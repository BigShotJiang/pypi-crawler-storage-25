"""CLI entrypoint to run Bayesian optimization over precomputed embeddings."""

from __future__ import annotations

import argparse

from bo_runner import run_bo_experiment
from config import BOConfig
from input_manager import load_experiment_data
from results import save_experiment_result


def _parse_args() -> argparse.Namespace:
    """Parse command-line arguments for BO execution."""
    parser = argparse.ArgumentParser(description="Bayesian optimization over precomputed molecular embeddings.")
    parser.add_argument("--embeddings-npy", type=str, required=True, help="Path to embedding matrix (.npy).")
    parser.add_argument("--targets-csv", type=str, required=True, help="Path to original targets CSV.")
    parser.add_argument("--target-column", type=str, required=True, help="Column name in targets CSV to optimize.")
    parser.add_argument("--output-dir", type=str, default="results")
    parser.add_argument("--kernel-type", type=str, default="matern", choices=["matern", "rbf"])
    parser.add_argument("--acquisition-type", type=str, default="ei", choices=["ei", "thompson"])
    parser.add_argument("--n-trials", type=int, default=1)
    parser.add_argument("--n-bo-steps", type=int, default=5)
    parser.add_argument("--init-fraction", type=float, default=0.05)
    parser.add_argument("--init-count", type=int, default=None)
    parser.add_argument("--maximize", action="store_true", help="Optimize for maximum objective.")
    parser.add_argument("--minimize", action="store_true", help="Optimize for minimum objective.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed.")
    parser.add_argument("--dtype", type=str, default="float64", choices=["float32", "float64"])
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument(
        "--no-standardize-y",
        action="store_true",
        help="Disable target standardization in input_manager.",
    )
    return parser.parse_args()


def _build_config_from_args(args: argparse.Namespace) -> BOConfig:
    """Build `BOConfig` from direct CLI flags."""
    if args.maximize and args.minimize:
        raise ValueError("Use only one of --maximize or --minimize.")

    maximize = True if not args.minimize else False
    if args.maximize:
        maximize = True

    return BOConfig(
        embedding_npy_path=args.embeddings_npy,
        targets_csv_path=args.targets_csv,
        target_column=args.target_column,
        output_dir=args.output_dir,
        kernel_type=args.kernel_type,
        acquisition_type=args.acquisition_type,
        n_trials=args.n_trials,
        n_bo_steps=args.n_bo_steps,
        init_fraction=args.init_fraction,
        init_count=args.init_count,
        maximize=maximize,
        random_seed=args.seed,
        dtype=args.dtype,
        device=args.device,
        standardize_y=not args.no_standardize_y,
    )


def main() -> None:
    """Load data, run BO experiment, and save artifacts."""
    args = _parse_args()
    config = _build_config_from_args(args)
    x_all, y_all = load_experiment_data(config)
    result = run_bo_experiment(x_all=x_all, y_all=y_all, config=config)
    run_dir = save_experiment_result(result, config.output_dir)

    final_best = result.best_so_far_matrix[:, -1]
    print(f"Saved run artifacts to: {run_dir}")
    print(f"Final best-so-far mean over trials: {final_best.mean():.6f}")
    print(f"Final best-so-far std over trials: {final_best.std():.6f}")


if __name__ == "__main__":
    main()
