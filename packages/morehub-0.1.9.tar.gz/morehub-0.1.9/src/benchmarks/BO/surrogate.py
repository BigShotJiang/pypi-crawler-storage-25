"""Surrogate model interfaces and GP implementations for dense embeddings."""

from __future__ import annotations

from abc import ABC, abstractmethod

import torch
from botorch.models import SingleTaskGP
from gpytorch.distributions import MultivariateNormal
from gpytorch.kernels import MaternKernel, RBFKernel, ScaleKernel
from gpytorch.likelihoods import GaussianLikelihood
from gpytorch.means import ConstantMean
from gpytorch.mlls import ExactMarginalLogLikelihood

from config import BOConfig

try:
    from botorch.fit import fit_gpytorch_mll

    def _fit_mll(mll: ExactMarginalLogLikelihood) -> None:
        """Fit GP marginal log likelihood (new BoTorch API)."""
        fit_gpytorch_mll(mll)

except ImportError:
    from botorch import fit_gpytorch_model

    def _fit_mll(mll: ExactMarginalLogLikelihood) -> None:
        """Fit GP marginal log likelihood (legacy BoTorch API)."""
        fit_gpytorch_model(mll)


class DenseFeatureGP(SingleTaskGP):
    """Single-task GP with a kernel suitable for continuous dense vectors."""

    def __init__(self, train_X: torch.Tensor, train_Y: torch.Tensor, kernel_type: str = "matern"):
        """Create a GP with `matern` or `rbf` base kernel."""
        super().__init__(train_X, train_Y, likelihood=GaussianLikelihood())
        self.mean_module = ConstantMean()
        self.covar_module = ScaleKernel(base_kernel=_build_kernel(kernel_type, train_X.shape[-1]))
        self.to(train_X)

    def forward(self, x: torch.Tensor) -> MultivariateNormal:
        """Return latent GP distribution at query points."""
        mean_x = self.mean_module(x)
        covar_x = self.covar_module(x)
        return MultivariateNormal(mean_x, covar_x)


def _build_kernel(kernel_type: str, n_features: int):
    """Build an ARD kernel for dense feature inputs."""
    if kernel_type == "matern":
        return MaternKernel(nu=2.5, ard_num_dims=n_features)
    if kernel_type == "rbf":
        return RBFKernel(ard_num_dims=n_features)
    raise ValueError(f"Unsupported kernel_type='{kernel_type}'. Use 'matern' or 'rbf'.")


class BaseSurrogate(ABC):
    """Minimal interface expected by the BO runner."""

    @abstractmethod
    def fit(self, train_x: torch.Tensor, train_y: torch.Tensor) -> None:
        """Fit surrogate on observed points."""
        raise NotImplementedError

    @abstractmethod
    def posterior(self, query_x: torch.Tensor):
        """Return posterior object for candidate inputs."""
        raise NotImplementedError

    @property
    @abstractmethod
    def model(self):
        """Expose backend model object required by acquisition functions."""
        raise NotImplementedError


class DenseFeatureGPSurrogate(BaseSurrogate):
    """`BaseSurrogate` wrapper around `DenseFeatureGP`."""

    def __init__(self, kernel_type: str = "matern"):
        """Initialize unfitted GP surrogate."""
        self.kernel_type = kernel_type
        self._model: DenseFeatureGP | None = None
        self._mll: ExactMarginalLogLikelihood | None = None

    def fit(self, train_x: torch.Tensor, train_y: torch.Tensor) -> None:
        """Fit a fresh GP model on current observations."""
        if train_y.ndim == 1:
            train_y = train_y.unsqueeze(-1)
        self._model = DenseFeatureGP(train_x, train_y, kernel_type=self.kernel_type).to(train_x)
        self._mll = ExactMarginalLogLikelihood(self._model.likelihood, self._model)
        _fit_mll(self._mll)
        self._model.eval()

    def posterior(self, query_x: torch.Tensor):
        """Compute model posterior for query points."""
        if self._model is None:
            raise RuntimeError("Surrogate has not been fit yet.")
        self._model.eval()
        return self._model.posterior(query_x)

    @property
    def model(self) -> DenseFeatureGP:
        """Return fitted GP model for acquisition modules."""
        if self._model is None:
            raise RuntimeError("Surrogate has not been fit yet.")
        return self._model


def build_surrogate(config: BOConfig) -> BaseSurrogate:
    """Factory to construct the configured surrogate implementation."""
    if config.surrogate_type != "gp":
        raise ValueError(f"Unsupported surrogate_type='{config.surrogate_type}'. Only 'gp' is implemented.")
    return DenseFeatureGPSurrogate(kernel_type=config.kernel_type)
