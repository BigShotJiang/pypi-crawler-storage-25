# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'bo_ui.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QFrame, QGridLayout,
    QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QRadioButton, QSizePolicy, QSpinBox, QTextEdit,
    QVBoxLayout, QWidget)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1003, 754)
        self.verticalLayout_2 = QVBoxLayout(Form)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.frame_29 = QFrame(Form)
        self.frame_29.setObjectName(u"frame_29")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.frame_29.sizePolicy().hasHeightForWidth())
        self.frame_29.setSizePolicy(sizePolicy)
        self.frame_29.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_29.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout = QGridLayout(self.frame_29)
        self.gridLayout.setObjectName(u"gridLayout")
        self.frame_30 = QFrame(self.frame_29)
        self.frame_30.setObjectName(u"frame_30")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.frame_30.sizePolicy().hasHeightForWidth())
        self.frame_30.setSizePolicy(sizePolicy1)
        self.frame_30.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_30.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_7 = QVBoxLayout(self.frame_30)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.frame_31 = QFrame(self.frame_30)
        self.frame_31.setObjectName(u"frame_31")
        self.frame_31.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_31.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_31.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout = QVBoxLayout(self.frame_31)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.frame_6 = QFrame(self.frame_31)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_6.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.frame_6)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label_28 = QLabel(self.frame_6)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setMinimumSize(QSize(300, 0))
        self.label_28.setMaximumSize(QSize(100, 16777215))
        font = QFont()
        font.setFamilies([u"Oswald"])
        font.setPointSize(15)
        self.label_28.setFont(font)
        self.label_28.setTextFormat(Qt.TextFormat.PlainText)
        self.label_28.setScaledContents(False)

        self.horizontalLayout_2.addWidget(self.label_28)

        self.frame_39 = QFrame(self.frame_6)
        self.frame_39.setObjectName(u"frame_39")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.frame_39.sizePolicy().hasHeightForWidth())
        self.frame_39.setSizePolicy(sizePolicy2)
        self.frame_39.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_39.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_26 = QHBoxLayout(self.frame_39)
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.label_26 = QLabel(self.frame_39)
        self.label_26.setObjectName(u"label_26")
        font1 = QFont()
        font1.setFamilies([u"Oswald"])
        font1.setPointSize(10)
        self.label_26.setFont(font1)

        self.horizontalLayout_26.addWidget(self.label_26)

        self.pushButton_6 = QPushButton(self.frame_39)
        self.pushButton_6.setObjectName(u"pushButton_6")
        self.pushButton_6.setMinimumSize(QSize(30, 30))
        self.pushButton_6.setMaximumSize(QSize(40, 40))
        icon = QIcon()
        icon.addFile(u"icons/run.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_6.setIcon(icon)
        self.pushButton_6.setIconSize(QSize(30, 30))

        self.horizontalLayout_26.addWidget(self.pushButton_6)


        self.horizontalLayout_2.addWidget(self.frame_39)


        self.verticalLayout.addWidget(self.frame_6)

        self.frame_33 = QFrame(self.frame_31)
        self.frame_33.setObjectName(u"frame_33")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(1)
        sizePolicy3.setHeightForWidth(self.frame_33.sizePolicy().hasHeightForWidth())
        self.frame_33.setSizePolicy(sizePolicy3)
        self.frame_33.setMinimumSize(QSize(0, 0))
        self.frame_33.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_33.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_36 = QHBoxLayout(self.frame_33)
        self.horizontalLayout_36.setObjectName(u"horizontalLayout_36")
        self.frame_45 = QFrame(self.frame_33)
        self.frame_45.setObjectName(u"frame_45")
        sizePolicy1.setHeightForWidth(self.frame_45.sizePolicy().hasHeightForWidth())
        self.frame_45.setSizePolicy(sizePolicy1)
        self.frame_45.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_45.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_2 = QGridLayout(self.frame_45)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.widget_4 = QWidget(self.frame_45)
        self.widget_4.setObjectName(u"widget_4")
        self.verticalLayout_8 = QVBoxLayout(self.widget_4)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.label_5 = QLabel(self.widget_4)
        self.label_5.setObjectName(u"label_5")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.label_5.sizePolicy().hasHeightForWidth())
        self.label_5.setSizePolicy(sizePolicy4)

        self.verticalLayout_8.addWidget(self.label_5)

        self.spinBox = QSpinBox(self.widget_4)
        self.spinBox.setObjectName(u"spinBox")
        self.spinBox.setValue(20)

        self.verticalLayout_8.addWidget(self.spinBox)


        self.gridLayout_2.addWidget(self.widget_4, 1, 0, 1, 1)

        self.widget_2 = QWidget(self.frame_45)
        self.widget_2.setObjectName(u"widget_2")
        self.verticalLayout_5 = QVBoxLayout(self.widget_2)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.label_2 = QLabel(self.widget_2)
        self.label_2.setObjectName(u"label_2")
        sizePolicy4.setHeightForWidth(self.label_2.sizePolicy().hasHeightForWidth())
        self.label_2.setSizePolicy(sizePolicy4)

        self.verticalLayout_5.addWidget(self.label_2)

        self.radioButton_8 = QRadioButton(self.widget_2)
        self.radioButton_8.setObjectName(u"radioButton_8")
        font2 = QFont()
        font2.setFamilies([u"Oswald"])
        self.radioButton_8.setFont(font2)

        self.verticalLayout_5.addWidget(self.radioButton_8)

        self.radioButton_9 = QRadioButton(self.widget_2)
        self.radioButton_9.setObjectName(u"radioButton_9")
        self.radioButton_9.setFont(font2)

        self.verticalLayout_5.addWidget(self.radioButton_9)


        self.gridLayout_2.addWidget(self.widget_2, 0, 1, 1, 1)

        self.widget_3 = QWidget(self.frame_45)
        self.widget_3.setObjectName(u"widget_3")
        self.verticalLayout_6 = QVBoxLayout(self.widget_3)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.label_3 = QLabel(self.widget_3)
        self.label_3.setObjectName(u"label_3")
        sizePolicy4.setHeightForWidth(self.label_3.sizePolicy().hasHeightForWidth())
        self.label_3.setSizePolicy(sizePolicy4)

        self.verticalLayout_6.addWidget(self.label_3)

        self.radioButton_10 = QRadioButton(self.widget_3)
        self.radioButton_10.setObjectName(u"radioButton_10")
        self.radioButton_10.setFont(font2)

        self.verticalLayout_6.addWidget(self.radioButton_10)

        self.radioButton_11 = QRadioButton(self.widget_3)
        self.radioButton_11.setObjectName(u"radioButton_11")
        self.radioButton_11.setFont(font2)

        self.verticalLayout_6.addWidget(self.radioButton_11)


        self.gridLayout_2.addWidget(self.widget_3, 2, 1, 1, 1)

        self.widget_6 = QWidget(self.frame_45)
        self.widget_6.setObjectName(u"widget_6")
        self.verticalLayout_12 = QVBoxLayout(self.widget_6)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.label_7 = QLabel(self.widget_6)
        self.label_7.setObjectName(u"label_7")
        sizePolicy4.setHeightForWidth(self.label_7.sizePolicy().hasHeightForWidth())
        self.label_7.setSizePolicy(sizePolicy4)

        self.verticalLayout_12.addWidget(self.label_7)

        self.radioButton_14 = QRadioButton(self.widget_6)
        self.radioButton_14.setObjectName(u"radioButton_14")
        self.radioButton_14.setFont(font2)

        self.verticalLayout_12.addWidget(self.radioButton_14)

        self.radioButton_15 = QRadioButton(self.widget_6)
        self.radioButton_15.setObjectName(u"radioButton_15")
        self.radioButton_15.setFont(font2)

        self.verticalLayout_12.addWidget(self.radioButton_15)


        self.gridLayout_2.addWidget(self.widget_6, 1, 1, 1, 1)

        self.widget = QWidget(self.frame_45)
        self.widget.setObjectName(u"widget")
        self.verticalLayout_4 = QVBoxLayout(self.widget)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.label = QLabel(self.widget)
        self.label.setObjectName(u"label")

        self.verticalLayout_4.addWidget(self.label)

        self.lineEdit = QLineEdit(self.widget)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setStyleSheet(u"background-color: rgb(200,200,200);")

        self.verticalLayout_4.addWidget(self.lineEdit)


        self.gridLayout_2.addWidget(self.widget, 0, 0, 1, 1)

        self.widget_5 = QWidget(self.frame_45)
        self.widget_5.setObjectName(u"widget_5")
        self.verticalLayout_10 = QVBoxLayout(self.widget_5)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.label_6 = QLabel(self.widget_5)
        self.label_6.setObjectName(u"label_6")
        sizePolicy4.setHeightForWidth(self.label_6.sizePolicy().hasHeightForWidth())
        self.label_6.setSizePolicy(sizePolicy4)

        self.verticalLayout_10.addWidget(self.label_6)

        self.spinBox_2 = QSpinBox(self.widget_5)
        self.spinBox_2.setObjectName(u"spinBox_2")
        self.spinBox_2.setValue(20)

        self.verticalLayout_10.addWidget(self.spinBox_2)


        self.gridLayout_2.addWidget(self.widget_5, 2, 0, 1, 1)


        self.horizontalLayout_36.addWidget(self.frame_45)


        self.verticalLayout.addWidget(self.frame_33)

        self.frame_54 = QFrame(self.frame_31)
        self.frame_54.setObjectName(u"frame_54")
        self.frame_54.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_54.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_54.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_40 = QHBoxLayout(self.frame_54)
        self.horizontalLayout_40.setObjectName(u"horizontalLayout_40")
        self.model_installed_4 = QCheckBox(self.frame_54)
        self.model_installed_4.setObjectName(u"model_installed_4")
        self.model_installed_4.setEnabled(False)
        font3 = QFont()
        font3.setFamilies([u"Oswald"])
        font3.setPointSize(9)
        self.model_installed_4.setFont(font3)
        self.model_installed_4.setAutoFillBackground(False)
        self.model_installed_4.setIconSize(QSize(30, 30))
        self.model_installed_4.setCheckable(False)
        self.model_installed_4.setTristate(False)

        self.horizontalLayout_40.addWidget(self.model_installed_4)


        self.verticalLayout.addWidget(self.frame_54)


        self.verticalLayout_7.addWidget(self.frame_31)


        self.gridLayout.addWidget(self.frame_30, 0, 0, 1, 1)

        self.frame = QFrame(self.frame_29)
        self.frame.setObjectName(u"frame")
        sizePolicy1.setHeightForWidth(self.frame.sizePolicy().hasHeightForWidth())
        self.frame.setSizePolicy(sizePolicy1)
        self.frame.setMinimumSize(QSize(0, 0))
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_11 = QVBoxLayout(self.frame)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.frame_38 = QFrame(self.frame)
        self.frame_38.setObjectName(u"frame_38")
        sizePolicy1.setHeightForWidth(self.frame_38.sizePolicy().hasHeightForWidth())
        self.frame_38.setSizePolicy(sizePolicy1)
        self.frame_38.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_38.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_13 = QVBoxLayout(self.frame_38)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.widget_9 = QWidget(self.frame_38)
        self.widget_9.setObjectName(u"widget_9")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.widget_9.sizePolicy().hasHeightForWidth())
        self.widget_9.setSizePolicy(sizePolicy5)
        self.widget_9.setMinimumSize(QSize(0, 50))
        self.gridLayout_3 = QGridLayout(self.widget_9)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.label_25 = QLabel(self.widget_9)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setFont(font1)

        self.gridLayout_3.addWidget(self.label_25, 0, 0, 1, 1)


        self.verticalLayout_13.addWidget(self.widget_9)

        self.textEdit_3 = QTextEdit(self.frame_38)
        self.textEdit_3.setObjectName(u"textEdit_3")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(2)
        sizePolicy6.setHeightForWidth(self.textEdit_3.sizePolicy().hasHeightForWidth())
        self.textEdit_3.setSizePolicy(sizePolicy6)
        self.textEdit_3.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_3.setReadOnly(True)

        self.verticalLayout_13.addWidget(self.textEdit_3)

        self.widget_7 = QWidget(self.frame_38)
        self.widget_7.setObjectName(u"widget_7")
        self.verticalLayout_3 = QVBoxLayout(self.widget_7)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.label_8 = QLabel(self.widget_7)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setFont(font2)

        self.verticalLayout_3.addWidget(self.label_8)

        self.widget_70 = QWidget(self.widget_7)
        self.widget_70.setObjectName(u"widget_70")
        sizePolicy3.setHeightForWidth(self.widget_70.sizePolicy().hasHeightForWidth())
        self.widget_70.setSizePolicy(sizePolicy3)
        self.horizontalLayout_192 = QHBoxLayout(self.widget_70)
        self.horizontalLayout_192.setObjectName(u"horizontalLayout_192")
        self.pushButton_47 = QPushButton(self.widget_70)
        self.pushButton_47.setObjectName(u"pushButton_47")
        self.pushButton_47.setMinimumSize(QSize(46, 46))
        self.pushButton_47.setMaximumSize(QSize(60, 16777215))
        icon1 = QIcon()
        icon1.addFile(u"icons/folder.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_47.setIcon(icon1)
        self.pushButton_47.setIconSize(QSize(30, 30))

        self.horizontalLayout_192.addWidget(self.pushButton_47)

        self.label_149 = QLabel(self.widget_70)
        self.label_149.setObjectName(u"label_149")
        self.label_149.setMinimumSize(QSize(2, 33))
        self.label_149.setMaximumSize(QSize(16777215, 33))
        self.label_149.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_192.addWidget(self.label_149)


        self.verticalLayout_3.addWidget(self.widget_70)


        self.verticalLayout_13.addWidget(self.widget_7)

        self.widget_8 = QWidget(self.frame_38)
        self.widget_8.setObjectName(u"widget_8")
        self.horizontalLayout = QHBoxLayout(self.widget_8)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.frame_41 = QFrame(self.widget_8)
        self.frame_41.setObjectName(u"frame_41")
        sizePolicy2.setHeightForWidth(self.frame_41.sizePolicy().hasHeightForWidth())
        self.frame_41.setSizePolicy(sizePolicy2)
        self.frame_41.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_41.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_28 = QHBoxLayout(self.frame_41)
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.label_29 = QLabel(self.frame_41)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setFont(font1)

        self.horizontalLayout_28.addWidget(self.label_29)

        self.pushButton_8 = QPushButton(self.frame_41)
        self.pushButton_8.setObjectName(u"pushButton_8")
        self.pushButton_8.setMinimumSize(QSize(30, 30))
        self.pushButton_8.setMaximumSize(QSize(40, 40))
        self.pushButton_8.setIcon(icon)
        self.pushButton_8.setIconSize(QSize(30, 30))

        self.horizontalLayout_28.addWidget(self.pushButton_8)


        self.horizontalLayout.addWidget(self.frame_41)

        self.frame_42 = QFrame(self.widget_8)
        self.frame_42.setObjectName(u"frame_42")
        sizePolicy2.setHeightForWidth(self.frame_42.sizePolicy().hasHeightForWidth())
        self.frame_42.setSizePolicy(sizePolicy2)
        self.frame_42.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_42.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_29 = QHBoxLayout(self.frame_42)
        self.horizontalLayout_29.setObjectName(u"horizontalLayout_29")
        self.checkBox_2 = QCheckBox(self.frame_42)
        self.checkBox_2.setObjectName(u"checkBox_2")
        self.checkBox_2.setFont(font2)

        self.horizontalLayout_29.addWidget(self.checkBox_2)

        self.checkBox = QCheckBox(self.frame_42)
        self.checkBox.setObjectName(u"checkBox")
        self.checkBox.setFont(font2)

        self.horizontalLayout_29.addWidget(self.checkBox)


        self.horizontalLayout.addWidget(self.frame_42)


        self.verticalLayout_13.addWidget(self.widget_8)


        self.verticalLayout_11.addWidget(self.frame_38)


        self.gridLayout.addWidget(self.frame, 0, 1, 1, 1)


        self.verticalLayout_2.addWidget(self.frame_29)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.label_28.setText(QCoreApplication.translate("Form", u"Bayesian Optimization Benchmarking", None))
        self.label_26.setText(QCoreApplication.translate("Form", u"RUN", None))
        self.pushButton_6.setText("")
        self.label_5.setText(QCoreApplication.translate("Form", u"Trials", None))
        self.label_2.setText(QCoreApplication.translate("Form", u"Kernel", None))
        self.radioButton_8.setText(QCoreApplication.translate("Form", u"Matern", None))
        self.radioButton_9.setText(QCoreApplication.translate("Form", u"RBF", None))
        self.label_3.setText(QCoreApplication.translate("Form", u"Acquisition", None))
        self.radioButton_10.setText(QCoreApplication.translate("Form", u"EI", None))
        self.radioButton_11.setText(QCoreApplication.translate("Form", u"Thompson", None))
        self.label_7.setText(QCoreApplication.translate("Form", u"Optimization direction", None))
        self.radioButton_14.setText(QCoreApplication.translate("Form", u"Maximum", None))
        self.radioButton_15.setText(QCoreApplication.translate("Form", u"Minimum", None))
        self.label.setText(QCoreApplication.translate("Form", u"What is the name of the target column?", None))
        self.label_6.setText(QCoreApplication.translate("Form", u"BO steps", None))
        self.model_installed_4.setText(QCoreApplication.translate("Form", u"Installation completed", None))
        self.label_25.setText(QCoreApplication.translate("Form", u"Status Console", None))
        self.textEdit_3.setHtml(QCoreApplication.translate("Form", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.label_8.setText(QCoreApplication.translate("Form", u"Select your data folder", None))
        self.pushButton_47.setText("")
        self.label_149.setText("")
        self.label_29.setText(QCoreApplication.translate("Form", u"Run visualization", None))
        self.pushButton_8.setText("")
        self.checkBox_2.setText(QCoreApplication.translate("Form", u"Parallelize models", None))
        self.checkBox.setText(QCoreApplication.translate("Form", u"Use Cuda", None))
    # retranslateUi

