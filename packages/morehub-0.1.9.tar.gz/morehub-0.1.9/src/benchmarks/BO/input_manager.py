"""Input loading and validation utilities for embeddings and targets."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from config import BOConfig


def load_embeddings(path: str | Path) -> np.ndarray:
    """Load dense embeddings from a `.npy` file and enforce shape `(N, D)`."""
    p = Path(path)
    if p.suffix.lower() != ".npy":
        raise ValueError(f"Embeddings must be provided as .npy, got: {p}")
    arr = np.asarray(np.load(p))
    if arr.ndim != 2:
        raise ValueError(f"Embeddings must be 2D (N, D), got shape {arr.shape}")
    return arr.astype(np.float64, copy=False)


def load_targets_from_csv(csv_path: str | Path, target_column: str) -> np.ndarray:
    """Load one target column from CSV as a 1D float vector."""
    p = Path(csv_path)
    if p.suffix.lower() != ".csv":
        raise ValueError(f"Targets must be provided as .csv, got: {p}")

    frame = pd.read_csv(p)
    if target_column not in frame.columns:
        cols = ", ".join(map(str, frame.columns))
        raise ValueError(
            f"target_column='{target_column}' not found in {p}. Available columns: {cols}"
        )

    y_series = pd.to_numeric(frame[target_column], errors="coerce")
    n_invalid = int(y_series.isna().sum())
    if n_invalid > 0:
        raise ValueError(
            f"Column '{target_column}' in {p} contains {n_invalid} non-numeric or missing values."
        )
    y = y_series.to_numpy(dtype=np.float64)
    return y


def validate_data(X: np.ndarray, y: np.ndarray) -> None:
    """Validate alignment, sample count, and finite values."""
    if X.shape[0] != y.shape[0]:
        raise ValueError(
            f"Number of rows in embeddings and targets must match, got {X.shape[0]} and {y.shape[0]}"
        )
    if X.shape[0] < 2:
        raise ValueError("Need at least 2 samples")
    if not np.isfinite(X).all():
        raise ValueError("Embeddings contain NaN or inf values")
    if not np.isfinite(y).all():
        raise ValueError("Targets contain NaN or inf values")


def scale_to_unit_cube(X: np.ndarray) -> np.ndarray:
    """Min-max scale each feature to [0, 1] using global dataset bounds."""
    x_min = np.min(X, axis=0)
    x_max = np.max(X, axis=0)
    denom = x_max - x_min
    safe_denom = np.where(denom > 0.0, denom, 1.0)
    X_scaled = (X - x_min) / safe_denom
    # Constant dimensions are uninformative; map them to zero.
    X_scaled[:, denom <= 0.0] = 0.0
    return X_scaled


def standardize_targets(y: np.ndarray) -> np.ndarray:
    """Z-score targets; returns unchanged copy when variance is zero."""
    std = np.std(y)
    if std <= 0.0:
        return y.copy()
    return (y - np.mean(y)) / std


def load_experiment_data(config: BOConfig) -> tuple[np.ndarray, np.ndarray]:
    """Load and validate experiment arrays from the configured paths."""
    X = load_embeddings(config.embedding_npy_path)
    y = load_targets_from_csv(config.targets_csv_path, config.target_column)
    validate_data(X, y)
    X = scale_to_unit_cube(X)
    if config.standardize_y:
        y = standardize_targets(y)
    return X, y
