"""Acquisition interfaces and implementations used by the BO runner."""

from __future__ import annotations

from abc import ABC, abstractmethod

import torch
from botorch.acquisition.analytic import LogExpectedImprovement

from config import BOConfig


class BaseAcquisition(ABC):
    """Interface for pool-based acquisition strategies."""

    @abstractmethod
    def score(self, model, x_pool: torch.Tensor, y_observed: torch.Tensor) -> torch.Tensor:
        """Return acquisition scores for all candidates in `x_pool`."""
        raise NotImplementedError

    def select_next(self, model, x_pool: torch.Tensor, y_observed: torch.Tensor) -> int:
        """Return the index of the highest-scoring candidate."""
        scores = self.score(model, x_pool, y_observed)
        return int(torch.argmax(scores).item())


class LogExpectedImprovementAcquisition(BaseAcquisition):
    """Log-Expected Improvement acquisition, evaluated in chunks for large pools."""

    def __init__(self, chunk_size: int = 4096):
        """Create LogEI scorer with configurable candidate chunk size."""
        self.chunk_size = chunk_size

    def score(self, model, x_pool: torch.Tensor, y_observed: torch.Tensor) -> torch.Tensor:
        """Compute LogEI scores for each candidate in `x_pool`."""
        best_f = torch.max(y_observed)
        acqf = LogExpectedImprovement(model=model, best_f=best_f)
        chunks = []
        with torch.no_grad():
            for start in range(0, x_pool.shape[0], self.chunk_size):
                x_chunk = x_pool[start : start + self.chunk_size].unsqueeze(-2)
                chunks.append(acqf(x_chunk).reshape(-1))
        return torch.cat(chunks, dim=0)


class ThompsonSamplingAcquisition(BaseAcquisition):
    """Single-sample Thompson sampling over the candidate pool."""

    def score(self, model, x_pool: torch.Tensor, y_observed: torch.Tensor) -> torch.Tensor:
        """Draw one posterior sample and use it as candidate scores."""
        del y_observed
        with torch.no_grad():
            posterior = model.posterior(x_pool)
            sampled = posterior.rsample(torch.Size([1])).squeeze(0).squeeze(-1)
        return sampled


def build_acquisition(config: BOConfig) -> BaseAcquisition:
    """Factory to construct the configured acquisition strategy."""
    if config.acquisition_type in {"ei", "expected_improvement"}:
        return LogExpectedImprovementAcquisition()
    if config.acquisition_type in {"thompson", "ts"}:
        return ThompsonSamplingAcquisition()
    raise ValueError(
        f"Unsupported acquisition_type='{config.acquisition_type}'. "
        "Use 'ei' or 'thompson'."
    )
