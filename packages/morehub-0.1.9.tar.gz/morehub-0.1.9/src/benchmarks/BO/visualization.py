"""Plotting helpers for BO run artifacts."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Sequence

import matplotlib.pyplot as plt
import numpy as np

from results import load_run_artifacts


def plot_best_so_far(
    best_so_far: np.ndarray,
    *,
    label: str,
    ax: plt.Axes | None = None,
    color: str | None = None,
) -> plt.Axes:
    """Plot a single best-so-far curve (or mean/std if 2D)."""
    if ax is None:
        _, ax = plt.subplots(figsize=(8, 5))

    if best_so_far.ndim == 1:
        mean = best_so_far
        std = np.zeros_like(best_so_far)
    elif best_so_far.ndim == 2:
        mean = best_so_far.mean(axis=0)
        std = best_so_far.std(axis=0)
    else:
        raise ValueError(f"Expected best_so_far with ndim 1 or 2, got shape {best_so_far.shape}")

    steps = np.arange(mean.shape[0])
    ax.plot(steps, mean, label=label, color=color)
    ax.fill_between(steps, mean - std, mean + std, alpha=0.2, color=color)
    ax.set_xlabel("BO Step")
    ax.set_ylabel("Best-so-far objective")
    ax.grid(alpha=0.25)
    return ax


def plot_runs(run_dirs: Sequence[str | Path], labels: Sequence[str] | None = None) -> plt.Figure:
    """Plot and compare multiple saved run directories."""
    fig, ax = plt.subplots(figsize=(9, 5))
    for i, run_dir in enumerate(run_dirs):
        artifacts = load_run_artifacts(run_dir)
        label = labels[i] if labels and i < len(labels) else Path(run_dir).name
        plot_best_so_far(artifacts["best_so_far"], label=label, ax=ax)
    ax.legend(loc="best")
    fig.tight_layout()
    return fig


def _parse_args() -> argparse.Namespace:
    """Parse CLI arguments for artifact plotting."""
    parser = argparse.ArgumentParser(description="Plot BO run artifacts.")
    parser.add_argument("run_dirs", nargs="+", help="Run directories containing best_so_far.npy and metadata.")
    parser.add_argument("--labels", nargs="*", default=None, help="Optional labels matching run_dirs order.")
    parser.add_argument("--save-path", default=None, help="If provided, saves figure to this path.")
    return parser.parse_args()


def main() -> None:
    """CLI entrypoint for plotting saved runs."""
    args = _parse_args()
    fig = plot_runs(args.run_dirs, labels=args.labels)
    if args.save_path:
        Path(args.save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(args.save_path, dpi=200, bbox_inches="tight")
        print(f"Saved figure to: {args.save_path}")
    else:
        plt.show()


if __name__ == "__main__":
    main()
