"""Core Bayesian optimization loop over a discrete candidate pool."""

from __future__ import annotations

import time

import numpy as np
from tqdm.auto import tqdm

from acquisition import build_acquisition
from config import BOConfig
from results import BOExperimentResult, TrialHistory
from surrogate import build_surrogate
from utils import (
    apply_objective_direction,
    best_value,
    resolve_torch_device_dtype,
    set_global_seed,
    to_torch,
)


def _run_single_trial(
    x_all: np.ndarray,
    y_all: np.ndarray,
    config: BOConfig,
    trial_seed: int,
) -> TrialHistory:
    """Run one BO trial and return full per-step history."""
    rng = np.random.default_rng(trial_seed)
    n_samples = x_all.shape[0]
    n_init = config.resolved_init_count(n_samples)
    if n_init >= n_samples:
        raise ValueError(
            f"Need at least one pool point after initialization. Got n_init={n_init}, n_samples={n_samples}."
        )

    max_steps = min(config.n_bo_steps, n_samples - n_init)
    y_for_model = apply_objective_direction(y_all, maximize=config.maximize)
    observed_mask = np.zeros(n_samples, dtype=bool)
    initial_indices = rng.choice(n_samples, size=n_init, replace=False)
    observed_mask[initial_indices] = True

    device, dtype = resolve_torch_device_dtype(config.device, config.dtype)
    surrogate = build_surrogate(config)
    acquisition = build_acquisition(config)

    selected_indices: list[int] = []
    observed_targets = y_all[initial_indices].tolist()
    best_so_far = [best_value(y_all[observed_mask], maximize=config.maximize)]

    for _ in tqdm(range(max_steps), desc="BO steps", leave=False):
        train_idx = np.flatnonzero(observed_mask)
        pool_idx = np.flatnonzero(~observed_mask)

        x_train = to_torch(x_all[train_idx], dtype=dtype, device=device)
        y_train = to_torch(y_for_model[train_idx], dtype=dtype, device=device).unsqueeze(-1)
        x_pool = to_torch(x_all[pool_idx], dtype=dtype, device=device)

        surrogate.fit(x_train, y_train)
        next_local_idx = acquisition.select_next(
            surrogate.model, x_pool, y_train.squeeze(-1)
        )
        next_global_idx = int(pool_idx[next_local_idx])

        observed_mask[next_global_idx] = True
        selected_indices.append(next_global_idx)
        observed_targets.append(float(y_all[next_global_idx]))
        best_so_far.append(best_value(y_all[observed_mask], maximize=config.maximize))

    if max_steps < config.n_bo_steps:
        pad = [best_so_far[-1]] * (config.n_bo_steps - max_steps)
        best_so_far.extend(pad)

    return TrialHistory(
        initial_indices=np.asarray(initial_indices, dtype=np.int64),
        selected_indices=np.asarray(selected_indices, dtype=np.int64),
        observed_targets=np.asarray(observed_targets, dtype=np.float64),
        best_so_far=np.asarray(best_so_far, dtype=np.float64),
    )


def run_bo_experiment(x_all: np.ndarray, y_all: np.ndarray, config: BOConfig) -> BOExperimentResult:
    """Run multi-trial BO and aggregate outcomes for saving/plotting."""
    set_global_seed(config.random_seed)

    # Initialize lists to collect trial results and metadata for summary and saving.
    trial_histories: list[TrialHistory] = []
    trial_seeds: list[int] = []
    trial_durations_sec: list[float] = []

    for trial in tqdm(range(config.n_trials), desc="Trials"):
        trial_seed = config.random_seed + trial
        t0 = time.perf_counter() # Start timer for this trial
        history = _run_single_trial(
            x_all=x_all,
            y_all=y_all,
            config=config,
            trial_seed=trial_seed,
        )
        dt = time.perf_counter() - t0
        trial_histories.append(history)
        trial_seeds.append(trial_seed)
        trial_durations_sec.append(dt)

    best_so_far_matrix = np.vstack([h.best_so_far for h in trial_histories])
    metadata = {
        "n_samples": int(x_all.shape[0]),
        "n_features": int(x_all.shape[1]),
        "mean_trial_duration_sec": float(np.mean(trial_durations_sec)),
        "trial_durations_sec": trial_durations_sec,
    }

    return BOExperimentResult(
        config=config,
        trial_histories=trial_histories,
        best_so_far_matrix=best_so_far_matrix,
        trial_seeds=trial_seeds,
        metadata=metadata,
    )
