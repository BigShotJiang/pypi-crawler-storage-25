﻿"""Workspace launcher for BO benchmark runs.

This script is called by the GUI and handles:
1. Provisioning/reusing a dedicated benchmark virtual environment.
2. Installing benchmark dependencies from requirements.txt.
3. Discovering model embeddings in a data instance.
4. Executing BO runs per model/variant and saving manifests/sentinels.
5. Building single-run and cross-model comparison plots.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


BENCHMARK_NAME = "BO"
DATA_SENTINEL = ".morehub_data.json"
DEPS_STATE_FILE = ".deps_state.json"
RUN_META_FILE = ".run_meta.json"
MODEL_STATUS_FILE = ".bo_status.json"
MODEL_MANIFEST_FILE = "manifest.json"


def _log(message: str) -> None:
    print(message, flush=True)


def _cmd_display(cmd: list[str]) -> str:
    if os.name == "nt":
        return subprocess.list2cmdline(cmd)
    return " ".join(cmd)


def _run_checked(cmd: list[str], cwd: Path | None = None) -> None:
    _log(f"Running: {_cmd_display(cmd)}")
    subprocess.run(cmd, cwd=str(cwd) if cwd else None, check=True)


def _run_capture_checked(cmd: list[str], cwd: Path | None = None) -> str:
    result = subprocess.run(
        cmd,
        cwd=str(cwd) if cwd else None,
        check=True,
        text=True,
        capture_output=True,
    )
    return result.stdout.strip()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _venv_python(venv_dir: Path) -> Path:
    if os.name == "nt":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def _load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _ensure_venv(venv_dir: Path) -> Path:
    python_path = _venv_python(venv_dir)
    if python_path.exists():
        _log(f"Benchmark virtual environment already exists: {venv_dir}")
        return python_path

    _log(f"Creating benchmark virtual environment: {venv_dir}")
    _run_checked([sys.executable, "-m", "venv", str(venv_dir)])

    if not python_path.exists():
        raise RuntimeError(f"Failed to create benchmark Python at {python_path}")
    return python_path


def _ensure_dependencies(venv_python: Path, requirements_path: Path, state_path: Path) -> None:
    requirements_hash = _sha256(requirements_path)
    state = _load_json(state_path)

    if (
        state.get("requirements_sha256") == requirements_hash
        and state.get("requirements_path") == str(requirements_path)
        and state.get("venv_python") == str(venv_python)
    ):
        _log("Benchmark dependencies already satisfied. Skipping pip install.")
        return

    _log("Installing benchmark dependencies...")
    _run_checked([str(venv_python), "-m", "pip", "install", "--upgrade", "pip"])
    _run_checked([str(venv_python), "-m", "pip", "install", "-r", str(requirements_path)])

    _save_json(
        state_path,
        {
            "benchmark": BENCHMARK_NAME,
            "requirements_path": str(requirements_path),
            "requirements_sha256": requirements_hash,
            "venv_python": str(venv_python),
            "installed_at": datetime.now(timezone.utc).isoformat(),
        },
    )


def _safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value.strip()).strip("._-") or "item"


def _discover_embedding_cases(embeddings_root: Path) -> list[dict]:
    if not embeddings_root.exists():
        return []

    cases = []
    seen_keys: set[str] = set()
    for npy_path in sorted(p for p in embeddings_root.rglob("*.npy") if p.is_file()):
        filtered_csv = npy_path.with_name(f"{npy_path.stem}_filtered.csv")
        if not filtered_csv.exists():
            continue

        try:
            rel_parent = npy_path.parent.resolve().relative_to(embeddings_root.resolve())
        except ValueError:
            continue

        parent_parts = [_safe_name(part) for part in rel_parent.parts if part]
        if not parent_parts:
            continue

        key = "_".join(parent_parts)
        if key in seen_keys:
            key = f"{key}_{_safe_name(npy_path.stem)}"
        seen_keys.add(key)

        cases.append(
            {
                "model_key": key,
                "embeddings_path": npy_path,
                "targets_csv": filtered_csv,
                "relative_parent": str(rel_parent),
                "stem": npy_path.stem,
            }
        )

    return cases


def _latest_bo_run(model_dir: Path) -> Path | None:
    candidates = [p for p in model_dir.glob("bo_run_*") if p.is_dir()]
    if not candidates:
        return None
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0]


def _cuda_available_in_venv(venv_python: Path, bo_source_dir: Path) -> bool:
    cmd = [
        str(venv_python),
        "-c",
        "import torch; print('1' if torch.cuda.is_available() else '0')",
    ]
    try:
        output = _run_capture_checked(cmd, cwd=bo_source_dir)
        return output.strip().endswith("1")
    except Exception as exc:
        _log(f"[BO] Warning: unable to probe CUDA availability in benchmark venv: {exc}")
        return False


def _resolve_device(requested_device: str, venv_python: Path, bo_source_dir: Path) -> str:
    requested = requested_device.lower()
    if requested not in {"auto", "cpu", "cuda"}:
        raise ValueError(f"Unsupported device '{requested_device}'. Use auto, cpu, or cuda.")

    cuda_available = _cuda_available_in_venv(venv_python, bo_source_dir)

    if requested == "cpu":
        return "cpu"
    if requested == "cuda":
        if cuda_available:
            return "cuda"
        raise RuntimeError(
            "CUDA requested but unavailable in benchmark venv. "
            f"Benchmark Python: {venv_python}. "
            "Install a CUDA-enabled PyTorch build there, or uncheck 'Use Cuda' in the BO widget and rerun."
        )

    # auto
    return "cuda" if cuda_available else "cpu"


def _resolve_parallel_workers(requested: int, n_cases: int, resolved_device: str) -> int:
    if n_cases <= 1:
        return 1

    if requested <= 0:
        cpu_count = os.cpu_count() or 1
        if cpu_count <= 2:
            workers = 1
        else:
            workers = max(1, min(4, cpu_count // 2))
    else:
        workers = requested

    workers = max(1, min(workers, n_cases))

    if resolved_device == "cuda" and workers > 1:
        _log("[BO] CUDA mode detected. For stability, forcing --parallel-models to 1.")
        workers = 1

    return workers


def _case_signature(args: argparse.Namespace, maximize: bool, resolved_device: str) -> dict:
    return {
        "target_column": args.target_column,
        "kernel_type": args.kernel_type,
        "acquisition_type": args.acquisition_type,
        "n_trials": args.n_trials,
        "n_bo_steps": args.n_bo_steps,
        "maximize": maximize,
        "seed": args.seed,
        "device": resolved_device,
        "dtype": args.dtype,
    }


def _build_bo_command(
    *,
    venv_python: Path,
    bo_main_script: Path,
    embeddings_path: Path,
    targets_csv: Path,
    target_column: str,
    model_output_dir: Path,
    kernel_type: str,
    acquisition_type: str,
    n_trials: int,
    n_bo_steps: int,
    maximize: bool,
    seed: int,
    device: str,
    dtype: str,
) -> list[str]:
    cmd = [
        str(venv_python),
        str(bo_main_script),
        "--embeddings-npy",
        str(embeddings_path),
        "--targets-csv",
        str(targets_csv),
        "--target-column",
        target_column,
        "--output-dir",
        str(model_output_dir),
        "--kernel-type",
        kernel_type,
        "--acquisition-type",
        acquisition_type,
        "--n-trials",
        str(n_trials),
        "--n-bo-steps",
        str(n_bo_steps),
        "--seed",
        str(seed),
        "--device",
        device,
        "--dtype",
        dtype,
    ]
    cmd.append("--maximize" if maximize else "--minimize")
    return cmd


def _render_plot(
    *,
    venv_python: Path,
    visualization_script: Path,
    run_dirs: list[Path],
    labels: list[str],
    save_path: Path,
    cwd: Path,
) -> None:
    if not run_dirs:
        raise RuntimeError("No run directories available for plotting.")

    cmd = [
        str(venv_python),
        str(visualization_script),
        *[str(p) for p in run_dirs],
        "--labels",
        *labels,
        "--save-path",
        str(save_path),
    ]
    _run_checked(cmd, cwd=cwd)


def _load_case_status(model_dir: Path) -> dict:
    return _load_json(model_dir / MODEL_STATUS_FILE)


def _save_case_status(model_dir: Path, payload: dict) -> None:
    _save_json(model_dir / MODEL_STATUS_FILE, payload)


def _save_case_manifest(model_dir: Path, payload: dict) -> None:
    _save_json(model_dir / MODEL_MANIFEST_FILE, payload)


def _run_case(
    *,
    case: dict,
    args: argparse.Namespace,
    maximize: bool,
    resolved_device: str,
    bo_source_dir: Path,
    bo_main_script: Path,
    visualization_script: Path,
    venv_python: Path,
    benchmark_root: Path,
) -> dict:
    model_key = case["model_key"]
    embeddings_path = Path(case["embeddings_path"]).resolve()
    targets_csv = Path(case["targets_csv"]).resolve()

    model_dir = benchmark_root / model_key
    model_dir.mkdir(parents=True, exist_ok=True)

    status_path = model_dir / MODEL_STATUS_FILE
    existing_status = _load_case_status(model_dir)
    signature = _case_signature(args, maximize, resolved_device)

    existing_run_dir = Path(existing_status.get("run_dir", "")) if existing_status.get("run_dir") else None
    if (
        not args.force_rerun
        and existing_status.get("status") == "success"
        and existing_status.get("signature") == signature
        and existing_run_dir is not None
        and existing_run_dir.exists()
    ):
        _log(f"[BO] Skipping {model_key}: successful result already exists.")
        return {
            "model_key": model_key,
            "status": "skipped",
            "run_dir": str(existing_run_dir),
            "model_dir": str(model_dir),
            "plot_path": existing_status.get("plot_path"),
            "manifest_path": str(model_dir / MODEL_MANIFEST_FILE),
            "exit_code": 0,
        }

    running_status = {
        "status": "running",
        "started_at": datetime.now(timezone.utc).isoformat(),
        "model_key": model_key,
        "signature": signature,
        "input": {
            "embeddings_npy": str(embeddings_path),
            "targets_csv": str(targets_csv),
        },
    }
    _save_case_status(model_dir, running_status)

    command = _build_bo_command(
        venv_python=venv_python,
        bo_main_script=bo_main_script,
        embeddings_path=embeddings_path,
        targets_csv=targets_csv,
        target_column=args.target_column,
        model_output_dir=model_dir,
        kernel_type=args.kernel_type,
        acquisition_type=args.acquisition_type,
        n_trials=args.n_trials,
        n_bo_steps=args.n_bo_steps,
        maximize=maximize,
        seed=args.seed,
        device=resolved_device,
        dtype=args.dtype,
    )

    exit_code = 0
    run_dir: Path | None = None
    single_plot_path: Path | None = None

    try:
        _run_checked(command, cwd=bo_source_dir)
        run_dir = _latest_bo_run(model_dir)
        if run_dir is None:
            raise RuntimeError(f"No bo_run_* output folder found in {model_dir} after successful run.")

        single_plot_path = model_dir / "best_so_far.png"
        _render_plot(
            venv_python=venv_python,
            visualization_script=visualization_script,
            run_dirs=[run_dir],
            labels=[model_key],
            save_path=single_plot_path,
            cwd=bo_source_dir,
        )

        status_payload = {
            "status": "success",
            "finished_at": datetime.now(timezone.utc).isoformat(),
            "model_key": model_key,
            "signature": signature,
            "run_dir": str(run_dir),
            "plot_path": str(single_plot_path),
            "input": {
                "embeddings_npy": str(embeddings_path),
                "targets_csv": str(targets_csv),
            },
        }
        _save_case_status(model_dir, status_payload)

        manifest = {
            "tool": "bo",
            "status": "success",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "model_key": model_key,
            "relative_parent": case.get("relative_parent"),
            "input": {
                "embeddings_npy": str(embeddings_path),
                "targets_csv": str(targets_csv),
                "target_column": args.target_column,
            },
            "config": signature,
            "command": command,
            "output": {
                "model_dir": str(model_dir),
                "run_dir": str(run_dir),
                "plot_path": str(single_plot_path),
            },
            "status_file": str(status_path),
        }
        _save_case_manifest(model_dir, manifest)
        _log(f"[BO] Completed successfully: {model_key}")

        return {
            "model_key": model_key,
            "status": "success",
            "run_dir": str(run_dir),
            "model_dir": str(model_dir),
            "plot_path": str(single_plot_path),
            "manifest_path": str(model_dir / MODEL_MANIFEST_FILE),
            "exit_code": 0,
        }

    except subprocess.CalledProcessError as exc:
        exit_code = int(exc.returncode)
    except Exception:
        exit_code = 1

    failed_status = {
        "status": "failed",
        "finished_at": datetime.now(timezone.utc).isoformat(),
        "model_key": model_key,
        "signature": signature,
        "input": {
            "embeddings_npy": str(embeddings_path),
            "targets_csv": str(targets_csv),
        },
        "exit_code": exit_code,
    }
    _save_case_status(model_dir, failed_status)

    manifest = {
        "tool": "bo",
        "status": "failed",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "model_key": model_key,
        "relative_parent": case.get("relative_parent"),
        "input": {
            "embeddings_npy": str(embeddings_path),
            "targets_csv": str(targets_csv),
            "target_column": args.target_column,
        },
        "config": signature,
        "command": command,
        "output": {
            "model_dir": str(model_dir),
        },
        "status_file": str(status_path),
        "exit_code": exit_code,
    }
    _save_case_manifest(model_dir, manifest)
    _log(f"[BO] Failed with exit code {exit_code}: {model_key}")

    return {
        "model_key": model_key,
        "status": "failed",
        "run_dir": str(run_dir) if run_dir is not None else None,
        "model_dir": str(model_dir),
        "plot_path": str(single_plot_path) if single_plot_path is not None else None,
        "manifest_path": str(model_dir / MODEL_MANIFEST_FILE),
        "exit_code": exit_code,
    }


def _successful_run_items(items: list[dict]) -> list[dict]:
    successful = []
    for item in items:
        if item.get("status") in {"success", "skipped"}:
            run_dir = item.get("run_dir")
            if run_dir and Path(run_dir).exists():
                successful.append(item)
    return successful


def _existing_successes_from_status(benchmark_root: Path) -> list[dict]:
    items = []
    for candidate in sorted(benchmark_root.iterdir()):
        if not candidate.is_dir():
            continue
        if candidate.name.startswith("."):
            continue
        status = _load_json(candidate / MODEL_STATUS_FILE)
        if status.get("status") != "success":
            continue
        run_dir = status.get("run_dir")
        if not run_dir:
            continue
        run_path = Path(run_dir)
        if not run_path.exists():
            continue
        items.append(
            {
                "model_key": status.get("model_key", candidate.name),
                "status": "success",
                "run_dir": str(run_path),
                "model_dir": str(candidate),
                "plot_path": status.get("plot_path"),
                "manifest_path": str(candidate / MODEL_MANIFEST_FILE),
                "exit_code": 0,
            }
        )
    return items


def _write_session_manifest(benchmark_root: Path, payload: dict) -> None:
    _save_json(benchmark_root / "manifest.json", payload)


def _render_comparison_plot(
    *,
    benchmark_root: Path,
    bo_source_dir: Path,
    venv_python: Path,
    visualization_script: Path,
    successful_items: list[dict],
) -> Path | None:
    if not successful_items:
        return None

    run_dirs = [Path(item["run_dir"]) for item in successful_items]
    labels = [str(item["model_key"]) for item in successful_items]
    save_path = benchmark_root / "comparison_best_so_far.png"
    _render_plot(
        venv_python=venv_python,
        visualization_script=visualization_script,
        run_dirs=run_dirs,
        labels=labels,
        save_path=save_path,
        cwd=bo_source_dir,
    )
    return save_path


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run BO benchmark with managed benchmark virtual environment")
    parser.add_argument("--data_root", required=True, help="Absolute data instance root path (data_<name>)")
    parser.add_argument("--target-column", default=None, help="Column name in *_filtered.csv to optimize")

    parser.add_argument("--kernel-type", choices=["matern", "rbf"], default="matern")
    parser.add_argument("--acquisition-type", choices=["ei", "thompson"], default="ei")
    parser.add_argument("--n-trials", type=int, default=20)
    parser.add_argument("--n-bo-steps", type=int, default=20)
    parser.add_argument("--seed", type=int, default=42)

    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    parser.add_argument("--dtype", choices=["float32", "float64"], default="float32")
    parser.add_argument(
        "--parallel-models",
        type=int,
        default=0,
        help="Model-level parallel workers. 1 disables parallelism, 0 means auto.",
    )

    parser.add_argument("--maximize", action="store_true")
    parser.add_argument("--minimize", action="store_true")
    parser.add_argument("--force-rerun", action="store_true", help="Ignore success sentinel and rerun all cases")
    parser.add_argument("--visualize-only", action="store_true", help="Only regenerate comparison plot from successful cases")

    args = parser.parse_args()

    if args.maximize and args.minimize:
        parser.error("Use only one of --maximize or --minimize.")

    if not args.visualize_only:
        if not args.target_column or not str(args.target_column).strip():
            parser.error("--target-column is required unless --visualize-only is set.")

    if args.n_trials < 1:
        parser.error("--n-trials must be >= 1")
    if args.n_bo_steps < 1:
        parser.error("--n-bo-steps must be >= 1")

    return args


def main() -> int:
    args = _parse_args()

    data_root = Path(args.data_root).resolve()
    if not data_root.exists() or not data_root.is_dir():
        raise FileNotFoundError(f"Data root directory does not exist: {data_root}")
    if not (data_root / DATA_SENTINEL).exists():
        raise RuntimeError(f"Invalid data instance (missing {DATA_SENTINEL}): {data_root}")

    benchmark_root = data_root / "data" / "benchmarks" / BENCHMARK_NAME
    embeddings_root = data_root / "data" / "embeddings"
    venv_dir = benchmark_root / ".venv"

    bo_source_dir = Path(__file__).resolve().parent
    bo_main_script = bo_source_dir / "main.py"
    visualization_script = bo_source_dir / "visualization.py"
    requirements_path = bo_source_dir / "requirements.txt"

    benchmark_root.mkdir(parents=True, exist_ok=True)
    embeddings_root.mkdir(parents=True, exist_ok=True)

    if not bo_main_script.exists():
        raise FileNotFoundError(f"BO main script not found: {bo_main_script}")
    if not visualization_script.exists():
        raise FileNotFoundError(f"BO visualization script not found: {visualization_script}")
    if not requirements_path.exists():
        raise FileNotFoundError(f"BO requirements file not found: {requirements_path}")

    created_at = datetime.now(timezone.utc).isoformat()
    run_meta = {
        "format": "morehub-bo-run",
        "version": 1,
        "created_at": created_at,
        "status": "running",
        "mode": "visualize_only" if args.visualize_only else "run",
        "data_root": str(data_root),
        "benchmark_root": str(benchmark_root),
    }
    _save_json(benchmark_root / RUN_META_FILE, run_meta)

    _log(f"[BO] Data root: {data_root}")
    _log(f"[BO] Benchmark root: {benchmark_root}")

    venv_python = _ensure_venv(venv_dir)
    _ensure_dependencies(venv_python, requirements_path, benchmark_root / DEPS_STATE_FILE)

    try:
        resolved_device = _resolve_device(args.device, venv_python, bo_source_dir)
    except RuntimeError as exc:
        run_meta.update(
            {
                "status": "failed",
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "error": str(exc),
            }
        )
        _save_json(benchmark_root / RUN_META_FILE, run_meta)
        _log(f"[BO] {exc}")
        return 1

    _log(f"[BO] Device request: {args.device} -> using {resolved_device}")
    _log(f"[BO] DType: {args.dtype}")

    maximize = True if not args.minimize else False
    if args.maximize:
        maximize = True

    if args.visualize_only:
        existing_items = _existing_successes_from_status(benchmark_root)
        if not existing_items:
            raise RuntimeError("No successful BO runs found to visualize.")

        comparison_plot = _render_comparison_plot(
            benchmark_root=benchmark_root,
            bo_source_dir=bo_source_dir,
            venv_python=venv_python,
            visualization_script=visualization_script,
            successful_items=existing_items,
        )

        run_meta.update(
            {
                "status": "success",
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "summary": {
                    "total": len(existing_items),
                    "successes": len(existing_items),
                    "failures": 0,
                    "skipped": 0,
                },
                "items": existing_items,
                "comparison_plot": str(comparison_plot) if comparison_plot else None,
            }
        )
        _save_json(benchmark_root / RUN_META_FILE, run_meta)
        if comparison_plot is not None:
            _log(f"[BO] Comparison plot saved to: {comparison_plot}")
        _log("[BO] Visualization completed successfully.")
        return 0

    cases = _discover_embedding_cases(embeddings_root)
    if not cases:
        raise RuntimeError(
            "No valid BO inputs found under data/embeddings. "
            "Expected pairs of '<stem>.npy' and '<stem>_filtered.csv'."
        )

    _log(f"[BO] Found {len(cases)} model embedding case(s).")

    workers = _resolve_parallel_workers(args.parallel_models, len(cases), resolved_device)
    _log(f"[BO] Parallel model workers: {workers}")

    items: list[dict] = []
    if workers == 1:
        for case in cases:
            items.append(
                _run_case(
                    case=case,
                    args=args,
                    maximize=maximize,
                    resolved_device=resolved_device,
                    bo_source_dir=bo_source_dir,
                    bo_main_script=bo_main_script,
                    visualization_script=visualization_script,
                    venv_python=venv_python,
                    benchmark_root=benchmark_root,
                )
            )
    else:
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            futures = [
                executor.submit(
                    _run_case,
                    case=case,
                    args=args,
                    maximize=maximize,
                    resolved_device=resolved_device,
                    bo_source_dir=bo_source_dir,
                    bo_main_script=bo_main_script,
                    visualization_script=visualization_script,
                    venv_python=venv_python,
                    benchmark_root=benchmark_root,
                )
                for case in cases
            ]
            for future in concurrent.futures.as_completed(futures):
                items.append(future.result())

    items.sort(key=lambda item: str(item.get("model_key", "")))

    failures = len([i for i in items if i.get("status") == "failed"])
    skipped = len([i for i in items if i.get("status") == "skipped"])

    successful_items = _successful_run_items(items)
    comparison_plot = None
    if successful_items:
        try:
            comparison_plot = _render_comparison_plot(
                benchmark_root=benchmark_root,
                bo_source_dir=bo_source_dir,
                venv_python=venv_python,
                visualization_script=visualization_script,
                successful_items=successful_items,
            )
            _log(f"[BO] Comparison plot saved to: {comparison_plot}")
        except Exception as exc:
            _log(f"[BO] Warning: failed to generate comparison plot: {exc}")

    session_manifest = {
        "tool": "bo",
        "created_at": created_at,
        "finished_at": datetime.now(timezone.utc).isoformat(),
        "data_root": str(data_root),
        "benchmark_root": str(benchmark_root),
        "config": {
            **_case_signature(args, maximize, resolved_device),
            "parallel_models": workers,
            "requested_parallel_models": args.parallel_models,
            "requested_device": args.device,
        },
        "summary": {
            "total": len(items),
            "successes": len([i for i in items if i.get("status") == "success"]),
            "skipped": skipped,
            "failures": failures,
        },
        "comparison_plot": str(comparison_plot) if comparison_plot else None,
        "items": items,
    }
    _write_session_manifest(benchmark_root, session_manifest)

    run_meta.update(
        {
            "status": "success" if failures == 0 else "failed",
            "finished_at": datetime.now(timezone.utc).isoformat(),
            "summary": session_manifest["summary"],
            "items": items,
            "comparison_plot": session_manifest["comparison_plot"],
            "execution": {
                "requested_device": args.device,
                "resolved_device": resolved_device,
                "dtype": args.dtype,
                "requested_parallel_models": args.parallel_models,
                "resolved_parallel_models": workers,
            },
        }
    )
    _save_json(benchmark_root / RUN_META_FILE, run_meta)

    if failures == 0:
        _log("[BO] Benchmark run completed successfully.")
        return 0

    _log(f"[BO] Benchmark run completed with failures: {failures}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
