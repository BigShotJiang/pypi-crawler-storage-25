"""Configuration schema for BO-over-embeddings experiments."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(slots=True)
class BOConfig:
    """Runtime configuration for one BO experiment family."""

    embedding_npy_path: str
    targets_csv_path: str
    target_column: str
    output_dir: str = "results"
    surrogate_type: str = "gp"
    kernel_type: str = "matern"
    acquisition_type: str = "ei"
    n_trials: int = 20
    n_bo_steps: int = 20
    init_fraction: float = 0.05
    init_count: int | None = None
    maximize: bool = True
    random_seed: int = 42
    dtype: str = "float64"
    device: str = "cpu"
    standardize_y: bool = True

    def __post_init__(self) -> None:
        """Normalize string fields and validate constraints."""
        self.surrogate_type = self.surrogate_type.lower()
        self.kernel_type = self.kernel_type.lower()
        self.acquisition_type = self.acquisition_type.lower()
        self.dtype = self.dtype.lower()
        self.target_column = self.target_column.strip()

        if not self.embedding_npy_path.lower().endswith(".npy"):
            raise ValueError("embedding_npy_path must point to a .npy file")
        if not self.targets_csv_path.lower().endswith(".csv"):
            raise ValueError("targets_csv_path must point to a .csv file")
        if not self.target_column:
            raise ValueError("target_column must be provided")

        if self.n_trials < 1:
            raise ValueError("n_trials must be >= 1")
        if self.n_bo_steps < 1:
            raise ValueError("n_bo_steps must be >= 1")
        if self.init_count is not None and self.init_count < 1:
            raise ValueError("init_count must be >= 1 when provided")
        if not (0.0 < self.init_fraction <= 1.0):
            raise ValueError("init_fraction must be in (0, 1]")
        if self.dtype not in {"float32", "float64"}:
            raise ValueError("dtype must be 'float32' or 'float64'")

    def resolved_init_count(self, n_samples: int) -> int:
        """Return initialization set size from `init_count` or `init_fraction`."""
        if n_samples < 1:
            raise ValueError("n_samples must be >= 1")
        if self.init_count is not None:
            n_init = self.init_count
        else:
            n_init = int(self.init_fraction * n_samples)
        return max(1, min(n_samples, n_init))

    def to_dict(self) -> dict[str, Any]:
        """Serialize config to a plain dictionary."""
        return asdict(self)
