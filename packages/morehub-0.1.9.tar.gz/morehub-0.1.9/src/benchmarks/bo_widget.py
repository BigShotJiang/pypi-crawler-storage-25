﻿from __future__ import annotations

import html
import sys
from pathlib import Path

from PySide6.QtCore import QProcess, Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QFileDialog, QMessageBox, QPushButton, QWidget

from benchmarks.BO.ui.bo_ui import Ui_Form

DATA_SENTINEL = ".morehub_data.json"
BENCHMARK_NAME = "BO"


class BOWidget(QWidget):
    """GUI controller for BO benchmark execution."""

    def __init__(
        self,
        workspace_provider,
        data_root_provider,
        data_root_setter,
        package_root: Path,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.ui = Ui_Form()
        self.ui.setupUi(self)

        self._workspace_provider = workspace_provider
        self._data_root_provider = data_root_provider
        self._data_root_setter = data_root_setter
        self._package_root = package_root
        self._process: QProcess | None = None

        self._configure_ui()
        self._bind_controls()
        self.refresh_workspace_state()

    def _configure_ui(self) -> None:
        self.setWindowTitle("Bayesian Optimization")

        if not self.ui.radioButton_8.isChecked() and not self.ui.radioButton_9.isChecked():
            self.ui.radioButton_8.setChecked(True)

        if not self.ui.radioButton_10.isChecked() and not self.ui.radioButton_11.isChecked():
            self.ui.radioButton_10.setChecked(True)

        if not self.ui.radioButton_14.isChecked() and not self.ui.radioButton_15.isChecked():
            self.ui.radioButton_14.setChecked(True)

        self.ui.spinBox.setMinimum(1)
        self.ui.spinBox_2.setMinimum(1)

        self.ui.model_installed_4.setText("Environment ready")
        self.ui.model_installed_4.setEnabled(True)
        self.ui.model_installed_4.setCheckable(True)
        self.ui.model_installed_4.setFocusPolicy(Qt.NoFocus)
        self.ui.model_installed_4.setAttribute(Qt.WA_TransparentForMouseEvents, True)

        icons_dir = self._package_root / "ui" / "icons"
        if not icons_dir.exists():
            icons_dir = self._package_root / "benchmarks" / "GP_regressor" / "ui" / "icons"

        run_icon = QIcon(str(icons_dir / "run.png"))
        folder_icon = QIcon(str(icons_dir / "folder.png"))
        self.ui.pushButton_6.setIcon(run_icon)
        visualize_button = self._visualization_button()
        if visualize_button is not None:
            visualize_button.setIcon(run_icon)
        if hasattr(self.ui, "pushButton_47"):
            self.ui.pushButton_47.setIcon(folder_icon)

        if hasattr(self.ui, "label_149"):
            self.ui.label_149.setText("No data selected")
            self.ui.label_149.setToolTip("")

        if hasattr(self.ui, "checkBox"):
            self.ui.checkBox.setToolTip("Use CUDA. If unavailable, this run fails and you can uncheck it to retry.")
        if hasattr(self.ui, "checkBox_2"):
            self.ui.checkBox_2.setToolTip("Run model cases in parallel when CPU is selected.")

        self.ui.textEdit_3.clear()

    def _bind_controls(self) -> None:
        self.ui.pushButton_6.clicked.connect(self._on_run_clicked)
        visualize_button = self._visualization_button()
        if visualize_button is not None:
            visualize_button.clicked.connect(self._on_visualization_clicked)
        if hasattr(self.ui, "pushButton_47"):
            self.ui.pushButton_47.clicked.connect(self._on_select_data_folder)

    def _visualization_button(self) -> QPushButton | None:
        if hasattr(self.ui, "pushButton_8"):
            return self.ui.pushButton_8
        if hasattr(self.ui, "pushButton_7"):
            return self.ui.pushButton_7
        return None

    def _workspace_root(self) -> Path | None:
        workspace = self._workspace_provider()
        if workspace is None:
            return None
        return Path(workspace)

    def _default_root_dir(self) -> Path:
        workspace = self._workspace_root()
        if workspace is None:
            return Path.home()
        return workspace

    def _is_data_instance(self, data_root: Path) -> bool:
        return (data_root / DATA_SENTINEL).exists()

    def _find_data_root(self, start_path: Path) -> Path | None:
        path = start_path.resolve()
        for candidate in [path, *path.parents]:
            if (candidate / DATA_SENTINEL).exists():
                return candidate
        return None

    def _resolve_data_root_from_path(self, selected_path: Path | None) -> Path | None:
        if selected_path is None:
            return None
        data_root = self._find_data_root(selected_path)
        if data_root is None or not self._is_data_instance(data_root):
            return None
        return data_root

    def _active_data_root(self) -> Path | None:
        selected = self._data_root_provider()
        if selected is None:
            return None

        data_root = Path(selected).resolve()
        if not self._is_data_instance(data_root):
            return None
        return data_root

    def _update_data_label(self, data_root: Path | None) -> None:
        label = getattr(self.ui, "label_149", None)
        if label is None:
            return

        if data_root is None:
            label.setText("No data selected")
            label.setToolTip("")
            return

        label.setText(data_root.name)
        label.setToolTip(str(data_root))

    def refresh_workspace_state(self) -> None:
        data_root = self._active_data_root()
        self._update_data_label(data_root)

        if data_root is None:
            self.ui.model_installed_4.setChecked(False)
            return

        benchmark_root = data_root / "data" / "benchmarks" / BENCHMARK_NAME
        venv_python = benchmark_root / ".venv" / ("Scripts" if sys.platform.startswith("win") else "bin") / (
            "python.exe" if sys.platform.startswith("win") else "python"
        )
        self.ui.model_installed_4.setChecked(venv_python.exists())

    def _set_inputs_enabled(self, enabled: bool) -> None:
        self.ui.pushButton_6.setEnabled(enabled)
        visualize_button = self._visualization_button()
        if visualize_button is not None:
            visualize_button.setEnabled(enabled)
        if hasattr(self.ui, "pushButton_47"):
            self.ui.pushButton_47.setEnabled(enabled)

    def _log_color_for_line(self, line: str) -> str | None:
        normalized = line.strip().lower()
        if "completed successfully" in normalized:
            return "#1b8f3a"
        if "failed" in normalized or "error" in normalized or "traceback" in normalized:
            return "#b3261e"
        return None

    def _append_log(self, text: str) -> None:
        stripped = text.rstrip()
        for line in stripped.splitlines() or [stripped]:
            safe_line = html.escape(line)
            color = self._log_color_for_line(line) or "#000000"
            self.ui.textEdit_3.append(f"<span style=\"color: {color};\">{safe_line}</span>")

    def _selected_kernel(self) -> str:
        if self.ui.radioButton_8.isChecked():
            return "matern"
        if self.ui.radioButton_9.isChecked():
            return "rbf"
        self._append_log("[BO] No kernel selected. Defaulting to matern.")
        return "matern"

    def _selected_acquisition(self) -> str:
        if self.ui.radioButton_10.isChecked():
            return "ei"
        if self.ui.radioButton_11.isChecked():
            return "thompson"
        self._append_log("[BO] No acquisition selected. Defaulting to ei.")
        return "ei"

    def _selected_direction_flag(self) -> str:
        if self.ui.radioButton_15.isChecked():
            return "--minimize"
        return "--maximize"

    def _target_column(self) -> str:
        return self.ui.lineEdit.text().strip()

    def _selected_parallel_models(self) -> int:
        checkbox = getattr(self.ui, "checkBox_2", None)
        if checkbox is not None and checkbox.isChecked():
            return 0
        return 1

    def _selected_device(self) -> str:
        checkbox = getattr(self.ui, "checkBox", None)
        if checkbox is not None and checkbox.isChecked():
            return "cuda"
        return "cpu"

    def _build_launcher_args(self, *, visualize_only: bool) -> list[str]:
        launcher = self._package_root / "benchmarks" / "BO" / "launcher.py"
        if not launcher.exists():
            raise FileNotFoundError(f"BO launcher script not found at {launcher}")

        data_root = self._active_data_root()
        if data_root is None:
            raise RuntimeError(
                "No data folder selected. Select a data_<name> folder first using the folder button."
            )

        args = [
            str(launcher),
            "--data_root",
            str(data_root),
        ]

        if visualize_only:
            args.append("--visualize-only")
            return args

        target_column = self._target_column()
        if not target_column:
            raise RuntimeError("Target column is required.")

        args.extend(
            [
                "--target-column",
                target_column,
                "--kernel-type",
                self._selected_kernel(),
                "--acquisition-type",
                self._selected_acquisition(),
                "--n-trials",
                str(max(1, int(self.ui.spinBox.value()))),
                "--n-bo-steps",
                str(max(1, int(self.ui.spinBox_2.value()))),
                "--seed",
                "42",
                "--parallel-models",
                str(self._selected_parallel_models()),
                "--device",
                self._selected_device(),
                "--dtype",
                "float32",
                self._selected_direction_flag(),
            ]
        )
        return args

    def _start_process(self, args: list[str], start_message: str) -> None:
        if self._process is not None:
            self._append_log("[BO] A benchmark process is already running.")
            return

        process = QProcess(self)
        process.setProgram(sys.executable)
        process.setArguments(args)
        process.setWorkingDirectory(str(self._package_root / "benchmarks" / "BO"))
        process.setProcessChannelMode(QProcess.SeparateChannels)

        process.readyReadStandardOutput.connect(
            lambda p=process: self._append_log(bytes(p.readAllStandardOutput()).decode(errors="replace"))
        )
        process.readyReadStandardError.connect(
            lambda p=process: self._append_log(bytes(p.readAllStandardError()).decode(errors="replace"))
        )
        process.finished.connect(self._on_process_finished)

        self._process = process
        self._set_inputs_enabled(False)
        self._append_log(start_message)
        self._append_log(f"[BO] Running: {sys.executable} {' '.join(args)}")
        process.start()

    def _on_select_data_folder(self) -> None:
        selected_dir = QFileDialog.getExistingDirectory(
            self,
            "Select data folder",
            str(self._default_root_dir()),
        )
        if not selected_dir:
            return

        selected_path = Path(selected_dir).resolve()
        data_root = self._resolve_data_root_from_path(selected_path)
        if data_root is None:
            QMessageBox.warning(
                self,
                "Invalid Data Folder",
                "Select a valid data instance folder (data_<name>) that contains .morehub_data.json.",
            )
            self._append_log(f"[BO] Invalid data folder: {selected_path}")
            return

        if self._data_root_setter is None:
            QMessageBox.warning(
                self,
                "Data Selection Unavailable",
                "The BO widget is not connected to app-level data selection.",
            )
            return

        self._data_root_setter(data_root)
        self._append_log(f"[BO] Data selected for models + benchmarks: {data_root}")
        self.refresh_workspace_state()

    def _on_run_clicked(self) -> None:
        try:
            if self._selected_device() == "cuda":
                self._append_log(
                    "[BO] CUDA requested. If unavailable in benchmark venv, the run will stop. "
                    "Uncheck 'Use Cuda' and run again to use CPU."
                )
            args = self._build_launcher_args(visualize_only=False)
            self._start_process(args, "[BO] Starting BO benchmark run...")
        except Exception as exc:
            QMessageBox.warning(self, "Bayesian Optimization", str(exc))
            self._append_log(f"[BO] {exc}")

    def _on_visualization_clicked(self) -> None:
        try:
            args = self._build_launcher_args(visualize_only=True)
            self._start_process(args, "[BO] Building BO comparison visualization...")
        except Exception as exc:
            QMessageBox.warning(self, "Bayesian Optimization", str(exc))
            self._append_log(f"[BO] {exc}")

    def _on_process_finished(self, exit_code: int, _status) -> None:
        self._set_inputs_enabled(True)
        self._process = None

        if exit_code == 0:
            self._append_log("[BO] Process completed successfully.")
        else:
            self._append_log(f"[BO] Process failed with exit code {exit_code}.")

        self.refresh_workspace_state()

