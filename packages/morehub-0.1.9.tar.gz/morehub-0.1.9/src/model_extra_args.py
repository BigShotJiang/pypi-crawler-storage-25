﻿from __future__ import annotations

"""Model-specific extra argument resolution for embeddings execution.

This module owns **additional** runtime flags appended to model `embeddings.py`
commands. Common I/O flags are intentionally owned by `runner.py`.

Scope of this module:
- model-specific CLI extras (for example `--variant`, `--use-atoms`)
- model-specific fallback/default decisions and notice messages
- derivation of a stable `version_tag` used by output naming/foldering

Non-scope:
- shared I/O arguments (`--file`, `--output-dir`, `--output-stem`, etc.)
- process execution orchestration
"""

from dataclasses import dataclass
import re
from typing import Any, Mapping


@dataclass(frozen=True)
class RuntimeArgsResult:
    """Resolved extra-argument payload for one model execution.

    Fields:
    - `extra_args`: additional CLI args appended by the app.
    - `version_tag`: semantic model configuration tag for output naming.
    - `notices`: informational fallback/default messages for UI logging.
    """

    extra_args: list[str]
    version_tag: str | None
    notices: list[str]


def _extract_variant_arg(extra_args: list[str]) -> str | None:
    """Extract the value of `--variant` from an args list, if present."""
    for index, token in enumerate(extra_args):
        if token == "--variant" and (index + 1) < len(extra_args):
            value = str(extra_args[index + 1]).strip()
            return value or None
    return None


def normalize_output_token(value: str) -> str:
    """Normalize a token so it is filesystem-safe and deterministic."""
    token = re.sub(r"[^A-Za-z0-9]+", "_", str(value)).strip("_")
    return token or "default"


def build_embeddings_output_stem(model_name: str, version_tag: str | None) -> str:
    """Build canonical output stem: `embeddings_<MODEL>[_<VERSION>]`."""
    parts = ["embeddings", model_name.upper()]
    if version_tag:
        parts.append(version_tag)
    return "_".join(normalize_output_token(part) for part in parts if part)


# ---------------------------------------------------------------------------
# Per-model extra-argument builders (explicit model structure)
# ---------------------------------------------------------------------------


def _build_clamp_args(_ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build CLAMP extra args.

    Current behavior: no model-specific extra flags are appended by the GUI.
    """
    return [], []


def _build_molbert_args(_ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build MOLBERT extra args.

    Current behavior: no model-specific extra flags are appended by the GUI.
    """
    return [], []


def _build_grover_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build GROVER extra args from UI controls.

    Uses:
    - variant: `base|large`
    - optional flags: `--use-atoms`, `--use-bonds`
    """
    use_large = bool(ui_state.get("grover_use_large", False))
    use_atoms = bool(ui_state.get("grover_use_atoms", False))
    use_bonds = bool(ui_state.get("grover_use_bonds", False))

    args = ["--variant", "large" if use_large else "base"]
    notices: list[str] = []
    if use_atoms:
        args.append("--use-atoms")
    if use_bonds:
        args.append("--use-bonds")
    if not use_atoms and not use_bonds:
        args.append("--use-atoms")
        notices.append("[GROVER] Neither atoms nor bonds selected; defaulting to atoms.")
    return args, notices


def _build_mat_args(_ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build MAT extra args.

    Current behavior: no model-specific extra flags are appended by the GUI.
    """
    return [], []


def _build_rmat_args(_ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build RMAT extra args.

    Current behavior: no model-specific extra flags are appended by the GUI.
    """
    return [], []


def _build_selfiested_args(_ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build SELFIESTED extra args for debugging behavior overrides.

    Current debug policy:
    - force no normalization
    - force mean pooling (no CLS)
    - cap max sequence length to 128
    """
    return ["--no-normalize", "--no-cls", "--max-length", "128"], []


def _build_variant_args(
    model_name: str,
    selected_variant: str | None,
    default_variant: str,
    fallback_notice: str,
) -> tuple[list[str], list[str]]:
    """Generic helper for models controlled by one `--variant` option."""
    if selected_variant:
        return ["--variant", selected_variant], []
    return ["--variant", default_variant], [f"[{model_name}] {fallback_notice}"]


def _build_chemberta_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build ChemBERTa variant args from UI state."""
    return _build_variant_args(
        model_name="CHEMBERTA",
        selected_variant=ui_state.get("chemberta_variant"),
        default_variant="zinc-base-v1",
        fallback_notice="No variant selected; defaulting to zinc-base-v1.",
    )


def _build_graphormer_args(_ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build GRAPHORMER extra args.

    Current behavior: no model-specific extra flags are appended by the GUI.
    """
    return [], []


def _build_graphfp_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build GraphFP variant args from UI state."""
    return _build_variant_args(
        model_name="GRAPHFP",
        selected_variant=ui_state.get("graphfp_variant"),
        default_variant="gin_cp",
        fallback_notice="No variant selected; defaulting to gin_cp.",
    )


def _build_coati_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build COATI variant args from UI state."""
    return _build_variant_args(
        model_name="COATI",
        selected_variant=ui_state.get("coati_variant"),
        default_variant="grande_closed",
        fallback_notice="No variant selected; defaulting to grande_closed.",
    )


def _build_coulomb_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build Coulomb representation args from UI state."""
    return _build_variant_args(
        model_name="COULOMB",
        selected_variant=ui_state.get("coulomb_variant"),
        default_variant="bob",
        fallback_notice="No representation selected; defaulting to bags of bonds.",
    )


def _build_morgan_args(_ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build MORGAN extra args.

    Current behavior: no model-specific extra flags are appended by the GUI.
    """
    return [], []

def _build_gem_args(_ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build GEM extra args.

    Current behavior: no model-specific extra flags are appended by the GUI.
    """
    return [], []

def _build_simson_args(_ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build SimSon extra args.

    Current behavior: no model-specific extra flags are appended by the GUI.
    """
    return [], []


def _build_chemfm_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build ChemFM variant args from UI state."""
    return _build_variant_args(
        model_name="CHEMFM",
        selected_variant=ui_state.get("chemfm_variant"),
        default_variant="chemfm-1b",
        fallback_notice="No variant selected; defaulting to ChemFM-1B.",
    )


def _build_chemgpt_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build ChemGPT variant args from UI state."""
    return _build_variant_args(
        model_name="CHEMGPT",
        selected_variant=ui_state.get("chemgpt_variant"),
        default_variant="chemgpt-1.2b",
        fallback_notice="No variant selected; defaulting to ChemGPT-1.2B.",
    )


def _build_selfformer_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build SelFormer variant args from UI state."""
    return _build_variant_args(
        model_name="SELFORMER",
        selected_variant=ui_state.get("selfformer_variant"),
        default_variant="selformer-lite",
        fallback_notice="No variant selected; defaulting to SELFormer-Lite.",
    )


def _build_chemformer_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build ChemFormer checkpoint and optional embedding-readout args from UI state.

    Supports optional passthrough keys:
    - `chemformer_pooling`: `auto|mean|task_token`
    - `chemformer_task_token`: task token string for discriminative readout

    Default behavior keeps task-token resolution inside CHEMFORMER/embeddings.py,
    which performs variant-aware discovery and strict validation.
    """
    args, notices = _build_variant_args(
        model_name="CHEMFORMER",
        selected_variant=ui_state.get("chemformer_variant"),
        default_variant="pretrained/combined",
        fallback_notice="No variant selected; defaulting to pretrained/combined.",
    )

    pooling = str(ui_state.get("chemformer_pooling", "")).strip().lower()
    if pooling in {"auto", "mean", "task_token"}:
        args.extend(["--pooling", pooling])

    task_token = ui_state.get("chemformer_task_token")
    if task_token is not None:
        task_token_text = str(task_token).strip()
        if task_token_text:
            args.extend(["--task-token", task_token_text])

    if pooling == "task_token" and not any(token == "--task-token" for token in args):
        notices.append(
            "[CHEMFORMER] pooling=task_token requested without a token; embeddings script will require an explicit token or variant auto-resolution."
        )

    return args, notices
def _build_novomolgen_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build NovoMolGen variant args from UI state."""
    return _build_variant_args(
        model_name="NOVOMOLGEN",
        selected_variant=ui_state.get("novomolgen_variant"),
        default_variant="32m-atomwise",
        fallback_notice="No variant selected; defaulting to 32m-atomwise.",
    )


def _build_molformer_args(_ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build MOLFORMER extra args.

    Current behavior: no model-specific extra flags are appended by the GUI.
    """
    return [], []


def _build_molgen_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build MolGen variant args from UI state."""
    return _build_variant_args(
        model_name="MOLGEN",
        selected_variant=ui_state.get("molgen_variant"),
        default_variant="7b",
        fallback_notice="No variant selected; defaulting to 7b.",
    )


def _build_molclr_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build MolCLR backbone args from UI state.

    Preserves historical fallback behavior:
    - both selected -> default to GIN
    - none selected -> default to GCN
    """
    use_gin = bool(ui_state.get("molclr_use_gin", False))
    use_gcn = bool(ui_state.get("molclr_use_gcn", False))

    if use_gin and use_gcn:
        return ["--variant", "gin"], ["[MOLCLR] Both GIN and GCN selected; defaulting to GIN."]
    if use_gin:
        return ["--variant", "gin"], []
    if use_gcn:
        return ["--variant", "gcn"], []
    return ["--variant", "gcn"], ["[MOLCLR] No backbone selected; defaulting to GCN."]


def _build_molr_args(ui_state: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    """Build MolR backbone args from UI state."""
    return _build_variant_args(
        model_name="MOLR",
        selected_variant=ui_state.get("molr_variant"),
        default_variant="gcn_1024",
        fallback_notice="No variant selected; defaulting to gcn_1024.",
    )


def _build_embeddings_version_tag(model_name: str, extra_args: list[str]) -> str | None:
    """Derive a semantic version tag from resolved extra args."""
    upper = model_name.upper()

    if upper == "GROVER":
        variant = _extract_variant_arg(extra_args) or "base"
        use_atoms = "--use-atoms" in extra_args
        use_bonds = "--use-bonds" in extra_args
        if use_atoms and use_bonds:
            mode = "atomsBonds"
        elif use_atoms:
            mode = "atoms"
        elif use_bonds:
            mode = "bonds"
        else:
            mode = "atoms"
        return f"{variant}_{mode}"

    if upper == "NOVOMOLGEN":
        variant = (_extract_variant_arg(extra_args) or "").lower()
        variant_map = {
            "32m-atomwise": "NovoMolGen_32M_SMILES_AtomWise",
            "157m-atomwise": "NovoMolGen_157M_SMILES_AtomWise",
            "300m-atomwise": "NovoMolGen_300M_SMILES_AtomWise",
            "32m-bpe": "NovoMolGen_32M_SMILES_BPE",
            "157m-bpe": "NovoMolGen_157M_SMILES_BPE",
            "300m-bpe": "NovoMolGen_300M_SMILES_BPE",
        }
        if variant in variant_map:
            return variant_map[variant]
        return variant or None

    return _extract_variant_arg(extra_args)


def build_model_extra_args(model_name: str, ui_state: Mapping[str, Any]) -> RuntimeArgsResult:
    """Build extra args and version tag for one model.

    Parameters:
    - `model_name`: logical model id from app tab.
    - `ui_state`: normalized UI state dictionary.

    Returns:
    - `RuntimeArgsResult` containing extra args, optional version tag, and notices.
    """
    upper = model_name.upper()

    if upper == "CLAMP":
        args, notices = _build_clamp_args(ui_state)
    elif upper == "MOLBERT":
        args, notices = _build_molbert_args(ui_state)
    elif upper == "GROVER":
        args, notices = _build_grover_args(ui_state)
    elif upper == "MAT":
        args, notices = _build_mat_args(ui_state)
    elif upper == "RMAT":
        args, notices = _build_rmat_args(ui_state)
    elif upper == "SELFIESTED":
        args, notices = _build_selfiested_args(ui_state)
    elif upper == "CHEMBERTA":
        args, notices = _build_chemberta_args(ui_state)
    elif upper == "GRAPHORMER":
        args, notices = _build_graphormer_args(ui_state)
    elif upper == "GRAPHFP":
        args, notices = _build_graphfp_args(ui_state)
    elif upper == "COATI":
        args, notices = _build_coati_args(ui_state)
    elif upper == "COULOMB":
        args, notices = _build_coulomb_args(ui_state)
    elif upper == "MORGAN":
        args, notices = _build_morgan_args(ui_state)
    elif upper == "GEM":
        args, notices = _build_gem_args(ui_state)
    elif upper == "SIMSON":
        args, notices = _build_simson_args(ui_state)
    elif upper == "CHEMFM":
        args, notices = _build_chemfm_args(ui_state)
    elif upper == "CHEMGPT":
        args, notices = _build_chemgpt_args(ui_state)
    elif upper == "SELFORMER":
        args, notices = _build_selfformer_args(ui_state)
    elif upper == "CHEMFORMER":
        args, notices = _build_chemformer_args(ui_state)
    elif upper == "NOVOMOLGEN":
        args, notices = _build_novomolgen_args(ui_state)
    elif upper == "MOLFORMER":
        args, notices = _build_molformer_args(ui_state)
    elif upper == "MOLGEN":
        args, notices = _build_molgen_args(ui_state)
    elif upper == "MOLCLR":
        args, notices = _build_molclr_args(ui_state)
    elif upper == "MOLR":
        args, notices = _build_molr_args(ui_state)
    else:
        args, notices = [], []

    version_tag = _build_embeddings_version_tag(upper, args)
    return RuntimeArgsResult(extra_args=args, version_tag=version_tag, notices=notices)


def build_model_runtime_args(model_name: str, ui_state: Mapping[str, Any]) -> RuntimeArgsResult:
    """Backward-compatible alias for `build_model_extra_args`."""
    return build_model_extra_args(model_name, ui_state)


__all__ = [
    "RuntimeArgsResult",
    "build_embeddings_output_stem",
    "build_model_extra_args",
    "build_model_runtime_args",
    "normalize_output_token",
]


