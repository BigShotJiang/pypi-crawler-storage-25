"""Unit tests for the async-context fallback paths in the widget tag.

The template tag is sync (Django simple_tag), but it gets rendered
inside async views (Daphne / ASGI hosts). Sync ORM calls inside an
async event loop raise ``SynchronousOnlyOperation``; the tag's
``_resolve_request_user`` and ``_safe_session_create`` helpers detect
that and route through ``request.auser()`` and ``session.acreate()``
via an ``async_to_sync`` bridge.

These tests exercise the fallback path with stub objects so the SDK's
test suite never has to spin up an actual ASGI server. Each test
configures Django minimally, builds a fake request, and then asserts
the fallback was hit.

Logging assertions monkey-patch the module-level ``logger.warning``
rather than using ``caplog``. The host project's pytest config (root
``pyproject.toml``) routes log records through a custom handler that
caplog can't always see, so we observe the call directly on the
logger object — which is faster, more deterministic, and doesn't
care about handler topology.
"""

import django
from django.conf import settings
from django.core.exceptions import SynchronousOnlyOperation


def _ensure_django_configured():
    if not settings.configured:
        settings.configure(
            DEBUG=True,
            INSTALLED_APPS=["django.contrib.auth", "django.contrib.contenttypes"],
            DATABASES={
                "default": {
                    "ENGINE": "django.db.backends.sqlite3",
                    "NAME": ":memory:",
                }
            },
            USE_TZ=True,
        )
        django.setup()


_ensure_django_configured()


from agentgraft.django.templatetags import agentgraft as ag_tag  # noqa: E402
from agentgraft.django.templatetags.agentgraft import (  # noqa: E402
    _resolve_request_user,
    _safe_session_create,
    agentgraft_widget,
)
from django.test.utils import override_settings  # noqa: E402


class _LogCapture:
    """Capture every ``logger.warning(fmt, *args)`` call.

    Used as a monkey-patched replacement for ``logger.warning`` so the
    tests can observe what was logged without depending on pytest's
    caplog fixture (which is sensitive to handler topology in the
    enclosing project).
    """

    def __init__(self):
        self.calls: list[str] = []

    def __call__(self, fmt: str, *args, **kwargs):
        try:
            rendered = fmt % args if args else fmt
        except TypeError, ValueError:
            rendered = fmt
        self.calls.append(rendered)

    @property
    def text(self) -> str:
        return "\n".join(self.calls)


# ---------------------------------------------------------------------------
# Stubs
# ---------------------------------------------------------------------------


class _SyncOnlyUserDescriptor:
    """A stand-in for Django's ``SimpleLazyObject`` user wrapper.

    Touching the ``is_authenticated`` attribute raises
    ``SynchronousOnlyOperation`` — the same failure mode the real
    ``LazyObject`` raises when its ``get_user`` resolves a user inside
    an async event loop.
    """

    is_authenticated = property(
        lambda self: (_ for _ in ()).throw(
            SynchronousOnlyOperation("sync orm call inside async context")
        )
    )


class _StubAuthenticatedUser:
    pk = 42
    is_authenticated = True


class _RequestWithSyncOnlyUser:
    """Async-view request: sync access throws, ``auser`` works."""

    def __init__(self, *, async_user=None, async_raises=None):
        self.user = _SyncOnlyUserDescriptor()
        self._async_user = async_user
        self._async_raises = async_raises

    async def auser(self):
        if self._async_raises is not None:
            raise self._async_raises
        return self._async_user


class _RequestWithoutAuser:
    """Async-view request without an ``auser`` method (older Django)."""

    user = _SyncOnlyUserDescriptor()


# ---------------------------------------------------------------------------
# _resolve_request_user
# ---------------------------------------------------------------------------


class TestResolveRequestUser:
    def test_sync_fast_path_returns_authenticated_user(self):
        class SyncRequest:
            user = _StubAuthenticatedUser()

        user, is_auth = _resolve_request_user(SyncRequest())
        assert is_auth is True
        assert user.pk == 42

    def test_async_fallback_routes_through_auser(self):
        request = _RequestWithSyncOnlyUser(async_user=_StubAuthenticatedUser())
        user, is_auth = _resolve_request_user(request)
        assert is_auth is True
        assert user.pk == 42

    def test_async_fallback_anonymous_when_no_auser(self):
        # Older Django (no async user helper) → anonymous fallback,
        # no crash.
        user, is_auth = _resolve_request_user(_RequestWithoutAuser())
        assert user is None
        assert is_auth is False

    def test_async_fallback_logs_and_returns_anonymous_on_runtime_error(self, monkeypatch):
        # An OS-level / runtime error inside auser() must drop the
        # visitor to anonymous AND leave a breadcrumb in the logger.
        capture = _LogCapture()
        monkeypatch.setattr(ag_tag.logger, "warning", capture)
        request = _RequestWithSyncOnlyUser(async_raises=RuntimeError("loop closed"))
        user, is_auth = _resolve_request_user(request)
        assert user is None
        assert is_auth is False
        assert "async user resolution failed" in capture.text

    def test_request_with_no_user_attribute(self):
        class BlankRequest:
            user = None

        user, is_auth = _resolve_request_user(BlankRequest())
        assert user is None
        assert is_auth is False


# ---------------------------------------------------------------------------
# _safe_session_create
# ---------------------------------------------------------------------------


class _SyncSession:
    """Sync-view session — ``create`` succeeds without async."""

    def __init__(self):
        self.created = False

    def create(self):
        self.created = True


class _AsyncOnlySession:
    """Async-view session — ``create`` raises, ``acreate`` succeeds."""

    def __init__(self):
        self.acreated = False

    def create(self):
        raise SynchronousOnlyOperation("sync session create in async context")

    async def acreate(self):
        self.acreated = True


class _AsyncOnlySessionThatExplodes:
    """Async-view session whose acreate also fails."""

    def create(self):
        raise SynchronousOnlyOperation("sync session create in async context")

    async def acreate(self):
        raise OSError("session backend unreachable")


class _OldSession:
    """Older Django session backend without ``acreate``."""

    def create(self):
        raise SynchronousOnlyOperation("sync session create in async context")


class TestSafeSessionCreate:
    def test_sync_path_calls_create(self):
        session = _SyncSession()
        _safe_session_create(session)
        assert session.created is True

    def test_async_fallback_calls_acreate(self):
        session = _AsyncOnlySession()
        _safe_session_create(session)
        assert session.acreated is True

    def test_logs_when_acreate_missing(self, monkeypatch):
        capture = _LogCapture()
        monkeypatch.setattr(ag_tag.logger, "warning", capture)
        _safe_session_create(_OldSession())
        assert "does not expose acreate" in capture.text

    def test_logs_when_acreate_raises(self, monkeypatch):
        capture = _LogCapture()
        monkeypatch.setattr(ag_tag.logger, "warning", capture)
        _safe_session_create(_AsyncOnlySessionThatExplodes())
        assert "async session.acreate() failed" in capture.text


# ---------------------------------------------------------------------------
# agentgraft_widget — missing-key error path (XSS hardening)
# ---------------------------------------------------------------------------


class TestAgentgraftWidgetMissingKeys:
    """The missing-keys error path renders an HTML comment that
    interpolates the ``profile`` argument. A host that mis-wires the
    tag as ``{% agentgraft_widget profile=request.GET.x %}`` could
    flow user input into the comment; without HTML-escaping, a
    payload like ``--><script>alert(1)</script><!--`` would break out
    of the comment and execute.

    These tests use ``override_settings(AGENTGRAFT={})`` as a method-
    level context manager so the helper sees no profile config and
    falls through to the missing-keys path. (The class-decorator form
    of ``override_settings`` only works on ``SimpleTestCase``
    subclasses; we use plain pytest classes here.)
    """

    def test_missing_settings_returns_html_comment(self):
        with override_settings(AGENTGRAFT={}):
            out = agentgraft_widget(context={}, profile="default")
        assert "missing" in out
        assert "api_base" in out
        assert "public_key" in out
        assert "webhook_secret" in out

    def test_profile_with_html_payload_is_escaped(self):
        # The pre-fix bug: a profile name containing ``-->`` would
        # break out of the HTML comment and let an attacker inject
        # arbitrary HTML/JS into the page. The post-fix behaviour:
        # the dangerous chars are HTML-escaped so the comment stays
        # a comment.
        payload = "--><script>alert(1)</script><!--"
        with override_settings(AGENTGRAFT={}):
            out = agentgraft_widget(context={}, profile=payload)
        # The literal payload must NOT appear unescaped in the output.
        assert "<script>" not in out
        # The escaped form should be present.
        assert "&lt;script&gt;" in out
        # The dangerous comment-break sequence must be neutralised.
        # The only ``-->`` in the output is the trailing comment
        # terminator; the payload's ``-->`` must have been escaped.
        assert out.endswith(" -->")
        assert "-->" not in out[:-4]
