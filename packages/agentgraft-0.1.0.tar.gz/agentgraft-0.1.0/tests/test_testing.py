"""Tests for ``agentgraft.testing`` — call_tool, tool_schema, ag_reset fixture."""

from typing import Annotated

import agentgraft as ag
import pytest
from agentgraft import get_registry
from agentgraft.testing import call_tool, tool_schema

# ---------------------------------------------------------------------------
# Helpers — stub user and tools used across tests
# ---------------------------------------------------------------------------


class _User:
    def __init__(self, name: str = "alice"):
        self.name = name


_USER = _User()


# ---------------------------------------------------------------------------
# call_tool
# ---------------------------------------------------------------------------


class TestCallTool:
    def test_callable_injects_user_as_first_arg(self):
        received = {}

        @ag.tool
        def probe(user, x: int) -> int:
            """Probe."""
            received["user"] = user
            received["x"] = x
            return x * 2

        result = call_tool(probe, _USER, x=7)
        assert result == 14
        assert received["user"] is _USER
        assert received["x"] == 7

    def test_callable_with_no_extra_args(self):
        @ag.tool
        def greet(user) -> str:
            """Greet."""
            return f"hello {user.name}"

        assert call_tool(greet, _USER) == "hello alice"

    def test_string_name_looks_up_registered_tool(self):
        @ag.tool
        def by_name(user, value: str) -> str:
            """By name."""
            return value.upper()

        assert call_tool("by_name", _USER, value="hello") == "HELLO"

    def test_string_name_missing_raises_key_error(self):
        with pytest.raises(KeyError, match="ghost"):
            call_tool("ghost", _USER)

    def test_wrong_kwargs_raise_type_error(self):
        @ag.tool
        def strict(user, required_arg: str) -> str:
            """Strict."""
            return required_arg

        with pytest.raises(TypeError):
            call_tool(strict, _USER, wrong_name="oops")

    def test_callable_return_value_is_passed_through(self):
        @ag.tool
        def give_list(user, n: int) -> list:
            """Give list."""
            return list(range(n))

        assert call_tool(give_list, _USER, n=3) == [0, 1, 2]

    def test_tool_exception_propagates_unchanged(self):
        @ag.tool
        def boom(user) -> str:
            """Boom."""
            raise ValueError("on purpose")

        with pytest.raises(ValueError, match="on purpose"):
            call_tool(boom, _USER)


# ---------------------------------------------------------------------------
# tool_schema
# ---------------------------------------------------------------------------


class TestToolSchema:
    def test_returns_parameters_schema_dict(self):
        @ag.tool
        def schema_check(user, query: str, limit: int = 10) -> list:
            """Schema check."""
            return []

        schema = tool_schema(schema_check)
        assert schema["type"] == "object"
        assert "additionalProperties" in schema

    def test_required_fields_correct(self):
        @ag.tool
        def req_check(user, required: str, optional: int = 0) -> None:
            """Req check."""

        schema = tool_schema(req_check)
        assert "required" in schema["required"]
        assert "optional" not in schema["required"]

    def test_property_types_correct(self):
        @ag.tool
        def type_check(user, name: str, count: int, active: bool) -> None:
            """Type check."""

        schema = tool_schema(type_check)
        assert schema["properties"]["name"]["type"] == "string"
        assert schema["properties"]["count"]["type"] == "integer"
        assert schema["properties"]["active"]["type"] == "boolean"

    def test_docstring_description_present(self):
        @ag.tool
        def with_desc(user, order_id: str) -> dict:
            """Fetch order.

            Args:
                order_id: UUID of the order to fetch.
            """
            return {}

        schema = tool_schema(with_desc)
        assert schema["properties"]["order_id"]["description"] == "UUID of the order to fetch."

    def test_ag_param_description_present(self):
        @ag.tool
        def with_param(
            user,
            item_id: Annotated[int, ag.Param("Numeric item ID.")],
        ) -> dict:
            """Fetch item."""
            return {}

        schema = tool_schema(with_param)
        assert schema["properties"]["item_id"]["description"] == "Numeric item ID."

    def test_string_name_looks_up_registered_tool(self):
        @ag.tool
        def named_schema(user, x: float) -> float:
            """Named schema."""
            return x

        schema = tool_schema("named_schema")
        assert schema["properties"]["x"]["type"] == "number"

    def test_string_name_missing_raises_key_error(self):
        with pytest.raises(KeyError, match="no_such_tool"):
            tool_schema("no_such_tool")

    def test_user_param_not_in_schema(self):
        @ag.tool
        def user_excluded(user, value: str) -> str:
            """User excluded."""
            return value

        schema = tool_schema(user_excluded)
        assert "user" not in schema["properties"]


# ---------------------------------------------------------------------------
# ag_reset fixture
# ---------------------------------------------------------------------------


class TestAgResetFixture:
    def test_fixture_clears_tools_before_test(self, ag_reset):
        # Registry should be empty because ag_reset ran before this test.
        assert get_registry().tools == {}

    def test_fixture_allows_fresh_registration(self, ag_reset):
        @ag.tool
        def fresh_tool(user) -> str:
            """Fresh."""
            return "ok"

        assert "fresh_tool" in get_registry().tools

    def test_duplicate_registration_works_across_tests_using_fixture(self, ag_reset):
        # Because ag_reset resets between tests, this tool can be
        # re-registered without triggering the "already registered" guard
        # even if another test registered it earlier.
        @ag.tool
        def reusable(user) -> int:
            """Reusable."""
            return 1

        assert "reusable" in get_registry().tools

    def test_same_tool_name_second_test(self, ag_reset):
        # Second test registering the same name as the previous one — would
        # fail with ValueError if ag_reset didn't wipe the registry.
        @ag.tool
        def reusable(user) -> int:  # noqa: F811
            """Reusable."""
            return 2

        assert "reusable" in get_registry().tools
