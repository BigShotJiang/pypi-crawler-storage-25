"""Unit tests for the stdlib HTTP client (mocked urlopen)."""

import io
import json
import urllib.error
from unittest.mock import patch

import pytest
from agentgraft.client import APIError, Client


class TestClientConstruction:
    def test_requires_api_base(self):
        with pytest.raises(ValueError, match="api_base"):
            Client(api_base="", api_key="x")

    def test_requires_api_key(self):
        with pytest.raises(ValueError, match="api_key"):
            Client(api_base="https://x", api_key="")

    def test_strips_trailing_slash_from_base(self):
        c = Client(api_base="https://x/", api_key="k")
        assert c.api_base == "https://x"


def _fake_response(body: dict, status: int = 200):
    """Build a fake context-manager-style response object for urlopen."""
    payload = json.dumps(body).encode()
    response = io.BytesIO(payload)
    response.read = response.read  # context-manager methods
    response.__enter__ = lambda self: self
    response.__exit__ = lambda self, *a: None
    return response


class TestSyncGraft:
    def test_sends_bearer_token(self):
        captured = {}

        def fake_urlopen(req, timeout=None):
            captured["url"] = req.full_url
            captured["headers"] = dict(req.header_items())
            captured["body"] = req.data
            return _fake_response({"tools": {"added": ["x"]}})

        c = Client(api_base="https://chat.example.com", api_key="sk_live_abc")
        with patch("urllib.request.urlopen", fake_urlopen):
            result = c.sync_graft(
                graft_id="11111111-1111-1111-1111-111111111111", payload={"tools": [], "agents": []}
            )

        assert "11111111-1111-1111-1111-111111111111" in captured["url"]
        # urllib title-cases header keys
        assert captured["headers"].get("Authorization") == "Bearer sk_live_abc"
        assert captured["headers"].get("Content-type") == "application/json"
        assert json.loads(captured["body"]) == {"tools": [], "agents": []}
        assert result == {"tools": {"added": ["x"]}}

    def test_http_4xx_raises_api_error(self):
        def fake_urlopen(req, timeout=None):
            raise urllib.error.HTTPError(
                url=req.full_url,
                code=400,
                msg="Bad Request",
                hdrs={},
                fp=io.BytesIO(b'{"detail": "broken"}'),
            )

        c = Client(api_base="https://x", api_key="k")
        with (
            patch("urllib.request.urlopen", fake_urlopen),
            pytest.raises(APIError) as exc_info,
        ):
            c.sync_graft(graft_id="g", payload={})
        assert exc_info.value.status_code == 400
        assert "broken" in exc_info.value.body

    def test_network_error_raises_api_error(self):
        def fake_urlopen(req, timeout=None):
            raise urllib.error.URLError("connection refused")

        c = Client(api_base="https://x", api_key="k")
        with (
            patch("urllib.request.urlopen", fake_urlopen),
            pytest.raises(APIError) as exc_info,
        ):
            c.sync_graft(graft_id="g", payload={})
        assert exc_info.value.status_code == 0  # network errors get 0
        assert "connection refused" in exc_info.value.body

    def test_socket_timeout_raises_api_error_not_traceback(self):
        # Socket-level timeouts raise the builtin ``TimeoutError``
        # (which urllib does NOT wrap in URLError on Python 3.10+).
        # Without an explicit catch in ``_do_request`` the caller
        # would see a raw traceback instead of the clean APIError
        # envelope every other transport failure uses.
        def fake_urlopen(req, timeout=None):
            raise TimeoutError("the read operation timed out")

        c = Client(api_base="https://x", api_key="k", timeout=5)
        with (
            patch("urllib.request.urlopen", fake_urlopen),
            pytest.raises(APIError) as exc_info,
        ):
            c.sync_graft(graft_id="g", payload={})
        assert exc_info.value.status_code == 0
        assert "timed out" in exc_info.value.body
        assert "5s" in exc_info.value.body
