"""Tests for Client retry/backoff behaviour.

Uses ``unittest.mock.patch`` on ``urllib.request.urlopen`` and
``time.sleep`` so tests run at full speed with no actual I/O.
"""

import io
import json
import urllib.error
from unittest.mock import patch

import pytest
from agentgraft.client import _RETRYABLE_STATUS, APIError, Client

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ok_response(body: dict):
    payload = json.dumps(body).encode()
    resp = io.BytesIO(payload)
    resp.__enter__ = lambda s: s
    resp.__exit__ = lambda s, *a: None
    return resp


def _http_error(code: int, body: str = "server error"):
    return urllib.error.HTTPError(
        url="https://x",
        code=code,
        msg="err",
        hdrs={},
        fp=io.BytesIO(body.encode()),
    )


def _make_client(max_retries: int = 3) -> Client:
    return Client(api_base="https://x", api_key="k", max_retries=max_retries)


# ---------------------------------------------------------------------------
# No-retry path — still works cleanly
# ---------------------------------------------------------------------------


class TestNoRetryPath:
    def test_success_on_first_attempt_no_sleep(self):
        client = _make_client()
        with (
            patch("urllib.request.urlopen", return_value=_ok_response({"ok": True})),
            patch("time.sleep") as mock_sleep,
        ):
            result = client.sync_graft(graft_id="g", payload={})
        assert result == {"ok": True}
        mock_sleep.assert_not_called()

    def test_4xx_raises_immediately_no_retry(self):
        attempts = 0

        def fake_urlopen(req, timeout=None):
            nonlocal attempts
            attempts += 1
            raise _http_error(400, "bad request")

        client = _make_client()
        with (
            patch("urllib.request.urlopen", fake_urlopen),
            patch("time.sleep"),
            pytest.raises(APIError) as exc_info,
        ):
            client.sync_graft(graft_id="g", payload={})

        assert exc_info.value.status_code == 400
        assert attempts == 1  # no retries for 4xx

    def test_401_raises_immediately(self):
        with (
            patch("urllib.request.urlopen", side_effect=_http_error(401)),
            patch("time.sleep"),
            pytest.raises(APIError) as exc_info,
        ):
            _make_client().sync_graft(graft_id="g", payload={})
        assert exc_info.value.status_code == 401

    def test_404_raises_immediately(self):
        with (
            patch("urllib.request.urlopen", side_effect=_http_error(404)),
            patch("time.sleep"),
            pytest.raises(APIError) as exc_info,
        ):
            _make_client().sync_graft(graft_id="g", payload={})
        assert exc_info.value.status_code == 404


# ---------------------------------------------------------------------------
# Retry on transient errors
# ---------------------------------------------------------------------------


class TestRetryOnTransientErrors:
    def test_retries_on_500_then_succeeds(self):
        responses = [_http_error(500), _ok_response({"synced": True})]
        call_count = 0

        def fake_urlopen(req, timeout=None):
            nonlocal call_count
            r = responses[call_count]
            call_count += 1
            if isinstance(r, urllib.error.HTTPError):
                raise r
            return r

        with (
            patch("urllib.request.urlopen", fake_urlopen),
            patch("time.sleep") as mock_sleep,
        ):
            result = _make_client().sync_graft(graft_id="g", payload={})

        assert result == {"synced": True}
        assert call_count == 2
        assert mock_sleep.call_count == 1  # one sleep between attempts

    def test_retries_on_503_then_succeeds(self):
        responses = [_http_error(503), _http_error(503), _ok_response({"ok": True})]
        idx = 0

        def fake(req, timeout=None):
            nonlocal idx
            r = responses[idx]
            idx += 1
            if isinstance(r, urllib.error.HTTPError):
                raise r
            return r

        with (
            patch("urllib.request.urlopen", fake),
            patch("time.sleep") as mock_sleep,
        ):
            result = _make_client().sync_graft(graft_id="g", payload={})

        assert result == {"ok": True}
        assert idx == 3
        assert mock_sleep.call_count == 2

    def test_retries_on_network_error_then_succeeds(self):
        responses = [
            urllib.error.URLError("connection refused"),
            _ok_response({"ok": True}),
        ]
        idx = 0

        def fake(req, timeout=None):
            nonlocal idx
            r = responses[idx]
            idx += 1
            if isinstance(r, Exception):
                raise r
            return r

        with (
            patch("urllib.request.urlopen", fake),
            patch("time.sleep"),
        ):
            result = _make_client().sync_graft(graft_id="g", payload={})

        assert result == {"ok": True}

    def test_retries_on_timeout_then_succeeds(self):
        responses = [TimeoutError("timed out"), _ok_response({"ok": True})]
        idx = 0

        def fake(req, timeout=None):
            nonlocal idx
            r = responses[idx]
            idx += 1
            if isinstance(r, Exception):
                raise r
            return r

        with (
            patch("urllib.request.urlopen", fake),
            patch("time.sleep"),
        ):
            result = _make_client().sync_graft(graft_id="g", payload={})

        assert result == {"ok": True}

    def test_retries_on_429_rate_limit(self):
        responses = [_http_error(429, "rate limited"), _ok_response({"ok": True})]
        idx = 0

        def fake(req, timeout=None):
            nonlocal idx
            r = responses[idx]
            idx += 1
            if isinstance(r, urllib.error.HTTPError):
                raise r
            return r

        with (
            patch("urllib.request.urlopen", fake),
            patch("time.sleep"),
        ):
            result = _make_client().sync_graft(graft_id="g", payload={})

        assert result == {"ok": True}

    def test_all_retryable_status_codes_are_retried(self):
        # Verify the constant is what we expect
        assert frozenset({429, 500, 502, 503, 504}) == _RETRYABLE_STATUS


# ---------------------------------------------------------------------------
# Exhausted retries
# ---------------------------------------------------------------------------


class TestExhaustedRetries:
    def test_raises_after_max_retries_exhausted(self):
        # Create a fresh HTTPError per call — a single instance has a BytesIO
        # fp that is exhausted after the first read, so subsequent retries
        # would see an empty body if we reused the same object.
        with (
            patch(
                "urllib.request.urlopen",
                # List comprehension creates 4 distinct objects, each with
                # its own BytesIO fp — * 4 would share one exhausted instance.
                side_effect=[_http_error(500, "still broken") for _ in range(4)],
            ),
            patch("time.sleep"),
            pytest.raises(APIError) as exc_info,
        ):
            _make_client(max_retries=3).sync_graft(graft_id="g", payload={})

        assert exc_info.value.status_code == 500
        assert "still broken" in exc_info.value.body

    def test_total_attempts_equals_max_retries_plus_one(self):
        attempts = 0

        def fake(req, timeout=None):
            nonlocal attempts
            attempts += 1
            raise _http_error(503)

        with (
            patch("urllib.request.urlopen", fake),
            patch("time.sleep"),
            pytest.raises(APIError),
        ):
            _make_client(max_retries=3).sync_graft(graft_id="g", payload={})

        assert attempts == 4  # 1 initial + 3 retries

    def test_zero_retries_means_single_attempt(self):
        attempts = 0

        def fake(req, timeout=None):
            nonlocal attempts
            attempts += 1
            raise _http_error(500)

        with (
            patch("urllib.request.urlopen", fake),
            patch("time.sleep") as mock_sleep,
            pytest.raises(APIError),
        ):
            _make_client(max_retries=0).sync_graft(graft_id="g", payload={})

        assert attempts == 1
        mock_sleep.assert_not_called()

    def test_network_error_exhausted_raises_api_error(self):
        with (
            patch(
                "urllib.request.urlopen",
                side_effect=urllib.error.URLError("DNS failure"),
            ),
            patch("time.sleep"),
            pytest.raises(APIError) as exc_info,
        ):
            _make_client(max_retries=2).sync_graft(graft_id="g", payload={})

        assert exc_info.value.status_code == 0
        assert "DNS failure" in exc_info.value.body

    def test_timeout_exhausted_raises_api_error(self):
        with (
            patch("urllib.request.urlopen", side_effect=TimeoutError("timed out")),
            patch("time.sleep"),
            pytest.raises(APIError) as exc_info,
        ):
            _make_client(max_retries=1).sync_graft(graft_id="g", payload={})

        assert exc_info.value.status_code == 0
        assert "timed out" in exc_info.value.body


# ---------------------------------------------------------------------------
# Back-off timing
# ---------------------------------------------------------------------------


class TestBackoffTiming:
    def test_sleep_is_called_between_retries_not_before_first(self):
        """First attempt never sleeps; sleep once before each retry."""
        attempts = 0

        def fake(req, timeout=None):
            nonlocal attempts
            attempts += 1
            if attempts < 3:
                raise _http_error(503)
            return _ok_response({"ok": True})

        with (
            patch("urllib.request.urlopen", fake),
            patch("time.sleep") as mock_sleep,
        ):
            _make_client(max_retries=3).sync_graft(graft_id="g", payload={})

        # Two failures → two sleeps before attempts 2 and 3
        assert mock_sleep.call_count == 2
        # Sleep durations are positive
        for c in mock_sleep.call_args_list:
            assert c.args[0] > 0

    def test_second_sleep_is_longer_than_first(self):
        """Back-off is exponential — second delay > first delay."""
        sleep_calls = []

        def fake(req, timeout=None):
            raise _http_error(500)

        with (
            patch("urllib.request.urlopen", fake),
            patch("time.sleep", side_effect=lambda d: sleep_calls.append(d)),
            pytest.raises(APIError),
        ):
            _make_client(max_retries=3).sync_graft(graft_id="g", payload={})

        # 3 retries → 3 sleep calls
        assert len(sleep_calls) == 3
        # Exponential growth: on average each delay doubles, but jitter means
        # we can only assert a monotonic trend on the raw (pre-jitter) values.
        # We test that delay[1] > delay[0] * 0.5 (accounting for ±20% jitter).
        assert sleep_calls[1] > sleep_calls[0] * 0.5
        assert sleep_calls[2] > sleep_calls[1] * 0.5

    def test_max_retries_constructor_arg(self):
        client = Client(api_base="https://x", api_key="k", max_retries=7)
        assert client.max_retries == 7

    def test_default_max_retries_is_three(self):
        client = Client(api_base="https://x", api_key="k")
        assert client.max_retries == 3

    def test_negative_max_retries_raises_value_error(self):
        # max_retries=-1 would produce an empty loop and then
        # `raise None` → confusing TypeError. Must fail at construction.
        with pytest.raises(ValueError, match="max_retries"):
            Client(api_base="https://x", api_key="k", max_retries=-1)
