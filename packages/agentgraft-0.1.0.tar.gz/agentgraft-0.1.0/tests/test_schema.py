"""Unit tests for ``build_parameters_schema``, ``parse_docstring_args``,
and ``strip_args_section``."""

import inspect
import textwrap
from typing import Annotated

import pytest
from agentgraft.schema import (
    Param,
    build_parameters_schema,
    parse_docstring_args,
    strip_args_section,
)


def _params(*specs):
    """Helper: build a list of inspect.Parameter from (name, type, default) tuples."""
    out = []
    for spec in specs:
        name, ann = spec[0], spec[1]
        default = spec[2] if len(spec) > 2 else inspect.Parameter.empty
        out.append(
            inspect.Parameter(
                name,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                annotation=ann,
                default=default,
            )
        )
    return out


# ---------------------------------------------------------------------------
# parse_docstring_args
# ---------------------------------------------------------------------------


class TestParseDocstringArgs:
    # ── Empty / missing inputs ────────────────────────────────────────────

    def test_empty_string_returns_empty_dict(self):
        assert parse_docstring_args("") == {}

    def test_no_args_section_returns_empty_dict(self):
        doc = "Does something useful. No parameter block here."
        assert parse_docstring_args(doc) == {}

    def test_multiline_docstring_without_args_section(self):
        doc = textwrap.dedent("""\
            Summary line.

            More context about the function.
            Another sentence here.
        """)
        assert parse_docstring_args(doc) == {}

    # ── Basic extraction ─────────────────────────────────────────────────

    def test_single_param(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                query: The search query string.
        """)
        assert parse_docstring_args(doc) == {"query": "The search query string."}

    def test_multiple_params(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                query: The search query.
                limit: Max number of results.
                offset: Starting position.
        """)
        result = parse_docstring_args(doc)
        assert result == {
            "query": "The search query.",
            "limit": "Max number of results.",
            "offset": "Starting position.",
        }

    def test_real_function_docstring(self):
        """Test against the exact __doc__ a real function would have."""

        def search(user, query: str, limit: int = 10):
            """Search the database.

            Args:
                query: The search query to run.
                limit: Max results to return.
            """

        result = parse_docstring_args(search.__doc__)
        assert result["query"] == "The search query to run."
        assert result["limit"] == "Max results to return."

    # ── Multi-line descriptions ──────────────────────────────────────────

    def test_two_line_continuation(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                text: A long description that continues
                    on the next line here.
        """)
        result = parse_docstring_args(doc)
        assert result["text"] == "A long description that continues on the next line here."

    def test_three_line_continuation(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                param: First line of the description,
                    second line continues it,
                    and a third line ends it.
        """)
        result = parse_docstring_args(doc)
        assert result["param"] == (
            "First line of the description, second line continues it, and a third line ends it."
        )

    def test_continuation_after_first_param_doesnt_bleed_into_second(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                first: First description spans
                    two lines.
                second: Second description is short.
        """)
        result = parse_docstring_args(doc)
        assert result["first"] == "First description spans two lines."
        assert result["second"] == "Second description is short."

    # ── Type annotations in parens ───────────────────────────────────────

    def test_strips_type_annotation_in_parens(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                name (str): The user's name.
        """)
        assert parse_docstring_args(doc) == {"name": "The user's name."}

    def test_strips_optional_type_annotation(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                limit (int, optional): Max results.
        """)
        assert parse_docstring_args(doc) == {"limit": "Max results."}

    def test_strips_complex_type_annotation(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                ids (list[int]): List of IDs to fetch.
        """)
        assert parse_docstring_args(doc) == {"ids": "List of IDs to fetch."}

    # ── *args / **kwargs stripping ────────────────────────────────────────

    def test_strips_single_asterisk(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                *args: Positional overrides.
        """)
        assert parse_docstring_args(doc) == {"args": "Positional overrides."}

    def test_strips_double_asterisk(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                **kwargs: Keyword overrides.
        """)
        assert parse_docstring_args(doc) == {"kwargs": "Keyword overrides."}

    # ── Header variants ──────────────────────────────────────────────────

    def test_arguments_header(self):
        doc = textwrap.dedent("""\
            Summary.

            Arguments:
                x: The x value.
        """)
        assert parse_docstring_args(doc) == {"x": "The x value."}

    def test_parameters_header(self):
        doc = textwrap.dedent("""\
            Summary.

            Parameters:
                x: The x value.
        """)
        assert parse_docstring_args(doc) == {"x": "The x value."}

    def test_params_header(self):
        doc = textwrap.dedent("""\
            Summary.

            Params:
                x: The x value.
        """)
        assert parse_docstring_args(doc) == {"x": "The x value."}

    def test_header_is_case_insensitive(self):
        doc = textwrap.dedent("""\
            Summary.

            ARGS:
                x: The x value.
        """)
        assert parse_docstring_args(doc) == {"x": "The x value."}

    # ── Blank lines within the block ─────────────────────────────────────

    def test_blank_lines_between_params_are_skipped(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                first: First param.

                second: Second param.
        """)
        result = parse_docstring_args(doc)
        assert result == {"first": "First param.", "second": "Second param."}

    # ── Section terminators ──────────────────────────────────────────────

    def test_stops_at_returns_section(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                x: The input.

            Returns:
                The result.
        """)
        result = parse_docstring_args(doc)
        assert result == {"x": "The input."}
        assert "Returns" not in result

    def test_stops_at_raises_section(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                x: The input.

            Raises:
                ValueError: If x is negative.
        """)
        result = parse_docstring_args(doc)
        assert result == {"x": "The input."}

    def test_stops_at_examples_section(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                x: The input.

            Examples:
                >>> foo(1)
        """)
        result = parse_docstring_args(doc)
        assert result == {"x": "The input."}

    def test_stops_at_de_indent(self):
        # A line with less indentation than param entries ends the block.
        doc = "Summary.\n\nArgs:\n    x: The input.\nSomething else at base level."
        result = parse_docstring_args(doc)
        assert result == {"x": "The input."}

    # ── Edge cases ────────────────────────────────────────────────────────

    def test_empty_args_section_returns_empty(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
        """)
        assert parse_docstring_args(doc) == {}

    def test_param_with_colon_but_no_description_excluded(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                name:
                value: Non-empty description.
        """)
        result = parse_docstring_args(doc)
        # "name" had nothing after the colon → excluded
        assert "name" not in result
        assert result["value"] == "Non-empty description."

    def test_multiple_args_sections_uses_first(self):
        # Only the first Args: block is parsed (unusual but shouldn't crash).
        doc = textwrap.dedent("""\
            Summary.

            Args:
                x: First block x.

            Args:
                y: Second block y.
        """)
        result = parse_docstring_args(doc)
        # First Args: block has x, second block starts a new section-level entry
        # which will look like a new param "Args" — but "Args" ends up in _ARGS_HEADERS
        # and .lower() is "args" which IS in _END_HEADERS? No — _END_HEADERS doesn't
        # contain "args". Let's just verify x is present and no crash.
        assert "x" in result


# ---------------------------------------------------------------------------
# strip_args_section
# ---------------------------------------------------------------------------


class TestStripArgsSection:
    def test_empty_string_returns_empty(self):
        assert strip_args_section("") == ""

    def test_no_args_section_returns_cleandoc(self):
        doc = "    Summary line.\n    More context.\n"
        result = strip_args_section(doc)
        assert result == "Summary line.\nMore context."

    def test_strips_args_section_and_everything_after(self):
        doc = textwrap.dedent("""\
            Summary.

            Args:
                x: The input.
        """)
        assert strip_args_section(doc) == "Summary."

    def test_keeps_paragraphs_before_args(self):
        doc = textwrap.dedent("""\
            Summary line.

            Extended description of the function
            in a second paragraph.

            Args:
                x: The input.
        """)
        result = strip_args_section(doc)
        assert (
            result
            == "Summary line.\n\nExtended description of the function\nin a second paragraph."
        )

    def test_applies_cleandoc_to_result(self):
        # Raw docstring has leading indentation that inspect.cleandoc should strip.
        raw = "\n    Summary.\n\n    More detail.\n\n    Args:\n        x: val.\n    "
        result = strip_args_section(raw)
        assert result == "Summary.\n\nMore detail."

    def test_args_at_start_of_docstring(self):
        doc = textwrap.dedent("""\
            Args:
                x: The input.
        """)
        assert strip_args_section(doc) == ""

    def test_arguments_header_stripped(self):
        doc = textwrap.dedent("""\
            Summary.

            Arguments:
                x: The input.
        """)
        assert strip_args_section(doc) == "Summary."

    def test_real_function_docstring(self):
        def fn(user, x: int) -> None:
            """Do the thing.

            This is the main description.

            Args:
                x: The x value.
            """

        result = strip_args_section(fn.__doc__)
        assert result == "Do the thing.\n\nThis is the main description."


# ---------------------------------------------------------------------------
# build_parameters_schema — docstring_args kwarg
# ---------------------------------------------------------------------------


class TestBuildParametersSchemaDocstringArgs:
    def test_docstring_description_applied_to_param(self):
        params = _params(("query", str))
        schema = build_parameters_schema(params, docstring_args={"query": "The search query."})
        assert schema["properties"]["query"]["description"] == "The search query."

    def test_docstring_description_does_not_apply_to_unlisted_param(self):
        params = _params(("query", str), ("limit", int))
        schema = build_parameters_schema(params, docstring_args={"query": "Search query."})
        assert schema["properties"]["query"]["description"] == "Search query."
        # limit is not in docstring_args → no description key
        assert "description" not in schema["properties"]["limit"]

    def test_ag_param_wins_over_docstring_args(self):
        params = _params(("item_id", Annotated[int, Param("From ag.Param.")]))
        schema = build_parameters_schema(params, docstring_args={"item_id": "From docstring."})
        assert schema["properties"]["item_id"]["description"] == "From ag.Param."

    def test_extra_docstring_args_key_silently_ignored(self):
        # docstring_args may contain a param that was renamed — just ignore it.
        params = _params(("query", str))
        schema = build_parameters_schema(
            params, docstring_args={"query": "Good.", "ghost": "Never used."}
        )
        assert "ghost" not in schema["properties"]
        assert schema["properties"]["query"]["description"] == "Good."

    def test_none_docstring_args_is_safe(self):
        params = _params(("x", int))
        schema = build_parameters_schema(params, docstring_args=None)
        assert "description" not in schema["properties"]["x"]

    def test_type_and_description_both_present(self):
        params = _params(("limit", int, 10))
        schema = build_parameters_schema(params, docstring_args={"limit": "Max results."})
        prop = schema["properties"]["limit"]
        assert prop["type"] == "integer"
        assert prop["description"] == "Max results."


# ---------------------------------------------------------------------------
# build_parameters_schema — existing behaviour (regression)
# ---------------------------------------------------------------------------


class TestBuildParametersSchema:
    def test_empty_params_yields_empty_object_schema(self):
        schema = build_parameters_schema([])
        assert schema == {
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": False,
        }

    def test_primitive_str_int_bool(self):
        schema = build_parameters_schema(_params(("name", str), ("count", int), ("active", bool)))
        assert schema["properties"]["name"] == {"type": "string"}
        assert schema["properties"]["count"] == {"type": "integer"}
        assert schema["properties"]["active"] == {"type": "boolean"}
        assert set(schema["required"]) == {"name", "count", "active"}

    def test_float_maps_to_number(self):
        schema = build_parameters_schema(_params(("price", float)))
        assert schema["properties"]["price"] == {"type": "number"}

    def test_optional_makes_param_non_required(self):
        schema = build_parameters_schema(_params(("limit", int | None)))
        assert schema["properties"]["limit"] == {"type": "integer"}
        assert "limit" not in schema["required"]

    def test_default_makes_param_non_required(self):
        schema = build_parameters_schema(_params(("limit", int, 10)))
        assert "limit" not in schema["required"]

    def test_list_of_str(self):
        schema = build_parameters_schema(_params(("tags", list[str])))
        assert schema["properties"]["tags"] == {
            "type": "array",
            "items": {"type": "string"},
        }

    def test_bare_list(self):
        schema = build_parameters_schema(_params(("items", list)))
        assert schema["properties"]["items"]["type"] == "array"

    def test_dict_maps_to_object(self):
        schema = build_parameters_schema(_params(("meta", dict)))
        assert schema["properties"]["meta"] == {"type": "object"}

    def test_missing_annotation_raises(self):
        with pytest.raises(ValueError, match="missing a type hint"):
            build_parameters_schema(_params(("name", inspect.Parameter.empty)))

    def test_additional_properties_is_false(self):
        schema = build_parameters_schema(_params(("x", int)))
        assert schema["additionalProperties"] is False

    def test_required_order_matches_param_order(self):
        schema = build_parameters_schema(_params(("a", int), ("b", str), ("c", bool)))
        assert schema["required"] == ["a", "b", "c"]
