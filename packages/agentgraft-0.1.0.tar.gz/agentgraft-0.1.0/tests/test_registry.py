"""Unit tests for the in-memory registry."""

import pytest
from agentgraft import (
    AgentRegistration,
    GraftConfig,
    Registry,
    ToolRegistration,
    get_registry,
    reset_registry,
)


class TestRegistry:
    def test_starts_empty(self):
        r = Registry()
        assert r.tools == {}
        assert r.agents == {}
        assert r.user_loader is None
        assert r.graft_config == GraftConfig()

    def test_register_tool_and_lookup(self):
        r = Registry()
        t = ToolRegistration(name="echo", description="d", parameters_schema={}, func=lambda u: u)
        r.register_tool(t)
        assert r.tools["echo"] is t

    def test_duplicate_tool_raises(self):
        r = Registry()
        r.register_tool(
            ToolRegistration(name="x", description="d", parameters_schema={}, func=lambda u: 1)
        )
        with pytest.raises(ValueError, match="already registered"):
            r.register_tool(
                ToolRegistration(name="x", description="d", parameters_schema={}, func=lambda u: 2)
            )

    def test_register_agent_and_lookup(self):
        r = Registry()
        a = AgentRegistration(name="helper", instructions="role")
        r.register_agent(a)
        assert r.agents["helper"] is a

    def test_duplicate_agent_raises(self):
        r = Registry()
        r.register_agent(AgentRegistration(name="x", instructions="r"))
        with pytest.raises(ValueError, match="already registered"):
            r.register_agent(AgentRegistration(name="x", instructions="r"))

    def test_user_loader_set_once(self):
        r = Registry()
        r.set_user_loader(lambda x: x)
        with pytest.raises(ValueError, match="already registered"):
            r.set_user_loader(lambda x: x)

    def test_graft_config_can_be_replaced(self):
        r = Registry()
        r.set_graft_config(GraftConfig(identity="first"))
        r.set_graft_config(GraftConfig(identity="second"))
        assert r.graft_config.identity == "second"

    def test_reset_clears_all_state(self):
        r = Registry()
        r.register_tool(
            ToolRegistration(name="t", description="d", parameters_schema={}, func=lambda u: 1)
        )
        r.register_agent(AgentRegistration(name="a", instructions="r"))
        r.set_user_loader(lambda x: x)
        r.set_graft_config(GraftConfig(identity="x"))
        r.reset()
        assert r.tools == {}
        assert r.agents == {}
        assert r.user_loader is None
        assert r.graft_config == GraftConfig()


class TestGlobalSingleton:
    def test_get_registry_returns_same_instance(self):
        a = get_registry()
        b = get_registry()
        assert a is b

    def test_reset_registry_clears_singleton(self):
        get_registry().register_tool(
            ToolRegistration(name="t", description="d", parameters_schema={}, func=lambda u: 1)
        )
        assert "t" in get_registry().tools
        reset_registry()
        assert get_registry().tools == {}
