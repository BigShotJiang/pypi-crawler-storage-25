"""Tests for multi-profile registries.

Profiles let one Python file declare two (or twenty) independent chat
experiences side by side. The contract these tests pin:

1. Decorators write into the registry named by their ``profile=`` kwarg.
2. Registries are isolated — registering ``"foo"`` in profile A leaves
   profile B's tools dict empty.
3. The same name can be reused across profiles without collision.
4. ``reset_registry()`` with no arg clears every profile; with a name
   clears just that one.
5. ``handle_webhook(..., profile=...)`` dispatches against the right
   registry and uses the right secret.
"""

import hashlib
import hmac
import json

import agentgraft as ag
import pytest
from agentgraft import (
    DEFAULT_PROFILE,
    get_all_profiles,
    get_registry,
    handle_webhook,
    reset_registry,
)
from agentgraft.webhook import WebhookError

# ---------------------------------------------------------------------------
# Decorator → registry plumbing
# ---------------------------------------------------------------------------


class TestProfileDecoration:
    def test_default_profile_is_default_when_kwarg_omitted(self):
        @ag.tool
        def thing(user) -> int:
            """T."""
            return 1

        assert "thing" in get_registry().tools
        assert "thing" in get_registry(DEFAULT_PROFILE).tools

    def test_named_profile_isolates_tools(self):
        @ag.tool
        def in_default(user) -> int:
            """D."""
            return 1

        @ag.tool(profile="public")
        def in_public(user) -> int:
            """P."""
            return 2

        assert "in_default" in get_registry().tools
        assert "in_public" not in get_registry().tools
        assert "in_public" in get_registry("public").tools
        assert "in_default" not in get_registry("public").tools

    def test_same_tool_name_in_two_profiles_does_not_collide(self):
        @ag.tool
        def search(user, query: str) -> list:
            """Default."""
            return []

        @ag.tool(profile="public")
        def search(user, query: str) -> list:  # noqa: F811
            """Public."""
            return []

        assert get_registry().tools["search"].description == "Default."
        assert get_registry("public").tools["search"].description == "Public."

    def test_agent_lands_in_named_profile(self):
        @ag.tool(profile="public")
        def info(user) -> str:
            """I."""
            return "x"

        @ag.agent(profile="public", entry=True, tools=[info])
        def public_concierge():
            """P."""

        assert "public_concierge" in get_registry("public").agents
        assert "public_concierge" not in get_registry().agents

    def test_user_loader_per_profile(self):
        @ag.user_loader
        def load_authed(external_id: str) -> dict:
            return {"kind": "authed", "id": external_id}

        @ag.user_loader(profile="public")
        def load_guest(external_id: str) -> dict:
            return {"kind": "guest", "id": external_id}

        assert get_registry().user_loader("u1") == {"kind": "authed", "id": "u1"}
        assert get_registry("public").user_loader("u1") == {
            "kind": "guest",
            "id": "u1",
        }

    def test_user_loader_collides_within_profile(self):
        @ag.user_loader
        def load(x: str) -> str:
            return x

        with pytest.raises(ValueError, match="already registered"):

            @ag.user_loader
            def load2(x: str) -> str:  # noqa: F811
                return x

    def test_user_loader_does_not_collide_across_profiles(self):
        @ag.user_loader
        def load(x: str) -> str:
            return x

        # Should NOT raise — different profile.
        @ag.user_loader(profile="public")
        def load_public(x: str) -> str:
            return x

    def test_graft_config_per_profile(self):
        ag.graft(name="Default Graft", identity="Authenticated.")
        ag.graft(profile="public", name="Public Graft", identity="Anonymous.")

        assert get_registry().graft_config.name == "Default Graft"
        assert get_registry("public").graft_config.name == "Public Graft"


# ---------------------------------------------------------------------------
# Reset semantics
# ---------------------------------------------------------------------------


class TestResetRegistry:
    def test_reset_with_no_arg_clears_all_profiles(self):
        @ag.tool
        def a(user) -> int:
            """A."""
            return 1

        @ag.tool(profile="public")
        def b(user) -> int:
            """B."""
            return 2

        reset_registry()

        assert get_registry().tools == {}
        assert get_registry("public").tools == {}

    def test_reset_with_profile_name_clears_only_that_one(self):
        @ag.tool
        def a(user) -> int:
            """A."""
            return 1

        @ag.tool(profile="public")
        def b(user) -> int:
            """B."""
            return 2

        reset_registry("public")

        assert "a" in get_registry().tools
        assert get_registry("public").tools == {}


# ---------------------------------------------------------------------------
# get_all_profiles
# ---------------------------------------------------------------------------


class TestGetAllProfiles:
    def test_returns_all_materialised_profiles(self):
        @ag.tool
        def a(user) -> int:
            """A."""
            return 1

        @ag.tool(profile="public")
        def b(user) -> int:
            """B."""
            return 2

        @ag.tool(profile="admin")
        def c(user) -> int:
            """C."""
            return 3

        profiles = get_all_profiles()
        assert set(profiles.keys()) == {"default", "public", "admin"}

    def test_returns_a_copy_not_internal_state(self):
        @ag.tool
        def a(user) -> int:
            """A."""
            return 1

        profiles = get_all_profiles()
        profiles["admin"] = "tampered"
        # Re-fetching should not see the tampering.
        assert "admin" not in get_all_profiles()


# ---------------------------------------------------------------------------
# Webhook dispatch routes by profile
# ---------------------------------------------------------------------------


SECRET_DEFAULT = "whsec_default"
SECRET_PUBLIC = "whsec_public"


def _sign(body: bytes, secret: str) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def _payload(tool: str, **arguments) -> bytes:
    return json.dumps(
        {
            "tool": tool,
            "arguments": arguments,
            "user_external_id": "u1",
        }
    ).encode()


@pytest.fixture
def two_profile_registry():
    @ag.user_loader
    def load_authed(external_id: str) -> dict:
        return {"kind": "authed", "id": external_id}

    @ag.user_loader(profile="public")
    def load_guest(external_id: str) -> dict:
        return {"kind": "guest", "id": external_id}

    @ag.tool
    def list_grafts(user) -> list[str]:
        """List grafts (authed)."""
        return ["graft-1", "graft-2"]

    @ag.tool(profile="public")
    def what_is_agentgraft(user) -> str:
        """Explain AgentGraft."""
        return "An embeddable chat infrastructure for Django apps."


class TestWebhookProfileRouting:
    def test_default_profile_dispatches_default_tools(self, two_profile_registry):
        body = _payload("list_grafts")
        result = handle_webhook(
            body=body,
            signature=_sign(body, SECRET_DEFAULT),
            webhook_secret=SECRET_DEFAULT,
        )
        assert result == {"result": ["graft-1", "graft-2"]}

    def test_public_profile_dispatches_public_tools(self, two_profile_registry):
        body = _payload("what_is_agentgraft")
        result = handle_webhook(
            body=body,
            signature=_sign(body, SECRET_PUBLIC),
            webhook_secret=SECRET_PUBLIC,
            profile="public",
        )
        assert result["result"].startswith("An embeddable")

    def test_default_cannot_see_public_tool(self, two_profile_registry):
        # Calling 'what_is_agentgraft' against the default profile
        # should be a 404 — that tool only exists in public.
        body = _payload("what_is_agentgraft")
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(
                body=body,
                signature=_sign(body, SECRET_DEFAULT),
                webhook_secret=SECRET_DEFAULT,
            )
        assert exc_info.value.status_code == 404

    def test_public_cannot_see_default_tool(self, two_profile_registry):
        body = _payload("list_grafts")
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(
                body=body,
                signature=_sign(body, SECRET_PUBLIC),
                webhook_secret=SECRET_PUBLIC,
                profile="public",
            )
        assert exc_info.value.status_code == 404

    def test_each_profile_uses_its_own_user_loader(self, two_profile_registry):
        body = _payload("list_grafts")
        # Default registry's loader returns kind=authed
        result = handle_webhook(
            body=body,
            signature=_sign(body, SECRET_DEFAULT),
            webhook_secret=SECRET_DEFAULT,
        )

        # We can't directly observe the user object the loader returned,
        # but we can prove isolation by calling the public-profile tool
        # whose return value embeds the user kind.
        @ag.tool(profile="public")
        def echo_user_kind(user) -> str:
            """Echo."""
            return user["kind"]

        body = _payload("echo_user_kind")
        result = handle_webhook(
            body=body,
            signature=_sign(body, SECRET_PUBLIC),
            webhook_secret=SECRET_PUBLIC,
            profile="public",
        )
        assert result == {"result": "guest"}


# ---------------------------------------------------------------------------
# Anonymous-aware loader
# ---------------------------------------------------------------------------


class TestIsAnonymousFlag:
    def test_loader_with_is_anonymous_kwarg_receives_it(self):
        captured = {}

        @ag.user_loader
        def load(external_id: str, *, is_anonymous: bool = False) -> dict:
            captured["external_id"] = external_id
            captured["is_anonymous"] = is_anonymous
            return {"id": external_id}

        @ag.tool
        def t(user) -> str:
            """T."""
            return "ok"

        body = json.dumps(
            {
                "tool": "t",
                "arguments": {},
                "user_external_id": "session:abc",
                "is_anonymous": True,
            }
        ).encode()
        secret = "s"
        handle_webhook(
            body=body,
            signature=_sign(body, secret),
            webhook_secret=secret,
        )
        assert captured == {"external_id": "session:abc", "is_anonymous": True}

    def test_legacy_loader_without_is_anonymous_still_works(self):
        @ag.user_loader
        def load(external_id: str) -> dict:
            return {"id": external_id}

        @ag.tool
        def t(user) -> str:
            """T."""
            return "ok"

        body = json.dumps(
            {
                "tool": "t",
                "arguments": {},
                "user_external_id": "u1",
                "is_anonymous": True,
            }
        ).encode()
        secret = "s"
        # Should not raise even though the payload includes is_anonymous
        # and the loader doesn't accept it — the SDK only forwards it
        # when the signature declares the parameter.
        result = handle_webhook(
            body=body,
            signature=_sign(body, secret),
            webhook_secret=secret,
        )
        assert result == {"result": "ok"}
