"""Unit tests for ``handle_webhook``."""

import hashlib
import hmac
import json

import agentgraft as ag
import pytest
from agentgraft import handle_webhook
from agentgraft.webhook import WebhookError

SECRET = "whsec_test_1234567890"


def _sign(body: bytes, secret: str = SECRET) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def _payload(tool: str, **arguments) -> bytes:
    return json.dumps(
        {
            "tool": tool,
            "arguments": arguments,
            "user_external_id": "user-42",
        }
    ).encode()


@pytest.fixture
def configured_registry():
    """A small but realistic registry: one user_loader + two tools."""

    @ag.user_loader
    def load_user(external_id: str) -> dict:
        # Pretend we have a user database keyed by external id
        return {"id": external_id, "name": f"User {external_id}"}

    @ag.tool
    def echo(user, message: str) -> str:
        """Echo a message."""
        return f"{user['name']}: {message}"

    @ag.tool
    def fail(user) -> None:
        """Always raises."""
        raise RuntimeError("intentional")


class TestSignatureVerification:
    def test_valid_signature_dispatches(self, configured_registry):
        body = _payload("echo", message="hi")
        result = handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert result == {"result": "User user-42: hi"}

    def test_missing_signature_raises_403(self, configured_registry):
        body = _payload("echo", message="hi")
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(body=body, signature="", webhook_secret=SECRET)
        assert exc_info.value.status_code == 403

    def test_wrong_signature_raises_403(self, configured_registry):
        body = _payload("echo", message="hi")
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(body=body, signature="deadbeef", webhook_secret=SECRET)
        assert exc_info.value.status_code == 403

    def test_signature_with_wrong_secret_raises_403(self, configured_registry):
        body = _payload("echo", message="hi")
        bad_sig = _sign(body, secret="other_secret")
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(body=body, signature=bad_sig, webhook_secret=SECRET)
        assert exc_info.value.status_code == 403


class TestPayloadValidation:
    def test_invalid_json_raises_400(self, configured_registry):
        body = b"not json"
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert exc_info.value.status_code == 400

    def test_non_object_body_raises_400(self, configured_registry):
        body = b'["not", "an", "object"]'
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert exc_info.value.status_code == 400

    def test_missing_tool_field_raises_400(self, configured_registry):
        body = json.dumps({"arguments": {}, "user_external_id": "x"}).encode()
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert exc_info.value.status_code == 400

    def test_arguments_must_be_object(self, configured_registry):
        body = json.dumps(
            {"tool": "echo", "arguments": "not-an-object", "user_external_id": "x"}
        ).encode()
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert exc_info.value.status_code == 400


class TestDispatch:
    def test_unknown_tool_raises_404(self, configured_registry):
        body = _payload("nonexistent")
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert exc_info.value.status_code == 404
        assert "nonexistent" in exc_info.value.message

    def test_user_loader_failure_raises_403(self):
        # Build a fresh registry: broken loader + a tool
        @ag.user_loader
        def _broken_loader(_x):
            raise LookupError("user not found")

        @ag.tool
        def echo(user, message: str) -> str:
            """Echo."""
            return message

        body = _payload("echo", message="hi")
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert exc_info.value.status_code == 403

    def test_no_user_loader_raises_500(self):
        # No fixture: registry is empty, but a tool exists
        @ag.tool
        def x(user) -> str:
            """X."""
            return "ok"

        body = _payload("x")
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert exc_info.value.status_code == 500
        assert "user_loader" in exc_info.value.message

    def test_tool_called_with_correct_user_and_args(self, configured_registry):
        body = _payload("echo", message="hello world")
        result = handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert result["result"] == "User user-42: hello world"

    def test_tool_argument_mismatch_raises_400(self, configured_registry):
        body = _payload("echo", wrong_arg="x")
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert exc_info.value.status_code == 400

    def test_tool_internal_error_raises_500(self, configured_registry):
        body = _payload("fail")
        with pytest.raises(WebhookError) as exc_info:
            handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert exc_info.value.status_code == 500
        assert "RuntimeError" in exc_info.value.message
        assert "intentional" in exc_info.value.message


class TestAnonymousVisitorWarning:
    """When the webhook receives an anonymous visitor (``is_anonymous:
    true``) but the registered ``user_loader`` does NOT declare an
    ``is_anonymous`` parameter, the SDK logs a one-line warning so the
    host developer notices their loader will likely fail. The dispatch
    still proceeds (calling the loader positionally) so this is a
    breadcrumb, not a hard failure."""

    def test_warns_when_loader_lacks_is_anonymous(self, monkeypatch):
        @ag.user_loader
        def load_user(external_id: str) -> dict:
            return {"id": external_id}

        @ag.tool
        def echo(user, message: str) -> str:
            """Echo a message."""
            return f"got {message}"

        # Capture warnings emitted by the webhook module's logger.
        from agentgraft import webhook as webhook_module

        captured: list[str] = []

        def fake_warning(fmt, *args, **kwargs):
            try:
                captured.append(fmt % args if args else fmt)
            except TypeError, ValueError:
                captured.append(fmt)

        monkeypatch.setattr(webhook_module.logger, "warning", fake_warning)

        body = json.dumps(
            {
                "tool": "echo",
                "arguments": {"message": "hi"},
                "user_external_id": "session:abc123",
                "is_anonymous": True,
            }
        ).encode()
        result = handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        # Dispatch still succeeds.
        assert result == {"result": "got hi"}
        # Warning was emitted with the right shape.
        assert len(captured) == 1
        assert "anonymous visitor" in captured[0]
        assert "is_anonymous" in captured[0]
        assert "session:abc123" in captured[0]

    def test_no_warning_when_loader_declares_is_anonymous(self, monkeypatch):
        @ag.user_loader
        def load_user(external_id: str, *, is_anonymous: bool = False) -> dict:
            return {"id": external_id, "anon": is_anonymous}

        @ag.tool
        def echo(user, message: str) -> str:
            """Echo a message."""
            return f"got {message}"

        from agentgraft import webhook as webhook_module

        captured: list[str] = []
        monkeypatch.setattr(
            webhook_module.logger,
            "warning",
            lambda fmt, *a, **k: captured.append(fmt),
        )

        body = json.dumps(
            {
                "tool": "echo",
                "arguments": {"message": "hi"},
                "user_external_id": "session:abc123",
                "is_anonymous": True,
            }
        ).encode()
        handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert captured == []

    def test_no_warning_for_authenticated_visitor(self, monkeypatch):
        # Authenticated visitor + loader without is_anonymous → no
        # warning. The warning only fires when there's an actual
        # mismatch (anonymous routed through a non-anon-aware loader).
        @ag.user_loader
        def load_user(external_id: str) -> dict:
            return {"id": external_id}

        @ag.tool
        def echo(user, message: str) -> str:
            """Echo a message."""
            return f"got {message}"

        from agentgraft import webhook as webhook_module

        captured: list[str] = []
        monkeypatch.setattr(
            webhook_module.logger,
            "warning",
            lambda fmt, *a, **k: captured.append(fmt),
        )

        body = json.dumps(
            {
                "tool": "echo",
                "arguments": {"message": "hi"},
                "user_external_id": "user-42",
                # is_anonymous omitted → defaults to False
            }
        ).encode()
        handle_webhook(body=body, signature=_sign(body), webhook_secret=SECRET)
        assert captured == []
