"""Tiny stdlib-only HTTP client for the AgentGraft admin API.

The SDK avoids extra dependencies — no ``requests``, no ``httpx``. Sync
operations against the admin API (push config, fetch graft state) happen
through ``urllib`` because they're called from one place (the management
command) and don't need streaming or connection pooling.

Tool dispatch is a separate concern handled by the AgentGraft service, not
the SDK, so this client never has to talk to that path.
"""

import json
import logging
import random
import time
import urllib.error
import urllib.parse
import urllib.request

from . import __version__

logger = logging.getLogger(__name__)

# HTTP status codes that are safe to retry (transient server-side issues).
# 4xx codes (except 429) are not retried — they indicate a bad request that
# won't succeed on a second attempt.
_RETRYABLE_STATUS = frozenset({429, 500, 502, 503, 504})

_RETRY_INITIAL_DELAY = 1.0  # seconds before the second attempt
_RETRY_MAX_DELAY = 10.0  # cap on the exponential back-off ceiling
_RETRY_JITTER = 0.2  # ±20 % randomisation to avoid thundering herds

# Identify the SDK on every outbound request. Without an explicit
# User-Agent, ``urllib`` defaults to ``Python-urllib/3.x`` which
# Cloudflare's managed bot ruleset bans outright (error 1010,
# ``browser_signature_banned``) — and the AgentGraft API itself sits
# behind Cloudflare. Sending a meaningful UA also makes server logs
# legible: ops can immediately see "this 4xx came from the SDK at
# version X" instead of guessing.
_USER_AGENT = f"agentgraft-python/{__version__} (+https://agentgraft.com)"


class APIError(Exception):
    """The AgentGraft admin API returned a non-2xx response."""

    def __init__(self, status_code: int, body: str) -> None:
        self.status_code = status_code
        self.body = body
        super().__init__(f"HTTP {status_code}: {body[:200]}")


class Client:
    """Minimal Bearer-auth JSON client for the AgentGraft admin API."""

    def __init__(
        self,
        *,
        api_base: str,
        api_key: str,
        timeout: int = 30,
        max_retries: int = 3,
    ) -> None:
        if not api_base:
            raise ValueError("Client(api_base=...) is required")
        if not api_key:
            raise ValueError("Client(api_key=...) is required")
        if max_retries < 0:
            raise ValueError(f"Client(max_retries=...) must be >= 0, got {max_retries!r}")
        self.api_base = api_base.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries

    # ── high-level operations ────────────────────────────────────────────

    def sync_graft(self, *, graft_id: str, payload: dict) -> dict:
        """POST a sync payload to ``/api/v1/admin/grafts/{id}/sync/``."""
        url = f"{self.api_base}/api/v1/admin/grafts/{graft_id}/sync/"
        return self._post_json(url, payload)

    def fetch_policy(self, codename: str) -> dict:
        """GET a single Policy Shop entry by codename.

        Used by the sync command to resolve ``ag.policy(...)``
        references into the actual prompt fragment text before push.
        Codenames contain a literal slash (``agentgraft/mermaid-strict``)
        which urllib already handles correctly because the slash is a
        legal path character.

        The endpoint is unauthenticated — the catalogue is global and
        identical for every customer — so we deliberately do NOT send
        the Bearer token here. That keeps the public-API contract
        clean even if a developer runs ``agentgraft_sync`` with a
        bogus API key while debugging the policy reference.

        Raises :class:`APIError` with status 404 if the codename
        doesn't exist in the catalogue.
        """
        # Quote the codename so spaces or other punctuation never
        # break the URL. The slash inside ``agentgraft/foo`` is
        # preserved because we mark it as a safe character.
        safe_codename = urllib.parse.quote(codename, safe="/")
        url = f"{self.api_base}/api/v1/policies/{safe_codename}/"
        return self._get_json(url)

    # ── low-level transport ──────────────────────────────────────────────

    def _post_json(self, url: str, body: dict) -> dict:
        data = json.dumps(body).encode("utf-8")
        request = urllib.request.Request(
            url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
                "Accept": "application/json",
                "User-Agent": _USER_AGENT,
            },
            method="POST",
        )
        return self._do_request(request)

    def _get_json(self, url: str) -> dict:
        """GET a JSON resource. No Authorization header — used for
        the unauthenticated public Policy Shop endpoint.
        """
        request = urllib.request.Request(
            url,
            headers={
                "Accept": "application/json",
                "User-Agent": _USER_AGENT,
            },
            method="GET",
        )
        return self._do_request(request)

    def _do_request(self, request: urllib.request.Request) -> dict:
        """Execute ``request`` with exponential back-off retries.

        Retries on transient failures: network errors, timeouts, and
        HTTP 5xx / 429 responses. Non-retryable errors (4xx except 429)
        are raised immediately without consuming retry budget.

        Back-off formula::

            delay = min(initial * 2^(attempt-1), max_delay) * jitter

        where ``jitter`` is a uniform random multiplier in
        ``[1 - JITTER, 1 + JITTER]``.
        """
        last_exc: APIError | None = None

        for attempt in range(self.max_retries + 1):
            if attempt > 0:
                delay = min(
                    _RETRY_INITIAL_DELAY * (2 ** (attempt - 1)),
                    _RETRY_MAX_DELAY,
                )
                delay *= 1.0 + _RETRY_JITTER * (2.0 * random.random() - 1.0)
                logger.warning(
                    "agentgraft: transient error on attempt %d/%d — retrying in %.1fs (%s)",
                    attempt,
                    self.max_retries,
                    delay,
                    last_exc,
                )
                time.sleep(delay)

            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    response_body = response.read()

            except urllib.error.HTTPError as exc:
                error_body = exc.read().decode("utf-8", errors="replace")
                api_exc = APIError(exc.code, error_body)
                if exc.code in _RETRYABLE_STATUS:
                    last_exc = api_exc
                    continue
                # 4xx (other than 429) — not transient, raise immediately.
                raise api_exc from exc

            except urllib.error.URLError as exc:
                last_exc = APIError(0, f"Network error: {exc.reason}")
                continue

            except TimeoutError as exc:
                # Socket-level timeout. In Python 3.10+ ``socket.timeout``
                # is an alias for the builtin ``TimeoutError`` (a subclass
                # of ``OSError``) which urllib does NOT wrap in
                # ``URLError`` — so without this branch the caller would
                # see a raw ``TimeoutError`` traceback instead of the
                # clean ``APIError`` envelope every other failure mode
                # gets routed through.
                last_exc = APIError(
                    0,
                    f"Network error: timed out after {self.timeout}s ({exc})",
                )
                continue

            else:
                # Successful HTTP response — decode and return.
                if not response_body:
                    return {}
                try:
                    return json.loads(response_body)
                except json.JSONDecodeError as exc:
                    raise APIError(
                        200, f"Response was not valid JSON: {response_body[:200]!r}"
                    ) from exc

        # Exhausted all attempts.
        raise last_exc
