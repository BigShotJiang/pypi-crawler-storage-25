"""Test helpers for AgentGraft tool authors.

Provides a pytest fixture and two utility functions that make writing
tests for ``@ag.tool`` functions straightforward and safe.

**Quick setup** — add one line to your project's ``conftest.py``::

    pytest_plugins = ["agentgraft.testing"]

This makes the ``ag_reset`` fixture available across your entire test
suite without any imports in individual test files.

**Manual use** — import the fixture or utilities directly::

    from agentgraft.testing import ag_reset, call_tool, tool_schema

**Example test**::

    from myapp.agentgraft_config import list_orders, get_order

    def test_list_orders_returns_only_users_orders(db):
        user = User.objects.create(email="a@example.com")
        Order.objects.create(owner=user, status="pending")
        Order.objects.create(owner=user, status="fulfilled")

        result = call_tool(list_orders, user, status="pending")
        assert len(result) == 1

    def test_get_order_schema_has_required_order_id():
        schema = tool_schema(get_order)
        assert "order_id" in schema["required"]
        assert schema["properties"]["order_id"]["type"] == "string"
"""

import pytest

from .registry import DEFAULT_PROFILE, get_registry
from .registry import reset_registry as _reset_registry

# ---------------------------------------------------------------------------
# Pytest fixture
# ---------------------------------------------------------------------------


@pytest.fixture
def ag_reset():
    """Reset the AgentGraft registry before and after each test.

    Prevents decorator-side-effect registrations from leaking between
    tests — without this, the ``'already registered'`` guard fires
    whenever two tests import the same config module.

    Enable globally via ``conftest.py``::

        pytest_plugins = ["agentgraft.testing"]

    Or use per-test / per-class::

        class TestMyTools:
            def test_something(self, ag_reset):
                ...
    """
    _reset_registry()
    yield
    _reset_registry()


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def call_tool(fn_or_name, user, *, profile: str = DEFAULT_PROFILE, **kwargs):
    """Call a registered tool exactly as the webhook does.

    Injects ``user`` as the first argument and forwards ``kwargs`` as
    the LLM-supplied arguments, mirroring exactly how the webhook
    handler invokes the tool function after signature verification and
    user lookup have already succeeded.

    Args:
        fn_or_name: The decorated tool function, or the string name it
            was registered under.
        user: The user object to pass as the first argument (normally
            injected by the SDK at webhook time).
        profile: Which registry profile to look up the tool from when
            ``fn_or_name`` is a string. Ignored when it's a callable.
        **kwargs: Arguments the LLM would supply — must match the tool's
            non-user parameters.

    Returns:
        Whatever the tool function returns.

    Raises:
        KeyError: If ``fn_or_name`` is a string and no tool by that
            name is registered in ``profile``.
        TypeError: If ``kwargs`` don't match the tool's signature
            (same error the webhook handler would surface as HTTP 400).

    Example::

        result = call_tool(list_orders, user, status="pending", limit=5)
    """
    if callable(fn_or_name):
        return fn_or_name(user, **kwargs)

    tool_reg = get_registry(profile).tools.get(fn_or_name)
    if tool_reg is None:
        raise KeyError(
            f"No tool named {fn_or_name!r} registered in profile {profile!r}. "
            "Decorate it with @ag.tool before calling call_tool()."
        )
    return tool_reg.func(user, **kwargs)


def tool_schema(fn_or_name, *, profile: str = DEFAULT_PROFILE) -> dict:
    """Return the JSON Schema generated for a registered tool's parameters.

    Useful for asserting that the schema the SDK pushes to AgentGraft
    is exactly what you expect — right types, correct ``required`` list,
    descriptions present.

    Args:
        fn_or_name: The decorated tool function, or the string name it
            was registered under.
        profile: Which registry profile to look the tool up from.

    Returns:
        The ``parameters_schema`` dict (a JSON Schema ``object``) that
        the SDK would send during ``agentgraft_sync``.

    Raises:
        KeyError: If the tool isn't registered.

    Example::

        schema = tool_schema(get_order)
        assert "order_id" in schema["required"]
        assert schema["properties"]["order_id"]["description"] == "..."
    """
    name = fn_or_name.__name__ if callable(fn_or_name) else fn_or_name

    tool_reg = get_registry(profile).tools.get(name)
    if tool_reg is None:
        raise KeyError(
            f"No tool named {name!r} registered in profile {profile!r}. "
            "Decorate it with @ag.tool before calling tool_schema()."
        )
    return tool_reg.parameters_schema
