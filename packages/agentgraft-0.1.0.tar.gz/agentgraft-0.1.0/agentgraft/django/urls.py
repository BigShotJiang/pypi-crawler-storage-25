"""URL config for the AgentGraft Django adapter.

Mount it under any prefix you like::

    path("agentgraft/", include("agentgraft.django.urls")),

Routes:

- ``POST /agentgraft/webhook/`` — receives webhooks for the default profile.
- ``POST /agentgraft/webhook/<profile>/`` — receives webhooks for any
  named profile (``public``, ``admin``, etc.).

Configure the matching URL as the host webhook on each graft in the
AgentGraft dashboard.
"""

from django.urls import path

from .views import webhook_view

app_name = "agentgraft"

urlpatterns = [
    path("webhook/", webhook_view, name="webhook"),
    path("webhook/<str:profile>/", webhook_view, name="webhook-profile"),
]
