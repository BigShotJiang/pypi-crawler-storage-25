"""Django integration for the AgentGraft SDK.

Add ``"agentgraft.django"`` to ``INSTALLED_APPS``. The app config will
import the module named in ``AGENTGRAFT["config_module"]`` at startup,
which triggers the decorators inside it and populates the registry.

Required settings::

    AGENTGRAFT = {
        "api_base":       "https://chat.agentgraft.com",
        "api_key":        env("AGENTGRAFT_API_KEY"),
        "graft_id":       "11111111-1111-1111-1111-111111111111",
        "webhook_secret": env("AGENTGRAFT_WEBHOOK_SECRET"),
        "config_module":  "myapp.agentgraft_config",  # default: "agentgraft_config"
    }

The webhook URL is mounted by including
``"agentgraft.django.urls"`` in your project's URL config::

    path("agentgraft/", include("agentgraft.django.urls")),
"""

default_app_config = "agentgraft.django.apps.AgentGraftConfig"
