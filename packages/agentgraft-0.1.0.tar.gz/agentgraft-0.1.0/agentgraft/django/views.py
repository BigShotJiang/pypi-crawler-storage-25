"""Django webhook view — translates ``handle_webhook`` into HTTP.

The view is profile-aware: the URL config maps each profile to its own
URL (``/agentgraft/webhook/`` for default, ``/agentgraft/webhook/<profile>/``
for any other), and the view picks up the right ``webhook_secret`` from
the matching settings block.
"""

import json

from django.http import HttpRequest, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from ..registry import DEFAULT_PROFILE
from ..webhook import WebhookError, handle_webhook
from .settings_helpers import get_profile_config


@csrf_exempt
@require_POST
def webhook_view(request: HttpRequest, profile: str = DEFAULT_PROFILE) -> JsonResponse:
    """Receive a tool call from AgentGraft and dispatch it to a profile registry.

    AgentGraft signs each request with HMAC-SHA256 over the raw body using
    the per-graft webhook secret. The signature lives in
    ``X-AgentGraft-Signature``.

    The ``profile`` URL kwarg selects which registry to dispatch against
    and which secret to verify against. Default is ``"default"``.
    """
    profile_config = get_profile_config(profile)
    secret = profile_config.get("webhook_secret", "")
    if not secret:
        return JsonResponse(
            {
                "error": (
                    f"AGENTGRAFT settings are missing 'webhook_secret' for profile {profile!r}"
                )
            },
            status=500,
        )

    signature = request.headers.get("X-AgentGraft-Signature", "")
    try:
        result = handle_webhook(
            body=request.body,
            signature=signature,
            webhook_secret=secret,
            profile=profile,
        )
    except WebhookError as exc:
        return JsonResponse({"error": exc.message}, status=exc.status_code)
    except Exception as exc:  # noqa: BLE001 — last-resort safety net
        return JsonResponse(
            {"error": f"Unhandled error: {type(exc).__name__}: {exc}"},
            status=500,
        )

    # ``result`` is already JSON-serialisable because it came out of a
    # decorated tool. We do a defensive json.dumps round-trip via
    # JsonResponse so non-serialisable values produce a 500 here rather
    # than a confusing traceback at the WSGI layer.
    try:
        json.dumps(result)
    except (TypeError, ValueError) as exc:
        return JsonResponse(
            {"error": f"Tool returned non-JSON-serialisable value: {exc}"},
            status=500,
        )
    return JsonResponse(result, status=200)
