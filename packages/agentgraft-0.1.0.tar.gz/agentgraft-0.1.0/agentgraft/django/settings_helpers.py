"""Helpers for reading the host project's ``AGENTGRAFT`` settings dict.

The settings shape is::

    AGENTGRAFT = {
        # The single Python file that declares every profile's tools,
        # agents, user loader, and graft prompt context. Imported once
        # at startup by ``agentgraft.django.apps.AgentGraftConfig.ready``.
        "config_module": "myapp.agentgraft_config",

        # One entry per chat experience. Profile names are arbitrary
        # strings — pick whatever reads well in your codebase.
        "profiles": {
            "default": {
                "api_base":       "https://chat.agentgraft.com",
                "api_key":        os.environ["AGENTGRAFT_API_KEY"],
                "graft_id":       os.environ["AGENTGRAFT_GRAFT_ID"],
                "webhook_secret": os.environ["AGENTGRAFT_WEBHOOK_SECRET"],
            },
            "public": {
                "api_base":       "https://chat.agentgraft.com",
                "api_key":        os.environ["AGENTGRAFT_PUBLIC_API_KEY"],
                "graft_id":       os.environ["AGENTGRAFT_PUBLIC_GRAFT_ID"],
                "webhook_secret": os.environ["AGENTGRAFT_PUBLIC_WEBHOOK_SECRET"],
            },
        },
    }

Single-profile installations still go through ``profiles["default"]`` —
one shape, no special cases, no "the SDK supports two ways to do this"
documentation pages. Adding a second profile later is purely additive.

Every other Django adapter module (sync command, webhook view, template
tag) goes through the helpers below so the shape is enforced in exactly
one place.
"""

from django.conf import settings

from ..registry import DEFAULT_PROFILE


def get_settings() -> dict:
    """Return the host project's ``AGENTGRAFT`` dict, or ``{}`` if unset."""
    return getattr(settings, "AGENTGRAFT", {}) or {}


def get_profile_config(profile: str = DEFAULT_PROFILE) -> dict:
    """Return the per-profile connection settings dict.

    Always returns a dict — possibly empty if the profile isn't declared.
    Callers do their own validation against the returned dict so error
    messages can mention which key is missing in their context.
    """
    profiles = get_settings().get("profiles") or {}
    return profiles.get(profile) or {}


def list_profile_names() -> list[str]:
    """Return all profile names declared in settings.

    Used by the sync command when invoked without ``--profile`` to ask
    "which profiles do I know about?".
    """
    profiles = get_settings().get("profiles") or {}
    return list(profiles.keys())


def get_config_module() -> str:
    """Return the dotted path to the host's config module.

    The config module is shared across every profile (one Python file
    declares them all using ``profile=`` kwargs on the decorators).
    Defaults to ``"agentgraft_config"`` so a host with a top-level
    ``agentgraft_config.py`` doesn't have to set anything.
    """
    return get_settings().get("config_module", "agentgraft_config")


def require(profile_config: dict, *keys: str) -> None:
    """Raise ``ValueError`` if any of ``keys`` is missing from the dict.

    Centralised so the error messages stay consistent everywhere we
    validate profile configs.
    """
    missing = [k for k in keys if not profile_config.get(k)]
    if missing:
        raise ValueError("AGENTGRAFT profile config missing required key(s): " + ", ".join(missing))


# The full set of keys a production profile is expected to carry. The
# sync command and the widget template tag each only consume a subset
# (sync needs api_key + graft_id; the tag needs public_key +
# webhook_secret), but documenting both here in one place keeps the
# README and the validators in sync. The actual validators still call
# ``require(...)`` with their own subsets so error messages mention
# only the keys that matter for the surface that's failing.
REQUIRED_PROFILE_KEYS: tuple[str, ...] = (
    "api_base",
    "api_key",
    "public_key",
    "graft_id",
    "webhook_secret",
)
