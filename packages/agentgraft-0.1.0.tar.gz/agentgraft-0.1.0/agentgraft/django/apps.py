"""Django AppConfig that auto-imports the host app's ``agentgraft_config`` module.

Importing the config module is the only way the registry gets populated:
the decorators inside it (``@ag.tool``, ``@ag.agent``, ``@ag.user_loader``,
``ag.graft(...)``) only run on import. We do this in ``ready()`` so it
happens exactly once per process, after Django's app registry is set up.
"""

import contextlib
import importlib

from django.apps import AppConfig
from django.conf import settings


class AgentGraftConfig(AppConfig):
    name = "agentgraft.django"
    label = "agentgraft_django"
    verbose_name = "AgentGraft"

    def ready(self) -> None:
        config = getattr(settings, "AGENTGRAFT", {}) or {}
        module_path = config.get("config_module", "agentgraft_config")
        # Host app hasn't created the config module yet — that's fine
        # for first-run / scaffolding. The sync command will surface a
        # clearer error if the registry is empty when it tries to push.
        with contextlib.suppress(ModuleNotFoundError):
            importlib.import_module(module_path)
