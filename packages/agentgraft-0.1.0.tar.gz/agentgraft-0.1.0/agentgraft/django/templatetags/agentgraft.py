"""``{% agentgraft_widget %}`` template tag.

Drops the embed script tag into a Django template, with everything the
widget needs to bootstrap itself: the embed script src, the graft id, a
stable per-visitor ``data-user-id``, an HMAC signature of that id, and a
``data-anonymous`` flag.

The host developer never has to think about identity. The tag inspects
``request.user`` and chooses one of two strategies:

- **Authenticated visitor** → ``data-user-id="user:{user.pk}"``,
  ``data-anonymous="false"``.
- **Anonymous visitor** → the tag ensures a Django session exists,
  reads its session key, and uses ``data-user-id="session:{key}"``
  with ``data-anonymous="true"``. The session key is cookie-backed by
  Django so the same browser keeps the same identity across requests
  (and across refreshes), which means anonymous visitors get persistent
  conversation history without the host writing any extra code.

The HMAC is computed server-side with the matching profile's
``webhook_secret``, so the page render is fully trusted — the widget
never has to mint or sign anything itself.

The tag accepts an optional ``profile`` argument so a single template
can host any number of named widgets (e.g. ``{% agentgraft_widget %}``
on dashboard pages and ``{% agentgraft_widget profile="public" %}`` on
the marketing landing page).
"""

import hashlib
import hmac
import logging

from asgiref.sync import async_to_sync
from django import template
from django.core.exceptions import SynchronousOnlyOperation
from django.utils.html import escape as html_escape
from django.utils.safestring import mark_safe

from ...registry import DEFAULT_PROFILE
from ..settings_helpers import get_profile_config

logger = logging.getLogger(__name__)

register = template.Library()


@register.simple_tag(takes_context=True)
def agentgraft_widget(context, profile: str = DEFAULT_PROFILE) -> str:
    """Render the script tag that boots the AgentGraft widget.

    Reads the per-profile connection details out of the host's
    ``AGENTGRAFT["profiles"]`` settings and emits the exact data
    attributes that ``embed.js`` expects:

    - ``data-public-key``  — the graft's browser-safe ``pk_*`` token
    - ``data-user-id``     — namespaced visitor id (``user:{pk}`` or ``session:{key}``)
    - ``data-user-hmac``   — HMAC-SHA256 of user-id with the webhook secret
    - ``data-api-base``    — base URL of the AgentGraft service
    - ``data-anonymous``   — ``"true"`` for session-keyed visitors, ``"false"`` otherwise
    """
    profile_config = get_profile_config(profile)
    api_base = (profile_config.get("api_base") or "").rstrip("/")
    public_key = profile_config.get("public_key") or ""
    secret = profile_config.get("webhook_secret") or ""

    # Build a precise list of which keys are missing so the host
    # developer can fix the exact problem instead of guessing through
    # a generic "one of these is wrong" hint.
    missing = [
        name
        for name, value in (
            ("api_base", api_base),
            ("public_key", public_key),
            ("webhook_secret", secret),
        )
        if not value
    ]
    if missing:
        # ``profile`` could in principle carry untrusted data if a host
        # mis-wires the tag as ``{% agentgraft_widget profile=request.GET.x %}``.
        # We HTML-escape it before interpolating into the comment so a
        # ``-->`` payload can never break out of the comment and turn an
        # error message into a script-injection vector. The other
        # interpolations (``missing`` keys) are hardcoded literals so
        # they don't need escaping.
        safe_profile = html_escape(profile)
        return mark_safe(
            f"<!-- agentgraft_widget: profile '{safe_profile}' is missing "
            f"AGENTGRAFT['profiles']['{safe_profile}'] keys: "
            f"{', '.join(missing)} -->"
        )

    request = context.get("request")
    external_id, is_anonymous = _resolve_visitor_identity(request)
    signature = _sign(secret, external_id)

    # The embed bundle is an ES module in BOTH dev and prod:
    #
    # - In dev, ``/embed.js`` redirects to the Vite dev server, which
    #   serves unbundled ES module source.
    # - In prod, ``/embed.js`` is the Vite-built bundle, which uses ES
    #   module ``export`` statements at the top level (Vite's default
    #   library output format).
    #
    # Either way, the browser needs ``type="module"`` to parse it
    # without throwing ``Unexpected token 'export'``. We always emit
    # the attribute. (Earlier versions of this tag conditioned on
    # ``settings.DEBUG`` and broke production silently — see SDK
    # v0.0.1 release notes.)
    return mark_safe(
        f'<script type="module" src="{api_base}/embed.js" '
        f'data-public-key="{public_key}" '
        f'data-user-id="{external_id}" '
        f'data-user-hmac="{signature}" '
        f'data-api-base="{api_base}" '
        f'data-anonymous="{"true" if is_anonymous else "false"}" '
        f"async></script>"
    )


def _resolve_visitor_identity(request) -> tuple[str, bool]:
    """Return ``(external_id, is_anonymous)`` for the current request.

    Authenticated users get ``"user:{pk}"``. Anonymous visitors get
    ``"session:{session_key}"`` after the SDK ensures a session exists.
    The namespacing prefix lets the host's user_loader tell the two
    apart without a parallel "type" parameter.

    If the request object isn't available (template rendered outside an
    HTTP request, e.g. by an offline render command), the tag falls back
    to a static ``"session:offline"`` placeholder so the page still
    renders — but the resulting widget will pin every offline visitor to
    the same conversation, so don't render the tag offline in production.

    Async-view compatibility: when the host app serves the page from
    an ``async def`` view (Daphne / ASGI), accessing ``request.user``
    from a sync template tag triggers ``SynchronousOnlyOperation``
    because ``SimpleLazyObject`` does a sync ORM call to resolve the
    user. We catch that and route through Django's async-safe
    ``request.auser()`` via ``async_to_sync``, which runs the lookup
    on a worker thread. Host apps using sync views see the fast
    path; async views see the same external id with one extra
    thread hop.
    """
    if request is None:
        return "session:offline", True

    user, is_auth = _resolve_request_user(request)
    if user is not None and is_auth:
        return f"user:{user.pk}", False

    # Anonymous: ensure a session exists, then use its key.
    session = getattr(request, "session", None)
    if session is None:
        return "session:offline", True

    if not session.session_key:
        # Force Django to mint and persist a new session key. This sets
        # the sessionid cookie on the response, so the same browser will
        # come back with the same key on subsequent requests.
        #
        # ``session.create()`` is a sync-DB operation. In async views
        # it raises ``SynchronousOnlyOperation`` the same way
        # ``request.user`` did above, so we route through the async
        # variant ``session.acreate()`` (Django 5.0+) via the same
        # ``async_to_sync`` bridge.
        _safe_session_create(session)

    return f"session:{session.session_key or 'offline'}", True


def _resolve_request_user(request) -> tuple[object | None, bool]:
    """Get ``(user, is_authenticated)`` for ``request`` from any view flavour.

    Tries the fast synchronous path first (``request.user`` attribute
    access). If that raises ``SynchronousOnlyOperation`` — which
    Django does when a sync DB call happens inside an async event
    loop — falls back to ``async_to_sync(request.auser)()`` so the
    lookup runs on a thread the ORM is happy with. The two paths
    return the same User object shape, so callers don't need to
    branch on which one succeeded.

    Failures on the async fallback are narrowed to the operational
    error classes we expect to see in practice (DB connection drops,
    OS-level network errors, runtime issues from misconfigured async
    contexts) — and *logged*, never silently swallowed. The visitor
    drops to anonymous identity in that case so the page still
    renders, but ops have a breadcrumb to chase.
    """
    try:
        user = getattr(request, "user", None)
        if user is None:
            return None, False
        # Force resolution: SimpleLazyObject triggers the wrapped
        # ``get_user`` (which does a sync ORM call) on first attribute
        # access, so this is where the async-context failure shows up.
        is_auth = bool(getattr(user, "is_authenticated", False))
        return user, is_auth
    except SynchronousOnlyOperation:
        # Async view context. Resolve through Django's async user
        # helper, bridged back to sync via a worker thread.
        auser = getattr(request, "auser", None)
        if auser is None:
            return None, False
        try:
            user = async_to_sync(auser)()
        except (RuntimeError, OSError) as exc:
            logger.warning(
                "agentgraft_widget: async user resolution failed (%s: %s); "
                "falling back to anonymous identity for this request.",
                type(exc).__name__,
                exc,
            )
            return None, False
        return user, bool(getattr(user, "is_authenticated", False))


def _safe_session_create(session) -> None:
    """Mint a fresh session key, handling both sync and async contexts.

    ``SessionBase.create()`` is sync-DB. In async views Django raises
    ``SynchronousOnlyOperation`` when it's called outside a thread
    pool — same defensive check that blocks ``request.user.pk``. We
    catch that, then try ``session.acreate()`` (Django 5.0+) via
    ``async_to_sync``. If neither path is available (older Django,
    strange session backend), we log and no-op so the caller falls
    back to a ``session:offline`` stub instead of 500'ing on an
    async anonymous visit.
    """
    try:
        session.create()
        return
    except SynchronousOnlyOperation:
        pass

    acreate = getattr(session, "acreate", None)
    if acreate is None:
        logger.warning(
            "agentgraft_widget: anonymous visitor in an async view but "
            "the session backend does not expose acreate(); the visitor "
            "will get a session:offline placeholder identity."
        )
        return
    try:
        async_to_sync(acreate)()
    except (RuntimeError, OSError) as exc:
        logger.warning(
            "agentgraft_widget: async session.acreate() failed (%s: %s); "
            "falling back to a session:offline placeholder identity.",
            type(exc).__name__,
            exc,
        )


def _sign(secret: str, external_id: str) -> str:
    return hmac.new(
        secret.encode(),
        external_id.encode(),
        hashlib.sha256,
    ).hexdigest()
