"""Framework-agnostic webhook handler.

When AgentGraft's orchestrator decides to invoke a tool, it POSTs the call
to the host app's webhook endpoint with an HMAC-SHA256 signature. The host
app's responsibility is to:

1. Verify the signature
2. Look up the user via the registered :func:`user_loader`
3. Dispatch the call to the registered :func:`tool` function
4. Return the result inside a ``{"result": ...}`` envelope

:func:`handle_webhook` does all of that. It's a pure function — no Django,
no Flask, no FastAPI — so framework adapters wrap it with maybe twenty
lines of glue. The Django adapter lives in :mod:`agentgraft.django`.

The function raises :class:`WebhookError` for any failure, with an HTTP
status code and a short message the adapter can serialise into a 4xx/5xx
JSON response.

**Profiles.** ``handle_webhook`` takes an optional ``profile`` argument
that selects which registry to dispatch against. The default profile
matches the default decorator behaviour. Framework adapters route to the
right profile based on the URL or a header.
"""

import hashlib
import hmac
import inspect
import json
import logging
from typing import Any

from .registry import DEFAULT_PROFILE, get_registry

logger = logging.getLogger(__name__)


class WebhookError(Exception):
    """A failure raised during webhook handling.

    Carries an HTTP status code so framework adapters can map it directly
    to a response without thinking. Status codes used:

    - 400 — malformed request body or missing required field
    - 403 — invalid signature or user lookup failure
    - 404 — unknown tool name
    - 500 — registered handler raised an internal exception
    """

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        self.message = message
        super().__init__(message)


def handle_webhook(
    *,
    body: bytes,
    signature: str,
    webhook_secret: str,
    profile: str = DEFAULT_PROFILE,
) -> dict:
    """Verify, parse, dispatch, and respond to a single webhook call.

    Returns a ``{"result": <anything>}`` dict on success. Raises
    :class:`WebhookError` on any failure with the appropriate HTTP status
    code attached.

    The ``profile`` selects which registry to dispatch against — useful
    for host apps that run multiple chat experiences side by side (e.g.
    a default authenticated dashboard concierge plus a public marketing
    concierge).
    """
    if not _verify_signature(body, signature, webhook_secret):
        raise WebhookError(403, "Invalid HMAC signature")

    try:
        payload = json.loads(body)
    except json.JSONDecodeError as exc:
        raise WebhookError(400, f"Invalid JSON body: {exc}") from exc

    if not isinstance(payload, dict):
        raise WebhookError(400, "Webhook body must be a JSON object")

    tool_name = payload.get("tool")
    arguments = payload.get("arguments") or {}
    user_external_id = payload.get("user_external_id")
    is_anonymous = bool(payload.get("is_anonymous", False))

    if not tool_name:
        raise WebhookError(400, "Missing 'tool' field in payload")
    if not isinstance(arguments, dict):
        raise WebhookError(400, "'arguments' must be a JSON object")

    registry = get_registry(profile)
    tool_record = registry.tools.get(tool_name)
    if tool_record is None:
        raise WebhookError(
            404,
            f"Unknown tool: {tool_name!r} (profile {profile!r})",
        )

    if registry.user_loader is None:
        raise WebhookError(
            500,
            f"No @ag.user_loader is registered for profile {profile!r}. "
            "Define one in your config module.",
        )

    try:
        user = _call_user_loader(
            registry.user_loader,
            external_id=user_external_id,
            is_anonymous=is_anonymous,
        )
    except Exception as exc:
        # User lookup failure is a 403 — the requesting user couldn't be
        # resolved against the host app's identity store.
        raise WebhookError(403, f"User lookup failed for {user_external_id!r}: {exc}") from exc

    try:
        result = tool_record.func(user, **arguments)
    except TypeError as exc:
        # Argument mismatch — the LLM passed something the function doesn't accept.
        raise WebhookError(400, f"Bad arguments for tool {tool_name!r}: {exc}") from exc
    except Exception as exc:
        # Any other tool exception is a 500 from the host app's perspective.
        raise WebhookError(
            500,
            f"Tool {tool_name!r} raised: {type(exc).__name__}: {exc}",
        ) from exc

    return {"result": result}


def _verify_signature(body: bytes, supplied: str, secret: str) -> bool:
    """Constant-time HMAC verification."""
    if not supplied:
        return False
    expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, supplied)


def _call_user_loader(
    loader: Any,
    *,
    external_id: Any,
    is_anonymous: bool,
) -> Any:
    """Invoke the user loader, passing ``is_anonymous`` only if it accepts it.

    Loaders defined before the anonymous-visitor support landed take a
    single positional argument and would break if we always forwarded the
    keyword. We introspect the signature once per call and only pass the
    flag when the loader actually declares it.

    When the visitor is anonymous but the registered loader does NOT
    declare ``is_anonymous``, we log a one-line warning so the host
    developer notices: their loader is being called with an opaque
    ``session:abc123`` external id and will likely raise on a
    ``User.objects.get(pk=...)`` lookup. The fix is to add an
    ``is_anonymous=True`` keyword arg to the loader and branch on it.
    """
    try:
        sig = inspect.signature(loader)
    except TypeError, ValueError:
        # Builtins or C-extension callables don't have inspectable
        # signatures — fall back to positional-only invocation.
        return loader(external_id)

    if "is_anonymous" in sig.parameters:
        return loader(external_id, is_anonymous=is_anonymous)
    if is_anonymous:
        logger.warning(
            "agentgraft: anonymous visitor (%r) is being routed to a "
            "user_loader that does not declare 'is_anonymous'. The loader "
            "will be called with the raw external id and will likely fail "
            "on an authenticated-user lookup. Add 'is_anonymous=False' as "
            "a keyword arg to your @ag.user_loader and branch on it.",
            external_id,
        )
    return loader(external_id)
