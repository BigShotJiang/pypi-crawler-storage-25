"""AgentGraft SDK — define your chat config in code.

The PyPI distribution is named ``agentgraft`` (``pip install agentgraft``)
but the Python import path is ``agentgraft`` so it never collides with
a host application's own ``agentgraft/`` Django package.

Typical usage::

    import agentgraft as ag

    @ag.user_loader
    def load_user(external_id: str):
        return User.objects.get(pk=external_id)

    @ag.tool
    def list_datasets(user) -> list[dict]:
        '''List the user's datasets.'''
        return list(user.datasets.values('id', 'name'))

    @ag.agent(entry=True, tools=[list_datasets])
    def helper():
        '''You help users explore their datasets.'''

    ag.graft(
        name="MyApp",
        identity="You are MyApp's assistant.",
        voice="Be concise.",
    )
"""

from importlib.metadata import PackageNotFoundError, version

from .decorators import agent, graft, policy, tool, user_loader
from .registry import (
    DEFAULT_PROFILE,
    AgentRegistration,
    GraftConfig,
    PolicyRef,
    Registry,
    ToolRegistration,
    get_all_profiles,
    get_registry,
    reset_registry,
)
from .schema import Param
from .webhook import WebhookError, handle_webhook

# Single source of truth: pull the version from installed package
# metadata so we never have to dual-bump pyproject.toml AND a literal
# string in code. Falls back to the dev sentinel when running from a
# source checkout that hasn't been pip-installed (e.g. inside the
# monorepo dev shell).
try:
    __version__ = version("agentgraft")
except PackageNotFoundError:  # pragma: no cover — dev-checkout fallback
    __version__ = "0.0.0+local"

__all__ = [
    # Decorators (public DSL)
    "tool",
    "agent",
    "graft",
    "policy",
    "user_loader",
    # Parameter descriptor — attach descriptions to tool parameters
    "Param",
    # Registry introspection (sync command, tests)
    "Registry",
    "ToolRegistration",
    "AgentRegistration",
    "GraftConfig",
    "PolicyRef",
    "get_registry",
    "get_all_profiles",
    "reset_registry",
    "DEFAULT_PROFILE",
    # Webhook handling (Django adapter, third-party adapters)
    "handle_webhook",
    "WebhookError",
    # Version
    "__version__",
]
