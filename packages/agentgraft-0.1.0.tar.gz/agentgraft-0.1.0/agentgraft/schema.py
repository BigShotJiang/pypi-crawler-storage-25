"""Generate JSON Schema fragments from Python type hints.

Used by the ``@ag.tool`` decorator to build the ``parameters_schema`` that
gets pushed to AgentGraft and shown to the LLM. Supports the subset of
type hints we expect to see in real-world chat tool signatures:

  - primitives: str, int, float, bool
  - container types: list, list[T], dict
  - Optional[T] / T | None  → makes the parameter non-required
  - default values → make the parameter non-required regardless of type
  - Literal["a", "b"]  → {"enum": ["a", "b"]} with inferred type
  - Enum subclasses    → {"enum": [member.value, ...]} with inferred type
  - Annotated[T, ag.Param("description")]  → adds "description" to the schema

Parameter descriptions are populated from two sources in priority order:

  1. ``Annotated[T, ag.Param("...")]`` on the parameter — explicit, wins always.
  2. Google-style ``Args:`` section in the function docstring — automatic
     fallback; zero extra syntax for the developer.

The tool-level description (what the LLM reads to decide *whether* to call
the tool) is the docstring with the ``Args:`` section stripped out so the
parameter documentation doesn't pollute the tool overview.
"""

import enum
import inspect
import typing
from typing import Annotated, Any

# ---------------------------------------------------------------------------
# Param descriptor
# ---------------------------------------------------------------------------


class Param:
    """Attach an explicit description (and optional examples) to a tool parameter.

    The primary way to add parameter descriptions is a Google-style ``Args:``
    section in the function docstring — the SDK parses it automatically with no
    extra imports. Use ``ag.Param`` when you need to override one parameter
    independently, or when you want to attach ``examples`` that the docstring
    format can't express.

    Priority: ``ag.Param`` wins over the docstring ``Args:`` section.

    ::

        from typing import Annotated
        import agentgraft as ag

        @ag.tool
        def get_dataset(
            user,
            dataset_id: Annotated[int, ag.Param(
                "Numeric ID of the dataset, as returned by list_datasets",
                examples=[42, 137],
            )],
        ) -> dict:
            \"\"\"Fetch a single dataset by ID.\"\"\"
            ...

    Arguments:
        description: What the LLM should know about this parameter — what
            it means, where the value comes from, edge cases to be aware of.
        examples: Optional list of example values shown to the model. Useful
            for IDs, query strings, or any parameter where the expected
            format isn't obvious from the type alone.
    """

    __slots__ = ("description", "examples")

    def __init__(self, description: str, *, examples: list | None = None) -> None:
        self.description = description
        self.examples = examples

    def __repr__(self) -> str:
        return f"Param({self.description!r})"


# ---------------------------------------------------------------------------
# Docstring parsing
# ---------------------------------------------------------------------------

# Section headers that introduce an Args block. Lower-cased for comparison.
_ARGS_HEADERS = frozenset({"args", "arguments", "parameters", "params"})

# Section headers that end an Args block (lower-cased, without trailing colon).
# Any word followed by ":" at the base indentation level terminates the block,
# but we explicitly list the most common ones as documentation.
_END_HEADERS = frozenset(
    {
        "returns",
        "return",
        "yields",
        "yield",
        "raises",
        "raise",
        "except",
        "exceptions",
        "notes",
        "note",
        "example",
        "examples",
        "attributes",
        "todo",
        "references",
        "see also",
        "warns",
        "warning",
        "warnings",
    }
)


def parse_docstring_args(docstring: str) -> dict[str, str]:
    """Parse a Google-style ``Args:`` section from a docstring.

    Returns a ``{param_name: description}`` dict. Multi-line descriptions
    (indented continuation lines) are joined with a single space. Type
    annotations in the ``name (type):`` form are ignored — the SDK already
    has the type from the function signature.

    Returns an empty dict if there is no ``Args:`` section.
    """
    if not docstring:
        return {}

    # Normalise tabs and split into lines. We work with the raw indentation
    # (not inspect.cleandoc) because the relative indentation is what tells
    # us where the Args block starts and ends.
    lines = docstring.expandtabs(4).splitlines()

    # ── Step 1: locate the Args: header ─────────────────────────────────────
    args_body_start: int | None = None
    for idx, line in enumerate(lines):
        stripped = line.strip()
        # Match "Args:" / "Arguments:" etc. — exactly the word plus a colon,
        # nothing else on the line (some styles add a trailing space, handle
        # that too).
        if stripped.rstrip(":").lower() in _ARGS_HEADERS and stripped.endswith(":"):
            args_body_start = idx + 1
            break

    if args_body_start is None:
        return {}

    # ── Step 2: determine the indentation of parameter entries ───────────────
    # The first non-blank line after "Args:" sets the baseline. Every line at
    # exactly this indentation starts a new parameter; lines indented further
    # are continuations.
    param_indent: int | None = None
    for line in lines[args_body_start:]:
        if line.strip():
            param_indent = len(line) - len(line.lstrip())
            break

    if param_indent is None:
        # Args: section exists but is empty
        return {}

    # ── Step 3: collect parameter entries ───────────────────────────────────
    result: dict[str, str] = {}
    current_name: str | None = None
    current_parts: list[str] = []

    def _flush() -> None:
        if current_name is not None and current_parts:
            result[current_name] = " ".join(current_parts)

    for line in lines[args_body_start:]:
        # Skip blank lines — they can appear between parameters in some styles.
        if not line.strip():
            continue

        indent = len(line) - len(line.lstrip())
        stripped = line.strip()

        if indent < param_indent:
            # We've de-dented past the Args block — stop entirely.
            break

        if indent == param_indent:
            # Could be a new parameter OR a new section header (e.g. "Returns:").
            # A section header has no colon-separated name part that looks like a
            # valid identifier, so we check: if the text before the first ":" is
            # a known end-header or contains spaces (section headers often do),
            # stop processing.
            colon_pos = stripped.find(":")
            if colon_pos == -1:
                # No colon at all — not a parameter line, skip.
                continue

            name_raw = stripped[:colon_pos].strip()

            # Strip parenthetical type: "order_id (str)" → "order_id"
            paren_pos = name_raw.find("(")
            if paren_pos != -1:
                name_raw = name_raw[:paren_pos].strip()

            # Strip *args / **kwargs asterisks
            name_clean = name_raw.lstrip("*").strip()

            # If this looks like a section header (known keyword, or contains
            # spaces, or is empty after cleaning), end the Args block.
            if not name_clean or " " in name_clean or name_clean.lower() in _END_HEADERS:
                break

            # Commit previous parameter, start a new one.
            _flush()
            current_name = name_clean
            desc_start = stripped[colon_pos + 1 :].strip()
            current_parts = [desc_start] if desc_start else []

        else:
            # indent > param_indent — continuation of the current parameter.
            if current_name is not None:
                current_parts.append(stripped)

    _flush()

    # Drop any entries that ended up empty (e.g. "param:" with no description)
    return {k: v for k, v in result.items() if v}


def strip_args_section(docstring: str) -> str:
    """Return the docstring with the ``Args:`` section (and everything after it)
    removed, then cleaned with ``inspect.cleandoc``.

    Used to build the tool-level description — the part the LLM reads to decide
    *whether* to call the tool. The parameter descriptions are folded into the
    schema separately; keeping them in the tool description would just add noise.
    """
    if not docstring:
        return ""

    lines = docstring.expandtabs(4).splitlines()
    result_lines: list[str] = []

    for line in lines:
        stripped = line.strip()
        if stripped.rstrip(":").lower() in _ARGS_HEADERS and stripped.endswith(":"):
            break
        result_lines.append(line)

    return inspect.cleandoc("\n".join(result_lines))


# ---------------------------------------------------------------------------
# Schema generation
# ---------------------------------------------------------------------------

_PRIMITIVE_TYPE_MAP: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}


def build_parameters_schema(
    params: list[inspect.Parameter],
    *,
    docstring_args: dict[str, str] | None = None,
) -> dict:
    """Build a JSON Schema ``object`` from a list of inspect parameters.

    ``docstring_args`` is a ``{name: description}`` dict parsed from the
    function's ``Args:`` section. It is used as a fallback: if a parameter's
    annotation already carries a description via ``Annotated[T, ag.Param(...)]``
    that takes priority and the docstring entry is ignored.

    Parameters without a type annotation raise ``ValueError`` at decoration
    time so the developer fixes the signature before sync.
    """
    properties: dict[str, dict] = {}
    required: list[str] = []
    docstring_args = docstring_args or {}

    for param in params:
        if param.annotation is inspect.Parameter.empty:
            raise ValueError(
                f"Tool parameter {param.name!r} is missing a type hint. "
                f"Add one (e.g. `{param.name}: int`) so AgentGraft can "
                "build the JSON schema for the LLM."
            )

        prop = _annotation_to_schema(param.annotation)

        # Merge docstring description as fallback — only if ag.Param hasn't
        # already provided one (ag.Param wins).
        if "description" not in prop and param.name in docstring_args:
            prop = {**prop, "description": docstring_args[param.name]}

        properties[param.name] = prop

        # A parameter is required iff (a) it has no default AND (b) the type
        # is not Optional. Optional[X] alone makes it non-required because
        # the LLM is allowed to omit it.
        has_default = param.default is not inspect.Parameter.empty
        is_optional = _is_optional_type(param.annotation)
        if not has_default and not is_optional:
            required.append(param.name)

    return {
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }


def _annotation_to_schema(ann: Any) -> dict:
    """Translate one Python annotation to a JSON Schema fragment."""
    origin = typing.get_origin(ann)
    args = typing.get_args(ann)

    # Annotated[T, ag.Param("description"), ...] — extract metadata first,
    # then recurse into the base type and merge the Param fields in.
    if origin is Annotated:
        base_type = args[0]
        metadata = args[1:]
        schema = _annotation_to_schema(base_type)
        for meta in metadata:
            if isinstance(meta, Param):
                schema = {**schema, "description": meta.description}
                if meta.examples:
                    schema["examples"] = list(meta.examples)
                break  # Only the first Param wins
        return schema

    # Optional[X] / Union[X, None] → strip the None and recurse
    if origin is typing.Union:
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1:
            return _annotation_to_schema(non_none[0])
        # General union → use anyOf
        return {"anyOf": [_annotation_to_schema(a) for a in non_none]}

    # Literal["a", "b", ...] → enum constraint with inferred base type.
    # The LLM receives an explicit list of allowed values — no guessing.
    if origin is typing.Literal:
        values = list(args)
        if values and all(isinstance(v, str) for v in values):
            return {"type": "string", "enum": values}
        if values and all(isinstance(v, int) for v in values):
            return {"type": "integer", "enum": values}
        return {"enum": values}

    # list[T] → array of items
    if origin is list:
        if args:
            return {"type": "array", "items": _annotation_to_schema(args[0])}
        return {"type": "array"}

    # dict[K, V] → object (we don't bother with key/value schemas)
    if origin is dict:
        return {"type": "object"}

    # Enum subclass → enum constraint. Values are used (not names) because
    # the LLM sends values in the JSON payload.
    if isinstance(ann, type) and issubclass(ann, enum.Enum):
        values = [m.value for m in ann]
        if values and all(isinstance(v, str) for v in values):
            return {"type": "string", "enum": values}
        if values and all(isinstance(v, int) for v in values):
            return {"type": "integer", "enum": values}
        return {"enum": values}

    # Primitive type
    if isinstance(ann, type) and ann in _PRIMITIVE_TYPE_MAP:
        return {"type": _PRIMITIVE_TYPE_MAP[ann]}

    # Bare ``list`` or ``dict`` (no parameterisation)
    if ann is list:
        return {"type": "array"}
    if ann is dict:
        return {"type": "object"}

    # Unknown — fall through to ``any``. Better to silently accept than
    # crash sync for an exotic type the developer might have a reason for.
    return {}


def _is_optional_type(ann: Any) -> bool:
    """``True`` if the annotation is ``Optional[X]`` or ``X | None``."""
    # Unwrap Annotated first so Optional[Annotated[X, ...]] is handled.
    if typing.get_origin(ann) is Annotated:
        return _is_optional_type(typing.get_args(ann)[0])
    origin = typing.get_origin(ann)
    if origin is typing.Union:
        return type(None) in typing.get_args(ann)
    return False
