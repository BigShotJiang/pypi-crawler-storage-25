"""In-memory registries of decorated tools, agents, hooks, and graft config.

The SDK supports any number of independent **profiles**. A profile is just
a string name (``"default"``, ``"public"``, ``"admin"``, ``"trial"``,
``"support"``, …); each profile owns its own private :class:`Registry`
with its own tools, agents, user loader, and graft config. Profiles never
share state — a tool registered with ``profile="public"`` is invisible to
the default profile, and vice versa.

Why this exists: a single Django host app may want multiple chat
experiences with different tool surfaces, prompts, and identity models.
The dashboard concierge needs a real ``User.objects.get()`` lookup and
tenancy-aware tools; the public landing concierge wants a guest sentinel
and a marketing-only tool set. Both belong in the same Python file (so
they're easy to read top-to-bottom), but they must dispatch against
*physically separate* registries so a public-profile tool can never be
called against an authenticated user, and vice versa. The separation is
enforced by the SDK at the dispatch layer, not by convention at the
application layer.

Decorators in :mod:`decorators` write into the registry named by their
``profile=`` kwarg (default: ``"default"``). The sync command and the
webhook handler each take a ``profile`` argument and read from the
matching registry.

Tests should call :func:`reset_registry` between cases to wipe state.
With no argument it clears every profile; with a profile name it clears
just that one.
"""

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

DEFAULT_PROFILE = "default"


@dataclass
class ToolRegistration:
    """A tool function registered via ``@ag.tool``."""

    name: str  # snake_case identifier (function name)
    description: str  # docstring or explicit ``description=``
    parameters_schema: dict  # JSON Schema generated from type hints
    func: Callable[..., Any]  # the actual Python callable


@dataclass
class AgentRegistration:
    """An agent definition registered via ``@ag.agent``."""

    name: str  # snake_case identifier (function name)
    instructions: str  # docstring (the role description)
    tool_names: list[str] = field(default_factory=list)
    handoff_names: list[str] = field(default_factory=list)
    sub_agent_names: list[str] = field(default_factory=list)
    # Any Cailos model codename — e.g. ``auto``, ``auto:speed``,
    # ``auto:cost``, ``claude-opus-4-7``. Passed to Cailos verbatim at
    # runtime; invalid values surface as Cailos errors, not local
    # validation failures.
    model: str = "auto"
    is_entry_point: bool = False


@dataclass(frozen=True)
class PolicyRef:
    """A reference to a curated server-side policy from the Policy Shop.

    Created via ``ag.policy("agentgraft/mermaid-strict")``. The SDK
    treats this as an opaque sentinel — the codename is stored locally,
    and the actual policy body is fetched from the AgentGraft Policy
    Shop API at sync time and substituted into the composed
    ``policies`` text before pushing to the runtime.

    Why this is a sentinel rather than an inlined string: customers
    reference policies by codename so that AgentGraft can improve a
    policy's wording centrally and every customer's next sync picks
    up the improvement automatically. The single source of truth lives
    on the AgentGraft servers, not in each customer's Python file.
    """

    codename: str


@dataclass
class GraftConfig:
    """Graft-level prompt context + widget welcome screen, set via ``ag.graft(...)``.

    The five prompt fields (identity / product_context / voice / scope /
    policies) compose into every agent's system prompt at runtime.

    The ``policies`` field is unique: it's stored internally as a list
    of items where each item is either a free-form string or a
    :class:`PolicyRef` referencing a curated server-side policy. The
    decorator accepts both forms transparently — pass a plain string
    for backward compatibility, pass a list to mix and match
    ``ag.policy("agentgraft/...")`` references with custom strings.
    The sync command resolves PolicyRefs into the actual policy bodies
    by hitting the public Policy Shop API and composes everything into
    a single string before pushing to the runtime.

    The two widget fields (``greeting`` and ``example_prompts``) drive
    the empty-state UI a visitor sees before sending a first message —
    a short paragraph plus a row of clickable suggestion buttons. Both
    are optional; the widget falls back to built-in defaults when blank.
    """

    name: str | None = None
    identity: str = ""
    product_context: str = ""
    voice: str = ""
    scope: str = ""
    policies: list = field(default_factory=list)
    webhook_url: str | None = None
    greeting: str = ""
    example_prompts: list = field(default_factory=list)
    # Tri-state fields: ``None`` means "don't touch the server value",
    # a concrete value means "set explicitly on the next sync". Matches
    # how the server's _SyncGraftMetaSerializer handles these fields —
    # absent keys are left unchanged, present keys overwrite. Lets a
    # host app declare ``memory_enabled=True`` in its config once and
    # have it stay true, without having to re-declare every unrelated
    # field on every sync.
    memory_enabled: bool | None = None
    recap_enabled: bool | None = None
    recap_min_gap_minutes: int | None = None
    recap_message_pairs: int | None = None
    recap_min_message_pairs: int | None = None


class Registry:
    """An isolated registry of host-app decorations for a single profile.

    A profile is one tenant of the SDK's per-process state. The dashboard
    profile and the public-marketing profile each get their own
    :class:`Registry` instance — independent ``tools`` dict, independent
    ``agents`` dict, independent ``user_loader``, independent
    ``graft_config``.
    """

    def __init__(self, profile: str = DEFAULT_PROFILE) -> None:
        self.profile = profile
        self.tools: dict[str, ToolRegistration] = {}
        self.agents: dict[str, AgentRegistration] = {}
        self.user_loader: Callable[..., Any] | None = None
        self.graft_config: GraftConfig = GraftConfig()

    # ── mutators ──────────────────────────────────────────────────────────

    def register_tool(self, tool: ToolRegistration) -> None:
        if tool.name in self.tools:
            raise ValueError(
                f"Tool {tool.name!r} is already registered in profile "
                f"{self.profile!r}. Each tool name must be unique within "
                "its profile (the same name in two different profiles is "
                "fine — the registries are independent)."
            )
        self.tools[tool.name] = tool

    def register_agent(self, agent: AgentRegistration) -> None:
        if agent.name in self.agents:
            raise ValueError(
                f"Agent {agent.name!r} is already registered in profile "
                f"{self.profile!r}. Each agent name must be unique within "
                "its profile."
            )
        self.agents[agent.name] = agent

    def set_user_loader(self, fn: Callable[..., Any]) -> None:
        if self.user_loader is not None:
            raise ValueError(
                f"user_loader is already registered in profile "
                f"{self.profile!r}. Only one @ag.user_loader is allowed "
                "per profile."
            )
        self.user_loader = fn

    def set_graft_config(self, config: GraftConfig) -> None:
        self.graft_config = config

    def reset(self) -> None:
        """Wipe all registrations on this profile. Use between tests."""
        self.tools.clear()
        self.agents.clear()
        self.user_loader = None
        self.graft_config = GraftConfig()


# ── Module-level multi-profile store ─────────────────────────────────────

_REGISTRIES: dict[str, Registry] = {}


def get_registry(profile: str = DEFAULT_PROFILE) -> Registry:
    """Return the :class:`Registry` for the given profile, creating it lazily.

    Profiles are created on first access — there is no separate
    "create_profile" call. Decorators that name a fresh profile string
    will materialise that profile's registry on the spot.
    """
    if profile not in _REGISTRIES:
        _REGISTRIES[profile] = Registry(profile=profile)
    return _REGISTRIES[profile]


def get_all_profiles() -> dict[str, Registry]:
    """Return a *copy* of the profile→Registry mapping.

    The sync command uses this to enumerate which profiles exist when the
    user runs ``manage.py agentgraft_sync`` without specifying ``--profile``.
    Returning a copy keeps callers from mutating the SDK's internal state
    by accident.
    """
    return dict(_REGISTRIES)


def reset_registry(profile: str | None = None) -> None:
    """Reset registries. Tests should call this between cases.

    With no argument, every profile is cleared (the most common test
    fixture). With a profile name, only that profile is cleared.
    """
    if profile is None:
        _REGISTRIES.clear()
    else:
        _REGISTRIES.pop(profile, None)
