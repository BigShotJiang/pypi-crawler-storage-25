"""The public DSL: ``@ag.tool``, ``@ag.agent``, ``@ag.user_loader``, ``ag.graft``.

Each decorator's only job is to write into a :class:`Registry`. The
functions themselves remain ordinary Python callables — the SDK never
mutates them or wraps them in instrumentation. ``@ag.agent`` is special:
its decorated function body is never invoked because the function exists
only as a vehicle for the docstring and the keyword-arg config.

**Profiles.** Every decorator accepts an optional ``profile=`` kwarg.
When omitted (or used as a bare decorator), the registration goes into
the ``"default"`` profile. Pass ``profile="public"`` (or any other name)
to register into a separate, independent registry — the dashboard
concierge can live in the default profile while the public marketing
concierge lives in ``"public"``, both in the same Python file.
"""

import inspect
from collections.abc import Callable
from typing import Any

from .registry import (
    DEFAULT_PROFILE,
    AgentRegistration,
    GraftConfig,
    PolicyRef,
    ToolRegistration,
    get_registry,
)
from .schema import build_parameters_schema, parse_docstring_args, strip_args_section

# ---------------------------------------------------------------------------
# @ag.tool
# ---------------------------------------------------------------------------


def tool(
    func: Callable | None = None,
    *,
    description: str | None = None,
    profile: str = DEFAULT_PROFILE,
):
    """Register a function as a tool that an agent can call.

    Use as a bare decorator (description comes from the docstring,
    profile defaults to ``"default"``)::

        @ag.tool
        def list_datasets(user) -> list[dict]:
            '''List the user's datasets.'''
            return list(user.datasets.values('id', 'name'))

    Or with explicit options::

        @ag.tool(description="Fetch one dataset by id.", profile="public")
        def explain_datasets(user) -> str:
            ...

    Contract:

    - The function name (``list_datasets``) becomes the tool name the LLM sees.
    - The first parameter is always ``user`` — the SDK injects whatever the
      registered :func:`user_loader` returns.
    - Every other parameter MUST have a type hint. The SDK builds the
      JSON schema from those hints.
    - The docstring (or ``description=``) is what the LLM uses to decide
      when to call the tool.
    - Tool names only have to be unique *within their profile*; the same
      name in two different profiles is fine because the registries are
      independent.
    """

    def wrap(fn: Callable) -> Callable:
        sig = inspect.signature(fn)
        params = list(sig.parameters.values())
        if not params:
            raise ValueError(
                f"@ag.tool {fn.__name__!r}: tool functions must take "
                "at least one parameter ('user' is injected by the SDK)."
            )

        # The first parameter is always the user — skip it for schema generation.
        tool_params = params[1:]
        docstring_args = parse_docstring_args(fn.__doc__ or "")
        schema = build_parameters_schema(tool_params, docstring_args=docstring_args)

        if description is not None:
            desc = description.strip()
        else:
            desc = strip_args_section(fn.__doc__ or "").strip()
        if not desc:
            raise ValueError(
                f"@ag.tool {fn.__name__!r}: missing description. "
                "Add a docstring or pass description=..."
            )

        get_registry(profile).register_tool(
            ToolRegistration(
                name=fn.__name__,
                description=desc,
                parameters_schema=schema,
                func=fn,
            )
        )
        return fn

    if func is None:
        # Called with kwargs: @ag.tool(description=..., profile=...)
        return wrap
    # Called bare: @ag.tool
    return wrap(func)


# ---------------------------------------------------------------------------
# @ag.agent
# ---------------------------------------------------------------------------


def agent(
    func: Callable | None = None,
    *,
    tools: list[Callable | str] | None = None,
    handoffs: list[Callable | str] | None = None,
    sub_agents: list[Callable | str] | None = None,
    model: str = "auto",
    entry: bool = False,
    profile: str = DEFAULT_PROFILE,
):
    """Register an agent. The function's docstring becomes its role.

    The function body is **never executed** — the function exists purely
    as a vehicle for:

    - the function name → the agent's identifier
    - the docstring     → the agent's role / instructions
    - decorator kwargs  → tools, handoffs, sub_agents, model, entry point flag, profile

    ::

        @ag.agent(
            entry=True,
            tools=[list_datasets, get_dataset],
            handoffs=[dataset_editor],
            sub_agents=[research_agent],
            model="auto",
            profile="default",  # or "public", "admin", etc.
        )
        def helper():
            '''You help users explore their datasets.'''

    ``tools``, ``handoffs``, and ``sub_agents`` accept either references to
    the decorated Python functions (typo-proof, IDE-friendly) or string names
    (useful for forward references where the target is defined later in the file).

    **``sub_agents`` vs ``handoffs``**:

    - ``handoffs`` is a full conversation transfer — the target agent takes
      ownership of the dialogue and the current agent steps aside.
    - ``sub_agents`` invokes the target agent as a *tool call* — the target
      runs its own tool loop and returns a result string, then the current
      agent stays in control and can use that result in its response.

    Use ``sub_agents`` when you want an orchestrator pattern (e.g. an advisor
    that calls a research specialist and folds the findings into a reply),
    rather than a routing pattern.
    """

    def wrap(fn: Callable) -> Callable:
        instructions = (fn.__doc__ or "").strip()
        if not instructions:
            raise ValueError(
                f"@ag.agent {fn.__name__!r}: missing docstring. "
                "Every agent needs a role description (docstring) so the "
                "LLM knows what to do."
            )

        tool_names = [_resolve_ref(t, kind="tool") for t in (tools or [])]
        handoff_names = [_resolve_ref(h, kind="handoff") for h in (handoffs or [])]
        sub_agent_names = [_resolve_ref(s, kind="sub_agent") for s in (sub_agents or [])]

        get_registry(profile).register_agent(
            AgentRegistration(
                name=fn.__name__,
                instructions=instructions,
                tool_names=tool_names,
                handoff_names=handoff_names,
                sub_agent_names=sub_agent_names,
                model=model,
                is_entry_point=entry,
            )
        )
        return fn

    if func is None:
        return wrap
    return wrap(func)


# ---------------------------------------------------------------------------
# @ag.user_loader
# ---------------------------------------------------------------------------


def user_loader(
    func: Callable[..., Any] | None = None,
    *,
    profile: str = DEFAULT_PROFILE,
):
    """Register the function that resolves an external user id to a user object.

    AgentGraft sends the host app's external user id (whatever the host
    chose — primary key, UUID, session key, anonymous token) on every
    webhook tool call. This function turns that id into the user object
    passed as the first argument to your ``@ag.tool`` functions.

    Bare decorator (default profile)::

        @ag.user_loader
        def load_user(external_id: str) -> User:
            return User.objects.get(pk=external_id)

    Per-profile (e.g. for an anonymous public concierge)::

        @ag.user_loader(profile="public")
        def load_guest(external_id: str, *, is_anonymous: bool = True) -> dict:
            return {"session": external_id.removeprefix("session:")}

    The optional ``is_anonymous`` keyword is set to ``True`` by the SDK
    when the visitor was identified via a Django session id rather than
    an authenticated user pk. Loaders are free to ignore it.

    Only one ``@ag.user_loader`` is allowed per profile.
    """

    def wrap(fn: Callable[..., Any]) -> Callable[..., Any]:
        get_registry(profile).set_user_loader(fn)
        return fn

    if func is None:
        # Called with kwargs: @ag.user_loader(profile="public")
        return wrap
    # Called bare: @ag.user_loader
    return wrap(func)


# ---------------------------------------------------------------------------
# ag.graft(...)
# ---------------------------------------------------------------------------


def graft(
    *,
    name: str | None = None,
    identity: str = "",
    product_context: str = "",
    voice: str = "",
    scope: str = "",
    policies: str | list | None = None,
    webhook_url: str | None = None,
    greeting: str = "",
    example_prompts: list[str] | None = None,
    memory_enabled: bool | None = None,
    recap_enabled: bool | None = None,
    recap_min_gap_minutes: int | None = None,
    recap_message_pairs: int | None = None,
    recap_min_message_pairs: int | None = None,
    profile: str = DEFAULT_PROFILE,
) -> None:
    """Set the graft-level prompt context + widget welcome screen.

    Call this once per profile in your config file. Each field is
    optional — fill in only the layers you want.

    The ``policies`` field accepts either a free-form string OR a list
    of items where each item is a string or a :func:`policy` reference::

        ag.graft(
            name="MyApp",
            identity="You are MyApp's assistant.",
            voice="Be concise.",
            policies=[
                ag.policy("agentgraft/no-hallucination"),
                ag.policy("agentgraft/concise"),
                ag.policy("agentgraft/secrets-redaction"),
                "Never call list_invoices for users without billing role.",
            ],
        )

        # Backwards-compatible: a plain string still works
        ag.graft(
            name="MyApp",
            policies="Never reveal API keys.",
        )

    Each ``ag.policy(...)`` reference is resolved at sync time by
    fetching the body from the AgentGraft Policy Shop API and
    composing it into the final ``policies`` text alongside any
    free-form strings. If a referenced codename doesn't exist, sync
    fails with a clear error pointing at the typo.

    The five text blocks (identity / product_context / voice / scope /
    policies) compose into every agent's system prompt at runtime. The
    two widget fields (``greeting`` + ``example_prompts``) appear in the
    empty-state UI before the visitor sends a first message; both are
    optional and fall back to built-in defaults when blank.

    ``memory_enabled`` and ``recap_enabled`` are tri-state: leave them
    as ``None`` (the default) to preserve whatever the server currently
    has, pass ``True`` to turn the feature on, or ``False`` to turn it
    off. ``memory_enabled=True`` wires long-term facts into every chat
    turn — the Dreamer extracts durable preferences after each
    conversation and the recall agent reads them on the next one.
    ``recap_enabled=True`` pre-generates a "where you left off" summary
    when a visitor has been idle, so returning visitors see context
    instead of a blank thread. Both default to ``False`` on a fresh
    graft; most production grafts want at least memory on.

    ``recap_min_gap_minutes`` / ``recap_message_pairs`` /
    ``recap_min_message_pairs`` tune the recap pipeline when it's on.
    Leave them ``None`` to use the server defaults (30 min idle,
    10-pair window, 3-pair minimum). The server clamps
    ``recap_min_gap_minutes`` at 30 (the sweep floor); shorter values
    are rejected at sync time.
    """
    policy_items = _normalise_policies(policies)
    get_registry(profile).set_graft_config(
        GraftConfig(
            name=name,
            identity=identity.strip(),
            product_context=product_context.strip(),
            voice=voice.strip(),
            scope=scope.strip(),
            policies=policy_items,
            webhook_url=webhook_url,
            greeting=greeting.strip(),
            example_prompts=[p.strip() for p in (example_prompts or []) if p.strip()],
            memory_enabled=memory_enabled,
            recap_enabled=recap_enabled,
            recap_min_gap_minutes=recap_min_gap_minutes,
            recap_message_pairs=recap_message_pairs,
            recap_min_message_pairs=recap_min_message_pairs,
        )
    )


# ---------------------------------------------------------------------------
# ag.policy(...)
# ---------------------------------------------------------------------------


def policy(codename: str) -> PolicyRef:
    """Reference a curated policy from the AgentGraft Policy Shop.

    The Policy Shop is AgentGraft's catalogue of ready-made,
    server-side prompt fragments that solve common LLM pain points
    (strict mermaid syntax, no hallucination, secrets redaction,
    etc). Browse the catalogue at ``/dashboard/policies/`` or via the
    public API at ``GET /api/v1/policies/``.

    Use as a list item in ``ag.graft(policies=[...])``::

        ag.graft(
            name="MyApp",
            policies=[
                ag.policy("agentgraft/mermaid-strict"),
                ag.policy("agentgraft/no-hallucination"),
                "Never recommend competitor products.",
            ],
        )

    The codename is resolved at sync time by hitting the public
    Policy Shop API. The body text is fetched, joined with any other
    list items, and pushed as the graft's ``policies`` field. If the
    codename doesn't exist in the catalogue, sync raises a clear
    error and refuses to push partial state.

    Returns a :class:`PolicyRef` sentinel — opaque to callers, only
    meaningful inside the sync command's resolution pass.
    """
    if not isinstance(codename, str):
        raise TypeError(
            f"ag.policy(codename) requires a string codename, "
            f"got {type(codename).__name__}: {codename!r}"
        )
    if not codename.strip():
        raise ValueError("ag.policy(codename) requires a non-empty codename.")
    if "/" not in codename:
        raise ValueError(
            f"ag.policy({codename!r}): codenames must be namespaced as "
            f"``namespace/slug`` (e.g. ``agentgraft/mermaid-strict``)."
        )
    return PolicyRef(codename=codename.strip())


def _normalise_policies(value: str | list | None) -> list:
    """Normalise the ``policies`` argument into a list of items.

    Accepts:

    - ``None`` → empty list
    - ``""``   → empty list
    - ``str``  → single-item list (after whitespace strip)
    - ``list`` → each item validated as ``str`` or :class:`PolicyRef`

    A list with non-string, non-PolicyRef items raises a clear error
    instead of silently coercing — typos in the config file should
    fail loudly at decorator-evaluation time, not silently at sync.
    """
    if value is None:
        return []
    if isinstance(value, str):
        stripped = value.strip()
        return [stripped] if stripped else []
    if not isinstance(value, list):
        raise TypeError(
            f"ag.graft(policies=...) must be a string or a list of "
            f"strings/PolicyRefs, got {type(value).__name__}."
        )
    items = []
    for index, item in enumerate(value):
        if isinstance(item, PolicyRef):
            items.append(item)
        elif isinstance(item, str):
            stripped = item.strip()
            if stripped:
                items.append(stripped)
        else:
            raise TypeError(
                f"ag.graft(policies=[...]): item {index} must be a "
                f"string or ag.policy(...) reference, got "
                f"{type(item).__name__}: {item!r}"
            )
    return items


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _resolve_ref(ref: Callable | str, *, kind: str) -> str:
    """Coerce a tool/handoff reference into the canonical string name."""
    if isinstance(ref, str):
        return ref
    if callable(ref) and hasattr(ref, "__name__"):
        return ref.__name__
    raise ValueError(
        f"@ag.agent {kind} reference must be a function or string, "
        f"got {type(ref).__name__}: {ref!r}"
    )
