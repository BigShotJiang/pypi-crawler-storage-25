"""Semantic pipeline utilities for KRPGScript.

The semantic pipeline runs after syntax parsing and handles:
- schema compilation for `.krpgd` (and legacy `!include` schema files)
- import/linking for multi-file projects
- scope-aware structural validation
- in-place argument type coercion
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Any

from krpgscript.parser import (
    Command,
    ParseError,
    Section,
    SourceLocation,
    TraceFrame,
    _quote_symbol,
    format_traceback,
    parse_text,
)


class ValueType(StrEnum):
    """Supported primitive value types for semantic arguments."""

    STRING = "string"
    INT = "int"
    FLOAT = "float"
    BOOL = "bool"
    ENUM = "enum"


@dataclass(slots=True, frozen=True)
class ArgumentDef:
    """Definition of one node argument in the schema."""

    value_type: ValueType
    is_optional: bool = False
    is_vararg: bool = False
    enum_values: tuple[str, ...] = ()
    minimum: int | float | None = None
    maximum: int | float | None = None


@dataclass(slots=True)
class ChildRule:
    """Allowed child rule for a section definition."""

    name: str
    is_optional: bool = False
    is_repeatable: bool = False
    is_anonymous: bool = False
    is_mixin: bool = False
    node_def: NodeDef | None = None


@dataclass(slots=True)
class NodeDef:
    """Base schema definition for commands and sections."""

    name: str
    args: list[ArgumentDef] = field(default_factory=list)
    is_anonymous: bool = False
    is_optional: bool = False
    is_repeatable: bool = False
    location: SourceLocation | None = None


@dataclass(slots=True)
class CommandDef(NodeDef):
    """Schema definition of a command (leaf) node."""


@dataclass(slots=True)
class SectionDef(NodeDef):
    """Schema definition of a section (block) node."""

    local_scope: dict[str, NodeDef] = field(default_factory=dict)
    allowed_children: list[ChildRule] = field(default_factory=list)
    allow_any_child: bool = False


class SemanticError(ValueError):
    """Raised when semantic linking or schema compilation fails."""

    def __init__(
        self,
        message: str,
        *,
        traceback: list[TraceFrame] | None = None,
        hint: str | None = None,
    ) -> None:
        """Initialize semantic error details with optional traceback and hint."""
        super().__init__(message)
        self.message = message
        self.traceback = traceback or []
        self.hint = hint

    def __str__(self) -> str:
        """Return the user-facing semantic error message."""
        return self.message


def format_semantic_traceback(error: SemanticError) -> str:
    """Render semantic errors in the same style as parser traceback output."""
    lines = ["Traceback (most recent call last):"]

    for frame in error.traceback:
        location = frame.location
        symbol = _quote_symbol(frame.symbol)
        lines.append(
            f'  File "{location.source_name}", line {location.line}, column {location.column}, '
            f"in {frame.kind} {symbol}"
        )
        if location.line_text:
            lines.append(f"    {location.line_text}")
            lines.append(f"    {' ' * (location.column - 1)}^")

    lines.append(f"SemanticError: {error}")
    if error.hint:
        lines.append(f"Hint: {error.hint}")

    return "\n".join(lines)


@dataclass(slots=True)
class SemanticProject:
    """Result of linking a script project and loading schema files."""

    root: Section
    schema_registry: dict[str, NodeDef] = field(default_factory=dict)


@dataclass(slots=True, frozen=True)
class SemanticAnnotation:
    """Renderable semantic details for one runtime AST node."""

    arg_types: tuple[ArgumentDef, ...] = ()
    children: tuple[str, ...] = ()


def build_semantic_annotations(
    root: Section,
    schema_registry: dict[str, NodeDef],
) -> dict[int, SemanticAnnotation]:
    """Build per-node argument type annotations for a validated tree.

    Returns a mapping keyed by ``id(node)`` with values such as
    ``"string"`` or ``"enum:ONE,TWO int?"``.
    """
    root_def = _resolve_root_definition(schema_registry)
    if root_def is None:
        return {}

    annotations: dict[int, SemanticAnnotation] = {}
    scope_stack: list[dict[str, NodeDef]] = [schema_registry]
    _collect_annotations(
        root,
        root_def,
        scope_stack=scope_stack,
        registry=schema_registry,
        annotations=annotations,
    )
    return annotations


def _collect_annotations(
    section_node: Section,
    section_def: SectionDef,
    *,
    scope_stack: list[dict[str, NodeDef]],
    registry: dict[str, NodeDef],
    annotations: dict[int, SemanticAnnotation],
) -> None:
    scope_stack.append(section_def.local_scope)
    try:
        child_rules = _expand_child_rules(section_def, scope_stack=scope_stack, registry=registry)
        exact_rules: dict[str, list[tuple[int, ChildRule]]] = {}
        for index, rule in enumerate(child_rules):
            if rule.is_anonymous:
                continue
            exact_rules.setdefault(rule.name, []).append((index, rule))

        anonymous_rules = [rule for rule in child_rules if rule.is_anonymous]
        anonymous_rule = anonymous_rules[0] if anonymous_rules else None

        for child in section_node.children:
            if child.name is None:
                continue

            selected_def: NodeDef | None = None
            use_anonymous_name = False

            candidates = exact_rules.get(child.name, [])
            for _, candidate in candidates:
                candidate_def = _resolve_rule_definition(
                    candidate,
                    scope_stack=scope_stack,
                    registry=registry,
                    location=child.location,
                )
                if isinstance(candidate_def, CommandDef) and isinstance(child, Section):
                    continue
                if isinstance(candidate_def, SectionDef) and isinstance(child, Command):
                    continue

                try:
                    _coerce_node_args(
                        child,
                        candidate_def,
                        consume_name_as_first_arg=False,
                        apply=False,
                    )
                except SemanticError:
                    continue

                selected_def = candidate_def
                break

            if selected_def is None and not candidates and anonymous_rule is not None:
                candidate_def = _resolve_rule_definition(
                    anonymous_rule,
                    scope_stack=scope_stack,
                    registry=registry,
                    location=child.location,
                )
                if isinstance(candidate_def, SectionDef) and isinstance(child, Command):
                    candidate_def = None

                if candidate_def is not None:
                    try:
                        _coerce_node_args(
                            child,
                            candidate_def,
                            consume_name_as_first_arg=True,
                            apply=False,
                        )
                    except SemanticError:
                        candidate_def = None

                if candidate_def is not None:
                    selected_def = candidate_def
                    use_anonymous_name = True

            if selected_def is None:
                continue

            arg_types = _annotation_arg_types(
                selected_def,
                consume_name_as_first_arg=use_anonymous_name,
            )
            child_annotations: tuple[str, ...] = ()
            if isinstance(selected_def, SectionDef):
                child_annotations = tuple(
                    _format_child_rule_annotations(
                        selected_def,
                        scope_stack=scope_stack,
                        registry=registry,
                    )
                )

            if arg_types or child_annotations:
                annotations[id(child)] = SemanticAnnotation(
                    arg_types=arg_types,
                    children=child_annotations,
                )

            if isinstance(child, Section) and isinstance(selected_def, SectionDef):
                _collect_annotations(
                    child,
                    selected_def,
                    scope_stack=scope_stack,
                    registry=registry,
                    annotations=annotations,
                )
    finally:
        scope_stack.pop()


def _annotation_arg_types(
    node_def: NodeDef,
    *,
    consume_name_as_first_arg: bool,
) -> tuple[ArgumentDef, ...]:
    args = node_def.args[1:] if consume_name_as_first_arg and node_def.args else node_def.args
    return tuple(args)


def _format_argument_type(argument: ArgumentDef) -> str:
    if argument.value_type is ValueType.ENUM:
        base = f"enum:{','.join(argument.enum_values)}"
    elif (
        argument.value_type is ValueType.INT
        and argument.minimum is not None
        and argument.maximum is not None
    ):
        base = f"int:{int(argument.minimum)}:{int(argument.maximum)}"
    elif (
        argument.value_type is ValueType.FLOAT
        and argument.minimum is not None
        and argument.maximum is not None
    ):
        base = f"float:{argument.minimum}:{argument.maximum}"
    else:
        base = argument.value_type.value

    if argument.is_optional:
        base += "?"
    if argument.is_vararg:
        base += "..."
    return base


def _format_child_rule_annotations(
    section_def: SectionDef,
    *,
    scope_stack: list[dict[str, NodeDef]],
    registry: dict[str, NodeDef],
) -> list[str]:
    scope_stack.append(section_def.local_scope)
    try:
        child_rules = _expand_child_rules(section_def, scope_stack=scope_stack, registry=registry)
        lines: list[str] = []
        for rule in child_rules:
            node_def = _resolve_rule_definition(
                rule,
                scope_stack=scope_stack,
                registry=registry,
                location=section_def.location,
            )
            lines.append(_format_child_rule_annotation(rule, node_def))
        return lines
    finally:
        scope_stack.pop()


def _format_child_rule_annotation(rule: ChildRule, node_def: NodeDef) -> str:
    name = rule.name
    if rule.is_anonymous:
        name += "*"
    if rule.is_optional:
        name += "?"
    if rule.is_repeatable:
        name += "..."

    args = " ".join(_format_argument_type(arg) for arg in node_def.args)
    body = " {}" if isinstance(node_def, SectionDef) else ""
    if args:
        return f"{name} {args}{body}"
    return f"{name}{body}"


@dataclass(slots=True)
class _LinkContext:
    schema_registry: dict[str, NodeDef] = field(default_factory=dict)
    schema_files: set[Path] = field(default_factory=set)
    schema_stack: list[Path] = field(default_factory=list)
    script_stack: list[Path] = field(default_factory=list)


def compile_project(entry_file: Path) -> SemanticProject:
    """Load, link, validate, and type a KRPG entry file."""
    context = _LinkContext()
    root = _load_script(entry_file.expanduser().resolve(), context)
    validate_tree(root, context.schema_registry)
    return SemanticProject(root=root, schema_registry=dict(context.schema_registry))


def load_project_schema(entry_file: Path) -> dict[str, NodeDef]:
    """Load and return schema registry without validating script tree."""
    context = _LinkContext()
    _load_script(entry_file.expanduser().resolve(), context)
    return dict(context.schema_registry)


def _load_script(path: Path, context: _LinkContext) -> Section:
    if path in context.script_stack:
        cycle = [*context.script_stack, path]
        raise SemanticError(
            f"Circular !import detected: {' -> '.join(str(item) for item in cycle)}",
            traceback=[],
            hint="Break the import cycle by removing one recursive `!import` reference.",
        )

    context.script_stack.append(path)
    try:
        try:
            source = path.read_text(encoding="utf-8")
        except OSError as error:
            raise SemanticError(
                f"Cannot read script file: {path}",
                hint=str(error),
            ) from error

        try:
            root = parse_text(source, source_name=str(path))
        except ParseError:
            raise

        linked_children: list[Section | Command] = []
        for child in root.children:
            if isinstance(child, Command) and child.name in {"!import", "!include"}:
                _expand_import(child, base_file=path, context=context, output=linked_children)
                continue
            linked_children.append(child)

        root.children = linked_children
        for child in root.children:
            child.parent = root
        return root
    finally:
        context.script_stack.pop()


def _expand_import(
    import_command: Command,
    *,
    base_file: Path,
    context: _LinkContext,
    output: list[Section | Command],
) -> None:
    location = import_command.location or SourceLocation(str(base_file), 1, 1, "")
    target = _resolve_import_target(import_command, base_file=base_file)
    directive = import_command.name

    if directive == "!include":
        _load_schema(target, context)
        return

    if target.suffix == ".krpg":
        imported_root = _load_script(target, context)
        output.extend(imported_root.children)
        return

    if target.suffix in {".krpgd", ".d"} or target.name.endswith(".krpg.d"):
        _load_schema(target, context)
        return

    raise SemanticError(
        f"Unsupported import target extension: {target.name}",
        traceback=[TraceFrame(kind="directive", symbol=directive or "!import", location=location)],
        hint="Use `!import` for `.krpg`/`.krpgd` or `!include` for schema files.",
    )


def _resolve_import_target(import_command: Command, *, base_file: Path) -> Path:
    location = import_command.location or SourceLocation(str(base_file), 1, 1, "")
    directive = import_command.name or "!import"
    if len(import_command.args) != 1:
        raise SemanticError(
            f"`{directive}` expects exactly one path argument",
            traceback=[TraceFrame(kind="directive", symbol=directive, location=location)],
            hint=f'Use `{directive} "relative/path.krpg"`.',
        )

    target = (base_file.parent / import_command.args[0]).resolve()
    if not target.is_file():
        raise SemanticError(
            f"Imported file not found: {target}",
            traceback=[TraceFrame(kind="directive", symbol=directive, location=location)],
            hint="Import paths are resolved relative to the file containing the directive.",
        )

    return target


def _load_schema(path: Path, context: _LinkContext) -> None:
    if path in context.schema_stack:
        cycle = [*context.schema_stack, path]
        raise SemanticError(
            f"Circular schema import detected: {' -> '.join(str(item) for item in cycle)}",
            hint="Break the import cycle by removing one recursive schema directive.",
        )

    if path in context.schema_files:
        return

    context.schema_stack.append(path)
    try:
        try:
            source = path.read_text(encoding="utf-8")
        except OSError as error:
            raise SemanticError(f"Cannot read schema file: {path}", hint=str(error)) from error

        try:
            root = parse_text(source, source_name=str(path))
        except ParseError:
            raise

        filtered_children: list[Section | Command] = []
        for child in root.children:
            if isinstance(child, Command) and child.name in {"!import", "!include"}:
                target = _resolve_import_target(child, base_file=path)
                if target.suffix == ".krpg":
                    raise SemanticError(
                        f"Schema file cannot import script file: {target.name}",
                        traceback=_node_traceback(child),
                        hint="Use schema imports only for `.krpgd`/`.krpg` schema files.",
                    )
                _load_schema(target, context)
                continue
            filtered_children.append(child)

        root.children = filtered_children

        compiled = compile_schema(root)
        # Last import wins by design.
        context.schema_registry.update(compiled)
        context.schema_files.add(path)
    finally:
        context.schema_stack.pop()


def compile_schema(root: Section) -> dict[str, NodeDef]:
    """Compile parsed `.krpgd` AST into a schema registry."""
    registry: dict[str, NodeDef] = {}
    seen_root = 0
    for child in root.children:
        definition = _compile_node_definition(child)
        if definition.name == "root":
            seen_root += 1
        registry[definition.name] = definition

    if seen_root > 1:
        raise SemanticError("Schema cannot define `root` more than once")

    _validate_root_schema(registry)
    return registry


def _compile_node_definition(node: Section | Command) -> NodeDef:
    if node.name is None:
        raise SemanticError("Schema node must have a name")

    name, is_anonymous, is_optional, is_repeatable, is_wildcard = _parse_name_modifiers(node.name)
    if is_wildcard:
        raise SemanticError("`...` cannot be used as a node definition name")

    args = [_parse_argument(token) for token in node.args]
    _validate_argument_order(args, node=node)

    if isinstance(node, Command):
        return CommandDef(
            name=name,
            args=args,
            is_anonymous=is_anonymous,
            is_optional=is_optional,
            is_repeatable=is_repeatable,
            location=node.location,
        )

    section = SectionDef(
        name=name,
        args=args,
        is_anonymous=is_anonymous,
        is_optional=is_optional,
        is_repeatable=is_repeatable,
        location=node.location,
    )

    for child in node.children:
        if isinstance(child, Command) and len(child.content) == 1:
            child_name = child.name or ""
            if child_name.startswith(":"):
                section.allowed_children.append(ChildRule(name=child_name[1:], is_mixin=True))
                continue

            rule_name, rule_anonymous, rule_optional, rule_repeatable, is_wildcard_rule = (
                _parse_name_modifiers(child_name)
            )
            if is_wildcard_rule:
                section.allow_any_child = True
                continue

            section.allowed_children.append(
                ChildRule(
                    name=rule_name,
                    is_optional=rule_optional,
                    is_repeatable=rule_repeatable,
                    is_anonymous=rule_anonymous,
                    node_def=None,
                )
            )
            continue

        inline_definition = _compile_node_definition(child)
        section.local_scope[inline_definition.name] = inline_definition
        section.allowed_children.append(
            ChildRule(
                name=inline_definition.name,
                is_optional=inline_definition.is_optional,
                is_repeatable=inline_definition.is_repeatable,
                is_anonymous=inline_definition.is_anonymous,
                node_def=inline_definition,
            )
        )

    has_anonymous = any(rule.is_anonymous for rule in section.allowed_children)
    if sum(1 for rule in section.allowed_children if rule.is_anonymous) > 1:
        raise SemanticError(
            "Section schema cannot define more than one anonymous child rule",
            traceback=_node_traceback(node),
            hint="Keep exactly one `name*` child rule per section.",
        )

    if has_anonymous and section.allow_any_child:
        raise SemanticError(
            "Section schema cannot allow both anonymous children (`*`) and "
            "wildcard children (`...`)",
            traceback=_node_traceback(node),
            hint=(
                "Use either one anonymous child template or wildcard child "
                "matching in the same section."
            ),
        )

    return section


def _parse_name_modifiers(raw_name: str) -> tuple[str, bool, bool, bool, bool]:
    token = raw_name.strip()
    if token == "...":
        return "...", False, False, False, True

    # Canonical modifier order for node names: `*` then `?` then `...`.
    is_repeatable = False
    is_optional = False
    is_anonymous = False
    if token.endswith("..."):
        token = token[:-3]
        is_repeatable = True
    if token.endswith("?"):
        token = token[:-1]
        is_optional = True
    if token.endswith("*"):
        token = token[:-1]
        is_anonymous = True

    if any(char in token for char in "*?"):
        raise SemanticError(
            f"Invalid name modifier order for token: {raw_name!r}. Expected `name*?...`",
        )

    if not token:
        raise SemanticError(f"Invalid empty node name after modifiers: {raw_name!r}")

    return token, is_anonymous, is_optional, is_repeatable, False


def _parse_argument(token: str) -> ArgumentDef:
    raw = token.strip()
    if not raw:
        raise SemanticError("Schema argument token cannot be empty")

    if raw == "...":
        return ArgumentDef(value_type=ValueType.STRING, is_optional=False, is_vararg=True)

    is_vararg = raw.endswith("...")
    if is_vararg:
        raw = raw[:-3]

    is_optional = raw.endswith("?")
    if is_optional:
        raw = raw[:-1]

    if raw.startswith("enum:"):
        raw_members = raw[len("enum:") :].split(",")
        if not raw_members or all(not value.strip() for value in raw_members):
            raise SemanticError("Enum argument must define at least one value")
        members_list = [value.strip() for value in raw_members]
        if any(not value for value in members_list):
            raise SemanticError("Enum argument contains an empty value")
        members = tuple(members_list)
        return ArgumentDef(
            value_type=ValueType.ENUM,
            is_optional=is_optional,
            is_vararg=is_vararg,
            enum_values=members,
        )

    if raw.startswith("int:"):
        minimum, maximum = _parse_range(raw, "int")
        return ArgumentDef(
            value_type=ValueType.INT,
            is_optional=is_optional,
            is_vararg=is_vararg,
            minimum=minimum,
            maximum=maximum,
        )

    if raw.startswith("float:"):
        minimum, maximum = _parse_range(raw, "float")
        return ArgumentDef(
            value_type=ValueType.FLOAT,
            is_optional=is_optional,
            is_vararg=is_vararg,
            minimum=minimum,
            maximum=maximum,
        )

    by_name = {
        "string": ValueType.STRING,
        "int": ValueType.INT,
        "float": ValueType.FLOAT,
        "bool": ValueType.BOOL,
    }
    if raw not in by_name:
        raise SemanticError(f"Unknown schema argument type: {raw!r}")

    return ArgumentDef(value_type=by_name[raw], is_optional=is_optional, is_vararg=is_vararg)


def _parse_range(raw: str, prefix: str) -> tuple[int | float, int | float]:
    parts = raw.split(":")
    if len(parts) != 3:
        raise SemanticError(f"{prefix} range must use `{prefix}:min:max` format")

    left = parts[1]
    right = parts[2]
    try:
        if prefix == "int":
            minimum = int(left)
            maximum = int(right)
        else:
            minimum = float(left)
            maximum = float(right)
    except ValueError as error:
        raise SemanticError(f"{prefix} range values must be valid numbers") from error

    if minimum > maximum:
        raise SemanticError(f"{prefix} range min cannot be greater than max")

    return minimum, maximum


def _validate_argument_order(args: list[ArgumentDef], *, node: Section | Command) -> None:
    seen_optional = False
    seen_vararg = False

    for arg in args:
        if seen_vararg:
            raise SemanticError(
                "Vararg argument (`...`) must be the last argument",
                traceback=_node_traceback(node),
            )

        if arg.is_vararg:
            seen_vararg = True
            continue

        if arg.is_optional:
            seen_optional = True
            continue

        if seen_optional:
            raise SemanticError(
                "Required arguments cannot appear after optional arguments",
                traceback=_node_traceback(node),
            )


def validate_tree(root: Section, schema_registry: dict[str, NodeDef]) -> None:
    """Validate and type a linked tree in place using compiled schema definitions."""
    root_def = _resolve_root_definition(schema_registry)
    scope_stack: list[dict[str, NodeDef]] = [schema_registry]

    if root_def is None:
        return

    _validate_section_children(root, root_def, scope_stack=scope_stack, registry=schema_registry)


def _resolve_root_definition(schema_registry: dict[str, NodeDef]) -> SectionDef | None:
    node_def = schema_registry.get("root")
    if node_def is None:
        return None

    if not isinstance(node_def, SectionDef):
        raise SemanticError("`root` type must be defined as a section", hint="Use `root { ... }`.")

    if node_def.args:
        raise SemanticError("`root` section cannot define arguments", hint="Use `root { ... }`.")

    return node_def


def _validate_section_children(
    section_node: Section,
    section_def: SectionDef,
    *,
    scope_stack: list[dict[str, NodeDef]],
    registry: dict[str, NodeDef],
) -> None:
    scope_stack.append(section_def.local_scope)
    try:
        child_rules = _expand_child_rules(section_def, scope_stack=scope_stack, registry=registry)
        exact_rules: dict[str, list[tuple[int, ChildRule]]] = {}
        for index, rule in enumerate(child_rules):
            if rule.is_anonymous:
                continue
            exact_rules.setdefault(rule.name, []).append((index, rule))

        anonymous_rules = [rule for rule in child_rules if rule.is_anonymous]
        anonymous_rule = anonymous_rules[0] if anonymous_rules else None
        anonymous_index = child_rules.index(anonymous_rule) if anonymous_rule is not None else None

        seen_counts: dict[int, int] = {}

        for child in section_node.children:
            if child.name is None:
                continue

            matched_rule: ChildRule | None = None
            matched_rule_index: int | None = None
            selected_def: NodeDef | None = None

            candidates = exact_rules.get(child.name, [])
            candidate_error: SemanticError | None = None
            for rule_index, candidate in candidates:
                try:
                    candidate_def = _resolve_rule_definition(
                        candidate,
                        scope_stack=scope_stack,
                        registry=registry,
                        location=child.location,
                    )
                    if isinstance(candidate_def, CommandDef) and isinstance(child, Section):
                        raise SemanticError(
                            f"Node `{child.name}` must be a command (without `{{}}`)",
                            traceback=_node_traceback(child),
                        )
                    if isinstance(candidate_def, SectionDef) and isinstance(child, Command):
                        raise SemanticError(
                            f"Node `{child.name}` must be a section (with `{{}}`)",
                            traceback=_node_traceback(child),
                        )
                    _coerce_node_args(
                        child,
                        candidate_def,
                        consume_name_as_first_arg=False,
                        apply=False,
                    )
                except SemanticError as error:
                    candidate_error = error
                    continue

                matched_rule = candidate
                matched_rule_index = rule_index
                selected_def = candidate_def
                break

            use_anonymous_name = False
            if (
                matched_rule is None
                and not candidates
                and anonymous_rule is not None
                and anonymous_index is not None
            ):
                try:
                    candidate_def = _resolve_rule_definition(
                        anonymous_rule,
                        scope_stack=scope_stack,
                        registry=registry,
                        location=child.location,
                    )
                    _coerce_node_args(
                        child,
                        candidate_def,
                        consume_name_as_first_arg=True,
                        apply=False,
                    )
                    matched_rule = anonymous_rule
                    matched_rule_index = anonymous_index
                    selected_def = candidate_def
                    use_anonymous_name = True
                except SemanticError as error:
                    candidate_error = error

            if matched_rule is None:
                if section_def.allow_any_child:
                    continue
                if candidate_error is not None:
                    raise candidate_error
                raise SemanticError(
                    f"Unknown node `{child.name}` inside section `{section_node.name or '<root>'}`",
                    traceback=_node_traceback(child),
                )

            assert selected_def is not None
            target_def = selected_def

            if isinstance(target_def, CommandDef) and isinstance(child, Section):
                raise SemanticError(
                    f"Node `{child.name}` must be a command (without `{{}}`)",
                    traceback=_node_traceback(child),
                )
            if isinstance(target_def, SectionDef) and isinstance(child, Command):
                raise SemanticError(
                    f"Node `{child.name}` must be a section (with `{{}}`)",
                    traceback=_node_traceback(child),
                )

            _coerce_node_args(
                child,
                target_def,
                consume_name_as_first_arg=use_anonymous_name,
                apply=True,
            )

            assert matched_rule_index is not None
            seen_counts[matched_rule_index] = seen_counts.get(matched_rule_index, 0) + 1
            if not matched_rule.is_repeatable and seen_counts[matched_rule_index] > 1:
                raise SemanticError(
                    "Node "
                    f"`{child.name}` appears more than once in "
                    f"`{section_node.name or '<root>'}`",
                    traceback=_node_traceback(child),
                    hint="Mark child with `...` in schema to allow repeats.",
                )

            if isinstance(child, Section) and isinstance(target_def, SectionDef):
                _validate_section_children(
                    child,
                    target_def,
                    scope_stack=scope_stack,
                    registry=registry,
                )

        for rule_index, rule in enumerate(child_rules):
            if not rule.is_optional and seen_counts.get(rule_index, 0) == 0:
                missing = f"{rule.name}*" if rule.is_anonymous else rule.name
                raise SemanticError(
                    "Missing required node "
                    f"`{missing}` in section `{section_node.name or '<root>'}`",
                    traceback=_node_traceback(section_node),
                )
    finally:
        scope_stack.pop()


def _expand_child_rules(
    section_def: SectionDef,
    *,
    scope_stack: list[dict[str, NodeDef]],
    registry: dict[str, NodeDef],
    _active_mixins: set[str] | None = None,
    _expanded_mixins: set[str] | None = None,
) -> list[ChildRule]:
    rules: list[ChildRule] = []
    active_mixins = _active_mixins or set()
    expanded_mixins = _expanded_mixins or set()

    for rule in section_def.allowed_children:
        if not rule.is_mixin:
            rules.append(rule)
            continue

        mixin_name = rule.name
        if mixin_name in active_mixins:
            raise SemanticError(f"Circular mixin reference detected: :{mixin_name}")
        if mixin_name in expanded_mixins:
            continue

        mixin_def = _resolve_def_in_scopes(
            mixin_name,
            scope_stack=scope_stack,
            registry=registry,
            location=section_def.location,
        )
        if not isinstance(mixin_def, SectionDef):
            raise SemanticError(f"Mixin `:{mixin_name}` must refer to a section type")

        expanded = _expand_child_rules(
            mixin_def,
            scope_stack=scope_stack,
            registry=registry,
            _active_mixins={*active_mixins, mixin_name},
            _expanded_mixins={*expanded_mixins, mixin_name},
        )
        rules.extend(expanded)
        expanded_mixins.add(mixin_name)

    return rules


def _resolve_rule_definition(
    rule: ChildRule,
    *,
    scope_stack: list[dict[str, NodeDef]],
    registry: dict[str, NodeDef],
    location: SourceLocation | None,
) -> NodeDef:
    if rule.node_def is not None:
        return rule.node_def
    return _resolve_def_in_scopes(
        rule.name,
        scope_stack=scope_stack,
        registry=registry,
        location=location,
    )


def _resolve_def_in_scopes(
    name: str,
    *,
    scope_stack: list[dict[str, NodeDef]],
    registry: dict[str, NodeDef],
    location: SourceLocation | None,
) -> NodeDef:
    for scope in reversed(scope_stack):
        if name in scope:
            return scope[name]

    if name in registry:
        return registry[name]

    traceback: list[TraceFrame] = []
    if location is not None:
        traceback = [TraceFrame(kind="schema", symbol=name, location=location)]
    raise SemanticError(f"Unknown type reference `{name}`", traceback=traceback)


def _coerce_node_args(
    node: Section | Command,
    node_def: NodeDef,
    *,
    consume_name_as_first_arg: bool,
    apply: bool,
) -> list[Any]:
    if node.name is None:
        return []

    raw_args = [str(arg) for arg in node.args]

    if not consume_name_as_first_arg:
        coerced = _coerce_arguments(raw_args, node_def.args, location=node.location)
        if apply:
            node.content = [node.name, *coerced]
        return coerced

    if isinstance(node_def, SectionDef):
        # For anonymous section rules, identifier must be consumed as the first schema arg.
        coerced_named = _coerce_arguments(
            [node.name, *raw_args],
            node_def.args,
            location=node.location,
        )
        final = coerced_named[1:]
        if apply:
            node.content = [node.name, *final]
        return final

    # Anonymous matching supports both styles:
    # 1) schema args exclude identifier (use raw args)
    # 2) schema args include identifier as first arg (use name + args)
    first_error: SemanticError | None = None
    try:
        coerced_raw = _coerce_arguments(raw_args, node_def.args, location=node.location)
        if apply:
            node.content = [node.name, *coerced_raw]
        return coerced_raw
    except SemanticError as error:
        first_error = error

    try:
        coerced_named = _coerce_arguments(
            [node.name, *raw_args],
            node_def.args,
            location=node.location,
        )
        final = coerced_named[1:]
        if apply:
            node.content = [node.name, *final]
        return final
    except SemanticError as error:
        if first_error is not None:
            raise first_error from error
        raise


def _coerce_arguments(
    raw_args: list[str],
    argument_defs: list[ArgumentDef],
    *,
    location: SourceLocation | None,
) -> list[Any]:
    result: list[Any] = []
    index = 0
    optional_chain_broken = False

    for arg_def in argument_defs:
        if arg_def.is_vararg:
            while index < len(raw_args):
                result.append(_coerce_scalar(raw_args[index], arg_def, location=location))
                index += 1
            return result

        if index >= len(raw_args):
            if arg_def.is_optional:
                optional_chain_broken = True
                continue
            raise SemanticError(
                "Not enough arguments for node",
                traceback=_location_traceback(location),
            )

        token = raw_args[index]
        try:
            coerced = _coerce_scalar(token, arg_def, location=location)
        except SemanticError:
            if arg_def.is_optional:
                optional_chain_broken = True
                continue
            raise

        if optional_chain_broken and arg_def.is_optional:
            raise SemanticError(
                "Cannot provide later optional argument while previous optional is omitted",
                traceback=_location_traceback(location),
            )

        result.append(coerced)
        index += 1

    if index < len(raw_args):
        raise SemanticError("Too many arguments for node", traceback=_location_traceback(location))

    return result


def _coerce_scalar(value: str, arg_def: ArgumentDef, *, location: SourceLocation | None) -> Any:
    if arg_def.value_type == ValueType.STRING:
        return value

    if arg_def.value_type == ValueType.INT:
        try:
            parsed = int(value)
        except ValueError as error:
            raise SemanticError(
                f"Expected int, got {value!r}", traceback=_location_traceback(location)
            ) from error
        _check_numeric_range(parsed, arg_def, location=location)
        return parsed

    if arg_def.value_type == ValueType.FLOAT:
        try:
            parsed = float(value)
        except ValueError as error:
            raise SemanticError(
                f"Expected float, got {value!r}", traceback=_location_traceback(location)
            ) from error
        _check_numeric_range(parsed, arg_def, location=location)
        return parsed

    if arg_def.value_type == ValueType.BOOL:
        lowered = value.lower()
        if lowered in {"true", "1"}:
            return True
        if lowered in {"false", "0"}:
            return False
        raise SemanticError(
            f"Expected bool, got {value!r}. Use true/false or 1/0.",
            traceback=_location_traceback(location),
        )

    if arg_def.value_type == ValueType.ENUM:
        if value not in arg_def.enum_values:
            allowed = ", ".join(arg_def.enum_values)
            raise SemanticError(
                f"Enum value {value!r} is not allowed. Expected one of: {allowed}",
                traceback=_location_traceback(location),
            )
        return value

    return value


def _check_numeric_range(
    value: int | float,
    arg_def: ArgumentDef,
    *,
    location: SourceLocation | None,
) -> None:
    if arg_def.minimum is not None and value < arg_def.minimum:
        raise SemanticError(
            f"Value {value} is below minimum {arg_def.minimum}",
            traceback=_location_traceback(location),
        )
    if arg_def.maximum is not None and value > arg_def.maximum:
        raise SemanticError(
            f"Value {value} is above maximum {arg_def.maximum}",
            traceback=_location_traceback(location),
        )


def _validate_root_schema(registry: dict[str, NodeDef]) -> None:
    root_def = registry.get("root")
    if root_def is None:
        return
    if not isinstance(root_def, SectionDef):
        raise SemanticError("`root` must be defined as a section")
    if root_def.args:
        raise SemanticError("`root` cannot have arguments")


def _location_traceback(location: SourceLocation | None) -> list[TraceFrame]:
    if location is None:
        return []
    return [TraceFrame(kind="node", symbol="<args>", location=location)]


def _node_traceback(node: Section | Command) -> list[TraceFrame]:
    location = node.location
    if location is None:
        return []

    symbol = " ".join(node.content) if node.content else "<node>"
    return [TraceFrame(kind="schema", symbol=symbol, location=location)]


def render_error(error: Exception) -> str:
    """Render known parser/semantic errors with traceback formatting."""
    if isinstance(error, ParseError):
        return format_traceback(error)
    if isinstance(error, SemanticError):
        return format_semantic_traceback(error)
    return str(error)
