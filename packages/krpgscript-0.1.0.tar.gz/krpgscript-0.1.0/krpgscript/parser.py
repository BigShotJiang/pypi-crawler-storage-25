"""Parser for KRPG DSL.

The parser builds a tree with two node types:
- Section: a block that can contain nested sections and commands
- Command: a leaf node with positional arguments
"""

from __future__ import annotations

import json
import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from enum import Enum, auto


@dataclass(slots=True, frozen=True)
class SourceLocation:
    """Source position for a token or AST node."""

    source_name: str
    line: int
    column: int
    line_text: str


@dataclass(slots=True, frozen=True)
class TraceFrame:
    """Single frame in a parser traceback."""

    kind: str
    symbol: str
    location: SourceLocation


@dataclass(slots=True)
class Token:
    """Token produced by the tokenizer with source position."""

    type: TokenType
    value: str
    location: SourceLocation

    def __iter__(self):
        """Yield token type and value for tuple-compatible unpacking."""
        yield self.type
        yield self.value

    def __len__(self) -> int:
        """Return the tuple-compatible token length."""
        return 2

    def __getitem__(self, index: int):
        """Return token type or value by tuple-style index."""
        if index == 0:
            return self.type
        if index == 1:
            return self.value
        raise IndexError(index)

    def __eq__(self, other: object) -> bool:
        """Compare tokens using type/value semantics for tuple compatibility."""
        if isinstance(other, Token):
            return (
                self.type == other.type
                and self.value == other.value
                and self.location == other.location
            )

        if isinstance(other, tuple) and len(other) == 2:
            return self.type == other[0] and self.value == other[1]

        if isinstance(other, list) and len(other) == 2:
            return self.type == other[0] and self.value == other[1]

        return False


class ParseError(ValueError):
    """Raised when token stream cannot be parsed into a valid tree."""

    def __init__(
        self,
        message: str,
        *,
        traceback: Sequence[TraceFrame] | None = None,
        hint: str | None = None,
    ) -> None:
        """Initialize a parse error with traceback metadata."""
        super().__init__(message)
        self.message = message
        self.traceback = list(traceback or [])
        self.hint = hint

    def __str__(self) -> str:
        """Return the human-readable parse error message."""
        return self.message


class TokenType(Enum):
    """Token kinds produced by the tokenizer."""

    NEWLINE = auto()
    BRACE = auto()
    COMMAND = auto()


@dataclass(slots=True)
class Command:
    """Leaf command node."""

    content: list[str] = field(default_factory=list)
    location: SourceLocation | None = field(default=None, repr=False)
    parent: Section | None = field(default=None, repr=False)

    @property
    def name(self) -> str | None:
        """Command name, or None if command has no tokens."""
        return self.content[0] if self.content else None

    @property
    def args(self) -> list[str]:
        """Command arguments (all tokens except name)."""
        return self.content[1:]


@dataclass(slots=True)
class Section:
    """Section node that can contain nested sections and commands."""

    content: list[str] = field(default_factory=list)
    location: SourceLocation | None = field(default=None, repr=False)
    parent: Section | None = field(default=None, repr=False)
    children: list[Section | Command] = field(default_factory=list)

    @property
    def name(self) -> str | None:
        """Section name, or None if section has no tokens."""
        return self.content[0] if self.content else None

    @property
    def args(self) -> list[str]:
        """Section arguments (all tokens except name)."""
        return self.content[1:]

    def add_child(self, item: Section | Command) -> None:
        """Attach a child node and set its parent reference."""
        item.parent = self
        self.children.append(item)

    def get(
        self,
        name: str,
        command: bool = True,
        section: bool = True,
    ) -> Section | Command | None:
        """Return the first child with matching name and type filter."""
        for child in self.children:
            if child.name == name and _child_matches(child, command=command, section=section):
                return child
        return None

    def all(
        self,
        name: str = "",
        command: bool = True,
        section: bool = True,
    ) -> list[Section | Command]:
        """Return all children matching optional name and type filter."""
        result: list[Section | Command] = []
        for child in self.children:
            if (not name or child.name == name) and _child_matches(
                child,
                command=command,
                section=section,
            ):
                result.append(child)
        return result

    def has(self, name: str, command: bool = True, section: bool = True) -> bool:
        """Return True if a matching child exists."""
        return self.get(name=name, command=command, section=section) is not None


def _child_matches(child: Section | Command, *, command: bool, section: bool) -> bool:
    if isinstance(child, Command):
        return command
    return section


def tokenize(text: str, *, source_name: str = "<string>") -> list[Token]:
    """Convert source text into token sequence.

    Rules:
    - braces produce BRACE tokens
    - command words and quoted strings produce COMMAND tokens
    - '#' starts a comment until newline
    - newline produces NEWLINE tokens
    """
    tokens: list[Token] = []
    temp: list[str] = []

    is_string = False
    is_comment = False
    close_char: str | None = None
    token_location: SourceLocation | None = None
    string_location: SourceLocation | None = None

    source_lines = text.splitlines()

    def current_line_text(line_number: int) -> str:
        if 1 <= line_number <= len(source_lines):
            return source_lines[line_number - 1]
        return ""

    def raise_unclosed_string() -> None:
        assert string_location is not None
        raise ParseError(
            "Unclosed string literal",
            traceback=[
                TraceFrame(
                    kind="string",
                    symbol=close_char or '"',
                    location=string_location,
                )
            ],
            hint=f"Close the string with {close_char or '"'} before the line break.",
        )

    def add_temp(token_type: TokenType = TokenType.COMMAND) -> None:
        nonlocal token_location
        if temp or is_string:
            token = "".join(temp).strip()
            if token_location is None:
                token_location = SourceLocation(source_name, 1, 1, current_line_text(1))
            tokens.append(Token(token_type, token, token_location))
            temp.clear()
            token_location = None

    line = 1
    column = 1
    index = 0
    while index < len(text):
        char = text[index]
        line_text = current_line_text(line)

        if is_string:
            if char == "\n":
                raise_unclosed_string()

            if char == close_char:
                if string_location is not None:
                    token_location = string_location
                add_temp()
                is_string = False
                close_char = None
                string_location = None
            else:
                temp.append(char)
            if char == "\n":
                line += 1
                column = 1
            else:
                column += 1
            index += 1
            continue

        if is_comment:
            if char == "\n":
                is_comment = False
                tokens.append(
                    Token(
                        TokenType.NEWLINE,
                        "\n",
                        SourceLocation(source_name, line, column, line_text),
                    )
                )
                line += 1
            column += 1
            index += 1
            continue

        if char in "{}":
            add_temp()
            tokens.append(
                Token(
                    TokenType.BRACE,
                    char,
                    SourceLocation(source_name, line, column, line_text),
                )
            )
            column += 1
            index += 1
            continue

        if char in {'"', "'", "`"}:
            add_temp()
            is_string = True
            close_char = char
            string_location = SourceLocation(source_name, line, column, line_text)
            column += 1
            index += 1
            continue

        if char == "#":
            add_temp()
            is_comment = True
            column += 1
            index += 1
            continue

        if char == "\n":
            add_temp()
            tokens.append(
                Token(
                    TokenType.NEWLINE,
                    "\n",
                    SourceLocation(source_name, line, column, line_text),
                )
            )
            line += 1
            column = 1
            index += 1
            continue

        if char in {" ", "\t", "\r"}:
            add_temp()
            column += 1
            index += 1
            continue

        if token_location is None:
            token_location = SourceLocation(source_name, line, column, line_text)
        temp.append(char)
        column += 1
        index += 1

    if is_string:
        raise_unclosed_string()

    add_temp()
    return tokens


def parse(tokens: Sequence[Token | tuple[TokenType, str]]) -> Section:
    """Parse token stream into a root Section node."""
    root = Section()
    selected = root
    current: list[str] = []
    current_location: SourceLocation | None = None

    for raw_token in tokens:
        token = _coerce_token(raw_token)
        token_type = token.type
        if token_type == TokenType.BRACE:
            if token.value == "{":
                node = Section(content=list(current), location=current_location or token.location)
                current.clear()
                current_location = None
                selected.add_child(node)
                selected = node
            else:
                if current:
                    selected.add_child(
                        Command(content=list(current), location=current_location or token.location)
                    )
                    current.clear()
                    current_location = None
                if selected.parent is None:
                    raise ParseError(
                        "Unexpected closing brace '}'",
                        traceback=[
                            *_traceback_frames(selected),
                            TraceFrame(kind="token", symbol="}", location=token.location),
                        ],
                        hint="Remove the extra `}` or open a matching `{` first.",
                    )
                selected = selected.parent
            continue

        if token_type == TokenType.COMMAND:
            if not current:
                current_location = token.location
            current.append(token.value)
            continue

        if token_type == TokenType.NEWLINE and current:
            selected.add_child(
                Command(content=list(current), location=current_location or token.location)
            )
            current.clear()
            current_location = None

    if current:
        selected.add_child(Command(content=list(current), location=current_location))

    if selected.parent is not None:
        raise ParseError(
            "Unclosed section block: missing '}'",
            traceback=_traceback_frames(selected),
            hint="Add a closing `}` for the most recent open section.",
        )

    return root


def parse_text(text: str, *, source_name: str = "<string>") -> Section:
    """Parse source text directly into a tree."""
    return parse(tokenize(text, source_name=source_name))


def format_traceback(error: ParseError) -> str:
    """Render a parse error as a Python-style traceback."""
    lines = ["Traceback (most recent call last):"]

    for frame in error.traceback:
        location = frame.location
        symbol = _quote_symbol(frame.symbol)
        lines.append(
            f'  File "{location.source_name}", line {location.line}, column {location.column}, '
            f"in {frame.kind} {symbol}"
        )
        if location.line_text:
            lines.append(f"    {location.line_text}")
            lines.append(f"    {' ' * (location.column - 1)}^")

    lines.append(f"ParseError: {error}")
    if error.hint:
        lines.append(f"Hint: {error.hint}")

    return "\n".join(lines)


def _coerce_token(token: Token | tuple[TokenType, str]) -> Token:
    if isinstance(token, Token):
        return token

    token_type, value = token
    return Token(token_type, value, SourceLocation("<string>", 1, 1, ""))


def _traceback_frames(section: Section) -> list[TraceFrame]:
    frames: list[TraceFrame] = []
    current: Section | None = section

    while current is not None and current.parent is not None:
        if current.location is not None:
            frames.append(
                TraceFrame(
                    kind="section",
                    symbol=_node_symbol(current),
                    location=current.location,
                )
            )
        current = current.parent

    frames.reverse()
    return frames


def _node_symbol(node: Section | Command) -> str:
    parts = [part for part in [node.name, *node.args] if part]
    return " ".join(parts) if parts else "<root>"


def _quote_symbol(symbol: str) -> str:
    if symbol in {'"', "'", "`"}:
        return repr(symbol)
    return f"`{symbol}`"


_SAFE_TOKEN_RE = re.compile(r"^[^\s{}#\"'`]+$")


def format_text(text: str, *, source_name: str = "<string>") -> str:
    """Parse source text and return a normalized KRPG script."""
    return format_section(parse_text(text, source_name=source_name))


def format_section(section: Section) -> str:
    """Serialize a section tree back into KRPG source text."""
    lines: list[str] = []

    def emit_node(node: Section | Command, depth: int) -> None:
        indent = "\t" * depth

        if isinstance(node, Command):
            lines.append(f"{indent}{_format_tokens(node.content)}")
            return

        if node.name is None:
            lines.append(f"{indent}{{")
        else:
            header = _format_tokens(node.content)
            lines.append(f"{indent}{header} {{" if header else f"{indent}{{")

        for child in node.children:
            emit_node(child, depth + 1)

        lines.append(f"{indent}}}")

    for child in section.children:
        emit_node(child, 0)

    return "\n".join(lines) + ("\n" if lines else "")


def node_to_dict(node: Section | Command) -> dict[str, object]:
    """Convert a node tree into a JSON-serializable dictionary."""
    if isinstance(node, Command):
        return {
            "kind": "command",
            "name": node.name,
            "args": list(node.args),
        }

    return {
        "kind": "section",
        "name": node.name,
        "args": list(node.args),
        "children": [node_to_dict(child) for child in node.children],
    }


def section_to_json(section: Section, *, indent: int = 2) -> str:
    """Serialize a parsed tree into formatted JSON."""
    return json.dumps(node_to_dict(section), ensure_ascii=False, indent=indent)


def _format_tokens(tokens: Sequence[str]) -> str:
    return " ".join(_format_token(token) for token in tokens)


def _format_token(token: str) -> str:
    if token and _SAFE_TOKEN_RE.fullmatch(token):
        return token

    for quote in ('"', "'", "`"):
        if quote not in token:
            return f"{quote}{token}{quote}"

    raise ValueError(f"Cannot format token containing all quote types: {token!r}")
