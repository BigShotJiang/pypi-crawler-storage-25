"""Compatibility wrapper for the KRPGScript command line entry point."""

from krpgscript.cli import main

if __name__ == "__main__":
    main()
