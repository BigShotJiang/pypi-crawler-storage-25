"""Command line interface for KRPGScript."""

from __future__ import annotations

import argparse
import glob
import json
import sys
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

from krpgscript.parser import (
    Command,
    ParseError,
    Section,
    format_text,
    format_traceback,
    node_to_dict,
    parse_text,
)
from krpgscript.semantic import (
    ArgumentDef,
    ChildRule,
    CommandDef,
    NodeDef,
    SectionDef,
    SemanticAnnotation,
    SemanticError,
    ValueType,
    build_semantic_annotations,
    compile_project,
    format_semantic_traceback,
    load_project_schema,
)

_SCRIPT_SUFFIX = ".krpg"
_TREE_TOKEN_COLLAPSE_THRESHOLD = 24
_TREE_TOKEN_EDGE = 8

_ANSI_RESET = "\033[0m"
_ANSI_DARK_GRAY = "\033[90m"
_ANSI_NAME = "\033[38;5;205m"
_ANSI_STRING = "\033[38;5;39m"
_ANSI_QUOTED_STRING = "\033[38;5;48m"
_ANSI_INT = "\033[38;5;221m"
_ANSI_FLOAT = "\033[38;5;213m"
_ANSI_BOOL = "\033[38;5;51m"
_ANSI_ENUM = _ANSI_INT


def build_parser() -> argparse.ArgumentParser:
    """Build the KRPGScript CLI argument parser."""
    parser = argparse.ArgumentParser(prog="krpgscript")
    subparsers = parser.add_subparsers(dest="command", required=True)

    check_parser = subparsers.add_parser("check", help="validate KRPG syntax")
    check_parser.add_argument(
        "paths",
        nargs="+",
        help="source file, directory, or glob pattern to validate",
    )

    format_parser = subparsers.add_parser("format", help="format KRPG source in place")
    format_parser.add_argument(
        "paths",
        nargs="+",
        help="source file, directory, or glob pattern to format",
    )

    json_parser = subparsers.add_parser("json", help="export KRPG tree to JSON")
    json_parser.add_argument(
        "paths",
        nargs="+",
        help="source file, directory, or glob pattern to export",
    )
    json_parser.add_argument("-o", "--output", type=Path, help="output JSON file")

    tree_parser = subparsers.add_parser("tree", help="print KRPG tree")
    tree_parser.add_argument(
        "paths",
        nargs="+",
        help="source file, directory, or glob pattern to render",
    )
    tree_parser.add_argument(
        "-semantic",
        "--semantic",
        action="store_true",
        help="include semantic argument type annotations",
    )
    tree_parser.add_argument(
        "--no-color",
        action="store_true",
        help="disable ANSI color output",
    )

    defs_parser = subparsers.add_parser("defs", help="print loaded KRPG schema definitions")
    defs_parser.add_argument(
        "paths",
        nargs="+",
        help="source file, directory, or glob pattern to inspect",
    )

    return parser


def run(argv: Sequence[str] | None = None) -> int:
    """Run the CLI and return an exit code."""
    parser = build_parser()
    args = parser.parse_args(argv)

    paths = _resolve_paths(args.paths, parser)

    if args.command == "check":
        return _run_check(paths)

    if args.command == "format":
        return _run_format(paths)

    if args.command == "json":
        return _run_json(paths, args.output)

    if args.command == "tree":
        return _run_tree(paths, args.semantic, no_color=args.no_color)

    if args.command == "defs":
        return _run_defs(paths)

    parser.exit(2, "Unknown command\n")
    return 2


def main() -> None:
    """Entry point for the installed console script."""
    raise SystemExit(run())


def _run_check(paths: list[Path]) -> int:
    errors: list[str] = []

    for path in paths:
        try:
            compile_project(path)
        except (OSError, ParseError, SemanticError, ValueError) as error:
            if isinstance(error, ParseError):
                errors.append(format_traceback(error))
            elif isinstance(error, SemanticError):
                errors.append(format_semantic_traceback(error))
            else:
                errors.append(f"{path}: {error}")
            continue

        print(f"OK: {path}")

    if errors:
        for error in errors:
            print(error, file=sys.stderr)
        return 1

    return 0


def _run_format(paths: list[Path]) -> int:
    errors: list[str] = []

    for path in paths:
        try:
            source = path.read_text(encoding="utf-8")
            formatted = format_text(source, source_name=str(path))
            if formatted != source:
                path.write_text(formatted, encoding="utf-8")
                print(f"Formatted: {path}")
            else:
                print(f"Unchanged: {path}")
        except (OSError, ParseError, ValueError) as error:
            if isinstance(error, ParseError):
                errors.append(format_traceback(error))
            else:
                errors.append(f"{path}: {error}")

    if errors:
        for error in errors:
            print(error, file=sys.stderr)
        return 1

    return 0


def _run_json(paths: list[Path], output: Path | None) -> int:
    trees: list[dict[str, object]] = []
    errors: list[str] = []

    for path in paths:
        try:
            root = compile_project(path).root
        except (OSError, ParseError, SemanticError, ValueError) as error:
            if isinstance(error, ParseError):
                errors.append(format_traceback(error))
            elif isinstance(error, SemanticError):
                errors.append(format_semantic_traceback(error))
            else:
                errors.append(f"{path}: {error}")
            continue

        trees.append({"path": str(path), "tree": node_to_dict(root)})

    if errors:
        for error in errors:
            print(error, file=sys.stderr)
        return 1

    payload: object = trees[0]["tree"] if len(trees) == 1 else trees

    data = json.dumps(payload, ensure_ascii=False, indent=2)
    if output is None:
        print(data)
    else:
        output.write_text(data + "\n", encoding="utf-8")
        print(f"Wrote: {output}")

    return 0


def _run_tree(paths: list[Path], semantic: bool, *, no_color: bool) -> int:
    errors: list[str] = []
    rendered: list[str] = []

    for path in paths:
        try:
            if semantic:
                project = compile_project(path)
                root = project.root
                annotations = build_semantic_annotations(root, project.schema_registry)
            else:
                source = path.read_text(encoding="utf-8")
                root = parse_text(source, source_name=str(path))
                annotations = {}
        except (OSError, ParseError, SemanticError, ValueError) as error:
            if isinstance(error, ParseError):
                errors.append(format_traceback(error))
            elif isinstance(error, SemanticError):
                errors.append(format_semantic_traceback(error))
            else:
                errors.append(f"{path}: {error}")
            continue

        lines = [str(path)]
        lines.extend(_render_tree_lines(root, annotations=annotations, use_color=not no_color))
        rendered.append("\n".join(lines))

    if errors:
        for error in errors:
            print(error, file=sys.stderr)
        return 1

    print("\n\n".join(rendered))
    return 0


def _run_defs(paths: list[Path]) -> int:
    errors: list[str] = []
    rendered: list[str] = []

    for path in paths:
        try:
            registry = load_project_schema(path)
        except (OSError, ParseError, SemanticError, ValueError) as error:
            if isinstance(error, ParseError):
                errors.append(format_traceback(error))
            elif isinstance(error, SemanticError):
                errors.append(format_semantic_traceback(error))
            else:
                errors.append(f"{path}: {error}")
            continue

        lines = [str(path)]
        lines.extend(_render_loaded_definitions(registry))
        rendered.append("\n".join(lines))

    if errors:
        for error in errors:
            print(error, file=sys.stderr)
        return 1

    print("\n\n".join(rendered))
    return 0


def _render_loaded_definitions(registry: dict[str, NodeDef]) -> list[str]:
    if not registry:
        return ["<no schema definitions loaded>"]

    lines: list[str] = []
    definitions = _collect_all_definitions(registry)

    for index, (label, node_def) in enumerate(definitions):
        lines.extend(_render_definition_block(label, node_def, registry=registry))
        if index != len(definitions) - 1:
            lines.append("")

    return lines


def _collect_all_definitions(registry: dict[str, NodeDef]) -> list[tuple[str, NodeDef]]:
    seen: set[int] = set()
    collected: list[tuple[str, NodeDef]] = []

    def visit(label: str, node_def: NodeDef) -> None:
        identity = id(node_def)
        if identity in seen:
            return
        seen.add(identity)
        collected.append((label, node_def))

        if isinstance(node_def, SectionDef):
            for local_name in sorted(node_def.local_scope):
                visit(f"{label}.{local_name}", node_def.local_scope[local_name])

    for name in sorted(registry):
        visit(name, registry[name])

    return collected


def _render_definition_block(
    label: str,
    node_def: NodeDef,
    *,
    registry: dict[str, NodeDef],
) -> list[str]:
    header = f"[{label}]"
    signature = _format_definition_signature(node_def)

    if isinstance(node_def, CommandDef):
        return [header, signature]

    if not isinstance(node_def, SectionDef):
        return [header, signature]

    lines = [header, f"{signature} {{"]
    for rule in node_def.allowed_children:
        lines.append(
            f"    {_format_child_rule_signature(rule, node_def=node_def, registry=registry)}"
        )
    lines.append("}")
    return lines


def _format_definition_signature(node_def: NodeDef) -> str:
    name = _apply_name_modifiers(
        node_def.name,
        is_anonymous=node_def.is_anonymous,
        is_optional=node_def.is_optional,
        is_repeatable=node_def.is_repeatable,
    )
    args = " ".join(_describe_argument_type(argument) for argument in node_def.args)
    if args:
        return f"{name} {args}"
    return name


def _format_child_rule_signature(
    rule: ChildRule,
    *,
    node_def: SectionDef,
    registry: dict[str, NodeDef],
) -> str:
    if rule.is_mixin:
        return f":{rule.name}"

    name = _apply_name_modifiers(
        rule.name,
        is_anonymous=rule.is_anonymous,
        is_optional=rule.is_optional,
        is_repeatable=rule.is_repeatable,
    )

    target = _resolve_child_rule_target(rule, node_def=node_def, registry=registry)
    if target is None:
        return name

    args = " ".join(_describe_argument_type(argument) for argument in target.args)
    section_tail = " {}" if isinstance(target, SectionDef) else ""
    if args:
        return f"{name} {args}{section_tail}"
    return f"{name}{section_tail}"


def _resolve_child_rule_target(
    rule: ChildRule,
    *,
    node_def: SectionDef,
    registry: dict[str, NodeDef],
) -> NodeDef | None:
    if rule.node_def is not None:
        return rule.node_def

    if rule.name in node_def.local_scope:
        return node_def.local_scope[rule.name]

    return registry.get(rule.name)


def _apply_name_modifiers(
    name: str,
    *,
    is_anonymous: bool,
    is_optional: bool,
    is_repeatable: bool,
) -> str:
    result = name
    if is_anonymous:
        result += "*"
    if is_optional:
        result += "?"
    if is_repeatable:
        result += "..."
    return result


def _render_tree_lines(
    root: Section,
    *,
    annotations: dict[int, SemanticAnnotation],
    use_color: bool,
) -> list[str]:
    lines: list[str] = []
    children = root.children
    for index, child in enumerate(children):
        is_last = index == len(children) - 1
        lines.extend(
            _render_node_lines(
                child,
                prefix="",
                is_last=is_last,
                annotations=annotations,
                use_color=use_color,
            )
        )
    return lines


def _render_node_lines(
    node: Section | Command,
    *,
    prefix: str,
    is_last: bool,
    annotations: dict[int, SemanticAnnotation],
    use_color: bool,
) -> list[str]:
    branch = "└── " if is_last else "├── "
    branch_prefix = _tree_segment(prefix + branch, use_color=use_color)
    lines = [f"{branch_prefix}{_node_label(node, annotations=annotations, use_color=use_color)}"]

    annotation = annotations.get(id(node))
    if annotation:
        semantic_prefix = _tree_segment(
            prefix + ("    " if is_last else "│   "), use_color=use_color
        )
        if annotation.arg_types:
            suffix = _format_semantic_suffix(annotation.arg_types, use_color=use_color)
            lines[0] = f"{lines[0]} {suffix}"

        child_lines = _limit_child_annotations(annotation.children)
        for child_annotation in child_lines.annotations:
            semantic_label = _tree_segment(f"⟶ {child_annotation}", use_color=use_color)
            lines.append(f"{semantic_prefix}{semantic_label}")
        if child_lines.remaining > 0:
            summary = f"⟶ {child_lines.first} and {child_lines.remaining} others..."
            lines.append(f"{semantic_prefix}{_tree_segment(summary, use_color=use_color)}")

    if isinstance(node, Section) and node.children:
        child_prefix = f"{prefix}{'    ' if is_last else '│   '}"
        for index, child in enumerate(node.children):
            child_is_last = index == len(node.children) - 1
            lines.extend(
                _render_node_lines(
                    child,
                    prefix=child_prefix,
                    is_last=child_is_last,
                    annotations=annotations,
                    use_color=use_color,
                )
            )

    return lines


def _node_label(
    node: Section | Command,
    *,
    annotations: dict[int, SemanticAnnotation],
    use_color: bool,
) -> str:
    if not node.content:
        return _colorize("<root>", _ANSI_NAME, use_color=use_color)

    annotation = annotations.get(id(node))
    arg_types = annotation.arg_types if annotation is not None else ()

    name = _collapse_tree_token(str(node.content[0]))
    parts = [_colorize(name, _ANSI_NAME, use_color=use_color)]
    for index, token in enumerate(node.content[1:]):
        arg_type = arg_types[index] if index < len(arg_types) else None
        parts.append(_format_arg_token(str(token), use_color=use_color, arg_type=arg_type))

    label = " ".join(parts)
    if isinstance(node, Section) and not node.children:
        label = f"{label} {_tree_segment('{}', use_color=use_color)}"
    return label


def _format_arg_token(token: str, *, use_color: bool, arg_type: ArgumentDef | None = None) -> str:
    collapsed = _collapse_tree_token(token)
    if arg_type is not None:
        if arg_type.value_type is ValueType.INT:
            return _colorize(collapsed, _ANSI_INT, use_color=use_color)
        if arg_type.value_type is ValueType.FLOAT:
            return _colorize(collapsed, _ANSI_FLOAT, use_color=use_color)
        if arg_type.value_type is ValueType.BOOL:
            return _colorize(collapsed, _ANSI_BOOL, use_color=use_color)
        if arg_type.value_type is ValueType.ENUM:
            return _colorize(collapsed, _ANSI_ENUM, use_color=use_color)

    if _is_int_token(token):
        return _colorize(collapsed, _ANSI_INT, use_color=use_color)
    if _is_float_token(token):
        return _colorize(collapsed, _ANSI_FLOAT, use_color=use_color)
    if _is_bool_token(token):
        return _colorize(collapsed, _ANSI_BOOL, use_color=use_color)

    text = collapsed
    if not token or any(char.isspace() for char in token):
        text = _quote_token(collapsed)
        return _colorize(text, _ANSI_QUOTED_STRING, use_color=use_color)
    return _colorize(text, _ANSI_STRING, use_color=use_color)


def _quote_token(token: str) -> str:
    for quote in ('"', "'", "`"):
        if quote not in token:
            return f"{quote}{token}{quote}"
    return f'"{token}"'


def _tree_segment(text: str, *, use_color: bool) -> str:
    return _colorize(text, _ANSI_DARK_GRAY, use_color=use_color)


def _colorize(text: str, color: str, *, use_color: bool) -> str:
    if not use_color:
        return text
    return f"{color}{text}{_ANSI_RESET}"


def _collapse_tree_token(token: str) -> str:
    if len(token) <= _TREE_TOKEN_COLLAPSE_THRESHOLD:
        return token
    return f"{token[:_TREE_TOKEN_EDGE]}...{token[-_TREE_TOKEN_EDGE:]}"


def _is_int_token(token: str) -> bool:
    if not token:
        return False
    if token[0] in {"+", "-"}:
        return token[1:].isdigit()
    return token.isdigit()


def _is_float_token(token: str) -> bool:
    if not token or token.count(".") != 1:
        return False
    try:
        float(token)
    except ValueError:
        return False
    return True


def _is_bool_token(token: str) -> bool:
    lowered = token.lower()
    return lowered in {"true", "false"}


def _format_semantic_suffix(arg_types: tuple[ArgumentDef, ...], *, use_color: bool) -> str:
    text = "(" + " ".join(_describe_argument_type(argument) for argument in arg_types) + ")"
    return _tree_segment(text, use_color=use_color)


def _limit_child_annotations(children: tuple[str, ...]) -> _ChildAnnotationSlice:
    if not children:
        return _ChildAnnotationSlice((), "", 0)

    shown = children[:3]
    remaining = max(0, len(children) - len(shown))
    first = shown[0] if shown else ""
    return _ChildAnnotationSlice(shown, first, remaining)


@dataclass(slots=True, frozen=True)
class _ChildAnnotationSlice:
    annotations: tuple[str, ...]
    first: str
    remaining: int


def _describe_argument_type(argument: ArgumentDef) -> str:
    if argument.value_type is ValueType.ENUM:
        base = f"enum:{','.join(argument.enum_values)}"
    elif (
        argument.value_type is ValueType.INT
        and argument.minimum is not None
        and argument.maximum is not None
    ):
        base = f"int:{int(argument.minimum)}:{int(argument.maximum)}"
    elif (
        argument.value_type is ValueType.FLOAT
        and argument.minimum is not None
        and argument.maximum is not None
    ):
        base = f"float:{argument.minimum}:{argument.maximum}"
    else:
        base = argument.value_type.value

    if argument.is_optional:
        base += "?"
    if argument.is_vararg:
        base += "..."
    return base


def _resolve_paths(raw_paths: Sequence[str], parser: argparse.ArgumentParser) -> list[Path]:
    resolved: list[Path] = []
    seen: set[Path] = set()

    for raw_path in raw_paths:
        expanded = _expand_path(raw_path)
        for path in expanded:
            normalized = path.expanduser().absolute()
            if normalized in seen:
                continue

            seen.add(normalized)
            resolved.append(normalized)

    if not resolved:
        parser.exit(1, "No KRPG files matched\n")

    return resolved


def _expand_path(raw_path: str) -> list[Path]:
    candidate = Path(raw_path).expanduser()

    if _has_glob(raw_path):
        matches = [Path(match) for match in glob.glob(raw_path, recursive=True)]
        return _collect_krpg_files(matches)

    if candidate.is_dir():
        return sorted(path for path in candidate.rglob(f"*{_SCRIPT_SUFFIX}") if path.is_file())

    if candidate.is_file() and candidate.suffix == _SCRIPT_SUFFIX:
        return [candidate]

    return []


def _collect_krpg_files(paths: list[Path]) -> list[Path]:
    collected: list[Path] = []

    for path in paths:
        if path.is_dir():
            collected.extend(
                sorted(item for item in path.rglob(f"*{_SCRIPT_SUFFIX}") if item.is_file())
            )
            continue

        if path.is_file() and path.suffix == _SCRIPT_SUFFIX:
            collected.append(path)

    return collected


def _has_glob(raw_path: str) -> bool:
    return any(char in raw_path for char in "*?[")
