from __future__ import annotations

from pathlib import Path

import pytest
from krpgscript import compile_project
from krpgscript.parser import parse_text
from krpgscript.semantic import SemanticError, compile_schema


def _write(path: Path, content: str) -> None:
    path.write_text(content.strip() + "\n", encoding="utf-8")


def _compile_with_item_mode(tmp_path: Path, mode: str, items_body: str) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        f"""
        root {{
            items
        }}
        items {{
            item{mode} string
        }}
        """,
    )

    _write(
        script,
        f"""
        !include types.krpg
        items {{
            {items_body}
        }}
        """,
    )

    compile_project(script)


def test_modifier_order_strict_star_question_ellipsis() -> None:
    compile_schema(parse_text("root {\n  item*?...\n}\n"))

    with pytest.raises(SemanticError, match="Invalid name modifier order"):
        compile_schema(parse_text("root {\n  item...?*\n}\n"))

    with pytest.raises(SemanticError, match="Invalid name modifier order"):
        compile_schema(parse_text("root {\n  item?*...\n}\n"))

    with pytest.raises(SemanticError, match="Invalid name modifier order"):
        compile_schema(parse_text("root {\n  item*...?\n}\n"))


def test_anonymous_mode_item_star_requires_exactly_one(tmp_path: Path) -> None:
    _compile_with_item_mode(tmp_path, "*", 'blade "ok"')

    with pytest.raises(SemanticError, match=r"Missing required node `item\*`"):
        _compile_with_item_mode(tmp_path, "*", "")

    with pytest.raises(SemanticError, match="appears more than once"):
        _compile_with_item_mode(tmp_path, "*", 'blade "a"\naxe "b"')


def test_anonymous_mode_item_star_question_zero_or_one(tmp_path: Path) -> None:
    _compile_with_item_mode(tmp_path, "*?", "")
    _compile_with_item_mode(tmp_path, "*?", 'blade "ok"')

    with pytest.raises(SemanticError, match="appears more than once"):
        _compile_with_item_mode(tmp_path, "*?", 'blade "a"\naxe "b"')


def test_anonymous_mode_item_star_ellipsis_one_or_more(tmp_path: Path) -> None:
    _compile_with_item_mode(tmp_path, "*...", 'blade "ok"')
    _compile_with_item_mode(tmp_path, "*...", 'blade "a"\naxe "b"')

    with pytest.raises(SemanticError, match=r"Missing required node `item\*`"):
        _compile_with_item_mode(tmp_path, "*...", "")


def test_anonymous_mode_item_star_question_ellipsis_zero_or_more(tmp_path: Path) -> None:
    _compile_with_item_mode(tmp_path, "*?...", "")
    _compile_with_item_mode(tmp_path, "*?...", 'blade "a"\naxe "b"')


def test_exact_match_has_priority_over_anonymous(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script_ok = tmp_path / "ok.krpg"
    script_bad = tmp_path / "bad.krpg"

    _write(
        schema,
        """
        root {
            items
        }
        blade int
        items {
            blade
            item*... bool
        }
        """,
    )

    _write(
        script_ok,
        """
        !include types.krpg
        items {
            blade 10
            sword true
        }
        """,
    )
    compile_project(script_ok)

    _write(
        script_bad,
        """
        !include types.krpg
        items {
            blade nope
        }
        """,
    )
    with pytest.raises(SemanticError, match="Expected int"):
        compile_project(script_bad)
