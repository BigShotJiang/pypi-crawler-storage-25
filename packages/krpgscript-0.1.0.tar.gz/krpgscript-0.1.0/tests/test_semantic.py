from __future__ import annotations

from pathlib import Path

import pytest
from krpgscript import Command, Section, compile_project
from krpgscript.parser import parse_text
from krpgscript.semantic import SemanticError, compile_schema


def _write(path: Path, content: str) -> None:
    path.write_text(content.strip() + "\n", encoding="utf-8")


def test_include_schema_and_type_coercion(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        """
        root {
            init
        }
        init {
            pass int
        }
        """,
    )

    _write(
        script,
        """
        !include types.krpg
        init {
            pass 1
        }
        """,
    )

    project = compile_project(script)
    init = project.root.get("init", command=False, section=True)
    assert isinstance(init, Section)

    command = init.get("pass", command=True, section=False)
    assert isinstance(command, Command)
    assert command.args[0] == 1


def test_overloaded_child_name_command_and_section(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        """
        root {
            action
        }
        say string...
        require ...
        action {
            require?... ...
            require?... ... {
                say...
            }
        }
        """,
    )

    _write(
        script,
        """
        !include types.krpg
        action {
            require quest alpha stage 1
            require quest alpha stage 1 {
                say done
            }
        }
        """,
    )

    project = compile_project(script)
    action = project.root.get("action", command=False, section=True)
    assert isinstance(action, Section)
    assert action.has("require", command=True, section=False)
    assert action.has("require", command=False, section=True)


def test_anonymous_section_uses_identifier_when_needed(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        """
        root {
            items
        }
        stack int:0:10
        items {
            item*... string string {
                stack?...
            }
        }
        """,
    )

    _write(
        script,
        """
        !include types.krpg
        items {
            blade "Нож" {
                stack 3
            }
        }
        """,
    )

    project = compile_project(script)
    items = project.root.get("items", command=False, section=True)
    assert isinstance(items, Section)

    blade = items.get("blade", command=False, section=True)
    assert isinstance(blade, Section)

    stack = blade.get("stack", command=True, section=False)
    assert isinstance(stack, Command)
    assert stack.args[0] == 3


def test_anonymous_section_rejects_extra_args_after_identifier(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        """
        root {
            items
        }
        items {
            item*... string string string {
            }
        }
        """,
    )

    _write(
        script,
        """
        !include types.krpg
        items {
            sword Sword Desc ERROR {
            }
        }
        """,
    )

    with pytest.raises(SemanticError, match="Too many arguments for node"):
        compile_project(script)


def test_real_bs_script_is_semantically_valid_and_typed() -> None:
    script = Path("examples/bs/main.krpg")

    project = compile_project(script)

    init = project.root.get("init", command=False, section=True)
    assert isinstance(init, Section)
    pass_command = init.get("pass", command=True, section=False)
    assert isinstance(pass_command, Command)
    assert pass_command.args[0] == 1

    items = project.root.get("items", command=False, section=True)
    assert isinstance(items, Section)
    throwing_knife = items.get("throwing_knife", command=False, section=True)
    assert isinstance(throwing_knife, Section)
    stack = throwing_knife.get("stack", command=True, section=False)
    assert isinstance(stack, Command)
    assert stack.args[0] == 10


def test_import_without_bang_is_regular_command_and_fails_schema_validation(
    tmp_path: Path,
) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        """
        root {
            init
        }
        init {
            pass int
        }
        """,
    )

    _write(
        script,
        """
        !include types.krpg
        init {
            import schema.krpgd
            pass 1
        }
        """,
    )

    with pytest.raises(SemanticError, match="Unknown node `import`"):
        compile_project(script)


def test_directive_requires_argument(tmp_path: Path) -> None:
    script = tmp_path / "main.krpg"
    _write(script, "!import")

    with pytest.raises(SemanticError, match="expects exactly one path argument"):
        compile_project(script)


def test_flag_order_validation() -> None:
    broken_one = parse_text("root {\n  item...?*\n}\n")
    broken_two = parse_text("root {\n  item?*...\n}\n")
    valid = parse_text("root {\n  item*?...\n}\n")

    with pytest.raises(SemanticError, match="Invalid name modifier order"):
        compile_schema(broken_one)

    with pytest.raises(SemanticError, match="Invalid name modifier order"):
        compile_schema(broken_two)

    compile_schema(valid)


def test_single_and_combined_flags_are_supported() -> None:
    compile_schema(parse_text("root {\n  item*\n}\n"))
    compile_schema(parse_text("root {\n  item?\n}\n"))
    compile_schema(parse_text("root {\n  item...\n}\n"))
    compile_schema(parse_text("root {\n  item*...\n}\n"))
    compile_schema(parse_text("root {\n  item?...\n}\n"))


def test_numeric_range_and_enum_validation(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    ok_script = tmp_path / "ok.krpg"
    bad_script = tmp_path / "bad.krpg"

    _write(
        schema,
        """
        root {
            val
            slot
        }
        val int:0:100
        slot enum:HEAD,BODY
        """,
    )

    _write(
        ok_script,
        """
        !include types.krpg
        val 100
        slot BODY
        """,
    )

    _write(
        bad_script,
        """
        !include types.krpg
        val 101
        slot LEGS
        """,
    )

    compile_project(ok_script)
    with pytest.raises(SemanticError, match="above maximum"):
        compile_project(bad_script)


def test_bool_and_float_validation(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    ok_script = tmp_path / "ok.krpg"
    bad_script = tmp_path / "bad.krpg"

    _write(
        schema,
        """
        root {
            flag
            speed
        }
        flag bool
        speed float
        """,
    )

    _write(
        ok_script,
        """
        !include types.krpg
        flag true
        speed 1.25
        """,
    )
    _write(
        bad_script,
        """
        !include types.krpg
        flag maybe
        speed nope
        """,
    )

    project = compile_project(ok_script)
    flag = project.root.get("flag", command=True, section=False)
    speed = project.root.get("speed", command=True, section=False)
    assert isinstance(flag, Command)
    assert isinstance(speed, Command)
    assert flag.args[0] is True
    assert isinstance(speed.args[0], float)

    with pytest.raises(SemanticError, match="Expected bool"):
        compile_project(bad_script)


def test_required_optional_and_vararg_arguments(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    _write(
        schema,
        """
        root {
            cmd
            print
            loose
        }
        cmd string int?
        print string...
        loose ...
        """,
    )

    ok_one = tmp_path / "ok1.krpg"
    _write(ok_one, '!include types.krpg\ncmd test\nprint a b c\nloose 1 2 "true"\n')
    compile_project(ok_one)

    ok_two = tmp_path / "ok2.krpg"
    _write(ok_two, "!include types.krpg\ncmd test 10\nprint alpha\nloose\n")
    compile_project(ok_two)

    bad = tmp_path / "bad.krpg"
    _write(bad, "!include types.krpg\ncmd\n")
    with pytest.raises(SemanticError, match="Not enough arguments"):
        compile_project(bad)


def test_argument_order_rules_are_enforced() -> None:
    bad_optional_then_required = parse_text("cmd int? string\n")
    bad_after_vararg = parse_text("cmd ... int\n")
    good = parse_text("cmd string int? ...\n")

    with pytest.raises(SemanticError, match="Required arguments cannot appear after optional"):
        compile_schema(bad_optional_then_required)

    with pytest.raises(SemanticError, match=r"Vararg argument .* last"):
        compile_schema(bad_after_vararg)

    compile_schema(good)


def test_root_constraints() -> None:
    with pytest.raises(SemanticError, match="more than once"):
        compile_schema(parse_text("root {}\nroot {}\n"))

    with pytest.raises(SemanticError, match=r"root.*arguments"):
        compile_schema(parse_text("root string {}\n"))


def test_shadowing_local_definition_overrides_global(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        """
        root {
            cmd
            sect
        }
        cmd string
        sect {
            cmd int
        }
        """,
    )

    _write(
        script,
        """
        !include types.krpg
        cmd hi
        sect {
            cmd 1
        }
        """,
    )

    compile_project(script)

    bad = tmp_path / "bad.krpg"
    _write(
        bad,
        """
        !include types.krpg
        sect {
            cmd hi
        }
        """,
    )

    with pytest.raises(SemanticError, match="Expected int"):
        compile_project(bad)


def test_group_mixin_and_circular_group_detection(tmp_path: Path) -> None:
    ok_schema = tmp_path / "ok_types.krpg"
    ok_script = tmp_path / "ok.krpg"

    _write(
        ok_schema,
        """
        root {
            action
        }
        say string...
        cmd1 string
        group_base {
            say...
        }
        group_extra {
            :group_base
            cmd1?
        }
        action {
            :group_extra
        }
        """,
    )
    _write(ok_script, "!include ok_types.krpg\naction {\n  say hi\n}\n")
    compile_project(ok_script)

    bad_schema = parse_text(
        """
        a {
            :b
        }
        b {
            :a
        }
        root {
            :a
        }
        """
    )
    registry = compile_schema(bad_schema)
    bad_script = tmp_path / "bad.krpg"
    _write(bad_script, "")

    with pytest.raises(SemanticError, match="Circular mixin reference"):
        from krpgscript.semantic import validate_tree

        validate_tree(Section(), registry)


def test_anonymous_priority_and_uniqueness() -> None:
    compile_schema(
        parse_text(
            """
            blade string
            items {
                blade
                item*...
            }
            root {
                items
            }
            """
        )
    )

    with pytest.raises(SemanticError, match="more than one anonymous"):
        compile_schema(
            parse_text(
                """
                sect {
                    type1*
                    type2*
                }
                """
            )
        )


def test_command_vs_section_strictness(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    command_as_section = tmp_path / "bad1.krpg"
    section_as_command = tmp_path / "bad2.krpg"

    _write(
        schema,
        """
        root {
            cmd
            sect
        }
        cmd string
        sect {
            ...
        }
        """,
    )

    _write(command_as_section, '!include types.krpg\ncmd "s" {}\n')
    _write(section_as_command, "!include types.krpg\nsect\n")

    with pytest.raises(SemanticError, match="must be a command"):
        compile_project(command_as_section)

    with pytest.raises(SemanticError, match="must be a section"):
        compile_project(section_as_command)


def test_optional_repeatable_semantics(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    _write(
        schema,
        """
        root {
            once?
            many...
            maybe?...
        }
        once string
        many string
        maybe string
        """,
    )

    ok = tmp_path / "ok.krpg"
    _write(ok, "!include types.krpg\nmany a\n")
    compile_project(ok)

    bad_repeat = tmp_path / "bad_repeat.krpg"
    _write(bad_repeat, "!include types.krpg\nonce a\nonce b\nmany a\n")
    with pytest.raises(SemanticError, match="more than once"):
        compile_project(bad_repeat)

    bad_missing_many = tmp_path / "bad_missing_many.krpg"
    _write(bad_missing_many, "!include types.krpg\n")
    with pytest.raises(SemanticError, match="Missing required node `many`"):
        compile_project(bad_missing_many)


def test_ambiguity_with_optional_prefix_is_strict_order(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"
    _write(
        schema,
        """
        root {
            test
        }
        test string? int?
        """,
    )
    _write(script, "!include types.krpg\ntest 123\n")

    project = compile_project(script)
    test_cmd = project.root.get("test", command=True, section=False)
    assert isinstance(test_cmd, Command)
    assert test_cmd.args == ["123"]


def test_deep_scope_group_resolution(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"
    _write(
        schema,
        """
        say string
        group {
            say
        }
        root {
            quest*... string string {
                step*... string string {
                    :group
                }
            }
        }
        """,
    )
    _write(
        script,
        """
        !include types.krpg
        q1 "Quest" {
            s1 "Step" {
                say ok
            }
        }
        """,
    )
    compile_project(script)


def test_schema_import_cycle_and_duplicate_names_last_wins(tmp_path: Path) -> None:
    a = tmp_path / "a.krpgd"
    b = tmp_path / "b.krpgd"
    main = tmp_path / "main.krpg"

    _write(
        a,
        """
        !import "b.krpgd"
        root {
            val
        }
        val int
        """,
    )
    _write(
        b,
        """
        !import "a.krpgd"
        val string
        """,
    )
    _write(main, '!import "a.krpgd"\nval 1\n')

    with pytest.raises(SemanticError, match="Circular"):
        compile_project(main)

    c = tmp_path / "c.krpgd"
    d = tmp_path / "d.krpgd"
    main2 = tmp_path / "main2.krpg"
    _write(c, "val string\n")
    _write(
        d,
        """
        root {
            val
        }
        val int
        """,
    )
    _write(
        main2,
        '!import "c.krpgd"\n!import "d.krpgd"\nval 10\n',
    )

    project = compile_project(main2)
    val = project.root.get("val", command=True, section=False)
    assert isinstance(val, Command)
    assert val.args[0] == 10


def test_schema_rejects_anonymous_and_wildcard_together() -> None:
    with pytest.raises(SemanticError, match="anonymous children"):
        compile_schema(
            parse_text(
                """
                sect {
                    item*
                    ...
                }
                """
            )
        )


def test_duplicate_mixin_reference_is_ignored_without_error(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        """
        say string
        cmds {
            say...
        }
        root {
            :cmds
            :cmds
        }
        """,
    )
    _write(script, "!include types.krpg\nsay ok\n")

    compile_project(script)


def test_indirect_mixin_cycle_is_detected(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        """
        A {
            :B
        }
        B {
            :C
        }
        C {
            :A
        }
        root {
            :A
        }
        """,
    )
    _write(script, "!include types.krpg\n")

    with pytest.raises(SemanticError, match="Circular mixin reference"):
        compile_project(script)


def test_invalid_enum_and_range_schema_forms() -> None:
    with pytest.raises(SemanticError, match="at least one"):
        compile_schema(parse_text("val enum:\n"))

    with pytest.raises(SemanticError, match="empty value"):
        compile_schema(parse_text("val enum:A, ,B\n"))

    with pytest.raises(SemanticError, match="min cannot be greater than max"):
        compile_schema(parse_text("val int:100:0\n"))

    with pytest.raises(SemanticError, match="int:min:max"):
        compile_schema(parse_text("val int:10\n"))

    with pytest.raises(SemanticError, match="valid numbers"):
        compile_schema(parse_text("val float:a:b\n"))


def test_nested_required_children_are_enforced(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        """
        root {
            npcs
        }
        action string
        npcs {
            npc*... string string string {
                action...
            }
        }
        """,
    )
    _write(
        script,
        """
        !include types.krpg
        npcs {
            clay "name" "desc" {
            }
        }
        """,
    )

    with pytest.raises(SemanticError, match="Missing required node `action`"):
        compile_project(script)
