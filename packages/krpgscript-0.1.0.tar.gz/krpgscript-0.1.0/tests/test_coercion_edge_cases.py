from __future__ import annotations

from pathlib import Path

import pytest
from krpgscript import Command, compile_project
from krpgscript.semantic import SemanticError


def _write(path: Path, content: str) -> None:
    path.write_text(content.strip() + "\n", encoding="utf-8")


def test_bool_from_numeric_literals(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        """
        root {
            flag
            off
        }
        flag bool
        off bool
        """,
    )
    _write(script, "!include types.krpg\nflag 1\noff 0\n")

    project = compile_project(script)
    flag = project.root.get("flag", command=True, section=False)
    off = project.root.get("off", command=True, section=False)
    assert isinstance(flag, Command)
    assert isinstance(off, Command)
    assert flag.args[0] is True
    assert off.args[0] is False


def test_float_accepts_integer_input(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(schema, "root { speed }\nspeed float\n")
    _write(script, "!include types.krpg\nspeed 10\n")

    project = compile_project(script)
    speed = project.root.get("speed", command=True, section=False)
    assert isinstance(speed, Command)
    assert speed.args[0] == 10.0


def test_untyped_vararg_keeps_everything_as_string(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(schema, "root { print }\nprint ...\n")
    _write(script, "!include types.krpg\nprint 123 True 1.2\n")

    project = compile_project(script)
    command = project.root.get("print", command=True, section=False)
    assert isinstance(command, Command)
    assert command.args == ["123", "True", "1.2"]


def test_optional_arguments_cannot_skip_previous_optional(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(schema, "root { test }\ntest int? string?\n")
    _write(script, '!include types.krpg\ntest "hello"\n')

    with pytest.raises(SemanticError, match="Cannot provide later optional argument"):
        compile_project(script)


def test_int_and_float_boundary_values_are_valid(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        """
        root {
            age_min
            age_max
            speed_min
            speed_max
        }
        age_min int:0:100
        age_max int:0:100
        speed_min float:0:10
        speed_max float:0:10
        """,
    )
    _write(
        script,
        "!include types.krpg\nage_min 0\nage_max 100\nspeed_min 0\nspeed_max 10\n",
    )

    project = compile_project(script)
    age_min = project.root.get("age_min", command=True, section=False)
    age_max = project.root.get("age_max", command=True, section=False)
    speed_min = project.root.get("speed_min", command=True, section=False)
    speed_max = project.root.get("speed_max", command=True, section=False)

    assert isinstance(age_min, Command)
    assert isinstance(age_max, Command)
    assert isinstance(speed_min, Command)
    assert isinstance(speed_max, Command)

    assert age_min.args[0] == 0
    assert age_max.args[0] == 100
    assert speed_min.args[0] == 0.0
    assert speed_max.args[0] == 10.0
