from __future__ import annotations

from pathlib import Path

import pytest
from krpgscript.parser import (
    Command,
    ParseError,
    Section,
    TokenType,
    parse,
    parse_text,
    tokenize,
)


def test_tokenize_quotes_comments_and_braces() -> None:
    text = """
    root {
        say \"hello world\" # comment
        pass 1
    }
    """

    tokens = tokenize(text)

    assert (TokenType.BRACE, "{") in tokens
    assert (TokenType.BRACE, "}") in tokens
    assert (TokenType.COMMAND, "hello world") in tokens
    assert not any(token_value.startswith("#") for _, token_value in tokens)


def test_parse_nested_sections_and_commands() -> None:
    tree = parse_text(
        """
        quests {
            quest main {
                stage 0 {
                    goal run help
                }
            }
        }
        """
    )

    quests = tree.get("quests", command=False, section=True)
    assert isinstance(quests, Section)

    quest = quests.get("quest", command=False, section=True)
    assert isinstance(quest, Section)
    assert quest.args[0] == "main"

    stage = quest.get("stage", command=False, section=True)
    assert isinstance(stage, Section)
    assert stage.args == ["0"]

    goal = stage.get("goal", command=True, section=False)
    assert isinstance(goal, Command)
    assert goal.args == ["run", "help"]


def test_parse_example_krpg_script() -> None:
    example_path = Path(__file__).resolve().parent.parent / "examples" / "story.krpg"
    source = example_path.read_text(encoding="utf-8")

    root = parse(tokenize(source))

    game = root.get("game", command=False, section=True)
    assert isinstance(game, Section)

    title = game.get("title", command=True, section=False)
    assert isinstance(title, Command)
    assert title.args == ["Small Demo"]

    player = game.get("player", command=False, section=True)
    assert isinstance(player, Section)
    assert player.args == ["Aria"]
    assert player.has("hp", command=True, section=False)

    intro_scene = game.get("scene", command=False, section=True)
    assert isinstance(intro_scene, Section)
    assert intro_scene.args == ["intro"]

    choices = intro_scene.all("choice", command=True, section=False)
    assert len(choices) == 2
    assert isinstance(choices[0], Command)
    assert choices[0].args == ["Open the door", "goto", "hall"]


def test_parse_fails_on_unbalanced_braces() -> None:
    with pytest.raises(ParseError) as error_info:
        parse_text("root {\n  say hello\n", source_name="story.krpg")

    error = error_info.value
    assert error.traceback
    assert error.traceback[-1].location.source_name == "story.krpg"
    assert error.hint == "Add a closing `}` for the most recent open section."

    with pytest.raises(ParseError) as error_info:
        parse_text("}\n", source_name="story.krpg")

    error = error_info.value
    assert error.traceback[-1].symbol == "}"
    assert error.hint == "Remove the extra `}` or open a matching `{` first."


def test_parse_fails_on_unclosed_string() -> None:
    with pytest.raises(ParseError) as error_info:
        parse_text('say "hello\nnext', source_name="story.krpg")

    error = error_info.value
    assert error.traceback[-1].symbol == '"'
    assert error.hint == 'Close the string with " before the line break.'
