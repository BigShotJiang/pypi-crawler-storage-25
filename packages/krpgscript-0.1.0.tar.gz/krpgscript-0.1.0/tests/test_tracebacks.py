from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest
from krpgscript.parser import ParseError, format_traceback, parse_text

BROKEN_FIXTURES = Path("tests/fixtures/broken")


@pytest.mark.parametrize(
    ("fixture_name", "expected_traceback"),
    [
        (
            "unclosed_section.krpg",
            "\n".join(
                [
                    "Traceback (most recent call last):",
                    '  File "tests/fixtures/broken/unclosed_section.krpg", '
                    "line 1, column 1, in section `root`",
                    "    root {",
                    "    ^",
                    '  File "tests/fixtures/broken/unclosed_section.krpg", '
                    "line 2, column 5, in section `child`",
                    "        child {",
                    "        ^",
                    "ParseError: Unclosed section block: missing '}'",
                    "Hint: Add a closing `}` for the most recent open section.",
                ]
            ),
        ),
        (
            "unclosed_string.krpg",
            dedent(
                """
                Traceback (most recent call last):
                  File "tests/fixtures/broken/unclosed_string.krpg", line 1, column 5, in string '"'
                    say "hello
                        ^
                ParseError: Unclosed string literal
                Hint: Close the string with " before the line break.
                """
            ).strip(),
        ),
        (
            "unexpected_closing.krpg",
            "\n".join(
                [
                    "Traceback (most recent call last):",
                    '  File "tests/fixtures/broken/unexpected_closing.krpg", '
                    "line 1, column 1, in token `}`",
                    "    }",
                    "    ^",
                    "ParseError: Unexpected closing brace '}'",
                    "Hint: Remove the extra `}` or open a matching `{` first.",
                ]
            ),
        ),
    ],
)
def test_broken_files_emit_python_style_tracebacks(
    fixture_name: str,
    expected_traceback: str,
) -> None:
    fixture_path = BROKEN_FIXTURES / fixture_name

    with pytest.raises(ParseError) as error_info:
        parse_text(
            fixture_path.read_text(encoding="utf-8"),
            source_name=fixture_path.as_posix(),
        )

    assert format_traceback(error_info.value) == expected_traceback
