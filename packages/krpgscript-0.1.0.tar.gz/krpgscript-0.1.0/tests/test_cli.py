from __future__ import annotations

import json
from pathlib import Path

from krpgscript.cli import run


def test_check_accepts_valid_script(tmp_path: Path, capsys) -> None:
    script_path = tmp_path / "story.krpg"
    script_path.write_text("game {\n  title demo\n}\n", encoding="utf-8")

    exit_code = run(["check", str(script_path)])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert f"OK: {script_path}" in captured.out


def test_check_accepts_directory_and_ignores_non_krpg_files(
    tmp_path: Path,
    capsys,
) -> None:
    scripts_dir = tmp_path / "scripts"
    nested_dir = scripts_dir / "nested"
    nested_dir.mkdir(parents=True)

    (scripts_dir / "ignore.txt").write_text("not a krpg file", encoding="utf-8")
    (nested_dir / "story.krpg").write_text("game {\n  title demo\n}\n", encoding="utf-8")

    exit_code = run(["check", str(scripts_dir)])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "story.krpg" in captured.out
    assert "ignore.txt" not in captured.out


def test_check_accepts_recursive_glob(tmp_path: Path, capsys) -> None:
    nested_dir = tmp_path / "a" / "b"
    nested_dir.mkdir(parents=True)
    script_path = nested_dir / "story.krpg"
    script_path.write_text("game {\n  title demo\n}\n", encoding="utf-8")

    exit_code = run(["check", str(tmp_path / "**" / "*.krpg")])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert f"OK: {script_path}" in captured.out


def test_check_ignores_non_krpg_files_in_mixed_arguments(tmp_path: Path, capsys) -> None:
    py_path = tmp_path / "script.py"
    krpg_path = tmp_path / "story.krpg"
    py_path.write_text("print('ignore me')\n", encoding="utf-8")
    krpg_path.write_text("game {\n  title demo\n}\n", encoding="utf-8")

    exit_code = run(["check", str(py_path), str(krpg_path)])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert f"OK: {krpg_path}" in captured.out
    assert "script.py" not in captured.out


def test_format_rewrites_script_in_place(tmp_path: Path) -> None:
    script_path = tmp_path / "story.krpg"
    script_path.write_text("game{title demo}\n", encoding="utf-8")

    exit_code = run(["format", str(script_path)])

    assert exit_code == 0
    assert script_path.read_text(encoding="utf-8") == "game {\n\ttitle demo\n}\n"


def test_format_rewrites_multiple_scripts_in_directory(tmp_path: Path) -> None:
    scripts_dir = tmp_path / "scripts"
    nested_dir = scripts_dir / "nested"
    nested_dir.mkdir(parents=True)

    first_path = scripts_dir / "first.krpg"
    second_path = nested_dir / "second.krpg"
    first_path.write_text("game{title first}\n", encoding="utf-8")
    second_path.write_text("game{title second}\n", encoding="utf-8")

    exit_code = run(["format", str(scripts_dir)])

    assert exit_code == 0
    assert first_path.read_text(encoding="utf-8") == "game {\n\ttitle first\n}\n"
    assert second_path.read_text(encoding="utf-8") == "game {\n\ttitle second\n}\n"


def test_json_exports_tree(tmp_path: Path) -> None:
    script_path = tmp_path / "story.krpg"
    output_path = tmp_path / "story.json"
    script_path.write_text("game {\n  title demo\n}\n", encoding="utf-8")

    exit_code = run(["json", str(script_path), "-o", str(output_path)])

    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert exit_code == 0
    assert payload["kind"] == "section"
    assert payload["name"] is None
    assert payload["children"][0]["name"] == "game"


def test_json_exports_multiple_trees_for_directory(tmp_path: Path) -> None:
    scripts_dir = tmp_path / "scripts"
    nested_dir = scripts_dir / "nested"
    nested_dir.mkdir(parents=True)

    first_path = scripts_dir / "first.krpg"
    second_path = nested_dir / "second.krpg"
    output_path = tmp_path / "bundle.json"
    first_path.write_text("game {\n  title first\n}\n", encoding="utf-8")
    second_path.write_text("game {\n  title second\n}\n", encoding="utf-8")

    exit_code = run(["json", str(scripts_dir), "-o", str(output_path)])

    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert exit_code == 0
    assert isinstance(payload, list)
    assert payload[0]["path"].endswith("first.krpg")
    assert payload[1]["path"].endswith("second.krpg")


def test_check_prints_traceback_for_unclosed_section(tmp_path: Path, capsys) -> None:
    script_path = tmp_path / "broken.krpg"
    script_path.write_text("game {\n  title demo\n", encoding="utf-8")

    exit_code = run(["check", str(script_path)])

    captured = capsys.readouterr()
    assert exit_code == 1
    assert "Traceback (most recent call last):" in captured.err
    assert f'File "{script_path}"' in captured.err
    assert "Add a closing `}`" in captured.err


def test_check_resolves_imported_script(tmp_path: Path, capsys) -> None:
    entry = tmp_path / "entry.krpg"
    imported = tmp_path / "part.krpg"
    imported.write_text("scene intro {\n  say hello\n}\n", encoding="utf-8")
    entry.write_text('!import "part.krpg"\n', encoding="utf-8")

    exit_code = run(["check", str(entry)])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert f"OK: {entry}" in captured.out


def test_check_fails_when_import_target_is_missing(tmp_path: Path, capsys) -> None:
    entry = tmp_path / "entry.krpg"
    entry.write_text('!import "missing.krpg"\n', encoding="utf-8")

    exit_code = run(["check", str(entry)])

    captured = capsys.readouterr()
    assert exit_code == 1
    assert "SemanticError: Imported file not found" in captured.err
    assert "resolved relative to the file containing the directive" in captured.err


def test_check_fails_when_import_cycle_detected(tmp_path: Path, capsys) -> None:
    first = tmp_path / "first.krpg"
    second = tmp_path / "second.krpg"
    first.write_text('!import "second.krpg"\n', encoding="utf-8")
    second.write_text('!import "first.krpg"\n', encoding="utf-8")

    exit_code = run(["check", str(first)])

    captured = capsys.readouterr()
    assert exit_code == 1
    assert "SemanticError: Circular !import detected" in captured.err


def test_tree_prints_structure(tmp_path: Path, capsys) -> None:
    script = tmp_path / "story.krpg"
    script.write_text("game {\n  title demo\n}\n", encoding="utf-8")

    exit_code = run(["tree", "--no-color", str(script)])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert str(script) in captured.out
    assert "└── game" in captured.out
    assert "└── title demo" in captured.out


def test_tree_semantic_prints_type_annotations(tmp_path: Path, capsys) -> None:
    schema = tmp_path / "types.krpg.d"
    script = tmp_path / "main.krpg"

    schema.write_text(
        "\n".join(
            [
                "root {",
                "    item",
                "    type",
                "}",
                "item string",
                "type enum:SOME,ANOTHER",
                "",
            ]
        ),
        encoding="utf-8",
    )
    script.write_text(
        "\n".join(
            [
                '!include "types.krpg.d"',
                "item potion",
                "type SOME",
                "",
            ]
        ),
        encoding="utf-8",
    )

    exit_code = run(["tree", "-semantic", "--no-color", str(script)])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "├── item potion (string)" in captured.out
    assert "└── type SOME (enum:SOME,ANOTHER)" in captured.out


def test_tree_semantic_prints_section_child_signatures(tmp_path: Path, capsys) -> None:
    schema = tmp_path / "types.krpg.d"
    script = tmp_path / "main.krpg"

    schema.write_text(
        "\n".join(
            [
                "root {",
                "    items",
                "}",
                "items {",
                "    item*... string string string {",
                "        slot_type?... enum:WEAPON,ARMOR,TROUSERS",
                "        stack?... int:0:128",
                "    }",
                "}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    script.write_text(
        "\n".join(
            [
                '!include "types.krpg.d"',
                "items {",
                "    blade knife desc {}",
                "}",
                "",
            ]
        ),
        encoding="utf-8",
    )

    exit_code = run(["tree", "-semantic", "--no-color", str(script)])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "└── items" in captured.out
    assert "⟶ item*... string string string {}" in captured.out
    assert "└── blade knife desc {} (string string)" in captured.out
    assert "⟶ slot_type?... enum:WEAPON,ARMOR,TROUSERS" in captured.out
    assert "⟶ stack?... int:0:128" in captured.out


def test_tree_collapses_long_strings(tmp_path: Path, capsys) -> None:
    script = tmp_path / "story.krpg"
    script.write_text("say AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\n", encoding="utf-8")

    exit_code = run(["tree", "--no-color", str(script)])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "say AAAAAAAA...AAAAAAAA" in captured.out


def test_tree_quotes_empty_and_spaced_string_args_and_marks_empty_section(
    tmp_path: Path,
    capsys,
) -> None:
    script = tmp_path / "story.krpg"
    script.write_text(
        "\n".join(
            [
                'say "hello world"',
                'say ""',
                "void {}",
                "",
            ]
        ),
        encoding="utf-8",
    )

    exit_code = run(["tree", "--no-color", str(script)])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert 'say "hello world"' in captured.out
    assert 'say ""' in captured.out
    assert "void {}" in captured.out


def test_defs_prints_loaded_definitions(tmp_path: Path, capsys) -> None:
    schema = tmp_path / "types.krpg.d"
    script = tmp_path / "main.krpg"

    schema.write_text(
        "\n".join(
            [
                "root {",
                "    items",
                "}",
                "items {",
                "    item*... string string string {",
                "        slot_type?... enum:WEAPON,ARMOR,TROUSERS",
                "        stack?... int:0:128",
                "    }",
                "}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    script.write_text('!include "types.krpg.d"\n', encoding="utf-8")

    exit_code = run(["defs", str(script)])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert str(script) in captured.out
    assert "[root]" in captured.out
    assert "[items]" in captured.out
    assert "[items.item]" in captured.out
    assert "item*... string string string {}" in captured.out
    assert "slot_type?... enum:WEAPON,ARMOR,TROUSERS" in captured.out
    assert "stack?... int:0:128" in captured.out
