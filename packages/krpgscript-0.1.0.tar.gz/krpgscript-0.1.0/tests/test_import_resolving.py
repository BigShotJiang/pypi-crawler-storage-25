from __future__ import annotations

from pathlib import Path

import pytest
from krpgscript import Section, compile_project
from krpgscript.semantic import SemanticError


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.strip() + "\n", encoding="utf-8")


def _root_names(root: Section) -> list[str]:
    names: list[str] = []
    for child in root.children:
        if child.name is not None:
            names.append(child.name)
    return names


def test_import_quoted_and_unquoted_are_equivalent(tmp_path: Path) -> None:
    part = tmp_path / "part.krpg"
    quoted = tmp_path / "quoted.krpg"
    unquoted = tmp_path / "unquoted.krpg"

    _write(part, "say hello\n")
    _write(quoted, '!import "part.krpg"\n')
    _write(unquoted, "!import part.krpg\n")

    quoted_project = compile_project(quoted)
    unquoted_project = compile_project(unquoted)

    assert _root_names(quoted_project.root) == _root_names(unquoted_project.root)


def test_import_invalid_multi_token_path_fails(tmp_path: Path) -> None:
    script = tmp_path / "main.krpg"
    _write(script, "!import f i l e.krpg\n")

    with pytest.raises(SemanticError, match="expects exactly one path argument"):
        compile_project(script)


def test_import_unsupported_extension_fails(tmp_path: Path) -> None:
    script = tmp_path / "main.krpg"
    data = tmp_path / "data.json"

    _write(data, '{"ok": true}\n')
    _write(script, '!import "data.json"\n')

    with pytest.raises(SemanticError, match="Unsupported import target extension"):
        compile_project(script)


def test_import_relative_resolution_is_based_on_current_file(tmp_path: Path) -> None:
    main = tmp_path / "A.krpg"
    nested = tmp_path / "dir" / "B.krpg"
    sibling = tmp_path / "C.krpg"

    _write(
        main,
        """
        !import dir/B.krpg
        start root
        """,
    )
    _write(
        nested,
        """
        !import ../C.krpg
        from_b 1
        """,
    )
    _write(sibling, "from_c 2\n")

    project = compile_project(main)
    names = _root_names(project.root)

    assert "from_c" in names
    assert "from_b" in names
    assert "start" in names


def test_import_without_bang_is_treated_as_regular_command(tmp_path: Path) -> None:
    schema = tmp_path / "types.krpg"
    script = tmp_path / "main.krpg"

    _write(
        schema,
        """
        root {
            start
        }
        start string
        """,
    )
    _write(
        script,
        """
        !include types.krpg
        import something.krpg
        start ok
        """,
    )

    with pytest.raises(SemanticError, match="Unknown node `import`"):
        compile_project(script)
