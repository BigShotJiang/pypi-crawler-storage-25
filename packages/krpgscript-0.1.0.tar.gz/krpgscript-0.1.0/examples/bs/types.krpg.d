# --- Глобальные определения (Shared Groups) ---

# Группа команд, которые могут встречаться почти в любом блоке логики
logic_flow {
    say?... string...
    set?... string string
    wait?... ...
    return?...
    pass?... int
    if?... string { :action_body }
    require?... ...
    require? ... { :action_body }
}

# Группа команд для взаимодействия с миром
world_actions {
    quest?... string
    goto?... string...
    evolve?... string
    unlock?... string
    complete?... string
    pickup?... string int?
    item?... string int?
    npc?... string
}

# Явное определение zero-arg команды для ссылок вида `return?...`
return

# Объединенная группа для тел экшенов (NPC, Локации, Сцены)
action_body {
    :logic_flow
    :world_actions
    multiple? string int int string {
        option... int string
        require? ... { :logic_flow }
        if?... string
        quest?... string
        say?... string...
        evolve?... string
    }
}

# --- Структура Корня ---

root {
    init
    scenarios
    items
    npcs
    locations
    quests
}

# --- Секции верхнего уровня ---

init {
    :logic_flow
    quest? string
}

scenarios {
    # Сценарии без ключевого слова (просто имя { ... })
    scenario*... string? {
        say... string...
    }
}

items {
    # Предметы: имя "Название" "Описание" { свойства }
    item*... string string string {
        slot_type? enum:WEAPON,ARMOR,TROUSERS
        stack? int:0:128
    }
}

npcs {
    # NPC: имя "Имя" "Описание" { стадии }
    npc*... string string string {
        stage?... {
            # Экшен: имя "Название" { логика }
            action*... string string string {
                :action_body
            }
        }
    }
}

locations {
    location*... string string string {
        item?... string int?
        npc?... string
        stage?... {
            action*... string string string {
                :action_body
            }
        }
    }
    # Команды настройки связей в корне локаций
    start? string
    link?... string string
    lock?... string
}

quests {
    quest*... string string string {
        # Стадия квеста: "Название" { цели }
        quest_stage*... string {
            goal... enum:PICKUP,WEAR,VISIT,TALK,FREEZE ...
            end?... enum:UNLOCK,RUN,INTRODUCE,QUEST string
        }
    }
}