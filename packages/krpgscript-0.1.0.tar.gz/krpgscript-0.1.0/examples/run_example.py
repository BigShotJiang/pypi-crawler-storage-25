"""Minimal API example for parsing KRPG DSL."""

from __future__ import annotations

from pathlib import Path

from krpgscript import Command, Section, parse_text


def print_tree(node: Section, indent: int = 0) -> None:
    """Print a readable tree with Section and Command nodes."""
    pad = " " * indent

    if node.name is None:
        print("<root>")
    else:
        args = " ".join(node.args)
        if args:
            print(f"{pad}Section: {node.name} {args}")
        else:
            print(f"{pad}Section: {node.name}")

    for child in node.children:
        if isinstance(child, Command):
            child_args = " ".join(child.args)
            if child_args:
                print(f"{' ' * (indent + 2)}Command: {child.name} {child_args}")
            else:
                print(f"{' ' * (indent + 2)}Command: {child.name}")
            continue

        print_tree(child, indent + 2)


def main() -> None:
    """Parse the demo script and print its Section/Command tree."""
    script_path = Path(__file__).with_name("story.krpg")
    root = parse_text(script_path.read_text(encoding="utf-8"))
    print_tree(root)


if __name__ == "__main__":
    main()
