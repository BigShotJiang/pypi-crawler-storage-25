items {
    item*... string string string {
        slot_type? enum:WEAPON,ARMOR,TROUSERS
        stack? int:0:128
    }
}

actions {
    say?... string...
    set?... string string
    if?... string { :actions }
    menu?... string {
        option... string {
            :actions
        }
    }
}

root {
    items
    actions
}