# krpgscript

[Русский](README.ru.md) | English

Типизированный парсер для небольшого KRPG DSL.

## Что делает проект

`krpgscript` разбирает текстовый формат с фигурными скобками в дерево узлов `Section` и `Command`.
Проект специально ограничен синтаксическим парсингом и не включает runtime-движок.

## Основные сущности

- `Section` — контейнерный узел, который может содержать вложенные секции и команды
- `Command` — листовой узел с позиционными аргументами
- `TokenType` — тип токена: `NEWLINE`, `BRACE`, `COMMAND`
- `parse_text()` — основной вход для разбора сырого текста в AST

## Пример синтаксиса

См. [examples/story.krpg](examples/story.krpg) для минимального демо.

```text
game {
    title "Small Demo"
    version 1

    player "Aria" {
        hp 100
        mp 25
        skill "quick strike"
    }

    scene intro {
        say "You wake up in a quiet room."
        choice "Open the door" goto hall
        choice "Go back to sleep" goto sleep
    }
}
```

## Использование

### Разбор текста в Python

```python
from pathlib import Path

from krpgscript import Command, Section, parse_text

root = parse_text(Path("examples/story.krpg").read_text(encoding="utf-8"))

game = root.get("game", command=False, section=True)
assert isinstance(game, Section)

for child in game.children:
    if isinstance(child, Command):
        print(child.name, child.args)
    else:
        print(child.name, child.args)
```

### Запуск демо-примера

```bash
uv run python examples/run_example.py
```

### CLI

Проверка синтаксиса для файла, папки или glob-пути:

```bash
krpgscript check examples/story.krpg examples/
```

Форматирование одного или нескольких файлов:

```bash
krpgscript format examples/**/*.krpg
```

Экспорт дерева в JSON:

```bash
krpgscript json examples/story.krpg -o story.json
```

## Разработка

Установить зависимости:

```bash
uv sync --dev
```

Запустить тесты:

```bash
just test
```

Запустить линтинг и type checking:

```bash
just check
```

Отформатировать код:

```bash
just fmt
```

Собрать релизные артефакты:

```bash
just build
```

Проверить релизный workflow:

```bash
just release-check
```

## Структура проекта

```text
krpgscript/
  __init__.py
  main.py
  parser.py
examples/
  run_example.py
  story.krpg
tests/
  test_parser.py
justfile
```

## Примечания

- У пакета нет runtime-зависимостей
- Публичный API находится в [krpgscript/\_\_init\_\_.py](krpgscript/__init__.py)
- Текущий API парсера: `Section`, `Command`, `TokenType`, `tokenize`, `parse`, `parse_text`
