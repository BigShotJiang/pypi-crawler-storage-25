const spec={
  "openapi": "3.0.0",
  "info": {
    "title": "Patent Information Retrieval APIs",
    "version": "1.0",
    "description": "Server URL ： https://ip-data.jpo.go.jp/api\n\nTo retrieve information in response to the parameters defined.\n\n<font color=\"red\"><b>*Note: \"try it out\" buttons in the specification pages are not available.</b></font>\n\n<font color=\"red\"><b>*Note: To maintain stable operation, the provision of information via the Patent Information Retrieval APIs is regulated by access limits.</b></font>"
  },
  "servers": null,
  "paths": {
    "/patent/v1/app_progress/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2020008423
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Patent Progress Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing retrieved progress information)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no bibliographic information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "inventionTitle": {
                              "type": "string",
                              "description": "発明の名称",
                              "maxLength": 1000
                            },
                            "applicantAttorney": {
                              "type": "array",
                              "description": "申請人（出願人・代理人）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "applicantAttorneyCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "申請人コード"
                                  },
                                  "repeatNumber": {
                                    "type": "string",
                                    "description": "繰返番号"
                                  },
                                  "name": {
                                    "type": "string",
                                    "description": "申請人氏名・名称",
                                    "maxLength": 1000
                                  },
                                  "applicantAttorneyClass": {
                                    "type": "string",
                                    "description": "出願人・代理人識別",
                                    "pattern": "^[0-9]{1}$"
                                  }
                                }
                              }
                            },
                            "filingDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "出願日"
                            },
                            "publicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{9}$",
                              "description": "公開番号"
                            },
                            "ADPublicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "公開番号（西暦変換）"
                            },
                            "nationalPublicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{9}$",
                              "description": "公表番号"
                            },
                            "ADNationalPublicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "公表番号（西暦変換）"
                            },
                            "publicationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "公開日"
                            },
                            "registrationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{7}$",
                              "description": "登録番号"
                            },
                            "registrationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "登録日"
                            },
                            "internationalApplicationNumber": {
                              "type": "string",
                              "pattern": "^[A-Z]{2}[0-9]{10}$",
                              "description": "国際出願番号"
                            },
                            "internationalPublicationNumber": {
                              "type": "string",
                              "pattern": "^WO[0-9]{10}$",
                              "description": "国際公開番号"
                            },
                            "internationalPublicationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "国際公開日"
                            },
                            "erasureIdentifier": {
                              "type": "string",
                              "pattern": "^[0-9]{2}$",
                              "description": "抹消識別"
                            },
                            "expireDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "存続期間満了年月日"
                            },
                            "disappearanceDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "本権利消滅日"
                            },
                            "priorityRightInformation": {
                              "type": "array",
                              "description": "優先権基礎情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "parisPriorityApplicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9.-]+$",
                                    "description": "パリ条約に基づく優先権出願番号"
                                  },
                                  "parisPriorityDate": {
                                    "type": "string",
                                    "pattern": "^[0-9]{8}$",
                                    "description": "パリ条約に基づく優先権主張日"
                                  },
                                  "parisPriorityCountryCd": {
                                    "type": "string",
                                    "pattern": "^[A-Z]{2}$",
                                    "description": "パリ条約に基づく優先権国コード"
                                  },
                                  "nationalPriorityLawCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{1}$",
                                    "description": "国内優先権四法コード"
                                  },
                                  "nationalPriorityApplicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{10}$",
                                    "description": "国内優先権出願番号"
                                  },
                                  "nationalPriorityInternationalApplicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{12}$",
                                    "description": "国内優先権国際出願番号"
                                  },
                                  "nationalPriorityDate": {
                                    "type": "string",
                                    "pattern": "^[0-9]{8}$",
                                    "description": "国内優先権主張日"
                                  }
                                }
                              }
                            },
                            "parentApplicationInformation": {
                              "type": "object",
                              "description": "原出願情報",
                              "properties": {
                                "parentApplicationNumber": {
                                  "type": "string",
                                  "description": "原出願番号",
                                  "pattern": "^[0-9]{10}$"
                                },
                                "filingDate": {
                                  "type": "string",
                                  "description": "出願日",
                                  "pattern": "^[0-9]{8}$"
                                }
                              }
                            },
                            "divisionalApplicationInformation": {
                              "type": "array",
                              "description": "分割出願群情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "applicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{10}$",
                                    "description": "出願番号"
                                  },
                                  "publicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "公開番号"
                                  },
                                  "ADPublicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{10}$",
                                    "description": "公開番号（西暦変換）"
                                  },
                                  "nationalPublicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "公表番号"
                                  },
                                  "ADNationalPublicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{10}$",
                                    "description": "公表番号（西暦変換）"
                                  },
                                  "registrationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{7}$",
                                    "description": "登録番号"
                                  },
                                  "internationalApplicationNumber": {
                                    "type": "string",
                                    "pattern": "^[A-Z]{2}[0-9]{10}$",
                                    "description": "国際出願番号"
                                  },
                                  "internationalPublicationNumber": {
                                    "type": "string",
                                    "pattern": "^WO[0-9]{10}$",
                                    "description": "国際公開番号"
                                  },
                                  "erasureIdentifier": {
                                    "type": "string",
                                    "pattern": "^[0-9]{2}$",
                                    "description": "抹消識別"
                                  },
                                  "expireDate": {
                                    "type": "string",
                                    "pattern": "^[0-9]{8}$",
                                    "description": "存続期間満了年月日"
                                  },
                                  "disappearanceDate": {
                                    "type": "string",
                                    "pattern": "^[0-9]{8}$",
                                    "description": "本権利消滅日"
                                  },
                                  "divisionalGeneration": {
                                    "type": "string",
                                    "description": "分割出願の世代"
                                  }
                                }
                              }
                            },
                            "bibliographyInformation": {
                              "type": "array",
                              "description": "書類一覧（書誌）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "numberType": {
                                    "type": "string",
                                    "maxLength": 2,
                                    "description": "番号種別"
                                  },
                                  "number": {
                                    "type": "string",
                                    "maxLength": 20,
                                    "description": "番号"
                                  },
                                  "documentList": {
                                    "type": "array",
                                    "description": "書類一覧",
                                    "items": {
                                      "type": "object",
                                      "properties": {
                                        "legalDate": {
                                          "type": "string",
                                          "pattern": "^[0-9]{8}$",
                                          "description": "受付日・発送日・作成日"
                                        },
                                        "irirFlg": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "IB書類フラグ"
                                        },
                                        "availabilityFlag": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "書類実体有無"
                                        },
                                        "documentCode": {
                                          "type": "string",
                                          "pattern": "^[0-9]{7}$",
                                          "description": "中間書類コード"
                                        },
                                        "documentDescription": {
                                          "type": "string",
                                          "maxLength": 40,
                                          "description": "書類名"
                                        },
                                        "documentNumber": {
                                          "type": "string",
                                          "pattern": "^[0-9]{11}$",
                                          "description": "書類番号"
                                        },
                                        "versionNumber": {
                                          "type": "string",
                                          "maxLength": 4,
                                          "description": "バージョン番号"
                                        },
                                        "documentSeparator": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "書類識別"
                                        },
                                        "numberOfPages": {
                                          "type": "string",
                                          "maxLength": 5,
                                          "description": "ページ数"
                                        },
                                        "sizeOfDocument": {
                                          "type": "string",
                                          "maxLength": 6,
                                          "description": "ドキュメントサイズ"
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "998",
                        "data": {
                          "applicationNumber": "2020008423",
                          "inventionTitle": "管理システム及び管理方法",
                          "applicantAttorney": [
                            {
                              "applicantAttorneyCd": "718000266",
                              "repeatNumber": "1",
                              "name": "特許庁長官",
                              "applicantAttorneyClass": "1"
                            },
                            {
                              "applicantAttorneyCd": "100099759",
                              "repeatNumber": "2",
                              "name": "青木　篤",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100123582",
                              "repeatNumber": "3",
                              "name": "三橋　真二",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100114018",
                              "repeatNumber": "4",
                              "name": "南山　知広",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100165191",
                              "repeatNumber": "5",
                              "name": "河合　章",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100133835",
                              "repeatNumber'": "6",
                              "name'": "河野　努",
                              "applicantAttorneyClass'": "2"
                            },
                            {
                              "applicantAttorneyCd": "100180806",
                              "repeatNumber": "7",
                              "name": "三浦　剛",
                              "applicantAttorneyClass": "2"
                            }
                          ],
                          "filingDate": "20200122",
                          "publicationNumber": "503022359",
                          "ADPublicationNumber": "2021022359",
                          "nationalPublicationNumber": "",
                          "ADNationalPublicationNumber": "",
                          "publicationDate": "20210218",
                          "registrationNumber": "6691280",
                          "registrationDate": "20200414",
                          "internationalApplicationNumber": "",
                          "internationalPublicationNumber": "",
                          "internationalPublicationDate": "",
                          "erasureIdentifier": "00",
                          "expireDate": "20400122",
                          "disappearanceDate": "",
                          "priorityRightInformation": [
                            {
                              "parisPriorityApplicationNumber": "",
                              "parisPriorityDate": "",
                              "parisPriorityCountryCd": "",
                              "nationalPriorityLawCd": "1",
                              "nationalPriorityApplicationNumber": "2019139759",
                              "nationalPriorityInternationalApplicationNumber": "",
                              "nationalPriorityDate": "20190730"
                            }
                          ],
                          "parentApplicationInformation": {},
                          "divisionalApplicationInformation": [],
                          "bibliographyInformation": [
                            {
                              "numberType": "01",
                              "number": "2020008423",
                              "documentList": [
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A621",
                                  "documentDescription": "出願審査請求書",
                                  "documentNumber": "52000131988",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1116"
                                },
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A63",
                                  "documentDescription": "請求の範囲",
                                  "documentNumber": "52000131764",
                                  "versionNumber": "0001",
                                  "documentSeparator": "L",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "3065"
                                },
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A63",
                                  "documentDescription": "要約書",
                                  "documentNumber": "52000131764",
                                  "versionNumber": "0001",
                                  "documentSeparator": "Y",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1281"
                                },
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A63",
                                  "documentDescription": "明細書",
                                  "documentNumber": "52000131764",
                                  "versionNumber": "0001",
                                  "documentSeparator": "M",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "34836"
                                },
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A63",
                                  "documentDescription": "図面",
                                  "documentNumber": "52000131764",
                                  "versionNumber": "0001",
                                  "documentSeparator": "Z",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "553114"
                                },
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A63",
                                  "documentDescription": "特許願",
                                  "documentNumber": "52000131764",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1451"
                                },
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A871",
                                  "documentDescription": "早期審査に関する事情説明書",
                                  "documentNumber": "52000131990",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20200206",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A523",
                                  "documentDescription": "添付書類",
                                  "documentNumber": "12000230003",
                                  "versionNumber": "0001",
                                  "documentSeparator": "T",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "34488"
                                },
                                {
                                  "legalDate": "20200206",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A523",
                                  "documentDescription": "手続補正書",
                                  "documentNumber": "12000230003",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1193"
                                },
                                {
                                  "legalDate": "20200302",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A971005",
                                  "documentDescription": "早期審査に関する報告書",
                                  "documentNumber": "96520054329",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20200310",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A01",
                                  "documentDescription": "特許査定",
                                  "documentNumber": "06120092529",
                                  "versionNumber": "0001",
                                  "documentSeparator": "K",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1512"
                                },
                                {
                                  "legalDate": "20200402",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A843",
                                  "documentDescription": "優先権証明請求（電子データ交換協定）",
                                  "documentNumber": "BBBBBBBBBBB",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20200403",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A845",
                                  "documentDescription": "優先権証明応答（電子データ交換協定）",
                                  "documentNumber": "BBBBBBBBBBB",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20200408",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A972001",
                                  "documentDescription": "要約不備職権訂正",
                                  "documentNumber": "96620018712",
                                  "versionNumber": "0001",
                                  "documentSeparator": "C",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1398"
                                },
                                {
                                  "legalDate": "20200813",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A861",
                                  "documentDescription": "ファイル記録事項の閲覧（縦覧）請求書",
                                  "documentNumber": "00520005569",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            },
                            {
                              "numberType": "02",
                              "number": "503022359",
                              "documentList": []
                            },
                            {
                              "numberType": "06",
                              "number": "6691280",
                              "documentList": [
                                {
                                  "legalDate": "20200310",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A01",
                                  "documentDescription": "特許査定",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20200428",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "R150",
                                  "documentDescription": "特許証",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            },
                            {
                              "numberType": "07",
                              "number": "2020700850",
                              "documentList": [
                                {
                                  "legalDate": "20201029",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C561",
                                  "documentDescription": "異議申立書",
                                  "documentNumber": "02020005340",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201112",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C201",
                                  "documentDescription": "異議番号通知",
                                  "documentNumber": "07120091248",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201112",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C201",
                                  "documentDescription": "異議番号通知",
                                  "documentNumber": "07120091247",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201112",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C201",
                                  "documentDescription": "異議番号通知",
                                  "documentNumber": "07120091246",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201113",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C95",
                                  "documentDescription": "予告登録通知",
                                  "documentNumber": "97120052549",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201119",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C22",
                                  "documentDescription": "審判官指定（変更）通知",
                                  "documentNumber": "07120092827",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201119",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C22",
                                  "documentDescription": "審判官指定（変更）通知",
                                  "documentNumber": "07120092828",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201207",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "C16",
                                  "documentDescription": "異議の決定",
                                  "documentNumber": "07120095888",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1316"
                                },
                                {
                                  "legalDate": "20201211",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C3012",
                                  "documentDescription": "郵便送達報告書",
                                  "documentNumber": "97120057317",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20210119",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C28",
                                  "documentDescription": "再送",
                                  "documentNumber": "97121002236",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20210119",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "C16",
                                  "documentDescription": "異議の決定",
                                  "documentNumber": "07120095889",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1316"
                                },
                                {
                                  "legalDate": "20210202",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C3012",
                                  "documentDescription": "郵便送達報告書",
                                  "documentNumber": "97121004846",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20210203",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C96",
                                  "documentDescription": "確定登録通知",
                                  "documentNumber": "97121004933",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            },
                            {
                              "numberType": "08",
                              "number": "5 0310035",
                              "documentList": []
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401.\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429.\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with the processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500.\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-app_progress",
        "description": "Retrieves progress information associated with defined patent application number.\n\nRequest defines an application number as URL parameter.\n\n{application number} defined as in the following example.\n\nYou can define one application number per request.\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/app_progress/2020008423",
        "parameters": []
      }
    },
    "/patent/v1/app_progress_simple/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2020008423
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Simplified Patent Progress Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing simplified patent progress infomation retreved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no bibliographic information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "inventionTitle": {
                              "type": "string",
                              "description": "発明の名称",
                              "maxLength": 1000
                            },
                            "applicantAttorney": {
                              "type": "array",
                              "description": "申請人（出願人・代理人）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "applicantAttorneyCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "申請人コード"
                                  },
                                  "repeatNumber": {
                                    "type": "string",
                                    "description": "繰返番号"
                                  },
                                  "name": {
                                    "type": "string",
                                    "description": "申請人氏名・名称",
                                    "maxLength": 1000
                                  },
                                  "applicantAttorneyClass": {
                                    "type": "string",
                                    "description": "出願人・代理人識別",
                                    "pattern": "^[0-9]{1}$"
                                  }
                                }
                              }
                            },
                            "filingDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "出願日"
                            },
                            "publicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{9}$",
                              "description": "公開番号"
                            },
                            "ADPublicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "公開番号（西暦変換）"
                            },
                            "nationalPublicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{9}$",
                              "description": "公表番号"
                            },
                            "ADNationalPublicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "公表番号（西暦変換）"
                            },
                            "publicationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "公開日"
                            },
                            "registrationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{7}$",
                              "description": "登録番号"
                            },
                            "registrationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "登録日"
                            },
                            "internationalApplicationNumber": {
                              "type": "string",
                              "pattern": "^[A-Z]{2}[0-9]{10}$",
                              "description": "国際出願番号"
                            },
                            "internationalPublicationNumber": {
                              "type": "string",
                              "pattern": "^WO[0-9]{10}$",
                              "description": "国際公開番号"
                            },
                            "internationalPublicationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "国際公開日"
                            },
                            "erasureIdentifier": {
                              "type": "string",
                              "pattern": "^[0-9]{2}$",
                              "description": "抹消識別"
                            },
                            "expireDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "存続期間満了年月日"
                            },
                            "disappearanceDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "本権利消滅日"
                            },
                            "bibliographyInformation": {
                              "type": "array",
                              "description": "書類一覧（書誌）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "numberType": {
                                    "type": "string",
                                    "maxLength": 2,
                                    "description": "番号種別"
                                  },
                                  "number": {
                                    "type": "string",
                                    "maxLength": 20,
                                    "description": "番号"
                                  },
                                  "documentList": {
                                    "type": "array",
                                    "description": "書類一覧",
                                    "items": {
                                      "type": "object",
                                      "properties": {
                                        "legalDate": {
                                          "type": "string",
                                          "pattern": "^[0-9]{8}$",
                                          "description": "受付日・発送日・作成日"
                                        },
                                        "irirFlg": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "IB書類フラグ"
                                        },
                                        "availabilityFlag": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "書類実体有無"
                                        },
                                        "documentCode": {
                                          "type": "string",
                                          "pattern": "^[0-9]{7}$",
                                          "description": "中間書類コード"
                                        },
                                        "documentDescription": {
                                          "type": "string",
                                          "maxLength": 40,
                                          "description": "書類名"
                                        },
                                        "documentNumber": {
                                          "type": "string",
                                          "pattern": "^[0-9]{11}$",
                                          "description": "書類番号"
                                        },
                                        "versionNumber": {
                                          "type": "string",
                                          "maxLength": 4,
                                          "description": "バージョン番号"
                                        },
                                        "documentSeparator": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "書類識別"
                                        },
                                        "numberOfPages": {
                                          "type": "string",
                                          "maxLength": 5,
                                          "description": "ページ数"
                                        },
                                        "sizeOfDocument": {
                                          "type": "string",
                                          "maxLength": 6,
                                          "description": "ドキュメントサイズ"
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "998",
                        "data": {
                          "applicationNumber": "2020008423",
                          "inventionTitle": "管理システム及び管理方法",
                          "applicantAttorney": [
                            {
                              "applicantAttorneyCd": "718000266",
                              "repeatNumber": "1",
                              "name": "特許庁長官",
                              "applicantAttorneyClass": "1"
                            },
                            {
                              "applicantAttorneyCd": "100099759",
                              "repeatNumber": "2",
                              "name": "青木　篤",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100123582",
                              "repeatNumber": "3",
                              "name": "三橋　真二",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100114018",
                              "repeatNumber": "4",
                              "name": "南山　知広",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100165191",
                              "repeatNumber": "5",
                              "name": "河合　章",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100133835",
                              "repeatNumber'": "6",
                              "name'": "河野　努",
                              "applicantAttorneyClass'": "2"
                            },
                            {
                              "applicantAttorneyCd": "100180806",
                              "repeatNumber": "7",
                              "name": "三浦　剛",
                              "applicantAttorneyClass": "2"
                            }
                          ],
                          "filingDate": "20200122",
                          "publicationNumber": "503022359",
                          "ADPublicationNumber": "2021022359",
                          "nationalPublicationNumber": "",
                          "ADNationalPublicationNumber": "",
                          "publicationDate": "20210218",
                          "registrationNumber": "6691280",
                          "registrationDate": "20200414",
                          "internationalApplicationNumber": "",
                          "internationalPublicationNumber": "",
                          "internationalPublicationDate": "",
                          "erasureIdentifier": "00",
                          "expireDate": "20400122",
                          "disappearanceDate": "",
                          "bibliographyInformation": [
                            {
                              "numberType": "01",
                              "number": "2020008423",
                              "documentList": [
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A621",
                                  "documentDescription": "出願審査請求書",
                                  "documentNumber": "52000131988",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1116"
                                },
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A63",
                                  "documentDescription": "請求の範囲",
                                  "documentNumber": "52000131764",
                                  "versionNumber": "0001",
                                  "documentSeparator": "L",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "3065"
                                },
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A63",
                                  "documentDescription": "要約書",
                                  "documentNumber": "52000131764",
                                  "versionNumber": "0001",
                                  "documentSeparator": "Y",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1281"
                                },
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A63",
                                  "documentDescription": "明細書",
                                  "documentNumber": "52000131764",
                                  "versionNumber": "0001",
                                  "documentSeparator": "M",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "34836"
                                },
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A63",
                                  "documentDescription": "図面",
                                  "documentNumber": "52000131764",
                                  "versionNumber": "0001",
                                  "documentSeparator": "Z",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "553114"
                                },
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A63",
                                  "documentDescription": "特許願",
                                  "documentNumber": "52000131764",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1451"
                                },
                                {
                                  "legalDate": "20200122",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A871",
                                  "documentDescription": "早期審査に関する事情説明書",
                                  "documentNumber": "52000131990",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20200206",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A523",
                                  "documentDescription": "添付書類",
                                  "documentNumber": "12000230003",
                                  "versionNumber": "0001",
                                  "documentSeparator": "T",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "34488"
                                },
                                {
                                  "legalDate": "20200206",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A523",
                                  "documentDescription": "手続補正書",
                                  "documentNumber": "12000230003",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1193"
                                },
                                {
                                  "legalDate": "20200302",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A971005",
                                  "documentDescription": "早期審査に関する報告書",
                                  "documentNumber": "96520054329",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20200310",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A01",
                                  "documentDescription": "特許査定",
                                  "documentNumber": "06120092529",
                                  "versionNumber": "0001",
                                  "documentSeparator": "K",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1512"
                                },
                                {
                                  "legalDate": "20200402",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A843",
                                  "documentDescription": "優先権証明請求（電子データ交換協定）",
                                  "documentNumber": "BBBBBBBBBBB",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20200403",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A845",
                                  "documentDescription": "優先権証明応答（電子データ交換協定）",
                                  "documentNumber": "BBBBBBBBBBB",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20200408",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A972001",
                                  "documentDescription": "要約不備職権訂正",
                                  "documentNumber": "96620018712",
                                  "versionNumber": "0001",
                                  "documentSeparator": "C",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1398"
                                },
                                {
                                  "legalDate": "20200813",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A861",
                                  "documentDescription": "ファイル記録事項の閲覧（縦覧）請求書",
                                  "documentNumber": "00520005569",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            },
                            {
                              "numberType": "02",
                              "number": "503022359",
                              "documentList": []
                            },
                            {
                              "numberType": "06",
                              "number": "6691280",
                              "documentList": [
                                {
                                  "legalDate": "20200310",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A01",
                                  "documentDescription": "特許査定",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20200428",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "R150",
                                  "documentDescription": "特許証",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            },
                            {
                              "numberType": "07",
                              "number": "2020700850",
                              "documentList": [
                                {
                                  "legalDate": "20201029",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C561",
                                  "documentDescription": "異議申立書",
                                  "documentNumber": "02020005340",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201112",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C201",
                                  "documentDescription": "異議番号通知",
                                  "documentNumber": "07120091248",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201112",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C201",
                                  "documentDescription": "異議番号通知",
                                  "documentNumber": "07120091247",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201112",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C201",
                                  "documentDescription": "異議番号通知",
                                  "documentNumber": "07120091246",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201113",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C95",
                                  "documentDescription": "予告登録通知",
                                  "documentNumber": "97120052549",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201119",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C22",
                                  "documentDescription": "審判官指定（変更）通知",
                                  "documentNumber": "07120092827",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201119",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C22",
                                  "documentDescription": "審判官指定（変更）通知",
                                  "documentNumber": "07120092828",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20201207",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "C16",
                                  "documentDescription": "異議の決定",
                                  "documentNumber": "07120095888",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1316"
                                },
                                {
                                  "legalDate": "20201211",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C3012",
                                  "documentDescription": "郵便送達報告書",
                                  "documentNumber": "97120057317",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20210119",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C28",
                                  "documentDescription": "再送",
                                  "documentNumber": "97121002236",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20210119",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "C16",
                                  "documentDescription": "異議の決定",
                                  "documentNumber": "07120095889",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1316"
                                },
                                {
                                  "legalDate": "20210202",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C3012",
                                  "documentDescription": "郵便送達報告書",
                                  "documentNumber": "97121004846",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20210203",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "C96",
                                  "documentDescription": "確定登録通知",
                                  "documentNumber": "97121004933",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            },
                            {
                              "numberType": "08",
                              "number": "5 0310035",
                              "documentList": []
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-app_progress_simple",
        "description": "Retrieves progress data associated with the defined patent application number (excluding basic priority information, original application information and divisional application information).\n\nRequest defines an application number as URL parameter.\n\n{application number} defined as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/app_progress_simple/2020008423",
        "parameters": []
      }
    },
    "/patent/v1/divisional_app_info/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2007035937
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Patent Divisional Aplication Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing divisional patent application infomation retrieved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no bibliographic information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "parentApplicationInformation": {
                              "type": "object",
                              "description": "原出願情報",
                              "properties": {
                                "parentApplicationNumber": {
                                  "type": "string",
                                  "description": "原出願番号",
                                  "pattern": "^[0-9]{10}$"
                                },
                                "filingDate": {
                                  "type": "string",
                                  "description": "出願日",
                                  "pattern": "^[0-9]{8}$"
                                }
                              }
                            },
                            "divisionalApplicationInformation": {
                              "type": "array",
                              "description": "分割出願群情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "applicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{10}$",
                                    "description": "出願番号"
                                  },
                                  "publicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "公開番号"
                                  },
                                  "ADPublicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{10}$",
                                    "description": "公開番号（西暦変換）"
                                  },
                                  "nationalPublicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "公表番号"
                                  },
                                  "ADNationalPublicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{10}$",
                                    "description": "公表番号（西暦変換）"
                                  },
                                  "registrationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{7}$",
                                    "description": "登録番号"
                                  },
                                  "internationalApplicationNumber": {
                                    "type": "string",
                                    "pattern": "^[A-Z]{2}[0-9]{10}$",
                                    "description": "国際出願番号"
                                  },
                                  "internationalPublicationNumber": {
                                    "type": "string",
                                    "pattern": "^WO[0-9]{10}$",
                                    "description": "国際公開番号"
                                  },
                                  "erasureIdentifier": {
                                    "type": "string",
                                    "pattern": "^[0-9]{2}$",
                                    "description": "抹消識別"
                                  },
                                  "expireDate": {
                                    "type": "string",
                                    "pattern": "^[0-9]{8}$",
                                    "description": "存続期間満了年月日"
                                  },
                                  "disappearanceDate": {
                                    "type": "string",
                                    "pattern": "^[0-9]{8}$",
                                    "description": "本権利消滅日"
                                  },
                                  "divisionalGeneration": {
                                    "type": "string",
                                    "description": "分割出願の世代"
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "49",
                        "data": {
                          "applicationNumber": "2007035937",
                          "parentApplicationInformation": {
                            "parentApplicationNumber": "2000009310",
                            "filingDate": "20000118"
                          },
                          "divisionalApplicationInformation": [
                            {
                              "applicationNumber": "2000009310",
                              "publicationNumber": "413202365",
                              "ADPublicationNumber": "2001202365",
                              "nationalPublicationNumber": "",
                              "ADNationalPublicationNumber": "",
                              "registrationNumber": "3947859",
                              "internationalApplicationNumber": "",
                              "internationalPublicationNumber": "",
                              "erasureIdentifier": "01",
                              "expireDate": "20200118",
                              "disappearanceDate": "20140427",
                              "divisionalGeneration": "0"
                            },
                            {
                              "applicationNumber": "2007035937",
                              "publicationNumber": "419157175",
                              "ADPublicationNumber": "2007157175",
                              "nationalPublicationNumber": "",
                              "ADNationalPublicationNumber": "",
                              "registrationNumber": "4488010",
                              "internationalApplicationNumber": "",
                              "internationalPublicationNumber": "",
                              "erasureIdentifier": "01",
                              "expireDate": "20200118",
                              "disappearanceDate": "20140409",
                              "divisionalGeneration": "1"
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-divisional_app_info",
        "description": "Retrieves divisional application data associated with the defined patent application number.\n\nRequest defines an application number as URL parameter.\n\nDefines a patent application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/divisional_app_info/2007035937",
        "parameters": []
      }
    },
    "/patent/v1/priority_right_app_info/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2020008423
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Patent Priority Basic Application Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing infomation on priority basic application retreved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no bibliographic information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "priorityRightInformation": {
                              "type": "array",
                              "description": "優先権基礎情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "parisPriorityApplicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9.-]+$",
                                    "description": "パリ条約に基づく優先権出願番号"
                                  },
                                  "parisPriorityDate": {
                                    "type": "string",
                                    "pattern": "^[0-9]{8}$",
                                    "description": "パリ条約に基づく優先権主張日"
                                  },
                                  "parisPriorityCountryCd": {
                                    "type": "string",
                                    "pattern": "^[A-Z]{2}$",
                                    "description": "パリ条約に基づく優先権国コード"
                                  },
                                  "nationalPriorityLawCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{1}$",
                                    "description": "国内優先権四法コード"
                                  },
                                  "nationalPriorityApplicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{10}$",
                                    "description": "国内優先権出願番号"
                                  },
                                  "nationalPriorityInternationalApplicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9]{12}$",
                                    "description": "国内優先権国際出願番号"
                                  },
                                  "nationalPriorityDate": {
                                    "type": "string",
                                    "pattern": "^[0-9]{8}$",
                                    "description": "国内優先権主張日"
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "49",
                        "data": {
                          "applicationNumber": "2020008423",
                          "priorityRightInformation": [
                            {
                              "parisPriorityApplicationNumber": "",
                              "parisPriorityDate": "",
                              "parisPriorityCountryCd": "",
                              "nationalPriorityLawCd": "1",
                              "nationalPriorityApplicationNumber": "2019139759",
                              "nationalPriorityInternationalApplicationNumber": "",
                              "nationalPriorityDate": "20190730"
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-priority_right_app_info",
        "description": "Retrieves priority basic application information associated with the defined patent application number.\n\nRequest defines an application number as URL parameter.\n\nDefines an application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/priority_right_app_info/2020008423",
        "parameters": []
      }
    },
    "/patent/v1/applicant_attorney_cd/{applicant code}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{9}$",
            "example": 718000266
          },
          "name": "applicant code",
          "in": "path",
          "required": true,
          "description": "9-letter fixed-length chart (refer to code index 01520)"
        }
      ],
      "get": {
        "summary": "Patent Applicant Name Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (retrieved names of applicants (applicants and/or attorneys)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n\n\n◆107：no applicable data found\n\nOccurs when there is no names of applicants (applicants and/or attorneys).\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicantAttorneyName": {
                              "type": "string",
                              "description": "申請人氏名・名称"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "199",
                        "data": {
                          "applicantAttorneyName": "特許庁長官"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-applicant_attorney-cd",
        "description": "Retrieves names of applicants (applicants and/or attorneys) through defined applicant codes.\n\nRequest defines an applicant code as URL parameter.\n\nDefines an applicant code for {applicant code} as shown in the example below.\n\nOne applicant code to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/applicant_attorney_cd/718000266\n",
        "parameters": []
      }
    },
    "/patent/v1/applicant_attorney/{applicants names}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "example": "特許庁長官"
          },
          "name": "applicants names",
          "in": "path",
          "required": true,
          "description": "perfect-matching"
        }
      ],
      "get": {
        "summary": "Patent Applicant Codes Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing retrieved applicants (applicants and/or attorneys) codes)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when there is no applicants codes associated with the applicants names.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicantAttorney": {
                              "type": "array",
                              "description": "申請人（出願人・代理人）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "applicantAttorneyCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "申請人コード"
                                  },
                                  "name": {
                                    "type": "string",
                                    "description": "申請人氏名・名称"
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "198",
                        "data": {
                          "applicantAttorney": [
                            {
                              "applicantAttorneyCd": "718000266",
                              "name": "特許庁長官"
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-applicant_attorney",
        "description": "Retrieves applicant (applicant and/or attorney) code through perfect-matching search of defined applicant name.\n\nRequest defines an applicant name as URL parameter.\n\n{applicant name} defined as shown in the example below.\n\nOne name to be defined per request.\n\nPossible to retrieve applicant (applicant and/or representatie) code if the name matches perfectly with the desugbated name.\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/applicant_attorney/特許庁長官\n",
        "parameters": []
      }
    },
    "/patent/v1/case_number_reference/{kind}/{number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^(application|publication|registration)$",
            "example": "application"
          },
          "name": "kind code",
          "in": "path",
          "description": "define 'appliation', 'publication' or 'registration'\n",
          "required": true
        },
        {
          "schema": {
            "type": "string",
            "example": "2020008423"
          },
          "name": "registration number",
          "in": "path",
          "required": true,
          "description": "Define application number, publication/release number or registration number\n\nApplication number: 10-letter fixed-length chart (Gregorian calendar year 4 digits + 0-padding patent application number)\n\nPublication/release number: 10-letter fixed-length chart (Gregorian calendar year 4 digits + 0-padding patent publication/release number)\n\nRegistration number: 7-letter fixed-length chart (refer to code index 01680)\n"
        }
      ],
      "get": {
        "summary": "Patent Number Reference API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing retrieved progress information)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when there is no information associated with the application number.\n\n\n◆111：unavailable registration number\n\nOccurs when number associated with requested parameter are not of Heisei nor Reiwa Era.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆204：Parameter Incorrect\n\nOccurs when there is a problem with the path parameter or request parameter of the API to be accessed.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "publicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "公開番号（西暦）"
                            },
                            "nationalPublicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "公表番号（西暦）"
                            },
                            "registrationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{7}$",
                              "description": "登録番号"
                            },
                            "internationalPublicationNumber": {
                              "type": "string",
                              "pattern": "^WO[0-9]{10}$",
                              "description": "国際公開番号"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "49",
                        "data": {
                          "applicationNumber": "2020008423",
                          "publicationNumber": "2021022359",
                          "nationalPublicationNumber": "",
                          "registrationNumber": "6691280",
                          "internationalPublicationNumber": ""
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "49",
                        "data": {}
                      }
                    }
                  },
                  "111：unavailable registration number": {
                    "value": {
                      "result": {
                        "statusCode": "111",
                        "errorMessage": "提供対象外の案件番号のため取得できませんでした。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "204：Parameter Incorrect": {
                    "value": {
                      "result": {
                        "statusCode": "204",
                        "errorMessage": "パラメーターの入力された値に問題があります。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-case_number_reference",
        "description": "Retrieves numbers associated with defined kind and/or number.\n\nRequest defines a set of kind and number for path to URL as parameter.\n\nOne kind and one number to be defined per request.\n\nDefine 'application' for {kind} then define application number for {number}.\n\nDefine 'publication' for {kind} then define publication/release number for {number}.\n\n- Possible to retrieve publication/release numbers of Heisei/Reiwa Eras only.\n\n- \"Tokkaihei\" and \"Tokkouhei\" should be converted into Gregorian calendar year when designating publication/release numbers.\n\nDefine 'registration' for {kind} then define registration number for {number}.\n\nDefine a patent application number as shown on the example below:\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/case_number_reference/application/2020008423",
        "parameters": []
      }
    },
    "/patent/v1/app_doc_cont_opinion_amendment/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2007035937
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Patent Application Documents Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\n** in case of retrieving patent application (written opinions and amendments) **\n\nCharacters encoded in SJIS.\n\nReturns zip file of patent application (written opinions and amendments) associated with the defined application number.\n\nFile composision image is shown below:\n\nThe folder name in the ZIP file corresponds to \"intermediate code_document number\".\n\n-------------------------------------------------------------------------------------\nExample: if there is XML file of opinions and amendments in the file of retrieved patent application documents\n\ndocContOpinionAmendment_2007035937.zip\n\n↓  extracted\n\ndocContOpinionAmendment_2007035937\n\n├ A53_50800695453\n\n    └ JPOXMLDOC01-jpbibl.xml\n\n├ A53_50802750705\n\n    └ JPOXMLDOC01-jpbibl.xml\n\n├ A523_50800695455\n\n    └ JPOXMLDOC01-jpbibl.xml\n\n├ A523_50802750709\n\n    └ JPOXMLDOC01-jpbibl.xml\n\n└  A523_50902549908\n\n    └ JPOXMLDOC01-jpbibl.xml\n\n-------------------------------------------------------------------------------------\n-------------------------------------------------------------------------------------\n\n** in case the zip file of patent application (written opinions and amendments) is larger than 10MB **\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Successfully completed status code\n\n* Empty error message\n\n* Remaining number of accesses available\n\n* Detailed information data  (URL from which response zip file can be downloaded)\n\nDetails of status codes and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when a URL from which larger than 10MB response ZIP file can be downloaded is created successfully.\n\n-------------------------------------------------------------------------------------\n-------------------------------------------------------------------------------------\n\n** in case of not retrieving patent application documents (written opinions and amendments) **\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\n\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆107：no applicable data found\n\nOccurs when no documents associated with the requested application number is found.\n\n\n◆108：no applicable substantial documents\n\nOccurs when no substantial documents of patent application (written opinions and amendments) associated with defined application number.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/zip": {
                "examples": {
                  "successfully completed": {}
                }
              },
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "URL": {
                              "type": "string",
                              "description": "データ取得URL"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "99",
                        "data": {
                          "URL": "https://ipapi-prd-upload-10mbdata-from-ecs.s3.amazonaws.com/docContOpinionAmendment_2016137779.zip?AWSAccessKeyId=ASIAVDQOAPKFGXS3S3EC&Signature=SUuJ5X3BB0aEq8rR4dW90io6kfM%3D&x-amz-security-token=IQoJb3JpZ2luX2VjEE4aDmFwLW5vcnRoZWFzdC0xIkgwRgIhAIUfMS9zYjD6k3KlBcCQaoy2cXqrTUgljCWf%2F5HeYk%2BbAiEA%2FRj2t79UmVpTB4pHLQOxmspRXkwvwGKsR%2F%2FEUvOyytMq8gMIKBABGgwzNTExNDI5Njc5NDYiDKQRhe54g34a7ZOUtirPA0LgKoT5STfLXL2tfysB2kDNazrz8KVAAZ7%2B94FJyIE54eIvJWJ5mUp3UdZdv05mM7ZEcVXMiOMOec%2FzCA80YUDyKesozuOxnKv%2FJ2fFRT2GjQeFQu0qQnxmWHSIKD6tHJSyfcSSOGj4nAIJQiNUTfRVE09wT2oWbHX8OiEdDrmhdxQbZExIpKyumvUjk919YSDbzhEao4oSCId854%2FO1qC9Ibs0nMEdqnmlbpvO1jfm4yhScnLtzzGIxEGlqezngu2hTad0SxFCzGlV9GYI1RDJYSlcnsZzU%2F68oTz%2BBEHtTiqNblmyIiFk5dPVEhmi%2FRfL%2B3%2BN6U15KEB3U7CvT7ALsQY5NwRHJW3xZ9a0hlw%2BOlrpZEz0hTNgGLhzQECRCyPE5ZX55SVZreclfiQcDQnuFP5r0JHeo6AfC8YUNAykSsybUfX8j66jug5ccmwjmsMiBRrRQlLESkQyqGT8YhHQUYV02PVtvjSfB5q7m6UNlBUQMh3GkPUoosyLgxWTq7agc0FeyIOUlecg%2B8f77DZ4Yv19oBdEf7Cwt85iqN9gW%2Faixd8cGubVCAirH5gGZHXnneb1LG6MOeFACROmY2O5JMOhX3NXpmVgtOSRZ2sw5Y65mgY6pAHefvwiieUTivp8baoGC2fnhKOKjfZuL7eANWBQJAjK5shImbSg%2F4BTwRngVZSH1MEEMSK2ycTQQDjyNW9j4%2F%2BH29kBhjuomJjg81fBpGAwZLTsaItxGR2CfM6PltQh22MnM1r%2FQgVbhJ50YZBwC3AtAHGa51QxlF5nOq%2FpV0VmMImFxjnQD92IGvl%2BqBqXOtEW%2BjGfbKlWDhfpVcYBnA4juFhjew%3D%3D&Expires=1666075263"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "108：no applicable substantial documents": {
                    "value": {
                      "result": {
                        "statusCode": "108",
                        "errorMessage": "該当する書類実体がありません。",
                        "remainAccessCount": "99"
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              },
              "headers": {}
            }
          }
        },
        "operationId": "get-app_doc_cont_opinion_amendment",
        "description": "Download zip file of substantial documents of patent application (written opinions and amendments) of defined patent application.\n\nRequest defines application number for path to URL as parameter.\n\nDefines an application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/app_doc_cont_opinion_amendment/2007035937\n\n\nReturns zip file of substantial file of documents for substantive examination of patent application (written opinions and amendments) if there is data associated with the defined application number.\n\nReturns a URL from which response zip file can be downloaded when the zip file of patent application (written opinions and amendments) associated with the defined application number is larger than 10MB. The URL is valid for 5 minutes.\n\nReturns error response in json format if there is no data associated with the defined application number.",
        "parameters": []
      }
    },
    "/patent/v1/app_doc_cont_refusal_reason_decision/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2007035937
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Mailed Patent Documents Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\n** in case of retrieving patent application documents (notice of reasons for refusal, decisions to grant patent, decision of refusal and decisions of dismissal of amendments) **\n\nCharacters encoded in SJIS.\n\nReturns zip file of mailed documents (notice of reasons for refusal, decisions to grant patent, decision of refusal and decisions of dismissal of amendments) associated with the defined application number.\n\nFile composision image is shown below:\n\n-------------------------------------------------------------------------------------\nExample: if there is XML file of in the file of notice of reasons for refusal, decisions to grant patent and decision of refusal retrieved patent application documents\n\ndocContRefusalReasonDecision_2007035937.zip\n\n↓  extracted\n\ndocContRefusalReasonDecision_2007035937\n\n  ├ 06108061091-jpntce.xml\n\n  ├ 06108649980-jpntce.xml\n\n  ├ 06109626962-jpntce.xml\n\n  └ 06110158781-jpntce.xml\n\n-------------------------------------------------------------------------------------\n-------------------------------------------------------------------------------------\n\n** in case of not retrieving mailed documents (notice of reasons for refusal, decisions to grant patent, decision of refusal and decisions of dismissal of amendments) **\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\n\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆107：no applicable data found\n\nOccurs when no document associated with the requested application number is found.\n\n\n◆108：no applicable substantial documents\n\nOccurs when no substantial documents of patent application (notice of reasons for refusal, decisions to grant patent, decision of refusal and decisions of dismissal of amendments) associated with defined application number.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/zip": {
                "examples": {
                  "successfully completed": {}
                }
              },
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ (空オブジェクト)"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "108：no applicable substantial documents": {
                    "value": {
                      "result": {
                        "statusCode": "108",
                        "errorMessage": "該当する書類実体がありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-app_doc_cont_refusal_reason_decision",
        "description": "Download zip file of mailed substantial documents of patent application (notice of reasons for refusal, decisions to grant patent, decision of refusal and decisions of dismissal of amendments) of defined patent application.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a patent applicant number for {applicant number} as shown in the example below.\n\nOne application number to be defined per request.\n\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/app_doc_cont_refusal_reason_decision/2007035937\n\n\nReturns zip file of substantial file of documents for substantive examination of patent application (notice of reasons for refusal, decisions to grant patent, decision of refusal and decisions of dismissal of amendments) if there is data associated with the defined application number.\n\nReturns error response in json format if there is no data associated with the defined application number.",
        "parameters": []
      }
    },
    "/patent/v1/app_doc_cont_refusal_reason/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2007035937
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Notice of Reasons for Refusal Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\n** Retrieved Notice of Reasons for Refusal **\n\nCharacters encoded in SJIS.\n\nReturns zip file of Notice of Reasons for Refusal associated with the defined application number.\n\nIf there are multiple number of Notice of Reasons for Refusal, they are bundled into one file to be returned.\n\nFile composision image is shown below:\n\n-------------------------------------------------------------------------------------\nExample: As a result of matching multiple number of XML files of retrieved Notice of Reasons for Refusal with part of responding image files,\n\ndocContRefusalReason_2007035937.zip\n\n↓  extracted\n\ndocContRefusalReason_2007035937\n\n  ├ 06108061091-jpntce.xml\n\n  └ 06108649980-jpntce.xml\n\n-------------------------------------------------------------------------------------\n-------------------------------------------------------------------------------------\n\n** in case of not retrieving Notice of Reasons for Refusal **\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\n\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆107：no applicable data found\n\nOccurs when no documents associated with the requested application number is found.\n\n\n◆108：no applicable substantial documents\n\nOccurs when no Notice of Reasons for Refusal associated with defined application number.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/zip": {
                "examples": {
                  "successfully completed": {}
                }
              },
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ (空オブジェクト)"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "108：no applicable substantial documents": {
                    "value": {
                      "result": {
                        "statusCode": "108",
                        "errorMessage": "該当する書類実体がありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              },
              "headers": {}
            }
          }
        },
        "operationId": "get-app_doc_cont_refusal_reason",
        "description": "Download zip file of Notice of Reasons for Refusal of defined patent application number.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a patent application number for {applicant number} as shown in the example below.\n\nOne application number to be defined per request.\n\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/app_doc_cont_refusal_reason/2007035937\n\n\nReturns zip file of specific Notice of Reasons for Refusal if there is data associated with the defined application number.\n\nReturns error response in json format if there is no data associated with the defined application number.",
        "parameters": []
      }
    },
    "/patent/v1/cite_doc_info/{application number}": {
      "parameters": [
        {
          "schema": {
            "pattern": "^[0-9]{10}$",
            "example": 2020008423
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Patent Cited Documents Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing retrieved cited documents information)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when there is no information associated with the application number.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "patentDoc": {
                              "type": "object",
                              "description": "特許文献情報データ",
                              "properties": {
                                "draftDate": {
                                  "type": "string",
                                  "pattern": "^[0-9]{8}$",
                                  "description": "起案日"
                                },
                                "citationType": {
                                  "type": "string",
                                  "description": "種別\n\n2文字固定長（コード表07010を参照）\n"
                                },
                                "citationOrder": {
                                  "type": "string",
                                  "description": "引用順番"
                                },
                                "documentNumber": {
                                  "type": "string",
                                  "description": "文献番号\n\n12〜16文字（コード表07020を参照）\n"
                                }
                              }
                            },
                            "nonPatentDoc": {
                              "type": "object",
                              "description": "非特許文献情報データ",
                              "properties": {
                                "draftDate": {
                                  "type": "string",
                                  "pattern": "^[0-9]{8}$",
                                  "description": "起案日"
                                },
                                "citationType": {
                                  "type": "string",
                                  "description": "種別\n\n2文字固定長（コード表07010を参照）\n"
                                },
                                "citationOrder": {
                                  "type": "string",
                                  "description": "引用順番"
                                },
                                "documentType": {
                                  "type": "string",
                                  "description": "文献分類\n\n3文字固定長（コード表07060を参照）\n"
                                },
                                "authorName": {
                                  "type": "string",
                                  "description": "著者/翻訳者名"
                                },
                                "paperTitle": {
                                  "type": "string",
                                  "description": "論文名/タイトル"
                                },
                                "publicationName": {
                                  "type": "string",
                                  "description": "刊行物名"
                                },
                                "issueCountryCd": {
                                  "type": "string",
                                  "description": "発行国コード\n\n2文字固定長（コード表07070を参照）\n"
                                },
                                "publisher": {
                                  "type": "string",
                                  "description": "発行所／発行者"
                                },
                                "issueDate": {
                                  "type": "string",
                                  "pattern": "^[0-9]{8}$",
                                  "description": "発行／受入年月日"
                                },
                                "issueDateType": {
                                  "type": "string",
                                  "description": "年月日フラグ\n\n1文字固定長（コード表07080を参照）\n"
                                },
                                "issueNumber": {
                                  "type": "string",
                                  "description": "版数／巻／号数"
                                },
                                "citationPages": {
                                  "type": "string",
                                  "description": "引用頁"
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "99",
                        "data": {
                          "applicationNumber": "2020008423",
                          "patentDoc": [
                            {
                              "draftDate": "20200302",
                              "citationType": "31",
                              "citationOrder": "1",
                              "documentNumber": "JPA 426119839"
                            },
                            {
                              "draftDate": "20200302",
                              "citationType": "31",
                              "citationOrder": "2",
                              "documentNumber": "JPA 415141168"
                            },
                            {
                              "draftDate": "20200302",
                              "citationType": "31",
                              "citationOrder": "3",
                              "documentNumber": "JPA 419199987"
                            },
                            {
                              "draftDate": "20200302",
                              "citationType": "31",
                              "citationOrder": "4",
                              "documentNumber": "JPA 420516341"
                            },
                            {
                              "draftDate": "20200302",
                              "citationType": "31",
                              "citationOrder": "5",
                              "documentNumber": "JPA 421211144"
                            }
                          ],
                          "nonPatentDoc": []
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-cite-doc-info",
        "description": "Retrieves cited documents information of defined patent application number.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a patent application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/cite_doc_info/2020008423",
        "parameters": []
      }
    },
    "/patent/v1/registration_info/{application number}": {
      "parameters": [
        {
          "schema": {
            "pattern": "^[0-9]{10}$",
            "example": 2020008423
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Patent Registration Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing registration information retrieved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "filingDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "出願日"
                            },
                            "registrationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{7}$",
                              "description": "登録番号"
                            },
                            "registrationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "登録日"
                            },
                            "decisionDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "査定日"
                            },
                            "appealTrialDecisiondDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "審決日"
                            },
                            "rightPersonInformation": {
                              "type": "array",
                              "description": "権利者情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "rightPersonCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "権利者コード"
                                  },
                                  "rightPersonName": {
                                    "type": "string",
                                    "description": "権利者名"
                                  }
                                }
                              }
                            },
                            "inventionTitle": {
                              "type": "string",
                              "description": "発明の名称",
                              "maxLength": 1000
                            },
                            "numberOfClaims": {
                              "type": "string",
                              "pattern": "^[0-9]{3}$",
                              "description": "請求項の数"
                            },
                            "expireDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "存続期間満了年月日"
                            },
                            "nextPensionPaymentDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "次期年金納付期限"
                            },
                            "lastPaymentYearly": {
                              "type": "string",
                              "pattern": "^[0-9]{2}$",
                              "description": "最終納付年分"
                            },
                            "erasureIdentifier": {
                              "type": "string",
                              "pattern": "^[0-9]{2}$",
                              "description": "本権利抹消識別\n\nコード表05310を参照\n"
                            },
                            "disappearanceDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "本権利抹消日"
                            },
                            "updateDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "更新日付"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "99",
                        "data": {
                          "applicationNumber": "2020008423",
                          "filingDate": "20200122",
                          "registrationNumber": "6691280",
                          "registrationDate": "20200414",
                          "decisionDate": "20200302",
                          "appealTrialDecisiondDate": "",
                          "rightPersonInformation": [
                            {
                              "rightPersonCd": "718000266",
                              "rightPersonName": "特許庁長官"
                            }
                          ],
                          "inventionTitle": "管理システム及び管理方法",
                          "numberOfClaims": "015",
                          "expireDate": "20400122",
                          "nextPensionPaymentDate'": "",
                          "lastPaymentYearly": "00",
                          "erasureIdentifier": "00",
                          "disappearanceDate": "",
                          "updateDate": "20210205"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-registration-info",
        "description": "Retrieves registration information associated with defined patent application number.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a patent application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/registration_info/2020008423",
        "parameters": []
      }
    },
    "/patent/v1/jpp_fixed_address/{application number}": {
      "parameters": [
        {
          "schema": {
            "pattern": "^[0-9]{10}$",
            "example": 2020008423
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Patent J-PlatPat Fixed Address Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing J-PlatPat Fixed Address retrieved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "URL": {
                              "type": "string",
                              "description": "J-PlatPat固定アドレス"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "199",
                        "data": {
                          "URL": "https://www.j-platpat.inpit.go.jp/c1800/PU/JP-2020-008423/A9121C47B81363B5C6B5BE66C53D6572A2DB04417E66CF7B8D79A166F5ADB8C9/10/ja"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-jpp_fixed_address",
        "description": "Retrieves J-PlatPat Fixed Address associated with defined patent application number.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a patent application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/jpp_fixed_address/2020008423",
        "parameters": []
      }
    },
    "/patent/v1/pct_national_phase_application_number/{kind}/{number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^(international_application|international_publication)$",
            "example": "international_application"
          },
          "name": "kind code",
          "in": "path",
          "description": "define international_application or international_publication\n",
          "required": true
        },
        {
          "schema": {
            "type": "string",
            "example": "JP2019011858"
          },
          "name": "registration number",
          "in": "path",
          "required": true,
          "description": "Define international application number or international publication number\n\nInternational application number：2-letter fixed-length chart country code＋10-letter fixed-length chart (Gregorian calendar year 4 digits + 0-padding patent international application number)\n\nInternational publication number：WO＋10-letter fixed-length chart (Gregorian calendar year 4 digits + 0-padding patent international publication number)\n"
        }
      ],
      "get": {
        "summary": "Patent PCT National Phase Application Number Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Patent)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing PCT national phase application number retrieved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆204：Parameter Incorrect\n\nOccurs when there is a problem with the path parameter or request parameter of the API to be accessed.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "199",
                        "data": {
                          "applicationNumber": "2019563629"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "199",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "204：Parameter Incorrect": {
                    "value": {
                      "result": {
                        "statusCode": "204",
                        "errorMessage": "パラメーターの入力された値に問題があります。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-pct_national_phase_application_number",
        "description": "Retrieves PCT national phase application number associated with defined kind and/or number.\n\nRequest defines a set of kind and number for path to URL as parameter.\n\nOne kind and one number to be defined per request.\n\nDefine 'international_application' for {kind} then define international application number for {number}.\n\nDefine 'international_publication' for {kind} then define international publication number for {number}.\n\nDefine a patent international application number as shown on the example below:\n\nExample：https://ip-data.jpo.go.jp/api/patent/v1/pct_national_phase_application_number/international_application/JP2019011858",
        "parameters": []
      }
    },
    "/design/v1/app_progress/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2022012584
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Design Progress Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Design)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing retrieved progress information)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no bibliographic information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "designArticle": {
                              "type": "string",
                              "description": "意匠に係る物品の名称",
                              "maxLength": 1000
                            },
                            "designClass": {
                              "type": "string",
                              "pattern": "^[A-Z]{1}[0-9]{5}$",
                              "description": "意匠分類"
                            },
                            "applicantAttorney": {
                              "type": "array",
                              "description": "申請人（出願人・代理人）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "applicantAttorneyCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "申請人コード"
                                  },
                                  "repeatNumber": {
                                    "type": "string",
                                    "description": "繰返番号"
                                  },
                                  "name": {
                                    "type": "string",
                                    "description": "申請人氏名・名称",
                                    "maxLength": 1000
                                  },
                                  "applicantAttorneyClass": {
                                    "type": "string",
                                    "description": "出願人・代理人識別",
                                    "pattern": "^[0-9]{1}$"
                                  }
                                }
                              }
                            },
                            "filingDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "出願日"
                            },
                            "publicationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "公開日"
                            },
                            "registrationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{7}$",
                              "description": "登録番号"
                            },
                            "registrationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "登録日"
                            },
                            "principalDesignApplicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "本意匠番号"
                            },
                            "erasureIdentifier": {
                              "type": "string",
                              "pattern": "^[0-9]{2}$",
                              "description": "抹消識別"
                            },
                            "expireDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "存続期間満了年月日"
                            },
                            "disappearanceDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "本権利消滅日"
                            },
                            "priorityRightInformation": {
                              "type": "array",
                              "description": "優先権基礎情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "parisPriorityApplicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9.-]+$",
                                    "description": "パリ条約に基づく優先権出願番号"
                                  },
                                  "parisPriorityDate": {
                                    "type": "string",
                                    "pattern": "^[0-9]{8}$",
                                    "description": "パリ条約に基づく優先権主張日"
                                  },
                                  "parisPriorityCountryCd": {
                                    "type": "string",
                                    "pattern": "^[A-Z]{2}$",
                                    "description": "パリ条約に基づく優先権国コード"
                                  }
                                }
                              }
                            },
                            "parentApplicationInformation": {
                              "type": "object",
                              "description": "原出願情報",
                              "properties": {
                                "parentApplicationCategory": {
                                  "type": "string",
                                  "description": "原出願種別",
                                  "pattern": "^[0-9]{2}$"
                                },
                                "parentApplicationLawCode": {
                                  "type": "string",
                                  "description": "原出願四法コード",
                                  "pattern": "^[1-4]{1}$"
                                },
                                "parentApplicationNumber": {
                                  "type": "string",
                                  "description": "原出願番号",
                                  "pattern": "^[0-9]{10}$"
                                }
                              }
                            },
                            "bibliographyInformation": {
                              "type": "array",
                              "description": "書類一覧（書誌）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "numberType": {
                                    "type": "string",
                                    "maxLength": 2,
                                    "description": "番号種別"
                                  },
                                  "number": {
                                    "type": "string",
                                    "maxLength": 20,
                                    "description": "番号"
                                  },
                                  "documentList": {
                                    "type": "array",
                                    "description": "書類一覧",
                                    "items": {
                                      "type": "object",
                                      "properties": {
                                        "legalDate": {
                                          "type": "string",
                                          "pattern": "^[0-9]{8}$",
                                          "description": "受付日・発送日・作成日"
                                        },
                                        "irirFlg": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "IB書類フラグ"
                                        },
                                        "availabilityFlag": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "書類実体有無"
                                        },
                                        "documentCode": {
                                          "type": "string",
                                          "pattern": "^[0-9]{7}$",
                                          "description": "中間書類コード"
                                        },
                                        "documentDescription": {
                                          "type": "string",
                                          "maxLength": 40,
                                          "description": "書類名"
                                        },
                                        "documentNumber": {
                                          "type": "string",
                                          "pattern": "^[0-9]{11}$",
                                          "description": "書類番号"
                                        },
                                        "versionNumber": {
                                          "type": "string",
                                          "maxLength": 4,
                                          "description": "バージョン番号"
                                        },
                                        "documentSeparator": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "書類識別"
                                        },
                                        "numberOfPages": {
                                          "type": "string",
                                          "maxLength": 5,
                                          "description": "ページ数"
                                        },
                                        "sizeOfDocument": {
                                          "type": "string",
                                          "maxLength": 6,
                                          "description": "ドキュメントサイズ"
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "399",
                        "data": {
                          "applicationNumber": "2022012584",
                          "designArticle": "乗用自動車",
                          "designClass": "G22100",
                          "applicantAttorney": [
                            {
                              "applicantAttorneyCd": "591037096",
                              "repeatNumber": "1",
                              "name": "フオルクスワーゲン・アクチエンゲゼルシヤフト",
                              "applicantAttorneyClass": "1"
                            },
                            {
                              "applicantAttorneyCd": "100114890",
                              "repeatNumber": "2",
                              "name": "アインゼル・フェリックス＝ラインハルト",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100209185",
                              "repeatNumber": "3",
                              "name": "松永　章吾",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100127823",
                              "repeatNumber": "4",
                              "name": "山崎　和香子",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100121809",
                              "repeatNumber": "5",
                              "name": "前川　砂織",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100124556",
                              "repeatNumber": "6",
                              "name": "大倉　桂子",
                              "applicantAttorneyClass": "2"
                            }
                          ],
                          "filingDate": "20220523",
                          "publicationDate": "",
                          "registrationNumber": "1735126",
                          "registrationDate": "20230112",
                          "principalDesignApplicationNumber": "2022011905",
                          "erasureIdentifier": "00",
                          "expireDate": "20470512",
                          "disappearanceDate": "",
                          "priorityRightInformation": [
                            {
                              "parisPriorityApplicationNumber": "402021101137.4",
                              "parisPriorityDate": "20211210",
                              "parisPriorityCountryCd": "DE"
                            }
                          ],
                          "parentApplicationInformation": {
                            "parentApplicationCategory": "10",
                            "parentApplicationLawCode": "3",
                            "parentApplicationNumber": "2022300084"
                          },
                          "bibliographyInformation": [
                            {
                              "numberType": "01",
                              "number": "2022012584",
                              "documentList": [
                                {
                                  "legalDate": "20220523",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A63",
                                  "documentDescription": "意匠登録願",
                                  "documentNumber": "52270000349",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "600145"
                                },
                                {
                                  "legalDate": "20221013",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A131",
                                  "documentDescription": "拒絶理由通知書",
                                  "documentNumber": "06322057705",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1224"
                                },
                                {
                                  "legalDate": "20221013",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A223",
                                  "documentDescription": "同一出願人による同日出願の協議指令書",
                                  "documentNumber": "06322057707",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "2133"
                                },
                                {
                                  "legalDate": "20221207",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A523",
                                  "documentDescription": "手続補正書",
                                  "documentNumber": "52202708726",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "702"
                                },
                                {
                                  "legalDate": "20221207",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A53",
                                  "documentDescription": "意見書",
                                  "documentNumber": "52202708723",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "927"
                                },
                                {
                                  "legalDate": "20221222",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A252",
                                  "documentDescription": "審査官通知（その他の通知）（期間無）",
                                  "documentNumber": "06322071592",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1397"
                                },
                                {
                                  "legalDate": "20221222",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A01",
                                  "documentDescription": "登録査定",
                                  "documentNumber": "06322071596",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "851"
                                },
                                {
                                  "legalDate": "20230110",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A61",
                                  "documentDescription": "登録料納付",
                                  "documentNumber": "BBBBBBBBBBB",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            },
                            {
                              "numberType": "06",
                              "number": "1735126",
                              "documentList": [
                                {
                                  "legalDate": "20221222",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A01",
                                  "documentDescription": "登録査定",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20230110",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "R100",
                                  "documentDescription": "設定納付書",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20230124",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "R150",
                                  "documentDescription": "登録証",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401.\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429.\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with the processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500.\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-app_progress",
        "description": "Retrieves progress information associated with defined design application number. \n\nRequest defines an application number as URL parameter.\n\n{application number} defined as in the following example.\n\nYou can define one application number per request.\n\nExample：https://ip-data.jpo.go.jp/api/design/v1/app_progress/2022012584",
        "parameters": []
      }
    },
    "/design/v1/app_progress_simple/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2022012584
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Simplified Design Progress Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Design)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing simplified design Progress infomation retreved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no bibliographic information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "designArticle": {
                              "type": "string",
                              "description": "意匠に係る物品の名称",
                              "maxLength": 1000
                            },
                            "applicantAttorney": {
                              "type": "array",
                              "description": "申請人（出願人・代理人）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "applicantAttorneyCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "申請人コード"
                                  },
                                  "repeatNumber": {
                                    "type": "string",
                                    "description": "繰返番号"
                                  },
                                  "name": {
                                    "type": "string",
                                    "description": "申請人氏名・名称",
                                    "maxLength": 1000
                                  },
                                  "applicantAttorneyClass": {
                                    "type": "string",
                                    "description": "出願人・代理人識別",
                                    "pattern": "^[0-9]{1}$"
                                  }
                                }
                              }
                            },
                            "filingDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "出願日"
                            },
                            "publicationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "公開日"
                            },
                            "registrationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{7}$",
                              "description": "登録番号"
                            },
                            "registrationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "登録日"
                            },
                            "erasureIdentifier": {
                              "type": "string",
                              "pattern": "^[0-9]{2}$",
                              "description": "抹消識別"
                            },
                            "expireDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "存続期間満了年月日"
                            },
                            "disappearanceDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "本権利消滅日"
                            },
                            "bibliographyInformation": {
                              "type": "array",
                              "description": "書類一覧（書誌）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "numberType": {
                                    "type": "string",
                                    "maxLength": 2,
                                    "description": "番号種別"
                                  },
                                  "number": {
                                    "type": "string",
                                    "maxLength": 20,
                                    "description": "番号"
                                  },
                                  "documentList": {
                                    "type": "array",
                                    "description": "書類一覧",
                                    "items": {
                                      "type": "object",
                                      "properties": {
                                        "legalDate": {
                                          "type": "string",
                                          "pattern": "^[0-9]{8}$",
                                          "description": "受付日・発送日・作成日"
                                        },
                                        "irirFlg": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "IB書類フラグ"
                                        },
                                        "availabilityFlag": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "書類実体有無"
                                        },
                                        "documentCode": {
                                          "type": "string",
                                          "pattern": "^[0-9]{7}$",
                                          "description": "中間書類コード"
                                        },
                                        "documentDescription": {
                                          "type": "string",
                                          "maxLength": 40,
                                          "description": "書類名"
                                        },
                                        "documentNumber": {
                                          "type": "string",
                                          "pattern": "^[0-9]{11}$",
                                          "description": "書類番号"
                                        },
                                        "versionNumber": {
                                          "type": "string",
                                          "maxLength": 4,
                                          "description": "バージョン番号"
                                        },
                                        "documentSeparator": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "書類識別"
                                        },
                                        "numberOfPages": {
                                          "type": "string",
                                          "maxLength": 5,
                                          "description": "ページ数"
                                        },
                                        "sizeOfDocument": {
                                          "type": "string",
                                          "maxLength": 6,
                                          "description": "ドキュメントサイズ"
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "399",
                        "data": {
                          "applicationNumber": "2022012584",
                          "designArticle": "乗用自動車",
                          "applicantAttorney": [
                            {
                              "applicantAttorneyCd": "591037096",
                              "repeatNumber": "1",
                              "name": "フオルクスワーゲン・アクチエンゲゼルシヤフト",
                              "applicantAttorneyClass": "1"
                            },
                            {
                              "applicantAttorneyCd": "100114890",
                              "repeatNumber": "2",
                              "name": "アインゼル・フェリックス＝ラインハルト",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100209185",
                              "repeatNumber": "3",
                              "name": "松永　章吾",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100127823",
                              "repeatNumber": "4",
                              "name": "山崎　和香子",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100121809",
                              "repeatNumber": "5",
                              "name": "前川　砂織",
                              "applicantAttorneyClass": "2"
                            },
                            {
                              "applicantAttorneyCd": "100124556",
                              "repeatNumber": "6",
                              "name": "大倉　桂子",
                              "applicantAttorneyClass": "2"
                            }
                          ],
                          "filingDate": "20220523",
                          "publicationDate": "",
                          "registrationNumber": "1735126",
                          "registrationDate": "20230112",
                          "erasureIdentifier": "00",
                          "expireDate": "20470512",
                          "disappearanceDate": "",
                          "bibliographyInformation": [
                            {
                              "numberType": "01",
                              "number": "2022012584",
                              "documentList": [
                                {
                                  "legalDate": "20220523",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A63",
                                  "documentDescription": "意匠登録願",
                                  "documentNumber": "52270000349",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "600145"
                                },
                                {
                                  "legalDate": "20221013",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A131",
                                  "documentDescription": "拒絶理由通知書",
                                  "documentNumber": "06322057705",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1224"
                                },
                                {
                                  "legalDate": "20221013",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A223",
                                  "documentDescription": "同一出願人による同日出願の協議指令書",
                                  "documentNumber": "06322057707",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "2133"
                                },
                                {
                                  "legalDate": "20221207",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A523",
                                  "documentDescription": "手続補正書",
                                  "documentNumber": "52202708726",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "702"
                                },
                                {
                                  "legalDate": "20221207",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A53",
                                  "documentDescription": "意見書",
                                  "documentNumber": "52202708723",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "927"
                                },
                                {
                                  "legalDate": "20221222",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A252",
                                  "documentDescription": "審査官通知（その他の通知）（期間無）",
                                  "documentNumber": "06322071592",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "1397"
                                },
                                {
                                  "legalDate": "20221222",
                                  "irirFlg": "0",
                                  "availabilityFlag": "1",
                                  "documentCode": "A01",
                                  "documentDescription": "登録査定",
                                  "documentNumber": "06322071596",
                                  "versionNumber": "0001",
                                  "documentSeparator": "S",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "851"
                                },
                                {
                                  "legalDate": "20230110",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A61",
                                  "documentDescription": "登録料納付",
                                  "documentNumber": "BBBBBBBBBBB",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            },
                            {
                              "numberType": "06",
                              "number": "1735126",
                              "documentList": [
                                {
                                  "legalDate": "20221222",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A01",
                                  "documentDescription": "登録査定",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20230110",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "R100",
                                  "documentDescription": "設定納付書",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20230124",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "R150",
                                  "documentDescription": "登録証",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-app_progress_simple",
        "description": "Retrieves progress data associated with the defined design application number (excluding basic priority information and original application information).\n\nRequest defines an application number as URL parameter.\n\n{application number} defined as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/design/v1/app_progress_simple/2022012584",
        "parameters": []
      }
    },
    "/design/v1/priority_right_app_info/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2022012584
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Design Priority Basic Application Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Design)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing infomation on priority basic application retreved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no bibliographic information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "priorityRightInformation": {
                              "type": "array",
                              "description": "優先権基礎情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "parisPriorityApplicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9.-]+$",
                                    "description": "パリ条約に基づく優先権出願番号"
                                  },
                                  "parisPriorityDate": {
                                    "type": "string",
                                    "pattern": "^[0-9]{8}$",
                                    "description": "パリ条約に基づく優先権主張日"
                                  },
                                  "parisPriorityCountryCd": {
                                    "type": "string",
                                    "pattern": "^[A-Z]{2}$",
                                    "description": "パリ条約に基づく優先権国コード"
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "29",
                        "data": {
                          "applicationNumber": "2022012584",
                          "priorityRightInformation": [
                            {
                              "parisPriorityApplicationNumber": "402021101137.4",
                              "parisPriorityDate": "20211210",
                              "parisPriorityCountryCd": "DE"
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-priority_right_app_info",
        "description": "Retrieves priority basic application information associated with the defined design application number.\n\nRequest defines an application number as URL parameter.\n\nDefines an application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/design/v1/priority_right_app_info/2022012584",
        "parameters": []
      }
    },
    "/design/v1/applicant_attorney_cd/{applicant code}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{9}$",
            "example": 591037096
          },
          "name": "applicant code",
          "in": "path",
          "required": true,
          "description": "9-letter fixed-length chart (refer to code index 01520)"
        }
      ],
      "get": {
        "summary": "Design Applicant Name Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Design)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (retrieved names of applicants (applicants and/or attorneys)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n\n\n◆107：no applicable data found\n\nOccurs when there is no names of applicants (applicants and/or attorneys).\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicantAttorneyName": {
                              "type": "string",
                              "description": "申請人氏名・名称"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "199",
                        "data": {
                          "applicantAttorneyName": "フオルクスワーゲン・アクチエンゲゼルシヤフト"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-applicant_attorney-cd",
        "description": "Retrieves names of applicants (applicants and/or attorneys) through defined applicant codes.\n\nRequest defines an applicant code as URL parameter.\n\nDefines an applicant code for {applicant code} as shown in the example below.\n\nOne applicant code to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/design/v1/applicant_attorney_cd/591037096\n",
        "parameters": []
      }
    },
    "/design/v1/applicant_attorney/{applicants names}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "example": "アッコ　ブランズ　コーポレイション"
          },
          "name": "applicants names",
          "in": "path",
          "required": true,
          "description": "perfect-matching"
        }
      ],
      "get": {
        "summary": "Design Applicant Codes Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Design)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing retrieved applicants (applicants and/or attorneys) codes)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when there is no applicants codes associated with the applicants names.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicantAttorney": {
                              "type": "array",
                              "description": "申請人（出願人・代理人）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "applicantAttorneyCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "申請人コード"
                                  },
                                  "name": {
                                    "type": "string",
                                    "description": "申請人氏名・名称"
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "199",
                        "data": {
                          "applicantAttorney": [
                            {
                              "applicantAttorneyCd": "516092430",
                              "name": "アッコ　ブランズ　コーポレイション"
                            },
                            {
                              "applicantAttorneyCd": "516297943",
                              "name": "アッコ　ブランズ　コーポレイション"
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-applicant_attorney",
        "description": "Retrieves applicant (applicant and/or attorney) code through perfect-matching search of defined applicant name.\n\nRequest defines an applicant name as URL parameter.\n\n{applicant name} defined as shown in the example below.\n\nOne name to be defined per request.\n\nPossible to retrieve applicant (applicant and/or representatie) code if the name matches perfectly with the desugbated name.\n\nExample：https://ip-data.jpo.go.jp/api/design/v1/applicant_attorney/アッコ　ブランズ　コーポレイション\n",
        "parameters": []
      }
    },
    "/design/v1/case_number_reference/{kind}/{number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^(application|registration)$",
            "example": "application"
          },
          "name": "kind code",
          "in": "path",
          "description": "define 'appliation' or 'registration'\n",
          "required": true
        },
        {
          "schema": {
            "type": "string",
            "example": "2016500748"
          },
          "name": "registration number",
          "in": "path",
          "required": true,
          "description": "Define application number or registration number\n\nApplication number: 10-letter fixed-length chart (Gregorian calendar year 4 digits + 0-padding design application number)\n\nRegistration number: 7-letter fixed-length chart (refer to code index 01680)\n"
        }
      ],
      "get": {
        "summary": "Design Number Reference API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Design)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing retrieved progress information)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when there is no information associated with the application number.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆204：Parameter Incorrect\n\nOccurs when there is a problem with the path parameter or request parameter of the API to be accessed.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "registrationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{7}$",
                              "description": "登録番号"
                            },
                            "internationalRegistrationNumber": {
                              "type": "string",
                              "pattern": "^[A-Z]{2}[0-9]{6}$",
                              "description": "国際登録番号"
                            },
                            "designNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{3}$",
                              "description": "意匠番号"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "49",
                        "data": {
                          "applicationNumber": "2016500748",
                          "registrationNumber": "1581216",
                          "internationalRegistrationNumber": "DM/091050",
                          "designNumber": "001"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "49",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "204：Parameter Incorrect": {
                    "value": {
                      "result": {
                        "statusCode": "204",
                        "errorMessage": "パラメーターの入力された値に問題があります。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-case_number_reference",
        "description": "Retrieves numbers associated with defined kind and/or number.\n\nRequest defines a set of kind and number for path to URL as parameter.\n\nOne kind and one number to be defined per request.\n\nDefine 'application' for {kind} then define application number for {number}.\n\nDefine 'registration' for {kind} then define registration number for {number}.\n\nDefine a design application number as shown on the example below:\n\nExample：https://ip-data.jpo.go.jp/api/design/v1/case_number_reference/application/2016500748",
        "parameters": []
      }
    },
    "/design/v1/app_doc_cont_opinion_amendment/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2020021161
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Design Application Documents Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Design)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\n** in case of retrieving design application (written opinions and amendments) **\n\nCharacters encoded in SJIS.\n\nReturns zip file of design application (written opinions and amendments) associated with the defined application number.\n\nFile composision image is shown below:\n\nThe folder name in the ZIP file corresponds to \"intermediate code_document number\".\n\n-------------------------------------------------------------------------------------\nExample: if there is HTM file of opinions and amendments in the file of retrieved design application documents with part of responding image files,\n\ndocContOpinionAmendment_2020021161.zip\n\n↓  extracted\n\ndocContOpinionAmendment_2020021161\n\n├ A53_52100384909\n\n    └ JPOSGMLDOC1P.HTM\n\n└ A523_52100384910\n\n    └ JPOSGMLDOC1P.HTM\n\n    └ JPOSGMLDOC10001.JPG\n\n    └ JPOSGMLDOC10002.JPG\n\n    └ JPOSGMLDOC10003.JPG\n\n    └ JPOSGMLDOC10004.JPG\n\n    └ JPOSGMLDOC10005.JPG\n\n    └ JPOSGMLDOC10006.JPG\n\n    └ JPOSGMLDOC10007.JPG\n\n-------------------------------------------------------------------------------------\n-------------------------------------------------------------------------------------\n\n** in case the zip file of design application (written opinions and amendments) is larger than 10MB **\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Successfully completed status code\n\n* Empty error message\n\n* Remaining number of accesses available\n\n* Detailed information data  (URL from which response zip file can be downloaded)\n\nDetails of status codes and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when a URL from which larger than 10MB response ZIP file can be downloaded is created successfully.\n\n-------------------------------------------------------------------------------------\n-------------------------------------------------------------------------------------\n\n** in case of not retrieving design application documents (written opinions and amendments) **\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\n\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆107：no applicable data found\n\nOccurs when no documents associated with the requested application number is found.\n\n\n◆108：no applicable substantial documents\n\nOccurs when no substantial documents of design application (written opinions and amendments) associated with defined application number.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/zip": {
                "examples": {
                  "successfully completed": {}
                }
              },
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "URL": {
                              "type": "string",
                              "description": "データ取得URL"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "99",
                        "data": {
                          "URL": "https://ipapi-prd-upload-10mbdata-from-ecs.s3.amazonaws.com/docContOpinionAmendment_2016137779.zip?AWSAccessKeyId=ASIAVDQOAPKFGXS3S3EC&Signature=SUuJ5X3BB0aEq8rR4dW90io6kfM%3D&x-amz-security-token=IQoJb3JpZ2luX2VjEE4aDmFwLW5vcnRoZWFzdC0xIkgwRgIhAIUfMS9zYjD6k3KlBcCQaoy2cXqrTUgljCWf%2F5HeYk%2BbAiEA%2FRj2t79UmVpTB4pHLQOxmspRXkwvwGKsR%2F%2FEUvOyytMq8gMIKBABGgwzNTExNDI5Njc5NDYiDKQRhe54g34a7ZOUtirPA0LgKoT5STfLXL2tfysB2kDNazrz8KVAAZ7%2B94FJyIE54eIvJWJ5mUp3UdZdv05mM7ZEcVXMiOMOec%2FzCA80YUDyKesozuOxnKv%2FJ2fFRT2GjQeFQu0qQnxmWHSIKD6tHJSyfcSSOGj4nAIJQiNUTfRVE09wT2oWbHX8OiEdDrmhdxQbZExIpKyumvUjk919YSDbzhEao4oSCId854%2FO1qC9Ibs0nMEdqnmlbpvO1jfm4yhScnLtzzGIxEGlqezngu2hTad0SxFCzGlV9GYI1RDJYSlcnsZzU%2F68oTz%2BBEHtTiqNblmyIiFk5dPVEhmi%2FRfL%2B3%2BN6U15KEB3U7CvT7ALsQY5NwRHJW3xZ9a0hlw%2BOlrpZEz0hTNgGLhzQECRCyPE5ZX55SVZreclfiQcDQnuFP5r0JHeo6AfC8YUNAykSsybUfX8j66jug5ccmwjmsMiBRrRQlLESkQyqGT8YhHQUYV02PVtvjSfB5q7m6UNlBUQMh3GkPUoosyLgxWTq7agc0FeyIOUlecg%2B8f77DZ4Yv19oBdEf7Cwt85iqN9gW%2Faixd8cGubVCAirH5gGZHXnneb1LG6MOeFACROmY2O5JMOhX3NXpmVgtOSRZ2sw5Y65mgY6pAHefvwiieUTivp8baoGC2fnhKOKjfZuL7eANWBQJAjK5shImbSg%2F4BTwRngVZSH1MEEMSK2ycTQQDjyNW9j4%2F%2BH29kBhjuomJjg81fBpGAwZLTsaItxGR2CfM6PltQh22MnM1r%2FQgVbhJ50YZBwC3AtAHGa51QxlF5nOq%2FpV0VmMImFxjnQD92IGvl%2BqBqXOtEW%2BjGfbKlWDhfpVcYBnA4juFhjew%3D%3D&Expires=1666075263"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "108：no applicable substantial documents": {
                    "value": {
                      "result": {
                        "statusCode": "108",
                        "errorMessage": "該当する書類実体がありません。",
                        "remainAccessCount": "99"
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              },
              "headers": {}
            }
          }
        },
        "operationId": "get-app_doc_cont_opinion_amendment",
        "description": "Download zip file of substantial documents of design application (written opinions and amendments) of defined design application.\n\nRequest defines application number for path to URL as parameter.\n\nDefines an application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\n\nExample：https://ip-data.jpo.go.jp/api/design/v1/app_doc_cont_opinion_amendment/2020021161\n\n\nReturns zip file of substantial file of documents for substantive examination of design application (written opinions and amendments) if there is data associated with the defined application number.\n\nReturns a URL from which response zip file can be downloaded when the zip file of design application (written opinions and amendments) associated with the defined application number is larger than 10MB. The URL is valid for 5 minutes.\n\nReturns error response in json format if there is no data associated with the defined application number.",
        "parameters": []
      }
    },
    "/design/v1/app_doc_cont_refusal_reason_decision/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2020009549
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Mailed Design Documents Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Design)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\n** in case of retrieving design application documents (notice of reasons for refusal, decisions to grant registration, decision of refusal and decisions of dismissal of amendments) **\n\nCharacters encoded in SJIS.\n\nReturns zip file of mailed documents (notice of reasons for refusal, decisions to grant registration, decision of refusal and decisions of dismissal of amendments) associated with the defined application number.\n\nFile composision image is shown below:\n\n-------------------------------------------------------------------------------------\nExample: if there is HTM file of in the file of notice of reasons for refusal, decisions to grant registration and decisions of dismissal of amendments retrieved design application documents\n\ndocContRefusalReasonDecision_2020009549.zip\n\n↓  extracted\n\ndocContRefusalReasonDecision_2020009549\n\n  ├ 06320063863P.HTM\n\n  ├ 06321024685P.HTM\n\n  ├ 06321054907P.HTM\n\n  └ 06322053487P.HTM\n\n-------------------------------------------------------------------------------------\n-------------------------------------------------------------------------------------\n\n** in case of not retrieving mailed documents (notice of reasons for refusal, decisions to grant registration, decision of refusal and decisions of dismissal of amendments) **\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\n\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆107：no applicable data found\n\nOccurs when no document associated with the requested application number is found.\n\n\n◆108：no applicable substantial documents\n\nOccurs when no substantial documents of design application (notice of reasons for refusal, decisions to grant registration, decision of refusal and decisions of dismissal of amendments) associated with defined application number.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/zip": {
                "examples": {
                  "successfully completed": {}
                }
              },
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ (空オブジェクト)"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "108：no applicable substantial documents": {
                    "value": {
                      "result": {
                        "statusCode": "108",
                        "errorMessage": "該当する書類実体がありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-app_doc_cont_refusal_reason_decision",
        "description": "Download zip file of mailed substantial documents of design application (notice of reasons for refusal, decisions to grant registration, decision of refusal and decisions of dismissal of amendments) of defined design application.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a design application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\n\nExample：https://ip-data.jpo.go.jp/api/design/v1/app_doc_cont_refusal_reason_decision/2020009549\n\n\nReturns zip file of substantial file of documents for substantive examination of design application (notice of reasons for refusal, decisions to grant registration, decision of refusal and decisions of dismissal of amendments) if there is data associated with the defined application number.\n\nReturns error response in json format if there is no data associated with the defined application number.",
        "parameters": []
      }
    },
    "/design/v1/app_doc_cont_refusal_reason/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2020009549
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Notice of Reasons for Refusal Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Design)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\n** Retrieved Notice of Reasons for Refusal **\n\nCharacters encoded in SJIS.\n\nReturns zip file of Notice of Reasons for Refusal associated with the defined application number.\n\nIf there are multiple number of Notice of Reasons for Refusal, they are bundled into one file to be returned.\n\nFile composision image is shown below:\n\n-------------------------------------------------------------------------------------\nExample: As a result of matching multiple number of HTM files of retrieved Notice of Reasons for Refusal\n\ndocContRefusalReason_2020009549.zip\n\n↓  extracted\n\ndocContRefusalReason_2020009549\n\n  └ 06320063863P.HTM\n\n-------------------------------------------------------------------------------------\n-------------------------------------------------------------------------------------\n\n** in case of not retrieving Notice of Reasons for Refusal **\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\n\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆107：no applicable data found\n\nOccurs when no documents associated with the requested application number is found.\n\n\n◆108：no applicable substantial documents\n\nOccurs when no Notice of Reasons for Refusal associated with defined application number.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/zip": {
                "examples": {
                  "successfully completed": {}
                }
              },
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ (空オブジェクト)"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "108：no applicable substantial documents": {
                    "value": {
                      "result": {
                        "statusCode": "108",
                        "errorMessage": "該当する書類実体がありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              },
              "headers": {}
            }
          }
        },
        "operationId": "get-app_doc_cont_refusal_reason",
        "description": "Download zip file of Notice of Reasons for Refusal of defined design application number.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a design application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\n\nExample：https://ip-data.jpo.go.jp/api/design/v1/app_doc_cont_refusal_reason/2020009549\n\n\nReturns zip file of specific Notice of Reasons for Refusal if there is data associated with the defined application number.\n\nReturns error response in json format if there is no data associated with the defined application number.",
        "parameters": []
      }
    },
    "/design/v1/registration_info/{application number}": {
      "parameters": [
        {
          "schema": {
            "pattern": "^[0-9]{10}$",
            "example": 2022012584
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Design Registration Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Design)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing registration information retrieved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "filingDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "出願日"
                            },
                            "registrationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{7}$",
                              "description": "登録番号"
                            },
                            "registrationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "登録日"
                            },
                            "decisionDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "査定日"
                            },
                            "appealTrialDecisiondDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "審決日"
                            },
                            "rightPersonInformation": {
                              "type": "array",
                              "description": "権利者情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "rightPersonCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "権利者コード"
                                  },
                                  "rightPersonName": {
                                    "type": "string",
                                    "description": "権利者名"
                                  }
                                }
                              }
                            },
                            "designArticle": {
                              "type": "string",
                              "description": "意匠に係る物品の名称",
                              "maxLength": 1000
                            },
                            "expireDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "存続期間満了年月日"
                            },
                            "nextPensionPaymentDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "次期年金納付期限"
                            },
                            "lastPaymentYearly": {
                              "type": "string",
                              "pattern": "^[0-9]{2}$",
                              "description": "最終納付年分"
                            },
                            "erasureIdentifier": {
                              "type": "string",
                              "pattern": "^[0-9]{2}$",
                              "description": "本権利抹消識別\n\nコード表05310を参照\n"
                            },
                            "disappearanceDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "本権利抹消日"
                            },
                            "updateDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "更新日付"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "199",
                        "data": {
                          "applicationNumber": "2022012584",
                          "filingDate": "20220523",
                          "registrationNumber": "1735126",
                          "registrationDate": "20230112",
                          "decisionDate": "20221219",
                          "appealTrialDecisiondDate": "",
                          "rightPersonInformation": [
                            {
                              "rightPersonCd": "591037096",
                              "rightPersonName": "フオルクスワーゲン・アクチエンゲゼルシヤフト"
                            }
                          ],
                          "designArticle": "乗用自動車",
                          "expireDate": "20470512",
                          "nextPensionPaymentDate": "20260112",
                          "lastPaymentYearly": "03",
                          "erasureIdentifier": "00",
                          "disappearanceDate": "",
                          "updateDate": "20230112"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-registration-info",
        "description": "Retrieves registration information associated with defined design application number.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a design application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/design/v1/registration_info/2022012584",
        "parameters": []
      }
    },
    "/design/v1/jpp_fixed_address/{application number}": {
      "parameters": [
        {
          "schema": {
            "pattern": "^[0-9]{10}$",
            "example": 2022012584
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Design J-PlatPat Fixed Address Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Design)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing J-PlatPat Fixed Address retrieved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "URL": {
                              "type": "string",
                              "description": "J-PlatPat固定アドレス"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "199",
                        "data": {
                          "URL": "https://www.j-platpat.inpit.go.jp/c1800/DE/JP-2022-012584/27DBA8496517D2F4B482AEB97A0FC03B7FCD90E236B6B4847FDC349CB22E6034/30/ja"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-jpp_fixed_address",
        "description": "Retrieves J-PlatPat Fixed Address associated with defined design application number.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a design application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/design/v1/jpp_fixed_address/2022012584",
        "parameters": []
      }
    },
    "/trademark/v1/app_progress/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2018009480
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Trademark Progress Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Trademark)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing retrieved progress information)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no bibliographic information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "applicantAttorney": {
                              "type": "array",
                              "description": "申請人（出願人・代理人）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "applicantAttorneyCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "申請人コード"
                                  },
                                  "name": {
                                    "type": "string",
                                    "description": "申請人氏名・名称",
                                    "maxLength": 1000
                                  },
                                  "applicantAttorneyClass": {
                                    "type": "string",
                                    "description": "出願人・代理人識別",
                                    "pattern": "^[0-9]{1}$"
                                  }
                                }
                              }
                            },
                            "filingDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "出願日"
                            },
                            "publicationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "公開日"
                            },
                            "registrationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{7}$",
                              "description": "登録番号"
                            },
                            "registrationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "登録日"
                            },
                            "erasureIdentifier": {
                              "type": "string",
                              "pattern": "^[0-9]{2}$",
                              "description": "抹消識別"
                            },
                            "expireDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "存続期間満了年月日"
                            },
                            "disappearanceDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "本権利消滅日"
                            },
                            "trademarkForDisplay": {
                              "type": "string",
                              "description": "表示用商標"
                            },
                            "transliteration": {
                              "type": "object",
                              "description": "称呼"
                            },
                            "viennaClass": {
                              "type": "object",
                              "description": "ウィーン図形分類"
                            },
                            "goodsServiceInformation": {
                              "type": "array",
                              "description": "商品区分情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "goodsServiceClass": {
                                    "type": "string",
                                    "pattern": "^[0-9]{2}$",
                                    "description": "指定商品又は指定役務の区分"
                                  },
                                  "goodsServiceName": {
                                    "type": "string",
                                    "description": "指定商品又は指定役務名"
                                  },
                                  "similarCode": {
                                    "type": "string",
                                    "pattern": "^[0-9]{2}[A-Z]{1}[0-9]{2}$",
                                    "description": "類似群コード"
                                  }
                                }
                              }
                            },
                            "priorityRightInformation": {
                              "type": "array",
                              "description": "優先権基礎情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "parisPriorityApplicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9.-]+$",
                                    "description": "パリ条約に基づく優先権出願番号"
                                  },
                                  "parisPriorityDate": {
                                    "type": "string",
                                    "pattern": "^[0-9]{8}$",
                                    "description": "パリ条約に基づく優先権主張日"
                                  },
                                  "parisPriorityCountryCd": {
                                    "type": "string",
                                    "pattern": "^[A-Z]{2}$",
                                    "description": "パリ条約に基づく優先権国コード"
                                  }
                                }
                              }
                            },
                            "parentApplicationInformation": {
                              "type": "object",
                              "description": "原出願情報",
                              "properties": {
                                "parentApplicationCategory": {
                                  "type": "string",
                                  "description": "原出願種別",
                                  "pattern": "^[0-9]{2}$"
                                },
                                "parentApplicationLawCode": {
                                  "type": "string",
                                  "description": "原出願四法コード",
                                  "pattern": "^[1-4]{1}$"
                                },
                                "parentApplicationNumber": {
                                  "type": "string",
                                  "description": "原出願番号",
                                  "pattern": "^[0-9]{10}$"
                                }
                              }
                            },
                            "bibliographyInformation": {
                              "type": "array",
                              "description": "書類一覧（書誌）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "numberType": {
                                    "type": "string",
                                    "maxLength": 2,
                                    "description": "番号種別"
                                  },
                                  "number": {
                                    "type": "string",
                                    "maxLength": 20,
                                    "description": "番号"
                                  },
                                  "documentList": {
                                    "type": "array",
                                    "description": "書類一覧",
                                    "items": {
                                      "type": "object",
                                      "properties": {
                                        "legalDate": {
                                          "type": "string",
                                          "pattern": "^[0-9]{8}$",
                                          "description": "受付日・発送日・作成日"
                                        },
                                        "irirFlg": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "IB書類フラグ"
                                        },
                                        "availabilityFlag": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "書類実体有無"
                                        },
                                        "documentCode": {
                                          "type": "string",
                                          "pattern": "^[0-9]{7}$",
                                          "description": "中間書類コード"
                                        },
                                        "documentDescription": {
                                          "type": "string",
                                          "maxLength": 40,
                                          "description": "書類名"
                                        },
                                        "documentNumber": {
                                          "type": "string",
                                          "pattern": "^[0-9]{11}$",
                                          "description": "書類番号"
                                        },
                                        "versionNumber": {
                                          "type": "string",
                                          "maxLength": 4,
                                          "description": "バージョン番号"
                                        },
                                        "documentSeparator": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "書類識別"
                                        },
                                        "numberOfPages": {
                                          "type": "string",
                                          "maxLength": 5,
                                          "description": "ページ数"
                                        },
                                        "sizeOfDocument": {
                                          "type": "string",
                                          "maxLength": 6,
                                          "description": "ドキュメントサイズ"
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "399",
                        "data": {
                          "applicationNumber": "2018009480",
                          "applicantAttorney": [
                            {
                              "applicantAttorneyCd": "718000266",
                              "name": "特許庁長官",
                              "applicantAttorneyClass": "1"
                            }
                          ],
                          "filingDate": "20180124",
                          "publicationDate": "20180206",
                          "registrationNumber": "6036291",
                          "registrationDate": "20180420",
                          "erasureIdentifier": "00",
                          "expireDate": "20280420",
                          "disappearanceDate": "",
                          "trademarkForDisplay": "Ｌｏｃａｌ　Ｓｐｅｃｉａｌｔｙ∞地域団体商標＼特許庁",
                          "transliteration": {
                            "0": "ローカルスペシャルティーチイキダンタイショーヒョートッキョチョー",
                            "1": "ローカルスペシャルティー",
                            "2": "チイキダンタイショーヒョートッキョチョー",
                            "3": "チイキダンタイショーヒョー",
                            "4": "チイキダンタイ",
                            "5": "トッキョチョー"
                          },
                          "viennaClass": {
                            "0": "1.17.11.1",
                            "1": "26.1.1",
                            "2": "26.1.3",
                            "3": "26.1.12",
                            "4": "26.1.16",
                            "5": "26.1.20",
                            "6": "26.1.21",
                            "7": "26.2.7",
                            "8": "29.1.1.1",
                            "9": "29.1.1.2",
                            "10": "29.1.3.2",
                            "11": "29.1.8.1",
                            "12": "29.1.11"
                          },
                          "goodsServiceInformation": [
                            {
                              "goodsServiceClass": "09",
                              "goodsServiceName": "電子出版物，インターネットを利用して受信し、及び保存することができる画像ファイル，記録済みデータ記録媒体",
                              "similarCode": "09G53 11C01 24A01 24E01 24E02 26A01 26D01"
                            },
                            {
                              "goodsServiceClass": "16",
                              "goodsServiceName": "パンフレット，書籍",
                              "similarCode": "26A01"
                            },
                            {
                              "goodsServiceClass": "41",
                              "goodsServiceName": "知識の教授，セミナー・研修会・講習会・シンポジウム・コンテストの企画・運営又は開催，電子出版物の提供，オンラインによる映像の提供（ダウンロードできないものに限る。）",
                              "similarCode": "41A01 41A03 41C02 41E02 41F06"
                            },
                            {
                              "goodsServiceClass": "45",
                              "goodsServiceName": "工業所有権に関する助言，工業所有権に関する情報の提供",
                              "similarCode": "42R01"
                            }
                          ],
                          "priorityRightInformation": [],
                          "parentApplicationInformation": {},
                          "bibliographyInformation": [
                            {
                              "numberType": "01",
                              "number": "2018009480",
                              "documentList": [
                                {
                                  "legalDate": "20180124",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A63",
                                  "documentDescription": "商標登録願",
                                  "documentNumber": "51800141837",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180307",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A871",
                                  "documentDescription": "早期審査に関する事情説明書",
                                  "documentNumber": "51800471314",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180315",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A971005",
                                  "documentDescription": "早期審査に関する報告書",
                                  "documentNumber": "96418007168",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180319",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A01",
                                  "documentDescription": "登録査定",
                                  "documentNumber": "06418044149",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180524",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A861",
                                  "documentDescription": "ファイル記録事項の閲覧（縦覧）請求書",
                                  "documentNumber": "00518005715",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180604",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A861",
                                  "documentDescription": "ファイル記録事項の閲覧（縦覧）請求書",
                                  "documentNumber": "00518006126",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180913",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A861",
                                  "documentDescription": "ファイル記録事項の閲覧（縦覧）請求書",
                                  "documentNumber": "00518010389",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180919",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A861",
                                  "documentDescription": "ファイル記録事項の閲覧（縦覧）請求書",
                                  "documentNumber": "00518010619",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20190514",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A861",
                                  "documentDescription": "ファイル記録事項の閲覧（縦覧）請求書",
                                  "documentNumber": "00519005083",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            },
                            {
                              "numberType": "06",
                              "number": "6036291",
                              "documentList": [
                                {
                                  "legalDate": "20180319",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A01",
                                  "documentDescription": "登録査定",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180508",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "R150",
                                  "documentDescription": "登録証",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401.\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429.\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with the processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500.\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-app_progress",
        "description": "Retrieves progress information associated with defined trademark application number.\n\nRequest defines an application number as URL parameter.\n\n{application number} defined as in the following example.\n\nYou can define one application number per request.\n\nExample：https://ip-data.jpo.go.jp/api/trademark/v1/app_progress/2018009480\n\n*In the case of a trademark application that has been divided during the filing procedures, it is possible to obtain information on the original application from the divisional application number.\n\n*In the case of a trademark divided after the trademark was registered, the original registration information cannot be obtained from the divisional registration number.",
        "parameters": []
      }
    },
    "/trademark/v1/app_progress_simple/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2018009480
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Simplified Trademark Progress Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Trademark)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing simplified trademark Progress infomation retreved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no bibliographic information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "applicantAttorney": {
                              "type": "array",
                              "description": "申請人（出願人・代理人）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "applicantAttorneyCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "申請人コード"
                                  },
                                  "name": {
                                    "type": "string",
                                    "description": "申請人氏名・名称",
                                    "maxLength": 1000
                                  },
                                  "applicantAttorneyClass": {
                                    "type": "string",
                                    "description": "出願人・代理人識別",
                                    "pattern": "^[0-9]{1}$"
                                  }
                                }
                              }
                            },
                            "filingDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "出願日"
                            },
                            "publicationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "公開日"
                            },
                            "registrationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{7}$",
                              "description": "登録番号"
                            },
                            "registrationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "登録日"
                            },
                            "erasureIdentifier": {
                              "type": "string",
                              "pattern": "^[0-9]{2}$",
                              "description": "抹消識別"
                            },
                            "expireDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "存続期間満了年月日"
                            },
                            "disappearanceDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "本権利消滅日"
                            },
                            "trademarkForDisplay": {
                              "type": "string",
                              "description": "表示用商標"
                            },
                            "transliteration": {
                              "type": "object",
                              "description": "称呼"
                            },
                            "viennaClass": {
                              "type": "object",
                              "description": "ウィーン図形分類"
                            },
                            "goodsServiceInformation": {
                              "type": "array",
                              "description": "商品区分情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "goodsServiceClass": {
                                    "type": "string",
                                    "pattern": "^[0-9]{2}$",
                                    "description": "指定商品又は指定役務の区分"
                                  },
                                  "goodsServiceName": {
                                    "type": "string",
                                    "description": "指定商品又は指定役務名"
                                  },
                                  "similarCode": {
                                    "type": "string",
                                    "pattern": "^[0-9]{2}[A-Z]{1}[0-9]{2}$",
                                    "description": "類似群コード"
                                  }
                                }
                              }
                            },
                            "bibliographyInformation": {
                              "type": "array",
                              "description": "書類一覧（書誌）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "numberType": {
                                    "type": "string",
                                    "maxLength": 2,
                                    "description": "番号種別"
                                  },
                                  "number": {
                                    "type": "string",
                                    "maxLength": 20,
                                    "description": "番号"
                                  },
                                  "documentList": {
                                    "type": "array",
                                    "description": "書類一覧",
                                    "items": {
                                      "type": "object",
                                      "properties": {
                                        "legalDate": {
                                          "type": "string",
                                          "pattern": "^[0-9]{8}$",
                                          "description": "受付日・発送日・作成日"
                                        },
                                        "irirFlg": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "IB書類フラグ"
                                        },
                                        "availabilityFlag": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "書類実体有無"
                                        },
                                        "documentCode": {
                                          "type": "string",
                                          "pattern": "^[0-9]{7}$",
                                          "description": "中間書類コード"
                                        },
                                        "documentDescription": {
                                          "type": "string",
                                          "maxLength": 40,
                                          "description": "書類名"
                                        },
                                        "documentNumber": {
                                          "type": "string",
                                          "pattern": "^[0-9]{11}$",
                                          "description": "書類番号"
                                        },
                                        "versionNumber": {
                                          "type": "string",
                                          "maxLength": 4,
                                          "description": "バージョン番号"
                                        },
                                        "documentSeparator": {
                                          "type": "string",
                                          "pattern": "^[0-9]{1}$",
                                          "description": "書類識別"
                                        },
                                        "numberOfPages": {
                                          "type": "string",
                                          "maxLength": 5,
                                          "description": "ページ数"
                                        },
                                        "sizeOfDocument": {
                                          "type": "string",
                                          "maxLength": 6,
                                          "description": "ドキュメントサイズ"
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "399",
                        "data": {
                          "applicationNumber": "2018009480",
                          "applicantAttorney": [
                            {
                              "applicantAttorneyCd": "718000266",
                              "name": "特許庁長官",
                              "applicantAttorneyClass": "1"
                            }
                          ],
                          "filingDate": "20180124",
                          "publicationDate": "20180206",
                          "registrationNumber": "6036291",
                          "registrationDate": "20180420",
                          "erasureIdentifier": "00",
                          "expireDate": "20280420",
                          "disappearanceDate": "",
                          "trademarkForDisplay": "Ｌｏｃａｌ　Ｓｐｅｃｉａｌｔｙ∞地域団体商標＼特許庁",
                          "transliteration": {
                            "0": "ローカルスペシャルティーチイキダンタイショーヒョートッキョチョー",
                            "1": "ローカルスペシャルティー",
                            "2": "チイキダンタイショーヒョートッキョチョー",
                            "3": "チイキダンタイショーヒョー",
                            "4": "チイキダンタイ",
                            "5": "トッキョチョー"
                          },
                          "viennaClass": {
                            "0": "1.17.11.1",
                            "1": "26.1.1",
                            "2": "26.1.3",
                            "3": "26.1.12",
                            "4": "26.1.16",
                            "5": "26.1.20",
                            "6": "26.1.21",
                            "7": "26.2.7",
                            "8": "29.1.1.1",
                            "9": "29.1.1.2",
                            "10": "29.1.3.2",
                            "11": "29.1.8.1",
                            "12": "29.1.11"
                          },
                          "goodsServiceInformation": [
                            {
                              "goodsServiceClass": "09",
                              "goodsServiceName": "電子出版物，インターネットを利用して受信し、及び保存することができる画像ファイル，記録済みデータ記録媒体",
                              "similarCode": "09G53 11C01 24A01 24E01 24E02 26A01 26D01"
                            },
                            {
                              "goodsServiceClass": "16",
                              "goodsServiceName": "パンフレット，書籍",
                              "similarCode": "26A01"
                            },
                            {
                              "goodsServiceClass": "41",
                              "goodsServiceName": "知識の教授，セミナー・研修会・講習会・シンポジウム・コンテストの企画・運営又は開催，電子出版物の提供，オンラインによる映像の提供（ダウンロードできないものに限る。）",
                              "similarCode": "41A01 41A03 41C02 41E02 41F06"
                            },
                            {
                              "goodsServiceClass": "45",
                              "goodsServiceName": "工業所有権に関する助言，工業所有権に関する情報の提供",
                              "similarCode": "42R01"
                            }
                          ],
                          "bibliographyInformation": [
                            {
                              "numberType": "01",
                              "number": "2018009480",
                              "documentList": [
                                {
                                  "legalDate": "20180124",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A63",
                                  "documentDescription": "商標登録願",
                                  "documentNumber": "51800141837",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180307",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A871",
                                  "documentDescription": "早期審査に関する事情説明書",
                                  "documentNumber": "51800471314",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180315",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A971005",
                                  "documentDescription": "早期審査に関する報告書",
                                  "documentNumber": "96418007168",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180319",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A01",
                                  "documentDescription": "登録査定",
                                  "documentNumber": "06418044149",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180524",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A861",
                                  "documentDescription": "ファイル記録事項の閲覧（縦覧）請求書",
                                  "documentNumber": "00518005715",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180604",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A861",
                                  "documentDescription": "ファイル記録事項の閲覧（縦覧）請求書",
                                  "documentNumber": "00518006126",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180913",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A861",
                                  "documentDescription": "ファイル記録事項の閲覧（縦覧）請求書",
                                  "documentNumber": "00518010389",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180919",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A861",
                                  "documentDescription": "ファイル記録事項の閲覧（縦覧）請求書",
                                  "documentNumber": "00518010619",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20190514",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A861",
                                  "documentDescription": "ファイル記録事項の閲覧（縦覧）請求書",
                                  "documentNumber": "00519005083",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            },
                            {
                              "numberType": "06",
                              "number": "6036291",
                              "documentList": [
                                {
                                  "legalDate": "20180319",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "A01",
                                  "documentDescription": "登録査定",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                },
                                {
                                  "legalDate": "20180508",
                                  "irirFlg": "0",
                                  "availabilityFlag": "0",
                                  "documentCode": "R150",
                                  "documentDescription": "登録証",
                                  "documentNumber": "99999999999",
                                  "versionNumber": "0000",
                                  "documentSeparator": " ",
                                  "numberOfPages": "0",
                                  "sizeOfDocument": "0"
                                }
                              ]
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-app_progress_simple",
        "description": "Retrieves progress data associated with the defined trademark application number (excluding basic priority information and original application information).\n\nRequest defines an application number as URL parameter.\n\n{application number} defined as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/trademark/v1/app_progress_simple/2018009480",
        "parameters": []
      }
    },
    "/trademark/v1/priority_right_app_info/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2020089151
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Trademark Priority Basic Application Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Trademark)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing infomation on priority basic application retreved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no bibliographic information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "priorityRightInformation": {
                              "type": "array",
                              "description": "優先権基礎情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "parisPriorityApplicationNumber": {
                                    "type": "string",
                                    "pattern": "^[0-9.-]+$",
                                    "description": "パリ条約に基づく優先権出願番号"
                                  },
                                  "parisPriorityDate": {
                                    "type": "string",
                                    "pattern": "^[0-9]{8}$",
                                    "description": "パリ条約に基づく優先権主張日"
                                  },
                                  "parisPriorityCountryCd": {
                                    "type": "string",
                                    "pattern": "^[A-Z]{2}$",
                                    "description": "パリ条約に基づく優先権国コード"
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "29",
                        "data": {
                          "applicationNumber": "2020089151",
                          "priorityRightInformation": [
                            {
                              "parisPriorityApplicationNumber": "00003477499",
                              "parisPriorityDate": "20200326",
                              "parisPriorityCountryCd": "GB"
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-priority_right_app_info",
        "description": "Retrieves priority basic application information associated with the defined trademark application number.\n\nRequest defines an application number as URL parameter.\n\nDefines an application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/trademark/v1/priority_right_app_info/2020089151",
        "parameters": []
      }
    },
    "/trademark/v1/applicant_attorney_cd/{applicant code}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{9}$",
            "example": 718000266
          },
          "name": "applicant code",
          "in": "path",
          "required": true,
          "description": "9-letter fixed-length chart (refer to code index 01520)"
        }
      ],
      "get": {
        "summary": "Trademark Applicant Name Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Trademark)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (retrieved names of applicants (applicants and/or attorneys)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n\n\n◆107：no applicable data found\n\nOccurs when there is no names of applicants (applicants and/or attorneys).\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicantAttorneyName": {
                              "type": "string",
                              "description": "申請人氏名・名称"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "199",
                        "data": {
                          "applicantAttorneyName": "特許庁長官"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-applicant_attorney-cd",
        "description": "Retrieves names of applicants (applicants and/or attorneys) through defined applicant codes.\n\nRequest defines an applicant code as URL parameter.\n\nDefines an applicant code for {applicant code} as shown in the example below.\n\nOne applicant code to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/trademark/v1/applicant_attorney_cd/718000266\n",
        "parameters": []
      }
    },
    "/trademark/v1/applicant_attorney/{applicants names}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "example": "特許庁長官"
          },
          "name": "applicants names",
          "in": "path",
          "required": true,
          "description": "perfect-matching"
        }
      ],
      "get": {
        "summary": "Trademark Applicant Codes Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Trademark)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing retrieved applicants (applicants and/or attorneys) codes)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when there is no applicants codes associated with the applicants names.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicantAttorney": {
                              "type": "array",
                              "description": "申請人（出願人・代理人）",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "applicantAttorneyCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "申請人コード"
                                  },
                                  "name": {
                                    "type": "string",
                                    "description": "申請人氏名・名称"
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "198",
                        "data": {
                          "applicantAttorney": [
                            {
                              "applicantAttorneyCd": "718000266",
                              "name": "特許庁長官"
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-applicant_attorney",
        "description": "Retrieves applicant (applicant and/or attorney) code through perfect-matching search of defined applicant name.\n\nRequest defines an applicant name as URL parameter.\n\n{applicant name} defined as shown in the example below.\n\nOne name to be defined per request.\n\nPossible to retrieve applicant (applicant and/or representatie) code if the name matches perfectly with the desugbated name.\n\nExample：https://ip-data.jpo.go.jp/api/trademark/v1/applicant_attorney/特許庁長官\n",
        "parameters": []
      }
    },
    "/trademark/v1/case_number_reference/{kind}/{number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^(application|registration)$",
            "example": "application"
          },
          "name": "kind code",
          "in": "path",
          "description": "define 'appliation' or 'registration'\n",
          "required": true
        },
        {
          "schema": {
            "type": "string",
            "example": "2018009480"
          },
          "name": "registration number",
          "in": "path",
          "required": true,
          "description": "Define application number or registration number\n\nApplication number: 10-letter fixed-length chart (Gregorian calendar year 4 digits + 0-padding trademark application number)\n\nRegistration number: 7-letter fixed-length chart (refer to code index 01680)\n"
        }
      ],
      "get": {
        "summary": "Trademark Number Reference API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Trademark)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing retrieved progress information)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when there is no information associated with the application number.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆204：Parameter Incorrect\n\nOccurs when there is a problem with the path parameter or request parameter of the API to be accessed.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "registrationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{7}$",
                              "description": "登録番号"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "49",
                        "data": {
                          "applicationNumber": "2018009480",
                          "registrationNumber": "6036291"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "49",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "204：Parameter Incorrect": {
                    "value": {
                      "result": {
                        "statusCode": "204",
                        "errorMessage": "パラメーターの入力された値に問題があります。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-case_number_reference",
        "description": "Retrieves numbers associated with defined kind and/or number.\n\nRequest defines a set of kind and number for path to URL as parameter.\n\nOne kind and one number to be defined per request.\n\nDefine 'application' for {kind} then define application number for {number}.\n\nDefine 'registration' for {kind} then define registration number for {number}.\n\nDefine a trademark application number as shown on the example below:\n\nExample：https://ip-data.jpo.go.jp/api/trademark/v1/case_number_reference/application/2018009480",
        "parameters": []
      }
    },
    "/trademark/v1/app_doc_cont_opinion_amendment/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2018039075
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Trademark Application Documents Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Trademark)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\n** in case of retrieving trademark application (written opinions and amendments) **\n\nCharacters encoded in SJIS.\n\nReturns zip file of trademark application (written opinions and amendments) associated with the defined application number.\n\nFile composision image is shown below:\n\nThe folder name in the ZIP file corresponds to \"intermediate code_document number\".\n\n-------------------------------------------------------------------------------------\nExample: if there is HTM file of opinions and amendments in the file of retrieved trademark application documents\n\ndocContOpinionAmendment_2018039075.zip\n\n↓  extracted\n\ndocContOpinionAmendment_2018039075\n\n├ A53_51900120571\n\n    └ JPOSGMLDOC1P.HTM\n\n├ A523_51900120573\n\n    └ JPOSGMLDOC1P.HTM\n\n-------------------------------------------------------------------------------------\n-------------------------------------------------------------------------------------\n\n** in case the zip file of trademark application (written opinions and amendments) is larger than 10MB **\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Successfully completed status code\n\n* Empty error message\n\n* Remaining number of accesses available\n\n* Detailed information data  (URL from which response zip file can be downloaded)\n\nDetails of status codes and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when a URL from which larger than 10MB response ZIP file can be downloaded is created successfully.\n\n-------------------------------------------------------------------------------------\n-------------------------------------------------------------------------------------\n\n** in case of not retrieving trademark application documents (written opinions and amendments) **\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\n\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆107：no applicable data found\n\nOccurs when no documents associated with the requested application number is found.\n\n\n◆108：no applicable substantial documents\n\nOccurs when no substantial documents of trademark application (written opinions and amendments) associated with defined application number.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/zip": {
                "examples": {
                  "successfully completed": {}
                }
              },
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "URL": {
                              "type": "string",
                              "description": "データ取得URL"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "99",
                        "data": {
                          "URL": "https://ipapi-prd-upload-10mbdata-from-ecs.s3.amazonaws.com/docContOpinionAmendment_2016137779.zip?AWSAccessKeyId=ASIAVDQOAPKFGXS3S3EC&Signature=SUuJ5X3BB0aEq8rR4dW90io6kfM%3D&x-amz-security-token=IQoJb3JpZ2luX2VjEE4aDmFwLW5vcnRoZWFzdC0xIkgwRgIhAIUfMS9zYjD6k3KlBcCQaoy2cXqrTUgljCWf%2F5HeYk%2BbAiEA%2FRj2t79UmVpTB4pHLQOxmspRXkwvwGKsR%2F%2FEUvOyytMq8gMIKBABGgwzNTExNDI5Njc5NDYiDKQRhe54g34a7ZOUtirPA0LgKoT5STfLXL2tfysB2kDNazrz8KVAAZ7%2B94FJyIE54eIvJWJ5mUp3UdZdv05mM7ZEcVXMiOMOec%2FzCA80YUDyKesozuOxnKv%2FJ2fFRT2GjQeFQu0qQnxmWHSIKD6tHJSyfcSSOGj4nAIJQiNUTfRVE09wT2oWbHX8OiEdDrmhdxQbZExIpKyumvUjk919YSDbzhEao4oSCId854%2FO1qC9Ibs0nMEdqnmlbpvO1jfm4yhScnLtzzGIxEGlqezngu2hTad0SxFCzGlV9GYI1RDJYSlcnsZzU%2F68oTz%2BBEHtTiqNblmyIiFk5dPVEhmi%2FRfL%2B3%2BN6U15KEB3U7CvT7ALsQY5NwRHJW3xZ9a0hlw%2BOlrpZEz0hTNgGLhzQECRCyPE5ZX55SVZreclfiQcDQnuFP5r0JHeo6AfC8YUNAykSsybUfX8j66jug5ccmwjmsMiBRrRQlLESkQyqGT8YhHQUYV02PVtvjSfB5q7m6UNlBUQMh3GkPUoosyLgxWTq7agc0FeyIOUlecg%2B8f77DZ4Yv19oBdEf7Cwt85iqN9gW%2Faixd8cGubVCAirH5gGZHXnneb1LG6MOeFACROmY2O5JMOhX3NXpmVgtOSRZ2sw5Y65mgY6pAHefvwiieUTivp8baoGC2fnhKOKjfZuL7eANWBQJAjK5shImbSg%2F4BTwRngVZSH1MEEMSK2ycTQQDjyNW9j4%2F%2BH29kBhjuomJjg81fBpGAwZLTsaItxGR2CfM6PltQh22MnM1r%2FQgVbhJ50YZBwC3AtAHGa51QxlF5nOq%2FpV0VmMImFxjnQD92IGvl%2BqBqXOtEW%2BjGfbKlWDhfpVcYBnA4juFhjew%3D%3D&Expires=1666075263"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "108：no applicable substantial documents": {
                    "value": {
                      "result": {
                        "statusCode": "108",
                        "errorMessage": "該当する書類実体がありません。",
                        "remainAccessCount": "99"
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              },
              "headers": {}
            }
          }
        },
        "operationId": "get-app_doc_cont_opinion_amendment",
        "description": "Download zip file of substantial documents of trademark application (written opinions and amendments) of defined trademark application.\n\nRequest defines application number for path to URL as parameter.\n\nDefines an application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\n\nExample：https://ip-data.jpo.go.jp/api/trademark/v1/app_doc_cont_opinion_amendment/2018039075\n\n\nReturns zip file of substantial file of documents for substantive examination of trademark application (written opinions and amendments) if there is data associated with the defined application number.\n\nReturns a URL from which response zip file can be downloaded when the zip file of trademark application (written opinions and amendments) associated with the defined application number is larger than 10MB. The URL is valid for 5 minutes.\n\nReturns error response in json format if there is no data associated with the defined application number.",
        "parameters": []
      }
    },
    "/trademark/v1/app_doc_cont_refusal_reason_decision/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2021010720
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Mailed Trademark Documents Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Trademark)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\n** in case of retrieving trademark application documents (notice of reasons for refusal, decisions to grant registration, decision of refusal and decisions of dismissal of amendments) **\n\nCharacters encoded in SJIS.\n\nReturns zip file of mailed documents (notice of reasons for refusal, decisions to grant registration, decision of refusal and decisions of dismissal of amendments) associated with the defined application number.\n\nFile composision image is shown below:\n\n-------------------------------------------------------------------------------------\nExample: if there is HTM file of in the file of notice of reasons for refusal, decisions to grant registration and decision of refusal retrieved trademark application documents with part of responding image files,\n\ndocContRefusalReasonDecision_2021010720.zip\n\n↓  extracted\n\ndocContRefusalReasonDecision_2021010720\n\n  ├ 06421238784P.HTM\n\n  ├ 06422013425P.HTM\n\n  ├ 06422109079P.HTM\n\n  ├ 064212387840001.tif\n\n  ├ 064212387840002.tif\n\n  └ 064220134250001.tif\n\n-------------------------------------------------------------------------------------\n-------------------------------------------------------------------------------------\n\n** in case of not retrieving mailed documents (notice of reasons for refusal, decisions to grant registration, decision of refusal and decisions of dismissal of amendments) **\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\n\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆107：no applicable data found\n\nOccurs when no document associated with the requested application number is found.\n\n\n◆108：no applicable substantial documents\n\nOccurs when no substantial documents of trademark application (notice of reasons for refusal, decisions to grant registration, decision of refusal and decisions of dismissal of amendments) associated with defined application number.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/zip": {
                "examples": {
                  "successfully completed": {}
                }
              },
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ (空オブジェクト)"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "108：no applicable substantial documents": {
                    "value": {
                      "result": {
                        "statusCode": "108",
                        "errorMessage": "該当する書類実体がありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-app_doc_cont_refusal_reason_decision",
        "description": "Download zip file of mailed substantial documents of trademark application (notice of reasons for refusal, decisions to grant registration, decision of refusal and decisions of dismissal of amendments) of defined trademark application.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a trademark applicant number for {applicant number} as shown in the example below.\n\nOne application number to be defined per request.\n\n\nExample：https://ip-data.jpo.go.jp/api/trademark/v1/app_doc_cont_refusal_reason_decision/2021010720\n\n\nReturns zip file of substantial file of documents for substantive examination of trademark application (notice of reasons for refusal, decisions to grant registration, decision of refusal and decisions of dismissal of amendments) if there is data associated with the defined application number.\n\nReturns error response in json format if there is no data associated with the defined application number.",
        "parameters": []
      }
    },
    "/trademark/v1/app_doc_cont_refusal_reason/{application number}": {
      "parameters": [
        {
          "schema": {
            "type": "string",
            "pattern": "^[0-9]{10}$",
            "example": 2021010720
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Notice of Reasons for Refusal Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Trademark)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\n** Retrieved Notice of Reasons for Refusal **\n\nCharacters encoded in SJIS.\n\nReturns zip file of Notice of Reasons for Refusal associated with the defined application number.\n\nIf there are multiple number of Notice of Reasons for Refusal, they are bundled into one file to be returned.\n\nFile composision image is shown below:\n\n-------------------------------------------------------------------------------------\nExample: As a result of matching multiple number of HTM files of retrieved Notice of Reasons for Refusal with part of responding image files,\n\ndocContRefusalReason_2021010720.zip\n\n↓  extracted\n\ndocContRefusalReason_2021010720\n\n  ├ 06421238784P.HTM\n\n  ├ 064212387840001.tif\n\n  └ 064212387840002.tif\n\n-------------------------------------------------------------------------------------\n-------------------------------------------------------------------------------------\n\n** in case of not retrieving Notice of Reasons for Refusal **\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\n\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆107：no applicable data found\n\nOccurs when no documents associated with the requested application number is found.\n\n\n◆108：no applicable substantial documents\n\nOccurs when no Notice of Reasons for Refusal associated with defined application number.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/zip": {
                "examples": {
                  "successfully completed": {}
                }
              },
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ (空オブジェクト)"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "108：no applicable substantial documents": {
                    "value": {
                      "result": {
                        "statusCode": "108",
                        "errorMessage": "該当する書類実体がありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              },
              "headers": {}
            }
          }
        },
        "operationId": "get-app_doc_cont_refusal_reason",
        "description": "Download zip file of Notice of Reasons for Refusal of defined trademark application number.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a trademark application number for {applicant number} as shown in the example below.\n\nOne application number to be defined per request.\n\n\nExample：https://ip-data.jpo.go.jp/api/trademark/v1/app_doc_cont_refusal_reason/2021010720\n\n\nReturns zip file of specific Notice of Reasons for Refusal if there is data associated with the defined application number.\n\nReturns error response in json format if there is no data associated with the defined application number.",
        "parameters": []
      }
    },
    "/trademark/v1/registration_info/{application number}": {
      "parameters": [
        {
          "schema": {
            "pattern": "^[0-9]{10}$",
            "example": 2018009480
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Trademark Registration Information Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Trademark)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing registration information retrieved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "applicationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{10}$",
                              "description": "出願番号"
                            },
                            "filingDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "出願日"
                            },
                            "registrationNumber": {
                              "type": "string",
                              "pattern": "^[0-9]{7}$",
                              "description": "登録番号"
                            },
                            "registrationDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "登録日"
                            },
                            "decisionDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "査定日"
                            },
                            "appealTrialDecisiondDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "審決日"
                            },
                            "rightPersonInformation": {
                              "type": "array",
                              "description": "権利者情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "rightPersonCd": {
                                    "type": "string",
                                    "pattern": "^[0-9]{9}$",
                                    "description": "権利者コード"
                                  },
                                  "rightPersonName": {
                                    "type": "string",
                                    "description": "権利者名"
                                  }
                                }
                              }
                            },
                            "trademarkForDisplay": {
                              "type": "string",
                              "description": "表示用商標"
                            },
                            "transliteration": {
                              "type": "object",
                              "description": "称呼"
                            },
                            "viennaClass": {
                              "type": "object",
                              "description": "ウィーン図形分類"
                            },
                            "goodsServiceInformation": {
                              "type": "array",
                              "description": "商品区分情報",
                              "items": {
                                "type": "object",
                                "properties": {
                                  "goodsServiceClass": {
                                    "type": "string",
                                    "pattern": "^[0-9]{2}$",
                                    "description": "指定商品又は指定役務の区分"
                                  },
                                  "goodsServiceName": {
                                    "type": "string",
                                    "description": "指定商品又は指定役務名"
                                  },
                                  "similarCode": {
                                    "type": "string",
                                    "pattern": "^[0-9]{2}[A-Z]{1}[0-9]{2}$",
                                    "description": "類似群コード"
                                  }
                                }
                              }
                            },
                            "expireDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "存続期間満了年月日"
                            },
                            "nextPensionPaymentDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "次期年金納付期限"
                            },
                            "lastPaymentYearly": {
                              "type": "string",
                              "pattern": "^[0-9]{2}$",
                              "description": "最終納付年分"
                            },
                            "erasureIdentifier": {
                              "type": "string",
                              "pattern": "^[0-9]{2}$",
                              "description": "本権利抹消識別\n\nコード表05310を参照\n"
                            },
                            "disappearanceDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "本権利抹消日"
                            },
                            "updateDate": {
                              "type": "string",
                              "pattern": "^[0-9]{8}$",
                              "description": "更新日付"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "199",
                        "data": {
                          "applicationNumber": "2018009480",
                          "filingDate": "20180124",
                          "registrationNumber": "6036291",
                          "registrationDate": "20180420",
                          "decisionDate": "20180316",
                          "appealTrialDecisiondDate": "",
                          "rightPersonInformation": [
                            {
                              "rightPersonCd": "718000266",
                              "rightPersonName": "特許庁長官"
                            }
                          ],
                          "expireDate": "20280420",
                          "nextPensionPaymentDate": "20280420",
                          "lastPaymentYearly": "10",
                          "erasureIdentifier": "00",
                          "disappearanceDate": "",
                          "updateDate": "20180420",
                          "trademarkForDisplay": "Ｌｏｃａｌ　Ｓｐｅｃｉａｌｔｙ∞地域団体商標＼特許庁",
                          "transliteration": {
                            "0": "ローカルスペシャルティーチイキダンタイショーヒョートッキョチョー",
                            "1": "ローカルスペシャルティー",
                            "2": "チイキダンタイショーヒョートッキョチョー",
                            "3": "チイキダンタイショーヒョー",
                            "4": "チイキダンタイ",
                            "5": "トッキョチョー"
                          },
                          "viennaClass": {
                            "0": "1.17.11.1",
                            "1": "26.1.1",
                            "2": "26.1.3",
                            "3": "26.1.12",
                            "4": "26.1.16",
                            "5": "26.1.20",
                            "6": "26.1.21",
                            "7": "26.2.7",
                            "8": "29.1.1.1",
                            "9": "29.1.1.2",
                            "10": "29.1.3.2",
                            "11": "29.1.8.1",
                            "12": "29.1.11"
                          },
                          "goodsServiceInformation": [
                            {
                              "goodsServiceClass": "09",
                              "goodsServiceName": "電子出版物，インターネットを利用して受信し、及び保存することができる画像ファイル，記録済みデータ記録媒体",
                              "similarCode": "09G53 11C01 24A01 24E01 24E02 26A01 26D01"
                            },
                            {
                              "goodsServiceClass": "16",
                              "goodsServiceName": "パンフレット，書籍",
                              "similarCode": "26A01"
                            },
                            {
                              "goodsServiceClass": "41",
                              "goodsServiceName": "知識の教授，セミナー・研修会・講習会・シンポジウム・コンテストの企画・運営又は開催，電子出版物の提供，オンラインによる映像の提供（ダウンロードできないものに限る。）",
                              "similarCode": "41A01 41A03 41C02 41E02 41F06"
                            },
                            {
                              "goodsServiceClass": "45",
                              "goodsServiceName": "工業所有権に関する助言，工業所有権に関する情報の提供",
                              "similarCode": "42R01"
                            }
                          ]
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-registration-info",
        "description": "Retrieves registration information associated with defined trademark application number.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a trademark application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/trademark/v1/registration_info/2018009480",
        "parameters": []
      }
    },
    "/trademark/v1/jpp_fixed_address/{application number}": {
      "parameters": [
        {
          "schema": {
            "pattern": "^[0-9]{10}$",
            "example": 2018009480
          },
          "name": "application number",
          "in": "path",
          "required": true,
          "description": "Gregorian calendar year (4 digits)+0 padding (6 digits)"
        }
      ],
      "get": {
        "summary": "Trademark J-PlatPat Fixed Address Retrieval API",
        "tags": [
          "Japan Patent Information Retrieval APIs (Trademark)"
        ],
        "responses": {
          "200": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 200:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format.\n\n* Status code in accordance with processing results.\n\n* Error message in case of an error.\n\n* Remaining number of accesses available.\n\n* Detailed information data (object containing J-PlatPat Fixed Address retrieved)\n\n*Empty object is configured for detailed information data if the result returned is other than successful completion.\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆100：successfully completed\n\nReturned when relevant data is retrieved successfully.\n\n*Regarding the detailed information data to be returned,\n\n* no characters for parameter is configured when there's no value.\n* null array is to be configured when there is no value for a parameter that is assumed to have repetition.\n\n\n◆107：no applicable data found\n\nOccurs when no information associated with the requested application number is found.\n\n\n◆203：exceeded daily access limit\n\nReached daily access limit to regulate further access.\n\n\n◆208：Characters impossible to be entered into parameters\n\nReturns when tab characters, \",\" , \";\" and/or\"|\" are contained in the parameter.\n\n\n◆999：Unexpected error\n\nUnable to retrieve requested data for some reasons although the server is working properly.\n\n-------------------------------------------------------------------------------------\n\nCharacter specified for schema patterns are character strings of regular expression.\n\nExample: ^[[0-9]]{10}$ ⇒ 10 digits consists of 0 to 9",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ",
                          "properties": {
                            "URL": {
                              "type": "string",
                              "description": "J-PlatPat固定アドレス"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "100：successfully completed": {
                    "value": {
                      "result": {
                        "statusCode": "100",
                        "errorMessage": "",
                        "remainAccessCount": "199",
                        "data": {
                          "URL": "https://www.j-platpat.inpit.go.jp/c1800/TR/JP-2018-009480/25AD3EA6D2E6DB18D4FF56AC680FB8A7D35923B6C546C571462BD72ABAFBACE0/40/ja"
                        }
                      }
                    }
                  },
                  "107：no applicable data found": {
                    "value": {
                      "result": {
                        "statusCode": "107",
                        "errorMessage": "該当するデータがありません。",
                        "remainAccessCount": "99",
                        "data": {}
                      }
                    }
                  },
                  "203：exceeded daily access limit": {
                    "value": {
                      "result": {
                        "statusCode": "203",
                        "errorMessage": "1日のアクセス上限を超過したため閲覧を制限します。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "208：Characters impossible to be entered into parameters": {
                    "value": {
                      "result": {
                        "statusCode": "208",
                        "errorMessage": "「タブ文字、,、 :、|」の文字は利用できません。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 401:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆210：invalid token error\n\nOccurs if token for authentication is invalid.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "210：invalid token error": {
                    "value": {
                      "result": {
                        "statusCode": "210",
                        "errorMessage": "無効なトークンです。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "429": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 429:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status code in accordance with the processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆303：error due to concentrated accesses\n\nOccurs if API server is overloaded.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "303：error due to concentrated accesses": {
                    "value": {
                      "result": {
                        "statusCode": "303",
                        "errorMessage": "アクセスが集中しています。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 500:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            }
          },
          "504": {
            "description": "Listed below are the API status codes to be configured if HTTP status code is 504:\n\nCharacters encoded in UTF8.\n\nReturns the followings in json format:\n\n* Status codes in accordance with processing results\n\n* Error message in case of an error\n\n* Remaining number of accesses available\n\n* Detailed information data (empty object)\n\nDetails of status codes, error messages and other details of results to be returned are shown below:\n\n-------------------------------------------------------------------------------------\n\n◆302：timeout\n\nProcess terminated due to timeout.\n\n\n◆999：Unexpected error\n\nUnexpected error occurred.",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "result": {
                      "type": "object",
                      "description": "取得結果",
                      "properties": {
                        "statusCode": {
                          "type": "string",
                          "description": "ステータスコード",
                          "pattern": "^[0-9]{3}$"
                        },
                        "errorMessage": {
                          "type": "string",
                          "description": "エラーメッセージ"
                        },
                        "remainAccessCount": {
                          "type": "string",
                          "description": "残アクセス数"
                        },
                        "data": {
                          "type": "object",
                          "description": "詳細情報データ"
                        }
                      }
                    }
                  }
                },
                "examples": {
                  "302：timeout": {
                    "value": {
                      "result": {
                        "statusCode": "302",
                        "errorMessage": "処理が時間内に終了しないため、タイムアウトになりました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  },
                  "999：Unexpected error": {
                    "value": {
                      "result": {
                        "statusCode": "999",
                        "errorMessage": "想定外のエラーが発生しました。",
                        "remainAccessCount": "",
                        "data": {}
                      }
                    }
                  }
                }
              }
            },
            "headers": {}
          }
        },
        "operationId": "get-jpp_fixed_address",
        "description": "Retrieves J-PlatPat Fixed Address associated with defined trademark application number.\n\nRequest defines application number for path to URL as parameter.\n\nDefines a trademark application number for {application number} as shown in the example below.\n\nOne application number to be defined per request.\n\nExample：https://ip-data.jpo.go.jp/api/trademark/v1/jpp_fixed_address/2018009480",
        "parameters": []
      }
    }
  },
  "components": {
    "schemas": {}
  }
}
