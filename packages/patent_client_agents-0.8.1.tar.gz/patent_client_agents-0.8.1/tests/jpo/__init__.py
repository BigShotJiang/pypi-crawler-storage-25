"""Tests for JPO module."""
