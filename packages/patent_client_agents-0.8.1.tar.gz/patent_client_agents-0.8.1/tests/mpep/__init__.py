"""Tests for MPEP module."""
