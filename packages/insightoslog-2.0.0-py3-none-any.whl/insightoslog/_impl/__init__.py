#!/usr/bin/env python3
"""
@file __init__.py
@brief InsightOS Logging SDK - Python 统一入口

使用方式:
    from insightoslog import init, info, LogLevel
    
    init({
        "service_name": "my-service",
        "level": LogLevel.INFO
    })
    
    info("Hello World")

或者使用子模块导入:
    from insightoslog.logging import init, info, LogLevel
"""

import json
import logging
import logging.handlers
import queue
import os
import socket
import threading
import traceback as tb_module
import re
import sys
from typing import Optional, Any, Dict, List
from datetime import datetime


# ==================== 工具函数 ====================

def _get_default_log_root() -> str:
    """获取默认日志根目录

    优先级：用户配置 > 当前工作目录（CWD） > /tmp/insightoslog
    """
    # 优先使用当前工作目录（CWD）
    try:
        cwd = os.getcwd()
        if cwd:
            return cwd
    except OSError:
        pass

    # 回退到脚本所在目录
    if getattr(sys, '_MEIPASS', None):
        # PyInstaller 打包环境
        return sys._MEIPASS
    if sys.argv and sys.argv[0]:
        script_path = os.path.abspath(sys.argv[0])
        if os.path.isfile(script_path):
            return os.path.dirname(script_path)

    # 最终回退
    return "/tmp/insightoslog"


def _generate_log_filename(service_name: str = "") -> str:
    """生成带执行日期的日志文件名：{服务名}_YYYY-MM-DD.log
    同一天执行持续写入同一文件，超出大小限制后截断生成新文件（带序号）
    """
    base_name = service_name if service_name else "insightos"
    return f"{base_name}_{datetime.now().strftime('%Y-%m-%d')}.log"


# ==================== 级别 ====================

class LogLevel:
    """日志级别"""
    TRACE = 0
    DEBUG = 1
    INFO = 2
    WARN = 3
    ERROR = 4
    FATAL = 5

    _LEVELS = {
        TRACE: "TRACE",
        DEBUG: "DEBUG",
        INFO: "INFO",
        WARN: "WARN",
        ERROR: "ERROR",
        FATAL: "FATAL"
    }

    _COLORS = {
        TRACE: "\033[90m",
        DEBUG: "\033[94m",
        INFO: "\033[92m",
        WARN: "\033[93m",
        ERROR: "\033[91m",
        FATAL: "\033[95m"
    }

    _RESET = "\033[0m"

    @staticmethod
    def to_string(level: int) -> str:
        return LogLevel._LEVELS.get(level, "UNKNOWN")

    @staticmethod
    def to_color(level: int) -> str:
        return LogLevel._COLORS.get(level, "")


_LEVEL_NAME_TO_VALUE = {
    "TRACE": LogLevel.TRACE,
    "DEBUG": LogLevel.DEBUG,
    "INFO": LogLevel.INFO,
    "WARN": LogLevel.WARN,
    "ERROR": LogLevel.ERROR,
    "FATAL": LogLevel.FATAL,
}


def _coerce_log_level(level: Any) -> int:
    if isinstance(level, str):
        return _LEVEL_NAME_TO_VALUE.get(level.strip().upper(), LogLevel.INFO)
    if isinstance(level, int):
        return level
    return LogLevel.INFO


# ==================== 消息数据结构 ====================

class Caller:
    """调用者信息"""
    def __init__(self, file: str = "", line: int = 0, function: str = ""):
        self.file = file
        self.line = line
        self.function = function

    def to_dict(self) -> Dict:
        return {"file": self.file, "line": self.line, "function": self.function}


class Context:
    """链路上下文"""
    def __init__(self, trace_id: str = "", span_id: str = "", parent_span_id: str = ""):
        self.trace_id = trace_id
        self.span_id = span_id
        self.parent_span_id = parent_span_id

    def to_dict(self) -> Dict:
        return {
            "trace_id": self.trace_id,
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id
        }


class Resource:
    """资源信息"""
    def __init__(self, type: str = "", name: str = "", instance_id: str = "",
                 host: str = "", pid: int = 0):
        self.type = type
        self.name = name
        self.instance_id = instance_id
        self.host = host
        self.pid = pid

    def to_dict(self) -> Dict:
        return {
            "service_type": self.type,
            "service_name": self.name,
            "instance_id": self.instance_id,
            "host": self.host,
            "pid": self.pid
        }


class Meta:
    """元数据"""
    @staticmethod
    def now_rfc3339() -> str:
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+08:00"


class Data:
    """数据"""
    def __init__(self, params: Any = None, result: Any = None,
                 latency_ms: Optional[int] = None, truncated: bool = False):
        self.param = params
        self.res = result
        self.latency_ms = latency_ms
        self.truncated = truncated

    def to_dict(self) -> Dict:
        result = {}
        if self.param is not None:
            result["param"] = self.param
        if self.res is not None:
            result["res"] = self.res
        if self.latency_ms is not None:
            result["latency_ms"] = self.latency_ms
        if self.truncated:
            result["truncated"] = self.truncated
        return result


class EventRequest:
    """请求信息"""
    def __init__(self, method: str = "", path: str = "", latency_ms: int = 0,
                 status: int = 0, url: str = ""):
        self.method = method
        self.path = path or url
        self.latency_ms = latency_ms
        self.status = status

    def to_dict(self) -> Dict:
        result = {}
        if self.method:
            result["method"] = self.method
        if self.path:
            result["path"] = self.path
        if self.latency_ms:
            result["latency_ms"] = self.latency_ms
        if self.status:
            result["status"] = self.status
        return result


class LogError:
    """错误信息"""
    def __init__(self, type_or_message: str = "", message_or_stack: str = "", stacktrace: str = ""):
        if stacktrace:
            self.type = type_or_message
            self.message = message_or_stack
            self.stacktrace = stacktrace
        elif _looks_like_stacktrace(message_or_stack):
            self.type = ""
            self.message = type_or_message
            self.stacktrace = message_or_stack
        else:
            self.type = type_or_message
            self.message = message_or_stack
            self.stacktrace = ""

    def to_dict(self) -> Dict:
        result = {
            "type": self.type,
            "message": self.message
        }
        if self.stacktrace:
            result["stacktrace"] = self.stacktrace
        return result

    @property
    def msg(self) -> str:
        return self.message

    @property
    def stack(self) -> str:
        return self.stacktrace


def _looks_like_stacktrace(value: str) -> bool:
    if not value:
        return False
    markers = ("\n", "Traceback", " at ", ".py:", ".go:", ".cpp:", ".cc:", ".java:")
    return any(marker in value for marker in markers)


# ==================== 初始化配置 ====================

class FileSpec:
    """文件配置 (与 Go/C++ 统一)"""
    def __init__(self, path: str = "", max_size: int = 5242880, max_files: int = 3):
        self.path = path
        self.max_size = max_size
        self.max_files = max_files


def _normalize_file_spec(file_config: Any = None, fallback: Optional[Dict[str, Any]] = None) -> FileSpec:
    fallback = fallback or {}

    if isinstance(file_config, FileSpec):
        spec = FileSpec(file_config.path, file_config.max_size, file_config.max_files)
    elif isinstance(file_config, dict):
        spec = FileSpec(
            path=file_config.get("path", fallback.get("path", "")),
            max_size=file_config.get("max_size", file_config.get("max_bytes", fallback.get("max_size", fallback.get("max_bytes", 5242880)))),
            max_files=file_config.get("max_files", file_config.get("backup_count", fallback.get("max_files", fallback.get("backup_count", 3)))),
        )
    else:
        spec = FileSpec(
            path=fallback.get("path", ""),
            max_size=fallback.get("max_size", fallback.get("max_bytes", 5242880)),
            max_files=fallback.get("max_files", fallback.get("backup_count", 3)),
        )

    if not spec.max_size:
        spec.max_size = 5242880
    if not spec.max_files:
        spec.max_files = 3
    return spec


def _normalize_stdout_fields(fields: Any) -> List[str]:
    if not fields:
        return ["event", "caller"]
    if isinstance(fields, str):
        fields = [item.strip() for item in fields.strip("[]").split(",")]
    normalized = [str(item).strip().strip("\"'") for item in fields if str(item).strip().strip("\"'")]
    return normalized or ["event", "caller"]


class InitParam:
    """初始化参数 (与 Go/C++ 统一)"""
    def __init__(self,
                 # 日志级别
                 level: int = LogLevel.INFO,
                 # 服务信息
                 service_type: str = "",
                 service_name: str = "",
                 instance_id: str = "",
                 # 日志配置
                 # 可选值: stdout / rotate_file / dual
                 output: str = "stdout",
                 log_root: str = "",
                 # 缓冲区配置
                 buffer_size: int = 4096,
                 flush_interval: float = 2.0,
                 # 文件配置
                 file: FileSpec = None,
                 # 追踪配置
                 enable_tracing: bool = True,
                 # stdout 输出时包含的域字段（默认 ["event", "caller"]）
                 stdout_fields: List[str] = None):
        self.level = _coerce_log_level(level)
        self.service_type = service_type
        self.service_name = service_name
        self.instance_id = instance_id or f"{socket.gethostname()}-{os.getpid()}"
        self.output = output
        self.log_root = log_root
        self.buffer_size = buffer_size
        self.flush_interval = flush_interval
        # 文件配置
        self.file = _normalize_file_spec(file)
        # 追踪配置
        self.enable_tracing = enable_tracing
        # stdout 域过滤：event 始终输出，其他域按配置
        self.stdout_fields = _normalize_stdout_fields(stdout_fields)


def _normalize_init_param(config: Any) -> InitParam:
    if isinstance(config, InitParam):
        config.level = _coerce_log_level(config.level)
        config.file = _normalize_file_spec(config.file)
        config.stdout_fields = _normalize_stdout_fields(config.stdout_fields)
        if not config.output:
            config.output = "stdout"
        if not config.log_root and config.output in ("rotate_file", "dual"):
            config.log_root = _get_default_log_root()
        return config

    if not isinstance(config, dict):
        raise TypeError("config must be an InitParam or dict")

    payload = dict(config)
    fallback_file = {
        "path": payload.pop("path", ""),
        "max_size": payload.pop("max_size", payload.pop("max_bytes", 5242880)),
        "max_files": payload.pop("max_files", payload.pop("backup_count", 3)),
    }
    file_config = _normalize_file_spec(payload.pop("file", None), fallback_file)

    cfg = InitParam(
        level=payload.pop("level", LogLevel.INFO),
        service_type=payload.pop("service_type", ""),
        service_name=payload.pop("service_name", ""),
        instance_id=payload.pop("instance_id", ""),
        output=payload.pop("output", "stdout"),
        log_root=payload.pop("log_root", ""),
        buffer_size=payload.pop("buffer_size", 4096),
        flush_interval=payload.pop("flush_interval", 2.0),
        file=file_config,
        enable_tracing=payload.pop("enable_tracing", True),
        stdout_fields=payload.pop("stdout_fields", None),
    )

    if cfg.output in ("rotate_file", "dual") and not cfg.log_root:
        cfg.log_root = _get_default_log_root()
    return cfg


HEADER_TRACE_ID = "X-InsightOSLog-TraceID"
HEADER_SPAN_ID = "X-InsightOSLog-SpanID"
HEADER_PARENT_SPAN_ID = "X-InsightOSLog-ParentSpanID"


# ==================== 上下文管理 ====================

class InsightOSLogContext:
    """线程局部存储的上下文"""
    _context = threading.local()
    _prepared_context = None

    @classmethod
    def set_current_context(cls, ctx: Context) -> None:
        cls._context.ctx = ctx

    @classmethod
    def get_current_context(cls) -> Context:
        return getattr(cls._context, 'ctx', Context())

    @classmethod
    def clear_context(cls) -> None:
        if hasattr(cls._context, 'ctx'):
            del cls._context.ctx

    @classmethod
    def start_new_trace(cls) -> str:
        """开始新的追踪链路"""
        if not _global_enable_tracing:
            return ""
        trace_id = generate_trace_id()
        span_id = generate_span_id()
        cls.set_current_context(Context(trace_id, span_id, ""))
        return trace_id

    @classmethod
    def continue_trace(cls, trace_id: str, span_id: str) -> None:
        """继续已有链路"""
        if not _global_enable_tracing:
            return
        cls.set_current_context(Context(trace_id, generate_span_id(), span_id))

    @classmethod
    def inject(cls, trace_id: str, span_id: str, parent_span_id: str = "") -> None:
        """手动注入上下文"""
        if not _global_enable_tracing:
            return
        if not trace_id:
            cls.clear_context()
            return
        cls.set_current_context(Context(trace_id, span_id, parent_span_id))

    @classmethod
    def extract_and_inject_from_headers(cls, trace_id: str, span_id: str, parent_span_id: str = "") -> None:
        """从 HTTP Header 提取并注入上下文"""
        if not _global_enable_tracing:
            return
        if not trace_id:
            cls.clear_context()
            return
        upstream_span_id = span_id or parent_span_id
        cls.set_current_context(Context(trace_id, generate_span_id(), upstream_span_id))

    @classmethod
    def prepare_for_child_thread(cls) -> None:
        """准备子线程的上下文"""
        cls._prepared_context = cls.get_current_context()

    @classmethod
    def inherit_from_prepared(cls) -> None:
        """从准备好的上下文继承"""
        if cls._prepared_context:
            cls.set_current_context(cls._prepared_context)

    @classmethod
    def inherit_from_parent(cls) -> None:
        """从父线程继承上下文（用于子线程）"""
        cls.inherit_from_prepared()


# ==================== ID 生成器 ====================

def generate_trace_id() -> str:
    """生成 Trace ID"""
    import uuid
    return uuid.uuid4().hex[:16]


def generate_span_id() -> str:
    """生成 Span ID"""
    import uuid
    return uuid.uuid4().hex[:8]


# ==================== 日志建造者 ====================

class LogBuilder:
    """日志建造者"""
    def __init__(self, message: str = ""):
        self._message = message
        self._level = LogLevel.INFO
        self._ctx = InsightOSLogContext.get_current_context()
        self._request: Optional[EventRequest] = None
        self._params: Any = None
        self._result: Any = None
        self._latency_ms: Optional[int] = None
        self._error: Optional[LogError] = None
        self._truncate: bool = False

    def msg(self, message: str) -> 'LogBuilder':
        self._message = message
        return self

    def level(self, level: int) -> 'LogBuilder':
        self._level = level
        return self

    def context(self, ctx: Context) -> 'LogBuilder':
        self._ctx = ctx
        return self

    def request(self, method_or_request: Any, path: str = "", latency_ms: int = 0,
                status: int = 0) -> 'LogBuilder':
        if isinstance(method_or_request, EventRequest):
            self._request = method_or_request
        elif isinstance(method_or_request, dict):
            self._request = EventRequest(
                method=method_or_request.get("method", ""),
                path=method_or_request.get("path", "") or method_or_request.get("url", ""),
                latency_ms=method_or_request.get("latency_ms", 0),
                status=method_or_request.get("status", 0),
            )
        else:
            self._request = EventRequest(str(method_or_request), path, latency_ms, status)
        return self

    def on_request(self, request: Any) -> 'LogBuilder':
        return self.request(request)

    def with_params(self, params: Any) -> 'LogBuilder':
        self._params = params
        return self

    def with_result(self, result: Any) -> 'LogBuilder':
        self._result = result
        return self

    def with_data(self, params: Any, result: Any) -> 'LogBuilder':
        self._params = params
        self._result = result
        return self

    def latency(self, ms: int) -> 'LogBuilder':
        self._latency_ms = ms
        return self

    def truncate(self, enable: bool = True) -> 'LogBuilder':
        self._truncate = enable
        return self

    def with_error(self, err: LogError) -> 'LogBuilder':
        self._error = err
        return self

    def send(self) -> None:
        caller = _get_caller_info()
        _log_message(self._level, self._ctx, self._message,
                    request=self._request, params=self._params,
                    result=self._result, latency_ms=self._latency_ms,
                    error=self._error, truncate=self._truncate, caller=caller)

    # ---- 别名方法（与 Go/C++ 对齐）----
    def params(self, params: Any) -> 'LogBuilder':
        return self.with_params(params)

    def result(self, result: Any) -> 'LogBuilder':
        return self.with_result(result)

    def error(self, msg: str, stack: str = "") -> 'LogBuilder':
        self._error = LogError("", msg, stack)
        return self

    def log(self) -> None:
        self.send()


class ContextWithLog:
    """上下文管理器 - 自动设置和清理上下文"""
    def __init__(self, trace_id: str = "", span_id: str = "", parent_span_id: str = ""):
        self._ctx = Context(trace_id, span_id, parent_span_id)
        self._previous_ctx: Optional[Context] = None

    def __enter__(self) -> Context:
        self._previous_ctx = InsightOSLogContext.get_current_context()
        InsightOSLogContext.set_current_context(self._ctx)
        return self._ctx

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        InsightOSLogContext.set_current_context(self._previous_ctx)


# ==================== 配置加载器 ====================

def init_from_config(config_path: str) -> None:
    """从配置文件初始化"""
    import yaml
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    init(config or {})


# ==================== 敏感信息过滤 ====================

SENSITIVE_PATTERNS = [
    (re.compile(r'("|)(password|passwd|pwd|secret|token|key|api_key|apikey)("|)\s*[:=]\s*["\']?([^"\'\s,}]+)["\']?', re.I), r'\1\2\3: "***"'),
    (re.compile(r'(password|passwd|pwd|secret|token)\s*=\s*([^\s&]+)', re.I), r'\1=***'),
]


def mask_sensitive(text: str) -> str:
    """过滤敏感信息"""
    for pattern, replacement in SENSITIVE_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


# ==================== 全局变量 ====================

_global_resource: Optional[Any] = None
_initialized: bool = False
_global_logger: Optional[logging.Logger] = None
_global_output_mode: str = "stdout"
_flush_timer: Optional[threading.Timer] = None
_global_stdout_fields: set = {"event"}  # stdout 域过滤集合，event 始终包含
_global_enable_tracing: bool = True  # 是否启用链路追踪


# ==================== 核心日志函数 ====================

def _to_python_level(level: int) -> int:
    """转换日志级别到 Python 级别"""
    mapping = {
        LogLevel.TRACE: logging.DEBUG,
        LogLevel.DEBUG: logging.DEBUG,
        LogLevel.INFO: logging.INFO,
        LogLevel.WARN: logging.WARNING,
        LogLevel.ERROR: logging.ERROR,
        LogLevel.FATAL: logging.CRITICAL,
    }
    return mapping.get(level, logging.INFO)


def _from_python_level(level: int) -> LogLevel:
    """转换 Python 级别到日志级别"""
    mapping = {
        logging.DEBUG: LogLevel.DEBUG,
        logging.INFO: LogLevel.INFO,
        logging.WARNING: LogLevel.WARN,
        logging.ERROR: LogLevel.ERROR,
        logging.CRITICAL: LogLevel.FATAL,
    }
    return mapping.get(level, LogLevel.INFO)


def _cancel_flush_timer() -> None:
    global _flush_timer
    if _flush_timer is not None:
        _flush_timer.cancel()
        _flush_timer = None


def _close_logger() -> None:
    global _global_logger
    if _global_logger is None:
        return

    listener = getattr(_global_logger, "_queue_listener", None)
    if listener is not None:
        listener.stop()
        try:
            delattr(_global_logger, "_queue_listener")
        except AttributeError:
            pass

    file_handler = getattr(_global_logger, "_file_handler", None)
    if file_handler is not None:
        try:
            file_handler.flush()
        except Exception:
            pass

    for handler in list(_global_logger.handlers):
        try:
            handler.flush()
        except Exception:
            pass
        _global_logger.removeHandler(handler)
        handler.close()

    if file_handler is not None and file_handler not in _global_logger.handlers:
        try:
            file_handler.close()
        except Exception:
            pass

    _global_logger = None


def _log_message(level: int, ctx: Any, msg: str,
                 request: Optional[EventRequest] = None,
                 params: Any = None, result: Any = None,
                 latency_ms: Optional[int] = None,
                 error: Optional[LogError] = None,
                 truncate: bool = False,
                 caller: Optional[Caller] = None) -> None:
    """核心日志函数"""
    if not _initialized:
        return
    if level < _global_log_level:
        return

    from datetime import datetime
    now = datetime.now()
    timestamp_local = now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+08:00"

    log_msg = {
        "meta": {
            "level": LogLevel.to_string(level),
            "time": timestamp_local
        },
        "resource": _global_resource.to_dict() if _global_resource else {},
    }

    if caller:
        log_msg["caller"] = caller.to_dict()

    log_msg["event"] = {
        "msg": msg
    }

    if request:
        log_msg["event"]["request"] = request.to_dict()

    if params is not None or result is not None or latency_ms is not None:
        data = Data(params, result, latency_ms, truncate)

        if params is not None:
            params_str = json.dumps(params, ensure_ascii=False)
            params_str = mask_sensitive(params_str)
            data.param = json.loads(params_str)
        if result is not None:
            result_str = json.dumps(result, ensure_ascii=False)
            result_str = mask_sensitive(result_str)
            data.res = json.loads(result_str)

        log_msg["data"] = data.to_dict()

        if latency_ms is not None:
            if "request" not in log_msg["event"]:
                log_msg["event"]["request"] = {}
            log_msg["event"]["request"]["latency_ms"] = latency_ms

    log_msg["context"] = ctx.to_dict() if hasattr(ctx, 'to_dict') else {}

    if error:
        log_msg["error"] = error.to_dict()

    json_str = json.dumps(log_msg, ensure_ascii=False)

    global _global_output_mode
    level_str = LogLevel.to_string(level)

    if _global_output_mode == "stdout":
        color = LogLevel.to_color(level)
        color_suffix = LogLevel._RESET
        # 提取消息内容
        msg_content = log_msg.get("event", {}).get("msg", "")
        # 提取 context 信息
        context_parts = []
        if "context" in _global_stdout_fields:
            ctx_data = log_msg.get("context", {})
            if ctx_data.get("trace_id"):
                context_parts.append(f"trace_id={ctx_data.get('trace_id')}")
            if ctx_data.get("span_id"):
                context_parts.append(f"span_id={ctx_data.get('span_id')}")
            if ctx_data.get("parent_span_id"):
                context_parts.append(f"parent_span_id={ctx_data.get('parent_span_id')}")
        context_str = " ".join(context_parts) if context_parts else ""
        # 提取 data 信息
        data_parts = []
        if "data" in _global_stdout_fields:
            data_data = log_msg.get("data", {})
            if data_data.get("param"):
                data_parts.append(f"param={data_data.get('param')}")
            if data_data.get("res"):
                data_parts.append(f"res={data_data.get('res')}")
            if data_data.get("latency_ms"):
                data_parts.append(f"latency_ms={data_data.get('latency_ms')}")
        data_str = " ".join(data_parts) if data_parts else ""
        # 提取 error 信息
        error_str = ""
        if "error" in _global_stdout_fields:
            error_data = log_msg.get("error", {})
            if error_data:
                if error_data.get("msg"):
                    error_str = f"error={error_data.get('msg')}"
                elif error_data.get("message"):
                    error_str = f"error={error_data.get('message')}"
        # 提取 resource 信息
        resource_parts = []
        if "resource" in _global_stdout_fields:
            resource = log_msg.get("resource", {})
            if resource.get("host"):
                resource_parts.append(f"host={resource.get('host')}")
            if resource.get("pid"):
                resource_parts.append(f"pid={resource.get('pid')}")
        resource_str = " ".join(resource_parts) if resource_parts else ""
        # 提取调用位置
        caller_str = ""
        if "caller" in _global_stdout_fields:
            caller_info = log_msg.get("caller", {})
            if caller_info:
                caller_str = f"{caller_info.get('file', '')}:{caller_info.get('line', '')} {caller_info.get('function', '')}"
        # 格式：时间 [级别] 消息 context data error resource (调用位置)
        parts = [f"{color}{timestamp_local} [{level_str}] {msg_content}"]
        if context_str:
            parts.append(f"{color}{context_str}")
        if data_str:
            parts.append(f"{color}{data_str}")
        if error_str:
            parts.append(f"{color}{error_str}")
        if resource_str:
            parts.append(f"{color}{resource_str}")
        if caller_str:
            parts.append(f"{color}({caller_str})")
        parts.append(color_suffix)
        print(" ".join(parts))
    elif _global_output_mode == "dual":
        # dual 模式：同时输出到终端和文件
        # 1. 输出到文件（完整 JSON，包含 resource）
        _file_log(level, json_str)
        # 2. 输出到终端（易读格式）
        color = LogLevel.to_color(level)
        color_suffix = LogLevel._RESET
        msg_content = log_msg.get("event", {}).get("msg", "")
        # 提取 context 信息
        context_parts = []
        if "context" in _global_stdout_fields:
            ctx_data = log_msg.get("context", {})
            if ctx_data.get("trace_id"):
                context_parts.append(f"trace_id={ctx_data.get('trace_id')}")
            if ctx_data.get("span_id"):
                context_parts.append(f"span_id={ctx_data.get('span_id')}")
            if ctx_data.get("parent_span_id"):
                context_parts.append(f"parent_span_id={ctx_data.get('parent_span_id')}")
        context_str = " ".join(context_parts) if context_parts else ""
        # 提取 data 信息
        data_parts = []
        if "data" in _global_stdout_fields:
            data_data = log_msg.get("data", {})
            if data_data.get("param"):
                data_parts.append(f"param={data_data.get('param')}")
            if data_data.get("res"):
                data_parts.append(f"res={data_data.get('res')}")
            if data_data.get("latency_ms"):
                data_parts.append(f"latency_ms={data_data.get('latency_ms')}")
        data_str = " ".join(data_parts) if data_parts else ""
        # 提取 error 信息
        error_str = ""
        if "error" in _global_stdout_fields:
            error_data = log_msg.get("error", {})
            if error_data:
                if error_data.get("msg"):
                    error_str = f"error={error_data.get('msg')}"
                elif error_data.get("message"):
                    error_str = f"error={error_data.get('message')}"
        # 提取 resource 信息
        resource_parts = []
        if "resource" in _global_stdout_fields:
            resource = log_msg.get("resource", {})
            if resource.get("host"):
                resource_parts.append(f"host={resource.get('host')}")
            if resource.get("pid"):
                resource_parts.append(f"pid={resource.get('pid')}")
        resource_str = " ".join(resource_parts) if resource_parts else ""
        # 提取调用位置
        caller_str = ""
        if "caller" in _global_stdout_fields:
            caller_info = log_msg.get("caller", {})
            if caller_info:
                caller_str = f"{caller_info.get('file', '')}:{caller_info.get('line', '')} {caller_info.get('function', '')}"
        parts = [f"{color}{timestamp_local} [{level_str}] {msg_content}"]
        if context_str:
            parts.append(f"{color}{context_str}")
        if data_str:
            parts.append(f"{color}{data_str}")
        if error_str:
            parts.append(f"{color}{error_str}")
        if resource_str:
            parts.append(f"{color}{resource_str}")
        if caller_str:
            parts.append(f"{color}({caller_str})")
        parts.append(color_suffix)
        print(" ".join(parts))
    else:
        _file_log(level, json_str)


def _get_caller_info(_ignored_depth: int = 2) -> Caller:
    """获取调用者信息（自动跳过 SDK 内部栈帧）"""
    try:
        stack = tb_module.extract_stack()
        if not stack:
            return Caller()

        SDK_MARKERS = ('insightoslog', '_impl', 'traceback')
        INTERNAL_NAMES = ('_get_caller_info', '_log_message',
                          'send', 'log', 'info', 'debug', 'warn',
                          'error', 'fatal', 'trace',
                          'info_with_context', 'debug_with_context',
                          'warn_with_context', 'error_with_context',
                          'fatal_with_context', 'trace_with_context',
                          '_log_message_asYNC')  # future async support

        for i in range(-1, -len(stack) - 1, -1):
            frame = stack[i]
            is_sdk = any(m in frame.filename for m in SDK_MARKERS)
            is_internal = frame.name in INTERNAL_NAMES
            if not is_sdk and not is_internal:
                return Caller(
                    file=os.path.basename(frame.filename),
                    line=frame.lineno,
                    function=frame.name
                )

        # fallback: 栈顶第一个非 _get_caller_info 的帧
        for frame in reversed(stack):
            if frame.name != '_get_caller_info':
                return Caller(
                    file=os.path.basename(frame.filename),
                    line=frame.lineno,
                    function=frame.name
                )
        return Caller()
    except:
        return Caller()


# ==================== 便捷日志函数 ====================

def trace(msg: str, *args) -> None:
    ctx = InsightOSLogContext.get_current_context()
    msg = msg.format(*args) if args else msg
    caller = _get_caller_info()
    _log_message(LogLevel.TRACE, ctx, msg, caller=caller)


def debug(msg: str, *args) -> None:
    ctx = InsightOSLogContext.get_current_context()
    msg = msg.format(*args) if args else msg
    caller = _get_caller_info()
    _log_message(LogLevel.DEBUG, ctx, msg, caller=caller)


def info(msg: str, *args) -> None:
    ctx = InsightOSLogContext.get_current_context()
    msg = msg.format(*args) if args else msg
    caller = _get_caller_info()
    _log_message(LogLevel.INFO, ctx, msg, caller=caller)


def warn(msg: str, *args) -> None:
    ctx = InsightOSLogContext.get_current_context()
    msg = msg.format(*args) if args else msg
    caller = _get_caller_info()
    _log_message(LogLevel.WARN, ctx, msg, caller=caller)


def error(msg: str, *args) -> None:
    ctx = InsightOSLogContext.get_current_context()
    msg = msg.format(*args) if args else msg
    caller = _get_caller_info()
    _log_message(LogLevel.ERROR, ctx, msg, caller=caller)


def fatal(msg: str, *args) -> None:
    ctx = InsightOSLogContext.get_current_context()
    msg = msg.format(*args) if args else msg
    caller = _get_caller_info()
    _log_message(LogLevel.FATAL, ctx, msg, caller=caller)


# ==================== 带 Context 的日志函数 ====================

def trace_with_context(ctx: Context, msg: str, *args,
                       params: Any = None, result: Any = None,
                       latency_ms: Optional[int] = None) -> None:
    msg = msg.format(*args) if args else msg
    caller = _get_caller_info()
    _log_message(LogLevel.TRACE, ctx, msg, params=params, result=result,
                 latency_ms=latency_ms, caller=caller)


def debug_with_context(ctx: Context, msg: str, *args,
                       params: Any = None, result: Any = None,
                       latency_ms: Optional[int] = None) -> None:
    msg = msg.format(*args) if args else msg
    caller = _get_caller_info()
    _log_message(LogLevel.DEBUG, ctx, msg, params=params, result=result,
                 latency_ms=latency_ms, caller=caller)


def info_with_context(ctx: Context, msg: str, *args,
                       params: Any = None, result: Any = None,
                       latency_ms: Optional[int] = None) -> None:
    msg = msg.format(*args) if args else msg
    caller = _get_caller_info()
    _log_message(LogLevel.INFO, ctx, msg, params=params, result=result,
                 latency_ms=latency_ms, caller=caller)


def warn_with_context(ctx: Context, msg: str, *args,
                       params: Any = None, result: Any = None,
                       latency_ms: Optional[int] = None) -> None:
    msg = msg.format(*args) if args else msg
    caller = _get_caller_info()
    _log_message(LogLevel.WARN, ctx, msg, params=params, result=result,
                 latency_ms=latency_ms, caller=caller)


def error_with_context(ctx: Context, msg: str, *args,
                       params: Any = None, result: Any = None,
                       latency_ms: Optional[int] = None,
                       error: Optional[LogError] = None) -> None:
    msg = msg.format(*args) if args else msg
    caller = _get_caller_info()
    _log_message(LogLevel.ERROR, ctx, msg, params=params, result=result,
                 latency_ms=latency_ms, error=error, caller=caller)


def fatal_with_context(ctx: Context, msg: str, *args,
                       params: Any = None, result: Any = None,
                       latency_ms: Optional[int] = None,
                       error: Optional[LogError] = None) -> None:
    msg = msg.format(*args) if args else msg
    caller = _get_caller_info()
    _log_message(LogLevel.FATAL, ctx, msg, params=params, result=result,
                 latency_ms=latency_ms, error=error, caller=caller)


# ==================== 便捷函数 ====================

def current_context():
    """获取当前 Context"""
    return InsightOSLogContext.get_current_context()


def make_context(trace_id: str, span_id: str, parent_span_id: str = ""):
    """创建 Context"""
    return Context(trace_id, span_id, parent_span_id)


def with_context(trace_id: str = "", span_id: str = "", parent_span_id: str = "") -> ContextWithLog:
    """创建 RAII 上下文管理器，自动保存并恢复旧上下文

    使用方式:
        guard = with_context(trace_id, span_id)
        info("在上下文中记录日志")
        del guard  # 自动恢复旧上下文
    """
    return ContextWithLog(trace_id, span_id, parent_span_id)


def with_context_from_ctx(ctx: Context) -> ContextWithLog:
    """从已有 Context 创建 RAII 上下文管理器"""
    return ContextWithLog(ctx.trace_id, ctx.span_id, ctx.parent_span_id)


def extract_from_headers(headers_or_trace_id: Any, span_id: Optional[str] = None, parent_span_id: str = "") -> None:
    """从 HTTP Header 提取并注入上下文"""
    if isinstance(headers_or_trace_id, dict):
        trace_id = headers_or_trace_id.get(HEADER_TRACE_ID) or headers_or_trace_id.get("trace_id", "")
        incoming_span_id = headers_or_trace_id.get(HEADER_SPAN_ID) or headers_or_trace_id.get("span_id", "")
        incoming_parent_span_id = headers_or_trace_id.get(HEADER_PARENT_SPAN_ID) or headers_or_trace_id.get("parent_span_id", "")
    else:
        trace_id = headers_or_trace_id or ""
        incoming_span_id = span_id or ""
        incoming_parent_span_id = parent_span_id or ""

    InsightOSLogContext.extract_and_inject_from_headers(trace_id, incoming_span_id, incoming_parent_span_id)


# ==================== 文件输出 ====================

def _file_log(level: int, json_str: str) -> None:
    """输出到文件"""
    global _global_logger, _global_output_mode

    if _global_output_mode in ("rotate_file", "dual") and _global_logger:
        _global_logger.log(_to_python_level(level), json_str)
    else:
        print(json_str)


def global_resource() -> Optional[Any]:
    """获取全局 Resource"""
    return _global_resource


def refresh_pid() -> None:
    """刷新 PID"""
    global _global_resource
    if _global_resource:
        _global_resource.pid = os.getpid()


# ==================== 控制函数 ====================

def is_initialized() -> bool:
    """检查是否已初始化"""
    return _initialized


_global_log_level: int = LogLevel.INFO


def set_level(level: int) -> None:
    """设置日志级别"""
    global _global_log_level
    _global_log_level = _coerce_log_level(level)


def get_level() -> int:
    """获取当前日志级别"""
    global _global_log_level
    return _global_log_level


def flush() -> None:
    """刷新日志缓冲区"""
    if _global_logger is None:
        return

    listener = getattr(_global_logger, "_queue_listener", None)
    if listener is not None:
        for handler in listener.handlers:
            handler.flush()

    file_handler = getattr(_global_logger, "_file_handler", None)
    if file_handler is not None:
        file_handler.flush()

    for handler in list(_global_logger.handlers):
        handler.flush()


def shutdown() -> None:
    """关闭日志系统"""
    global _initialized
    flush()
    _cancel_flush_timer()
    _close_logger()
    _initialized = False


# ==================== 资源管理 ====================

_global_config: Optional[InitParam] = None


def set_global_resource(resource: Resource) -> None:
    """设置全局资源信息"""
    global _global_resource
    _global_resource = resource


def GlobalResource() -> Optional[Resource]:
    """获取全局资源"""
    return _global_resource


def SetGlobalResource(resource: Resource) -> None:
    """设置全局资源"""
    set_global_resource(resource)


# ==================== ID 生成 ====================

def GenerateTraceID() -> str:
    """生成 Trace ID"""
    return generate_trace_id()


def GenerateSpanID() -> str:
    """生成 Span ID"""
    return generate_span_id()


# ==================== 初始化 ====================

def init(config: Any) -> None:
    """初始化 SDK"""
    global _global_resource, _initialized, _global_output_mode, _global_logger, _flush_timer, _global_log_level, _global_stdout_fields, _global_enable_tracing, _global_config

    config = _normalize_init_param(config)
    _cancel_flush_timer()
    _close_logger()

    hostname = socket.gethostname()
    pid = os.getpid()

    _global_log_level = config.level
    _global_enable_tracing = config.enable_tracing
    _global_config = config

    _global_resource = Resource(
        type=config.service_type,
        name=config.service_name,
        instance_id=config.instance_id,
        host=hostname,
        pid=pid
    )

    _global_output_mode = config.output
    _global_stdout_fields = {"event"}  # event 始终包含
    for f in config.stdout_fields:
        _global_stdout_fields.add(f)

    if config.output in ("rotate_file", "dual"):
        # 日志目录（默认为可执行文件所在目录）
        log_dir = config.log_root if config.log_root else _get_default_log_root()

        # 日志文件名（默认格式：{service_name}_YYYY-MM-DD.log）
        if config.file.path:
            file_path = config.file.path.rstrip('/')
            basename = os.path.basename(file_path)
            # 如果 basename 是目录名（不是文件名），生成默认文件名
            # 判断依据：没有扩展名
            if not basename or '.' not in basename:
                # 整个路径作为目录
                log_dir = file_path
                log_file = os.path.join(log_dir, _generate_log_filename(config.service_name))
            else:
                # 文件路径，提取目录和文件名
                log_dir = os.path.dirname(file_path) or '.'
                log_file = file_path
        else:
            log_file = os.path.join(log_dir, _generate_log_filename(config.service_name))

        os.makedirs(log_dir, exist_ok=True)

        _global_logger = logging.getLogger("insightoslog")
        _global_logger.setLevel(logging.DEBUG)
        _global_logger.propagate = False

        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=config.file.max_size,
            backupCount=config.file.max_files,
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)

        formatter = logging.Formatter('%(message)s')
        file_handler.setFormatter(formatter)
        _global_logger._file_handler = file_handler

        if config.buffer_size > 0:
            log_queue = queue.Queue(maxsize=config.buffer_size)
            queue_handler = logging.handlers.QueueHandler(log_queue)
            _global_logger.addHandler(queue_handler)

            listener = logging.handlers.QueueListener(
                log_queue,
                file_handler,
                respect_handler_level=True
            )
            listener.start()

            _global_logger._queue_listener = listener

            print(f"[InsightOSLog] SDK init: output={config.output}, log_file={log_file}, buffer_size={config.buffer_size}")
        else:
            _global_logger.addHandler(file_handler)
            print(f"[InsightOSLog] SDK init: output={config.output}, log_file={log_file}")
    else:
        print(f"[InsightOSLog] SDK init: output={config.output}")

    if config.flush_interval > 0:
        def _flush_loop():
            global _global_logger, _flush_timer
            flush()
            _flush_timer = threading.Timer(config.flush_interval, _flush_loop)
            _flush_timer.daemon = True
            _flush_timer.start()

        _flush_timer = threading.Timer(config.flush_interval, _flush_loop)
        _flush_timer.daemon = True
        _flush_timer.start()
        print(f"[InsightOSLog] SDK init: flush_interval={config.flush_interval}s")

    _initialized = True


# ==================== Logger 类封装 ====================

class Logger:
    """Logger 类封装"""

    @staticmethod
    def init(param: Any) -> None:
        """初始化日志系统"""
        init(param)

    @staticmethod
    def init_from_config(config_path: str = "./InsightOSLogConfig.yaml") -> None:
        """从配置文件初始化"""
        init_from_config(config_path)

    @staticmethod
    def flush() -> None:
        """刷新日志缓冲区"""
        flush()

    @staticmethod
    def shutdown() -> None:
        """关闭日志系统"""
        shutdown()

    @staticmethod
    def refresh_pid() -> None:
        """刷新进程 ID"""
        refresh_pid()

    @staticmethod
    def is_initialized() -> bool:
        """检查是否已初始化"""
        return _initialized

    @staticmethod
    def set_level(level: LogLevel) -> None:
        """设置日志级别"""
        set_level(level)

    @staticmethod
    def get_level() -> LogLevel:
        """获取当前日志级别"""
        return get_level()

    @staticmethod
    def get_resource() -> Resource:
        """获取全局资源信息"""
        return global_resource()

    @staticmethod
    def set_resource(resource: Resource) -> None:
        """设置全局资源信息"""
        set_global_resource(resource)

    @staticmethod
    def trace(msg: str, *args) -> None:
        """记录 trace 级别日志"""
        trace(msg, *args)

    @staticmethod
    def debug(msg: str, *args) -> None:
        """记录 debug 级别日志"""
        debug(msg, *args)

    @staticmethod
    def info(msg: str, *args) -> None:
        """记录 info 级别日志"""
        info(msg, *args)

    @staticmethod
    def warn(msg: str, *args) -> None:
        """记录 warn 级别日志"""
        warn(msg, *args)

    @staticmethod
    def error(msg: str, *args) -> None:
        """记录 error 级别日志"""
        error(msg, *args)

    @staticmethod
    def fatal(msg: str, *args) -> None:
        """记录 fatal 级别日志"""
        fatal(msg, *args)


# ==================== Trace 类封装 ====================

class Trace:
    """Trace 类封装"""

    @staticmethod
    def start_new_trace() -> str:
        """开始新的追踪链路"""
        return InsightOSLogContext.start_new_trace()

    @staticmethod
    def continue_trace(trace_id: str, span_id: str) -> None:
        """继续已有链路"""
        InsightOSLogContext.continue_trace(trace_id, span_id)

    @staticmethod
    def inject(trace_id: str, span_id: str, parent_span_id: str = "") -> None:
        """手动注入上下文"""
        InsightOSLogContext.inject(trace_id, span_id, parent_span_id)

    @staticmethod
    def get_current_context() -> Context:
        """获取当前 Trace 上下文"""
        return InsightOSLogContext.get_current_context()

    @staticmethod
    def get_trace_id() -> str:
        """获取 Trace ID"""
        ctx = InsightOSLogContext.get_current_context()
        return ctx.trace_id if ctx else ""

    @staticmethod
    def get_span_id() -> str:
        """获取 Span ID"""
        ctx = InsightOSLogContext.get_current_context()
        return ctx.span_id if ctx else ""

    @staticmethod
    def get_parent_span_id() -> str:
        """获取父 Span ID"""
        ctx = InsightOSLogContext.get_current_context()
        return ctx.parent_span_id if ctx else ""

    @staticmethod
    def get_propagation_headers() -> dict:
        """获取需要传播到下游的 HTTP Header"""
        return {
            'trace_id': Trace.get_trace_id(),
            'span_id': Trace.get_span_id(),
            'parent_span_id': ""
        }

    @staticmethod
    def extract_from_headers(headers_or_trace_id: Any, span_id: Optional[str] = None, parent_span_id: str = "") -> None:
        """从 HTTP Header 提取并注入上下文"""
        extract_from_headers(headers_or_trace_id, span_id, parent_span_id)

    @staticmethod
    def prepare_for_child_thread() -> None:
        """准备子线程的上下文"""
        InsightOSLogContext.prepare_for_child_thread()

    @staticmethod
    def inherit_from_prepared() -> None:
        """从准备好的上下文继承"""
        InsightOSLogContext.inherit_from_prepared()

    @staticmethod
    def inherit_from_parent() -> None:
        """从父线程继承上下文"""
        InsightOSLogContext.inherit_from_parent()

    @staticmethod
    def clear_context() -> None:
        """清除当前上下文"""
        InsightOSLogContext.clear_context()

    @staticmethod
    def set_current_context(context: Context) -> None:
        """设置当前上下文"""
        InsightOSLogContext.set_current_context(context)


# ==================== 全局实例 ====================

_default_logger = Logger()
_default_trace = Trace()

# Logger2/Trace2：与 Go 对齐的全大写全局实例（通过类属性访问）
Logger2 = Logger   # 类引用，Logger.Info() 静态调用
Trace2 = Trace     # 类引用，Trace.StartNewTrace() 静态调用


# ==================== 导出 ====================

__all__ = [
    'LogLevel',
    'Caller', 'Meta', 'Resource', 'Context',
    'EventRequest', 'Event', 'Data', 'LogError',
    'InitParam',
    'HEADER_TRACE_ID', 'HEADER_SPAN_ID', 'HEADER_PARENT_SPAN_ID',
    'InsightOSLogContext',
    'generate_trace_id', 'generate_span_id',
    'LogBuilder', 'ContextWithLog',
    'trace', 'debug', 'info', 'warn', 'error', 'fatal',
    'tracef', 'debugf', 'infof', 'warnf', 'errorf', 'fatalf',
    'trace_with_context', 'debug_with_context', 'info_with_context',
    'warn_with_context', 'error_with_context', 'fatal_with_context',
    'current_context', 'make_context', 'extract_from_headers',
    'init', 'init_from_config', 'shutdown', 'refresh_pid',
    'mask_sensitive',
    'is_initialized', 'flush', 'set_level', 'get_level',
    'global_resource', 'GlobalResource', 'set_global_resource', 'SetGlobalResource',
    'GenerateTraceID', 'GenerateSpanID',
    'Logger', 'Trace',
]
