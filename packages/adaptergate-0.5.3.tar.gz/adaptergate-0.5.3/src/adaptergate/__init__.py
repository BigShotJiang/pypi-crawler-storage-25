"""adaptergate — CI gate for per-tenant LoRA adapters that update online.

See CONTEXT.md for project background and NOTICE for upstream attribution.
"""
__version__ = "0.5.3"
