This project is currently maintained by Mostafa Moradian and various contributors:

# Django SAML2 Auth

- Original author:
  - [Li Fang](https://github.com/fangli)

- Current maintainer:
  - [Mostafa Moradian](https://github.com/mostafa) (k6.io & Grafana Labs)

# Dependencies

PySAML2: [c00kiemon5ter](https://github.com/c00kiemon5ter) and other contributors.

PyJWT: [José Padilla](https://github.com/jpadilla) (Auth0) and other contributors.

cryptography: [Paul Kehrer](https://github.com/reaperhulk) and other contributors.

# Test dependencies

django: [various contributors](https://github.com/django/django/blob/master/AUTHORS).

pytest: Holger Krekel and [other contributors](https://github.com/pytest-dev/pytest/blob/master/AUTHORS).

pytest-django: Ben Firshman, Andreas Pelme and [other contributors](https://github.com/pytest-dev/pytest-django/blob/master/AUTHORS).

responses: [markstory](https://github.com/markstory) and other contributors.

# Contributors

If your code or changes are here, but you are not mentioned, please open
an issue.

- [Mostafa Moradian](https://github.com/mostafa) (k6.io & Grafana Labs)
- [Rafael Muñoz Cárdenas](https://github.com/Menda) (k6.io & Grafana Labs)
- [DSpeichert](https://github.com/DSpeichert)
- [jacobh](https://github.com/jacobh)
- [Gene Wood](http://github.com/gene1wood/)
- [Terry](https://github.com/tpeng)
- [Tim Pierce](https://github.com/qwrrty/) (Adobe Systems)
- [Tonymke](https://github.com/tonymke/)
- [pintor](https://github.com/pintor)
- [BaconAndEggs](https://github.com/BaconAndEggs)
- [Ryan Mahaffey](https://github.com/mahaffey)
- [ayr-ton](https://github.com/ayr-ton)
- [kevPo](https://github.com/kevPo)
- [chriskj](https://github.com/chriskj)
- [Griffin J Rademacher](https://github.com/favorable-mutation)
- [Akshit Dhar](https://github.com/akshit-wwstay)
- [Jean Vincent](https://github.com/jean-sh)
- [Søren Howe Gersager](https://github.com/syre)
- [Gabrio Mauri](https://github.com/sgabb)
- [Hugh Enxing](https://github.com/henxing) (CVision AI)
- [Tamara Nocentini](https://github.com/TamaraNocentini)
- [Paolo Romolini](https://github.com/paoloromolini)
- [Uraiz Ali](https://github.com/UraizAli)
- [Santiago Gandolfo](https://github.com/santigandolfo)
- [Greg Wong](https://github.com/gregorywong)
- [Michael V. Battista](https://github.com/mvbattista)
- [William Abbott](https://github.com/wrabit)
- [Henry Harutyunyan](https://github.com/henryh9n) (Revolut)
- [Noppanut Ploywong](https://github.com/noppanut15)
- [Mohammed Almeshal](https://github.com/MohammedAlmeshal)