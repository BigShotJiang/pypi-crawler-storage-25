"""
DNR-Back Runtime

Native backend runtime implementation (FastAPI + Pydantic).

This module provides:
- Model generation (Pydantic models from EntitySpec)
- Service generation (domain logic stubs from ServiceSpec)
- Route generation (FastAPI routes from EndpointSpec)
- Runtime server creation

Example usage:
    >>> from dazzle.back.specs import BackendSpec
    >>> from dazzle.back.runtime import create_app, run_app
    >>>
    >>> # Create spec (from DSL conversion or manual)
    >>> spec = BackendSpec(name="my_app", ...)
    >>>
    >>> # Create FastAPI app
    >>> app = create_app(spec)
    >>>
    >>> # Or run directly
    >>> run_app(spec, port=8000)
"""

from dazzle.back.runtime._fastapi_compat import FASTAPI_AVAILABLE
from dazzle.back.runtime.access_evaluator import (
    can_create,
    can_delete,
    can_read,
    can_update,
    evaluate_access_condition,
    evaluate_permission,
    evaluate_visibility,
    filter_visible_records,
)
from dazzle.back.runtime.app_factory import create_app, run_app
from dazzle.back.runtime.migrations import (
    MigrationAction,
    MigrationError,
    MigrationPlan,
    MigrationStep,
)
from dazzle.back.runtime.model_generator import (
    generate_all_entity_models,
    generate_create_schema,
    generate_entity_model,
    generate_list_response_schema,
    generate_update_schema,
)
from dazzle.back.runtime.repository import (
    DatabaseManager,
    Repository,
    RepositoryFactory,
)
from dazzle.back.runtime.route_generator import (
    RouteGenerator,
    generate_crud_routes,
)
from dazzle.back.runtime.server import (
    DazzleBackendApp,
    ServerConfig,
)
from dazzle.back.runtime.service_generator import (
    BaseService,
    CRUDService,
    CustomService,
    ServiceContext,
    ServiceFactory,
)
from dazzle.core.access import AccessRuntimeContext

__all__ = [
    # Access control (v0.7.0)
    "AccessRuntimeContext",
    "evaluate_access_condition",
    "evaluate_visibility",
    "evaluate_permission",
    "can_read",
    "can_create",
    "can_update",
    "can_delete",
    "filter_visible_records",
    # Model generation
    "generate_entity_model",
    "generate_all_entity_models",
    "generate_create_schema",
    "generate_update_schema",
    "generate_list_response_schema",
    # Services
    "BaseService",
    "CRUDService",
    "CustomService",
    "ServiceFactory",
    "ServiceContext",
    # Routes
    "RouteGenerator",
    "generate_crud_routes",
    "FASTAPI_AVAILABLE",
    # Server
    "DazzleBackendApp",
    "ServerConfig",
    "create_app",
    "run_app",
    # Repository
    "Repository",
    "DatabaseManager",
    "RepositoryFactory",
    # Migrations
    "MigrationAction",
    "MigrationStep",
    "MigrationPlan",
    "MigrationError",
]
