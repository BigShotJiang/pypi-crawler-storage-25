"""Auth routes subsystem.

Registers authentication routes (login/register/logout), social auth (OAuth2),
2FA routes, and JWT routes. Auth deps (AuthStore, AuthMiddleware, auth_dep,
optional_auth_dep) are set on SubsystemContext by DazzleBackendApp._setup_auth().
"""

import logging
from typing import Any

from dazzle.back.runtime.subsystems import SubsystemContext

logger = logging.getLogger("dazzle.server")


class AuthSubsystem:
    name = "auth_routes"

    def __init__(self) -> None:
        self._jwt_service: Any | None = None
        self._token_store: Any | None = None
        self._social_auth_service: Any | None = None

    def startup(self, ctx: SubsystemContext) -> None:
        if not ctx.enable_auth or not ctx.auth_store:
            return
        self._register_auth_routes(ctx)
        self._init_social_auth(ctx)

    def _register_auth_routes(self, ctx: SubsystemContext) -> None:
        """Register login/register/logout, 2FA, and JWT auth routes."""
        from dazzle.back.runtime.auth import create_2fa_routes, create_auth_routes

        # Build persona -> default_route mapping for post-login redirect
        _persona_routes: dict[str, str] = {}
        for p in ctx.config.personas:
            route = p.get("default_route")
            if route:
                _persona_routes[p["id"]] = route
        # Default signup role: first persona ID (public-facing persona by convention)
        _default_signup_roles = [ctx.config.personas[0]["id"]] if ctx.config.personas else None

        assert ctx.auth_store is not None, "auth_store must be set before AuthSubsystem starts"
        auth_router = create_auth_routes(
            ctx.auth_store,
            persona_routes=_persona_routes or None,
            default_signup_roles=_default_signup_roles,
        )
        ctx.app.include_router(auth_router)

        # Stash auth_store on app.state for routes that need it
        # (magic link consumer, qa_routes, etc.)
        ctx.app.state.auth_store = ctx.auth_store

        # Mount the magic link consumer router (general-purpose, production-safe)
        from dazzle.back.runtime.auth.magic_link_routes import create_magic_link_routes

        magic_link_router = create_magic_link_routes()
        ctx.app.include_router(magic_link_router)

        # Form-encoded password-reset routes (Phase 1.B.2, v0.67.31) —
        # typed-Fragment views in `auth_views.py` post to these endpoints
        # rather than the JSON ones in `routes.py`.
        from dazzle.back.runtime.auth.password_reset_routes import (
            create_password_reset_routes,
        )

        password_reset_router = create_password_reset_routes()
        ctx.app.include_router(password_reset_router)

        # Form-encoded password-mode login/signup routes (Phase 1.B.3,
        # v0.67.32). Mounted unconditionally — the typed-Fragment views
        # are only RENDERED when `app.state.auth_password_mode_enabled`
        # is True, but the endpoints themselves are safe to mount in
        # either mode (they just won't get traffic in magic-link-only
        # deployments).
        from dazzle.back.runtime.auth.password_login_routes import (
            create_password_login_routes,
        )

        password_login_router = create_password_login_routes()
        ctx.app.include_router(password_login_router)

        # Form-encoded 2FA challenge submit routes (Phase 1.D.1,
        # v0.67.35) — the typed challenge view posts here instead of
        # the JSON `/auth/2fa/verify` endpoint, so the form works
        # without JS.
        from dazzle.back.runtime.auth.two_factor_form_routes import (
            create_two_factor_form_routes,
        )

        two_factor_form_router = create_two_factor_form_routes()
        ctx.app.include_router(two_factor_form_router)

        # SSO initiation + callback routes (Phase 1.C, v0.67.39).
        # Mounted unconditionally so the endpoint dispatcher can return
        # a friendly "sso_provider_unknown" redirect when SSO isn't
        # configured. The OAuth client is only constructed when a
        # registered provider is hit — `authlib` stays an optional dep.
        from dazzle.back.runtime.auth.sso_config import (
            load_sso_providers_from_env,
        )
        from dazzle.back.runtime.auth.sso_routes import create_sso_routes

        configured = load_sso_providers_from_env()
        ctx.app.state.sso_providers = configured
        if configured:
            # SessionMiddleware backs Authlib's `state` storage between
            # the initiate redirect and the callback. The session
            # cookie is signed (not encrypted) via itsdangerous — fine
            # for the short-lived state token but DON'T put sensitive
            # data in `request.session`. The secret defaults to a
            # random per-process value; production deployments should
            # set DAZZLE_SESSION_SECRET so the cookie survives restarts.
            import os
            import secrets

            from starlette.middleware.sessions import SessionMiddleware

            session_secret = os.environ.get("DAZZLE_SESSION_SECRET") or secrets.token_urlsafe(64)
            ctx.app.add_middleware(
                SessionMiddleware,
                secret_key=session_secret,
                same_site="lax",
                https_only=False,  # cookie_secure() controls per-cookie
            )
            ctx.app.include_router(create_sso_routes())

        # 2FA routes — thread the AppSpec-level TwoFactorConfig through so
        # DSL authors can tune recovery-code count etc. at app-configuration
        # time (#838). When no SecurityConfig is present on the AppSpec, the
        # routes fall back to framework defaults via TwoFactorConfig().
        twofa_config = None
        if ctx.appspec.security is not None:
            twofa_config = ctx.appspec.security.two_factor
        twofa_router = create_2fa_routes(
            ctx.auth_store,
            database_url=ctx.database_url,
            two_factor_config=twofa_config,
        )
        ctx.app.include_router(twofa_router)

        # SES webhook (if SES is configured)
        try:
            from dazzle.back.channels.ses_webhooks import register_ses_webhook

            register_ses_webhook(ctx.app)
        except Exception:
            logger.info("SES webhooks not available, skipping registration")

    def _init_social_auth(self, ctx: SubsystemContext) -> None:
        """Initialize social auth (OAuth2) if providers are configured."""
        if not ctx.auth_config or not ctx.auth_store:
            return

        # Check if OAuth providers are configured
        oauth_providers = getattr(ctx.auth_config, "oauth_providers", None)
        if not oauth_providers:
            return

        import os

        try:
            from dazzle.back.runtime.jwt_auth import JWTConfig, JWTService
            from dazzle.back.runtime.social_auth import (
                SocialAuthService,
                create_social_auth_routes,
            )
            from dazzle.back.runtime.token_store import TokenStore
        except ImportError as e:
            logger.warning("Social auth dependencies not available: %s", e)
            return

        # Get JWT config from auth_config
        jwt_cfg = getattr(ctx.auth_config, "jwt", None)
        access_minutes = getattr(jwt_cfg, "access_token_minutes", 15) if jwt_cfg else 15
        refresh_days = getattr(jwt_cfg, "refresh_token_days", 7) if jwt_cfg else 7

        # Create JWT service
        jwt_secret = os.getenv("JWT_SECRET")
        jwt_config_kwargs: dict[str, Any] = {
            "access_token_expire_minutes": access_minutes,
            "refresh_token_expire_days": refresh_days,
        }
        if jwt_secret:
            jwt_config_kwargs["secret_key"] = jwt_secret
        else:
            logger.warning(
                "JWT_SECRET not set — using auto-generated secret. "
                "Sessions will be invalidated on server restart. "
                "Set JWT_SECRET in your environment for production use."
            )
        self._jwt_service = JWTService(JWTConfig(**jwt_config_kwargs))

        # Create token store (PostgreSQL-only)
        if not ctx.database_url:
            logger.warning("Social auth requires DATABASE_URL for token storage")
            return
        self._token_store = TokenStore(
            database_url=ctx.database_url,
            token_lifetime_days=refresh_days,
        )

        # Build social auth config from manifest + environment
        social_config = self._build_social_auth_config(oauth_providers)
        if not social_config:
            logger.info("No OAuth providers configured with valid credentials")
            return

        # Create social auth service
        self._social_auth_service = SocialAuthService(
            auth_store=ctx.auth_store,
            jwt_service=self._jwt_service,
            token_store=self._token_store,
            config=social_config,
        )

        # Register social auth routes
        social_router = create_social_auth_routes(self._social_auth_service)
        ctx.app.include_router(social_router)

        # Log enabled providers
        enabled = []
        if social_config.google_client_id:
            enabled.append("google")
        if social_config.github_client_id:
            enabled.append("github")
        if social_config.apple_team_id:
            enabled.append("apple")

        if enabled:
            logger.info("Social auth enabled: %s", ", ".join(enabled))

    def _build_social_auth_config(self, oauth_providers: list[Any]) -> Any | None:
        """Build SocialAuthConfig from manifest oauth_providers.

        Reads credentials from environment variables specified in manifest.
        """
        import os

        from dazzle.back.runtime.social_auth import SocialAuthConfig

        config = SocialAuthConfig()
        any_configured = False

        for provider_cfg in oauth_providers:
            provider = provider_cfg.provider.lower()

            if provider == "google":
                client_id = os.getenv(provider_cfg.client_id_env)
                if client_id:
                    config.google_client_id = client_id
                    any_configured = True
                else:
                    logger.warning("Google OAuth: %s not set", provider_cfg.client_id_env)

            elif provider == "github":
                client_id = os.getenv(provider_cfg.client_id_env)
                client_secret = os.getenv(provider_cfg.client_secret_env)
                if client_id and client_secret:
                    config.github_client_id = client_id
                    config.github_client_secret = client_secret
                    any_configured = True
                else:
                    # Log which env vars are missing (names only, never values)
                    missing_names: list[str] = []
                    if not client_id:
                        missing_names.append("client_id")
                    if not client_secret:
                        missing_names.append("client_secret")
                    logger.warning(
                        "GitHub OAuth: missing env vars for %s",
                        ", ".join(missing_names),
                    )

            elif provider == "apple":
                # Apple requires team_id, key_id, private_key, bundle_id
                # These would need extended manifest schema
                logger.warning(
                    "Apple OAuth: requires extended configuration "
                    "(team_id, key_id, private_key, bundle_id)"
                )

            else:
                logger.warning("Unknown OAuth provider: %s", provider)

        return config if any_configured else None

    def shutdown(self) -> None:
        pass
