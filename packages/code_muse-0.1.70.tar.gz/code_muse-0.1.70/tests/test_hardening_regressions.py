import subprocess
import time
from unittest.mock import patch

from code_muse.plugins.shell_lint.register_callbacks import _lint_shell_command
from code_muse.tools.command_runner import kill_process_group


class TestShellHardening:
    """Regression tests for shell command hardening."""

    def test_kill_process_group(self):
        """Test that kill_process_group kills the process and its children."""
        # Use a command that spawns a subshell and a sleep
        cmd = "sleep 100 & sleep 100"
        proc = subprocess.Popen(cmd, shell=True, start_new_session=True)

        # Give it a moment to start
        time.sleep(0.1)

        # Verify it's running
        assert proc.poll() is None

        # Kill it
        kill_process_group(proc)

        # Verify it's dead
        # Wait a bit for the signal to propagate
        proc.wait(timeout=2)
        assert proc.poll() is not None

    def test_shell_lint_unquoted_find(self):
        """Test that unquoted find patterns are blocked."""
        command = "find . -name *.py"
        result = _lint_shell_command(None, command)
        assert result is not None
        assert result["blocked"] is True
        assert "Unquoted wildcard" in result["reason"]

    def test_shell_lint_quoted_find_passes(self):
        """Test that quoted find patterns pass."""
        command = "find . -name '*.py'"
        result = _lint_shell_command(None, command)
        assert result is None

    def test_shell_lint_mismatched_quotes_python(self):
        """Test that mismatched quotes in python -c are blocked."""
        # count(') = 1, count(") = 1 -> odd, odd -> BLOCKS
        command = "python3 -c \"print('hello)"
        result = _lint_shell_command(None, command)
        assert result is not None
        assert result["blocked"] is True

        # count(') = 2, count(") = 2 -> even, even -> PASSES
        command = "python3 -c \"print('hello')\""
        result = _lint_shell_command(None, command)
        assert result is None

    def test_shell_lint_unquoted_grep(self):
        """Test that unquoted grep patterns are blocked."""
        command = "grep -n test *.log"
        result = _lint_shell_command(None, command)
        assert result is not None
        assert result["blocked"] is True


class TestStreamingPolicy:
    """Regression tests for streaming policy."""

    @patch("code_muse.provider_identity.resolve_provider_identity")
    def test_streaming_policy_flaky_provider(self, mock_resolve):
        """Test that flaky providers have streaming disabled."""
        from code_muse.agents._run_utils import _model_allows_streaming

        # Test crof (Kimi)
        # We need to mock ModelFactory.load_config too because _model_allows_streaming calls it
        with patch("code_muse.model_factory.ModelFactory.load_config") as mock_cfg:
            mock_cfg.return_value = {"kimi": {"provider": "crof", "name": "kimi-v1"}}
            assert _model_allows_streaming("kimi") is False

            mock_cfg.return_value = {"gpt4": {"provider": "openai", "name": "gpt-4"}}
            assert _model_allows_streaming("gpt4") is True

    def test_round_robin_streaming_policy(self):
        """Test that round-robin models disable streaming if any member is flaky."""
        from code_muse.agents._run_utils import _model_allows_streaming

        with patch("code_muse.model_factory.ModelFactory.load_config") as mock_cfg:
            mock_cfg.return_value = {
                "rr": {"type": "round_robin", "models": ["gpt4", "kimi"]},
                "gpt4": {"provider": "openai"},
                "kimi": {"provider": "crof"},
            }
            assert _model_allows_streaming("rr") is False
