"""Tests for agent max-run limits, usage limits, and token budget configuration.

Covers gaps found during code review (now resolved):
1. total_tokens_limit / max_tool_calls config getters exist and are exported
2. build_usage_limits() wires all caps into pydantic-ai UsageLimits
3. Sub-agents use build_usage_limits() consistently with primary agent
"""

from unittest.mock import patch

from code_muse import config as cp_config
from code_muse.agents import _runtime
from code_muse.config import parser
from code_muse.tools import agent_tools

# ---------------------------------------------------------------------------
# Gap 1 (RESOLVED): Config getters now exist
# ---------------------------------------------------------------------------


class TestConfigGettersExist:
    """total_tokens_limit and max_tool_calls getters now exist
    and are exported from code_muse.config."""

    def test_total_tokens_limit_in_get_config_keys(self):
        """The key is listed so it appears in /set tab-completion."""
        keys = cp_config.get_config_keys()
        assert "total_tokens_limit" in keys

    def test_max_tool_calls_in_get_config_keys(self):
        """The key is listed so it appears in /set tab-completion."""
        keys = cp_config.get_config_keys()
        assert "max_tool_calls" in keys

    def test_get_total_tokens_limit_function_in_parser(self):
        """The getter exists in parser."""
        assert hasattr(parser, "get_total_tokens_limit")

    def test_get_max_tool_calls_function_in_parser(self):
        """The getter exists in parser."""
        assert hasattr(parser, "get_max_tool_calls")

    def test_exported_from_config_init(self):
        """These functions are exported from code_muse.config."""
        assert hasattr(cp_config, "get_total_tokens_limit")
        assert hasattr(cp_config, "get_max_tool_calls")

    def test_build_usage_limits_exported(self):
        """build_usage_limits is exported from code_muse.config."""
        assert hasattr(cp_config, "build_usage_limits")


# ---------------------------------------------------------------------------
# Gap 2 (RESOLVED): build_usage_limits wires all caps
# ---------------------------------------------------------------------------


class TestBuildUsageLimits:
    """build_usage_limits() wires request, token, and tool-call limits."""

    @patch("code_muse.config.parser.get_value", return_value=None)
    def test_defaults_no_token_or_tool_limits(self, _mock_gv):
        """When no config is set, total_tokens and tool_calls are None (unlimited)."""
        from code_muse.config.parser import build_usage_limits

        ul = build_usage_limits()
        assert ul.request_limit == 1000  # default message limit
        assert ul.total_tokens_limit is None
        assert ul.tool_calls_limit is None

    @patch("code_muse.config.parser.get_value")
    def test_configured_limits_passed_through(self, mock_gv):
        """Configured total_tokens_limit and max_tool_calls flow through."""
        from code_muse.config.parser import build_usage_limits, get_message_limit

        def side_effect(key, section=None):
            return {"total_tokens_limit": "50000", "max_tool_calls": "25"}.get(key)

        mock_gv.side_effect = side_effect
        ul = build_usage_limits()
        assert ul.request_limit == get_message_limit()  # preserved
        assert ul.total_tokens_limit == 50000
        assert ul.tool_calls_limit == 25

    @patch("code_muse.config.parser.get_value")
    def test_zero_means_unlimited(self, mock_gv):
        """Config value of 0 maps to None (unlimited) in UsageLimits."""
        from code_muse.config.parser import build_usage_limits

        def side_effect(key, section=None):
            return {
                "total_tokens_limit": "0",
                "max_tool_calls": "0",
                "max_messages_hard_cap": "100",
            }.get(key)

        mock_gv.side_effect = side_effect
        ul = build_usage_limits()
        assert ul.total_tokens_limit is None
        assert ul.tool_calls_limit is None

    def test_runtime_uses_build_usage_limits(self):
        """_runtime.py uses build_usage_limits() instead of bare UsageLimits."""
        source = _runtime.__file__
        with open(source) as f:
            content = f.read()
        assert "build_usage_limits()" in content
        # Should NOT have the old bare construction
        assert "UsageLimits(request_limit=get_message_limit())" not in content

    @patch("code_muse.config.parser.get_value", return_value=None)
    def test_graceful_fallback_on_unsupported_field(self, _mock_gv):
        """If UsageLimits raises TypeError on unknown field, fall back gracefully."""
        from code_muse.config.parser import build_usage_limits

        # With current pydantic-ai the fields ARE supported,
        # so this test verifies the happy-path still works.
        ul = build_usage_limits()
        assert ul.request_limit == 1000


# ---------------------------------------------------------------------------
# Gap 3 (RESOLVED): Sub-agents use build_usage_limits
# ---------------------------------------------------------------------------


class TestSubAgentUsageLimits:
    """Sub-agent invocations use build_usage_limits() consistently."""

    def test_sub_agent_uses_build_usage_limits(self):
        """agent_tools.py uses build_usage_limits() instead of bare UsageLimits."""
        source = agent_tools.__file__
        with open(source) as f:
            content = f.read()
        assert "build_usage_limits()" in content
        # Should NOT have the old bare construction
        assert "UsageLimits(request_limit=get_message_limit())" not in content

    def test_sub_agent_does_not_pass_usage_limits_none(self):
        """Sub-agents do not pass usage_limits=None."""
        source = agent_tools.__file__
        with open(source) as f:
            content = f.read()
        assert "usage_limits=None" not in content


# ---------------------------------------------------------------------------
# Gap 4: get_message_limit() has zero tests
# ---------------------------------------------------------------------------


class TestMessageLimitConfig:
    """get_message_limit() has no tests anywhere — covering it now."""

    def test_default_message_limit(self):
        """Default is 1000 when no config is set."""
        from code_muse.config.parser import get_message_limit

        with patch("code_muse.config.parser.get_value", return_value=None):
            assert get_message_limit() == 1000

    def test_message_limit_from_config(self):
        """Reads the configured value."""
        from code_muse.config.parser import get_message_limit

        with patch("code_muse.config.parser.get_value", return_value="500"):
            assert get_message_limit() == 500

    def test_message_limit_invalid_falls_back_to_default(self):
        """Invalid config values fall back to default."""
        from code_muse.config.parser import get_message_limit

        with patch("code_muse.config.parser.get_value", return_value="not-a-number"):
            assert get_message_limit() == 1000

    def test_message_limit_empty_falls_back_to_default(self):
        """Empty string falls back to default."""
        from code_muse.config.parser import get_message_limit

        with patch("code_muse.config.parser.get_value", return_value=""):
            assert get_message_limit() == 1000

    def test_message_limit_zero(self):
        """Zero is accepted (agent gets zero steps)."""
        from code_muse.config.parser import get_message_limit

        with patch("code_muse.config.parser.get_value", return_value="0"):
            assert get_message_limit() == 0


# ---------------------------------------------------------------------------
# Gap 5: compute_effective_history_budget() has zero tests
# ---------------------------------------------------------------------------


class TestEffectiveHistoryBudget:
    """compute_effective_history_budget() has no tests —
    covering the four model-class tiers.

    ModelFactory.load_config is mocked to return {} so the function
    falls back to out_max = max(4096, min(65536, ctx*0.08)).
    """

    @patch("code_muse.model_factory.ModelFactory.load_config", return_value={})
    def test_large_context_1m_plus(self, _mock_mf):
        """≥1M context: 88% budget (minus out_max 32768 and safety 20000)."""
        from code_muse.config.models import compute_effective_history_budget

        budget = compute_effective_history_budget(1_000_000, overhead=0)
        # 88% of 1M = 880000, out_max=min(32768, 150000)=32768, safety=20000
        # budget = 880000 - 32768 - 20000 = 827232
        assert budget == 827_232

    @patch("code_muse.model_factory.ModelFactory.load_config", return_value={})
    def test_medium_context_200k(self, _mock_mf):
        """100k–1M: 74% budget (minus out_max 16000 and safety 4000)."""
        from code_muse.config.models import compute_effective_history_budget

        budget = compute_effective_history_budget(200_000, overhead=0)
        # 74% of 200k = 148000, out_max=16000, safety=4000
        # budget = 148000 - 16000 - 4000 = 128000
        assert budget == 128_000

    @patch("code_muse.model_factory.ModelFactory.load_config", return_value={})
    def test_small_context_64k(self, _mock_mf):
        """32k–100k: 68% budget (minus out_max 5120 and safety 2048)."""
        from code_muse.config.models import compute_effective_history_budget

        budget = compute_effective_history_budget(64_000, overhead=0)
        # 68% of 64k = 43520, out_max=5120, safety=2048
        # budget = 43520 - 5120 - 2048 = 36352
        assert budget == 36_352

    @patch("code_muse.model_factory.ModelFactory.load_config", return_value={})
    def test_tiny_context_16k(self, _mock_mf):
        """<32k: 55% budget clamped to floor of 4096."""
        from code_muse.config.models import compute_effective_history_budget

        budget = compute_effective_history_budget(16_000, overhead=0)
        # 55% of 16k = 8800, out_max=4096, safety=2048
        # budget = 8800 - 4096 - 2048 = 2656, clamped to 4096
        assert budget == 4096

    @patch("code_muse.model_factory.ModelFactory.load_config", return_value={})
    def test_with_overhead(self, _mock_mf):
        """Overhead is subtracted from the budget."""
        from code_muse.config.models import compute_effective_history_budget

        budget = compute_effective_history_budget(200_000, overhead=10_000)
        # 74% of 200k = 148000, minus 10000 overhead, out_max=16000, safety=4000
        # budget = 148000 - 10000 - 16000 - 4000 = 118000
        assert budget == 118_000

    @patch("code_muse.model_factory.ModelFactory.load_config", return_value={})
    def test_overhead_exceeds_budget(self, _mock_mf):
        """When overhead exceeds budget, result is clamped to floor."""
        from code_muse.config.models import compute_effective_history_budget

        budget = compute_effective_history_budget(16_000, overhead=50_000)
        # overhead > max possible budget, result clamped to 4096
        assert budget == 4096


# ---------------------------------------------------------------------------
# Gap 6: filter_huge_message_threshold — getter exists but hidden from /set
# ---------------------------------------------------------------------------


class TestFilterHugeMessageThreshold:
    """filter_huge_message_threshold has a getter but is hidden
    from /set tab-completion."""

    def test_getter_exists(self):
        """The getter function exists."""
        from code_muse.config.parser import get_filter_huge_message_threshold

        assert callable(get_filter_huge_message_threshold)

    def test_in_get_config_keys(self):
        """Now visible in /set tab-completion."""
        keys = cp_config.get_config_keys()
        assert "filter_huge_message_threshold" in keys

    def test_used_in_history(self):
        """It IS actually used in _history.py for message filtering."""
        import code_muse.agents._history as hist

        source = hist.__file__
        with open(source) as f:
            content = f.read()
        assert "get_filter_huge_message_threshold" in content

    def test_default_value(self):
        """Default threshold is 50000."""
        from code_muse.config.parser import get_filter_huge_message_threshold

        with patch("code_muse.config.parser.get_value", return_value=None):
            assert get_filter_huge_message_threshold() == 50000


# ---------------------------------------------------------------------------
# Gap 7: max_loop_iterations safety cap in _runtime.py
# ---------------------------------------------------------------------------


class TestMaxLoopIterationsSafetyCap:
    """The hardcoded max_loop_iterations=50 safety cap in _runtime.py."""

    def test_safety_cap_exists(self):
        """The safety cap constant exists."""
        source = _runtime.__file__
        with open(source) as f:
            content = f.read()
        assert "max_loop_iterations = 50" in content

    def test_safety_cap_is_used_in_loop(self):
        """The cap is used as the loop range."""
        source = _runtime.__file__
        with open(source) as f:
            content = f.read()
        assert "for _ in range(max_loop_iterations):" in content

    def test_separate_retry_budgets_exist(self):
        """Both hook and critic retry budgets are read from config."""
        source = _runtime.__file__
        with open(source) as f:
            content = f.read()
        assert "get_max_hook_retries()" in content
        assert "get_max_critic_retries()" in content

    def test_both_exhausted_check_prevents_loop(self):
        """The loop breaks when both budgets are exhausted, not just one."""
        source = _runtime.__file__
        with open(source) as f:
            content = f.read()
        assert "both_exhausted" in content
