"""Tests for per-callback timeout and fire-and-forget exception logging.

Covers:
- ``_trigger_callbacks`` (async) timeout via ``asyncio.wait_for``
- ``_trigger_callbacks_sync`` timeout via ``future.result(timeout=…)``
- ``on_startup`` inline timeout
- ``fire_callbacks`` exception logging for async fire-and-forget tasks
- ``_get_callback_timeout`` env-var configuration
"""

import asyncio
import os
from unittest.mock import patch

import pytest

from code_muse.callbacks import (
    clear_callbacks,
    fire_callbacks,
    on_startup,
    register_callback,
)
from code_muse.callbacks._callback_engine import (
    _ENV_CALLBACK_TIMEOUT,
    _get_callback_timeout,
    _trigger_callbacks,
    _trigger_callbacks_sync,
)


class TestGetCallbackTimeout:
    """Tests for the _get_callback_timeout config helper."""

    def test_default_timeout_is_30(self):
        """Without env var, returns 30 seconds."""
        with patch.dict(os.environ, {}, clear=True):
            assert _get_callback_timeout() == 30.0

    def test_env_var_overrides_default(self):
        """MUSE_CALLBACK_TIMEOUT=5 → 5 seconds."""
        with patch.dict(os.environ, {_ENV_CALLBACK_TIMEOUT: "5"}):
            assert _get_callback_timeout() == 5.0

    def test_env_var_float_value(self):
        """Float values are accepted."""
        with patch.dict(os.environ, {_ENV_CALLBACK_TIMEOUT: "0.5"}):
            assert _get_callback_timeout() == 0.5

    def test_env_var_zero_disables_timeout(self):
        """Zero disables timeout (useful for debugging)."""
        with patch.dict(os.environ, {_ENV_CALLBACK_TIMEOUT: "0"}):
            assert _get_callback_timeout() == 0.0

    def test_env_var_negative_uses_default(self):
        """Negative values are rejected, default used."""
        with (
            patch.dict(os.environ, {_ENV_CALLBACK_TIMEOUT: "-10"}),
            patch("code_muse.callbacks._callback_engine.logger") as m_log,
        ):
            assert _get_callback_timeout() == 30.0
            m_log.warning.assert_called_once()

    def test_env_var_invalid_uses_default(self):
        """Non-numeric values are rejected, default used."""
        with (
            patch.dict(os.environ, {_ENV_CALLBACK_TIMEOUT: "nope"}),
            patch("code_muse.callbacks._callback_engine.logger") as m_log,
        ):
            assert _get_callback_timeout() == 30.0
            m_log.warning.assert_called_once()


class TestAsyncCallbackTimeout:
    """Tests for _trigger_callbacks (async) per-callback timeout."""

    def setup_method(self):
        clear_callbacks()

    @pytest.mark.asyncio
    async def test_slow_async_callback_times_out(self):
        """A callback that sleeps beyond the timeout should be cut short."""

        async def slow_callback():
            await asyncio.sleep(9999)
            return "should not reach"

        register_callback("shutdown", slow_callback)

        with (
            patch.dict(os.environ, {_ENV_CALLBACK_TIMEOUT: "0.2"}),
            patch("code_muse.callbacks._callback_engine.logger") as m_log,
        ):
            results = await _trigger_callbacks("shutdown")
            assert results == [None]
            # A warning about the timeout should have been logged
            warn_calls = [
                c.args[0]
                for c in m_log.warning.call_args_list
                if "timed out" in c.args[0]
            ]
            assert len(warn_calls) == 1
            assert "slow_callback" in warn_calls[0]

    @pytest.mark.asyncio
    async def test_fast_async_callback_completes_within_timeout(self):
        """A callback that finishes before timeout returns normally."""

        async def fast_callback():
            return "fast"

        register_callback("shutdown", fast_callback)

        with patch.dict(os.environ, {_ENV_CALLBACK_TIMEOUT: "5"}):
            results = await _trigger_callbacks("shutdown")
            assert results == ["fast"]

    @pytest.mark.asyncio
    async def test_timeout_does_not_block_subsequent_callbacks(self):
        """After a timeout, the chain continues to the next callback."""

        async def slow_callback():
            await asyncio.sleep(9999)

        async def good_callback():
            return "good"

        register_callback("shutdown", slow_callback)
        register_callback("shutdown", good_callback)

        with patch.dict(os.environ, {_ENV_CALLBACK_TIMEOUT: "0.2"}):
            results = await _trigger_callbacks("shutdown")
            assert len(results) == 2
            assert results[0] is None  # timed out
            assert results[1] == "good"  # ran fine

    @pytest.mark.asyncio
    async def test_zero_timeout_disables_wait_for(self):
        """When timeout=0, asyncio.wait_for is skipped entirely."""

        async def forever_callback():
            # With timeout disabled, this would hang. We patch
            # wait_for to prove it's NOT called.
            return "no-limit"

        register_callback("shutdown", forever_callback)

        with patch.dict(os.environ, {_ENV_CALLBACK_TIMEOUT: "0"}):
            results = await _trigger_callbacks("shutdown")
            assert results == ["no-limit"]


class TestSyncCallbackTimeout:
    """Tests for _trigger_callbacks_sync per-callback timeout."""

    def setup_method(self):
        clear_callbacks()

    def test_sync_callback_fast_path(self):
        """Sync callbacks are not affected by timeout."""

        def sync_cb():
            return "sync_result"

        register_callback("load_model_config", sync_cb)

        results = _trigger_callbacks_sync("load_model_config")
        assert results == ["sync_result"]


class TestOnStartupTimeout:
    """Tests for on_startup per-callback timeout."""

    def setup_method(self):
        clear_callbacks()

    @pytest.mark.asyncio
    async def test_slow_startup_callback_times_out(self):
        """A slow startup callback should be cut short and logged."""

        async def slow_startup():
            await asyncio.sleep(9999)
            return "never"

        register_callback("startup", slow_startup)

        with (
            patch.dict(os.environ, {_ENV_CALLBACK_TIMEOUT: "0.2"}),
            patch("code_muse.callbacks._lifecycle_hooks.logger") as m_log,
        ):
            results = await on_startup()
            assert results == [None]
            # Should have a warning about the timeout
            warn_calls = [
                c.args[0]
                for c in m_log.warning.call_args_list
                if "timed out" in c.args[0]
            ]
            assert len(warn_calls) >= 1

    @pytest.mark.asyncio
    async def test_startup_timeout_then_success(self):
        """A timed-out callback followed by a fast one — both get processed."""

        async def slow():
            await asyncio.sleep(9999)

        def fast():
            return "ok"

        register_callback("startup", slow)
        register_callback("startup", fast)

        with patch.dict(os.environ, {_ENV_CALLBACK_TIMEOUT: "0.2"}):
            results = await on_startup()
            assert results[0] is None
            assert results[1] == "ok"


class TestFireAndForgetExtensionLogging:
    """Tests for fire_callbacks exception logging."""

    def setup_method(self):
        clear_callbacks()

    @pytest.mark.asyncio
    async def test_fire_and_forget_async_exception_logged(self):
        """Async fire-and-forget tasks that raise should have exceptions logged."""

        async def bad_callback(*args, **kwargs):
            raise RuntimeError("boom")

        register_callback("on_message", bad_callback)

        # Patch the package-level logger that the _PackageLogger proxy resolves to
        with patch("code_muse.callbacks.logger") as m_log:
            fire_callbacks("on_message", "hello")
            # The task runs in the current loop; give it a moment
            await asyncio.sleep(0.1)
            # Should have logged an error about the exception
            error_calls = [
                c
                for c in m_log.error.call_args_list
                if "boom" in str(c) or "bad_callback" in str(c)
            ]
            assert len(error_calls) >= 1

    def test_fire_and_forget_sync_exception_logged(self):
        """Sync fire-and-forget callbacks that raise should have exceptions logged."""

        def bad_sync(*args, **kwargs):
            raise ValueError("sync boom")

        register_callback("on_message", bad_sync)

        # Patch the package-level logger that the _PackageLogger proxy resolves to
        with patch("code_muse.callbacks.logger") as m_log:
            fire_callbacks("on_message", "hello")
            debug_calls = [
                c.args[0] for c in m_log.debug.call_args_list if "bad_sync" in c.args[0]
            ]
            assert len(debug_calls) >= 1


class TestFireAndForgetAgentExceptionDispatch:
    """Tests that fire-and-forget callbacks dispatch the agent_exception hook."""

    def setup_method(self):
        clear_callbacks()

    @pytest.mark.asyncio
    async def test_async_exception_dispatches_agent_exception(self):
        """When an async fire-and-forget callback raises, agent_exception is fired."""

        observed = []

        def observer(exc, *args, **kwargs):
            observed.append(exc)

        async def bad_callback(*args, **kwargs):
            raise RuntimeError("async boom")

        register_callback("on_message", bad_callback)
        register_callback("agent_exception", observer)

        fire_callbacks("on_message", "hello")
        await asyncio.sleep(0.2)

        assert len(observed) == 1
        assert isinstance(observed[0], RuntimeError)
        assert str(observed[0]) == "async boom"

    def test_sync_exception_dispatches_agent_exception(self):
        """When a sync fire-and-forget callback raises, agent_exception is fired."""

        observed = []

        def observer(exc, *args, **kwargs):
            observed.append(exc)

        def bad_callback(*args, **kwargs):
            raise ValueError("sync boom")

        register_callback("on_message", bad_callback)
        register_callback("agent_exception", observer)

        fire_callbacks("on_message", "hello")

        # Sync callback exceptions are dispatched to agent_exception
        # synchronously within fire_callbacks itself.
        assert len(observed) == 1
        assert isinstance(observed[0], ValueError)
        assert str(observed[0]) == "sync boom"

    @pytest.mark.asyncio
    async def test_agent_exception_does_not_recurse(self):
        """An agent_exception callback that raises should not cause infinite recursion."""

        call_count = 0

        def bad_observer(exc, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            raise RuntimeError("observer also fails")

        async def bad_callback(*args, **kwargs):
            raise RuntimeError("original boom")

        register_callback("on_message", bad_callback)
        register_callback("agent_exception", bad_observer)

        # Must not hang or blow the stack
        fire_callbacks("on_message", "hello")
        await asyncio.sleep(0.3)

        # The original callback fires once; the observer fires once.
        # The observer's own failure should NOT re-trigger agent_exception
        # because the phase guard blocks it.
        assert call_count == 1

    def test_sync_agent_exception_does_not_recurse(self):
        """A sync agent_exception observer that raises should not recurse."""

        call_count = 0

        def bad_observer(exc, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            raise RuntimeError("observer also fails")

        def bad_callback(*args, **kwargs):
            raise RuntimeError("original boom")

        register_callback("on_message", bad_callback)
        register_callback("agent_exception", bad_observer)

        fire_callbacks("on_message", "hello")

        # The observer runs once; its own failure is caught by the
        # phase guard and does not re-trigger agent_exception.
        assert call_count == 1
