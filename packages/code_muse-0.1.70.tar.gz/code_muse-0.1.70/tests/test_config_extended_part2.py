from unittest.mock import patch

import pytest

from code_muse.config import (
    clear_agent_pinned_model,
    get_agent_pinned_model,
    get_compaction_strategy,
    get_compaction_threshold,
    set_agent_pinned_model,
)


class TestConfigExtendedPart2:
    """Test advanced configuration functions in code_muse/config.py"""

    @pytest.fixture
    def mock_config_file(self):
        """Mock config file operations"""
        with patch("code_muse.config.CONFIG_FILE", "/mock/config/muse.cfg"):
            yield

    def test_agent_pinned_model_get_set(self, mock_config_file):
        """Test getting and setting agent pinned model.

        Patch target note: config_agent.py does `import parser as _parser`
        and calls _parser.get_value/set_config_value, so we patch
        parser.get_value / parser.set_config_value (the shim module).
        """
        agent_name = "test-agent"
        model_name = "gpt-4"

        # Test getting non-existent pinned model
        with patch("code_muse.config.parser.get_value") as mock_get:
            mock_get.return_value = None
            result = get_agent_pinned_model(agent_name)
            assert result is None
            mock_get.assert_called_once_with(f"agent_model_{agent_name}")

        # Test setting pinned model
        with patch("code_muse.config.parser.set_config_value") as mock_set:
            set_agent_pinned_model(agent_name, model_name)
            mock_set.assert_called_once_with(f"agent_model_{agent_name}", model_name)

        # Test getting existing pinned model
        with patch("code_muse.config.parser.get_value") as mock_get:
            mock_get.return_value = model_name
            result = get_agent_pinned_model(agent_name)
            assert result == model_name
            mock_get.assert_called_once_with(f"agent_model_{agent_name}")

    def test_clear_agent_pinned_model(self, mock_config_file):
        """Test clearing agent-specific pinned models"""
        agent_name = "test-agent"

        with patch("code_muse.config.parser.set_config_value") as mock_set:
            clear_agent_pinned_model(agent_name)
            mock_set.assert_called_once_with(f"agent_model_{agent_name}", "")

    def test_get_compaction_strategy(self, mock_config_file):
        """Test getting compaction strategy configuration.

        Patch target note: get_compaction_strategy() lives in parser_runtime.py
        and calls get_value imported at module scope from parser_core, so we
        must patch parser_runtime.get_value (not parser.get_value).
        """
        # Test default strategy
        with patch("code_muse.config.parser_runtime.get_value") as mock_get:
            mock_get.return_value = None
            result = get_compaction_strategy()
            assert result == "summarization"  # Default value
            mock_get.assert_called_once_with("compaction_strategy")

        # Test valid strategies
        for strategy in ["summarization", "truncation"]:
            with patch("code_muse.config.parser_runtime.get_value") as mock_get:
                mock_get.return_value = strategy.upper()  # Test case normalization
                result = get_compaction_strategy()
                assert result == strategy.lower()

        # Test invalid strategy falls back to default
        with patch("code_muse.config.parser_runtime.get_value") as mock_get:
            mock_get.return_value = "invalid_strategy"
            result = get_compaction_strategy()
            assert result == "summarization"  # Default fallback

    def test_get_compaction_threshold(self, mock_config_file):
        """Test getting compaction threshold configuration.

        Patch target note: same as test_get_compaction_strategy — patch
        parser_runtime.get_value because get_compaction_threshold() uses
        get_value imported at module scope from parser_core.
        """
        # Test default threshold
        with patch("code_muse.config.parser_runtime.get_value") as mock_get:
            mock_get.return_value = None
            result = get_compaction_threshold()
            assert result == 0.90  # Default value
            mock_get.assert_called_once_with("compaction_threshold")

        # Test valid threshold (in 0.90–0.97 range)
        with patch("code_muse.config.parser_runtime.get_value") as mock_get:
            mock_get.return_value = "0.93"
            result = get_compaction_threshold()
            assert result == 0.93

        # Test threshold clamping - minimum (below 0.90 floor)
        with patch("code_muse.config.parser_runtime.get_value") as mock_get:
            mock_get.return_value = "0.3"  # Below floor
            result = get_compaction_threshold()
            assert result == 0.90  # Clamped to floor

        # Test threshold clamping - maximum
        with patch("code_muse.config.parser_runtime.get_value") as mock_get:
            mock_get.return_value = "0.98"  # Above maximum
            result = get_compaction_threshold()
            assert result == 0.97  # Clamped to maximum

        # Test invalid value falls back to default
        with patch("code_muse.config.parser_runtime.get_value") as mock_get:
            mock_get.return_value = "invalid"
            result = get_compaction_threshold()
            assert result == 0.90  # Default fallback

    def test_agent_pinned_model_integration(self, mock_config_file):
        """Test integration of agent pinned model functions"""
        agent_name = "integration-agent"
        model_name = "claude-3-sonnet"

        # Mock the underlying config operations
        with (
            patch("code_muse.config.parser.set_config_value") as mock_set,
            patch("code_muse.config.parser.get_value") as mock_get,
        ):
            # Initially no pinned model
            mock_get.return_value = None
            assert get_agent_pinned_model(agent_name) is None

            # Set a pinned model
            set_agent_pinned_model(agent_name, model_name)
            mock_set.assert_called_with(f"agent_model_{agent_name}", model_name)

            # Get the pinned model
            mock_get.return_value = model_name
            assert get_agent_pinned_model(agent_name) == model_name

            # Clear the pinned model
            clear_agent_pinned_model(agent_name)
            mock_set.assert_called_with(f"agent_model_{agent_name}", "")

    def test_compaction_config_edge_cases(self, mock_config_file):
        """Test edge cases for compaction configuration.

        Patch target note: compaction functions are in parser_runtime.py
        (patch parser_runtime.get_value), but agent-model functions go
        through the parser shim (patch parser.get_value / parser.set_config_value).
        """
        # Test compaction strategy with whitespace (note: actual implementation doesn't strip)
        with patch("code_muse.config.parser_runtime.get_value") as mock_get:
            mock_get.return_value = "  summarization  "
            result = get_compaction_strategy()
            # The actual implementation doesn't strip whitespace, so it falls back to default
            assert result == "summarization"  # Default fallback for non-exact match

        # Test compaction strategy with exact match
        with patch("code_muse.config.parser_runtime.get_value") as mock_get:
            mock_get.return_value = "summarization"
            result = get_compaction_strategy()
            assert result == "summarization"

        # Test compaction threshold with extreme values
        test_cases = [
            ("0", 0.90),  # Below floor → clamped to 0.90
            ("1.0", 0.97),  # Above maximum
            ("-0.1", 0.90),  # Negative → clamped to floor
            ("2.0", 0.97),  # Above 1.0
        ]

        for input_val, expected in test_cases:
            with patch("code_muse.config.parser_runtime.get_value") as mock_get:
                mock_get.return_value = input_val
                result = get_compaction_threshold()
                assert result == expected

    def test_config_value_types(self, mock_config_file):
        """Test that config values handle different types correctly"""
        # Test with integer values for threshold
        with patch("code_muse.config.parser_runtime.get_value") as mock_get:
            mock_get.return_value = "1"
            result = get_compaction_threshold()
            assert isinstance(result, float)
            assert result == 0.97  # Clamped to maximum

        # Test with float values for threshold (within 0.90–0.97 range)
        with patch("code_muse.config.parser_runtime.get_value") as mock_get:
            mock_get.return_value = "0.93"
            result = get_compaction_threshold()
            assert isinstance(result, float)
            assert result == 0.93
