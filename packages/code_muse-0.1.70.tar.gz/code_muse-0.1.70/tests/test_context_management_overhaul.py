"""Tests for context management overhaul: proactive truncation, hard cap, hygiene plugin."""

from unittest.mock import patch

from code_muse.config import (
    get_max_messages_hard_cap,
    get_proactive_truncation_message_count,
)

# ---------------------------------------------------------------------------
# get_proactive_truncation_message_count
# ---------------------------------------------------------------------------


class TestProactiveTruncationMessageCount:
    """Tests for the configurable proactive truncation threshold."""

    def test_default_returns_15(self):
        """With no config override, the default is 15."""
        with patch("code_muse.config.parser_safety.get_value", return_value=None):
            assert get_proactive_truncation_message_count() == 15

    def test_config_override_works(self):
        """A valid config value is respected."""
        with patch("code_muse.config.parser_safety.get_value", return_value="25"):
            assert get_proactive_truncation_message_count() == 25

    def test_minimum_clamping(self):
        """Values below 10 are clamped to 10."""
        with patch("code_muse.config.parser_safety.get_value", return_value="3"):
            assert get_proactive_truncation_message_count() == 10

    def test_invalid_config_returns_default(self):
        """Non-numeric config values fall back to default 15."""
        with patch("code_muse.config.parser_safety.get_value", return_value="abc"):
            assert get_proactive_truncation_message_count() == 15

    def test_none_config_returns_default(self):
        """None config value falls back to default 15."""
        with patch("code_muse.config.parser_safety.get_value", return_value=None):
            assert get_proactive_truncation_message_count() == 15


# ---------------------------------------------------------------------------
# get_max_messages_hard_cap
# ---------------------------------------------------------------------------


class TestMaxMessagesHardCap:
    """Tests for the raised hard cap and dynamic scaling."""

    def test_default_no_model_returns_at_least_300(self):
        """Without a model_max, the hard cap is at least 300."""
        with patch("code_muse.config.parser_safety.get_value", return_value=None):
            result = get_max_messages_hard_cap(model_max=None)
            # max(300, compute_dynamic_message_cap(default=300)) = 300
            assert result >= 300

    def test_all_models_return_at_least_300(self):
        """Any model_max yields a hard cap >= 300 due to max(300, ...) floor."""
        with patch("code_muse.config.parser_safety.get_value", return_value=None):
            # 4k model — dynamic cap is 300 (tier floor), max(300, 300) = 300
            assert get_max_messages_hard_cap(model_max=4096) >= 300
            # 200k model — dynamic cap is 400, max(300, 400) = 400
            result_200k = get_max_messages_hard_cap(model_max=200000)
            assert result_200k >= 300
            assert result_200k == 400  # tier-appropriate, not just floor
            # 1M+ model — dynamic cap is 500, max(300, 500) = 500
            result_1m = get_max_messages_hard_cap(model_max=1000000)
            assert result_1m >= 300
            assert result_1m == 500  # tier-appropriate

    def test_dynamic_scaling_works(self):
        """Large models get higher caps than small models."""
        with patch("code_muse.config.parser_safety.get_value", return_value=None):
            small = get_max_messages_hard_cap(model_max=4096)
            medium = get_max_messages_hard_cap(model_max=200000)
            large = get_max_messages_hard_cap(model_max=1000000)
            assert small <= medium <= large

    def test_user_override_works(self):
        """A user-set config value is respected (clamped to min 10)."""
        with patch("code_muse.config.parser_safety.get_value", return_value="500"):
            result = get_max_messages_hard_cap(model_max=None)
            assert result == 500

    def test_user_override_clamped_to_10(self):
        """User overrides below 10 are clamped."""
        with patch("code_muse.config.parser_safety.get_value", return_value="3"):
            result = get_max_messages_hard_cap(model_max=None)
            assert result == 10


# ---------------------------------------------------------------------------
# Exception handling correctness (parser_safety.py)
# ---------------------------------------------------------------------------


class TestExceptionHandling:
    """Verify that except clauses in parser_safety.py catch both types."""

    def test_get_max_consecutive_tool_errors_catches_valueerror(self):
        """get_max_consecutive_tool_errors handles ValueError from int()."""
        from code_muse.config.parser_safety import get_max_consecutive_tool_errors

        with patch("code_muse.config.parser_safety.get_value", return_value="abc"):
            # If except clause only caught ValueError (not TypeError),
            # a TypeError from int(None) would escape. This test
            # exercises the ValueError branch.
            result = get_max_consecutive_tool_errors()
            assert isinstance(result, int)

    def test_get_max_consecutive_tool_errors_catches_typeerror(self):
        """get_max_consecutive_tool_errors handles TypeError from int(None)."""
        from code_muse.config.parser_safety import get_max_consecutive_tool_errors

        with patch("code_muse.config.parser_safety.get_value", return_value=None):
            # int(None) raises TypeError — the except clause must catch it.
            result = get_max_consecutive_tool_errors()
            assert isinstance(result, int)

    def test_get_proactive_truncation_catches_typeerror(self):
        """get_proactive_truncation_message_count handles TypeError."""
        from code_muse.config.parser_safety import (
            get_proactive_truncation_message_count,
        )

        with patch("code_muse.config.parser_safety.get_value", return_value=None):
            # int(None) raises TypeError — must be caught.
            result = get_proactive_truncation_message_count()
            assert result == 15  # default

    def test_get_max_messages_hard_cap_catches_typeerror(self):
        """get_max_messages_hard_cap handles TypeError from int(None)."""
        from code_muse.config.parser_safety import get_max_messages_hard_cap

        with patch("code_muse.config.parser_safety.get_value", return_value=None):
            # int(None) raises TypeError — the except clause must catch it.
            result = get_max_messages_hard_cap(model_max=None)
            assert isinstance(result, int)
            assert result >= 300

    def test_get_total_tokens_limit_catches_typeerror(self):
        """get_total_tokens_limit handles TypeError."""
        from code_muse.config.parser_safety import get_total_tokens_limit

        with patch("code_muse.config.parser_safety.get_value", return_value=None):
            result = get_total_tokens_limit()
            assert isinstance(result, int)


# ---------------------------------------------------------------------------
# Context hygiene plugin
# ---------------------------------------------------------------------------


class TestContextHygienePlugin:
    """Tests for the context_hygiene plugin registration."""

    def test_import_works(self):
        """The plugin module is importable."""
        from code_muse.plugins.context_hygiene import register_callbacks  # noqa: F401

    def test_callback_registered(self):
        """The load_prompt callback is registered and returns a string."""
        from code_muse.plugins.context_hygiene.register_callbacks import (
            _hygiene_prompt,
        )

        result = _hygiene_prompt()
        assert isinstance(result, str)
        assert "Batch tool calls" in result
        assert "Context Management Guidelines" in result

    def test_registration_graceful_on_error(self):
        """Registration swallows exceptions — never crashes."""
        import importlib

        import code_muse.plugins.context_hygiene.register_callbacks as mod

        # Re-importing the module should not raise even if callback
        # system is unavailable (try/except in module body).
        importlib.reload(mod)  # should not raise
