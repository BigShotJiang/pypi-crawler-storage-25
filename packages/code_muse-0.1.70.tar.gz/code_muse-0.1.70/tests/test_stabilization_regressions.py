from unittest.mock import MagicMock, patch

import pytest
from pydantic_ai.messages import ModelRequest, UserPromptPart

from code_muse.agents.base_agent import BaseAgent
from code_muse.agents.compaction.compact import compact


class TestStabilizationRegressions:
    """Regression tests for agent stabilization and compaction."""

    def test_compact_return_signature(self):
        """Test that compact returns (history, dropped, tokens)."""
        messages = [ModelRequest(parts=[UserPromptPart(content="test")])]
        # Mock agent to return a context window
        agent = MagicMock()
        agent.get_model_name.return_value = "gpt-4"

        # We need to mock get_compaction_threshold and get_max_messages_hard_cap
        with (
            patch(
                "code_muse.agents.compaction.compact.get_compaction_threshold",
                return_value=2.0,
            ),
            patch(
                "code_muse.agents.compaction.compact.get_max_messages_hard_cap",
                return_value=1000,
            ),
        ):
            # Threshold > 1.0 means no compaction should trigger
            history, dropped, tokens = compact(agent, messages, 1000, 10)

            assert isinstance(history, list)
            assert isinstance(dropped, list)
            assert isinstance(tokens, int)
            assert len(history) == 1
            assert len(dropped) == 0
            assert tokens > 0

    @pytest.mark.asyncio
    async def test_nested_timeout_handling(self):
        """Test that base_agent.py correctly extracts nested TimeoutError from ExceptionGroup."""

        class MockAgent(BaseAgent):
            @property
            def name(self):
                return "mock"

            @property
            def display_name(self):
                return "Mock"

            @property
            def description(self):
                return "Mock agent"

            def get_system_prompt(self):
                return "system"

            def get_available_tools(self):
                return []

        agent = MockAgent()

        # Create a nested ExceptionGroup containing a TimeoutError
        # In Python 3.11+, we use ExceptionGroup
        inner_eg = ExceptionGroup("inner", [TimeoutError("timed out")])
        outer_eg = ExceptionGroup("outer", [inner_eg, ValueError("other error")])

        # Wrap it in BaseExceptionGroup as that's what base_agent.py catches first
        outer_beg = BaseExceptionGroup("outer_beg", [outer_eg])

        with (
            patch("code_muse.agents.base_agent.run", side_effect=outer_beg),
            patch(
                "code_muse.agents.base_agent.get_overall_run_timeout_seconds",
                return_value=60,
            ),
        ):
            with pytest.raises(TimeoutError) as excinfo:
                await agent.run("test")

            assert "Agent run timed out after 60s" in str(excinfo.value)
            # Ensure it didn't just swallow it
            assert isinstance(excinfo.value.__cause__, ExceptionGroup)
