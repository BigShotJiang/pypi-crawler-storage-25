"""Security helpers for Muse."""
