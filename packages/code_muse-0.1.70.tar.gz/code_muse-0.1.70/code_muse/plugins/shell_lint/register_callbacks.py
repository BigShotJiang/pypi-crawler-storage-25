import re

from code_muse.callbacks import register_callback
from code_muse.messaging import emit_warning


def _lint_shell_command(context, command, cwd=None, timeout=60):
    """Lint shell commands for common mistakes."""

    # e.g., find . -name *.py
    if re.search(r'\bfind\b.*\s-name\s+([^"\'\s]*[*?][^"\'\s]*)', command):
        msg = (
            f"MALFORMED COMMAND DETECTED: '{command}'.\n"
            "Unquoted wildcard detected in 'find -name'. This will be expanded by the shell "
            "before find see it. Please wrap the pattern in quotes (e.g., -name '*.py')."
        )
        emit_warning(msg)
        return {"blocked": True, "reason": msg}

    # 2. Check for unquoted grep patterns
    if re.search(r'\bgrep\b\s+-[^r]*\s+([^"\'\s]*[*?][^"\'\s]*)', command):
        msg = (
            f"MALFORMED COMMAND DETECTED: '{command}'.\n"
            "Unquoted wildcard detected in grep. This may lead to unexpected shell expansion. "
            "Please wrap your search pattern in quotes."
        )
        emit_warning(msg)
        return {"blocked": True, "reason": msg}

    # 3. Malformed python -c strings (basic check for mismatched quotes)
    if (
        "python" in command
        and "-c" in command
        and command.count("'") % 2 != 0
        and command.count('"') % 2 != 0
    ):
        msg = (
            f"MALFORMED COMMAND DETECTED: '{command}'.\n"
            "Mismatched quotes detected in 'python -c' command."
        )
        emit_warning(msg)
        return {"blocked": True, "reason": msg}

    return None


register_callback("run_shell_command", _lint_shell_command)
