"""Context Budget Dashboard plugin — /context command."""
