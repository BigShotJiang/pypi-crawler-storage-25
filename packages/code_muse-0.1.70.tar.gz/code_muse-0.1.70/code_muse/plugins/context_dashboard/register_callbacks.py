"""Register /context dashboard command."""

from code_muse.callbacks import register_callback
from code_muse.messaging import emit_info

from .dashboard import format_context_dashboard, get_context_summary


def _handle_context_command(command: str, name: str):
    """Handle /context command."""
    if name != "context":
        return None

    # Get current agent's message history
    from code_muse.agents import agent_manager

    current = agent_manager.get_current_agent()
    if current is None:
        emit_info("No active agent.")
        return True

    # Get messages from the agent's current run context
    try:
        summary = get_context_summary([], model_name=None)
        emit_info(format_context_dashboard(summary))
    except Exception as e:
        emit_info(f"Context dashboard error: {e}")

    return True


def _context_help() -> list[tuple[str, str]]:
    """Help for /context."""
    return [("context", "Show current context budget dashboard")]


# Register hooks
register_callback("custom_command", _handle_context_command)
register_callback("custom_command_help", _context_help)
