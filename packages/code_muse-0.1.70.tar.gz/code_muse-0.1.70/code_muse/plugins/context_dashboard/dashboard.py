"""Context Budget Dashboard — shows current session token spend vs model limit."""

import logging
from typing import Any

from code_muse.agents._history import estimate_tokens_for_message
from code_muse.config import get_protected_token_count
from code_muse.plugins.semantic_compression.compression_result import (
    get_compression_telemetry,
)

logger = logging.getLogger(__name__)


def get_context_summary(
    messages: list, model_name: str | None = None
) -> dict[str, Any]:
    """Compute current context budget summary.

    Returns dict with:
    - total_tokens: estimated tokens in current message history
    - protected_tokens: reserved for system prompt + tools
    - available_tokens: model limit - total - protected
    - model_name: the model being used
    - compression_savings: from compression telemetry
    - compaction_events: count of recent compactions (if tracked)
    """
    from code_muse.config import get_global_model_name

    if model_name is None:
        model_name = get_global_model_name()

    # Estimate total tokens in history
    total_tokens = sum(estimate_tokens_for_message(m, model_name) for m in messages)

    # Get protected token count (system prompt, tools, overhead)
    protected_tokens = get_protected_token_count()

    # Get compression savings
    compression_telemetry = get_compression_telemetry()
    compression_savings = compression_telemetry.total_savings_chars

    return {
        "total_tokens": total_tokens,
        "protected_tokens": protected_tokens,
        # Default context
        "available_tokens": max(0, 128000 - total_tokens - protected_tokens),
        "model_name": model_name,
        "compression_savings_chars": compression_savings,
        "compression_count": compression_telemetry.total_results,
        "message_count": len(messages),
    }


def format_context_dashboard(summary: dict[str, Any]) -> str:
    """Format context summary as human-readable dashboard."""
    total = summary["total_tokens"]
    protected = summary["protected_tokens"]
    available = summary["available_tokens"]
    model = summary["model_name"]
    comp_count = summary["compression_count"]
    comp_savings = summary["compression_savings_chars"]
    msg_count = summary["message_count"]

    # Budget bar
    used_pct = min(100, (total / max(1, total + available)) * 100)
    bar_len = 30
    filled = int(bar_len * used_pct / 100)
    bar = "█" * filled + "░" * (bar_len - filled)

    lines = [
        f"📊 Context Budget — {model}",
        f"[{bar}] {used_pct:.0f}%",
        "",
        f"Messages:     {msg_count}",
        f"Used:         {total:,} tokens",
        f"Protected:    {protected:,} tokens",
        f"Available:    {available:,} tokens",
        "",
        f"Compressions: {comp_count} ({comp_savings:,} chars saved)",
    ]
    return "\n".join(lines)
