"""Context hygiene plugin — encourages batched operations to avoid message count explosions.

Hooks into ``load_prompt`` to append a brief guidance note about
batching tool calls and consolidating file operations.
"""

from code_muse.callbacks import register_callback


def _on_load_prompt() -> str | None:
    # No try-except needed: returns a static string with no fallible logic.
    # Add error handling if content ever becomes dynamic.
    return (
        "## Context Hygiene\n"
        "- Batch related tool calls in a single turn when possible.\n"
        "- Consolidate multiple file reads into a single `read_file` call.\n"
        "- Avoid interleaving independent operations — group by topic.\n"
    )


register_callback("load_prompt", _on_load_prompt)
