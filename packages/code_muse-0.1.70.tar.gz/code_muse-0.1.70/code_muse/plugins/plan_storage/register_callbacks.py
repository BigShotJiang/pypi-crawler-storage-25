"""Callback registrations for the plan_storage plugin.

Provides:
    - ``/plan-show`` slash command to display the current structured plan
    - Storage/retrieval of :class:`Plan` objects via task_context when
      available, falling back to an in-memory module-level variable
"""

import logging

from code_muse.agents.agent_planning import Plan, PlanStep
from code_muse.callbacks import register_callback
from code_muse.messaging import emit_info, emit_warning

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# In-memory fallback store (used when task_context is unavailable)
# ---------------------------------------------------------------------------

_current_plan: Plan | None = None


# ---------------------------------------------------------------------------
# Public API: store / retrieve Plan objects
# ---------------------------------------------------------------------------


def store_plan(plan: Plan) -> None:
    """Persist a Plan object.

    Tries to stash it on the active task in task_context's TaskManager;
    falls back to the module-level ``_current_plan`` variable.
    """
    global _current_plan
    _current_plan = plan

    # Attempt task_context integration
    try:
        from code_muse.plugins.task_context.register_callbacks import (
            _get_task_manager,
        )

        manager = _get_task_manager()
        task = manager.get_active_task()
        if task is not None:
            # Store as JSON-serializable dict on the task's outcome_summary
            # (the TaskContext model has extra="forbid", so we use a side-channel)
            task.outcome_summary = _plan_summary(plan)
            logger.debug("Plan stored on active task %s", task.task_id[:8])
            return
    except Exception:
        logger.debug("task_context unavailable, using in-memory plan storage")

    logger.debug("Plan stored in memory (task_context not available)")


def get_current_plan() -> Plan | None:
    """Retrieve the current Plan object.

    Checks task_context first, then falls back to the module-level variable.
    """
    # Try task_context first
    try:
        from code_muse.plugins.task_context.register_callbacks import (
            _get_task_manager,
        )

        manager = _get_task_manager()
        task = manager.get_active_task()
        if (
            task is not None
            and task.outcome_summary
            and task.outcome_summary.startswith("[plan]")
        ):
            return _current_plan
    except Exception:
        pass

    return _current_plan


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _plan_summary(plan: Plan) -> str:
    """Create a short marker string identifying a stored plan."""
    step_count = len(plan.steps)
    done_count = sum(1 for s in plan.steps if s.status == "done")
    return f"[plan] {plan.title} — {done_count}/{step_count} steps done"


def _render_plan(plan: Plan) -> str:
    """Render a Plan object as a human-readable markdown string."""
    lines: list[str] = []
    lines.append(f"## Plan: {plan.title}")
    lines.append("")
    lines.append(f"**Objective:** {plan.objective}")
    lines.append("")

    if plan.context_files:
        lines.append(f"**Context files:** {', '.join(plan.context_files)}")
        lines.append("")

    for step in plan.steps:
        status_icon = {
            "pending": "⬜",
            "in_progress": "🔶",
            "done": "✅",
            "blocked": "🚫",
        }.get(step.status, "⬜")
        lines.append(f"### Step {step.step_number} {status_icon}")
        lines.append(f"- **Description:** {step.description}")
        lines.append(f"- **Verification:** {step.verification}")
        if step.files:
            lines.append(f"- **Files:** {', '.join(step.files)}")
        if step.agent:
            lines.append(f"- **Agent:** {step.agent}")
        lines.append("")

    if plan.risks:
        lines.append("**Risks:**")
        for risk in plan.risks:
            lines.append(f"- {risk}")
        lines.append("")

    summary = _plan_summary(plan)
    lines.append(f"**Status:** {summary}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Slash-command: /plan-show
# ---------------------------------------------------------------------------


def _on_custom_command(command: str, name: str) -> bool | None:
    """Handle ``/plan-show`` — display the current structured plan."""
    if name != "plan-show":
        return None

    plan = get_current_plan()
    if plan is None:
        emit_warning("No plan stored yet. Create one with the Planning Agent first.")
        return True

    emit_info(_render_plan(plan))
    return True


def _on_custom_command_help() -> list[tuple[str, str]]:
    """Provide help entry for /plan-show."""
    return [
        ("plan-show", "Display the current structured plan"),
    ]


# ---------------------------------------------------------------------------
# Hook into agent_run_end to capture plans from planning-agent output
# ---------------------------------------------------------------------------


def _on_agent_run_end(
    agent_name: str,
    model_name: str,
    session_id: str | None = None,
    success: bool = True,
    error: str | None = None,
    response_text: str | None = None,
    metadata: dict | None = None,
) -> None:
    """After a planning-agent run, attempt to parse its output into a Plan."""
    if agent_name != "planning-agent":
        return
    if not success or not response_text:
        return

    plan = _parse_plan_from_text(response_text)
    if plan is not None:
        store_plan(plan)
        logger.info("Captured plan '%s' from planning-agent output", plan.title)


def _parse_plan_from_text(text: str) -> Plan | None:
    """Best-effort parse of planning-agent markdown output into a Plan.

    This is a lightweight heuristic parser — it looks for the structured
    headers the planning-agent is instructed to emit.
    """
    lines = text.split("\n")

    title = ""
    objective = ""
    context_files: list[str] = []
    steps: list[PlanStep] = []
    risks: list[str] = []

    # Parse title from "## Plan: <title>"
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("## Plan:"):
            title = stripped[len("## Plan:") :].strip()
            break

    if not title:
        # Fallback: use first line or a generic title
        title = "Untitled Plan"

    # Parse objective
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("**Objective:**"):
            objective = stripped.split("**Objective:**", 1)[1].strip()
            break

    # Parse context files
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("**Context files:**"):
            files_str = stripped.split("**Context files:**", 1)[1].strip()
            if files_str.lower() != "none":
                context_files = [f.strip() for f in files_str.split(",") if f.strip()]
            break

    # Parse steps (look for "### Step N" blocks)
    i = 0
    step_num = 0
    while i < len(lines):
        stripped = lines[i].strip()
        if stripped.startswith("### Step"):
            step_num += 1
            desc = ""
            verification = ""
            files: list[str] = []
            agent = ""
            # Scan lines until next ### or end
            j = i + 1
            while j < len(lines):
                s = lines[j].strip()
                if s.startswith("### Step") or s.startswith("## "):
                    break
                if s.startswith("- **Description:**"):
                    desc = s.split("**Description:**", 1)[1].strip()
                elif s.startswith("- **Verification:**"):
                    verification = s.split("**Verification:**", 1)[1].strip()
                elif s.startswith("- **Files:**"):
                    files_str = s.split("**Files:**", 1)[1].strip()
                    if files_str.lower() != "none":
                        files = [f.strip() for f in files_str.split(",") if f.strip()]
                elif s.startswith("- **Agent:**"):
                    agent = s.split("**Agent:**", 1)[1].strip()
                j += 1
            steps.append(
                PlanStep(
                    step_number=step_num,
                    description=desc,
                    verification=verification,
                    status="pending",
                    files=files,
                    agent=agent,
                )
            )
            i = j
            continue
        i += 1

    # Parse risks
    in_risks = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("**Risks:**"):
            in_risks = True
            continue
        if in_risks:
            if stripped.startswith("- "):
                risks.append(stripped[2:].strip())
            elif stripped.startswith("**") or stripped.startswith("##"):
                in_risks = False

    if not steps:
        # Couldn't parse any steps — don't create a Plan
        return None

    return Plan(
        title=title,
        objective=objective,
        steps=steps,
        risks=risks,
        context_files=context_files,
    )


# ---------------------------------------------------------------------------
# Register all callbacks
# ---------------------------------------------------------------------------

register_callback("custom_command", _on_custom_command)
register_callback("custom_command_help", _on_custom_command_help)
register_callback("agent_run_end", _on_agent_run_end)

logger.debug("Plan Storage plugin callbacks registered")
