"""Unified compression result model and telemetry helpers.

Every compressor (semantic, smart_output, build_filter, shell_minimizer, etc.)
emits a CompressionResult so stats can be aggregated and the token ledger
can track savings per strategy.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class CompressionStrategy(Enum):
    """Compression strategy identifiers."""

    SEMANTIC = "semantic"
    SMART_OUTPUT = "smart_output"
    BUILD_FILTER = "build_filter"
    SHELL_MINIMIZER = "shell_minimizer"
    GIT_COMPRESS = "git_compress"
    TEST_COMPRESS = "test_compress"
    LINT_COMPRESS = "lint_compress"
    CODE_COMPRESS = "code_compress"
    READ_COMPRESS = "read_compress"
    TREE_SITTER = "tree_sitter"
    JSON_COMPRESS = "json_compress"


@dataclass(frozen=True)
class CompressionResult:
    """Unified output from any compression pass.

    Attributes:
        original_len: Character count before compression.
        compressed_len: Character count after compression (0 = no change).
        strategy: Which compression strategy was applied.
        confidence: 0.0-1.0 estimate of information preservation.
        reversible: Whether the original can be recovered (via /show original).
        metadata: Strategy-specific details (e.g., which rules fired).
    """

    original_len: int
    compressed_len: int
    strategy: CompressionStrategy
    confidence: float = 1.0
    reversible: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def savings_ratio(self) -> float:
        """Fraction of characters saved (0.0 = no savings, 1.0 = fully compressed)."""
        if self.original_len == 0:
            return 0.0
        return 1.0 - (self.compressed_len / self.original_len)

    @property
    def savings_chars(self) -> int:
        """Characters saved by compression."""
        return self.original_len - self.compressed_len

    @property
    def was_compressed(self) -> bool:
        """Whether compression actually reduced the output."""
        return self.compressed_len < self.original_len


@dataclass
class CompressionTelemetry:
    """Session-level compression statistics aggregator."""

    _results: list[CompressionResult] = field(default_factory=list)

    def record(self, result: CompressionResult) -> None:
        """Record a compression result."""
        if result.was_compressed:
            self._results.append(result)

    @property
    def total_results(self) -> int:
        return len(self._results)

    @property
    def total_original_chars(self) -> int:
        return sum(r.original_len for r in self._results)

    @property
    def total_compressed_chars(self) -> int:
        return sum(r.compressed_len for r in self._results)

    @property
    def total_savings_chars(self) -> int:
        return self.total_original_chars - self.total_compressed_chars

    @property
    def average_savings_ratio(self) -> float:
        if not self._results:
            return 0.0
        return sum(r.savings_ratio for r in self._results) / len(self._results)

    @property
    def by_strategy(self) -> dict[CompressionStrategy, int]:
        """Count of compressions per strategy."""
        counts: dict[CompressionStrategy, int] = {}
        for r in self._results:
            counts[r.strategy] = counts.get(r.strategy, 0) + 1
        return counts

    def summary(self) -> str:
        """Human-readable summary for /compression-stats."""
        if not self._results:
            return "No compressions recorded this session."
        lines = [
            f"Compressions: {self.total_results}",
            f"Original: {self.total_original_chars:,} chars",
            f"Compressed: {self.total_compressed_chars:,} chars",
            (
                f"Savings: {self.total_savings_chars:,} chars "
                f"({self.average_savings_ratio:.1%})"
            ),
            "",
            "By strategy:",
        ]
        for strategy, count in sorted(self.by_strategy.items(), key=lambda x: -x[1]):
            lines.append(f"  {strategy.value}: {count}")
        return "\n".join(lines)


# Module-level singleton for session telemetry
_session_telemetry = CompressionTelemetry()


def get_compression_telemetry() -> CompressionTelemetry:
    """Get the session-level compression telemetry singleton."""
    return _session_telemetry


def reset_compression_telemetry() -> None:
    """Reset session telemetry (for testing)."""
    global _session_telemetry
    _session_telemetry = CompressionTelemetry()
