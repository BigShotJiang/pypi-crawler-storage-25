"""Critic learning — closed-loop feedback from user edits after reviews.

Hooks into post_tool_call for file write operations. When a file is
edited shortly after a critic review, compares the edit against the
review suggestions and records acceptance/ignorance signals.
"""

import logging
import time
from typing import Any

from code_muse.callbacks import register_callback
from code_muse.messaging import emit_info

from .learning_store import get_all_rule_stats, get_demotable_rules, record_signal

logger = logging.getLogger(__name__)

# Track recent critic reviews: {(file_path, timestamp, [suggestions])}
_recent_reviews: dict[str, tuple[float, list[str]]] = {}

# How long after a review to watch for user edits (seconds)
_WATCH_WINDOW = 300  # 5 minutes


def _on_post_tool_call(
    tool_name: str,
    tool_args: Any,
    result: Any,
    duration_ms: float,
    context: Any = None,
) -> Any:
    """Watch for file edits after critic reviews."""
    if tool_name not in ("edit_file", "replace_in_file", "create_file"):
        return None

    file_path = ""
    if isinstance(tool_args, dict):
        file_path = tool_args.get("path", tool_args.get("file_path", ""))

    if not file_path:
        return None

    # Check if we have a recent review for this file
    now = time.time()
    if file_path in _recent_reviews:
        review_time, suggestions = _recent_reviews[file_path]
        if now - review_time < _WATCH_WINDOW:
            # User edited after review — record signal
            # For now, record as "modified"
            # (we can't easily diff against specific suggestions)
            for rule in suggestions:
                record_signal(rule, "modified", file_path)
            logger.debug(
                "Recorded critic learning signals for %s (%d rules)",
                file_path,
                len(suggestions),
            )
            del _recent_reviews[file_path]

    return None


def _handle_critic_learning_command(command: str, name: str) -> Any:
    """Handle /critic-learning command."""
    parts = name.strip().split()
    if parts and parts[0] == "critic-learning":
        demotable = get_demotable_rules()
        all_stats = get_all_rule_stats()

        if not all_stats:
            emit_info(
                "No critic learning data yet. "
                "Use the system and review code — signals accumulate automatically."
            )
            return True

        lines = ["📊 Critic Learning Report", ""]
        for rule, stats in sorted(all_stats.items()):
            total = sum(stats.values())
            rate = stats["accepted"] / total if total > 0 else 0
            flag = " ⚠️ DEMOTE" if rule in demotable else ""
            lines.append(
                f"  {rule}: {stats['accepted']}/{total} accepted ({rate:.0%}){flag}"
            )

        if demotable:
            lines.append("")
            lines.append(f"Rules to deprioritize: {', '.join(demotable)}")

        emit_info("\n".join(lines))
        return True

    return None


def _critic_learning_help() -> list[tuple[str, str]]:
    return [
        (
            "critic-learning",
            "Show critic learning report — which review rules users accept/ignore",
        )
    ]


# Register hooks
register_callback("post_tool_call", _on_post_tool_call)
register_callback("custom_command", _handle_critic_learning_command)
register_callback("custom_command_help", _critic_learning_help)
