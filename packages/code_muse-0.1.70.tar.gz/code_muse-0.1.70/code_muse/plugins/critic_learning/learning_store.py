"""Critic learning signal store — records review suggestion outcomes.

Stores per-rule signals in a JSONL file under
~/.local/state/code_muse/critic_learning.jsonl.
Each entry: {"rule": str, "action": "accepted"|"ignored"|"modified",
            "timestamp": float, "file_path": str}
"""

import json
import logging
import os
import time
from pathlib import Path

logger = logging.getLogger(__name__)

_xdg = os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state")
_STORE_DIR = Path(_xdg) / "code_muse"
_STORE_FILE = _STORE_DIR / "critic_learning.jsonl"


def _ensure_store_dir() -> None:
    _STORE_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(_STORE_DIR, 0o700)


def record_signal(rule: str, action: str, file_path: str = "") -> None:
    """Record a learning signal."""
    _ensure_store_dir()
    entry = {
        "rule": rule,
        "action": action,
        "timestamp": time.time(),
        "file_path": file_path,
    }
    with open(_STORE_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")


def get_rule_stats(rule: str) -> dict[str, int]:
    """Get acceptance stats for a rule."""
    if not _STORE_FILE.exists():
        return {"accepted": 0, "ignored": 0, "modified": 0}

    stats = {"accepted": 0, "ignored": 0, "modified": 0}
    with open(_STORE_FILE, encoding="utf-8") as f:
        for line in f:
            try:
                entry = json.loads(line.strip())
                if entry.get("rule") == rule:
                    action = entry.get("action", "")
                    if action in stats:
                        stats[action] += 1
            except json.JSONDecodeError, KeyError:
                continue
    return stats


def get_all_rule_stats() -> dict[str, dict[str, int]]:
    """Get stats for all rules."""
    if not _STORE_FILE.exists():
        return {}

    all_stats: dict[str, dict[str, int]] = {}
    with open(_STORE_FILE, encoding="utf-8") as f:
        for line in f:
            try:
                entry = json.loads(line.strip())
                rule = entry.get("rule", "")
                action = entry.get("action", "")
                if rule not in all_stats:
                    all_stats[rule] = {"accepted": 0, "ignored": 0, "modified": 0}
                if action in all_stats[rule]:
                    all_stats[rule][action] += 1
            except json.JSONDecodeError, KeyError:
                continue
    return all_stats


def get_demotable_rules(threshold: float = 0.3, min_observations: int = 5) -> list[str]:
    """Get rules where acceptance rate is below threshold.

    These rules should be deprioritized in future reviews.
    """
    all_stats = get_all_rule_stats()
    demotable = []
    for rule, stats in all_stats.items():
        total = sum(stats.values())
        if total < min_observations:
            continue
        acceptance_rate = stats["accepted"] / total
        if acceptance_rate < threshold:
            demotable.append(rule)
    return demotable
