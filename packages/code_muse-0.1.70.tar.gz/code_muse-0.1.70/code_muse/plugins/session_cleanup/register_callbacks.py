from code_muse.callbacks import register_callback
from code_muse.tools.background_jobs import stop_all_background_jobs_in_group


async def _cleanup_session_background_jobs(group_id: str):
    """Terminate all background jobs associated with a cancelled agent session."""
    if group_id:
        count = stop_all_background_jobs_in_group(group_id)
        if count > 0:
            from code_muse.messaging import emit_info

            emit_info(
                f"🛑 Terminated {count} background job(s) for cancelled session {group_id}"
            )


register_callback("agent_run_cancel", _cleanup_session_background_jobs)
