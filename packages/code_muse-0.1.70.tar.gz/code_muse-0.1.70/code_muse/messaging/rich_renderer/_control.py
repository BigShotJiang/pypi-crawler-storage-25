"""Control / auxiliary message rendering mixin.

Covers spinner, divider, status panel, version check, and skills.
"""

from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table

from ..messages import (
    DividerMessage,
    SkillActivateMessage,
    SkillListMessage,
    SpinnerControl,
    StatusPanelMessage,
    VersionCheckMessage,
)


class ControlRenderMixin:
    """Renders control messages: spinner, divider, status panel, version
    check, skill list, and skill activation."""

    def _render_spinner_control(self, msg: SpinnerControl) -> None:
        """Handle spinner control messages."""
        if msg.action == "start" and msg.text or msg.action == "update" and msg.text:
            with self._lock:
                self._spinners[msg.spinner_id] = msg.text
            self._console.print(f"[dim]⠋ {msg.text}[/dim]")
        elif msg.action == "stop":
            with self._lock:
                self._spinners.pop(msg.spinner_id, None)

    def _render_divider(self, msg: DividerMessage) -> None:
        """Render a horizontal divider."""
        chars = {"light": "─", "heavy": "━", "double": "═"}
        char = chars.get(msg.style, "─")
        rule = Rule(style="dim", characters=char)
        self._console.print(rule)

    def _render_status_panel(self, msg: StatusPanelMessage) -> None:
        """Render a status panel with key-value fields."""
        table = Table(show_header=False, box=None, padding=(0, 1))
        table.add_column("Key", style="bold cyan")
        table.add_column("Value")

        for key, value in msg.fields.items():
            table.add_row(key, value)

        panel = Panel(table, title=f"[bold]{msg.title}[/bold]", border_style="blue")
        self._console.print(panel)

    def _render_version_check(self, msg: VersionCheckMessage) -> None:
        """Render version check information."""
        if msg.update_available:
            cur = msg.current_version
            latest = msg.latest_version
            self._console.print(f"[dim]⬆ Update available: {cur} → {latest}[/dim]")
        else:
            self._console.print(
                f"[dim]✓ You're on the latest version ({msg.current_version})[/dim]"
            )

    # ------------------------------------------------------------------
    # Skills
    # ------------------------------------------------------------------

    def _render_skill_list(self, msg: SkillListMessage) -> None:
        """Render a list of available skills."""
        if self._should_suppress_subagent_output():
            return

        banner = self._format_banner("agent_response", "LIST SKILLS")
        query_info = f" matching [cyan]'{msg.query}'[/cyan]" if msg.query else ""
        self._console.print(
            f"\n{banner} 🛠️ Found [bold]{msg.total_count}[/bold] skill(s){query_info}\n"
        )

        if not msg.skills:
            self._console.print("[dim]  No skills found.[/dim]")
            self._console.print("[dim]  Install skills in ~/.muse/skills/[/dim]\n")
            return

        table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
        table.add_column("Status", style="dim", width=8)
        table.add_column("Name", style="cyan")
        table.add_column("Description", style="dim")
        table.add_column("Tags", style="yellow dim")

        for skill in msg.skills:
            status = "[green]✓[/green]" if skill.enabled else "[red]✗[/red]"
            tags = ", ".join(skill.tags[:3]) if skill.tags else "-"
            desc = skill.description
            if len(desc) > 50:
                desc = desc[:47] + "..."
            table.add_row(status, skill.name, desc, tags)

        self._console.print(table)
        self._console.print()

    def _render_skill_activate(self, msg: SkillActivateMessage) -> None:
        """Render skill activation result."""
        if self._should_suppress_subagent_output():
            return

        banner = self._format_banner("agent_response", "ACTIVATE SKILL")
        status = "[green]✓[/green]" if msg.success else "[red]✗[/red]"
        self._console.print(
            f"\n{banner} {status} [bold cyan]{msg.skill_name}[/bold cyan]\n"
        )

        if msg.success:
            self._console.print(f"  [dim]Path:[/dim] {msg.skill_path}")

            if msg.resource_count > 0:
                self._console.print(
                    f"  [dim]Resources:[/dim] {msg.resource_count} bundled file(s)"
                )

            if msg.content_preview:
                preview = msg.content_preview.replace("\n", " ")[:100]
                if len(msg.content_preview) > 100:
                    preview += "..."
                self._console.print(f"  [dim]Preview:[/dim] {preview}")
        else:
            self._console.print("  [red]Activation failed[/red]")

        self._console.print()
