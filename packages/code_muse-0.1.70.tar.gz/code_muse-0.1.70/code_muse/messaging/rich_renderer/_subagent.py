"""Agent and sub-agent rendering mixin."""

from rich.markdown import Markdown
from rich.markup import escape as escape_rich_markup

from ..messages import (
    AgentReasoningMessage,
    AgentResponseMessage,
    SubAgentInvocationMessage,
    SubAgentResponseMessage,
    UniversalConstructorMessage,
)


class SubAgentRenderMixin:
    """Renders agent reasoning, responses, sub-agent invocations, and
    universal-constructor messages."""

    def _render_agent_reasoning(self, msg: AgentReasoningMessage) -> None:
        """Render agent reasoning matching old format."""
        banner = self._format_banner("agent_reasoning", "AGENT REASONING")
        self._console.print(f"\n{banner}")

        self._console.print("[bold cyan]Current reasoning:[/bold cyan]")
        md = Markdown(msg.reasoning)
        self._console.print(md)

        if msg.next_steps and msg.next_steps.strip():
            self._console.print("\n[bold cyan]Planned next steps:[/bold cyan]")
            md_steps = Markdown(msg.next_steps)
            self._console.print(md_steps)

        self._console.print()

    def _render_agent_response(self, msg: AgentResponseMessage) -> None:
        """Render agent response with header and markdown formatting."""
        banner = self._format_banner("agent_response", "AGENT RESPONSE")
        self._console.print(f"\n{banner}\n")

        if msg.is_markdown:
            md = Markdown(msg.content)
            self._console.print(md)
        else:
            self._console.print(msg.content)

    def _render_subagent_invocation(self, msg: SubAgentInvocationMessage) -> None:
        """Render sub-agent invocation header with nice formatting."""
        if self._should_suppress_subagent_output():
            return

        session_type = (
            "New session"
            if msg.is_new_session
            else f"Continuing ({msg.message_count} messages)"
        )
        banner = self._format_banner("invoke_agent", "🤖 INVOKE AGENT")
        self._console.print(
            f"\n{banner} "
            f"[bold cyan]{msg.agent_name}[/bold cyan] "
            f"[dim]({session_type})[/dim]"
        )

        self._console.print(f"[dim]Session:[/dim] [bold]{msg.session_id}[/bold]")

        prompt_display = (
            msg.prompt[:200] + "..." if len(msg.prompt) > 200 else msg.prompt
        )
        self._console.print("[dim]Prompt:[/dim]")
        md_prompt = Markdown(prompt_display)
        self._console.print(md_prompt)

    def _render_subagent_response(self, msg: SubAgentResponseMessage) -> None:
        """Render sub-agent response with markdown formatting."""
        banner = self._format_banner("subagent_response", "✓ AGENT RESPONSE")
        self._console.print(f"\n{banner} [bold cyan]{msg.agent_name}[/bold cyan]")

        md = Markdown(msg.response)
        self._console.print(md)

        self._console.print(
            f"\n[dim]Session [bold]{msg.session_id}[/bold] saved "
            f"({msg.message_count} messages)[/dim]"
        )

    def _render_universal_constructor(self, msg: UniversalConstructorMessage) -> None:
        """Render universal_constructor tool output with banner."""
        if self._should_suppress_subagent_output():
            return

        banner = self._format_banner("universal_constructor", "UNIVERSAL CONSTRUCTOR")

        header_parts = [f"\n{banner} 🔧 [bold cyan]{msg.action.upper()}[/bold cyan]"]
        if msg.tool_name:
            safe_tool_name = escape_rich_markup(msg.tool_name)
            header_parts.append(f" [dim]tool=[/dim][bold]{safe_tool_name}[/bold]")
        self._console.print("".join(header_parts))

        safe_summary = escape_rich_markup(msg.summary) if msg.summary else ""
        if msg.success:
            self._console.print(f"[green]✓[/green] {safe_summary}")
        else:
            self._console.print(f"[red]✗[/red] {safe_summary}")

        if msg.details:
            safe_details = escape_rich_markup(msg.details)
            self._console.print(f"[dim]{safe_details}[/dim]")

        self._console.print()
