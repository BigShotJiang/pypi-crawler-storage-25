"""Diff rendering mixin."""

from code_muse.tools.common import format_diff_with_colors

from ..messages import DiffMessage


class DiffRenderMixin:
    """Renders diff messages with syntax highlighting."""

    def _render_diff(self, msg: DiffMessage) -> None:
        """Render a diff with beautiful syntax highlighting."""
        if self._should_suppress_subagent_output():
            return

        op_icons = {"create": "✨", "modify": "✏️", "delete": "🗑️"}
        op_colors = {"create": "green", "modify": "yellow", "delete": "red"}
        icon = op_icons.get(msg.operation, "📄")
        op_color = op_colors.get(msg.operation, "white")

        if msg.operation == "create":
            banner = self._format_banner("create_file", "CREATE FILE")
        elif msg.operation == "delete":
            banner = self._format_banner("delete_file", "DELETE FILE")
        else:
            banner = self._format_banner("replace_in_file", "EDIT FILE")
        self._console.print(
            f"\n{banner} "
            f"{icon} [{op_color}]{msg.operation.upper()}[/{op_color}] "
            f"[bold cyan]{msg.path}[/bold cyan]"
        )

        if not msg.diff_lines:
            return

        diff_text_lines = []
        for line in msg.diff_lines:
            if line.type == "add":
                diff_text_lines.append(f"+{line.content}")
            elif line.type == "remove":
                diff_text_lines.append(f"-{line.content}")
            else:  # context
                if line.content.startswith(("---", "+++", "@@", "diff ", "index ")):
                    diff_text_lines.append(line.content)
                else:
                    diff_text_lines.append(f" {line.content}")

        diff_text = "\n".join(diff_text_lines)
        formatted_diff = format_diff_with_colors(diff_text)
        self._console.print(formatted_diff)
