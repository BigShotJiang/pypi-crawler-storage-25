"""User interaction rendering mixin (input, confirmation, selection)."""

import asyncio

from rich.markup import escape as escape_rich_markup

from ..commands import ConfirmationResponse, SelectionResponse, UserInputResponse
from ..messages import ConfirmationRequest, SelectionRequest, UserInputRequest


class UserInputRenderMixin:
    """Renders interactive prompts (input, confirmation, selection).

    These methods are *async* because they block on user input via
    ``loop.run_in_executor``.
    """

    async def _render_user_input_request(self, msg: UserInputRequest) -> None:
        """Render input prompt and send response back to bus."""
        prompt = msg.prompt_text
        if msg.default_value:
            prompt += f" [{msg.default_value}]"
        prompt += ": "

        loop = asyncio.get_running_loop()
        if msg.input_type == "password":
            value = await loop.run_in_executor(
                None, lambda: self._console.input(prompt, password=True)
            )
        else:
            value = await loop.run_in_executor(
                None, lambda: self._console.input(f"[cyan]{prompt}[/cyan]")
            )

        if not value and msg.default_value:
            value = msg.default_value

        response = UserInputResponse(prompt_id=msg.prompt_id, value=value)
        self._bus.provide_response(response)

    async def _render_confirmation_request(self, msg: ConfirmationRequest) -> None:
        """Render confirmation dialog and send response back."""
        safe_title = escape_rich_markup(msg.title)
        safe_description = escape_rich_markup(msg.description)
        self._console.print(f"\n[bold yellow]{safe_title}[/bold yellow]")
        self._console.print(safe_description)

        options_str = "/".join(msg.options)
        prompt = f"[{options_str}]"
        loop = asyncio.get_running_loop()

        while True:
            choice = await loop.run_in_executor(
                None,
                lambda: self._console.input(f"[cyan]{prompt}[/cyan] ").strip().lower(),
            )

            for i, opt in enumerate(msg.options):
                if choice == opt.lower() or choice == opt[0].lower():
                    confirmed = i == 0  # First option is "confirm"

                    feedback = None
                    if msg.allow_feedback:
                        feedback = await loop.run_in_executor(
                            None,
                            lambda: self._console.input(
                                "[dim]Feedback (optional): [/dim]"
                            ),
                        )
                        feedback = feedback if feedback else None

                    response = ConfirmationResponse(
                        prompt_id=msg.prompt_id,
                        confirmed=confirmed,
                        feedback=feedback,
                    )
                    self._bus.provide_response(response)
                    return

            self._console.print(f"[red]Please enter one of: {options_str}[/red]")

    async def _render_selection_request(self, msg: SelectionRequest) -> None:
        """Render selection menu and send response back."""
        safe_prompt = escape_rich_markup(msg.prompt_text)
        self._console.print(f"\n[bold]{safe_prompt}[/bold]")

        for i, opt in enumerate(msg.options):
            safe_opt = escape_rich_markup(opt)
            self._console.print(f"  [cyan]{i + 1}[/cyan]. {safe_opt}")

        if msg.allow_cancel:
            self._console.print("  [dim]0. Cancel[/dim]")

        loop = asyncio.get_running_loop()

        while True:
            choice = await loop.run_in_executor(
                None, lambda: self._console.input("[cyan]Enter number: [/cyan]").strip()
            )

            try:
                idx = int(choice)
                if msg.allow_cancel and idx == 0:
                    response = SelectionResponse(
                        prompt_id=msg.prompt_id,
                        selected_index=-1,
                        selected_value="",
                    )
                    self._bus.provide_response(response)
                    return

                if 1 <= idx <= len(msg.options):
                    response = SelectionResponse(
                        prompt_id=msg.prompt_id,
                        selected_index=idx - 1,
                        selected_value=msg.options[idx - 1],
                    )
                    self._bus.provide_response(response)
                    return
            except ValueError:
                pass

            self._console.print(f"[red]Please enter 1-{len(msg.options)}[/red]")
