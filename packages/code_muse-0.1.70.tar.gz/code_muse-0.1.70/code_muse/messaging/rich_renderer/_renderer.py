"""Composed RichConsoleRenderer — inherits from focused mixins."""

from ._base import _CoreMixin
from ._control import ControlRenderMixin
from ._diff import DiffRenderMixin
from ._file import FileRenderMixin
from ._shell import ShellRenderMixin
from ._subagent import SubAgentRenderMixin
from ._text import TextRenderMixin
from ._user_input import UserInputRenderMixin


class RichConsoleRenderer(
    _CoreMixin,
    TextRenderMixin,
    FileRenderMixin,
    DiffRenderMixin,
    ShellRenderMixin,
    SubAgentRenderMixin,
    UserInputRenderMixin,
    ControlRenderMixin,
):
    """Rich console implementation of the renderer protocol.

    This renderer consumes messages from a MessageBus and renders them
    using Rich.  It uses a background thread for synchronous compatibility
    with the main loop.

    Method groups live in the mixin base-classes listed above; this class
    simply composes them into a single concrete renderer.
    """
