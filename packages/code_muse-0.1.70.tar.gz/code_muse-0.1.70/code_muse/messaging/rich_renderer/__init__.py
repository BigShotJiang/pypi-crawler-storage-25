"""Rich console renderer for structured messages.

This package implements the presentation layer for Muse's messaging system.
It consumes structured messages from the MessageBus and renders them using Rich.

The renderer is responsible for ALL presentation decisions — the messages contain
only structured data with no formatting hints.

Existing imports continue to work::

    from code_muse.messaging.rich_renderer import RichConsoleRenderer
    from code_muse.messaging.rich_renderer import (
        RendererProtocol, DEFAULT_STYLES, DIFF_STYLES
    )
"""

from ._protocol import DEFAULT_STYLES, DIFF_STYLES, RendererProtocol
from ._renderer import RichConsoleRenderer

__all__ = [
    "RendererProtocol",
    "RichConsoleRenderer",
    "DEFAULT_STYLES",
    "DIFF_STYLES",
]
