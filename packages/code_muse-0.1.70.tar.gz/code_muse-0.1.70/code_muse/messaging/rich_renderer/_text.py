"""Text message rendering mixin."""

from rich.markup import escape as escape_rich_markup

from ..messages import MessageLevel, TextMessage


class TextRenderMixin:
    """Renders plain-text messages with level-based styling."""

    def _render_text(self, msg: TextMessage) -> None:
        """Render a text message with appropriate styling.

        Text is escaped to prevent Rich markup injection which could crash
        the renderer if malformed tags are present in shell output or other
        user-provided content.
        """
        style = self._styles.get(msg.level, "white")

        # Make version messages dim
        if "Current version:" in msg.text or "Latest version:" in msg.text:
            style = "dim"

        prefix = self._get_level_prefix(msg.level)
        # Escape Rich markup to prevent crashes from malformed tags
        safe_text = escape_rich_markup(msg.text)
        self._console.print(f"{prefix}{safe_text}", style=style)

    def _get_level_prefix(self, level: MessageLevel) -> str:
        """Get a prefix icon for the message level."""
        prefixes = {
            MessageLevel.ERROR: "✗ ",
            MessageLevel.WARNING: "⚠ ",
            MessageLevel.SUCCESS: "✓ ",
            MessageLevel.INFO: "ℹ ",
            MessageLevel.DEBUG: "• ",
        }
        return prefixes.get(level, "")
