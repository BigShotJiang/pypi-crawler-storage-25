"""Core lifecycle, dispatch, and shared helpers for RichConsoleRenderer."""

import threading

from rich.console import Console
from rich.markup import escape as escape_rich_markup

from code_muse.config import get_banner_color, get_subagent_verbose
from code_muse.tools.subagent_context import is_subagent

from ..bus import MessageBus
from ..messages import (
    AgentResponseMessage,
    AnyMessage,
    ConfirmationRequest,
    SelectionRequest,
    SubAgentResponseMessage,
    UserInputRequest,
)


class _CoreMixin:
    """Core lifecycle, dispatch, and shared helpers.

    This mixin provides __init__, start/stop, consume loop, the main
    _do_render dispatcher, and utility methods used across all other mixins.
    It MUST be the first base in the MRO so its __init__ runs.
    """

    def __init__(
        self,
        bus: MessageBus,
        console: Console | None = None,
        styles: dict | None = None,
    ) -> None:
        """Initialize the renderer.

        Args:
            bus: The MessageBus to consume messages from.
            console: Rich Console instance (creates default if None).
            styles: Custom style mappings (uses DEFAULT_STYLES if None).
        """
        from ._protocol import DEFAULT_STYLES

        self._bus = bus
        self._console = console or Console()
        self._styles = styles or DEFAULT_STYLES.copy()
        self._running = False
        self._thread: threading.Thread | None = None
        self._spinners: dict[str, object] = {}  # spinner_id -> status context

        # Thread-safety: protects _running, _spinners, and other shared mutable
        # state accessed from both the background consume loop and the caller.
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def console(self) -> Console:
        """Get the Rich console."""
        return self._console

    @property
    def _is_running(self) -> bool:
        """Thread-safe read of the running flag."""
        with self._lock:
            return self._running

    # ------------------------------------------------------------------
    # Banner helpers (used by nearly every other mixin)
    # ------------------------------------------------------------------

    def _get_banner_color(self, banner_name: str) -> str:
        """Get the configured color for a banner."""
        return get_banner_color(banner_name)

    def _format_banner(self, banner_name: str, text: str) -> str:
        """Format a banner with its configured color."""
        color = self._get_banner_color(banner_name)
        # TODO: PEP 750 t-string — use templatelib when stable
        return f"[bold white on {color}] {text} [/bold white on {color}]"

    def _should_suppress_subagent_output(self) -> bool:
        """Check if sub-agent output should be suppressed."""
        return is_subagent() and not get_subagent_verbose()

    # =========================================================================
    # Lifecycle (Synchronous — for compatibility with main.py)
    # =========================================================================

    def start(self) -> None:
        """Start the renderer in a background thread."""
        with self._lock:
            if self._running:
                return
            self._running = True

        self._bus.mark_renderer_active()

        self._thread = threading.Thread(target=self._consume_loop_sync, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop the renderer."""
        with self._lock:
            self._running = False
        self._bus.mark_renderer_inactive()

        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)
        with self._lock:
            self._thread = None

    def _consume_loop_sync(self) -> None:
        """Synchronous message consumption loop running in background thread."""
        import time

        for msg in self._bus.get_buffered_messages():
            self._render_sync(msg)
        self._bus.clear_buffer()

        while self._is_running:
            message = self._bus.get_message_nowait()
            if message:
                self._render_sync(message)
            else:
                time.sleep(0.1)  # 100ms poll interval; avoids 100Hz busy-wait

    def _render_sync(self, message: AnyMessage) -> None:
        """Render a message synchronously with error handling."""
        try:
            self._do_render(message)
        except Exception as e:
            safe_error = escape_rich_markup(str(e))
            self._console.print(f"[dim red]Render error: {safe_error}[/dim red]")

    # =========================================================================
    # Async Lifecycle (for future async-first usage)
    # =========================================================================

    async def start_async(self) -> None:
        """Start the renderer asynchronously."""
        with self._lock:
            if self._running:
                return
            self._running = True
        self._bus.mark_renderer_active()

        for msg in self._bus.get_buffered_messages():
            self._render_sync(msg)
        self._bus.clear_buffer()

    async def stop_async(self) -> None:
        """Stop the renderer asynchronously."""
        with self._lock:
            self._running = False
        self._bus.mark_renderer_inactive()

    # =========================================================================
    # Main Dispatch
    # =========================================================================

    def _do_render(self, message: AnyMessage) -> None:
        """Synchronously render a message by dispatching to the appropriate handler.

        Note: User input requests are skipped in sync mode as they require async.
        """
        # ---- Text ----
        from ..messages import TextMessage

        if isinstance(message, TextMessage):
            self._render_text(message)
            return

        # ---- File ops ----
        from ..messages import FileContentMessage, FileListingMessage, GrepResultMessage

        if isinstance(message, FileListingMessage):
            self._render_file_listing(message)
            return
        if isinstance(message, FileContentMessage):
            self._render_file_content(message)
            return
        if isinstance(message, GrepResultMessage):
            self._render_grep_result(message)
            return

        # ---- Diff ----
        from ..messages import DiffMessage

        if isinstance(message, DiffMessage):
            self._render_diff(message)
            return

        # ---- Shell ----
        from ..messages import ShellLineMessage, ShellOutputMessage, ShellStartMessage

        if isinstance(message, ShellStartMessage):
            self._render_shell_start(message)
            return
        if isinstance(message, ShellLineMessage):
            self._render_shell_line(message)
            return
        if isinstance(message, ShellOutputMessage):
            self._render_shell_output(message)
            return

        # ---- Agent / Sub-agent ----
        from ..messages import (
            AgentReasoningMessage,
            SubAgentInvocationMessage,
            UniversalConstructorMessage,
        )

        if isinstance(message, AgentReasoningMessage):
            self._render_agent_reasoning(message)
            return
        if isinstance(message, AgentResponseMessage):
            # Skip rendering — streamed via event_stream_handler
            return
        if isinstance(message, SubAgentInvocationMessage):
            self._render_subagent_invocation(message)
            return
        if isinstance(message, SubAgentResponseMessage):
            # Skip — displayed via display_non_streamed_result
            return
        if isinstance(message, UniversalConstructorMessage):
            self._render_universal_constructor(message)
            return

        # ---- User interaction (sync fallback) ----
        if isinstance(message, UserInputRequest):
            self._console.print("[dim]User input requested (requires async)[/dim]")
            return
        if isinstance(message, ConfirmationRequest):
            self._console.print("[dim]Confirmation requested (requires async)[/dim]")
            return
        if isinstance(message, SelectionRequest):
            self._console.print("[dim]Selection requested (requires async)[/dim]")
            return

        # ---- Control ----
        from ..messages import (
            DividerMessage,
            SkillActivateMessage,
            SkillListMessage,
            SpinnerControl,
            StatusPanelMessage,
            VersionCheckMessage,
        )

        if isinstance(message, SpinnerControl):
            self._render_spinner_control(message)
            return
        if isinstance(message, DividerMessage):
            self._render_divider(message)
            return
        if isinstance(message, StatusPanelMessage):
            self._render_status_panel(message)
            return
        if isinstance(message, VersionCheckMessage):
            self._render_version_check(message)
            return
        if isinstance(message, SkillListMessage):
            self._render_skill_list(message)
            return
        if isinstance(message, SkillActivateMessage):
            self._render_skill_activate(message)
            return

        # Unknown message type
        self._console.print(f"[dim]Unknown message: {type(message).__name__}[/dim]")

    async def render(self, message: AnyMessage) -> None:
        """Render a message asynchronously (supports user input requests)."""
        if isinstance(message, UserInputRequest):
            await self._render_user_input_request(message)
        elif isinstance(message, ConfirmationRequest):
            await self._render_confirmation_request(message)
        elif isinstance(message, SelectionRequest):
            await self._render_selection_request(message)
        else:
            self._do_render(message)
