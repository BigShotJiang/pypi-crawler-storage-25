"""Shell output rendering mixin."""

import sys

from rich.markup import escape as escape_rich_markup
from rich.text import Text

from ..messages import ShellLineMessage, ShellOutputMessage, ShellStartMessage


class ShellRenderMixin:
    """Renders shell command start, line-by-line output, and completion."""

    def _render_shell_start(self, msg: ShellStartMessage) -> None:
        """Render shell command start notification."""
        if self._should_suppress_subagent_output():
            return

        safe_command = escape_rich_markup(msg.command)
        banner = self._format_banner("shell_command", "SHELL COMMAND")

        if msg.background:
            self._console.print(
                f"\n{banner} 🚀 [dim]$ {safe_command}[/dim]"
                "  [bold magenta][BACKGROUND 🌙][/bold magenta]"
            )
        else:
            self._console.print(f"\n{banner} 🚀 [dim]$ {safe_command}[/dim]")

        if msg.cwd:
            safe_cwd = escape_rich_markup(msg.cwd)
            self._console.print(f"[dim]📂 Working directory: {safe_cwd}[/dim]")

        if msg.background:
            self._console.print("[dim]⏱ Runs detached (no timeout)[/dim]")
        else:
            self._console.print(f"[dim]⏱ Timeout: {msg.timeout}s[/dim]")

    def _render_shell_line(self, msg: ShellLineMessage) -> None:
        """Render shell output line preserving ANSI codes and carriage returns."""
        if "\r" in msg.line:
            # Bypass Rich entirely — write directly to stdout so terminal
            # interprets \r (progress-bar style output)
            sys.stdout.write(f"\033[2m{msg.line}\033[0m")
            sys.stdout.flush()
        else:
            text = Text.from_ansi(msg.line)
            self._console.print(text, style="dim")

    def _render_shell_output(self, msg: ShellOutputMessage) -> None:
        """Render shell command output.

        Just a trailing newline for spinner separation.
        """
        self._console.print()
