"""File operation rendering mixin (listing, content, grep)."""

import re
from collections import defaultdict
from pathlib import Path

from ..messages import FileContentMessage, FileListingMessage, GrepResultMessage


class FileRenderMixin:
    """Renders file-related messages: listings, content, grep results."""

    # ------------------------------------------------------------------
    # File listing
    # ------------------------------------------------------------------

    def _render_file_listing(self, msg: FileListingMessage) -> None:
        """Render a compact directory listing with directory summaries."""
        if self._should_suppress_subagent_output():
            return

        rec_flag = f"(recursive={msg.recursive})"
        banner = self._format_banner("directory_listing", "DIRECTORY LISTING")
        self._console.print(
            f"\n{banner} 📂 "
            f"[bold cyan]{msg.directory}[/bold cyan] "
            f"[dim]{rec_flag}[/dim]\n"
        )

        dir_stats: dict = defaultdict(
            lambda: {"files": [], "subdirs": set(), "total_size": 0}
        )
        root_key = ""

        for entry in msg.files:
            path = entry.path
            parent = (
                str(Path(path).parent) if Path(path).parent != Path(".") else root_key
            )

            if entry.type == "dir":
                dir_stats[parent]["subdirs"].add(path)
                _ = dir_stats[path]
            else:
                dir_stats[parent]["files"].append(entry)
                dir_stats[parent]["total_size"] += entry.size

        def render_dir_tree(dir_path: str, depth: int = 0) -> None:
            """Recursively render directory with compact summary."""
            stats = dir_stats.get(
                dir_path, {"files": [], "subdirs": set(), "total_size": 0}
            )
            files = stats["files"]
            subdirs = sorted(stats["subdirs"])

            def get_recursive_size(d: str) -> int:
                s = dir_stats.get(d, {"files": [], "subdirs": set(), "total_size": 0})
                size = s["total_size"]
                for sub in s["subdirs"]:
                    size += get_recursive_size(sub)
                return size

            def get_recursive_file_count(d: str) -> int:
                s = dir_stats.get(d, {"files": [], "subdirs": set(), "total_size": 0})
                count = len(s["files"])
                for sub in s["subdirs"]:
                    count += get_recursive_file_count(sub)
                return count

            indent = "    " * depth

            if dir_path == root_key:
                for f in sorted(files, key=lambda x: x.path):
                    icon = self._get_file_icon(f.path)
                    name = Path(f.path).name
                    size_str = (
                        f" [dim]({self._format_size(f.size)})[/dim]"
                        if f.size > 0
                        else ""
                    )
                    self._console.print(
                        f"{indent}{icon} [green]{name}[/green]{size_str}"
                    )

                for subdir in subdirs:
                    render_dir_tree(subdir, depth)
            else:
                dir_name = Path(dir_path).name
                rec_size = get_recursive_size(dir_path)
                rec_file_count = get_recursive_file_count(dir_path)
                subdir_count = len(subdirs)

                parts = []
                if rec_file_count > 0:
                    parts.append(
                        f"{rec_file_count} file{'s' if rec_file_count != 1 else ''}"
                    )
                if subdir_count > 0:
                    parts.append(
                        f"{subdir_count} subdir{'s' if subdir_count != 1 else ''}"
                    )
                if rec_size > 0:
                    parts.append(self._format_size(rec_size))

                summary = f" [dim]({', '.join(parts)})[/dim]" if parts else ""
                self._console.print(
                    f"{indent}📁 [bold blue]{dir_name}/[/bold blue]{summary}"
                )

                for subdir in subdirs:
                    render_dir_tree(subdir, depth + 1)

        render_dir_tree(root_key, 0)

        self._console.print("\n[bold cyan]Summary:[/bold cyan]")
        self._console.print(
            f"📁 [blue]{msg.dir_count} directories[/blue], "
            f"📄 [green]{msg.file_count} files[/green] "
            f"[dim]({self._format_size(msg.total_size)} total)[/dim]"
        )

    # ------------------------------------------------------------------
    # File content
    # ------------------------------------------------------------------

    def _render_file_content(self, msg: FileContentMessage) -> None:
        """Render a file read — just show the header, not the content.

        The file content is for the LLM only, not for display in the UI.
        """
        if self._should_suppress_subagent_output():
            return

        line_info = ""
        if msg.start_line is not None and msg.num_lines is not None:
            end_line = msg.start_line + msg.num_lines - 1
            line_info = f" [dim](lines {msg.start_line}-{end_line})[/dim]"

        banner = self._format_banner("read_file", "READ FILE")
        self._console.print(
            f"\n{banner} 📂 [bold cyan]{msg.path}[/bold cyan]{line_info}"
        )

    # ------------------------------------------------------------------
    # Grep results
    # ------------------------------------------------------------------

    def _render_grep_result(self, msg: GrepResultMessage) -> None:
        """Render grep results grouped by file."""
        if self._should_suppress_subagent_output():
            return

        banner = self._format_banner("grep", "GREP")
        self._console.print(
            f"\n{banner} 📂 [dim]{msg.directory} for '{msg.search_term}'[/dim]"
        )

        if not msg.matches:
            self._console.print(
                f"[dim]No matches found for '{msg.search_term}' "
                f"in {msg.directory}[/dim]"
            )
            return

        by_file: dict[str, list] = {}
        for match in msg.matches:
            by_file.setdefault(match.file_path, []).append(match)

        if msg.verbose:
            for file_path in sorted(by_file.keys()):
                file_matches = by_file[file_path]
                match_word = "match" if len(file_matches) == 1 else "matches"
                self._console.print(
                    f"\n[dim]📄 {file_path} ({len(file_matches)} {match_word})[/dim]"
                )

                for match in file_matches:
                    line = match.line_content
                    parts = msg.search_term.split()
                    search_term = msg.search_term
                    for part in parts:
                        if not part.startswith("-"):
                            search_term = part
                            break

                    if search_term and not search_term.startswith("-"):
                        highlighted_line = re.sub(
                            f"({re.escape(search_term)})",
                            r"[bold yellow]\1[/bold yellow]",
                            line,
                            flags=re.IGNORECASE,
                        )
                    else:
                        highlighted_line = line

                    ln = match.line_number
                    self._console.print(f"  [dim]{ln:4d}[/dim] │ {highlighted_line}")
        else:
            self._console.print("")
            for file_path in sorted(by_file.keys()):
                file_matches = by_file[file_path]
                match_word = "match" if len(file_matches) == 1 else "matches"
                self._console.print(
                    f"[dim]📄 {file_path} ({len(file_matches)} {match_word})[/dim]"
                )

        match_word = "match" if msg.total_matches == 1 else "matches"
        file_word = "file" if len(by_file) == 1 else "files"
        num_files = len(by_file)
        self._console.print(
            f"[dim]Found {msg.total_matches} {match_word} "
            f"across {num_files} {file_word}[/dim]"
        )

        self._console.print()

    # ------------------------------------------------------------------
    # Size / icon helpers (used by file listing)
    # ------------------------------------------------------------------

    def _format_size(self, size_bytes: int) -> str:
        """Format byte size to human readable matching old format."""
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.1f} KB"
        elif size_bytes < 1024 * 1024 * 1024:
            return f"{size_bytes / (1024 * 1024):.1f} MB"
        else:
            return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"

    def _get_file_icon(self, file_path: str) -> str:
        """Get an emoji icon for a file based on its extension."""
        ext = Path(file_path).suffix.lower()
        icons = {
            # Python
            ".py": "🐍",
            ".pyw": "🐍",
            # JavaScript/TypeScript
            ".js": "📜",
            ".jsx": "📜",
            ".ts": "📜",
            ".tsx": "📜",
            # Web
            ".html": "🌐",
            ".htm": "🌐",
            ".xml": "🌐",
            ".css": "🎨",
            ".scss": "🎨",
            ".sass": "🎨",
            # Documentation
            ".md": "📝",
            ".markdown": "📝",
            ".rst": "📝",
            ".txt": "📝",
            # Config
            ".json": "⚙️",
            ".yaml": "⚙️",
            ".yml": "⚙️",
            ".toml": "⚙️",
            ".ini": "⚙️",
            # Images
            ".jpg": "🖼️",
            ".jpeg": "🖼️",
            ".png": "🖼️",
            ".gif": "🖼️",
            ".svg": "🖼️",
            ".webp": "🖼️",
            # Audio
            ".mp3": "🎵",
            ".wav": "🎵",
            ".ogg": "🎵",
            ".flac": "🎵",
            # Video
            ".mp4": "🎬",
            ".avi": "🎬",
            ".mov": "🎬",
            ".webm": "🎬",
            # Documents
            ".pdf": "📄",
            ".doc": "📄",
            ".docx": "📄",
            ".xls": "📄",
            ".xlsx": "📄",
            ".ppt": "📄",
            ".pptx": "📄",
            # Archives
            ".zip": "📦",
            ".tar": "📦",
            ".gz": "📦",
            ".rar": "📦",
            ".7z": "📦",
            # Executables
            ".exe": "⚡",
            ".dll": "⚡",
            ".so": "⚡",
            ".dylib": "⚡",
        }
        return icons.get(ext, "📄")
