"""Protocol definition for spinner interfaces.

Extracts the structural contract from ``SpinnerBase`` so that code
depending only on the spinner interface can type-check against the
Protocol rather than requiring ``SpinnerBase`` inheritance.
"""

from typing import Protocol, runtime_checkable


@runtime_checkable
class SpinnerProtocol(Protocol):
    """Structural interface for spinner implementations.

    Defines the core ``start``/``stop``/``update_frame`` lifecycle and
    the ``current_frame``/``is_spinning`` read-only properties.
    """

    def start(self) -> None:
        """Start the spinner animation."""
        ...

    def stop(self) -> None:
        """Stop the spinner animation."""
        ...

    def update_frame(self) -> None:
        """Advance to the next animation frame."""
        ...

    @property
    def current_frame(self) -> str:
        """The current spinner frame character."""
        ...

    @property
    def is_spinning(self) -> bool:
        """Whether the spinner is currently active."""
        ...
