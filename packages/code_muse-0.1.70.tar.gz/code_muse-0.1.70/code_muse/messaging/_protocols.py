"""Protocol definitions for messaging lifecycle interfaces.

These Protocols document the structural contracts used across the
messaging subsystem. Classes that implement ``start()`` / ``stop()``
satisfy ``StartStoppable`` regardless of their inheritance tree.
"""

from typing import Protocol, runtime_checkable


@runtime_checkable
class StartStoppable(Protocol):
    """Structural interface for components with a start/stop lifecycle.

    Satisfied by ``MessageQueue``, ``SpinnerBase``, ``RichConsoleRenderer``,
    ``SynchronousInteractiveRenderer``, ``MitmProxyManager``, and any other
    component that follows the start/stop pattern.
    """

    def start(self) -> None:
        """Start the component (may be idempotent)."""
        ...

    def stop(self) -> None:
        """Stop the component (may be idempotent)."""
        ...
