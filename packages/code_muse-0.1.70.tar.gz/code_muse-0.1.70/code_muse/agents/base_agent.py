"""Base agent class — a thin conductor delegating to focused helpers.

The real logic lives in sibling modules:
    * ``_history``     — token estimation, hashing, orphan pruning
    * ``_compaction``  — summarization/truncation + history processor factory
    * ``_builder``     — pydantic-ai agent construction + tool wiring
    * ``_runtime``     — ``run`` orchestration, cancellation, retries
    * ``_key_listeners`` — Ctrl+X / cancel-agent keyboard listener threads

Keep this file under 300 lines. If it's growing, the new logic probably
belongs in one of the helpers above (or a new one).
"""

import asyncio
import uuid
from abc import ABC, abstractmethod
from typing import Any, ClassVar

import pydantic_ai.models

from code_muse.agents._builder import (
    build_pydantic_agent,
)
from code_muse.agents._history import (
    estimate_context_overhead,
    estimate_tokens_for_message,
    hash_message,
)
from code_muse.agents._runtime import run
from code_muse.agents._streaming_retry import should_retry_streaming
from code_muse.agents.compaction import summarize
from code_muse.config import (
    get_agent_pinned_model,
    get_global_model_name,
    get_overall_run_timeout_seconds,
    get_protected_token_count,
)

should_retry_streaming_exception = should_retry_streaming

__all__ = ["BaseAgent", "should_retry_streaming_exception"]


class BaseAgent(ABC):
    """Abstract base for all Muse agents."""

    # Class-level agent name metadata for zero-instantiation discovery
    _agent_name: ClassVar[str | None] = None

    def __init__(self) -> None:
        self.id: str = str(uuid.uuid4())
        self._message_history: list[Any] = []
        self._pinned_messages: list[Any] = []
        self._compacted_message_hashes: set[int] = set()
        self._code_generation_agent: Any = None
        self._last_model_name: str | None = None
        self._muse_rules: str | None = None
        self.cur_model: pydantic_ai.models.Model | None = None
        self.pydantic_agent: Any = None

    # ---- Abstract interface ------------------------------------------------
    @property
    @abstractmethod
    def name(self) -> str:
        """Stable machine identifier (e.g. ``python-programmer``)."""

    @property
    @abstractmethod
    def display_name(self) -> str:
        """Human-readable name shown in UIs."""

    @property
    @abstractmethod
    def description(self) -> str:
        """One-line summary of what this agent does."""

    @abstractmethod
    def get_system_prompt(self) -> str:
        """Return the agent's system prompt (identity is appended separately)."""

    @abstractmethod
    def get_available_tools(self) -> list[str]:
        """Return the list of tool names this agent should register."""

    # ---- Optional overrides ------------------------------------------------
    def get_tools_config(self) -> dict[str, Any | None]:
        return None

    def get_user_prompt(self) -> str | None:
        return None

    def get_model_name(self) -> str | None:
        pinned = get_agent_pinned_model(self.name)
        return pinned if pinned else get_global_model_name()

    # ---- Identity ---------------------------------------------------------
    def get_identity(self) -> str:
        return f"{self.name}-{self.id[:6]}"

    def get_identity_prompt(self) -> str:
        return (
            f"\n\nYour ID is `{self.get_identity()}`. "
            "Use this for any tasks which require identifying yourself "
            "such as claiming task ownership or coordination with other agents."
        )

    def get_full_system_prompt(self) -> str:
        instructions = self.get_system_prompt() + self.get_identity_prompt()
        # Also append pinned messages as protected facts
        pinned = self.get_pinned_messages()
        if pinned:
            try:
                from code_muse.plugins.task_context.protected_facts import (
                    ProtectedFact,
                    get_protected_fact_manager,
                )

                mgr = get_protected_fact_manager()
                for msg in pinned:
                    text = self._extract_message_text(msg)
                    if text and not mgr.has_fact(text):
                        mgr.add_fact(
                            ProtectedFact(
                                content=text[:200],
                                category="pinned_message",
                                priority=0,
                                immutable=False,
                            )
                        )
            except Exception:
                pass
        return instructions

    # ---- Message history (plain dict-level access) ------------------------
    def get_message_history(self) -> list[Any]:
        return self._message_history

    def set_message_history(self, history: list[Any]) -> None:
        self._message_history = history

    def clear_message_history(self) -> None:
        self._message_history = []
        self._pinned_messages.clear()
        self._compacted_message_hashes.clear()

    def append_to_message_history(self, message: Any) -> None:
        self._message_history.append(message)

    # ---- Pinned messages (compaction-proof) --------------------------------
    def pin_message(self, message: Any) -> None:
        """Pin a message so it survives compaction.

        Pinned messages are always preserved during summarization or
        truncation and prepended after the system message in the history.
        """
        msg_hash = self.hash_message(message)
        if msg_hash not in {self.hash_message(m) for m in self._pinned_messages}:
            self._pinned_messages.append(message)

    def unpin_message(self, message: Any) -> None:
        """Remove a previously pinned message by content hash."""
        target_hash = self.hash_message(message)
        self._pinned_messages = [
            m for m in self._pinned_messages if self.hash_message(m) != target_hash
        ]

    def get_pinned_messages(self) -> list[Any]:
        """Return a shallow copy of pinned messages."""
        return list(self._pinned_messages)

    def _extract_message_text(self, message: Any) -> str:
        """Extract plain text from a message for protected fact content."""
        from code_muse.plugins.task_context.protected_facts import (
            _extract_message_text as _ext,
        )

        return _ext(message)

    # ---- Token / context helpers ------------------------------------------
    def estimate_tokens_for_message(self, message: Any) -> int:
        return estimate_tokens_for_message(message, self.get_model_name())

    def hash_message(self, message: Any) -> int:
        return hash_message(message)

    def _get_model_context_length(self) -> int:
        """Context window for the agent's effective model (fallback: 128k)."""
        try:
            from code_muse.config.models import get_model_context_length

            return get_model_context_length(model_name=self.get_model_name())
        except Exception:
            return 128000

    def _estimate_context_overhead(self) -> int:
        """Tokens used by system prompt + registered pydantic tools.

        Cached per agent instance because tool schemas are fixed per build
        and the system prompt is stable once ``_assemble_instructions``
        (which now caches ``load_muse_rules``) has run.
        """
        model_name = self.get_model_name()
        cached = getattr(self, "_context_overhead_cache", None)
        if cached is not None and cached.get("model_name") == model_name:
            return cached["value"]

        system_prompt = self.get_full_system_prompt()
        try:
            from code_muse.model_utils import prepare_prompt_for_model

            prepared = prepare_prompt_for_model(
                model_name=model_name or "",
                system_prompt=system_prompt,
                user_prompt="",
                prepend_system_to_user=False,
            )
            resolved = prepared.instructions or system_prompt
        except Exception:
            resolved = system_prompt

        tools = (
            getattr(self.pydantic_agent, "_tools", None)
            if self.pydantic_agent
            else None
        )
        value = estimate_context_overhead(resolved, tools, model_name)
        self._context_overhead_cache = {"value": value, "model_name": model_name}
        return value

    def _format_timeout_diagnostic(self, exc_grp: BaseException) -> str:
        """Build a friendly, actionable timeout diagnostic message.

        Wrapped in try/except so a fallback message is always produced
        even if introspection calls fail.  *exc_grp* is the exception
        group from the timeout; reserved for future inspection of
        which sub-call timed out (currently unused in the message).
        """
        try:
            timeout_seconds = get_overall_run_timeout_seconds()
            model_name = self.get_model_name() or "unknown"
            context_length = self._get_model_context_length()
            overhead = self._estimate_context_overhead()
            msg_count = len(self._message_history)
            return (
                f"Agent run timed out after {timeout_seconds}s "
                f"(model: {model_name}, "
                f"context window: {context_length:,} tokens, "
                f"estimated overhead: {overhead:,} tokens, "
                f"message count: {msg_count}). "
                f"Try increasing the timeout with "
                f"`/config run_timeout_seconds 1200`, "
                f"or use a model with a larger context window, "
                f"or run `/compact` to reduce context."
            )
        except Exception:
            # Best-effort: include timeout seconds even in fallback
            # since that call is unlikely to fail.
            try:
                timeout_seconds = get_overall_run_timeout_seconds()
            except Exception:
                timeout_seconds = None
            if timeout_seconds is not None:
                return (
                    f"Agent run timed out after {timeout_seconds}s. "
                    "Try increasing the timeout with "
                    "`/config run_timeout_seconds 1200`, "
                    "or run `/compact` to reduce context."
                )
            return (
                "Agent run timed out. "
                "Try increasing the timeout with "
                "`/config run_timeout_seconds 1200`, "
                "or run `/compact` to reduce context."
            )

    # ---- Orchestration (thin delegations) ---------------------------------
    def summarize_messages(
        self,
        messages: list[Any],
        with_protection: bool = True,
    ) -> tuple[list, list]:
        """Delegate to ``_compaction.summarize`` with config-derived protection."""
        return summarize(
            messages,
            get_protected_token_count(
                getattr(self, "model_name", None) or getattr(self, "_model_name", None)
            ),
            with_protection=with_protection,
            model_name=self.get_model_name(),
        )

    def reload_code_generation_agent(self, message_group: str | None = None) -> Any:
        return build_pydantic_agent(self, output_type=str, message_group=message_group)

    async def run(self, prompt: str, **kwargs: Any) -> Any:
        """Run the agent with available tools, swallowing exceptions gracefully.

        The underlying ``_runtime.run`` propagates exception groups
        for callers that want structured error handling.  This high-level entry
        point catches and logs model or tool errors so callers (e.g. the REPL)
        aren't disrupted by routine failures, but it re-raises control-flow
        exceptions (cancellation, keyboard interrupt, system exit) so they
        are handled by the event loop / shell as expected.
        """
        try:
            return await run(self, prompt, **kwargs)
        except asyncio.CancelledError, KeyboardInterrupt, SystemExit:
            raise
        except BaseExceptionGroup as exc:
            # Split into non-Exception (CancelledError, KeyboardInterrupt,
            # SystemExit) and Exception sub-groups.  Re-raise any non-Exception
            # subgroup so the event loop / shell handles control-flow correctly.
            non_exc, exc_grp = exc.split(
                lambda e: isinstance(
                    e, (asyncio.CancelledError, KeyboardInterrupt, SystemExit)
                )
            )
            if non_exc is not None:
                raise non_exc from exc
            # exc_grp (may be None if *all* sub-exceptions were control-flow)
            # contains only Exception-derived sub-exceptions — safe to swallow.
            import traceback

            from code_muse.messaging import emit_error, emit_warning

            if exc_grp is not None:
                # Recursively extract TimeoutError from the exception group tree
                timeout_grp, exc_grp = exc_grp.split(TimeoutError)

                if timeout_grp is not None:
                    # Log any co-occurring non-timeout exceptions before propagating.
                    if exc_grp is not None:
                        for i, sub in enumerate(exc_grp.exceptions, 1):
                            tb = "".join(
                                traceback.format_exception(
                                    type(sub), sub, sub.__traceback__
                                )
                            )
                            emit_error(
                                f"Swallowed exception #{i} (co-occurred with TimeoutError): {sub!r}"
                            )
                            emit_warning(tb.rstrip())

                    msg = self._format_timeout_diagnostic(timeout_grp)
                    raise TimeoutError(msg) from timeout_grp

                # No TimeoutError — swallow all sub-exceptions as before.
                for i, sub in enumerate(exc_grp.exceptions, 1):
                    tb = "".join(
                        traceback.format_exception(type(sub), sub, sub.__traceback__)
                    )
                    emit_error(f"Swallowed exception #{i}: {sub!r}")
                    emit_warning(tb.rstrip())
            return None
        except Exception as exc:
            import traceback

            from code_muse.messaging import emit_error, emit_warning

            tb = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
            emit_error(f"run swallowed exception: {exc!r}")
            emit_warning(tb.rstrip())
            return None
