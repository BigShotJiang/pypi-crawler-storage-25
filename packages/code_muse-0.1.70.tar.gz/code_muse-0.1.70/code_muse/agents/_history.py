"""Pure helpers for message history hashing, token estimation, and pruning.

Extracted from the original ``BaseAgent`` god-class. Everything in here is a
free function with no hidden state. Call sites pass messages (and, where
needed, already-resolved strings / tool dicts) in explicitly.

PERF-04 adds :class:`CompactionCache` — a per-compaction-run cache that avoids
repeated ``hash_message`` / ``estimate_tokens_for_message`` calls on the same
message objects within a single ``compact()`` invocation.

PERF-TOK-CACHE adds a global TTL cache (5 min) for ``estimate_tokens_for_message``
results, keyed by content hash + model name.  This extends caching to all call
sites (session commands, loop, resume, etc.) that previously bypassed the
CompactionCache.  The cache does not retain message objects — only integer
hashes as keys — so there is no lifecycle concern.
"""

import dataclasses
import math
import pathlib
import threading
import time
import weakref

try:
    from annotationlib import get_annotations
except ImportError:
    # Python <3.14 fallback
    from inspect import get_annotations
from collections import OrderedDict
from typing import Any

import orjson as json
import pydantic
from pydantic_ai import BinaryContent
from pydantic_ai.messages import ModelMessage, ModelRequest, ToolReturnPart

# ---------------------------------------------------------------------------
# Drift tracking: calibration between estimates and actual provider usage
# ---------------------------------------------------------------------------


@dataclasses.dataclass
class DriftTracker:
    """Tracks cumulative drift between token estimates and provider-reported usage.

    Records the running total of *estimated* tokens (from our heuristics /
    tiktoken / learned ratios) versus *actual* tokens reported by the model
    provider (e.g. ``usage.input_tokens`` from a pydantic-ai RunResult).

    The drift percentage tells us how far off our estimates are, so budget
    calculations can self-correct.
    """

    total_estimated: int = 0
    total_actual: int = 0
    session_drift_pct: float = 0.0
    last_calibration_model: str | None = None
    warnings_fired: set[str] = dataclasses.field(default_factory=set)

    def record_usage(
        self, estimated: int, actual: int, model_name: str | None = None
    ) -> float:
        """Record a calibration point and return current drift percentage.

        Drift is ``abs(estimated - actual) / actual`` over the running totals.
        A positive drift means we're overestimating; negative means under.
        The percentage is always absolute — direction is not distinguished.
        """
        self.total_estimated += estimated
        self.total_actual += actual
        if self.total_actual > 0:
            self.session_drift_pct = (
                abs(self.total_estimated - self.total_actual) / self.total_actual
            )
        if model_name:
            self.last_calibration_model = model_name
        return self.session_drift_pct

    def should_warn(self) -> bool:
        """Return True if drift exceeds 10% and warning hasn't fired this session."""
        return (
            self.session_drift_pct > 0.10 and "drift_10pct" not in self.warnings_fired
        )


# Module-level global — one tracker per process lifetime.
_drift_tracker = DriftTracker()


def get_drift_tracker() -> DriftTracker:
    """Return the module-level :class:`DriftTracker` singleton."""
    return _drift_tracker


def reset_drift_tracker() -> None:
    """Reset the drift tracker to a fresh state (called on startup)."""
    global _drift_tracker
    _drift_tracker = DriftTracker()


def _prep_for_orjson(obj):
    """Prepare object for orjson serialization by converting non-serializable types."""
    if isinstance(obj, pathlib.PurePath):
        return str(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


# PERF-0yj.1: Global LRU cache for stringify_part — parts are often identical
# across messages (same tool results reused), so caching by object identity
# eliminates redundant json/orjson work during compaction.
_stringify_part_lru: OrderedDict[int, str] = OrderedDict()
_STRINGIFY_PART_LRU_MAX = 4096
_stringify_part_cache_lock = threading.Lock()


def _evict_stringify_cache(msg_id: int) -> None:
    """Remove a stale entry from the stringify_part LRU cache after GC."""
    with _stringify_part_cache_lock:
        _stringify_part_lru.pop(msg_id, None)


def clear_stringify_part_cache() -> None:
    """Clear the stringify_part LRU cache."""
    with _stringify_part_cache_lock:
        _stringify_part_lru.clear()


def stringify_part(part: Any) -> str:
    """Return a stable, timestamp-free string representation of a message part.

    Used for both hashing and token estimation. Ignoring timestamps means two
    otherwise-identical parts emitted at different times collapse to the same
    string, which is exactly what we want for dedup.
    """
    msg_id = id(part)
    with _stringify_part_cache_lock:
        cached = _stringify_part_lru.get(msg_id)
        if cached is not None:
            _stringify_part_lru.move_to_end(msg_id)
            return cached

    attributes: list[str] = [part.__class__.__name__]

    if hasattr(part, "role") and part.role:
        attributes.append(f"role={part.role}")
    if hasattr(part, "instructions") and part.instructions:
        attributes.append(f"instructions={part.instructions}")

    if hasattr(part, "tool_call_id") and part.tool_call_id:
        attributes.append(f"tool_call_id={part.tool_call_id}")
    if hasattr(part, "tool_name") and part.tool_name:
        attributes.append(f"tool_name={part.tool_name}")

    content = getattr(part, "content", None)
    if content is None:
        attributes.append("content=None")
    elif isinstance(content, str):
        attributes.append(f"content={content}")
    elif isinstance(content, pydantic.BaseModel):
        dumped = json.dumps(content.model_dump(), default=_prep_for_orjson).decode()
        attributes.append(f"content={dumped}")
    elif isinstance(content, dict):
        dumped = json.dumps(content, default=_prep_for_orjson).decode()
        attributes.append(f"content={dumped}")
    elif isinstance(content, list):
        for item in content:
            if isinstance(item, str):
                attributes.append(f"content={item}")
            elif isinstance(item, BinaryContent):
                attributes.append(f"BinaryContent={hash(item.data)}")
    else:
        attributes.append(f"content={repr(content)}")

    result = "|".join(attributes)

    # Bounded LRU cache — evict oldest when full
    with _stringify_part_cache_lock:
        if len(_stringify_part_lru) >= _STRINGIFY_PART_LRU_MAX:
            _stringify_part_lru.popitem(last=False)
        _stringify_part_lru[msg_id] = result
    weakref.finalize(part, _evict_stringify_cache, msg_id)
    return result


# PERF-07: Cache hash results by object identity.  A message that appears
# in multiple history lists (e.g. after copy-on-write) will hash
# identically, so id()-keyed caching is correct as long as the message
# object is alive — which it always is while it's in a history list.
#
# A ``weakref.finalize`` callback automatically drops the cached entry
# when the message object is garbage-collected, preventing stale hits if the
# same memory address is reused for a different message later (common in
# tests that create many short-lived messages).
_hash_cache: OrderedDict[int, int] = OrderedDict()
_HASH_CACHE_MAX = 8192
_hash_cache_lock = threading.Lock()


def _evict_hash_cache(msg_id: int) -> None:
    with _hash_cache_lock:
        _hash_cache.pop(msg_id, None)


def hash_message(message: Any) -> int:
    """Stable hash for a ``ModelMessage`` that ignores timestamps."""
    msg_id = id(message)
    with _hash_cache_lock:
        cached = _hash_cache.get(msg_id)
        if cached is not None:
            _hash_cache.move_to_end(msg_id)
            return cached

    role = getattr(message, "role", None)
    instructions = getattr(message, "instructions", None)
    header_bits: list[str] = []
    if role:
        header_bits.append(f"role={role}")
    if instructions:
        header_bits.append(f"instructions={instructions}")

    part_strings = [stringify_part(part) for part in getattr(message, "parts", [])]
    canonical = "||".join(header_bits + part_strings)
    result = hash(canonical)

    # Bounded cache — LRU eviction when full
    with _hash_cache_lock:
        if len(_hash_cache) >= _HASH_CACHE_MAX:
            _hash_cache.popitem(last=False)
        _hash_cache[msg_id] = result
    weakref.finalize(message, _evict_hash_cache, msg_id)
    return result


def estimate_tokens(text: str) -> int:
    """Character-based token estimator tuned for code-heavy content.

    Uses ``len / 2.5`` as the base divisor — a conservative estimate that
    avoids undercounting which can lead to context overflow.  Per-model
    calibration multipliers applied downstream by
    ``estimate_tokens_for_message`` adjust for models with even denser
    tokenizers.
    """
    return max(1, math.floor(len(text) / 2.5))


# Models whose tokenizer the char/2.5 heuristic systematically *under*counts.
# Bump these by a calibration factor so context-usage math stops lying to us.
# Substring match is case-insensitive; both naming orders are accepted because
# vendor naming is a coin flip.
_TOKEN_MULTIPLIER_RULES: tuple[tuple[tuple[str, ...], float], ...] = (
    (("opus-4-7", "4-7-opus"), 1.35),
    (("claude-3-5-sonnet", "sonnet-3-5", "claude-3.5-sonnet"), 1.15),
    (("gpt-4o", "gpt4o"), 1.10),
    (("gemini",), 1.20),
    (("mimo",), 1.15),
)


def model_token_multiplier(model_name: str | None) -> float:
    """Per-model fudge factor for our char-based token estimator.

    Returns 1.0 when ``model_name`` is falsy or doesn't match any rule.
    """
    if not model_name:
        return 1.0
    lowered = model_name.lower()
    for needles, factor in _TOKEN_MULTIPLIER_RULES:
        if any(needle in lowered for needle in needles):
            return factor
    return 1.0


def _apply_multiplier(raw_tokens: int, model_name: str | None) -> int:
    multiplier = model_token_multiplier(model_name)
    if multiplier == 1.0:
        return raw_tokens
    return max(1, math.floor(raw_tokens * multiplier))


# PERF-TOK-CACHE: Global TTL cache for token estimates, keyed by content hash
# + model_name.  Extends the CompactionCache pattern to all call sites
# (session_commands, loop, resume, session_storage) that previously bypassed
# caching entirely.  TTL: 5 minutes; bounded to 200 entries with LRU eviction.
_token_estimate_cache: OrderedDict[tuple[int, str | None], tuple[int, float]] = (
    OrderedDict()
)
_TOKEN_ESTIMATE_CACHE_MAX = 1024
_TOKEN_ESTIMATE_TTL = 300.0  # seconds
_token_estimate_cache_lock = threading.Lock()


def clear_token_estimate_cache() -> None:
    """Clear the global token-estimate TTL cache (useful in tests)."""
    with _token_estimate_cache_lock:
        _token_estimate_cache.clear()


def estimate_tokens_for_message(
    message: ModelMessage,
    model_name: str | None = None,
) -> int:
    """Estimate the number of tokens in a single model message.

    When ``model_name`` is provided, the raw count is scaled by
    :func:`model_token_multiplier` to compensate for tokenizers that don't
    play nicely with our char/2.5 heuristic.

    Results are cached globally by ``(content_hash, model_name)`` with a
    5-minute TTL so that repeated calls from different call sites (compact,
    session commands, resume, etc.) avoid recomputing the same estimate.
    """
    # Content-hash keyed cache check — avoids recomputation across call sites.
    msg_hash = hash_message(message)
    cache_key = (msg_hash, model_name)
    now = time.monotonic()
    with _token_estimate_cache_lock:
        cached = _token_estimate_cache.get(cache_key)
        if cached is not None:
            tokens, ts = cached
            if now - ts < _TOKEN_ESTIMATE_TTL:
                _token_estimate_cache.move_to_end(cache_key)
                return tokens
            # Expired — evict and recompute below.
            del _token_estimate_cache[cache_key]

    total = 0
    for part in getattr(message, "parts", []) or []:
        part_str = stringify_part(part)
        if part_str:
            total += estimate_tokens(part_str)
    result = _apply_multiplier(max(1, total), model_name)

    # Store in global cache with TTL timestamp.
    with _token_estimate_cache_lock:
        if len(_token_estimate_cache) >= _TOKEN_ESTIMATE_CACHE_MAX:
            _token_estimate_cache.popitem(last=False)
        _token_estimate_cache[cache_key] = (result, now)
    return result


def estimate_context_overhead(
    system_prompt: str,
    pydantic_tools: dict[str, Any | None],
    model_name: str | None = None,
) -> int:
    """Estimate fixed token overhead for the system prompt + tool definitions.

    The caller is responsible for resolving the system prompt for the active
    model (e.g. via ``prepare_prompt_for_model``). external tool overhead is
    deliberately ignored — it was guesswork anyway.

    Args:
        system_prompt: The already-resolved instruction/system prompt string.
        pydantic_tools: The pydantic-ai agent's ``_tools`` dict, or ``None``.

    Returns:
        Estimated total token overhead.
    """
    total = 0
    if system_prompt:
        total += estimate_tokens(system_prompt)

    if not pydantic_tools:
        return _apply_multiplier(total, model_name)

    for tool_name, tool_func in pydantic_tools.items():
        total += estimate_tokens(tool_name)

        description = getattr(tool_func, "__doc__", None) or ""
        if description:
            total += estimate_tokens(description)

        schema = getattr(tool_func, "schema", None)
        if schema is not None:
            schema_str = json.dumps(schema) if isinstance(schema, dict) else str(schema)
            total += estimate_tokens(schema_str)
        else:
            annotations = get_annotations(tool_func)
            if annotations:
                total += estimate_tokens(str(annotations))

    return _apply_multiplier(total, model_name)


# Pydantic-AI has FOUR part kinds that carry a tool_call_id:
#   * tool-call            -> ToolCallPart            (regular tool call)
#   * tool-return          -> ToolReturnPart          (regular tool response)
#   * builtin-tool-call    -> BuiltinToolCallPart     (claude extended-thinking, etc.)
#   * builtin-tool-return  -> BuiltinToolReturnPart   (builtin tool response)
#   * retry-prompt         -> RetryPromptPart
#         (assistant told to retry; acts as a response)
#
# Treating only `tool-call` / `tool-return` (and ignoring the others) caused
# subtle bugs: e.g. builtin tool calls on Claude Opus were counted as pending
# forever, deferring summarization on every turn.
_TOOL_CALL_PART_KINDS: frozenset[str] = frozenset({"tool-call", "builtin-tool-call"})
_TOOL_RETURN_PART_KINDS: frozenset[str] = frozenset(
    {"tool-return", "builtin-tool-return", "retry-prompt"}
)


def _classify_tool_part(part: object) -> str | None:
    """Return ``"call"``, ``"return"``, or ``None`` for a message part.

    ``None`` means the part doesn't participate in tool_call_id pairing
    (either no id, or an unrelated part kind).
    """
    if getattr(part, "tool_call_id", None) is None:
        return None
    pk = getattr(part, "part_kind", None)
    if pk in _TOOL_CALL_PART_KINDS:
        return "call"
    if pk in _TOOL_RETURN_PART_KINDS:
        return "return"
    return None


def prune_interrupted_tool_calls(
    messages: list[ModelMessage],
) -> list[ModelMessage]:
    """Drop messages participating in mismatched tool_call/tool_return pairs.

    A mismatched ``tool_call_id`` is one that appears only as a call or only
    as a return. The model will reject such histories ("tool_use ids found
    without tool_result blocks"), so we strip them out while preserving order.
    """
    if not messages:
        return messages

    tool_call_ids: set[str] = set()
    tool_return_ids: set[str] = set()

    for msg in messages:
        for part in getattr(msg, "parts", []) or []:
            kind = _classify_tool_part(part)
            if kind == "call":
                tool_call_ids.add(part.tool_call_id)
            elif kind == "return":
                tool_return_ids.add(part.tool_call_id)

    mismatched = tool_call_ids.symmetric_difference(tool_return_ids)
    if not mismatched:
        return messages

    pruned: list[ModelMessage] = []
    for msg in messages:
        if any(
            getattr(part, "tool_call_id", None) in mismatched
            for part in getattr(msg, "parts", []) or []
        ):
            continue
        pruned.append(msg)
    return pruned


def has_pending_tool_calls(messages: list[ModelMessage]) -> bool:
    """Return True if any tool call is still waiting for its response.

    Recognizes both regular (``tool-call`` / ``tool-return``) and builtin
    (``builtin-tool-call`` / ``builtin-tool-return``) pairings, plus
    ``retry-prompt`` as a valid response form.
    """
    if not messages:
        return False

    tool_call_ids: set[str] = set()
    tool_return_ids: set[str] = set()

    for msg in messages:
        for part in getattr(msg, "parts", []) or []:
            kind = _classify_tool_part(part)
            if kind == "call":
                tool_call_ids.add(part.tool_call_id)
            elif kind == "return":
                tool_return_ids.add(part.tool_call_id)

    return bool(tool_call_ids - tool_return_ids)


def filter_huge_messages(
    messages: list[ModelMessage],
    model_name: str | None = None,
    cache: Any | None = None,  # CompactionCache when available
) -> list[ModelMessage]:
    """Drop messages above the configured token budget, then prune orphans.

    Dropping huge tool_return messages can leave their corresponding
    tool_call messages as orphans (or vice versa). We run
    prune_interrupted_tool_calls afterwards to keep the history valid.
    """
    from code_muse.config.parser import get_filter_huge_message_threshold

    threshold = get_filter_huge_message_threshold()
    filtered = [
        m
        for m in messages
        if (
            cache.estimate_tokens(m, model_name)
            if cache
            else estimate_tokens_for_message(m, model_name)
        )
        < threshold
    ]
    if len(filtered) != len(messages):
        filtered = prune_interrupted_tool_calls(filtered)
    return filtered


# ---------------------------------------------------------------------------
# PERF-04: Per-compaction-run cache
# ---------------------------------------------------------------------------


@dataclasses.dataclass
class CompactionCache:
    """Per-compaction-run cache for message hashes and token estimates.

    Created fresh at the start of each ``compact()`` call. Avoids repeated
    ``hash_message()`` and ``estimate_tokens_for_message()`` invocations on
    the same ``ModelMessage`` objects within a single compaction cycle.

    Importantly, this is *not* a global cache — it is scoped to one
    ``compact()`` invocation and dropped afterwards so we never retain
    message objects beyond their natural lifecycle.
    """

    # message id(id(m)) → int hash
    _message_hashes: dict[int, int] = dataclasses.field(default_factory=dict)
    # (id(m), model_name_or_None) → int token count
    _token_counts: dict[tuple[int, str | None], int] = dataclasses.field(
        default_factory=dict
    )

    def hash_message(self, message: ModelMessage) -> int:
        """Cached wrapper around :func:`hash_message` (module-level)."""
        key = id(message)
        if key not in self._message_hashes:
            self._message_hashes[key] = hash_message(message)
        return self._message_hashes[key]

    def estimate_tokens(
        self, message: ModelMessage, model_name: str | None = None
    ) -> int:
        """Cached wrapper around :func:`estimate_tokens_for_message`."""
        key = (id(message), model_name)
        if key not in self._token_counts:
            self._token_counts[key] = estimate_tokens_for_message(message, model_name)
        return self._token_counts[key]

    def sum_tokens(
        self, messages: list[ModelMessage], model_name: str | None = None
    ) -> int:
        """Sum estimated tokens across all messages using the cache."""
        return sum(self.estimate_tokens(m, model_name) for m in messages)


def is_tool_result_message(msg: ModelMessage) -> bool:
    """Check if a message contains tool return parts."""
    if isinstance(msg, ModelRequest):
        return any(isinstance(p, ToolReturnPart) for p in msg.parts)
    return False
