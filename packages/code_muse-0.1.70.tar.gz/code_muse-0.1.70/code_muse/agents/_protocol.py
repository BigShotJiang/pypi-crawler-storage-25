"""Protocol definitions for agent interfaces.

These Protocols define the structural contracts that agent-like objects
must satisfy. They enable type-safe function signatures without
requiring inheritance from ``BaseAgent`` (which remains an ABC for
nominal subtyping and shared implementation).
"""

from typing import Protocol, runtime_checkable


@runtime_checkable
class AgentProtocol(Protocol):
    """Structural interface for any Muse agent.

    Functions that accept an agent only need a subset of these methods;
    the Protocol documents the full contract so that ``agent: Any``
    annotations can be replaced with ``agent: AgentProtocol``.
    """

    @property
    def name(self) -> str:
        """Stable machine identifier (e.g. ``python-programmer``)."""
        ...

    @property
    def display_name(self) -> str:
        """Human-readable name shown in UIs."""
        ...

    @property
    def description(self) -> str:
        """One-line summary of what this agent does."""
        ...

    def get_system_prompt(self) -> str:
        """Return the agent's system prompt (identity is appended separately)."""
        ...

    def get_available_tools(self) -> list[str]:
        """Return the list of tool names this agent should register."""
        ...

    def get_model_name(self) -> str | None:
        """Return the effective model name (pinned or global)."""
        ...

    def get_full_system_prompt(self) -> str:
        """Return the complete system prompt including identity and rules."""
        ...

    def get_message_history(self) -> list[object]:
        """Return the current message history."""
        ...

    def get_identity(self) -> str:
        """Return ``{name}-{id[:6]}`` for task-ownership claims."""
        ...
