"""History budget computation, token counting, and shared split utilities.

These helpers are consumed by both the truncation and summarization
compaction strategies. Keeping them in one place avoids circular imports
and provides a single source of truth for budget math.
"""

import dataclasses
import logging as _logging
from typing import Any

from pydantic_ai.messages import (
    ModelMessage,
    ModelRequest,
    ModelResponse,
    TextPart,
    ThinkingPart,
    ToolReturnPart,
)

from code_muse.agents._history import (
    CompactionCache,
    _classify_tool_part,
    estimate_tokens_for_message,
)
from code_muse.messaging import emit_info

# ── Constants ──────────────────────────────────────────────────────────

_SUMMARIZATION_INSTRUCTIONS = (
    "The input will be a log of Agentic AI steps that have been taken"
    " as well as user queries, etc. Summarize the contents of these steps."
    " The high level details should remain but the bulk of the content from tool-call"
    " responses should be compacted and summarized. For example if you see a tool-call"
    " reading a file, and the file contents are large, then in your"
    " summary you might just"
    " write: * used read_file on space_invaders.cpp - contents removed."
    "\n Make sure your result is a bulleted list of all steps and interactions."
    "\n\nNOTE: This summary represents older conversation history. "
    "Recent messages are preserved separately."
)

# Default for tool result retention; actual value comes from config.
_DEFAULT_TOOL_RESULTS_TO_KEEP = 7

# Token-proportion threshold above which compact_with_tool_truncation
# applies tool-result truncation even for short histories.
_TOOL_TRUNCATION_TOKEN_THRESHOLD = 0.50


# ── Split-point helpers ────────────────────────────────────────────────


def _find_safe_split_index(messages: list[ModelMessage], initial_split_idx: int) -> int:
    """Adjust split index so we never sever a tool_call from its tool_return."""
    if initial_split_idx <= 1:
        return initial_split_idx

    protected_tool_return_ids: set[str] = set()
    for msg in messages[initial_split_idx:]:
        for part in getattr(msg, "parts", []) or []:
            if _classify_tool_part(part) == "return":
                tcid = getattr(part, "tool_call_id", None)
                if tcid:
                    protected_tool_return_ids.add(tcid)

    if not protected_tool_return_ids:
        return initial_split_idx

    adjusted_idx = initial_split_idx
    # Walk backwards; never cross the system message at index 0.
    for i in range(initial_split_idx - 1, 0, -1):
        msg = messages[i]
        has_match = False
        for part in getattr(msg, "parts", []) or []:
            if _classify_tool_part(part) == "call":
                tcid = getattr(part, "tool_call_id", None)
                if tcid and tcid in protected_tool_return_ids:
                    has_match = True
                    break
        if has_match:
            adjusted_idx = i
        else:
            # Tool calls and their returns are adjacent — first miss ends it.
            break

    return adjusted_idx


def split_for_protected_summarization(
    messages: list[ModelMessage],
    protected_tokens: int,
    model_name: str | None = None,
    cache: CompactionCache | None = None,
) -> tuple[list[ModelMessage], list[ModelMessage]]:
    """Split messages into (to_summarize, protected) groups.

    The system message (index 0) is always protected. Starting from the most
    recent message, we accumulate messages into the protected zone until we
    hit ``protected_tokens``. Everything in-between becomes summarization
    fodder. The split point is adjusted to keep tool_call/tool_return pairs
    together.
    """
    if len(messages) <= 1:
        return [], messages

    _tok = cache.estimate_tokens if cache else estimate_tokens_for_message

    system_message = messages[0]
    system_tokens = _tok(system_message, model_name)

    protected_messages: list[ModelMessage] = []
    running_tokens = system_tokens

    for i in range(len(messages) - 1, 0, -1):
        msg_tokens = _tok(messages[i], model_name)
        if running_tokens + msg_tokens > protected_tokens:
            break
        protected_messages.append(messages[i])
        running_tokens += msg_tokens

    protected_messages.reverse()
    protected_messages.insert(0, system_message)

    protected_start_idx = max(1, len(messages) - (len(protected_messages) - 1))
    protected_start_idx = _find_safe_split_index(messages, protected_start_idx)
    messages_to_summarize = messages[1:protected_start_idx]

    emit_info(
        f"🔒 Protecting {len(protected_messages)} recent messages "
        f"({running_tokens} tokens, limit: {protected_tokens})"
    )
    emit_info(f"📝 Summarizing {len(messages_to_summarize)} older messages")

    return messages_to_summarize, protected_messages


# ── Thinking-part cleanup ──────────────────────────────────────────────


def _strip_empty_thinking_parts(
    messages: list[ModelMessage],
) -> tuple[list[ModelMessage], int]:
    """Remove empty ThinkingParts; drop messages rendered empty by removal."""
    cleaned: list[ModelMessage] = []
    filtered_count = 0
    for msg in messages:
        parts = list(msg.parts)
        if (
            len(parts) == 1
            and isinstance(parts[0], ThinkingPart)
            and not parts[0].content
        ):
            filtered_count += 1
            continue
        if any(isinstance(p, ThinkingPart) and not p.content for p in parts):
            msg = dataclasses.replace(
                msg,
                parts=[
                    p
                    for p in parts
                    if not (isinstance(p, ThinkingPart) and not p.content)
                ],
            )
            if not msg.parts:
                filtered_count += 1
                continue
        cleaned.append(msg)
    return cleaned, filtered_count


# ── Protected-fact integration ─────────────────────────────────────────


def _inject_protected_facts_into_system(
    messages: list[ModelMessage],
) -> list[ModelMessage]:
    """Append protected facts to the system prompt (message at index 0).

    Returns the messages list — a shallow copy if facts were injected
    (with a new SystemModelMessage at index 0), or the original list
    unchanged if no injection occurred.  The input list is never
    mutated in place.
    """
    if not messages:
        return messages

    system_msg = messages[0]
    if not isinstance(system_msg, ModelRequest):
        return messages

    try:
        from code_muse.plugins.task_context.protected_facts import (
            get_protected_fact_manager,
        )

        mgr = get_protected_fact_manager()
        fact_block = mgr.get_prompt_block()
        if not fact_block:
            return messages

        # Append to the first part with string content — immutably.
        # Build new part/message/list objects so the caller's shared
        # history is never mutated in place.
        for idx, part in enumerate(system_msg.parts):
            if hasattr(part, "content") and isinstance(part.content, str):
                if "## Protected User Facts" not in part.content:
                    new_part = dataclasses.replace(
                        part, content=part.content + fact_block
                    )
                    new_parts = list(system_msg.parts)
                    new_parts[idx] = new_part
                    new_messages = list(messages)  # shallow copy
                    new_messages[0] = dataclasses.replace(system_msg, parts=new_parts)
                    return new_messages
                return messages
    except Exception:
        _log = _logging.getLogger(__name__)
        _log.debug("Failed to inject protected facts", exc_info=True)

    return messages


def _is_protected_message(
    message: ModelMessage, fact_manager: Any | None = None
) -> bool:
    """Check if a message contains protected fact content."""
    if fact_manager is None:
        try:
            from code_muse.plugins.task_context.protected_facts import (
                get_protected_fact_manager,
            )

            fact_manager = get_protected_fact_manager()
        except Exception:
            return False

    if not fact_manager.get_all_facts():
        return False

    text = _extract_message_text(message)
    for fact in fact_manager.get_all_facts():
        if fact.content.lower() in text.lower():
            return True
    return False


def _extract_message_text(message: ModelMessage) -> str:
    """Extract all text from a message for content matching."""
    parts = getattr(message, "parts", []) or []
    texts: list[str] = []
    for part in parts:
        content = getattr(part, "content", None)
        if isinstance(content, str):
            texts.append(content)
        elif isinstance(content, list):
            for item in content:
                if isinstance(item, str):
                    texts.append(item)
    return " ".join(texts)


# ── Extractive (heuristic) compaction ─────────────────────────────────

# Number of recent turns whose tool results are kept in full.
_EXTRACTIVE_KEEP_RECENT_TURNS = 3

# Max length of first-100-chars prefix for old tool results.
_EXTRACTIVE_HEAD_CHARS = 100


def extractive_compact(
    messages: list[ModelMessage],
    target_tokens: int,
    model_name: str | None = None,
    cache: CompactionCache | None = None,
) -> list[ModelMessage]:
    """Cheap heuristic compaction: keep decisions, file paths, errors;
    drop verbose tool output.

    Extracts key content from messages without LLM calls:
    - Keeps all ModelRequest messages (user turns)
    - Keeps the last N tool results in full
    - For older tool results: keep only the first line + error indicators
    - Keeps all TextPart content (agent reasoning)
    - Keeps all ThinkingPart content
    - Drops intermediate tool results older than the last 3 turns

    Returns the compacted message list. If the result is already under
    ``target_tokens``, returns the original list unchanged.
    """
    if not messages:
        return messages

    _tok = cache.estimate_tokens if cache else estimate_tokens_for_message
    current_tokens = (
        cache.sum_tokens(messages, model_name)
        if cache
        else sum(_tok(m, model_name) for m in messages)
    )

    # Fast path: already within budget
    if current_tokens <= target_tokens:
        return messages

    # Phase 1: identify protected (recent) tool result IDs.
    # Walk messages in reverse; the last N tool-result-bearing ModelRequest
    # messages are "protected" — their ToolReturnParts are kept in full.
    protected_tool_ids: set[str] = set()
    recent_turns_seen = 0
    for i in range(len(messages) - 1, -1, -1):
        msg = messages[i]
        if not isinstance(msg, ModelRequest):
            continue
        tool_returns = [p for p in msg.parts if isinstance(p, ToolReturnPart)]
        if tool_returns:
            recent_turns_seen += 1
            if recent_turns_seen <= _EXTRACTIVE_KEEP_RECENT_TURNS:
                for part in tool_returns:
                    protected_tool_ids.add(part.tool_call_id)
            else:
                break  # older than the keep window — stop collecting

    # Phase 2: rebuild messages with truncated old tool results
    result: list[ModelMessage] = []
    for msg in messages:
        # ModelResponse messages: keep all (TextPart + ThinkingPart = agent reasoning)
        if isinstance(msg, ModelResponse):
            result.append(msg)
            continue

        if not isinstance(msg, ModelRequest):
            result.append(msg)
            continue

        # Check if this ModelRequest has any old tool results to truncate
        has_old_tool_result = False
        new_parts: list = []
        for part in msg.parts:
            if (
                isinstance(part, ToolReturnPart)
                and part.tool_call_id not in protected_tool_ids
            ):
                has_old_tool_result = True
                truncated_content = _truncate_tool_content(part.content)
                new_parts.append(dataclasses.replace(part, content=truncated_content))
            else:
                new_parts.append(part)

        if has_old_tool_result:
            result.append(ModelRequest(parts=new_parts))
        else:
            result.append(msg)

    # Phase 3: if still over budget, drop old tool-result-only messages
    # entirely (keeping at least the last _EXTRACTIVE_KEEP_RECENT_TURNS turns)
    new_tokens = (
        cache.sum_tokens(result, model_name)
        if cache
        else sum(_tok(m, model_name) for m in result)
    )
    if new_tokens <= target_tokens:
        return result

    # Aggressive pass: remove old tool-result-only ModelRequest messages
    # whose tool results were already truncated
    aggressive: list[ModelMessage] = []
    # Always keep first message (system prompt) and messages in the recent window
    recent_msg_indices: set[int] = set()
    recent_count = 0
    for i in range(len(result) - 1, 0, -1):  # skip index 0 (system)
        msg = result[i]
        if isinstance(msg, ModelRequest) and any(
            isinstance(p, ToolReturnPart) and p.tool_call_id in protected_tool_ids
            for p in msg.parts
        ):
            recent_count += 1
            if recent_count <= _EXTRACTIVE_KEEP_RECENT_TURNS:
                recent_msg_indices.add(i)
            else:
                break

    for i, msg in enumerate(result):
        if i == 0:
            aggressive.append(msg)
            continue
        if i in recent_msg_indices:
            aggressive.append(msg)
            continue
        # Drop old tool-result-only messages (no user text parts)
        if isinstance(msg, ModelRequest):
            has_user_content = any(isinstance(p, TextPart) for p in msg.parts)
            has_only_old_tool_results = all(
                isinstance(p, ToolReturnPart)
                and p.tool_call_id not in protected_tool_ids
                for p in msg.parts
            )
            if has_only_old_tool_results and not has_user_content:
                continue  # drop this old tool-result-only message
        aggressive.append(msg)

    return aggressive


def _truncate_tool_content(content: str) -> str:
    """Truncate tool result content: first 100 chars + last line if different.

    For multi-line content: keep first 100 chars + '\n...' + last line.
    For single-line content > 100 chars: keep first 100 chars + '...'.
    For content ≤ 100 chars: keep as-is.
    """
    if not isinstance(content, str):
        content = str(content)

    if len(content) <= _EXTRACTIVE_HEAD_CHARS:
        return content

    lines = content.split("\n")
    head = content[:_EXTRACTIVE_HEAD_CHARS]

    # Single line: just truncate with ellipsis
    if len(lines) <= 1:
        return f"{head}..."

    last_line = lines[-1].strip()
    # If the last line is already within the head, just ellipsize
    if not last_line or last_line in head:
        return f"{head}\n..."

    return f"{head}\n...\n{last_line}"
