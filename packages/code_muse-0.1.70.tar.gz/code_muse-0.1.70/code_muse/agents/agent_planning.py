"""Planning Agent - Breaks down complex tasks into actionable steps
with strategic roadmapping.

Provides first-class Plan and PlanStep dataclasses so that plans are
structured objects, not just blobs of text.
"""

import dataclasses
import time

from code_muse.config import get_agent_name

from .base_agent import BaseAgent
from .prompts import AUTONOMY_BASE_PROMPT as _AUTONOMY_BASE_PROMPT

# ---------------------------------------------------------------------------
# Structured plan dataclasses
# ---------------------------------------------------------------------------


@dataclasses.dataclass
class PlanStep:
    """A single step in a structured plan."""

    step_number: int
    description: str
    verification: str  # How to verify this step is complete
    status: str = "pending"  # pending | in_progress | done | blocked
    files: list[str] = dataclasses.field(default_factory=list)
    agent: str = ""  # Which agent should handle this


@dataclasses.dataclass
class Plan:
    """First-class structured plan object."""

    title: str
    objective: str
    steps: list[PlanStep]
    risks: list[str] = dataclasses.field(default_factory=list)
    created_at: float = dataclasses.field(default_factory=time.time)
    context_files: list[str] = dataclasses.field(default_factory=list)


class PlanningAgent(BaseAgent):
    """Planning Agent - Analyzes requirements and creates detailed execution plans."""

    _agent_name = "planning-agent"

    @property
    def name(self) -> str:
        return "planning-agent"

    @property
    def display_name(self) -> str:
        return "Planning Agent 📋"

    @property
    def description(self) -> str:
        return (
            "Breaks down complex coding tasks into clear, actionable steps. "
            "Analyzes project structure, identifies dependencies, "
            "and creates execution roadmaps."
        )

    def get_available_tools(self) -> list[str]:
        """Get the list of tools available to the Planning Agent."""
        return [
            "list_files",
            "read_file",
            "grep",
            "ask_user_question",
            "list_agents",
            "invoke_agent",
            "list_or_search_skills",
        ]

    def get_system_prompt(self) -> str:
        """Get the Planning Agent's system prompt — autonomy base + planning overlay."""
        agent_name = get_agent_name()
        return (
            _AUTONOMY_BASE_PROMPT
            + "\n\n"
            + _PLANNING_OVERLAY.format(agent_name=agent_name)
        )


# The autonomy base prompt is imported from .prompts (single source of truth).


# ---------------------------------------------------------------------------
# Planning overlay — strategic roadmapping mode.
# ---------------------------------------------------------------------------

_PLANNING_OVERLAY = """\
## Planning Mode

You are {agent_name} in Planning Mode. Your job is to create clear, executable \
roadmaps and coordinate execution when the user has asked for implementation or \
explicitly approved a plan.

## Planning autonomy

- Use read-only exploration before producing a serious project plan: `list_files`, \
`read_file`, `grep`, `list_agents`, and relevant skill discovery.
- Read-only exploration does not require separate user approval.
- If the user asked only for a plan, produce the plan and ask whether to execute it.
- If the user asked to implement, fix, execute, proceed, start, or coordinate, treat \
that as approval to coordinate implementation after briefly presenting the plan.
- Do not start write/destructive actions or invoke implementation agents when the \
user requested planning only.
- Ask before destructive, irreversible, credential-related, dependency-installing, \
production-data, network-impacting, or long-running/background actions.

## Planning process

1. Inspect repository structure, key config, docs, and existing conventions.
2. Identify project type, architecture, constraints, likely test commands, and \
relevant files.
3. Break the request into sequential and parallelizable tasks.
4. Identify files/components likely to change.
5. Identify risks, assumptions, unknowns, dependencies, and validation strategy.
6. Recommend specialist agents only where they add value.
7. If approved or already asked to execute, coordinate implementation and \
integrate results.

## Delegation routing

You are a PLANNING agent and do NOT have file editing tools. You MUST delegate \
implementation to a coding agent via `invoke_agent`. Follow this routing:

1. **Standard coding implementation** (editing files, running tests, fixing bugs, \
adding features) → use **Muse** (`"muse"`). Muse is the default creative coding \
agent with full file editing, shell, and browser tools.

2. **Creating reusable tools** (a new persistent Python function in the Universal \
Constructor registry) → use **Helios** (`"helios"`). Helios is the Universal \
Constructor for creating durable reusable tools.

3. **Code review & quality checks** → use **Code Critic** (`"code-critic"`).

4. **Web UI testing & browser automation** → use **QA Iris** (`"qa-iris"`).

5. **Anything else not covered above** → default to **Muse** (`"muse"`).

Don't overthink routing. For almost all standard coding tasks, Muse is the right choice.

## Plan output format

You MUST produce plans using the following structured markdown format. Each \
section is mandatory — the system parses this structure to build first-class Plan \
objects.

## Plan: <title>

**Objective:** one sentence.

**Context files:** comma-separated list of relevant files (or "none").

### Step 1
- **Description:** what to do.
- **Verification:** how to confirm this step is complete.
- **Files:** files involved (comma-separated, or "none").
- **Agent:** which agent should handle this (e.g. muse, helios, code-critic), \
or "planning-agent" if no delegation needed.

### Step 2
- **Description:** …
- **Verification:** …
- **Files:** …
- **Agent:** …

(Repeat for each step.)

**Risks:**
- risk 1
- risk 2

**Validation strategy:** commands or checks to run.

**Next action:**
- If planning only: ask for approval to execute.
- If implementation was requested: proceed to coordinate execution without \
asking again, unless a high-risk action is required."""
