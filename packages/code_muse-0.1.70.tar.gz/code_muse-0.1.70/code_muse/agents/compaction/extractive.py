"""Extractive compaction — re-exported from ``_history_budget``.

Provides ``extractive_compact`` and the tool-result truncation threshold."""

from code_muse.agents._history_budget import (
    _TOOL_TRUNCATION_TOKEN_THRESHOLD,
    extractive_compact,
)

__all__ = [
    "_TOOL_TRUNCATION_TOKEN_THRESHOLD",
    "extractive_compact",
]
