"""Unified compaction entrypoint (compact, compact_with_tool_truncation)."""

import logging
from contextlib import suppress
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from code_muse.agents._protocol import AgentProtocol

from pydantic_ai.messages import ModelMessage

from code_muse.agents._history import (
    CompactionCache,
    filter_huge_messages,
    has_pending_tool_calls,
    hash_message,
)
from code_muse.agents._history_budget import (
    _TOOL_TRUNCATION_TOKEN_THRESHOLD,
    _inject_protected_facts_into_system,
    extractive_compact,
)
from code_muse.agents.compaction.handoff import context_handoff
from code_muse.agents.compaction.summarize import summarize
from code_muse.agents.compaction.truncate import (
    _truncate_tool_result_content,
    _truncate_with_dropped,
)
from code_muse.config import (
    get_compaction_strategy,
    get_compaction_threshold,
    get_max_messages_hard_cap,
    get_proactive_truncation_message_count,
    get_protected_token_count,
)
from code_muse.messaging import emit_info, emit_warning
from code_muse.messaging.spinner import SpinnerBase, update_spinner_context

_log = logging.getLogger(__name__)


# ── Compaction path logging ───────────────────────────────────────────


def _log_compaction_path(
    path: str,
    before: list[ModelMessage],
    after: list[ModelMessage],
    model_max: int,
    total_tokens: int,
    cache: CompactionCache | None = None,
    model_name: str | None = None,
) -> None:
    """Log which compaction path was taken and its effect."""
    proportion = total_tokens / model_max if model_max else 0.0
    _log.info(
        "Compaction path=%s: %d→%d messages, %d/%d tokens (%.1f%%)",
        path,
        len(before),
        len(after),
        total_tokens,
        model_max,
        proportion * 100,
    )
    emit_info(
        f"🔧 Compaction ({path}): {len(before)}→{len(after)} msgs, "
        f"{total_tokens}/{model_max} tokens ({proportion:.0%})"
    )


# ── Unified compaction entrypoint ──────────────────────────────────────


def compact(
    agent: AgentProtocol | Any | None,
    messages: list[ModelMessage],
    model_max: int,
    context_overhead: int,
    cache: CompactionCache | None = None,
) -> tuple[list[ModelMessage], list[ModelMessage], int]:
    """Unified compaction entrypoint. Replaces ``message_history_processor``.

    Args:
        agent: The owning agent. Used to resolve the active model name so
            token estimates can apply per-model calibration multipliers.
        messages: Current message history (already accumulated by the caller).
        model_max: Effective model context window in tokens.
        context_overhead: Estimated overhead for system prompt + tool schemas.
        cache: Optional pre-warmed CompactionCache to reuse. A fresh one
            is created if not provided (backward-compatible).

    Returns:
        ``(new_messages, dropped_messages, final_total_tokens)``.
        ``final_total_tokens`` includes ``context_overhead``.
    """
    # Resolve model name once so all downstream estimators apply the same
    # per-model calibration multiplier.
    model_name: str | None = None
    if agent is not None:
        try:
            model_name = agent.get_model_name()
        except Exception:
            model_name = None

    # PERF-04: create a per-compaction cache to avoid repeated hash/token
    # computations on the same message objects within this invocation.
    if cache is None:
        cache = CompactionCache()

    message_tokens = cache.sum_tokens(messages, model_name)
    total_tokens = message_tokens + context_overhead
    proportion_used = total_tokens / model_max if model_max else 0.0

    context_summary = SpinnerBase.format_context_info(
        total_tokens, model_max, proportion_used
    )
    update_spinner_context(context_summary)

    # Emit user-visible context warnings
    with suppress(Exception):
        from code_muse.plugins.task_context.context_status import (
            check_and_emit_context_warnings,
        )

        check_and_emit_context_warnings(
            usage_pct=proportion_used,
            budget_tokens=model_max,
            tokens_used=total_tokens,
            model_name=model_name,
            message_count=len(messages),
            hard_cap=get_max_messages_hard_cap(model_max=model_max),
        )

    # Replace long pasted documents with reference stubs (before compaction)
    with suppress(Exception):
        from code_muse.plugins.task_context.document_store import (
            replace_long_documents_in_history,
        )

        messages = replace_long_documents_in_history(messages)

    # Inject protected facts into system message if available.
    # Returns a new list if injection occurred; original list if not.
    with suppress(Exception):
        messages = _inject_protected_facts_into_system(messages)

    threshold = get_compaction_threshold()
    # Compaction only triggers when current_tokens >= 90% of true model
    # context.  No artificial threshold reduction for any model size — the
    # 64k floor in get_model_context_length() ensures model_max is always a
    # true, meaningful context window.
    if proportion_used <= threshold:
        return messages, [], total_tokens

    strategy = get_compaction_strategy()

    protected_tokens = get_protected_token_count(
        model_name=model_name, overhead=context_overhead
    )
    filtered = filter_huge_messages(messages, model_name, cache=cache)

    # ── Cheap-first compaction pipeline ────────────────────────────
    # Stage 1: Extractive (heuristic) — no LLM, no token cost.
    #   Pulls decisions, file paths, errors from messages; drops verbose
    #   tool output from old turns.
    #
    # Use the effective history budget (which accounts for overhead +
    # output reservation) instead of raw model_max * threshold.
    # This avoids setting an extractive target that can never be met
    # because overhead was not subtracted.
    from code_muse.config.models import compute_effective_history_budget

    effective_budget = compute_effective_history_budget(
        model_max, overhead=context_overhead, model_name=model_name
    )
    extractive_target = max(int(effective_budget * threshold), protected_tokens)
    after_extractive = extractive_compact(
        filtered, extractive_target, model_name, cache=cache
    )
    extractive_tokens = (
        cache.sum_tokens(after_extractive, model_name) + context_overhead
    )
    extractive_proportion = extractive_tokens / model_max if model_max else 0.0

    if extractive_proportion <= threshold:
        _log_compaction_path(
            "extractive",
            filtered,
            after_extractive,
            model_max,
            extractive_tokens,
            cache,
            model_name,
        )
        # Figure out which messages were dropped for hash bookkeeping
        _hash = cache.hash_message if cache else hash_message
        after_hashes = {_hash(m) for m in after_extractive}
        dropped = [m for m in filtered if _hash(m) not in after_hashes]
        return after_extractive, dropped, extractive_tokens

    # Stage 2: Structural truncation — no LLM, dedup + collapse + age-based.
    after_structural = _truncate_tool_result_content(after_extractive)
    structural_tokens = (
        cache.sum_tokens(after_structural, model_name) + context_overhead
    )
    structural_proportion = structural_tokens / model_max if model_max else 0.0

    if structural_proportion <= threshold:
        _log_compaction_path(
            "structural",
            filtered,
            after_structural,
            model_max,
            structural_tokens,
            cache,
            model_name,
        )
        _hash = cache.hash_message if cache else hash_message
        after_hashes = {_hash(m) for m in after_structural}
        dropped = [m for m in filtered if _hash(m) not in after_hashes]
        return after_structural, dropped, structural_tokens

    # Stage 2.5: Context handoff — session reset with state injection.
    #
    # When cheap compaction (extractive + structural) fails to bring usage
    # below threshold, context_handoff is the PRIMARY escape path — not a
    # conditional bypass.  It replaces the destructive infinite-summarization
    # loop with a clean state handoff: ≤200-word summary + protected tail,
    # giving the agent a fresh context window with full state continuity.
    #
    # LLM summarization (Stage 3) is retained as a LAST-RESORT fallback
    # only if the handoff somehow fails to reduce message count.
    handoff_result, handoff_dropped = context_handoff(
        agent, after_structural, model_max, context_overhead
    )
    if len(handoff_result) < len(after_structural):
        handoff_tokens = cache.sum_tokens(handoff_result, model_name) + context_overhead
        _log_compaction_path(
            "context_handoff",
            filtered,
            handoff_result,
            model_max,
            handoff_tokens,
            cache,
            model_name,
        )
        _hash = cache.hash_message if cache else hash_message
        after_hashes = {_hash(m) for m in handoff_result}
        dropped = [m for m in filtered if _hash(m) not in after_hashes]
        return handoff_result, dropped, handoff_tokens
    # Handoff didn't reduce messages — fall through to Stage 3.

    # Stage 3: LAST RESORT — LLM summarization or hard truncation.
    # This only runs when context_handoff (Stage 2.5) also failed to
    # reduce message count.  In normal operation, handoff should always
    # succeed and this path is rarely reached.
    # The authoritative prune_interrupted_tool_calls() runs once at the
    # end of the history processor, so any orphaned tool_call / tool_return
    # pairs (from cancelled runs, Ctrl-C interrupts, etc.) are stripped out
    # there. The check below only trips on a genuine mid-execution state,
    # which shouldn't happen when the history_processor is invoked — but we
    # keep it as a defensive safety net.
    #
    # Previously this check ran on the raw `messages` list, which meant a
    # single orphaned tool_call (e.g., from one cancelled command weeks ago)
    # would defer summarization forever, letting history grow unbounded.
    if strategy == "summarization" and has_pending_tool_calls(after_structural):
        emit_warning(
            "⚠️  Summarization deferred: pending tool call(s) detected "
            "after pruning orphans. Will retry on next invocation.",
            message_group="token_context_status",
        )
        return after_structural, [], structural_tokens

    if strategy == "truncation":
        result_messages, summarized_messages = _truncate_with_dropped(
            after_structural, protected_tokens, model_name, cache=cache
        )
        _log_compaction_path(
            "truncation",
            filtered,
            result_messages,
            model_max,
            cache.sum_tokens(result_messages, model_name) + context_overhead,
            cache,
            model_name,
        )
    else:
        # Route through the public summarize() so error handling, logging,
        # and any future instrumentation stay in one place (DRY).
        result_messages, summarized_messages = summarize(
            after_structural, protected_tokens, True, model_name, cache=cache
        )
        # If summarization failed gracefully (returned original messages
        # with nothing dropped), fall back to truncation for this cycle.
        # The user's strategy preference is preserved for the next cycle.
        if not summarized_messages:
            pre_truncate_count = len(after_structural)
            result_messages, summarized_messages = _truncate_with_dropped(
                after_structural, protected_tokens, model_name, cache=cache
            )
            dropped_count = pre_truncate_count - len(result_messages)
            _log_compaction_path(
                "summarization→truncation",
                filtered,
                result_messages,
                model_max,
                cache.sum_tokens(result_messages, model_name) + context_overhead,
                cache,
                model_name,
            )
            emit_warning(
                f"↪️  Summarization produced no compaction; "
                f"falling back to truncation: "
                f"{pre_truncate_count} → {len(result_messages)} messages "
                f"({dropped_count} dropped)",
                message_group="token_context_status",
            )
        else:
            _log_compaction_path(
                "summarization",
                filtered,
                result_messages,
                model_max,
                cache.sum_tokens(result_messages, model_name) + context_overhead,
                cache,
                model_name,
            )

    final_token_count = cache.sum_tokens(result_messages, model_name)
    final_summary = SpinnerBase.format_context_info(
        final_token_count,
        model_max,
        final_token_count / model_max if model_max else 0.0,
    )
    update_spinner_context(final_summary)

    # Reset warning flags after compaction so user gets alerted again if context refills
    with suppress(Exception):
        from code_muse.plugins.task_context.context_status import reset_warning_state

        reset_warning_state()

    final_total_tokens = final_token_count + context_overhead
    return result_messages, summarized_messages, final_total_tokens


# ── Enhanced compaction with tool-result truncation ────────────────────


def compact_with_tool_truncation(
    agent: AgentProtocol | Any | None,
    messages: list[ModelMessage],
    model_max: int,
    context_overhead: int,
) -> tuple[list[ModelMessage], list[ModelMessage], int]:
    """Enhanced compact() that first truncates old tool results,
    then runs normal compaction.

    Tool-result truncation runs when EITHER:
    - The message count is > 20, OR
    - Token usage already exceeds 50% of the context window.
    This ensures large tool results in short histories still get truncated.

    Returns: (new_messages, dropped_messages_for_hash_tracking)
    """
    # Decide whether tool-result truncation is worthwhile.
    # Skip only for very small histories that are also well within budget.
    model_name: str | None = None
    if agent is not None:
        try:
            model_name = agent.get_model_name()
        except Exception:
            model_name = None

    cache = CompactionCache()
    message_tokens = cache.sum_tokens(messages, model_name)
    proportion_used = (
        (message_tokens + context_overhead) / model_max if model_max else 0.0
    )
    needs_tool_truncation = (
        len(messages) > get_proactive_truncation_message_count()
        or proportion_used > _TOOL_TRUNCATION_TOKEN_THRESHOLD
    )
    if not needs_tool_truncation:
        return compact(agent, messages, model_max, context_overhead, cache=cache)

    # Step 1: Truncate old tool results (always safe, always reduces tokens)
    truncated = _truncate_tool_result_content(messages)

    # Step 2: Run existing compaction on the already-trimmed history
    # The existing compact() handles summarization or truncation if still over threshold
    return compact(agent, truncated, model_max, context_overhead, cache=cache)
