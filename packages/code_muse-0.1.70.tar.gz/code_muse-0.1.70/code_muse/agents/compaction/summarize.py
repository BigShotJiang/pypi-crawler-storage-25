"""Summarization-related compaction logic.

Provides ``summarize`` (the public entry point that swallows exceptions and
returns original messages on failure) and ``_run_summarization_core`` (the
inner implementation that propagates exceptions for callers that want to
handle failure themselves, e.g. fall back to truncation).

The summarization agent itself has no history processor. To protect it
from context overflow, ``_run_summarization_core`` applies a bounded-input
gate: if ``messages_to_summarize`` exceeds a safe token budget, older
messages are sliced off before the summarizer sees them.
"""

import logging as _logging

from pydantic_ai.messages import (
    ModelMessage,
    ModelRequest,
    TextPart,
)

from code_muse.agents._history import CompactionCache, estimate_tokens_for_message
from code_muse.agents._history_budget import (
    _SUMMARIZATION_INSTRUCTIONS,
    split_for_protected_summarization,
)
from code_muse.agents.compaction.truncate import _truncate_with_dropped
from code_muse.config.models import (
    compute_effective_history_budget,
    get_model_context_length,
)
from code_muse.messaging import emit_error, emit_warning

# ── Summarizer input budget ──────────────────────────────────────────
# The summarization agent has no history processor of its own, so we
# must bound the input it receives.  We use 60% of the model's effective
# budget as the summarizer input ceiling — generous enough for good
# summaries but well within the provider's context limit.
_SUMMARIZER_INPUT_FRACTION = 0.60


def _bound_summarizer_input(
    messages_to_summarize: list[ModelMessage],
    model_name: str | None,
    cache: CompactionCache | None,
) -> list[ModelMessage]:
    """Slice ``messages_to_summarize`` to a safe token budget.

    The summarization agent has no compaction of its own. Without this
    guard, handing 70-100+ messages to ``run_summarization_sync`` can
    overflow the summarizer's context window, causing silent failures
    or context-length errors.

    Strategy: compute a token ceiling from the effective history budget,
    then slice from the *end* (most recent messages first) to stay within
    the ceiling.  Older messages are dropped — they are the least useful
    for summarization anyway.
    """
    if not messages_to_summarize:
        return messages_to_summarize

    _tok = cache.estimate_tokens if cache else estimate_tokens_for_message
    total_tokens = (
        cache.sum_tokens(messages_to_summarize, model_name)
        if cache
        else sum(_tok(m, model_name) for m in messages_to_summarize)
    )

    # Derive the summarizer's input ceiling from the effective budget.
    # Falls back to a percentage of the model context if budget lookup
    # fails.
    try:
        model_ctx = get_model_context_length(model_name)
        effective = compute_effective_history_budget(model_ctx, 0, model_name)
        ceiling = max(4096, int(effective * _SUMMARIZER_INPUT_FRACTION))
    except Exception:
        ceiling = 65536  # safe default

    if total_tokens <= ceiling:
        return messages_to_summarize

    # Walk backwards, keeping messages until we hit the ceiling.
    kept: list[ModelMessage] = []
    running = 0
    for msg in reversed(messages_to_summarize):
        msg_tokens = _tok(msg, model_name)
        if running + msg_tokens > ceiling:
            break
        kept.append(msg)
        running += msg_tokens
    kept.reverse()

    dropped = len(messages_to_summarize) - len(kept)
    if dropped > 0:
        emit_warning(
            f"📋 Summarizer input bounded: dropped {dropped} oldest messages "
            f"({total_tokens} → {running} tokens) to fit summarizer window."
        )

    return kept


def _run_summarization_core(
    messages: list[ModelMessage],
    protected_tokens: int,
    with_protection: bool,
    model_name: str | None,
    cache: CompactionCache | None = None,
) -> tuple[list[ModelMessage], list[ModelMessage]]:
    """Inner summarization that propagates exceptions to the caller.

    Returns ``(compacted_messages, summarized_source_messages)`` or raises
    on summarization-agent failure. Use :func:`summarize` if you want the
    swallow-and-return-original behavior, or call this directly when you want
    to handle failure yourself (e.g. fall back to truncation).
    """
    if not messages:
        return [], []

    if with_protection:
        messages_to_summarize, protected_messages = split_for_protected_summarization(
            messages, protected_tokens, model_name, cache=cache
        )
    else:
        messages_to_summarize = messages[1:]
        protected_messages = messages[:1]

    system_message = messages[0]

    if not messages_to_summarize:
        return messages, []

    # Bound the summarizer's input to prevent context overflow.
    # The summarization agent has no history processor, so we must
    # ensure its input fits within a safe fraction of the model window.
    messages_to_summarize = _bound_summarizer_input(
        messages_to_summarize, model_name, cache
    )

    if not messages_to_summarize:
        return messages, []

    from code_muse.summarization_agent import run_summarization_sync

    new_messages = run_summarization_sync(
        _SUMMARIZATION_INSTRUCTIONS, message_history=messages_to_summarize
    )

    if not isinstance(new_messages, list):
        emit_warning(
            "Summarization agent returned non-list output;"
            " wrapping into message request"
        )
        new_messages = [ModelRequest([TextPart(str(new_messages))])]

    compacted: list[ModelMessage] = [system_message] + list(new_messages)
    compacted.extend(msg for msg in protected_messages if msg is not system_message)
    return compacted, messages_to_summarize


def _log_summarization_failure(error: Exception, fallback_note: str = "") -> None:
    """Single source of truth for summarization-failure user messaging."""
    error_type = type(error).__name__
    emit_error(f"Compaction failed: [{error_type}] {error}")
    from code_muse.summarization_agent import SummarizationError

    if isinstance(error, SummarizationError) and error.original_error:
        underlying = type(error.original_error).__name__
        suffix = f" {fallback_note}" if fallback_note else ""
        emit_warning(f"💡 Underlying error was {underlying}.{suffix}")
    elif fallback_note:
        emit_warning(fallback_note)


def summarize(
    messages: list[ModelMessage],
    protected_tokens: int,
    with_protection: bool = True,
    model_name: str | None = None,
    cache: CompactionCache | None = None,
) -> tuple[list[ModelMessage], list[ModelMessage]]:
    """Summarize older messages, preserving the protected recent tail.

    Returns ``(compacted_messages, summarized_source_messages)``. On failure
    we log a warning and return ``(messages, [])`` so the run continues.
    """
    try:
        result_messages, summarized_messages = _run_summarization_core(
            messages, protected_tokens, with_protection, model_name, cache=cache
        )

        # Validate summarization output
        try:
            from code_muse.summarization_agent import _validate_summary_fidelity

            validation = _validate_summary_fidelity(result_messages)
            if validation.retry_needed:
                _logging.getLogger(__name__).warning(
                    "Summarization validation failed: missing %d protected facts",
                    len(validation.preserved_facts_missing),
                )
                # Fall back to truncation if summarization dropped critical facts
                if validation.retry_needed:
                    result_messages, summarized_messages = messages, []
                    emit_warning(
                        "Summarization dropped protected facts — "
                        "falling back to truncation."
                    )
        except ImportError:
            pass

        return result_messages, summarized_messages
    except Exception as e:
        _log_summarization_failure(
            e,
            "Consider using '/set compaction_strategy=truncation' as a fallback.",
        )
        return messages, []


__all__ = [
    "_run_summarization_core",
    "_truncate_with_dropped",
    "summarize",
]
