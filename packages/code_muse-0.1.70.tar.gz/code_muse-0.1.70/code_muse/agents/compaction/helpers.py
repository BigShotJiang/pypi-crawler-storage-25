"""Helper functions — re-exported from ``_history`` and ``_history_budget``, plus local truncation utilities."""

from code_muse.agents._history import (
    filter_huge_messages,
    has_pending_tool_calls,
    hash_message,
    prune_interrupted_tool_calls,
)
from code_muse.agents._history_budget import _strip_empty_thinking_parts
from code_muse.agents.compaction.truncate import (
    _truncate_tool_result_content,
    truncate,
)

__all__ = [
    "_strip_empty_thinking_parts",
    "_truncate_tool_result_content",
    "filter_huge_messages",
    "has_pending_tool_calls",
    "hash_message",
    "prune_interrupted_tool_calls",
    "truncate",
]
