"""Compaction package — re-exports all public names for backward compatibility.

The implementation is split across submodules:

- ``cache``          — ``CompactionCache``
- ``helpers``        — hash_message, truncate, filter_huge_messages, etc.
- ``extractive``     — extractive_compact
- ``truncate``       — truncate, _truncate_with_dropped, _truncate_tool_result_content
- ``summarize``      — summarize, _run_summarization_core
- ``compact``        — compact(), compact_with_tool_truncation()
- ``handoff``        — generate_handoff_summary, context_handoff
- ``history_processor`` — make_history_processor()
"""

# Re-export all public names so that
#   from code_muse.agents.compaction import <name>
# works as the canonical import path.

from code_muse.agents.compaction.cache import CompactionCache
from code_muse.agents.compaction.compact import (
    compact,
    compact_with_tool_truncation,
)
from code_muse.agents.compaction.extractive import (
    _TOOL_TRUNCATION_TOKEN_THRESHOLD,
    extractive_compact,
)
from code_muse.agents.compaction.handoff import (
    context_handoff,
    generate_handoff_summary,
)
from code_muse.agents.compaction.helpers import (
    _strip_empty_thinking_parts,
    _truncate_tool_result_content,
    filter_huge_messages,
    has_pending_tool_calls,
    hash_message,
    prune_interrupted_tool_calls,
    truncate,
)
from code_muse.agents.compaction.history_processor import make_history_processor
from code_muse.agents.compaction.summarize import (
    _run_summarization_core,
    summarize,
)
from code_muse.agents.compaction.truncate import _truncate_with_dropped

__all__ = [
    # cache
    "CompactionCache",
    # compact
    "compact",
    "compact_with_tool_truncation",
    # extractive
    "extractive_compact",
    "_TOOL_TRUNCATION_TOKEN_THRESHOLD",
    # handoff
    "context_handoff",
    "generate_handoff_summary",
    # helpers
    "filter_huge_messages",
    "has_pending_tool_calls",
    "hash_message",
    "prune_interrupted_tool_calls",
    "truncate",
    "_strip_empty_thinking_parts",
    "_truncate_tool_result_content",
    # history_processor
    "make_history_processor",
    # truncate
    "_truncate_with_dropped",
    # summarize
    "summarize",
    "_run_summarization_core",
]
