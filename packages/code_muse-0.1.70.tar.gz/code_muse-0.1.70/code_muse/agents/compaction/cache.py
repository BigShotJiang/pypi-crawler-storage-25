"""CompactionCache — re-exported from ``_history`` for package convenience."""

from code_muse.agents._history import CompactionCache

__all__ = ["CompactionCache"]
