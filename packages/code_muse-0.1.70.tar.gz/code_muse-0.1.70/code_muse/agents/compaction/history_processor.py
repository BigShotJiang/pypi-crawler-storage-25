"""History processor closure (make_history_processor).

Extracted from ``_compaction.py`` to stay under the 600-line cap.
"""

from collections.abc import Callable
from contextlib import suppress
from typing import Any

from pydantic_ai.messages import ModelMessage, ModelResponse

from code_muse.agents._history import (
    CompactionCache,
    hash_message,
    prune_interrupted_tool_calls,
)
from code_muse.agents._history_budget import _strip_empty_thinking_parts
from code_muse.agents.compaction.compact import compact_with_tool_truncation
from code_muse.agents.compaction.handoff import context_handoff
from code_muse.agents.compaction.truncate import (
    _truncate_tool_result_content,
    truncate,
)
from code_muse.callbacks import (
    on_message_history_processor_end,
    on_message_history_processor_start,
)
from code_muse.messaging import emit_warning

# ── History processor closure ──────────────────────────────────────────


def make_history_processor(agent: Any) -> Callable[..., list[ModelMessage]]:
    """Build the pydantic-ai ``history_processors`` callback for ``agent``.

    The returned closure:
      1. Fires ``on_message_history_processor_start``.
      2. Merges any incoming messages not already in ``agent._message_history``
         (preserving the last-message regardless of compacted-hash collisions).
      3. Runs ``compact_with_tool_truncation(...)`` if we're over threshold —
         truncates older tool-result content first, then falls through to compact().
      4. Records dropped-message hashes in ``agent._compacted_message_hashes``.
      5. Strips empty ThinkingParts.
      6. Trims trailing ModelResponse messages so history ends with a ModelRequest.
      7. Fires ``on_message_history_processor_end``.

    Agent contract (Phase 3 will enforce on ``BaseAgent``):
      - ``agent._message_history: list``
      - ``agent._compacted_message_hashes: set``
      - ``agent._get_model_context_length() -> int``
      - ``agent._estimate_context_overhead() -> int``
      - ``agent.name`` / ``agent.session_id`` (optional)
    """

    def history_processor(messages: list[ModelMessage]) -> list[ModelMessage]:
        # pydantic-ai picks 1-arg vs 2-arg processor by inspecting the first
        # parameter's type annotation (must be ``RunContext`` for 2-arg form).
        # We don't need ctx, so we use the 1-arg form.
        history: list[ModelMessage] = agent._message_history
        compacted_hashes: set[int] = agent._compacted_message_hashes

        on_message_history_processor_start(
            agent_name=getattr(agent, "name", None),
            session_id=getattr(agent, "session_id", None),
            message_history=history,
            incoming_messages=list(messages),
        )

        existing_hashes = {hash_message(m) for m in history}
        messages_added = 0
        last_idx = len(messages) - 1
        for i, msg in enumerate(messages):
            h = hash_message(msg)
            if h in existing_hashes:
                continue
            # Always keep the last (newest) message, even if its hash collides
            # with a previously compacted one — short prompts like "yes"/"1"
            # can collide and get silently dropped otherwise.
            if i == last_idx or h not in compacted_hashes:
                history.append(msg)
                messages_added += 1

        # ── Proactive tool-result truncation ──────────────────────────────
        # If history is already long, pre-truncate tool results before the
        # full compaction pipeline evaluates. This keeps verbose tool outputs
        # from bloating the extractive/structural passes.
        # Threshold 15: median message count where tool-result bloat becomes
        # the dominant cost factor; empirically derived from typical sessions.
        # _truncate_tool_result_content is idempotent — a second call in
        # compact_with_tool_truncation is a no-op on already-truncated entries.
        _PROACTIVE_TRUNCATION_MSG_THRESHOLD = 15

        if len(history) > _PROACTIVE_TRUNCATION_MSG_THRESHOLD:
            history = _truncate_tool_result_content(history)

        new_history, dropped, post_compact_tokens = compact_with_tool_truncation(
            agent,
            history,
            agent._get_model_context_length(),
            agent._estimate_context_overhead(),
        )
        agent._message_history = new_history
        for m in dropped:
            compacted_hashes.add(hash_message(m))

        cleaned, filtered_count = _strip_empty_thinking_parts(agent._message_history)

        # Ensure history ends with a ModelRequest — otherwise Anthropic etc.
        # reject it with a "prefill" error.
        while cleaned and isinstance(cleaned[-1], ModelResponse):
            cleaned.pop()

        # Always prune orphaned tool_call/tool_return pairs that may have
        # been created by truncate() during compaction. The model REQUIRES
        # valid tool call pairs — missing returns or stray calls cause it
        # to produce empty responses.
        cleaned = prune_interrupted_tool_calls(cleaned)

        agent._message_history = cleaned

        # PRE-SEND SIZE GATE: Final safety check — guarantees the request we
        # send NEVER exceeds a safe fraction of the model context. Reserves
        # room for the model's response (output tokens are counted by the
        # provider against the same budget on most APIs).
        #
        # Target: input tokens + overhead ≤ 80% of model_max
        # (leaves ~20% headroom for response generation + estimation drift)
        model_max = agent._get_model_context_length()
        overhead = agent._estimate_context_overhead()
        cache_g = CompactionCache()
        model_name_g: str | None = None
        with suppress(Exception):
            model_name_g = agent.get_model_name()

        SAFE_FRACTION = 0.80

        # Reuse token count from compact when messages weren't modified
        # by strip/prune steps; recompute only if they were.
        if cleaned is new_history and len(cleaned) == len(new_history):
            total = post_compact_tokens
        else:
            total = cache_g.sum_tokens(cleaned, model_name_g) + overhead
        if total > int(model_max * SAFE_FRACTION) and len(cleaned) > 5:
            handoff_result, handoff_dropped = context_handoff(
                agent, cleaned, model_max, overhead
            )
            if len(handoff_result) < len(cleaned):
                for m in handoff_dropped:
                    compacted_hashes.add(hash_message(m))
                cleaned = prune_interrupted_tool_calls(handoff_result)
                cache_g = CompactionCache()

        # Loop: each pass cuts the budget more aggressively if still over.
        # Most cases resolve in one pass; the loop is defense-in-depth for
        # pathological cases (e.g. system prompt itself dominating budget).
        for attempt in range(4):
            current_tokens = cache_g.sum_tokens(cleaned, model_name_g)
            total = current_tokens + overhead
            if total <= int(model_max * SAFE_FRACTION):
                break
            if len(cleaned) <= 2:
                # Already as small as possible — give up; downstream
                # error handling (emergency compact + retry) will catch it.
                emit_warning(
                    f"⚠️  Pre-send gate: cannot shrink further "
                    f"({total}/{model_max} tokens, {len(cleaned)} msgs)."
                )
                break

            # Aggressively truncate to safe_input_tokens budget,
            # shrinking each pass.
            budget_fraction = SAFE_FRACTION / (attempt + 2)
            target_protected = max(
                1000,
                int(model_max * budget_fraction) - overhead,
            )
            cleaned = truncate(cleaned, target_protected, model_name_g, cache=cache_g)
            cleaned = prune_interrupted_tool_calls(cleaned)
            # Re-create cache because message identities may have changed.
            cache_g = CompactionCache()
            emit_warning(
                f"⚠️  Pre-send gate (pass {attempt + 1}): "
                f"{total}/{model_max} tokens too large; "
                f"truncating to {target_protected} protected tokens."
            )

        # Safety: ensure we didn't truncate away all user messages
        if len(cleaned) <= 1 and len(agent._message_history) > 1:
            emit_warning(
                "⚠️  Pre-send gate left only system prompt; "
                "restoring original history to prevent empty input."
            )
            cleaned = agent._message_history

        agent._message_history = cleaned

        on_message_history_processor_end(
            agent_name=getattr(agent, "name", None),
            session_id=getattr(agent, "session_id", None),
            message_history=list(cleaned),
            messages_added=messages_added,
            messages_filtered=len(messages) - messages_added + filtered_count,
        )

        return cleaned

    return history_processor
