"""Truncation-related compaction logic.

Provides ``truncate`` (the core drop-middle-messages strategy),
``_truncate_with_dropped`` (shared by ``compact`` for hash bookkeeping),
and ``_truncate_tool_result_content`` (replace old tool results with
truncation markers).
"""

import dataclasses

from pydantic_ai.messages import (
    ModelMessage,
    ModelRequest,
    ThinkingPart,  # noqa: E402 – needed by truncate
    ToolReturnPart,
)

from code_muse.agents._history import (
    CompactionCache,
    estimate_tokens_for_message,
    hash_message,
)
from code_muse.agents._history_budget import (
    _find_safe_split_index,
)
from code_muse.config import get_recent_tool_results_to_keep
from code_muse.messaging import emit_info


def truncate(
    messages: list[ModelMessage],
    protected_tokens: int,
    model_name: str | None = None,
    cache: CompactionCache | None = None,
) -> list[ModelMessage]:
    """Drop middle messages, keeping system prompt + recent tail within budget.

    Budget is the TOTAL token count of the returned list (system message
    included). Tool_call/tool_return pairs are preserved by adjusting the
    split point so we never sever a tool_call from its tool_return.
    """
    if not messages:
        return messages

    _tok = cache.estimate_tokens if cache else estimate_tokens_for_message

    emit_info("Truncating message history to manage token usage")

    system_message = messages[0]
    system_tokens = _tok(system_message, model_name)

    # If even the system message is over budget, return just it (caller's
    # responsibility — we can't do better here).
    if system_tokens >= protected_tokens or len(messages) == 1:
        return [system_message]

    # Optional 2nd message: extended-thinking context.
    extra_protected: list[ModelMessage] = []
    extra_tokens = 0
    skip_indices = {0}
    if len(messages) > 1:
        second_msg = messages[1]
        if any(isinstance(part, ThinkingPart) for part in second_msg.parts):
            second_tokens = _tok(second_msg, model_name)
            if system_tokens + second_tokens < protected_tokens:
                extra_protected.append(second_msg)
                extra_tokens = second_tokens
                skip_indices.add(1)

    # Walk backwards from the tail, accumulating recent messages until we
    # hit the remaining budget.
    budget_remaining = protected_tokens - system_tokens - extra_tokens
    recent: list[ModelMessage] = []
    recent_tokens = 0
    for i in range(len(messages) - 1, -1, -1):
        if i in skip_indices:
            continue
        msg_tokens = _tok(messages[i], model_name)
        if recent_tokens + msg_tokens > budget_remaining:
            break
        recent_tokens += msg_tokens
        recent.append(messages[i])

    # We collected in reverse order; reverse to chronological.
    recent.reverse()

    # Compute the split index from the original list and adjust to keep
    # tool_call/tool_return pairs together (never sever a pair).
    if recent:
        # Find the index of the earliest message in `recent` within `messages`.
        # We do this by identity since messages preserve identity through
        # the algorithm.
        first_recent_id = id(recent[0])
        split_idx = next(
            (i for i, m in enumerate(messages) if id(m) == first_recent_id),
            len(messages) - len(recent),
        )
        adjusted_idx = _find_safe_split_index(messages, split_idx)
        # If pair-safety pushed the split earlier, expand `recent` accordingly,
        # but ONLY if it still fits within the budget. If not, accept the
        # original (potentially-orphaned) split and rely on
        # prune_interrupted_tool_calls to clean up downstream.
        if adjusted_idx < split_idx:
            extra = messages[adjusted_idx:split_idx]
            extra_tok = sum(_tok(m, model_name) for m in extra)
            if recent_tokens + extra_tok <= budget_remaining:
                recent = list(extra) + recent
                recent_tokens += extra_tok

    result: list[ModelMessage] = [system_message] + extra_protected + recent

    # Safety: never return only the system prompt with no user messages.
    # When this happens, the budget was too small to fit even one message;
    # we still need *something* — pick the smallest recent message rather
    # than the last (which may be massive).
    if len(result) == 1 and len(messages) > 1:
        candidates = [messages[i] for i in range(1, len(messages))]
        smallest = min(candidates, key=lambda m: _tok(m, model_name))
        result.append(smallest)

    return result


def _truncate_with_dropped(
    filtered: list[ModelMessage],
    protected_tokens: int,
    model_name: str | None,
    cache: CompactionCache | None = None,
) -> tuple[list[ModelMessage], list[ModelMessage]]:
    """Truncate ``filtered`` and compute which messages got dropped.

    Shared by the truncation strategy and the summarization-failure fallback
    so both paths agree on what counts as 'dropped' for hash bookkeeping.
    """
    result_messages = truncate(filtered, protected_tokens, model_name, cache=cache)
    _hash = cache.hash_message if cache else hash_message
    result_hashes = {_hash(m) for m in result_messages}
    dropped = [m for m in filtered if _hash(m) not in result_hashes]
    return result_messages, dropped


def _truncate_tool_result_content(
    messages: list[ModelMessage],
    keep_count: int | None = None,
) -> list[ModelMessage]:
    """Replace older tool result content with a truncation marker,
    drop duplicates, and collapse repetitive shell outputs.

    Three passes (cheapest to most aggressive):

    1. **Dedup pass**: Drop tool results where the same tool name + same
       output prefix appears within 5 turns (keeps first, replaces
       subsequent with a ``[Duplicate — see above]`` marker).
    2. **Repetitive shell pass**: Collapse consecutive shell outputs with
       the same prefix (keep first + "repeated N times").
    3. **Age-based truncation**: Replace old tool results (beyond
       ``keep_count``) with a short notice marker.

    The structural pairing (tool_call ↔ tool_return) stays intact.
    Only affects ToolReturnPart content — all other parts preserved.

    Args:
        messages: The message history.
        keep_count: Number of recent tool results to keep in full.
            Defaults to the configurable ``recent_tool_results_to_keep``.
    """
    if keep_count is None:
        keep_count = get_recent_tool_results_to_keep()

    # Reverse-scan: collect tool_call_ids of the most recent N tool results
    protected_ids: set[str] = set()
    seen = 0
    for i in range(len(messages) - 1, -1, -1):
        msg = messages[i]
        if isinstance(msg, ModelRequest):
            for part in msg.parts:
                if isinstance(part, ToolReturnPart):
                    seen += 1
                    if seen <= keep_count:
                        protected_ids.add(part.tool_call_id)

    # ── Pass 1: Deduplicate tool results ───────────────────────────
    # Track (tool_name, output_prefix) → first occurrence index.
    # If the same combo reappears within 5 turns, replace with duplicate marker.
    _DEDUP_WINDOW = 5
    _DEDUP_PREFIX_LEN = 80  # first 80 chars of content for matching
    _DUPLICATE_MSG = "[Duplicate result — see earlier output above]"

    # Build a flat list of (msg_index, part_index, tool_name, content_prefix)
    # for all ToolReturnParts
    tool_returns: list[tuple[int, int, str, str]] = []
    for mi, msg in enumerate(messages):
        if not isinstance(msg, ModelRequest):
            continue
        for pi, part in enumerate(msg.parts):
            if isinstance(part, ToolReturnPart):
                content_str = (
                    part.content if isinstance(part.content, str) else str(part.content)
                )
                prefix = content_str[:_DEDUP_PREFIX_LEN]
                tool_returns.append((mi, pi, part.tool_name, prefix))

    # Find duplicate IDs: same tool_name + prefix within DEDUP_WINDOW
    duplicate_ids: set[str] = set()
    # Map from (tool_name, prefix) → last seen index in tool_returns list
    last_seen: dict[tuple[str, str], int] = {}
    for idx, (mi, pi, tool_name, prefix) in enumerate(tool_returns):
        key = (tool_name, prefix)
        if key in last_seen and (idx - last_seen[key]) <= _DEDUP_WINDOW:
            # This is a duplicate — mark its tool_call_id
            part = messages[mi].parts[pi]
            if isinstance(part, ToolReturnPart):
                duplicate_ids.add(part.tool_call_id)
        last_seen[key] = idx

    # ── Pass 2: Collapse repetitive shell outputs ──────────────────
    _SHELL_TOOL_NAMES = frozenset({"run_shell_command", "agent_run_shell_command"})
    _REPETITIVE_PREFIX_LEN = 40

    # Group consecutive shell results by output prefix
    collapsed_ids: set[str] = set()  # tool_call_ids whose content was collapsed
    collapse_content: dict[str, str] = {}  # tool_call_id → new content

    shell_returns: list[tuple[int, int, ToolReturnPart]] = []
    for mi, msg in enumerate(messages):
        if not isinstance(msg, ModelRequest):
            continue
        for pi, part in enumerate(msg.parts):
            if isinstance(part, ToolReturnPart) and part.tool_name in _SHELL_TOOL_NAMES:
                shell_returns.append((mi, pi, part))

    # Walk shell returns; group consecutive ones with same prefix
    if shell_returns:
        group_start = 0
        for i in range(1, len(shell_returns) + 1):
            # Check if current belongs to same group as group_start
            same_prefix = True
            if i < len(shell_returns):
                curr = shell_returns[i]
                first = shell_returns[group_start]
                curr_content = (
                    curr[2].content
                    if isinstance(curr[2].content, str)
                    else str(curr[2].content)
                )
                first_content = (
                    first[2].content
                    if isinstance(first[2].content, str)
                    else str(first[2].content)
                )
                same_prefix = (
                    curr_content[:_REPETITIVE_PREFIX_LEN]
                    == first_content[:_REPETITIVE_PREFIX_LEN]
                )

            if not same_prefix or i == len(shell_returns):
                group_len = i - group_start
                if group_len > 2:
                    # Collapse: keep first, mark rest as collapsed
                    first_part = shell_returns[group_start][2]
                    first_content = (
                        first_part.content
                        if isinstance(first_part.content, str)
                        else str(first_part.content)
                    )
                    collapsed_content = (
                        f"{first_content}\n[... repeated {group_len - 1} similar times]"
                    )
                    collapse_content[first_part.tool_call_id] = collapsed_content
                    for j in range(group_start + 1, i):
                        dup_part = shell_returns[j][2]
                        collapsed_ids.add(dup_part.tool_call_id)
                group_start = i

    # ── Pass 3: Forward-pass rebuild ───────────────────────────────
    result: list[ModelMessage] = []
    TRUNCATION_MSG = "[Result truncated — re-call tool if full output is needed]"

    for msg in messages:
        if not isinstance(msg, ModelRequest):
            result.append(msg)
            continue
        new_parts = []
        modified = False
        for part in msg.parts:
            if not isinstance(part, ToolReturnPart):
                new_parts.append(part)
                continue

            tcid = part.tool_call_id

            # Duplicate: replace with marker
            if tcid in duplicate_ids:
                modified = True
                new_parts.append(dataclasses.replace(part, content=_DUPLICATE_MSG))
                continue

            # Collapsed repetitive shell output
            if tcid in collapsed_ids:
                modified = True
                new_parts.append(
                    dataclasses.replace(
                        part, content="[Repeated shell output — see first occurrence]"
                    )
                )
                continue
            if tcid in collapse_content:
                modified = True
                new_parts.append(
                    dataclasses.replace(part, content=collapse_content[tcid])
                )
                continue

            # Old tool result (beyond keep_count): replace with truncation marker
            if tcid not in protected_ids:
                modified = True
                try:
                    if hasattr(part, "model_copy"):
                        new_parts.append(
                            part.model_copy(update={"content": TRUNCATION_MSG})
                        )
                    else:
                        new_parts.append(
                            dataclasses.replace(part, content=TRUNCATION_MSG)
                        )
                except Exception:
                    new_parts.append(part)
                continue

            new_parts.append(part)

        # Preserve identity when no parts were actually modified
        result.append(msg if not modified else ModelRequest(parts=new_parts))

    return result


__all__ = [
    "_truncate_tool_result_content",
    "_truncate_with_dropped",
    "truncate",
]
