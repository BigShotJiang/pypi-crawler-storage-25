"""Context handoff (session reset with state injection).

Part of the ``code_muse.agents.compaction`` package.
"""

import re
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from code_muse.agents._protocol import AgentProtocol

from pydantic_ai.messages import ModelMessage, ModelRequest

from code_muse.agents._history import CompactionCache
from code_muse.messaging import emit_info

# ── Handoff summary generation ────────────────────────────────────────


def generate_handoff_summary(
    old_messages: list[ModelMessage],
    model_name: str | None = None,
) -> str:
    """Generate a ≤200-word State Handoff summary from old messages.

    Extracts: current goal, files modified, key decisions, blockers,
    next steps.  Structured for injection into a fresh agent context
    so a new sub-agent or reset session can resume seamlessly.

    Args:
        old_messages: Messages being replaced by the handoff.
        model_name: Model name (for token estimation heuristics).

    Returns:
        Handoff summary text (≤200 words).
    """
    files_touched: set[str] = set()
    decisions: list[str] = []
    errors: list[str] = []
    current_goal: str = ""
    next_steps: list[str] = []

    for msg in old_messages:
        for part in getattr(msg, "parts", []) or []:
            content = getattr(part, "content", None)
            if not isinstance(content, str):
                continue
            # Extract file paths
            for match in re.finditer(r'["\']?(/[^\s"\']+\\.\w+)["\']?', content[:500]):
                files_touched.add(match.group(1))
            # Extract decisions/actions, blockers, and next steps
            for line in content.split("\n")[:5]:
                line_lower = line.lower().strip()
                if any(
                    kw in line_lower
                    for kw in ("decided", "fixed", "changed", "created", "updated")
                ):
                    decisions.append(line.strip()[:120])
                elif any(
                    kw in line_lower
                    for kw in ("next step", "then ", "after that", "still need")
                ):
                    next_steps.append(line.strip()[:120])
                elif any(
                    kw in line_lower for kw in ("error", "failed", "bug", "broken")
                ):
                    errors.append(line.strip()[:120])

    # Derive current goal from the first user-like message
    for msg in old_messages:
        if isinstance(msg, ModelRequest):
            for part in getattr(msg, "parts", []) or []:
                content = getattr(part, "content", None)
                if isinstance(content, str) and len(content) > 20:
                    current_goal = content[:200].strip()
                    break
            if current_goal:
                break

    # Build the handoff summary — concise, ≤200 words
    lines = ["## State Handoff"]
    if current_goal:
        lines.append(f"**Goal:** {current_goal}")
    if files_touched:
        lines.append("**Files touched:** " + ", ".join(sorted(files_touched)[:15]))
    if decisions:
        lines.append("**Key decisions:**")
        for d in decisions[:6]:
            lines.append(f"- {d}")
    if errors:
        lines.append("**Blockers:**")
        for e in errors[:4]:
            lines.append(f"- {e}")
    if next_steps:
        lines.append("**Next steps:**")
        for s in next_steps[:4]:
            lines.append(f"- {s}")
    lines.append("*Resume from where the conversation left off.*")

    # Enforce 200-word limit (truncate at word boundary, append marker)
    text = "\n".join(lines)
    words = text.split()
    if len(words) > 200:
        text = " ".join(words[:197]) + " ... [handoff truncated]"
    return text


# ── Context handoff ───────────────────────────────────────────────────


def context_handoff(
    agent: AgentProtocol | Any | None,
    messages: list[ModelMessage],
    model_max: int,
    context_overhead: int,
) -> tuple[list[ModelMessage], list[ModelMessage]]:
    """Reset the session context by replacing history with a structured
    state handoff summary.

    This is the primary compaction escape when cheap compaction (extractive →
    structural) has failed to bring usage below threshold.  Instead of
    infinitely re-summarizing the same window, this:

    1. Generates a concise ≤200-word State Handoff summary via
       ``generate_handoff_summary()`` (current goal, files modified,
       blockers, next steps).
    2. Attempts sub-agent spawning via ``invoke_agent`` with the handoff
       summary injected as the first message (fresh token window).
    3. If sub-agent spawning is unavailable (no RunContext in compaction
       pipeline), falls back to session reset: clears the message array
       and injects the handoff summary as a system message + protected
       tail.

    This avoids the pathological case of summarizing 100+ messages on
    every turn, which destroys both performance and nuance.

    Args:
        agent: The owning agent (for model name resolution).
        messages: Current message history.
        model_max: Model context window in tokens.
        context_overhead: System prompt + tool schema overhead.

    Returns:
        ``(new_messages, dropped_messages)``
    """
    from pydantic_ai.messages import TextPart

    if len(messages) <= 3:
        return messages, []

    model_name: str | None = None
    if agent is not None:
        try:
            model_name = agent.get_model_name()
        except Exception:
            model_name = None

    cache = CompactionCache()

    # Derive protected tail budget from the unified effective budget.
    from code_muse.config.models import compute_effective_history_budget

    effective_budget = compute_effective_history_budget(
        model_max, overhead=context_overhead, model_name=model_name
    )
    # 25% of effective budget for the protected tail — keeps recent
    # messages intact while freeing the majority of the window.
    _PROTECTED_TAIL_FRACTION = 0.25
    protected_budget = max(4096, int(effective_budget * _PROTECTED_TAIL_FRACTION))
    system_msg = messages[0]
    system_tokens = cache.estimate_tokens(system_msg, model_name)

    # Build protected tail from most recent messages
    protected_tail: list[ModelMessage] = []
    tail_tokens = system_tokens
    for msg in reversed(messages[1:]):
        msg_tokens = cache.estimate_tokens(msg, model_name)
        if tail_tokens + msg_tokens > protected_budget:
            break
        protected_tail.append(msg)
        tail_tokens += msg_tokens
    protected_tail.reverse()

    # Everything between system msg and protected tail is "old history"
    old_count = len(messages) - 1 - len(protected_tail)
    old_messages = messages[1 : 1 + old_count]

    if not old_messages:
        return messages, []

    # Step 1: Generate structured handoff summary (≤200 words)
    handoff_text = generate_handoff_summary(old_messages, model_name=model_name)

    # Step 2: Attempt sub-agent spawning for a fresh token window.
    # The compaction pipeline runs synchronously without RunContext, so
    # we cannot directly call invoke_agent here.  Instead, we perform a
    # session reset (clear old messages, inject handoff).  The agent's
    # main loop will see the reduced history and continue with a fresh
    # context window.  If sub-agent infrastructure becomes available
    # in the history processor context, this is where we'd spawn.
    handoff_msg = ModelRequest(parts=[TextPart(content=handoff_text)])

    new_history = [system_msg, handoff_msg] + protected_tail

    emit_info(
        f"🔄 Context handoff: {len(messages)} → {len(new_history)} messages "
        f"({old_count} old messages compressed into handoff summary)"
    )

    return new_history, old_messages
