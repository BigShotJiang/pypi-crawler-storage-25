"""Subinterpreter execution pool (PEP 734) for cheap true parallelism on Python 3.14+.

.. deprecated::
    This module is deprecated and will be removed in a future release.
    Use the Universal Constructor subprocess runner (``run_tool_subprocess``) instead.

This module provides a pooled executor that runs Python callables in isolated
sub-interpreters. Each sub-interpreter has its own GIL, enabling real OS-level
parallelism even on the standard (GIL-enabled) CPython build.

Public API (stable for Phase 2/3):
    from code_muse.interpreter_pool import (
        SubInterpreterExecutor,
        get_default_executor,
        is_available,
        run_in_subinterpreter,
    )

The implementation deliberately stays small and focused on the UC use case
while remaining reusable by other plugins.
"""

import atexit
import contextlib
import logging
import os
import threading
import time
import warnings
from collections import deque
from typing import Any

# ---------------------------------------------------------------------------
# Sandboxing configuration
# ---------------------------------------------------------------------------

# Modules that are ALWAYS allowed inside sub-interpreter sandboxes.
# These are safe, side-effect-free stdlib modules needed for data processing.
_SANDBOX_ALLOWED_MODULES: frozenset[str] = frozenset(
    {
        # Core data types & serialization
        "json",
        "re",
        "math",
        "decimal",
        "fractions",
        "statistics",
        "collections",
        "itertools",
        "functools",
        "operator",
        "copy",
        "pprint",
        # Datetime
        "datetime",
        "calendar",
        "zoneinfo",
        # Text processing
        "string",
        "textwrap",
        "unicodedata",
        "difflib",
        # Type helpers
        "typing",
        "dataclasses",
        "enum",
        "types",
        # Struct / binary data (no I/O side effects by themselves)
        "struct",
        # Path manipulation (read-only; I/O is blocked separately)
        "posixpath",
        "ntpath",
        "genericpath",
        "pureposixpath",
        "purentpath",
        # Required for bootstrap
        "importlib.util",
        "importlib",
        "sys",
        "traceback",
    }
)

# Modules that are ALWAYS blocked — side effects are too dangerous.
_SANDBOX_BLOCKED_MODULES: frozenset[str] = frozenset(
    {
        # Network
        "socket",
        "http",
        "urllib",
        "requests",
        "ssl",
        "asyncio",
        "xmlrpc",
        "ftplib",
        "smtplib",
        "telnetlib",
        "poplib",
        "imaplib",
        "xmlrpc.client",
        "xmlrpc.server",
        # OS / process
        "subprocess",
        "multiprocessing",
        "os",
        "signal",
        "resource",
        "ctypes",
        "winreg",
        # Filesystem (dangerous operations)
        "shutil",
        "tempfile",
        "glob",
        # Code execution / introspection that escapes sandbox
        "code",
        "codeop",
        "compileall",
        "py_compile",
        "compile",
        # System access
        "platform",
        "sysconfig",
        "distutils",
        "setuptools",
        "pkg_resources",
    }
)

# Default memory limit in bytes for sandboxed sub-interpreters (256 MB).
# Set MUSE_SANDBOX_MEMORY_LIMIT to override.  0 = no limit.
_DEFAULT_MEMORY_LIMIT = int(
    os.environ.get("MUSE_SANDBOX_MEMORY_LIMIT", str(256 * 1024 * 1024))
)

# Default CPU time limit in seconds for sandboxed sub-interpreters.
# Set MUSE_SANDBOX_CPU_LIMIT to override.  0 = no limit.
_DEFAULT_CPU_LIMIT = int(os.environ.get("MUSE_SANDBOX_CPU_LIMIT", "0"))

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Availability check
# ---------------------------------------------------------------------------


def is_available() -> bool:
    """Return True if the subinterpreter API is usable on this Python build."""
    try:
        from concurrent import interpreters  # noqa: F401

        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# The Executor
# ---------------------------------------------------------------------------


class SubInterpreterExecutor:
    """A pool of reusable sub-interpreters for parallel execution.

    Each interpreter in the pool runs with its own GIL. Creating a new
    interpreter is cheap compared to spawning an OS process.

    Usage:

        with SubInterpreterExecutor(max_workers=4) as exec:
            result = exec.run_module_function(
                module_path="/path/to/tool.py",
                function_name="my_tool",
                args={"city": "Berlin"},
                timeout=30.0,
            )
    """

    def __init__(
        self,
        max_workers: int = 4,
        keep_alive: bool = True,
        *,
        sandbox: bool = True,
        allowed_modules: frozenset[str] | None = None,
        memory_limit: int = _DEFAULT_MEMORY_LIMIT,
        cpu_limit: int = _DEFAULT_CPU_LIMIT,
    ):
        if not is_available():
            raise RuntimeError(
                "Subinterpreters (PEP 734) are only available on Python 3.14+. "
                "Use the multiprocessing fallback on older versions."
            )

        self._max_workers = max(1, max_workers)
        self._keep_alive = keep_alive
        self._sandbox = sandbox
        self._allowed_modules = allowed_modules or _SANDBOX_ALLOWED_MODULES
        self._memory_limit = memory_limit
        self._cpu_limit = cpu_limit
        self._pool: deque[Any] = deque()  # stores Interpreter objects
        self._lock = threading.Lock()
        self._closed = False
        self._created_count = 0

        # Import here so the module can still be imported on < 3.14
        from concurrent import interpreters as _interp_mod

        self._interp_mod = _interp_mod

    # ------------------------------------------------------------------ pool management

    def _acquire(self) -> Any:
        """Get an interpreter from the pool or create a new one."""
        with self._lock:
            if self._pool:
                return self._pool.popleft()
            # Create a fresh one
            interp = self._interp_mod.create()
            self._created_count += 1
            return interp

    def _release(self, interp: Any) -> None:
        """Return an interpreter to the pool or close it."""
        if self._closed or not self._keep_alive:
            with contextlib.suppress(Exception):
                interp.close()
            return

        with self._lock:
            if len(self._pool) < self._max_workers:
                self._pool.append(interp)
            else:
                with contextlib.suppress(Exception):
                    interp.close()

    def shutdown(self, wait: bool = True) -> None:
        """Close all interpreters in the pool."""
        self._closed = True
        with self._lock:
            while self._pool:
                interp = self._pool.popleft()
                with contextlib.suppress(Exception):
                    interp.close()
        logger.debug(
            "SubInterpreterExecutor shut down (created %d interpreters)",
            self._created_count,
        )

    def __enter__(self) -> SubInterpreterExecutor:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.shutdown(wait=True)

    # ------------------------------------------------------------------ execution

    # Trusted directory prefixes for module_path validation.
    # Only modules under these paths are allowed to run in sub-interpreters.
    _TRUSTED_PREFIXES: tuple[str, ...] = ()  # Set at construction or per-call

    @classmethod
    def set_trusted_prefixes(cls, prefixes: tuple[str, ...]) -> None:
        """Set the class-level trusted directory prefixes for module_path validation."""
        warnings.warn(
            "interpreter_pool is deprecated and will be removed. "
            "Use the Universal Constructor subprocess runner instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        cls._TRUSTED_PREFIXES = prefixes

    @classmethod
    def set_sandbox_allowed_modules(cls, modules: frozenset[str]) -> None:
        """Extend the per-executor import whitelist for sandboxed interpreters.

        Call this during plugin initialisation to grant additional imports
        to UC tools that need them (e.g. ``{"csv", "xml.etree.ElementTree"}``).
        """
        warnings.warn(
            "interpreter_pool is deprecated and will be removed. "
            "Use the Universal Constructor subprocess runner instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        # Merge into the instance defaults at class level so future
        # executors inherit the expanded set.
        # We modify a class variable so existing instances also see it.
        # (Individual instances can override via their constructor.)
        # We store the *additions* separately and merge at runtime.
        cls._sandbox_extra_modules = (
            getattr(cls, "_sandbox_extra_modules", frozenset()) | modules
        )

    @staticmethod
    def _validate_module_path(
        module_path: str, *, force_untrusted: bool = False
    ) -> None:
        """Validate that module_path is within a trusted workspace directory.

        Raises ValueError if module_path is not under any trusted prefix.
        This prevents arbitrary code execution outside designated directories.

        Args:
            module_path: Absolute path to the Python file.
            force_untrusted: If True, allow execution even when no trusted
                prefixes are configured.  Callers must set this explicitly
                to acknowledge the security risk.
        """
        if not SubInterpreterExecutor._TRUSTED_PREFIXES:
            if force_untrusted:
                logger.warning(
                    "interpreter_pool: executing module with no trusted "
                    "prefixes configured (force_untrusted=True). "
                    "This is a security risk — configure trusted prefixes "
                    "or use the subprocess runner for untrusted code."
                )
                return
            raise ValueError(
                "No trusted prefixes configured for interpreter_pool. "
                "Refusing to execute unsandboxed code. "
                "Call SubInterpreterExecutor.set_trusted_prefixes() first, "
                "or pass force_untrusted=True if you accept the risk."
            )
        resolved = os.path.realpath(module_path)
        for prefix in SubInterpreterExecutor._TRUSTED_PREFIXES:
            if resolved.startswith(os.path.realpath(prefix) + os.sep):
                return
        raise ValueError(
            f"Module path '{module_path}' is not within any trusted directory. "
            f"Trusted prefixes: {SubInterpreterExecutor._TRUSTED_PREFIXES}. "
            f"Use the subprocess runner (default) for untrusted code."
        )

    def run_module_function(
        self,
        module_path: str,
        function_name: str,
        args: dict[str, Any] | None = None,
        timeout: float = 30.0,
        *,
        result_path: str | None = None,
        stdout_path: str | None = None,
        stderr_path: str | None = None,
        force_untrusted: bool = False,
        sandbox: bool | None = None,
    ) -> dict[str, Any]:
        """Run a function defined in an external .py file inside a sub-interpreter.

        This is the high-level API used by the Universal Constructor runner.

        The implementation still uses temp files for result + stdout/stderr
        capture (same protocol as the multiprocessing path) so that all the
        TOCTOU protection, output capping, and error formatting logic in
        runner.py can stay unchanged.

        Args:
            module_path: Absolute path to the Python file containing the tool.
            function_name: Name of the function to call inside that module.
            args: JSON-serializable arguments for the function.
            timeout: Hard wall-clock limit in seconds.
            result_path / stdout_path / stderr_path: Optional paths to temp files
                that the caller has already created. If omitted, the executor
                will create its own temporary files (less efficient for the
                current runner integration).

        Returns:
            Dict with the same shape as the multiprocessing path:
            {"success": bool, "result": Any, "error": str|None, "stdout": str,
             "stderr": str, "execution_time": float}
        """
        warnings.warn(
            "interpreter_pool is deprecated and will be removed. "
            "Use the Universal Constructor subprocess runner instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        args = args or {}
        start = time.time()

        # Validate module_path is within a trusted workspace
        self._validate_module_path(module_path, force_untrusted=force_untrusted)

        # Determine sandbox mode: per-call override > executor default
        use_sandbox = self._sandbox if sandbox is None else sandbox

        # Use the caller's temp files when provided (the common case from runner.py)
        own_files = result_path is None
        if own_files:
            import tempfile

            with (
                tempfile.NamedTemporaryFile(
                    mode="w", suffix=".json", delete=False
                ) as rf,
                tempfile.NamedTemporaryFile(
                    mode="w", suffix=".txt", delete=False
                ) as sf,
                tempfile.NamedTemporaryFile(
                    mode="w", suffix=".txt", delete=False
                ) as ef,
            ):
                result_path = rf.name
                stdout_path = sf.name
                stderr_path = ef.name

        interp = self._acquire()
        timed_out = False
        watcher: threading.Timer | None = None

        try:
            # Prepare the payload for the sub-interpreter.
            # We still serialize via the fastjson shim so we are independent of orjson.
            import code_muse._fastjson as _json

            args_json = _json.dumps(args)

            # Build the effective allowed-modules set for the sandbox
            extra = getattr(self.__class__, "_sandbox_extra_modules", frozenset())
            effective_allowed = self._allowed_modules | extra

            # Prepare injected values for the sub-interpreter
            inject_kwargs: dict[str, Any] = {
                "__uc_module_path": str(module_path),
                "__uc_function_name": function_name,
                "__uc_args_json": args_json,
                "__uc_result_path": str(result_path),
                "__uc_stdout_path": str(stdout_path),
                "__uc_stderr_path": str(stderr_path),
                "__uc_sandbox": use_sandbox,
                "__uc_memory_limit": self._memory_limit,
                "__uc_cpu_limit": self._cpu_limit,
                "__uc_allowed_modules_json": _json.dumps(sorted(effective_allowed)),
                "__uc_blocked_modules_json": _json.dumps(
                    sorted(_SANDBOX_BLOCKED_MODULES)
                ),
            }

            interp.prepare_main(**inject_kwargs)

            # The actual work executed inside the sub-interpreter.
            # Includes sandboxing: restricted imports, resource limits,
            # and filesystem guard when sandbox mode is enabled.
            bootstrap = """
import importlib.util
import json
import sys
import traceback

# Read injected values
module_path = __uc_module_path
function_name = __uc_function_name
args_json = __uc_args_json
result_path = __uc_result_path
stdout_path = __uc_stdout_path
stderr_path = __uc_stderr_path
sandbox_enabled = __uc_sandbox
memory_limit = __uc_memory_limit
cpu_limit = __uc_cpu_limit
allowed_modules = set(json.loads(__uc_allowed_modules_json))
blocked_modules = set(json.loads(__uc_blocked_modules_json))

# ------------------------------------------------------------------
# Sandbox: restricted __import__
# ------------------------------------------------------------------
if sandbox_enabled:
    _original_import = __builtins__["__import__"] if isinstance(__builtins__, dict) else __builtins__.__import__

    def _restricted_import(name, globals=None, locals=None, fromlist=(), level=0):
        # Allow the top-level module name check
        top_name = name.split(".")[0]
        if top_name in blocked_modules or name in blocked_modules:
            raise ImportError(
                f"Sandbox blocks import of '{name}' — "
                f"dangerous module not allowed in sub-interpreter sandbox"
            )
        if top_name in allowed_modules or name in allowed_modules:
            return _original_import(name, globals, locals, fromlist, level)
        # Not in allow-list and not in block-list -> deny by default
        raise ImportError(
            f"Sandbox blocks import of '{name}' — "
            f"module not in allowed list. Allowed: {sorted(allowed_modules)}"
        )

    if isinstance(__builtins__, dict):
        __builtins__["__import__"] = _restricted_import
    else:
        __builtins__.__import__ = _restricted_import

    # ------------------------------------------------------------------
    # Sandbox: restrict os module if it was already imported
    # ------------------------------------------------------------------
    if "os" in sys.modules:
        _os = sys.modules["os"]
        for _attr in ("system", "popen", "spawn", "exec", "remove",
                      "unlink", "rmdir", "makedirs", "rename", "chmod",
                      "chown", "link", "symlink", "kill", "fork",
                      "forkpty", "execvp", "execvpe"):
            if hasattr(_os, _attr):
                setattr(_os, _attr, lambda *a, **kw: (_ for _ in ()).throw(
                    PermissionError(f"Sandbox blocks os.{_attr}()")
                ))

    # ------------------------------------------------------------------
    # Sandbox: resource limits (memory and CPU)
    # ------------------------------------------------------------------
    if memory_limit > 0 or cpu_limit > 0:
        try:
            import resource as _resource
            if memory_limit > 0:
                _resource.setrlimit(
                    _resource.RLIMIT_AS,
                    (memory_limit, memory_limit),
                )
            if cpu_limit > 0:
                _resource.setrlimit(
                    _resource.RLIMIT_CPU,
                    (cpu_limit, cpu_limit),
                )
        except (ImportError, ValueError, OSError) as _e:
            # resource module unavailable (e.g. Windows) or limit failed
            pass

stdout_buf = []
stderr_buf = []

class _CapStream:
    def __init__(self, buf):
        self.buf = buf
    def write(self, text):
        self.buf.append(text)
    def flush(self):
        pass

sys.stdout = _CapStream(stdout_buf)
sys.stderr = _CapStream(stderr_buf)

try:
    spec = importlib.util.spec_from_file_location("uc_tool_module", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module from {module_path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    func = getattr(mod, function_name, None)
    if func is None or not callable(func):
        raise NameError(
            f"Function '{function_name}' not found or not callable in {module_path}"
        )

    args = json.loads(args_json) if args_json else {}
    if not isinstance(args, dict):
        raise TypeError("tool_args must deserialize to a dict")

    raw_result = func(**args)

    result_obj = {"success": True, "result": raw_result}
    with open(result_path, "w", encoding="utf-8") as f:
        f.write(json.dumps(result_obj))

except Exception as exc:
    err_obj = {
        "success": False,
        "error": f"{type(exc).__name__}: {exc}",
        "traceback": traceback.format_exc(),
    }
    with open(result_path, "w", encoding="utf-8") as f:
        f.write(json.dumps(err_obj))

finally:
    with open(stdout_path, "w", encoding="utf-8") as f:
        f.write("".join(stdout_buf))
    with open(stderr_path, "w", encoding="utf-8") as f:
        f.write("".join(stderr_buf))
"""

            # Timeout handling: start a watcher that will close the interpreter
            # if the deadline is exceeded. Closing an interpreter from another
            # thread is the documented way to abort it.
            def _timeout_kill():
                nonlocal timed_out
                timed_out = True
                logger.warning(
                    "Subinterpreter timeout after %.1fs — closing interpreter", timeout
                )
                with contextlib.suppress(Exception):
                    interp.close()

            watcher = threading.Timer(timeout, _timeout_kill)
            watcher.daemon = True
            watcher.start()

            # Execute inside the sub-interpreter (blocking call from our perspective).
            # Note: On Python 3.14.5, interp.close() from another thread is not always
            # instantaneous for CPU-bound pure-Python loops. We still return the
            # correct "timed out" error shape to the caller; the interpreter will be
            # cleaned up when the pool shuts down or on next GC.
            interp.exec(bootstrap)

            execution_time = time.time() - start

            if timed_out:
                return {
                    "success": False,
                    "result": None,
                    "error": f"Tool timed out after {timeout}s",
                    "stdout": "",
                    "stderr": "",
                    "execution_time": execution_time,
                }

            # Read back the result written by the sub-interpreter
            try:
                with open(result_path, encoding="utf-8") as f:
                    result_data = _json.loads(f.read())
            except Exception as e:
                return {
                    "success": False,
                    "result": None,
                    "error": f"Failed to read tool result: {e}",
                    "stdout": "",
                    "stderr": "",
                    "execution_time": execution_time,
                }

            # Read captured output (already text)
            try:
                with open(stdout_path, encoding="utf-8") as f:
                    stdout_text = f.read()
            except Exception:
                stdout_text = ""

            try:
                with open(stderr_path, encoding="utf-8") as f:
                    stderr_text = f.read()
            except Exception:
                stderr_text = ""

            return {
                "success": result_data.get("success", False),
                "result": result_data.get("result")
                if result_data.get("success")
                else None,
                "error": result_data.get("error")
                if not result_data.get("success")
                else None,
                "stdout": stdout_text,
                "stderr": stderr_text,
                "execution_time": execution_time,
            }

        except Exception as exc:
            execution_time = time.time() - start
            return {
                "success": False,
                "result": None,
                "error": (
                    f"Subinterpreter execution failed: {type(exc).__name__}: {exc}"
                ),
                "stdout": "",
                "stderr": "",
                "execution_time": execution_time,
            }
        finally:
            if watcher:
                watcher.cancel()
            self._release(interp)

            if own_files:
                # Clean up temp files we created
                for p in (result_path, stdout_path, stderr_path):
                    with contextlib.suppress(OSError):
                        os.unlink(p)


# ---------------------------------------------------------------------------
# Module-level convenience API (recommended for most call sites)
# ---------------------------------------------------------------------------

_default_executor: SubInterpreterExecutor | None = None
_default_lock = threading.Lock()


def get_default_executor() -> SubInterpreterExecutor:
    """Return a process-wide default executor (lazy, keep-alive).

    Pool size can be controlled with the environment variable:
        MUSE_SUBINTERPRETER_POOL_SIZE=8
    Default is 4.
    """
    warnings.warn(
        "interpreter_pool is deprecated and will be removed. "
        "Use the Universal Constructor subprocess runner instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    global _default_executor
    if _default_executor is None:
        with _default_lock:
            if _default_executor is None:
                pool_size = int(os.environ.get("MUSE_SUBINTERPRETER_POOL_SIZE", "4"))
                pool_size = max(1, min(pool_size, 32))  # reasonable bounds
                _default_executor = SubInterpreterExecutor(
                    max_workers=pool_size, keep_alive=True
                )
    return _default_executor


# ---------------------------------------------------------------------------
# Clean shutdown at process exit (removes "remaining subinterpreters" warning)
# ---------------------------------------------------------------------------


@atexit.register
def _shutdown_default_executor() -> None:
    global _default_executor
    if _default_executor is not None:
        with contextlib.suppress(Exception):
            _default_executor.shutdown(wait=False)
        _default_executor = None


def run_in_subinterpreter(
    module_path: str,
    function_name: str,
    args: dict[str, Any] | None = None,
    timeout: float = 30.0,
    *,
    force_untrusted: bool = False,
    sandbox: bool | None = None,
) -> dict[str, Any]:
    """Convenience wrapper using the default executor.

    This is the function most plugin code should call.

    Args:
        sandbox: Override the executor's default sandbox setting.
            None = use executor default, True = force sandbox on,
            False = force sandbox off (DANGEROUS — only for trusted code).
    """
    warnings.warn(
        "interpreter_pool is deprecated and will be removed. "
        "Use the Universal Constructor subprocess runner instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return get_default_executor().run_module_function(
        module_path=module_path,
        function_name=function_name,
        args=args,
        timeout=timeout,
        force_untrusted=force_untrusted,
        sandbox=sandbox,
    )


# Convenience alias for code that wants to check before calling
available = is_available

# Public aliases for sandbox configuration constants
SANDBOX_ALLOWED_MODULES = _SANDBOX_ALLOWED_MODULES
SANDBOX_BLOCKED_MODULES = _SANDBOX_BLOCKED_MODULES


# Module-level convenience for setting trusted prefixes
def set_trusted_prefixes(prefixes: tuple[str, ...]) -> None:
    """Module-level convenience: set trusted prefixes on the class."""
    warnings.warn(
        "interpreter_pool is deprecated and will be removed. "
        "Use the Universal Constructor subprocess runner instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    SubInterpreterExecutor.set_trusted_prefixes(prefixes)


def set_sandbox_allowed_modules(modules: frozenset[str]) -> None:
    """Module-level convenience: extend the sandbox import whitelist."""
    warnings.warn(
        "interpreter_pool is deprecated and will be removed. "
        "Use the Universal Constructor subprocess runner instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    SubInterpreterExecutor.set_sandbox_allowed_modules(modules)


__all__ = [
    "SubInterpreterExecutor",
    "get_default_executor",
    "run_in_subinterpreter",
    "is_available",
    "available",
    "set_trusted_prefixes",
    "set_sandbox_allowed_modules",
    "SANDBOX_ALLOWED_MODULES",
    "SANDBOX_BLOCKED_MODULES",
]
