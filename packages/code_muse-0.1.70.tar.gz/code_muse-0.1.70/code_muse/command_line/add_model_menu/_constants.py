"""Constants and mappings for the add-model menu."""

from code_muse.models_dev_parser import ProviderInfo

PAGE_SIZE = 15  # Items per page

# Hardcoded OpenAI-compatible endpoints for providers that have dedicated SDKs
# but actually work fine with custom_openai. These are fallbacks when
# provider.api is not set.
PROVIDER_ENDPOINTS = {
    "xai": "https://api.x.ai/v1",
    "cohere": "https://api.cohere.com/compatibility/v1",
    "groq": "https://api.groq.com/openai/v1",
    "mistral": "https://api.mistral.ai/v1",
    "togetherai": "https://api.together.xyz/v1",
    "perplexity": "https://api.perplexity.ai",
    "deepinfra": "https://api.deepinfra.com/v1/openai",
    "aihubmix": "https://aihubmix.com/v1",
}

# Providers that require custom SDK implementations we don't support yet.
# These use non-OpenAI-compatible APIs or require special authentication
# (AWS SigV4, GCP, etc.)
UNSUPPORTED_PROVIDERS = {
    "amazon-bedrock": "Use /bedrock-setup to configure (aws_bedrock plugin)",
    "google-vertex": "Requires GCP service account authentication",
    "google-vertex-anthropic": "Requires GCP service account authentication",
    "cloudflare-workers-ai": "Requires account ID in URL path",
    "vercel": "Vercel AI Gateway - not yet supported",
    "v0": "Vercel v0 - not yet supported",
    "ollama-cloud": "Requires user-specific Ollama instance URL",
}

PROVIDER_IDENTITY_MAPPING = {
    "openai": "openai",
    "anthropic": "anthropic",
    "google": "google",
    "google-vertex": "google",
    "mistral": "mistral",
    "groq": "groq",
    "together-ai": "together_ai",
    "fireworks": "fireworks",
    "deepseek": "deepseek",
    "openrouter": "openrouter",
    "cerebras": "cerebras",
    "cohere": "cohere",
    "perplexity": "perplexity",
    "minimax": "minimax",
    "azure-openai": "azure_openai",
    "xai": "xai",
}


def derive_provider_identity(provider: ProviderInfo) -> str:
    """Derive the persisted provider identity for imported models."""
    provider_id = (provider.id or "").strip()
    if not provider_id:
        return "unknown"
    return PROVIDER_IDENTITY_MAPPING.get(provider_id, provider_id.replace("-", "_"))
