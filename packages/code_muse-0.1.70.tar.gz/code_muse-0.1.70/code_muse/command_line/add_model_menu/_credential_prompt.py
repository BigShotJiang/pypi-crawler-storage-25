"""Credential and custom-model prompting for the add-model menu."""

import os

from code_muse.command_line.utils import safe_input
from code_muse.config import set_config_value
from code_muse.messaging import emit_info, emit_warning
from code_muse.models_dev_parser import ModelInfo, ProviderInfo


class CredentialPromptMixin:
    """Mixin providing credential prompting and custom-model creation."""

    def _get_missing_env_vars(self, provider: ProviderInfo) -> list[str]:
        """Check which required env vars are missing for a provider."""
        missing = []
        for env_var in provider.env:
            if not os.environ.get(env_var):
                missing.append(env_var)
        return missing

    def _prompt_for_credentials(self, provider: ProviderInfo) -> bool:
        """Prompt user for missing credentials and save them.

        Returns:
            True if all credentials were provided (or none needed),
            False if user cancelled
        """
        missing_vars = self._get_missing_env_vars(provider)

        if not missing_vars:
            emit_info(
                f"✅ All required credentials for {provider.name} are already set!"
            )
            return True

        emit_info(f"\n🔑 {provider.name} requires the following credentials:\n")

        for env_var in missing_vars:
            # Show helpful hints based on common env var patterns
            hint = self._get_env_var_hint(env_var)
            if hint:
                emit_info(f"  {hint}")

            try:
                # Use safe_input for cross-platform compatibility (Windows fix)
                value = safe_input(f"  Enter {env_var} (or press Enter to skip): ")

                if not value:
                    emit_warning(
                        f"Skipped {env_var} - "
                        f"you can set it later with /set {env_var}=<value>"
                    )
                    continue

                value = str(value)

                # Save to config
                set_config_value(env_var, value)
                # Also set in current environment so it's immediately available
                os.environ[env_var] = value
                emit_info(f"✅ Saved {env_var} to config")

            except KeyboardInterrupt, EOFError:
                emit_info("")  # Clean newline
                emit_warning("Credential input cancelled")
                return False

        return True

    def _create_custom_model_info(
        self, model_name: str, context_length: int = 128000
    ) -> ModelInfo:
        """Create a ModelInfo object for a custom model.

        Since we don't know the model's capabilities, we assume reasonable defaults.
        """
        provider_id = self.pending_provider.id if self.pending_provider else "custom"
        return ModelInfo(
            provider_id=provider_id,
            model_id=model_name,
            name=model_name,
            tool_call=True,  # Assume true for usability
            temperature=True,
            context_length=context_length,
            max_output=min(
                16384, context_length // 4
            ),  # Reasonable default based on context
            input_modalities=["text"],
            output_modalities=["text"],
        )

    def _prompt_for_custom_model(self) -> tuple[str, int | None]:
        """Prompt user for custom model details.

        Returns:
            Tuple of (model_name, context_length) if provided, None if cancelled
        """
        provider = self.pending_provider
        if not provider:
            return None

        emit_info(f"\n✨ Adding custom model for {provider.name}\n")
        emit_info("  Enter the model ID exactly as the provider expects it.")
        emit_info(
            "  Examples: gpt-4-turbo-preview, "
            "claude-3-opus-20240229, gemini-1.5-pro-latest\n"
        )

        try:
            model_name = safe_input("  Model ID: ")

            if not model_name:
                emit_warning("No model name provided, cancelled.")
                return None

            # Ask for context size
            emit_info("\n  Enter the context window size (in tokens).")
            emit_info("  Common sizes: 8192, 32768, 128000, 200000, 1000000\n")

            context_input = safe_input("  Context size [128000]: ")

            if not context_input:
                context_length = 128000  # Default
            else:
                # Handle k/K suffix (e.g., "128k" -> 128000)
                context_input_lower = context_input.lower().replace(",", "")
                if context_input_lower.endswith("k"):
                    try:
                        context_length = int(float(context_input_lower[:-1]) * 1000)
                    except ValueError:
                        emit_warning("Invalid context size, using default 128000")
                        context_length = 128000
                elif context_input_lower.endswith("m"):
                    try:
                        context_length = int(float(context_input_lower[:-1]) * 1000000)
                    except ValueError:
                        emit_warning("Invalid context size, using default 128000")
                        context_length = 128000
                else:
                    try:
                        context_length = int(context_input)
                    except ValueError:
                        emit_warning("Invalid context size, using default 128000")
                        context_length = 128000

            return (model_name, context_length)

        except KeyboardInterrupt, EOFError:
            emit_info("")  # Clean newline
            emit_warning("Custom model input cancelled")
            return None

    def _get_env_var_hint(self, env_var: str) -> str:
        """Get a helpful hint for common environment variables."""
        hints = {
            "OPENAI_API_KEY": "💡 Get your API key from https://platform.openai.com/api-keys",
            "ANTHROPIC_API_KEY": "💡 Get your API key from https://console.anthropic.com/",
            "GEMINI_API_KEY": "💡 Get your API key from https://aistudio.google.com/apikey",
            "GOOGLE_API_KEY": "💡 Get your API key from https://aistudio.google.com/apikey",
            "AZURE_API_KEY": (
                "💡 Get your API key from Azure Portal > Your OpenAI Resource > Keys"
            ),
            "AZURE_RESOURCE_NAME": (
                "💡 Your Azure OpenAI resource name (not the full URL)"
            ),
            "GROQ_API_KEY": "💡 Get your API key from https://console.groq.com/keys",
            "MISTRAL_API_KEY": "💡 Get your API key from https://console.mistral.ai/",
            "COHERE_API_KEY": "💡 Get your API key from https://dashboard.cohere.com/api-keys",
            "DEEPSEEK_API_KEY": "💡 Get your API key from https://platform.deepseek.com/",
            "TOGETHER_API_KEY": "💡 Get your API key from https://api.together.xyz/settings/api-keys",
            "FIREWORKS_API_KEY": "💡 Get your API key from https://fireworks.ai/api-keys",
            "OPENROUTER_API_KEY": "💡 Get your API key from https://openrouter.ai/keys",
            "PERPLEXITY_API_KEY": "💡 Get your API key from https://www.perplexity.ai/settings/api",
            "CEREBRAS_API_KEY": "💡 Get your API key from https://cloud.cerebras.ai/",
            "HUGGINGFACE_API_KEY": "💡 Get your API key from https://huggingface.co/settings/tokens",
            "XAI_API_KEY": "💡 Get your API key from https://console.x.ai/",
        }
        return hints.get(env_var, "")
