"""Display/rendering logic for the add-model menu."""

from code_muse.command_line.pagination import (
    get_page_bounds,
    get_total_pages,
)

from ._constants import PAGE_SIZE, UNSUPPORTED_PROVIDERS


class MenuRenderMixin:
    """Mixin providing all _render_* methods and update_display."""

    def _render_provider_list(self) -> list:
        """Render the provider list panel."""
        lines = []

        lines.append(("", " Providers"))
        lines.append(("", "\n\n"))

        if not self.providers:
            lines.append(("fg:yellow", "  No providers available."))
            lines.append(("", "\n\n"))
            self._render_navigation_hints(lines)
            return lines

        filter_label = getattr(self, "provider_filter", "") or "type to filter"
        lines.append(("fg:ansibrightblack", f" Filter: {filter_label}"))
        lines.append(("", "\n\n"))

        filtered_providers = self._filtered_providers()
        if not filtered_providers:
            lines.append(("fg:yellow", "  No providers match the current filter."))
            lines.append(("", "\n\n"))
            self._render_navigation_hints(lines)
            return lines

        # Show providers for current page
        total_pages = get_total_pages(len(filtered_providers), PAGE_SIZE)
        start_idx, end_idx = get_page_bounds(
            self.current_page,
            len(filtered_providers),
            PAGE_SIZE,
        )

        for i in range(start_idx, end_idx):
            provider = filtered_providers[i]
            is_selected = i == self.selected_provider_idx
            is_unsupported = provider.id in UNSUPPORTED_PROVIDERS

            # Format: "> Provider Name (X models)" or "  Provider Name (X models)"
            prefix = " > " if is_selected else "   "
            suffix = " ⚠️" if is_unsupported else ""
            label = f"{prefix}{provider.name} ({provider.model_count} models){suffix}"

            # Use dimmed color for unsupported providers
            if is_unsupported:
                lines.append(("fg:ansibrightblack dim", label))
            elif is_selected:
                lines.append(("fg:ansibrightblack", label))
            else:
                lines.append(("fg:ansibrightblack", label))

            lines.append(("", "\n"))

        lines.append(("", "\n"))
        lines.append(
            ("fg:ansibrightblack", f" Page {self.current_page + 1}/{total_pages}")
        )
        lines.append(("", "\n"))

        self._render_navigation_hints(lines)
        return lines

    def _render_model_list(self) -> list:
        """Render the model list panel."""
        lines = []

        if not self.current_provider:
            lines.append(("fg:yellow", "  No provider selected."))
            lines.append(("", "\n\n"))
            self._render_navigation_hints(lines)
            return lines

        lines.append(("", f" {self.current_provider.name} Models"))
        lines.append(("", "\n"))
        filter_label = getattr(self, "model_filter", "") or "type to filter"
        lines.append(("fg:ansibrightblack", f" Filter: {filter_label}"))
        lines.append(("", "\n\n"))

        filtered_models = self._filtered_models()
        custom_visible = self._should_show_custom_model()
        if not filtered_models and not custom_visible:
            lines.append(("fg:yellow", "  No models match the current filter."))
            lines.append(("", "\n\n"))
            self._render_navigation_hints(lines)
            return lines

        # Total items = models + 1 for custom model option
        total_items = len(filtered_models) + int(custom_visible)
        total_pages = get_total_pages(total_items, PAGE_SIZE)
        start_idx, end_idx = get_page_bounds(self.current_page, total_items, PAGE_SIZE)

        # Render models from the current page
        for i in range(start_idx, end_idx):
            # Check if this is the custom model option (last item)
            if custom_visible and i == len(filtered_models):
                is_selected = i == self.selected_model_idx
                if is_selected:
                    lines.append(("fg:ansicyan bold", " > ✨ Custom model..."))
                else:
                    lines.append(("fg:ansicyan", "   ✨ Custom model..."))
                lines.append(("", "\n"))
                continue

            model = filtered_models[i]
            is_selected = i == self.selected_model_idx

            # Create capability icons
            icons = []
            if model.has_vision:
                icons.append("👁")
            if model.tool_call:
                icons.append("🔧")
            if model.reasoning:
                icons.append("🧠")

            icon_str = " ".join(icons) + " " if icons else ""

            if is_selected:
                lines.append(("fg:ansibrightblack", f" > {icon_str}{model.name}"))
            else:
                lines.append(("fg:ansibrightblack", f"   {icon_str}{model.name}"))

            lines.append(("", "\n"))

        lines.append(("", "\n"))
        lines.append(
            ("fg:ansibrightblack", f" Page {self.current_page + 1}/{total_pages}")
        )
        lines.append(("", "\n"))

        self._render_navigation_hints(lines)
        return lines

    def _render_navigation_hints(self, lines: list):
        """Render navigation hints at the bottom of the list panel."""
        lines.append(("", "\n"))
        lines.append(("fg:ansibrightblack", "  ↑/↓ "))
        lines.append(("", "Navigate  "))
        lines.append(("fg:ansibrightblack", "←/→ "))
        lines.append(("", "Page\n"))
        lines.append(("fg:ansibrightblack", "  Type "))
        lines.append(("", "Filter list\n"))
        lines.append(("fg:ansibrightblack", "  Backspace "))
        lines.append(("", "Delete filter char\n"))
        lines.append(("fg:ansibrightblack", "  Ctrl+U "))
        lines.append(("", "Clear filter\n"))
        if self.view_mode == "providers":
            lines.append(("fg:green", "  Enter  "))
            lines.append(("", "Select\n"))
        else:
            lines.append(("fg:green", "  Enter  "))
            lines.append(("", "Add Model\n"))
            lines.append(("fg:ansibrightblack", "  Esc/Back  "))
            lines.append(("", "Back\n"))
        lines.append(("fg:ansibrightred", "  Ctrl+C "))
        lines.append(("", "Cancel"))

    def _render_model_details(self) -> list:
        """Render the model details panel."""
        lines = []

        lines.append(("dim cyan", " MODEL DETAILS"))
        lines.append(("", "\n\n"))

        if self.view_mode == "providers":
            provider = self._get_current_provider()
            if not provider:
                lines.append(("fg:yellow", "  No provider selected."))
                return lines

            lines.append(("bold", f"  {provider.name}"))
            lines.append(("", "\n"))
            lines.append(("fg:ansibrightblack", f"  ID: {provider.id}"))
            lines.append(("", "\n"))
            lines.append(("fg:ansibrightblack", f"  Models: {provider.model_count}"))
            lines.append(("", "\n"))
            lines.append(("fg:ansibrightblack", f"  API: {provider.api}"))
            lines.append(("", "\n"))

            # Show unsupported warning if applicable
            if provider.id in UNSUPPORTED_PROVIDERS:
                lines.append(("", "\n"))
                lines.append(("fg:ansired bold", "  ⚠️  UNSUPPORTED PROVIDER"))
                lines.append(("", "\n"))
                lines.append(("fg:ansired", f"  {UNSUPPORTED_PROVIDERS[provider.id]}"))
                lines.append(("", "\n"))
                lines.append(
                    (
                        "fg:ansibrightblack",
                        "  Models from this provider cannot be added.",
                    )
                )
                lines.append(("", "\n"))

            if provider.env:
                lines.append(("", "\n"))
                lines.append(("bold", "  Environment Variables:"))
                lines.append(("", "\n"))
                for env_var in provider.env:
                    lines.append(("fg:ansibrightblack", f"    • {env_var}"))
                    lines.append(("", "\n"))

            if provider.doc:
                lines.append(("", "\n"))
                lines.append(("bold", "  Documentation:"))
                lines.append(("", "\n"))
                lines.append(("fg:ansibrightblack", f"    {provider.doc}"))
                lines.append(("", "\n"))

        else:  # models view
            model = self._get_current_model()
            provider = self.current_provider

            if not provider:
                lines.append(("fg:yellow", "  No model selected."))
                return lines

            # Handle custom model option
            if self._is_custom_model_selected():
                lines.append(("bold", "  ✨ Custom Model"))
                lines.append(("", "\n\n"))
                lines.append(("fg:ansicyan", "  Add a model not listed in models.dev"))
                lines.append(("", "\n\n"))
                lines.append(("bold", "  How it works:"))
                lines.append(("", "\n"))
                lines.append(("fg:ansibrightblack", "  1. Press Enter to select"))
                lines.append(("", "\n"))
                lines.append(("fg:ansibrightblack", "  2. Enter the model ID/name"))
                lines.append(("", "\n"))
                lines.append(
                    ("fg:ansibrightblack", f"  3. Uses {provider.name}'s API endpoint")
                )
                lines.append(("", "\n\n"))
                lines.append(("bold", "  Use cases:"))
                lines.append(("", "\n"))
                lines.append(("fg:ansibrightblack", "  • Newly released models"))
                lines.append(("", "\n"))
                lines.append(("fg:ansibrightblack", "  • Fine-tuned models"))
                lines.append(("", "\n"))
                lines.append(("fg:ansibrightblack", "  • Preview/beta models"))
                lines.append(("", "\n"))
                lines.append(("fg:ansibrightblack", "  • Custom deployments"))
                lines.append(("", "\n\n"))
                if provider.env:
                    lines.append(("bold", "  Required credentials:"))
                    lines.append(("", "\n"))
                    for env_var in provider.env:
                        lines.append(("fg:ansibrightblack", f"    • {env_var}"))
                        lines.append(("", "\n"))
                return lines

            if not model:
                lines.append(("fg:yellow", "  No model selected."))
                return lines

            lines.append(("bold", f"  {provider.name} - {model.name}"))
            lines.append(("", "\n\n"))

            # BIG WARNING for models without tool calling
            if not model.tool_call:
                lines.append(("fg:ansiyellow bold", "  ⚠️  NO TOOL CALLING SUPPORT"))
                lines.append(("", "\n"))
                lines.append(
                    ("fg:ansiyellow", "  This model cannot use tools (file ops,")
                )
                lines.append(("", "\n"))
                lines.append(
                    ("fg:ansiyellow", "  shell commands, etc). It will be very")
                )
                lines.append(("", "\n"))
                lines.append(("fg:ansiyellow", "  limited for coding tasks!"))
                lines.append(("", "\n\n"))

            # Capabilities
            lines.append(("bold", "  Capabilities:"))
            lines.append(("", "\n"))

            capabilities = [
                ("Vision", model.has_vision),
                ("Tool Calling", model.tool_call),
                ("Reasoning", model.reasoning),
                ("Temperature", model.temperature),
                ("Structured Output", model.structured_output),
                ("Attachments", model.attachment),
            ]

            for cap_name, has_cap in capabilities:
                if has_cap:
                    lines.append(("fg:green", f"    ✓ {cap_name}"))
                else:
                    lines.append(("fg:ansibrightblack", f"    ✗ {cap_name}"))
                lines.append(("", "\n"))

            # Pricing
            lines.append(("", "\n"))
            lines.append(("bold", "  Pricing:"))
            lines.append(("", "\n"))

            if model.cost_input is not None or model.cost_output is not None:
                if model.cost_input is not None:
                    lines.append(
                        (
                            "fg:ansibrightblack",
                            f"    Input: ${model.cost_input:.6f}/token",
                        )
                    )
                    lines.append(("", "\n"))
                if model.cost_output is not None:
                    lines.append(
                        (
                            "fg:ansibrightblack",
                            f"    Output: ${model.cost_output:.6f}/token",
                        )
                    )
                    lines.append(("", "\n"))
                if model.cost_cache_read is not None:
                    lines.append(
                        (
                            "fg:ansibrightblack",
                            f"    Cache Read: ${model.cost_cache_read:.6f}/token",
                        )
                    )
                    lines.append(("", "\n"))
            else:
                lines.append(("fg:ansibrightblack", "    Pricing not available"))
                lines.append(("", "\n"))

            # Limits
            lines.append(("", "\n"))
            lines.append(("bold", "  Limits:"))
            lines.append(("", "\n"))

            if model.context_length > 0:
                lines.append(
                    (
                        "fg:ansibrightblack",
                        f"    Context: {model.context_length:,} tokens",
                    )
                )
                lines.append(("", "\n"))
            if model.max_output > 0:
                lines.append(
                    (
                        "fg:ansibrightblack",
                        f"    Max Output: {model.max_output:,} tokens",
                    )
                )
                lines.append(("", "\n"))

            # Modalities
            if model.input_modalities or model.output_modalities:
                lines.append(("", "\n"))
                lines.append(("bold", "  Modalities:"))
                lines.append(("", "\n"))

                if model.input_modalities:
                    lines.append(
                        (
                            "fg:ansibrightblack",
                            f"    Input: {', '.join(model.input_modalities)}",
                        )
                    )
                    lines.append(("", "\n"))
                if model.output_modalities:
                    lines.append(
                        (
                            "fg:ansibrightblack",
                            f"    Output: {', '.join(model.output_modalities)}",
                        )
                    )
                    lines.append(("", "\n"))

            # Metadata
            lines.append(("", "\n"))
            lines.append(("bold", "  Metadata:"))
            lines.append(("", "\n"))

            lines.append(("fg:ansibrightblack", f"    Model ID: {model.model_id}"))
            lines.append(("", "\n"))
            lines.append(("fg:ansibrightblack", f"    Full ID: {model.full_id}"))
            lines.append(("", "\n"))

            if model.knowledge:
                lines.append(
                    ("fg:ansibrightblack", f"    Knowledge: {model.knowledge}")
                )
                lines.append(("", "\n"))

            if model.release_date:
                lines.append(
                    ("fg:ansibrightblack", f"    Released: {model.release_date}")
                )
                lines.append(("", "\n"))

            lines.append(
                ("fg:ansibrightblack", f"    Open Weights: {model.open_weights}")
            )
            lines.append(("", "\n"))

        return lines

    def update_display(self):
        """Update the display based on current state."""
        if self.view_mode == "providers":
            self.menu_control.text = self._render_provider_list()
        else:
            self.menu_control.text = self._render_model_list()

        self.preview_control.text = self._render_model_details()
