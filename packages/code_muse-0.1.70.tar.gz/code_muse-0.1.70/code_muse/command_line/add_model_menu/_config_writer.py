"""Config persistence for the add-model menu."""

from pathlib import Path

import orjson
import orjson as json

from code_muse.config import EXTRA_MODELS_FILE
from code_muse.messaging import emit_error, emit_info
from code_muse.models_dev_parser import ModelInfo, ProviderInfo

from ._constants import PROVIDER_ENDPOINTS, derive_provider_identity


class ConfigWriterMixin:
    """Mixin providing model config building and persistence."""

    def _add_model_to_extra_config(
        self, model: ModelInfo, provider: ProviderInfo
    ) -> bool:
        """Add a model to the extra_models.json configuration file.

        The extra_models.json format is a dictionary where:
        - Keys are user-friendly model names (e.g., "provider-model-name")
        - Values contain type, name, custom_endpoint (if needed), and context_length
        """
        try:
            # Load existing extra models (dictionary format)
            extra_models_path = Path(EXTRA_MODELS_FILE)
            extra_models: dict = {}

            if extra_models_path.exists():
                try:
                    with open(extra_models_path, encoding="utf-8") as f:
                        extra_models = json.loads(f.read())
                        if not isinstance(extra_models, dict):
                            emit_error(
                                "extra_models.json must be a dictionary, not a list"
                            )
                            return False
                except json.JSONDecodeError as e:
                    emit_error(f"Error parsing extra_models.json: {e}")
                    return False

            # Create a unique key for this model (provider-modelname format)
            model_key = f"{provider.id}-{model.model_id}".replace("/", "-").replace(
                ":", "-"
            )

            # Check for duplicates
            if model_key in extra_models:
                emit_info(f"Model {model_key} is already in extra_models.json")
                return True  # Not an error, just already exists

            # Convert to Muse config format (dictionary value)
            config = self._build_model_config(model, provider)
            extra_models[model_key] = config

            # Ensure directory exists
            extra_models_path.parent.mkdir(parents=True, exist_ok=True)

            # Save updated configuration (atomic write)
            temp_path = extra_models_path.with_suffix(".tmp")
            with open(temp_path, "w", encoding="utf-8") as f:
                f.write(json.dumps(extra_models, option=orjson.OPT_INDENT_4).decode())
            temp_path.replace(extra_models_path)

            emit_info(f"Added {model_key} to extra_models.json")
            return True

        except Exception as e:
            emit_error(f"Error adding model to extra_models.json: {e}")
            return False

    def _build_model_config(self, model: ModelInfo, provider: ProviderInfo) -> dict:
        """Build a Muse compatible model configuration.

        Format matches models.json structure:
        {
            "type": "openai" | "anthropic" | "gemini" | "custom_openai" | etc.,
            "name": "actual-model-id",
            "custom_endpoint": {"url": "...", "api_key": "$ENV_VAR"},  # if needed
            "context_length": 200000
        }
        """
        # Map provider IDs to Muse types
        type_mapping = {
            "openai": "openai",
            "anthropic": "anthropic",
            "google": "gemini",
            "google-vertex": "gemini",
            "mistral": "custom_openai",
            "groq": "custom_openai",
            "together-ai": "custom_openai",
            "fireworks": "custom_openai",
            "deepseek": "custom_openai",
            "openrouter": "custom_openai",
            "cerebras": "cerebras",
            "cohere": "custom_openai",
            "perplexity": "custom_openai",
            "minimax": "custom_anthropic",
        }

        # Determine the model type
        model_type = type_mapping.get(provider.id, "custom_openai")

        # Special case: kimi-for-coding uses "kimi-for-coding" as the model name
        # instead of the model_id from models.dev (which is "kimi-k2-thinking")
        if provider.id == "kimi-for-coding":
            model_name = "kimi-for-coding"
        else:
            model_name = model.model_id

        config: dict = {
            "type": model_type,
            "provider": derive_provider_identity(provider),
            "name": model_name,
        }

        # Add custom endpoint for non-standard providers
        if model_type == "custom_openai":
            # Get the API URL - prefer provider.api, fall back to hardcoded endpoints
            api_url = provider.api
            if not api_url or api_url == "N/A":
                api_url = PROVIDER_ENDPOINTS.get(provider.id)

            if api_url:
                # Determine the API key environment variable
                api_key_env = f"${provider.env[0]}" if provider.env else "$API_KEY"
                config["custom_endpoint"] = {"url": api_url, "api_key": api_key_env}

        # Special handling for minimax: uses custom_anthropic but needs custom_endpoint
        # and the URL needs /v1 stripped (comes as https://api.minimax.io/anthropic/v1)
        if provider.id == "minimax" and provider.api:
            api_url = provider.api
            # Strip /v1 suffix if present
            if api_url.endswith("/v1"):
                api_url = api_url[:-3]
            api_key_env = f"${provider.env[0]}" if provider.env else "$API_KEY"
            config["custom_endpoint"] = {"url": api_url, "api_key": api_key_env}

        # Add context length if available
        if model.context_length and model.context_length > 0:
            config["context_length"] = model.context_length

        # Add supported settings based on model type
        if model_type == "anthropic":
            config["supported_settings"] = [
                "temperature",
                "extended_thinking",
                "budget_tokens",
            ]
        elif model_type == "openai" and "gpt-5" in model.model_id:
            # GPT-5 models have special settings
            if "codex" in model.model_id:
                config["supported_settings"] = [
                    "temperature",
                    "top_p",
                    "reasoning_effort",
                ]
            else:
                config["supported_settings"] = [
                    "temperature",
                    "top_p",
                    "reasoning_effort",
                    "verbosity",
                ]
        else:
            # Default settings for most models
            config["supported_settings"] = ["temperature", "seed", "top_p"]

        return config
