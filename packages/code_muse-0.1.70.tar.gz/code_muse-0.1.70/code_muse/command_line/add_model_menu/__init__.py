"""Interactive terminal UI for browsing and adding models from models_dev_api.json.

Provides a beautiful split-panel interface for browsing providers and models
with live preview of model details and one-click addition to extra_models.json.
"""

from code_muse.command_line.add_model_menu._config_writer import ConfigWriterMixin
from code_muse.command_line.add_model_menu._constants import (
    PAGE_SIZE,
    PROVIDER_ENDPOINTS,
    PROVIDER_IDENTITY_MAPPING,
    UNSUPPORTED_PROVIDERS,
    derive_provider_identity,
)
from code_muse.command_line.add_model_menu._credential_prompt import (
    CredentialPromptMixin,
)
from code_muse.command_line.add_model_menu._menu_render import MenuRenderMixin
from code_muse.command_line.add_model_menu._menu_tui import (
    MenuTUIMixin,
    interactive_model_picker,
)


class AddModelMenu(
    MenuRenderMixin,
    ConfigWriterMixin,
    CredentialPromptMixin,
    MenuTUIMixin,
):
    """Interactive TUI for browsing and adding models.

    Composed from focused mixins:
    - MenuRenderMixin: display/rendering logic
    - ConfigWriterMixin: model config persistence
    - CredentialPromptMixin: API key / credential prompting
    - MenuTUIMixin: state, navigation, keybindings, run loop
    """


__all__ = [
    "AddModelMenu",
    "interactive_model_picker",
    "PAGE_SIZE",
    "PROVIDER_ENDPOINTS",
    "PROVIDER_IDENTITY_MAPPING",
    "UNSUPPORTED_PROVIDERS",
    "derive_provider_identity",
]
