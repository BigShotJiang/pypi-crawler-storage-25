"""Core TUI state, navigation, keybindings, and run loop for the add-model menu."""

import sys
import time

from prompt_toolkit.application import Application
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import Dimension, Layout, VSplit, Window
from prompt_toolkit.layout.controls import FormattedTextControl
from prompt_toolkit.widgets import Frame

from code_muse.command_line.pagination import (
    ensure_visible_page,
    get_page_for_index,
    get_total_pages,
)
from code_muse.command_line.utils import safe_input
from code_muse.list_filtering import query_matches_text
from code_muse.messaging import emit_error, emit_info, emit_warning
from code_muse.models_dev_parser import ModelInfo, ModelsDevRegistry, ProviderInfo
from code_muse.tools.command_runner import set_awaiting_user_input

from ._constants import PAGE_SIZE, UNSUPPORTED_PROVIDERS


class MenuTUIMixin:
    """Mixin providing core state, navigation, keybindings, and the TUI run loop.

    Combined with MenuRenderMixin, ConfigWriterMixin, and CredentialPromptMixin
    to form the complete AddModelMenu class.
    """

    def __init__(self):
        """Initialize the model browser menu."""
        self.registry: ModelsDevRegistry | None = None
        self.providers: list[ProviderInfo] = []
        self.current_provider: ProviderInfo | None = None
        self.current_models: list[ModelInfo] = []

        # State management
        self.view_mode = "providers"  # "providers" or "models"
        self.selected_provider_idx = 0
        self.selected_model_idx = 0
        self.current_page = 0
        self.result = None  # Track if user added a model
        self.provider_filter = ""
        self.model_filter = ""

        # Pending model for credential prompting
        self.pending_model: ModelInfo | None = None
        self.pending_provider: ProviderInfo | None = None

        # Custom model support
        self.is_custom_model_selected = False
        self.custom_model_name: str | None = None

        # Initialize registry
        self._initialize_registry()

    def _initialize_registry(self):
        """Initialize the ModelsDevRegistry with error handling.

        Fetches from live models.dev API first, falls back to bundled JSON.
        """
        try:
            self.registry = (
                ModelsDevRegistry()
            )  # Will try API first, then bundled fallback
            self.providers = self.registry.get_providers()
            if not self.providers:
                emit_error("No providers found in models database")
        except FileNotFoundError as e:
            emit_error(f"Models database unavailable: {e}")
        except Exception as e:
            emit_error(f"Error loading models registry: {e}")

    def _get_current_provider(self) -> ProviderInfo | None:
        """Get the currently selected provider."""
        filtered_providers = self._filtered_providers()
        if 0 <= self.selected_provider_idx < len(filtered_providers):
            return filtered_providers[self.selected_provider_idx]
        return None

    def _get_current_model(self) -> ModelInfo | None:
        """Get the currently selected model.

        Returns None if "Custom model" option is selected
        (which is at index len(current_models)).
        """
        if self.view_mode == "models" and self.current_provider:
            # Check if custom model option is selected (it's the last item)
            filtered_models = self._filtered_models()
            if self._should_show_custom_model() and (
                self.selected_model_idx == len(filtered_models)
            ):
                return None  # Custom model selected
            if 0 <= self.selected_model_idx < len(filtered_models):
                return filtered_models[self.selected_model_idx]
        return None

    def _is_custom_model_selected(self) -> bool:
        """Check if the custom model option is currently selected."""
        if self.view_mode == "models" and self.current_provider:
            return self._should_show_custom_model() and (
                self.selected_model_idx == len(self._filtered_models())
            )
        return False

    def _filtered_providers(self) -> list[ProviderInfo]:
        provider_filter = getattr(self, "provider_filter", "")
        if not provider_filter:
            return self.providers
        return [
            provider
            for provider in self.providers
            if query_matches_text(provider_filter, provider.name, provider.id)
        ]

    def _filtered_models(self) -> list[ModelInfo]:
        model_filter = getattr(self, "model_filter", "")
        if not model_filter:
            return self.current_models
        return [
            model
            for model in self.current_models
            if query_matches_text(
                model_filter,
                model.name,
                model.model_id,
                getattr(model, "full_id", ""),
            )
        ]

    def _should_show_custom_model(self) -> bool:
        model_filter = getattr(self, "model_filter", "")
        return (
            not model_filter
            or not self._filtered_models()
            or query_matches_text(model_filter, "custom model")
        )

    def _get_active_filter_text(self) -> str:
        if self.view_mode == "providers":
            return getattr(self, "provider_filter", "")
        return getattr(self, "model_filter", "")

    def _sync_provider_selection(self, preferred_provider: ProviderInfo | None) -> None:
        filtered_providers = self._filtered_providers()
        if not filtered_providers:
            self.selected_provider_idx = 0
            self.current_page = 0
            return

        if preferred_provider and preferred_provider in filtered_providers:
            self.selected_provider_idx = filtered_providers.index(preferred_provider)
        else:
            self.selected_provider_idx = min(
                self.selected_provider_idx, len(filtered_providers) - 1
            )
        self._ensure_selection_visible()

    def _sync_model_selection(
        self, preferred_model: ModelInfo | None, preferred_custom: bool
    ) -> None:
        filtered_models = self._filtered_models()
        total_items = len(filtered_models) + int(self._should_show_custom_model())
        if total_items <= 0:
            self.selected_model_idx = 0
            self.current_page = 0
            return

        if preferred_custom and self._should_show_custom_model():
            self.selected_model_idx = len(filtered_models)
        elif preferred_model and preferred_model in filtered_models:
            self.selected_model_idx = filtered_models.index(preferred_model)
        else:
            self.selected_model_idx = min(self.selected_model_idx, total_items - 1)
        self._ensure_selection_visible()

    def _set_provider_filter(self, value: str) -> None:
        preferred_provider = self._get_current_provider()
        self.provider_filter = value
        self._sync_provider_selection(preferred_provider)

    def _set_model_filter(self, value: str) -> None:
        preferred_model = self._get_current_model()
        preferred_custom = self._is_custom_model_selected()
        self.model_filter = value
        self._sync_model_selection(preferred_model, preferred_custom)

    def _append_filter_char(self, value: str) -> None:
        if self.view_mode == "providers":
            self._set_provider_filter(getattr(self, "provider_filter", "") + value)
        else:
            self._set_model_filter(getattr(self, "model_filter", "") + value)

    def _delete_filter_char(self) -> bool:
        if self.view_mode == "providers":
            provider_filter = getattr(self, "provider_filter", "")
            if not provider_filter:
                return False
            self._set_provider_filter(provider_filter[:-1])
            return True

        model_filter = getattr(self, "model_filter", "")
        if not model_filter:
            return False
        self._set_model_filter(model_filter[:-1])
        return True

    def _clear_active_filter(self) -> bool:
        if self.view_mode == "providers":
            if not getattr(self, "provider_filter", ""):
                return False
            self._set_provider_filter("")
            return True

        if not getattr(self, "model_filter", ""):
            return False
        self._set_model_filter("")
        return True

    def _get_total_items(self) -> int:
        """Return the number of items in the active list view."""
        if self.view_mode == "providers":
            return len(self._filtered_providers())
        return len(self._filtered_models()) + int(self._should_show_custom_model())

    def _get_selected_index(self) -> int:
        """Return the selected absolute index for the active list view."""
        if self.view_mode == "providers":
            return self.selected_provider_idx
        return self.selected_model_idx

    def _set_selected_index(self, index: int) -> None:
        """Set the selected absolute index for the active list view."""
        if self.view_mode == "providers":
            self.selected_provider_idx = index
        else:
            self.selected_model_idx = index

    def _ensure_selection_visible(self) -> None:
        """Keep the selected item on the current page."""
        self.current_page = ensure_visible_page(
            self._get_selected_index(),
            self.current_page,
            self._get_total_items(),
            PAGE_SIZE,
        )

    def _go_to_previous_page(self) -> None:
        """Move to the previous page and select its first item."""
        if self.current_page <= 0:
            return
        self.current_page -= 1
        self._set_selected_index(self.current_page * PAGE_SIZE)

    def _go_to_next_page(self) -> None:
        """Move to the next page and select its first item."""
        total_pages = get_total_pages(self._get_total_items(), PAGE_SIZE)
        if self.current_page >= total_pages - 1:
            return
        self.current_page += 1
        self._set_selected_index(self.current_page * PAGE_SIZE)

    def _enter_provider(self):
        """Enter the selected provider to view its models."""
        provider = self._get_current_provider()
        if not provider or not self.registry:
            return

        self.current_provider = provider
        self.current_models = self.registry.get_models(provider.id)
        self.view_mode = "models"
        self.model_filter = ""
        self.selected_model_idx = 0
        self.current_page = get_page_for_index(self.selected_model_idx, PAGE_SIZE)
        self.update_display()

    def _go_back_to_providers(self):
        """Go back to providers view."""
        self.view_mode = "providers"
        self.current_provider = None
        self.current_models = []
        self.model_filter = ""
        self.selected_model_idx = 0
        self.current_page = get_page_for_index(self.selected_provider_idx, PAGE_SIZE)
        self.update_display()

    def _add_current_model(self):
        """Add the currently selected model to extra_models.json."""
        provider = self.current_provider

        if not provider:
            return

        # Block unsupported providers
        if provider.id in UNSUPPORTED_PROVIDERS:
            self.result = "unsupported"
            return

        # Check if custom model option is selected
        if self._is_custom_model_selected():
            self.is_custom_model_selected = True
            self.pending_provider = provider
            self.result = (
                "pending_custom_model"  # Signal to prompt for custom model name
            )
            return

        model = self._get_current_model()
        if model:
            # Store model/provider for credential prompting after TUI exits
            self.pending_model = model
            self.pending_provider = provider
            self.result = "pending_credentials"  # Signal to prompt for credentials

    def _try_add_current_model(self) -> bool:
        """Attempt to add the current model selection and report success."""
        if self.view_mode != "models" or self._get_total_items() <= 0:
            return False

        self._add_current_model()
        return self.result is not None

    def run(self) -> bool:
        """Run the interactive model browser (synchronous).

        Returns:
            True if a model was added, False otherwise
        """
        if not self.registry or not self.providers:
            emit_warning("No models data available.")
            return False

        # Build UI
        self.menu_control = FormattedTextControl(text="")
        self.preview_control = FormattedTextControl(text="")

        menu_window = Window(
            content=self.menu_control, wrap_lines=True, width=Dimension(weight=30)
        )
        preview_window = Window(
            content=self.preview_control, wrap_lines=True, width=Dimension(weight=70)
        )

        menu_frame = Frame(menu_window, width=Dimension(weight=30), title="Browse")
        preview_frame = Frame(
            preview_window, width=Dimension(weight=70), title="Details"
        )

        root_container = VSplit([menu_frame, preview_frame])

        # Key bindings
        kb = KeyBindings()

        @kb.add("up")
        @kb.add("c-p")  # Ctrl+P = previous (Emacs-style)
        def _(event):
            if self.view_mode == "providers":
                if self.selected_provider_idx > 0:
                    self.selected_provider_idx -= 1
                    self._ensure_selection_visible()
            else:  # models view
                if self.selected_model_idx > 0:
                    self.selected_model_idx -= 1
                    self._ensure_selection_visible()
            self.update_display()

        @kb.add("down")
        @kb.add("c-n")  # Ctrl+N = next (Emacs-style)
        def _(event):
            if self.view_mode == "providers":
                if self.selected_provider_idx < len(self._filtered_providers()) - 1:
                    self.selected_provider_idx += 1
                    self._ensure_selection_visible()
            else:  # models view - include custom model option at the end
                max_index = self._get_total_items() - 1
                if self.selected_model_idx < max_index:
                    self.selected_model_idx += 1
                    self._ensure_selection_visible()
            self.update_display()

        @kb.add("left")
        def _(event):
            """Previous page."""
            self._go_to_previous_page()
            self.update_display()

        @kb.add("right")
        def _(event):
            """Next page."""
            self._go_to_next_page()
            self.update_display()

        @kb.add("enter")
        def _(event):
            if self.view_mode == "providers":
                self._enter_provider()
            elif self.view_mode == "models" and self._try_add_current_model():
                # Enter adds the model when viewing models
                event.app.exit()

        @kb.add("escape")
        def _(event):
            if self.view_mode == "models":
                self._go_back_to_providers()

        @kb.add("backspace")
        def _(event):
            if self._delete_filter_char():
                self.update_display()
                return
            if self.view_mode == "models":
                self._go_back_to_providers()

        @kb.add("c-u")
        def _(event):
            if self._clear_active_filter():
                self.update_display()

        @kb.add("<any>")
        def _(event):
            if not event.data or not event.data.isprintable():
                return
            self._append_filter_char(event.data)
            self.update_display()

        @kb.add("c-c")
        def _(event):
            event.app.exit()

        layout = Layout(root_container)
        app = Application(
            layout=layout,
            key_bindings=kb,
            full_screen=False,
            mouse_support=False,
        )

        set_awaiting_user_input(True)

        # Enter alternate screen buffer once for entire session
        sys.stdout.write("\033[?1049h")  # Enter alternate buffer
        sys.stdout.write("\033[2J\033[H")  # Clear and home
        sys.stdout.flush()
        time.sleep(0.05)

        try:
            # Initial display
            self.update_display()

            # Just clear the current buffer (don't switch buffers)
            sys.stdout.write("\033[2J\033[H")  # Clear screen within current buffer
            sys.stdout.flush()

            # Run application in a background thread to avoid event loop conflicts
            # This is needed because code_muse runs in an async context
            app.run(in_thread=True)

        finally:
            # Exit alternate screen buffer once at end
            sys.stdout.write("\033[?1049l")  # Exit alternate buffer
            sys.stdout.flush()
            # Reset awaiting input flag
            set_awaiting_user_input(False)

        # Clear exit message (unless we're about to prompt for more input)
        if self.result not in ("pending_credentials", "pending_custom_model"):
            emit_info("✓ Exited model browser")

        # Handle unsupported provider
        if self.result == "unsupported" and self.current_provider:
            reason = UNSUPPORTED_PROVIDERS.get(
                self.current_provider.id, "Not supported"
            )
            emit_error(f"Cannot add model from {self.current_provider.name}: {reason}")
            return False

        # Handle custom model flow after TUI exits
        if self.result == "pending_custom_model" and self.pending_provider:
            # Prompt for custom model details (name and context size)
            custom_model_result = self._prompt_for_custom_model()
            if not custom_model_result:
                return False

            model_name, context_length = custom_model_result

            # Create a ModelInfo for the custom model
            self.pending_model = self._create_custom_model_info(
                model_name, context_length
            )

            # Prompt for any missing credentials
            if self._prompt_for_credentials(
                self.pending_provider
            ) and self._add_model_to_extra_config(
                self.pending_model, self.pending_provider
            ):
                # Now add the model to config
                self.result = "added"
                return True
            return False

        # Handle pending credential flow after TUI exits
        if (
            self.result == "pending_credentials"
            and self.pending_model
            and self.pending_provider
        ):
            # Warn about non-tool-calling models
            if not self.pending_model.tool_call:
                emit_warning(
                    f"⚠️  {self.pending_model.name} "
                    f"does NOT support tool calling!\n"
                    f"   This model won't be able to edit files, "
                    f"run commands, or use any tools.\n"
                    f"   It will be very limited for coding tasks."
                )
                try:
                    confirm = safe_input(
                        "\n  Are you sure you want to add this model? (y/N): "
                    ).lower()
                    if confirm not in ("y", "yes"):
                        emit_info("Model addition cancelled.")
                        return False
                except KeyboardInterrupt, EOFError:
                    emit_info("")
                    return False

            # Prompt for any missing credentials
            if self._prompt_for_credentials(
                self.pending_provider
            ) and self._add_model_to_extra_config(
                self.pending_model, self.pending_provider
            ):
                # Now add the model to config
                self.result = "added"
                return True
            return False

        return self.result == "added"


def interactive_model_picker() -> bool:
    """Show interactive terminal UI to browse and add models.

    Returns:
        True if a model was added, False otherwise
    """
    from code_muse.command_line.add_model_menu import AddModelMenu

    menu = AddModelMenu()
    return menu.run()
