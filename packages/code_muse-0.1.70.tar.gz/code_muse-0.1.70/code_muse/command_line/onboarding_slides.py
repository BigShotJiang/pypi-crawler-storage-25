"""Slide content for the onboarding wizard.

Lean, mean, ADHD-friendly slides. 5 slides max!
"""


# ============================================================================
# Slide Data Constants
# ============================================================================

# Model subscription options
MODEL_OPTIONS: list[tuple[str, str, str]] = [
    ("chatgpt", "ChatGPT Plus/Pro/Max", "OAuth login - no API key needed"),
    ("claude", "Claude Code Pro/Max", "OAuth login - no API key needed"),
    ("api_keys", "API Keys", "OpenAI, Anthropic, Google, etc."),
    ("openrouter", "OpenRouter", "Single key for 100+ models"),
    ("skip", "Skip for now", "Configure later with /set or /add_model"),
]


# ============================================================================
# Navigation Footer (shown on ALL slides)
# ============================================================================


def get_nav_footer() -> str:
    """Navigation hints shown at bottom of every slide."""
    return (
        "\n[dim]─────────────────────────────────────[/dim]\n"
        "[green]→/l[/green] Next  "
        "[green]←/h[/green] Back  "
        "[green]↑↓/jk[/green] Options  "
        "[green]Enter[/green] Select  "
        "[yellow]ESC[/yellow] Skip"
    )


# ============================================================================
# Gradient Banner
# ============================================================================


def get_gradient_banner() -> str:
    """Generate the gradient MUSE banner (shared with launch banner)."""
    from code_muse.banner import BANNER_LINES

    palette = [
        "bright_yellow",
        "gold1",
        "dark_orange",
        "orange_red1",
        "bright_red",
        "medium_purple1",
    ]
    lines = []
    for i, line in enumerate(BANNER_LINES):
        colour = palette[i] if i < len(palette) else palette[-1]
        lines.append(f"[bold {colour}]{line}[/bold {colour}]")
    return "\n".join(lines)


# ============================================================================
# Slide Content (5 slides total)
# ============================================================================


def slide_welcome() -> str:
    """Slide 1: Welcome - quick intro."""
    content = get_gradient_banner()
    content += "\n\n"
    content += "[bold white]Welcome.[/bold white]\n\n"
    content += "[cyan]Quick setup:[/cyan]\n"
    content += "  1. Pick your model provider\n"
    content += "  2. Optional: External tools\n"
    content += "  3. Learn when to use which agent\n"
    content += "  4. Start coding!\n\n"
    content += "[dim]Takes ~1 minute. Let's go![/dim]"
    content += get_nav_footer()
    return content


def slide_models(selected_option: int, options: list[tuple[str, str]]) -> str:
    """Slide 2: Model selection."""
    content = "[bold cyan]📦 Pick Your Models[/bold cyan]\n\n"
    content += "[white]How do you want to access LLMs?[/white]\n\n"

    for i, (_, label) in enumerate(options):
        if i == selected_option:
            content += f"[bold green]▶ {label}[/bold green]\n"
        else:
            content += f"[dim]  {label}[/dim]\n"

    content += "\n"

    # Context based on selection
    opt = options[selected_option][0] if options else None
    if opt == "chatgpt":
        content += "[yellow]💡 ChatGPT OAuth[/yellow]\n"
        content += "  Uses your existing subscription\n"
        content += "  GPT-5.2, GPT-5.2-codex\n"
    elif opt == "claude":
        content += "[yellow]💡 Claude OAuth[/yellow]\n"
        content += "  Uses your existing subscription\n"
        content += "  Opus/Sonnet/Haiku 4.5\n"
    elif opt == "api_keys":
        content += "[yellow]💡 API Keys[/yellow]\n"
        content += "  [cyan]/set OPENAI_API_KEY=sk-...[/cyan]\n"
        content += "  [cyan]/add_model[/cyan] to browse 1500+ models\n"
    elif opt == "openrouter":
        content += "[yellow]💡 OpenRouter[/yellow]\n"
        content += "  One API key, all providers\n"
        content += "  [cyan]/set OPENROUTER_API_KEY=...[/cyan]\n"
    else:
        content += "[dim]No worries! Use /set or /add_model later[/dim]\n"

    content += get_nav_footer()
    return content


def slide_use_cases() -> str:
    """Slide 4: When to use which agent - THE IMPORTANT ONE."""
    content = "[bold cyan]🎯 When to Use What[/bold cyan]\n\n"

    content += "[bold yellow]Muse (default)[/bold yellow]\n"
    content += "  [green]USE FOR:[/green] Direct coding tasks\n"
    content += "  • Fix this bug\n"
    content += "  • Add a feature to this file\n"
    content += "  • Refactor this function\n"
    content += "  • Write tests for X\n\n"

    content += "[bold yellow]📋 Planning Agent[/bold yellow]\n"
    content += "  [green]USE FOR:[/green] Complex multi-step projects\n"
    content += "  • Build me a REST API with auth\n"
    content += "  • Create a CLI tool from scratch\n"
    content += "  • Refactor entire codebase\n"
    content += "  • Multi-file architectural changes\n\n"

    content += "[cyan]Switch: /agent planning-agent[/cyan]\n"
    content += "[dim]Planning breaks big tasks into steps,[/dim]\n"
    content += "[dim]then delegates to specialists.[/dim]"
    content += get_nav_footer()
    return content


def slide_done(trigger_oauth: str | None) -> str:
    """Slide 5: You're ready!"""
    content = "[bold green]🎉 Ready to Roll![/bold green]\n\n"
    content += "[bold cyan]Essential commands:[/bold cyan]\n"
    content += "  [cyan]/model[/cyan]   Switch models\n"
    content += "  [cyan]/agent[/cyan]   Switch agents\n"
    content += "  [cyan]/help[/cyan]    All commands\n\n"

    content += "[bold yellow]Pro tips:[/bold yellow]\n"
    content += "  • Be specific in prompts\n"
    content += "  • Use Planning Agent for big tasks\n"
    content += "  • @ for file path completion\n\n"

    if trigger_oauth:
        content += f"[bold cyan]→ {trigger_oauth.title()} OAuth next![/bold cyan]\n\n"

    content += "[dim]Re-run anytime: [/dim][cyan]/tutorial[/cyan]\n"
    content += "\n[bold yellow]Press Enter to start.[/bold yellow]"
    content += get_nav_footer()
    return content
