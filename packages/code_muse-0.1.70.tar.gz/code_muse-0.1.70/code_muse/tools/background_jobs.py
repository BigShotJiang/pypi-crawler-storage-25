"""Minimal background job registry with bounded log access.

Provides safe tracking of detached shell processes started via
``run_shell_command(background=True)``.  Jobs are stored in a
process-wide dict keyed by PID.  Log tailing is bounded to avoid
unbounded reads.

Each background job has an optional ``max_runtime`` (seconds).  When
provided and > 0, a lightweight watcher thread terminates the process
after the deadline expires and cleans up the registry entry.
"""

import contextlib
import logging
import os
import signal
import threading
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configurable background-job timeout
# ---------------------------------------------------------------------------

_DEFAULT_BACKGROUND_TIMEOUT: int = 600  # 10 minutes
_ENV_BACKGROUND_TIMEOUT: str = "MUSE_BACKGROUND_TIMEOUT"
_GRACE_PERIOD_SECONDS: float = 5.0  # SIGTERM → SIGKILL gap


def get_background_timeout() -> int:
    """Return the default max runtime (seconds) for background shell jobs.

    Reads ``MUSE_BACKGROUND_TIMEOUT`` from the environment (integer,
    seconds).  Falls back to 600 s (10 min).  A value of 0 disables the
    timeout entirely (useful for debugging).  Invalid / negative values
    are silently ignored and the default is used instead.
    """
    raw = os.environ.get(_ENV_BACKGROUND_TIMEOUT)
    if raw is None:
        return _DEFAULT_BACKGROUND_TIMEOUT
    try:
        val = int(raw)
        if val < 0:
            logger.warning(
                "Ignoring negative %s=%s; using default %ds",
                _ENV_BACKGROUND_TIMEOUT,
                raw,
                _DEFAULT_BACKGROUND_TIMEOUT,
            )
            return _DEFAULT_BACKGROUND_TIMEOUT
        return val
    except ValueError:
        logger.warning(
            "Ignoring invalid %s=%r; using default %ds",
            _ENV_BACKGROUND_TIMEOUT,
            raw,
            _DEFAULT_BACKGROUND_TIMEOUT,
        )
        return _DEFAULT_BACKGROUND_TIMEOUT


@dataclass
class BackgroundJob:
    pid: int
    command: str
    cwd: str | None
    log_file: str
    start_time: float = field(default_factory=lambda: os.times()[0])
    max_runtime: int | None = None  # Seconds; None/0 = no enforced limit
    group_id: str | None = None  # The agent session or group ID


# In-memory registry of background jobs keyed by PID
_BACKGROUND_JOBS: dict[int, BackgroundJob] = {}

# Maximum bytes to read when tailing a background log
_MAX_TAIL_BYTES = 32_768

# Maximum lines to return from a tail
_MAX_TAIL_LINES = 256


def register_background_job(
    pid: int,
    command: str,
    cwd: str | None,
    log_file: str,
    max_runtime: int | None = None,
    group_id: str | None = None,
) -> None:
    """Register a new background job.

    If *max_runtime* is > 0 a watcher thread is spawned that will
    terminate the process after *max_runtime* seconds and remove it
    from the registry.  When *max_runtime* is ``None`` the default
    from :func:`get_background_timeout` is used.  A value of ``0`` means
    "run forever" (no watcher).
    """
    if max_runtime is None:
        max_runtime = get_background_timeout()

    _BACKGROUND_JOBS[pid] = BackgroundJob(
        pid=pid,
        command=command,
        cwd=cwd,
        log_file=log_file,
        max_runtime=max_runtime,
        group_id=group_id,
    )

    if max_runtime and max_runtime > 0:
        _spawn_expiry_watcher(pid, max_runtime)


def list_background_jobs() -> list[BackgroundJob]:
    """Return a list of registered background jobs."""
    # Prune jobs whose log files no longer exist (rough heuristic)
    stale: list[int] = []
    for pid, job in list(_BACKGROUND_JOBS.items()):
        try:
            if not Path(job.log_file).exists():
                stale.append(pid)
        except OSError:
            stale.append(pid)
    for pid in stale:
        _BACKGROUND_JOBS.pop(pid, None)
    return list(_BACKGROUND_JOBS.values())


def stop_background_job(pid: int) -> bool:
    """Attempt to terminate a background job by PID.

    Sends SIGTERM to the process group (if POSIX), removes the job from
    the registry, and returns ``True`` if the job was known.  Returns
    ``False`` if the PID was not registered.
    """
    job = _BACKGROUND_JOBS.pop(pid, None)
    if job is None:
        return False
    _terminate_process(pid)
    return True


def stop_all_background_jobs_in_group(group_id: str) -> int:
    """Terminate all background jobs matching *group_id*.

    Returns the number of jobs terminated.
    """
    if not group_id:
        return 0

    to_stop = [pid for pid, job in _BACKGROUND_JOBS.items() if job.group_id == group_id]
    for pid in to_stop:
        stop_background_job(pid)

    return len(to_stop)


def _terminate_process(pid: int) -> None:
    """Best-effort termination of a process (and its group on POSIX)."""
    with contextlib.suppress(OSError, ProcessLookupError):
        if os.name == "posix":
            # Kill the entire process group (started with setsid)
            os.killpg(pid, signal.SIGTERM)
        else:
            os.kill(pid, signal.SIGTERM)


def _force_kill_process(pid: int) -> None:
    """Last-resort SIGKILL of a process (and its group on POSIX)."""
    with contextlib.suppress(OSError, ProcessLookupError):
        if os.name == "posix":
            os.killpg(pid, signal.SIGKILL)
        else:
            os.kill(pid, signal.SIGKILL)


# In-memory set of PIDs currently watched by an expiry thread.
# Used to prevent duplicate watchers and to support cancellation.
_EXPIRY_WATCHED_PIDS: set[int] = set()
_EXPIRY_WATCHED_LOCK = threading.Lock()


def _spawn_expiry_watcher(pid: int, max_runtime: int) -> None:
    """Start a daemon thread that kills *pid* after *max_runtime* seconds."""
    with _EXPIRY_WATCHED_LOCK:
        if pid in _EXPIRY_WATCHED_PIDS:
            return  # Already watched – shouldn't happen, but be safe.
        _EXPIRY_WATCHED_PIDS.add(pid)

    def _watcher() -> None:
        try:
            threading.Event().wait(timeout=max_runtime)
            # Check if the process is still alive before killing
            try:
                os.kill(pid, 0)  # Probe: raises if dead
            except OSError, ProcessLookupError:
                # Process already exited – just clean up registry.
                _BACKGROUND_JOBS.pop(pid, None)
                return

            # Process still alive → terminate
            logger.info(
                "Background job PID %d exceeded %ds runtime; terminating",
                pid,
                max_runtime,
            )
            _terminate_process(pid)

            # Grace period for graceful shutdown
            threading.Event().wait(timeout=_GRACE_PERIOD_SECONDS)
            try:
                os.kill(pid, 0)
            except OSError, ProcessLookupError:
                pass  # Terminated gracefully
            else:
                logger.warning(
                    "Background job PID %d still alive after SIGTERM; sending SIGKILL",
                    pid,
                )
                _force_kill_process(pid)
        finally:
            # Always clean up registry + watcher set
            _BACKGROUND_JOBS.pop(pid, None)
            with _EXPIRY_WATCHED_LOCK:
                _EXPIRY_WATCHED_PIDS.discard(pid)

    t = threading.Thread(target=_watcher, daemon=True, name=f"bg-expiry-{pid}")
    t.start()


def tail_background_job_log(pid: int, max_lines: int = _MAX_TAIL_LINES) -> str:
    """Return the tail of a background job's log file.

    Reads at most ``_MAX_TAIL_BYTES`` from the end of the log to avoid
    loading massive files into memory.
    """
    job = _BACKGROUND_JOBS.get(pid)
    if job is None:
        return ""
    try:
        path = Path(job.log_file)
        if not path.exists():
            return ""
        size = path.stat().st_size
        read_size = min(_MAX_TAIL_BYTES, size)
        with open(path, "rb") as f:
            f.seek(max(0, size - read_size))
            raw = f.read()
        text = raw.decode("utf-8", errors="replace")
        lines = deque(text.splitlines(), maxlen=max_lines)
        return "\n".join(lines)
    except OSError, ValueError:
        return ""
