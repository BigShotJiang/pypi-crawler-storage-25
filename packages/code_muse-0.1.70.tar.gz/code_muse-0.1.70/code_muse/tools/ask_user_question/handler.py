"""Ask User Question — handler, models, TUI, and rendering.

Consolidated module containing everything needed for the ask_user_question tool:
constants, theming, Pydantic models, TUI state, panel rendering, keyboard
handling, and the main ask_user_question() entry point.
"""

import asyncio
import io
import logging
import os
import re
import shutil
import sys
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Annotated, Any, Final, NamedTuple, TypeVar

from prompt_toolkit import Application
from prompt_toolkit.application import run_in_terminal
from prompt_toolkit.formatted_text import ANSI, FormattedText
from prompt_toolkit.key_binding import KeyBindings, KeyPressEvent
from prompt_toolkit.layout import Layout, VSplit, Window
from prompt_toolkit.layout.controls import FormattedTextControl
from prompt_toolkit.layout.dimension import Dimension
from prompt_toolkit.output import create_output
from prompt_toolkit.output.color_depth import ColorDepth
from prompt_toolkit.widgets import Frame
from pydantic import BaseModel, BeforeValidator, Field, ValidationError, model_validator
from rich.console import Console
from rich.markup import escape as rich_escape

from code_muse.command_line.wiggum_state import is_wiggum_active
from code_muse.tools.subagent_context import is_subagent

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════════════════

# Question constraints
MAX_QUESTIONS_PER_CALL: Final[int] = 10
MIN_OPTIONS_PER_QUESTION: Final[int] = 2
MAX_OPTIONS_PER_QUESTION: Final[int] = 6
MAX_HEADER_LENGTH: Final[int] = 60
MAX_LABEL_LENGTH: Final[int] = 50
MAX_DESCRIPTION_LENGTH: Final[int] = 200
MAX_QUESTION_LENGTH: Final[int] = 500
MAX_OTHER_TEXT_LENGTH: Final[int] = 500

# UI settings
DEFAULT_TIMEOUT_SECONDS: Final[int] = 300
TIMEOUT_WARNING_SECONDS: Final[int] = 60
AUTO_ADD_OTHER_OPTION: Final[bool] = True

# Other option configuration
OTHER_OPTION_LABEL: Final[str] = "Other"
OTHER_OPTION_DESCRIPTION: Final[str] = "Enter a custom option"

# Left panel width
LEFT_PANEL_PADDING: Final[int] = 14
MIN_LEFT_PANEL_WIDTH: Final[int] = 21
MAX_LEFT_PANEL_WIDTH: Final[int] = 36

# Horizontal padding for panel content
PANEL_CONTENT_PADDING: Final[str] = "  "

# CI environment variables
CI_ENV_VARS: Final[tuple[str, ...]] = (
    "CI",
    "GITHUB_ACTIONS",
    "GITLAB_CI",
    "JENKINS_URL",
    "TRAVIS",
    "CIRCLECI",
    "BUILDKITE",
    "AZURE_PIPELINES",
    "TEAMCITY_VERSION",
)

# Terminal escape sequences
ENTER_ALT_SCREEN: Final[str] = "\033[?1049h"
EXIT_ALT_SCREEN: Final[str] = "\033[?1049l"
CLEAR_AND_HOME: Final[str] = "\033[2J\033[H"

# Unicode symbols
CURSOR_POINTER: Final[str] = "\u276f"  # ❯
CURSOR_TRIANGLE: Final[str] = "\u25b6"  # ▶
CHECK_MARK: Final[str] = "\u2713"  # ✓
RADIO_FILLED: Final[str] = "\u25cf"  # ●
BORDER_DOUBLE: Final[str] = "\u2550"  # ═
ARROW_LEFT: Final[str] = "\u2190"  # ←
ARROW_RIGHT: Final[str] = "\u2192"  # →
ARROW_UP: Final[str] = "\u2191"  # ↑
ARROW_DOWN: Final[str] = "\u2193"  # ↓
PIPE_SEPARATOR: Final[str] = "\u2502"  # │

# Panel rendering
MAX_READABLE_WIDTH: Final[int] = 120
HELP_BORDER_WIDTH: Final[int] = 50

# Error formatting
MAX_VALIDATION_ERRORS_SHOWN: Final[int] = 3

# Terminal synchronization delay
TERMINAL_SYNC_DELAY: Final[float] = 0.05


# ═══════════════════════════════════════════════════════════════════════════
# Theme
# ═══════════════════════════════════════════════════════════════════════════

_config_getter: Callable[[str], str | None] | None = None


def _get_config_value(key: str) -> str | None:
    """Safely get a config value, caching the import for performance."""
    global _config_getter
    if _config_getter is None:
        try:
            from code_muse.config import get_value

            _config_getter = get_value
        except ImportError:
            _config_getter = lambda _: None  # noqa: E731
    return _config_getter(key)


_T = TypeVar("_T", bound=NamedTuple)


def _apply_config_overrides[T: NamedTuple](
    default: _T, config_map: Mapping[str, str]
) -> _T:
    """Apply config overrides to a color scheme."""
    overrides = {}
    for field, config_key in config_map.items():
        value = _get_config_value(config_key)
        if value:
            overrides[field] = value
    return default._replace(**overrides) if overrides else default


class TUIColors(NamedTuple):
    """Color scheme for the prompt_toolkit left panel."""

    header_bold: str = "bold cyan"
    header_dim: str = "fg:ansicyan dim"
    cursor_active: str = "fg:ansigreen bold"
    cursor_inactive: str = "fg:ansiwhite"
    selected: str = "fg:ansicyan"
    selected_check: str = "fg:ansigreen"
    text_normal: str = ""
    text_dim: str = "fg:ansiwhite dim"
    text_warning: str = "fg:ansiyellow bold"
    help_key: str = "fg:ansigreen"
    help_text: str = "fg:ansiwhite dim"
    error: str = "fg:ansired"


_DEFAULT_TUI = TUIColors()

_TUI_CONFIG_MAP: dict[str, str] = {
    "header_bold": "tui_header_color",
    "cursor_active": "tui_cursor_color",
    "selected": "tui_selected_color",
}


def get_tui_colors() -> TUIColors:
    """Get the current TUI color scheme."""
    return _apply_config_overrides(_DEFAULT_TUI, _TUI_CONFIG_MAP)


class RichColors(NamedTuple):
    """Rich markup colors for the question panel."""

    header: str = "bold cyan"
    progress: str = "dim"
    question: str = "bold"
    question_hint: str = "dim"
    cursor: str = "green bold"
    selected: str = "cyan"
    normal: str = ""
    description: str = "dim"
    input_label: str = "bold yellow"
    input_text: str = "green"
    input_hint: str = "dim"
    help_border: str = "bold cyan"
    help_title: str = "bold cyan"
    help_section: str = "bold"
    help_key: str = "green"
    help_close: str = "dim"
    timeout_warning: str = "bold yellow"


_DEFAULT_RICH = RichColors()

_RICH_CONFIG_MAP: dict[str, str] = {
    "header": "tui_rich_header_color",
    "cursor": "tui_rich_cursor_color",
}


def get_rich_colors() -> RichColors:
    """Get Rich console colors for the question panel."""
    return _apply_config_overrides(_DEFAULT_RICH, _RICH_CONFIG_MAP)


# ═══════════════════════════════════════════════════════════════════════════
# Models
# ═══════════════════════════════════════════════════════════════════════════

ANSI_ESCAPE_PATTERN = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")


def sanitize_text(text: str) -> str:
    """Remove ANSI escape codes and strip whitespace."""
    return ANSI_ESCAPE_PATTERN.sub("", text).strip()


def _make_sanitizer(
    *, allow_none: bool = False, default: str = ""
) -> Callable[[Any], str]:
    """Create a sanitizer with configurable None handling."""

    def sanitize(v: Any) -> str:
        if v is None:
            if allow_none:
                return default
            raise ValueError("Value cannot be None")
        return sanitize_text(str(v))

    return sanitize


_sanitize_required = _make_sanitizer(allow_none=False)
_sanitize_optional = _make_sanitizer(allow_none=True, default="")


def _sanitize_header(v: Any) -> str:
    """Sanitize header: remove ANSI, strip, replace spaces with hyphens."""
    return _sanitize_required(v).replace(" ", "-")


def _check_unique(items: list[str], field_name: str) -> None:
    """Raise ValueError if items has duplicates (case-insensitive)."""
    lowered = [i.lower() for i in items]
    if len(lowered) != len(set(lowered)):
        raise ValueError(f"{field_name} must be unique")


class QuestionOption(BaseModel):
    """A single selectable option for a question."""

    label: Annotated[
        str,
        BeforeValidator(_sanitize_required),
        Field(
            min_length=1,
            max_length=MAX_LABEL_LENGTH,
            description="Short option name (1-5 words)",
        ),
    ]
    description: Annotated[
        str,
        BeforeValidator(_sanitize_optional),
        Field(
            default="",
            max_length=MAX_DESCRIPTION_LENGTH,
            description="Explanation of what this option means",
        ),
    ]


class Question(BaseModel):
    """A single question with multiple-choice options."""

    question: Annotated[
        str,
        BeforeValidator(_sanitize_required),
        Field(
            min_length=1,
            max_length=MAX_QUESTION_LENGTH,
            description="The full question text to display",
        ),
    ]
    header: Annotated[
        str,
        BeforeValidator(_sanitize_header),
        Field(
            min_length=1,
            max_length=MAX_HEADER_LENGTH,
            description="Short label for compact display (max 60 chars)",
        ),
    ]
    multi_select: Annotated[
        bool,
        Field(default=False, description="If true, user can select multiple options"),
    ]
    options: Annotated[
        list[QuestionOption],
        Field(
            min_length=MIN_OPTIONS_PER_QUESTION,
            max_length=MAX_OPTIONS_PER_QUESTION,
            description="Array of 2-6 selectable options",
        ),
    ]

    @model_validator(mode="after")
    def validate_unique_labels(self) -> Question:
        """Ensure all option labels are unique within a question."""
        _check_unique([opt.label for opt in self.options], "Option labels")
        return self


class AskUserQuestionInput(BaseModel):
    """Input schema for the ask_user_question tool."""

    questions: Annotated[
        list[Question],
        Field(
            min_length=1,
            max_length=MAX_QUESTIONS_PER_CALL,
            description="Array of 1-10 questions to ask",
        ),
    ]

    @model_validator(mode="after")
    def validate_unique_headers(self) -> AskUserQuestionInput:
        """Ensure all question headers are unique."""
        _check_unique([q.header for q in self.questions], "Question headers")
        return self


class QuestionAnswer(BaseModel):
    """Answer to a single question."""

    question_header: Annotated[
        str, Field(description="Header of the answered question")
    ]
    selected_options: Annotated[
        list[str], Field(default_factory=list, description="Labels of selected options")
    ]
    other_text: Annotated[
        str | None,
        Field(
            default=None,
            max_length=MAX_OTHER_TEXT_LENGTH,
            description="Custom text if 'Other' was selected",
        ),
    ]

    @property
    def has_other(self) -> bool:
        """Check if user provided custom 'Other' input."""
        return self.other_text is not None

    @property
    def is_empty(self) -> bool:
        """Check if no options were selected."""
        return not self.selected_options and self.other_text is None


class AskUserQuestionOutput(BaseModel):
    """Output schema for the ask_user_question tool."""

    answers: Annotated[
        list[QuestionAnswer],
        Field(default_factory=list, description="Answers to all questions"),
    ]
    cancelled: Annotated[
        bool, Field(default=False, description="True if user cancelled (Esc/Ctrl+C)")
    ]
    error: Annotated[
        str | None,
        Field(default=None, description="Error message if interaction failed"),
    ]
    timed_out: Annotated[
        bool, Field(default=False, description="True if interaction timed out")
    ]

    @property
    def success(self) -> bool:
        """Check if interaction completed successfully."""
        return not self.cancelled and self.error is None and not self.timed_out

    @classmethod
    def error_response(cls, error: str) -> AskUserQuestionOutput:
        """Create an error response."""
        return cls(error=error)

    @classmethod
    def cancelled_response(cls) -> AskUserQuestionOutput:
        """Create a cancelled response (intentional user action, not an error)."""
        return cls(answers=[], cancelled=True, error=None)

    @classmethod
    def timeout_response(cls, timeout: int) -> AskUserQuestionOutput:
        """Create a timeout response."""
        return cls(
            answers=[],
            cancelled=False,
            timed_out=True,
            error=f"Interaction timed out after {timeout} seconds of inactivity",
        )

    def get_answer(self, header: str) -> QuestionAnswer | None:
        """Get answer by question header (case-insensitive)."""
        header_lower = header.lower()
        return next(
            (a for a in self.answers if a.question_header.lower() == header_lower),
            None,
        )

    def get_selected(self, header: str) -> list[str]:
        """Get selected options for a question by header."""
        answer = self.get_answer(header)
        return answer.selected_options if answer else []


# ═══════════════════════════════════════════════════════════════════════════
# UI State
# ═══════════════════════════════════════════════════════════════════════════


class CancelledException(Exception):
    """Raised when user cancels the interaction."""


class QuestionUIState:
    """Holds the current UI state for the question interaction."""

    def __init__(self, questions: list[Question]) -> None:
        self.questions = questions
        self.current_question_index = 0
        self.cursor_positions: list[int] = [0] * len(questions)
        self.selected_options: list[set[int]] = [set() for _ in questions]
        self.single_selections: list[int | None] = [None] * len(questions)
        self.other_texts: list[str | None] = [None] * len(questions)
        self.entering_other_text = False
        self.other_text_buffer = ""
        self.show_help = False
        self.timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS
        self.last_activity_time: float = time.monotonic()

    def reset_activity_timer(self) -> None:
        self.last_activity_time = time.monotonic()

    def get_time_remaining(self) -> int:
        elapsed = time.monotonic() - self.last_activity_time
        return max(0, int(self.timeout_seconds - elapsed))

    def is_timed_out(self) -> bool:
        return self.get_time_remaining() <= 0

    def should_show_timeout_warning(self) -> bool:
        remaining = self.get_time_remaining()
        return remaining <= TIMEOUT_WARNING_SECONDS and remaining > 0

    @property
    def current_question(self) -> Question:
        return self.questions[self.current_question_index]

    def get_left_panel_width(self) -> int:
        max_header_len = max(len(q.header) for q in self.questions)
        width = max_header_len + LEFT_PANEL_PADDING
        return max(MIN_LEFT_PANEL_WIDTH, min(width, MAX_LEFT_PANEL_WIDTH))

    def get_other_text_for_question(self, index: int) -> str | None:
        return self.other_texts[index]

    def jump_to_first(self) -> None:
        self.current_cursor = 0

    def jump_to_last(self) -> None:
        self.current_cursor = self.total_options - 1

    @property
    def current_cursor(self) -> int:
        return self.cursor_positions[self.current_question_index]

    @current_cursor.setter
    def current_cursor(self, value: int) -> None:
        self.cursor_positions[self.current_question_index] = value

    @property
    def total_options(self) -> int:
        count = len(self.current_question.options)
        if AUTO_ADD_OTHER_OPTION:
            count += 1
        return count

    def is_question_answered(self, index: int) -> bool:
        question = self.questions[index]
        if question.multi_select:
            return (
                len(self.selected_options[index]) > 0
                or self.other_texts[index] is not None
            )
        return self.single_selections[index] is not None

    def is_other_option(self, index: int) -> bool:
        if not AUTO_ADD_OTHER_OPTION:
            return False
        return index == len(self.current_question.options)

    def enter_other_text_mode(self) -> None:
        self.entering_other_text = True
        self.other_text_buffer = self.other_texts[self.current_question_index] or ""

    def commit_other_text(self) -> None:
        if not self.other_text_buffer.strip():
            self.entering_other_text = False
            self.other_text_buffer = ""
            return
        self.other_texts[self.current_question_index] = self.other_text_buffer
        other_idx = len(self.current_question.options)
        self._select_option_at(self.current_question_index, other_idx)
        self.entering_other_text = False
        self.other_text_buffer = ""

    def _select_option_at(self, question_idx: int, option_idx: int) -> None:
        if self.questions[question_idx].multi_select:
            self.selected_options[question_idx].add(option_idx)
        else:
            self.single_selections[question_idx] = option_idx

    def select_all_options(self) -> None:
        if not self.current_question.multi_select:
            return
        for i in range(len(self.current_question.options)):
            self.selected_options[self.current_question_index].add(i)

    def select_no_options(self) -> None:
        if not self.current_question.multi_select:
            return
        self.selected_options[self.current_question_index].clear()
        self.other_texts[self.current_question_index] = None

    def move_cursor_up(self) -> None:
        if self.current_cursor > 0:
            self.current_cursor -= 1

    def move_cursor_down(self) -> None:
        if self.current_cursor < self.total_options - 1:
            self.current_cursor += 1

    def next_question(self) -> None:
        if self.current_question_index < len(self.questions) - 1:
            self.current_question_index += 1

    def prev_question(self) -> None:
        if self.current_question_index > 0:
            self.current_question_index -= 1

    def toggle_current_option(self) -> None:
        if not self.current_question.multi_select:
            return
        cursor = self.current_cursor
        selected = self.selected_options[self.current_question_index]
        if cursor in selected:
            selected.discard(cursor)
        else:
            selected.add(cursor)

    def select_current_option(self) -> None:
        if self.current_question.multi_select:
            return
        self.single_selections[self.current_question_index] = self.current_cursor

    def is_option_selected(self, index: int) -> bool:
        if self.current_question.multi_select:
            return index in self.selected_options[self.current_question_index]
        return self.single_selections[self.current_question_index] == index

    def _resolve_option_label(
        self, question: Question, question_idx: int, opt_idx: int
    ) -> tuple[str, str | None]:
        if AUTO_ADD_OTHER_OPTION and opt_idx == len(question.options):
            return OTHER_OPTION_LABEL, self.other_texts[question_idx]
        return question.options[opt_idx].label, None

    def build_answers(self) -> list[QuestionAnswer]:
        answers = []
        for i, question in enumerate(self.questions):
            selected_labels: list[str] = []
            other_text: str | None = None

            if question.multi_select:
                for opt_idx in sorted(self.selected_options[i]):
                    label, opt_other = self._resolve_option_label(question, i, opt_idx)
                    selected_labels.append(label)
                    if opt_other is not None:
                        other_text = opt_other
            else:
                sel_idx = self.single_selections[i]
                if sel_idx is not None:
                    label, other_text = self._resolve_option_label(question, i, sel_idx)
                    selected_labels.append(label)

            answers.append(
                QuestionAnswer(
                    question_header=question.header,
                    selected_options=selected_labels,
                    other_text=other_text,
                )
            )
        return answers


# ═══════════════════════════════════════════════════════════════════════════
# Renderers
# ═══════════════════════════════════════════════════════════════════════════


def render_question_panel(
    state: QuestionUIState,
    colors: RichColors | None = None,
    available_width: int | None = None,
) -> ANSI:
    """Render the right panel with the current question."""
    try:
        return _render_question_panel_unsafe(state, colors, available_width)
    except Exception as exc:  # noqa: BLE001
        buffer = io.StringIO()
        Console(file=buffer, force_terminal=True, no_color=True).print(
            f"[render error: {type(exc).__name__}: {exc}]",
            markup=False,
        )
        return ANSI(buffer.getvalue())


def _render_question_panel_unsafe(
    state: QuestionUIState,
    colors: RichColors | None,
    available_width: int | None,
) -> ANSI:
    if colors is None:
        colors = get_rich_colors()

    buffer = io.StringIO()
    if available_width is not None:
        terminal_width = min(available_width, MAX_READABLE_WIDTH)
    else:
        terminal_width = min(shutil.get_terminal_size().columns, MAX_READABLE_WIDTH)
    console = Console(
        file=buffer,
        force_terminal=True,
        width=terminal_width,
        legacy_windows=False,
        color_system="truecolor",
        no_color=False,
        force_interactive=True,
    )

    if state.show_help:
        return _render_help_overlay(console, buffer, colors)

    question = state.current_question
    q_num = state.current_question_index + 1
    total = len(state.questions)
    pad = PANEL_CONTENT_PADDING

    safe_header_decoration = rich_escape(f"[{question.header}]")
    safe_question = rich_escape(question.question)

    # Header
    console.print(
        f"{pad}[{colors.header}]{safe_header_decoration}[/{colors.header}] "
        f"[{colors.progress}]({q_num}/{total})[/{colors.progress}]"
    )
    console.print()

    # Question text
    if question.multi_select:
        console.print(
            f"{pad}[bold]? {safe_question}[/bold] [dim](select multiple)[/dim]"
        )
    else:
        console.print(f"{pad}[bold]? {safe_question}[/bold]")
    console.print()

    # Render options
    for i, option in enumerate(question.options):
        _render_option(
            console,
            label=option.label,
            description=option.description,
            is_cursor=state.current_cursor == i,
            is_selected=state.is_option_selected(i),
            multi_select=question.multi_select,
            colors=colors,
            padding=pad,
        )

    # Render "Other" option if enabled
    if AUTO_ADD_OTHER_OPTION:
        other_idx = len(question.options)
        other_text = state.get_other_text_for_question(state.current_question_index)
        if other_text:
            other_desc = f'"{rich_escape(other_text)}"'
        else:
            other_desc = OTHER_OPTION_DESCRIPTION
        _render_option(
            console,
            label=OTHER_OPTION_LABEL,
            description=other_desc,
            is_cursor=state.current_cursor == other_idx,
            is_selected=state.is_option_selected(other_idx),
            multi_select=question.multi_select,
            colors=colors,
            padding=pad,
        )

    # If entering "Other" text, show the input field
    if state.entering_other_text:
        console.print()
        input_lbl = colors.input_label
        input_txt = colors.input_text
        input_hnt = colors.input_hint
        console.print(f"{pad}[{input_lbl}]Enter your custom option:[/{input_lbl}]")
        console.print(f"{pad}[{input_txt}]> {state.other_text_buffer}_[/{input_txt}]")
        console.print()
        console.print(
            f"{pad}[{input_hnt}]Enter to confirm, Esc to cancel[/{input_hnt}]"
        )

    # Help text at bottom
    console.print()
    is_last = state.current_question_index == total - 1
    help_parts = [
        "Space Toggle" if question.multi_select else "Space Select",
        "Enter Next" if not is_last else None,
        f"{ARROW_LEFT}{ARROW_RIGHT} Questions" if total > 1 else None,
        "Ctrl+S Submit",
        "? Help",
    ]
    separator = f" {PIPE_SEPARATOR} "
    help_text = separator.join(p for p in help_parts if p)
    console.print(f"{pad}[{colors.description}]{help_text}[/{colors.description}]")

    # Show timeout warning if approaching timeout
    if state.should_show_timeout_warning():
        remaining = state.get_time_remaining()
        tw = colors.timeout_warning
        console.print()
        console.print(
            f"{pad}[{tw}]⚠ Timeout in {remaining}s - press any key to continue[/{tw}]"
        )

    return ANSI(buffer.getvalue())


_HELP_SECTIONS: list[tuple[str, list[tuple[str, str | None, str]]]] = [
    (
        "Navigation:",
        [
            (ARROW_UP, "k", "Move up"),
            (ARROW_DOWN, "j", "Move down"),
            (ARROW_LEFT, "h", "Previous question"),
            (ARROW_RIGHT, "l", "Next question"),
            ("g", None, "Jump to first option"),
            ("G", None, "Jump to last option"),
        ],
    ),
    (
        "Selection:",
        [
            ("Space", None, "Select option (radio) / Toggle (checkbox)"),
            ("Enter", None, "Next question (select + advance)"),
            ("a", None, "Select all (multi-select)"),
            ("n", None, "Select none (multi-select)"),
            ("Ctrl+S", None, "Submit all answers"),
        ],
    ),
    (
        "Other:",
        [
            ("Tab", None, "Peek behind (toggle TUI visibility)"),
            ("?", None, "Toggle this help"),
            ("Esc", None, "Cancel"),
            ("Ctrl+C", None, "Cancel"),
        ],
    ),
]


def _render_help_overlay(
    console: Console, buffer: io.StringIO, colors: RichColors
) -> ANSI:
    """Render the help overlay."""
    pad = PANEL_CONTENT_PADDING
    border = colors.help_border
    key_style = colors.help_key
    section_style = colors.help_section

    border_line = f"{pad}[{border}]{BORDER_DOUBLE * HELP_BORDER_WIDTH}[/{border}]"

    console.print(border_line)
    console.print(
        f"{pad}[{colors.help_title}]           KEYBOARD SHORTCUTS[/{colors.help_title}]"
    )
    console.print(border_line)
    console.print()

    for section_name, shortcuts in _HELP_SECTIONS:
        console.print(f"{pad}[{section_style}]{section_name}[/{section_style}]")
        for primary, alt, desc in shortcuts:
            if alt:
                console.print(
                    f"{pad}  [{key_style}]{primary}[/{key_style}] / "
                    f"[{key_style}]{alt}[/{key_style}]       {desc}"
                )
            else:
                console.print(
                    f"{pad}  [{key_style}]{primary}[/{key_style}]           {desc}"
                )
        console.print()

    console.print(border_line)
    close_msg = (
        f"{pad}[{colors.help_close}]Press [{key_style}]?"
        f"[/{key_style}] to close this help[/{colors.help_close}]"
    )
    console.print(close_msg)
    console.print(border_line)

    return ANSI(buffer.getvalue())


def _render_option(
    console: Console,
    *,
    label: str,
    description: str,
    is_cursor: bool,
    is_selected: bool,
    multi_select: bool,
    colors: RichColors,
    padding: str = "",
) -> None:
    """Render a single option line."""
    label = rich_escape(label)
    description = rich_escape(description) if description else ""

    cursor_style = colors.cursor
    selected_style = colors.selected
    desc_style = colors.description

    if multi_select:
        checkbox = f"[{CHECK_MARK}]" if is_selected else "[ ]"
        if is_cursor:
            prefix = f"[{cursor_style}]{CURSOR_POINTER} {checkbox}[/{cursor_style}]"
        else:
            prefix = f"  {checkbox}"
    else:
        radio = f"({RADIO_FILLED})" if is_selected else "( )"
        if is_cursor:
            prefix = f"[{cursor_style}]{CURSOR_POINTER} {radio}[/{cursor_style}]"
        else:
            prefix = f"  {radio}"

    if is_cursor:
        label_styled = f"[{cursor_style}]{label}[/{cursor_style}]"
    elif is_selected:
        label_styled = f"[{selected_style}]{label}[/{selected_style}]"
    else:
        label_styled = label

    console.print(f"{padding}  {prefix} {label_styled}")

    if description:
        console.print(f"{padding}      [{desc_style}]{description}[/{desc_style}]")
    console.print()


# ═══════════════════════════════════════════════════════════════════════════
# TUI Loop
# ═══════════════════════════════════════════════════════════════════════════


def _wait_for_keypress() -> None:
    """Block until any key is pressed, reading directly from the terminal."""
    try:
        import msvcrt

        msvcrt.getch()
    except ImportError:
        import select
        import termios
        import tty

        fd = sys.__stdin__.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.__stdin__.read(1)
            if ch == "\x1b":
                while select.select([sys.__stdin__], [], [], 0.01)[0]:
                    sys.__stdin__.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


@dataclass(slots=True)
class TUIResult:
    """Result holder for the TUI interaction."""

    cancelled: bool = False
    confirmed: bool = False


async def run_question_tui(
    state: QuestionUIState,
) -> tuple[list[QuestionAnswer], bool, bool]:
    """Run the main question TUI loop."""
    result = TUIResult()
    timed_out = False
    kb = KeyBindings()

    # --- Factory for dual-mode handlers (vim keys that type in text mode) ---
    def make_dual_mode_handler(
        char: str, action: Callable[[], None]
    ) -> Callable[[KeyPressEvent], None]:
        def handler(event: KeyPressEvent) -> None:
            state.reset_activity_timer()
            if state.entering_other_text:
                state.other_text_buffer += char
            else:
                action()
            event.app.invalidate()

        return handler

    # --- Factory for arrow key navigation (don't type in text mode) ---
    def make_arrow_handler(
        action: Callable[[], None],
    ) -> Callable[[KeyPressEvent], None]:
        def handler(event: KeyPressEvent) -> None:
            state.reset_activity_timer()
            if not state.entering_other_text:
                action()
                event.app.invalidate()

        return handler

    kb.add("up")(make_arrow_handler(state.move_cursor_up))
    kb.add("down")(make_arrow_handler(state.move_cursor_down))
    kb.add("left")(make_arrow_handler(state.prev_question))
    kb.add("right")(make_arrow_handler(state.next_question))

    # --- Vim-style navigation ---
    kb.add("k")(make_dual_mode_handler("k", state.move_cursor_up))
    kb.add("j")(make_dual_mode_handler("j", state.move_cursor_down))
    kb.add("h")(make_dual_mode_handler("h", state.prev_question))
    kb.add("l")(make_dual_mode_handler("l", state.next_question))
    kb.add("g")(make_dual_mode_handler("g", state.jump_to_first))
    kb.add("G")(make_dual_mode_handler("G", state.jump_to_last))

    # --- Selection controls ---
    def _toggle_help() -> None:
        state.show_help = not state.show_help

    kb.add("a")(make_dual_mode_handler("a", state.select_all_options))
    kb.add("n")(make_dual_mode_handler("n", state.select_no_options))
    kb.add("?")(make_dual_mode_handler("?", _toggle_help))

    @kb.add("space")
    def toggle_option(event: KeyPressEvent) -> None:
        state.reset_activity_timer()
        if state.entering_other_text:
            state.other_text_buffer += " "
            event.app.invalidate()
            return
        if state.is_other_option(state.current_cursor):
            state.enter_other_text_mode()
            event.app.invalidate()
            return
        if state.current_question.multi_select:
            state.toggle_current_option()
        else:
            state.select_current_option()
        event.app.invalidate()

    @kb.add("enter")
    def advance_question(event: KeyPressEvent) -> None:
        state.reset_activity_timer()
        if state.entering_other_text:
            state.commit_other_text()
            event.app.invalidate()
            return
        if state.is_other_option(state.current_cursor):
            state.enter_other_text_mode()
            event.app.invalidate()
            return

        is_last_question = state.current_question_index == len(state.questions) - 1
        cursor_is_on_selected = state.is_option_selected(state.current_cursor)

        if not state.current_question.multi_select:
            state.select_current_option()

        if not is_last_question:
            state.next_question()
            event.app.invalidate()
        else:
            if cursor_is_on_selected:
                result.confirmed = True
                event.app.exit()
            else:
                event.app.invalidate()

    @kb.add("c-s")
    def submit_all(event: KeyPressEvent) -> None:
        state.reset_activity_timer()
        if state.entering_other_text:
            state.commit_other_text()
        result.confirmed = True
        event.app.exit()

    @kb.add("escape")
    def cancel(event: KeyPressEvent) -> None:
        state.reset_activity_timer()
        if state.entering_other_text:
            state.entering_other_text = False
            state.other_text_buffer = ""
            event.app.invalidate()
            return
        result.cancelled = True
        event.app.exit()

    @kb.add("c-c")
    def ctrl_c_cancel(event: KeyPressEvent) -> None:
        result.cancelled = True
        event.app.exit()

    @kb.add("tab")
    def toggle_peek(event: KeyPressEvent) -> None:
        state.reset_activity_timer()

        def _peek() -> None:
            sys.__stdout__.write(
                "\n  \033[2mPress any key to return to questions...\033[0m\n"
            )
            sys.__stdout__.flush()
            _wait_for_keypress()
            state.reset_activity_timer()

        run_in_terminal(_peek, in_executor=True)

    @kb.add("<any>")
    def handle_text_input(event: KeyPressEvent) -> None:
        state.reset_activity_timer()
        if state.entering_other_text:
            char = event.data
            if char and len(char) == 1 and ord(char) >= 32:
                state.other_text_buffer += char
                event.app.invalidate()

    @kb.add("backspace")
    def handle_backspace(event: KeyPressEvent) -> None:
        if state.entering_other_text and state.other_text_buffer:
            state.other_text_buffer = state.other_text_buffer[:-1]
            event.app.invalidate()

    # --- Panel rendering ---
    tui_colors = get_tui_colors()
    rich_colors = get_rich_colors()

    def get_left_panel_text() -> FormattedText:
        pad = "  "
        lines: list[tuple[str, str]] = [
            ("", pad),
            (tui_colors.header_bold, "Questions"),
            ("", "\n\n"),
        ]

        for i, question in enumerate(state.questions):
            is_current = i == state.current_question_index
            is_answered = state.is_question_answered(i)
            cursor = f"{CURSOR_TRIANGLE} " if is_current else "  "
            status = f"{CHECK_MARK} " if is_answered else "  "

            cursor_style = (
                tui_colors.cursor_active if is_current else tui_colors.cursor_inactive
            )
            content_style = (
                tui_colors.selected_check
                if is_answered
                else tui_colors.cursor_active
                if is_current
                else tui_colors.text_dim
            )

            lines.append(("", pad))
            if is_answered:
                lines.append((cursor_style, cursor))
                lines.append((content_style, status + question.header))
            else:
                lines.append((content_style, cursor + status + question.header))
            lines.append(("", "\n"))

        lines.extend(
            [
                ("", "\n"),
                ("", pad),
                (tui_colors.header_dim, f"{ARROW_LEFT}{ARROW_RIGHT} Switch question"),
                ("", "\n"),
                ("", pad),
                (tui_colors.header_dim, f"{ARROW_UP}{ARROW_DOWN} Navigate options"),
                ("", "\n"),
                ("", "\n"),
                ("", pad),
                (tui_colors.help_key, "Ctrl+S"),
                (tui_colors.header_dim, " Submit"),
                ("", "\n"),
                ("", pad),
                (tui_colors.help_key, "Tab"),
                (tui_colors.header_dim, " Peek behind"),
            ]
        )

        return FormattedText(lines)

    def get_right_panel_text() -> ANSI:
        term_width = shutil.get_terminal_size().columns
        available = term_width - left_panel_width - 4
        return render_question_panel(
            state, colors=rich_colors, available_width=available
        )

    # --- Layout ---
    left_panel_width = state.get_left_panel_width()

    left_panel = Window(
        content=FormattedTextControl(lambda: get_left_panel_text()),
        width=Dimension(preferred=left_panel_width, max=left_panel_width),
    )

    right_panel = Window(
        content=FormattedTextControl(lambda: get_right_panel_text()),
        wrap_lines=True,
    )

    root_container = VSplit(
        [
            Frame(left_panel, title=""),
            Frame(right_panel, title=""),
        ]
    )

    layout = Layout(root_container)

    output = create_output(stdout=sys.__stdout__)

    app = Application(
        layout=layout,
        key_bindings=kb,
        full_screen=True,
        mouse_support=False,
        color_depth=ColorDepth.DEPTH_24_BIT,
        output=output,
    )

    async def timeout_checker() -> None:
        nonlocal timed_out
        while True:
            await asyncio.sleep(1)
            if state.is_timed_out():
                timed_out = True
                app.exit()
                return
            app.invalidate()

    timeout_task = asyncio.create_task(timeout_checker())
    app_exception: BaseException | None = None

    try:
        await app.run_async()
    except BaseException as e:
        app_exception = e
    finally:
        timeout_task.cancel()
        await asyncio.gather(timeout_task, return_exceptions=True)

    if app_exception is not None:
        raise app_exception

    if timed_out:
        return ([], False, True)

    if result.cancelled:
        return ([], True, False)

    return (state.build_answers(), False, False)


# ═══════════════════════════════════════════════════════════════════════════
# Interactive Picker (async entry point)
# ═══════════════════════════════════════════════════════════════════════════


async def interactive_question_picker(
    questions: list[Question],
    timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS,
) -> tuple[list[QuestionAnswer], bool, bool]:
    """Show an interactive split-panel TUI for questions."""
    from code_muse.tools.command_runner import set_awaiting_user_input

    state = QuestionUIState(questions)
    state.timeout_seconds = timeout_seconds
    set_awaiting_user_input(True)

    try:
        return await run_question_tui(state)
    finally:
        set_awaiting_user_input(False)


# ═══════════════════════════════════════════════════════════════════════════
# Handler
# ═══════════════════════════════════════════════════════════════════════════


class AsyncContextError(RuntimeError):
    """Raised when TUI is called from async context without await."""


def _cancelled_response() -> AskUserQuestionOutput:
    """Create a standardized cancelled response."""
    return AskUserQuestionOutput.cancelled_response()


def is_interactive() -> bool:
    """Check if we're running in an interactive terminal."""
    try:
        if not sys.stdin.isatty():
            return False
    except AttributeError, OSError:
        return False
    return not any(os.environ.get(var) for var in CI_ENV_VARS)


def ask_user_question(
    questions: list[Question | dict[str, Any]],
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
) -> AskUserQuestionOutput:
    """Ask the user one or more interactive multiple-choice questions.

    Args:
        questions: List of question objects with question, header,
            multi_select, and options fields.
        timeout: Inactivity timeout in seconds (default: 300)

    Returns:
        AskUserQuestionOutput with answers, cancelled, error, timed_out fields.
    """
    logger.info("ask_user_question called with %d questions", len(questions))

    if is_subagent():
        logger.warning("ask_user_question called from sub-agent context - disabled")
        return AskUserQuestionOutput.error_response(
            "Interactive tools are disabled for sub-agents. "
            "Sub-agents should make reasonable decisions or return to the parent agent "
            "if user input is required."
        )

    if is_wiggum_active():
        logger.warning("ask_user_question called during wiggum mode - disabled")
        return AskUserQuestionOutput.error_response(
            "Interactive tools are disabled during /wiggum mode. "
            "The agent is running autonomously in a loop. "
            "Make a reasonable decision to proceed, or stop and wait for user input "
            "by completing the current task."
        )

    if not is_interactive():
        logger.warning("Non-interactive environment detected")
        return AskUserQuestionOutput.error_response(
            "Cannot ask questions: not running in an interactive terminal. "
            "Please provide configuration through arguments or config files."
        )

    try:
        validated_input = _validate_input(questions)
    except ValidationError as e:
        error_msg = _format_validation_error(e)
        logger.warning("Validation error: %s", error_msg)
        return AskUserQuestionOutput.error_response(error_msg)
    except (TypeError, ValueError) as e:
        logger.error("Unexpected validation error: %s", e, exc_info=True)
        return AskUserQuestionOutput.error_response(f"Validation error: {e!s}")

    try:
        answers, cancelled, timed_out = _run_interactive_picker(
            validated_input.questions, timeout
        )

        if timed_out:
            logger.info("Interaction timed out after %d seconds", timeout)
            return AskUserQuestionOutput.timeout_response(timeout)

        if cancelled:
            logger.info("User cancelled the interaction")
            return _cancelled_response()

        logger.info("Successfully collected %d answers", len(answers))
        return AskUserQuestionOutput(answers=answers)

    except CancelledException, KeyboardInterrupt:
        logger.info("User cancelled the interaction")
        return _cancelled_response()

    except OSError as e:
        logger.error("Unexpected error during interaction: %s", e)
        return AskUserQuestionOutput.error_response(f"Interaction error: {e!s}")


def _run_interactive_picker(
    questions: list[Question], timeout: int
) -> tuple[list[QuestionAnswer], bool, bool]:
    """Run the interactive TUI, handling async context detection."""
    try:
        asyncio.get_running_loop()
        raise AsyncContextError(
            "Cannot run interactive TUI from within an async context. "
            "Either call from synchronous code, or use "
            "'await interactive_question_picker()' directly for async callers."
        )
    except RuntimeError:
        pass

    return asyncio.run(interactive_question_picker(questions, timeout_seconds=timeout))


def _validate_input(
    questions: list[Question | dict[str, Any]],
) -> AskUserQuestionInput:
    """Validate and convert input dictionaries to Pydantic models."""
    return AskUserQuestionInput.model_validate({"questions": questions})


def _format_validation_error(error: ValidationError) -> str:
    """Format a Pydantic ValidationError into a readable string."""
    errors = error.errors()
    if not errors:
        return "Validation error"

    messages = []
    for err in errors[:MAX_VALIDATION_ERRORS_SHOWN]:
        loc = ".".join(str(x) for x in err["loc"])
        msg = err["msg"]
        messages.append(f"{loc}: {msg}")

    result = "Validation error: " + "; ".join(messages)
    if len(errors) > MAX_VALIDATION_ERRORS_SHOWN:
        result += f" (and {len(errors) - MAX_VALIDATION_ERRORS_SHOWN} more)"

    return result
