"""Ask User Question tool for Muse.

This tool allows agents to ask users interactive multiple-choice questions
through a terminal TUI interface.
"""

from .handler import (
    AskUserQuestionInput,
    AskUserQuestionOutput,
    Question,
    QuestionAnswer,
    QuestionOption,
    ask_user_question,
)
from .register import register_ask_user_question

__all__ = [
    "ask_user_question",
    "register_ask_user_question",
    "AskUserQuestionInput",
    "AskUserQuestionOutput",
    "Question",
    "QuestionAnswer",
    "QuestionOption",
]
