"""Core config parser infrastructure.

Atomic writes, caching, ensure_config_exists, get/set/reset value,
isolated_config, and key enumeration.

Extracted from ``parser.py`` to stay under the 600-line cap.
"""

import configparser
import contextlib
import os
import threading
from contextlib import contextmanager
from pathlib import Path

import code_muse.config.paths as paths

DEFAULT_SECTION = "muse"
REQUIRED_KEYS = ["agent_name", "owner_name"]

# Config cache to avoid repeated file reads
_config_cache: tuple[str, float, configparser.ConfigParser | None] = None
_config_cache_lock = threading.Lock()  # Module-level; avoids lazy-init race


def _atomic_write_config(config_parser: configparser.ConfigParser) -> None:
    """Write config atomically: write to temp, os.replace, enforce 0o600.

    Prevents truncated config on crash. Uses same pattern as
    code_muse.secret_storage.atomic_write_private_bytes.
    """
    global _config_cache
    tmp_path = str(paths.CONFIG_FILE) + ".tmp"
    try:
        # Write to temp file
        with open(tmp_path, "w", encoding="utf-8") as f:
            config_parser.write(f)
        # Atomic replace
        os.replace(tmp_path, str(paths.CONFIG_FILE))
        # Enforce private permissions
        os.chmod(paths.CONFIG_FILE, 0o600)
        os.chmod(paths.CONFIG_DIR, 0o700)
    except Exception:
        # Clean up temp file on failure
        with contextlib.suppress(OSError):
            os.unlink(tmp_path)
        raise
    # Invalidate cache after successful write
    _config_cache = None


def _get_cached_config() -> configparser.ConfigParser:
    """Return a cached ConfigParser, re-reading only when the file changes."""
    global _config_cache

    cache_key = str(paths.CONFIG_FILE)
    try:
        mtime = paths.CONFIG_FILE.stat().st_mtime
    except OSError:
        mtime = 0.0

    with _config_cache_lock:
        if (
            _config_cache is not None
            and _config_cache[0] == cache_key
            and _config_cache[1] == mtime
        ):
            return _config_cache[2]
        # Cache miss or file changed — reload
        config = configparser.ConfigParser()
        config.read(paths.CONFIG_FILE)
        _config_cache = (cache_key, mtime, config)
        return config


def ensure_config_exists():
    """
    Ensure that XDG directories and muse.cfg exist, prompting if needed.
    Returns configparser.ConfigParser for reading.
    """
    # Create all XDG directories with 0700 permissions per XDG spec
    for directory in [
        paths.CONFIG_DIR,
        paths.DATA_DIR,
        paths.CACHE_DIR,
        paths.STATE_DIR,
        paths.SKILLS_DIR,
    ]:
        if not directory.exists():
            directory.mkdir(parents=True, mode=0o700, exist_ok=True)
    # No need to re-import from paths; already imported as module
    exists = paths.CONFIG_FILE.is_file()
    config = configparser.ConfigParser()
    if exists:
        config.read(paths.CONFIG_FILE)
    missing = []
    if DEFAULT_SECTION not in config:
        config[DEFAULT_SECTION] = {}
    for key in REQUIRED_KEYS:
        if not config[DEFAULT_SECTION].get(key):
            missing.append(key)
    if missing:
        # Note: Using sys.stdout here for initial setup
        # before messaging system is available
        import sys

        sys.stdout.write("[Run] Let's get your agent ready.\n")
        sys.stdout.flush()
        for key in missing:
            if key == "agent_name":
                val = input("What should we name the agent? ").strip()
            elif key == "owner_name":
                val = input("What's your name (so Muse knows its owner)? ").strip()
            else:
                val = input(f"Enter {key}: ").strip()
            config[DEFAULT_SECTION][key] = val

    # Set default values for important config keys if they don't exist
    if not config[DEFAULT_SECTION].get("auto_save_session"):
        config[DEFAULT_SECTION]["auto_save_session"] = "true"
    if not config[DEFAULT_SECTION].get("animations_enabled"):
        config[DEFAULT_SECTION]["animations_enabled"] = "true"

    # Write the config if we made any changes
    if missing or not exists:
        _atomic_write_config(config)

    # Always enforce private permissions (even on pre-existing files)
    if paths.CONFIG_FILE.exists():
        os.chmod(paths.CONFIG_FILE, 0o600)

    # Belt-and-suspenders: enforce private CONFIG_DIR permissions
    os.chmod(paths.CONFIG_DIR, 0o700)
    return config


def get_value(key: str):
    config = _get_cached_config()
    val = config.get(DEFAULT_SECTION, key, fallback=None)
    return val


def get_config_keys():
    """
    Returns the list of all config keys currently in muse.cfg,
    plus certain preset expected keys.
    """
    from code_muse.config_appearance import DEFAULT_BANNER_COLORS

    default_keys = [
        "yolo_mode",
        "model",
        "compaction_strategy",
        "protected_token_count",
        "compaction_threshold",
        "summarization_model",
        "message_limit",
        "allow_recursion",
        "openai_reasoning_effort",
        "openai_reasoning_summary",
        "openai_verbosity",
        "auto_save_session",
        "max_saved_sessions",
        "http2",
        "diff_context_lines",
        "default_agent",
        "temperature",
        "auto_approve",
    ]
    # Add pack agents control key
    default_keys.append("enable_pack_agents")
    # Add universal constructor control key
    default_keys.append("enable_universal_constructor")
    # Add hook retry limit keys
    default_keys.append("max_hook_retries")
    default_keys.append("max_critic_retries")
    # Add safety/cost control keys
    default_keys.append("max_consecutive_tool_errors")
    default_keys.append("overall_run_timeout")
    # Add sub-agent depth cap key
    default_keys.append("max_subagent_depth")
    default_keys.append("total_tokens_limit")
    default_keys.append("max_tool_calls")
    # Add streaming control key
    default_keys.append("enable_streaming")
    # Add cancel agent key configuration
    default_keys.append("cancel_agent_key")
    # Add banner color keys
    for banner_name in DEFAULT_BANNER_COLORS:
        default_keys.append(f"banner_color_{banner_name}")
    # Add resume message count configuration
    default_keys.append("resume_message_count")
    # Add compaction tuning keys
    default_keys.append("recent_tool_results_to_keep")
    default_keys.append("max_messages_hard_cap")
    default_keys.append("filter_huge_message_threshold")

    config = configparser.ConfigParser()
    config.read(paths.CONFIG_FILE)
    keys = set(config[DEFAULT_SECTION].keys()) if DEFAULT_SECTION in config else set()
    keys.update(default_keys)
    return sorted(keys)


def set_config_value(key: str, value: str):
    """
    Sets a config value in the persistent config file.
    """
    config = configparser.ConfigParser()
    config.read(paths.CONFIG_FILE)
    if DEFAULT_SECTION not in config:
        config[DEFAULT_SECTION] = {}
    config[DEFAULT_SECTION][key] = value
    _atomic_write_config(config)


# Alias for API compatibility
def set_value(key: str, value: str) -> None:
    """Set a config value. Alias for set_config_value."""
    set_config_value(key, value)


def reset_value(key: str) -> None:
    """Remove a key from the config file, resetting it to default."""
    config = configparser.ConfigParser()
    config.read(paths.CONFIG_FILE)
    if DEFAULT_SECTION in config and key in config[DEFAULT_SECTION]:
        del config[DEFAULT_SECTION][key]
        _atomic_write_config(config)


@contextmanager
def isolated_config(temp_dir: Path):
    """Temporarily redirect ALL config paths to a temp directory. Restores on exit.

    Creates the full ``.muse/`` directory structure (config, data, cache, state
    subdirectories) under *temp_dir* and points every path constant in both
    ``code_muse.config.paths`` and ``code_muse.config`` to the temp equivalents.

    Unlike the previous implementation, this does **not** copy the real config
    file — each test starts from a clean slate.  This prevents cross-test bleed
    when a test mutates a shared config value.

    Yields ``(temp_config_file, temp_config_dir)``.
    """
    import code_muse.config as cfg_mod
    import code_muse.config.paths as paths

    global _config_cache

    # --- 1. Save originals ---------------------------------------------------
    _PATH_ATTRS = [
        # Base dirs
        "CONFIG_DIR",
        "DATA_DIR",
        "CACHE_DIR",
        "STATE_DIR",
        # Derived config files
        "CONFIG_FILE",
        # Data files
        "MODELS_FILE",
        "EXTRA_MODELS_FILE",
        "MODELS_CACHE_FILE",
        "AGENTS_DIR",
        "SKILLS_DIR",
        "CONTEXTS_DIR",
        # OAuth plugin model files
        "GEMINI_MODELS_FILE",
        "CHATGPT_MODELS_FILE",
        "CLAUDE_MODELS_FILE",
        "COPILOT_MODELS_FILE",
        # Cache files
        "AUTOSAVE_DIR",
        # State files
        "COMMAND_HISTORY_FILE",
    ]

    originals: dict[str, object] = {}
    for attr in _PATH_ATTRS:
        originals[attr] = getattr(paths, attr)

    # --- 2. Build temp directory structure -----------------------------------
    muse_root = temp_dir / ".muse"
    temp_config_dir = muse_root / "config"
    temp_data_dir = muse_root / "data"
    temp_cache_dir = muse_root / "cache"
    temp_state_dir = muse_root / "state"

    for d in (temp_config_dir, temp_data_dir, temp_cache_dir, temp_state_dir):
        d.mkdir(parents=True, exist_ok=True)

    temp_config_file = temp_config_dir / "muse.cfg"
    # Create an empty config so config readers don't crash
    temp_config_file.write_text("[muse]\n", encoding="utf-8")

    # --- 3. Compute temp values for all derived paths ------------------------
    temp_values: dict[str, object] = {
        "CONFIG_DIR": temp_config_dir,
        "DATA_DIR": temp_data_dir,
        "CACHE_DIR": temp_cache_dir,
        "STATE_DIR": temp_state_dir,
        "CONFIG_FILE": temp_config_file,
        "MODELS_FILE": temp_data_dir / "models.json",
        "EXTRA_MODELS_FILE": temp_data_dir / "extra_models.json",
        "MODELS_CACHE_FILE": temp_data_dir / "models_cache.json",
        "AGENTS_DIR": temp_data_dir / "agents",
        "SKILLS_DIR": temp_data_dir / "skills",
        "CONTEXTS_DIR": temp_data_dir / "contexts",
        "GEMINI_MODELS_FILE": temp_data_dir / "gemini_models.json",
        "CHATGPT_MODELS_FILE": temp_data_dir / "chatgpt_models.json",
        "CLAUDE_MODELS_FILE": temp_data_dir / "claude_models.json",
        "COPILOT_MODELS_FILE": temp_data_dir / "copilot_models.json",
        "AUTOSAVE_DIR": temp_cache_dir / "autosaves",
        "COMMAND_HISTORY_FILE": temp_state_dir / "command_history.txt",
    }

    # --- 4. Apply overrides in BOTH modules ----------------------------------
    for attr, val in temp_values.items():
        setattr(paths, attr, val)
        setattr(cfg_mod, attr, val)

    # --- 5. Clear caches -----------------------------------------------------
    from code_muse.config.models import clear_model_cache, reset_session_model

    clear_model_cache()
    reset_session_model()
    _config_cache = None

    try:
        yield temp_config_file, temp_config_dir
    finally:
        # --- 6. Restore originals --------------------------------------------
        for attr, val in originals.items():
            setattr(paths, attr, val)
            setattr(cfg_mod, attr, val)

        clear_model_cache()
        reset_session_model()
        _config_cache = None
