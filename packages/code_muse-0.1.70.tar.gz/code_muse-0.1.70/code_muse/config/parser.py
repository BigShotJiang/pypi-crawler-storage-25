"""Backward-compatible shim — re-exports from parser submodules.

The actual implementations live in:

- ``code_muse.config.parser_core`` — atomic writes, caching, ensure_config_exists,
  get_value, get_config_keys, set_value, reset_value, isolated_config
- ``code_muse.config.parser_safety`` — safety flags, numeric limits, build_usage_limits
- ``code_muse.config.parser_runtime`` — runtime/UX getters, compaction, streaming, identity

This module exists solely so that existing ``from code_muse.config.parser import X``
statements continue to work during migration.
"""

from code_muse.config.parser_core import (
    DEFAULT_SECTION,
    REQUIRED_KEYS,
    _atomic_write_config,
    _config_cache,
    _config_cache_lock,
    _get_cached_config,
    ensure_config_exists,
    get_config_keys,
    get_value,
    isolated_config,
    reset_value,
    set_config_value,
    set_value,
)
from code_muse.config.parser_runtime import (
    get_agent_name,
    get_allow_recursion,
    get_animations_enabled,
    get_auto_approve,
    get_compaction_strategy,
    get_compaction_threshold,
    get_enable_streaming,
    get_filter_huge_message_threshold,
    get_max_critic_retries,
    get_max_hook_retries,
    get_max_subagent_depth,
    get_message_limit,
    get_overall_run_timeout_seconds,
    get_owner_name,
    get_puppy_name,
    get_recent_tool_results_to_keep,
    get_resume_message_count,
    get_subagent_verbose,
)
from code_muse.config.parser_safety import (
    build_usage_limits,
    get_grep_output_verbose,
    get_http2,
    get_max_consecutive_tool_errors,
    get_max_messages_hard_cap,
    get_max_tool_calls,
    get_proactive_truncation_message_count,
    get_safety_permission_level,
    get_total_tokens_limit,
    get_yolo_mode,
    set_http2,
)

__all__ = [
    # Core
    "DEFAULT_SECTION",
    "REQUIRED_KEYS",
    "_atomic_write_config",
    "_get_cached_config",
    "_config_cache",
    "_config_cache_lock",
    "ensure_config_exists",
    "get_config_keys",
    "get_value",
    "isolated_config",
    "reset_value",
    "set_config_value",
    "set_value",
    # Safety
    "build_usage_limits",
    "get_grep_output_verbose",
    "get_http2",
    "get_max_consecutive_tool_errors",
    "get_max_messages_hard_cap",
    "get_max_tool_calls",
    "get_proactive_truncation_message_count",
    "get_safety_permission_level",
    "get_total_tokens_limit",
    "get_yolo_mode",
    "set_http2",
    # Runtime
    "get_agent_name",
    "get_allow_recursion",
    "get_animations_enabled",
    "get_auto_approve",
    "get_compaction_strategy",
    "get_compaction_threshold",
    "get_enable_streaming",
    "get_filter_huge_message_threshold",
    "get_max_critic_retries",
    "get_max_hook_retries",
    "get_max_subagent_depth",
    "get_message_limit",
    "get_overall_run_timeout_seconds",
    "get_owner_name",
    "get_puppy_name",
    "get_recent_tool_results_to_keep",
    "get_resume_message_count",
    "get_subagent_verbose",
]
