"""Safety, limits, and usage budget config getters.

Extracted from ``parser.py`` to stay under the 600-line cap.
"""

from code_muse.config.parser_core import get_value, set_config_value  # noqa: F401

# ── Boolean feature flags ──────────────────────────────────────────────


def get_yolo_mode() -> bool:
    """Checks muse.cfg for 'yolo_mode' (case-insensitive in value only).

    Defaults to False (safe mode) if not set.
    Allowed values for ON: 1, '1', 'true', 'yes', 'on' (all case-insensitive for value).
    """
    true_vals = {"1", "true", "yes", "on"}
    cfg_val = get_value("yolo_mode")
    if cfg_val is not None:
        return str(cfg_val).strip().lower() in true_vals
    return False


def get_safety_permission_level() -> str:
    """Checks muse.cfg for 'safety_permission_level' (case-insensitive in value only).

    Defaults to 'medium' if not set.
    Allowed values: 'none', 'low', 'medium', 'high', 'critical'
    (all case-insensitive for value).
    Returns the normalized lowercase string.
    """
    valid_levels = {"none", "low", "medium", "high", "critical"}
    cfg_val = get_value("safety_permission_level")
    if cfg_val is not None:
        normalized = str(cfg_val).strip().lower()
        if normalized in valid_levels:
            return normalized
    return "medium"  # Default to medium risk threshold


def get_grep_output_verbose() -> bool:
    """Checks muse.cfg for 'grep_output_verbose' (case-insensitive in value only).

    Defaults to False (concise output) if not set.
    Allowed values for ON: 1, '1', 'true', 'yes', 'on' (all case-insensitive for value).

    When False (default): Shows only file names with match counts
    When True: Shows full output with line numbers and content
    """
    true_vals = {"1", "true", "yes", "on"}
    cfg_val = get_value("grep_output_verbose")
    if cfg_val is not None:
        return str(cfg_val).strip().lower() in true_vals
    return False


def get_http2() -> bool:
    """Get the http2 configuration value.

    Returns False if not set (default).
    """
    val = get_value("http2")
    if val is None:
        return False
    return str(val).lower() in ("1", "true", "yes", "on")


def set_http2(enabled: bool) -> None:
    """Sets the http2 configuration value.

    Args:
        enabled: Whether to enable HTTP/2 for httpx clients
    """
    set_config_value("http2", "true" if enabled else "false")


# ── Numeric limits ────────────────────────────────────────────────────


def get_max_consecutive_tool_errors(default: int = 3) -> int:
    """Max consecutive tool errors before aborting the agent run."""
    val = get_value("max_consecutive_tool_errors")
    try:
        return int(val) if val else default
    except (ValueError, TypeError):
        return default


def get_max_messages_hard_cap(
    default: int = 1000,
    model_max: int | None = None,
) -> int:
    """Return the max message count before forced compaction.

    The count cap is a **safety net** against pathological inputs —
    e.g. thousands of 1-token messages that never exceed the token
    threshold.  For normal usage the token-based threshold (≥90%)
    fires first: at model_max=8000 (smallest model), the 90% token
    threshold fires at ~7200 tokens ≈ 20 avg messages — well below
    the 1000 count cap.  The count cap is never the limiting factor
    for normal conversations.

    When ``model_max`` is provided and no user override is set, the
    cap scales dynamically via compute_dynamic_message_cap(), floored
    at 1000. Dynamic tiers: <100k→1000, 100k–1M→1200, ≥1M→1500.
    The ``max(1000, ...)`` wrapper ensures the floor is never breached
    even if tier values change.

    A user-set ``max_messages_hard_cap`` in config always wins.

    Configurable by ``max_messages_hard_cap`` key.
    Clamped to a minimum of 10.
    """
    val = get_value("max_messages_hard_cap")
    try:
        user_override = int(val) if val else None
    except (ValueError, TypeError):
        user_override = None

    if user_override is not None:
        return max(10, user_override)

    # No user override — compute dynamically from context window
    from code_muse.config._dynamic_cap import compute_dynamic_message_cap

    return max(1000, compute_dynamic_message_cap(model_max=model_max, default=1000))


def get_proactive_truncation_message_count() -> int:
    """Return message count threshold for proactive tool-result truncation.

    When message count exceeds this value, tool results are proactively
    truncated (before hitting the compaction threshold).

    Default is 15 (reduced from hardcoded 20) to truncate earlier
    and avoid triggering compaction.

    Configurable by ``proactive_truncation_message_count`` key.
    """
    val = get_value("proactive_truncation_message_count")
    try:
        return max(10, int(val))
    except (ValueError, TypeError):
        return 15


def get_total_tokens_limit(default: int = 0) -> int:
    """Return the maximum total tokens allowed for a single agent run.

    0 means no limit (unlimited).
    Configurable by 'total_tokens_limit' key.
    """
    val = get_value("total_tokens_limit")
    try:
        return int(val) if val else default
    except (ValueError, TypeError):
        return default


def get_max_tool_calls(default: int = 0) -> int:
    """Return the maximum number of tool calls allowed per agent run.

    0 means no limit (unlimited).
    Configurable by 'max_tool_calls' key.
    """
    val = get_value("max_tool_calls")
    try:
        return int(val) if val else default
    except (ValueError, TypeError):
        return default


# ── Composite usage limits ────────────────────────────────────────────


def build_usage_limits():
    """Build a pydantic-ai ``UsageLimits`` from current config values.

    Wires together the request (message) limit, total token limit, and
    tool-call limit.  Config values of 0 mean "unlimited" and are mapped
    to ``None`` because pydantic-ai uses ``None`` for no limit.

    Fails gracefully: if pydantic-ai does not support a field on the
    installed version, the constructor will raise ``TypeError`` and we
    fall back to a request-limit-only instance, logging a debug message.
    """
    import logging

    from pydantic_ai import UsageLimits as _UsageLimits

    logger = logging.getLogger(__name__)

    # Import here to avoid circular dependency at module level
    from code_muse.config.parser_runtime import get_message_limit

    request_limit = get_message_limit()
    total_tokens = get_total_tokens_limit()
    tool_calls = get_max_tool_calls()

    # 0 means unlimited in our config; pydantic-ai uses None for that.
    total_tokens_limit = total_tokens if total_tokens > 0 else None
    tool_calls_limit = tool_calls if tool_calls > 0 else None

    try:
        return _UsageLimits(
            request_limit=request_limit,
            total_tokens_limit=total_tokens_limit,
            tool_calls_limit=tool_calls_limit,
        )
    except TypeError:
        # Older pydantic-ai may not accept total_tokens_limit or
        # tool_calls_limit — fall back to request-only.
        logger.debug(
            "pydantic-ai UsageLimits does not accept "
            "total_tokens_limit/tool_calls_limit; falling back to "
            "request_limit only"
        )
        return _UsageLimits(request_limit=request_limit)
