"""Config: model selection, validation, and caching."""

import configparser
from contextlib import suppress

import code_muse.config.parser as _parser
import code_muse.config.paths as paths

# Session-local model name (initialized from file on first access, then cached)
_SESSION_MODEL: str | None = None

# Cache containers for model validation and defaults
_model_validation_cache = {}
_default_model_cache = None
_default_vision_model_cache = None


def _default_model_from_models_json():
    """Load the default model name from models.json.

    Returns the first model in models.json as the default.
    Falls back to ``gpt-5`` if the file cannot be read.
    """
    global _default_model_cache

    if _default_model_cache is not None:
        return _default_model_cache

    try:
        from code_muse.model_factory import ModelFactory

        models_config = ModelFactory.load_config()
        if models_config:
            # Use first model in models.json as default
            first_key = next(iter(models_config))
            _default_model_cache = first_key
            return first_key
        _default_model_cache = "gpt-5"
        return "gpt-5"
    except Exception:
        _default_model_cache = "gpt-5"
        return "gpt-5"


def _default_vision_model_from_models_json() -> str:
    """Select a default vision-capable model from models.json with caching."""
    global _default_vision_model_cache

    if _default_vision_model_cache is not None:
        return _default_vision_model_cache

    try:
        from code_muse.model_factory import ModelFactory

        models_config = ModelFactory.load_config()
        if models_config:
            # Prefer explicitly tagged vision models
            for name, config in models_config.items():
                if config.get("supports_vision"):
                    _default_vision_model_cache = name
                    return name

            # Fallback heuristic: common multimodal models
            preferred_candidates = (
                "gpt-4.1",
                "gpt-4.1-mini",
                "gpt-4.1-nano",
                "claude-4-0-sonnet",
                "gemini-2.5-flash-preview-05-20",
            )
            for candidate in preferred_candidates:
                if candidate in models_config:
                    _default_vision_model_cache = candidate
                    return candidate

            # Last resort: use the general default model
            _default_vision_model_cache = _default_model_from_models_json()
            return _default_vision_model_cache

        _default_vision_model_cache = "gpt-4.1"
        return "gpt-4.1"
    except Exception:
        _default_vision_model_cache = "gpt-4.1"
        return "gpt-4.1"


def _validate_model_exists(model_name: str) -> bool:
    """Check if a model exists in models.json with caching to avoid redundant calls."""
    global _model_validation_cache

    # Check cache first
    if model_name in _model_validation_cache:
        return _model_validation_cache[model_name]

    try:
        from code_muse.model_factory import ModelFactory

        models_config = ModelFactory.load_config()
        exists = model_name in models_config

        # Cache the result
        _model_validation_cache[model_name] = exists
        return exists
    except Exception:
        # If we can't validate, assume it exists to avoid breaking things
        _model_validation_cache[model_name] = True
        return True


def clear_model_cache():
    """Clear the model validation cache. Call this when models.json changes."""
    global _model_validation_cache, _default_model_cache, _default_vision_model_cache
    _model_validation_cache.clear()
    _default_model_cache = None
    _default_vision_model_cache = None


def reset_session_model():
    """Reset the session-local model cache.

    This is primarily for testing purposes. In normal operation, the session
    model is set once at startup and only changes via set_model_name().
    """
    global _SESSION_MODEL
    _SESSION_MODEL = None


def model_supports_setting(model_name: str, setting: str) -> bool:
    """Check if a model supports a particular setting (e.g., 'temperature', 'seed').

    Args:
        model_name: The name of the model to check.
        setting: The setting name to check for (e.g., 'temperature', 'seed', 'top_p').

    Returns:
        True if the model supports the setting, False otherwise.
        Defaults to True for backwards compatibility if model config doesn't specify.
    """
    # GLM-4.7 and GLM-5 models always support clear_thinking setting
    if setting == "clear_thinking" and (
        "glm-4.7" in model_name.lower() or "glm-5" in model_name.lower()
    ):
        return True

    try:
        from code_muse.model_factory import ModelFactory

        models_config = ModelFactory.load_config()
        model_config = models_config.get(model_name, {})

        # Get supported_settings list, default to supporting common settings
        supported_settings = model_config.get("supported_settings")

        if supported_settings is None:
            # Default: assume common settings are supported for backwards compatibility
            # For Anthropic/Claude models, include extended thinking settings
            if model_name.startswith("claude-") or model_name.startswith("anthropic-"):
                base = ["temperature", "extended_thinking", "budget_tokens"]
                from code_muse.model_utils import supports_adaptive_thinking

                if supports_adaptive_thinking(model_name):
                    base.append("effort")
                return setting in base
            return setting in ["temperature", "seed"]

        return setting in supported_settings
    except Exception:
        # If we can't check, assume supported for safety
        return True


def get_global_model_name():
    """Return a valid model name for Muse to use.

    Uses session-local caching so that model changes in other terminals
    don't affect this running instance. The file is only read once at startup.

    1. If _SESSION_MODEL is set, return it (session cache)
    2. Otherwise, look at ``model`` in *muse.cfg*
    3. If that value exists **and** is present in *models.json*, use it
    4. Otherwise return the first model listed in *models.json*
    5. As a last resort fall back to ``claude-4-0-sonnet``

    The result is cached in _SESSION_MODEL for subsequent calls.
    """
    global _SESSION_MODEL

    # Return cached session model if already initialized
    if _SESSION_MODEL is not None:
        return _SESSION_MODEL

    # First access - initialize from file
    stored_model = _parser.get_value("model")

    if stored_model and _validate_model_exists(stored_model):
        _SESSION_MODEL = stored_model
        return _SESSION_MODEL

    # Either no stored model or it's not valid – choose default from models.json
    _SESSION_MODEL = _default_model_from_models_json()
    return _SESSION_MODEL


def set_model_name(model: str):
    """Sets the model name in both the session cache and persistent config file.

    Updates _SESSION_MODEL immediately for this process, and writes to the
    config file so new terminals will pick up this model as their default.
    """
    global _SESSION_MODEL

    # Update session cache immediately
    _SESSION_MODEL = model

    # Also persist to file for new terminal sessions
    from code_muse.config.parser import DEFAULT_SECTION

    config = configparser.ConfigParser()
    config.read(paths.CONFIG_FILE)
    if DEFAULT_SECTION not in config:
        config[DEFAULT_SECTION] = {}
    config[DEFAULT_SECTION]["model"] = model or ""
    from code_muse.config.parser import _atomic_write_config

    _atomic_write_config(config)

    # Clear model cache when switching models to ensure fresh validation
    clear_model_cache()


def get_model_context_length(model_name: str | None = None) -> int:
    """
    Get the context length for a model from models.json.

    Args:
        model_name: Optional model name. If None, uses the global model.
    """
    try:
        from code_muse.model_factory import ModelFactory

        model_configs = ModelFactory.load_config()
        if model_name is None:
            model_name = get_global_model_name()

        # Get context length from model config
        model_config = model_configs.get(model_name, {})
        context_length = model_config.get("context_length", 128000)  # Default value

        # Floor at 64k: misconfigured entries (e.g. 32768) must not shrink
        # the effective window below what modern models actually support.
        # Most current models provide 128k+; 65536 is the absolute minimum
        # we accept before falling back to 128000.
        clamped = int(context_length)
        if clamped < 65536:
            clamped = 128000

        return clamped
    except Exception:
        # Fallback to default context length if anything goes wrong
        return 128000


def compute_effective_history_budget(
    model_max: int, overhead: int = 0, model_name: str | None = None
) -> int:
    """
    Model-class-aware effective token budget for (system prompt + message history).

    Implements the adaptive limits from the 2026-05 performance audit:
    - >= 1M context: 90% for history (after reserves)
    - 100k–1M: 82%
    - 32k–100k: 74%
    - < 32k: 60% (aggressive)

    Output reservation prefers the model's declared max_output / max_output_tokens
    (from models_dev, Bedrock, custom models, etc.). Falls back to a safe 8% of ctx
    (capped 4k–64k).

    Always reserves a safety buffer (2k or 2%) for estimation drift + response.

    This is the single source of truth for protected_tokens, compaction thresholds,
    pre-send gates, and emergency compaction. Plugins (e.g. token_accuracy) can
    influence via model metadata returned from load_models_config.

    Args:
        model_max: The model's context window in tokens.
        overhead: Estimated tokens for system prompt + tool schemas.
        model_name: Optional model name for per-model max_output lookup.

    Returns:
        The token budget available for history content before compaction triggers.
    """
    if model_max <= 0:
        model_max = 128000

    if model_max >= 1_000_000:
        hist_frac = 0.90
    elif model_max >= 100_000:
        hist_frac = 0.82
    elif model_max >= 32_000:
        hist_frac = 0.74
    else:
        hist_frac = 0.60

    # Output reservation: the model's max output capability is NOT a
    # per-turn reservation — most responses are 1–8k tokens.  Always cap
    # the per-turn output reservation at 8% of context, with a 4k floor.
    out_max = max(4096, int(model_max * 0.08))

    safety = max(2048, int(model_max * 0.02))
    budget = int(model_max * hist_frac) - overhead - out_max - safety
    return max(4096, budget)


def get_protected_token_count(model_name: str | None = None, overhead: int = 0) -> int:
    """Returns the user-configured protected token count for message history compaction.

    This is the number of tokens in recent messages that won't be summarized.
    Defaults to the adaptive budget (based on model context length) if unset
    or misconfigured.  Configurable by 'protected_token_count' key.

    Now respects the adaptive compute_effective_history_budget (from the
    2026-05 performance audit) so 1M models get much larger protected tails
    (~85-88%) while 32k models are aggressively capped.

    Args:
        model_name: Optional model name for per-model budget computation.
            Falls back to the global model if not provided.
        overhead: Estimated tokens for system prompt + tool schemas.
            Passed through to ``compute_effective_history_budget`` so the
            protected zone accounts for real overhead. Defaults to 0 for
            backwards compatibility with callers that lack live overhead.
    """
    val = _parser.get_value("protected_token_count")
    try:
        model_context_length = get_model_context_length(model_name)
        # Use caller-supplied model_name when available, otherwise resolve
        # from global config.
        resolved_name = model_name
        if resolved_name is None:
            with suppress(Exception):
                resolved_name = get_global_model_name()

        # New adaptive budget is the authoritative cap for protected zone.
        # Caller-supplied overhead is forwarded so the budget reflects
        # the real available space (fixes the "13716 stuck" bug where
        # overhead=0 produced a tiny protected zone on large models).
        effective_budget = compute_effective_history_budget(
            model_context_length, overhead=overhead, model_name=resolved_name
        )
        # Leave headroom inside the budget for overhead + a few turns
        adaptive_max = max(4096, int(effective_budget * 0.92))

        max_protected_tokens = adaptive_max

        configured_value = int(val) if val else max_protected_tokens
        return max(1000, min(configured_value, max_protected_tokens))
    except ValueError, TypeError, Exception:
        model_context_length = get_model_context_length(model_name)
        return max(1000, int(model_context_length * 0.55))
