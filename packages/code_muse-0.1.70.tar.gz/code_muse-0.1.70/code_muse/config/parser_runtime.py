"""Runtime, UX, and compaction config getters.

Extracted from ``parser.py`` to stay under the 600-line cap.
"""

from code_muse.config.parser_core import get_value

# ── Timeout & depth limits ────────────────────────────────────────────


def get_overall_run_timeout_seconds(default: int = 600) -> int:
    """Max wall-clock time in seconds for a single agent run (0 = no limit)."""
    val = get_value("overall_run_timeout")
    try:
        return int(val) if val else default
    except ValueError, TypeError:
        return default


def get_max_subagent_depth(default: int = 4) -> int:
    """Max nesting depth for sub-agent invocations (0 = no sub-agents allowed).

    Prevents runaway recursive agent spawning. Default of 4 means the main
    agent can call a sub-agent, which can call another, up to 4 levels deep.
    Configurable by 'max_subagent_depth' key via /set command.

    Example: /set max_subagent_depth=2
    """
    val = get_value("max_subagent_depth")
    try:
        configured_value = int(val) if val else default
        # Depth must be non-negative; 0 disables sub-agent invocation entirely
        return max(0, configured_value)
    except ValueError, TypeError:
        return default


# ── Session resume ────────────────────────────────────────────────────


def get_resume_message_count() -> int:
    """Returns the number of messages to display when resuming a session.

    Defaults to 50 if unset or misconfigured.
    Configurable by 'resume_message_count' key via /set command.

    Example: /set resume_message_count=30
    """
    val = get_value("resume_message_count")
    try:
        configured_value = int(val) if val else 50
        # Enforce reasonable bounds: minimum 1, maximum 100
        return max(1, min(configured_value, 100))
    except ValueError, TypeError:
        return 50


# ── Compaction ────────────────────────────────────────────────────────


def get_compaction_threshold() -> float:
    """Returns the user-configured compaction threshold as a float between 0.0 and 1.0.

    This is the proportion of model context that triggers compaction.
    Defaults to 0.90 (90%) if unset or misconfigured.
    Configurable by 'compaction_threshold' key.
    """
    val = get_value("compaction_threshold")
    try:
        threshold = float(val) if val else 0.90
        # Floor at 0.90: compaction must ONLY trigger when approaching the
        # true model context limit, not at artificial low limits.
        return max(0.90, min(0.97, threshold))
    except ValueError, TypeError:
        return 0.90


def get_compaction_strategy() -> str:
    """Returns the user-configured compaction strategy.

    Options are 'summarization' or 'truncation'.
    Defaults to 'summarization' if not set or misconfigured.
    Configurable by 'compaction_strategy' key.
    """
    val = get_value("compaction_strategy")
    if val and val.lower() in ["summarization", "truncation"]:
        return val.lower()
    # Default to summarization
    return "summarization"


# ── Message & request limits ──────────────────────────────────────────


def get_message_limit(default: int = 1000) -> int:
    """Returns the user-configured message/request limit for the agent.

    Controls how many steps/requests the agent can take per run.
    Defaults to 1000 if unset or misconfigured.
    Configurable by 'message_limit' key.
    """
    val = get_value("message_limit")
    try:
        return int(val) if val else default
    except ValueError, TypeError:
        return default


# ── Boolean feature flags ──────────────────────────────────────────────


def get_auto_approve() -> bool:
    """Get the auto_approve configuration value.

    When True, all user approval prompts are automatically approved
    without showing the interactive menu.
    Defaults to True for a smoother UX.
    """
    val = get_value("auto_approve")
    if val is None:
        return True
    return str(val).lower() in ("1", "true", "yes", "on")


def get_allow_recursion() -> bool:
    """Get the allow_recursion configuration value.

    Returns True if recursion is allowed, False otherwise.
    """
    val = get_value("allow_recursion")
    if val is None:
        return True  # Default to True to allow recursion unless explicitly disabled
    return str(val).lower() in ("1", "true", "yes", "on")


def get_animations_enabled() -> bool:
    """Return whether terminal animations are enabled.

    Defaults to True if not configured.
    """
    val = get_value("animations_enabled")
    if val is None:
        return True
    return val.lower() in ("true", "1", "yes", "on")


def get_subagent_verbose() -> bool:
    """Return True if sub-agent verbose output is enabled (default False).

    When False (default), sub-agents produce quiet, sparse output suitable
    for parallel execution. When True, sub-agents produce full verbose output
    like the main agent (useful for debugging).
    """
    cfg_val = get_value("subagent_verbose")
    if cfg_val is None:
        return False
    return str(cfg_val).strip().lower() in {"1", "true", "yes", "on"}


# ── Hook retry limits ─────────────────────────────────────────────────


def get_max_hook_retries() -> int:
    """Return the maximum number of plugin hook retries after an agent run.

    When a plugin hook returns ``{"retry": True, ...}`` the agent re-runs.
    This caps how many times that can happen for **non-critic** hooks to
    prevent runaway loops.  Critic-driven retries have a separate budget
    controlled by ``get_max_critic_retries()``.
    Defaults to 10.
    """
    val = get_value("max_hook_retries")
    if val is None:
        return 10
    try:
        n = int(val)
        return max(1, n)  # At least 1 to avoid nonsensical values
    except ValueError, TypeError:
        return 10


def get_max_critic_retries() -> int:
    """Return the maximum number of critic-driven retries after an agent run.

    Critic retries (``{"retry": True, ..., "source": "critic"}``) are tracked
    separately from regular hook retries so the critic can have a larger
    iteration budget without starving other hooks.
    Defaults to 10.
    """
    val = get_value("max_critic_retries")
    if val is None:
        return 10
    try:
        n = int(val)
        return max(1, n)
    except ValueError, TypeError:
        return 10


# ── Streaming ─────────────────────────────────────────────────────────


def get_enable_streaming() -> bool:
    """Get the enable_streaming configuration value.

    Controls whether streaming (SSE) is used for model responses.
    Returns True if streaming is enabled, False otherwise.
    Defaults to True.
    """
    val = get_value("enable_streaming")
    if val is None:
        return True  # Default to True for better UX
    return str(val).lower() in ("1", "true", "yes", "on")


# ── Identity ──────────────────────────────────────────────────────────


def get_agent_name() -> str:
    return get_value("agent_name") or "Muse"


def get_owner_name() -> str:
    return get_value("owner_name") or "Creator"


def get_puppy_name() -> str:
    return get_agent_name()


# ── Compaction tuning ────────────────────────────────────────────────


def get_filter_huge_message_threshold(default: int = 50000) -> int:
    """Return the max token threshold for filter_huge_messages.

    Configurable by 'filter_huge_message_threshold' key.
    Defaults to 50000 if unset or misconfigured.
    Clamped to a minimum of 1000.
    """
    val = get_value("filter_huge_message_threshold")
    try:
        threshold = int(val) if val else default
        return max(1000, threshold)
    except ValueError, TypeError:
        return default


def get_recent_tool_results_to_keep(default: int = 7) -> int:
    """Return the number of recent tool results to keep in full during truncation.

    Configurable by 'recent_tool_results_to_keep' key.
    Older tool results get their content replaced with a truncation marker.
    Defaults to 7 if unset or misconfigured.
    Clamped to a minimum of 1.
    """
    val = get_value("recent_tool_results_to_keep")
    try:
        count = int(val) if val else default
        return max(1, count)
    except ValueError, TypeError:
        return default
