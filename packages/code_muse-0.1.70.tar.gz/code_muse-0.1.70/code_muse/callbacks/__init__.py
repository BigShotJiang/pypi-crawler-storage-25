"""``code_muse.callbacks`` — Plugin callback registry.

Backward-compatible package that re-exports every public name from the
split submodules.  All existing imports continue to work::

    from code_muse.callbacks import register_callback, fire_callbacks
    from code_muse.callbacks import on_register_tools, on_agent_exception
    from code_muse.callbacks import VALID_HOOKS
"""

import logging

# -- Engine (state, registration, dispatch) --------------------------------
from code_muse.callbacks._callback_engine import (
    VALID_HOOKS,
    CallbackFunc,
    PhaseType,
    _callback_lock,
    _callbacks,
    _defer_mode,
    _deferred_registrations,
    _executor,
    _executor_shutdown,
    _shutdown_executor,
    _sorted_cache,
    _trigger_callbacks,
    _trigger_callbacks_sync,
    begin_deferred,
    clear_callbacks,
    commit_deferred,
    count_callbacks,
    fire_callbacks,
    get_callbacks,
    register_callback,
    rollback_deferred,
    unregister_callback,
)

# -- Sorting utilities (pure) -----------------------------------------------
from code_muse.callbacks._callback_sorting import sort_by_priority

# -- Lifecycle hooks (on_* wrappers) -----------------------------------------
from code_muse.callbacks._lifecycle_hooks import (
    on_agent_exception,
    on_agent_reload,
    on_agent_run_cancel,
    on_agent_run_context,
    on_agent_run_end,
    on_agent_run_result,
    on_agent_run_start,
    on_invoke_agent,
    on_load_model_config,
    on_load_models_config,
    on_load_prompt,
    on_should_skip_fallback_render,
    on_shutdown,
    on_startup,
    on_version_check,
)
from code_muse.callbacks._lifecycle_hooks_ops import (
    on_create_file,
    on_custom_command,
    on_custom_command_help,
    on_delete_file,
    on_delete_snippet,
    on_edit_file,
    on_file_permission,
    on_get_model_system_prompt,
    on_message,
    on_message_history_processor_end,
    on_message_history_processor_start,
    on_post_tool_call,
    on_pre_tool_call,
    on_prepare_model_prompt,
    on_register_agents,
    on_register_model_providers,
    on_register_model_types,
    on_register_tools,
    on_replace_in_file,
    on_run_shell_command,
    on_stream_event,
    on_stream_event_sync,
)

# ---------------------------------------------------------------------------
# Package logger
# ---------------------------------------------------------------------------
# Defined AFTER all imports so the ``_PackageLogger`` proxy used by
# submodules resolves to THIS object via ``sys.modules[...].logger``.
# This also means ``patch('code_muse.callbacks.logger')`` in tests
# replaces the real logger, and the proxy picks up the Mock automatically.
logger = logging.getLogger("code_muse.callbacks")

__all__ = [
    # Types & constants
    "VALID_HOOKS",
    "PhaseType",
    "CallbackFunc",
    # Core registration & dispatch
    "register_callback",
    "unregister_callback",
    "clear_callbacks",
    "get_callbacks",
    "count_callbacks",
    "fire_callbacks",
    # Deferred registration
    "begin_deferred",
    "commit_deferred",
    "rollback_deferred",
    # Sorting utility
    "sort_by_priority",
    # Internal (used by tests, not public API)
    "_callbacks",
    "_sorted_cache",
    "_callback_lock",
    "_executor",
    "_executor_shutdown",
    "_defer_mode",
    "_deferred_registrations",
    "_shutdown_executor",
    "_trigger_callbacks",
    "_trigger_callbacks_sync",
    "logger",
    # Lifecycle hooks
    "on_agent_exception",
    "on_agent_reload",
    "on_agent_run_cancel",
    "on_agent_run_context",
    "on_agent_run_end",
    "on_agent_run_result",
    "on_agent_run_start",
    "on_create_file",
    "on_custom_command",
    "on_custom_command_help",
    "on_delete_file",
    "on_delete_snippet",
    "on_edit_file",
    "on_file_permission",
    "on_get_model_system_prompt",
    "on_invoke_agent",
    "on_load_model_config",
    "on_load_models_config",
    "on_load_prompt",
    "on_message",
    "on_message_history_processor_end",
    "on_message_history_processor_start",
    "on_post_tool_call",
    "on_pre_tool_call",
    "on_prepare_model_prompt",
    "on_register_agents",
    "on_register_model_providers",
    "on_register_model_types",
    "on_register_tools",
    "on_replace_in_file",
    "on_run_shell_command",
    "on_should_skip_fallback_render",
    "on_shutdown",
    "on_startup",
    "on_stream_event",
    "on_stream_event_sync",
    "on_version_check",
]
