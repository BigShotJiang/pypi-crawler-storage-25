"""Core callback registry engine.

Owns all mutable global state (the ``_callbacks`` dict, sorted cache,
thread lock, executor) and provides registration, query, and dispatch
functions.  The ``on_*`` convenience wrappers live in
``_lifecycle_hooks.py``.
"""

import asyncio
import atexit
import concurrent.futures
import os
import sys
import threading
import traceback
import weakref
from collections.abc import Callable
from typing import Any, Literal

from code_muse.callbacks._callback_sorting import sort_by_priority

# ---------------------------------------------------------------------------
# Configurable callback timeout
# ---------------------------------------------------------------------------

_DEFAULT_CALLBACK_TIMEOUT: float = 30.0
_ENV_CALLBACK_TIMEOUT: str = "MUSE_CALLBACK_TIMEOUT"


def _get_callback_timeout() -> float:
    """Return per-callback timeout in seconds.

    Reads ``MUSE_CALLBACK_TIMEOUT`` from the environment (float, in seconds).
    Falls back to 30 s.  A value of 0 disables the timeout (useful for
    debugging).  Invalid values are silently ignored.
    """
    raw = os.environ.get(_ENV_CALLBACK_TIMEOUT)
    if raw is None:
        return _DEFAULT_CALLBACK_TIMEOUT
    try:
        val = float(raw)
        if val < 0:
            logger.warning(
                f"Ignoring negative {_ENV_CALLBACK_TIMEOUT}={raw}; "
                f"using default {_DEFAULT_CALLBACK_TIMEOUT}s"
            )
            return _DEFAULT_CALLBACK_TIMEOUT
        return val
    except ValueError:
        logger.warning(
            f"Ignoring invalid {_ENV_CALLBACK_TIMEOUT}={raw!r}; "
            f"using default {_DEFAULT_CALLBACK_TIMEOUT}s"
        )
        return _DEFAULT_CALLBACK_TIMEOUT


# ---------------------------------------------------------------------------
# Package-scoped logger proxy
# ---------------------------------------------------------------------------


class _PackageLogger:
    """Proxy that resolves every attribute access through the package module.

    When ``code_muse.callbacks`` is a package (not a monolith), submodule
    functions can't rely on ``patch('code_muse.callbacks.logger')`` reaching
    their local ``logger`` variable.  This proxy always delegates to
    ``sys.modules["code_muse.callbacks"].logger``, so the patch target
    is respected across every submodule.
    """

    def __getattr__(self, name: str) -> Any:
        return getattr(sys.modules["code_muse.callbacks"].logger, name)


logger: Any = _PackageLogger()

# ---------------------------------------------------------------------------
# Public constants & type aliases
# ---------------------------------------------------------------------------

# Single canonical source of truth for all valid hook/phase names.
# Used to build _callbacks dict and validated against PhaseType in tests.
VALID_HOOKS: tuple[str, ...] = (
    "startup",
    "shutdown",
    "invoke_agent",
    "agent_exception",
    "version_check",
    "edit_file",
    "create_file",
    "replace_in_file",
    "delete_snippet",
    "delete_file",
    "run_shell_command",
    "load_model_config",
    "load_models_config",
    "load_prompt",
    "agent_reload",
    "custom_command",
    "custom_command_help",
    "file_permission",
    "pre_tool_call",
    "post_tool_call",
    "stream_event",
    "register_tools",
    "register_agents",
    "register_model_type",
    "get_model_system_prompt",
    "prepare_model_prompt",
    "agent_run_start",
    "agent_run_end",
    "agent_run_result",
    "register_model_providers",
    "message_history_processor_start",
    "message_history_processor_end",
    "on_message",
    "agent_run_context",
    "agent_run_cancel",
    "should_skip_fallback_render",
)

PhaseType = Literal[*VALID_HOOKS]

CallbackFunc = Callable[..., Any]

# ---------------------------------------------------------------------------
# Mutable global state (all guarded by _callback_lock)
# ---------------------------------------------------------------------------

# (priority, func) tuples — higher priority runs first.
_callbacks: dict[str, list[tuple[int, CallbackFunc]]] = {h: [] for h in VALID_HOOKS}

# Pre-sorted cache: populated lazily by get_callbacks(), invalidated on
# register/unregister/clear.  Avoids sorting the (priority, func) tuples
# on every dispatch.
_sorted_cache: dict[str, list[CallbackFunc]] = {}

# FREE-THREADED: ThreadPoolExecutor is compatible with free-threaded Python 3.14 —
# no GIL contention for I/O-bound callback work.
_executor = concurrent.futures.ThreadPoolExecutor(max_workers=8)

# Thread-safe lock for all mutable global state
_callback_lock = threading.Lock()

# Shutdown flag to prevent new submissions during teardown
_executor_shutdown = False

# ---------------------------------------------------------------------------
# Deferred (atomic) registration support
# ---------------------------------------------------------------------------

# When True, register_callback buffers calls instead of committing them.
_defer_mode: bool = False
_deferred_registrations: list[tuple[PhaseType, CallbackFunc, int]] = []


def begin_deferred() -> None:
    """Enter deferred registration mode.

    While active, ``register_callback`` buffers calls instead of committing
    them.  Call ``commit_deferred()`` to apply the batch or
    ``rollback_deferred()`` to discard it.
    """
    global _defer_mode
    with _callback_lock:
        _defer_mode = True
        _deferred_registrations.clear()


def commit_deferred() -> list[str]:
    """Commit all buffered registrations atomically.

    Validates the full batch first, then applies every registration.  If any
    application fails after partial commit, all successfully committed entries
    are rolled back and a ``RuntimeError`` is raised.

    Returns a list of non-fatal validation warnings (empty on success).
    """
    global _defer_mode
    with _callback_lock:
        _defer_mode = False
        batch = list(_deferred_registrations)
        _deferred_registrations.clear()
        if not batch:
            return []

        # --- Phase 1: validate everything before touching state ---
        warnings: list[str] = []
        seen_keys: set[tuple[PhaseType, int, str]] = set()
        for phase, func, _priority in batch:
            if phase not in _callbacks:
                raise ValueError(
                    f"Deferred registration references unsupported phase: {phase}"
                )
            if not callable(func):
                raise TypeError(f"Deferred callback must be callable, got {type(func)}")
            key = (phase, id(func), func.__name__)
            if key in seen_keys:
                warnings.append(
                    f"Duplicate deferred registration: {func.__name__} for '{phase}'"
                )
            seen_keys.add(key)

        # --- Phase 2: apply; rollback on any unexpected error ---
        committed: list[tuple[PhaseType, CallbackFunc, int]] = []
        try:
            for phase, func, priority in batch:
                # Bypass the duplicate-is-func check in register_callback so that
                # deferred registrations for *different* plugins can coexist.
                # We still guard against the exact-same-func duplicate at commit
                # time.
                if any(f is func for _, f in _callbacks[phase]):
                    warnings.append(
                        f"Skipping duplicate: {func.__name__} already in '{phase}'"
                    )
                    continue
                _callbacks[phase].append((priority, func))
                _sorted_cache.pop(phase, None)  # Invalidate sorted cache
                committed.append((phase, func, priority))
                logger.debug(
                    f"Committed deferred callback {func.__name__} for "
                    f"phase '{phase}' (priority={priority})"
                )
        except Exception:
            # Rollback everything we managed to commit
            for phase, func, _priority in committed:
                for idx, (_, existing_func) in enumerate(_callbacks[phase]):
                    if existing_func is func:
                        del _callbacks[phase][idx]
                        _sorted_cache.pop(phase, None)  # Invalidate sorted cache
                        break
            logger.error(
                "Deferred commit failed; rolled back %d registrations",
                len(committed),
            )
            raise

    logger.debug("Committed %d deferred registrations", len(committed))
    return warnings


def rollback_deferred() -> None:
    """Discard all buffered registrations without committing."""
    global _defer_mode
    with _callback_lock:
        count = len(_deferred_registrations)
        _defer_mode = False
        _deferred_registrations.clear()
    logger.debug("Rolled back %d deferred registrations", count)


# ---------------------------------------------------------------------------
# Executor teardown
# ---------------------------------------------------------------------------


def _shutdown_executor() -> None:
    """Gracefully shut down the callback ThreadPoolExecutor.

    Called automatically at interpreter exit via ``atexit``.  Plugins that
    spawn long-running threads inside callbacks should clean themselves up
    in response to the ``shutdown`` hook; this function only terminates the
    executor that runs those callbacks.
    """
    global _executor_shutdown
    _executor_shutdown = True
    try:
        _executor.shutdown(wait=True, cancel_futures=True)
        logger.debug("Callback executor shut down cleanly")
    except Exception as exc:
        logger.warning(f"Callback executor shutdown error: {exc}")


atexit.register(_shutdown_executor)

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register_callback(phase: PhaseType, func: CallbackFunc, priority: int = 0) -> None:
    if not callable(func):
        raise TypeError(f"Callback must be callable, got {type(func)}")

    with _callback_lock:
        if phase not in _callbacks:
            raise ValueError(
                f"Unsupported phase: {phase}. "
                f"Supported phases: {list(_callbacks.keys())}"
            )

        # In deferred mode, buffer the registration for later atomic commit
        if _defer_mode:
            _deferred_registrations.append((phase, func, priority))
            _sorted_cache.pop(phase, None)  # Invalidate sorted cache
            logger.debug(
                f"Buffered deferred callback {func.__name__} for "
                f"phase '{phase}' (priority={priority})"
            )
            return

        # Prevent duplicate registration of the same callback function
        # This can happen if plugins are accidentally loaded multiple times
        for _existing_priority, existing_func in _callbacks[phase]:
            if existing_func is func:
                logger.debug(
                    f"Callback {func.__name__} already registered "
                    f"for phase '{phase}', skipping"
                )
                return

        _callbacks[phase].append((priority, func))
        _sorted_cache.pop(phase, None)  # Invalidate sorted cache
        logger.debug(
            f"Registered async callback {func.__name__} "
            f"for phase '{phase}' (priority={priority})"
        )


def unregister_callback(phase: PhaseType, func: CallbackFunc) -> bool:
    with _callback_lock:
        if phase not in _callbacks:
            return False
        for idx, (_existing_priority, existing_func) in enumerate(_callbacks[phase]):
            if existing_func is func:
                del _callbacks[phase][idx]
                _sorted_cache.pop(phase, None)  # Invalidate sorted cache
                logger.debug(
                    f"Unregistered async callback {func.__name__} from phase '{phase}'"
                )
                return True
    return False


def clear_callbacks(phase: PhaseType | None = None) -> None:
    with _callback_lock:
        if phase is None:
            for p in _callbacks:
                _callbacks[p].clear()
            logger.debug("Cleared all async callbacks")
        else:
            if phase in _callbacks:
                _callbacks[phase].clear()
                logger.debug(f"Cleared async callbacks for phase '{phase}'")
        _sorted_cache.clear()


# ---------------------------------------------------------------------------
# Query
# ---------------------------------------------------------------------------


def get_callbacks(phase: PhaseType) -> list[CallbackFunc]:
    """Return callbacks for *phase* sorted by priority (highest first).

    Uses a pre-sorted cache that is invalidated on register/unregister/clear.
    """
    with _callback_lock:
        cached = _sorted_cache.get(phase)
        if cached is not None:
            return list(cached)

        callbacks = _callbacks.get(phase, [])
        if not callbacks:
            _sorted_cache[phase] = []
            return []

        result = sort_by_priority(callbacks)
        _sorted_cache[phase] = result
        return list(result)


def count_callbacks(phase: PhaseType | None = None) -> int:
    with _callback_lock:
        if phase is None:
            return sum(len(callbacks) for callbacks in _callbacks.values())
        return len(_callbacks.get(phase, []))


# ---------------------------------------------------------------------------
# Dispatch (fire-and-forget + trigger)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Weak-reference tracking for fire-and-forget tasks
# ---------------------------------------------------------------------------
# Without a strong reference, a fire-and-forget task can be garbage-
# collected before its done-callback fires, leading to Python's dreaded
# "Task exception was never retrieved" warning.  We keep a weak-reference
# set so tasks stay alive until they complete, but don't leak memory.
_fire_and_forget_tasks: weakref.WeakSet[asyncio.Task] = weakref.WeakSet()


def _dispatch_agent_exception_safe(exc: BaseException, phase: str, source: str) -> None:
    """Dispatch agent_exception hook unless already in that phase.

    Guards against recursion when an agent_exception observer itself
    raises.  *source* is a debug label (e.g. "done callback").
    """
    if phase == "agent_exception":
        return
    try:
        fire_callbacks("agent_exception", exc)
    except Exception:
        logger.debug(f"Failed to dispatch agent_exception from {source}")


def _make_fire_and_forget_done_callback(
    name: str, phase: str = ""
) -> Callable[[asyncio.Task], None]:
    """Return a done-callback for async fire-and-forget tasks.

    Retrieves and logs the exception (preventing "Task exception was
    never retrieved" warnings).  Dispatches agent_exception for plugin
    observability, guarded against recursion via *phase*.
    """

    def _on_done(task: asyncio.Task) -> None:
        _fire_and_forget_tasks.discard(task)
        try:
            exc = task.exception()
        except asyncio.CancelledError:
            logger.debug(f"Fire-and-forget callback {name} was cancelled")
            return
        if exc is None:
            logger.debug(f"Fire-and-forget callback {name} completed")
        else:
            logger.error(
                f"Fire-and-forget callback {name} raised: {exc}\n"
                f"{traceback.format_exception(type(exc), exc, exc.__traceback__)}"
            )
            _dispatch_agent_exception_safe(exc, phase, "async done callback")

    return _on_done


def _make_executor_done_callback(
    name: str, phase: str = ""
) -> Callable[[concurrent.futures.Future], None]:
    """Return a done-callback for thread-pool futures.

    Dispatches agent_exception for plugin observability, guarded
    against recursion via *phase*.
    """

    def _on_done(future: concurrent.futures.Future) -> None:
        exc = future.exception()
        if exc is None:
            logger.debug(f"Fire-and-forget executor callback {name} completed")
        else:
            logger.error(
                f"Fire-and-forget executor callback {name} raised: {exc}\n"
                f"{traceback.format_exception(type(exc), exc, exc.__traceback__)}"
            )
            _dispatch_agent_exception_safe(exc, phase, "executor done callback")

    return _on_done


def _run_fire_and_forget_coro(coro: Any, name: str) -> None:
    """Run a fire-and-forget coroutine in the thread pool executor.

    Exceptions are logged and swallowed — the caller never sees them.
    """
    try:
        asyncio.run(coro)
    except Exception as e:
        logger.error(
            f"Fire-and-forget callback {name} raised: {e}\n{traceback.format_exc()}"
        )


def fire_callbacks(phase: PhaseType, *args, **kwargs) -> None:
    """Fire callbacks without blocking; async callbacks run in the background.

    Useful for observation hooks (like ``on_message``) that must not delay
    the caller.  Exceptions are logged and swallowed.
    """
    callbacks = get_callbacks(phase)
    if not callbacks:
        return

    for callback in callbacks:
        try:
            result = callback(*args, **kwargs)
            if asyncio.iscoroutine(result):
                try:
                    loop = asyncio.get_running_loop()
                    task = loop.create_task(result)
                    _fire_and_forget_tasks.add(task)
                    task.add_done_callback(
                        _make_fire_and_forget_done_callback(callback.__name__, phase)
                    )
                except RuntimeError:
                    future = _executor.submit(
                        _run_fire_and_forget_coro, result, callback.__name__
                    )
                    future.add_done_callback(
                        _make_executor_done_callback(callback.__name__, phase)
                    )
        except Exception as e:
            logger.debug(f"Fire-and-forget callback {callback.__name__} failed: {e}")
            _dispatch_agent_exception_safe(e, phase, "sync callback")


def _trigger_callbacks_sync(phase: PhaseType, *args, **kwargs) -> list[Any]:
    callbacks = get_callbacks(phase)
    if not callbacks:
        logger.debug(f"No callbacks registered for phase '{phase}'")
        return []

    timeout = _get_callback_timeout()
    results = []
    for callback in callbacks:
        try:
            result = callback(*args, **kwargs)
            # Handle async callbacks - if we get a coroutine, run it
            if asyncio.iscoroutine(result):
                try:
                    asyncio.get_running_loop()
                    # We're in an async context (e.g., the TUI).
                    # Run the coroutine in a separate thread so it gets
                    # its own event loop.  Configurable timeout prevents
                    # a misbehaving hook from freezing the session.
                    future = _executor.submit(asyncio.run, result)
                    result = future.result(timeout=timeout or None)
                except RuntimeError:
                    # No running loop — we're in a sync/worker thread.
                    result = asyncio.run(result)
            results.append(result)
            logger.debug(f"Successfully executed callback {callback.__name__}")
        except concurrent.futures.TimeoutError:
            logger.warning(
                f"Callback {callback.__name__} timed out in phase '{phase}' "
                f"after {timeout}s"
            )
            results.append(None)
        except Exception as e:
            logger.error(
                f"Callback {callback.__name__} failed in phase '{phase}': {e}\n"
                f"{traceback.format_exc()}"
            )
            results.append(None)

    return results


async def _trigger_callbacks(phase: PhaseType, *args, **kwargs) -> list[Any]:
    """Trigger all registered callbacks for *phase* in priority order.

    Hook execution order: callbacks run from highest priority to lowest.
    For ``run_shell_command``, the caller (``command_runner.py``) iterates
    through results in priority order and the **first non-None** result
    containing ``{"pre_executed": True, ...}`` wins — subsequent results
    are ignored.

    Each async callback is guarded by a per-callback timeout (see
    ``_get_callback_timeout``).  A timeout is treated as a non-fatal
    failure: a warning is logged and ``None`` is appended to results,
    and the chain continues.
    """
    callbacks = get_callbacks(phase)

    if not callbacks:
        logger.debug(f"No callbacks registered for phase '{phase}'")
        return []

    timeout = _get_callback_timeout()
    logger.debug(f"Triggering {len(callbacks)} async callbacks for phase '{phase}'")

    results = []
    for callback in callbacks:
        try:
            result = callback(*args, **kwargs)
            if asyncio.iscoroutine(result):
                if timeout > 0:
                    result = await asyncio.wait_for(result, timeout=timeout)
                else:
                    result = await result
            results.append(result)
            logger.debug(f"Successfully executed async callback {callback.__name__}")
        except TimeoutError:
            logger.warning(
                f"Async callback {callback.__name__} timed out in phase "
                f"'{phase}' after {timeout}s"
            )
            results.append(None)
        except Exception as e:
            logger.error(
                f"Async callback {callback.__name__} failed in phase '{phase}': {e}\n"
                f"{traceback.format_exc()}"
            )
            results.append(None)

    return results
