"""Pure callback sorting/priority utilities.

Stateless helpers extracted from the callback engine so they can be
tested and reasoned about independently of the global mutable registry.
"""

from collections.abc import Callable
from typing import Any

CallbackFunc = Callable[..., Any]


def sort_by_priority(
    callbacks: list[tuple[int, CallbackFunc]],
) -> list[CallbackFunc]:
    """Sort ``(priority, func)`` tuples highest-priority-first.

    Uses a stable sort so that callbacks registered at the same priority
    preserve their registration order.
    """
    sorted_callbacks = sorted(callbacks, key=lambda item: item[0], reverse=True)
    return [func for _priority, func in sorted_callbacks]
