"""Lifecycle hook convenience functions.

Every ``on_*`` function is a thin wrapper around the core engine's
``_trigger_callbacks`` / ``_trigger_callbacks_sync`` / ``get_callbacks``
dispatchers.  They exist solely to give callers a typed, discoverable
API for each hook phase.
"""

import traceback
from typing import Any

from code_muse.callbacks._callback_engine import (
    CallbackFunc,  # noqa: F401 — re-exported for downstream type-checking
    PhaseType,  # noqa: F401
    _trigger_callbacks,
    _trigger_callbacks_sync,
    get_callbacks,
    logger,
)

# ---------------------------------------------------------------------------
# Core lifecycle hooks
# ---------------------------------------------------------------------------


async def on_startup() -> list[Any]:
    import asyncio as _asyncio

    from code_muse.callbacks._callback_engine import _get_callback_timeout

    callbacks = get_callbacks("startup")
    timeout = _get_callback_timeout()
    results: list[Any] = []
    failed_names: list[str] = []
    timed_out_names: list[str] = []
    for callback in callbacks:
        try:
            result = callback()
            if _is_coro(result):
                if timeout > 0:
                    result = await _asyncio.wait_for(result, timeout=timeout)
                else:
                    result = await result
            results.append(result)
            logger.debug(f"Successfully executed async callback {callback.__name__}")
        except TimeoutError:
            logger.warning(
                f"Async callback {callback.__name__} timed out in phase "
                f"'startup' after {timeout}s"
            )
            timed_out_names.append(callback.__name__)
            results.append(None)
        except Exception as e:
            logger.error(
                f"Async callback {callback.__name__} failed in phase 'startup': {e}\n"
                f"{traceback.format_exc()}"
            )
            failed_names.append(callback.__name__)
            results.append(None)
    all_bad = failed_names + timed_out_names
    if all_bad:
        count = len(all_bad)
        names_str = ", ".join(all_bad)
        # TODO: PEP 750 t-string — use templatelib when stable
        logger.warning(f"{count} startup callback(s) failed: {names_str}")
        from code_muse.messaging import emit_warning

        # TODO: PEP 750 t-string — use templatelib when stable
        emit_warning(f"⚠️ {count} plugin(s) failed to load: {names_str}")

    return results


async def on_shutdown() -> list[Any]:
    return await _trigger_callbacks("shutdown")


async def on_invoke_agent(*args, **kwargs) -> list[Any]:
    return await _trigger_callbacks("invoke_agent", *args, **kwargs)


async def on_agent_exception(exception: Exception, *args, **kwargs) -> list[Any]:
    return await _trigger_callbacks("agent_exception", exception, *args, **kwargs)


async def on_version_check(*args, **kwargs) -> list[Any]:
    return await _trigger_callbacks("version_check", *args, **kwargs)


# ---------------------------------------------------------------------------
# Model / prompt hooks (sync)
# ---------------------------------------------------------------------------


def on_load_model_config(*args, **kwargs) -> list[Any]:
    return _trigger_callbacks_sync("load_model_config", *args, **kwargs)


def on_load_models_config() -> list[Any]:
    """Trigger callbacks to load additional model configurations.

    Plugins can register callbacks that return a dict of model configurations
    to be merged with the built-in models.json. Plugin models override built-in
    models with the same name.

    Returns:
        List of model config dicts from all registered callbacks.
    """
    return _trigger_callbacks_sync("load_models_config")


def on_load_prompt():
    return _trigger_callbacks_sync("load_prompt")


# ---------------------------------------------------------------------------
# Agent lifecycle hooks
# ---------------------------------------------------------------------------


def on_agent_reload(*args, **kwargs) -> Any:
    return _trigger_callbacks_sync("agent_reload", *args, **kwargs)


async def on_agent_run_start(
    agent_name: str,
    model_name: str,
    session_id: str | None = None,
) -> list[Any]:
    """Trigger callbacks when an agent run starts.

    This fires at the beginning of run, before the agent task is created.
    Useful for:
    - Starting background tasks (like token refresh heartbeats)
    - Logging/analytics
    - Resource allocation

    Args:
        agent_name: Name of the agent starting
        model_name: Name of the model being used
        session_id: Optional session identifier

    Returns:
        List of results from registered callbacks.
    """
    return await _trigger_callbacks(
        "agent_run_start", agent_name, model_name, session_id
    )


async def on_agent_run_end(
    agent_name: str,
    model_name: str,
    session_id: str | None = None,
    success: bool = True,
    error: Exception | None = None,
    response_text: str | None = None,
    metadata: dict | None = None,
) -> list[Any]:
    """Trigger callbacks when an agent run ends.

    This fires at the end of run, in the finally block.
    Always fires regardless of success/failure/cancellation.

    Useful for:
    - Stopping background tasks (like token refresh heartbeats)
    - Workflow orchestration (like Ralph's autonomous loop)
    - Logging/analytics
    - Resource cleanup
    - Detecting completion signals in responses

    Args:
        agent_name: Name of the agent that finished
        model_name: Name of the model that was used
        session_id: Optional session identifier
        success: Whether the run completed successfully
        error: Exception if the run failed, None otherwise
        response_text: The final text response from the agent (if successful)
        metadata: Optional dict with additional context (tokens used, etc.)

    Returns:
        List of results from registered callbacks.
    """
    return await _trigger_callbacks(
        "agent_run_end",
        agent_name,
        model_name,
        session_id,
        success,
        error,
        response_text,
        metadata,
    )


async def on_agent_run_result(
    result: Any,
    agent_name: str,
    model_name: str,
) -> list[Any]:
    """Trigger callbacks after an agent run returns a result.

    Fires after ``pydantic_agent.run()`` completes successfully, **before**
    the result is handed back to the caller.  Plugins can inspect the result
    and request an automatic retry (e.g. when an upstream content-filter
    produced a false-positive refusal).

    Callback signature::

        async def my_callback(result, agent_name: str, model_name: str)
            -> dict | None

    To request a retry, return a dict with::

        {
            "retry": True,
            "prompt": "<message to send on retry>",
            "delay": 1.0,          # optional, seconds before retry
        }

    Return ``None`` (or omit a return) to let the result pass through.
    The first callback that returns a retry request wins; the agent
    replays at most a small fixed number of times to prevent runaway loops.

    Args:
        result: The ``RunResult`` returned by ``pydantic_agent.run()``.
        agent_name: Name of the agent that produced the result.
        model_name: Name of the model that was used.

    Returns:
        List of results from registered callbacks.
    """
    return await _trigger_callbacks("agent_run_result", result, agent_name, model_name)


def on_agent_run_context(agent, pydantic_agent, group_id) -> list[Any]:
    """Collect async context managers wrapping ``pydantic_agent.run()``.

    Each callback returns an async CM (with ``__aenter__``/``__aexit__``) or
    ``None``. The caller composes all non-``None`` results via
    ``contextlib.AsyncExitStack``.

    Returns a list of async context managers (may be empty).
    """
    results = _trigger_callbacks_sync(
        "agent_run_context", agent, pydantic_agent, group_id
    )
    return [r for r in results if r is not None]


async def on_agent_run_cancel(group_id: str) -> list[Any]:
    """Fired when an agent run is cancelled or interrupted.

    Plugins use this to cancel any external workflow tracking the run.
    """
    return await _trigger_callbacks("agent_run_cancel", group_id)


def on_should_skip_fallback_render(agent) -> bool:
    """Return True if any plugin requests skipping the non-streaming fallback render."""
    results = _trigger_callbacks_sync("should_skip_fallback_render", agent)
    return any(r is True for r in results)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_coro(obj: Any) -> bool:
    """Check if *obj* is a coroutine (avoids importing asyncio at module level)."""
    import asyncio

    return asyncio.iscoroutine(obj)
