"""Operational lifecycle hook convenience functions.

Hooks for file operations, shell commands, tool events, stream events,
custom commands, file permissions, registration collection, model prompt
hooks, message history, and message observation.
"""

from typing import Any

from code_muse.callbacks._callback_engine import (
    _trigger_callbacks,
    _trigger_callbacks_sync,
)

# ---------------------------------------------------------------------------
# File-operation hooks (sync)
# ---------------------------------------------------------------------------


def on_edit_file(*args, **kwargs) -> Any:
    return _trigger_callbacks_sync("edit_file", *args, **kwargs)


def on_create_file(*args, **kwargs) -> Any:
    return _trigger_callbacks_sync("create_file", *args, **kwargs)


def on_replace_in_file(*args, **kwargs) -> Any:
    return _trigger_callbacks_sync("replace_in_file", *args, **kwargs)


def on_delete_snippet(*args, **kwargs) -> Any:
    return _trigger_callbacks_sync("delete_snippet", *args, **kwargs)


def on_delete_file(*args, **kwargs) -> Any:
    return _trigger_callbacks_sync("delete_file", *args, **kwargs)


# ---------------------------------------------------------------------------
# Shell command hooks
# ---------------------------------------------------------------------------


async def on_run_shell_command(*args, **kwargs) -> Any:
    """Trigger callbacks for shell command execution.

    Execution order and resolution rule:
        Callbacks fire in priority order (highest first).  The caller
        (``command_runner.py``) iterates the result list and the **first
        non-None** dict containing ``"pre_executed": True`` wins — all
        remaining results are ignored.

    Intended priority chain for ``run_shell_command``:

        2. ``policy_engine`` / ``shell_safety`` (priority 50)
           — enforces allow/deny/ask-user rules
        3. ``shell_minimizer`` (priority 0) — compresses
           known command output

    Future handlers **must** pass an explicit ``priority`` argument to
    ``register_callback()`` to position themselves correctly in the
    pipeline.

    Args:
        *args: Positional arguments passed to callbacks (context, command, ...).
        **kwargs: Keyword arguments passed to callbacks (cwd, timeout, ...).

    Returns:
        List of results from all registered callbacks.
    """
    return await _trigger_callbacks("run_shell_command", *args, **kwargs)


# ---------------------------------------------------------------------------
# Custom command hooks (sync)
# ---------------------------------------------------------------------------


def on_custom_command_help() -> list[Any]:
    """Collect custom command help entries from plugins.

    Each callback should return a list of tuples [(name, description), ...]
    or a single tuple, or None. We'll flatten and sanitize results.
    """
    return _trigger_callbacks_sync("custom_command_help")


def on_custom_command(command: str, name: str) -> list[Any]:
    """Trigger custom command callbacks.

    This allows plugins to register handlers for slash commands
    that are not built into the core command handler.

    Args:
        command: The full command string (e.g., "/foo bar baz").
        name: The primary command name without the leading slash (e.g., "foo").

    Returns:
        Implementations may return:
        - True if the command was handled (and no further action is needed)
        - A string to be processed as user input by the caller
        - None to indicate not handled
    """
    return _trigger_callbacks_sync("custom_command", command, name)


# ---------------------------------------------------------------------------
# File permission hooks (sync)
# ---------------------------------------------------------------------------


def on_file_permission(
    context: Any,
    file_path: str,
    operation: str,
    preview: str | None = None,
    message_group: str | None = None,
    operation_data: Any = None,
) -> list[Any]:
    """Trigger file permission callbacks.

    This allows plugins to register handlers for file permission checks
    before file operations are performed.

    Args:
        context: The operation context
        file_path: Path to the file being operated on
        operation: Description of the operation
        preview: Optional preview of changes (deprecated - use operation_data instead)
        message_group: Optional message group
        operation_data: Operation-specific data for preview generation (recommended)

    Returns:
        List of boolean results from permission handlers.
        Returns True if permission should be granted, False if denied.
    """
    # PERF-08: Skip callback overhead entirely in yolo mode
    from code_muse.config import get_yolo_mode

    if get_yolo_mode():
        return [True]

    # For backward compatibility, if operation_data is provided, prefer it over preview
    if operation_data is not None:
        preview = None
    return _trigger_callbacks_sync(
        "file_permission",
        context,
        file_path,
        operation,
        preview,
        message_group,
        operation_data,
    )


# ---------------------------------------------------------------------------
# Tool call hooks (async)
# ---------------------------------------------------------------------------


async def on_pre_tool_call(
    tool_name: str, tool_args: dict, context: Any = None
) -> list[Any]:
    """Trigger callbacks before a tool is called.

    This allows plugins to inspect, modify, or log tool calls before
    they are executed.

    Args:
        tool_name: Name of the tool being called
        tool_args: Arguments being passed to the tool
        context: Optional context data for the tool call

    Returns:
        List of results from registered callbacks.
    """
    return await _trigger_callbacks("pre_tool_call", tool_name, tool_args, context)


async def on_post_tool_call(
    tool_name: str,
    tool_args: dict,
    result: Any,
    duration_ms: float,
    context: Any = None,
) -> list[Any]:
    """Trigger callbacks after a tool completes.

    This allows plugins to inspect tool results, log execution times,
    or perform post-processing.

    Args:
        tool_name: Name of the tool that was called
        tool_args: Arguments that were passed to the tool
        result: The result returned by the tool
        duration_ms: Execution time in milliseconds
        context: Optional context data for the tool call

    Returns:
        List of results from registered callbacks.
    """
    return await _trigger_callbacks(
        "post_tool_call", tool_name, tool_args, result, duration_ms, context
    )


# ---------------------------------------------------------------------------
# Stream event hooks (async + sync variant)
# ---------------------------------------------------------------------------


async def on_stream_event(
    event_type: str, event_data: Any, agent_session_id: str | None = None
) -> list[Any]:
    """Trigger callbacks for streaming events.

    This allows plugins to react to streaming events in real-time,
    such as tokens being generated, tool calls starting, etc.

    Args:
        event_type: Type of the streaming event
        event_data: Data associated with the event
        agent_session_id: Optional session ID of the agent emitting the event

    Returns:
        List of results from registered callbacks.
    """
    return await _trigger_callbacks(
        "stream_event", event_type, event_data, agent_session_id
    )


def on_stream_event_sync(
    event_type: str, event_data: Any, agent_session_id: str | None = None
) -> list[Any]:
    """Synchronous version of on_stream_event — no task creation.

    Used for high-frequency events (part_delta) where async overhead
    would be wasteful. Callbacks are fired synchronously in the caller's
    thread.
    """
    return _trigger_callbacks_sync(
        "stream_event", event_type, event_data, agent_session_id
    )


# ---------------------------------------------------------------------------
# Registration collection hooks (sync)
# ---------------------------------------------------------------------------


def on_register_tools() -> list[dict[str, Any]]:
    """Collect custom tool registrations from plugins.

    Each callback should return a list of dicts with:
    - "name": str - the tool name
    - "register_func": callable - function that takes an agent and registers the tool

    Example return: [{"name": "my_tool", "register_func": register_my_tool}]
    """
    return _trigger_callbacks_sync("register_tools")


def on_register_agents() -> list[dict[str, Any]]:
    """Collect custom agent registrations from plugins.

    Each callback should return a list of dicts with either:
    - "name": str, "class": Type[BaseAgent] - for Python agent classes
    - "name": str, "json_path": str - for JSON agent files

    Example return: [{"name": "my-agent", "class": MyAgentClass}]
    """
    return _trigger_callbacks_sync("register_agents")


def on_register_model_types() -> list[dict[str, Any]]:
    """Collect custom model type registrations from plugins.

    This hook allows plugins to register custom model types that can be used
    in model configurations. Each callback should return a list of dicts with:
    - "type": str - the model type name (e.g., "claude_code")
    - "handler": callable - function(model_name, model_config, config) -> model instance

    The handler function receives:
    - model_name: str - the name of the model being created
    - model_config: dict - the model's configuration from models.json
    - config: dict - the full models configuration

    The handler should return a model instance or None if creation fails.

    Example callback:
        def register_my_model_types():
            return [{
                "type": "my_custom_type",
                "handler": create_my_custom_model,
            }]

    Example return: [{"type": "my_custom_type", "handler": create_my_custom_model}]
    """
    return _trigger_callbacks_sync("register_model_type")


def on_register_model_providers() -> list[Any]:
    """Trigger callbacks to register custom model provider classes.

    Plugins can register callbacks that return a dict mapping provider names
    to model classes.

    Returns:
        List of dicts from all registered callbacks.
    """
    return _trigger_callbacks_sync("register_model_providers")


# ---------------------------------------------------------------------------
# Model prompt hooks (sync)
# ---------------------------------------------------------------------------


def on_get_model_system_prompt(
    model_name: str, default_system_prompt: str, user_prompt: str
) -> list[dict[str, Any]]:
    """Allow plugins to provide custom system prompts for specific model types.

    This hook allows plugins to override the system prompt handling for custom
    model types (like claude_code models). Each callback receives
    the model name and should return a dict if it handles that model type, or None.

    Args:
        model_name: The name of the model being used (e.g., "claude-code-sonnet")
        default_system_prompt: The default system prompt from the agent
        user_prompt: The user's prompt/message

    Each callback should return a dict with:
    - "instructions": str - the system prompt/instructions to use
    - "user_prompt": str - the (possibly modified) user prompt
    - "handled": bool - True if this callback handled the model

    Or return None if the callback doesn't handle this model type.

    Example callback:
        def get_my_model_system_prompt(model_name, default_system_prompt, user_prompt):
            if model_name.startswith("my-custom-"):
                return {
                    "instructions": "You are MyCustomBot.",
                    "user_prompt": f"{default_system_prompt}\\n\\n{user_prompt}",
                    "handled": True,
                }
            return None  # Not handled by this callback

    Returns:
        List of results from registered callbacks (dicts or None values).
    """
    return _trigger_callbacks_sync(
        "get_model_system_prompt", model_name, default_system_prompt, user_prompt
    )


def on_prepare_model_prompt(
    model_name: str,
    system_prompt: str,
    user_prompt: str,
    prepend_system_to_user: bool = True,
) -> list[dict[str, Any | None]]:
    """Allow plugins to fully prepare the prompt for a model.

    This is the hook fired from ``model_utils.prepare_prompt_for_model`` to let
    plugins take over prompt preparation for specific model families (e.g.
    claude-code OAuth models which need a hard-coded instruction string and
    have the system prompt prepended to the user message).

    Unlike ``get_model_system_prompt`` (which is used by augmenting plugins like
    agent_skills), this hook is for plugins that want to *fully handle* the
    prompt prep for a given model. The first callback returning ``handled=True``
    wins; the rest are ignored.

    Args:
        model_name: The name of the model being used.
        system_prompt: The default system prompt from the agent.
        user_prompt: The user's prompt/message.
        prepend_system_to_user: Whether the caller wants system prompt prepended
            to the user prompt (only meaningful for plugins that manipulate the
            user prompt, like claude-code).

    Each callback should return a dict with:
        - ``"handled"``: bool — True if this callback fully prepared the prompt.
        - ``"instructions"``: str — the system prompt/instructions to use.
        - ``"user_prompt"``: str — the (possibly modified) user prompt.
        - ``"is_claude_code"``: bool — (optional) flag preserved on PreparedPrompt.

    Or return ``None`` to indicate "I don't handle this model".

    Returns:
        List of results (dicts or ``None``) from registered callbacks.
    """
    return _trigger_callbacks_sync(
        "prepare_model_prompt",
        model_name,
        system_prompt,
        user_prompt,
        prepend_system_to_user,
    )


# ---------------------------------------------------------------------------
# Message history processor hooks (sync)
# ---------------------------------------------------------------------------


def on_message_history_processor_start(
    agent_name: str,
    session_id: str | None,
    message_history: list[Any],
    incoming_messages: list[Any],
) -> list[Any]:
    """Trigger callbacks at the start of message history processing.

    This hook fires at the beginning of the message_history_accumulator,
    before any deduplication or processing occurs. Useful for:
    - Logging/debugging message flow
    - Observing raw incoming messages
    - Analytics on message history growth

    Args:
        agent_name: Name of the agent processing messages
        session_id: Optional session identifier
        message_history: Current message history (before processing)
        incoming_messages: New messages being added

    Returns:
        List of results from registered callbacks.
    """
    return _trigger_callbacks_sync(
        "message_history_processor_start",
        agent_name,
        session_id,
        message_history,
        incoming_messages,
    )


def on_message_history_processor_end(
    agent_name: str,
    session_id: str | None,
    message_history: list[Any],
    messages_added: int,
    messages_filtered: int,
) -> list[Any]:
    """Trigger callbacks at the end of message history processing.

    This hook fires at the end of the message_history_accumulator,
    after deduplication and filtering has been applied. Useful for:
    - Logging/debugging final message state
    - Analytics on deduplication effectiveness
    - Observing what was actually added to history

    Args:
        agent_name: Name of the agent processing messages
        session_id: Optional session identifier
        message_history: Final message history (after processing)
        messages_added: Count of new messages that were added
        messages_filtered: Count of messages that were filtered out (dupes/empty)

    Returns:
        List of results from registered callbacks.
    """
    return _trigger_callbacks_sync(
        "message_history_processor_end",
        agent_name,
        session_id,
        message_history,
        messages_added,
        messages_filtered,
    )


# ---------------------------------------------------------------------------
# Message observation hook (async)
# ---------------------------------------------------------------------------


async def on_message(message_id: str, message: Any) -> list[Any]:
    """Trigger callbacks when a message is emitted.

    This is the global observation hook for the messaging system.
    For per-message interception with pattern matching, use
    messaging.interceptors.register_interceptor() instead.

    This hook is for observation (logging, analytics, WebSocket forwarding),
    while interceptors are for control (silencing, replacing, redirecting).

    Args:
        message_id: The well-known message identifier (e.g., "tool:edit_file:complete")
        message: The full Pydantic BaseMessage model (or UIMessage for legacy)

    Returns:
        List of results from registered callbacks.
    """
    return await _trigger_callbacks("on_message", message_id, message)
