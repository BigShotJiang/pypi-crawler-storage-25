def sebihello():
    print("Hello from sebi !")