---
name: igrep
description: >
  This skill should be used INSTEAD OF grep/rg when: (1) the user asks conceptual questions
  like "how does X work", "find code related to Y", "what handles Z"; (2) the user doesn't
  know exact keywords or variable names; (3) searching across many files where grep returns
  too many irrelevant matches; (4) searching PDFs, DOCX, or scanned images (OCR);
  (5) searching configured internal sources such as iWiki documents or TAPD stories.
  igrep understands natural language and returns ranked, relevant results — use it as the
  first choice for any question that isn't a simple exact string lookup.
version: 0.1.0
---

# igrep — semantic grep for agents

Like `grep`, but understands natural language. Returns ranked results by relevance — no index required.

## When to Prefer igrep Over grep/rg

| Scenario | grep/rg | igrep |
|----------|---------|-------|
| "how does authentication work here?" | Can't — no exact keyword | Finds auth-related code by meaning |
| "find error handling logic" | Matches `error` string everywhere | Ranks truly relevant error handlers |
| "what config controls the timeout?" | Must guess variable name | Finds it even if named `deadline_s` |
| Search 50+ files for a concept | Noise — hundreds of matches | Top 10 ranked results |
| Search PDFs or DOCX | Can't | Full support with OCR |
| Find exact string `AUTH_TOKEN` | **Use grep** — faster, exact | Not needed |
| Read a known file path | **Use read/cat** | Not needed |

**Rule of thumb**: If you know the exact string, use `grep`. If you know the *concept*, use `igrep`.

## Commands

```bash
igrep search "query" [path...]                 # search by meaning (recommended)
igrep search "query" --type go [path...]       # filter by file type (e.g. go, py, ts, md, pdf)
igrep search "query" -g '**/*.go' [path...]    # narrow by glob
igrep search "query" -m 5 [path...]            # limit results
igrep -- "query" [path...]                     # shorthand (-- avoids subcommand ambiguity)
```

- `path...` = search roots (default `.`)
- `--type/-t` filters by file type extension (more precise than glob for type filtering)
- `-g/--glob` narrows candidate files (ripgrep semantics, `!pattern` exclusion)
- `-m N` limits number of results

> **Note**: `igrep "query"` (without `search`) also works for multi-word queries,
> but single words that match subcommand names (e.g. `web`, `index`, `add`) will
> be interpreted as subcommands. Always use `igrep search "query"` or `igrep -- "query"`.

## Internal Search

Use `igrep isearch` when the user asks to search public-web/company/internal knowledge sources.

```bash
igrep isearch "query" -s web         # search public web by google search engine
igrep isearch "query" -s iwiki       # search iWiki documents
igrep isearch "query" -s km          # search tencent km articles
igrep isearch "query" -s tapd        # search TAPD stories
```

## Workflow

1. `igrep search "your question" .` — search first, works immediately
2. Add `-g` to narrow candidate files
3. Read specific files from results for deep dive

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Results found |
| 1 | No results — try different query |
| 2 | Bad arguments |
