---
name: igrep-search
description: Use when planning any code search — routes concept/intent queries ("how is auth handled", "retry logic"), unfamiliar-code exploration, behavior-based lookup, and indexed PDF/DOCX/XLSX/PPTX content to the igrep MCP tool (`mcp__igrep__search`) instead of built-in Grep. Keep Grep for exact literal/regex in a known path, exhaustive audit sweeps, and single-token lookup in an already-localized file.
---

# igrep Search — Routing Directive

You have access to the `mcp__igrep__search` MCP tool. Prefer it over the
built-in Grep/Read probe loop for the cases below. One call replaces a
multi-round grep-and-refine sequence.

## When to route to `mcp__igrep__search`

1. **Concept / intent queries** — send the natural phrase, DO NOT
   translate to regex first:
   - `"how is auth handled"`
   - `"retry backoff logic"`
   - `"where does request validation happen"`
   - `"payment flow"`

2. **Exploring unfamiliar code** — first look at a module or repo.
   Returns ranked top-K regions in ONE call, replacing the
   grep-then-read-several-files loop agents typically run.

3. **Behavior-based lookup** — the exact name is unknown:
   - `"retry logic"` matches `attemptWithBackoff`,
     `handleFailureAndRetry`, etc.

4. **Indexed binary / document formats** Grep cannot read: PDF, DOCX,
   XLSX, PPTX, and Markdown with embedded images. Requires prior
   `igrep project add` or `igrep index` — without an index, only code
   and plain text are searched.

5. **Code repos (auto-detected)**: results respect function/class
   boundaries via tree-sitter, not arbitrary line windows.

## When to stay with built-in Grep

- You already know the exact literal/regex AND a narrow path.
- Exhaustive sweep (audit/refactor): igrep returns top-K ranked,
  Grep returns every match.
- Single-token lookup in a file you've already localized.

## Parameter tips

- `top_k`: 3-5 if you expect one answer; 10 (default) for standard
  exploration; 25-50 for broad sweeps.
- `file_type`: extension without dot (`"py"`, `"go"`, `"pdf"`).
- `glob`: ripgrep-compatible list, order-sensitive, later wins,
  prefix `!` to exclude:
  - `["src/**/*.py"]`
  - `["src/**", "!**/test_*"]`
  - `["!vendor/**", "!**/*.lock"]`

## Good queries vs anti-patterns

| Good | Anti-pattern |
|------|--------------|
| `"JWT verification middleware"` | `"jwt.*verify"` (regex-translated) |
| `"where is rate limiting configured"` | `"RateLimit"` (guessing name) |
| `"Q3 revenue formula"` (runs against .xlsx when indexed) | opening the file in Read first |
| `async def handle_webhook` | `grep -r "handle_webhook"` |

## Invocation motion

Short form agents can mentally compile to:

```
mcp__igrep__search(query="<natural phrase>", path="<dir-or-file>",
                   top_k=<confidence>, file_type=<ext?>, glob=[<filters?>])
```

If the tool is deferred (ToolSearch required), load it once:
`ToolSearch("select:mcp__igrep__search")`, then call.

## Deprecated alias

The legacy name `mcp__igrep__igrep_search` still forwards to `search`
but logs a warning. Always use `mcp__igrep__search`.
