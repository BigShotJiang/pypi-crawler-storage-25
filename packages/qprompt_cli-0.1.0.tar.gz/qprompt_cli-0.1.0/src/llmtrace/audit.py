from __future__ import annotations

from typing import Any


def run_answer_audit(trace: dict[str, Any]) -> dict[str, Any]:
    final_answer = trace.get("final_answer", "")
    evidence = trace.get("evidence", [])
    parsed = trace.get("parsed", {})

    claims: list[dict[str, Any]] = []
    unsupported: list[str] = []

    if "enterprise" in final_answer.lower():
        claims.append(
            {
                "claim": "Enterprise segment is a key driver",
                "evidence": "query_result_enterprise_drop",
                "confidence": "medium",
            }
        )

    if not evidence and final_answer:
        unsupported.append("Answer contains claims but no attached evidence records")

    risk_flags: list[str] = []
    if parsed.get("missing_context"):
        risk_flags.extend([f"Missing context: {x}" for x in parsed["missing_context"]])

    return {
        "claims": claims,
        "unsupported_claims": unsupported,
        "assumptions_used": parsed.get("assumptions", []),
        "risk_flags": risk_flags,
    }
