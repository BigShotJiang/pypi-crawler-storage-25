import pandas as pd

def classify_atsi(score):
    if pd.isna(score):
        return None
    score = max(0.0, min(100.0, float(score)))
    if score >= 75:
        return "Unpolluted"
    elif score >= 50:
        return "Moderate"
    elif score >= 25:
        return "Eutrophic"
    else:
        return "Hypertrophic"

def classify_series(series):
    return series.apply(classify_atsi)
