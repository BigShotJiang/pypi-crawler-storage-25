from pathlib import Path
import pandas as pd

def load_data(file_path):
    file_path = Path(file_path)

    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    suffix = file_path.suffix.lower()

    if suffix in [".xlsx", ".xls"]:
        return pd.read_excel(file_path)
    elif suffix == ".csv":
        return pd.read_csv(file_path)
    elif suffix == ".txt":
        return pd.read_csv(file_path, sep=None, engine="python")
    else:
        raise ValueError(
            f"Unsupported file format: {suffix}. Use .xlsx, .csv, or .txt"
        )
