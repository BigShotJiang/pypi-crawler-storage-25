from .io import load_data
from .preprocessing import validate_atsi_input
from .thresholds import assign_thresholds
from .atsifunction import compute_atsi_series
from .classification import classify_series

def run_atsi(file_path):
    """
    Main ATSI workflow.

    Required input columns:
        - CHL
        - SAL
    """
    df = load_data(file_path)
    df = validate_atsi_input(df)
    df = assign_thresholds(df, sal_col="SAL")
    df["ATSI"] = compute_atsi_series(df)
    df["ATSI"] = df["ATSI"].clip(lower=0, upper=100)
    df["ATSI_Class"] = classify_series(df["ATSI"])
    return df
