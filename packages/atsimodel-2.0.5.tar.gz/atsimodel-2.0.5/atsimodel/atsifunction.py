import numpy as np
import pandas as pd

def clip_0_100(x):
    if pd.isna(x):
        return np.nan
    return float(np.clip(x, 0.0, 100.0))

def compute_atsi_score(chl_value, chl_threshold_low, chl_threshold_upper):
    """
    ATSI = (NFh - NFl) - [ ((CHLc - CHLtl) / CHLtu) * NFh ]
    """
    NFh = 100.0
    NFl = 0.0

    if pd.isna(chl_value) or pd.isna(chl_threshold_low) or pd.isna(chl_threshold_upper):
        return np.nan
    if chl_threshold_upper <= 0:
        return np.nan

    atsi = (NFh - NFl) - (((chl_value - chl_threshold_low) / chl_threshold_upper) * NFh)
    return clip_0_100(atsi)

def compute_atsi_series(df, chl_col="CHL", low_col="CHL_TL", upper_col="CHL_TU"):
    return df.apply(
        lambda row: compute_atsi_score(row[chl_col], row[low_col], row[upper_col]),
        axis=1
    )
