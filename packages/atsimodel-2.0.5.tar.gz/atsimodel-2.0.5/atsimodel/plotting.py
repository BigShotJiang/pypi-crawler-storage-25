import matplotlib.pyplot as plt

def plot_atsi_distribution(df, score_col="ATSI"):
    plt.figure(figsize=(8, 5))
    plt.hist(df[score_col].dropna(), bins=20, edgecolor="black")
    plt.xlabel("ATSI Score")
    plt.ylabel("Frequency")
    plt.title("Distribution of ATSI Scores")
    plt.tight_layout()
    plt.show()

def plot_chl_vs_atsi(df, chl_col="CHL", score_col="ATSI"):
    plt.figure(figsize=(8, 5))
    plt.scatter(df[chl_col], df[score_col])
    plt.xlabel("CHL (µg/L)")
    plt.ylabel("ATSI Score")
    plt.title("CHL vs ATSI")
    plt.tight_layout()
    plt.show()
