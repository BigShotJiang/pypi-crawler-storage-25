import pandas as pd

SAL_THRESHOLD_TABLE = {
    0:  {"CHL_TL": 15.0, "CHL_TU": 30.0},
    1:  {"CHL_TL": 15.0, "CHL_TU": 30.0},
    2:  {"CHL_TL": 15.0, "CHL_TU": 30.0},
    3:  {"CHL_TL": 15.0, "CHL_TU": 30.0},
    4:  {"CHL_TL": 15.0, "CHL_TU": 30.0},
    5:  {"CHL_TL": 15.0, "CHL_TU": 30.0},
    6:  {"CHL_TL": 15.0, "CHL_TU": 30.0},
    7:  {"CHL_TL": 15.0, "CHL_TU": 30.0},
    8:  {"CHL_TL": 15.0, "CHL_TU": 30.0},
    9:  {"CHL_TL": 15.0, "CHL_TU": 30.0},
    10: {"CHL_TL": 15.0, "CHL_TU": 30.0},
    11: {"CHL_TL": 15.0, "CHL_TU": 30.0},
    12: {"CHL_TL": 15.0, "CHL_TU": 30.0},
    13: {"CHL_TL": 15.0, "CHL_TU": 30.0},
    14: {"CHL_TL": 15.0, "CHL_TU": 30.0},
    15: {"CHL_TL": 15.0, "CHL_TU": 30.0},
    16: {"CHL_TL": 15.0, "CHL_TU": 30.0},
    17: {"CHL_TL": 15.0, "CHL_TU": 30.0},
    18: {"CHL_TL": 14.7, "CHL_TU": 29.4},
    19: {"CHL_TL": 14.4, "CHL_TU": 28.9},
    20: {"CHL_TL": 14.2, "CHL_TU": 28.3},
    21: {"CHL_TL": 13.9, "CHL_TU": 27.8},
    22: {"CHL_TL": 13.6, "CHL_TU": 27.2},
    23: {"CHL_TL": 13.3, "CHL_TU": 26.7},
    24: {"CHL_TL": 13.1, "CHL_TU": 26.1},
    25: {"CHL_TL": 12.8, "CHL_TU": 25.6},
    26: {"CHL_TL": 12.5, "CHL_TU": 25.0},
    27: {"CHL_TL": 12.2, "CHL_TU": 24.4},
    28: {"CHL_TL": 11.9, "CHL_TU": 23.9},
    29: {"CHL_TL": 11.7, "CHL_TU": 23.3},
    30: {"CHL_TL": 11.4, "CHL_TU": 22.8},
    31: {"CHL_TL": 11.1, "CHL_TU": 22.2},
    32: {"CHL_TL": 10.8, "CHL_TU": 21.7},
    33: {"CHL_TL": 10.6, "CHL_TU": 21.1},
    34: {"CHL_TL": 10.3, "CHL_TU": 20.6},
    35: {"CHL_TL": 10.0, "CHL_TU": 20.0},
}

def round_salinity_to_median_bin(sal):
    if pd.isna(sal):
        return None
    sal_bin = int(round(float(sal)))
    sal_bin = max(0, min(35, sal_bin))
    return sal_bin

def get_chl_thresholds_from_salinity(sal):
    sal_bin = round_salinity_to_median_bin(sal)
    if sal_bin is None:
        return {"SAL_BIN": None, "CHL_TL": None, "CHL_TU": None}
    vals = SAL_THRESHOLD_TABLE[sal_bin]
    return {"SAL_BIN": sal_bin, "CHL_TL": vals["CHL_TL"], "CHL_TU": vals["CHL_TU"]}

def assign_thresholds(df, sal_col="SAL"):
    df = df.copy()
    threshold_df = df[sal_col].apply(get_chl_thresholds_from_salinity).apply(pd.Series)
    df["SAL_BIN"] = threshold_df["SAL_BIN"]
    df["CHL_TL"] = threshold_df["CHL_TL"]
    df["CHL_TU"] = threshold_df["CHL_TU"]
    return df
