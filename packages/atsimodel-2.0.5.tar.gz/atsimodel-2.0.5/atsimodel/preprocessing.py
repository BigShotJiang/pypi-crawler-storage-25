import pandas as pd

def standardize_columns(df):
    df = df.copy()
    df.columns = [str(c).strip().upper() for c in df.columns]
    return df

def validate_atsi_input(df):
    """
    ATSIModel requires:
        - CHL : Chlorophyll-a
        - SAL : Salinity median / representative salinity
    """
    df = standardize_columns(df)

    required = ["CHL", "SAL"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(
            f"Missing required columns: {missing}. ATSIModel requires CHL and SAL."
        )

    df["CHL"] = pd.to_numeric(df["CHL"], errors="coerce")
    df["SAL"] = pd.to_numeric(df["SAL"], errors="coerce")

    return df
