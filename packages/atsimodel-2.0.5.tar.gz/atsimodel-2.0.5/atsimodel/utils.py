from pathlib import Path

def export_results(df, out_base="ATSI_results", formats=("xlsx", "csv", "json")):
    out_base = Path(out_base)
    out_base.parent.mkdir(parents=True, exist_ok=True)

    if "xlsx" in formats:
        df.to_excel(f"{out_base}.xlsx", index=False)
    if "csv" in formats:
        df.to_csv(f"{out_base}.csv", index=False)
    if "json" in formats:
        df.to_json(f"{out_base}.json", orient="records", indent=4)
