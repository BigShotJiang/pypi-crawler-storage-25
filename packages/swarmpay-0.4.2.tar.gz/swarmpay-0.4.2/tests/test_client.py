"""Tests for SwarmPay client configuration."""

import swarmpay.api_server as api_server
from swarmpay import __version__
from swarmpay.client import SwarmPay


def test_client_uses_legacy_admin_wallet_env(monkeypatch):
    monkeypatch.delenv("SWARMPAY_ADMIN_WALLET", raising=False)
    monkeypatch.setenv("PAYFI_ADMIN_WALLET", "0xLEGACYADMIN")

    client = SwarmPay()

    assert client._admin_wallet == "0xLEGACYADMIN"


def test_client_prefers_new_admin_wallet_env(monkeypatch):
    monkeypatch.setenv("SWARMPAY_ADMIN_WALLET", "0xNEWADMIN")
    monkeypatch.setenv("PAYFI_ADMIN_WALLET", "0xLEGACYADMIN")

    client = SwarmPay()

    assert client._admin_wallet == "0xNEWADMIN"


def test_api_server_uses_package_version():
    assert api_server.__version__ == __version__
