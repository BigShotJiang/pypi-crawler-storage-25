"""Tests for the FeeEngine – fee calculation and volume tiers."""

from swarmpay.fee_engine import FeeEngine, FeeConfig


def test_default_fee_is_one_percent():
    engine = FeeEngine()
    result = engine.calculate_fee(100.0)
    assert result["fee_amount"] == 1.0
    assert result["service_amount"] == 99.0
    assert result["fee_percent"] == 0.01


def test_fee_on_small_amount():
    engine = FeeEngine()
    result = engine.calculate_fee(0.50)
    assert result["fee_amount"] == 0.005
    assert result["service_amount"] == 0.495


def test_minimum_fee_enforced():
    engine = FeeEngine()
    # 1% of $0.01 = $0.0001, but min fee is $0.001
    result = engine.calculate_fee(0.01)
    assert result["fee_amount"] == 0.001


def test_maximum_fee_enforced():
    engine = FeeEngine(FeeConfig(max_fee_usd=10.0))
    # 1% of $5000 = $50, but max is $10
    result = engine.calculate_fee(5000.0)
    assert result["fee_amount"] == 10.0


def test_custom_fee_percent():
    engine = FeeEngine(FeeConfig(base_fee_percent=0.02))
    result = engine.calculate_fee(100.0)
    assert result["fee_amount"] == 2.0
    assert result["fee_percent"] == 0.02


def test_volume_discount_tier_10k():
    engine = FeeEngine()
    engine.record_volume("wallet_a", 15_000)
    result = engine.calculate_fee(100.0, sender_wallet="wallet_a")
    assert result["fee_percent"] == 0.008
    assert result["fee_amount"] == 0.8


def test_volume_discount_tier_100k():
    engine = FeeEngine()
    engine.record_volume("wallet_a", 150_000)
    result = engine.calculate_fee(100.0, sender_wallet="wallet_a")
    assert result["fee_percent"] == 0.005
    assert result["fee_amount"] == 0.5


def test_volume_discount_tier_1m():
    engine = FeeEngine()
    engine.record_volume("wallet_a", 2_000_000)
    result = engine.calculate_fee(100.0, sender_wallet="wallet_a")
    assert result["fee_percent"] == 0.003
    assert result["fee_amount"] == 0.3


def test_volume_tracking_accumulates():
    engine = FeeEngine()
    engine.record_volume("w1", 5_000)
    engine.record_volume("w1", 6_000)
    # Total: 11,000 → tier 0.8%
    result = engine.calculate_fee(100.0, sender_wallet="w1")
    assert result["fee_percent"] == 0.008


def test_different_wallets_independent_volume():
    engine = FeeEngine()
    engine.record_volume("w1", 50_000)
    engine.record_volume("w2", 500)
    r1 = engine.calculate_fee(100.0, sender_wallet="w1")
    r2 = engine.calculate_fee(100.0, sender_wallet="w2")
    assert r1["fee_percent"] == 0.008  # 10k+ tier
    assert r2["fee_percent"] == 0.01   # base tier


def test_admin_wallet_in_result():
    engine = FeeEngine(FeeConfig(admin_wallet="0xADMIN"))
    result = engine.calculate_fee(100.0)
    assert result["admin_wallet"] == "0xADMIN"


def test_fee_schedule():
    engine = FeeEngine()
    schedule = engine.get_fee_schedule()
    assert len(schedule) == 4
    assert schedule[0]["min_volume_usd"] == 0
    assert schedule[0]["fee_percent"] == 0.01
    assert schedule[-1]["min_volume_usd"] == 1_000_000
    assert schedule[-1]["fee_percent"] == 0.003


def test_zero_amount():
    engine = FeeEngine()
    result = engine.calculate_fee(0.0)
    # Min fee kicks in
    assert result["fee_amount"] == 0.001


def test_total_equals_fee_plus_service():
    engine = FeeEngine()
    for amount in [0.10, 1.0, 50.0, 999.99]:
        result = engine.calculate_fee(amount)
        assert abs(result["total"] - (result["fee_amount"] + result["service_amount"])) < 0.000001
