"""Tests for dashboard summary/feed helpers."""

from swarmpay.dashboard import build_dashboard_feed, build_dashboard_summary
from swarmpay.webhooks import WebhookDispatcher


def test_build_dashboard_summary_counts_events_and_deliveries(tmp_path):
    dispatcher = WebhookDispatcher(storage_path=str(tmp_path / "webhooks.json"))
    dispatcher.subscribe("https://example.com/a", "secret-a")
    dispatcher.subscribe("https://example.com/b", "secret-b", enabled=False)
    event = dispatcher.emit("escrow.funded", {"escrow_id": "escrow:1"})
    dispatcher.deliver_event(event, sender=lambda sub, evt: 200, now=100.0)

    summary = build_dashboard_summary(dispatcher)

    assert summary["total_events"] == 1
    assert summary["total_subscriptions"] == 2
    assert summary["enabled_subscriptions"] == 1
    assert summary["successful_deliveries"] == 1
    assert summary["escrow_funded_events"] == 1
    assert summary["delivery_success_rate"] == 1.0


def test_build_dashboard_feed_orders_newest_first(tmp_path):
    dispatcher = WebhookDispatcher(storage_path=str(tmp_path / "webhooks.json"))
    dispatcher.subscribe("https://example.com/a", "secret-a")

    event = dispatcher.emit("escrow.funded", {"escrow_id": "escrow:1"})
    dispatcher.deliver_event(event, sender=lambda sub, evt: 200, now=100.0)

    feed = build_dashboard_feed(dispatcher, limit=10)

    assert len(feed) == 2
    assert feed[0]["timestamp"] >= feed[1]["timestamp"]
    assert feed[0]["kind"] in {"event", "delivery"}
