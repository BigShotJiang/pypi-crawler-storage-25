"""Tests for the ServiceRegistry – service discovery."""

import os
import tempfile
import pytest

from swarmpay.registry import ServiceRegistry, ServiceListing


@pytest.fixture
def registry(tmp_path):
    """Create a registry with a temp storage file."""
    path = str(tmp_path / "test_registry.json")
    return ServiceRegistry(storage_path=path)


def test_register_service(registry):
    listing = ServiceListing(
        wallet="0xAAA",
        service_type="text-analysis",
        price_usd=0.50,
        description="NLP Analysis",
    )
    sid = registry.register(listing)
    assert sid == "text-analysis:0xAAA"


def test_find_service(registry):
    registry.register(ServiceListing(
        wallet="0xAAA", service_type="translation", price_usd=0.30,
    ))
    registry.register(ServiceListing(
        wallet="0xBBB", service_type="translation", price_usd=0.20,
    ))
    results = registry.find("translation")
    assert len(results) == 2


def test_find_case_insensitive(registry):
    registry.register(ServiceListing(
        wallet="0xAAA", service_type="Text-Analysis", price_usd=0.50,
    ))
    results = registry.find("text-analysis")
    assert len(results) == 1


def test_find_cheapest(registry):
    registry.register(ServiceListing(
        wallet="0xAAA", service_type="ocr", price_usd=1.00,
    ))
    registry.register(ServiceListing(
        wallet="0xBBB", service_type="ocr", price_usd=0.25,
    ))
    registry.register(ServiceListing(
        wallet="0xCCC", service_type="ocr", price_usd=0.75,
    ))
    cheapest = registry.find_cheapest("ocr")
    assert cheapest is not None
    assert cheapest["price_usd"] == 0.25
    assert cheapest["wallet"] == "0xBBB"


def test_find_cheapest_no_results(registry):
    result = registry.find_cheapest("nonexistent")
    assert result is None


def test_deregister(registry):
    registry.register(ServiceListing(
        wallet="0xAAA", service_type="summarize", price_usd=0.10,
    ))
    assert len(registry.find("summarize")) == 1
    registry.deregister("summarize:0xAAA")
    assert len(registry.find("summarize")) == 0


def test_list_all(registry):
    registry.register(ServiceListing(
        wallet="0xAAA", service_type="a", price_usd=1.0,
    ))
    registry.register(ServiceListing(
        wallet="0xBBB", service_type="b", price_usd=2.0,
    ))
    all_services = registry.list_all()
    assert len(all_services) == 2


def test_persistence(tmp_path):
    path = str(tmp_path / "persist.json")
    reg1 = ServiceRegistry(storage_path=path)
    reg1.register(ServiceListing(
        wallet="0xAAA", service_type="persist-test", price_usd=0.50,
    ))

    # New instance should load from disk
    reg2 = ServiceRegistry(storage_path=path)
    results = reg2.find("persist-test")
    assert len(results) == 1
    assert results[0]["price_usd"] == 0.50


def test_registered_at_auto_set(registry):
    listing = ServiceListing(
        wallet="0xAAA", service_type="test", price_usd=1.0,
    )
    assert listing.registered_at == ""
    registry.register(listing)
    services = registry.list_all()
    assert services[0]["registered_at"] != ""
