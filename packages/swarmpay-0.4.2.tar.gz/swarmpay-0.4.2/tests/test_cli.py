"""Tests for CLI onboarding helpers."""

from pathlib import Path

from swarmpay.cli import _inspect_config, _read_env_file, _with_defaults, _write_env_file


def test_with_defaults_creates_demo_ready_config(monkeypatch):
    monkeypatch.setattr("swarmpay.cli._generate_api_key", lambda: "sk_swarmpay_test")

    config = _with_defaults({})

    assert config["SWARMPAY_NETWORK"] == "base-sepolia"
    assert config["SWARMPAY_API_KEY"] == "sk_swarmpay_test"
    assert config["SWARMPAY_HOST"] == "127.0.0.1"
    assert config["SWARMPAY_PORT"] == "8420"


def test_write_env_file_round_trip(tmp_path):
    env_path = tmp_path / ".env"
    config = {
        "CDP_API_KEY_ID": "id",
        "CDP_API_KEY_SECRET": "secret",
        "CDP_WALLET_SECRET": "wallet-secret",
        "SWARMPAY_ADMIN_WALLET": "0xADMIN",
        "SWARMPAY_NETWORK": "base-sepolia",
        "SWARMPAY_API_KEY": "sk_swarmpay_test",
        "SWARMPAY_HOST": "127.0.0.1",
        "SWARMPAY_PORT": "8420",
        "OPENAI_API_KEY": "",
    }

    _write_env_file(env_path, config)
    loaded = _read_env_file(env_path)

    assert loaded["CDP_API_KEY_ID"] == "id"
    assert loaded["CDP_WALLET_SECRET"] == "wallet-secret"
    assert loaded["SWARMPAY_API_KEY"] == "sk_swarmpay_test"


def test_inspect_config_reports_demo_mode():
    summary = _inspect_config(
        {
            "SWARMPAY_NETWORK": "base-sepolia",
            "SWARMPAY_API_KEY": "sk_swarmpay_test",
        }
    )

    assert summary["mode"] == "demo"
    assert summary["live_ready"] is False
    assert summary["network_supported"] is True


def test_inspect_config_reports_live_mode():
    summary = _inspect_config(
        {
            "SWARMPAY_NETWORK": "base-mainnet",
            "SWARMPAY_API_KEY": "sk_swarmpay_test",
            "CDP_API_KEY_ID": "id",
            "CDP_API_KEY_SECRET": "secret",
            "CDP_WALLET_SECRET": "wallet-secret",
        }
    )

    assert summary["mode"] == "live"
    assert summary["live_ready"] is True
    assert summary["has_wallet_secret"] is True
