"""Tests for SwarmPay constants."""

from swarmpay.constants import (
    USDC_CONTRACTS,
    TOKEN_DECIMALS,
    SUPPORTED_NETWORKS,
    ERC20_TRANSFER_SELECTOR,
)


def test_usdc_address_format():
    for network, addr in USDC_CONTRACTS.items():
        assert addr.startswith("0x"), f"USDC address on {network} must start with 0x"
        assert len(addr) == 42, f"USDC address on {network} must be 42 chars"


def test_usdc_sepolia_address():
    assert USDC_CONTRACTS["base-sepolia"] == "0x036CbD53842c5426634e7929541eC2318f3dCF7e"


def test_usdc_mainnet_address():
    assert USDC_CONTRACTS["base-mainnet"] == "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"


def test_token_decimals():
    assert TOKEN_DECIMALS["usdc"] == 6
    assert TOKEN_DECIMALS["eth"] == 18


def test_supported_networks():
    assert "base-sepolia" in SUPPORTED_NETWORKS
    assert "base-mainnet" in SUPPORTED_NETWORKS
    assert SUPPORTED_NETWORKS["base-sepolia"]["is_testnet"] is True
    assert SUPPORTED_NETWORKS["base-mainnet"]["is_testnet"] is False


def test_erc20_selector():
    assert ERC20_TRANSFER_SELECTOR == "0xa9059cbb"
