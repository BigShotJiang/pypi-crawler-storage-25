"""
SwarmPay – The Payment Layer for AI Agents.
Visa for the AI Age.

Usage:
    from swarmpay import SwarmPay

    sp = SwarmPay()
    wallet = sp.create_wallet("my-agent")
    wallet.pay("0xRecipient...", amount=0.50)
"""

from swarmpay.client import SwarmPay
from swarmpay.wallet import AgentWallet, PaymentResult
from swarmpay.registry import ServiceRegistry
from swarmpay.fee_engine import FeeEngine
from swarmpay.escrow import EscrowEngine, EscrowConfig, EscrowRecord, EscrowState
from swarmpay.reputation import ReputationEngine, ReputationConfig, AgentReputation
from swarmpay.permissions import PermissionEngine, SpendingLimits, AgentPermissions
from swarmpay.constants import USDC_CONTRACTS, SUPPORTED_NETWORKS
from swarmpay.onchain_escrow import (
    OnchainEscrowActionResult,
    OnchainEscrowClient,
    OnchainEscrowConfig,
    OnchainEscrowFlowResult,
    OnchainEscrowFundingResult,
    OnchainEscrowIntent,
    OnchainEscrowRecord,
    OnchainEscrowStatus,
    OnchainEscrowTx,
    build_escrow_id,
    create_onchain_record,
    hash_escrow_metadata,
)
from swarmpay.webhooks import (
    WebhookDeliveryResult,
    WebhookDispatcher,
    WebhookEvent,
    WebhookSubscription,
    serialize_event,
    sign_event,
)
from swarmpay.dashboard import build_dashboard_feed, build_dashboard_summary

__version__ = "0.4.2"
__all__ = [
    "SwarmPay", "AgentWallet", "PaymentResult",
    "ServiceRegistry", "FeeEngine",
    "EscrowEngine", "EscrowConfig", "EscrowRecord", "EscrowState",
    "ReputationEngine", "ReputationConfig", "AgentReputation",
    "PermissionEngine", "SpendingLimits", "AgentPermissions",
    "USDC_CONTRACTS", "SUPPORTED_NETWORKS",
    "OnchainEscrowActionResult", "OnchainEscrowClient", "OnchainEscrowConfig",
    "OnchainEscrowFlowResult",
    "OnchainEscrowFundingResult",
    "OnchainEscrowIntent", "OnchainEscrowRecord", "OnchainEscrowStatus",
    "OnchainEscrowTx", "build_escrow_id", "create_onchain_record",
    "hash_escrow_metadata", "WebhookDeliveryResult", "WebhookDispatcher",
    "WebhookEvent", "WebhookSubscription", "serialize_event", "sign_event",
    "build_dashboard_feed", "build_dashboard_summary",
]
