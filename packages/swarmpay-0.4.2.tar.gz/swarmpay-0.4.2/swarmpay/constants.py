"""
SwarmPay Constants – Contract-Adressen, Netzwerk-Config.
"""

# USDC Contract Addresses (Circle Official)
USDC_CONTRACTS = {
    "base-mainnet": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
    "base-sepolia": "0x036CbD53842c5426634e7929541eC2318f3dCF7e",
}

# ETH Placeholder (used by CDP SDK internally)
ETH_ADDRESS = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE"

# Token Decimals
TOKEN_DECIMALS = {
    "usdc": 6,
    "eth": 18,
}

# Supported Networks
SUPPORTED_NETWORKS = {
    "base-sepolia": {
        "name": "Base Sepolia Testnet",
        "explorer": "https://sepolia.basescan.org",
        "is_testnet": True,
    },
    "base-mainnet": {
        "name": "Base Mainnet",
        "explorer": "https://basescan.org",
        "is_testnet": False,
    },
}

# SwarmPay Escrow Contract Addresses
ESCROW_CONTRACTS = {
    "base-mainnet": "0x9Be790E8583f0425D213bF862148E8e531700106",
}

# ERC-20 Transfer Function Signature
ERC20_TRANSFER_SELECTOR = "0xa9059cbb"
ERC20_APPROVE_SELECTOR = "0x095ea7b3"

# SwarmPay Escrow Function Signatures (computed from deployed ABI)
# fundEscrow(address,address,uint256,uint256,uint256,uint64,bytes32)
ESCROW_FUND_SELECTOR = "0xee5e8f20"
# confirmDelivery(uint256)
ESCROW_CONFIRM_DELIVERY_SELECTOR = "0xfd84cb97"
# releaseEscrow(uint256)
ESCROW_RELEASE_SELECTOR = "0xed653164"
# refundEscrow(uint256)
ESCROW_REFUND_SELECTOR = "0x356f9dfd"
# disputeEscrow(uint256,bytes32)
ESCROW_DISPUTE_SELECTOR = "0xc1e6a198"
