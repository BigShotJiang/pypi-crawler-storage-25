"""
SwarmPay CLI Entry Point.

Usage:
    python3 -m swarmpay          → Show all commands
    python3 -m swarmpay setup    → Interactive setup
    python3 -m swarmpay demo     → Quick payment demo
    python3 -m swarmpay serve    → Start API server
"""
import sys
from swarmpay.cli import main

if __name__ == "__main__":
    main()
