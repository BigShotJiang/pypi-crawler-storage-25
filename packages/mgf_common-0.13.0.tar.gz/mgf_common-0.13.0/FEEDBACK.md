# FEEDBACK.md — Consumer feedback & open roadmap

> **Living document.** Design conversations between
> `mgf-common` maintainers and library consumers.
>
> **Format.** Each entry is a uniform block: identifier, status
> badge, severity, structured frontmatter, then prose. The format
> is optimised for both human readers and AI agents — every entry
> has the same shape, every status field is grep-able.
>
> **Bar.** Industry-standard. The shape any serious Python
> service / desktop / mobile project reaches for by default.

---

## §1. Process

### 1.1 Submission

A consumer adds an entry by opening a PR that edits this file.
Every entry MUST follow the **§1.4 entry template** below — the
uniform shape is what makes the document machine-actionable.

The `mgf-common feedback` CLI prints the submission flow + the
entry template ready to paste. Run it from any project that
depends on mgf-common.

### 1.2 Severity

| Level | Meaning | SLA |
|---|---|---|
| 🔴 **Blocker** | Getting it wrong requires a breaking change to fix later. MUST be decided before locking the public surface. | Triaged within the release cycle it lands in; decision recorded inline. |
| 🟡 **High** | Significant quality-of-life issue. Painful to live with, additive to add later. | Addressed as a minor / patch; no release gate. |
| 🟢 **Nice-to-have** | Real value, not urgent. | Picked up when a maintainer has capacity or a second consumer asks. |
| 💭 **Aspirational** | "Long-term where should this go" input. Not actionable today. | Kept for roadmap reviews; drives major-version planning. |

### 1.3 Status lifecycle

```
OPEN → ACCEPTED → SCHEDULED → SHIPPED
       ↓
       REJECTED   (with rationale)
       DEFERRED   (agreed in principle, not scheduled)
```

- **OPEN** — submitted, not yet triaged.
- **ACCEPTED** — maintainers agree; not yet scheduled.
- **SCHEDULED** — assigned a release.
- **SHIPPED** — landed; entry's status changes inline with a
  one-line retrospective. (We don't keep a parallel "shipped
  audit" section — the CHANGELOG carries the audit trail.)
- **REJECTED** — kept (not deleted) so future consumers don't
  re-raise.
- **DEFERRED** — agreed in principle, picked up at next roadmap
  review.

### 1.4 Entry template — every new entry MUST follow this shape

```markdown
### `<AREA>-<NN>` — One-line title

| Field | Value |
|---|---|
| Status | OPEN / ACCEPTED / SCHEDULED / SHIPPED / REJECTED / DEFERRED |
| Severity | 🔴 / 🟡 / 🟢 / 💭 |
| Submitter | <Project> (commit `<sha>` if applicable) |
| Submitted | YYYY-MM-DD |
| Decision | pending / accepted / rejected (one line) |
| Decided on | YYYY-MM-DD or `—` |
| Scheduled for | release tag or `—` |
| Shipped in | commit SHA + release tag, or `—` |

**Concern.** What's wrong or missing. One paragraph.

**Why it matters.** Why this affects real consumers. One paragraph.

**Suggested shape.** Concrete proposal — code snippet, prose, or
both. Not required to be the final answer; required to be a
starting point.

**Decision rationale.** Filled when triaged. Why accepted /
rejected / deferred / scheduled.

**Retrospective.** Filled when shipped. Did the suggested shape
survive contact with implementation? What changed and why?
```

The frontmatter table is the single source of truth for status.
Prose comes after.

### 1.5 Ground rules

- **API stability is best-effort during the 0.x window.** Pinning
  to a minor (e.g., `>=0.X,<0.Y`) opts the consumer in to a
  predictable change cadence; pinning broadly opts in to faster
  iteration. Aggressive 🔴 Blocker resolution is the point of
  the early window.
- **A "co-developed" consumer carries less signal than a remote
  one.** A concern raised independently by a consumer with no
  prior coordination is a stronger lift signal than the same
  concern surfaced by the maintainer's primary consumer. Filter
  accordingly.
- **Don't optimise for `mgf-common` developers.** Every design
  trade-off favours the consumer. A feature that saves the
  library author an hour but costs every consumer a day of
  integration pain is a net loss.

---

## §2. Open feedback (active)

Sorted by area, then ID. To add a new entry, copy §1.4's template
verbatim and fill it in.

### 🟡 Papercuts

#### `PAPER-03` — Observability shim pattern is load-bearing but undocumented

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High (doc, not code) |
| Submitter | Reference consumer |
| Submitted | 2026-04-23 |
| Decision | accept (recipe form rather than standards-doc section) |
| Decided on | 2026-05-01 |
| Scheduled for | shipped in-tree |
| Shipped in | `docs/public/recipes/observability_shim.md` (in-tree) + cross-link from `05_observability.md` |

**Concern.** A consumer can layer a project-local
`<project>/observability/__init__.py` re-export shim over
`mgf.common.observability` to layer in its own redactor /
formatter / handler extensions without forking `mgf.common`.
This pattern is valuable but nowhere documented as recommended
practice.

**Why it matters.** A future consumer evaluating the
architecture will either (a) miss the pattern entirely and
either fork or live with limited extensibility, or (b) discover
it by reading another consumer's source — neither is the right
onboarding shape for an industry-standard library.

**Suggested shape.** Add a section to
`docs/standards/COMMON_COMPONENTS.md` or a new
`docs/patterns/shim-layering.md` explaining: (a) why a consumer
might want a shim even without legacy call sites, (b) the
`import-linter` contract that keeps the shim from re-entangling,
(c) how to layer consumer-specific redactor extensions on top.

**Resolution.** Shipped as a recipe at
`docs/public/recipes/observability_shim.md` rather than a
standards-doc section: the standards docs declare MUSTs and
SHOULDs, while this is a recommended pattern (a recipe). The
recipe covers: why a shim is valuable for extensibility (not
just back-compat), the closed-box rule that applies inside the
shim, a layered example (custom redactor + custom log handler +
wrapper around `operation_span`), an `import-linter` contract
for the consumer side, and when NOT to use the shim.
Cross-linked from `docs/public/05_observability.md` "Related
docs".

---

#### `PAPER-04` — Schema-versioning patterns are not reusable

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | Reference consumer |
| Submitted | 2026-04-23 |
| Decision | accept (suggested shape verbatim) |
| Decided on | 2026-05-01 |
| Scheduled for | shipped in-tree |
| Shipped in | `mgf.common.versioned.VersionedFileStore[T]` + `MigrateFn` (in-tree) |

**Concern.** Every sub-config file in a real consumer (hooks,
schedules, alerts, lab specs, profiles) implements the same
shape: `version: int` + unknown-key rejection + migration
callback + atomic write. The code is duplicated across many
modules because `mgf.common.config.BaseAppSettings` covers only
the top-level config file, not satellite files.

**Why it matters.** Real code duplication cost (~600 LOC in
the reference consumer alone); will replicate in every consumer.
Each instance also drifts subtly (slightly different error
wording, slightly different migration shape) — exactly the
bit-rot the standards exist to prevent.

**Resolution.** Ships as `mgf.common.versioned`, a new public
subpackage. Two public names:

- `VersionedFileStore[T]` — the generic. Constructor takes the
  pydantic schema (must set `extra="forbid"`), the
  `current_version`, an optional `migrate=` callback, and an
  optional `version_field=` (default `"version"`; the consumer
  uses both `version` and `schema_version`). Format auto-detects
  from the path suffix (`.yaml` / `.yml` / `.json`); override via
  `file_format=`. `load()` validates, routes through migrate,
  returns `T`. `save()` stamps `version_field=current_version`
  and writes atomically (temp + fsync + rename, mode 0o600).
  Errors land as `AppConfigError` with PEP 678 notes naming the
  path + offending key.
- `MigrateFn` — the type alias for the migration callback:
  `Callable[[Mapping[str, Any], int], Mapping[str, Any]]`.

Recipe at `docs/public/recipes/versioned.md`. Pinned by 28 unit
tests + 5 user-perspective tests + the `PUBLIC_API.md` /
`PUBLIC_API.json` contract.

---

#### `PAPER-06` — `docs/standards/` cites the reference consumer with file:line

| Field | Value |
|---|---|
| Status | 🟡 PARTIAL — line-range citations stripped + caveat banner added |
| Severity | 🟡 High (doc refactor) |
| Submitter | Reference consumer |
| Submitted | 2026-04-23 |
| Decision | accept partial; full restructure deferred |
| Decided on | 2026-04-30 |
| Scheduled for | full restructure: future |
| Shipped in | partial: line ranges stripped from 12 citations across 6 docs; caveat banner in `docs/standards/README.md` |

**Concern.** Some topic docs have "AS-IS in <consumer>"
paragraphs citing specific file:line locations. These rot as the
consumer evolves. When a second consumer arrives, these
paragraphs become confusing ("wait, is that the reference
example or an accident?").

**Why it matters.** The standards docs are the public face of
the project. Consumer-specific examples cluttering the
cross-project standard creates a perception that the standards
are consumer-shaped rather than industry-shaped — which
undermines the cornerstone-library positioning.

**Suggested shape (partial done).** Highest-rot-risk component
closed: 12 `*.py:NN-MM` line-range citations across
`COMMON_COMPONENTS.md`, `LOGGING.md`, `CONFIGURATION.md`,
`DESIGN_PRINCIPLES.md`, and `ERROR_HANDLING.md` replaced with
file/function references that don't drift on every refactor. A
caveat banner in `docs/standards/README.md` warns readers that
consumer-specific examples are illustrative.

**Full restructure (still open).** Move consumer-specific
paragraphs into a dedicated `docs/reference-consumer/`
subfolder. When a second consumer arrives, generalise to
`docs/reference-consumers/Project1.md` /
`docs/reference-consumers/Project2.md`. Standards stay
consumer-neutral.

---

#### `PAPER-07` — Default-path helpers (`_default_log_path`, `_crash_dir`) are private but consumers need them

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | Maintainer audit (VManager integration walk, 2026-05-01) |
| Submitted | 2026-05-01 |
| Decision | accept (suggested shape verbatim) |
| Decided on | 2026-05-02 |
| Scheduled for | 0.13.0 |
| Shipped in | `mgf.common.observability.{default_log_path, default_crash_dir, default_state_dir}` (v0.13.0); underscore-prefixed names retained as deprecated aliases that emit `MgfDeprecationWarning` for one cycle |

**Concern.** Consumers writing observability-adjacent UI (a log
viewer dialog, a crash-report browser, a "show me where my
state lives" diagnostic) need to know the on-disk paths the
library writes to. Today these paths are computed by private
helpers in `mgf.common.observability`:

- `mgf.common.observability.logging_setup._default_log_path()`
  — resolves `<state>/<app>/logs/<app>.log`.
- `mgf.common.observability.crash_reporter._crash_dir()` —
  resolves `<state>/<app>/crashes/`.

The reference consumer has already had to reach into the
private surface — `vmanager/gui/windows/main_window.py:254`
imports `_default_log_path` directly — which is a real
closed-box leak the consumer had no public alternative for.

**Why it matters.** Closed-box discipline is load-bearing for
`mgf-common`'s positioning. Every consumer that needs to
surface "where do my logs live?" in their UI is going to hit
this gap. The library can either (a) keep both paths private
and force every consumer to reach into the private surface
(the worst outcome — silent erosion of the closed-box
property) or (b) promote them now while the surface is still
small.

**Suggested shape.** Promote both helpers to public, ideally
in a small dedicated module so future path helpers have a
home::

    # mgf/common/observability/paths.py — new public module
    from pathlib import Path

    def default_log_path() -> Path: ...
    def default_crash_dir() -> Path: ...
    def default_state_dir() -> Path: ...   # the parent of both

Re-export from `mgf.common.observability.__all__`. Keep the
underscore-prefixed names as deprecated aliases for one cycle
so consumers reaching into the private surface get a
deprecation warning rather than a silent break.

Pin via the existing AP-10 sync test + a public-surface test
in `tests/public_surface/test_observability_as_user.py`.

---

#### `PAPER-08` — `mgf-common catch-up` should detect closed-box leaks (private imports from `mgf.common._*`)

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🟢 Nice-to-have |
| Submitter | Maintainer audit (VManager integration walk, 2026-05-01) |
| Submitted | 2026-05-01 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** `mgf-common catch-up` audits four-gate config,
pin staleness, CLAUDE.md presence, and v0.1-pattern call
sites. It does NOT audit consumer source for closed-box leaks
(`from mgf.common._x import _y` or `from mgf.common.X import
_private`). The reference consumer had one such leak that the
audit didn't surface (`_default_log_path` import in
VManager's main window) — `tests/public_surface/`'s
`test_no_private_imports.py` AST pin is exactly the right
shape, but lives in `mgf-common`'s test suite, so the
discipline isn't enforced consumer-side unless the consumer
copies it.

**Why it matters.** The closed-box rule is harder to enforce
when consumers can write `from mgf.common._foo import _bar`
and silently get away with it until the next refactor breaks
their import. Surfacing this in `catch-up` makes the rule
discoverable as part of the standard "is my project up to
spec?" workflow, rather than something the consumer has to
remember to write a test for.

**Suggested shape.** Extend `_check_legacy_patterns` (or add a
new `_check_closed_box_leaks` audit row) that AST-walks every
`*.py` under `src/` and emits a warning for each
`mgf.common._*` import or `mgf.common.X._private`
import-from. Output format same as the existing
"v0.1-pattern usage" row — list the offending paths and a
one-line suggestion. Caveat: the audit MUST NOT walk into the
consumer's own `tests/` directory, since
`tests/unit/_internal_test_helpers/` style imports are
legitimate consumer-side.

This is also the right shape to surface FEEDBACK PAPER-07 —
the audit would name the private import and PAPER-07 (when
shipped) would direct the consumer to the public alternative.

---

#### `VAULT-01` — Vault registry should accept `config_model=` for typed custom backends

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | Maintainer dogfood |
| Submitted | 2026-04-28 |
| Decision | accept (suggested shape verbatim) |
| Decided on | 2026-05-01 |
| Scheduled for | shipped in-tree |
| Shipped in | `register_vault_backend(name, *, config_model=None)` + a `model_validator` on `VaultSettings` that coerces dicts → typed model when registered (in-tree) |

**Concern.** The three built-in vault backends
(`EnvVaultConfig` / `KeyringVaultConfig` /
`EncryptedFileVaultConfig`) ship typed configs via the
discriminated union `BuiltinVaultBackendConfig`. Custom
backends (HashiCorp Vault, AWS Secrets Manager, …) still use
`dict[str, Any]` — the closed-box leak is half-closed.
Consumer code shipping a custom backend writes stringly-typed
config dicts that the IDE / mypy / pydantic won't validate.

**Why it matters.** The whole point of typed configs was to
close the "consumers spelunk source to know what keys each
backend wants" gap. Custom backends still spelunk. Real
third-party stores (HashiCorp / AWS) are exactly where the
typed-config win matters most.

**Suggested shape.** Extend `register_vault_backend` to
optionally accept a `config_model` parameter; the registry
stores the mapping. `VaultSettings.config` then validates
against the registered model when the active `backend` matches:

```python
from mgf.common.vault import register_vault_backend
from mgf.common.config import BaseModel, ConfigDict

class HashicorpVaultConfig(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    backend_type: Literal["hashicorp"] = "hashicorp"
    url: str
    token: str
    mount: str = "secret"

@register_vault_backend("hashicorp", config_model=HashicorpVaultConfig)
def make_hashicorp_vault(config: HashicorpVaultConfig) -> VaultProtocol:
    ...
```

`MgfSettings(backend="hashicorp", config=...)` then accepts the
typed config; `BuiltinVaultBackendConfig` becomes a
dynamically-resolved discriminated union from the registry.

**Resolution.** Ships as additive surface:

- `register_vault_backend(name, *, config_model=None)` — the new
  `config_model=` kwarg accepts a `BaseModel` subclass. The
  registry stores `(factory, config_model)` pairs internally.
- `VaultSettings` gets a `model_validator(mode="after")` that
  consults the registry: when the active `backend` has a
  registered `config_model`, an incoming dict is validated and
  replaced with the typed instance; an already-typed instance
  passes through; a wrong typed instance raises with a clear
  error; an unregistered backend leaves the dict untouched
  (factories registered without a model own their own validation).
- Built-in backends (`env` / `keyring` / `file`) keep their
  existing isinstance dispatch + deprecation warning for
  backward compat — the change is purely additive for custom
  backends.

Recipe section in `docs/public/07_vault.md` ("Custom backend with
a typed config — recommended"). Pinned by 8 unit tests + 1
public-surface test.

---

### 💭 Aspirational

#### `ASPIRE-01` — "Multi-consumer process" as an explicit design choice

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 💭 Aspirational |
| Submitter | Reference consumer |
| Submitted | 2026-04-23 |
| Decision | accept (position paper at suggested path) |
| Decided on | 2026-05-01 |
| Scheduled for | shipped in-tree |
| Shipped in | `docs/public/multi_tenancy.md` (in-tree) + cross-link from `01_lifecycle.md` |

**Concern.** The hybrid module-global + opt-in `AppContext`
shape covers most "library-in-library" / multi-consumer
scenarios via PEP 567 contextvar isolation. But the design
question of whether mgf-common explicitly supports or
explicitly forbids multi-tenancy is worth a position paper —
silence is the worst option, since consumers who hit
ambiguity discover it via pain.

**Why it matters.** Decide whether `mgf-common` explicitly
supports or explicitly forbids multi-tenancy as part of the
public-API contract. The current shape supports it implicitly
(scoped `AppContext` context manager), but the contract isn't
documented as a stable promise.

**Suggested shape.** A `docs/public/multi_tenancy.md` walkthrough
that documents the supported scenarios:

  - Library plug-in with its own identity
  - Monorepo tests importing multiple consumer projects
  - Long-running services embedding consumer sub-components

…plus the unsupported ones (e.g., per-request identity in a
single-process server — that's what request-id contextvars are
for, not full identity isolation).

**Resolution.** Shipped as
[`docs/public/multi_tenancy.md`](../docs/public/multi_tenancy.md):
a position paper that commits the project to a specific shape.
The supported scenarios match the suggested list (S1 plug-in
framework, S2 monorepo tests, S3 long-running services with
finite tenants). The unsupported anti-pattern is named
explicitly: per-request identity in a single-process server —
with reasons (cardinality, crash-dir scatter, OTel
service.name semantics) and the right alternative
(`request_id` contextvar via the
fastapi/django middleware that already ships). The contract
table at the end is part of the public-API promise.

---

## §3. Multi-tenancy decision (design rationale)

The hardest unresolved design question, captured here in full so
the trade-offs survive even if the related entries above don't.

**Option A — "One app per process, explicit."**
- Pro: simple, fast (no contextvar lookup), matches 95% of real use.
- Con: forecloses on library-in-library architectures forever.

**Option B — Per-consumer `AppContext` (full contextvar).**
- Pro: supports every use case.
- Con: every observability function pays a contextvar lookup;
  surface-area doubles (every API needs a sibling that takes a
  context arg).

**Option C — Hybrid (the shipped shape).**
- Module-level globals for the default; `AppContext` as opt-in
  override. Observability resolves via the active context if any,
  else the global.
- Pro: zero overhead for the 95% case; extension available for
  the 5%.
- Con: two paths to reason about (acceptable: the second path is
  documented as a power-user escape hatch).

The Option C shape is what `mgf.common.bootstrap()` +
`AppContext` currently implement. PEP 567 contextvar semantics
give correct async-task isolation + thread isolation without
per-call plumbing. The `current_context()` fast path is a
single ContextVar.get() call (~30 ns).

---

## §4. Reviewer's meta-feedback

Unvarnished personal view from the maintainer + co-design partner.
Take or leave. No frontmatter — these aren't actionable items,
they're trajectory observations.

1. **`mgf-common` is more ambitious than its size suggests.**
   Small today; ambition (industry-standard Python infrastructure
   library) is enormous. Every decision should be made with
   "what would I do if this had 100 consumers" in mind.

2. **The reference-consumer model is a double-edged sword.**
   A co-designed reference consumer gives `mgf-common` a starting
   advantage but biases every decision toward "this works for
   <that consumer>". A second consumer's audit will surface
   assumptions the first can't see. **Recommendation:** even a
   single-file utility that uses `mgf.common.config` only would
   surface assumptions; recruit one early.

3. **The standards docs are heroic and 100% aimed at humans.**
   The "Rules box" pattern is great. But industry-standard also
   means machine-readable: the MUST/SHOULD/MAY set should be
   extractable as a JSON schema so a consumer's CI can run
   `mgf-common-lint` for a structured pass/fail report.

4. **The release flow is a latent risk.** Manual `uv publish`
   from a token file works fine for now. For an industry-standard
   library, plan the path to GPG-signed releases + SLSA provenance
   + a release branch requiring second-maintainer sign-off. Not
   urgent, but plan.

5. **The "cornerstone rhythm" — one shared library + many
   consumers — is the highest-leverage pattern in the project.**
   It captures something most libraries never articulate. Real
   audience is library AUTHORS, not consumers. Consider a separate
   `docs/for-library-authors/` track or a blog post to bootstrap
   the community.

---

## §5. How consumers submit feedback

Any project that depends on `mgf-common` — co-developed sibling,
external adopter, internal team project, hobby user — uses this
file to surface concerns. The submission flow is the same
regardless of relationship to the maintainers.

### Quick-start

```bash
# In a project that has mgf-common installed:
mgf-common feedback              # how to submit + severity guide
mgf-common feedback --template   # the entry template, ready to paste
mgf-common feedback --url        # this file's URL on codeberg
```

### Submission steps

1. **Read §1.4 (entry template) + §1.2 (severity).** The
   uniform shape is what makes the document machine-actionable.
   Don't deviate — the audit trail depends on it.
2. **Pick a fresh ID.** Format `<AREA>-<NN>` where `AREA` is a
   capitalised domain prefix (e.g., `API`, `HTTP`, `DB`,
   `CONFIG`, `SEC`, `TEST`, `VAULT`, `SSH`) and `NN` is a
   2-digit sequence within that area.
3. **Add the entry under §2** (open feedback). §2 is for "this
   is wrong / missing / painful." Roadmap-shaped requests —
   "this whole module would be useful" — also live in §2;
   severity tells you how urgent.
4. **Open a PR.** Two paths depending on access:
   - **Co-developer / sibling-project author**: PR directly
     against `mgf-common`'s `master`.
   - **External consumer (no PR access yet)**: open the
     codeberg PR from a fork. If you can't fork or PR
     (corporate firewall, etc.), open an issue at
     `https://codeberg.org/magogi-admin/mgf_common/issues` with
     "FEEDBACK:" prefix and paste the entry — a maintainer will
     mirror it into FEEDBACK.md and reference your issue.
5. **Triage** happens in the PR thread. The decision (accepted
   / rejected / deferred / scheduled) lands in the entry's
   `Decision` field. The maintainer drives this; submitters
   don't need to push.
6. **When shipped**, the entry's status changes to SHIPPED with
   a one-line retrospective on what was implemented + any
   shape changes. The CHANGELOG carries the full release-level
   detail.
7. **Rejected entries stay in the file** with rationale —
   recording "we considered this and said no, because…" is
   higher-leverage than recording only what shipped.

### What makes a great submission

- **Specific call site or example.** "I tried `MgfSettings(...)`
  with `extra_keys=['foo']` and got a confusing error" beats
  "settings are awkward."
- **Severity self-assessment.** Be honest. A 🔴 means "if we
  lock the API with this, fixing it is breaking later." Most
  things are 🟡 or 🟢; reserve 🔴 for genuine API-shape
  concerns.
- **Suggested shape, even if rough.** A wrong starting point is
  more useful than no starting point. The maintainer can refine.
- **One concern per entry.** Don't bundle. If you have three
  separate sharp edges, file three entries — they'll be triaged
  on different cadences.

### Don't worry about

- **Whether your concern is "important enough."** File it. The
  triage will sort severity. False-negative (concern missed) is
  more expensive than false-positive (entry triaged + closed
  quickly).
- **Whether the maintainer will be annoyed.** This file IS the
  design conversation.
- **Picking the perfect ID.** Maintainers will renumber if
  there's a clash. Get the entry in.

---

## §6. Cross-references

- Engineering standards: [`docs/standards/`](docs/standards/) (8 topic docs).
- Public-API contract: [`PUBLIC_API.md`](PUBLIC_API.md) (the AP-10 contract).
- Vulnerability-reporting policy: [`SECURITY.md`](SECURITY.md) (the SC-12 contract).
- Maintainer's dense-lookup doc: [`docs/claude/CLAUDE.md`](docs/claude/CLAUDE.md).
- Onboarding entry point: [`STARTHERE.md`](STARTHERE.md).
