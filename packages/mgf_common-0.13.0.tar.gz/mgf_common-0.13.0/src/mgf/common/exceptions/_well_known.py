"""Well-known exception categories + generic concretes.

Categories (8) — every consumer-project exception falls under one of
these so callers can match on a category without enumerating every
concrete subclass:

  * :class:`ConfigError`       — config schema / validation failures
  * :class:`ProviderError`     — anything raised by a provider impl
  * :class:`OperationError`    — runtime failure during a use case
  * :class:`GuestError`        — failure talking to a remote agent
  * :class:`EnvironmentError`  — host pre-flight failure
  * :class:`VaultError`        — credential storage failure
  * :class:`SchedulerError`    — scheduler / hook subsystem failure

Generic concretes (4) — useful on their own AND useful as bases for
project-specific subclasses. Each carries machine-readable fields per
rule EH-08:

  * :class:`SchemaValidationError`   — carries ``.errors`` (list)
  * :class:`CommandError`            — carries ``.argv`` / ``.returncode`` / ``.stderr``
  * :class:`ResourceNotFoundError`   — carries ``.name``
  * :class:`ResourceAlreadyExistsError` — carries ``.name``

See ``docs/standards/ERROR_HANDLING.md`` §2 for the design rationale
+ the drop-in template that produced this file.
"""

from __future__ import annotations

from typing import Any

from mgf.common.exceptions._base import AppError

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


class ConfigError(AppError):
    """Base for configuration / spec validation failures."""


class SchemaValidationError(ConfigError):
    """A typed spec or config payload failed validation.

    Always carries the *complete* list of errors so callers can show
    every problem at once (don't make the user re-run for each one).

    The message prefix is configurable via the
    :attr:`_MESSAGE_PREFIX` class attribute. Subclasses that want a
    different prefix override it without bypassing this class's
    ``__init__`` (closes FEEDBACK PAPER-05). Example::

        class SpecValidationError(SchemaValidationError):
            _MESSAGE_PREFIX = "spec validation failed"

    The default ``"validation failed"`` is pinned by the test suite
    so existing consumers depending on it stay green.
    """

    # Override in subclasses to customise the message prefix.
    # Class attribute (not constructor arg) so subclasses don't have
    # to forward arguments.
    _MESSAGE_PREFIX: str = "validation failed"

    def __init__(self, errors: list[str]) -> None:
        if not errors:
            raise ValueError("SchemaValidationError requires at least one error")
        self.errors: list[str] = list(errors)  # copy — defensive
        super().__init__(f"{self._MESSAGE_PREFIX}: {'; '.join(errors)}")


class AppConfigError(ConfigError):
    """The application config file is missing, malformed, or wrong version.

    Raised by :func:`mgf.common.config.load_settings` and friends.
    The message is human-formatted; consumer projects MAY subclass
    to add app-specific action hints (rule EH-09).
    """


# ---------------------------------------------------------------------------
# Provider (third-party SDK / hardware boundary)
# ---------------------------------------------------------------------------


class ProviderError(AppError):
    """Base for failures inside a provider implementation.

    A provider implementation MUST translate every third-party
    exception into a ProviderError (or subclass) at the boundary
    that owns the third-party call (rule EH-02).
    """


class ResourceNotFoundError(ProviderError):
    """A name or id did not resolve to any known resource.

    Carries ``.name`` for callers that need to programmatically
    decide what to do (e.g., create the missing resource). Subclass
    in your project to add an actionable message hint per rule
    EH-09 — for example, VManager's ``DomainNotFoundError`` extends
    the message with "run 'vmanager vm list' to see known VMs".
    """

    def __init__(self, name: str) -> None:
        self.name: str = name
        super().__init__(f"no resource named {name!r}")


class ResourceAlreadyExistsError(ProviderError):
    """A create operation collided with an existing resource."""

    def __init__(self, name: str) -> None:
        self.name: str = name
        super().__init__(f"a resource named {name!r} already exists")


# ---------------------------------------------------------------------------
# Operations (runtime failures during a long-running use case)
# ---------------------------------------------------------------------------


class OperationError(AppError):
    """Base for runtime failures during a long-running operation."""


class CommandError(OperationError):
    """A subprocess invoked via the shell wrapper exited non-zero.

    Carries argv, returncode, and stderr so callers can surface a
    precise error without re-running the command. Tests rely on the
    "command failed (exit N):" prefix and on the trailing
    ": <stderr>" tail when stderr is non-empty.
    """

    def __init__(
        self,
        argv: list[str],
        returncode: int,
        stderr: str = "",
    ) -> None:
        self.argv: list[str] = list(argv)
        self.returncode: int = returncode
        self.stderr: str = stderr
        cmd = " ".join(argv)
        tail = f": {stderr.strip()}" if stderr.strip() else ""
        super().__init__(f"command failed (exit {returncode}): {cmd}{tail}")


# ---------------------------------------------------------------------------
# Guest / network (remote agent communication)
# ---------------------------------------------------------------------------


class GuestError(AppError):
    """Base for failures communicating with a remote agent."""


class GuestUnreachableError(GuestError):
    """Could not open a connection to a remote host.

    Raised by SSH client wrappers, guest-agent ping helpers, and any
    other code that opens a network connection to a remote system.
    The message typically includes the host + port + the underlying
    cause; consumer projects MAY subclass to add an action hint per
    rule EH-09.
    """


class GuestCommandError(GuestError):
    """A command ran on the remote host but returned non-zero.

    Distinct from :class:`GuestUnreachableError` (network/auth
    failure) and from :class:`CommandError` (host-side subprocess
    failure). Used by the SSH client wrapper to surface remote
    exit codes.
    """


# ---------------------------------------------------------------------------
# Vault (credential storage)
# ---------------------------------------------------------------------------


class VaultError(AppError):
    """Base for credential vault failures."""


# ---------------------------------------------------------------------------
# Environment (host pre-flight)
# ---------------------------------------------------------------------------


class HostEnvironmentError(AppError):
    """Base for host pre-flight failures.

    Raised when a host-level pre-flight check fails: CPU lacks
    vmx, kernel module missing, required binary absent, etc.

    Named ``HostEnvironmentError`` (not ``EnvironmentError``) to
    avoid shadowing Python's built-in alias for ``OSError``. The
    legacy name remains as a deprecated alias that emits
    :class:`MgfDeprecationWarning` on subclass or instantiation.
    """


# Deprecated alias — construction emits MgfDeprecationWarning so
# consumers see the migration signal. The class IS
# HostEnvironmentError so isinstance checks against either name work.
class _DeprecatedEnvironmentErrorMeta(type):
    """Metaclass that emits MgfDeprecationWarning on subclass /
    direct construction. Lets us keep ``EnvironmentError`` as a
    drop-in alias while signalling the rename loudly."""

    def __call__(cls, *args: Any, **kwargs: Any) -> Any:
        import warnings

        from mgf.common._warnings import MgfDeprecationWarning

        warnings.warn(
            "mgf.common.exceptions.EnvironmentError is deprecated; "
            "use HostEnvironmentError instead.",
            MgfDeprecationWarning,
            stacklevel=2,
        )
        return super().__call__(*args, **kwargs)

    def __subclasscheck__(cls, subclass: type) -> bool:
        # Make `issubclass(MyError, EnvironmentError)` work for
        # MyError defined as `MyError(HostEnvironmentError)`.
        return issubclass(subclass, HostEnvironmentError) or super().__subclasscheck__(subclass)


class EnvironmentError(  # noqa: A001 — alias for HostEnvironmentError
    HostEnvironmentError, metaclass=_DeprecatedEnvironmentErrorMeta,
):
    """Deprecated alias for :class:`HostEnvironmentError`.

    The name shadowed Python's built-in ``EnvironmentError`` (an
    alias for ``OSError``). Use :class:`HostEnvironmentError` in
    new code.
    """


# ---------------------------------------------------------------------------
# Scheduler / hooks
# ---------------------------------------------------------------------------


class SchedulerError(AppError):
    """Base for scheduler and hook subsystem failures."""


# ---------------------------------------------------------------------------
# Cancellation (cooperative; rule DP-09)
# ---------------------------------------------------------------------------


class CancellationError(OperationError):
    """A long-running operation was cancelled cooperatively.

    Raised by :class:`mgf.common.progress.CancellationToken.raise_if_cancelled`
    (and its async sibling) when ``cancel()`` has been signalled.
    Subclass of :class:`OperationError` so existing CLI top-level
    handlers that map ``OperationError`` → exit code catch it
    without code change (rule EH-04).

    The standard rule (``DESIGN_PRINCIPLES.md`` §8): cancellation
    MUST raise a typed exception, never a bare
    :class:`KeyboardInterrupt`. ``CancellationError`` is the
    canonical type to use; consumer call sites either catch it
    explicitly to render a nice "operation cancelled" message,
    or let it propagate up to the top-level handler.
    """

    def __init__(self, message: str = "operation cancelled by user") -> None:
        super().__init__(message)


# ---------------------------------------------------------------------------
# Lifecycle (bootstrap / shutdown)
# ---------------------------------------------------------------------------


class BootstrapError(OperationError):
    """Library bootstrap failed mid-wiring.

    Raised by :func:`mgf.common.bootstrap` when one of the wiring
    steps (identity / logging / OTel / excepthooks / crash sinks)
    raises. Bootstrap is **transactional** (closes FEEDBACK design
    ref §14.2): on failure, every wiring step that succeeded so
    far is rolled back, the process state is restored to its
    pre-bootstrap shape, and this exception is raised carrying:

    - ``.failed_step``      — the wiring step that raised
      (e.g., ``"otel"``, ``"crash_sinks"``).
    - ``__cause__``         — the original exception (chained via
      ``raise BootstrapError(...) from cause``).

    Catching ``BootstrapError`` and continuing is almost always
    wrong — the library is uninitialised; subsequent observability
    calls would silently no-op. The right shape is: log to stderr,
    fix the cause, exit with a non-zero code.

    Subclass of :class:`OperationError` so consumer top-level
    handlers that already map ``OperationError`` to an exit code
    (rule EH-04) catch it without code change.
    """

    def __init__(self, failed_step: str, *, cause: BaseException) -> None:
        self.failed_step: str = failed_step
        super().__init__(
            f"bootstrap failed at step {failed_step!r}: {cause}; "
            f"the library is uninitialised. Fix the cause and "
            f"retry mgf.common.bootstrap()."
        )


__all__ = [
    "AppConfigError",
    "BootstrapError",
    "CancellationError",
    "CommandError",
    "ConfigError",
    "EnvironmentError",
    "GuestCommandError",
    "GuestError",
    "GuestUnreachableError",
    "HostEnvironmentError",
    "OperationError",
    "ProviderError",
    "ResourceAlreadyExistsError",
    "ResourceNotFoundError",
    "SchedulerError",
    "SchemaValidationError",
    "VaultError",
]
