"""mgf.common — shared infrastructure for MGF projects.

See: ``docs/public/library_common.md`` (overview),
     ``docs/public/01_lifecycle.md`` (this module's surface).

Three core components today:

  - :mod:`mgf.common.exceptions` — typed exception hierarchy
    (``AppError`` base + 7 category bases + 6 generic concretes).
  - :mod:`mgf.common.config`     — :class:`BaseAppSettings` +
    layered loader (kwargs > env > .env > YAML > defaults) +
    cross-OS path helpers.
  - :mod:`mgf.common.observability` — structured logging
    (JSON / text formatters, multi-sink :func:`setup_logging`),
    crash reporter, sys / threading excepthooks, optional
    OpenTelemetry instrumentation.

Identity is process-wide: call :func:`configure` once at startup
to set the app name + version that every observability function
reads (log paths, env-var prefixes, OTel service name, crash
report ``app`` field).

See ``docs/standards/`` (lands in Phase 4) for the cross-project
engineering standards this package implements, and ``COMMON.md``
(lands in Phase 5) for the extraction plan.
"""

from __future__ import annotations

from mgf.common._errors import add_help_note
from mgf.common._identity import (
    UnconfiguredWarning,
    app_name,
    app_version,
    configure,
)
from mgf.common._lifecycle import (
    AppContext,
    bootstrap,
    current_context,
)
from mgf.common._test_helpers import bootstrap_for_test

__all__ = [
    "AppContext",
    "UnconfiguredWarning",
    "add_help_note",
    "app_name",
    "app_version",
    "bootstrap",
    "bootstrap_for_test",
    "configure",
    "current_context",
]

# Version string for the package itself. Bumped when a release is
# tagged; consumers rarely need to read this — they use
# ``mgf.common.app_version()`` for THEIR own app version, set via
# ``configure(app_version=...)``.
__version__ = "0.13.0"
