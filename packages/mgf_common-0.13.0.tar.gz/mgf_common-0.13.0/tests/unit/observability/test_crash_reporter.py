"""Unit tests for :mod:`mgf.common.observability.crash_reporter`.

The conftest sets the test app name to ``mgftest``; the crash dir
and env-var name therefore use that prefix.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from mgf.common.observability import crash_reporter
from mgf.common.observability.crash_reporter import report_now

_APP = "mgftest"
_SINK_ENV = f"{_APP.upper()}_CRASH_SINK"


@pytest.fixture(autouse=True)
def _isolate_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))
    monkeypatch.delenv(_SINK_ENV, raising=False)


def _trigger() -> BaseException:
    """Helper to produce an exception with a real traceback + cause."""
    try:
        try:
            raise RuntimeError("inner cause")
        except RuntimeError as inner:
            raise ValueError("outer message") from inner
    except ValueError as outer:
        return outer


# ---------------------------------------------------------------------------
# Local write
# ---------------------------------------------------------------------------


def test_report_now_writes_local_file(tmp_path: Path) -> None:
    exc = _trigger()
    path = report_now(exc, source="unit-test")
    assert path != Path("/dev/null")
    assert path.exists()
    assert path.suffix == ".json"


def test_report_contains_documented_fields(tmp_path: Path) -> None:
    exc = _trigger()
    path = report_now(exc, source="unit-test")
    payload = json.loads(path.read_text())

    assert payload["app"] == _APP
    assert payload["source"] == "unit-test"
    assert "timestamp" in payload
    assert "report_id" in payload
    assert "version" in payload

    assert payload["exception"]["type"] == "builtins.ValueError"
    assert "outer message" in payload["exception"]["message"]

    assert payload["cause"] is not None
    assert payload["cause"]["type"] == "builtins.RuntimeError"
    assert "inner cause" in payload["cause"]["message"]

    assert isinstance(payload["traceback"], list)
    assert any("ValueError" in line for line in payload["traceback"])

    assert "python" in payload["platform"]
    assert "system" in payload["platform"]


def test_report_filename_is_filesystem_portable(tmp_path: Path) -> None:
    exc = _trigger()
    path = report_now(exc, source="x")
    # No colons in the filename (Windows-portable).
    assert ":" not in path.name


def test_report_file_mode_is_0o600(tmp_path: Path) -> None:
    exc = _trigger()
    path = report_now(exc, source="x")
    mode = path.stat().st_mode & 0o777
    assert mode == 0o600


# ---------------------------------------------------------------------------
# Atomic write
# ---------------------------------------------------------------------------


def test_no_tmp_files_left_behind_on_success(tmp_path: Path) -> None:
    exc = _trigger()
    report_now(exc, source="x")
    crash_dir = tmp_path / "state" / _APP / "crashes"
    leftover_tmp = list(crash_dir.glob("*.tmp"))
    assert leftover_tmp == []


# ---------------------------------------------------------------------------
# Never raises
# ---------------------------------------------------------------------------


def test_report_never_raises_when_state_dir_unwritable(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # Replace the helper with one that returns a path inside a file
    # (so mkdir fails). report_now must still return without raising.
    a_file = tmp_path / "blocker"
    a_file.write_text("x")
    monkeypatch.setattr(crash_reporter, "_crash_dir", lambda: a_file / "subdir")
    exc = _trigger()
    path = report_now(exc, source="x")
    assert path == Path("/dev/null")  # sentinel — local write failed


# ---------------------------------------------------------------------------
# Remote shipping (HTTP)
# ---------------------------------------------------------------------------


def test_remote_http_sink_called_when_url_set(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    posted: list[bytes] = []

    class _FakeResp:
        def __enter__(self) -> _FakeResp:
            return self

        def __exit__(self, *args: object) -> None:
            return None

    def fake_urlopen(req: object, timeout: float) -> _FakeResp:
        posted.append(req.data)  # type: ignore[attr-defined]
        return _FakeResp()

    monkeypatch.setenv(_SINK_ENV, "https://example.invalid/hook")
    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

    exc = _trigger()
    report_now(exc, source="x")
    assert posted, "HTTP sink was not invoked"
    assert b"outer message" in posted[0]


def test_unknown_sink_logs_warning_and_does_not_raise(
    monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
) -> None:
    monkeypatch.setenv(_SINK_ENV, "weird-sink-name")
    exc = _trigger()
    with caplog.at_level("WARNING"):
        path = report_now(exc, source="x")
    assert path != Path("/dev/null")  # local still succeeded
    assert any("unknown crash sink" in rec.message for rec in caplog.records)
