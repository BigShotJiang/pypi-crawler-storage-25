"""User-perspective tests for ``mgf.common.exceptions``.

Surfaces exercised:
  - The seven category bases (``ConfigError`` / ``OperationError`` /
    ``ProviderError`` / ``GuestError`` / ``HostEnvironmentError`` /
    ``VaultError`` / ``SchedulerError``)
  - The seven generic concretes
    (``SchemaValidationError`` / ``AppConfigError`` /
    ``CommandError`` / ``ResourceNotFoundError`` /
    ``ResourceAlreadyExistsError`` / ``GuestUnreachableError`` /
    ``GuestCommandError``)
  - ``BootstrapError`` (carries .failed_step)
  - ``CancellationError`` (catchable as ``OperationError``)
  - Subclassing pattern for project-specific exceptions
"""

from __future__ import annotations

import pytest

from mgf.common.exceptions import (
    AppError,
    BootstrapError,
    CancellationError,
    CommandError,
    HostEnvironmentError,
    OperationError,
    ProviderError,
    ResourceAlreadyExistsError,
    ResourceNotFoundError,
    SchemaValidationError,
)


class TestHierarchy:
    def test_every_concrete_subclasses_apperror(self) -> None:
        for cls in (
            CommandError, ResourceNotFoundError,
            ResourceAlreadyExistsError, SchemaValidationError,
            BootstrapError, CancellationError, HostEnvironmentError,
        ):
            assert issubclass(cls, AppError), f"{cls.__name__} is not AppError"

    def test_cancellation_caught_as_operation_error(self) -> None:
        """Existing ``except OperationError:`` clauses catch
        ``CancellationError`` without code change."""
        try:
            raise CancellationError
        except OperationError:
            return  # caught — contract holds
        raise AssertionError("CancellationError not caught as OperationError")

    def test_resource_not_found_error_carries_name(self) -> None:
        err = ResourceNotFoundError("vm-42")
        assert err.name == "vm-42"
        assert "vm-42" in str(err)

    def test_resource_already_exists_carries_name(self) -> None:
        err = ResourceAlreadyExistsError("vm-42")
        assert err.name == "vm-42"

    def test_command_error_carries_argv_and_returncode(self) -> None:
        err = CommandError(argv=["ls", "/nope"], returncode=2, stderr="not found")
        assert err.argv == ["ls", "/nope"]
        assert err.returncode == 2
        assert err.stderr == "not found"

    def test_schema_validation_error_carries_errors(self) -> None:
        err = SchemaValidationError(["field 'x' is required", "field 'y' must be int"])
        assert err.errors == ["field 'x' is required", "field 'y' must be int"]
        assert "validation failed" in str(err)


class TestSubclassing:
    """The canonical pattern from PUBLIC_API.md / examples."""

    def test_subclass_a_concrete(self) -> None:
        class DomainNotFoundError(ResourceNotFoundError):
            def __init__(self, name: str) -> None:
                super().__init__(name)
                # Override the message format with project flavour.
                self.args = (f"no domain named {name!r}; run 'myapp list'",)

        err = DomainNotFoundError("corp-net")
        assert err.name == "corp-net"
        assert "myapp list" in str(err)
        # Still catchable via the generic concrete:
        try:
            raise err
        except ResourceNotFoundError:
            pass
        # AND via the category base:
        try:
            raise err
        except ProviderError:
            pass

    def test_subclass_a_category(self) -> None:
        class MyAppError(AppError):
            """Project-wide nominal alias."""

        err = MyAppError("anything")
        assert isinstance(err, AppError)


class TestBootstrapError:
    def test_carries_failed_step(self) -> None:
        """BootstrapError exposes the failed step + composes the
        cause's message into its own message. Note: the library
        does NOT chain via ``__cause__`` — the cause is text-only.
        Worth a follow-up if consumers want PEP-3134 chaining."""
        cause = ValueError("inner reason")
        err = BootstrapError("logging", cause=cause)
        assert err.failed_step == "logging"
        # Cause's message text is composed into the error message.
        assert "inner reason" in str(err)
        assert "logging" in str(err)


class TestRaiseAndCatch:
    """End-to-end: raise + catch + inspect a typed exception."""

    def test_user_can_catch_apperror_root(self) -> None:
        with pytest.raises(AppError):
            raise CommandError(argv=["false"], returncode=1, stderr="")
