"""CLI entry point."""

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

import typer
from dotenv import load_dotenv
from rich.console import Console

from seaf_helper_tools.commands.assessment_xls2yaml import app as xls2yaml_app
from seaf_helper_tools.commands.assessment_yaml2xls import app as yaml2xls_app
from seaf_helper_tools.mcp.server import app as mcp_server_app

app = typer.Typer(help="helper-commands — инструменты для работы с данными оценок")
console = Console()


def _setup_file_logging() -> None:
    log_dir = Path.cwd() / "temp" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(
        log_dir / "seaf-helper-tools.log",
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.addHandler(handler)


@app.callback()
def main(
    env_file: Path = typer.Option(
        Path(".env"),
        "--env-file",
        help="Путь к .env файлу (по умолчанию .env в текущей директории)",
    ),
) -> None:
    """helper-commands — инструменты для работы с данными оценок."""
    _setup_file_logging()
    if env_file.exists():
        load_dotenv(env_file)
    elif env_file != Path(".env"):
        console.print(f"[yellow]Warning: .env файл не найден: {env_file}[/yellow]")


app.add_typer(yaml2xls_app)
app.add_typer(xls2yaml_app)
app.add_typer(mcp_server_app, name="mcp-server")

if __name__ == "__main__":
    app()
