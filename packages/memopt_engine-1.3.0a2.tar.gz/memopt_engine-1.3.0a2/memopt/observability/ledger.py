"""
Optimization ledger — records per-batch energy, cost, and CO₂ savings.

Every figure is derived from real measurements or explicit environment
variables. Nothing is hardcoded.

Energy model:
  energy_saved_kwh = tokens × (baseline_j_per_token - actual_j_per_token)
                     / 3_600_000

CO₂ model:
  co2_saved_kg = energy_saved_kwh × grid_intensity_kg_per_kwh

Cost model:
  cost_saved_usd = energy_saved_kwh × electricity_price_usd_per_kwh
                 + gpu_hours_saved × gpu_price_usd_per_hr

Environment variables (all have documented defaults):
  MEMOPT_BASELINE_J_PER_TOKEN    float  default: 0.001 J/token (A100 typical)
  MEMOPT_GRID_INTENSITY_KG_KWH   float  default: 0.233 (EU average 2024,
                                         source: IEA Electricity 2024)
  MEMOPT_ELECTRICITY_PRICE_USD   float  default: 0.12 USD/kWh (EU average)
  MEMOPT_GPU_PRICE_USD_HR        float  default: 2.00 USD/hr (A100 on-demand)
  MEMOPT_LEDGER_DB_PATH          str    default: ~/.memopt/ledger.db
  MEMOPT_SIGNING_KEY             str    required for certificate signing,
                                         optional for ledger-only use
"""
from __future__ import annotations
import os
import time
import json
import hashlib
import sqlite3
import logging
import threading
from dataclasses import dataclass, asdict
from typing import Optional, List

_ADMIN_TENANT = "_admin"

logger = logging.getLogger(__name__)

# Environment-configurable defaults — all documented above
_BASELINE_J_PER_TOKEN  = float(os.environ.get(
    "MEMOPT_BASELINE_J_PER_TOKEN", "0.001"
))
_GRID_INTENSITY        = float(os.environ.get(
    "MEMOPT_GRID_INTENSITY_KG_KWH", "0.233"
))
_ELECTRICITY_PRICE     = float(os.environ.get(
    "MEMOPT_ELECTRICITY_PRICE_USD", "0.12"
))
_GPU_PRICE_HR          = float(os.environ.get(
    "MEMOPT_GPU_PRICE_USD_HR", "2.00"
))
_LEDGER_DB_PATH        = os.path.expanduser(
    os.environ.get("MEMOPT_LEDGER_DB_PATH", "~/.memopt/ledger.db")
)

FLUSH_INTERVAL_S = float(os.environ.get("MEMOPT_LEDGER_FLUSH_S",    "60.0"))
FLUSH_BATCH_SIZE  = int(os.environ.get("MEMOPT_LEDGER_BATCH_SIZE", "100"))


@dataclass
class LedgerEntry:
    """
    One batch's optimization record.

    All energy and cost fields are computed from real measurements.
    If a measurement is unavailable (no PowerSampler, no CUDA),
    the field is None — never a made-up number.
    """
    batch_id:             str
    timestamp:            float
    node_id:              str
    tenant_id:            str             # tenant that generated this batch
    tokens_generated:     int

    # Raw measurements
    actual_j_per_token:   Optional[float]  # from PowerSampler
    baseline_j_per_token: float            # from env or measured baseline
    gkd_hit_rate_pct:     Optional[float]  # from GKDStore.stats()
    speedup_ratio:        Optional[float]  # from kernel_hooks.stats()
    hbm_saved_bytes:      Optional[float]  # from VMM.stats()

    # Derived savings (None if input measurements unavailable)
    energy_saved_kwh:     Optional[float]
    co2_saved_kg:         Optional[float]
    cost_saved_usd:       Optional[float]

    # Grid parameters used (for auditability)
    grid_intensity_used:  float
    electricity_price_used: float
    gpu_price_hr_used:    float

    # Measurement provenance
    energy_source:        str = "unmeasured"  # nvml_measured | estimated | unmeasured


def _compute_savings(
    tokens:              int,
    actual_j_per_token:  Optional[float],
    baseline_j_per_token: float,
    gkd_hit_rate_pct:    Optional[float],
) -> dict:
    """
    Compute energy, CO₂, and cost savings from measured inputs.

    Returns a dict with energy_saved_kwh, co2_saved_kg, cost_saved_usd.
    Any field is None if the required measurement is unavailable.
    """
    energy_saved_kwh = None
    co2_saved_kg     = None
    cost_saved_usd   = None

    if actual_j_per_token is not None and tokens > 0:
        j_saved = tokens * (baseline_j_per_token - actual_j_per_token)
        if j_saved > 0:
            energy_saved_kwh = j_saved / 3_600_000
            co2_saved_kg     = energy_saved_kwh * _GRID_INTENSITY
            cost_saved_usd   = energy_saved_kwh * _ELECTRICITY_PRICE

    # GKD savings — tokens × hit_rate means that fraction of KV compute
    # was skipped. Each skipped KV compute saves approximately
    # baseline_j_per_token worth of GPU work.
    if gkd_hit_rate_pct is not None and tokens > 0:
        compute_saved_tokens = tokens * (gkd_hit_rate_pct / 100.0)
        j_from_gkd = compute_saved_tokens * baseline_j_per_token
        kwh_from_gkd = j_from_gkd / 3_600_000
        if energy_saved_kwh is None:
            energy_saved_kwh = kwh_from_gkd
            co2_saved_kg     = kwh_from_gkd * _GRID_INTENSITY
            cost_saved_usd   = kwh_from_gkd * _ELECTRICITY_PRICE
        else:
            energy_saved_kwh += kwh_from_gkd
            co2_saved_kg     += kwh_from_gkd * _GRID_INTENSITY
            cost_saved_usd   += kwh_from_gkd * _ELECTRICITY_PRICE

    return {
        "energy_saved_kwh": round(energy_saved_kwh, 12)
                             if energy_saved_kwh is not None else None,
        "co2_saved_kg":     round(co2_saved_kg, 12)
                             if co2_saved_kg is not None else None,
        "cost_saved_usd":   round(cost_saved_usd, 9)
                             if cost_saved_usd is not None else None,
    }


def _compute_entry_hash(entry_data: dict, prev_hash: Optional[str]) -> str:
    """
    Compute SHA-256 of this entry's canonical JSON + previous hash.
    Forms a tamper-evident chain: modifying any past entry invalidates
    all subsequent hashes from that point forward.
    """
    chain_input = {
        "prev_hash":  prev_hash or "genesis",
        "batch_id":   entry_data["batch_id"],
        "timestamp":  entry_data["timestamp"],
        "node_id":    entry_data["node_id"],
        "tenant_id":  entry_data.get("tenant_id", "_default"),
        "tokens":     entry_data["tokens_generated"],
        "energy_kwh": entry_data.get("energy_saved_kwh"),
        "co2_kg":     entry_data.get("co2_saved_kg"),
        "cost_usd":   entry_data.get("cost_saved_usd"),
    }
    canonical = json.dumps(chain_input, sort_keys=True,
                           separators=(",", ":")).encode()
    return hashlib.sha256(canonical).hexdigest()


def _get_latest_hash(conn) -> Optional[str]:
    """Return the entry_hash of the most recent entry, or None."""
    row = conn.execute(
        "SELECT entry_hash FROM entries ORDER BY timestamp DESC LIMIT 1"
    ).fetchone()
    return row[0] if row else None


class _WriteBuffer:
    """
    Batches LedgerEntry objects and flushes them to SQLite in one
    transaction either when FLUSH_BATCH_SIZE entries accumulate or
    FLUSH_INTERVAL_S seconds have elapsed — whichever comes first.

    This reduces SQLite write frequency from one transaction per
    token-batch (potentially thousands/second) to at most one
    transaction per 60 s under steady-state load.

    Thread-safe: all mutations hold self._lock.
    The flush loop runs in a daemon thread started by start().
    """

    def __init__(self, write_fn, flush_interval: float, flush_batch_size: int):
        self._write_fn         = write_fn        # OptimizationLedger._write
        self._flush_interval   = flush_interval
        self._flush_batch_size = flush_batch_size
        self._lock             = threading.Lock()
        self._pending: list    = []
        self._stop_event       = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        """Start the background flush loop. Safe to call once."""
        self._thread = threading.Thread(
            target=self._flush_loop, daemon=True, name="ledger-flush"
        )
        self._thread.start()

    def append(self, entry) -> None:
        """
        Enqueue an entry. Flushes immediately if batch size reached.
        Never raises.
        """
        flush_now = False
        with self._lock:
            self._pending.append(entry)
            if len(self._pending) >= self._flush_batch_size:
                flush_now = True
        if flush_now:
            self._flush()

    def shutdown(self) -> None:
        """Flush remaining entries and stop the background thread."""
        self._stop_event.set()
        self._flush()   # drain whatever is left

    def pending_count(self) -> int:
        """Return how many entries are buffered but not yet written."""
        with self._lock:
            return len(self._pending)

    def _flush(self) -> None:
        """Write all pending entries to SQLite. Never raises."""
        with self._lock:
            batch, self._pending = self._pending, []
        for entry in batch:
            try:
                self._write_fn(entry)
            except Exception as e:
                logger.debug(f"Ledger buffer flush error: {e}")

    def _flush_loop(self) -> None:
        """Background thread: flush every FLUSH_INTERVAL_S seconds."""
        while not self._stop_event.wait(timeout=self._flush_interval):
            self._flush()


class OptimizationLedger:
    """
    Appends LedgerEntry records to a SQLite database.
    Thread-safe. Gracefully handles SQLite errors without crashing.

    Usage:
        ledger = OptimizationLedger()
        entry  = ledger.record(
            tokens=1024,
            actual_j_per_token=0.00045,
            gkd_hit_rate_pct=90.0,
            speedup_ratio=5.18,
            hbm_saved_bytes=177e9,
            node_id="rack1-node-a",
        )
        recent = ledger.recent(n=10)
        totals = ledger.totals()
    """

    def __init__(self, db_path: str = _LEDGER_DB_PATH):
        self._db_path = db_path
        self._lock    = threading.RLock()
        self._batch_counter = 0
        self._init_db()
        self._buffer = _WriteBuffer(
            write_fn=self._write,
            flush_interval=FLUSH_INTERVAL_S,
            flush_batch_size=FLUSH_BATCH_SIZE,
        )
        self._buffer.start()

    def _init_db(self) -> None:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(self._db_path)), exist_ok=True)
            with self._connect() as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS entries (
                        batch_id              TEXT PRIMARY KEY,
                        timestamp             REAL NOT NULL,
                        node_id               TEXT NOT NULL,
                        tenant_id             TEXT NOT NULL DEFAULT '_default',
                        tokens_generated      INTEGER NOT NULL,
                        actual_j_per_token    REAL,
                        baseline_j_per_token  REAL NOT NULL,
                        gkd_hit_rate_pct      REAL,
                        speedup_ratio         REAL,
                        hbm_saved_bytes       REAL,
                        energy_saved_kwh      REAL,
                        co2_saved_kg          REAL,
                        cost_saved_usd        REAL,
                        grid_intensity_used   REAL NOT NULL,
                        electricity_price_used REAL NOT NULL,
                        gpu_price_hr_used     REAL NOT NULL,
                        prev_hash             TEXT,
                        entry_hash            TEXT NOT NULL,
                        raw_json              TEXT NOT NULL
                    )
                """)
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_timestamp "
                    "ON entries(timestamp)"
                )
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_tenant "
                    "ON entries(tenant_id)"
                )
                # Migration: add energy_source column if not present
                try:
                    conn.execute(
                        "ALTER TABLE entries ADD COLUMN "
                        "energy_source TEXT DEFAULT 'unmeasured'"
                    )
                except sqlite3.OperationalError:
                    pass  # column already exists
        except Exception as e:
            logger.warning(f"Ledger DB init failed: {e} — ledger disabled")

    def _connect(self):
        conn = sqlite3.connect(
            self._db_path, timeout=5.0,
            isolation_level=None   # autocommit
        )
        # AUDIT P1: WAL mode enables concurrent readers + one writer without
        # blocking; critical for append-only ledger under multi-tenant load.
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _has_disk_space(self) -> bool:
        """Check free disk space before writing. Returns True if ok."""
        try:
            import shutil
            min_mb = float(os.environ.get(
                'MEMOPT_LEDGER_MIN_FREE_MB', '500'))
            db_dir = os.path.dirname(
                os.path.abspath(self._db_path))
            free_mb = shutil.disk_usage(db_dir).free / (1024 * 1024)
            if free_mb < min_mb:
                logger.warning(
                    f"Ledger: low disk ({free_mb:.0f}MB free). "
                    f"Skipping write.")
                self._entries_skipped = \
                    getattr(self, '_entries_skipped', 0) + 1
                return False
            return True
        except Exception:
            return True  # assume ok on error

    def record(
        self,
        tokens:              int,
        node_id:             str             = "local",
        tenant_id:           str             = "_default",
        actual_j_per_token:  Optional[float] = None,
        gkd_hit_rate_pct:    Optional[float] = None,
        speedup_ratio:       Optional[float] = None,
        hbm_saved_bytes:     Optional[float] = None,
        baseline_j_per_token: float          = _BASELINE_J_PER_TOKEN,
        energy_source:       str             = "unmeasured",
    ) -> LedgerEntry:
        """
        Record one batch and compute its savings.
        Returns the LedgerEntry regardless of whether DB write succeeds.
        Skips write if disk space is below MEMOPT_LEDGER_MIN_FREE_MB.
        """
        if not self._has_disk_space():
            # Return a minimal entry without writing to DB
            return LedgerEntry(
                batch_id=f"skipped_{int(time.time())}",
                timestamp=time.time(),
                node_id=node_id,
                tenant_id=tenant_id,
                tokens_generated=tokens,
                actual_j_per_token=actual_j_per_token,
                baseline_j_per_token=baseline_j_per_token,
                gkd_hit_rate_pct=gkd_hit_rate_pct,
                speedup_ratio=speedup_ratio,
                hbm_saved_bytes=hbm_saved_bytes,
                energy_saved_kwh=None,
                co2_saved_kg=None,
                cost_saved_usd=None,
                grid_intensity_used=_GRID_INTENSITY,
                electricity_price_used=_ELECTRICITY_PRICE,
                gpu_price_hr_used=_GPU_PRICE_HR,
            )

        with self._lock:
            self._batch_counter += 1
            batch_id = f"{int(time.time())}_{self._batch_counter}"

        savings = _compute_savings(
            tokens=tokens,
            actual_j_per_token=actual_j_per_token,
            baseline_j_per_token=baseline_j_per_token,
            gkd_hit_rate_pct=gkd_hit_rate_pct,
        )

        # Determine energy_source if not explicitly set
        if energy_source == "unmeasured" and actual_j_per_token is not None:
            energy_source = "nvml_measured"
        elif energy_source == "unmeasured" and gkd_hit_rate_pct is not None:
            energy_source = "estimated"

        entry = LedgerEntry(
            batch_id=batch_id,
            timestamp=time.time(),
            node_id=node_id,
            tenant_id=tenant_id,
            tokens_generated=tokens,
            actual_j_per_token=actual_j_per_token,
            baseline_j_per_token=baseline_j_per_token,
            gkd_hit_rate_pct=gkd_hit_rate_pct,
            speedup_ratio=speedup_ratio,
            hbm_saved_bytes=hbm_saved_bytes,
            energy_saved_kwh=savings["energy_saved_kwh"],
            co2_saved_kg=savings["co2_saved_kg"],
            cost_saved_usd=savings["cost_saved_usd"],
            energy_source=energy_source,
            grid_intensity_used=_GRID_INTENSITY,
            electricity_price_used=_ELECTRICITY_PRICE,
            gpu_price_hr_used=_GPU_PRICE_HR,
        )

        self._buffer.append(entry)
        return entry

    def _write(self, entry: LedgerEntry) -> None:
        try:
            with self._lock:
                with self._connect() as conn:
                    d = asdict(entry)
                    prev_hash  = _get_latest_hash(conn)
                    entry_hash = _compute_entry_hash(d, prev_hash)
                    conn.execute("""
                        INSERT INTO entries (
                            batch_id, timestamp, node_id, tenant_id,
                            tokens_generated,
                            actual_j_per_token, baseline_j_per_token,
                            gkd_hit_rate_pct, speedup_ratio,
                            hbm_saved_bytes,
                            energy_saved_kwh, co2_saved_kg,
                            cost_saved_usd,
                            grid_intensity_used,
                            electricity_price_used,
                            gpu_price_hr_used,
                            prev_hash, entry_hash,
                            raw_json,
                            energy_source
                        ) VALUES (
                            :batch_id, :timestamp, :node_id, :tenant_id,
                            :tokens_generated,
                            :actual_j_per_token, :baseline_j_per_token,
                            :gkd_hit_rate_pct, :speedup_ratio,
                            :hbm_saved_bytes,
                            :energy_saved_kwh, :co2_saved_kg,
                            :cost_saved_usd,
                            :grid_intensity_used,
                            :electricity_price_used,
                            :gpu_price_hr_used,
                            :prev_hash, :entry_hash,
                            :raw_json,
                            :energy_source
                        )
                    """, {
                        **d,
                        "prev_hash":  prev_hash,
                        "entry_hash": entry_hash,
                        "raw_json":   json.dumps(d),
                        "energy_source": d.get("energy_source", "unmeasured"),
                    })
        except sqlite3.IntegrityError:
            logger.debug(f"Ledger write rejected duplicate batch_id: {entry.batch_id}")
        except Exception as e:
            logger.debug(f"Ledger write failed: {e}")

    def flush(self) -> None:
        """Write all buffered entries to SQLite immediately.
        Use this in tests or when you need entries visible to verify_chain()
        before shutdown.
        """
        self._buffer._flush()

    def shutdown(self) -> None:
        """Flush the write buffer and stop the background flush thread.
        Call at server shutdown to ensure no buffered entries are lost.
        """
        self._buffer.shutdown()

    def pending_count(self) -> int:
        """Return how many entries are buffered but not yet written to SQLite."""
        return self._buffer.pending_count()

    def size_bytes(self) -> int:
        """Return the size of the ledger database file in bytes. 0 on error."""
        try:
            return os.path.getsize(self._db_path)
        except Exception:
            return 0

    def recent(self, n: int = 100, tenant_id: Optional[str] = None) -> List[dict]:
        """Return the n most recent ledger entries as dicts.

        Note: entries buffered but not yet flushed will not appear here.
        If tenant_id is provided, returns only entries for that tenant.
        """
        try:
            with self._connect() as conn:
                if tenant_id is not None:
                    rows = conn.execute(
                        "SELECT raw_json FROM entries "
                        "WHERE tenant_id = ? "
                        "ORDER BY timestamp DESC LIMIT ?",
                        (tenant_id, n),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT raw_json FROM entries "
                        "ORDER BY timestamp DESC LIMIT ?", (n,)
                    ).fetchall()
            return [json.loads(r[0]) for r in rows]
        except Exception as e:
            logger.debug(f"Ledger read failed: {e}")
            return []

    def totals(self, tenant_id: Optional[str] = None) -> dict:
        """
        Aggregate totals across all ledger entries.
        Returns sums of tokens, energy, CO₂, and cost saved.
        Fields are None if no entries with that measurement exist.

        Note: entries buffered but not yet flushed will not appear here.
        If tenant_id is provided, aggregates only that tenant's entries.
        """
        try:
            with self._connect() as conn:
                if tenant_id is not None:
                    row = conn.execute("""
                        SELECT
                            COUNT(*)                    AS n_batches,
                            SUM(tokens_generated)       AS tokens_total,
                            SUM(energy_saved_kwh)       AS energy_kwh,
                            SUM(co2_saved_kg)           AS co2_kg,
                            SUM(cost_saved_usd)         AS cost_usd,
                            SUM(hbm_saved_bytes)        AS hbm_bytes,
                            AVG(gkd_hit_rate_pct)       AS avg_gkd_hit_rate,
                            AVG(speedup_ratio)          AS avg_speedup
                        FROM entries
                        WHERE tenant_id = ?
                    """, (tenant_id,)).fetchone()
                else:
                    row = conn.execute("""
                        SELECT
                            COUNT(*)                    AS n_batches,
                            SUM(tokens_generated)       AS tokens_total,
                            SUM(energy_saved_kwh)       AS energy_kwh,
                            SUM(co2_saved_kg)           AS co2_kg,
                            SUM(cost_saved_usd)         AS cost_usd,
                            SUM(hbm_saved_bytes)        AS hbm_bytes,
                            AVG(gkd_hit_rate_pct)       AS avg_gkd_hit_rate,
                            AVG(speedup_ratio)          AS avg_speedup
                        FROM entries
                    """).fetchone()
            if row is None:
                return {}
            keys = ["n_batches", "tokens_total", "energy_saved_kwh",
                    "co2_saved_kg", "cost_saved_usd", "hbm_saved_bytes",
                    "avg_gkd_hit_rate_pct", "avg_speedup_ratio"]
            result = {k: v for k, v in zip(keys, row)}

            # Energy source breakdown
            try:
                if tenant_id is not None:
                    es_rows = conn.execute(
                        "SELECT energy_source, COUNT(*) FROM entries "
                        "WHERE tenant_id = ? GROUP BY energy_source",
                        (tenant_id,)).fetchall()
                else:
                    es_rows = conn.execute(
                        "SELECT energy_source, COUNT(*) FROM entries "
                        "GROUP BY energy_source").fetchall()
                breakdown = {"nvml_measured": 0, "estimated": 0, "unmeasured": 0}
                for src, cnt in es_rows:
                    key_name = src or "unmeasured"
                    if key_name in breakdown:
                        breakdown[key_name] = cnt
                    else:
                        breakdown["unmeasured"] += cnt
                result["energy_source_breakdown"] = breakdown
            except Exception:
                result["energy_source_breakdown"] = {
                    "nvml_measured": 0, "estimated": 0, "unmeasured": 0}

            return result
        except Exception as e:
            logger.debug(f"Ledger totals failed: {e}")
            return {}

    def verify_and_certify(self,
                           tenant_id: Optional[str] = None) -> dict:
        """
        Verify the hash chain for tenant_id and return a signed
        certificate of chain integrity.

        This is the auditor-facing method: one call produces a
        document that proves the ledger has not been tampered with.

        Returns a dict with:
            tenant_id:        str
            chain_valid:      bool
            entries_checked:  int
            first_bad_batch:  str | None
            issued_at:        float
            signature:        str | None
            signature_status: str  "signed" | "unsigned"

        Never raises — errors are captured in the result.
        """
        try:
            result = self.verify_chain(tenant_id=tenant_id)
        except Exception as exc:
            result = {
                "ok":             False,
                "entries_checked": 0,
                "reason":         str(exc),
            }

        payload = {
            "tenant_id":       tenant_id or "_all",
            "chain_valid":     result.get("ok", False),
            "entries_checked": result.get("entries_checked", 0),
            "first_bad_batch": result.get("first_bad_batch_id"),
            "issued_at":       time.time(),
        }

        # Sign with existing certificate infrastructure
        try:
            from memopt.observability.certificate import sign_entry
            cert = sign_entry(payload)
            payload["signature"]        = cert.get("signature")
            payload["signature_status"] = cert.get("signature_status", "unsigned")
        except Exception:
            payload["signature"]        = None
            payload["signature_status"] = "unsigned"

        return payload

    def export_csv(
        self,
        tenant_id: str = "",
        start_time: float = 0.0,
        end_time: float = 0.0,
        max_rows: int = 100_000,
    ) -> str:
        """
        Export ledger entries as CSV string. One row per batch.

        energy_source column shows:
          nvml_measured - real GPU power reading
          estimated     - calculated from hit rate
          unmeasured    - no measurement available

        Never raises. Returns empty CSV on error.
        """
        try:
            import csv
            import io

            rows = self._fetch_rows(
                tenant_id=tenant_id,
                start_time=start_time,
                end_time=end_time,
                max_rows=max_rows)

            output = io.StringIO()
            writer = csv.writer(output)

            writer.writerow([
                "batch_id", "timestamp", "tenant_id",
                "tokens_generated", "actual_j_per_token",
                "energy_source", "energy_saved_kwh",
                "co2_saved_kg", "cost_saved_usd", "entry_hash",
            ])

            for row in rows:
                writer.writerow([
                    row.get("batch_id", ""),
                    row.get("timestamp", ""),
                    row.get("tenant_id", ""),
                    row.get("tokens_generated", 0),
                    row.get("actual_j_per_token", ""),
                    row.get("energy_source", "unmeasured"),
                    row.get("energy_saved_kwh", ""),
                    row.get("co2_saved_kg", ""),
                    row.get("cost_saved_usd", ""),
                    str(row.get("entry_hash", ""))[:16],
                ])

            return output.getvalue()

        except Exception as e:
            logger.debug("CSV export failed: %s", e)
            return ""

    def _fetch_rows(
        self,
        tenant_id: str = "",
        start_time: float = 0.0,
        end_time: float = 0.0,
        max_rows: int = 100_000,
    ) -> List[dict]:
        """Fetch ledger rows with optional filters. Never raises."""
        try:
            query = "SELECT * FROM entries"
            params: list = []
            conditions = []

            if tenant_id:
                conditions.append("tenant_id = ?")
                params.append(tenant_id)
            if start_time > 0:
                conditions.append("timestamp >= ?")
                params.append(start_time)
            if end_time > 0:
                conditions.append("timestamp <= ?")
                params.append(end_time)

            if conditions:
                query += " WHERE " + " AND ".join(conditions)
            query += f" ORDER BY timestamp ASC LIMIT {max_rows}"

            with self._connect() as conn:
                conn.row_factory = sqlite3.Row
                cur = conn.execute(query, params)
                return [dict(r) for r in cur.fetchall()]
        except Exception as e:
            logger.debug("Fetch rows failed: %s", e)
            return []

    def verify_chain(self, tenant_id: Optional[str] = None) -> dict:
        """
        Verify the tamper-evident hash chain.

        Checks two things for every entry:
        1. entry_hash matches recomputed hash from raw_json + prev_hash.
        2. raw_json["tokens_generated"] matches the SQL tokens_generated column
           (detects tampering that updates SQL columns but not raw_json).

        Returns:
            {"ok": True, "entries_checked": N}
            {"ok": False, "entries_checked": N, "first_bad_batch_id": "...",
             "reason": "hash_mismatch" | "column_mismatch"}
        """
        try:
            with self._connect() as conn:
                if tenant_id is not None:
                    rows = conn.execute(
                        "SELECT batch_id, prev_hash, entry_hash, "
                        "tokens_generated, raw_json "
                        "FROM entries "
                        "WHERE tenant_id = ? "
                        "ORDER BY timestamp ASC",
                        (tenant_id,),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT batch_id, prev_hash, entry_hash, "
                        "tokens_generated, raw_json "
                        "FROM entries ORDER BY timestamp ASC"
                    ).fetchall()

            checked = 0
            for batch_id, prev_hash, stored_hash, sql_tokens, raw in rows:
                checked += 1
                entry_data = json.loads(raw)

                # Cross-column consistency: detect SQL-only tampering
                if entry_data.get("tokens_generated") != sql_tokens:
                    return {
                        "ok": False,
                        "entries_checked": checked,
                        "first_bad_batch_id": batch_id,
                        "reason": "column_mismatch",
                    }

                # Hash chain integrity
                expected = _compute_entry_hash(entry_data, prev_hash)
                if expected != stored_hash:
                    return {
                        "ok": False,
                        "entries_checked": checked,
                        "first_bad_batch_id": batch_id,
                        "reason": "hash_mismatch",
                    }

            return {"ok": True, "entries_checked": checked}
        except Exception as e:
            logger.debug(f"Ledger verify_chain failed: {e}")
            return {"ok": False, "entries_checked": 0, "reason": str(e)}


# ═══════════════════════════════════════════════════════════════════════════
# Carbon calculator
# ═══════════════════════════════════════════════════════════════════════════

class CarbonCalculator:
    """
    Calculates CO2 avoided from energy savings.

    Uses regional grid intensity factors.

    HONEST: These are estimates based on average grid carbon intensity.
    They are NOT certified carbon credits, regulatory compliance instruments,
    or audited environmental claims. They ARE reasonable estimates for
    reporting, directionally correct, and configurable per deployment region.

    Grid intensity sources:
      EU average:  0.233 kg/kWh (IEA 2024)
      US average:  0.380 kg/kWh (EPA 2024)
      China:       0.581 kg/kWh (IEA 2024)
      UK:          0.148 kg/kWh (National Grid 2024)
      France:      0.052 kg/kWh (RTE 2024, nuclear)
    """

    GRID_INTENSITIES = {
        "eu":     0.233,
        "us":     0.380,
        "china":  0.581,
        "uk":     0.148,
        "france": 0.052,
        "global": 0.475,
    }

    def __init__(self):
        self._region = os.environ.get(
            "MEMOPT_GRID_REGION", "eu").lower()

        env_intensity = os.environ.get("MEMOPT_GRID_INTENSITY_KG_KWH")
        if env_intensity:
            try:
                self._intensity = float(env_intensity)
            except ValueError:
                self._intensity = self.GRID_INTENSITIES.get(
                    self._region, 0.233)
        else:
            self._intensity = self.GRID_INTENSITIES.get(
                self._region, 0.233)

    def kwh_to_co2_kg(self, energy_kwh: float) -> float:
        """Convert kWh saved to kg CO2 avoided. Returns 0.0 for negative energy."""
        if energy_kwh <= 0:
            return 0.0
        return round(energy_kwh * self._intensity, 6)

    def kg_to_tonnes(self, co2_kg: float) -> float:
        return round(co2_kg / 1000, 6)

    def annual_projection(self, daily_kwh_saved: float) -> dict:
        """
        Project annual CO2 savings.

        HONEST: This is a linear projection. Actual savings depend on
        workload staying consistent. We do not guarantee these numbers.
        """
        annual_kwh = daily_kwh_saved * 365
        annual_co2_kg = self.kwh_to_co2_kg(annual_kwh)

        return {
            "annual_kwh_saved": round(annual_kwh, 4),
            "annual_co2_kg": round(annual_co2_kg, 4),
            "annual_co2_tonnes": self.kg_to_tonnes(annual_co2_kg),
            "grid_region": self._region,
            "grid_intensity_kg_kwh": self._intensity,
            "projection_basis": "linear",
            "disclaimer": (
                "Linear projection from daily average. "
                "Not a certified carbon credit."),
        }

    def stats(self) -> dict:
        return {
            "region": self._region,
            "intensity": self._intensity,
            "source": "configured",
            "available_regions": list(self.GRID_INTENSITIES.keys()),
        }
