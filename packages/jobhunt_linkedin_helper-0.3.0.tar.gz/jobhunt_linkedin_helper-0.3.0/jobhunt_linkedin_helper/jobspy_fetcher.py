from __future__ import annotations

import logging
import math
from datetime import date, datetime
from typing import Any, Optional

logger = logging.getLogger("jobhunt.linkedin-helper")

SUPPORTED_PLATFORMS = {"indeed", "glassdoor", "bayt"}


class _JobSpyErrorCapture(logging.Handler):
    def __init__(self) -> None:
        super().__init__(level=logging.ERROR)
        self.errors: list[str] = []

    def emit(self, record: logging.LogRecord) -> None:
        self.errors.append(record.getMessage())


def fetch_jobs(
    *,
    platforms: list[str],
    search_terms: list[str],
    location_preference: str,
    location_city: Optional[str],
    extra_cities: list[str],
    max_results_per_term: int,
    country_indeed: Optional[str] = None,
) -> tuple[list[dict[str, Any]], list[str]]:
    try:
        from jobspy import scrape_jobs  # type: ignore[import]
    except ModuleNotFoundError as exc:
        raise RuntimeError("python-jobspy is not installed. Run: pip install python-jobspy") from exc

    selected = [p for p in platforms if p in SUPPORTED_PLATFORMS]
    if not selected or not search_terms:
        return [], []

    warnings: list[str] = []
    if not country_indeed:
        skipped_for_country = [platform for platform in selected if platform in {"indeed", "glassdoor"}]
        for platform in skipped_for_country:
            warnings.append(
                f"{platform.title()} was skipped because it needs a city with a country, like 'Dubai, United Arab Emirates'."
            )
        selected = [platform for platform in selected if platform not in {"indeed", "glassdoor"}]
        if not selected:
            return [], list(dict.fromkeys(warnings))

    locations = _build_locations(location_preference, location_city, extra_cities)
    safe_limit = max(1, min(int(max_results_per_term), 20))
    all_jobs: list[dict[str, Any]] = []

    for term in search_terms:
        for location in locations:
            for platform in selected:
                kwargs: dict[str, Any] = {
                    "site_name": [platform],
                    "search_term": term,
                    "location": location,
                    "results_wanted": safe_limit,
                    "verbose": 0,
                }
                if location_preference == "remote":
                    kwargs["is_remote"] = True
                if country_indeed and platform in ("indeed", "glassdoor"):
                    kwargs["country_indeed"] = country_indeed

                capture = _JobSpyErrorCapture()
                jobspy_logger = logging.getLogger("JobSpy")
                jobspy_logger.addHandler(capture)
                try:
                    result = scrape_jobs(**kwargs)
                    rows = _rows_from_result(result)
                except Exception as exc:
                    logger.warning("JobSpy %s fetch failed for term %r: %s", platform, term, exc)
                    warnings.append(f"{platform.title()} could not be fetched: {exc}")
                    continue
                finally:
                    jobspy_logger.removeHandler(capture)

                if not rows and capture.errors:
                    msg = capture.errors[0]
                    logger.warning("JobSpy %s blocked/error for term %r: %s", platform, term, msg)
                    if any(tok in msg.lower() for tok in ("403", "forbidden", "blocked", "captcha", "429")):
                        warnings.append(f"{platform.title()} temporarily blocked this machine. Try again later.")
                    else:
                        warnings.append(f"{platform.title()} could not be fetched: {msg}")
                    continue

                for row in rows:
                    job = _normalise_row(row, search_term=term)
                    if job:
                        all_jobs.append(job)

    # Dedupe by jobUrl / id
    seen: set[str] = set()
    deduped: list[dict[str, Any]] = []
    for job in all_jobs:
        key = str(job.get("id") or job.get("jobUrl") or "")
        if key and key in seen:
            continue
        seen.add(key)
        deduped.append(job)

    deduped_warnings = list(dict.fromkeys(warnings))
    return deduped, deduped_warnings


def _build_locations(location_preference: str, location_city: Optional[str], extra_cities: list[str]) -> list[str]:
    if location_preference in ("onsite", "both") and location_city:
        locations = [location_city] + [c for c in extra_cities if c]
        return list(dict.fromkeys(locations))
    return [""]


def _rows_from_result(result: Any) -> list[dict[str, Any]]:
    if result is None:
        return []
    if hasattr(result, "to_dict"):
        try:
            rows = result.to_dict(orient="records")
            if isinstance(rows, list):
                return [r for r in rows if isinstance(r, dict)]
        except Exception:
            pass
    if isinstance(result, list):
        return [r for r in result if isinstance(r, dict)]
    return []


def _pick(row: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in row:
            return row[key]
    return None


def _coerce_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and math.isnan(value):
        return ""
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    text = str(value).strip()
    return "" if text.lower() == "nan" else text


def _row_location(row: dict[str, Any]) -> str:
    loc = _pick(row, "location", "LOCATION")
    if isinstance(loc, dict):
        parts = [_coerce_str(loc.get(k)) for k in ("city", "state", "country")]
        joined = ", ".join(p for p in parts if p)
        if joined:
            return joined
    flat_parts = [_coerce_str(_pick(row, "city")), _coerce_str(_pick(row, "state")), _coerce_str(_pick(row, "country"))]
    joined = ", ".join(p for p in flat_parts if p)
    return joined or _coerce_str(loc)


def _normalise_row(row: dict[str, Any], *, search_term: str) -> dict[str, Any] | None:
    platform = _coerce_str(_pick(row, "site", "SITE")).lower()
    if platform not in SUPPORTED_PLATFORMS:
        return None

    job_url = _coerce_str(_pick(row, "job_url", "JOB_URL"))
    title = _coerce_str(_pick(row, "title", "TITLE"))
    company = _coerce_str(_pick(row, "company", "COMPANY"))
    location = _row_location(row)
    description = _coerce_str(_pick(row, "description", "DESCRIPTION"))
    date_posted = _coerce_str(_pick(row, "date_posted", "DATE_POSTED"))
    raw_id = _coerce_str(_pick(row, "id", "ID")) or job_url or f"{platform}|{title}|{company}"

    remote_val = _pick(row, "is_remote", "IS_REMOTE")
    if remote_val is True or (isinstance(remote_val, str) and remote_val.strip().lower() in {"true", "1", "yes"}):
        work_type = "remote"
    else:
        work_type = _coerce_str(_pick(row, "job_type", "JOB_TYPE"))

    min_amt = _coerce_str(_pick(row, "min_amount"))
    max_amt = _coerce_str(_pick(row, "max_amount"))
    interval = _coerce_str(_pick(row, "interval"))
    currency = _coerce_str(_pick(row, "currency"))
    amount = f"{min_amt}-{max_amt}" if min_amt and max_amt else (min_amt or max_amt)
    salary = " ".join(p for p in [currency, amount, interval] if p)

    return {
        "_platform": platform,
        "_search_term": search_term,
        "id": raw_id,
        "position": title,
        "company": company,
        "location": location,
        "jobUrl": job_url,
        "description": description,
        "workType": work_type,
        "salary": salary,
        "date": date_posted,
    }
