from __future__ import annotations

import argparse
import asyncio
import getpass
import json
import logging
import os
import shutil
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import httpx

from .fetcher import fetch_jobs as fetch_linkedin_jobs
from .jobspy_fetcher import fetch_jobs as fetch_jobspy_jobs

DEFAULT_SERVER_URL = os.environ.get("JOBHUNT_HELPER_DEFAULT_SERVER_URL", "").strip()
DEFAULT_SCRAPER_PORT = 3001
DEFAULT_TOKEN_FILE = Path.home() / ".jobhunt" / "linkedin-local-agent.json"
SCRAPER_BOOT_TIMEOUT_SECONDS = 45.0
HELPER_VERSION = "jobhunt-linkedin-helper/0.3.0"

logger = logging.getLogger("jobhunt.linkedin-helper")


def _configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )


def _package_root() -> Path:
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", "")
        if meipass:
            return Path(meipass) / "jobhunt_linkedin_helper"
    return Path(__file__).resolve().parent


def _scraper_dir() -> Path:
    return _package_root() / "scraper"


def _bundled_binary(name: str) -> Path | None:
    package_binary = _package_root() / "bin" / name
    if package_binary.exists():
        return package_binary
    exe_dir_binary = Path(sys.executable).resolve().parent / "jobhunt_linkedin_helper" / "bin" / name
    if exe_dir_binary.exists():
        return exe_dir_binary
    return None


def _ensure_parent_dir(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def _load_state(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception as exc:
        raise RuntimeError(f"Could not read token file {path}: {exc}") from exc


def _save_state(path: Path, state: dict[str, Any]) -> None:
    _ensure_parent_dir(path)
    path.write_text(json.dumps(state, indent=2))
    os.chmod(path, 0o600)


def _headers(token: str) -> dict[str, str]:
    return {"X-LinkedIn-Agent-Token": token}


def _require_binary(name: str, *, install_hint: str) -> str:
    bundled = _bundled_binary(name)
    if bundled is not None:
        return str(bundled)
    binary = shutil.which(name)
    if binary:
        return binary
    raise SystemExit(f"{name} is required for the local fetch helper. {install_hint}")


def _ensure_scraper_dependencies(scraper_dir: Path) -> None:
    if (scraper_dir / "node_modules").exists():
        return

    npm = _require_binary(
        "npm",
        install_hint="Install Node.js 20+ so the helper can bootstrap its local scraper.",
    )
    logger.info("Installing bundled scraper dependencies...")
    subprocess.run(
        [npm, "install", "--omit=dev", "--no-fund", "--no-audit"],
        cwd=str(scraper_dir),
        check=True,
    )


def _wait_for_scraper(scraper_url: str, *, timeout_seconds: float = SCRAPER_BOOT_TIMEOUT_SECONDS) -> None:
    deadline = time.monotonic() + timeout_seconds
    last_error: str | None = None
    while time.monotonic() < deadline:
        try:
            response = httpx.get(f"{scraper_url.rstrip('/')}/health", timeout=2.0)
            response.raise_for_status()
            return
        except Exception as exc:  # noqa: BLE001
            last_error = str(exc)
            time.sleep(0.5)
    raise SystemExit(f"Bundled scraper did not become healthy at {scraper_url}. Last error: {last_error or 'unknown'}")


def _terminate_process(proc: subprocess.Popen[Any] | None) -> None:
    if proc is None or proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=8)
    except subprocess.TimeoutExpired:
        proc.kill()


def _start_managed_scraper(*, scraper_port: int, skip_bootstrap: bool) -> tuple[subprocess.Popen[Any], str]:
    scraper_dir = _scraper_dir()
    node = _require_binary(
        "node",
        install_hint="Install Node.js 20+ so the helper can run its bundled scraper.",
    )
    if not skip_bootstrap:
        _ensure_scraper_dependencies(scraper_dir)

    env = os.environ.copy()
    env["SCRAPER_PORT"] = str(scraper_port)
    proc = subprocess.Popen(
        [node, "server.js"],
        cwd=str(scraper_dir),
        env=env,
    )
    scraper_url = f"http://127.0.0.1:{scraper_port}"
    try:
        _wait_for_scraper(scraper_url)
    except Exception:
        _terminate_process(proc)
        raise
    return proc, scraper_url


def _pair(
    client: httpx.Client,
    *,
    server_url: str,
    pairing_code: str,
    device_name: str,
    token_file: Path,
) -> dict[str, Any]:
    response = client.post(
        f"{server_url.rstrip('/')}/api/linkedin-local/pair/complete",
        json={
            "pairing_code": pairing_code,
            "device_name": device_name,
            "helper_version": HELPER_VERSION,
        },
    )
    response.raise_for_status()
    payload = response.json()
    state = {
        "server_url": server_url.rstrip("/"),
        "device_token": payload["device_token"],
        "device": payload["device"],
    }
    _save_state(token_file, state)
    logger.info("Paired local fetch helper as %s", payload["device"]["device_name"])
    return state


def _claim_task(client: httpx.Client, *, server_url: str, token: str) -> dict[str, Any] | None:
    response = client.post(
        f"{server_url.rstrip('/')}/api/linkedin-local/tasks/claim",
        headers=_headers(token),
    )
    if response.status_code == 204:
        return None
    response.raise_for_status()
    return response.json()


def _complete_task(
    client: httpx.Client,
    *,
    server_url: str,
    token: str,
    task_id: int,
    raw_jobs: list[dict[str, Any]],
    warnings: list[str],
) -> None:
    response = client.post(
        f"{server_url.rstrip('/')}/api/linkedin-local/tasks/{task_id}/complete",
        headers=_headers(token),
        json={"raw_jobs": raw_jobs, "warnings": warnings},
    )
    response.raise_for_status()


def _fail_task(client: httpx.Client, *, server_url: str, token: str, task_id: int, error: str) -> None:
    response = client.post(
        f"{server_url.rstrip('/')}/api/linkedin-local/tasks/{task_id}/fail",
        headers=_headers(token),
        json={"error": error[:2000]},
    )
    response.raise_for_status()


def _run_linkedin_fetch(task: dict[str, Any], *, scraper_url: str) -> tuple[list[dict[str, Any]], list[str]]:
    return asyncio.run(
        fetch_linkedin_jobs(
            search_terms=[str(term).strip() for term in task.get("search_terms", []) if str(term).strip()],
            location_preference=task.get("location_preference", "both"),
            location_city=task.get("location_city"),
            extra_cities=[str(city).strip() for city in task.get("extra_cities", []) if str(city).strip()],
            max_results_per_term=int(task.get("max_results_per_term", 10)),
            scraper_url=scraper_url,
        )
    )


def _run_jobspy_fetch(task: dict[str, Any]) -> tuple[list[dict[str, Any]], list[str]]:
    return fetch_jobspy_jobs(
        platforms=[str(p).strip() for p in task.get("platforms", []) if str(p).strip()],
        search_terms=[str(term).strip() for term in task.get("search_terms", []) if str(term).strip()],
        location_preference=task.get("location_preference", "both"),
        location_city=task.get("location_city"),
        extra_cities=[str(city).strip() for city in task.get("extra_cities", []) if str(city).strip()],
        max_results_per_term=int(task.get("max_results_per_term", 10)),
        country_indeed=task.get("country_indeed"),
    )


def _default_device_name() -> str:
    return socket.gethostname() or "Local fetch helper"


def _prompt_value(prompt: str, *, default: str = "", secret: bool = False) -> str:
    suffix = f" [{default}]" if default else ""
    while True:
        raw = getpass.getpass(f"{prompt}{suffix}: ") if secret else input(f"{prompt}{suffix}: ")
        value = raw.strip() or default.strip()
        if value:
            return value
        print("This value is required.")


def _can_prompt() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


def _http_error_message(response: httpx.Response | None) -> str:
    if response is None:
        return "Unknown error from JobHunt."

    try:
        payload = response.json()
    except Exception:  # noqa: BLE001
        payload = None

    if isinstance(payload, dict):
        detail = payload.get("detail")
        if isinstance(detail, str) and detail.strip():
            return detail.strip()

    text = response.text.strip()
    if text:
        return text[:400]
    return f"HTTP {response.status_code}"


def _interactive_first_run(
    *,
    server_url: str,
    pairing_code: str,
    device_name: str,
) -> tuple[str, str, str]:
    print("")
    print("JobHunt Helper first-time setup")
    print("Paste the details shown in JobHunt. This only needs to be done once on this computer.")
    print("")
    resolved_server_url = _prompt_value("JobHunt server URL", default=server_url or "https://your-api-domain.com")
    resolved_pairing_code = _prompt_value("Pairing code", default=pairing_code, secret=False)
    resolved_device_name = _prompt_value("Computer name", default=device_name or _default_device_name())
    print("")
    return resolved_server_url, resolved_pairing_code, resolved_device_name


def _pair_or_exit(
    client: httpx.Client,
    *,
    server_url: str,
    pairing_code: str,
    device_name: str,
    token_file: Path,
) -> dict[str, Any]:
    try:
        return _pair(
            client,
            server_url=server_url,
            pairing_code=pairing_code,
            device_name=device_name,
            token_file=token_file,
        )
    except httpx.HTTPStatusError as exc:
        raise SystemExit(f"Could not pair helper: {_http_error_message(exc.response)}") from exc
    except httpx.HTTPError as exc:
        raise SystemExit(f"Could not reach JobHunt while pairing: {exc}") from exc


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the JobHunt local fetch helper. On first launch it asks for a pairing code, then future launches reconnect automatically."
    )
    parser.add_argument("--server-url", default=DEFAULT_SERVER_URL, help="Hosted JobHunt base URL, e.g. https://jobhunt.example.com")
    parser.add_argument("--pairing-code", default="", help="One-time pairing code generated from JobHunt")
    parser.add_argument("--device-name", default=_default_device_name(), help="Human-friendly name shown in JobHunt")
    parser.add_argument("--token-file", default=str(DEFAULT_TOKEN_FILE), help="Where to store the helper token")
    parser.add_argument("--poll-seconds", type=float, default=8.0, help="How often to poll for work when idle")
    parser.add_argument("--once", action="store_true", help="Claim at most one task and exit")
    parser.add_argument("--scraper-port", type=int, default=DEFAULT_SCRAPER_PORT, help="Port used by the helper-managed scraper")
    parser.add_argument("--scraper-url", default="", help="Use an external scraper URL when --no-managed-scraper is set")
    parser.add_argument("--no-managed-scraper", action="store_true", help="Do not start the bundled scraper automatically")
    parser.add_argument("--skip-scraper-bootstrap", action="store_true", help="Skip npm install for the bundled scraper")
    args = parser.parse_args()

    _configure_logging()

    token_file = Path(args.token_file).expanduser()
    managed_scraper: subprocess.Popen[Any] | None = None
    scraper_url = args.scraper_url.strip() or f"http://127.0.0.1:{args.scraper_port}"

    def _shutdown(*_: Any) -> None:
        _terminate_process(managed_scraper)
        raise SystemExit(0)

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    try:
        with httpx.Client(timeout=120.0) as client:
            state = _load_state(token_file)
            requested_server_url = args.server_url.strip()
            requested_pairing_code = args.pairing_code.strip()
            requested_device_name = args.device_name.strip() or _default_device_name()

            if requested_pairing_code:
                state = _pair_or_exit(
                    client,
                    server_url=requested_server_url,
                    pairing_code=requested_pairing_code,
                    device_name=requested_device_name,
                    token_file=token_file,
                )
            elif state is None:
                if not _can_prompt():
                    raise SystemExit(
                        "No saved helper token found. Run the helper from a terminal once so it can ask for your pairing code."
                    )
                prompted_server_url, prompted_pairing_code, prompted_device_name = _interactive_first_run(
                    server_url=requested_server_url,
                    pairing_code=requested_pairing_code,
                    device_name=requested_device_name,
                )
                state = _pair_or_exit(
                    client,
                    server_url=prompted_server_url,
                    pairing_code=prompted_pairing_code,
                    device_name=prompted_device_name,
                    token_file=token_file,
                )

            server_url = str(requested_server_url or (state or {}).get("server_url") or "").rstrip("/")
            token = str((state or {}).get("device_token") or "")
            if not token:
                raise SystemExit("Saved helper token is missing. Re-pair this device.")
            if not server_url:
                raise SystemExit("Saved helper server URL is missing. Re-pair this device.")

            if not args.no_managed_scraper:
                logger.info("Starting bundled LinkedIn scraper...")
                managed_scraper, scraper_url = _start_managed_scraper(
                    scraper_port=args.scraper_port,
                    skip_bootstrap=args.skip_scraper_bootstrap,
                )
            else:
                logger.info("Using external scraper at %s", scraper_url)

            logger.info("Local fetch helper connected to %s", server_url)
            logger.info("LinkedIn scraper available at %s", scraper_url)

            while True:
                try:
                    task = _claim_task(client, server_url=server_url, token=token)
                except httpx.HTTPStatusError as exc:
                    if exc.response is not None and exc.response.status_code in {401, 403}:
                        logger.warning("Saved helper session is no longer valid. Re-pairing is required.")
                        if not _can_prompt():
                            raise SystemExit(
                                "This helper session expired or was revoked. Open the helper again and enter a fresh pairing code."
                            ) from exc
                        print("")
                        print("This helper needs to be paired again before it can keep working.")
                        prompted_server_url, prompted_pairing_code, prompted_device_name = _interactive_first_run(
                            server_url=server_url,
                            pairing_code="",
                            device_name=requested_device_name,
                        )
                        state = _pair_or_exit(
                            client,
                            server_url=prompted_server_url,
                            pairing_code=prompted_pairing_code,
                            device_name=prompted_device_name,
                            token_file=token_file,
                        )
                        server_url = str((state or {}).get("server_url") or prompted_server_url).rstrip("/")
                        token = str((state or {}).get("device_token") or "")
                        continue
                    raise
                if task is None:
                    if args.once:
                        return
                    time.sleep(max(args.poll_seconds, 1.0))
                    continue

                task_id = int(task["task_id"])
                task_type = task.get("task_type", "linkedin")
                logger.info("Claimed %s fetch task %s", task_type, task_id)
                try:
                    if task_type == "jobspy":
                        raw_jobs, warnings = _run_jobspy_fetch(task)
                    else:
                        raw_jobs, warnings = _run_linkedin_fetch(task, scraper_url=scraper_url)
                    _complete_task(
                        client,
                        server_url=server_url,
                        token=token,
                        task_id=task_id,
                        raw_jobs=raw_jobs,
                        warnings=warnings,
                    )
                    logger.info("Completed %s fetch task %s with %s raw jobs", task_type, task_id, len(raw_jobs))
                except KeyboardInterrupt:
                    raise
                except Exception as exc:  # noqa: BLE001
                    message = f"Local fetch helper could not finish the {task_type} fetch: {exc}"
                    logger.exception("Task %s failed locally", task_id)
                    try:
                        _fail_task(client, server_url=server_url, token=token, task_id=task_id, error=message)
                    except Exception:  # noqa: BLE001
                        logger.exception("Could not report failure for task %s back to JobHunt", task_id)

                if args.once:
                    return
    finally:
        _terminate_process(managed_scraper)


if __name__ == "__main__":
    main()
