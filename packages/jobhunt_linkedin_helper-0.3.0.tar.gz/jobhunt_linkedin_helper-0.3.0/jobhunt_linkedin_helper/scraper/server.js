const express = require('express')
const linkedIn = require('linkedin-jobs-api')
const axios = require('axios')
const cheerio = require('cheerio')

const app = express()
app.use(express.json())

const HOST = process.env.SCRAPER_HOST || '127.0.0.1'
const PORT = process.env.SCRAPER_PORT || 3001
const DETAIL_BATCH = Number(process.env.SCRAPER_DETAIL_BATCH || 2)
const DETAIL_DELAY_MS = Number(process.env.SCRAPER_DETAIL_DELAY_MS || 250)

// Reuse axios with a browser-like UA to avoid blocks
const http = axios.create({
  timeout: 15000,
  headers: {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.9',
  },
})

async function fetchDescription(jobUrl) {
  if (!jobUrl) return ''
  try {
    const resp = await http.get(jobUrl)
    const $ = cheerio.load(resp.data)
    // LinkedIn job detail page description selectors (try multiple)
    const text =
      $('.description__text').text().trim() ||
      $('.show-more-less-html__markup').text().trim() ||
      $('[class*="description"]').first().text().trim()
    return text.replace(/\s+/g, ' ').slice(0, 5000)
  } catch {
    return ''
  }
}

app.get('/health', (_, res) => res.json({ ok: true }))

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

function isBlockedError(err) {
  const status = Number(err?.response?.status || err?.statusCode || err?.status || 0)
  const message = String(err?.response?.data?.error || err?.message || '')
  return [403, 429, 999].includes(status) || /captcha|blocked|too many requests|rate limit|unusual traffic|access denied|forbidden/i.test(message)
}

app.post('/search', async (req, res) => {
  const {
    keyword = '',
    location = '',
    remoteFilter = '',
    dateSincePosted = 'past month',
    jobType = 'full time',
    limit = '25',
  } = req.body

  try {
    const results = await linkedIn.query({
      keyword,
      location,
      remoteFilter,
      dateSincePosted,
      jobType,
      limit: String(limit),
      sortBy: 'recent',
    })

    // Fetch descriptions in parallel, max 5 at a time
    for (let i = 0; i < results.length; i += DETAIL_BATCH) {
      const batch = results.slice(i, i + DETAIL_BATCH)
      await Promise.all(
        batch.map(async (job) => {
          job.description = await fetchDescription(job.jobUrl)
        })
      )
      if (i + DETAIL_BATCH < results.length && DETAIL_DELAY_MS > 0) await wait(DETAIL_DELAY_MS)
    }

    res.json({ jobs: results })
  } catch (err) {
    const message = String(err?.response?.data?.error || err?.message || 'Scraper request failed')
    const status = Number(err?.response?.status || err?.statusCode || err?.status || 500)
    const blocked = isBlockedError(err)
    console.error('Scraper error:', message)
    res.status(blocked ? 429 : (status >= 400 && status < 600 ? status : 500)).json({ error: message, blocked, jobs: [] })
  }
})

app.listen(PORT, HOST, () => {
  console.log(`Scraper service running on http://${HOST}:${PORT}`)
})
