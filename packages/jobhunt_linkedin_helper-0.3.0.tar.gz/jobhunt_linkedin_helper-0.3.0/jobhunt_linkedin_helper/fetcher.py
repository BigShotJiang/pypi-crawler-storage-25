from __future__ import annotations

import asyncio
from typing import Optional

import httpx

DEFAULT_MAX_RESULTS_PER_TERM = 20
SAFE_MAX_RESULTS_PER_TERM = 20

REMOTE_FILTER_MAP = {
    "remote": "remote",
    "onsite": "on site",
    "both": "",
}


def _build_locations(location_preference: str, location_city: Optional[str], extra_cities: list[str]) -> list[str]:
    locations: list[str] = []
    if location_preference in ("onsite", "both") and location_city:
        locations.append(location_city)
        locations.extend(city for city in extra_cities if city)
    if not locations:
        return [""]
    return list(dict.fromkeys(locations))


def _looks_blocked(status_code: int | None, message: str) -> bool:
    text = message.lower()
    if status_code in {403, 429, 999}:
        return True
    return any(
        phrase in text
        for phrase in (
            "captcha",
            "temporarily blocked",
            "too many requests",
            "rate limit",
            "unusual traffic",
            "access denied",
            "forbidden",
            "blocked",
        )
    )


async def _fetch_search_batch(
    client: httpx.AsyncClient,
    *,
    scraper_url: str,
    term: str,
    location: str,
    remote_filter: str,
    max_results_per_term: int,
) -> tuple[list[dict], str | None]:
    payload = {
        "keyword": term,
        "location": location,
        "remoteFilter": remote_filter,
        "dateSincePosted": "past month",
        "jobType": "full time",
        "limit": str(max_results_per_term),
    }

    try:
        response = await client.post(f"{scraper_url.rstrip('/')}/search", json=payload)
        response.raise_for_status()
        jobs = response.json().get("jobs", [])
    except httpx.HTTPError as exc:
        body = exc.response.text[:300] if exc.response is not None else str(exc)
        status_code = exc.response.status_code if exc.response is not None else None
        if _looks_blocked(status_code, body):
            return [], "LinkedIn temporarily blocked the helper on this machine. Try again later."
        return [], None
    except Exception as exc:
        if _looks_blocked(None, str(exc)):
            return [], "LinkedIn temporarily blocked the helper on this machine. Try again later."
        return [], None

    for job in jobs:
        job["_platform"] = "linkedin"
        job["_search_term"] = term
    return jobs, None


async def fetch_jobs(
    *,
    search_terms: list[str],
    location_preference: str,
    location_city: Optional[str],
    extra_cities: list[str],
    scraper_url: str,
    max_results_per_term: int = DEFAULT_MAX_RESULTS_PER_TERM,
) -> tuple[list[dict], list[str]]:
    if not search_terms:
        return [], []

    safe_limit = max(1, min(int(max_results_per_term), SAFE_MAX_RESULTS_PER_TERM))
    locations = _build_locations(location_preference, location_city, extra_cities)
    remote_filter = REMOTE_FILTER_MAP.get(location_preference, "")

    warnings: list[str] = []
    all_jobs: list[dict] = []

    async with httpx.AsyncClient(timeout=60.0) as client:
        results = await asyncio.gather(*[
            _fetch_search_batch(
                client,
                scraper_url=scraper_url,
                term=term,
                location=location,
                remote_filter=remote_filter,
                max_results_per_term=safe_limit,
            )
            for term in search_terms
            for location in locations
        ])

    for jobs, warning in results:
        all_jobs.extend(jobs)
        if warning:
            warnings.append(warning)

    return all_jobs, list(dict.fromkeys(warnings))
