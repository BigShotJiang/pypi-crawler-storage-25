# JobHunt Helper

The local companion for hosted [JobHunt](https://github.com/msalmanashraf/jobhunt) deployments.

Keeps IP-sensitive fetching (LinkedIn, Bayt, Indeed, Glassdoor) on the user's own machine instead of the shared server IP.

## Install

Requires [uv](https://docs.astral.sh/uv/getting-started/installation/) — a fast Python installer (no Python needed beforehand).

**macOS / Linux**
```sh
curl -LsSf https://astral.sh/uv/install.sh | sh
uv tool install jobhunt-linkedin-helper
```

**Windows (PowerShell)**
```powershell
powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
uv tool install jobhunt-linkedin-helper
```

## Run

```sh
job-hunt
```

On first launch it will ask for:
- Your JobHunt server URL
- A pairing code (generate one in JobHunt → Settings → Local helper)

After that, future launches reconnect automatically. A new pairing code is only needed if the helper is revoked.

## What it does

- Pairs with your hosted JobHunt server using a short-lived code
- Stores only a revocable device token on disk (`~/.jobhunt/linkedin-local-agent.json`)
- Runs the bundled LinkedIn scraper locally (Node.js required)
- Runs Bayt / Indeed / Glassdoor fetches via JobSpy
- Polls the JobHunt API for tasks and sends results back

## Entrypoints

All three are equivalent:
- `job-hunt`
- `jobhunt-helper`
- `jobhunt-linkedin-helper`

## Advanced usage

```sh
job-hunt --server-url https://jobhunt-api.example.com --pairing-code JHLI-XXXX-XXXX
```

Run `job-hunt --help` for all options.
