"""calcfi-compound-interest — Future value with periodic contributions.

FV (regular contributions, annuity-immediate) = PMT * [(1+r)^n - 1] / r
FV (single principal) = P * (1+r)^n

License: MIT. Author: Jere Salmisto. https://calcfi.app
"""
from typing import Union

__version__ = "0.1.0"
Number = Union[int, float]

def future_value(monthly_contribution: Number, annual_rate: Number, years: Number, initial: Number = 0) -> float:
    """Future value with monthly contributions + optional initial lump sum.

    Args:
        monthly_contribution: Dollars added each month.
        annual_rate: Annual return as decimal (e.g., 0.08 for 8%).
        years: Investment horizon in years.
        initial: Starting principal (default 0).

    Examples:
        >>> round(future_value(500, 0.08, 30), 2)
        745179.97
    """
    r = annual_rate / 12.0
    n = years * 12
    if r == 0:
        return float(initial) + float(monthly_contribution) * n
    fv_contrib = float(monthly_contribution) * ((1 + r) ** n - 1) / r
    fv_initial = float(initial) * (1 + r) ** n
    return fv_initial + fv_contrib

def present_value(target_fv: Number, annual_rate: Number, years: Number) -> float:
    """Present value (lump sum needed today) to reach a target FV."""
    return float(target_fv) / (1 + annual_rate) ** years

def years_to_target(monthly_contribution: Number, annual_rate: Number, target: Number) -> float:
    """How many years of monthly contributions to reach target."""
    import math
    if monthly_contribution <= 0:
        raise ValueError("monthly_contribution must be positive")
    r = annual_rate / 12.0
    if r == 0:
        return target / monthly_contribution / 12
    n = math.log(1 + target * r / monthly_contribution) / math.log(1 + r)
    return n / 12
