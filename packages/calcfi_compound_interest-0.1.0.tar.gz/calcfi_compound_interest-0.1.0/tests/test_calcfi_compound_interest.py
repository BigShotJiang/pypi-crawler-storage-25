from calcfi_compound_interest import future_value, present_value

def test_30yr_500_monthly_at_8():
    assert abs(future_value(500, 0.08, 30) - 745179.97) < 1.0

def test_pv():
    assert abs(present_value(100, 0.08, 10) - 46.32) < 0.5

def test_zero_rate():
    assert future_value(500, 0, 10) == 60_000.0
