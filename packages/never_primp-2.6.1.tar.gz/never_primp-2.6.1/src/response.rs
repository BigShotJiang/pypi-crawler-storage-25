use encoding_rs::{Encoding, UTF_8};
use mime::Mime;
use pyo3::prelude::*;
use pyo3::types::{PyBytes, PyDict, PyString};
use std::sync::Mutex;

use crate::runtime::RUNTIME;

#[pyclass]
pub struct Response {
    inner: Mutex<Option<wreq::Response>>,

    _content: Mutex<Option<Vec<u8>>>,
    _text: Mutex<Option<String>>,
    _encoding: Mutex<Option<String>>,
    _headers: Mutex<Option<Py<PyDict>>>,
    _cookies: Mutex<Option<Py<PyDict>>>,

    #[pyo3(get)]
    pub url: String,

    #[pyo3(get)]
    pub status_code: u16,
}

#[pymethods]
impl Response {
    #[getter]
    fn content<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyBytes>> {
        {
            let cache = self._content.lock().unwrap();
            if let Some(bytes) = &*cache {
                return Ok(PyBytes::new(py, bytes));
            }
        }

        self.ensure_metadata_extracted(py)?;

        let bytes = {
            let mut inner_lock = self.inner.lock().unwrap();
            let response = inner_lock.take()
                .ok_or_else(|| pyo3::exceptions::PyRuntimeError::new_err(
                    "Response body already consumed"
                ))?;

            py.detach(|| {
                RUNTIME.block_on(async {
                    response.bytes().await
                })
            }).map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
        };

        let mut cache = self._content.lock().unwrap();
        *cache = Some(bytes.to_vec());
        Ok(PyBytes::new(py, cache.as_ref().unwrap()))
    }

    #[getter]
    fn text<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyString>> {
        {
            let cache = self._text.lock().unwrap();
            if let Some(text) = &*cache {
                return Ok(PyString::new(py, text));
            }
        }

        let content = self.content(py)?;
        let raw_bytes = content.as_bytes();

        let encoding_name = self.get_encoding(py)?;

        let text = {
            let encoding = Encoding::for_label(encoding_name.as_bytes()).unwrap_or(UTF_8);
            let (decoded, _, _) = encoding.decode(raw_bytes);
            decoded.into_owned()
        };

        let mut cache = self._text.lock().unwrap();
        *cache = Some(text);
        Ok(PyString::new(py, cache.as_ref().unwrap()))
    }

    fn json(&self, py: Python) -> PyResult<Py<PyAny>> {
        let content = self.content(py)?;
        let raw_bytes = content.as_bytes();

        let json_value: serde_json::Value = serde_json::from_slice(raw_bytes)
            .map_err(|e| pyo3::exceptions::PyValueError::new_err(
                format!("Failed to parse JSON: {}", e)
            ))?;

        pythonize::pythonize(py, &json_value)
            .map(|bound| bound.unbind())
            .map_err(|e| pyo3::exceptions::PyValueError::new_err(
                format!("Failed to convert JSON to Python: {}", e)
            ))
    }

    #[getter]
    fn headers(&self, py: Python) -> PyResult<Py<PyDict>> {
        {
            let cache = self._headers.lock().unwrap();
            if let Some(headers) = &*cache {
                return Ok(headers.clone_ref(py));
            }
        }

        let inner_lock = self.inner.lock().unwrap();
        if inner_lock.is_none() {
            return Err(pyo3::exceptions::PyRuntimeError::new_err(
                "Headers not available - response was consumed before headers were accessed"
            ));
        }
        drop(inner_lock);

        let dict = self.extract_headers(py)?;

        let mut cache = self._headers.lock().unwrap();
        *cache = Some(dict.clone_ref(py));

        Ok(dict)
    }

    #[getter]
    fn cookies(&self, py: Python) -> PyResult<Py<PyDict>> {
        {
            let cache = self._cookies.lock().unwrap();
            if let Some(cookies) = &*cache {
                return Ok(cookies.clone_ref(py));
            }
        }

        let dict = self.extract_cookies(py)?;

        let mut cache = self._cookies.lock().unwrap();
        *cache = Some(dict.clone_ref(py));

        Ok(dict)
    }

    #[getter]
    fn encoding(&self, _py: Python) -> PyResult<Option<String>> {
        {
            let cache = self._encoding.lock().unwrap();
            if let Some(encoding) = &*cache {
                return Ok(Some(encoding.clone()));
            }
        }

        let encoding = match self.extract_encoding() {
            Ok(enc) => enc,
            Err(_) => return Ok(None),
        };

        let mut cache = self._encoding.lock().unwrap();
        *cache = Some(encoding.clone());

        Ok(Some(encoding))
    }
}

impl Response {
    pub fn from_wreq_response(wreq_resp: wreq::Response) -> Self {
        let url = wreq_resp.uri().to_string();
        let status_code = wreq_resp.status().as_u16();

        Response {
            inner: Mutex::new(Some(wreq_resp)),
            _content: Mutex::new(None),
            _text: Mutex::new(None),
            _encoding: Mutex::new(None),
            _headers: Mutex::new(None),
            _cookies: Mutex::new(None),
            url,
            status_code,
        }
    }

    fn get_encoding(&self, py: Python) -> PyResult<String> {
        self.encoding(py)?.ok_or_else(|| {
            pyo3::exceptions::PyValueError::new_err("Could not detect encoding")
        })
    }

    fn ensure_metadata_extracted(&self, py: Python) -> PyResult<()> {
        {
            let cache = self._headers.lock().unwrap();
            if cache.is_none() {
                drop(cache);
                let headers = self.extract_headers(py)?;
                let mut cache = self._headers.lock().unwrap();
                *cache = Some(headers);
            }
        }

        {
            let cache = self._encoding.lock().unwrap();
            if cache.is_none() {
                drop(cache);
                let encoding = self.extract_encoding().unwrap_or_else(|_| "utf-8".to_string());
                let mut cache = self._encoding.lock().unwrap();
                *cache = Some(encoding);
            }
        }

        {
            let cache = self._cookies.lock().unwrap();
            if cache.is_none() {
                drop(cache);
                let cookies = self.extract_cookies(py)?;
                let mut cache = self._cookies.lock().unwrap();
                *cache = Some(cookies);
            }
        }

        Ok(())
    }

    fn extract_headers(&self, py: Python) -> PyResult<Py<PyDict>> {
        let inner_lock = self.inner.lock().unwrap();
        let response = inner_lock.as_ref()
            .ok_or_else(|| pyo3::exceptions::PyRuntimeError::new_err(
                "Response already consumed"
            ))?;

        let dict = PyDict::new(py);
        for key in response.headers().keys() {
            let values: Vec<&str> = response.headers()
                .get_all(key)
                .iter()
                .filter_map(|v| v.to_str().ok())
                .collect();
            let joined = values.join(", ");
            dict.set_item(key.as_str(), joined)?;
        }
        Ok(dict.unbind())
    }

    fn extract_cookies(&self, py: Python) -> PyResult<Py<PyDict>> {
        let inner_lock = self.inner.lock().unwrap();
        let response = inner_lock.as_ref()
            .ok_or_else(|| pyo3::exceptions::PyRuntimeError::new_err(
                "Response already consumed"
            ))?;

        let dict = PyDict::new(py);
        let set_cookie_headers = response.headers().get_all(http::header::SET_COOKIE);

        for cookie_header in set_cookie_headers.iter() {
            if let Ok(cookie_str) = cookie_header.to_str() {
                if let Some((name, rest)) = cookie_str.split_once('=') {
                    let value = rest.split(';').next().unwrap_or("").trim();
                    dict.set_item(name.trim(), value)?;
                }
            }
        }
        Ok(dict.unbind())
    }

    fn extract_encoding(&self) -> PyResult<String> {
        let inner_lock = self.inner.lock().unwrap();
        let response = inner_lock.as_ref()
            .ok_or_else(|| pyo3::exceptions::PyRuntimeError::new_err(
                "Response already consumed"
            ))?;

        let encoding = response.headers()
            .get(http::header::CONTENT_TYPE)
            .and_then(|v| v.to_str().ok())
            .and_then(|v| v.parse::<Mime>().ok())
            .and_then(|m| m.get_param("charset").map(|c| c.to_string()))
            .unwrap_or_else(|| "utf-8".to_string());

        Ok(encoding)
    }
}
