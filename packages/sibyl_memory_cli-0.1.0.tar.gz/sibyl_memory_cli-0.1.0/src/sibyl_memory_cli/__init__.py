"""sibyl-memory-cli — Command-line interface for the Sibyl Memory Plugin.

Entry point: `sibyl` (installed via [project.scripts] in pyproject).

Commands:
    sibyl init          activate the plugin — opens browser SIWE flow, writes ~/.sibyl-memory/credentials.json
    sibyl upgrade       open the upgrade flow — stake $SIBYL or subscribe in USDC
    sibyl status        show current tier, DB size, expiry, account
    sibyl health        provider self-check (mirrors SibylMemoryProvider.health())

Browser pages live at sibyllabs.org/plugin/{activate,upgrade}.
All HTTP calls target https://api.sibyllabs.org/api/plugin/*.
"""
from .cli import main

__version__ = "0.1.0"

__all__ = ["main", "__version__"]
