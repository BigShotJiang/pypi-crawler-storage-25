import pytest

from pycldf.util import *
from pycldf.fileutil import *
from pycldf.urlutil import *
from pycldf.sliceutil import *
from pycldf.markdown import metadata2markdown


@pytest.mark.parametrize("sliceable,slices,expected", [
    ('abcdefg', [slice(1, 3)], 'bc'),
    ('abcdefg', ['2', '4'], 'bd'),
    ('abcdefg', [2, 4], 'ce'),
    ('abcdefg', ['2:8:2'], 'bdf'),
    ('abcdefg', ['2:5', (1, 4)], 'bcdebcd'),
    ([1, 2, 3, 4], ['1:6:2'], [1, 3]),
    ((1, 2, 3, 4), ['1:6:2'], (1, 3))
])
def test_multislice(sliceable, slices, expected):
    assert multislice(sliceable, *slices) == expected


@pytest.mark.parametrize(
    'qname,expected',
    [
        ('rdf:ID', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#ID'),
        ('xyz:thing', None),
    ]
)
def test_qname2url(qname, expected):
    assert qname2url(qname) == expected


def test_DictTuple():
    t = DictTuple([1, 2, 3], key=lambda i: str(i + 1))
    assert t['4'] == t[2] == 3

    t = DictTuple([1, 2, 3, 4, 3, 2], key=lambda i: str(i), multi=True)
    assert t['2'] == [2, 2]


@pytest.mark.parametrize("url,expected", [
    ('name', 'name'),
    (None, None),
    ('http://example.com:123/p?q=1#f', 'http://example.com:123/p?q=1#f'),
    ('http://user@example.com/', 'http://example.com/'),
    ('http://user:pwd@example.com/', 'http://example.com/'),
])
def test_sanitize_url(url, expected):
    assert sanitize_url(url) == expected


def test_url_without_fragment():
    assert url_without_fragment('http://example.org/p#frag#ment') == 'http://example.org/p'


def test_metadata2markdown(tmp_path):
    from pycldf import Generic

    ds = Generic.in_dir(tmp_path)
    ds.add_component('LanguageTable')
    ds.add_sources("@book{b,\ntitle={the book}}")
    ds.write(
        LanguageTable=[dict(ID='l', Name='the language')],
        zipped={'LanguageTable', 'sources.bib'}
    )
    md = metadata2markdown(ds, tmp_path / 'Generic-metadata.json')
    assert 'sources.bib.zip' in md
    assert 'languages.csv.zip' in md

    tmp_path.joinpath('languages.csv.zip').unlink()
    md = metadata2markdown(ds, tmp_path / 'Generic-metadata.json')
    assert 'languages.csv.zip' not in md, "Don't link non-existing files"


def test_split_and_cat(tmp_path):
    p = tmp_path / 'testfile'
    text = 'This is the test content'
    p.write_text(text)
    res = splitfile(p, 5)
    assert not p.exists()
    assert len(res) == 5
    assert catfile(p)
    assert p.exists()
    assert p.read_text() == text

    assert splitfile(p, 1000) == [p]
    assert not catfile(p)
