import time
from typing import Any, Dict, List, Optional

import httpx
from projectdavid_common.utilities.logging_service import LoggingUtility

from projectdavid.clients.base_client import BaseAPIClient

LOG = LoggingUtility()


class ToolsClientError(Exception):
    """Custom exception for ToolsClient errors."""


class ToolsClient(BaseAPIClient):
    # ------------------------------------------------------------------ #
    #  INIT
    # ------------------------------------------------------------------ #
    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: float = 60.0,
        connect_timeout: float = 10.0,
        read_timeout: float = 30.0,
        write_timeout: float = 30.0,
    ):
        super().__init__(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            connect_timeout=connect_timeout,
            read_timeout=read_timeout,
            write_timeout=write_timeout,
        )
        LOG.info("ToolsClient ready at: %s", self.base_url)

    # ------------------------------------------------------------------ #
    #  INTERNAL HELPERS
    # ------------------------------------------------------------------ #
    @staticmethod
    def _parse_response(response: httpx.Response) -> Dict[str, Any]:
        try:
            return response.json()
        except (httpx.DecodingError, ValueError) as e:
            # Catching both covers almost all JSON parsing failures
            LOG.error("Failed to decode JSON response: %s", response.text)
            raise ToolsClientError(f"Invalid JSON response from API: {e}")
        except Exception as e:
            # Catching any other unexpected error to ensure we never "fall through"
            LOG.error("Unexpected error parsing response: %s", str(e))
            raise ToolsClientError(f"Unexpected error parsing API response: {e}")

        # This line is technically unreachable due to the raises above,
        # but it satisfies Mypy's "Infrastructure Grade" requirements.
        return {}

    def _request_with_retries(self, method: str, url: str, **kwargs) -> httpx.Response:
        """
        Executes HTTP requests with exponential backoff for 5xx errors.
        """
        retries = 3
        for attempt in range(retries):
            try:
                resp = self.client.request(method, url, **kwargs)
                resp.raise_for_status()
                return resp
            except httpx.HTTPStatusError as exc:
                if (
                    exc.response.status_code in {500, 502, 503, 504}
                    and attempt < retries - 1
                ):
                    LOG.warning(
                        "ToolsClient: Retrying request due to server error (attempt %d)",
                        attempt + 1,
                    )
                    time.sleep(2**attempt)
                else:
                    LOG.error(
                        "ToolsClient Request Failed: %s %s | Status: %s",
                        method,
                        url,
                        exc.response.status_code,
                    )
                    raise ToolsClientError(f"API Request Failed: {exc}") from exc
            except httpx.RequestError as exc:
                if attempt < retries - 1:
                    time.sleep(2**attempt)
                else:
                    raise ToolsClientError(f"Network error: {exc}") from exc

        raise ToolsClientError(f"Request failed after {retries} retries")

    # ------------------------------------------------------------------ #
    #  WEB BROWSING CAPABILITIES
    # ------------------------------------------------------------------ #
    def web_read(self, url: str, force_refresh: bool = False) -> str:
        """
        Orders the API to visit a URL, scrape it, and return the first page (Page 0).
        """
        LOG.info("Tools: Reading URL %s (refresh=%s)", url, force_refresh)

        payload = {"url": url, "force_refresh": force_refresh}
        resp = self._request_with_retries("POST", "/v1/tools/web/read", json=payload)

        data = self._parse_response(resp)
        return data.get("content", "")

    def web_scroll(self, url: str, page: int) -> str:
        """
        Retrieves a specific page chunk from a previously read URL.
        """
        LOG.info("Tools: Scrolling URL %s to page %d", url, page)

        payload = {"url": url, "page": page}
        resp = self._request_with_retries("POST", "/v1/tools/web/scroll", json=payload)

        data = self._parse_response(resp)
        return data.get("content", "")

    def web_search(self, url: str, query: str) -> str:
        """
        Searches the entire document (all pages) for a specific keyword.
        """
        LOG.info("Tools: Searching URL %s for '%s'", url, query)

        payload = {"url": url, "query": query}
        resp = self._request_with_retries("POST", "/v1/tools/web/search", json=payload)

        data = self._parse_response(resp)
        return data.get("content", "")

    def web_serp(
        self,
        query: str,
        count: int = 10,
        engines: Optional[List[str]] = None,
    ) -> str:
        """
        Performs a structured SERP search via the internal SearxNG container.

        SearxNG fans out to multiple search engines simultaneously (DDG, Bing,
        Google) and returns deduplicated results ranked by score — no browser
        overhead, no markdown parsing.

        Args:
            query:   The search query string.
            count:   Maximum number of results to return (default 10).
            engines: Optional list to pin specific engines e.g.
                     ["duckduckgo", "bing"]. None uses SearxNG defaults.

        Returns:
            str: Agent-ready formatted result string with titles, URLs,
                 snippets, authority tags, and mandatory source guidance.

        Example:
            results = client.tools.web_serp("bgp route reflector design", count=5)
            results = client.tools.web_serp("python async", engines=["duckduckgo"])
        """
        LOG.info(
            "Tools: SERP search '%s' count=%d engines=%s",
            query,
            count,
            engines or "default",
        )

        payload: Dict[str, Any] = {"query": query, "count": count}
        if engines:
            payload["engines"] = engines

        resp = self._request_with_retries("POST", "/v1/tools/web/serp", json=payload)

        data = self._parse_response(resp)
        return data.get("content", "")

    # ------------------------------------------------------------------ #
    #  SCRATCHPAD CAPABILITIES
    # ------------------------------------------------------------------ #
    def scratchpad_read(self, thread_id: str) -> str:
        """
        Retrieves the current research plan and notes for a specific thread.

        Returns:
            str: The formatted scratchpad content.
        """
        LOG.info("Tools: Reading Scratchpad for thread %s", thread_id)

        payload = {"thread_id": thread_id}
        resp = self._request_with_retries(
            "POST", "/v1/tools/scratchpad/read", json=payload
        )

        data = self._parse_response(resp)
        return data.get("content", "")

    def scratchpad_update(self, thread_id: str, content: str) -> str:
        """
        Overwrites the entire scratchpad with new content (e.g., re-planning).

        Returns:
            str: Success message.
        """
        LOG.info("Tools: Overwriting Scratchpad for thread %s", thread_id)

        payload = {"thread_id": thread_id, "content": content}
        resp = self._request_with_retries(
            "POST", "/v1/tools/scratchpad/update", json=payload
        )

        data = self._parse_response(resp)
        return data.get("message", "Scratchpad updated.")

    def scratchpad_append(self, thread_id: str, note: str) -> str:
        """
        Appends a specific note or finding to the bottom of the scratchpad.

        Returns:
            str: Success message.
        """
        LOG.info("Tools: Appending to Scratchpad for thread %s", thread_id)

        payload = {"thread_id": thread_id, "note": note}
        resp = self._request_with_retries(
            "POST", "/v1/tools/scratchpad/append", json=payload
        )

        data = self._parse_response(resp)
        return data.get("message", "Note appended.")
