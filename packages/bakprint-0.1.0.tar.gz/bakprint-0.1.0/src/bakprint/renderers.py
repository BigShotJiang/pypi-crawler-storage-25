from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import is_dataclass, fields
from typing import Any, Callable

from rich.console import Group
from rich.pretty import Pretty
from rich.table import Table
from rich.text import Text

try:
    import numpy as np
except ImportError:  # pragma: no cover - optional dependency
    np = None

try:
    import pandas as pd
except ImportError:  # pragma: no cover - optional dependency
    pd = None

from .config import PrintConfig


def render_metadata(metadata: list[tuple[str, str]], config: PrintConfig) -> Table:
    table = Table.grid(padding=(0, 1))
    table.add_column(style=config.resolve_style(config.metadata_key_style), justify="right", no_wrap=True)
    table.add_column(style=config.resolve_style(config.metadata_value_style))
    for key, value in metadata:
        table.add_row(key, value)
    return table


def truncate(value: str, limit: int) -> str:
    if len(value) <= limit:
        return value
    return value[: max(0, limit - 1)] + "…"


def summarize_scalar(value: Any) -> str:
    if isinstance(value, float):
        return f"{value:.4g}"
    return str(value)


class ObjectRenderer:
    def __init__(
        self,
        config: PrintConfig,
        custom_renderers: dict[type[Any], Callable[[Any, PrintConfig], Any]] | None = None,
    ) -> None:
        self.config = config
        self.custom_renderers = custom_renderers or {}

    def render(
        self,
        obj: Any,
        label: str | None = None,
        extra_metadata: list[tuple[str, str]] | None = None,
        mode: str | None = None,
    ):
        render_mode = mode or self.config.display_mode
        metadata = self._metadata_for(obj, label)
        if extra_metadata:
            metadata.extend(extra_metadata)
        body = self._render_body(obj, depth=0, mode=render_mode)
        if metadata and self.config.show_header:
            return Group(render_metadata(metadata, self.config), body)
        return body

    def _metadata_for(self, obj: Any, label: str | None) -> list[tuple[str, str]]:
        metadata: list[tuple[str, str]] = []
        if label:
            metadata.append(("label", label))
        if self.config.show_type:
            metadata.append(("type", type(obj).__name__))

        if np is not None and isinstance(obj, np.ndarray):
            metadata.append(("shape", " x ".join(str(x) for x in obj.shape)))
            metadata.append(("dtype", str(obj.dtype)))
            metadata.append(("size", str(obj.size)))
            return metadata

        if pd is not None:
            if isinstance(obj, pd.DataFrame):
                metadata.append(("shape", f"{obj.shape[0]} rows x {obj.shape[1]} cols"))
                memory = int(obj.memory_usage(deep=True).sum())
                metadata.append(("memory", _human_bytes(memory)))
                return metadata
            if isinstance(obj, pd.Series):
                metadata.append(("length", str(len(obj))))
                metadata.append(("dtype", str(obj.dtype)))
                memory = int(obj.memory_usage(deep=True))
                metadata.append(("memory", _human_bytes(memory)))
                return metadata

        if isinstance(obj, Mapping):
            metadata.append(("size", str(len(obj))))
        elif isinstance(obj, (str, bytes, bytearray)):
            metadata.append(("length", str(len(obj))))
        elif isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray)):
            metadata.append(("size", str(len(obj))))
        return metadata

    def _render_body(self, obj: Any, depth: int, mode: str):
        for target_type, renderer in self.custom_renderers.items():
            if isinstance(obj, target_type):
                return renderer(obj, self.config)
        if mode == "summary":
            return self._render_summary(obj, depth)
        if np is not None and isinstance(obj, np.ndarray):
            return self._render_numpy(obj)
        if pd is not None:
            if isinstance(obj, pd.DataFrame):
                return self._render_dataframe(obj)
            if isinstance(obj, pd.Series):
                return self._render_series(obj)
        if isinstance(obj, str):
            return Text(
                truncate(repr(obj), self.config.max_string),
                style=self.config.resolve_style("string"),
            )
        if isinstance(obj, (bytes, bytearray)):
            return Text(
                truncate(repr(obj), self.config.max_string),
                style=self.config.resolve_style("string"),
            )
        if is_dataclass(obj) and not isinstance(obj, type):
            payload = {field.name: getattr(obj, field.name) for field in fields(obj)}
            return self._render_mapping(payload, depth)
        if isinstance(obj, Mapping):
            return self._render_mapping(obj, depth)
        if isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray)):
            return self._render_sequence(obj, depth)
        return Pretty(obj, expand_all=False, indent_guides=True, max_string=self.config.max_string)

    def _render_summary(self, obj: Any, depth: int):
        if np is not None and isinstance(obj, np.ndarray):
            return self._render_numpy_summary(obj)
        if pd is not None:
            if isinstance(obj, pd.DataFrame):
                return self._render_dataframe_summary(obj)
            if isinstance(obj, pd.Series):
                return self._render_series_summary(obj)
        if isinstance(obj, Mapping):
            return self._render_mapping_summary(obj, depth)
        if isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray)):
            return self._render_sequence_summary(obj, depth)
        return Text(truncate(repr(obj), self.config.max_string), style=self.config.resolve_style("string"))

    def _render_mapping(self, obj: Mapping[Any, Any], depth: int) -> Table:
        table = Table(
            show_header=True,
            header_style=self.config.resolve_style(self.config.label_style),
            box=None,
            expand=True,
            padding=(0, 1),
        )
        table.add_column("key", style=self.config.resolve_style(self.config.metadata_key_style), no_wrap=True)
        table.add_column("value")

        items = obj.items()
        if self.config.sort_keys:
            items = sorted(items, key=lambda item: str(item[0]))

        count = 0
        for key, value in items:
            if count >= self.config.max_items:
                table.add_row("…", f"{len(obj) - self.config.max_items} more items")
                break
            table.add_row(truncate(str(key), self.config.max_cell_length), self._cell(value, depth + 1))
            count += 1
        return table

    def _render_sequence(self, obj: Sequence[Any], depth: int) -> Table:
        table = Table(
            show_header=True,
            header_style=self.config.resolve_style(self.config.label_style),
            box=None,
            expand=True,
            padding=(0, 1),
        )
        table.add_column("#", style=self.config.resolve_style(self.config.metadata_key_style), no_wrap=True)
        table.add_column("value")

        for index, value in enumerate(obj[: self.config.max_items]):
            table.add_row(str(index), self._cell(value, depth + 1))
        if len(obj) > self.config.max_items:
            table.add_row("…", f"{len(obj) - self.config.max_items} more items")
        return table

    def _render_numpy(self, array: Any) -> Group:
        stats_text = None
        if self.config.show_stats and array.size:
            numeric = _numpy_numeric_stats(array)
            if numeric:
                stats_text = Text(
                    " | ".join(f"{key}={value}" for key, value in numeric),
                    style=self.config.resolve_style(self.config.summary_style),
                )

        rows, cols = _visible_window(array.shape, self.config.max_array_rows, self.config.max_array_cols)
        preview = array[_array_preview_slices(array.ndim, rows, cols)]
        body = Pretty(preview.tolist(), expand_all=False, indent_guides=True, max_string=self.config.max_string)

        if array.ndim >= 2:
            summary_text = f"showing first {rows} row(s) and {cols} column(s)"
        else:
            summary_text = f"showing first {rows} item(s)"
        if array.ndim > 2:
            summary_text += " plus clipped higher dimensions"

        summary = Text(summary_text, style=self.config.resolve_style(self.config.summary_style))
        if stats_text:
            return Group(stats_text, body, summary)
        return Group(body, summary)

    def _render_numpy_summary(self, array: Any) -> Group:
        lines = [
            Text(f"shape={array.shape} | ndim={array.ndim} | dtype={array.dtype}", style=self.config.resolve_style(self.config.summary_style)),
        ]
        if self.config.show_stats and array.size:
            numeric = _numpy_numeric_stats(array)
            if numeric:
                lines.append(
                    Text(
                        " | ".join(f"{key}={value}" for key, value in numeric),
                        style=self.config.resolve_style(self.config.summary_style),
                    )
                )
        sample_size = min(array.size, self.config.max_items)
        if sample_size:
            sample = array.reshape(-1)[:sample_size].tolist()
            lines.append(Text(f"sample={sample}", style=self.config.resolve_style("string")))
        return Group(*lines)

    def _render_dataframe(self, frame: Any) -> Group:
        visible = frame.iloc[: self.config.max_dataframe_rows, : self.config.max_dataframe_cols]
        table = Table(
            show_header=True,
            header_style=self.config.resolve_style(self.config.label_style),
            expand=True,
            padding=(0, 1),
        )

        if self.config.show_index:
            index_name = frame.index.name or "index"
            table.add_column(index_name, style=self.config.resolve_style(self.config.metadata_key_style), no_wrap=True)

        for column in visible.columns:
            title = str(column)
            if self.config.show_dtypes:
                summary_style = self.config.resolve_style(self.config.summary_style)
                title = f"{title}\n[{summary_style}]{frame[column].dtype}[/]"
            table.add_column(title, overflow="fold")

        for index, row in visible.iterrows():
            cells = []
            if self.config.show_index:
                cells.append(truncate(str(index), self.config.max_cell_length))
            for value in row.tolist():
                cells.append(truncate(summarize_scalar(value), self.config.max_cell_length))
            table.add_row(*cells)

        notes: list[Text] = []
        if self.config.show_summary:
            notes.append(
                Text(
                    f"showing {len(visible)} of {len(frame)} rows and {len(visible.columns)} of {len(frame.columns)} columns",
                    style=self.config.resolve_style(self.config.summary_style),
                )
            )
        if self.config.show_stats:
            numeric = frame.select_dtypes(include="number")
            if not numeric.empty:
                notes.append(
                    Text(
                        f"numeric columns={numeric.shape[1]} | nulls={int(frame.isna().sum().sum())}",
                        style=self.config.resolve_style(self.config.summary_style),
                    )
                )
        return Group(table, *notes)

    def _render_dataframe_summary(self, frame: Any) -> Group:
        schema = Table(
            show_header=True,
            header_style=self.config.resolve_style(self.config.label_style),
            expand=True,
            padding=(0, 1),
            box=None,
        )
        schema.add_column("column", style=self.config.resolve_style(self.config.metadata_key_style), no_wrap=True)
        schema.add_column("dtype")
        schema.add_column("nulls", justify="right")

        visible_columns = list(frame.columns[: self.config.max_dataframe_cols])
        for column in visible_columns:
            schema.add_row(str(column), str(frame[column].dtype), str(int(frame[column].isna().sum())))

        notes = [
            Text(
                f"rows={len(frame)} | columns={len(frame.columns)} | memory={_human_bytes(int(frame.memory_usage(deep=True).sum()))}",
                style=self.config.resolve_style(self.config.summary_style),
            )
        ]
        numeric = frame.select_dtypes(include="number")
        if self.config.show_stats and not numeric.empty:
            notes.append(
                Text(
                    f"numeric columns={numeric.shape[1]} | total nulls={int(frame.isna().sum().sum())}",
                    style=self.config.resolve_style(self.config.summary_style),
                )
            )
        if len(frame.columns) > len(visible_columns):
            notes.append(
                Text(
                    f"showing schema for first {len(visible_columns)} of {len(frame.columns)} columns",
                    style=self.config.resolve_style(self.config.summary_style),
                )
            )
        return Group(schema, *notes)

    def _render_series(self, series: Any) -> Group:
        visible = series.iloc[: self.config.max_series_rows]
        table = Table(
            show_header=True,
            header_style=self.config.resolve_style(self.config.label_style),
            expand=True,
            padding=(0, 1),
        )
        if self.config.show_index:
            index_name = series.index.name or "index"
            table.add_column(index_name, style=self.config.resolve_style(self.config.metadata_key_style), no_wrap=True)
        table.add_column(series.name or "value")

        for index, value in visible.items():
            row = []
            if self.config.show_index:
                row.append(truncate(str(index), self.config.max_cell_length))
            row.append(truncate(summarize_scalar(value), self.config.max_cell_length))
            table.add_row(*row)

        notes = [
            Text(
                f"showing {len(visible)} of {len(series)} rows",
                style=self.config.resolve_style(self.config.summary_style),
            )
        ]
        if self.config.show_stats and _is_numeric_series(series):
            notes.append(
                Text(
                    f"min={series.min():.4g} | max={series.max():.4g} | mean={series.mean():.4g}",
                    style=self.config.resolve_style(self.config.summary_style),
                )
            )
        return Group(table, *notes)

    def _render_series_summary(self, series: Any) -> Group:
        lines = [
            Text(
                f"length={len(series)} | dtype={series.dtype} | nulls={int(series.isna().sum())}",
                style=self.config.resolve_style(self.config.summary_style),
            )
        ]
        if self.config.show_stats and _is_numeric_series(series) and len(series):
            lines.append(
                Text(
                    f"min={series.min():.4g} | max={series.max():.4g} | mean={series.mean():.4g}",
                    style=self.config.resolve_style(self.config.summary_style),
                )
            )
        sample = [summarize_scalar(value) for value in series.iloc[: self.config.max_items].tolist()]
        lines.append(Text(f"sample={sample}", style=self.config.resolve_style("string")))
        return Group(*lines)

    def _cell(self, value: Any, depth: int) -> str:
        if depth > self.config.max_depth:
            return truncate(repr(value), self.config.max_string)
        if isinstance(value, str):
            return truncate(repr(value), self.config.max_string)
        if np is not None and isinstance(value, np.ndarray):
            shape = " x ".join(str(x) for x in value.shape)
            return f"ndarray(shape={shape}, dtype={value.dtype})"
        if pd is not None:
            if isinstance(value, pd.DataFrame):
                return f"DataFrame(shape={value.shape[0]}x{value.shape[1]})"
            if isinstance(value, pd.Series):
                return f"Series(len={len(value)}, dtype={value.dtype})"
        if isinstance(value, Mapping):
            return f"{type(value).__name__}({len(value)} items)"
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
            return f"{type(value).__name__}({len(value)} items)"
        return truncate(repr(value), self.config.max_string)

    def _render_mapping_summary(self, obj: Mapping[Any, Any], depth: int) -> Group:
        table = Table(
            show_header=True,
            header_style=self.config.resolve_style(self.config.label_style),
            box=None,
            expand=True,
            padding=(0, 1),
        )
        table.add_column("key", style=self.config.resolve_style(self.config.metadata_key_style), no_wrap=True)
        table.add_column("kind")
        for index, (key, value) in enumerate(obj.items()):
            if index >= self.config.max_items:
                break
            table.add_row(truncate(str(key), self.config.max_cell_length), type(value).__name__)
        notes = [Text(f"items={len(obj)}", style=self.config.resolve_style(self.config.summary_style))]
        if len(obj) > self.config.max_items:
            notes.append(Text(f"showing first {self.config.max_items} keys", style=self.config.resolve_style(self.config.summary_style)))
        return Group(table, *notes)

    def _render_sequence_summary(self, obj: Sequence[Any], depth: int) -> Group:
        sample = [type(value).__name__ for value in obj[: self.config.max_items]]
        lines = [
            Text(f"items={len(obj)}", style=self.config.resolve_style(self.config.summary_style)),
            Text(f"sample types={sample}", style=self.config.resolve_style(self.config.summary_style)),
        ]
        return Group(*lines)


def _human_bytes(size: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    amount = float(size)
    for unit in units:
        if amount < 1024 or unit == units[-1]:
            return f"{amount:.1f} {unit}"
        amount /= 1024
    return f"{size} B"


def _visible_window(shape: tuple[int, ...], max_rows: int, max_cols: int) -> tuple[int, int]:
    if not shape:
        return (1, 1)
    if len(shape) == 1:
        return (min(shape[0], max_rows), 1)
    return (min(shape[0], max_rows), min(shape[1], max_cols))


def _array_preview_slices(ndim: int, rows: int, cols: int) -> tuple[slice, ...]:
    if ndim <= 0:
        return tuple()
    slices = [slice(0, rows)]
    if ndim >= 2:
        slices.append(slice(0, cols))
    for _ in range(2, ndim):
        slices.append(slice(0, 2))
    return tuple(slices)


def _numpy_numeric_stats(array: Any) -> list[tuple[str, str]]:
    if np is None or not np.issubdtype(array.dtype, np.number):
        return []
    flat = array.reshape(-1)
    if flat.size == 0:
        return []
    return [
        ("min", summarize_scalar(np.min(flat))),
        ("max", summarize_scalar(np.max(flat))),
        ("mean", summarize_scalar(np.mean(flat))),
    ]


def _is_numeric_series(series: Any) -> bool:
    if pd is None:
        return False
    return pd.api.types.is_numeric_dtype(series.dtype)
