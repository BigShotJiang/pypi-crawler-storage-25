from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any

from rich.theme import Theme


THEME_PRESETS: dict[str, dict[str, str]] = {
    "aurora": {
        "frame.border": "bold cyan",
        "frame.title": "bold white",
        "label": "bold bright_magenta",
        "meta.key": "bold bright_cyan",
        "meta.value": "white",
        "summary": "bright_black",
        "accent": "bold bright_yellow",
        "number": "bold bright_green",
        "string": "bright_white",
        "muted": "bright_black",
        "type": "bold bright_blue",
        "warning": "bold bright_red",
        "diff.added": "bold bright_green",
        "diff.removed": "bold bright_red",
        "diff.changed": "bold bright_yellow",
    },
    "paper": {
        "frame.border": "blue",
        "frame.title": "bold black",
        "label": "bold dark_orange",
        "meta.key": "bold blue",
        "meta.value": "black",
        "summary": "dim",
        "accent": "bold magenta",
        "number": "bold green",
        "string": "black",
        "muted": "dim",
        "type": "bold dark_cyan",
        "warning": "bold red",
        "diff.added": "bold green",
        "diff.removed": "bold red",
        "diff.changed": "bold dark_orange",
    },
    "matrix": {
        "frame.border": "bold green",
        "frame.title": "bold bright_green",
        "label": "bold chartreuse1",
        "meta.key": "bold spring_green2",
        "meta.value": "green",
        "summary": "green4",
        "accent": "bold green_yellow",
        "number": "bold green1",
        "string": "bright_green",
        "muted": "green4",
        "type": "bold green3",
        "warning": "bold red",
        "diff.added": "bold green1",
        "diff.removed": "bold red",
        "diff.changed": "bold green_yellow",
    },
    "noir": {
        "frame.border": "white",
        "frame.title": "bold white",
        "label": "bold cyan",
        "meta.key": "bold white",
        "meta.value": "white",
        "summary": "bright_black",
        "accent": "bold yellow",
        "number": "bold green",
        "string": "white",
        "muted": "bright_black",
        "type": "bold cyan",
        "warning": "bold red",
        "diff.added": "bold green",
        "diff.removed": "bold red",
        "diff.changed": "bold yellow",
    },
}

@dataclass(slots=True)
class PrintConfig:
    theme: str = "aurora"
    display_mode: str = "preview"
    border_effect: str = "static"
    prefer_ascii_borders: bool | None = None
    width: int | None = None
    expand: bool = True
    show_header: bool = True
    show_type: bool = True
    show_summary: bool = True
    show_stats: bool = True
    show_trace: bool = False
    show_timestamp: bool = False
    show_index: bool = True
    show_dtypes: bool = True
    sort_keys: bool = False
    max_depth: int = 2
    max_items: int = 12
    max_string: int = 160
    max_array_rows: int = 10
    max_array_cols: int = 8
    max_dataframe_rows: int = 12
    max_dataframe_cols: int = 8
    max_series_rows: int = 16
    max_cell_length: int = 32
    diff_sample_size: int = 12
    animation_duration: float = 1.4
    animation_fps: int = 10
    border_style: str = "frame.border"
    title_style: str = "frame.title"
    label_style: str = "label"
    metadata_key_style: str = "meta.key"
    metadata_value_style: str = "meta.value"
    summary_style: str = "summary"
    custom_styles: dict[str, str] = field(default_factory=dict)

    def with_overrides(self, **overrides: Any) -> "PrintConfig":
        if not overrides:
            return self
        return replace(self, **overrides)

    def resolve_style(self, style_name: str) -> str:
        styles = dict(THEME_PRESETS.get(self.theme, THEME_PRESETS["aurora"]))
        styles.update(self.custom_styles)
        return styles.get(style_name, style_name)

    def rich_theme(self) -> Theme:
        styles = dict(THEME_PRESETS.get(self.theme, THEME_PRESETS["aurora"]))
        styles.update(self.custom_styles)
        return Theme(styles)
