from __future__ import annotations

import inspect
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from rich import box
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.box import Box

from .config import PrintConfig
from .diffing import DiffRenderer
from .renderers import ObjectRenderer

RenderHook = Callable[[Any, PrintConfig], Any]

MARCHING_DASH_BOXES: tuple[Box, ...] = (
    Box(
        "╭┄┬╮\n"
        "┆ ┆┆\n"
        "├┄┼┤\n"
        "┆ ┆┆\n"
        "├┄┼┤\n"
        "├┄┼┤\n"
        "┆ ┆┆\n"
        "╰┄┴╯\n"
    ),
    Box(
        "╭┈┬╮\n"
        "┊ ┊┊\n"
        "├┈┼┤\n"
        "┊ ┊┊\n"
        "├┈┼┤\n"
        "├┈┼┤\n"
        "┊ ┊┊\n"
        "╰┈┴╯\n"
    ),
    Box(
        "╭╌┬╮\n"
        "╎ ╎╎\n"
        "├╌┼┤\n"
        "╎ ╎╎\n"
        "├╌┼┤\n"
        "├╌┼┤\n"
        "╎ ╎╎\n"
        "╰╌┴╯\n"
    ),
    Box(
        "╭╍┬╮\n"
        "╏ ╏╏\n"
        "├╍┼┤\n"
        "╏ ╏╏\n"
        "├╍┼┤\n"
        "├╍┼┤\n"
        "╏ ╏╏\n"
        "╰╍┴╯\n"
    ),
)

ASCII_MARCHING_DASH_BOXES: tuple[Box, ...] = (
    Box(
        "+-++\n"
        "| ||\n"
        "+-++\n"
        "| ||\n"
        "+-++\n"
        "+-++\n"
        "| ||\n"
        "+-++\n",
        ascii=True,
    ),
    Box(
        "+=++\n"
        "! !!\n"
        "+=++\n"
        "! !!\n"
        "+=++\n"
        "+=++\n"
        "! !!\n"
        "+=++\n",
        ascii=True,
    ),
)


class DebugPrinter:
    def __init__(
        self,
        config: PrintConfig | None = None,
        console: Console | None = None,
        renderers: dict[type[Any], RenderHook] | None = None,
    ) -> None:
        self.config = config or PrintConfig()
        self.console = console or Console(theme=self.config.rich_theme(), width=self.config.width)
        self.renderers = dict(renderers or {})
        self.renderer = ObjectRenderer(self.config, custom_renderers=self.renderers)
        self.diff_renderer = DiffRenderer(self.config)

    def with_config(self, **overrides: Any) -> "DebugPrinter":
        config = self.config.with_overrides(**overrides)
        return DebugPrinter(config=config, renderers=self.renderers)

    def register(self, target_type: type[Any], renderer: RenderHook) -> "DebugPrinter":
        self.renderers[target_type] = renderer
        self.renderer = ObjectRenderer(self.config, custom_renderers=self.renderers)
        return self

    def format(self, obj: Any, label: str | None = None, title: str | None = None, frame: int = 0):
        content = self.renderer.render(obj, label=label, extra_metadata=self._trace_metadata())
        panel_title = title or label or type(obj).__name__
        return self._base_panel(content, panel_title, frame=frame)

    def print(self, *objects: Any, title: str | None = None, labels: list[str] | tuple[str, ...] | None = None) -> None:
        if labels is None:
            labels = [None] * len(objects)
        if len(labels) != len(objects):
            raise ValueError("labels must match the number of objects")

        for index, (obj, label) in enumerate(zip(objects, labels)):
            panel_title = title if len(objects) == 1 else f"{title or 'debug'} #{index + 1}"
            if self._should_animate():
                self.animate(obj, label=label, title=panel_title)
            else:
                self.console.print(self.format(obj, label=label, title=panel_title))

    def inspect(self, obj: Any, label: str | None = None, title: str | None = None) -> Any:
        if self._should_animate():
            self.animate(obj, label=label, title=title)
        else:
            self.console.print(self.format(obj, label=label, title=title))
        return obj

    def summarize(self, obj: Any, label: str | None = None, title: str | None = None) -> Any:
        content = self.renderer.render(
            obj,
            label=label,
            extra_metadata=self._trace_metadata(),
            mode="summary",
        )
        panel_title = title or label or f"{type(obj).__name__} summary"
        if self._should_animate():
            self._animate_renderable(content, panel_title)
        else:
            self.console.print(self._base_panel(content, panel_title))
        return obj

    def format_diff(
        self,
        before: Any,
        after: Any,
        labels: tuple[str, str] = ("before", "after"),
        title: str | None = None,
    ):
        content = self.diff_renderer.render(
            before,
            after,
            labels=labels,
            extra_metadata=self._trace_metadata(),
        )
        panel_title = title or "diff"
        return self._base_panel(content, panel_title)

    def diff(
        self,
        before: Any,
        after: Any,
        labels: tuple[str, str] = ("before", "after"),
        title: str | None = None,
    ) -> None:
        if self._should_animate():
            content = self.diff_renderer.render(
                before,
                after,
                labels=labels,
                extra_metadata=self._trace_metadata(),
            )
            self._animate_renderable(content, title or "diff")
        else:
            self.console.print(self.format_diff(before, after, labels=labels, title=title))

    def animate(
        self,
        obj: Any,
        label: str | None = None,
        title: str | None = None,
        duration: float | None = None,
        fps: int | None = None,
    ) -> Any:
        content = self.renderer.render(obj, label=label, extra_metadata=self._trace_metadata())
        panel_title = title or label or type(obj).__name__
        if self._should_animate():
            self._animate_renderable(content, panel_title, duration=duration, fps=fps)
        else:
            self.console.print(self._base_panel(content, panel_title))
        return obj

    def _panel_title_markup(self, panel_title: str) -> str:
        return f"[{self.config.resolve_style(self.config.title_style)}]{panel_title}[/]"

    def _base_panel(self, content: Any, panel_title: str, frame: int = 0) -> Panel:
        return Panel(
            content,
            title=self._panel_title_markup(panel_title),
            border_style=self.config.resolve_style(self.config.border_style),
            title_align="left",
            expand=self.config.expand,
            box=self._resolve_box(frame),
        )

    def _resolve_box(self, frame: int) -> Box:
        if self.config.border_effect == "marching_dashes":
            boxes = self._marching_dash_boxes()
            return boxes[frame % len(boxes)]
        return box.ROUNDED

    def _marching_dash_boxes(self) -> tuple[Box, ...]:
        if self._prefer_ascii_borders():
            return ASCII_MARCHING_DASH_BOXES
        return MARCHING_DASH_BOXES

    def _prefer_ascii_borders(self) -> bool:
        if self.config.prefer_ascii_borders is not None:
            return self.config.prefer_ascii_borders
        encoding = (getattr(self.console.file, "encoding", "") or "").lower()
        if self.console.safe_box:
            return True
        return "utf" not in encoding

    def _should_animate(self) -> bool:
        return self.config.border_effect == "marching_dashes" and bool(getattr(self.console, "is_terminal", False))

    def _animate_renderable(
        self,
        content: Any,
        panel_title: str,
        duration: float | None = None,
        fps: int | None = None,
    ) -> None:
        duration = self.config.animation_duration if duration is None else duration
        fps = self.config.animation_fps if fps is None else fps
        total_frames = max(1, int(duration * fps))
        refresh = max(1, fps)
        with Live(
            self._base_panel(content, panel_title, frame=0),
            console=self.console,
            refresh_per_second=refresh,
            transient=False,
        ) as live:
            for frame in range(total_frames):
                live.update(self._base_panel(content, panel_title, frame=frame), refresh=True)
                time.sleep(1 / refresh)

    def _trace_metadata(self) -> list[tuple[str, str]]:
        metadata: list[tuple[str, str]] = []
        if self.config.show_timestamp:
            metadata.append(("time", datetime.now().isoformat(timespec="seconds")))
        if self.config.show_trace:
            frame = self._find_external_frame()
            if frame is not None:
                path = Path(frame.filename)
                try:
                    location = str(path.resolve().relative_to(Path.cwd()))
                except ValueError:
                    location = path.name
                metadata.append(("caller", f"{location}:{frame.lineno}"))
                metadata.append(("function", frame.function))
        return metadata

    def _find_external_frame(self):
        current_path = Path(__file__).resolve()
        for frame in inspect.stack()[2:]:
            frame_path = Path(frame.filename).resolve()
            if frame_path != current_path:
                return frame
        return None


def _resolve_printer(config: PrintConfig | None = None, console: Console | None = None, **overrides: Any) -> DebugPrinter:
    resolved = (config or PrintConfig()).with_overrides(**overrides)
    return DebugPrinter(config=resolved, console=console)


def bak_printx(
    *objects: Any,
    title: str | None = None,
    labels: list[str] | tuple[str, ...] | None = None,
    config: PrintConfig | None = None,
    console: Console | None = None,
    **overrides: Any,
) -> None:
    _resolve_printer(config=config, console=console, **overrides).print(*objects, title=title, labels=labels)


def bak_formatx(
    obj: Any,
    label: str | None = None,
    title: str | None = None,
    config: PrintConfig | None = None,
    **overrides: Any,
):
    return _resolve_printer(config=config, **overrides).format(obj, label=label, title=title)


def bak_inspectx(
    obj: Any,
    label: str | None = None,
    title: str | None = None,
    config: PrintConfig | None = None,
    console: Console | None = None,
    **overrides: Any,
) -> Any:
    return _resolve_printer(config=config, console=console, **overrides).inspect(obj, label=label, title=title)


def bak_animatex(
    obj: Any,
    label: str | None = None,
    title: str | None = None,
    config: PrintConfig | None = None,
    console: Console | None = None,
    duration: float | None = None,
    fps: int | None = None,
    **overrides: Any,
) -> Any:
    return _resolve_printer(config=config, console=console, **overrides).animate(
        obj,
        label=label,
        title=title,
        duration=duration,
        fps=fps,
    )


def bak_summaryx(
    obj: Any,
    label: str | None = None,
    title: str | None = None,
    config: PrintConfig | None = None,
    console: Console | None = None,
    **overrides: Any,
) -> Any:
    return _resolve_printer(config=config, console=console, **overrides).summarize(obj, label=label, title=title)


def bak_diffx(
    before: Any,
    after: Any,
    labels: tuple[str, str] = ("before", "after"),
    title: str | None = None,
    config: PrintConfig | None = None,
    console: Console | None = None,
    **overrides: Any,
) -> None:
    _resolve_printer(config=config, console=console, **overrides).diff(before, after, labels=labels, title=title)


printx = bak_printx
formatx = bak_formatx
inspectx = bak_inspectx
animatex = bak_animatex
summaryx = bak_summaryx
diffx = bak_diffx
