from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import fields, is_dataclass
from typing import Any

try:
    import numpy as np
except ImportError:  # pragma: no cover - optional dependency
    np = None

try:
    import pandas as pd
except ImportError:  # pragma: no cover - optional dependency
    pd = None

from .config import PrintConfig


def to_structured(
    obj: Any,
    *,
    config: PrintConfig | None = None,
    label: str | None = None,
    title: str | None = None,
    mode: str | None = None,
    extra_metadata: list[tuple[str, str]] | None = None,
) -> dict[str, Any]:
    exporter = StructuredExporter(config or PrintConfig())
    return exporter.export(
        obj,
        label=label,
        title=title,
        mode=mode or (config.display_mode if config else "preview"),
        extra_metadata=extra_metadata,
    )


def diff_structured(
    before: Any,
    after: Any,
    *,
    config: PrintConfig | None = None,
    title: str | None = None,
    labels: tuple[str, str] = ("before", "after"),
    extra_metadata: list[tuple[str, str]] | None = None,
) -> dict[str, Any]:
    exporter = StructuredExporter(config or PrintConfig())
    return exporter.export_diff(
        before,
        after,
        title=title,
        labels=labels,
        extra_metadata=extra_metadata,
    )


class StructuredExporter:
    def __init__(self, config: PrintConfig) -> None:
        self.config = config

    def export(
        self,
        obj: Any,
        *,
        label: str | None = None,
        title: str | None = None,
        mode: str = "preview",
        extra_metadata: list[tuple[str, str]] | None = None,
    ) -> dict[str, Any]:
        metadata = self._metadata(obj, label=label)
        if extra_metadata:
            metadata.extend({"key": key, "value": value} for key, value in extra_metadata)
        sections = self._sections_for(obj, mode=mode)
        return {
            "kind": "object",
            "title": title or label or type(obj).__name__,
            "mode": mode,
            "object_type": type(obj).__name__,
            "metadata": metadata,
            "sections": sections,
        }

    def export_diff(
        self,
        before: Any,
        after: Any,
        *,
        title: str | None = None,
        labels: tuple[str, str] = ("before", "after"),
        extra_metadata: list[tuple[str, str]] | None = None,
    ) -> dict[str, Any]:
        metadata = [
            {"key": "left", "value": type(before).__name__},
            {"key": "right", "value": type(after).__name__},
        ]
        if extra_metadata:
            metadata.extend({"key": key, "value": value} for key, value in extra_metadata)
        sections = self._diff_sections(before, after, labels=labels)
        return {
            "kind": "diff",
            "title": title or "Diff",
            "labels": list(labels),
            "metadata": metadata,
            "sections": sections,
        }

    def _metadata(self, obj: Any, *, label: str | None) -> list[dict[str, str]]:
        items: list[tuple[str, str]] = []
        if label:
            items.append(("label", label))
        if self.config.show_type:
            items.append(("type", type(obj).__name__))
        if np is not None and isinstance(obj, np.ndarray):
            items.extend(
                [
                    ("shape", " x ".join(str(x) for x in obj.shape)),
                    ("dtype", str(obj.dtype)),
                    ("size", str(obj.size)),
                ]
            )
        elif pd is not None and isinstance(obj, pd.DataFrame):
            items.extend(
                [
                    ("shape", f"{obj.shape[0]} rows x {obj.shape[1]} cols"),
                    ("memory", _human_bytes(int(obj.memory_usage(deep=True).sum()))),
                ]
            )
        elif pd is not None and isinstance(obj, pd.Series):
            items.extend(
                [
                    ("length", str(len(obj))),
                    ("dtype", str(obj.dtype)),
                    ("memory", _human_bytes(int(obj.memory_usage(deep=True)))),
                ]
            )
        elif isinstance(obj, Mapping):
            items.append(("size", str(len(obj))))
        elif isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray)):
            items.append(("size", str(len(obj))))
        elif isinstance(obj, (str, bytes, bytearray)):
            items.append(("length", str(len(obj))))
        return [{"key": key, "value": value} for key, value in items]

    def _sections_for(self, obj: Any, *, mode: str) -> list[dict[str, Any]]:
        if mode == "summary":
            return self._summary_sections(obj)
        return self._preview_sections(obj)

    def _preview_sections(self, obj: Any) -> list[dict[str, Any]]:
        if np is not None and isinstance(obj, np.ndarray):
            return self._numpy_preview(obj)
        if pd is not None:
            if isinstance(obj, pd.DataFrame):
                return self._dataframe_preview(obj)
            if isinstance(obj, pd.Series):
                return self._series_preview(obj)
        if is_dataclass(obj) and not isinstance(obj, type):
            return self._mapping_preview({field.name: getattr(obj, field.name) for field in fields(obj)})
        if isinstance(obj, Mapping):
            return self._mapping_preview(obj)
        if isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray)):
            return self._sequence_preview(obj)
        return [{"type": "code", "language": "python", "content": _truncate(repr(obj), self.config.max_string)}]

    def _summary_sections(self, obj: Any) -> list[dict[str, Any]]:
        if np is not None and isinstance(obj, np.ndarray):
            return self._numpy_summary(obj)
        if pd is not None:
            if isinstance(obj, pd.DataFrame):
                return self._dataframe_summary(obj)
            if isinstance(obj, pd.Series):
                return self._series_summary(obj)
        if isinstance(obj, Mapping):
            rows = []
            for index, (key, value) in enumerate(obj.items()):
                if index >= self.config.max_items:
                    break
                rows.append([str(key), type(value).__name__])
            return [
                {"type": "table", "title": "Keys", "columns": ["key", "kind"], "rows": rows},
                {"type": "text", "content": f"items={len(obj)}"},
            ]
        if isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray)):
            sample = [type(value).__name__ for value in obj[: self.config.max_items]]
            return [{"type": "text", "content": f"items={len(obj)} | sample types={sample}"}]
        return [{"type": "code", "language": "python", "content": _truncate(repr(obj), self.config.max_string)}]

    def _mapping_preview(self, obj: Mapping[Any, Any]) -> list[dict[str, Any]]:
        rows = []
        items = obj.items()
        if self.config.sort_keys:
            items = sorted(items, key=lambda item: str(item[0]))
        for index, (key, value) in enumerate(items):
            if index >= self.config.max_items:
                rows.append(["…", f"{len(obj) - self.config.max_items} more items"])
                break
            rows.append([_truncate(str(key), self.config.max_cell_length), _preview_value(value, self.config)])
        return [{"type": "table", "title": "Mapping", "columns": ["key", "value"], "rows": rows}]

    def _sequence_preview(self, obj: Sequence[Any]) -> list[dict[str, Any]]:
        rows = []
        for index, value in enumerate(obj[: self.config.max_items]):
            rows.append([str(index), _preview_value(value, self.config)])
        if len(obj) > self.config.max_items:
            rows.append(["…", f"{len(obj) - self.config.max_items} more items"])
        return [{"type": "table", "title": "Sequence", "columns": ["index", "value"], "rows": rows}]

    def _numpy_preview(self, array: Any) -> list[dict[str, Any]]:
        sections: list[dict[str, Any]] = []
        if self.config.show_stats and array.size and np is not None and np.issubdtype(array.dtype, np.number):
            flat = array.reshape(-1)
            sections.append(
                {
                    "type": "stats",
                    "items": [
                        {"label": "min", "value": _summarize_scalar(np.min(flat))},
                        {"label": "max", "value": _summarize_scalar(np.max(flat))},
                        {"label": "mean", "value": _summarize_scalar(np.mean(flat))},
                    ],
                }
            )
        if array.ndim == 1:
            rows = [[str(index), _summarize_scalar(value)] for index, value in enumerate(array[: self.config.max_array_rows].tolist())]
            sections.append({"type": "table", "title": "Array", "columns": ["index", "value"], "rows": rows})
        elif array.ndim >= 2:
            rows = min(array.shape[0], self.config.max_array_rows)
            cols = min(array.shape[1], self.config.max_array_cols)
            preview = array[:rows, :cols]
            table_rows = []
            for row_index in range(rows):
                table_rows.append([str(row_index)] + [_summarize_scalar(value) for value in preview[row_index].tolist()])
            sections.append(
                {
                    "type": "table",
                    "title": "Array",
                    "columns": ["row"] + [str(index) for index in range(cols)],
                    "rows": table_rows,
                }
            )
            sections.append({"type": "text", "content": f"showing first {rows} row(s) and {cols} column(s)"})
        else:
            sections.append({"type": "code", "language": "python", "content": _truncate(repr(array.tolist()), self.config.max_string)})
        return sections

    def _numpy_summary(self, array: Any) -> list[dict[str, Any]]:
        items = [
            {"label": "shape", "value": str(array.shape)},
            {"label": "ndim", "value": str(array.ndim)},
            {"label": "dtype", "value": str(array.dtype)},
        ]
        if self.config.show_stats and array.size and np is not None and np.issubdtype(array.dtype, np.number):
            flat = array.reshape(-1)
            items.extend(
                [
                    {"label": "min", "value": _summarize_scalar(np.min(flat))},
                    {"label": "max", "value": _summarize_scalar(np.max(flat))},
                    {"label": "mean", "value": _summarize_scalar(np.mean(flat))},
                ]
            )
        sample = array.reshape(-1)[: self.config.max_items].tolist() if array.size else []
        return [
            {"type": "stats", "items": items},
            {"type": "code", "language": "python", "content": f"sample={sample}"},
        ]

    def _dataframe_preview(self, frame: Any) -> list[dict[str, Any]]:
        visible = frame.iloc[: self.config.max_dataframe_rows, : self.config.max_dataframe_cols]
        columns = []
        if self.config.show_index:
            columns.append(frame.index.name or "index")
        for column in visible.columns:
            title = str(column)
            if self.config.show_dtypes:
                title = f"{title} ({frame[column].dtype})"
            columns.append(title)
        rows = []
        for index, row in visible.iterrows():
            current = []
            if self.config.show_index:
                current.append(_truncate(str(index), self.config.max_cell_length))
            current.extend(_truncate(_summarize_scalar(value), self.config.max_cell_length) for value in row.tolist())
            rows.append(current)
        sections: list[dict[str, Any]] = [{"type": "table", "title": "DataFrame", "columns": columns, "rows": rows}]
        sections.append({"type": "text", "content": f"showing {len(visible)} of {len(frame)} rows and {len(visible.columns)} of {len(frame.columns)} columns"})
        if self.config.show_stats:
            numeric = frame.select_dtypes(include="number")
            if not numeric.empty:
                sections.append({"type": "text", "content": f"numeric columns={numeric.shape[1]} | nulls={int(frame.isna().sum().sum())}"})
        return sections

    def _dataframe_summary(self, frame: Any) -> list[dict[str, Any]]:
        visible_columns = list(frame.columns[: self.config.max_dataframe_cols])
        rows = []
        for column in visible_columns:
            rows.append([str(column), str(frame[column].dtype), str(int(frame[column].isna().sum()))])
        sections = [
            {"type": "table", "title": "Schema", "columns": ["column", "dtype", "nulls"], "rows": rows},
            {"type": "text", "content": f"rows={len(frame)} | columns={len(frame.columns)} | memory={_human_bytes(int(frame.memory_usage(deep=True).sum()))}"},
        ]
        numeric = frame.select_dtypes(include="number")
        if self.config.show_stats and not numeric.empty:
            sections.append({"type": "text", "content": f"numeric columns={numeric.shape[1]} | total nulls={int(frame.isna().sum().sum())}"})
        return sections

    def _series_preview(self, series: Any) -> list[dict[str, Any]]:
        visible = series.iloc[: self.config.max_series_rows]
        columns = []
        if self.config.show_index:
            columns.append(series.index.name or "index")
        columns.append(series.name or "value")
        rows = []
        for index, value in visible.items():
            current = []
            if self.config.show_index:
                current.append(_truncate(str(index), self.config.max_cell_length))
            current.append(_truncate(_summarize_scalar(value), self.config.max_cell_length))
            rows.append(current)
        sections: list[dict[str, Any]] = [{"type": "table", "title": "Series", "columns": columns, "rows": rows}]
        sections.append({"type": "text", "content": f"showing {len(visible)} of {len(series)} rows"})
        if self.config.show_stats and pd is not None and pd.api.types.is_numeric_dtype(series.dtype):
            sections.append({"type": "text", "content": f"min={series.min():.4g} | max={series.max():.4g} | mean={series.mean():.4g}"})
        return sections

    def _series_summary(self, series: Any) -> list[dict[str, Any]]:
        sections = [{"type": "text", "content": f"length={len(series)} | dtype={series.dtype} | nulls={int(series.isna().sum())}"}]
        if self.config.show_stats and pd is not None and pd.api.types.is_numeric_dtype(series.dtype) and len(series):
            sections.append({"type": "text", "content": f"min={series.min():.4g} | max={series.max():.4g} | mean={series.mean():.4g}"})
        sample = [_summarize_scalar(value) for value in series.iloc[: self.config.max_items].tolist()]
        sections.append({"type": "code", "language": "python", "content": f"sample={sample}"})
        return sections

    def _diff_sections(self, before: Any, after: Any, *, labels: tuple[str, str]) -> list[dict[str, Any]]:
        if np is not None and isinstance(before, np.ndarray) and isinstance(after, np.ndarray):
            return self._numpy_diff(before, after, labels=labels)
        if pd is not None:
            if isinstance(before, pd.DataFrame) and isinstance(after, pd.DataFrame):
                return self._dataframe_diff(before, after, labels=labels)
            if isinstance(before, pd.Series) and isinstance(after, pd.Series):
                return self._series_diff(before, after, labels=labels)
        if isinstance(before, Mapping) and isinstance(after, Mapping):
            return self._mapping_diff(before, after, labels=labels)
        return [
            {
                "type": "table",
                "title": "Diff",
                "columns": ["field", "status", labels[0], labels[1]],
                "rows": [["value", "changed" if not _values_equal(before, after) else "unchanged", _preview_value(before, self.config), _preview_value(after, self.config)]],
            }
        ]

    def _mapping_diff(self, before: Mapping[Any, Any], after: Mapping[Any, Any], *, labels: tuple[str, str]) -> list[dict[str, Any]]:
        before_keys = set(before)
        after_keys = set(after)
        removed = sorted(before_keys - after_keys, key=str)
        added = sorted(after_keys - before_keys, key=str)
        changed = [key for key in sorted(before_keys & after_keys, key=str) if not _values_equal(before[key], after[key])]
        rows = []
        for key in changed[: self.config.diff_sample_size]:
            rows.append([str(key), "changed", _preview_value(before[key], self.config), _preview_value(after[key], self.config)])
        for key in added[: self.config.diff_sample_size]:
            rows.append([str(key), "added", "—", _preview_value(after[key], self.config)])
        for key in removed[: self.config.diff_sample_size]:
            rows.append([str(key), "removed", _preview_value(before[key], self.config), "—"])
        return [
            {"type": "table", "title": "Diff", "columns": ["key", "status", labels[0], labels[1]], "rows": rows},
            {"type": "text", "content": f"changed={len(changed)} | added={len(added)} | removed={len(removed)}"},
        ]

    def _numpy_diff(self, before: Any, after: Any, *, labels: tuple[str, str]) -> list[dict[str, Any]]:
        shared_shape = tuple(min(left, right) for left, right in zip(before.shape, after.shape))
        before_view = before[tuple(slice(0, amount) for amount in shared_shape)]
        after_view = after[tuple(slice(0, amount) for amount in shared_shape)]
        changed_positions = np.argwhere(before_view != after_view)
        rows = []
        for position in changed_positions[: self.config.diff_sample_size]:
            index = tuple(int(x) for x in position.tolist())
            before_value = before_view[index]
            after_value = after_view[index]
            delta = ""
            if np.issubdtype(type(before_value), np.number) and np.issubdtype(type(after_value), np.number):
                delta = _summarize_scalar(after_value - before_value)
            rows.append([str(index), "changed", _summarize_scalar(before_value), _summarize_scalar(after_value), delta])
        sections = [
            {"type": "table", "title": "Array Diff", "columns": ["index", "status", labels[0], labels[1], "delta"], "rows": rows},
            {"type": "text", "content": f"shape {before.shape} -> {after.shape} | dtype {before.dtype} -> {after.dtype}"},
            {"type": "text", "content": f"changed cells={len(changed_positions)}"},
        ]
        if before_view.size and np.issubdtype(before_view.dtype, np.number) and np.issubdtype(after_view.dtype, np.number):
            sections.append({"type": "text", "content": f"max |delta|={_summarize_scalar(np.max(np.abs(after_view - before_view)))}"})
        return sections

    def _dataframe_diff(self, before: Any, after: Any, *, labels: tuple[str, str]) -> list[dict[str, Any]]:
        before_columns = set(before.columns)
        after_columns = set(after.columns)
        before_index = set(before.index)
        after_index = set(after.index)
        common_columns = [column for column in before.columns if column in after_columns]
        common_index = [index for index in before.index if index in after_index]
        before_common = before.loc[common_index, common_columns]
        after_common = after.loc[common_index, common_columns]
        diff_mask = before_common.ne(after_common) | (before_common.isna() ^ after_common.isna())
        changed_locations = [(row, column) for row, series in diff_mask.iterrows() for column, changed in series.items() if bool(changed)]
        rows = []
        for row, column in changed_locations[: self.config.diff_sample_size]:
            rows.append([f"{row} / {column}", "changed", _preview_value(before_common.at[row, column], self.config), _preview_value(after_common.at[row, column], self.config)])
        return [
            {"type": "table", "title": "DataFrame Diff", "columns": ["row / col", "status", labels[0], labels[1]], "rows": rows},
            {"type": "text", "content": f"changed cells={len(changed_locations)} | added cols={len(after_columns - before_columns)} | removed cols={len(before_columns - after_columns)}"},
            {"type": "text", "content": f"added rows={len(after_index - before_index)} | removed rows={len(before_index - after_index)}"},
        ]

    def _series_diff(self, before: Any, after: Any, *, labels: tuple[str, str]) -> list[dict[str, Any]]:
        before_index = set(before.index)
        after_index = set(after.index)
        common_index = [index for index in before.index if index in after_index]
        changed = [index for index in common_index if not _values_equal(before.loc[index], after.loc[index])]
        added = sorted(after_index - before_index, key=str)
        removed = sorted(before_index - after_index, key=str)
        rows = []
        for index in changed[: self.config.diff_sample_size]:
            rows.append([str(index), "changed", _preview_value(before.loc[index], self.config), _preview_value(after.loc[index], self.config)])
        for index in added[: self.config.diff_sample_size]:
            rows.append([str(index), "added", "—", _preview_value(after.loc[index], self.config)])
        for index in removed[: self.config.diff_sample_size]:
            rows.append([str(index), "removed", _preview_value(before.loc[index], self.config), "—"])
        return [
            {"type": "table", "title": "Series Diff", "columns": ["index", "status", labels[0], labels[1]], "rows": rows},
            {"type": "text", "content": f"changed={len(changed)} | added={len(added)} | removed={len(removed)}"},
        ]


def _values_equal(left: Any, right: Any) -> bool:
    if pd is not None:
        if isinstance(left, (pd.DataFrame, pd.Series)) and isinstance(right, type(left)):
            return bool(left.equals(right))
    if np is not None and isinstance(left, np.ndarray) and isinstance(right, np.ndarray):
        return bool(np.array_equal(left, right, equal_nan=True))
    try:
        result = left == right
    except Exception:
        return repr(left) == repr(right)
    if isinstance(result, bool):
        return result
    if np is not None and isinstance(result, np.bool_):
        return bool(result)
    return False


def _preview_value(value: Any, config: PrintConfig) -> str:
    if np is not None and isinstance(value, np.ndarray):
        return f"ndarray(shape={value.shape}, dtype={value.dtype})"
    if pd is not None:
        if isinstance(value, pd.DataFrame):
            return f"DataFrame(shape={value.shape})"
        if isinstance(value, pd.Series):
            return f"Series(len={len(value)}, dtype={value.dtype})"
    if isinstance(value, Mapping):
        return f"{type(value).__name__}({len(value)} items)"
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return f"{type(value).__name__}({len(value)} items)"
    return _truncate(repr(value), config.max_string)


def _truncate(value: str, limit: int) -> str:
    if len(value) <= limit:
        return value
    return value[: max(0, limit - 1)] + "…"


def _summarize_scalar(value: Any) -> str:
    if isinstance(value, float):
        return f"{value:.4g}"
    return str(value)


def _human_bytes(size: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    amount = float(size)
    for unit in units:
        if amount < 1024 or unit == units[-1]:
            return f"{amount:.1f} {unit}"
        amount /= 1024
    return f"{size} B"
