from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from rich.console import Group
from rich.table import Table
from rich.text import Text

try:
    import numpy as np
except ImportError:  # pragma: no cover - optional dependency
    np = None

try:
    import pandas as pd
except ImportError:  # pragma: no cover - optional dependency
    pd = None

from .config import PrintConfig
from .renderers import render_metadata, summarize_scalar, truncate


class DiffRenderer:
    def __init__(self, config: PrintConfig) -> None:
        self.config = config

    def render(
        self,
        before: Any,
        after: Any,
        labels: tuple[str, str] = ("before", "after"),
        extra_metadata: list[tuple[str, str]] | None = None,
    ):
        metadata = list(extra_metadata or [])
        metadata.extend(
            [
                ("left", type(before).__name__),
                ("right", type(after).__name__),
            ]
        )
        body = self._render_body(before, after, labels=labels)
        if self.config.show_header:
            return Group(render_metadata(metadata, self.config), body)
        return body

    def _render_body(self, before: Any, after: Any, labels: tuple[str, str]):
        if np is not None and isinstance(before, np.ndarray) and isinstance(after, np.ndarray):
            return self._render_numpy_diff(before, after, labels)
        if pd is not None:
            if isinstance(before, pd.DataFrame) and isinstance(after, pd.DataFrame):
                return self._render_dataframe_diff(before, after, labels)
            if isinstance(before, pd.Series) and isinstance(after, pd.Series):
                return self._render_series_diff(before, after, labels)
        if isinstance(before, Mapping) and isinstance(after, Mapping):
            return self._render_mapping_diff(before, after, labels)
        return self._render_generic_diff(before, after, labels)

    def _render_mapping_diff(self, before: Mapping[Any, Any], after: Mapping[Any, Any], labels: tuple[str, str]):
        table = self._diff_table(labels)
        before_keys = set(before)
        after_keys = set(after)

        removed = sorted(before_keys - after_keys, key=str)
        added = sorted(after_keys - before_keys, key=str)
        changed = [key for key in sorted(before_keys & after_keys, key=str) if not _values_equal(before[key], after[key])]

        for key in changed[: self.config.diff_sample_size]:
            table.add_row(
                str(key),
                _status_text("changed", self.config),
                _value_preview(before[key], self.config),
                _value_preview(after[key], self.config),
            )
        for key in added[: self.config.diff_sample_size]:
            table.add_row(
                str(key),
                _status_text("added", self.config),
                "—",
                _value_preview(after[key], self.config),
            )
        for key in removed[: self.config.diff_sample_size]:
            table.add_row(
                str(key),
                _status_text("removed", self.config),
                _value_preview(before[key], self.config),
                "—",
            )

        notes = [
            Text(
                f"changed={len(changed)} | added={len(added)} | removed={len(removed)}",
                style=self.config.resolve_style(self.config.summary_style),
            )
        ]
        if len(changed) + len(added) + len(removed) == 0:
            notes.append(Text("objects are equal", style=self.config.resolve_style(self.config.summary_style)))
        return Group(table, *notes)

    def _render_numpy_diff(self, before: Any, after: Any, labels: tuple[str, str]):
        table = self._diff_table(labels, key_title="index", include_delta=True)
        notes = [
            Text(
                f"shape {before.shape} -> {after.shape} | dtype {before.dtype} -> {after.dtype}",
                style=self.config.resolve_style(self.config.summary_style),
            )
        ]

        if before.shape != after.shape:
            notes.append(Text("arrays differ in shape; showing shared-region changes only", style=self.config.resolve_style(self.config.summary_style)))

        shared_shape = tuple(min(left, right) for left, right in zip(before.shape, after.shape))
        if len(shared_shape) != before.ndim or len(shared_shape) != after.ndim:
            return Group(table, *notes)

        before_view = before[tuple(slice(0, amount) for amount in shared_shape)]
        after_view = after[tuple(slice(0, amount) for amount in shared_shape)]
        diff_mask = before_view != after_view
        changed_positions = np.argwhere(diff_mask)

        for position in changed_positions[: self.config.diff_sample_size]:
            index = tuple(int(x) for x in position.tolist())
            before_value = before_view[index]
            after_value = after_view[index]
            delta = ""
            if _is_numpy_numeric_pair(before_value, after_value):
                delta = summarize_scalar(after_value - before_value)
            table.add_row(
                str(index),
                _status_text("changed", self.config),
                summarize_scalar(before_value),
                summarize_scalar(after_value),
                delta,
            )

        notes.append(
            Text(
                f"changed cells={len(changed_positions)}",
                style=self.config.resolve_style(self.config.summary_style),
            )
        )
        if _is_numpy_numeric_array(before_view) and _is_numpy_numeric_array(after_view) and before_view.size:
            max_abs = np.max(np.abs(after_view - before_view))
            notes.append(Text(f"max |delta|={summarize_scalar(max_abs)}", style=self.config.resolve_style(self.config.summary_style)))
        return Group(table, *notes)

    def _render_dataframe_diff(self, before: Any, after: Any, labels: tuple[str, str]):
        table = self._diff_table(labels, key_title="row / col")
        before_columns = set(before.columns)
        after_columns = set(after.columns)
        before_index = set(before.index)
        after_index = set(after.index)

        added_columns = sorted(after_columns - before_columns, key=str)
        removed_columns = sorted(before_columns - after_columns, key=str)
        added_rows = sorted(after_index - before_index, key=str)
        removed_rows = sorted(before_index - after_index, key=str)

        common_columns = [column for column in before.columns if column in after_columns]
        common_index = [index for index in before.index if index in after_index]
        before_common = before.loc[common_index, common_columns]
        after_common = after.loc[common_index, common_columns]
        diff_mask = before_common.ne(after_common) | (before_common.isna() ^ after_common.isna())
        changed_locations = [(row, column) for row, series in diff_mask.iterrows() for column, changed in series.items() if bool(changed)]

        for row, column in changed_locations[: self.config.diff_sample_size]:
            table.add_row(
                f"{row} / {column}",
                _status_text("changed", self.config),
                _value_preview(before_common.at[row, column], self.config),
                _value_preview(after_common.at[row, column], self.config),
            )
        for column in added_columns[: self.config.diff_sample_size]:
            table.add_row(str(column), _status_text("added", self.config), "column", "column")
        for column in removed_columns[: self.config.diff_sample_size]:
            table.add_row(str(column), _status_text("removed", self.config), "column", "—")

        notes = [
            Text(
                f"changed cells={len(changed_locations)} | added cols={len(added_columns)} | removed cols={len(removed_columns)}",
                style=self.config.resolve_style(self.config.summary_style),
            ),
            Text(
                f"added rows={len(added_rows)} | removed rows={len(removed_rows)}",
                style=self.config.resolve_style(self.config.summary_style),
            ),
        ]
        return Group(table, *notes)

    def _render_series_diff(self, before: Any, after: Any, labels: tuple[str, str]):
        table = self._diff_table(labels, key_title="index")
        before_index = set(before.index)
        after_index = set(after.index)
        common_index = [index for index in before.index if index in after_index]
        changed = [index for index in common_index if not _values_equal(before.loc[index], after.loc[index])]
        added = sorted(after_index - before_index, key=str)
        removed = sorted(before_index - after_index, key=str)

        for index in changed[: self.config.diff_sample_size]:
            table.add_row(
                str(index),
                _status_text("changed", self.config),
                _value_preview(before.loc[index], self.config),
                _value_preview(after.loc[index], self.config),
            )
        for index in added[: self.config.diff_sample_size]:
            table.add_row(str(index), _status_text("added", self.config), "—", _value_preview(after.loc[index], self.config))
        for index in removed[: self.config.diff_sample_size]:
            table.add_row(str(index), _status_text("removed", self.config), _value_preview(before.loc[index], self.config), "—")

        notes = [
            Text(
                f"changed={len(changed)} | added={len(added)} | removed={len(removed)}",
                style=self.config.resolve_style(self.config.summary_style),
            )
        ]
        return Group(table, *notes)

    def _render_generic_diff(self, before: Any, after: Any, labels: tuple[str, str]):
        table = self._diff_table(labels, key_title="field")
        status = "unchanged" if _values_equal(before, after) else "changed"
        table.add_row(
            "value",
            _status_text(status, self.config),
            _value_preview(before, self.config),
            _value_preview(after, self.config),
        )
        return table

    def _diff_table(self, labels: tuple[str, str], key_title: str = "key", include_delta: bool = False) -> Table:
        table = Table(
            show_header=True,
            header_style=self.config.resolve_style(self.config.label_style),
            expand=True,
            padding=(0, 1),
        )
        table.add_column(key_title, style=self.config.resolve_style(self.config.metadata_key_style), no_wrap=True)
        table.add_column("status", no_wrap=True)
        table.add_column(labels[0])
        table.add_column(labels[1])
        if include_delta:
            table.add_column("delta", justify="right")
        return table


def _status_text(status: str, config: PrintConfig) -> Text:
    if status == "added":
        style = config.resolve_style("diff.added")
    elif status == "removed":
        style = config.resolve_style("diff.removed")
    elif status == "changed":
        style = config.resolve_style("diff.changed")
    else:
        style = config.resolve_style(config.summary_style)
    return Text(status, style=style)


def _value_preview(value: Any, config: PrintConfig) -> str:
    if np is not None and isinstance(value, np.ndarray):
        return f"ndarray(shape={value.shape}, dtype={value.dtype})"
    if pd is not None:
        if isinstance(value, pd.DataFrame):
            return f"DataFrame(shape={value.shape})"
        if isinstance(value, pd.Series):
            return f"Series(len={len(value)}, dtype={value.dtype})"
    if isinstance(value, Mapping):
        return f"{type(value).__name__}({len(value)} items)"
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return f"{type(value).__name__}({len(value)} items)"
    return truncate(repr(value), config.max_string)


def _values_equal(left: Any, right: Any) -> bool:
    if pd is not None:
        if isinstance(left, (pd.DataFrame, pd.Series)) and isinstance(right, type(left)):
            return bool(left.equals(right))
    if np is not None and isinstance(left, np.ndarray) and isinstance(right, np.ndarray):
        return bool(np.array_equal(left, right, equal_nan=True))
    try:
        result = left == right
    except Exception:
        return repr(left) == repr(right)
    if isinstance(result, bool):
        return result
    if np is not None and isinstance(result, np.bool_):
        return bool(result)
    return False


def _is_numpy_numeric_array(value: Any) -> bool:
    return np is not None and isinstance(value, np.ndarray) and np.issubdtype(value.dtype, np.number)


def _is_numpy_numeric_pair(left: Any, right: Any) -> bool:
    if np is None:
        return False
    return np.isscalar(left) and np.isscalar(right) and np.issubdtype(type(left), np.number) and np.issubdtype(type(right), np.number)
