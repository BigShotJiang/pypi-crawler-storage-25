from __future__ import annotations

import unittest

import numpy as np
import pandas as pd
from rich.console import Console
from rich.text import Text

from bakprint import DebugPrinter, PrintConfig, bak_formatx
from bakprint.structured import diff_structured, to_structured


class BakprintTests(unittest.TestCase):
    def render_to_text(self, obj, **overrides):
        console = Console(record=True, width=100)
        printer = DebugPrinter(config=PrintConfig().with_overrides(**overrides), console=console)
        console.print(printer.format(obj))
        return console.export_text()

    def test_mapping_render_contains_keys(self):
        text = self.render_to_text({"alpha": 1, "beta": [1, 2, 3]})
        self.assertIn("alpha", text)
        self.assertIn("beta", text)

    def test_sequence_render_contains_indices(self):
        text = self.render_to_text(["x", "y", "z"])
        self.assertIn("0", text)
        self.assertIn("'x'", text)

    def test_long_string_is_truncated(self):
        text = self.render_to_text("a" * 80, max_string=12)
        self.assertIn("…", text)

    def test_multiple_labels_length_must_match(self):
        printer = DebugPrinter()
        with self.assertRaises(ValueError):
            printer.print(1, 2, labels=["only-one"])

    def test_custom_renderer_registration(self):
        class Widget:
            def __init__(self, name):
                self.name = name

        console = Console(record=True, width=100)
        printer = DebugPrinter(console=console)
        printer.register(Widget, lambda obj, config: Text(obj.name, style=config.resolve_style("accent")))
        console.print(printer.format(Widget("special-widget")))
        text = console.export_text()
        self.assertIn("special-widget", text)

    def test_marching_dashes_frame_renders(self):
        console = Console(record=True, width=100)
        printer = DebugPrinter(
            config=PrintConfig(border_effect="marching_dashes"),
            console=console,
        )
        console.print(printer.format({"alpha": 1}, frame=2))
        text = console.export_text()
        self.assertIn("alpha", text)

    def test_marching_dashes_falls_back_to_ascii_boxes(self):
        console = Console(record=True, width=100, safe_box=True)
        printer = DebugPrinter(
            config=PrintConfig(border_effect="marching_dashes"),
            console=console,
        )
        console.print(printer.format({"alpha": 1}, frame=1))
        text = console.export_text()
        self.assertIn("+", text)

    def test_marching_dashes_without_tty_prints_static_frame(self):
        console = Console(record=True, width=100)
        printer = DebugPrinter(
            config=PrintConfig(border_effect="marching_dashes"),
            console=console,
        )
        printer.animate({"alpha": 1}, title="Static Fallback")
        text = console.export_text()
        self.assertIn("Static Fallback", text)

    def test_trace_metadata_includes_caller(self):
        console = Console(record=True, width=100)
        printer = DebugPrinter(config=PrintConfig(show_trace=True), console=console)
        console.print(printer.format({"alpha": 1}))
        text = console.export_text()
        self.assertIn("test_bakprint.py", text)
        self.assertIn("test_trace_metadata_includes_caller", text)

    def test_dataframe_summary_mode_uses_schema_not_rows(self):
        dataframe = pd.DataFrame({"city": ["Beirut", "Paris"], "orders": [1, 2]})
        console = Console(record=True, width=100)
        printer = DebugPrinter(config=PrintConfig(display_mode="summary"), console=console)
        console.print(printer.format(dataframe))
        text = console.export_text()
        self.assertIn("column", text)
        self.assertIn("rows=2", text)
        self.assertNotIn("Beirut", text)

    def test_mapping_diff_reports_added_removed_and_changed(self):
        console = Console(record=True, width=120)
        printer = DebugPrinter(console=console)
        console.print(printer.format_diff({"a": 1, "b": 2}, {"b": 3, "c": 4}, title="Diff"))
        text = console.export_text()
        self.assertIn("changed", text)
        self.assertIn("added", text)
        self.assertIn("removed", text)

    def test_numpy_diff_reports_changed_cells(self):
        console = Console(record=True, width=120)
        printer = DebugPrinter(console=console)
        left = np.array([[1, 2], [3, 4]])
        right = np.array([[1, 9], [3, 7]])
        console.print(printer.format_diff(left, right))
        text = console.export_text()
        self.assertIn("changed cells=2", text)
        self.assertIn("(0, 1)", text)

    def test_series_diff_reports_index_changes(self):
        console = Console(record=True, width=120)
        printer = DebugPrinter(console=console)
        left = pd.Series([10, 20], index=["a", "b"])
        right = pd.Series([10, 30, 40], index=["a", "b", "c"])
        console.print(printer.format_diff(left, right))
        text = console.export_text()
        self.assertIn("changed=1", text)
        self.assertIn("added=1", text)
        self.assertIn("b", text)

    def test_structured_preview_contains_sections(self):
        payload = to_structured({"alpha": 1, "beta": 2}, title="Preview")
        self.assertEqual(payload["kind"], "object")
        self.assertEqual(payload["title"], "Preview")
        self.assertTrue(payload["sections"])

    def test_bak_formatx_helper_uses_renamed_api(self):
        console = Console(record=True, width=100)
        console.print(bak_formatx({"alpha": 1}, title="Helper"))
        text = console.export_text()
        self.assertIn("Helper", text)
        self.assertIn("alpha", text)

    def test_structured_diff_contains_table_section(self):
        payload = diff_structured({"alpha": 1}, {"alpha": 2}, title="Diff")
        self.assertEqual(payload["kind"], "diff")
        self.assertEqual(payload["sections"][0]["type"], "table")


if __name__ == "__main__":
    unittest.main()
