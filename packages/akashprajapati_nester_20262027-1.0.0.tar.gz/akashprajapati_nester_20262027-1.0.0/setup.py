from setuptools import setup

setup(
    name='akashprajapati_nester_20262027',
    version='1.0.0',
    py_modules=['nester'],
    author='akash',
    author_email='917275363128kartik@gmail.com',
    url='http://www.headfirstlabs.com',
    description='A Simple printer of nested lists',
) 