#!/usr/bin/env python3
"""
Setup script for Sandai Operator SDK
"""

from setuptools import setup, find_namespace_packages
from pathlib import Path

# Read README
readme_path = Path(__file__).parent / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""

setup(
    name="sandai-operator-sdk",
    version="0.4.13",
    description="A Python SDK for building high-performance, asynchronous batch processing operators",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Sandai Team",
    author_email="dev@sand.ai",
    url="https://github.com/world-sim-dev/sandai-data-project",
    packages=find_namespace_packages(include=["sandai.*"]),
    python_requires=">=3.8",
    install_requires=[
        "pydantic>=2.0.0",
        "requests>=2.25.0",
        "watchdog>=2.1.0",
        "celery>=5.2.0",
        "redis>=4.0.0",
        "msgpack>=1.0.0",
        "boto3>=1.26.0",
        "oss2",
        "python-dotenv",
        "sentry-sdk",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0.0",
            "pytest-asyncio>=0.18.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
            "mypy>=0.950",
            "build>=0.8.0",
            "twine>=4.0.0",
        ],
        "examples": [
            "opencv-python>=4.5.0",
            "ffmpeg-python>=0.2.0",
        ]
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Distributed Computing",
    ],
    keywords="batch processing, async, operator, data processing, pipeline",
    project_urls={
        "Bug Reports": "https://github.com/world-sim-dev/sandai-data-project/issues",
        "Source": "https://github.com/world-sim-dev/sandai-data-project",
        "Documentation": "https://sandai-data-project.readthedocs.io/",
    },
    entry_points={
        "console_scripts": [
            "sdrun=sandai.operator.supervisor:main",
        ]
    },
)
