from __future__ import annotations

from typing import Any

from munch import munchify

from pywisetransfer import Client
from pywisetransfer.base import Base
from pywisetransfer.endpoint import WiseEndpoint


class ProfileService(Base):
    list = WiseEndpoint(path="/v1/profiles")
    get = WiseEndpoint(path="/v1/profiles/{profile_id}")


class Profile:
    def __init__(self, client: Client):
        self.service = ProfileService(client=client)

    def list(self, type: str | None = None) -> list[Any]:
        profiles: list[Any] = munchify(self.service.list())
        if type is None:
            return profiles
        return [p for p in profiles if p.type == type]

    def get(self, profile_id: str) -> Any:
        return munchify(self.service.get(profile_id=profile_id))
