"""Internal helpers for extracting usage data from provider SDK responses.

Supports the three common response shapes:

* Anthropic Messages — ``usage.input_tokens`` / ``usage.output_tokens``
* OpenAI Responses API — ``usage.input_tokens`` / ``usage.output_tokens``
* OpenAI Chat Completions — ``usage.prompt_tokens`` / ``usage.completion_tokens``

The extractor accepts either a Pydantic model (duck-typed via ``model_dump``)
or a plain ``dict`` with the same shape.
"""

from typing import Any


def extract_usage(response: Any) -> tuple[str, int, int]:
    """Extract ``(model, tokens_in, tokens_out)`` from a provider response.

    @param response - An Anthropic or OpenAI SDK response object (Pydantic
        model) or a dict with the same shape.
    @returns Tuple of canonical model name, input tokens, output tokens.
    @throws ValueError if the response shape is unrecognized or the ``model``
        field is missing.
    """
    if hasattr(response, "model_dump"):
        data = response.model_dump(mode="json")
    elif isinstance(response, dict):
        data = response
    else:
        raise ValueError(
            "response must be a Pydantic model or dict — got "
            f"{type(response).__name__}"
        )

    model = data.get("model")
    if not isinstance(model, str) or not model.strip():
        raise ValueError("response is missing a non-empty 'model' field")

    usage = data.get("usage")
    if not isinstance(usage, dict):
        raise ValueError("response is missing a 'usage' object")

    if "input_tokens" in usage and "output_tokens" in usage:
        return model, int(usage["input_tokens"]), int(usage["output_tokens"])

    if "prompt_tokens" in usage and "completion_tokens" in usage:
        return model, int(usage["prompt_tokens"]), int(usage["completion_tokens"])

    raise ValueError(
        "unrecognized usage shape — expected Anthropic Messages, OpenAI "
        "Responses, or OpenAI Chat Completions (usage.input_tokens/"
        "output_tokens or usage.prompt_tokens/completion_tokens)"
    )
