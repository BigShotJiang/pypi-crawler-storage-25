from __future__ import annotations

import hashlib
import json
import os
import re
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .lexer import CISTCompiler
from ..workspace.templates import COOKBOOK


KNOWN_NURSERY_ALIASES = {
    "capital": "capital",
    "farm": "capital",
    "hyper": "hyperliquid",
    "hyperliquid": "hyperliquid",
    "poly": "polymarket",
    "polymarket": "polymarket",
}

EXECUTION_INTENT_FIELDS = (
    "deal_open",
    "neg_deal_close",
    "pos_deal_close",
    "size",
    "open_time",
    "expiry_time",
    "timeframe",
    "recycle",
)

_GET_PRICE_PATTERN = re.compile(r"get_price\((['\"])([^'\"]+)\1\)")
_SYMBOLS_PATTERN = re.compile(r"symbols\s*:\s*\[\s*(['\"])([^'\"]+)\1")
_RESOLUTION_PATTERN = re.compile(r"resolution\s*:\s*(['\"])([^'\"]+)\1")
_TOKEN_PATTERN = re.compile(r"token_id\s*[:=]\s*(['\"])([^'\"]+)\1")


@dataclass(frozen=True)
class SourceDocument:
    role: str
    path: str
    content: str


@dataclass(frozen=True)
class NurserySymbol:
    venue: str
    namespace: str
    symbol: str
    signature: str
    file: str
    is_async: bool
    docs: str | None = None
    impl_name: str | None = None


class RustNurserySchemaExtractor:
    """Extract a pragmatic nursery schema directly from the Rust source tree."""

    FUNCTION_PATTERN = re.compile(
        r"pub\s+(async\s+)?fn\s+([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*(?:->\s*(.*?))?$"
    )
    IMPL_PATTERN = re.compile(r"impl(?:<[^>]+>)?\s+([A-Za-z_][A-Za-z0-9_]*)")

    def __init__(self, composer_root: Path | None) -> None:
        self.composer_root = composer_root

    def extract(self) -> list[dict[str, Any]]:
        if self.composer_root is None:
            return []

        nursery_root = self.composer_root / "nursery"
        if not nursery_root.exists():
            return []

        symbols: list[NurserySymbol] = []
        for venue_dir in sorted(path for path in nursery_root.iterdir() if path.is_dir()):
            if venue_dir.name == "target":
                continue
            for rust_file in sorted(venue_dir.rglob("*.rs")):
                if "target" in rust_file.parts:
                    continue
                symbols.extend(self._extract_file(venue_dir.name, rust_file))

        return [asdict(symbol) for symbol in symbols]

    def _extract_file(self, venue: str, rust_file: Path) -> list[NurserySymbol]:
        lines = rust_file.read_text(encoding="utf-8").splitlines()
        relative_path = rust_file.relative_to(self.composer_root).as_posix()
        namespace = relative_path[:-3].replace("/", ".")

        results: list[NurserySymbol] = []
        doc_buffer: list[str] = []
        current_impl: str | None = None
        impl_depth = 0
        brace_depth = 0
        index = 0

        while index < len(lines):
            line = lines[index]
            stripped = line.strip()

            if current_impl is not None and brace_depth < impl_depth:
                current_impl = None
                impl_depth = 0

            if stripped.startswith("///"):
                doc_buffer.append(stripped[3:].strip())
                brace_depth += line.count("{") - line.count("}")
                index += 1
                continue

            impl_match = self.IMPL_PATTERN.match(stripped)
            if impl_match and "{" in stripped:
                current_impl = impl_match.group(1)
                brace_depth += line.count("{") - line.count("}")
                impl_depth = brace_depth
                doc_buffer.clear()
                index += 1
                continue

            if stripped.startswith("pub ") and " fn " in f" {stripped} ":
                signature_lines = [stripped]
                while not signature_lines[-1].rstrip().endswith("{") and not signature_lines[-1].rstrip().endswith(";"):
                    index += 1
                    if index >= len(lines):
                        break
                    signature_lines.append(lines[index].strip())
                signature = " ".join(signature_lines)
                signature = signature.removesuffix("{").removesuffix(";").strip()
                match = self.FUNCTION_PATTERN.match(signature)
                if match is not None:
                    params = match.group(3).strip()
                    returns = (match.group(4) or "()").strip()
                    results.append(
                        NurserySymbol(
                            venue=venue,
                            namespace=namespace,
                            symbol=match.group(2),
                            signature=f"({params}) -> {returns}",
                            file=relative_path,
                            is_async=match.group(1) is not None,
                            docs=" ".join(doc_buffer) or None,
                            impl_name=current_impl,
                        )
                    )
                doc_buffer.clear()
                brace_depth += sum(chunk.count("{") - chunk.count("}") for chunk in signature_lines)
                index += 1
                continue

            if stripped:
                doc_buffer.clear()

            brace_depth += line.count("{") - line.count("}")
            index += 1

        return results


class CompileBundleBuilder:
    """Build the model-facing compile bundle that gets persisted in .mex."""

    def __init__(self, compiler: CISTCompiler | None = None) -> None:
        self.compiler = compiler or CISTCompiler()

    def build(
        self,
        source_path: Path,
        *,
        deploy: bool = False,
        ir: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        resolved = source_path.expanduser().resolve()
        compiled = ir or self.compiler.compile_file(resolved)
        workspace_root = self._resolve_workspace_root(resolved)
        composer_root = self._resolve_composer_root(workspace_root)
        documents = self._collect_documents(workspace_root, resolved, composer_root)
        nursery_schema = RustNurserySchemaExtractor(composer_root).extract()
        contract_name = self._contract_name(resolved, compiled)
        source_text = compiled.get("content", "")
        source_hash = hashlib.sha256(source_text.encode("utf-8")).hexdigest()
        build_id = uuid.uuid4().hex

        bundle = {
            "bundle_type": "cist.compile_bundle",
            "schema_version": "2026-04-11",
            "build_id": build_id,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "deploy": deploy,
            "contract_name": contract_name,
            "source_path": str(resolved),
            "workspace_root": str(workspace_root),
            "composer_root": str(composer_root) if composer_root is not None else None,
            "source_hash": source_hash,
            "source": source_text,
            "ir": {key: value for key, value in compiled.items() if key != "content"},
            "documents": [asdict(document) for document in documents],
            "nursery_schema": nursery_schema,
        }
        bundle["harness"] = self._build_harness(bundle)
        bundle["task_input"] = build_model_task_input(bundle)
        return bundle

    def _resolve_workspace_root(self, source_path: Path) -> Path:
        for candidate in [source_path.parent, *source_path.parents]:
            if (candidate / "cist.toml").exists():
                return candidate
            if candidate == candidate.parent:
                break
        return source_path.parent

    def _resolve_composer_root(self, workspace_root: Path) -> Path | None:
        configured = os.getenv("CIST_COMPOSER_ROOT", "").strip()
        if configured:
            configured_path = Path(configured).expanduser().resolve()
            if configured_path.exists():
                return configured_path

        repo_candidate = Path(__file__).resolve().parents[2] / "composer"
        if repo_candidate.exists():
            return repo_candidate

        workspace_candidate = workspace_root / "composer"
        if workspace_candidate.exists():
            return workspace_candidate

        return None

    def _collect_documents(
        self,
        workspace_root: Path,
        source_path: Path,
        composer_root: Path | None,
    ) -> list[SourceDocument]:
        documents: list[SourceDocument] = []

        bench_dir = source_path.parent / "bench"
        if bench_dir.exists():
            for candidate in sorted(bench_dir.iterdir()):
                if candidate.is_file() and candidate.suffix.lower() in {".cis", ".md", ".json"}:
                    documents.append(
                        SourceDocument(
                            role="bench" if candidate.suffix.lower() == ".cis" else "manifest",
                            path=str(candidate),
                            content=candidate.read_text(encoding="utf-8"),
                        )
                    )

        cookbook_path = workspace_root / "cookbook.md"
        if cookbook_path.exists():
            documents.append(
                SourceDocument(
                    role="cookbook",
                    path=str(cookbook_path),
                    content=cookbook_path.read_text(encoding="utf-8"),
                )
            )
        else:
            documents.append(
                SourceDocument(role="cookbook", path="builtin://cookbook.md", content=COOKBOOK)
            )

        if composer_root is not None:
            report_path = composer_root / "report.md"
            if report_path.exists():
                documents.append(
                    SourceDocument(
                        role="composer_report",
                        path=str(report_path),
                        content=report_path.read_text(encoding="utf-8"),
                    )
                )

        return documents

    def _contract_name(self, source_path: Path, compiled: dict[str, Any]) -> str:
        contracts = compiled.get("contracts", [])
        if contracts:
            return str(contracts[0])
        return source_path.stem

    def _build_harness(self, bundle: dict[str, Any]) -> dict[str, Any]:
        source = str(bundle.get("source", ""))
        ir = bundle.get("ir", {})
        module_aliases = [KNOWN_NURSERY_ALIASES[module] for module in ir.get("modules", []) if module in KNOWN_NURSERY_ALIASES]

        return {
            "goal": "Transpile the provided CIST contract into Rust code compatible with the Composer Contract trait, then run the bench/live pipeline.",
            "runtime_contract": {
                "contract_name": bundle["contract_name"],
                "venue_candidates": sorted(set(module_aliases)) or ["capital"],
                "asset_hint": self._detect_asset(source, bundle["contract_name"]),
                "timeframes": self._detect_timeframes(source),
                "intent_fields_present": [field for field in EXECUTION_INTENT_FIELDS if field in source],
            },
            "instructions": [
                "Read the cookbook and composer report included in documents before generating code.",
                "Use only nursery functions present in nursery_schema unless a document explicitly narrows the interface further.",
                "Emit Rust that implements crate::contracts::contract_trait::Contract and uses nursery_util::ExecutionIntent builders.",
                "Keep contract code self-contained and deterministic enough to compile before any refinement loop begins.",
                "When benches or manifests are present, preserve their intent when writing bench metadata or comments.",
            ],
            "expected_output": {
                "contract_rs": "Rust source for composer/contracts/<slug>/contract.rs",
                "bench_manifest_md": "Markdown manifest describing the local bench and safe data requirements",
                "attributes_json": "JSON metadata describing build provenance and compilation notes",
                "notes": "Optional short notes for the human terminal",
            },
        }

    def _detect_asset(self, source: str, contract_name: str) -> str:
        for pattern in (_GET_PRICE_PATTERN, _SYMBOLS_PATTERN, _TOKEN_PATTERN):
            match = pattern.search(source)
            if match is not None:
                return match.group(2)
        return contract_name.upper()

    def _detect_timeframes(self, source: str) -> list[str]:
        found = {match.group(2) for match in _RESOLUTION_PATTERN.finditer(source)}
        if not found:
            return ["1m", "15m", "1h"]
        return sorted(found)


def build_model_task_input(bundle: dict[str, Any]) -> str:
    """Render the final JSON prompt that the model receives as task_input."""

    prompt = {
        "task": "compile_cist_contract",
        "build_id": bundle.get("build_id"),
        "contract_name": bundle.get("contract_name"),
        "deploy": bundle.get("deploy", False),
        "source": bundle.get("source", ""),
        "ir": bundle.get("ir", {}),
        "harness": bundle.get("harness", {}),
        "documents": bundle.get("documents", []),
        "nursery_schema": bundle.get("nursery_schema", []),
        "output_contract": {
            "path": f"composer/contracts/{slugify(str(bundle.get('contract_name', 'contract')))}/contract.rs",
            "language": "rust",
        },
    }
    return json.dumps(prompt, indent=2, ensure_ascii=False)


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9_]+", "_", value.strip()).strip("_")
    if not slug:
        return "contract"
    if slug[0].isdigit():
        return f"contract_{slug}"
    return slug.lower()