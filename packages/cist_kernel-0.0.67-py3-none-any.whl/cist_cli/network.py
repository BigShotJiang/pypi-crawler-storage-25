from __future__ import annotations

import json
import os
from typing import Any, Generator
from urllib.parse import urljoin

import requests

from .compiler.bundle import build_model_task_input


class CloudCourier:
    """Manage streaming requests to the CIST Cloud compilation API."""

    DEFAULT_ENDPOINT = "https://api.cist.io/v1"

    def __init__(
        self, api_key: str | None = None, endpoint: str | None = None
    ) -> None:
        self.api_key = api_key or os.getenv("CIST_CLOUD_API_KEY")
        self.endpoint = (
            endpoint or os.getenv("CIST_CLOUD_ENDPOINT", self.DEFAULT_ENDPOINT)
        ).rstrip("/")

        if not self.api_key and not self._allows_anonymous():
            raise ValueError("CIST_CLOUD_API_KEY not set in environment")

    def _allows_anonymous(self) -> bool:
        return self.endpoint.startswith("http://127.0.0.1") or self.endpoint.startswith(
            "http://localhost"
        )

    def _headers(self, *, accept: str, content_type: str | None = None) -> dict[str, str]:
        headers = {"Accept": accept}
        if content_type is not None:
            headers["Content-Type"] = content_type
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _compile_payload(self, ast_or_bundle: dict[str, Any], deploy: bool) -> dict[str, Any]:
        if ast_or_bundle.get("bundle_type") == "cist.compile_bundle":
            bundle = dict(ast_or_bundle)
            bundle.setdefault("deploy", deploy)
            bundle.setdefault("task_input", build_model_task_input(bundle))
            return {
                "bundle": bundle,
                "deploy": deploy,
                "task_input": bundle["task_input"],
                "metadata": {
                    "contract_name": bundle.get("contract_name"),
                    "build_id": bundle.get("build_id"),
                    "source_hash": bundle.get("source_hash"),
                },
            }

        return {
            "bundle": {
                "bundle_type": "cist.legacy_bundle",
                "schema_version": "2026-04-11",
                "source": ast_or_bundle.get("content", ""),
                "ir": {key: value for key, value in ast_or_bundle.items() if key != "content"},
            },
            "deploy": deploy,
            "task_input": build_model_task_input(
                {
                    "build_id": "legacy",
                    "contract_name": (ast_or_bundle.get("contracts") or ["contract"])[0],
                    "deploy": deploy,
                    "source": ast_or_bundle.get("content", ""),
                    "ir": {key: value for key, value in ast_or_bundle.items() if key != "content"},
                    "documents": [],
                    "nursery_schema": [],
                    "harness": {"goal": "Compile the provided CIST source into a Rust contract."},
                }
            ),
        }

    def stream_compile(
        self, ast_or_bundle: dict[str, Any], deploy: bool = False
    ) -> Generator[dict[str, Any], None, None]:
        """Stream compilation events from the cloud compiler via SSE."""
        url = urljoin(f"{self.endpoint}/", "compile")
        headers = self._headers(accept="text/event-stream", content_type="application/json")
        payload = self._compile_payload(ast_or_bundle, deploy)

        try:
            response = requests.post(
                url,
                json=payload,
                headers=headers,
                stream=True,
                timeout=30,
            )
            response.raise_for_status()

            buffer = ""
            for chunk in response.iter_content(chunk_size=1024, decode_unicode=True):
                if not chunk:
                    continue
                if isinstance(chunk, bytes):
                    buffer += chunk.decode("utf-8", errors="replace")
                else:
                    buffer += chunk

                while "\n\n" in buffer:
                    message, buffer = buffer.split("\n\n", 1)
                    yield self._parse_sse(message)

            if buffer.strip():
                yield self._parse_sse(buffer)
        except requests.exceptions.HTTPError as exc:
            response = exc.response
            status_code = response.status_code if response is not None else None
            if status_code == 401:
                raise ConnectionError("Invalid API key (401)") from exc
            if status_code == 429:
                raise ConnectionError("Rate limit exceeded (429)") from exc
            if status_code is None:
                raise ConnectionError("HTTP error during compilation request") from exc
            raise ConnectionError(f"HTTP error {status_code}") from exc
        except requests.exceptions.RequestException as exc:
            raise ConnectionError(f"Network error: {exc}") from exc

    def telemetry(self, session_id: str | None = None) -> dict[str, Any]:
        url = urljoin(f"{self.endpoint}/", "telemetry")
        headers = self._headers(accept="application/json")
        params = {"session_id": session_id} if session_id else None

        try:
            response = requests.get(url, headers=headers, params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as exc:
            response = exc.response
            status_code = response.status_code if response is not None else None
            if status_code is None:
                raise ConnectionError("HTTP error during telemetry request") from exc
            raise ConnectionError(f"HTTP error {status_code}") from exc
        except requests.exceptions.RequestException as exc:
            raise ConnectionError(f"Network error: {exc}") from exc

    def _parse_sse(self, message: str) -> dict[str, Any]:
        """Parse a single Server-Sent Events message into a dictionary."""
        for line in message.strip().split("\n"):
            if line.startswith("data: "):
                payload = line[6:]
                try:
                    return json.loads(payload)
                except json.JSONDecodeError:
                    return {"type": "log", "message": payload}
        return {"type": "log", "message": message.strip()}