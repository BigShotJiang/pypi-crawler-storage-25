"""CIST workspace initialiser — content templates for generated files."""

from __future__ import annotations

EXAMPLE_CONTRACT = """\
# this contract uses the hyper nursery to deliver the price of oil over a period of 14 days to max at least $24,000 in pnl

use math
use hyper

# define a few utility functions to halp in the contract design
write fn get_oil_price():
    # the definition of the variables used in the function
    which defines:
        oil_price = hype.get_price("OIL")
        time_in_minutes=math.floor(compute.now()/60)
        current_time=compute.now()

    then:
        # the logic to fetch the price of oil every 3 minutes
        if time_in_minutes % 3 == 0:
            oil_price = hype.get_price("OIL")
        else:
            oil_price = hype.get_price("OIL")

    then:
        return oil_price

# parse the loop in as the execution intent for the contract to run indefinitely
contract OilPriceMonitor:
    which defines:
        while True:
            oil_price = get_oil_price()

            then:
                if oil_price > 80.0:
                    print("Oil price is high, consider selling.")
                elif oil_price < 40.0:
                    print("Oil price is low, consider buying.")
                else:
                    print("Oil price is stable, hold your position.")

            then:
                compute.sleep(180)  # sleep for 3 minutes (180 seconds)
                if compute.now() >= current_time + 14 * 24 * 60 * 60:
                    break
"""

BENCH_EXAMPLE = """\
# bench file for OilPriceMonitor — extend with your own test scenarios

use math
use hyper

# scenario: price above threshold triggers sell signal
contract BenchHighPrice:
    which defines:
        oil_price = 90.0  # simulated high price

        then:
            if oil_price > 80.0:
                print("bench: high price path OK")

# scenario: price below threshold triggers buy signal
contract BenchLowPrice:
    which defines:
        oil_price = 30.0  # simulated low price

        then:
            if oil_price < 40.0:
                print("bench: low price path OK")
"""

BENCH_MANIFEST = """\
# Local Bench Manifest

Describe what the safe should generate for this contract.

## Contract Summary
- venue: hyper
- asset: OIL
- target outcome: verify that the contract emits stable intents and survives bearish, bullish, and sideways conditions

## Required Data
- 1m and 15m OHLCV candles
- realistic volume shifts around inflection points
- at least 14 days of synthetic coverage

## Bench Goals
- validate the math logic before promotion
- verify that execution intent fields stay finite and internally consistent
- record edge-case failures so the quant can refine and recompile
"""

ENV_TEMPLATE = """\
# CIST Cloud API
CIST_CLOUD_API_KEY=
CIST_CLOUD_ENDPOINT=https://api.cist.io/v1
CIST_CLOUD_MODEL=1984-m3-0404
CIST_CLOUD_BACKEND=auto

# Optional local runtime overrides
CIST_COMPOSER_ROOT=
CIST_ENABLE_LIVE_RUN=0
COMPOSER_EXECUTE_LIVE_TRADES=0
"""


COOKBOOK = """\
# CIST Language Cookbook

A practical, hands-on reference for writing `.cis` files.
Work through it top-to-bottom or jump to any section you need.

---

## 1. The Two Modes

CIST is a **hybrid language**.  A lightweight LLM adapter sits between the
developer and the compiler, bridging two distinct ways of writing code.

| Mode | When to use | How types work |
|------|-------------|----------------|
| **Interpreted (lax)** | prototyping, scripting, quick ideas | LLM infers the safest, most flexible defaults |
| **Static (strict)** | production, performance-critical paths | developer provides explicit properties; LLM enforces them |

You can mix modes freely inside the same file.

---

## 2. Data Types & Properties

### 2.1 Syntax

    # static (explicit)
    {name}::{type} [{properties}] = {value}

    # interpreted (lax)
    {name} = {value}

Properties live inside `[…]` and are named so the code stays readable.
The LLM adapter fills in any blanks you leave.

---

### 2.2 Strings

**Static:**

    greeting::str [5, utf-8] = 'hello'
    # └ name   └ type  └ max 5 chars, utf-8 encoded

    banner::str [128, utf-8] = 'welcome to cist'

**Interpreted:**

    greeting = 'hello'
    # adapter assigns: dynamic length, utf-8 encoding, heap-allocated

**Properties:**
- first value — max character capacity (`dynamic` = no limit)
- second value — encoding (`utf-8`, `ascii`, `utf-16`)

---

### 2.3 Integers

**Static:**

    age::int [4, 0] = 30
    # └ name   └ type  └ 4 bytes (32-bit), 0 = no padding

    big_num::int [8, 0] = 9000000000
    # 8 bytes = 64-bit; safe for most financial arithmetic

**Interpreted:**

    age = 30
    # adapter assigns: 8-byte integer, promoted to BigInt if overflow detected

**Properties:**
- first value — allocation size in bytes (`1`, `2`, `4`, `8`)
- second value — padding / minimum digit width (`0` = none)

---

### 2.4 Floats

**Static:**

    price::float [8, 2] = 3.14
    # └ name    └ type  └ 8-byte double, 2 decimal places of precision

    rate::float [4, 5] = 0.00325
    # 4-byte single precision, 5 significant decimal places

**Interpreted:**

    price = 3.14
    # adapter assigns: 64-bit double, no precision cap

**Properties:**
- first value — byte size (`4` = 32-bit single, `8` = 64-bit double)
- second value — decimal place precision (`0` = full precision)

---

### 2.5 Booleans

**Static (strict — only literal `true`/`false` accepted):**

    is_active::bool [strict] = true

**Static (lax — `0`, `1`, empty list, etc. are truthy/falsy):**

    is_online::bool [lax] = 1

**Interpreted:**

    is_active = true
    # adapter defaults to lax evaluation

**Properties:**
- `strict` — only `true` or `false`; anything else is a compile-time error
- `lax` — follows common truthy/falsy rules (`0`, `[]`, `''` are falsy)

---

### 2.6 Lists

**Static:**

    scores::list [10, int] = [95, 87, 92]
    # └ name     └ type  └ capacity=10, element type=int

    names::list [dynamic, str] = ['alice', 'bob']
    # dynamic capacity, elements must be strings

**Interpreted:**

    scores = [95, 87, 92]
    # adapter assigns: dynamic capacity, type=any

**Properties:**
- first value — capacity (`dynamic` = grows as needed)
- second value — element type constraint (`any`, `int`, `str`, `float`, …)

---

### 2.7 Dicts

**Static:**

    config::dict [100, str] = {host: 'localhost', port: '8080'}
    # └ name     └ type   └ capacity=100, key type=str

**Interpreted:**

    config = {host: 'localhost', port: '8080'}
    # adapter assigns: dynamic capacity, key type=any

**Properties:**
- first value — key capacity
- second value — key type constraint

---

## 3. Structs

Structs are **lightweight value types** — shaped data with no built-in
behaviour.  Good for data transfer objects, points, records.

    struct Point:
        x::float [4, 2] = 0.0
        y::float [4, 2] = 0.0

    struct Money:
        amount::float [8, 2] = 0.0
        currency::str  [3, ascii] = 'USD'

    struct DateRange:
        start::int  [8, 0] = 0   # unix timestamp
        end::int    [8, 0] = 0

**Instantiating a struct:**

    origin = Point{x: 0.0, y: 0.0}
    price  = Money{amount: 42.00, currency: 'EUR'}

**Accessing fields:**

    print(origin.x)
    total = price.amount * 1.2

Structs are **immutable by default** — to update a field, reassign the whole
struct or use a contract (see section 5).

---

## 4. Functions

Functions are declared with `write fn`.

### 4.1 Interpreted (lax)

    write fn greet(name):
        which defines:
            message = 'hello, ' + name
        then:
            return message

### 4.2 Static (with typed parameters and return type)

    write fn add(a::int [4, 0], b::int [4, 0]) -> int:
        which defines:
            result::int [4, 0] = a + b
        then:
            return result

### 4.3 Multiple `then:` blocks

Each `then:` block runs in sequence.  Use them to keep logical phases separate.

    write fn process(value):
        which defines:
            cleaned = 0
            result  = 0

        then:
            # phase 1 — normalise
            if value < 0:
                cleaned = 0
            else:
                cleaned = value

        then:
            # phase 2 — compute
            result = cleaned * 2

        then:
            return result

### 4.4 No-return (void) functions

Simply omit `return`:

    write fn log(msg):
        print('[log] ' + msg)

---

## 5. Contracts (Objects)

Contracts are the **object system** in CIST.  Think of them as classes, but
designed around intent and execution.  A contract bundles state (`which
defines:`) with behaviour (`write fn … ` inside a `then:` block).

    contract Counter:
        which defines:
            count = 0

        then:
            write fn increment():
                count = count + 1

            write fn decrement():
                if count > 0:
                    count = count - 1

            write fn reset():
                count = 0

            write fn value() -> int:
                return count

**Instantiating a contract:**

    c = Counter{}
    c.increment()
    c.increment()
    print(c.value())   # 2
    c.reset()
    print(c.value())   # 0

**Contracts with typed fields (static mode):**

    contract Wallet:
        which defines:
            balance::float [8, 2]           = 0.0
            currency::str  [3, ascii]        = 'USD'
            transactions::list [1000, float] = []

        then:
            write fn deposit(amount::float [8, 2]):
                balance = balance + amount
                transactions.append(amount)

            write fn withdraw(amount::float [8, 2]) -> bool:
                if amount > balance:
                    return false
                balance = balance - amount
                transactions.append(0 - amount)
                return true

            write fn statement():
                for tx in transactions:
                    print(tx)

---

## 6. Control Flow

### 6.1 if / elif / else

    if score > 90:
        print('A')
    elif score > 75:
        print('B')
    elif score > 60:
        print('C')
    else:
        print('F')

### 6.2 while

    i = 0
    while i < 10:
        print(i)
        i = i + 1

### 6.3 for … in

    for item in scores:
        print(item)

**Range-based:**

    for i in range(0, 10):
        print(i)

### 6.4 break / continue

    for item in items:
        if item < 0:
            continue
        if item > 100:
            break
        print(item)

### 6.5 Inline ternary

    label = 'done' if is_complete else 'pending'

---

## 7. Modules & Packages

### 7.1 Importing a module

    use math
    use compute
    use hyper

### 7.2 Using a module

    result = math.floor(3.7)
    now    = compute.now()
    price  = hyper.get_price('EURUSD')

### 7.3 Selective import

    from math use floor, ceil, pow

    result = floor(3.7)   # no prefix needed

### 7.4 Custom packages

Drop a file named `my_package.cis` alongside your contract, then:

    use my_package

    result = my_package.my_function(42)

---

## 8. Macros

Macros are **compile-time transformations**.  They receive unevaluated tokens
and expand before the compiler sees the code.  Use them to eliminate repetitive
patterns without runtime overhead.

### 8.1 Simple macro

    macro double(x):
        yield x + x

    result = double(5)   # expands to: result = 5 + 5

### 8.2 Multi-statement macro

    macro swap(a, b):
        yield:
            tmp = a
            a   = b
            b   = tmp

    swap(x, y)   # expands the three-line block inline

### 8.3 Guard macro

    macro assert_positive(val, label):
        yield:
            if val < 0:
                print('assertion failed: ' + label + ' must be positive')

    assert_positive(price, 'price')

### 8.4 Logging macro (static mode)

    macro log_call(fn_name, args):
        yield:
            print('[call] ' + fn_name + ' args=' + args)

---

## 9. Data Streams

CIST has first-class support for **streaming data sources** via `from data(…)`.
The LLM adapter treats streams as async iterators under the hood.

    use hyper

    write fn watch_price(symbol):
        which defines:
            price = from data(hyper.stream(symbol))
        then:
            return price

    # live feed in a contract
    contract PriceWatcher:
        which defines:
            symbol = 'EURUSD'
            last   = 0.0

        then:
            write fn run():
                while true:
                    last = from data(hyper.stream(symbol))
                    print(symbol + ' → ' + last)
                    compute.sleep(1)

---

## 10. Example — Simple Calculator

A four-operation calculator demonstrating top-level functions, a contract, and
basic control flow.

    # simple-calculator.cis
    use math

    write fn add(a, b):
        return a + b

    write fn subtract(a, b):
        return a - b

    write fn multiply(a, b):
        return a * b

    write fn divide(a, b):
        if b == 0:
            print('error: division by zero')
            return 0
        return a / b

    contract Calculator:
        which defines:
            history::list [100, str] = []

        then:
            write fn compute(op, a, b):
                which defines:
                    result = 0
                    entry  = ''

                then:
                    if op == 'add':
                        result = add(a, b)
                    elif op == 'subtract':
                        result = subtract(a, b)
                    elif op == 'multiply':
                        result = multiply(a, b)
                    elif op == 'divide':
                        result = divide(a, b)
                    else:
                        print('unknown operation: ' + op)
                        return 0

                then:
                    entry = op + '(' + a + ', ' + b + ') = ' + result
                    history.append(entry)
                    return result

            write fn history():
                print('--- history ---')
                for entry in history:
                    print(entry)

    contract RunCalculator:
        which defines:
            calc = Calculator{}

        then:
            print(calc.compute('add',      10, 5))    # 15
            print(calc.compute('subtract', 10, 5))    # 5
            print(calc.compute('multiply', 10, 5))    # 50
            print(calc.compute('divide',   10, 5))    # 2.0
            print(calc.compute('divide',   10, 0))    # error, returns 0

            then:
                calc.history()

---

## 11. Example — Todo List

A full todo-list application using structs, contracts, control flow, and
static type annotations.

    # todo-list.cis

    struct TodoItem:
        id::int       [4, 0]    = 0
        title::str    [256, utf-8] = ''
        done::bool    [lax]     = false
        priority::int [1, 0]    = 1    # 1=low  2=medium  3=high

    contract TodoList:
        which defines:
            items::list   [1000, TodoItem] = []
            next_id::int  [4, 0]           = 1

        then:
            write fn add(title, priority) -> int:
                which defines:
                    item = TodoItem{
                        id:       next_id,
                        title:    title,
                        done:     false,
                        priority: priority
                    }
                then:
                    items.append(item)
                    next_id = next_id + 1
                    return item.id

            write fn complete(id) -> bool:
                for item in items:
                    if item.id == id:
                        item.done = true
                        return true
                return false

            write fn remove(id):
                which defines:
                    filtered = []
                then:
                    for item in items:
                        if item.id != id:
                            filtered.append(item)
                    items = filtered

            write fn pending() -> list:
                which defines:
                    result = []
                then:
                    for item in items:
                        if item.done == false:
                            result.append(item)
                    return result

            write fn by_priority(level) -> list:
                which defines:
                    result = []
                then:
                    for item in items:
                        if item.priority == level:
                            result.append(item)
                    return result

            write fn print_all():
                for item in items:
                    which defines:
                        status     = '[x]' if item.done else '[ ]'
                        prio_label = 'low'
                    then:
                        if item.priority == 2:
                            prio_label = 'medium'
                        elif item.priority == 3:
                            prio_label = 'high'
                        print(status + ' [' + prio_label + '] #' + item.id + ' ' + item.title)

    contract RunTodoDemo:
        which defines:
            list = TodoList{}

        then:
            list.add('buy groceries',        1)
            list.add('fix the build pipeline', 3)
            list.add('write the cookbook',   2)
            list.add('review pull requests', 2)
            list.add('deploy to staging',    3)

        then:
            list.complete(1)   # groceries done
            list.complete(3)   # cookbook done

        then:
            print('--- all tasks ---')
            list.print_all()

        then:
            pending = list.pending()
            print('--- pending (' + pending.length + ') ---')
            for task in pending:
                print(task.title)

        then:
            high = list.by_priority(3)
            print('--- high priority ---')
            for task in high:
                print(task.title)

---

## Quick-Reference Card

    # import
    use math

    # variable (lax)
    name = 'alice'

    # variable (strict)
    age::int [4, 0] = 30

    # struct
    struct Point:
        x::float [4,2] = 0.0
        y::float [4,2] = 0.0

    # function
    write fn greet(name):
        return 'hello, ' + name

    # typed function
    write fn add(a::int [4,0], b::int [4,0]) -> int:
        return a + b

    # contract
    contract Foo:
        which defines:
            bar = 0
        then:
            write fn set(v):
                bar = v

    # instantiate
    foo = Foo{}
    foo.set(42)

    # control flow
    if x > 0:
        print('positive')
    elif x == 0:
        print('zero')
    else:
        print('negative')

    for i in range(0, 5):
        print(i)

    while running:
        compute.sleep(1)

    # macro
    macro log(msg):
        yield print('[log] ' + msg)

    # data stream
    price = from data(hyper.stream('EURUSD'))
"""


def cist_toml(name: str, kernel_version: str) -> str:
    """Return the content for the ``cist.toml`` config file."""
    return f"""\
# CIST workspace configuration
# https://docs.cist.io/configuration

[project]
name = "{name}"
version = "0.1.0"
description = ""

[kernel]
# Kernel version this workspace was initialised with
version = "{kernel_version}"

[compiler]
# Set to true to treat all warnings as errors
strict = false
# Set to true to write .mex files as human-readable JSON instead of binary.
# Useful during development to inspect the compiled IR; set to false for release.
debug = false

[cloud]
# auto | nineth | template
backend = "auto"
model = "1984-m3-0404"

[runtime]
# Relative or absolute path to the Composer runtime used by the cloud worker.
composer_root = "composer"
# Poll interval suggestion for telemetry clients.
telemetry_poll_seconds = 5
"""
