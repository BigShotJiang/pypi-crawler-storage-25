from __future__ import annotations

from .service import create_app

try:
    import modal
except ImportError:  # pragma: no cover - optional dependency
    modal = None


if modal is not None:  # pragma: no cover - optional dependency
    image = modal.Image.debian_slim().pip_install(
        "fastapi>=0.115.0",
        "uvicorn>=0.30.0",
        "python-dotenv>=1.0.0",
    )
    modal_app = modal.App("cist-cloud-compiler")

    @modal_app.function(image=image)
    @modal.asgi_app()
    def fastapi_app():
        return create_app()
else:  # pragma: no cover - optional dependency
    modal_app = None