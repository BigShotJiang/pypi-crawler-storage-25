from __future__ import annotations

import json
import os
import re
import subprocess
import threading
import uuid
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Generator, Iterable

from ..compiler.bundle import CompileBundleBuilder, build_model_task_input, slugify


def _now_iso() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()


def _default_repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _default_composer_root() -> Path | None:
    configured = os.getenv("CIST_COMPOSER_ROOT", "").strip()
    if configured:
        path = Path(configured).expanduser().resolve()
        if path.exists():
            return path
    candidate = _default_repo_root() / "composer"
    if candidate.exists():
        return candidate
    return None


def _pascal_case(value: str) -> str:
    parts = [part for part in re.split(r"[^a-zA-Z0-9]+", value) if part]
    if not parts:
        return "Generated"
    return "".join(part[0].upper() + part[1:] for part in parts)


@dataclass
class GeneratedContract:
    contract_rs: str
    bench_manifest_md: str
    attributes_json: dict[str, Any]
    bench_test_rs: str
    notes: str = ""


class CompileTelemetryStore:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._sessions: dict[str, dict[str, Any]] = {}

    def open(self, session_id: str, bundle: dict[str, Any], deploy: bool) -> None:
        with self._lock:
            self._sessions[session_id] = {
                "session_id": session_id,
                "contract_name": bundle.get("contract_name"),
                "deploy": deploy,
                "status": "accepted",
                "stage": "accepted",
                "started_at": _now_iso(),
                "updated_at": _now_iso(),
                "events": deque(maxlen=200),
                "artifacts": [],
            }

    def update(self, session_id: str, **fields: Any) -> None:
        with self._lock:
            session = self._sessions.setdefault(
                session_id,
                {"session_id": session_id, "events": deque(maxlen=200), "artifacts": []},
            )
            session.update(fields)
            session["updated_at"] = _now_iso()

    def add_event(self, session_id: str, event: dict[str, Any]) -> None:
        with self._lock:
            session = self._sessions.setdefault(
                session_id,
                {"session_id": session_id, "events": deque(maxlen=200), "artifacts": []},
            )
            event_copy = dict(event)
            event_copy.setdefault("ts", _now_iso())
            session["events"].append(event_copy)
            if event_copy.get("type") == "artifact":
                session.setdefault("artifacts", []).append(event_copy)
            session["updated_at"] = _now_iso()

    def snapshot(self, session_id: str | None = None) -> dict[str, Any]:
        with self._lock:
            if session_id is not None:
                session = self._sessions.get(session_id)
                if session is None:
                    return {"sessions": []}
                return {"sessions": [self._materialize(session)]}
            return {
                "sessions": [self._materialize(session) for session in self._sessions.values()]
            }

    def _materialize(self, session: dict[str, Any]) -> dict[str, Any]:
        materialized = dict(session)
        materialized["events"] = list(session.get("events", []))
        return materialized


class TemplateModelRunner:
    name = "template"

    def generate(
        self,
        bundle: dict[str, Any],
        emit: Callable[[dict[str, Any]], None],
    ) -> GeneratedContract:
        venue = self._detect_venue(bundle)
        asset = self._detect_asset(bundle)
        contract_name = slugify(str(bundle.get("contract_name", "contract")))
        timeframe = self._detect_timeframe(bundle, venue)

        emit(
            {
                "type": "log",
                "message": (
                    f"Using deterministic template runner for {contract_name} "
                    f"on {venue} with asset {asset}"
                ),
            }
        )

        return GeneratedContract(
            contract_rs=self._render_contract(contract_name, venue, asset, timeframe),
            bench_manifest_md=self._render_manifest(contract_name, venue, asset, timeframe, bundle),
            attributes_json={
                "generated_by": self.name,
                "build_id": bundle.get("build_id"),
                "source_hash": bundle.get("source_hash"),
                "venue": venue,
                "asset": asset,
                "timeframe": timeframe,
                "generated_at": _now_iso(),
            },
            bench_test_rs=self._render_bench_test(contract_name),
            notes="Template runner emitted a compile-safe Rust contract scaffold.",
        )

    def _detect_venue(self, bundle: dict[str, Any]) -> str:
        modules = bundle.get("ir", {}).get("modules", [])
        if "farm" in modules or "capital" in modules:
            return "capital"
        if "hyper" in modules or "hyperliquid" in modules:
            return "hyperliquid"
        if "poly" in modules or "polymarket" in modules:
            return "polymarket"
        return "capital"

    def _detect_asset(self, bundle: dict[str, Any]) -> str:
        harness = bundle.get("harness", {})
        runtime_contract = harness.get("runtime_contract", {})
        asset_hint = str(runtime_contract.get("asset_hint") or "").strip()
        if asset_hint:
            return asset_hint
        return str(bundle.get("contract_name", "ASSET")).upper()

    def _detect_timeframe(self, bundle: dict[str, Any], venue: str) -> str:
        harness = bundle.get("harness", {})
        runtime_contract = harness.get("runtime_contract", {})
        timeframes = runtime_contract.get("timeframes", [])
        if venue == "capital":
            for candidate in ("1h", "15m", "5m"):
                if candidate in timeframes:
                    return candidate
        if venue == "hyperliquid":
            for candidate in ("15m", "5m", "1m"):
                if candidate in timeframes:
                    return candidate
        if venue == "polymarket":
            for candidate in ("5m", "1m", "15m"):
                if candidate in timeframes:
                    return candidate
        return str(timeframes[0]) if timeframes else "1m"

    def _render_contract(
        self,
        contract_name: str,
        venue: str,
        asset: str,
        timeframe: str,
    ) -> str:
        struct_name = f"{_pascal_case(contract_name)}Contract"
        venue_variant = {
            "capital": "Capital",
            "hyperliquid": "Hyperliquid",
            "polymarket": "Polymarket",
        }[venue]
        builder = {
            "capital": "capital",
            "hyperliquid": "hyperliquid",
            "polymarket": "polymarket",
        }[venue]
        size = {
            "capital": "1.0",
            "hyperliquid": "0.01",
            "polymarket": "25.0",
        }[venue]

        return f'''use std::time::Duration;

use anyhow::Result;
use nursery_util::{{Candle, ContractData, Direction, ExecutionIntent, Venue}};

use crate::contracts::contract_trait::Contract;

pub struct {struct_name} {{
    pub trigger_time: String,
    pub expiry_time: String,
}}

impl {struct_name} {{
    pub fn new(trigger_time: &str, expiry_time: &str) -> Self {{
        Self {{
            trigger_time: trigger_time.to_string(),
            expiry_time: expiry_time.to_string(),
        }}
    }}
}}

#[async_trait::async_trait]
impl Contract for {struct_name} {{
    fn name(&self) -> &str {{
        "{contract_name}"
    }}

    fn venue(&self) -> Venue {{
        Venue::{venue_variant}
    }}

    fn asset(&self) -> &str {{
        "{asset}"
    }}

    async fn tick(&self, data: &ContractData) -> Result<Option<ExecutionIntent>> {{
        let candles = match data.candles.get("{timeframe}") {{
            Some(candles) if candles.len() >= 20 => candles,
            _ => return Ok(None),
        }};

        let closes: Vec<f64> = candles.iter().map(|c| c.close).collect();
        let current_price = *closes.last().unwrap_or(&0.0);
        if current_price <= 0.0 {{
            return Ok(None);
        }}

        let fast = mean(&closes[closes.len() - 5..]);
        let slow = mean(&closes[closes.len() - 20..]);
        let spread = fast - slow;
        let threshold = current_price * 0.0025;
        if spread.abs() < threshold {{
            return Ok(None);
        }}

        let direction = if spread > 0.0 {{
            Direction::Long
        }} else {{
            Direction::Short
        }};
        let atr = average_true_range(candles, 14).max(current_price * 0.0015);
        let prop = fast + spread;
        let confidence = (spread.abs() / atr).min(1.0).max(0.0);

        let (positive_close, negative_close) = match direction {{
            Direction::Long => (
                current_price + atr * 1.8,
                current_price - atr * 1.0,
            ),
            Direction::Short => (
                current_price - atr * 1.8,
                current_price + atr * 1.0,
            ),
        }};

        let intent = ExecutionIntent::{builder}(
            "{asset}",
            direction,
            current_price,
            positive_close,
            negative_close,
            {size},
            &self.trigger_time,
            &self.expiry_time,
            prop,
            confidence,
        );

        if intent.validate().is_ok() {{
            Ok(Some(intent))
        }} else {{
            Ok(None)
        }}
    }}

    fn staleness_threshold(&self) -> Duration {{
        Duration::from_secs(120)
    }}

    fn open_time(&self) -> &str {{
        &self.trigger_time
    }}

    fn expiry_time(&self) -> &str {{
        &self.expiry_time
    }}
}}

fn mean(slice: &[f64]) -> f64 {{
    if slice.is_empty() {{
        return 0.0;
    }}
    slice.iter().sum::<f64>() / slice.len() as f64
}}

fn average_true_range(candles: &[Candle], period: usize) -> f64 {{
    if candles.len() < 2 {{
        return 0.0;
    }}

    let start = candles.len().saturating_sub(period);
    let mut values = Vec::with_capacity(candles.len().saturating_sub(start));

    for index in start..candles.len() {{
        let candle = &candles[index];
        let previous_close = if index == 0 {{
            candle.close
        }} else {{
            candles[index - 1].close
        }};

        let tr = (candle.high - candle.low)
            .max((candle.high - previous_close).abs())
            .max((candle.low - previous_close).abs());
        values.push(tr);
    }}

    mean(&values)
}}
'''

    def _render_manifest(
        self,
        contract_name: str,
        venue: str,
        asset: str,
        timeframe: str,
        bundle: dict[str, Any],
    ) -> str:
        documents = bundle.get("documents", [])
        bench_sources = [document for document in documents if document.get("role") == "bench"]
        bench_names = [Path(str(document.get("path", "bench"))).name for document in bench_sources]
        listed_benches = ", ".join(bench_names) if bench_names else "none supplied"
        return "\n".join(
            [
                f"# {contract_name} local bench manifest",
                "",
                "## Runtime target",
                f"- venue: {venue}",
                f"- asset: {asset}",
                f"- primary timeframe: {timeframe}",
                "",
                "## Bench goals",
                "- verify the generated contract emits valid ExecutionIntent values",
                "- verify the generated contract survives sparse and volatile data",
                "- verify the contract remains deterministic for repeated seeded runs",
                "",
                "## Human-authored benches discovered",
                f"- {listed_benches}",
                "",
                "## Safe data instructions",
                "- generate bearish, bullish, sideways, volatile, and flash-crash scenarios",
                "- include enough candles to cover both the fast and slow moving averages",
                "- preserve realistic volume changes whenever the venue supports OHLCV inputs",
            ]
        )

    def _render_bench_test(self, contract_name: str) -> str:
        struct_name = f"{_pascal_case(contract_name)}Contract"
        return f'''use crate::contracts::contract_trait::Contract;
use crate::contracts::{contract_name}::contract::{struct_name};

#[test]
fn generated_contract_constructs() {{
    let contract = {struct_name}::new(
        "2026-04-11T00:00:00Z",
        "2026-04-11T06:00:00Z",
    );
    assert_eq!(contract.name(), "{contract_name}");
}}
'''


class NinethModelRunner:
    name = "nineth"

    def __init__(self, fallback: TemplateModelRunner | None = None) -> None:
        self.fallback = fallback or TemplateModelRunner()

    def generate(
        self,
        bundle: dict[str, Any],
        emit: Callable[[dict[str, Any]], None],
    ) -> GeneratedContract:
        try:
            from dotenv import load_dotenv
            from nineth import NinethClient
        except ImportError as exc:
            emit(
                {
                    "type": "log",
                    "message": f"Nineth SDK unavailable ({exc}); falling back to template runner.",
                }
            )
            return self.fallback.generate(bundle, emit)

        load_dotenv()
        client = NinethClient()
        model_name = os.getenv("CIST_CLOUD_MODEL", "1984-m3-0404")
        task_input = str(bundle.get("task_input") or build_model_task_input(bundle))
        response_text = ""

        for event in client.model.request(
            task_input=task_input,
            model=model_name,
            stream=True,
            show_reasoning=False,
            reasoning="low",
            max_iterations=200,
        ):
            if event.get("type") == "model_delta":
                chunk = str(event.get("data", {}).get("text", ""))
                response_text += chunk
                if chunk.strip():
                    emit({"type": "log", "message": chunk.strip()})

        parsed = self._parse_response(response_text)
        if parsed is None:
            emit(
                {
                    "type": "log",
                    "message": "Nineth response was not machine-readable; falling back to template runner.",
                }
            )
            return self.fallback.generate(bundle, emit)

        return GeneratedContract(
            contract_rs=str(parsed.get("contract_rs") or ""),
            bench_manifest_md=str(parsed.get("bench_manifest_md") or ""),
            attributes_json=dict(parsed.get("attributes_json") or {}),
            bench_test_rs=str(parsed.get("bench_test_rs") or self.fallback._render_bench_test(slugify(str(bundle.get("contract_name", "contract"))))),
            notes=str(parsed.get("notes") or ""),
        )

    def _parse_response(self, text: str) -> dict[str, Any] | None:
        stripped = text.strip()
        if not stripped:
            return None
        try:
            return json.loads(stripped)
        except json.JSONDecodeError:
            pass

        json_match = re.search(r"\{[\s\S]*\}", stripped)
        if json_match is not None:
            try:
                return json.loads(json_match.group(0))
            except json.JSONDecodeError:
                pass

        code_blocks = re.findall(r"```rust\s*([\s\S]*?)```", stripped)
        if code_blocks:
            return {
                "contract_rs": code_blocks[0].strip(),
                "bench_manifest_md": "",
                "attributes_json": {},
                "notes": "Recovered Rust code from fenced output.",
            }
        return None


class ContractProjectWriter:
    def __init__(self, composer_root: Path) -> None:
        self.composer_root = composer_root

    def write(self, bundle: dict[str, Any], generated: GeneratedContract) -> list[Path]:
        contract_slug = slugify(str(bundle.get("contract_name", "contract")))
        contract_dir = self.composer_root / "contracts" / contract_slug
        bench_dir = contract_dir / "bench"
        attributes_dir = contract_dir / "attributes"

        bench_dir.mkdir(parents=True, exist_ok=True)
        attributes_dir.mkdir(parents=True, exist_ok=True)

        contract_path = contract_dir / "contract.rs"
        manifest_path = bench_dir / "manifest.md"
        bench_test_path = bench_dir / "test_0.rs"
        attributes_path = attributes_dir / "generated_compile.json"

        contract_path.write_text(generated.contract_rs, encoding="utf-8")
        manifest_path.write_text(generated.bench_manifest_md, encoding="utf-8")
        bench_test_path.write_text(generated.bench_test_rs, encoding="utf-8")
        attributes_path.write_text(
            json.dumps(generated.attributes_json, indent=2) + "\n",
            encoding="utf-8",
        )

        return [contract_path, manifest_path, bench_test_path, attributes_path]


class CompileService:
    def __init__(
        self,
        composer_root: Path | None = None,
        telemetry: CompileTelemetryStore | None = None,
    ) -> None:
        self.composer_root = composer_root or _default_composer_root()
        self.telemetry = telemetry or CompileTelemetryStore()

    def iter_compile(
        self,
        bundle: dict[str, Any],
        *,
        deploy: bool = False,
    ) -> Generator[dict[str, Any], None, None]:
        session_id = str(bundle.get("build_id") or uuid.uuid4().hex)
        bundle.setdefault("build_id", session_id)
        bundle.setdefault("task_input", build_model_task_input(bundle))

        self.telemetry.open(session_id, bundle, deploy)
        accepted = {
            "type": "accepted",
            "session_id": session_id,
            "contract_name": bundle.get("contract_name"),
        }
        self.telemetry.add_event(session_id, accepted)
        yield accepted

        if self.composer_root is None or not self.composer_root.exists():
            error = {
                "type": "error",
                "session_id": session_id,
                "message": "Composer runtime root is not available on the compile worker.",
            }
            self.telemetry.update(session_id, status="failed", stage="error")
            self.telemetry.add_event(session_id, error)
            yield error
            return

        self.telemetry.update(session_id, status="running", stage="model")
        model_events: list[dict[str, Any]] = []
        runner = self._runner(bundle)
        generated = runner.generate(bundle, model_events.append)

        for event in model_events:
            self.telemetry.add_event(session_id, event)
            yield event

        writer = ContractProjectWriter(self.composer_root)
        artifacts = writer.write(bundle, generated)
        for artifact in artifacts:
            event = {
                "type": "artifact",
                "session_id": session_id,
                "path": str(artifact),
            }
            self.telemetry.add_event(session_id, event)
            yield event

        if generated.notes:
            note_event = {
                "type": "log",
                "session_id": session_id,
                "message": generated.notes,
            }
            self.telemetry.add_event(session_id, note_event)
            yield note_event

        self.telemetry.update(session_id, stage="bench")
        for event in self._run_process(
            session_id,
            ["cargo", "run", "--bin", "composer", "--", "bench"],
            cwd=self.composer_root,
            phase="bench",
        ):
            yield event
            if event.get("type") == "error":
                self.telemetry.update(session_id, status="failed", stage="bench")
                return

        if deploy:
            if os.getenv("CIST_ENABLE_LIVE_RUN") == "1":
                self.telemetry.update(session_id, stage="live")
                for event in self._run_process(
                    session_id,
                    ["cargo", "run", "--bin", "composer", "--", "live"],
                    cwd=self.composer_root,
                    phase="live",
                    env={"COMPOSER_EXECUTE_LIVE_TRADES": "1"},
                ):
                    yield event
                    if event.get("type") == "error":
                        self.telemetry.update(session_id, status="failed", stage="live")
                        return
            else:
                event = {
                    "type": "log",
                    "session_id": session_id,
                    "message": "Deploy requested, but CIST_ENABLE_LIVE_RUN is not set. Bench artifacts are ready for promotion.",
                }
                self.telemetry.add_event(session_id, event)
                yield event

        complete = {
            "type": "complete",
            "session_id": session_id,
            "message": "Compilation pipeline finished successfully.",
        }
        self.telemetry.update(session_id, status="completed", stage="complete")
        self.telemetry.add_event(session_id, complete)
        yield complete

    def _runner(self, bundle: dict[str, Any]) -> TemplateModelRunner | NinethModelRunner:
        backend = os.getenv("CIST_CLOUD_BACKEND", "auto").strip().lower()
        if backend == "template":
            return TemplateModelRunner()
        if backend == "nineth":
            return NinethModelRunner()
        return NinethModelRunner()

    def _run_process(
        self,
        session_id: str,
        command: list[str],
        *,
        cwd: Path,
        phase: str,
        env: dict[str, str] | None = None,
    ) -> Iterable[dict[str, Any]]:
        process_env = os.environ.copy()
        if env:
            process_env.update(env)

        process = subprocess.Popen(
            command,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            env=process_env,
        )

        assert process.stdout is not None
        for line in process.stdout:
            message = line.rstrip()
            if not message:
                continue
            event = {
                "type": "log",
                "session_id": session_id,
                "phase": phase,
                "message": message,
            }
            self.telemetry.add_event(session_id, event)
            yield event

        exit_code = process.wait()
        if exit_code != 0:
            event = {
                "type": "error",
                "session_id": session_id,
                "phase": phase,
                "message": f"{phase} process failed with exit code {exit_code}",
            }
            self.telemetry.add_event(session_id, event)
            yield event


def format_sse(event: dict[str, Any]) -> str:
    return f"data: {json.dumps(event, ensure_ascii=False)}\n\n"


def create_app(service: CompileService | None = None) -> Any:
    try:
        from fastapi import FastAPI
        from fastapi.responses import StreamingResponse
    except ImportError as exc:
        raise RuntimeError(
            "FastAPI is not installed. Install the cloud extra or add fastapi/uvicorn to the environment."
        ) from exc

    compiler_service = service or CompileService()
    app = FastAPI(title="CIST Cloud Compiler", version="0.1.0")

    @app.post("/compile")
    async def compile_endpoint(payload: dict[str, Any]) -> StreamingResponse:
        bundle = payload.get("bundle") if isinstance(payload.get("bundle"), dict) else payload
        deploy = bool(payload.get("deploy", bundle.get("deploy", False)))

        def stream() -> Iterable[str]:
            for event in compiler_service.iter_compile(bundle, deploy=deploy):
                yield format_sse(event)

        return StreamingResponse(stream(), media_type="text/event-stream")

    @app.get("/telemetry")
    async def telemetry_endpoint(session_id: str | None = None) -> dict[str, Any]:
        return compiler_service.telemetry.snapshot(session_id)

    return app


def serve(host: str = "127.0.0.1", port: int = 8000) -> None:
    try:
        import uvicorn
    except ImportError as exc:
        raise RuntimeError(
            "uvicorn is not installed. Install the cloud extra or add uvicorn to the environment."
        ) from exc

    uvicorn.run(create_app(), host=host, port=port)


def build_server_bundle(source_path: Path, *, deploy: bool = False) -> dict[str, Any]:
    builder = CompileBundleBuilder()
    return builder.build(source_path, deploy=deploy)