"""Entry point for `python -m mnemo_mcp` and the `mnemo-mcp` console script."""
import asyncio
from mnemo_mcp.server import main


def main_sync():
    """Synchronous wrapper — used by the `mnemo-mcp` console script entry point."""
    asyncio.run(main())


if __name__ == "__main__":
    main_sync()
