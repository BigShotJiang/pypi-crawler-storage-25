from __future__ import annotations

import json
import logging
import os
import shlex
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def _is_loopback_host(hostname: Optional[str]) -> bool:
    return hostname in {"localhost", "127.0.0.1", "::1"}


def resolve_api_token(initial_token: str = "") -> str:
    """Resolve API token from env, token file, or command-based provider."""
    token = (initial_token or "").strip()
    if token:
        return token

    token_file = Path.home() / ".mnemo" / "mcp_token"
    if token_file.exists():
        file_token = token_file.read_text(encoding="utf-8").strip()
        if file_token:
            return file_token

    token_cmd = (os.getenv("MNEMO_API_TOKEN_CMD", "") or "").strip()
    if token_cmd:
        try:
            completed = subprocess.run(
                shlex.split(token_cmd),
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
            )
            if completed.returncode == 0:
                cmd_token = (completed.stdout or "").strip()
                if cmd_token:
                    return cmd_token
        except Exception as exc:
            logger.warning("token command failed: %s", exc)

    # Optional compatibility env if external auth broker injects bearer.
    oauth_token = (os.getenv("MNEMO_OAUTH_ACCESS_TOKEN", "") or "").strip()
    if oauth_token:
        return oauth_token
    return ""


class _NoAuthRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Strip Authorization header on redirect to prevent cross-origin token leakage."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        r = super().redirect_request(req, fp, code, msg, headers, newurl)
        if r:
            r.remove_header("Authorization")
        return r


def _build_opener() -> urllib.request.OpenerDirector:
    """Build an opener with proxy env vars disabled and safe redirect handling."""
    return urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        _NoAuthRedirectHandler(),
    )


def enforce_transport_policy(api_url: str) -> None:
    """Block all schemes except https and http-to-loopback (allowlist, not denylist)."""
    parsed = urllib.parse.urlparse(api_url)
    allow_insecure = (os.getenv("MNEMO_ALLOW_INSECURE_HTTP", "") or "").strip() == "1"
    if parsed.scheme not in {"https", "http"}:
        raise RuntimeError(
            f"Blocked scheme '{parsed.scheme}'. Only https (or http for loopback) is permitted."
        )
    if parsed.scheme == "http" and not _is_loopback_host(parsed.hostname):
        if allow_insecure:
            logger.warning(
                "MNEMO_ALLOW_INSECURE_HTTP=1 set. Proceeding with insecure HTTP to %s.",
                api_url,
            )
            return
        raise RuntimeError(
            "Insecure MCP transport blocked: MNEMO_API_URL uses HTTP on a non-loopback host. "
            "Use HTTPS or set MNEMO_ALLOW_INSECURE_HTTP=1 only for controlled testing."
        )


_http_session: Any = None
_http_session_lock = __import__("threading").Lock()


def _get_http_session() -> Any:
    """Return a module-level requests.Session with connection pooling.

    Reuses TCP+TLS connections across calls — eliminates 30-150ms handshake
    overhead that _build_opener() paid on every single call.
    """
    global _http_session
    if _http_session is not None:
        return _http_session
    with _http_session_lock:
        if _http_session is not None:
            return _http_session
        try:
            import requests as _req
            s = _req.Session()
            adapter = _req.adapters.HTTPAdapter(pool_connections=2, pool_maxsize=8)
            s.mount("https://", adapter)
            s.mount("http://", adapter)
            _http_session = s
        except ImportError:
            _http_session = None
    return _http_session


def api_call(
    api_url: str,
    api_token: str,
    method: str,
    path: str,
    body: Optional[Dict[str, Any]] = None,
    timeout_sec: float = 10.0,
    extra_headers: Optional[Dict[str, str]] = None,  # NEW: allow callers to inject headers
) -> Dict[str, Any]:
    """Make an authenticated API call to Mnemo backend.

    Parameters
    ----------
    extra_headers:
        Optional mapping of additional HTTP headers to merge into the request.
        Keys in *extra_headers* override the defaults (Content-Type,
        Authorization) if they collide — callers are responsible for not
        clobbering auth.  The primary use-case is ``Idempotency-Key``.
    """
    url = f"{api_url.rstrip('/')}{path}"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_token}",
    }
    # NEW: merge caller-supplied headers after defaults so they take precedence
    if extra_headers:
        headers.update(extra_headers)
    session = _get_http_session()
    if session is not None:
        try:
            resp = session.request(
                method.upper(),
                url,
                headers=headers,
                json=body if body else None,
                timeout=timeout_sec,
            )
            if not resp.ok:
                body_text = resp.text[:200]
                logger.error("API %s %s -> %d: %s", method, path, resp.status_code, body_text)
                return {"error": f"HTTP {resp.status_code}", "detail": body_text}
            return resp.json()
        except Exception as exc:
            logger.error("API call failed %s %s: %s", method.upper(), path, exc)
            return {"error": str(exc)}
    # Fallback: urllib (if requests not installed)
    data = json.dumps(body or {}).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
    opener = _build_opener()
    try:
        with opener.open(req, timeout=timeout_sec) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        body_text = exc.read().decode()
        logger.error("API %s %s -> %d: %s", method, path, exc.code, body_text[:200])
        return {"error": f"HTTP {exc.code}", "detail": body_text[:200]}
    except Exception as exc:
        logger.error("API call failed %s %s: %s", method.upper(), path, exc)
        return {"error": str(exc)}


def clip_tool_output(text: str) -> str:
    """Apply max output size guard for MCP tool results."""
    max_chars = int(os.getenv("MAX_MCP_OUTPUT_CHARS", "20000"))
    if max_chars < 1000:
        max_chars = 1000
    if len(text) <= max_chars:
        return text
    clipped = text[:max_chars]
    return (
        f"{clipped}\n\n"
        f"[output truncated to {max_chars} chars; set MAX_MCP_OUTPUT_CHARS to increase]"
    )

