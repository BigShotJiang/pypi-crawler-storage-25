"""
mnemo_mcp/attestation.py — Per-profile session attestation registry.

Maintains one SessionAttestationLog per authenticated profile. Sessions are
evicted after SESSION_IDLE_TTL_S seconds of inactivity (default 2 hours).

Thread-safe: all mutations of _ATTESTATION_SESSIONS are under _SESSION_LOCK.
SessionAttestationLog itself is also thread-safe (its own internal lock).

Backend selection (at startup):
  If ATTEST_HMAC_KEY and DATABASE_URL are both set → PostgresBackend (durable).
  Otherwise                                         → InMemoryBackend (dev/test).

A warning is logged when InMemoryBackend is used so the gap is never silent.

Stateless server constraint: Mnemo runs with stateless=True in
StreamableHTTPSessionManager — there is no persistent MCP session object.
The "session" here is per-profile (all tool calls from one authenticated
user share one log). If the same user has two concurrent MCP connections
(e.g., Claude Desktop + Claude Code), their leaves are interleaved in one
chain. This is documented as a known v0.1 limitation.

v0.1 limitations:
  - InMemoryBackend loses the log on Cloud Run instance recycle.
    PostgresBackend (enabled via env vars) fixes this.
  - PostgresBackend uses symmetric HMAC — tamper-evident, not non-repudiation.
  - KMS asymmetric signing and epoch sealing deferred (Mnemo thread 29462bd8).
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time

from mcp_attest import SessionAttestationLog, InMemoryBackend

logger = logging.getLogger(__name__)

SESSION_IDLE_TTL_S: float = 7200.0  # 2 hours
_EVICTION_INTERVAL_S: float = 300.0
_last_eviction_run: float = 0.0

_ATTESTATION_SESSIONS: dict[str, SessionAttestationLog] = {}
_ATTESTATION_BACKENDS: dict[str, object] = {}	# profile → PostgresBackend | None
_SESSION_LAST_USED: dict[str, float] = {}
_SESSION_LOCK = threading.Lock()

# Module-level daemon pool — avoids creating a new executor per eviction batch.
# Fire-and-forget: submit only, no wait(). The Cloud Run Job is the durability net.
import concurrent.futures as _cf_attest
_SEAL_EXECUTOR = _cf_attest.ThreadPoolExecutor(
	max_workers=10, thread_name_prefix="mnemo-seal"
)

# ── psycopg2 pool (lazy-initialised) ──────────────────────────────────────────
_PG_POOL = None
_PG_POOL_LOCK = threading.Lock()


def _pg_connect_kwargs(database_url: str) -> dict:
	"""
	Convert DATABASE_URL to psycopg2 keyword arguments.

	Handles the Cloud SQL Unix socket format used in GCP Cloud Run:
	  postgresql://user:pass@/dbname?host=/cloudsql/project:region:instance&sslmode=require

	psycopg2/libpq rejects sslmode=require on Unix socket connections (SSL is
	not supported for Unix-domain sockets — libpq docs). Strip sslmode when
	host is a socket path so the pool doesn't fail at startup in GCP.
	"""
	from urllib.parse import urlparse, parse_qs
	parsed = urlparse(database_url)
	qs = parse_qs(parsed.query)

	# host may be in the query string (Cloud SQL format) or in the netloc
	host = qs.get("host", [parsed.hostname or ""])[0]
	is_socket = host.startswith("/")

	kwargs: dict = {
		"dbname": (parsed.path or "/mnemo").lstrip("/") or "mnemo",
		"user": parsed.username,
		"password": parsed.password,
		"host": host or None,
	}
	if parsed.port:
		kwargs["port"] = parsed.port

	sslmode = qs.get("sslmode", [None])[0]
	if sslmode and not is_socket:
		kwargs["sslmode"] = sslmode
	# Unix socket: omit sslmode entirely — libpq silently rejects SSL on sockets

	return {k: v for k, v in kwargs.items() if v is not None}


def _get_pg_pool():
	"""Return module-level psycopg2 ThreadedConnectionPool, creating it on first call."""
	global _PG_POOL
	if _PG_POOL is not None:
		return _PG_POOL
	with _PG_POOL_LOCK:
		if _PG_POOL is not None:
			return _PG_POOL
		import psycopg2.pool
		database_url = os.environ.get("DATABASE_URL", "")
		if not database_url:
			return None
		try:
			kwargs = _pg_connect_kwargs(database_url)
			_PG_POOL = psycopg2.pool.ThreadedConnectionPool(minconn=2, maxconn=10, **kwargs)
			logger.info("[attestation] psycopg2 pool initialised (min=2 max=10)")
		except Exception as exc:
			logger.warning("[attestation] psycopg2 pool init failed: %s — falling back to InMemory", exc)
			return None
		return _PG_POOL


def _use_postgres() -> bool:
	"""True when both ATTEST_HMAC_KEY and DATABASE_URL are present."""
	return bool(os.environ.get("ATTEST_HMAC_KEY")) and bool(os.environ.get("DATABASE_URL"))


def _create_backend_and_session(profile: str, session_id: str, session_root_leaf: dict):
	"""
	Create a PostgresBackend for *profile* and INSERT the session row.
	Returns the backend, or None if Postgres is unavailable (falls back to InMemory).
	"""
	pool = _get_pg_pool()
	if pool is None:
		return None

	from mcp_attest.backends.postgres import PostgresBackend

	def _getconn():
		return pool.getconn()

	def _putconn(conn):
		pool.putconn(conn)

	# INSERT session record — ignore conflict so resume after recycle is safe
	conn = _getconn()
	try:
		with conn.cursor() as cur:
			cur.execute(
				"""
				INSERT INTO mcp_attestation_sessions
					(session_id, profile_id, session_root_leaf, status)
				VALUES (%s, %s, %s::jsonb, 'open')
				ON CONFLICT (session_id) DO NOTHING
				""",
				(session_id, profile, json.dumps(session_root_leaf, sort_keys=True)),
			)
		conn.commit()
	except Exception as exc:
		conn.rollback()
		logger.warning("[attestation] failed to insert session row: %s", exc)
		return None
	finally:
		_putconn(conn)	# always return connection — only called once (bug fix: removed from except)

	try:
		backend = PostgresBackend(
			conn_factory=_getconn,
			return_conn=_putconn,
			session_id=session_id,
			profile_id=profile,
		)
	except RuntimeError:
		# Chain integrity violation — must not fall back to InMemory
		raise
	except Exception as exc:
		logger.warning("[attestation] PostgresBackend init failed: %s — falling back to InMemory", exc)
		return None

	return backend


def _create_postgres_log(profile: str):
	"""
	Build a SessionAttestationLog backed by PostgresBackend for *profile*.

	Strategy: construct the PostgresBackend first (its __init__ generates the
	session_id and session_root internally via SessionAttestationLog), then
	pass it directly to a fresh SessionAttestationLog.  No monkey-patching.

	Returns (log, backend). On any failure returns (InMemoryBackend log, None).
	"""
	pool = _get_pg_pool()
	if pool is None:
		logger.warning("[attestation] no DB pool — using InMemoryBackend for profile=%s", profile[:20])
		return SessionAttestationLog(InMemoryBackend()), None

	from mcp_attest.backends.postgres import PostgresBackend

	def _getconn():
		return pool.getconn()

	def _putconn(conn):
		pool.putconn(conn)

	# Build the log with InMemoryBackend first so we can get session_id + root leaf
	# before touching Postgres. This keeps the session_id stable.
	import secrets as _secrets
	tmp_session_id = f"sess_{_secrets.token_hex(16)}"

	# INSERT session row now (before the log exists) so the FK is satisfied
	conn = _getconn()
	try:
		with conn.cursor() as cur:
			cur.execute(
				"""
				INSERT INTO mcp_attestation_sessions
					(session_id, profile_id, session_root_leaf, status)
				VALUES (%s, %s, '{}'::jsonb, 'open')
				ON CONFLICT (session_id) DO NOTHING
				""",
				(tmp_session_id, profile),
			)
		conn.commit()
	except Exception as exc:
		conn.rollback()
		logger.warning("[attestation] session INSERT failed: %s — falling back to InMemory", exc)
		return SessionAttestationLog(InMemoryBackend()), None
	finally:
		_putconn(conn)

	try:
		backend = PostgresBackend(
			conn_factory=_getconn,
			return_conn=_putconn,
			session_id=tmp_session_id,
			profile_id=profile,
		)
	except RuntimeError:
		# Chain integrity violation — must not fall back to InMemory; propagate to dispatch
		raise
	except Exception as exc:
		logger.warning("[attestation] PostgresBackend init failed: %s — falling back to InMemory", exc)
		return SessionAttestationLog(InMemoryBackend()), None

	# Now build the real log with the Postgres backend.
	# SessionAttestationLog.__init__ appends session_root via backend.append(),
	# which writes sequence=0 to DB. The session_root_leaf JSON in the sessions
	# table is then updated with the real leaf data.
	log = SessionAttestationLog(backend)

	# Back-fill session_root_leaf in the sessions row now that we have the real leaf
	root_leaf = log.session_root_leaf()
	conn2 = _getconn()
	try:
		with conn2.cursor() as cur:
			cur.execute(
				"UPDATE mcp_attestation_sessions SET session_root_leaf = %s::jsonb WHERE session_id = %s",
				(json.dumps(root_leaf, sort_keys=True), tmp_session_id),
			)
		conn2.commit()
	except Exception as exc:
		logger.warning("[attestation] session_root backfill failed (non-fatal): %s", exc)
		conn2.rollback()
	finally:
		_putconn(conn2)

	return log, backend


# ── Public API ────────────────────────────────────────────────────────────────

def get_or_create(profile: str) -> SessionAttestationLog:
	"""Return the active SessionAttestationLog for *profile*, creating one if needed.

	Evicts stale sessions at most once per _EVICTION_INTERVAL_S.
	Sealing (PostgresBackend.seal()) is called OUTSIDE _SESSION_LOCK to avoid
	holding the global lock during DB writes.
	"""
	if not profile:
		raise ValueError("profile must be non-empty")

	global _last_eviction_run
	now = time.monotonic()
	backends_to_seal = []

	with _SESSION_LOCK:
		if (now - _last_eviction_run) >= _EVICTION_INTERVAL_S:
			backends_to_seal = _evict_stale_locked(now)
			_last_eviction_run = now

		if profile not in _ATTESTATION_SESSIONS:
			if _use_postgres():
				log, backend = _create_postgres_log(profile)
				_ATTESTATION_BACKENDS[profile] = backend  # None means InMemory fallback
			else:
				if not os.environ.get("ATTEST_HMAC_KEY"):
					logger.warning(
						"[attestation] ATTEST_HMAC_KEY not set — using InMemoryBackend (not durable)"
					)
				log = SessionAttestationLog(InMemoryBackend())
				_ATTESTATION_BACKENDS[profile] = None

			_ATTESTATION_SESSIONS[profile] = log
			logger.info("[attestation] created session log for profile=%s", profile[:20])

		_SESSION_LAST_USED[profile] = now
		result = _ATTESTATION_SESSIONS[profile]

	# Seal evicted sessions OUTSIDE the lock — DB writes must not hold _SESSION_LOCK.
	# Fire-and-forget: no wait(). Cloud Run Job (seal_stale_sessions) is the durability net.
	for b in backends_to_seal:
		_SEAL_EXECUTOR.submit(_seal_safe, b)

	return result


def get(profile: str) -> SessionAttestationLog | None:
	"""Return the active log for *profile*, or None if no log exists.

	Does NOT create a new log. Does NOT update last-used time.
	Safe to call from read-only paths.
	"""
	if not profile:
		return None
	with _SESSION_LOCK:
		return _ATTESTATION_SESSIONS.get(profile)


def _evict_stale_locked(now: float) -> list:
	"""
	Remove sessions idle longer than SESSION_IDLE_TTL_S.
	Must be called under _SESSION_LOCK.
	Returns list of backends to seal (caller seals them outside the lock).
	"""
	stale = [
		p for p, last in _SESSION_LAST_USED.items()
		if (now - last) > SESSION_IDLE_TTL_S
	]
	evicted_backends = []
	for p in stale:
		_ATTESTATION_SESSIONS.pop(p, None)
		_SESSION_LAST_USED.pop(p, None)
		backend = _ATTESTATION_BACKENDS.pop(p, None)
		if backend is not None:
			evicted_backends.append(backend)
		logger.info("[attestation] evicted idle session log for profile=%s", p[:20])
	return evicted_backends


def _seal_safe(backend) -> None:
	"""Call backend.seal() with error isolation — eviction must not raise."""
	try:
		backend.seal()
	except Exception as exc:
		logger.warning("[attestation] seal() failed for session=%s: %s",
			getattr(backend, '_session_id', '?')[:20], exc)


def active_count() -> int:
	"""Return number of active (non-evicted) session logs."""
	with _SESSION_LOCK:
		return len(_ATTESTATION_SESSIONS)
