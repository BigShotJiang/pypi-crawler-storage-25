"""
_brief_cache.py — 60-second in-process morning-brief cache.

Zero dependency on mnemo_mcp.server — importable in isolation for testing.

Design notes:
  - Key: profile-scoped path string (e.g. /profile/alice/morning-brief).
    Profile isolation is structural: each profile has a unique path prefix.
    Cross-profile leakage is impossible.
  - TTL: 60s, enforced by same-bucket check AND elapsed-time check.
  - Thundering herd: per-profile threading.Lock serialises concurrent cold-start
    callers so only one DB fetch fires per 60s window.
  - No Redis — pure in-process, per-project rule (Postgres only; no Redis).
  - _brief_dict_lock guards the dicts themselves; profile locks guard fetches.
  - Both dicts are capped at _BRIEF_CACHE_MAX_ENTRIES. When a new profile is
    seen and the cap is hit, the oldest entry is evicted from BOTH dicts
    atomically (same key, same _brief_dict_lock acquisition) — FIFO/insertion-
    order, not true LRU — preventing unbounded growth in long-running processes.
  - profile_lock is captured inside _brief_dict_lock so a concurrent eviction
    cannot remove the key between the look-up and the lock acquisition.
  - Fast-path reads use a single .get() call; the result is stored in a local
    variable to avoid TOCTOU KeyError from a concurrent popitem().
"""
from __future__ import annotations

import threading
import time
from collections import OrderedDict
from typing import Any, Callable, Tuple

# ── Module-level state ────────────────────────────────────────────────────────
# Key: profile-scoped path (str)
# Value: (cache_timestamp_float, result_dict)
_brief_cache: "OrderedDict[str, Tuple[float, Any]]" = OrderedDict()

# Per-profile threading.Lock objects (not asyncio — called from ThreadPoolExecutor).
_brief_locks: "OrderedDict[str, threading.Lock]" = OrderedDict()

# Protects _brief_cache and _brief_locks themselves.
_brief_dict_lock = threading.Lock()

_BRIEF_TTL_SECONDS: float = 60.0

# Hard cap on the number of profiles tracked in-process.
_BRIEF_CACHE_MAX_ENTRIES: int = 10_000


def _is_cache_valid(cache_key: str, now: float) -> bool:
	"""Return True iff the cached entry is within the current 60s window and TTL."""
	entry = _brief_cache.get(cache_key)
	if entry is None:
		return False
	cached_ts, _ = entry
	return (
		int(cached_ts // _BRIEF_TTL_SECONDS) == int(now // _BRIEF_TTL_SECONDS)
		and (now - cached_ts) < _BRIEF_TTL_SECONDS
	)


def _fetch_brief_cached(cache_key: str, fetch_fn: Callable[[], Any]) -> Any:
	"""Fetch morning brief with a 60s in-process cache and thundering-herd guard.

	Thread-safe. Uses a per-profile threading.Lock so that even 20 concurrent
	cold-start callers trigger only one DB fetch within any 60s window.
	"""
	# Fast path — single .get() is GIL-atomic; storing in a local avoids the
	# TOCTOU KeyError that would occur if a concurrent popitem() evicts the key
	# between the validity check and the value read.
	now = time.time()
	entry = _brief_cache.get(cache_key)
	if entry is not None:
		cached_ts, value = entry
		if (
			int(cached_ts // _BRIEF_TTL_SECONDS) == int(now // _BRIEF_TTL_SECONDS)
			and (now - cached_ts) < _BRIEF_TTL_SECONDS
		):
			return value

	# Ensure a per-profile lock exists. profile_lock is captured inside
	# _brief_dict_lock so a concurrent eviction cannot delete the key after we
	# check for its presence but before we read it.
	with _brief_dict_lock:
		if cache_key not in _brief_locks:
			if len(_brief_locks) >= _BRIEF_CACHE_MAX_ENTRIES:
				# Evict the same key from both dicts atomically — prevents the two
				# structures from diverging and leaking orphaned locks or cache entries.
				evicted_key, _ = _brief_locks.popitem(last=False)
				_brief_cache.pop(evicted_key, None)
			_brief_locks[cache_key] = threading.Lock()
		profile_lock = _brief_locks[cache_key]

	with profile_lock:
		# Re-check after acquiring lock — another thread may have just populated it.
		# Same single-.get() pattern as the fast path above.
		now = time.time()
		entry = _brief_cache.get(cache_key)
		if entry is not None:
			cached_ts, value = entry
			if (
				int(cached_ts // _BRIEF_TTL_SECONDS) == int(now // _BRIEF_TTL_SECONDS)
				and (now - cached_ts) < _BRIEF_TTL_SECONDS
			):
				return value

		result = fetch_fn()
		with _brief_dict_lock:
			_brief_cache[cache_key] = (time.time(), result)
		return result
