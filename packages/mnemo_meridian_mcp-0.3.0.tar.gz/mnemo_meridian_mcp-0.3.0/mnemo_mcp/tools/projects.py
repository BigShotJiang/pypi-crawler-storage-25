from __future__ import annotations
from typing import Any, Dict, List, Optional
import urllib.parse
import sys as _sys

def _srv(): return _sys.modules['mnemo_mcp.server']

from mnemo_mcp.server import _MAX_TOOL_LIMIT

# Proxy wrappers — tests patch srv.X; wrappers ensure patches propagate here
def _api_call(*a, **kw): return _srv()._api_call(*a, **kw)
def _infer_project_from_cwd(*a, **kw): return _srv()._infer_project_from_cwd(*a, **kw)
def _invalidate_project_slug_cache(*a, **kw): return _srv()._invalidate_project_slug_cache(*a, **kw)
def _profile_path(*a, **kw): return _srv()._profile_path(*a, **kw)
def _record_mcp_usage(*a, **kw): return _srv()._record_mcp_usage(*a, **kw)
def _synthesise_project_context(*a, **kw): return _srv()._synthesise_project_context(*a, **kw)
def _logger(): return _srv().logger


def _handle_list_projects(args: Dict[str, Any]) -> str:
    limit = min(int(args.get("limit", 20)), _MAX_TOOL_LIMIT)
    qs = urllib.parse.urlencode({"limit": limit})
    result = _api_call("GET", f"{_profile_path('/projects')}?{qs}")

    if isinstance(result, dict) and "error" in result:
        return f"list_projects failed: {result['error']}. Try again or check your connection. [code: LIST_PROJECTS_FAILED]"
    projects = result if isinstance(result, list) else result.get("projects", [])

    usage_resp = _record_mcp_usage("list_projects")
    quota_notice = (
        f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        if usage_resp.get("quota_exceeded") else ""
    )

    if not projects:
        # Bug 2 fix: surface a helpful hint so the user knows how to create a project.
        inferred = _infer_project_from_cwd()
        detected = f"'{inferred}'" if inferred else "none detected"
        return (
            f"No projects found. Tip: tag a session with project='<slug>' to create one. "
            f"Detected CWD project: {detected}."
        ) + quota_notice

    lines = [f"Projects ({len(projects)}):"]
    for p in projects:
        slug = p.get("slug") or p.get("project") or p.get("name", "?")
        sessions = p.get("session_count", "?")
        decisions = p.get("decision_count", "?")
        threads = p.get("thread_count", "?")
        last_active = p.get("last_active") or p.get("updated_at", "?")
        ptype = p.get("type", "formal")
        tag = " [implicit]" if ptype == "implicit" else ""
        lines.append(f"  {slug}{tag} — {sessions} sessions, {decisions} decisions, {threads} threads — last: {last_active}")
    return "\n".join(lines) + quota_notice


def _handle_create_project(args: Dict[str, Any]) -> str:
	name = str(args.get("name", "")).strip()
	if not name:
		return "Error: name is required."
	body: Dict[str, Any] = {"name": name, "goal": args.get("goal", ""), "color": "#6366F1"}
	if args.get("slug"):
		body["slug"] = str(args["slug"]).strip()
	result = _api_call("POST", _profile_path("/projects"), body)
	if isinstance(result, dict) and "error" in result:
		detail = result.get("detail", "")
		return f"create_project failed: {result['error']} — {detail}. Project was not created. [code: CREATE_PROJECT_FAILED]"
	_invalidate_project_slug_cache()
	_record_mcp_usage("create_project")
	slug = result.get("slug", "?")
	pid = result.get("project_id", "?")
	return f"Project created. slug: {slug} | id: {pid}\nUse project='{slug}' in other tools to scope to this project."


def _handle_close_project(args: Dict[str, Any]) -> str:
	project = str(args.get("project", "")).strip()
	if not project:
		return "Error: project slug is required."
	reason = str(args.get("reason", "")).strip()
	body: Dict[str, Any] = {}
	if reason:
		body["reason"] = reason
	result = _api_call("POST", _profile_path(f"/projects/{urllib.parse.quote(project, safe='')}/archive"), body)
	if isinstance(result, dict) and "error" in result:
		detail = result.get("detail", "")
		return f"close_project failed: {result['error']} — {detail}. Project was not archived. [code: CLOSE_PROJECT_FAILED]"
	_record_mcp_usage("close_project")
	was_implicit = result.get("was_implicit", False)
	pid = result.get("project_id", "?")
	note = " (was implicit — formal record created)" if was_implicit else ""
	return f"Project '{project}' archived{note}. id: {pid}"


def _fetch_domains_for_project(project: str) -> List[Dict[str, Any]]:
    """Return [{name, count}] for the project's decision domains. Best-effort; returns [] on error."""
    try:
        result = _api_call(
            "POST", _profile_path("/intelligence/di/list_decision_domains"),
            {"scope": "me", "project": project},
            timeout_sec=0.5,
        )
        if isinstance(result, dict) and "domains" in result:
            return [{"name": d.get("name", "?"), "count": d.get("decision_count", 0)} for d in result["domains"]]
    except Exception as exc:
        _logger().debug("[get_project_context] domains fetch failed: %s", exc, exc_info=True)
    return []


def _handle_get_project_context(args: Dict[str, Any]) -> str:
    project = args.get("project", "").strip()
    if not project:
        return "Error: project slug is required."
    max_tokens = args.get("max_tokens", 2000)

    result = _api_call(
        "GET",
        f"{_profile_path(f'/projects/{urllib.parse.quote(project)}/context')}?max_tokens={max_tokens}",
    )

    if isinstance(result, dict) and "error" in result:
        if result.get("error", "").startswith("HTTP 404"):
            return _synthesise_project_context(project, max_tokens)
        return f"get_project_context failed: {result['error']}. Check the project slug and try again. [code: GET_PROJECT_CONTEXT_FAILED]"

    context_block = result.get("context_block") or result.get("content", "")
    if not context_block:
        return _synthesise_project_context(project, max_tokens)

    domains = _fetch_domains_for_project(project)
    if domains:
        domain_lines = ", ".join(f"{d['name']} ({d['count']})" for d in domains)
        context_block = context_block + f"\n\nDomains: {domain_lines}"

    usage_resp = _record_mcp_usage("get_project_context")
    quota_notice = (
        f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        if usage_resp.get("quota_exceeded") else ""
    )
    return context_block + quota_notice


# ── Project boundary tools ─────────────────────────────────────────────────────

def _handle_set_project_boundary(args: Dict[str, Any]) -> str:
	project_id = str(args.get("project_id", "")).strip()
	mode = str(args.get("mode", "")).strip()
	if not project_id:
		return "Error: project_id is required."
	if mode not in ("open", "isolated"):
		return "Error: mode must be 'open' or 'isolated'."
	result = _api_call(
		"PUT",
		_profile_path(f"/projects/{urllib.parse.quote(project_id)}/boundary"),
		{"mode": mode},
	)
	if isinstance(result, dict) and "error" in result:
		detail = result.get("detail", "")
		return f"Error setting boundary: {result['error']} — {detail}"
	_record_mcp_usage("set_project_boundary")
	return f"Boundary mode for project '{project_id}' set to '{mode}'."


def _handle_get_project_boundary(args: Dict[str, Any]) -> str:
	project_id = str(args.get("project_id", "")).strip()
	if not project_id:
		return "Error: project_id is required."
	result = _api_call(
		"GET",
		_profile_path(f"/projects/{urllib.parse.quote(project_id)}/boundary"),
	)
	if isinstance(result, dict) and "error" in result:
		return f"Error fetching boundary: {result['error']}"
	_record_mcp_usage("get_project_boundary")
	mode = result.get("boundary_mode", "?")
	overridable = result.get("overridable", False)
	return (
		f"Project '{project_id}': boundary_mode={mode}, overridable={overridable}"
	)


def _handle_set_dedup_window(args: Dict[str, Any]) -> str:
	try:
		days = int(args.get("days", 180))
	except (TypeError, ValueError):
		return "Error: days must be an integer."
	if not (30 <= days <= 730):
		return "Error: days must be between 30 and 730."
	result = _api_call(
		"PUT",
		_profile_path("/dedup-window"),
		{"days": days},
	)
	if isinstance(result, dict) and "error" in result:
		return f"Error setting dedup window: {result['error']}"
	_record_mcp_usage("set_dedup_window")
	return f"Dedup lookback window set to {days} days."


def _handle_grant_cross_project_visibility(args: Dict[str, Any]) -> str:
	from_project = str(args.get("from_project_id", "")).strip()
	to_project = str(args.get("to_project_id", "")).strip()
	expires_days = int(args.get("expires_days", 365))
	if not from_project or not to_project:
		return "Error: from_project_id and to_project_id are required."
	expires_days = min(expires_days, 365)
	result = _api_call(
		"POST",
		_profile_path("/visibility-grants"),
		{"from_project_id": from_project, "to_project_id": to_project, "expires_days": expires_days},
	)
	if isinstance(result, dict) and "error" in result:
		detail = result.get("detail", "")
		return f"Error granting visibility: {result['error']} — {detail}"
	_record_mcp_usage("grant_cross_project_visibility")
	grant_id = result.get("id", "?")
	expires = result.get("expires_at", "?")
	return (
		f"Visibility grant created: {from_project} → {to_project}. "
		f"id: {grant_id}, expires: {expires}"
	)


def _handle_revoke_cross_project_visibility(args: Dict[str, Any]) -> str:
	from_project = str(args.get("from_project_id", "")).strip()
	to_project = str(args.get("to_project_id", "")).strip()
	if not from_project or not to_project:
		return "Error: from_project_id and to_project_id are required."
	result = _api_call(
		"DELETE",
		_profile_path(
			f"/visibility-grants?from_project_id={urllib.parse.quote(from_project)}"
			f"&to_project_id={urllib.parse.quote(to_project)}"
		),
	)
	if isinstance(result, dict) and "error" in result:
		return f"Error revoking visibility: {result['error']}"
	_record_mcp_usage("revoke_cross_project_visibility")
	return f"Visibility grant revoked: {from_project} → {to_project}."

