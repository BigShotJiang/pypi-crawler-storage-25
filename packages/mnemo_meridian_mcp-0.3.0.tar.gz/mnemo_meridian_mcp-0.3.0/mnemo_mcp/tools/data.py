from __future__ import annotations
from typing import Any, Dict, List, Optional
import json
import os
import urllib.parse
import sys as _sys

def _srv(): return _sys.modules['mnemo_mcp.server']


# Proxy wrappers — tests patch srv.X; wrappers ensure patches propagate here
def _api_call(*a, **kw): return _srv()._api_call(*a, **kw)
def _format_export_review(*a, **kw): return _srv()._format_export_review(*a, **kw)
def _record_mcp_usage(*a, **kw): return _srv()._record_mcp_usage(*a, **kw)
def _resolve_profile(*a, **kw): return _srv()._resolve_profile(*a, **kw)
def _resolve_profile_write(*a, **kw): return _srv()._resolve_profile_write(*a, **kw)


def _handle_submit_feedback(args: Dict[str, Any]) -> str:
    """Submit product feedback to the Mnemo team via the backend /feedback endpoint."""
    message = str(args.get("message") or "").strip()
    if not message:
        return "Error: message is required."
    if len(message) > 2000:
        return "Error: message must be 2000 characters or fewer."

    category = str(args.get("category") or "other").strip()
    valid_categories = {"usability", "calibration", "feature_request", "bug", "other"}
    if category not in valid_categories:
        category = "other"

    body = {"message": message, "category": category, "source": "mcp", "consent_acknowledged": True}
    try:
        result = _api_call("POST", "/feedback", body)
    except (ConnectionError, TimeoutError, OSError) as e:
        return f"Error submitting feedback: network error — {str(e)}"

    if isinstance(result, dict) and result.get("ok"):
        parts = ["Feedback submitted successfully."]
        pii = result.get("pii_detected") or []
        if pii:
            parts.append(f"Note: the following patterns were detected and redacted before storage: {', '.join(pii)}.")
        prop = result.get("proprietary_warnings") or []
        if prop:
            parts.append(f"Note: potential proprietary content detected: {', '.join(prop)}.")
        parts.append(result.get("warning", ""))
        _record_mcp_usage("submit_feedback")
        return " ".join(p for p in parts if p)
    elif isinstance(result, dict) and "detail" in result:
        detail = result["detail"]
        if isinstance(detail, list):
            msgs = "; ".join(e.get("msg", str(e)) for e in detail)
            return f"Feedback validation failed: {msgs}"
        return f"Feedback validation failed: {detail}"
    elif isinstance(result, dict) and "error" in result:
        return f"submit_feedback failed: {result['error']}. Your feedback was not submitted. [code: SUBMIT_FEEDBACK_FAILED]"
    else:
        return f"submit_feedback failed: unexpected response from server. Your feedback may not have been submitted. [code: SUBMIT_FEEDBACK_UNEXPECTED]"


def _handle_export_data(args: Dict[str, Any]) -> str:
    """Two-phase export: preview (count+estimate) then full payload on confirmed=true."""
    profile = _resolve_profile(args)
    use_case = str(args.get("use_case") or "review").strip().lower()
    include = str(args.get("include") or "all").strip().lower()
    project = str(args.get("project") or "").strip()
    confirmed = bool(args.get("confirmed", False))

    params: Dict[str, Any] = {"include": include, "confirmed": str(confirmed).lower()}
    if project:
        params["project"] = project
    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"/profile/{urllib.parse.quote(profile)}/export/inline?{qs}")

    if isinstance(result, dict) and "error" in result:
        return f"export_data failed: {result['error']}. Check your include filter and try again. [code: EXPORT_FAILED]"

    # ── Preview phase ─────────────────────────────────────────────────────────
    if result.get("status") == "preview":
        counts = result.get("counts", {})
        total = result.get("total_records", 0)
        est = result.get("estimated_tokens", 0)
        lines = [
            f"Export preview — {use_case} / include={include}",
            "",
            "Record counts:",
        ]
        for k, v in counts.items():
            lines.append(f"  {k}: {v:,}")
        lines.append(f"  total: {total:,}")
        lines.append("")
        lines.append(f"Estimated context tokens: ~{est:,}")
        lines.append("")
        lines.append(
            "⚠ Call export_data again with confirmed=true ONLY after the user has "
            "acknowledged the token cost above."
        )
        _record_mcp_usage("export_data")
        return "\n".join(lines)

    # ── Confirmed: full payload ────────────────────────────────────────────────
    datasets = result.get("datasets", {})
    manifest = result.get("manifest", {})

    if use_case == "review":
        return _format_export_review(datasets, manifest)

    # backup / portability: return compact JSON
    # Guard: cap encoding cost before json.dumps blocks the thread on large exports.
    _total_records = sum(
        len(v) if isinstance(v, list) else 1
        for v in datasets.values()
    ) if isinstance(datasets, dict) else 0
    if _total_records > 5000:
        _record_mcp_usage("export_data")
        return (
            f"Export too large ({_total_records:,} records). "
            f"Use export_data with a narrower include= filter or smaller time window."
        )
    payload = json.dumps({"manifest": manifest, "datasets": datasets}, default=str)
    char_count = len(payload)
    _record_mcp_usage("export_data")
    return (
        f"# Mnemo export — {use_case}\n"
        f"Profile: {manifest.get('profile', profile)} | "
        f"Exported: {manifest.get('exported_at', '')[:19]}\n"
        f"Records: {manifest.get('counts', {})}\n\n"
        f"```json\n{payload}\n```\n\n"
        f"[{char_count:,} chars — copy the JSON block above to use with import_data]"
    )


def _handle_import_data(args: Dict[str, Any]) -> str:
    """Import previously exported datasets into the authenticated profile."""
    profile = _resolve_profile_write(args)
    datasets_json = str(args.get("datasets_json") or "").strip()
    use_case = str(args.get("use_case") or "restore").strip().lower()
    source_profile = str(args.get("source_profile") or "").strip()
    project_namespace = str(args.get("project_namespace") or "").strip()

    if not datasets_json:
        return "Error: datasets_json is required (paste the JSON from a prior export_data call)."

    # H-37: bound input size (default 5 MiB). Reject oversized payloads before
    # JSON parsing so we don't allocate hundreds of MB on a crafted blob.
    _max_bytes = int(os.getenv("MNEMO_MCP_IMPORT_MAX_BYTES", str(5 * 1024 * 1024)))
    if len(datasets_json.encode("utf-8")) > _max_bytes:
        return (
            f"Error: datasets_json exceeds the maximum allowed size of "
            f"{_max_bytes} bytes. Split the export into smaller chunks."
        )

    if use_case not in {"restore", "handoff", "merge"}:
        return "Error: use_case must be restore, handoff, or merge."

    try:
        datasets = json.loads(datasets_json)
    except json.JSONDecodeError as exc:
        return f"Error: datasets_json is not valid JSON — {exc}"

    # datasets_json may be the full export payload OR just the datasets dict
    if "datasets" in datasets and isinstance(datasets["datasets"], dict):
        datasets = datasets["datasets"]

    # PI-gate: scan record-level string content after json.loads.
    # Top-level scan in _scan_write_args only covers the first 500 chars of the
    # raw JSON string — per-record scan covers the full parsed payload.
    try:
        from backend.security import scan_for_injection, InjectionDetected, _sanitize_for_prompt
        _scan_limit = int(os.getenv("MNEMO_IMPORT_SCAN_MAX_RECORDS", "500"))
        _scan_count = 0

        def _scan_datasets(obj: Any) -> None:
            nonlocal _scan_count
            if _scan_count >= _scan_limit:
                return
            if isinstance(obj, str) and obj:
                _scan_count += 1
                scan_for_injection(_sanitize_for_prompt(obj), "import_record")
            elif isinstance(obj, dict):
                for v in obj.values():
                    _scan_datasets(v)
            elif isinstance(obj, list):
                for item in obj:
                    _scan_datasets(item)

        _scan_datasets(datasets)
    except InjectionDetected:
        return "Error: import rejected — input contains disallowed patterns."
    except ImportError:
        pass  # pip-package mode — no backend available
    except Exception as _scan_exc:
        import logging as _log
        _log.getLogger(__name__).error("[pi-gate] import scan error: %s", _scan_exc, exc_info=True)
        return "Error: import rejected — input could not be scanned."

    body: Dict[str, Any] = {
        "datasets": datasets,
        "use_case": use_case,
    }
    if source_profile:
        body["source_profile"] = source_profile
    if project_namespace:
        body["project_namespace"] = project_namespace

    result = _api_call("POST", f"/profile/{urllib.parse.quote(profile)}/import", body)

    if isinstance(result, dict) and "error" in result:
        return f"import_data failed: {result['error']}. Data was not imported. [code: IMPORT_FAILED]"

    imp = result.get("imported", {})
    skp = result.get("skipped", {})
    ns = result.get("namespace")
    total = result.get("total_imported", 0)

    lines = [
        f"Import complete — {use_case}",
        f"Namespace: {ns}" if ns else "",
        "",
        "Imported:",
    ]
    for k, v in imp.items():
        sk = skp.get(k, 0)
        lines.append(f"  {k}: {v} imported" + (f", {sk} skipped" if sk else ""))
    lines.append(f"\nTotal: {total} records imported")

    if use_case == "handoff" and ns:
        lines.append(
            f"\nAll imported records are tagged with project='{ns}'. "
            f"Use get_project_context(project='{ns}') to review them."
        )
    elif use_case == "restore":
        lines.append("\nOriginal record IDs preserved. Your memory is restored.")

    _record_mcp_usage("import_data")
    return "\n".join(l for l in lines if l is not None)

