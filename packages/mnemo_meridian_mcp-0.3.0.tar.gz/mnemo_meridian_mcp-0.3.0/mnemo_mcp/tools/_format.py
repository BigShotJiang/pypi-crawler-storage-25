"""Shared output formatters for all MCP tool handlers.

Rules:
- All data lists → markdown pipe tables (table())
- All write confirmations → confirm()
- Warnings → warn()
- Empty states → prose string, never an empty table
- IDs: 8 chars in tables, full in confirmation lines
- Decision/Thread text: max 60 chars, truncated with …
- Warning symbol: ⚠ (U+26A0) — NOT the emoji ⚠️
"""
from __future__ import annotations
from typing import Optional


_TEXT_MAX = 60
_ID_SHORT = 8


def _trunc(s: str, n: int = _TEXT_MAX) -> str:
    s = str(s or "")
    return s if len(s) <= n else s[:n - 1] + "…"


def _short_id(id_: str) -> str:
    s = str(id_ or "")
    return s[:_ID_SHORT] if len(s) > _ID_SHORT else s


def table(headers: list[str], rows: list[list[str]]) -> str:
    """Render a markdown pipe table.

    Headers and cell values are used as-is — callers are responsible for
    truncating long text fields before passing them in (use _trunc / _short_id).
    """
    if not rows:
        return ""
    sep = "|" + "|".join("-" * (len(h) + 2) for h in headers) + "|"
    head = "| " + " | ".join(headers) + " |"
    body = "\n".join("| " + " | ".join(str(c) for c in row) + " |" for row in rows)
    return f"{head}\n{sep}\n{body}"


def confirm(
    entity_type: str,
    entity_id: str,
    verb: Optional[str] = None,
    note: Optional[str] = None,
) -> str:
    """Render a write confirmation.

    Full ID is always shown (not truncated) so users can copy it for follow-up calls.
    Examples:
        confirm("Decision", "dec_abc123", "recorded")
        → ✓ Decision dec_abc123 recorded
        confirm("Thread", "thr_456", "resolved", "no longer needed")
        → ✓ Thread thr_456 resolved — no longer needed
        confirm("Session", "ses_789")
        → ✓ Session ses_789
    """
    parts = [f"✓ {entity_type} {entity_id}"]
    if verb:
        parts[0] += f" {verb}"
    if note:
        parts.append(f"— {note[:120]}")
    return " ".join(parts)


def warn(message: str) -> str:
    """Render a warning line. Uses ⚠ (U+26A0, not emoji ⚠️)."""
    return f"⚠ {message}"


def quota_notice(used: int | str, limit: int | str, upgrade_url: str = "") -> str:
    base = f"⚠ Usage: {used}/{limit} MCP calls this month"
    if upgrade_url:
        base += f" — upgrade at {upgrade_url}"
    return base


def format_usage_snapshot(usage_snap: dict) -> str:
    """Render the usage_snapshot dict as markdown lines.

    Returns an empty string when total_calls is 0 or the dict is empty.
    Pure function — no I/O, no server imports.
    """
    if not usage_snap or usage_snap.get("total_calls", 0) <= 0:
        return ""
    clients = usage_snap.get("clients") or {}
    days = usage_snap.get("days", 7)
    total = usage_snap["total_calls"]
    rows = [
        [k.title(), str(v)]
        for k, v in sorted(clients.items(), key=lambda x: -x[1])
        if v > 0
    ]
    lines = [f"\n**Your Usage (last {days}d) — {total} calls**"]
    if rows:
        lines.append("\n" + table(["Source", "Calls"], rows))
    most_active = usage_snap.get("most_active_day")
    if most_active:
        lines.append(f"Most active: {most_active}")
    return "\n".join(lines)
