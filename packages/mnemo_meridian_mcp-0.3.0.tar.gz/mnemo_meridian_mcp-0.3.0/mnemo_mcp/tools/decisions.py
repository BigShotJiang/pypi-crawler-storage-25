from __future__ import annotations
from typing import Any, Dict, List, Optional
from concurrent.futures import ThreadPoolExecutor
import re as _re
import urllib.parse
import uuid as _uuid_mod
import sys as _sys

_ISO_DATE_RE = _re.compile(r"^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}:\d{2}([.]\d+)?(Z|[+-]\d{2}:\d{2})?)?$")

def _srv(): return _sys.modules['mnemo_mcp.server']

from mnemo_mcp.server import _MAX_TOOL_LIMIT, _MCP_API_TOKEN_HINT
from mnemo_mcp.tools._format import table, confirm, warn, quota_notice, _trunc, _short_id


# Proxy wrappers — tests patch srv.X; wrappers ensure patches propagate here
def _active_profile(*a, **kw): return _srv()._active_profile(*a, **kw)
def _api_call(*a, **kw): return _srv()._api_call(*a, **kw)
def _enforce_max_len(*a, **kw): return _srv()._enforce_max_len(*a, **kw)
def _handle_get_blocked_decisions_proxy(*a, **kw): return _srv()._handle_get_blocked_decisions(*a, **kw)
def _handle_get_stale_decisions_proxy(*a, **kw): return _srv()._handle_get_stale_decisions(*a, **kw)
def _maybe_surface_related(*a, **kw): return _srv()._maybe_surface_related(*a, **kw)
def _profile_path(*a, **kw): return _srv()._profile_path(*a, **kw)
def _record_mcp_usage(*a, **kw): return _srv()._record_mcp_usage(*a, **kw)
def _resolve_profile(*a, **kw): return _srv()._resolve_profile(*a, **kw)
def _resolve_profile_write(*a, **kw): return _srv()._resolve_profile_write(*a, **kw)
def _resolve_project(*a, **kw): return _srv()._resolve_project(*a, **kw)
def _safe_scrub(*a, **kw): return _srv()._safe_scrub(*a, **kw)
def _validate_project_slug(*a, **kw): return _srv()._validate_project_slug(*a, **kw)


def _register_reference_internal(decision_id: str, referenced_by: str) -> None:
    """Auto-fire reference tracking when a decision is returned. Best-effort; never blocks.

    scope="me" is intentional — the backend records the reference against the caller's
    profile (resolved from the bearer token), not the decision owner. Backend contract:
    a team/org-scoped search returning another user's decision must NOT create a reference
    record under that other user's profile.
    """
    try:
        _api_call(
            "POST", _profile_path("/intelligence/di/register_decision_reference"),
            {"decision_id": decision_id, "referenced_by": referenced_by, "scope": "me"},
            timeout_sec=0.5,
        )
    except Exception:
        pass


def _append_intel_footer(lines: list, include_intel: bool) -> None:
    """Append contradiction + assumption intel lines to `lines` when include_intel=True.

    Fires two background API calls; total latency is ~3–6s. Best-effort: individual
    failures are logged at DEBUG and never propagate to the caller.
    """
    if not include_intel:
        return
    intel_lines: list[str] = []
    _intel_conflicts_path = _profile_path("/decisions/contradictions")
    _intel_assumptions_path = _profile_path("/decisions/assumptions")

    # ThreadPoolExecutor automatically propagates contextvars (including
    # _MCP_API_TOKEN_HINT) to worker threads — no manual capture needed.
    def _fetch_intel_conflicts() -> Any:
        return _api_call("GET", _intel_conflicts_path, timeout_sec=10.0)

    def _fetch_intel_assumptions_probe() -> Any:
        return _api_call("GET", f"{_intel_assumptions_path}?status=open&limit=1", timeout_sec=10.0)

    _intel_ex = ThreadPoolExecutor(max_workers=2)
    _f_conflicts = _intel_ex.submit(_fetch_intel_conflicts)
    _f_probe = _intel_ex.submit(_fetch_intel_assumptions_probe)
    try:
        _conflicts = _f_conflicts.result(timeout=12.0)
        if isinstance(_conflicts, list) and _conflicts:
            n = len(_conflicts)
            intel_lines.append(f"[!] {n} active conflict{'s' if n != 1 else ''} detected — review with get_contradictions()")
    except Exception as exc:
        _srv().logger.debug("[intel-footer] conflicts fetch failed: %s", exc, exc_info=True)
    try:
        _probe = _f_probe.result(timeout=12.0)
        if isinstance(_probe, list) and _probe:
            def _fetch_intel_count() -> Any:
                return _api_call("GET", f"{_intel_assumptions_path}?status=open&limit=200", timeout_sec=10.0)
            try:
                _count = _fetch_intel_count()
                n_asm = len(_count) if isinstance(_count, list) else 1
            except Exception:
                n_asm = 1
            intel_lines.append(f"[~] {n_asm} open assumption{'s' if n_asm != 1 else ''} may need validation")
    except Exception as exc:
        _srv().logger.debug("[intel-footer] assumptions probe failed: %s", exc, exc_info=True)
    _intel_ex.shutdown(wait=False, cancel_futures=True)
    if intel_lines:
        lines.append("")
        lines.extend(intel_lines)


def _handle_get_decisions(args: Dict[str, Any]) -> str:
	# stale / blocked modes delegate to existing handlers (same API calls)
	if args.get("stale"):
		stale_args = dict(args)
		stale_args["days"] = args.get("stale_days", 14)
		return _handle_get_stale_decisions_proxy(stale_args)
	if args.get("blocked"):
		return _handle_get_blocked_decisions_proxy(args)

	# Route directly to /decisions/merged — lightweight, no embedding computation.
	# Previously delegated to _handle_search_decisions → POST /intelligence/di/search_decisions
	# which triggered DI embedding path (11× over latency budget).
	params: dict = {
		"status": args.get("status", "open"),
		"limit": args.get("limit", 10),
	}
	if args.get("domain"):
		params["domain"] = args["domain"]
	# Map project from either flat param or nested filter format
	project = args.get("project") or (args.get("filter") or {}).get("project")
	if project:
		params["project"] = project
	if args.get("include_full"):
		params["include_full"] = "true"

	qs = urllib.parse.urlencode(params)
	result = _api_call("GET", f"{_profile_path('/decisions/merged')}?{qs}")

	if isinstance(result, list):
		decisions = result
	elif isinstance(result, dict) and "error" in result:
		return f"get_decisions failed: {result['error']}. Check your filters and try again. [code: GET_DECISIONS_FAILED]"
	else:
		decisions = result

	usage_resp = _record_mcp_usage("get_decisions")
	quota_notice = (
		f"\n[{usage_resp.get('used','?')}/{usage_resp.get('limit','?')} MCP calls]"
		if usage_resp.get("quota_exceeded") else ""
	)

	deprecation_note = (
		"[DEPRECATED] get_decisions will be removed in the next release. "
		"Use search_decisions(scope='me', status='open') instead.\n"
	)

	# intel footer: default True — shows contradictions/assumptions count inline
	include_intel = bool(args.get("include_intel", True))

	# D-2: compact format (default) returns a JSON array; table format returns markdown table.
	fmt = str(args.get("format", "compact")).strip().lower()

	if not decisions:
		if include_intel:
			lines = [deprecation_note + "No open decisions found." + quota_notice]
			_append_intel_footer(lines, True)
			return "\n".join(lines)
		return deprecation_note + "No open decisions found." + quota_notice

	if fmt == "compact":
		rows = [
			[
				str(d.get("domain", "general")),
				str(d.get("content", ""))[:60],
				str(d.get("confidence_label") or d.get("confidence_score") or ""),
				_short_id(str(d.get("decision_id") or d.get("id") or "")),
			]
			for d in decisions
		]
		compact_out = deprecation_note + f"{len(decisions)} decision(s):\n" + table(["Domain", "Decision", "Conf", "ID"], rows) + quota_notice
		if include_intel:
			lines = [compact_out]
			_append_intel_footer(lines, True)
			return "\n".join(lines)
		return compact_out

	rows = [
		[
			str(d.get("domain", "general")),
			str(d.get("content", ""))[:60],
			str(d.get("confidence_label") or d.get("confidence_score") or ""),
			str(d.get("timestamp") or d.get("created_at") or "")[:10],
		]
		for d in decisions
	]
	output = deprecation_note + table(["Domain", "Decision", "Conf", "Date"], rows) + quota_notice
	if include_intel:
		lines = [output]
		_append_intel_footer(lines, True)
		return "\n".join(lines)
	return output


def _handle_get_decision_clusters(args: Dict[str, Any]) -> str:
    """DI Phase 1: fetch decision clusters via GET /intelligence/di/clusters."""
    limit = max(1, min(50, int(args.get("limit") or 10)))
    params: Dict[str, Any] = {"limit": limit}
    # accept `by` (new name) or `cluster_type` (legacy alias)
    cluster_type = (args.get("by") or args.get("cluster_type") or "").strip().lower()
    if cluster_type:
        if cluster_type not in ("domain", "temporal", "recurrence"):
            return (
                "Error: cluster_type must be one of 'domain', 'temporal', 'recurrence'."
            )
        params["cluster_type"] = cluster_type
    if args.get("refresh"):
        params["refresh"] = "true"
    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"{_profile_path('/intelligence/di/clusters')}?{qs}")

    if isinstance(result, dict) and "error" in result:
        return "Error fetching clusters. Try again or check your filters. [code: CLUSTER_FETCH_FAILED]"

    clusters = result.get("clusters") if isinstance(result, dict) else None
    if clusters is None and isinstance(result, list):
        clusters = result
    clusters = clusters or []

    usage_resp = _record_mcp_usage("get_decision_clusters")
    quota_notice = (
        f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        if usage_resp.get("quota_exceeded") else ""
    )

    if not clusters:
        return "No decision clusters found — log more decisions to surface patterns." + quota_notice

    lines = [f"Decision Clusters ({len(clusters)}):"]
    lines.append(f"{'TYPE':<12} {'SIZE':<6} {'QUALITY':<8} LABEL")
    lines.append("-" * 80)
    for c in clusters:
        ctype = str(c.get("cluster_type") or "?")[:10].ljust(10)
        size = str(c.get("size") or 0).ljust(4)
        q = c.get("quality_score")
        quality = f"{float(q):.2f}" if q is not None else "  -  "
        label = str(c.get("label") or c.get("auto_label") or "?")[:70]
        lines.append(f"{ctype}  {size}   {quality:<8} {label}")
        if c.get("cluster_id"):
            lines.append(f"{'':14} id: {c['cluster_id']}")
    return "\n".join(lines) + quota_notice


def _handle_search_decisions(args: Dict[str, Any]) -> str:
    """DI-MVP-004: forward to POST /intelligence/di/search_decisions.

    Core params: query, domain, status, limit (all optional).
    Advanced params: pass as filter={} object or as flat args — both work.
    Scope defaults to "me" when not provided.
    Empty query triggers a metadata-only filter path (no semantic search).
    """
    body: Dict[str, Any] = {}
    for key in (
        "query", "scope", "team_id", "classification", "status", "domain",
        "staleness_max", "include_archive", "referenced_since", "cursor",
        "limit", "reversibility", "decision_type", "exclude_drafts",
    ):
        if key in args and args.get(key) is not None:
            body[key] = args[key]

    # Merge advanced params from optional filter={} object.
    # Flat params take precedence over filter values (backward-compat).
    # SECURITY: "scope" is intentionally excluded from filter merging — it is a
    # security-relevant ACL param and must always be supplied as an explicit flat arg.
    # Allowing filter.scope to silently elevate to "team"/"org" with no query would
    # enable unauthenticated-looking enumeration of all decisions in a wider scope.
    filter_obj = args.get("filter")
    if isinstance(filter_obj, dict):
        for fk in (
            "team_id", "classification", "staleness_max",
            "include_archive", "referenced_since", "cursor", "project",
        ):
            if fk in filter_obj and filter_obj[fk] is not None:
                body.setdefault(fk, filter_obj[fk])

    # scope defaults to "me"; validate only if explicitly provided
    if not body.get("scope"):
        body["scope"] = "me"
    elif body["scope"] not in ("me", "team", "org"):
        return "Error: `scope` must be one of me, team, org."
    if "reversibility" in body and body["reversibility"] not in {"one_way", "two_way", "unknown"}:
        return "Error: reversibility must be one_way, two_way, or unknown."
    if "decision_type" in body and body["decision_type"] not in {"tactical", "strategic", "architectural", "operational", "other"}:
        return "Error: decision_type must be tactical, strategic, architectural, operational, or other."

    result = _api_call(
        "POST", _profile_path("/intelligence/di/search_decisions"), body,
    )

    if isinstance(result, dict) and "error" in result:
        return "search_decisions failed. Check your query and filters, then try again. [code: SEARCH_DECISIONS_FAILED]"

    usage_resp = _record_mcp_usage("search_decisions")
    q_notice = (
        f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        if usage_resp.get("quota_exceeded") else ""
    )

    items = result.get("items", []) if isinstance(result, dict) else []
    summary = result.get("scope_summary", {}) if isinstance(result, dict) else {}
    next_cursor = result.get("next_cursor") if isinstance(result, dict) else None

    for it in items:
        if it.get("decision_id"):
            _register_reference_internal(it["decision_id"], "search")

    if not items:
        lines = [
            f"No decisions matched.  "
            f"total_in_scope={summary.get('total_in_scope', 0)}, "
            f"archived_matching={summary.get('archived_matching', 0)}."
        ]
        _append_intel_footer(lines, bool(args.get("include_intel", False)))
        return "\n".join(lines) + q_notice

    # D-2: compact format (default) returns a prose table; table format adds more columns.
    fmt = str(args.get("format", "compact")).strip().lower()
    if fmt == "compact":
        compact_rows = [
            [
                str(it.get("domain") or ""),
                str(it.get("body_excerpt") or it.get("content") or "")[:60],
                str(it.get("confidence_label") or it.get("confidence_score") or ""),
                _short_id(str(it.get("decision_id") or it.get("id") or "")),
            ]
            for it in items
        ]
        return f"{len(items)} decision(s) matched (scope={body['scope']}):\n" + table(["Domain", "Decision", "Conf", "ID"], compact_rows) + q_notice

    lines = [f"search_decisions ({len(items)} results, scope={body['scope']}):"]
    lines.append(
        f"{'DATE':<12} {'DOMAIN':<12} {'CLASS':<12} {'STATE':<12} "
        f"{'STALE':<6} {'SIM':<6} SCORE  EXCERPT"
    )
    lines.append("-" * 110)
    for it in items:
        date = str(it.get("created_at") or "")[:10]
        domain = str(it.get("domain") or "?")[:10].ljust(10)
        cls = str(it.get("classification") or "?")[:10].ljust(10)
        state = str(it.get("status") or "?")[:10].ljust(10)
        stale = f"{float(it.get('staleness_score') or 0.0):.2f}"
        sim = f"{float(it.get('similarity') or 0.0):.2f}"
        score = f"{float(it.get('final_score') or 0.0):.2f}"
        excerpt = (it.get("body_excerpt") or "")[:60]
        lines.append(
            f"{date:<12} {domain}  {cls}  {state}  {stale}  {sim}  {score}  {excerpt}"
        )
        if it.get("decision_id"):
            lines.append(f"{'':14} id: {it['decision_id']}")
        # Phase 7: surface has_contradiction flag when set by backend cache check
        if it.get("has_contradiction"):
            lines.append(f"{'':14} ⚠️  has_contradiction")

    if next_cursor:
        lines.append(f"\nnext_cursor: {next_cursor}")
    lines.append(
        f"scope_summary: total={summary.get('total_in_scope', 0)}, "
        f"archived_matching={summary.get('archived_matching', 0)}, "
        f"domains={summary.get('domains_represented', [])}"
    )
    _append_intel_footer(lines, bool(args.get("include_intel", False)))
    return "\n".join(lines) + q_notice


def _handle_get_decision_precedent(args: Dict[str, Any]) -> str:
    """DI-MVP-005: forward to POST /intelligence/di/get_decision_precedent.

    k_decisions, k_cohorts, and include_cross_domain are server-side config (k=5).
    They are no longer accepted from callers; stripped here to keep the surface clean.
    """
    body: Dict[str, Any] = {}
    # Only forward the public surface params; k_decisions/k_cohorts/include_cross_domain
    # are now server-side defaults (k=5) and must not be forwarded even if passed.
    for key in ("topic", "scope", "team_id", "domain"):
        if key in args and args.get(key) is not None:
            body[key] = args[key]
    oqf = str(args.get("outcome_quality_filter") or "").strip().lower()
    if oqf in {"good", "mixed", "poor"}:
        body["outcome_quality_filter"] = oqf
    if args.get("include_options"):
        body["include_options"] = True
    # Phase 11: counterfactual mode
    mode = str(args.get("mode") or "precedent").strip().lower()
    if mode not in {"precedent", "counterfactual"}:
        return "Error: mode must be 'precedent' or 'counterfactual'."
    if mode == "counterfactual":
        body["mode"] = "counterfactual"

    if not body.get("topic"):
        return "Error: `topic` is required."
    # scope defaults to "me"; validate only if explicitly provided
    if not body.get("scope"):
        body["scope"] = "me"
    elif body["scope"] not in ("me", "team", "org"):
        return "Error: `scope` must be one of me, team, org."

    result = _api_call(
        "POST", _profile_path("/intelligence/di/get_decision_precedent"), body,
    )

    if isinstance(result, dict) and "error" in result:
        return "Error fetching precedents. Try again or check the decision ID. [code: PRECEDENT_FETCH_FAILED]"

    _record_mcp_usage("get_decision_precedent")

    # Phase 11: counterfactual mode response
    _topic_display = (body.get("topic") or "")[:80]
    if mode == "counterfactual":
        cf_opts = result.get("counterfactual_options", []) if isinstance(result, dict) else []
        if not isinstance(cf_opts, list):
            cf_opts = []
        if not cf_opts:
            return f"No counterfactual options found for topic={_topic_display!r}."
        rows = []
        for cf in cf_opts[:10]:
            dec_id = _short_id(str(cf.get("decision_id") or "?"))
            label = str(cf.get("label_rejected") or "?")[:40]
            rationale = str(cf.get("rationale_rejected") or "")[:50]
            final = str(cf.get("final_choice") or "?")[:30]
            quality = str(cf.get("outcome_quality") or "?")[:8]
            rows.append([dec_id, label, rationale, final, quality])
        return (
            f"Counterfactual options for {_topic_display!r} ({len(cf_opts)} found):\n"
            + table(["Decision", "Rejected Option", "Rationale", "Chosen Instead", "Outcome"], rows)
        )

    precedents = (result.get("direct_precedents", []) if isinstance(result, dict) else [])[:20]
    meta = result.get("_meta", {}) if isinstance(result, dict) else {}

    # Phase 11: recurrence signal
    try:
        recurrence_count = int(result.get("recurrence_count") or 0) if isinstance(result, dict) else 0
    except (ValueError, TypeError):
        recurrence_count = 0
    recurrence_signal = bool(result.get("recurrence_signal", False)) if isinstance(result, dict) else False

    for it in precedents:
        if it.get("decision_id"):
            _register_reference_internal(it["decision_id"], "precedent")

    if not precedents:
        return f"No precedents found for topic={_topic_display!r}.  {meta.get('_mvp_note', '')}"

    lines = [f"get_decision_precedent ({len(precedents)} results, scope={body.get('scope')}):"]

    if recurrence_signal and recurrence_count > 1:
        lines.append(f"⚠️  RECURRENCE SIGNAL — this topic has been decided {recurrence_count}x. Systemic issue?")

    lines.append(f"{'DATE':<12} {'DOMAIN':<12} {'CLASS':<12} {'STATE':<12} {'STALE':<6} {'SIM':<6} {'QUALITY':<8} BODY")
    lines.append("-" * 110)
    for it in precedents:
        date = str(it.get("created_at") or "")[:10]
        domain = str(it.get("domain") or "?")[:10].ljust(10)
        cls = str(it.get("classification") or "?")[:10].ljust(10)
        state = str(it.get("status") or "?")[:10].ljust(10)
        stale = f"{float(it.get('staleness_score') or 0.0):.2f}"
        sim = f"{float(it.get('similarity') or 0.0):.2f}"
        quality = str(it.get("outcome_quality") or "-")[:7]
        body_snip = (it.get("body") or "")[:60]
        lines.append(f"{date:<12} {domain}  {cls}  {state}  {stale}  {sim}  {quality:<8} {body_snip}")
        if it.get("decision_id"):
            lines.append(f"{'':14} id: {it['decision_id']}")
        lin = it.get("lineage") or {}
        if lin.get("supersedes"):
            lines.append(f"{'':14} supersedes: {lin['supersedes']}")
        if lin.get("superseded_by"):
            lines.append(f"{'':14} superseded_by: {lin['superseded_by']}")
        # Phase 6: options_considered included when include_options=true
        opts = it.get("options_considered") or []
        if opts:
            lines.append(f"{'':14} options considered ({len(opts)}):")
            for opt in opts[:3]:
                opt_label = str(opt.get("label") or "?")[:40]
                opt_why = str(opt.get("rationale_rejected") or "")[:60]
                lines.append(f"{'':16} - {opt_label}" + (f": {opt_why}" if opt_why else ""))

    lines.append(f"\n[{meta.get('_mvp_note', 'MVP')}]")
    return "\n".join(lines)


def _handle_list_decision_domains(args: Dict[str, Any]) -> str:
    """DI-MVP-005: forward to POST /intelligence/di/list_decision_domains."""
    body: Dict[str, Any] = {}
    for key in ("scope", "team_id", "min_count"):
        if key in args and args.get(key) is not None:
            body[key] = args[key]

    if body.get("scope") not in ("me", "team", "org"):
        return "Error: `scope` must be one of me, team, org."

    result = _api_call(
        "POST", _profile_path("/intelligence/di/list_decision_domains"), body,
    )

    if isinstance(result, dict) and "error" in result:
        return "Error listing domains. Check your scope and try again. [code: LIST_DOMAINS_FAILED]"

    _record_mcp_usage("list_decision_domains")

    domains = result.get("domains", []) if isinstance(result, dict) else []
    if not domains:
        return f"No domains found in scope={body.get('scope')!r}."

    lines = [f"list_decision_domains ({len(domains)} domains, scope={body.get('scope')}):"]
    lines.append(f"{'DOMAIN':<20} {'COUNT':>6}  {'LAST ACTIVE':<12}  POLICY")
    lines.append("-" * 60)
    for d in domains:
        name = str(d.get("name") or "?")[:18].ljust(18)
        count = str(d.get("decision_count", 0)).rjust(6)
        last = str(d.get("last_active_at") or "")[:10]
        policy = "yes" if d.get("has_policy") else "no"
        lines.append(f"{name}  {count}  {last:<12}  {policy}")
    return "\n".join(lines)


def _handle_get_decision_lineage(args: Dict[str, Any]) -> str:
    """DI-MVP-005: forward to POST /intelligence/di/get_decision_lineage."""
    decision_id = (args.get("decision_id") or "").strip()
    if not decision_id:
        return "Error: `decision_id` is required."

    body: Dict[str, Any] = {"decision_id": decision_id}
    if args.get("depth") is not None:
        body["depth"] = int(args["depth"])

    result = _api_call(
        "POST", _profile_path("/intelligence/di/get_decision_lineage"), body,
    )

    if isinstance(result, dict) and "error" in result:
        status = result.get("status_code") or result.get("status")
        if status == 404:
            return f"Decision {decision_id!r} not found."
        return "Error fetching lineage. Check the decision ID and try again. [code: LINEAGE_FETCH_FAILED]"

    _record_mcp_usage("get_decision_lineage")

    root = result.get("root") or {}
    ancestors = result.get("ancestors", [])
    descendants = result.get("descendants", [])
    siblings = result.get("siblings", [])
    contradicting = result.get("contradicting", [])

    lines = [
        f"**Lineage: {_short_id(decision_id)}** — domain={root.get('domain')}, "
        f"class={root.get('classification')}, status={root.get('status')}",
    ]
    # Phase 6: include options_considered for root decision if present
    root_opts = root.get("options_considered") or []
    if root_opts:
        lines.append(f"Options considered ({len(root_opts)}):")
        for opt in root_opts[:5]:
            opt_label = str(opt.get("label") or "?")[:40]
            opt_why = str(opt.get("rationale_rejected") or "")[:60]
            lines.append(f"  - {opt_label}" + (f": {opt_why}" if opt_why else ""))
    rows = []
    for label, items in (
        ("ancestor", ancestors),
        ("descendant", descendants),
        ("sibling", siblings),
        ("contradicts", contradicting),
    ):
        for it in items:
            rows.append([label, _short_id(it.get("decision_id", "?")), str(it.get("domain", "?")), str(it.get("status", "?"))])
    if rows:
        lines.append(table(["Relation", "ID", "Domain", "Status"], rows))
    else:
        lines.append("No related decisions found.")
    return "\n".join(lines)


def _handle_register_decision_reference(args: Dict[str, Any]) -> str:
    """DI-V1-005: forward to POST /intelligence/di/register_decision_reference."""
    decision_id = (args.get("decision_id") or "").strip()
    referenced_by = (args.get("referenced_by") or "").strip()
    scope = (args.get("scope") or "me").strip()

    if not decision_id:
        return "Error: `decision_id` is required."
    if not referenced_by:
        return "Error: `referenced_by` is required."
    if referenced_by not in ("search", "precedent", "lineage", "explicit"):
        return "Error: `referenced_by` must be one of search, precedent, lineage, explicit."
    if scope not in ("me", "team", "org"):
        return "Error: `scope` must be one of me, team, org."

    body: Dict[str, Any] = {
        "decision_id": decision_id,
        "referenced_by": referenced_by,
        "scope": scope,
    }
    if args.get("team_id"):
        body["team_id"] = args["team_id"]

    result = _api_call(
        "POST", _profile_path("/intelligence/di/register_decision_reference"), body,
    )

    if isinstance(result, dict) and "error" in result:
        return "Error registering reference. Check the decision ID and try again. [code: REFERENCE_FAILED]"

    status = result.get("status") if isinstance(result, dict) else "unknown"
    if status == "disabled":
        return f"Reference tracking disabled for this organization (decision_id={decision_id})."
    referenced_at = result.get("referenced_at", "") if isinstance(result, dict) else ""
    return f"Reference recorded: decision_id={decision_id}, referenced_at={referenced_at}"


def _handle_get_entities(args: Dict[str, Any]) -> str:
    limit = min(int(args.get("limit", 5)), _MAX_TOOL_LIMIT)
    params: Dict[str, Any] = {"limit": limit}
    if args.get("name"):
        params["name"] = args["name"]
    if args.get("entity_type"):
        params["type_filter"] = args["entity_type"]
    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"{_profile_path('/entities')}?{qs}")

    if isinstance(result, dict) and "error" in result:
        return f"Error fetching entities: {result['error']}"
    entities = result if isinstance(result, list) else result.get("entities", [])

    usage_resp = _record_mcp_usage("get_entities")
    quota_notice = (
        f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        if usage_resp.get("quota_exceeded") else ""
    )

    if not entities:
        return "No entities found." + quota_notice
    rows = [
        [
            str(e.get("name", "?")),
            str(e.get("type", "?")),
            str(e.get("mention_count") or len(e.get("mentions", []))) + "x",
            str(e.get("last_seen", "?"))[:10],
        ]
        for e in entities
    ]
    return f"Entities ({len(entities)}):\n" + table(["Name", "Type", "Seen", "Last"], rows) + quota_notice


def _handle_log_decision(args: Dict[str, Any]) -> str:
    try:
        content_val = _enforce_max_len(args.get("content", ""), 4000, "content")
        rationale_val = _enforce_max_len(args.get("rationale", ""), 8000, "rationale")
    except ValueError as exc:
        return f"Error: {exc}"
    args = dict(args)
    args["content"] = content_val
    args["rationale"] = rationale_val
    body: Dict[str, Any] = {
        "content": _safe_scrub(args.get("content", "")),
        "confidence": float(args.get("confidence", 0.75)),
        "domain": args.get("domain", "strategy"),
        "rationale": _safe_scrub(args.get("rationale", "")),
        "source_client": _srv()._CLIENT_HINT,
    }
    if args.get("importance"):
        body["importance"] = args["importance"]
    reversibility = str(args.get("reversibility") or "").strip().lower()
    if reversibility in {"one_way", "two_way", "unknown"}:
        body["reversibility"] = reversibility
    decision_type = str(args.get("decision_type") or "").strip().lower()
    if decision_type in {"tactical", "strategic", "architectural", "operational", "other"}:
        body["decision_type"] = decision_type
    review_by = str(args.get("review_by") or "").strip()
    if review_by:
        if not _ISO_DATE_RE.match(review_by):
            return "Error: review_by must be an ISO 8601 date or datetime (e.g. '2026-07-01' or '2026-07-01T09:00:00Z')."
        body["review_by"] = review_by
    body["project"] = _resolve_project(args)
    body["project_id"] = body["project"]
    project_err = _validate_project_slug(body["project"])
    if project_err:
        return project_err
    # NEW: generate a per-call Idempotency-Key so MCP retries are safe.
    # UUID4 is random per invocation — idempotency only kicks in on true
    # network-level retries where the client sends the same UUID again.
    # Callers that want deterministic idempotency can pass idempotency_key
    # in args and we use it directly.
    idem_key: str = str(args.get("idempotency_key") or _uuid_mod.uuid4())
    extra_headers: Dict[str, str] = {"Idempotency-Key": idem_key}
    result = _api_call("POST", _profile_path("/decisions"), body, extra_headers=extra_headers)  # NEW
    if "error" in result:
        _record_mcp_usage("log_decision")
        return "log_decision failed. Check the decision content and try again. [code: LOG_DECISION_FAILED]"
    _record_mcp_usage("log_decision")

    # Source A — fire-and-forget assumption extraction enqueue.
    # Runs AFTER the decision is durably committed (error check above passed).
    # Any failure (QueueFullError, DB error) is swallowed and logged at WARNING.
    _decision_id_for_enqueue = result.get("decision_id")
    _rationale_for_enqueue = args.get("rationale", "")
    if _rationale_for_enqueue and len(_rationale_for_enqueue.strip()) > 20 and _decision_id_for_enqueue:
        _profile_id_for_enqueue = _resolve_profile(args)
        _content_for_enqueue = args.get("content", "")
        import concurrent.futures as _cf_a
        def _source_a_enqueue():
            import asyncio as _asyncio
            import backend.db as _db
            from backend.db_decisions import enqueue_assumption_extraction as _enqueue, QueueFullError as _QFE
            async def _run():
                pool = await _db.get_pool()
                async with pool.acquire(timeout=5.0) as conn:
                    await _enqueue(
                        conn,
                        profile_id=_profile_id_for_enqueue,
                        triggered_by='assumption_extract_rationale',
                        payload={
                            'decision_id': _decision_id_for_enqueue,
                            'decision_content': _content_for_enqueue[:500],
                            'rationale': _rationale_for_enqueue[:500],
                        },
                    )
            try:
                _asyncio.run(_run())
            except _QFE:
                _srv().logger.warning('[log_decision] assumption queue full for profile %s', _profile_id_for_enqueue)
            except Exception:
                _srv().logger.warning('[log_decision] source_a enqueue failed for decision %s', _decision_id_for_enqueue, exc_info=True)
        _ex_a = _cf_a.ThreadPoolExecutor(max_workers=1)
        _ex_a.submit(_source_a_enqueue)
        _ex_a.shutdown(wait=False)
    response = confirm("Decision", result.get("decision_id", "?"), "recorded", _trunc(args.get("content", "")))

    draft_until = str(result.get("draft_until") or "").strip()
    if draft_until:
        response += f"\n[DRAFT] Decision is in draft window until {draft_until[:19]} — cancel with cancel_draft_decision({result.get('decision_id', '?')!r}) to discard."

    alert = result.get("contradiction_alert")
    if alert and alert.get("detected"):
        severity = str(alert.get("severity", "medium")).upper()
        prior = str(alert.get("prior_decision", ""))[:120]
        prior_conf = alert.get("prior_confidence", "")
        prior_status = alert.get("prior_status", "")
        status_note = f" (later {prior_status})" if prior_status not in {"open", ""} else ""
        response += (
            f"\n\n⚠️  CONTRADICTION DETECTED [{severity}]\n"
            f"This conflicts with a prior decision logged at {prior_conf} confidence{status_note}:\n"
            f"  \"{prior}\"\n"
            f"Consider whether the prior reasoning still applies before committing."
        )

    cc_status = result.get("contradiction_check", "")
    if cc_status == "pending":
        response += "\n[contradiction check queued — results appear in morning brief or via get_recent_contradictions]"
    elif cc_status == "unavailable":
        response += "\n[contradiction check unavailable — will retry automatically]"

    # Unit H — Contextual Surface: append related thread note if any.
    try:
        decision_profile = _resolve_profile(args)
        related = _maybe_surface_related(decision_profile, args.get("content", ""), project=args.get("project", ""))
        if related:
            response += related
    except Exception as exc:
        _srv().logger.warning("[log-decision] surface_related failed: %s", exc, exc_info=True)

    # D-1: compact mode by default (~15 tokens); verbose=True returns full confirmation.
    verbose = bool(args.get("verbose", False))
    if not verbose:
        decision_id = result.get("decision_id", "?")
        domain = args.get("domain", "strategy")
        confidence_label = result.get("confidence_label") or "medium"
        return f"logged: {decision_id} ({domain}, {confidence_label})"

    return response


def _handle_log_decisions(args: Dict[str, Any]) -> str:
    """Batch variant: send an array of decisions in one call.

    Calls POST /profile/{name}/decisions/batch. Returns a compact summary
    listing each item's outcome (logged / duplicate / quota_exceeded / error).
    """
    raw_decisions = args.get("decisions")
    if not isinstance(raw_decisions, list) or len(raw_decisions) == 0:
        return "Error: decisions must be a non-empty array."
    if len(raw_decisions) > 25:
        return "Error: max 25 decisions per call."

    items = []
    for i, d in enumerate(raw_decisions):
        if not isinstance(d, dict) or not d.get("content"):
            return f"Error: item {i} missing required field 'content'."
        item: Dict[str, Any] = {
            "content": _safe_scrub(_enforce_max_len(str(d.get("content", "")), 4000, f"decisions[{i}].content")),
            "confidence": float(d.get("confidence", 0.75)),
            "domain": d.get("domain", "strategy"),
            "rationale": _safe_scrub(str(d.get("rationale") or "")),
            "project": _resolve_project(d),
            "source_client": _srv()._CLIENT_HINT,
        }
        if d.get("importance"):
            item["importance"] = d["importance"]
        items.append(item)

    result = _api_call("POST", _profile_path("/decisions/batch"), {"decisions": items})
    if "error" in result:
        return "log_decisions failed. Check content and try again. [code: LOG_DECISIONS_FAILED]"

    _record_mcp_usage("log_decisions")
    results = result.get("results", [])
    ok = result.get("ok", 0)
    total = result.get("total", len(items))

    if ok == total:
        ids = [r.get("id", "?") for r in results if r.get("status") == "ok"]
        return f"logged: {', '.join(ids)}"

    lines = []
    for r in results:
        status = r.get("status", "?")
        idx = r.get("index", "?")
        if status == "ok":
            lines.append(f"[{idx}] logged: {r.get('id', '?')}")
        elif status == "duplicate":
            lines.append(f"[{idx}] duplicate — existing: {r.get('existing_id', '?')}")
        elif status == "quota_exceeded":
            lines.append(f"[{idx}] quota_exceeded")
        else:
            lines.append(f"[{idx}] {status}: {r.get('detail', '')}")
    return f"batch({ok}/{total} ok)\n" + "\n".join(lines)


def _handle_annotate_decision_outcome(args: Dict[str, Any]) -> str:
    decision_id = str(args.get("decision_id", "")).strip()
    if not decision_id:
        return "Error: decision_id is required."
    outcome_status = str(args.get("outcome_status", "")).strip().lower()
    if outcome_status not in {"resolved", "superseded", "abandoned"}:
        return "Error: outcome_status must be resolved, superseded, or abandoned."
    outcome_notes = str(args.get("outcome_notes", "") or "").strip()
    profile = _resolve_profile_write(args)

    source_client = _srv()._MCP_CLIENT_HINT.get() or _srv()._CLIENT_HINT
    # Backend decision state machine uses: open -> validating -> resolved.
    # MCP contract uses: resolved/superseded/abandoned.
    status_map = {
        "resolved": "resolved",
        "superseded": "superseded",
        "abandoned": "cancelled",
    }
    target_status = status_map[outcome_status]
    body: Dict[str, Any] = {
        "status": target_status,
        "source_client": source_client,
    }
    if outcome_notes:
        body["outcome_notes"] = outcome_notes
    importance = str(args.get("importance", "") or "").strip().lower()
    if importance in {"low", "medium", "high", "critical"}:
        body["importance"] = importance
    # Backend IM-1 gate: resolving requires outcome_type ∈ {validated, reversed, partial}.
    # Default to "validated" — most common outcome — so callers don't need state-machine knowledge.
    if outcome_status == "resolved":
        outcome_type = str(args.get("outcome_type", "") or "").strip().lower()
        if outcome_type not in {"validated", "reversed", "partial"}:
            outcome_type = "validated"
        body["outcome_type"] = outcome_type
    outcome_quality = str(args.get("outcome_quality") or "").strip().lower()
    if outcome_quality:
        if outcome_quality not in {"good", "mixed", "poor", "unknown"}:
            return "Error: outcome_quality must be good, mixed, poor, or unknown."
        body["outcome_quality"] = outcome_quality

    result = _api_call(
        "PATCH",
        f"/profile/{profile}/decisions/{urllib.parse.quote(decision_id)}",
        body,
    )
    # Retry path: if direct open->resolved is rejected by state machine,
    # promote to validating first, then finalize as resolved.
    # outcome_type must travel in both hops — the IM-1 gate fires on the final transition.
    if (
        outcome_status == "resolved"
        and isinstance(result, dict)
        and "error" in result
        and str(result.get("error", "")).startswith("HTTP 422")
    ):
        step1 = _api_call(
            "PATCH",
            f"/profile/{profile}/decisions/{urllib.parse.quote(decision_id)}",
            {"status": "validating", "source_client": source_client},
        )
        if not (isinstance(step1, dict) and "error" in step1):
            result = _api_call(
                "PATCH",
                f"/profile/{profile}/decisions/{urllib.parse.quote(decision_id)}",
                body,
            )
    _record_mcp_usage("annotate_decision_outcome")
    if "error" in result:
        return f"Error annotating decision: {result['error']}"

    note = (outcome_notes[:100] if outcome_notes else "") + (f" | importance: {importance}" if importance else "")
    return confirm("Decision", decision_id, outcome_status, note or None)


def _handle_get_adversary_annotation(args: Dict[str, Any]) -> str:
    decision_id = str(args.get("decision_id", "")).strip()
    if not decision_id:
        return "get_adversary_annotation failed: decision_id is required. [code: MISSING_DECISION_ID]"

    result = _api_call("GET", f"{_profile_path(f'/decisions/{urllib.parse.quote(decision_id)}/adversary')}")
    if isinstance(result, dict) and "error" in result:
        return "No adversary annotation found."
    if result is None:
        return "No adversary annotation found."
    scenario = str(result.get("failure_scenario") or result.get("scenario") or "?")
    blast = str(result.get("blast_radius") or "?")
    cause = str(result.get("architectural_cause") or result.get("cause") or "?")
    rows = [
        ["Failure scenario", _trunc(scenario, 80)],
        ["Blast radius", _trunc(blast, 80)],
        ["Architectural cause", _trunc(cause, 80)],
    ]
    return f"Adversary annotation — {_short_id(decision_id)}:\n" + table(["Field", "Value"], rows)


def _handle_get_calibration(args: Dict[str, Any]) -> str:
    """Get calibration narrative with domain stats, validation rates, and blind spots."""
    result = _api_call("GET", _profile_path("/calibration/narrative"))

    if isinstance(result, dict) and "error" in result:
        return f"Error fetching calibration: {result['error']}"

    # Handle cold-start case
    stats = result.get("stats", {})
    cold_start = stats.get("cold_start", {})
    if cold_start.get("active"):
        journey = stats.get("journey", {})
        stage_desc = journey.get("stage_description", "Building calibration baseline")
        message = cold_start.get("message", "")
        usage_resp = _record_mcp_usage("get_calibration")
        output = f"**Calibration: {stage_desc}**\n{message}"
        if usage_resp.get("quota_exceeded"):
            output += f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        return output

    # Build readable output — prose summary above, table for per-domain stats
    lines = []

    # Executive summary (narrative prose above the table)
    exec_summary = result.get("executive_summary", "")
    if exec_summary:
        lines.append(f"**{exec_summary}**")

    # Per-domain statistics as table
    domains = stats.get("domains", [])
    if domains:
        rows = []
        for d in domains:
            conf_avg = float(d.get("confidence_avg") or 0.0)
            val_rate = float(d.get("validated_rate") or 0.0)
            delta = float(d.get("overconfidence_delta") or 0.0)
            direction = "over" if delta > 0.20 else ("under" if delta < -0.20 else "balanced")
            rows.append([
                str(d.get("domain", "general")),
                f"{conf_avg:.0%}",
                f"{val_rate:.0%}",
                direction,
            ])
        lines.append("\n**Domain Calibration**")
        lines.append(table(["Domain", "Avg Conf", "Validated", "Direction"], rows))

    # Outcome quality scores section (Phase 5)
    quality_summary = result.get("quality_summary", {})
    if quality_summary and quality_summary.get("scored_count", 0) > 0:
        try:
            scored = int(quality_summary.get("scored_count", 0))
            def _clamp(v, lo=0.0, hi=1.0): return max(lo, min(hi, float(v or 0.0)))
            good_pct = _clamp(quality_summary.get("good_rate", 0.0))
            mixed_pct = _clamp(quality_summary.get("mixed_rate", 0.0))
            poor_pct = _clamp(quality_summary.get("poor_rate", 0.0))
            predictable_poor_pct = _clamp(quality_summary.get("predictable_poor_rate", 0.0))
            lines.append(f"\n**Outcome Quality ({scored} scored)**")
            lines.append(f"Good: {good_pct:.0%}  Mixed: {mixed_pct:.0%}  Poor: {poor_pct:.0%}")
            if predictable_poor_pct > 0:
                lines.append(f"⚠️  {predictable_poor_pct:.0%} of poor decisions were predictable in hindsight")
        except Exception:
            pass

    # Temporal accuracy trend (Phase 9)
    accuracy_by_week = result.get("accuracy_by_week", [])
    trend = str(result.get("trend") or "").strip().lower()
    if accuracy_by_week:
        trend_icon = {"improving": "📈", "degrading": "📉", "stable": "→"}.get(trend, "")
        lines.append(f"\n**Accuracy Trend {trend_icon} ({trend or 'unknown'}) — last {len(accuracy_by_week)} weeks**")
        rows = []
        for w in accuracy_by_week[-8:]:
            week = str(w.get("week") or "?")[:10]
            acc = float(w.get("accuracy") or 0.0)
            scored = int(w.get("decisions_scored") or 0)
            rows.append([week, f"{acc:.0%}", str(scored)])
        lines.append(table(["Week", "Accuracy", "Scored"], rows))

    # Domain accuracy breakdown (Phase 9)
    accuracy_by_domain = result.get("accuracy_by_domain", [])
    if accuracy_by_domain:
        lines.append(f"\n**Accuracy by Domain**")
        rows = []
        for d in accuracy_by_domain[:10]:
            dom = str(d.get("domain") or "?")[:20]
            acc = float(d.get("accuracy") or 0.0)
            count = int(d.get("count") or 0)
            rows.append([dom, f"{acc:.0%}", str(count)])
        lines.append(table(["Domain", "Accuracy", "Count"], rows))

    # Critical blind spots
    insights = result.get("insights", [])
    critical_blinds = [i for i in insights if i.get("severity") == "critical" and i.get("insight_type") == "blind_spot"]
    if critical_blinds:
        rows = [[str(b.get("domain", "?")), _trunc(b.get("headline", ""))] for b in critical_blinds]
        lines.append(f"\n**Critical Blind Spots ({len(critical_blinds)})**")
        lines.append(table(["Domain", "Blind Spot"], rows))

    usage_resp = _record_mcp_usage("get_calibration")
    output = "\n".join(lines)
    if usage_resp.get("quota_exceeded"):
        output += f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
    return output


def _handle_get_stale_decisions(args: Dict[str, Any]) -> str:
    """Return open decisions not touched in N days (default 14)."""
    days = int(args.get("days", 14))
    params: Dict[str, Any] = {"stale": "true", "stale_days": max(1, days)}
    params["project"] = _resolve_project(args)
    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"{_profile_path('/decisions')}?{qs}")
    if isinstance(result, dict) and "error" in result:
        return f"Error fetching stale decisions: {result['error']}"
    decisions = result if isinstance(result, list) else result.get("decisions", [])
    if not decisions:
        return f"No stale decisions found (threshold: {days} days). Decision hygiene looks good."
    rows = [
        [
            str(d.get("importance") or "medium").upper(),
            str(d.get("updated_at") or d.get("created_at") or "")[:10],
            _trunc(d.get("content") or "?"),
            _short_id(d.get("decision_id", "")),
        ]
        for d in decisions
    ]
    _record_mcp_usage("get_stale_decisions")
    return (
        f"Stale Decisions — untouched for {days}+ days ({len(decisions)}):\n"
        + table(["Imp", "Last Updated", "Decision", "ID"], rows)
        + "\n\nAnnotate outcomes or resolve these to keep calibration healthy."
    )


def _handle_get_blocked_decisions(args: Dict[str, Any]) -> str:
    """Return open decisions that have unresolved threads in their time window."""
    params: Dict[str, Any] = {"blocked": "true"}
    params["project"] = _resolve_project(args)
    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"{_profile_path('/decisions')}?{qs}")
    if isinstance(result, dict) and "error" in result:
        return f"Error fetching blocked decisions: {result['error']}"
    decisions = result if isinstance(result, list) else result.get("decisions", [])
    if not decisions:
        return "No blocked decisions found — all open decisions have their threads resolved."
    rows = [
        [
            str(d.get("importance") or "medium").upper(),
            _trunc(d.get("content") or "?"),
            _short_id(d.get("decision_id", "")),
        ]
        for d in decisions
    ]
    _record_mcp_usage("get_blocked_decisions")
    return (
        f"Blocked Decisions — stalled on open threads ({len(decisions)}):\n"
        + table(["Imp", "Decision", "ID"], rows)
        + "\n\nResolve or defer the linked threads to unblock these decisions."
    )


def _handle_get_decisions_about_entity(args: Dict[str, Any]) -> str:
	"""Get all decisions that mention a specific entity (F6 Wave 3)."""
	entity_name = str(args.get("name") or "").strip()
	if not entity_name:
		return "Error: name is required (e.g., 'Admin MFA', 'GCP', 'CMEK')."

	# Query entity by name
	from backend.db_entities import DBEntityEngine
	from backend.db_decisions import DBDecisionEngine
	from pathlib import Path
	from backend.context import PROJECT_ROOT

	try:
		profile = _active_profile()
		if not profile:
			return "Error: could not determine profile."

		profile_root = PROJECT_ROOT / "data" / "profiles" / profile
		entity_engine = DBEntityEngine(profile_root)
		entity = entity_engine.get_entity_by_name(entity_name)

		if not entity:
			return f"Entity not found: '{entity_name}'. Run decisions through extraction first."

		# Get all decisions and find those mentioning this entity
		# Use simple heuristic: search decision content for entity name
		decision_engine = DBDecisionEngine(profile_root)
		decisions = decision_engine.get_decisions()

		matching = []
		for d in decisions:
			content = str(d.content or "").lower() if hasattr(d, 'content') else str(d.get("content") or "").lower()
			if entity_name.lower() in content:
				matching.append({
					"decision_id": d.decision_id if hasattr(d, 'decision_id') else d.get("decision_id"),
					"content": content[:150],
					"domain": d.domain if hasattr(d, 'domain') else d.get("domain", "?"),
					"status": d.status if hasattr(d, 'status') else d.get("status", "open"),
				})

		lines = [f"Decisions About '{entity_name}' ({len(matching)})"]
		lines.append(f"Entity type: {entity.get('type', '?')} | Mentions: {entity.get('mention_count', 0)}")
		lines.append("")
		for d in matching[:10]:
			lines.append(f"  • {d['decision_id']}: {d['content']}")
			lines.append(f"    [{d['domain']}] status={d['status']}")
		if len(matching) > 10:
			lines.append(f"\n  ... and {len(matching) - 10} more decisions")

		_record_mcp_usage("get_decisions_about_entity")
		return "\n".join(lines)

	except Exception as e:
		_srv().logger.debug(f"get_decisions_about_entity failed: {e}", exc_info=True)
		return "get_decisions_about_entity failed: could not query decisions for that entity. Try again or check that decisions have been indexed. [code: GET_ENTITY_DECISIONS_FAILED]"


def _handle_entity_impact_map(args: Dict[str, Any]) -> str:
	"""Return entity → decision dependency graph (F6 Wave 3)."""
	from backend.db_entities import DBEntityEngine
	from backend.db_decisions import DBDecisionEngine
	from pathlib import Path
	from backend.context import PROJECT_ROOT

	try:
		profile = _active_profile()
		if not profile:
			return "Error: could not determine profile."

		profile_root = PROJECT_ROOT / "data" / "profiles" / profile
		entity_engine = DBEntityEngine(profile_root)
		entities = entity_engine.get_all_entities()

		if not entities:
			return "No entities extracted yet. Create decisions and threads to build the entity graph."

		# Get decisions and count mentions per entity
		decision_engine = DBDecisionEngine(profile_root)
		decisions = decision_engine.get_decisions()

		# Build entity impact map
		entity_map = {}
		for entity in entities:
			name = entity.get("name", "?")
			etype = entity.get("type", "entity")
			mentions = 0
			decision_ids = []

			for d in decisions:
				content = str(d.content or "").lower() if hasattr(d, 'content') else str(d.get("content") or "").lower()
				if name.lower() in content:
					mentions += 1
					decision_id = d.decision_id if hasattr(d, 'decision_id') else d.get("decision_id", "?")
					decision_ids.append(decision_id)

			if mentions > 0:
				entity_map[name] = {
					"type": etype,
					"mentions": mentions,
					"linked_decisions": decision_ids[:5],
				}

		# Sort by mention count
		sorted_entities = sorted(entity_map.items(), key=lambda x: x[1]["mentions"], reverse=True)

		lines = [f"Entity Impact Map ({len(sorted_entities)} entities with mentions)"]
		lines.append("")
		for name, data in sorted_entities[:20]:
			lines.append(f"  {name} [{data['type']}]")
			lines.append(f"    Mentions: {data['mentions']} | Decisions: {len(data['linked_decisions'])}")
		if len(sorted_entities) > 20:
			lines.append(f"\n  ... and {len(sorted_entities) - 20} more entities")

		_record_mcp_usage("entity_impact_map")
		return "\n".join(lines)

	except Exception as e:
		_srv().logger.debug(f"entity_impact_map failed: {e}", exc_info=True)
		return "entity_impact_map failed: could not build the entity dependency map. Try again or check that entities have been indexed. [code: ENTITY_IMPACT_MAP_FAILED]"


def _handle_score_decision_outcome(args: Dict[str, Any]) -> str:
    """Store a quality score for a resolved decision to close the calibration loop."""
    decision_id = str(args.get("decision_id") or "").strip()
    if not decision_id:
        return "Error: decision_id is required."
    outcome_quality = str(args.get("outcome_quality") or "").strip().lower()
    if outcome_quality not in {"good", "mixed", "poor", "unknown"}:
        return "Error: outcome_quality must be good, mixed, poor, or unknown."
    quality_rationale = _safe_scrub(str(args.get("quality_rationale") or "").strip()[:2000])
    if not quality_rationale:
        return "Error: quality_rationale is required."

    body: Dict[str, Any] = {
        "decision_id": decision_id,
        "outcome_quality": outcome_quality,
        "quality_rationale": quality_rationale,
    }
    key_lesson = _safe_scrub(str(args.get("key_lesson") or "").strip()[:500])
    if key_lesson:
        body["key_lesson"] = key_lesson
    predictable = args.get("predictable_in_hindsight")
    if predictable is not None:
        body["predictable_in_hindsight"] = bool(predictable)
    assumptions_held = args.get("assumptions_held")
    if isinstance(assumptions_held, list) and assumptions_held:
        body["assumptions_held"] = [_safe_scrub(str(a)) for a in assumptions_held if a]
    assumptions_failed = args.get("assumptions_failed")
    if isinstance(assumptions_failed, list) and assumptions_failed:
        body["assumptions_failed"] = [_safe_scrub(str(a)) for a in assumptions_failed if a]

    idem_key: str = str(args.get("idempotency_key") or _uuid_mod.uuid4())
    result = _api_call(
        "POST",
        _profile_path("/decisions/scores"),
        body,
        extra_headers={"Idempotency-Key": idem_key},
    )
    _record_mcp_usage("score_decision_outcome")
    if isinstance(result, dict) and "error" in result:
        return f"Error scoring decision: {result['error']}"
    score_id = str(result.get("score_id") or result.get("id") or "?")
    lesson_note = f" | lesson: {key_lesson[:60]}" if key_lesson else ""
    return confirm("Score", score_id, outcome_quality, f"decision: {decision_id}{lesson_note}")


def _handle_log_decision_options(args: Dict[str, Any]) -> str:
    """Record rejected alternatives for a decision to prevent re-litigation.

    Backend dependency: requires POST /profile/{slug}/decisions/{id}/options route.
    Route is pending implementation; returns 404 until the backend ships it.
    """
    decision_id = str(args.get("decision_id") or "").strip()
    if not decision_id:
        return "Error: decision_id is required."
    options = args.get("options")
    if not isinstance(options, list) or not options:
        return "Error: options must be a non-empty array of {label, ...} objects."
    if len(options) > 50:
        return "Error: options array exceeds maximum of 50 items."

    validated: List[Dict[str, Any]] = []
    for i, opt in enumerate(options):
        if not isinstance(opt, dict):
            return f"Error: options[{i}] must be an object."
        try:
            label = _safe_scrub(str(opt.get("label") or "").strip()[:120])
        except Exception:
            label = str(opt.get("label") or "").strip()[:120]
        if not label:
            return f"Error: options[{i}].label is required."
        item: Dict[str, Any] = {"label": label}
        try:
            rationale = _safe_scrub(str(opt.get("rationale_rejected") or "").strip()[:500])
        except Exception:
            rationale = str(opt.get("rationale_rejected") or "").strip()[:500]
        if rationale:
            item["rationale_rejected"] = rationale
        try:
            tradeoff = _safe_scrub(str(opt.get("key_tradeoff") or "").strip()[:300])
        except Exception:
            tradeoff = str(opt.get("key_tradeoff") or "").strip()[:300]
        if tradeoff:
            item["key_tradeoff"] = tradeoff
        try:
            champion = _safe_scrub(str(opt.get("champion") or "").strip()[:100])
        except Exception:
            champion = str(opt.get("champion") or "").strip()[:100]
        if champion:
            item["champion"] = champion
        validated.append(item)

    body: Dict[str, Any] = {"decision_id": decision_id, "options": validated}
    idem_key: str = str(args.get("idempotency_key") or _uuid_mod.uuid4())
    result = _api_call(
        "POST",
        _profile_path(f"/decisions/{urllib.parse.quote(decision_id, safe='')}/options"),
        body,
        extra_headers={"Idempotency-Key": idem_key},
    )
    _record_mcp_usage("log_decision_options")
    if isinstance(result, dict) and "error" in result:
        status = result.get("status_code") or result.get("status")
        if status == 404 or "not found" in str(result.get("error", "")).lower():
            return f"Error: decision {decision_id!r} not found."
        return f"Error logging options: {result['error']}"
    stored = int(result.get("stored", len(validated)))
    return confirm("Options", decision_id, "recorded", f"{stored} alternative(s)")


def _handle_get_decision_contradictions(args: Dict[str, Any]) -> str:
    """Scan decision corpus for conflicting pairs. Results cached 30 min on the backend."""
    scope = str(args.get("scope") or "").strip().lower()
    if scope not in {"me", "team", "org"}:
        return "Error: scope must be one of me, team, org."
    limit = min(int(args.get("limit") or 10), _MAX_TOOL_LIMIT)
    active_only = bool(args.get("active_only", True))
    min_severity = float(args["min_severity"] if args.get("min_severity") is not None else 0.5)
    if not 0.0 <= min_severity <= 1.0:
        return "Error: min_severity must be between 0.0 and 1.0."

    body: Dict[str, Any] = {
        "scope": scope,
        "active_only": active_only,
        "min_severity": min_severity,
        "limit": limit,
    }
    domain = str(args.get("domain") or "").strip()
    if domain:
        body["domain"] = domain

    # Record usage before the expensive API call — quota consumed at dispatch, not on result.
    _record_mcp_usage("get_decision_contradictions")
    result = _api_call("POST", _profile_path("/decisions/contradictions/scan"), body)
    if isinstance(result, dict) and "error" in result:
        return f"Error scanning contradictions: {result['error']}"

    pairs = result.get("pairs", []) if isinstance(result, dict) else (result if isinstance(result, list) else [])
    scanned = result.get("scanned_count", 0) if isinstance(result, dict) else 0
    cache_age = result.get("cache_age_seconds") if isinstance(result, dict) else None

    if not pairs:
        cache_note = f" (cache age: {cache_age}s)" if cache_age is not None else ""
        return f"No contradictions found (scanned {scanned} decisions{cache_note})."

    rows = []
    for p in pairs:
        sev = float(p.get("severity") or 0.0)
        a_snip = str(p.get("decision_a") or p.get("a_excerpt") or "?")[:40]
        b_snip = str(p.get("decision_b") or p.get("b_excerpt") or "?")[:40]
        summary = str(p.get("contradiction_summary") or "")[:60]
        rows.append([f"{sev:.0%}", a_snip, b_snip, summary])

    cache_note = f" | cache age: {cache_age}s" if cache_age is not None else ""
    header = f"Contradictions ({len(pairs)} pairs, {scanned} scanned{cache_note}):"
    return header + "\n" + table(["Severity", "Decision A", "Decision B", "Summary"], rows)


_CRITICALITY_VALUES = {"low", "medium", "high", "critical"}
_ASSUMPTION_STATUS_VALUES = {"active", "held", "expired", "violated"}


def _handle_log_assumption(args: Dict[str, Any]) -> str:
    """Record an assumption tied to a decision — surfaces in get_assumptions_at_risk."""
    decision_id = str(args.get("decision_id") or "").strip()
    if not decision_id:
        return "Error: decision_id is required."
    try:
        assumption_text = _safe_scrub(str(args.get("assumption") or "").strip()[:2000])
    except Exception:
        return "Error: assumption text could not be processed — scrubbing failed."
    if not assumption_text:
        return "Error: assumption is required."
    criticality = str(args.get("criticality") or "medium").strip().lower()
    if criticality not in _CRITICALITY_VALUES:
        return f"Error: criticality must be one of {', '.join(sorted(_CRITICALITY_VALUES))}."

    body: Dict[str, Any] = {
        "decision_id": decision_id,
        "content": assumption_text,
        "criticality": criticality,
    }
    review_date = str(args.get("review_date") or "").strip()
    if review_date:
        if not _ISO_DATE_RE.match(review_date):
            return "Error: review_date must be an ISO 8601 date (e.g. '2026-07-01')."
        body["review_date"] = review_date

    idem_key: str = str(args.get("idempotency_key") or _uuid_mod.uuid4())
    _record_mcp_usage("log_assumption")
    result = _api_call(
        "POST",
        _profile_path(f"/decisions/{urllib.parse.quote(decision_id, safe='')}/assumptions"),
        body,
        extra_headers={"Idempotency-Key": idem_key},
    )
    if isinstance(result, dict) and "error" in result:
        status_code = result.get("status_code") or result.get("status")
        if status_code == 404 or "not found" in str(result.get("error", "")).lower():
            return f"Error: decision {decision_id!r} not found."
        return f"log_assumption failed: {result['error']}. Check the decision ID and try again. [code: LOG_ASSUMPTION_FAILED]"
    assumption_id = str(result.get("assumption_id") or result.get("id") or "?")
    review_note = f" | review by {review_date}" if review_date else ""
    return confirm("Assumption", assumption_id, criticality, f"decision: {decision_id}{review_note}")


def _handle_get_assumptions_at_risk(args: Dict[str, Any]) -> str:
    """Return assumptions whose review_date falls within window_days, grouped by criticality."""
    _wd = args.get("window_days")
    window_days = int(_wd) if _wd is not None else 7
    if window_days < 1 or window_days > 365:
        return "Error: window_days must be between 1 and 365."

    params: Dict[str, Any] = {"window_days": window_days, "status": "active"}
    criticality = str(args.get("criticality") or "").strip().lower()
    if criticality:
        if criticality not in _CRITICALITY_VALUES:
            return f"Error: criticality must be one of {', '.join(sorted(_CRITICALITY_VALUES))}."
        params["criticality"] = criticality
    project = str(args.get("project") or "").strip()
    if project:
        params["project"] = project

    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"{_profile_path('/decisions/assumptions/at_risk')}?{qs}")
    _record_mcp_usage("get_assumptions_at_risk")

    if isinstance(result, dict) and "error" in result:
        return f"Error fetching assumptions at risk: {result['error']}"

    items = (
        result.get("items", []) if isinstance(result, dict)
        else (result if isinstance(result, list) else [])
    )
    total = result.get("total", len(items)) if isinstance(result, dict) else len(items)

    if not items:
        return f"No assumptions due for review within {window_days} day(s)."

    rows = []
    for a in items:
        crit = str(a.get("criticality") or "?")[:8]
        dec_id = _short_id(str(a.get("decision_id") or "?"))
        review = str(a.get("review_date") or "?")[:10]
        text = str(a.get("assumption") or "?")[:60]
        status = str(a.get("status") or "active")[:10]
        rows.append([crit, dec_id, review, status, text])

    header = f"Assumptions at risk — {total} within {window_days}d:"
    return header + "\n" + table(["Criticality", "Decision", "Review Date", "Status", "Assumption"], rows)


_BREAKDOWN_VALUES = {"day", "week", "month"}


def _handle_get_decision_velocity(args: Dict[str, Any]) -> str:
    """Decision rate and load metrics over time — spike/stall detection per domain."""
    _wd = args.get("window_days")
    window_days = int(_wd) if _wd is not None else 30
    if window_days < 1 or window_days > 365:
        return "Error: window_days must be between 1 and 365."
    breakdown = str(args.get("breakdown") or "week").strip().lower()
    if breakdown not in _BREAKDOWN_VALUES:
        return f"Error: breakdown must be one of {', '.join(sorted(_BREAKDOWN_VALUES))}."

    params: Dict[str, Any] = {"window_days": window_days, "breakdown": breakdown}
    domain = str(args.get("domain") or "").strip()
    if domain:
        params["domain"] = domain
    project = str(args.get("project") or "").strip()
    if project:
        params["project"] = project

    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"{_profile_path('/decisions/velocity')}?{qs}", timeout_sec=5.0)
    _record_mcp_usage("get_decision_velocity")

    if isinstance(result, dict) and "error" in result:
        return f"Error fetching velocity: {result['error']}"

    by_domain = result.get("by_domain", []) if isinstance(result, dict) else []
    spike_alerts = result.get("spike_alerts", []) if isinstance(result, dict) else []
    stall_alerts = result.get("stall_alerts", []) if isinstance(result, dict) else []

    if not by_domain and not spike_alerts and not stall_alerts:
        return f"No velocity data for the past {window_days} day(s) — log more decisions to build trends."

    lines: List[str] = [f"Decision Velocity — {window_days}d, by {breakdown}:"]

    if spike_alerts:
        lines.append(f"\n⚠️  Spikes ({len(spike_alerts)}):")
        for s in spike_alerts[:5]:
            dom = str(s.get("domain") or "?")
            rate = float(s.get("rate") or 0.0)
            baseline = float(s.get("baseline") or 0.0)
            lines.append(f"  {dom}: {rate:.1f}/wk vs baseline {baseline:.1f}/wk")

    if stall_alerts:
        lines.append(f"\n⏸  Stalls ({len(stall_alerts)}):")
        for s in stall_alerts[:5]:
            dom = str(s.get("domain") or "?")
            days_ago = int(s.get("last_decision_days_ago") or 0)
            lines.append(f"  {dom}: last decision {days_ago}d ago")

    if by_domain:
        rows = []
        for d in by_domain[:15]:
            dom = str(d.get("domain") or "general")[:20]
            count = str(d.get("count") or 0)
            trend = str(d.get("trend") or "stable")
            rows.append([dom, count, trend])
        lines.append("\n" + table(["Domain", "Count", "Trend"], rows))

    return "\n".join(lines)


_PURGE_RECORD_TYPES = {"session", "decision", "thread", "entity", "assumption", "option"}
_PURGE_REASONS = {"compliance", "pii_leak", "import_error", "test_data"}
_MAX_PURGE_IDS = 100


def _handle_purge_records(args: Dict[str, Any]) -> str:
    """Hard delete records for compliance/PII/test-data. Preview without confirmed=True."""
    ids = args.get("ids")
    if not isinstance(ids, list) or not ids:
        return "Error: ids must be a non-empty array of record ID strings."
    if len(ids) > _MAX_PURGE_IDS:
        return f"Error: ids array exceeds maximum of {_MAX_PURGE_IDS} records per call."
    for i, rid in enumerate(ids):
        if not isinstance(rid, str) or not rid.strip():
            return f"Error: ids[{i}] must be a non-empty string."

    record_type = str(args.get("record_type") or "").strip().lower()
    if record_type not in _PURGE_RECORD_TYPES:
        return f"Error: record_type must be one of {', '.join(sorted(_PURGE_RECORD_TYPES))}."

    reason = str(args.get("reason") or "").strip().lower()
    if reason not in _PURGE_REASONS:
        return f"Error: reason must be one of {', '.join(sorted(_PURGE_REASONS))}."

    confirmed = bool(args.get("confirmed", False))
    project = str(args.get("project") or "").strip()

    body: Dict[str, Any] = {
        "ids": [str(rid).strip() for rid in ids],
        "record_type": record_type,
        "reason": reason,
        "confirmed": confirmed,
    }
    if project:
        body["project"] = project

    _record_mcp_usage("purge_records")
    result = _api_call("POST", _profile_path("/admin/purge"), body)

    if isinstance(result, dict) and "error" in result:
        status_code = result.get("status_code") or result.get("status")
        if status_code == 403 or "forbidden" in str(result.get("error", "")).lower():
            return "Error: purge_records is admin-only for full-scope operations."
        if "wrong project" in str(result.get("error", "")).lower() or (project and "scope" in str(result.get("error", "")).lower()):
            return f"Error: one or more records are not in project {project!r}."
        return f"Error purging records: {result['error']}"

    if not confirmed:
        affected = result.get("affected_count", len(ids))
        cascade_count = result.get("cascade_count", 0)
        cascade_note = f", {cascade_count} cascaded record(s)" if cascade_count else ""
        return (
            f"Purge preview: {affected} {record_type} record(s) would be deleted{cascade_note}. "
            f"Call again with confirmed=True to proceed."
        )

    audit_id = result.get("audit_id")
    if not audit_id:
        return "Error: purge executed but no audit_id returned — check backend audit log integrity before proceeding."
    purged = result.get("purged_count", len(ids))
    audit_id_str = str(audit_id)
    return confirm("Purge", audit_id_str, f"{purged} {record_type}(s)", f"reason={reason} | audit_id={audit_id_str}")


def _handle_cancel_draft_decision(args: Dict[str, Any]) -> str:
    """Hard delete a decision if it is still within the 5-minute draft window."""
    decision_id = str(args.get("decision_id") or "").strip()
    if not decision_id:
        return "Error: decision_id is required."

    result = _api_call(
        "DELETE",
        _profile_path(f"/decisions/{urllib.parse.quote(decision_id, safe='')}/draft"),
    )

    if isinstance(result, dict) and "error" in result:
        status_code = result.get("status_code") or result.get("status")
        if status_code == 404 or "not found" in str(result.get("error", "")).lower():
            return f"Error: decision {decision_id!r} not found."
        if "expired" in str(result.get("error", "")).lower() or status_code == 409:
            return f"Error: draft window for {decision_id!r} has expired — decision is committed."
        return f"Error cancelling draft: {result['error']}"

    return confirm("Draft cancelled", decision_id, "deleted", "decision discarded within draft window")


def _handle_get_pending_assumptions(args: Dict[str, Any]) -> str:
	"""Return pending (proposed) assumptions awaiting review.

	Cross-profile isolation: profile comes from the authenticated session via
	_active_profile() — never from caller-supplied args.
	"""
	import asyncio as _asyncio
	import backend.db as _db
	from backend.db_decisions import get_pending_assumptions as _get_pending

	profile = _active_profile()
	raw_limit = args.get("limit", 20)
	try:
		limit = max(1, min(50, int(raw_limit)))
	except (TypeError, ValueError):
		limit = 20
	include_dismissed = bool(args.get("include_dismissed", False))

	async def _run():
		pool = await _db.get_pool()
		async with pool.acquire(timeout=5.0) as conn:
			return await _get_pending(conn, profile_id=profile, limit=limit, include_dismissed=include_dismissed)

	try:
		rows = _asyncio.run(_run())
	except Exception:
		return "get_pending_assumptions failed: could not retrieve pending assumptions. Retry in a moment. [code: GET_PENDING_FAILED]"

	if not rows:
		return "No pending assumptions awaiting review."

	table_rows = []
	for r in rows:
		pending_id = _short_id(str(r.get("pending_id") or ""))
		content = _trunc(str(r.get("content") or ""))
		crit = str(r.get("capture_confidence") or "")[:6]
		dec_id = _short_id(str(r.get("decision_id") or ""))
		table_rows.append([pending_id, content, crit, dec_id])

	return f"{len(rows)} pending assumption(s) awaiting review:\n" + table(["ID", "Assumption", "Conf", "Decision"], table_rows)


def _handle_confirm_pending_assumption(args: Dict[str, Any]) -> str:
	"""Promote a pending assumption to decision_assumptions.

	profile comes from auth context — never from caller args.
	"""
	import asyncio as _asyncio
	import backend.db as _db
	from backend.di_assumptions import DBAssumptionEngine, NotFoundError

	pending_id = str(args.get("pending_id") or "").strip()
	if not pending_id:
		return "Error: pending_id is required."

	profile = _active_profile()
	engine = DBAssumptionEngine(profile_name=profile)

	async def _run():
		pool = await _db.get_pool()
		async with pool.acquire(timeout=5.0) as conn:
			return await engine.promote_pending(conn, pending_id=pending_id, profile=profile)

	try:
		assumption_id = _asyncio.run(_run())
	except NotFoundError:
		return f"confirm_pending_assumption failed: pending assumption {pending_id!r} not found. Verify the pending_id and try again. [code: PENDING_NOT_FOUND]"
	except Exception:
		return "confirm_pending_assumption failed: could not promote assumption to active. Retry in a moment. [code: CONFIRM_PENDING_FAILED]"

	return confirm("Assumption", str(assumption_id), "confirmed", f"promoted from pending {pending_id}")


def _handle_dismiss_pending_assumption(args: Dict[str, Any]) -> str:
	"""Dismiss a pending assumption.

	profile comes from auth context — never from caller args.
	"""
	import asyncio as _asyncio
	import backend.db as _db
	from backend.di_assumptions import DBAssumptionEngine, NotFoundError

	pending_id = str(args.get("pending_id") or "").strip()
	if not pending_id:
		return "Error: pending_id is required."

	profile = _active_profile()
	engine = DBAssumptionEngine(profile_name=profile)

	async def _run():
		pool = await _db.get_pool()
		async with pool.acquire(timeout=5.0) as conn:
			await engine.dismiss_pending(conn, pending_id=pending_id, profile=profile)

	try:
		_asyncio.run(_run())
	except NotFoundError:
		return f"dismiss_pending_assumption failed: pending assumption {pending_id!r} not found. Verify the pending_id and try again. [code: PENDING_NOT_FOUND]"
	except Exception:
		return "dismiss_pending_assumption failed: could not dismiss assumption. Retry in a moment. [code: DISMISS_PENDING_FAILED]"

	return confirm("Assumption", pending_id, "dismissed")


def _handle_log_assumptions(args: Dict[str, Any]) -> str:
	"""Write N assumptions for one decision in a single call."""
	decision_id = str(args.get("decision_id") or "").strip()
	if not decision_id:
		return "Error: decision_id is required."
	assumptions_raw = args.get("assumptions")
	if not assumptions_raw or not isinstance(assumptions_raw, list):
		return "Error: assumptions must be a non-empty array."
	if len(assumptions_raw) > 25:
		return "Error: maximum 25 assumptions per call."

	items = []
	for raw in assumptions_raw:
		if not isinstance(raw, dict):
			return "Error: each assumption must be an object with 'content' field."
		content = str(raw.get("content") or "").strip()
		if not content:
			return "Error: each assumption must have a non-empty 'content' field."
		item: Dict[str, Any] = {"content": content[:1000]}
		note = str(raw.get("note") or "").strip()
		if note:
			item["note"] = note[:500]
		items.append(item)

	_record_mcp_usage("log_assumptions")
	result = _api_call(
		"POST",
		_profile_path(f"/decisions/{urllib.parse.quote(decision_id, safe='')}/assumptions/batch"),
		{"assumptions": items},
	)
	if isinstance(result, dict) and "error" in result:
		status_code = result.get("status_code") or result.get("status")
		if status_code == 404 or "not found" in str(result.get("error", "")).lower():
			return f"Error: decision {decision_id!r} not found."
		return f"log_assumptions failed. [code: LOG_ASSUMPTIONS_FAILED]"

	ok = result.get("ok", 0)
	total = result.get("total", len(items))
	results = result.get("results", [])
	failed = [r for r in results if r.get("status") != "ok"]
	if not failed:
		return f"Logged {ok} assumption(s) for decision {decision_id}."
	fail_summary = "; ".join(f"[{r['index']}] {r.get('status','error')}" for r in failed)
	return f"Partial: {ok}/{total} logged for decision {decision_id}. Failed: {fail_summary}."


def _handle_confirm_pending_assumptions(args: Dict[str, Any]) -> str:
	"""Promote N pending assumptions to active in one call."""
	items_raw = args.get("pending_ids")
	if not items_raw or not isinstance(items_raw, list):
		return "Error: pending_ids must be a non-empty array of strings."
	if len(items_raw) > 25:
		return "Error: maximum 25 pending_ids per call."

	items = [{"pending_id": str(p).strip()} for p in items_raw if str(p).strip()]
	if not items:
		return "Error: pending_ids must be a non-empty array."

	_record_mcp_usage("confirm_pending_assumptions")
	result = _api_call(
		"POST",
		_profile_path("/decisions/assumptions/pending/confirm/batch"),
		{"items": items},
	)
	if isinstance(result, dict) and "error" in result:
		return f"confirm_pending_assumptions failed. [code: CONFIRM_PENDING_BATCH_FAILED]"

	ok = result.get("ok", 0)
	total = result.get("total", len(items))
	results = result.get("results", [])
	failed = [r for r in results if r.get("status") != "ok"]
	if not failed:
		return f"Confirmed {ok} pending assumption(s)."
	fail_summary = "; ".join(f"[{r['index']}] {r.get('pending_id','?')} {r.get('status','error')}" for r in failed)
	return f"Partial: {ok}/{total} confirmed. Failed: {fail_summary}."


def _handle_dismiss_pending_assumptions(args: Dict[str, Any]) -> str:
	"""Dismiss N pending assumptions in one call."""
	items_raw = args.get("pending_ids")
	if not items_raw or not isinstance(items_raw, list):
		return "Error: pending_ids must be a non-empty array of strings."
	if len(items_raw) > 25:
		return "Error: maximum 25 pending_ids per call."

	items = [{"pending_id": str(p).strip()} for p in items_raw if str(p).strip()]
	if not items:
		return "Error: pending_ids must be a non-empty array."

	_record_mcp_usage("dismiss_pending_assumptions")
	result = _api_call(
		"POST",
		_profile_path("/decisions/assumptions/pending/dismiss/batch"),
		{"items": items},
	)
	if isinstance(result, dict) and "error" in result:
		return f"dismiss_pending_assumptions failed. [code: DISMISS_PENDING_BATCH_FAILED]"

	ok = result.get("ok", 0)
	total = result.get("total", len(items))
	results = result.get("results", [])
	failed = [r for r in results if r.get("status") != "ok"]
	if not failed:
		return f"Dismissed {ok} pending assumption(s)."
	fail_summary = "; ".join(f"[{r['index']}] {r.get('pending_id','?')} {r.get('status','error')}" for r in failed)
	return f"Partial: {ok}/{total} dismissed. Failed: {fail_summary}."
