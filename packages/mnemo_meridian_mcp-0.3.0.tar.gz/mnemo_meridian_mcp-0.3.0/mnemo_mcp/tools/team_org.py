"""mnemo_mcp/tools/team_org.py — W3.1 MCP tools for org/team lifecycle.

Each handler is a thin shim over an existing backend HTTP route. Auth, scope,
and last-admin guards are enforced server-side by the underlying route — these
handlers do not duplicate them.

Naming convention: every tool here is prefixed ``org_*`` so it cannot collide
with team-tier (per-account team) tools. This is the org-scoped surface.

Latency: each handler issues exactly ONE HTTP call to the backend. The backend
route internally performs the same DB hops it would for a direct HTTP caller —
zero extra DB hops were added by the MCP wrapper layer.
"""
from __future__ import annotations

import json
import sys as _sys
import urllib.parse
from typing import Any, Dict


def _srv(): return _sys.modules['mnemo_mcp.server']


# Proxy wrappers — tests patch srv.X; wrappers ensure patches propagate here.
def _api_call(*a, **kw): return _srv()._api_call(*a, **kw)
def _record_mcp_usage(*a, **kw): return _srv()._record_mcp_usage(*a, **kw)


def _format_error(tool_name: str, result: Any) -> str:
	"""Bubble up backend HTTP errors to MCP callers in a uniform shape."""
	if isinstance(result, dict):
		err = result.get("error")
		detail = result.get("detail")
		if err or detail:
			payload = {"error": err or "request_failed", "tool": tool_name}
			if detail:
				payload["detail"] = detail
			return json.dumps(payload)
	return json.dumps({"error": "unexpected_response", "tool": tool_name, "raw": str(result)[:500]})


def _ok(result: Any) -> str:
	return json.dumps(result, default=str)


# ── Org-admin tools ───────────────────────────────────────────────────────────


def _handle_org_create_org(args: Dict[str, Any]) -> str:
	"""Create a new org. Caller becomes the first org_admin.

	Required: name. Optional: tier (free|individual|team|business|enterprise).
	Returns {org_id, name, tier, slug}.
	"""
	name = str(args.get("name") or "").strip()
	if not name:
		return json.dumps({"error": "validation_error", "detail": "name is required"})
	tier = str(args.get("tier") or "business").strip().lower()
	body = {"name": name, "tier": tier}
	result = _api_call("POST", "/orgs", body)
	if isinstance(result, dict) and "org_id" in result:
		_record_mcp_usage("org_create_org")
		return _ok(result)
	return _format_error("org_create_org", result)


def _handle_org_invite_member(args: Dict[str, Any]) -> str:
	"""Invite an email address to join an org. Returns the raw invite_token —
	deliver it to the invitee out of band (e.g. email or chat). Token is
	one-time-use and expires per server policy."""
	org_id = args.get("org_id")
	email = str(args.get("email") or "").strip()
	org_role = str(args.get("org_role") or "member").strip()
	if not org_id or not email:
		return json.dumps({"error": "validation_error", "detail": "org_id and email are required"})
	result = _api_call(
		"POST",
		f"/org/{int(org_id)}/members/invite",
		{"email": email, "org_role": org_role},
	)
	if isinstance(result, dict) and result.get("invite_token"):
		_record_mcp_usage("org_invite_member")
		return _ok(result)
	return _format_error("org_invite_member", result)


def _handle_org_list_members(args: Dict[str, Any]) -> str:
	"""List org members (paginated). Requires org_admin in target org.

	UX-P1-4: pass include_activity=true to also get last_seen_at,
	decisions_logged, mfa_enrolled per member.
	"""
	org_id = args.get("org_id")
	if not org_id:
		return json.dumps({"error": "validation_error", "detail": "org_id is required"})
	page = int(args.get("page") or 1)
	page_size = int(args.get("page_size") or 50)
	params: Dict[str, Any] = {"page": page, "page_size": page_size}
	if bool(args.get("include_activity")):
		params["include_activity"] = "true"
	qs = urllib.parse.urlencode(params)
	result = _api_call("GET", f"/org/{int(org_id)}/members?{qs}")
	if isinstance(result, dict) and "members" in result:
		_record_mcp_usage("org_list_members")
		return _ok(result)
	return _format_error("org_list_members", result)


def _handle_org_change_member_role(args: Dict[str, Any]) -> str:
	"""Change an org member's role. Last-admin guard enforced server-side."""
	org_id = args.get("org_id")
	profile_name = str(args.get("profile_name") or "").strip()
	new_role = str(args.get("new_role") or "").strip()
	if not org_id or not profile_name or not new_role:
		return json.dumps({"error": "validation_error", "detail": "org_id, profile_name, new_role are required"})
	result = _api_call(
		"PUT",
		f"/org/{int(org_id)}/members/{urllib.parse.quote(profile_name)}/role",
		{"org_role": new_role},
	)
	if isinstance(result, dict) and result.get("org_role"):
		_record_mcp_usage("org_change_member_role")
		return _ok({"ok": True, **result})
	return _format_error("org_change_member_role", result)


def _handle_org_suspend_member(args: Dict[str, Any]) -> str:
	"""Suspend an org member; revokes all their active sessions."""
	org_id = args.get("org_id")
	profile_name = str(args.get("profile_name") or "").strip()
	if not org_id or not profile_name:
		return json.dumps({"error": "validation_error", "detail": "org_id and profile_name are required"})
	result = _api_call(
		"POST",
		f"/org/{int(org_id)}/members/{urllib.parse.quote(profile_name)}/suspend",
		{},
	)
	if isinstance(result, dict) and result.get("status") == "suspended":
		_record_mcp_usage("org_suspend_member")
		return _ok({"ok": True, "sessions_revoked": result.get("sessions_revoked", 0)})
	return _format_error("org_suspend_member", result)


def _handle_org_deprovision_member(args: Dict[str, Any]) -> str:
	"""Deprovision an org member. Sets status=deprovisioned, clears profile.org_id,
	revokes sessions, queues a DEK rotation. Profile data remains with the user."""
	org_id = args.get("org_id")
	profile_name = str(args.get("profile_name") or "").strip()
	if not org_id or not profile_name:
		return json.dumps({"error": "validation_error", "detail": "org_id and profile_name are required"})
	result = _api_call(
		"POST",
		f"/org/{int(org_id)}/members/{urllib.parse.quote(profile_name)}/deprovision",
		{},
	)
	if isinstance(result, dict) and result.get("status") == "deprovisioned":
		_record_mcp_usage("org_deprovision_member")
		return _ok({
			"ok": True,
			"dek_rotation_job_id": result.get("dek_rotation_job_id"),
			"sessions_revoked": result.get("sessions_revoked", 0),
		})
	return _format_error("org_deprovision_member", result)


def _handle_org_remove_member(args: Dict[str, Any]) -> str:
	"""Hard-remove a member from the org. Profile data remains with the user."""
	org_id = args.get("org_id")
	profile_name = str(args.get("profile_name") or "").strip()
	if not org_id or not profile_name:
		return json.dumps({"error": "validation_error", "detail": "org_id and profile_name are required"})
	result = _api_call(
		"DELETE",
		f"/org/{int(org_id)}/members/{urllib.parse.quote(profile_name)}",
	)
	if isinstance(result, dict) and result.get("removed"):
		_record_mcp_usage("org_remove_member")
		return _ok({"ok": True, "sessions_revoked": result.get("sessions_revoked", 0)})
	return _format_error("org_remove_member", result)


def _handle_org_list_pending_invitations(args: Dict[str, Any]) -> str:
	"""List unaccepted, unexpired invitations for an org. Token hashes are NOT returned."""
	org_id = args.get("org_id")
	if not org_id:
		return json.dumps({"error": "validation_error", "detail": "org_id is required"})
	result = _api_call("GET", f"/org/{int(org_id)}/invitations")
	if isinstance(result, dict) and "invitations" in result:
		_record_mcp_usage("org_list_pending_invitations")
		return _ok(result)
	return _format_error("org_list_pending_invitations", result)


# ── Member tools (any authenticated user) ─────────────────────────────────────


def _handle_org_list_my_orgs(args: Dict[str, Any]) -> str:
	"""Return all orgs the caller is a member of, including my_role and status."""
	result = _api_call("GET", "/me/orgs")
	if isinstance(result, dict) and "orgs" in result:
		_record_mcp_usage("org_list_my_orgs")
		return _ok(result)
	return _format_error("org_list_my_orgs", result)


def _handle_org_list_my_pending_invites(args: Dict[str, Any]) -> str:
	"""Return pending org invitations addressed to the caller's email."""
	result = _api_call("GET", "/me/org-invitations")
	if isinstance(result, dict) and "invitations" in result:
		_record_mcp_usage("org_list_my_pending_invites")
		return _ok(result)
	return _format_error("org_list_my_pending_invites", result)


def _handle_org_accept_invite(args: Dict[str, Any]) -> str:
	"""Accept an org invitation using the raw token. Wraps W1.1-hardened
	/auth/org/accept-invite — may return {requires_mfa}, {requires_tos},
	{requires_sso}, or {access_token} on success."""
	token = str(args.get("token") or "").strip()
	if not token:
		return json.dumps({"error": "validation_error", "detail": "token is required"})
	result = _api_call("POST", "/auth/org/accept-invite", {"token": token})
	if isinstance(result, dict) and (
		"access_token" in result or "requires_mfa" in result
		or "requires_tos" in result or "requires_sso" in result
	):
		_record_mcp_usage("org_accept_invite")
		return _ok(result)
	return _format_error("org_accept_invite", result)


def _handle_org_leave_org(args: Dict[str, Any]) -> str:
	"""Self-remove from an org. If the caller is the last active org_admin,
	transfer_to must name another active member to be promoted."""
	org_id = args.get("org_id")
	if not org_id:
		return json.dumps({"error": "validation_error", "detail": "org_id is required"})
	body = {}
	transfer_to = str(args.get("transfer_to") or "").strip()
	if transfer_to:
		body["transfer_to"] = transfer_to
	result = _api_call("POST", f"/org/{int(org_id)}/membership/leave", body)
	if isinstance(result, dict) and result.get("ok"):
		_record_mcp_usage("org_leave_org")
		return _ok({"ok": True})
	return _format_error("org_leave_org", result)


# Public registry — server.py imports both the handler map and the tool specs.

ORG_TOOL_HANDLERS: Dict[str, Any] = {
	"org_create_org":                  _handle_org_create_org,
	"org_invite_member":               _handle_org_invite_member,
	"org_list_members":                _handle_org_list_members,
	"org_change_member_role":          _handle_org_change_member_role,
	"org_suspend_member":              _handle_org_suspend_member,
	"org_deprovision_member":          _handle_org_deprovision_member,
	"org_remove_member":               _handle_org_remove_member,
	"org_list_pending_invitations":    _handle_org_list_pending_invitations,
	"org_list_my_orgs":                _handle_org_list_my_orgs,
	"org_list_my_pending_invites":     _handle_org_list_my_pending_invites,
	"org_accept_invite":               _handle_org_accept_invite,
	"org_leave_org":                   _handle_org_leave_org,
}

ORG_WRITE_TOOLS = frozenset({
	"org_create_org",
	"org_invite_member",
	"org_change_member_role",
	"org_suspend_member",
	"org_deprovision_member",
	"org_remove_member",
	"org_accept_invite",
	"org_leave_org",
})

ORG_TOOL_SPECS = [
	{
		"name": "org_create_org",
		"description": (
			"Org surface — create a new organization. Caller is auto-enrolled as the "
			"first org_admin and can immediately invite members. Use this tool when "
			"the user wants to set up a new team workspace under their account."
		),
		"inputSchema": {
			"type": "object",
			"properties": {
				"name": {"type": "string", "description": "Display name of the org."},
				"tier": {
					"type": "string",
					"enum": ["free", "individual", "team", "business", "enterprise"],
					"default": "business",
				},
			},
			"required": ["name"],
		},
	},
	{
		"name": "org_invite_member",
		"description": (
			"Org surface — create an invitation for an email address to join an org. "
			"Requires org_admin in the target org. Returns a one-time invite_token "
			"the org admin must deliver out-of-band; treat it as sensitive."
		),
		"inputSchema": {
			"type": "object",
			"properties": {
				"org_id":   {"type": "integer", "description": "Target org id."},
				"email":    {"type": "string",  "description": "Invitee's email address."},
				"org_role": {
					"type": "string",
					"enum": ["org_admin", "member", "viewer", "billing_admin"],
					"default": "member",
				},
			},
			"required": ["org_id", "email"],
		},
	},
	{
		"name": "org_list_members",
		"description": (
			"Org surface — list members of an org with role and status. "
			"Requires org_admin in the target org. Paginated."
		),
		"inputSchema": {
			"type": "object",
			"properties": {
				"org_id":    {"type": "integer"},
				"page":      {"type": "integer", "default": 1},
				"page_size": {"type": "integer", "default": 50},
				"include_activity": {
					"type": "boolean",
					"default": False,
					"description": (
						"If true, include last_seen_at, decisions_logged, and "
						"mfa_enrolled per member (UX-P1-4)."
					),
				},
			},
			"required": ["org_id"],
		},
	},
	{
		"name": "org_change_member_role",
		"description": (
			"Org surface — change an existing member's role. Server-side last-admin "
			"guard blocks demoting the last active org_admin."
		),
		"inputSchema": {
			"type": "object",
			"properties": {
				"org_id":       {"type": "integer"},
				"profile_name": {"type": "string"},
				"new_role": {
					"type": "string",
					"enum": ["org_admin", "member", "viewer", "billing_admin"],
				},
			},
			"required": ["org_id", "profile_name", "new_role"],
		},
	},
	{
		"name": "org_suspend_member",
		"description": (
			"Org surface — suspend a member. Revokes all their active sessions and "
			"bumps the member_epoch so cached JWTs are rejected on next request. "
			"Requires org_admin."
		),
		"inputSchema": {
			"type": "object",
			"properties": {
				"org_id":       {"type": "integer"},
				"profile_name": {"type": "string"},
			},
			"required": ["org_id", "profile_name"],
		},
	},
	{
		"name": "org_deprovision_member",
		"description": (
			"Org surface — deprovision a member: status=deprovisioned, profile.org_id "
			"cleared, sessions revoked, MCP tokens revoked, DEK rotation queued. The "
			"profile and its data remain with the user. Requires org_admin."
		),
		"inputSchema": {
			"type": "object",
			"properties": {
				"org_id":       {"type": "integer"},
				"profile_name": {"type": "string"},
			},
			"required": ["org_id", "profile_name"],
		},
	},
	{
		"name": "org_remove_member",
		"description": (
			"Org surface — hard-delete the org_members row. The profile and its data "
			"remain with the user. Requires org_admin; last-admin guard applies."
		),
		"inputSchema": {
			"type": "object",
			"properties": {
				"org_id":       {"type": "integer"},
				"profile_name": {"type": "string"},
			},
			"required": ["org_id", "profile_name"],
		},
	},
	{
		"name": "org_list_pending_invitations",
		"description": (
			"Org surface — list unaccepted, unexpired invitations for an org. "
			"Token hashes are never returned, only metadata (email, role, "
			"expires_at, invited_by). Requires org_admin."
		),
		"inputSchema": {
			"type": "object",
			"properties": {"org_id": {"type": "integer"}},
			"required": ["org_id"],
		},
	},
	{
		"name": "org_list_my_orgs",
		"description": (
			"Org surface — list all organizations the caller is a member of, "
			"including the caller's role and membership status. No admin role "
			"required."
		),
		"inputSchema": {"type": "object", "properties": {}},
	},
	{
		"name": "org_list_my_pending_invites",
		"description": (
			"Org surface — list pending org invitations addressed to the caller's "
			"email. Use to discover invites before calling org_accept_invite."
		),
		"inputSchema": {"type": "object", "properties": {}},
	},
	{
		"name": "org_accept_invite",
		"description": (
			"Org surface — accept an org invitation using the raw token shared with "
			"the invitee. May return {requires_mfa}, {requires_tos}, {requires_sso} "
			"if the org enforces those gates, or {access_token} on success."
		),
		"inputSchema": {
			"type": "object",
			"properties": {
				"token": {"type": "string", "description": "Raw invite token from org_invite_member."},
			},
			"required": ["token"],
		},
	},
	{
		"name": "org_leave_org",
		"description": (
			"Org surface — caller self-removes from an org. If the caller is the "
			"last active org_admin, transfer_to must name another active member who "
			"will be promoted to org_admin atomically with the departure."
		),
		"inputSchema": {
			"type": "object",
			"properties": {
				"org_id":      {"type": "integer"},
				"transfer_to": {"type": "string", "description": "Required if caller is last active org_admin."},
			},
			"required": ["org_id"],
		},
	},
]
