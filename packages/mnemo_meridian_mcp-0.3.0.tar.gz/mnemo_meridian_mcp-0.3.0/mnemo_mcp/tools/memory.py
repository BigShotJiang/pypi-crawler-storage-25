from __future__ import annotations
from typing import Any, Dict, List, Optional
import asyncio
import hashlib
from mnemo_mcp.tools._format import table, confirm, warn, quota_notice, _trunc
from datetime import datetime, timezone
import json
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed as futures_as_completed
import sys as _sys

def _srv(): return _sys.modules['mnemo_mcp.server']

from mnemo_mcp.server import _API_URL, _MCP_API_TOKEN_HINT


# Proxy wrappers — tests patch srv.X; wrappers ensure patches propagate here
def _active_profile(*a, **kw): return _srv()._active_profile(*a, **kw)
def _api_call(*a, **kw): return _srv()._api_call(*a, **kw)
def _auto_flush_session(*a, **kw): return _srv()._auto_flush_session(*a, **kw)
def _check_and_flush(*a, **kw): return _srv()._check_and_flush(*a, **kw)
def _coerce_json_array(*a, **kw): return _srv()._coerce_json_array(*a, **kw)
def _enforce_max_len(*a, **kw): return _srv()._enforce_max_len(*a, **kw)
def _maybe_surface_related(*a, **kw): return _srv()._maybe_surface_related(*a, **kw)
def _profile_path(*a, **kw): return _srv()._profile_path(*a, **kw)
def _record_mcp_usage(*a, **kw): return _srv()._record_mcp_usage(*a, **kw)
def _resolve_profile_write(*a, **kw): return _srv()._resolve_profile_write(*a, **kw)
def _resolve_project(*a, **kw): return _srv()._resolve_project(*a, **kw)
def _validate_project_slug(*a, **kw): return _srv()._validate_project_slug(*a, **kw)
def _classify_wrap_session_decisions(*a, **kw): return _srv()._classify_wrap_session_decisions(*a, **kw)
def _safe_scrub(*a, **kw): return _srv()._safe_scrub(*a, **kw)

_MAX_WRAP_DECISIONS = 10
_MAX_WRAP_THREADS = 5
_MAX_WRAP_CALLS_PER_HOUR = 30  # A-1: per-profile hourly cap to prevent write amplification
_ALLOWED_WRAP_SOURCES = {"cowork", "claude_code", "claude_agent", "claude_chat", "custom"}
_TRIVIAL_THREAD_TITLES = {
    "todo", "follow up", "follow-up", "tbd", "none", "n/a", "na", "misc", "later", "soon",
}


def _normalize_wrap_source(value: Any) -> str:
    source = str(value or "custom").strip().lower()
    if source in _ALLOWED_WRAP_SOURCES:
        return source
    return "custom"


def _is_trivial_open_thread(title: str) -> bool:
    normalized = " ".join(title.strip().lower().split())
    if not normalized:
        return True
    if normalized in _TRIVIAL_THREAD_TITLES:
        return True
    words = [w for w in normalized.split(" ") if w]
    if len(words) == 1 and len(normalized) < 4:
        return True
    return False


def _handle_search_memory(args: Dict[str, Any]) -> str:
    # S1 (embedding-to-backend) shipped: the embedding model now lives entirely in
    # the backend process (backend/memory.py, warmed at lifespan startup). The MCP
    # process no longer owns a model; the bridge warmup guard has been removed.
    verbatim = bool(args.get("verbatim", False))
    if verbatim:
        max_tokens = args.get("max_tokens", 4000)
        n_results = args.get("n_results", 2)
    else:
        max_tokens = args.get("max_tokens", 1500)
        n_results = args.get("n_results", 5)

    body: Dict[str, Any] = {
        "query": args.get("query", ""),
        "max_tokens": max_tokens,
        "n_memories": n_results,
        "include": args.get("include", ["sessions", "decisions", "threads"]),
        "verbatim": verbatim,
    }
    body["project"] = _resolve_project(args)
    result = _api_call("POST", "/api/v1/context/retrieve", body)
    if "error" in result:
        return f"search_memory failed: {result['error']}. Try a different query or check your project filter. [code: SEARCH_MEMORY_FAILED]"

    context_block = result.get("context_block", "No relevant context found.")
    sources = result.get("sources", [])
    token_est = result.get("token_estimate", 0)
    output = [context_block]
    if sources:
        output.append(f"\n[{len(sources)} source(s), ~{token_est} tokens]")
        decision_ids = []
        for s in sources:
            if str(s.get("type", "")).lower() != "decision":
                continue
            did = str(s.get("id", "")).strip()
            if did and did not in decision_ids:
                decision_ids.append(did)
        if decision_ids:
            output.append(f"\nDecision IDs: {', '.join(decision_ids)}")

    usage_resp = _record_mcp_usage("search_memory")
    if usage_resp.get("quota_exceeded"):
        output.append(
            f"\n[Usage: {usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} "
            f"MCP calls this month — upgrade at {_API_URL.rstrip('/')}/settings#upgrade]"
        )
    return "\n".join(output)


def _handle_log_session(args: Dict[str, Any]) -> str:
    """index_session_fragment: agent-initiated tool (S7 — silent success).

    Success: return machine-readable JSON with indexed=true and fragment_id.
    Failure: return human-readable error string (no JSON blob).

    This is an agent-only operation (not user-facing); prose on success
    introduces noise into agent orchestration. Human users call wrap_session
    which returns full prose confirmation.
    """
    try:
        task = _enforce_max_len(args.get("task", ""), 4000, "task")
        output = _enforce_max_len(args.get("output", ""), 20000, "output")
    except ValueError as exc:
        return f"Error: index_session_fragment failed: {exc}. [code: MAX_LENGTH_EXCEEDED]"
    args = dict(args)
    args["task"] = task
    args["output"] = output
    profile = _resolve_profile_write(args)
    _check_and_flush(profile, "log_session", args.get("task", "")[:80])
    body: Dict[str, Any] = {
        "title": _safe_scrub(args.get("task", "")),
        "content": _safe_scrub(args.get("output", "")),
        "source": "custom",
        "source_client": _srv()._MCP_CLIENT_HINT.get() or _srv()._CLIENT_HINT,
    }
    body["project"] = _resolve_project(args)
    body["project_id"] = body["project"]
    project_err = _validate_project_slug(body["project"])
    if project_err:
        return project_err
    result = _api_call("POST", f"/profile/{profile}/sessions/import", body)
    if "error" in result:
        _record_mcp_usage("log_session")
        return f"index_session_fragment failed: could not import fragment. [code: {result.get('code', 'IMPORT_FAILED')}]"
    _record_mcp_usage("log_session")
    session_id = result.get("session_id", "?")
    # S7: return machine-readable JSON on success (no prose).
    return json.dumps({"indexed": True, "fragment_id": session_id})


def _handle_wrap_session(args: Dict[str, Any]) -> str:
    """Atomic end-of-session wrap: log session + decisions + surface threads.

    Replicates the Meridian Chat.jsx ExtractionCard flow for MCP contexts
    (Claude Code, Cowork, agents). The ExtractionCard fires on the streaming
    `done` event and lets the user save detected threads + decisions; this
    tool does the equivalent without a UI — Claude extracts them from the
    conversation and persists everything in one call.
    """
    # Unit G: explicit wrap_session flushes accumulated buffer immediately.
    profile_for_flush = _active_profile()
    if profile_for_flush:
        _auto_flush_session(profile_for_flush)

    # A-1: per-profile hourly rate limit. Separate counter (not monthly quota);
    # fail-closed so a DB outage cannot silently permit unbounded writes.
    # _record_mcp_usage is fire-and-forget and always returns {} — it CANNOT
    # be used for rate-limit decisions; call the synchronous rate-check endpoint.
    profile_for_rate = profile_for_flush or _active_profile()
    if not profile_for_rate:
        # UX-finding: silent-skip on missing profile was an amplification bypass.
        # A mis-configured client must not be able to write unbounded sessions.
        return (
            "Error: wrap_session requires an active profile. Set the X-Profile-Name "
            "header or call mnemo_session_init first. [code: NO_ACTIVE_PROFILE]"
        )
    # Adversary-finding cap: rate-check is a single-row UPSERT; a 30s default
    # would let a slow/missing DDL pin workers for 30s per call. A 3s ceiling
    # surfaces the fault as RATE_LIMITER_UNAVAILABLE within a bounded blast
    # radius. (The server side already enforces statement_timeout=2s.)
    rate_resp = _api_call(
        "POST",
        f"/profile/{profile_for_rate}/mcp/rate-check",
        {"tool": "wrap_session", "max_per_hour": _MAX_WRAP_CALLS_PER_HOUR},
        timeout_sec=3.0,
    )
    # Explicit fail-closed branches. Any non-OK shape (error key, missing
    # `allowed`, malformed body) rejects with a distinct code so the client
    # AND ops logs can tell transient infra faults apart from throttling.
    if "error" in rate_resp or "allowed" not in rate_resp:
        _srv().logger.warning(
            "[wrap_session] rate-check unusable — rejecting (fail-closed): %s",
            rate_resp.get("error") or f"missing 'allowed' in {list(rate_resp.keys())}",
        )
        return (
            "Error: wrap_session temporarily unavailable (rate limiter unreachable). "
            "This is a server-side issue, not a quota problem. Retry in 30–60 seconds. "
            "[code: RATE_LIMITER_UNAVAILABLE, retry_after_seconds: 30, fault: server, transient: true]"
        )
    if not rate_resp.get("allowed", False):
        # Display cap at limit (not current) so the message reads naturally —
        # "30/30 reached" rather than "31/30 exceeded" which looks like a bug.
        raw_current = rate_resp.get("current")
        display_current = min(int(raw_current), _MAX_WRAP_CALLS_PER_HOUR) if isinstance(raw_current, int) else _MAX_WRAP_CALLS_PER_HOUR
        retry_after = int(rate_resp.get("retry_after_seconds") or 0)
        reset_at = rate_resp.get("reset_at") or ""
        reset_hint = f" Reset at {reset_at} (in ~{max(1, retry_after // 60)} minutes)." if reset_at else ""
        # UX-ops: distinct log tag so client-hammering and limiter-outage look
        # different in logs without cross-referencing the endpoint.
        _srv().logger.info(
            "[wrap_session] rate_limited profile=%s raw_current=%s limit=%s",
            profile_for_rate, raw_current, _MAX_WRAP_CALLS_PER_HOUR,
        )
        return (
            f"Error: wrap_session rate limit reached ({display_current}/{_MAX_WRAP_CALLS_PER_HOUR} calls this hour)."
            f"{reset_hint} Batch decisions into the next wrap_session call or wait. "
            f"[code: RATE_LIMITED, retry_after_seconds: {retry_after}, fault: client, transient: true]"
        )

    try:
        task = _safe_scrub(_enforce_max_len(args.get("task", ""), 4000, "task"))
        output = _safe_scrub(_enforce_max_len(args.get("output", ""), 20000, "output"))
    except ValueError as exc:
        return f"Error: {exc}"
    decisions_raw = _coerce_json_array(args.get("decisions", []), "decisions")
    open_threads_raw = _coerce_json_array(args.get("open_threads", []), "open_threads")
    source = _normalize_wrap_source(args.get("source", "cowork"))
    project = args.get("project", "")
    if project:
        project_err = _validate_project_slug(project)
        if project_err:
            return project_err
    session_import_idem = "wrap_session_" + hashlib.sha256(
        f"{source}|{project}|{task}|{output}".encode("utf-8")
    ).hexdigest()[:40]

    # Scrub free-text fields in each decision before processing
    for i, d in enumerate(decisions_raw):
        if isinstance(d, str):
            decisions_raw[i] = _safe_scrub(d)
        elif isinstance(d, dict):
            if d.get("content"):
                d["content"] = _safe_scrub(d["content"])
            if d.get("rationale"):
                d["rationale"] = _safe_scrub(d["rationale"])

    # Cap decisions and threads
    errors: List[str] = []
    if len(decisions_raw) > _MAX_WRAP_DECISIONS:
        errors.append(
            f"Decision list capped at {_MAX_WRAP_DECISIONS}; "
            f"{len(decisions_raw) - _MAX_WRAP_DECISIONS} item(s) skipped."
        )
        decisions_raw = decisions_raw[:_MAX_WRAP_DECISIONS]

    # Classify decisions — separate true decisions from memories/threads
    try:
        classify_fn = _classify_wrap_session_decisions
        if classify_fn is None:
            raise ImportError("backend.agent_classifier not available")
        classified = classify_fn(decisions_raw)
    except ImportError:
        # Degraded mode — backend.agent_classifier unavailable. Apply a minimal
        # linguistic guard: reject items whose content begins with a past-tense
        # activity verb so activities don't get promoted as decisions.
        # Should never happen in production; treat as a hard dependency failure.
        _ACTIVITY_PREFIXES = (
            "ran ", "wrapped ", "completed ", "deployed ", "fixed ",
            "updated ", "added ", "removed ", "checked ", "reviewed ",
            "implemented ", "created ", "migrated ", "tested ", "merged ",
            "built ", "wrote ", "changed ", "refactored ", "configured ",
            "enabled ", "disabled ", "opened ", "closed ", "pushed ",
            "published ", "set up ", "wired up ", "cleaned up ", "rolled out ",
        )
        classified = []
        for d in decisions_raw:
            if not d:
                continue
            content = (d.get("content") if isinstance(d, dict) else str(d)).strip()
            if not content:
                continue
            if content.lower().startswith(_ACTIVITY_PREFIXES) or content.lower() in {p.strip() for p in _ACTIVITY_PREFIXES}:
                continue
            classified.append({
                "content": content,
                "entry_type": "decision",
                "confidence": float(d.get("confidence", 0.75)) if isinstance(d, dict) else 0.75,
                "confidence_label": "medium",
                "domain": d.get("domain", "strategy") if isinstance(d, dict) else "strategy",
                "rationale": d.get("rationale", "") if isinstance(d, dict) else "",
                "is_ambiguous": False,
            })

    # Build decision payloads (only "decision" type; "memory" type skipped)
    decision_payloads = []
    for item in classified:
        if item.get("entry_type") == "decision" and item.get("content"):
            decision_payloads.append({
                "content": item["content"],
                "domain": item.get("domain", "strategy"),
                "confidence": float(item.get("confidence", 0.75)),
                "rationale": item.get("rationale", ""),
            })

    # Build thread payloads — explicit threads first, then classifier-derived;
    # deduplicate and scrub PII; cap at _MAX_WRAP_THREADS total.
    _thread_candidates: List[str] = []
    for t in open_threads_raw:
        _thread_candidates.append(str(t))
    for item in classified:
        if item.get("entry_type") == "thread" and item.get("content"):
            _thread_candidates.append(str(item["content"]).strip())

    thread_payloads = []
    _seen_titles: set = set()
    for t in _thread_candidates:
        title = _safe_scrub(str(t).strip())
        if not title or _is_trivial_open_thread(title):
            if title:
                errors.append(f"Skipped trivial open thread: {title[:40]}")
            continue
        key = title.lower()
        if key in _seen_titles:
            continue
        _seen_titles.add(key)
        thread_payloads.append({"title": title, "body": ""})
        if len(thread_payloads) >= _MAX_WRAP_THREADS:
            errors.append(
                f"Open thread list capped at {_MAX_WRAP_THREADS}; "
                f"{len(_thread_candidates) - _MAX_WRAP_THREADS} item(s) skipped."
            )
            break

    # ── Single atomic POST /v1/sessions/wrap ──────────────────────────────────
    wrap_body: Dict[str, Any] = {
        "session": {
            "title": task,
            "content": output,
            "source": source,
            "idempotency_key": session_import_idem,
        },
        "decisions": decision_payloads,
        "open_threads": thread_payloads,
        "project": project,
        "source": source,
    }
    wrap_result = _api_call("POST", "/v1/sessions/wrap", wrap_body)

    if "error" in wrap_result:
        reason = wrap_result.get("error") or "unknown error"
        code = wrap_result.get("code") or "WRAP_FAILED"
        return (
            f"wrap_session failed: {reason}. "
            f"Your session was not saved. [code: {code}]"
        )

    session_id = wrap_result.get("session_id", "?")
    n_dec = wrap_result.get("decisions_logged", 0)
    n_thr = wrap_result.get("threads_opened", 0)

    # ── 4. Record usage ───────────────────────────────────────────────────────
    usage_resp = _record_mcp_usage("wrap_session")

    result_parts: List[str] = [f"Session saved. {n_dec} decision(s) logged, {n_thr} thread(s) opened."]

    # Surface thread titles when fewer threads were persisted than requested
    # so the user knows what was attempted even if persistence partially failed.
    if thread_payloads and n_thr < len(thread_payloads):
        for t in thread_payloads:
            title = t.get("title", "?")
            result_parts.append(warn(f"Thread attempted: {title}"))

    # Surface contradiction alerts returned by the wrap endpoint
    for alert in wrap_result.get("contradiction_alerts", []):
        severity = str(alert.get("severity") or "unknown").upper()
        prior = alert.get("prior_decision") or alert.get("content") or ""
        result_parts.append(f"[CONTRADICTION] {severity} — conflicts with: {prior[:120]}")

    if errors:
        result_parts.append(warn(f"{len(errors)} warning(s): {'; '.join(errors)}"))
    if usage_resp.get("quota_exceeded"):
        result_parts.append(
            quota_notice(usage_resp.get("used", "?"), usage_resp.get("limit", "?"),
                         f"{_API_URL.rstrip('/')}/settings#upgrade")
        )
    return "\n".join(result_parts)


def _handle_log_execution_event(args: Dict[str, Any]) -> str:
    """Log a discrete execution milestone and optionally resolve a linked decision."""
    profile = _resolve_profile_write(args)
    event_type = args.get("event_type", "other")
    description = _safe_scrub(args.get("description", "").strip())
    project = args.get("project", "")
    linked_decision_id = args.get("linked_decision_id", "").strip()

    if not description:
        return "Error: description is required."

    import_body: Dict[str, Any] = {
        "title": f"[Execution] {event_type.upper()}: {description[:120]}",
        "content": (
            f"Execution event logged.\n"
            f"Type: {event_type}\n"
            f"Description: {description}"
        ),
        "source": "custom",
        "source_client": _srv()._MCP_CLIENT_HINT.get() or _srv()._CLIENT_HINT,
        "idempotency_key": "exec_event_" + hashlib.sha256(
            f"{profile}|{event_type}|{project}|{linked_decision_id}|{description}".encode("utf-8")
        ).hexdigest()[:40],
    }
    if project:
        import_body["project"] = project

    result = _api_call("POST", f"/profile/{profile}/sessions/import", import_body)
    _record_mcp_usage("log_execution_event")
    # Fire-and-forget: check if all 4 onboarding milestones are done → auto-resolve tour thread
    try:
        _api_call("POST", f"/profile/{urllib.parse.quote(profile)}/usage/check-tour")
    except Exception:
        pass  # intentional: fire-and-forget; tour check must never block log_execution_event

    if "error" in result:
        return f"log_execution_event failed: {result['error']}. Event was not saved. [code: LOG_EXECUTION_FAILED]"

    session_id = result.get("session_id", "?")
    parts = [f"Execution event logged: [{event_type}] {description[:100]}. Session ID: {session_id}"]

    if linked_decision_id:
        patch_body: Dict[str, Any] = {"status": "resolved", "outcome_notes": description}
        d_result = _api_call(
            "PATCH",
            f"/profile/{profile}/decisions/{urllib.parse.quote(linked_decision_id)}",
            patch_body,
        )
        if "error" not in d_result:
            parts.append(f"Decision {linked_decision_id} marked as resolved.")
        else:
            parts.append(f"Note: could not resolve linked decision {linked_decision_id}: {d_result['error']}")

    return "\n".join(parts)


def _handle_mnemo_session_init(args: Dict[str, Any]) -> str:
	"""Initialize a Tier-3 (Privacy Mode) encrypted session.

	Rate-limited: max 5 attempts per 15-minute window per profile.
	Passphrase is never logged or stored in the response.
	"""
	passphrase = str(args.get("passphrase") or "")
	session_duration_hours = int(args.get("session_duration_hours") or 8)
	ttl_seconds = session_duration_hours * 3600

	profile = _active_profile()
	if not profile:
		return "mnemo_session_init: could not resolve profile."

	async def _run() -> str:
		import backend.db as db
		from backend.services.tier3_encryption import Tier3Encryption

		# ── Tier check via DB ──────────────────────────────────────────────────
		try:
			pool = await db.get_pool()
			async with pool.acquire(timeout=5.0) as conn:
				row = await conn.fetchrow(
					"SELECT key_tier FROM profile_encryption_keys WHERE profile = $1",
					profile,
				)
		except Exception as exc:
			_srv().logger.debug("[mnemo_session_init] DB tier check failed: %s", exc)
			return f"mnemo_session_init: could not verify profile tier: {exc}"

		key_tier = int((row["key_tier"] if row else None) or 1)
		if key_tier != 3:
			tier_name = {1: "Free (Tier 1)", 2: "Enterprise CMEK (Tier 2)"}.get(key_tier, f"Tier {key_tier}")
			return (
				f"mnemo_session_init is only available for Privacy Mode profiles (Tier 3). "
				f"Profile '{profile}' is on {tier_name}. "
				"Enable Privacy Mode in Mnemo Settings to use this feature."
			)

		# ── Rate limit: max 5 attempts per 15 min per profile ─────────────────
		now = datetime.now(timezone.utc)
		rl_window = now.replace(minute=(now.minute // 15) * 15, second=0, microsecond=0)
		try:
			rl_row = await pool.fetchrow(
				"""
				INSERT INTO mcp_token_rate (token_id, window_start, call_count)
				VALUES ($1, $2, 1)
				ON CONFLICT (token_id, window_start)
				DO UPDATE SET call_count = mcp_token_rate.call_count + 1
				RETURNING call_count
				""",
				f"session_init:{profile}",
				rl_window,
			)
			if (rl_row["call_count"] if rl_row else 1) > 5:
				return (
					"mnemo_session_init: rate limit exceeded. "
					"Max 5 attempts per 15 minutes per profile. Please wait before retrying."
				)
		except Exception as exc:
			_srv().logger.warning("[mnemo_session_init] rate-limit DB check failed — allowing: %s", exc)

		# ── Derive session key ────────────────────────────────────────────────
		tier3 = Tier3Encryption()
		try:
			token = await tier3.init_session(profile, passphrase, pool, ttl_seconds=ttl_seconds)
		except ValueError as exc:
			return f"mnemo_session_init: {exc}"

		from datetime import datetime as _dt, timezone as _tz
		expires_at = _dt.now(_tz.utc).replace(microsecond=0)
		import datetime as _datetime_module
		expires_at = expires_at + _datetime_module.timedelta(seconds=ttl_seconds)

		return json.dumps({
			"session_token": token,
			"expires_at": expires_at.isoformat().replace("+00:00", "Z"),
		})

	try:
		loop = asyncio.get_event_loop()
		if loop.is_running():
			import concurrent.futures
			with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
				future = ex.submit(asyncio.run, _run())
				return future.result(timeout=30)
		else:
			return loop.run_until_complete(_run())
	except Exception as exc:
		_srv().logger.error("[mnemo_session_init] error: %s", exc, exc_info=True)
		return f"mnemo_session_init failed: {exc}"
