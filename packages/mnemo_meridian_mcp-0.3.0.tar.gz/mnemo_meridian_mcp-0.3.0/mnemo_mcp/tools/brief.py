from __future__ import annotations
from typing import Any, Dict, List, Optional
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
from datetime import datetime, timezone
import sys as _sys

def _srv(): return _sys.modules['mnemo_mcp.server']

from mnemo_mcp.server import _MAX_TOOL_LIMIT, _MCP_API_TOKEN_HINT
from mnemo_mcp.tools._format import table, warn, quota_notice, _trunc, format_usage_snapshot
from mnemo_mcp.tools._brief_cache import (
	_brief_cache,
	_is_cache_valid,
	_fetch_brief_cached,
)

# Proxy wrappers — tests patch srv.X; wrappers ensure patches propagate here
def _api_call(*a, **kw): return _srv()._api_call(*a, **kw)
def _current_access_token(*a, **kw): return _srv()._current_access_token(*a, **kw)
def _infer_project_from_cwd(*a, **kw): return _srv()._infer_project_from_cwd(*a, **kw)
def _profile_path(*a, **kw): return _srv()._profile_path(*a, **kw)
def _record_mcp_usage(*a, **kw): return _srv()._record_mcp_usage(*a, **kw)
def _resolve_project(*a, **kw): return _srv()._resolve_project(*a, **kw)


def _handle_get_morning_brief(args: Dict[str, Any]) -> str:
    # Resolve profile ONCE in the calling thread before spawning workers.
    # _current_access_token() uses MCP-library contextvars that may not survive
    # into ThreadPoolExecutor threads even with _run_in_context — pre-building
    # the path strings avoids any profile-resolution inside the thread pool.
    brief_path = _profile_path("/morning-brief")
    changes_base = _profile_path("/activity/changes")

    # Cache key is the profile-scoped brief_path — strictly profile-isolated.
    # Cross-profile leakage is structurally impossible: each profile has a unique path.
    _cache_key = brief_path

    def _fetch_brief() -> Dict:
        return _api_call("GET", brief_path, timeout_sec=15.0)

    def _fetch_changes() -> Dict:
        try:
            changes_qs = urllib.parse.urlencode({"client": "all", "limit": 20, "since_days": 2})
            return _api_call("GET", f"{changes_base}?{changes_qs}")
        except Exception:
            return {}  # best-effort

    # Extract the token hint VALUE from the current context before submitting to workers.
    # We can't use _ctx.run() inside an already-entered context (Python restriction).
    # Instead, capture the value and manually set it in worker threads.
    _token_value = _MCP_API_TOKEN_HINT.get("")

    # ThreadPoolExecutor automatically propagates contextvars to worker threads.
    # Manual token capture + re-set is retained as belt-and-suspenders for
    # environments where the contextvar is set before submission.
    def _fetch_brief_with_hint():
        if _token_value:
            token_ctx = _MCP_API_TOKEN_HINT.set(_token_value)
            try:
                return _fetch_brief()
            finally:
                _MCP_API_TOKEN_HINT.reset(token_ctx)
        return _fetch_brief()

    def _fetch_changes_with_hint():
        if _token_value:
            token_ctx = _MCP_API_TOKEN_HINT.set(_token_value)
            try:
                return _fetch_changes()
            finally:
                _MCP_API_TOKEN_HINT.reset(token_ctx)
        return _fetch_changes()

    # Fast path: cache hit skips both DB round-trips entirely.
    _now = time.time()
    if _is_cache_valid(_cache_key, _now):
        result = _brief_cache[_cache_key][1]
        changes_result: Dict = {}
    else:
        # Don't use context-manager form — __exit__ calls shutdown(wait=True) which
        # blocks until _fetch_changes finishes even after FutureTimeoutError.
        # shutdown(wait=False) lets the changes thread run to completion in the
        # background without stalling the MCP response.
        ex = ThreadPoolExecutor(max_workers=2)
        # _fetch_brief_cached enforces a per-profile threading.Lock so even
        # 20 concurrent cold-start callers trigger only one DB fetch.
        f_brief = ex.submit(_fetch_brief_cached, _cache_key, _fetch_brief_with_hint)
        f_changes = ex.submit(_fetch_changes_with_hint)
        result = f_brief.result(timeout=20.0)
        try:
            changes_result = f_changes.result(timeout=2.0)
        except (FutureTimeoutError, Exception):
            changes_result = {}
        ex.shutdown(wait=False, cancel_futures=True)

    if "error" in result:
        err = str(result.get("error", "")).lower()
        # Resilience fallback: if morning brief generation times out, still return
        # a useful "since yesterday" snapshot instead of a hard error.
        if "timed out" in err or "timeout" in err or "http 504" in err:
            changes = changes_result.get("changes", []) if isinstance(changes_result, dict) else []
            lines = ["Morning brief timed out — returning quick activity snapshot instead."]
            if changes:
                lines.append(f"\n**Since Yesterday ({len(changes)} changes)**")
                for c in changes[:8]:
                    action = str(c.get("action") or c.get("type") or "updated")
                    entity = str(c.get("summary") or c.get("entity") or c.get("content") or c.get("title") or "?")[:80]
                    lines.append(f"• {action}: {entity}")
            _record_mcp_usage("get_morning_brief")
            return "\n".join(lines)
        return f"get_morning_brief failed: {result['error']}. Try again in a moment. [code: BRIEF_FETCH_FAILED]"
    summary = result.get("summary", "")
    priority = result.get("priority", "normal")
    decision_debt = result.get("decision_debt") or []
    approaching = result.get("approaching_deadlines") or []
    dormant = result.get("dormant_threads") or []
    contradictions = result.get("unresolved_contradictions") or []
    if not summary and not decision_debt and not approaching and not dormant:
        _record_mcp_usage("get_morning_brief")
        return "Morning brief unavailable — try running a session first."
    today = datetime.now(timezone.utc).strftime("%a %-d %b %Y")
    lines = [f"## Morning Brief — {today}"]
    lines.append(f"**Priority: {priority.upper()}**")

    # Status dashboard
    status_rows = []
    if contradictions:
        status_rows.append(("Contradictions", str(len(contradictions)), "Investigate"))
    if dormant:
        status_rows.append(("Dormant threads", str(len(dormant)), "Resolve"))
    if decision_debt:
        status_rows.append(("Decision debt", str(len(decision_debt)), "Review"))
    if approaching:
        status_rows.append(("Approaching deadlines", str(len(approaching)), "Action"))
    if status_rows:
        lines.append("\n" + table(["Metric", "Count", "Action"], list(status_rows)))

    # Since yesterday
    changes = changes_result.get("changes", []) if isinstance(changes_result, dict) else []
    if changes:
        lines.append(f"\n**Since Yesterday ({len(changes)} changes)**")
        rows = []
        for c in changes[:10]:
            action = str(c.get("action") or c.get("type") or "updated")
            entity = _trunc(c.get("summary") or c.get("entity") or c.get("content") or c.get("title") or "?")
            rows.append([action, entity])
        lines.append("\n" + table(["Type", "Summary"], rows))

    if decision_debt:
        lines.append(f"\n**Decision Debt ({len(decision_debt)})**")
        rows = [[d.get("severity", "?"), f"{d.get('age_days','?')}d", _trunc(d.get("content", "?"))] for d in decision_debt[:5]]
        lines.append("\n" + table(["Severity", "Age", "Decision"], rows))
    if approaching:
        lines.append(f"\n**Approaching Deadlines ({len(approaching)})**")
        rows = [[f"{d.get('days_until','?')}d", _trunc(d.get("content", "?"))] for d in approaching[:5]]
        lines.append("\n" + table(["Due", "Decision"], rows))
    if dormant:
        lines.append(f"\n**Dormant Threads ({len(dormant)})**")
        rows = [[_trunc(t.get("title") or t.get("content", "?"))] for t in dormant[:5]]
        lines.append("\n" + table(["Thread"], rows))
    if contradictions:
        lines.append(f"\n**Unresolved Contradictions ({len(contradictions)})**")
        rows = [[_trunc(str(c), 80)] for c in contradictions[:3]]
        lines.append("\n" + table(["Contradiction"], rows))

    # Phase 9 signals — review_due_today, assumptions_at_risk, contradictions_alert, velocity_signal
    review_due = result.get("review_due_today") or []
    if review_due:
        lines.append(f"\n**Review Due Today ({len(review_due)})**")
        rows = [[_trunc(str(d.get("title") or d.get("content") or "?"))] for d in review_due[:5]]
        lines.append(table(["Decision"], rows))

    asm_signal = result.get("assumptions_at_risk")
    if isinstance(asm_signal, dict) and asm_signal.get("count", 0) > 0:
        crit = asm_signal.get("critical_count", 0)
        crit_note = f", {crit} critical" if crit else ""
        lines.append(f"\n**Assumptions at Risk** — {asm_signal['count']} due for review{crit_note}")

    con_alert = result.get("contradictions_alert")
    if isinstance(con_alert, dict) and con_alert.get("count", 0) > 0:
        max_sev = float(con_alert.get("max_severity") or 0.0)
        lines.append(f"\n**Contradictions Alert** — {con_alert['count']} active (max severity {max_sev:.0%})")

    vel_signal = result.get("velocity_signal")
    if isinstance(vel_signal, dict):
        spikes = vel_signal.get("spikes") or []
        stalls = vel_signal.get("stalls") or []
        if spikes or stalls:
            parts = []
            if spikes:
                parts.append(f"{len(spikes)} domain spike(s)")
            if stalls:
                parts.append(f"{len(stalls)} domain stall(s)")
            lines.append(f"\n**Velocity Signal** — {', '.join(parts)}")

    announcements = result.get("announcements") or []
    if announcements:
        ann = announcements[0]
        prefix = "🚨 " if ann.get("is_emergency") else ""
        scope = str(ann.get("scope_level", "app")).upper()
        lines.append(f"\n**{prefix}Announcement [{scope}]** — {ann.get('title', '')}")
        lines.append(str(ann.get("body", ""))[:300])

    usage_section = format_usage_snapshot(result.get("usage_snapshot") or {})
    if usage_section:
        lines.append(usage_section)

    usage_resp = _record_mcp_usage("get_morning_brief")
    output = "\n".join(lines)
    if usage_resp.get("quota_exceeded"):
        output = quota_notice(usage_resp.get("used", "?"), usage_resp.get("limit", "?")) + "\n" + output
    return output


def _handle_get_recent_changes(args: Dict[str, Any]) -> str:
    client = str(args.get("client", "all")).strip().lower() or "all"
    action = str(args.get("action", "")).strip()
    limit = max(1, min(int(args.get("limit", 20)), _MAX_TOOL_LIMIT))
    since_days = max(1, min(int(args.get("since_days", 30)), 365))
    params: Dict[str, Any] = {
        "client": client,
        "limit": limit,
        "since_days": since_days,
    }
    # Only forward project when the caller explicitly supplied it.
    # Injecting the resolved default causes a JSON expression scan on
    # activity_events without a covering index, producing long-tail spikes.
    explicit_project = str(args.get("project") or "").strip()
    if explicit_project:
        params["project"] = explicit_project
    if action:
        params["action"] = action
    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"{_profile_path('/activity/changes')}?{qs}")
    usage_resp = _record_mcp_usage("get_recent_changes")

    if isinstance(result, dict) and "error" in result:
        return f"get_recent_changes failed: {result['error']}. Check your date range and client filters. [code: GET_CHANGES_FAILED]"

    changes = result.get("changes", []) if isinstance(result, dict) else []
    warning = result.get("warning") if isinstance(result, dict) else None
    if not changes:
        output = "No recent changes found for the selected filters."
        if warning:
            output += f" (warning: {warning})"
        if usage_resp.get("quota_exceeded"):
            output += f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        return output

    lines = [f"Recent changes ({len(changes)}):"]
    for item in changes:
        created_at = str(item.get("created_at", "?"))[:19].replace("T", " ")
        src_client = item.get("client", "other")
        action_name = item.get("action", "change")
        summary = str(item.get("summary", "")).strip() or "(no summary)"
        rid = item.get("resource_id", "")
        suffix = f" [{rid}]" if rid else ""
        lines.append(f"• {created_at} | {src_client} | {action_name}{suffix}: {summary}")
    if usage_resp.get("quota_exceeded"):
        lines.append(f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]")
    if warning:
        lines.append(f"\n(warning: {warning})")
    return "\n".join(lines)


def _handle_get_session_handoff_brief(args: Dict[str, Any]) -> str:
    """Return a structured resume block for the latest (or specified) session."""
    params: Dict[str, Any] = {}
    if args.get("session_id"):
        params["session_id"] = args["session_id"]
    params["project"] = _resolve_project(args)
    if args.get("module"):
        params["module"] = args["module"]
    hours = int(args.get("hours_window", 4))
    params["hours_window"] = max(1, min(hours, 24))

    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"{_profile_path('/sessions/handoff')}?{qs}")

    if isinstance(result, dict) and "error" in result:
        err = result.get("error", "")
        if err == "no_session":
            queried = result.get("queried_project") or params.get("project") or "none"
            inferred = _infer_project_from_cwd()
            diag = (
                f"inferred_project={inferred!r}, queried_project={queried!r}, "
                f"sessions_checked={result.get('sessions_checked', 0)}"
            )
            return (
                f"No session found. [{diag}]\n"
                "Run wrap_session at the end of your next session to enable handoff briefs. "
                "If a session was just logged, confirm the project slug matches by passing "
                f"project='{queried}' explicitly."
            )
        return f"get_session_handoff_brief failed: {result.get('detail', err)}. Check the session_id and project. [code: GET_HANDOFF_FAILED]"

    session_id = result.get("session_id", "?")
    title = str(result.get("title") or session_id)[:80]
    ts = str(result.get("ts") or "")[:16].replace("T", " ")
    project = result.get("project") or ""
    decisions = result.get("decisions") or []
    threads = result.get("open_threads") or []
    last_intent = str(result.get("last_intent") or "").strip()

    header = f"SESSION HANDOFF — {title}"
    if project:
        header += f" [{project}]"
    if ts:
        header += f" / {ts}"

    lines = [header, "=" * len(header)]

    # Decisions
    open_dec = [d for d in decisions if d.get("status") not in ("resolved", "superseded")]
    closed_dec = [d for d in decisions if d.get("status") in ("resolved", "superseded")]
    if decisions:
        lines.append(f"\nDECISIONS MADE ({len(decisions)})")
        for d in open_dec[:8]:
            imp = str(d.get("importance") or "")
            imp_tag = f" [{imp}]" if imp and imp != "medium" else ""
            lines.append(f"  • {str(d.get('content',''))[:120]}{imp_tag} [{d.get('status','open')}]")
        for d in closed_dec[:3]:
            lines.append(f"  ✓ {str(d.get('content',''))[:100]} [resolved]")
    else:
        lines.append("\nDECISIONS MADE (0)\n  None logged for this session.")

    # Open threads
    if threads:
        lines.append(f"\nOPEN THREADS ({len(threads)})")
        for t in threads[:6]:
            lines.append(f"  • {str(t.get('content',''))[:120]}")
    else:
        lines.append("\nOPEN THREADS (0)\n  No unresolved threads from this session.")

    # Last intent
    if last_intent:
        snippet = last_intent[:300] + ("…" if len(last_intent) > 300 else "")
        lines.append(f"\nLAST INTENT\n  {snippet}")

    # Recommended actions
    lines.append("\nRECOMMENDED FIRST ACTIONS")
    action_n = 1
    if open_dec:
        lines.append(f"  {action_n}. Review open decisions above — annotate any that resolved last session")
        action_n += 1
    if threads:
        lines.append(f"  {action_n}. Resolve or defer the {len(threads)} open thread(s) listed above")
        action_n += 1
    lines.append(f"  {action_n}. Call get_decisions(status='open') for full decision context if needed")

    _record_mcp_usage("get_session_handoff_brief")
    return "\n".join(lines)

