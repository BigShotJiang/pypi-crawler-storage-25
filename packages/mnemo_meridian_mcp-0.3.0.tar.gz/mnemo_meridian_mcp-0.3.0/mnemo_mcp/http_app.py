"""
mnemo_mcp/http_app.py — HTTP transport wrapper for Cloud Run deployment.

Wraps the mnemo_mcp MCP server with Starlette so it can accept inbound HTTP
connections.  Cloud Run requires a process to listen on $PORT; stdio transport
does not satisfy that requirement.

Transport: MCP Streamable HTTP (mcp.server.streamable_http_manager).
Health check: GET /health → 200 {"status": "ok"}

Environment variables (required):
    MNEMO_API_URL   Backend API base URL. Startup fails if missing or empty.

Environment variables (optional):
    PORT            HTTP port to listen on (default 8080, set by Cloud Run).
    LOG_LEVEL       Logging level (default INFO).
"""
from __future__ import annotations

import logging
import os
import sys

# ── Startup validation — fail fast before importing anything else ─────────────
_API_URL = (os.environ.get("MNEMO_API_URL") or "").strip()
if not _API_URL:
	print(
		"ERROR: MNEMO_API_URL is required but not set. "
		"Set it to the Mnemo backend URL (e.g. https://mnemo-api-bxkfuzweaq-uc.a.run.app).",
		file=sys.stderr,
	)
	sys.exit(1)

# ── Logging ───────────────────────────────────────────────────────────────────
_log_level = (os.environ.get("LOG_LEVEL") or "INFO").upper()
logging.basicConfig(level=getattr(logging, _log_level, logging.INFO), stream=sys.stderr)
logger = logging.getLogger(__name__)

# ── MCP + Starlette imports ───────────────────────────────────────────────────
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.authentication import AuthenticationMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route

try:
	from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
	_STREAMABLE_HTTP_AVAILABLE = True
except ImportError:
	_STREAMABLE_HTTP_AVAILABLE = False
	logger.warning(
		"[mnemo-mcp-http] StreamableHTTPSessionManager not available. "
		"MCP endpoint will be disabled; only /health will respond."
	)

# C-02: Import the same auth stack used by backend/routers/mcp_http.py so the
# /mcp endpoint on this standalone Cloud Run service is NOT unauthenticated.
# Startup will fail if these components or their dependencies cannot be loaded
# — that is intentional. An unauthenticated /mcp is a full data-exfil bypass.
from mcp.server.auth.middleware.auth_context import AuthContextMiddleware
from mcp.server.auth.middleware.bearer_auth import (
	BearerAuthBackend,
	RequireAuthMiddleware,
)

from mnemo_mcp.server import build_mcp_server
from backend.routers.mcp_http import MnemoTokenVerifier

_RESOURCE_METADATA_URL = (
	os.environ.get("MNEMO_BASE_URL", "https://api.mnemomcp.com").rstrip("/")
	+ "/.well-known/oauth-protected-resource/mcp"
)


# ── Health endpoint ───────────────────────────────────────────────────────────
async def health(request: Request) -> JSONResponse:
	"""Liveness probe used by Cloud Run and the Docker HEALTHCHECK."""
	return JSONResponse({"status": "ok", "service": "mnemo-mcp"})


# ── Build routes ─────────────────────────────────────────────────────────────
routes: list = [Route("/health", health, methods=["GET"])]

if _STREAMABLE_HTTP_AVAILABLE:
	# Build the MCP server instance only when MCP transport is available.
	logger.info("[mnemo-mcp-http] Building MCP server (API: %s)", _API_URL)
	_mcp_server = build_mcp_server()

	_session_manager = StreamableHTTPSessionManager(
		app=_mcp_server,
		event_store=None,
		json_response=True,
		stateless=True,
	)

	async def _raw_mcp_endpoint(scope, receive, send):  # pragma: no cover
		"""MCP Streamable HTTP endpoint — forwards to the session manager."""
		await _session_manager.handle_request(scope, receive, send)

	# C-02: Wrap the MCP handler in RequireAuthMiddleware so unauthenticated
	# callers get a 401 Unauthorized instead of full MCP tool access.
	_authed_mcp_endpoint = RequireAuthMiddleware(
		_raw_mcp_endpoint,
		required_scopes=[],
		resource_metadata_url=_RESOURCE_METADATA_URL,
	)

	# AuthenticationMiddleware wraps the whole app and populates the request's
	# auth context from the Bearer token; AuthContextMiddleware exposes it to
	# the MCP server via mcp.server.auth.middleware.auth_context.get_access_token.
	_mcp_middleware = [
		Middleware(AuthenticationMiddleware, backend=BearerAuthBackend(MnemoTokenVerifier())),
		Middleware(AuthContextMiddleware),
	]

	async def _lifespan(app):  # pragma: no cover
		async with _session_manager.run():
			logger.info("[mnemo-mcp-http] MCP session manager running (auth ENFORCED)")
			yield

	routes.append(Mount("/mcp", app=_authed_mcp_endpoint))
	app = Starlette(routes=routes, middleware=_mcp_middleware, lifespan=_lifespan)
else:
	logger.warning("[mnemo-mcp-http] MCP package unavailable — only /health endpoint active")
	app = Starlette(routes=routes)

logger.info("[mnemo-mcp-http] Starlette app ready (port from $PORT env var)")
