"""
mnemo_mcp/server.py — Mnemo Platform MCP Server
================================================
Exposes the Mnemo platform's memory and intelligence layer as an MCP server.

This means ANY Claude conversation — Claude.ai, Claude Code, Claude in Chrome,
a custom agent, another app — can call into Mnemo's memory directly without
being in the Mnemo/Meridian frontend.

Tools exposed
-------------
  search_memory       — semantic search over user's session history
  get_open_threads    — active unresolved threads
  get_decisions       — open decisions with confidence + rationale
  search_entities     — entity graph lookup
  get_morning_brief   — structured brief of what matters right now
  index_session_fragment — index a session from an external agent into Mnemo memory
  log_decision        — record a decision from any context
  list_projects       — list all project slugs with activity summaries
  get_project_context — one-shot retrieval of a project's full state

Setup
-----
  pip install mnemo-meridian-mcp

  Add to ~/claude_desktop_config.json:
  {
    "mcpServers": {
      "mnemo": {
        "command": "mnemo-mcp",
        "env": {
          "MNEMO_API_TOKEN": "<token from Mnemo Settings>"
        }
      }
    }
  }

  Note: MNEMO_API_URL defaults to https://api.mnemomcp.com (production).
  Only override it if using a local or staging instance.

Authentication
--------------
Generate a token in Mnemo → Settings → "Connect to Claude Desktop & Claude Code".
The token is long-lived (30–365 days) and scoped to the Mnemo platform, not to
any specific app (Meridian, VitalSync Coach, etc.).

Architecture
------------
Pure thin HTTP client over the Mnemo REST API. No dependency on the Mnemo
backend codebase — just stdlib + the mcp package.
"""

from __future__ import annotations

import asyncio
import collections
import concurrent.futures as _cf
import json
import contextvars
import logging
import os
import re
import secrets
import sys
import threading
import time
import urllib.parse
import uuid as _uuid_mod  # NEW: for Idempotency-Key generation
from datetime import datetime, timezone

# Eager import — fails fast at startup rather than at first wrap_session call.
# The ImportError fallback inside _handle_wrap_session handles the PyPI package case.
try:
	from backend.agent_classifier import classify_wrap_session_decisions as _classify_wrap_session_decisions
except ImportError:
	_classify_wrap_session_decisions = None

# Gen-2 metrics: track_mcp_call context manager.
# Optional import — server still works as a standalone pip package without backend.
# Also gated by MNEMO_METRICS_ENABLED env var — set to "false" to disable entirely.
import os as _os_metrics
_metrics_env_enabled = _os_metrics.environ.get("MNEMO_METRICS_ENABLED", "true").lower() not in ("false", "0", "no")
try:
	from backend.metrics_collector import track_mcp_call as _track_mcp_call
	_METRICS_AVAILABLE = _metrics_env_enabled
except ImportError:
	_track_mcp_call = None
	_METRICS_AVAILABLE = False

# C-03: pii_scrubber is a HARD dependency. If it cannot be imported the MCP
# server must refuse to start — we never want the server running with PII
# redaction silently disabled.
from backend.pii_scrubber import scrub_pii as _scrub_pii

try:
	from backend.feature_gates import FEATURE_GATES as _FEATURE_GATES, check_feature as _check_feature
	_FEATURE_GATES_AVAILABLE = True
except ImportError:
	_FEATURE_GATES = {}
	_check_feature = None
	_FEATURE_GATES_AVAILABLE = False

from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError, as_completed as futures_as_completed
from typing import Any, Callable, Dict, List, Optional
from mnemo_mcp.core import api_call, clip_tool_output, enforce_transport_policy, resolve_api_token
from mnemo_mcp import attestation as _attestation

logger = logging.getLogger(__name__)

# ── MCP SDK ───────────────────────────────────────────────────────────────────
try:
    import mcp.server.stdio
    from mcp.server import Server
    from mcp.types import Tool, TextContent, ToolAnnotations, ErrorData as _ErrorData
    from mcp.shared.exceptions import McpError
    from mcp.types import INVALID_PARAMS as _MCP_INVALID_PARAMS
    from mcp.types import METHOD_NOT_FOUND as _MCP_METHOD_NOT_FOUND
    _MCP_AVAILABLE = True
except ImportError:
    _MCP_AVAILABLE = False
    logger.warning(
        "[mnemo-mcp] 'mcp' package not installed. "
        "Run: pip install mnemo-meridian-mcp\n"
        "MCP server will not start without it."
    )

# ── Configuration (from env) ──────────────────────────────────────────────────
# MNEMO_INTERNAL_API_URL: when the MCP server is co-deployed with the backend
# (same Cloud Run instance), set this to http://localhost:8080 to avoid the
# loopback-via-public-internet anti-pattern. Bearer token auth still applies.
_INTERNAL_API_URL = os.getenv("MNEMO_INTERNAL_API_URL", "")
_API_URL = _INTERNAL_API_URL or os.getenv("MNEMO_API_URL", "https://api.mnemomcp.com")
if "localhost" in _API_URL.lower() and not _INTERNAL_API_URL:
    logger.warning(
        "[mnemo-mcp] Using local Mnemo instance at %s. "
        "Set MNEMO_API_URL to https://api.mnemomcp.com for production.",
        _API_URL,
    )
_API_TOKEN = resolve_api_token(os.getenv("MNEMO_API_TOKEN", ""))
_API_TOKEN_RESOLVED_AT: float = time.monotonic()
_TOKEN_REFRESH_INTERVAL: float = 300.0  # seconds; only applies when MNEMO_API_TOKEN_CMD is set
_PROFILE = os.getenv("MNEMO_PROFILE", "")
_CLIENT_HINT = os.getenv("MNEMO_CLIENT_HINT", "unknown").strip().lower() or "unknown"
_RESOLVED_PROFILE = ""
# Note: _PROFILE_LOCK removed per project rule (no threading.Lock).
# The standalone-mode profile cache uses a simple check-then-set;
# a benign race at startup may call _resolve_profile_from_api() twice
# but both calls return the same slug so the final value is correct.
_MCP_CLIENT_HINT = contextvars.ContextVar("mnemo_mcp_client_hint", default="unknown")
_MCP_API_TOKEN_HINT = contextvars.ContextVar("mnemo_mcp_api_token_hint", default="")
# Per-request profile override set by the HTTP SSE transport layer.
# Checked before the MCP-library access_token path so that the SSE transport
# (which already resolved the profile from the JWT) doesn't fall through to
# the /me API call which 404s for MCP tokens.
_ACTIVE_PROFILE_CTX: contextvars.ContextVar[str] = contextvars.ContextVar(
    "mnemo_active_profile_ctx", default=""
)

# Bug 1 fix: cap concurrent in-flight API calls to prevent stream closure
# under concurrent MCP tool calls racing on urllib shared resources.
_api_semaphore = asyncio.Semaphore(8)

# Adversary FIX 4: per-profile module-level dicts are unbounded in the original
# design.  A long-lived Cloud Run instance serving many distinct profiles would
# accumulate entries indefinitely, eventually triggering OOM kill.
# _BoundedDict caps at _PROFILE_DICT_CAP entries (FIFO eviction of oldest profile).
# Eviction means a profile's greeter/brief state resets — they may receive a
# repeat greeting after eviction. This is a minor UX hiccup, not a data bug.
_PROFILE_DICT_CAP: int = 10_000

class _BoundedDict(collections.OrderedDict):
    """OrderedDict capped at maxsize entries; oldest entry evicted on overflow."""
    def __init__(self, maxsize: int = _PROFILE_DICT_CAP):
        super().__init__()
        self._maxsize = maxsize

    def __setitem__(self, key, value):
        if key in self:
            self.move_to_end(key)
        super().__setitem__(key, value)
        if len(self) > self._maxsize:
            self.popitem(last=False)

# M2 (rate limiting): This file is the local/CLI MCP transport (stdio).
# It runs as a single process per user, directly on their machine, so
# per-user rate limiting is not applicable here.  Rate limiting is enforced
# at the HTTP transport layer (backend/routers/mcp_http.py) for all remote
# callers using the mcp_rl:{profile_name} Redis key.

# ── T6: Attestation backend availability flag ─────────────────────────────────
_ATTESTATION_BACKEND_AVAILABLE: bool = True
_ATTESTATION_RECHECK_IN_FLIGHT: bool = False


async def _check_attestation_backend() -> bool:
	"""Non-blocking probe: can we SELECT from audit_log?

	Returns True on success, False on any failure. Never raises.
	"""
	try:
		from backend import db
		pool = await db.get_pool()
		async with pool.acquire(timeout=3.0) as c:
			await c.fetchval("SELECT 1 FROM audit_log LIMIT 1")
		return True
	except Exception as exc:
		logger.warning("[T6] attestation backend unavailable (audit_log unreachable): %s", exc)
		return False


def _schedule_attestation_backend_recheck() -> None:
	"""Fire-and-forget: re-probe the attestation backend and flip _ATTESTATION_BACKEND_AVAILABLE."""
	global _ATTESTATION_BACKEND_AVAILABLE, _ATTESTATION_RECHECK_IN_FLIGHT
	if _ATTESTATION_RECHECK_IN_FLIGHT:
		return
	_ATTESTATION_RECHECK_IN_FLIGHT = True

	def _recheck():
		global _ATTESTATION_BACKEND_AVAILABLE, _ATTESTATION_RECHECK_IN_FLIGHT
		try:
			result = asyncio.run(_check_attestation_backend())
			if result:
				_ATTESTATION_BACKEND_AVAILABLE = True
				logger.info("[T6] attestation backend recovered — flag reset to True")
		except Exception as exc:
			logger.debug("[T6] recheck thread error (ignored): %s", exc)
		finally:
			_ATTESTATION_RECHECK_IN_FLIGHT = False

	t = threading.Thread(target=_recheck, daemon=True, name="attestation-recheck")
	t.start()


# ── T10: Loop detection + per-profile token cost cap ─────────────────────────
# In-memory per-replica. State resets on restart. SOC 2 note: cross-replica
# enforcement requires a shared backing store; this is a P2 limitation for a
# cost/availability control (not a data integrity control).

_LOOP_WINDOW_SECONDS: float = 300.0  # 5-min retention so window_5min gate has real data
_LOOP_THRESHOLD: int = 20  # >20 calls of same tool in 5min → loop suspected
_BASELINE_FLOOR_CALLS_PER_5MIN: int = 10  # active gate — no profile exempted below this cap
# profile_behavioral_baselines.p95_calls_per_5min is computed hourly but not yet wired
# into _detect_loop — _BASELINE_FLOOR_CALLS_PER_5MIN is the only active per-profile gate.
_tool_call_log: dict[str, collections.deque] = {}

_TOKEN_CAP_PER_HOUR: int = 500_000
_TOKEN_WINDOW_SECONDS: float = 3600.0
_token_cost_log: dict[str, collections.deque] = {}
_TOKEN_OVERHEAD_PER_CALL: int = 256


def _detect_loop(profile: str, tool_name: str) -> bool:
	"""Record call and return True if loop or floor threshold exceeded.

	Deque retains 5 minutes of entries (_LOOP_WINDOW_SECONDS=300) so both the
	per-tool count and the absolute floor gate operate over a real 5-minute window.

	Gates (checked in order):
	  1. Absolute floor: total calls across all tools in 5min > 3× floor (30 cap).
	  2. Per-tool loop: same tool called >_LOOP_THRESHOLD times in the window.
	"""
	now = time.monotonic()
	dq = _tool_call_log.setdefault(profile, collections.deque())
	dq.append((tool_name, now))
	while dq and now - dq[0][1] > _LOOP_WINDOW_SECONDS:
		dq.popleft()

	# Gate 1: absolute floor over the full 5-min window
	window_5min = sum(1 for _t, ts in dq if now - ts <= 300.0)
	if window_5min > _BASELINE_FLOOR_CALLS_PER_5MIN * 3:
		return True

	# Gate 2: per-tool loop detection
	count = sum(1 for t, _ in dq if t == tool_name)
	return count > _LOOP_THRESHOLD


def _record_token_cost(profile: str, args: dict) -> None:
	"""Record an estimated token cost entry for *profile*."""
	now = time.monotonic()
	try:
		arg_chars = len(json.dumps(args))
	except Exception:
		arg_chars = 0
	estimated = max(1, arg_chars // 4) + _TOKEN_OVERHEAD_PER_CALL
	dq = _token_cost_log.setdefault(profile, collections.deque())
	dq.append((estimated, now))
	while dq and now - dq[0][1] > _TOKEN_WINDOW_SECONDS:
		dq.popleft()


def _check_cost_cap(profile: str) -> bool:
	"""Return True if *profile* has exceeded _TOKEN_CAP_PER_HOUR tokens in the last hour."""
	now = time.monotonic()
	dq = _token_cost_log.get(profile)
	if not dq:
		return False
	while dq and now - dq[0][1] > _TOKEN_WINDOW_SECONDS:
		dq.popleft()
	total = sum(tokens for tokens, _ in dq)
	return total >= _TOKEN_CAP_PER_HOUR


# ── Behavioral rate limiting — O(1) token bucket (in-memory, per-replica) ────
# This is a LOCAL cost-ceiling only — each Cloud Run instance has its own bucket.
# The authoritative cross-instance rate limit is the Postgres-backed
# _rate_limit_middleware in backend/routers/mcp_http.py (mcp_token_rate table).
# This in-memory bucket fires first as a fast-path guard; the Postgres gate is
# the invariant that holds across all replicas.
# Keyed by profile_id → (tokens, capacity, refill_rate, last_refill_ts).
_BUCKET_CAPACITY: int = 100
_BUCKET_REFILL_RATE: int = 10  # tokens per minute
_token_buckets: dict[str, list] = {}  # profile → [tokens, capacity, refill_rate, last_refill_ts]


def _check_token_bucket(profile_id: str) -> bool:
	"""Refill + consume one token from the per-profile rate bucket.

	Returns True (call blocked) if the bucket is empty after refill.
	Falls back to False (allow) on any error — fail-open on infra error.

	Refill logic: tokens += floor((now - last_refill) * refill_rate / 60).
	"""
	try:
		now = time.monotonic()
		bucket = _token_buckets.get(profile_id)
		if bucket is None:
			# [tokens, capacity, refill_rate, last_refill_ts]
			bucket = [_BUCKET_CAPACITY, _BUCKET_CAPACITY, _BUCKET_REFILL_RATE, now]
			_token_buckets[profile_id] = bucket

		tokens, capacity, refill_rate, last_refill = bucket
		elapsed = now - last_refill
		refill = int(elapsed * refill_rate / 60.0)
		if refill > 0:
			tokens = min(capacity, tokens + refill)
			bucket[3] = now  # update last_refill_ts

		if tokens <= 0:
			bucket[0] = tokens
			logger.warning("[rate-bucket] bucket empty profile=%s", profile_id[:20])
			return True  # blocked

		bucket[0] = tokens - 1
		return False
	except Exception as exc:
		logger.debug("[rate-bucket] fallback (allow): %s", exc)
		return False


def _record_velocity_anomaly(profile_id: str) -> bool:
	"""Increment in-memory velocity anomaly counter. Returns True if throttle threshold hit.

	Counter resets when window_start is >10 minutes old.
	Throttle at anomaly_count >= 3 within the window.
	Falls back to False (allow) on any error.
	"""
	try:
		now = time.monotonic()
		key = f"_vel:{profile_id}"
		entry = _token_buckets.get(key)
		if entry is None or now - entry[1] > 600.0:  # [count, window_start]
			_token_buckets[key] = [1, now]
			return False
		entry[0] += 1
		return entry[0] >= 3
	except Exception as exc:
		logger.debug("[velocity-counter] fallback (allow): %s", exc)
		return False


# ── Scope drift detection — ADVISORY ONLY, never blocks dispatch ──────────────
# Signal is in-memory and non-durable. On-call responds to WARNING log lines.
# Postgres-backed suppression (mcp_velocity_counters) and durable audit leaf
# (mcp_attestation_events) are deferred to a follow-up sprint.
_SCOPE_DRIFT_SUPPRESSION: dict[str, float] = {}  # (profile:tool) → last_emit_time
_SCOPE_DRIFT_SUPPRESSION_TTL: float = 86400.0    # 24h in-memory suppression
_DESTRUCTIVE_TOOLS: frozenset = frozenset()  # populated lazily from MNEMO_TOOLS


def _check_scope_drift(profile_id: str, tool_name: str) -> None:
	"""Advisory scope drift signal. Never blocks dispatch.

	Flags (profile_id, tool_name) pairs where this profile has never called
	this tool before AND the tool has destructiveHint=True.
	Requires 3 calls spread over >=7 days before the pair is considered established.
	Emits at most once per 24h per (profile, tool) pair (in-memory suppression).
	"""
	global _DESTRUCTIVE_TOOLS
	if not _DESTRUCTIVE_TOOLS:
		try:
			_DESTRUCTIVE_TOOLS = frozenset(
				t["name"] for t in MNEMO_TOOLS
				if t.get("annotations", {}).get("destructiveHint", False)
			)
		except Exception:
			return

	if tool_name not in _DESTRUCTIVE_TOOLS:
		return

	suppress_key = f"{profile_id[:20]}:{tool_name}"
	now = time.monotonic()
	if now - _SCOPE_DRIFT_SUPPRESSION.get(suppress_key, 0) < _SCOPE_DRIFT_SUPPRESSION_TTL:
		return

	# Check call history in the in-memory call log
	dq = _tool_call_log.get(profile_id)
	if dq is None:
		# First ever call — emit drift signal
		_SCOPE_DRIFT_SUPPRESSION[suppress_key] = now
		logger.warning(
			"[scope-drift] novel destructive tool call profile=%s tool=%s "
			"(first call ever — no history)",
			profile_id[:20], tool_name,
		)
		return

	# Count calls to this tool in the deque; require spread over 7 days for establishment
	# (deque only covers 60s window for loop detection — use call log length as proxy)
	tool_calls_in_window = sum(1 for t, _ in dq if t == tool_name)
	if tool_calls_in_window < 3:
		_SCOPE_DRIFT_SUPPRESSION[suppress_key] = now
		logger.warning(
			"[scope-drift] rare destructive tool call profile=%s tool=%s "
			"calls_in_60s_window=%d",
			profile_id[:20], tool_name, tool_calls_in_window,
		)


# Unit H — MCP Proactive Presence: session-start greeter state.
# Keyed by profile_id → last greeting datetime (UTC).  Reset every 4h.
_session_greeted: _BoundedDict = _BoundedDict()
# Separate cooldown for new-user onboarding greeting — stamped AFTER results
# confirm new-user condition, unlike _session_greeted which stamps before fetches.
_onboarding_greeted: _BoundedDict = _BoundedDict()

# Unit E — Morning brief in-process delivery tracking.
# Avoids Redis (30 req/sec limit, historically flaky) for brief gating.
# _brief_delivered: profile → date the brief was last delivered (UTC).
_brief_delivered: _BoundedDict = _BoundedDict()
# _profile_tier_cache: profile → (tier, monotonic_timestamp). TTL of 60s prevents
# a Tier-1 profile that upgrades to Tier-3 from receiving MCP-channel briefs for
# the entire process lifetime. Cloud Run instances live hours; staleness without a
# TTL is a confidentiality regression for tier upgrades.
_TIER_CACHE_TTL_S: float = 60.0
_profile_tier_cache: _BoundedDict = _BoundedDict()

# Deferred greeting/brief cache: computed in background after tool returns,
# prepended to the *next* tool response so the current response has zero overhead.
# _pending_cache_lock guards all reads and writes to both dicts — dict.pop() +
# conditional dict.__setitem__ is not atomic across concurrent tool calls.
_pending_greeting: _BoundedDict = _BoundedDict()
_pending_brief: _BoundedDict = _BoundedDict()
_pending_cache_lock = threading.Lock()

# Fix 3: brief content cache for the get_morning_brief tool handler.
# Avoids re-running ~10 DB queries × ~400ms on every consecutive MCP call.
# Key: profile name. Value: (brief_str, expiry_monotonic).
# TTL 1800s (non-empty brief) / 120s (empty brief — changes more quickly).
# ±20% jitter applied at set-time to prevent thundering-herd expiry.
# Write tools (log_decision etc.) evict the entry so the next brief is fresh.
import random as _random
_BRIEF_CONTENT_CACHE: dict[str, tuple[str, float]] = {}
_BRIEF_CONTENT_CACHE_LOCK = threading.Lock()
_BRIEF_CONTENT_CACHE_TTL_S: float = 1800.0
_BRIEF_CONTENT_CACHE_EMPTY_TTL_S: float = 120.0


def _brief_content_cache_get(profile: str) -> "str | None":
	"""Return cached brief string for profile, or None if absent/expired."""
	with _BRIEF_CONTENT_CACHE_LOCK:
		entry = _BRIEF_CONTENT_CACHE.get(profile)
	if entry is None:
		return None
	brief_str, expiry = entry
	if time.monotonic() < expiry:
		return brief_str
	with _BRIEF_CONTENT_CACHE_LOCK:
		_BRIEF_CONTENT_CACHE.pop(profile, None)
	return None


def _brief_content_cache_set(profile: str, brief_str: str, is_empty: bool = False) -> None:
	"""Store brief string for profile with TTL + ±20% jitter."""
	base_ttl = _BRIEF_CONTENT_CACHE_EMPTY_TTL_S if is_empty else _BRIEF_CONTENT_CACHE_TTL_S
	jitter = base_ttl * 0.2 * (_random.random() * 2 - 1)  # ±20%
	expiry = time.monotonic() + base_ttl + jitter
	with _BRIEF_CONTENT_CACHE_LOCK:
		_BRIEF_CONTENT_CACHE[profile] = (brief_str, expiry)


def _evict_brief_cache_for_profile(profile: str) -> None:
	"""Remove brief cache entry for profile (called after write-tool dispatch)."""
	with _BRIEF_CONTENT_CACHE_LOCK:
		_BRIEF_CONTENT_CACHE.pop(profile, None)

# Dedup guard: profiles whose background prefetch is in-flight. Guarded by
# _pending_cache_lock (same lock as _pending_greeting/_pending_brief) to avoid
# a second threading.Lock per project rule (see _PROFILE_LOCK note above).
_prefetch_in_flight: set[str] = set()

# Session-novelty gate: only run prefetch once per _PREFETCH_MIN_INTERVAL_S per
# profile per instance. Prevents N-per-session pool waste (greet + brief each
# consume a connection even when they return early after the cooldown check).
_last_prefetch_time: _BoundedDict = _BoundedDict()
_PREFETCH_MIN_INTERVAL_S: float = 300.0  # 5 minutes

# Module-level executor for _maybe_greet parallel fetches — avoids creating
# a new ThreadPoolExecutor on every greet check (which burns thread churn).
# 12 workers: supports 4 concurrent profiles (3 fetches each) without queuing.
import atexit as _atexit
_greet_pool = _cf.ThreadPoolExecutor(max_workers=12, thread_name_prefix="mnemo-greet")
# SIGTERM does not fire atexit on Cloud Run; drain cleanly within grace window.
_atexit.register(lambda: _greet_pool.shutdown(wait=True, cancel_futures=True))

# S9: Bounded executor for slow-path MCP tools.
# max_workers=4 rationale: slow tools (search_memory, wrap_session, get_morning_brief,
# index_session_fragment) each hold a thread for 200–2000ms awaiting DB/vector queries.
# Capping at 4 ensures the default executor (40 workers) retains capacity for fast tools
# like mnemo_help and get_decisions, preventing starvation under burst traffic.
# After S1+S2 ship: remove search_memory and wrap_session from _SLOW_TOOLS
# (they become single fast HTTP calls, no longer need the slow executor).
_slow_executor = _cf.ThreadPoolExecutor(
    max_workers=4, thread_name_prefix="mnemo-slow"
)
_atexit.register(lambda: _slow_executor.shutdown(wait=True, cancel_futures=False))

_SLOW_TOOLS = {
    "search_memory", "get_morning_brief", "index_session_fragment"
}

# S3: tools that emit notifications/progress when a progressToken is present.
# Rationale: all other slow tools are fixed at source by S1/S2/S4 (single fast
# HTTP call, latency eliminated).  Progress adds no value when latency is gone.
# index_session_fragment remains slow (embedding I/O on the backend), so it is
# the only eligible tool.
_PROGRESS_ELIGIBLE_TOOLS = {"index_session_fragment"}

# Async lock for _maybe_greet_async (direct-DB path). Separate from
# _pending_cache_lock so the sync _maybe_greet tests stay unaffected.
_greet_async_lock: asyncio.Lock = asyncio.Lock()

# Strong-reference set so background tasks aren't GC'd before they complete.
_bg_tasks: set = set()

def _register_bg_task(task) -> None:
	_bg_tasks.add(task)
	task.add_done_callback(_bg_tasks.discard)

# Stop-words for keyword overlap matching (Unit H contextual surface).
_SURFACE_STOP_WORDS: frozenset[str] = frozenset({
	"a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
	"have", "has", "had", "do", "does", "did", "will", "would", "shall",
	"should", "may", "might", "can", "could", "must",
})

# Cooldown window for session greeting (seconds).
_GREET_COOLDOWN_SECS = 4 * 3600  # 4 hours

# ── Unit G: Session accumulator ───────────────────────────────────────────────
# Lazily detected via timestamp comparison on every tool call — no threads,
# no timers. Auto-flushes to /internal/wrap-session when gap > 10 min.
_session_buffer: _BoundedDict = _BoundedDict()   # profile_id -> [{tool, timestamp, input_summary}]
_last_tool_call: _BoundedDict = _BoundedDict()   # profile_id -> last call datetime

_SESSION_FLUSH_GAP_SECONDS = 600  # 10 minutes


def _auto_flush_session(profile_id: str) -> None:
	"""POST buffered tool trace to backend and clear buffer. Fire-and-forget."""
	buf = _session_buffer.get(profile_id, [])
	if not buf:
		return
	payload = {
		"profile_id": profile_id,
		"buffer": list(buf),
		"source": "auto",
	}
	try:
		_api_call("POST", "/internal/wrap-session", payload, timeout_sec=10.0)
	except Exception:
		pass  # never block tool calls on flush failure
	_session_buffer[profile_id] = []


def _check_and_flush(profile_id: str, tool_name: str, input_summary: str) -> None:
	"""Append current call to buffer. If gap since last call > 10min, flush first."""
	now = datetime.utcnow()
	last = _last_tool_call.get(profile_id)
	if last is not None and (now - last).total_seconds() > _SESSION_FLUSH_GAP_SECONDS:
		_auto_flush_session(profile_id)
	# Append *after* potential flush so current call starts a new session trace
	_session_buffer.setdefault(profile_id, []).append({
		"tool": tool_name,
		"timestamp": now.isoformat(),
		"input_summary": _safe_scrub(str(input_summary))[:200],
	})
	_last_tool_call[profile_id] = now


# ── HTTP client wrapper ────────────────────────────────────────────────────────

def _effective_api_token() -> str:
    """Return the best available API token.

    Priority:
    1. Module-level env var (standalone pip-package mode, MNEMO_API_TOKEN set).
    2. Per-request hint set by _mcp_api_token_hint_middleware (HTTP transport mode).

    Note: When running under ThreadPoolExecutor, contextvars may not survive.
    Ensure _MCP_API_TOKEN_HINT is set before submitting threads.
    """
    global _API_TOKEN, _API_TOKEN_RESOLVED_AT
    if _API_TOKEN:
        # Re-resolve if a dynamic command provider is configured and the TTL has expired.
        # Static env vars (MNEMO_API_TOKEN) are never re-resolved — the token is stable.
        if (
            os.getenv("MNEMO_API_TOKEN_CMD", "")
            and time.monotonic() - _API_TOKEN_RESOLVED_AT > _TOKEN_REFRESH_INTERVAL
        ):
            fresh = resolve_api_token("")
            if fresh:
                _API_TOKEN = fresh
                logger.debug("[MCP token] Re-resolved token from MNEMO_API_TOKEN_CMD")
            else:
                logger.warning("[MCP token] MNEMO_API_TOKEN_CMD returned empty — keeping prior token for next %ds", int(_TOKEN_REFRESH_INTERVAL))
            _API_TOKEN_RESOLVED_AT = time.monotonic()
        else:
            logger.debug("[MCP token] Using _API_TOKEN env var")
        return _API_TOKEN

    # access_token.token is the DB identity, not the raw bearer — never use it as
    # an API bearer.  The raw bearer is preserved by _mcp_api_token_hint_middleware
    # via _MCP_API_TOKEN_HINT; read that below.

    # Hint set by middleware before this call (should always be present for HTTP transport)
    hint_token = _MCP_API_TOKEN_HINT.get("")
    logger.debug("[MCP token] Checking hint, found: %s", bool(hint_token) and hint_token[:20])
    if hint_token:
        logger.info("[MCP token] Using token from hint")
        return str(hint_token)

    # Last resort: empty string will fail at API layer with clear error
    logger.error("[MCP token] No token found - returning empty string (will cause 401)")
    return ""


def _safe_scrub(text: str) -> str:
    """Scrub PII from text. C-03: pii_scrubber is a hard dependency; if
    scrubbing itself raises we refuse rather than silently write raw text.
    """
    if not text:
        return text
    if _scrub_pii is None:  # defensive — import guarantees non-None
        raise RuntimeError("pii_scrubber unavailable: refusing to write unredacted text")
    scrubbed, _ = _scrub_pii(text)
    return scrubbed


def _api_call(
    method: str,
    path: str,
    body: Optional[Dict] = None,
    timeout_sec: float = 30.0,
    extra_headers: Optional[Dict[str, str]] = None,  # NEW: forwarded to core.api_call
) -> Dict[str, Any]:
    return api_call(
        _API_URL,
        _effective_api_token(),
        method,
        path,
        body=body,
        timeout_sec=timeout_sec,
        extra_headers=extra_headers,  # NEW
    )


def _current_access_token() -> Any | None:
    """Return the current MCP access token if this call is running under HTTP auth."""
    try:
        from mcp.server.auth.middleware.auth_context import get_access_token
    except Exception:
        return None
    try:
        return get_access_token()
    except Exception:
        return None


def _normalise_profile_slug(value: Any) -> str:
    """Normalise an arbitrary input to a safe profile slug.

    QA-5 fix: input is capped at 256 characters BEFORE the character-filter
    comprehension runs, preventing O(N) iteration on poison-pill inputs.
    Characters that could be interpreted as ChromaDB query operators
    (``$``, ``{``, ``}``, ``"``, ``'``) are excluded by the isalnum() +
    explicit set allowlist — only ``[a-z0-9_-]`` can appear in the result.
    """
    # Cap BEFORE any iteration — prevents O(100k) comprehension on long inputs.
    slug = str(value or "")[:256].strip().lower()
    if not slug:
        return ""
    safe = "".join(ch for ch in slug if ch.isalnum() or ch in {"-", "_"})
    return safe[:64]


def _resolve_profile_from_api() -> str:
    me = _api_call("GET", "/me", timeout_sec=5.0)
    if not isinstance(me, dict) or "error" in me:
        return ""
    for field in ("profile", "bound_profile_id"):
        slug = _normalise_profile_slug(me.get(field))
        if slug:
            return slug
    return ""


def _active_profile() -> str:
    explicit = _normalise_profile_slug(_PROFILE)
    if explicit:
        return explicit

    # HTTP SSE transport sets this contextvar before dispatching into the thread
    # so we never fall through to the API call for that path.
    ctx_profile = _normalise_profile_slug(_ACTIVE_PROFILE_CTX.get(""))
    if ctx_profile:
        return ctx_profile

    # When running embedded inside the MCP HTTP server, the profile is already
    # resolved per-request by verify_token and stored in the MCP auth context.
    # Use it directly — do NOT use the global cache here, since each HTTP request
    # may belong to a different user.
    access_token = _current_access_token()
    if access_token:
        slug = _normalise_profile_slug(getattr(access_token, "client_id", ""))
        if slug:
            return slug

    # Standalone pip-package mode: MNEMO_API_TOKEN is set in the environment.
    # Cache the resolved profile for the process lifetime (single-user process).
    global _RESOLVED_PROFILE
    if _RESOLVED_PROFILE:
        return _RESOLVED_PROFILE

    resolved = _resolve_profile_from_api()
    if not resolved:
        raise RuntimeError(
            "Profile is not provisioned for this token yet. "
            "Sign in to Mnemo portal and run setup once: /portal/api/profile/ensure."
        )
    _RESOLVED_PROFILE = resolved
    return _RESOLVED_PROFILE


def _run_in_context(func: Callable[[], Any]) -> Any:
    """Run a function in the current context, for use with ThreadPoolExecutor.

    Preserves contextvars (like MCP auth tokens) when submitting to worker threads.
    """
    ctx = contextvars.copy_context()
    return ctx.run(func)


def _profile_path(suffix: str) -> str:
    base = urllib.parse.quote(_active_profile())
    tail = suffix if suffix.startswith("/") else f"/{suffix}"
    return f"/profile/{base}{tail}"


def _resolve_profile(args: Dict[str, Any]) -> str:
    """Return profile for READ-ONLY operations.

    Accepts a profile hint from *args* only when it matches the token-derived
    profile exactly.  For write operations use _resolve_profile_write() instead.
    """
    token_profile = _active_profile()
    from_args = _normalise_profile_slug(args.get("profile"))
    if from_args and from_args != token_profile:
        # Client supplied a profile that differs from the authenticated token —
        # ignore it to prevent IDOR on reads.
        logger.warning(
            "[_resolve_profile] args profile %r overridden by token profile %r",
            from_args,
            token_profile,
        )
    return token_profile


def _resolve_profile_write(args: Dict[str, Any]) -> str:  # noqa: ARG001
    """Return profile for WRITE operations — always from the authenticated token.

    The *args* dict is accepted for API symmetry but the profile key is
    intentionally ignored so that an LLM/client cannot redirect writes to an
    arbitrary profile.
    """
    return _active_profile()


def set_mcp_client_hint(client: str) -> contextvars.Token:
    return _MCP_CLIENT_HINT.set((client or "").strip().lower())


def reset_mcp_client_hint(token: contextvars.Token) -> None:
    _MCP_CLIENT_HINT.reset(token)


def set_mcp_api_token_hint(raw_token: str) -> contextvars.Token:
    return _MCP_API_TOKEN_HINT.set((raw_token or "").strip())


def reset_mcp_api_token_hint(token: contextvars.Token) -> None:
    _MCP_API_TOKEN_HINT.reset(token)


def set_active_profile_hint(profile: str) -> contextvars.Token:
    return _ACTIVE_PROFILE_CTX.set((profile or "").strip())


def reset_active_profile_hint(token: contextvars.Token) -> None:
    _ACTIVE_PROFILE_CTX.reset(token)


# ── Tool definitions ──────────────────────────────────────────────────────────

MNEMO_TOOLS: List[Dict[str, Any]] = [
    {
        "name": "search_memory",
        "description": (
            "Semantically search session history by query. "
            "Supports summary mode (default) and verbatim detail mode (verbatim=true). "
            "Call this tool directly — never delegate to a subagent."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The topic or question to search for"},
                "verbatim": {
                    "type": "boolean",
                    "description": (
                        "When true, returns the full stored key_output for each matched session "
                        "instead of the short 120-char snippet. Use when the user asks for "
                        "'details', 'full notes', or 'verbatim' content. "
                        "Automatically sets max_tokens=4000 and n_results=2 unless overridden."
                    ),
                    "default": False,
                },
                "max_tokens": {
                    "type": "integer",
                    "description": "Maximum tokens to return (default: 1500 in summary mode, 4000 in verbatim mode)",
                    "default": 1500,
                },
                "n_results": {
                    "type": "integer",
                    "description": "Number of sessions to retrieve (default: 5 in summary mode, 2 in verbatim mode)",
                    "default": 5,
                },
                "include": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Memory types to include: sessions, decisions, threads, entities",
                    "default": ["sessions", "decisions", "threads"],
                },
                "project": {
                    "type": "string",
                    "description": "Project slug to scope results. Infer from repo name or CLAUDE.md; ask only if ambiguous.",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "list_threads",
        "description": (
            "List threads sorted by recurrence/importance. "
            "Call this tool directly — never delegate to a subagent."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "enum": ["open", "deferred", "resolved", "dormant", "all"],
                    "description": "Filter by status. Default: open.",
                    "default": "open",
                },
                "limit": {"type": "integer", "description": "Max threads to return (default: 10).", "default": 10},
                "project": {
                    "type": "string",
                    "description": "Project slug to scope results. Infer from repo name or CLAUDE.md; ask only if ambiguous.",
                },
            },
        },
    },
    {
        "name": "escalate_thread",
        "description": "Set a deadline on a thread to mark it as time-sensitive. Both thread_id and deadline are required.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "thread_id": {"type": "string", "description": "Thread ID to escalate."},
                "deadline": {"type": "string", "description": "ISO 8601 deadline, e.g. '2026-04-20T17:00:00Z'."},
            },
            "required": ["thread_id", "deadline"],
        },
    },
    {
        "name": "escalate_threads",
        "description": (
            "Set deadlines on N threads in a single call — batch variant of escalate_thread. "
            "Use when you have 2+ threads to escalate at once."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "items": {
                    "type": "array",
                    "description": "Array of {thread_id, deadline} objects. Max 25.",
                    "maxItems": 25,
                    "items": {
                        "type": "object",
                        "properties": {
                            "thread_id": {"type": "string", "description": "Thread ID to escalate."},
                            "deadline": {"type": "string", "description": "ISO 8601 deadline, e.g. '2026-05-01T17:00:00Z'."},
                        },
                        "required": ["thread_id", "deadline"],
                    },
                },
            },
            "required": ["items"],
        },
    },
    {
        "name": "get_overdue_threads",
        "description": "Return threads whose deadline has passed. Use to surface time-sensitive items that need immediate attention.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "Optional project scope."},
                "limit": {"type": "integer", "description": "Max threads to return (default: 20).", "default": 20},
            },
        },
    },
    {
        "name": "get_decisions",
        "description": (
            "Retrieve tracked decisions with confidence, domain, and outcome status. "
            "Modes: default (open), stale=true (decision debt), blocked=true (stalled on threads). "
            "Call this tool directly — never delegate to a subagent."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {"type": "string", "enum": ["open", "resolved", "all"], "default": "open"},
                "domain": {"type": "string", "description": "Filter by domain: strategy, product, operations, etc."},
                "limit": {"type": "integer", "default": 10},
                "project": {
                    "type": "string",
                    "description": "Project slug to scope results. Infer from repo name or CLAUDE.md; ask only if ambiguous.",
                },
                "stale": {
                    "type": "boolean",
                    "description": "When true, return only open decisions not updated in stale_days days.",
                    "default": False,
                },
                "stale_days": {
                    "type": "integer",
                    "description": "Staleness threshold in days when stale=true (default: 14).",
                    "default": 14,
                },
                "blocked": {
                    "type": "boolean",
                    "description": "When true, return only open decisions that have unresolved threads in their time window.",
                    "default": False,
                },
                "include_intel": {
                    "type": "boolean",
                    "description": "When true, append contradiction and assumption analysis footer (adds 3–6s). Off by default.",
                    "default": False,
                },
                "format": {"type": "string", "enum": ["compact", "table"], "description": "compact=JSON array (default), table=markdown", "default": "compact"},
            },
        },
    },
    {
        "name": "group_decisions",
        "description": (
            "Group decisions by domain, temporal window, or recurrence chain. "
            "Useful for surfacing patterns without reading individual decision bodies. "
            "Call this tool directly — never delegate to a subagent."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "by": {
                    "type": "string",
                    "enum": ["domain", "temporal", "recurrence"],
                    "description": "Group by this dimension. Omit to return all types.",
                },
                "limit": {
                    "type": "integer",
                    "default": 10,
                    "description": "Maximum groups to return (1–50).",
                },
                "refresh": {
                    "type": "boolean",
                    "default": False,
                    "description": "Force a recompute before returning.",
                },
            },
        },
    },
    {
        "name": "search_decisions",
        "description": (
            "Semantic + metadata search over decisions. "
            "Core params: query (omit for metadata-only filter), domain, status, limit. "
            "scope defaults to 'me' (me | team | org). "
            "Advanced params: pass as filter={scope, team_id, classification, staleness_max, "
            "include_archive, referenced_since, cursor} or as flat args — both work. "
            "include_intel=true appends contradiction + assumption analysis (adds ~3–6s). "
            "Call this tool directly — never delegate to a subagent."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Natural-language query; omit or pass '' for metadata-only filter."},
                "domain": {"type": "string", "description": "Exact-match domain filter, e.g. 'pricing'."},
                "status": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Restrict by status, e.g. ['open'] or ['open', 'resolved'].",
                },
                "limit": {"type": "integer", "description": "1–100, default 20."},
                "scope": {"type": "string", "enum": ["me", "team", "org"], "description": "ACL scope; defaults to 'me'."},
                "include_intel": {
                    "type": "boolean",
                    "description": "When true, append contradiction and assumption analysis footer (adds ~3–6s). Off by default.",
                    "default": False,
                },
                "reversibility": {
                    "type": "string",
                    "enum": ["one_way", "two_way", "unknown"],
                    "description": "Filter by reversibility.",
                },
                "decision_type": {
                    "type": "string",
                    "enum": ["tactical", "strategic", "architectural", "operational", "other"],
                    "description": "Filter by decision type.",
                },
                "team_id": {"type": "string", "description": "Team UUID; required when scope='team'."},
                "classification": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter by classification labels, e.g. ['policy', 'strategy'].",
                },
                "staleness_max": {"type": "integer", "description": "Max decision age in days."},
                "include_archive": {"type": "boolean", "description": "When true, include archived decisions. Off by default."},
                "referenced_since": {"type": "string", "description": "ISO-8601 datetime; return only decisions referenced after this timestamp."},
                "cursor": {"type": "string", "description": "Opaque pagination cursor from a previous response's next_cursor field."},
                "filter": {
                    "type": "object",
                    "description": (
                        "Advanced filters: {scope, team_id, classification, staleness_max, "
                        "include_archive, referenced_since, cursor, project}. "
                        "Flat args also accepted for backward compatibility."
                    ),
                },
                "format": {"type": "string", "enum": ["compact", "table"], "description": "compact=JSON array (default), table=markdown", "default": "compact"},
            },
            "required": ["query", "scope"],
        },
    },
    {
        "name": "get_decision_precedent",
        "description": (
            "Given a topic + optional domain, return the closest prior decisions (k=5 by default). "
            "Scope is resolved from the caller's auth context (me | team | org).  "
            "Use outcome_quality_filter='good' to find prior decisions on this topic that worked. "
            "Call this tool directly — never delegate to a subagent."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "topic": {"type": "string", "description": "Natural-language topic, e.g. 'annual plan discount'."},
                "domain": {"type": "string", "description": "Optional domain filter, e.g. 'pricing'."},
                "scope": {"type": "string", "enum": ["me", "team", "org"], "description": "ACL scope."},
                "team_id": {"type": "string", "description": "Required when scope=team and caller is in multiple teams."},
                "outcome_quality_filter": {
                    "type": "string",
                    "enum": ["good", "mixed", "poor"],
                    "description": "Only return precedents with a matching outcome quality score (optional).",
                },
                "include_options": {
                    "type": "boolean",
                    "default": False,
                    "description": "When true, include options_considered for each precedent (default false).",
                },
                "mode": {
                    "type": "string",
                    "enum": ["precedent", "counterfactual"],
                    "default": "precedent",
                    "description": (
                        "precedent (default): return decisions on this topic. "
                        "counterfactual: return decisions where this option was considered but rejected."
                    ),
                },
            },
            "required": ["topic", "scope"],
        },
    },
    {
        "name": "get_decision_lineage",
        "description": (
            "DI-MVP-005: full supersede chain (ancestors, descendants, siblings) + "
            "contradiction matches for one decision.  Returns 404 if decision_id not found.  "
            "Call this tool directly — never delegate to a subagent."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "decision_id": {"type": "string", "description": "The decision_id to trace (TEXT, dec_<hex> format)."},
                "depth": {"type": "integer", "description": "Max supersede traversal depth (1–50, default 10)."},
            },
            "required": ["decision_id"],
        },
    },
    {
        "name": "search_entities",
        "description": "Look up entities mentioned across sessions (people, companies, projects, etc.) with mention count and history.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Entity name to look up (partial match supported)"},
                "entity_type": {"type": "string", "description": "Filter by entity type"},
                "limit": {"type": "integer", "default": 5},
                "project": {
                    "type": "string",
                    "description": "Project slug to scope results. Infer from repo name or CLAUDE.md; ask only if ambiguous.",
                },
            },
        },
    },
    {
        "name": "get_morning_brief",
        "description": (
            "Get the morning brief: priority level, since-yesterday delta, decision debt, open threads, and usage snapshot. "
            "Output is markdown-formatted — present it verbatim to the user with headers and tables as returned; do not paraphrase or reformat. "
            "Call this tool directly — never delegate to a subagent."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "format": {"type": "string", "enum": ["structured", "narrative"], "default": "structured"},
                "project": {
                    "type": "string",
                    "description": "Project slug to scope results. Infer from repo name or CLAUDE.md; ask only if ambiguous.",
                },
            },
        },
    },
    {
        "name": "index_session_fragment",
        "description": "Index an external session (task + output) into Mnemo for future retrieval.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "maxLength": 4000, "description": "The task or question that was addressed"},
                "output": {"type": "string", "maxLength": 20000, "description": "The key output or conclusion from the session"},
                "source": {"type": "string", "description": "Source identifier (e.g. 'claude_code', 'claude_agent')", "default": "external_mcp"},
                "app_id": {"type": "string", "description": "App this session belongs to (default: meridian)", "default": "meridian"},
                "project": {
                    "type": "string",
                    "description": "Project slug to scope results. Infer from repo name or CLAUDE.md; ask only if ambiguous.",
                },
            },
            "required": ["task", "output"],
        },
    },
    {
        "name": "log_decisions",
        "description": (
            "Record one or more decisions in a single call. Preferred over log_decision when you have "
            "multiple decisions — send them as an array instead of parallel calls. "
            "Returns per-item results so a duplicate in one item never blocks the others. "
            "Max 25 items per call."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "decisions": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 25,
                    "description": "List of decisions to log. Send all decisions from one response here rather than calling log_decision N times in parallel.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "content": {"type": "string", "maxLength": 4000, "description": "The decision statement — start with 'We will' or 'We are'"},
                            "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0, "description": "0.5=coin flip, 0.7=leaning, 0.85=high conviction, 0.95+=rare."},
                            "domain": {"type": "string", "default": "strategy", "description": "strategy, product, hiring, pricing, gtm, board, operations, partnerships, other"},
                            "importance": {"type": "string", "enum": ["low", "medium", "high", "critical"]},
                            "rationale": {"type": "string", "maxLength": 8000, "description": "Why this decision was made"},
                            "project": {"type": "string", "description": "Project slug — infer from repo name or CLAUDE.md"},
                        },
                        "required": ["content"],
                    },
                },
            },
            "required": ["decisions"],
        },
    },
    {
        "name": "log_decision",
        "description": (
            "Record a single decision. Use log_decisions (array form) when you have multiple decisions "
            "to avoid parallel calls. Confidence: 0.5=coin flip, 0.85=high conviction."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "maxLength": 4000, "description": "The decision statement — start with 'We will' or 'We are'"},
                "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0, "description": "0.5=coin flip, 0.7=leaning, 0.85=high conviction, 0.95+=rare. Be honest."},
                "domain": {
                    "type": "string",
                    "default": "strategy",
                    "description": "Domain category. Valid values: strategy, product, hiring, pricing, gtm, board, operations, partnerships, other. Aliases like 'go-to-market', 'talent', 'ops' are also accepted.",
                },
                "importance": {
                    "type": "string",
                    "enum": ["low", "medium", "high", "critical"],
                    "description": "Explicit importance override. If omitted, importance is auto-calculated from confidence + domain + recency.",
                },
                "rationale": {"type": "string", "maxLength": 8000, "description": "Why this decision was made"},
                "project": {
                    "type": "string",
                    "description": "Project slug to scope results. Infer from repo name or CLAUDE.md; ask only if ambiguous.",
                },
                "reversibility": {
                    "type": "string",
                    "enum": ["one_way", "two_way", "unknown"],
                    "default": "unknown",
                    "description": "one_way=hard to undo (hire, pricing floor); two_way=easily reversed; unknown=not assessed.",
                },
                "decision_type": {
                    "type": "string",
                    "enum": ["tactical", "strategic", "architectural", "operational", "other"],
                    "default": "other",
                    "description": "Category of decision for filtering and calibration reporting.",
                },
                "review_by": {
                    "type": "string",
                    "description": "ISO 8601 date/datetime to schedule a review of this decision, e.g. '2026-07-01'.",
                },
                "verbose": {"type": "boolean", "description": "Full output (default false = compact ~15 tokens)", "default": False},
            },
            "required": ["content"],
        },
    },
    {
        "name": "wrap_session",
        "description": "Atomically log session, decisions made, and open threads at session end.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "One-sentence summary of the task or question addressed this session",
                },
                "output": {
                    "type": "string",
                    "description": "The key output, conclusion, or deliverable from this session (2-5 sentences)",
                },
                "decisions": {
                    "type": "array",
                    "description": "Decisions made during this session",
                    "items": {
                        "type": "object",
                        "properties": {
                            "content": {"type": "string", "description": "A choice made where an alternative path was rejected. Commitments about future direction count even if no alternative is explicitly named. Do NOT include activities, tasks completed, or session summaries here."},
                            "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0, "default": 0.75},
                            "domain": {"type": "string", "default": "strategy"},
                            "rationale": {"type": "string"},
                        },
                        "required": ["content"],
                    },
                    "default": [],
                },
                "open_threads": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Unresolved questions or issues surfaced during this session",
                    "default": [],
                },
                "source": {
                    "type": "string",
                    "description": "Source of the session: 'cowork', 'claude_code', 'claude_agent', 'claude_chat'",
                    "default": "cowork",
                },
                "app_id": {
                    "type": "string",
                    "description": "App this session belongs to (default: meridian)",
                    "default": "meridian",
                },
                "project": {
                    "type": "string",
                    "description": "Project slug to scope results. Infer from repo name or CLAUDE.md; ask only if ambiguous.",
                },
                "verbose": {"type": "boolean", "description": "Full output (default false = compact ~15 tokens)", "default": False},
            },
            "required": ["task", "output"],
        },
    },
    {
        "name": "open_thread",
        "description": (
            "Open a new thread to track an unresolved question, scaling concern, or follow-up action "
            "surfaced mid-session — without requiring a full wrap_session call. "
            "Use when you detect a 'we should figure out X' or 'track: Y' during work. "
            "Returns thread_id immediately."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "The unresolved question or issue to track (required).",
                },
                "importance": {
                    "type": "string",
                    "enum": ["low", "medium", "high", "critical"],
                    "description": "Priority of this thread (default: medium).",
                    "default": "medium",
                },
                "project": {
                    "type": "string",
                    "description": "Project slug to scope the thread. Infer from repo name or CLAUDE.md; ask only if ambiguous.",
                },
                "deadline": {
                    "type": "string",
                    "description": "ISO 8601 datetime to auto-escalate on creation, e.g. '2026-04-30T17:00:00Z'.",
                },
                "body": {
                    "type": "string",
                    "description": "Optional longer-form description of the thread. Use when the title alone is lossy.",
                },
            },
            "required": ["title"],
        },
    },
    {
        "name": "open_threads",
        "description": (
            "Open N threads in a single call — batch variant of open_thread. "
            "Use when you have 2+ threads to open at once."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "threads": {
                    "type": "array",
                    "description": "Array of thread objects. Max 25.",
                    "maxItems": 25,
                    "items": {
                        "type": "object",
                        "properties": {
                            "title": {"type": "string", "description": "Thread title (required)."},
                            "importance": {
                                "type": "string",
                                "enum": ["low", "medium", "high", "critical"],
                                "default": "medium",
                            },
                            "body": {"type": "string", "description": "Optional longer description."},
                            "project": {"type": "string", "description": "Optional project slug."},
                        },
                        "required": ["title"],
                    },
                },
            },
            "required": ["threads"],
        },
    },
    {
        "name": "annotate_outcome",
        "description": (
            "Annotate the outcome of a decision, thread, or project. type param selects which:\n"
            "  decision — mark a decision as resolved, superseded, or abandoned.\n"
            "             resolved=outcome known; superseded=replaced; abandoned=dropped.\n"
            "             Add event_type to also log an execution milestone (shipped, launched, etc.).\n"
            "  thread   — close or defer a thread: resolved=answered; deferred/monitoring=postponed; "
            "dormant/abandoned=no longer relevant.\n"
            "  project  — archive a project: archived=completed work; completed=goal met; abandoned=dropped.\n"
            "             id is the project slug.\n"
            "After annotating, confirm back to user: id, type, and new status."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "type": {
                    "type": "string",
                    "enum": ["decision", "thread", "project"],
                    "description": "Whether you are annotating a decision, thread, or project.",
                },
                "id": {
                    "type": "string",
                    "description": (
                        "The decision_id, thread_id, or project slug to annotate. "
                        "For type=project, this is the project slug."
                    ),
                },
                "outcome_status": {
                    "type": "string",
                    "description": (
                        "Decision: resolved | superseded | abandoned. "
                        "Thread: resolved | deferred | dormant | monitoring | abandoned. "
                        "Project: archived | completed | abandoned."
                    ),
                },
                "outcome_notes": {
                    "type": "string",
                    "description": "Optional: brief note on what happened or why.",
                },
                "importance": {
                    "type": "string",
                    "enum": ["low", "medium", "high", "critical"],
                    "description": "Override importance level (decision type only).",
                },
                "event_type": {
                    "type": "string",
                    "enum": ["shipped", "launched", "signed", "closed", "hired", "raised", "cancelled", "other"],
                    "description": (
                        "Optional: execution milestone to log alongside the outcome. "
                        "Only applies when type=decision and outcome_status=resolved. "
                        "Replaces log_execution_event."
                    ),
                },
                "outcome_quality": {
                    "type": "string",
                    "enum": ["good", "mixed", "poor", "unknown"],
                    "description": (
                        "Optional quality assessment of how the decision played out. "
                        "Only applies when type=decision. Feeds calibration reporting."
                    ),
                },
            },
            "required": ["type", "id", "outcome_status"],
        },
    },
    {
        "name": "score_decision_outcome",
        "description": (
            "Score the quality of a resolved decision — separates disposition (was it executed?) "
            "from quality (was it correct?). Call after annotate_outcome when the outcome is known. "
            "Feeds calibration: quality scores are included in get_calibration confidence vs. quality mapping."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "decision_id": {"type": "string", "description": "The decision to score."},
                "outcome_quality": {
                    "type": "string",
                    "enum": ["good", "mixed", "poor", "unknown"],
                    "description": "good=outcome matched intent; mixed=partial success; poor=missed or wrong; unknown=too early to tell.",
                },
                "quality_rationale": {
                    "type": "string",
                    "description": "What actually happened — brief narrative of the outcome (required).",
                },
                "key_lesson": {
                    "type": "string",
                    "description": "One extractable lesson for future reference (optional).",
                },
                "predictable_in_hindsight": {
                    "type": "boolean",
                    "description": "Was the information available at decision time to predict this outcome? (optional)",
                },
                "assumptions_held": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Which assumptions proved correct (optional).",
                },
                "assumptions_failed": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Which assumptions proved wrong (optional).",
                },
            },
            "required": ["decision_id", "outcome_quality", "quality_rationale"],
        },
    },
    {
        "name": "log_decision_options",
        "description": (
            "Record the alternatives considered before a decision was made. "
            "Prevents re-litigation by making rejected options retrievable. "
            "Call immediately after log_decision."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "decision_id": {"type": "string", "description": "The decision these options were considered for."},
                "options": {
                    "type": "array",
                    "description": "List of alternatives that were considered and rejected.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "label": {"type": "string", "description": "Short name for this option, e.g. 'Use pgvector'."},
                            "rationale_rejected": {"type": "string", "description": "Why this option was not chosen."},
                            "key_tradeoff": {"type": "string", "description": "Core tradeoff vs. chosen option."},
                            "champion": {"type": "string", "description": "Who argued for this option (optional)."},
                        },
                        "required": ["label"],
                    },
                    "minItems": 1,
                },
            },
            "required": ["decision_id", "options"],
        },
    },
    {
        "name": "get_recent_changes",
        "description": "List recent write activity (added or updated) with client source and action.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "client": {
                    "type": "string",
                    "enum": ["all", "codex", "claude", "gemini", "other"],
                    "default": "all",
                },
                "action": {"type": "string"},
                "project": {"type": "string"},
                "limit": {"type": "integer", "default": 20},
                "since_days": {"type": "integer", "default": 30},
            },
        },
    },
    # log_execution_event removed from public surface (Phase 2).
    # Use annotate_outcome(type="decision", outcome_status="resolved", event_type=...) instead.
    {
        "name": "list_projects",
        "description": "List all projects with session counts, decision counts, and last activity date.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max projects to return (default: 20)", "default": 20},
            },
        },
    },
    {
        "name": "create_project",
        "description": (
            "Create a formal project record. Use before starting a new body of work to give it a name, "
            "slug, and optional goal. The slug becomes the project identifier used in all other tools. "
            "Returns the project_id and slug."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Human-readable project name (e.g. 'Mnemo Phase 2').",
                },
                "slug": {
                    "type": "string",
                    "description": "URL-safe slug identifier (auto-derived from name if omitted). "
                                   "Use lowercase-hyphenated form, e.g. 'mnemo-phase-2'.",
                },
                "goal": {
                    "type": "string",
                    "description": "One-line project goal or objective.",
                },
            },
            "required": ["name"],
        },
    },
    # close_project removed from public surface (Phase 2).
    # Use annotate_outcome(type="project", id="<slug>", outcome_status="archived") instead.
    {
        "name": "get_project_context",
        "description": "Retrieve a project's full state (sessions, decisions, threads, entities) for context injection.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {
                    "type": "string",
                    "description": "Project slug to retrieve context for. Infer from repo name or CLAUDE.md if not provided.",
                },
                "max_tokens": {
                    "type": "integer",
                    "description": "Max tokens to return (default: 2000)",
                    "default": 2000,
                },
            },
            "required": ["project"],
        },
    },
    {
        "name": "set_project_boundary",
        "description": "Set boundary mode for a project. Personal users only. 'open' = decisions searchable across all open projects (default); 'isolated' = scoped to this project only.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project_id": {"type": "string", "description": "Project ID to configure."},
                "mode": {"type": "string", "enum": ["open", "isolated"], "description": "'open' or 'isolated'."},
            },
            "required": ["project_id", "mode"],
        },
    },
    {
        "name": "get_project_boundary",
        "description": "Get boundary mode for a project, and whether the caller can override it.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project_id": {"type": "string", "description": "Project ID to query."},
            },
            "required": ["project_id"],
        },
    },
    {
        "name": "set_dedup_window",
        "description": "Set the dedup similarity lookback window (days). Range: 30–730. Default: 180.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "days": {"type": "integer", "description": "Lookback window in days (30–730)."},
            },
            "required": ["days"],
        },
    },
    {
        "name": "grant_cross_project_visibility",
        "description": "Enterprise org-admin only. Grant cross-project visibility so dedup checks can span from_project into to_project. Max 365 days expiry.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "from_project_id": {"type": "string"},
                "to_project_id": {"type": "string"},
                "expires_days": {"type": "integer", "default": 365, "description": "Days until grant expires (max 365)."},
            },
            "required": ["from_project_id", "to_project_id"],
        },
    },
    {
        "name": "revoke_cross_project_visibility",
        "description": "Enterprise org-admin only. Revoke an active cross-project visibility grant.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "from_project_id": {"type": "string"},
                "to_project_id": {"type": "string"},
            },
            "required": ["from_project_id", "to_project_id"],
        },
    },
    {
        "name": "get_calibration",
        "description": "Get calibration narrative: confidence metrics, validation rates, and judgment blind spots. Shows calibration health and where you may be overconfident or underconfident.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "resume_session",
        "description": "Get a structured resume block for the latest (or specified) session: decisions made, open threads, last intent, and recommended first actions. Call with no args at session start to instantly resume from where you left off. Replaces manual re-derivation of context.",
        "inputSchema": {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "additionalProperties": False,
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "Specific session to load. Omit for latest session (recommended default).",
                },
                "project": {
                    "type": "string",
                    "description": "Filter to sessions for this project slug. Inferred from CWD if omitted.",
                },
                "module": {
                    "type": "string",
                    "description": "Optional domain filter, e.g. 'auth', 'billing'. Narrows decision/thread scope.",
                },
                "hours_window": {
                    "type": "number",
                    "default": 4,
                    "description": "Hours after session start to include decisions/threads (default: 4).",
                },
            },
            "required": [],
        },
    },
    {
        "name": "export_data",
        "description": (
            "Export Mnemo data for backup, portability, or in-session review. "
            "Call without confirmed=true first to get token estimate; confirm before full retrieval."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "use_case": {
                    "type": "string",
                    "enum": ["backup", "portability", "review"],
                    "description": "backup=full JSON for external storage; portability=JSON ready for import_data; review=human-readable tables.",
                    "default": "review",
                },
                "include": {
                    "type": "string",
                    "enum": ["all", "sessions", "decisions", "threads", "entities", "projects"],
                    "description": "Which datasets to include. Default: all.",
                    "default": "all",
                },
                "project": {
                    "type": "string",
                    "description": "Optional: scope export to one project slug.",
                },
                "confirmed": {
                    "type": "boolean",
                    "description": "Set true ONLY after showing the user the token estimate and receiving confirmation.",
                    "default": False,
                },
            },
        },
    },
    {
        "name": "import_data",
        "description": (
            "Import previously exported Mnemo data. Modes: restore (own data), handoff (takeover), merge (combine profiles). "
            "datasets_json must be the JSON string from a prior export_data(confirmed=true) call."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "datasets_json": {
                    "type": "string",
                    "description": "JSON string of the 'datasets' field from a prior export_data(confirmed=true) response.",
                },
                "use_case": {
                    "type": "string",
                    "enum": ["restore", "handoff", "merge"],
                    "description": "restore=overwrite by ID; handoff=namespace under source profile; merge=skip existing.",
                    "default": "restore",
                },
                "source_profile": {
                    "type": "string",
                    "description": "Name of the person whose data this is (used in handoff to auto-derive project_namespace).",
                },
                "project_namespace": {
                    "type": "string",
                    "description": "Override the namespace prefix for imported records (handoff use case). Defaults to 'from_<source_profile>'.",
                },
            },
            "required": ["datasets_json"],
        },
    },
    {
        "name": "submit_feedback",
        "description": (
            "Submit product feedback to the Mnemo team about the platform, UI, or features. "
            "Use this ONLY to send feedback to the Mnemo product team — "
            "NOT for interacting with your memory system."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "message": {
                    "type": "string",
                    "description": "Your feedback message (max 2000 characters). Do not include API keys, passwords, or confidential information.",
                    "maxLength": 2000,
                },
                "category": {
                    "type": "string",
                    "enum": ["usability", "calibration", "feature_request", "bug", "other"],
                    "description": "Category of feedback.",
                },
            },
            "required": ["message"],
        },
    },
    {
        "name": "init_private_session",
        "description": (
            "Initialize an encrypted Privacy Mode session (Tier 3 profiles only). "
            "Required once per session before any data operations on Privacy Mode profiles. "
            "Returns a session token and expiry time. "
            "Passphrase is never logged or stored. "
            "Rate-limited: max 5 attempts per 15 minutes per profile."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "passphrase": {
                    "type": "string",
                    "description": "Your Privacy Mode passphrase. Never logged or stored.",
                },
                "session_duration_hours": {
                    "type": "integer",
                    "description": "Session duration in hours (default: 8).",
                    "default": 8,
                },
            },
            "required": ["passphrase"],
        },
    },
    {
        "name": "get_adversary_annotation",
        "description": (
            "Retrieve the most recent adversary analysis for a resolved decision. "
            "Returns the core assumption, collapse scenario, watch conditions, "
            "stress score, and criticality score. Returns null status if no analysis exists yet."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "decision_id": {
                    "type": "string",
                    "description": "The decision ID to retrieve the adversary annotation for.",
                },
            },
            "required": ["decision_id"],
        },
    },
    {
        "name": "purge_records",
        "description": (
            "Hard delete records for compliance (GDPR/CCPA), PII leak, import error, or test data cleanup. "
            "Cascades to related records (options, assumptions, outcome scores for decisions). "
            "Writes to an immutable audit log. Requires confirmed=true after preview. "
            "Admin-only for org-scope operations."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Record IDs to purge (max 100 per call).",
                },
                "record_type": {
                    "type": "string",
                    "enum": ["session", "decision", "thread", "entity", "assumption", "option"],
                    "description": "Type of record to purge.",
                },
                "reason": {
                    "type": "string",
                    "enum": ["compliance", "pii_leak", "import_error", "test_data"],
                    "description": "Reason for purge — written to immutable audit log.",
                },
                "confirmed": {
                    "type": "boolean",
                    "default": False,
                    "description": "Set to true to execute purge. Omit for preview only.",
                },
                "project": {
                    "type": "string",
                    "description": "Scope guard: purge fails if records are not in this project.",
                },
            },
            "required": ["ids", "record_type", "reason"],
        },
    },
    {
        "name": "cancel_draft_decision",
        "description": (
            "Discard a decision that is still within its 5-minute draft window. "
            "Hard-deletes the record. Errors if the draft window has expired — decision is then committed."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "decision_id": {
                    "type": "string",
                    "description": "ID of the draft decision to cancel.",
                },
            },
            "required": ["decision_id"],
        },
    },
    {
        "name": "get_decision_velocity",
        "description": (
            "Decision rate and load metrics over time. "
            "A domain spiking in decision rate signals instability; near-zero rate signals stall. "
            "Use as an org health indicator or to spot process bottlenecks."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "window_days": {
                    "type": "integer",
                    "default": 30,
                    "description": "Lookback period in days (1–365). Default 30.",
                },
                "breakdown": {
                    "type": "string",
                    "enum": ["day", "week", "month"],
                    "default": "week",
                    "description": "Time granularity for the velocity chart.",
                },
                "domain": {
                    "type": "string",
                    "description": "Scope to one domain.",
                },
                "project": {
                    "type": "string",
                    "description": "Scope to one project.",
                },
            },
            "required": [],
        },
    },
    {
        "name": "log_assumption",
        "description": (
            "Record an assumption tied to a specific decision — builds a living risk register. "
            "Surfaces in get_assumptions_at_risk when the review_date approaches. "
            "Use after logging a decision to capture the premises it depends on."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "decision_id": {
                    "type": "string",
                    "description": "ID of the decision this assumption belongs to.",
                },
                "assumption": {
                    "type": "string",
                    "description": "The assumption text (max 2000 chars).",
                },
                "criticality": {
                    "type": "string",
                    "enum": ["low", "medium", "high", "critical"],
                    "default": "medium",
                    "description": "How bad it would be if this assumption turns out to be wrong.",
                },
                "review_date": {
                    "type": "string",
                    "description": "ISO 8601 date when this assumption should be re-evaluated.",
                },
                "idempotency_key": {
                    "type": "string",
                    "description": "Client-supplied idempotency key. Auto-generated if omitted.",
                },
            },
            "required": ["decision_id", "assumption"],
        },
    },
    {
        "name": "log_assumptions",
        "description": (
            "Write N assumptions for one decision in a single call — batch variant of log_assumption. "
            "Use when you have 2+ assumptions to log for the same decision."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "decision_id": {
                    "type": "string",
                    "description": "ID of the decision all assumptions belong to.",
                },
                "assumptions": {
                    "type": "array",
                    "description": "Array of assumption objects. Max 25.",
                    "maxItems": 25,
                    "items": {
                        "type": "object",
                        "properties": {
                            "content": {"type": "string", "description": "Assumption text (max 1000 chars)."},
                            "note": {"type": "string", "description": "Optional note."},
                        },
                        "required": ["content"],
                    },
                },
            },
            "required": ["decision_id", "assumptions"],
        },
    },
    {
        "name": "get_assumptions_at_risk",
        "description": (
            "Return assumptions whose review_date falls within the given window, "
            "ordered by criticality. Use to triage which decisions need re-evaluation soon."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "window_days": {
                    "type": "integer",
                    "default": 7,
                    "description": "How many days ahead to look for due assumptions.",
                },
                "criticality": {
                    "type": "string",
                    "enum": ["low", "medium", "high", "critical"],
                    "description": "Filter by criticality level.",
                },
                "project": {
                    "type": "string",
                    "description": "Restrict to a specific project.",
                },
            },
            "required": [],
        },
    },
    {
        "name": "get_pending_assumptions",
        "description": (
            "Return auto-captured assumptions awaiting review (status='proposed'). "
            "These are assumptions extracted from session rationale or decisions that have not yet been confirmed or dismissed. "
            "Use confirm_pending_assumption or dismiss_pending_assumption to act on each item. "
            "Proposed assumptions NEVER appear in get_decisions or get_assumptions_at_risk."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "default": 20,
                    "description": "Max items to return (1–50, default 20).",
                },
                "include_dismissed": {
                    "type": "boolean",
                    "default": False,
                    "description": "When true, also include already-dismissed pending rows.",
                },
            },
            "required": [],
        },
    },
    {
        "name": "confirm_pending_assumption",
        "description": (
            "Promote a pending assumption to the confirmed decision_assumptions table. "
            "Use the pending_id returned by get_pending_assumptions."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "pending_id": {
                    "type": "string",
                    "description": "The pending_id of the assumption to confirm.",
                },
            },
            "required": ["pending_id"],
        },
    },
    {
        "name": "dismiss_pending_assumption",
        "description": (
            "Dismiss a pending assumption so it no longer appears in the review queue. "
            "Use the pending_id returned by get_pending_assumptions."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "pending_id": {
                    "type": "string",
                    "description": "The pending_id of the assumption to dismiss.",
                },
            },
            "required": ["pending_id"],
        },
    },
    {
        "name": "confirm_pending_assumptions",
        "description": (
            "Promote N pending assumptions to active in a single call — batch variant of confirm_pending_assumption. "
            "Use when you have 2+ pending assumptions to confirm."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "pending_ids": {
                    "type": "array",
                    "description": "Array of pending_id strings to confirm. Max 25.",
                    "maxItems": 25,
                    "items": {"type": "string"},
                },
            },
            "required": ["pending_ids"],
        },
    },
    {
        "name": "dismiss_pending_assumptions",
        "description": (
            "Dismiss N pending assumptions in a single call — batch variant of dismiss_pending_assumption. "
            "Use when you have 2+ pending assumptions to dismiss."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "pending_ids": {
                    "type": "array",
                    "description": "Array of pending_id strings to dismiss. Max 25.",
                    "maxItems": 25,
                    "items": {"type": "string"},
                },
            },
            "required": ["pending_ids"],
        },
    },
    {
        "name": "get_decision_contradictions",
        "description": (
            "Scan the active decision corpus for pairs of decisions that conflict with each other. "
            "Returns contradiction pairs with severity score. "
            "Run after bulk decision logging or when architectural coherence is in question. "
            "Results are cached per profile for 30 minutes — fast on repeat calls."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "scope": {
                    "type": "string",
                    "enum": ["me", "team", "org"],
                    "description": "ACL scope to scan.",
                },
                "domain": {
                    "type": "string",
                    "description": "Restrict scan to one domain, e.g. 'pricing'.",
                },
                "active_only": {
                    "type": "boolean",
                    "default": True,
                    "description": "When true (default), only scan open decisions.",
                },
                "min_severity": {
                    "type": "number",
                    "minimum": 0.0,
                    "maximum": 1.0,
                    "default": 0.5,
                    "description": "Minimum contradiction severity to include (0.0–1.0). Default 0.5.",
                },
                "limit": {
                    "type": "integer",
                    "default": 10,
                    "description": "Max contradiction pairs to return.",
                },
            },
            "required": ["scope"],
        },
    },
    {
        "name": "attestation_get_log",
        "description": (
            "Retrieve the cryptographic attestation log for the current session. "
            "Returns a hash-chained, ECDSA P-256–signed append-only log of all tool "
            "calls received and delivered in this session. Clients can verify the chain "
            "locally using the server_public_key in the session_root leaf."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "from_seq": {
                    "type": "integer",
                    "description": "First sequence number to include (default: 0).",
                },
                "to_seq": {
                    "type": "integer",
                    "description": "Last sequence number to include (default: latest).",
                },
            },
        },
    },
    {
        "name": "mnemo_help",
        "description": (
            "Get help with Mnemo — how it works, what to do next, and how to get more value. "
            "Call with no topic for a personalised next step based on your activity, or request "
            "a specific topic: 'quickstart', 'decisions', 'threads', 'memory', 'brief', 'advanced'."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "topic": {
                    "type": "string",
                    "description": (
                        "Optional. One of: 'quickstart', 'decisions', 'threads', 'memory', "
                        "'brief', 'advanced'. Leave empty for a personalised next step."
                    ),
                    "maxLength": 64,
                    "default": "",
                },
            },
            "required": [],
        },
    },
]

# ── W3.1: org/team lifecycle tool specs (org_* surface) ──────────────────────
# Imported and appended here so the existing list_tools() loop emits them
# alongside the legacy spec block. Kept in a separate module to keep server.py
# under control as the surface grows.
from mnemo_mcp.tools.team_org import (  # noqa: E402
	ORG_TOOL_HANDLERS as _ORG_TOOL_HANDLERS,
	ORG_TOOL_SPECS as _ORG_TOOL_SPECS,
	ORG_WRITE_TOOLS as _ORG_WRITE_TOOLS,
)
MNEMO_TOOLS.extend(_ORG_TOOL_SPECS)

# CoSAI T1: every tool inputSchema must reject unknown fields at the client
# dispatch layer. Apply additionalProperties:false post-hoc so future tools
# get it automatically without per-tool annotation.
for _t in MNEMO_TOOLS:
    _schema = _t.get("inputSchema", {})
    if isinstance(_schema, dict) and _schema.get("type") == "object":
        _schema["additionalProperties"] = False
        # Ensure nested array item schemas also reject unknown fields
        for _prop in _schema.get("properties", {}).values():
            if isinstance(_prop, dict) and _prop.get("type") == "object":
                _prop.setdefault("additionalProperties", False)
            if isinstance(_prop, dict) and _prop.get("type") == "array":
                _items = _prop.get("items", {})
                if isinstance(_items, dict) and _items.get("type") == "object":
                    _items.setdefault("additionalProperties", False)

# ── Tool hint annotations (OpenAI App Directory / MCP spec) ──────────────────
# readOnlyHint   — true = strictly fetches, never mutates
# destructiveHint — true = irreversible side-effects (hard delete, overwrite)
# openWorldHint  — true = writes to publicly visible internet state
# idempotentHint — true = repeated identical calls produce same result (all reads)
# All Mnemo tools operate within a closed, private-first-party system,
# so openWorldHint is false for every tool.
_TOOL_ANNOTATIONS: Dict[str, Dict[str, bool]] = {
    # ── Read-only (idempotent) ─────────────────────────────────────────────────
    "search_memory":              {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "list_threads":               {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_overdue_threads":        {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_decisions":              {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "group_decisions":            {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "search_decisions":           {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_decision_precedent":     {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_decision_lineage":       {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "search_entities":            {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_morning_brief":          {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_recent_changes":         {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "list_projects":              {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_project_context":        {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_calibration":            {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "resume_session":             {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "export_data":                {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_adversary_annotation":   {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_decision_velocity":      {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_assumptions_at_risk":    {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_pending_assumptions":    {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "get_decision_contradictions":{"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "attestation_get_log":        {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    "mnemo_help":                 {"readOnlyHint": True,  "idempotentHint": True,  "destructiveHint": False, "openWorldHint": False},
    # ── Write — reversible ─────────────────────────────────────────────────────
    "escalate_thread":             {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "escalate_threads":            {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "index_session_fragment":      {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "log_decisions":               {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "log_decision":                {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "wrap_session":                {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "open_thread":                 {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "open_threads":                {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "annotate_outcome":            {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "score_decision_outcome":      {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "log_decision_options":        {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "create_project":              {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "init_private_session":        {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "log_assumption":              {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "log_assumptions":             {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "confirm_pending_assumption":  {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "confirm_pending_assumptions": {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "dismiss_pending_assumption":  {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "dismiss_pending_assumptions": {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "submit_feedback":            {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    # ── Project / visibility config ────────────────────────────────────────────
    "set_project_boundary":            {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "get_project_boundary":            {"readOnlyHint": True,  "idempotentHint": True, "destructiveHint": False, "openWorldHint": False},
    "set_dedup_window":                {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "grant_cross_project_visibility":  {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "revoke_cross_project_visibility": {"readOnlyHint": False, "destructiveHint": True,  "openWorldHint": False},
    # ── Org / team lifecycle (W3.1) ────────────────────────────────────────────
    "org_create_org":                  {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "org_invite_member":               {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "org_list_members":                {"readOnlyHint": True,  "idempotentHint": True, "destructiveHint": False, "openWorldHint": False},
    "org_change_member_role":          {"readOnlyHint": False, "destructiveHint": True,  "openWorldHint": False},
    "org_suspend_member":              {"readOnlyHint": False, "destructiveHint": True,  "openWorldHint": False},
    "org_deprovision_member":          {"readOnlyHint": False, "destructiveHint": True,  "openWorldHint": False},
    "org_remove_member":               {"readOnlyHint": False, "destructiveHint": True,  "openWorldHint": False},
    "org_list_pending_invitations":    {"readOnlyHint": True,  "idempotentHint": True, "destructiveHint": False, "openWorldHint": False},
    "org_list_my_orgs":                {"readOnlyHint": True,  "idempotentHint": True, "destructiveHint": False, "openWorldHint": False},
    "org_list_my_pending_invites":     {"readOnlyHint": True,  "idempotentHint": True, "destructiveHint": False, "openWorldHint": False},
    "org_accept_invite":               {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False},
    "org_leave_org":                   {"readOnlyHint": False, "destructiveHint": True,  "openWorldHint": False},
    # ── Write — destructive (irreversible) ─────────────────────────────────────
    "purge_records":              {"readOnlyHint": False, "destructiveHint": True,  "openWorldHint": False},
    "cancel_draft_decision":      {"readOnlyHint": False, "destructiveHint": True,  "openWorldHint": False},
    "import_data":                {"readOnlyHint": False, "destructiveHint": True,  "openWorldHint": False},
}

# ── Usage recording ───────────────────────────────────────────────────────────

_MAX_TOOL_LIMIT = 50
_THREAD_STATUS_ALIASES = {
    "monitoring": "deferred",
    "abandoned": "dormant",
}


class QuotaExceededError(Exception):
    """Raised synchronously before tool dispatch when the caller is over quota."""
    def __init__(self, used: Any, limit: Any) -> None:
        self.used = used
        self.limit = limit
        super().__init__(f"MCP quota exceeded: {used}/{limit} calls this month")


# ── DB-hit budget per MCP tool call ───────────────────────────────────────────
# Phase 1 fix (d29b04e): reduced from 7 → 1-4 DB hits.
# Phase 2 fix (this file): reduces to exactly 1 DB hit, always.
#
#   Pre-call quota check (_check_quota_sync):
#     Cache hit  → 0 DB queries  (cache is refreshed from POST response below)
#     Cache miss → 1 PK lookup   GET /profile/{p}/usage/mcp-quota
#                                  → SELECT mcp_calls_this_period, mcp_calls_limit
#                                     FROM usage_quotas WHERE profile_id = $1
#
#   Post-call usage record (_record_mcp_usage, fire-and-forget):
#     Always     → 1 round-trip  POST /profile/{p}/usage/mcp
#                                  → INSERT usage_events + UPDATE usage_quotas
#                                     counter in a single transaction
#                  Response includes current quota state — background thread
#                  calls _set_cached_quota() so next _check_quota_sync is a
#                  cache hit with an accurate counter.
#
# Net: every MCP call = 1 DB round-trip, always.  Zero table scans.
# ──────────────────────────────────────────────────────────────────────────────

# Quota result cache: profile -> (result_dict, expires_monotonic)
#
# TTL=300s (5 minutes).  The counter is maintained atomically in the DB and
# refreshed from the POST response after every call, so the cache value is
# always within 1 call of the true counter.  A 5-minute TTL is safe because:
#   1. The counter increment in the POST response keeps the cache current.
#   2. Even if the background thread fails, the worst-case stale window is
#      300s — the same order of magnitude as the prior 60s design, and
#      acceptable for eventual-consistency quota enforcement.
#   3. We still never cache a quota-exceeded result — upgrades unblock immediately.
_quota_cache: Dict[str, tuple] = {}
_quota_cache_lock = threading.Lock()
_QUOTA_CACHE_TTL = 300.0
_QUOTA_CACHE_MAX = 1000


def _get_cached_quota(profile: str) -> Optional[Dict]:
    """Return the cached quota result for *profile* iff still fresh."""
    with _quota_cache_lock:
        entry = _quota_cache.get(profile)
        if entry and time.monotonic() < entry[1]:
            return entry[0]
    return None


def _set_cached_quota(profile: str, result: Dict) -> None:
    """Cache *result* for *profile*.  Prunes expired entries first.

    Capped at _QUOTA_CACHE_MAX — when full, the oldest entries are evicted.
    """
    now = time.monotonic()
    with _quota_cache_lock:
        # Prune expired entries inline — cheap (O(n)) and keeps dict bounded.
        expired = [p for p, (_v, exp) in _quota_cache.items() if exp <= now]
        for p in expired:
            _quota_cache.pop(p, None)
        # Hard cap: if still at max, evict oldest (by expiry — earliest first).
        if len(_quota_cache) >= _QUOTA_CACHE_MAX:
            oldest = sorted(_quota_cache.items(), key=lambda kv: kv[1][1])[: max(1, _QUOTA_CACHE_MAX // 10)]
            for p, _ in oldest:
                _quota_cache.pop(p, None)
        _quota_cache[profile] = (result, now + _QUOTA_CACHE_TTL)


def _clear_quota_cache() -> None:
    """Test helper — wipe the cache to make each test deterministic."""
    with _quota_cache_lock:
        _quota_cache.clear()


def _extract_quota_used_limit(result: Dict) -> tuple:
    """Extract (used, limit) from either new counter format or legacy summary format.

    New format (from /usage/mcp-quota or POST /usage/mcp response):
        {"used": N, "limit": N, "period_start": "..."}

    Legacy format (from /usage full summary — kept for test compatibility):
        {"this_month": {"mcp_calls": N}, "limits": {"mcp_calls": N}}
    """
    if "used" in result:
        used = result.get("used")
        limit = result.get("limit")
        return (0 if used is None else used), (-1 if limit is None else limit)
    this_month = result.get("this_month", {})
    limits = result.get("limits", {})
    return this_month.get("mcp_calls", 0), limits.get("mcp_calls", -1)


def _check_quota_sync(token: str, profile: str) -> None:
    """Synchronous pre-call quota check.  Raises QuotaExceededError if over limit.

    Cache miss path: GET /profile/{p}/usage/mcp-quota — single PK lookup on
    usage_quotas, no table scan of usage_events.

    Cache is also refreshed after every POST /usage/mcp call via
    _record_mcp_usage(), so steady-state calls are always cache hits.

    Caching rules:
      * Only non-exceeded results are cached.  A quota-exceeded response is
        never cached — if the user upgrades, their next call must go through.
      * The HTTP call is made WITHOUT holding the cache lock, so a slow
        backend cannot block other threads.
    """
    if not token or not profile:
        return
    result = _get_cached_quota(profile)
    if result is None:
        try:
            # Lightweight PK lookup — no table scan.
            result = api_call(
                _API_URL, token, "GET",
                f"/profile/{urllib.parse.quote(profile)}/usage/mcp-quota",
                timeout_sec=1.0,
            )
        except QuotaExceededError:
            raise
        except Exception:
            logger.warning("[quota-check] pre-call check failed — skipping enforcement", exc_info=True)
            return
        if not isinstance(result, dict) or "error" in result:
            logger.warning("[quota-check] usage endpoint returned error — skipping enforcement: %s", result)
            return
        # Evaluate exceeded-ness BEFORE caching — never cache an exceeded state.
        used, limit = _extract_quota_used_limit(result)
        if limit != -1 and used >= limit:
            # Do NOT cache — user may upgrade and we must unblock next call.
            raise QuotaExceededError(used, limit)
        _set_cached_quota(profile, result)
        return
    # Cache hit — result was stored only if previously not-exceeded, but re-check
    # in case limits changed out from under us (e.g. admin tier adjustment).
    if not isinstance(result, dict) or "error" in result:
        return
    used, limit = _extract_quota_used_limit(result)
    if limit != -1 and used >= limit:
        raise QuotaExceededError(used, limit)


def _record_mcp_usage(tool_name: str) -> Dict:
    """Fire usage recording in a daemon thread.  Returns immediately with empty dict.

    Fix #33: Capture token and profile from the calling thread's context BEFORE
    launching the background thread.  threading.Thread does NOT copy Python
    contextvars, so any context lookup inside the thread would return the wrong
    (default/empty) value, misattributing usage to a different tenant.

    The background thread parses the POST response (which contains current quota
    state) and calls _set_cached_quota() so the next _check_quota_sync() call
    is a cache hit with an accurate counter — no extra GET needed.
    """
    # Snapshot context values in the calling thread — safe to read here.
    token_snapshot: str = _effective_api_token()
    try:
        profile_snapshot: str = _active_profile()
    except Exception:
        profile_snapshot = ""

    def _record_in_background() -> None:
        # Use the snapshots captured in the calling thread — never call
        # _effective_api_token() or _active_profile() from inside this thread.
        if not profile_snapshot:
            return
        try:
            resp = api_call(
                _API_URL,
                token_snapshot,
                "POST",
                f"/profile/{urllib.parse.quote(profile_snapshot)}/usage/mcp",
                body={"tool": tool_name, "source": "mcp"},
                timeout_sec=10.0,
            )
            # Update the quota cache from the POST response so the next
            # _check_quota_sync() call is a cache hit with a fresh counter.
            if isinstance(resp, dict) and resp.get("ok") and "used" in resp:
                _u = resp.get("used")
                _l = resp.get("limit")
                used, limit = (0 if _u is None else _u), (-1 if _l is None else _l)
                # Only cache if not exceeded — user may upgrade and must unblock.
                if limit == -1 or used < limit:
                    _set_cached_quota(profile_snapshot, {
                        "used": used,
                        "limit": limit,
                        "period_start": resp.get("period_start"),
                    })
            else:
                # Response shape doesn't include ok/used — cache not refreshed.
                # This leaves the quota cache stale until the next cache-miss
                # _check_quota_sync fires. Log so billing drift is detectable.
                logger.debug(
                    "[quota-usage] POST response missing ok/used fields — cache not refreshed"
                    " profile=%s tool=%s keys=%s",
                    profile_snapshot[:20], tool_name, list((resp or {}).keys()),
                )
        except Exception:
            # Never block the user-facing response, but log so billing drift
            # is visible in Cloud Logging rather than silently accumulating.
            logger.error(
                "[quota-usage] background record failed — counter may be understated"
                " profile=%s tool=%s",
                profile_snapshot[:20], tool_name,
                exc_info=True,
            )

    thread = threading.Thread(target=_record_in_background, daemon=True)
    thread.start()
    return {}  # Return immediately — accounting is fire-and-forget


# ── Tool handlers ─────────────────────────────────────────────────────────────

def _enforce_max_len(value: Any, limit: int, field: str) -> str:
    """H-38: reject oversized string inputs even when the MCP client skipped
    schema-level maxLength enforcement."""
    text = str(value or "")
    if len(text) > limit:
        raise ValueError(
            f"Field '{field}' exceeds maximum length of {limit} characters "
            f"(got {len(text)})."
        )
    return text


def _coerce_json_array(value: Any, field_name: str) -> List[Any]:
    """Return a list, coercing JSON string payloads from MCP clients.

    Claude Code can serialize array arguments as JSON strings before they reach
    the server. Accept the native list form, JSON-encoded arrays, or a single
    scalar value as a last-resort one-item list so user data is not dropped.
    """
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return []
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("[mnemo-mcp] %s received a plain string; using one-item list", field_name)
            return [raw]
        if isinstance(parsed, list):
            return parsed
        if parsed is None:
            return []
        return [parsed]
    return [value]


def _infer_project_from_cwd() -> Optional[str]:
    """Bug 2 fix: try to infer a project slug from the current working directory.

    Reads .git/config (remote.origin.url repo name) or CLAUDE.md (# Project: <slug>
    or project= lines) in the CWD.  Returns a normalised slug or None.
    """
    import configparser
    import re

    cwd = os.getcwd()

    # 1. Try CLAUDE.md — look for a "project: <slug>" or "# <slug>" hint.
    claude_md = os.path.join(cwd, "CLAUDE.md")
    if os.path.isfile(claude_md):
        try:
            with open(claude_md, encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    # e.g. "project: my-project" or "# Project: my-project"
                    m = re.match(r"(?i)#?\s*project[:\s]+([a-z0-9][a-z0-9_\-]{0,62})", line.strip())
                    if m:
                        slug = _normalise_profile_slug(m.group(1))
                        if slug:
                            return slug
        except OSError:
            pass

    # 2. Try .git/config — extract repo name from remote.origin.url.
    git_config = os.path.join(cwd, ".git", "config")
    if os.path.isfile(git_config):
        try:
            cfg = configparser.ConfigParser()
            cfg.read(git_config, encoding="utf-8")
            url = cfg.get('remote "origin"', "url", fallback="")
            if url:
                # Strip trailing .git and take the last path component.
                repo = url.rstrip("/").rstrip(".git").rstrip("/").split("/")[-1]
                slug = _normalise_profile_slug(repo)
                if slug:
                    return slug
        except (OSError, configparser.Error):
            pass

    return None


def _resolve_project(args: Dict[str, Any]) -> str:
	"""Return project slug from args, CWD inference, or 'General' as default."""
	if args.get("project"):
		return args["project"]
	inferred = _infer_project_from_cwd()
	return inferred if inferred else "General"


_PROJECT_SLUG_CACHE: Dict[str, tuple] = {}  # {profile_path: (timestamp, frozenset[str])}
_PROJECT_SLUG_CACHE_TTL = 60.0  # seconds


def _invalidate_project_slug_cache() -> None:
	"""Drop the cached project list for the current profile. Call after create_project."""
	key = _profile_path("/projects")
	_PROJECT_SLUG_CACHE.pop(key, None)


def _validate_project_slug(slug: str) -> Optional[str]:
	"""Return None if slug is valid; return an error string if the slug does not exist.

	Skips validation for 'General' and fails-open on API errors. The project list
	is cached per profile for _PROJECT_SLUG_CACHE_TTL seconds so repeated write
	calls in the same session pay the GET cost at most once per minute.
	"""
	if not slug or slug == "General":
		return None
	key = _profile_path("/projects")
	cached = _PROJECT_SLUG_CACHE.get(key)
	now = time.monotonic()
	if cached and (now - cached[0]) < _PROJECT_SLUG_CACHE_TTL:
		known = cached[1]
	else:
		result = _api_call("GET", f"{key}?limit=200")
		if isinstance(result, dict) and "error" in result:
			return None  # fail-open: cannot validate, allow through
		projects = result if isinstance(result, list) else result.get("projects", [])
		known = frozenset(str(p.get("slug", "")).strip() for p in projects if p.get("slug"))
		_PROJECT_SLUG_CACHE[key] = (now, known)
	if slug not in known:
		suggestion = f": {', '.join(sorted(known))}" if known else ""
		return (
			f"Error: project '{slug}' does not exist. "
			f"Call create_project first, or choose an existing project{suggestion}. "
			f"[code: PROJECT_NOT_FOUND]"
		)
	return None


def _synthesise_project_context(project: str, max_tokens: int) -> str:
    """Fallback: build project context from existing tools when the dedicated
    /projects/{slug}/context endpoint is not yet available on the backend."""
    parts: List[str] = [f"# Project context: {project}\n"]

    # Resolve profile ONCE in the calling thread — same reason as _handle_get_morning_brief.
    decisions_path = _profile_path("/decisions")
    threads_path = _profile_path("/threads")

    # Parallelize the three API calls: search, decisions, and threads
    def _fetch_search() -> Dict:
        return _api_call("POST", "/api/v1/context/retrieve", {
            "query": f"project {project}",
            "max_tokens": max_tokens // 2,
            "n_memories": 5,
            "include": ["sessions", "decisions", "threads"],
            "project": project,
        })

    def _fetch_decisions() -> Dict:
        qs = urllib.parse.urlencode({"status": "open", "limit": 10, "project": project})
        return _api_call("GET", f"{decisions_path}?{qs}")

    def _fetch_threads() -> Dict:
        tqs = urllib.parse.urlencode({"status": "open", "limit": 5, "project": project})
        return _api_call("GET", f"{threads_path}?{tqs}")

    # Extract token hint VALUE from current context before submitting to workers.
    # Use manual token setting in each worker to avoid nested context.run() calls.
    _token_value = _MCP_API_TOKEN_HINT.get("")

    def _fetch_search_with_hint():
        if not _token_value:
            raise RuntimeError("MCP token unavailable in search worker — cannot make authenticated API call")
        token_ctx = _MCP_API_TOKEN_HINT.set(_token_value)
        try:
            return _fetch_search()
        finally:
            _MCP_API_TOKEN_HINT.reset(token_ctx)

    def _fetch_decisions_with_hint():
        if not _token_value:
            raise RuntimeError("MCP token unavailable in decisions worker — cannot make authenticated API call")
        token_ctx = _MCP_API_TOKEN_HINT.set(_token_value)
        try:
            return _fetch_decisions()
        finally:
            _MCP_API_TOKEN_HINT.reset(token_ctx)

    def _fetch_threads_with_hint():
        if not _token_value:
            raise RuntimeError("MCP token unavailable in threads worker — cannot make authenticated API call")
        token_ctx = _MCP_API_TOKEN_HINT.set(_token_value)
        try:
            return _fetch_threads()
        finally:
            _MCP_API_TOKEN_HINT.reset(token_ctx)

    # Don't use context-manager form — __exit__ calls shutdown(wait=True) which
    # blocks until all threads finish even after a FutureTimeoutError.
    ex = ThreadPoolExecutor(max_workers=3)
    f_search = ex.submit(_fetch_search_with_hint)
    f_decisions = ex.submit(_fetch_decisions_with_hint)
    f_threads = ex.submit(_fetch_threads_with_hint)
    try:
        search_result = f_search.result(timeout=8.0)
    except (FutureTimeoutError, Exception):
        search_result = {}
    try:
        d_result = f_decisions.result(timeout=8.0)
    except (FutureTimeoutError, Exception):
        d_result = {}
    try:
        t_result = f_threads.result(timeout=8.0)
    except (FutureTimeoutError, Exception):
        t_result = {}
    ex.shutdown(wait=False, cancel_futures=True)

    if "error" not in search_result:
        block = search_result.get("context_block", "")
        if block:
            parts.append(block)

    decisions = d_result if isinstance(d_result, list) else d_result.get("decisions", [])
    if decisions:
        parts.append(f"\n## Open decisions ({len(decisions)})")
        for d in decisions:
            parts.append(f"• [{d.get('domain', '?')}] {d.get('content', '?')} ({float(d.get('confidence', 0)):.0%})")

    threads = t_result if isinstance(t_result, list) else t_result.get("threads", [])
    if threads:
        parts.append(f"\n## Open threads ({len(threads)})")
        for t in threads:
            parts.append(f"◦ {t.get('title', '?')} — seen {t.get('recurrence_count', 1)}x")

    _record_mcp_usage("get_project_context")
    return "\n".join(parts) if len(parts) > 1 else f"No context found for project '{project}' yet."


def extract_phrase_pattern(query: str) -> Optional[str]:
	"""Extract a normalised phrase pattern from a query for anonymous gap logging.

	Examples:
	  "how to log a decision?" → "how to X"
	  "help with threads" → "help with X"
	  "what about calibration?" → "question"
	"""
	q = query.lower().strip()
	if q.startswith("how to "):
		return "how to X"
	if q.startswith("help"):
		return "help with X"
	if "?" in q:
		return "question"
	return None


def _format_export_review(datasets: Dict[str, Any], manifest: Dict[str, Any]) -> str:
    """Format export datasets as human-readable tables for in-session review."""
    lines: List[str] = [
        f"# Mnemo data review",
        f"Profile: {manifest.get('profile', '?')} | "
        f"Exported: {manifest.get('exported_at', '')[:19]}",
        "",
    ]

    # ── Decisions ─────────────────────────────────────────────────────────────
    decisions = datasets.get("decisions", [])
    if decisions:
        lines.append(f"## Decisions ({len(decisions)})")
        lines.append(f"{'DATE':<12} {'DOMAIN':<12} {'CONF':>5}  {'STATE':<12} {'IMP':<8}  DECISION")
        lines.append("-" * 90)
        for d in decisions[:50]:
            date = str(d.get("created_at") or d.get("timestamp") or "")[:10]
            domain = str(d.get("domain") or "?")[:11]
            conf = float(d.get("confidence") or 0)
            state = str(d.get("status") or "open")[:11]
            imp = str(d.get("importance") or "medium")[:7]
            content = str(d.get("content") or "?")[:80]
            lines.append(f"{date:<12} {domain:<12} {conf:>5.2f}  {state:<12} {imp:<8}  {content}")
            if d.get("decision_id"):
                lines.append(f"{'':>43}id: {d['decision_id']}")
        if len(decisions) > 50:
            lines.append(f"  … {len(decisions) - 50} more decisions (use include=decisions for full list)")
        lines.append("")

    # ── Threads ───────────────────────────────────────────────────────────────
    threads = datasets.get("threads", [])
    if threads:
        lines.append(f"## Threads ({len(threads)})")
        lines.append(f"{'STATUS':<10} {'RECUR':>5}  {'LAST SEEN':<12}  THREAD")
        lines.append("-" * 70)
        for t in threads[:30]:
            status = str(t.get("status") or "open")[:9]
            recur = int(t.get("recurrence_count") or 1)
            last = str(t.get("last_seen") or t.get("updated_at") or "")[:10]
            title = str(t.get("title") or t.get("content") or "?")[:60]
            lines.append(f"{status:<10} {recur:>5}  {last:<12}  {title}")
        if len(threads) > 30:
            lines.append(f"  … {len(threads) - 30} more threads")
        lines.append("")

    # ── Sessions summary ──────────────────────────────────────────────────────
    sessions = datasets.get("sessions", [])
    if sessions:
        lines.append(f"## Sessions — last 10 of {len(sessions)}")
        for s in sessions[-10:]:
            date = str(s.get("created_at") or "")[:10]
            task = str(s.get("task") or s.get("title") or "?")[:80]
            lines.append(f"  {date}  {task}")
        lines.append("")

    # ── Projects ──────────────────────────────────────────────────────────────
    projects = datasets.get("projects", [])
    if projects:
        lines.append(f"## Projects ({len(projects)})")
        for p in projects:
            slug = str(p.get("slug") or "?")
            status = str(p.get("status") or "active")
            goal = str(p.get("goal") or "")[:60]
            lines.append(f"  [{status}] {slug}  {goal}")
        lines.append("")

    _record_mcp_usage("export_data")
    return "\n".join(lines)


def _maybe_greet(profile_id: str, pool: Any = None, api_token: str = "") -> Optional[str]:
	"""Return greeting alert on first tool call of session (4h cooldown), else None.

	Queries the API for up to 3 urgent items in priority order:
	  1. Overdue decisions: importance high/critical, state open, updated >7d ago
	  1b. Decisions with review_by within 7 days
	  1c. Assumptions at risk (review_date within 7 days, high/critical criticality first)
	  2. Unresolved contradictions older than 3 days
	  3. Threads with 3+ recurrences still unresolved

	Silent (returns None) when nothing is urgent — no noise for active users.
	Updates _session_greeted[profile_id] only on non-None return.

	api_token must be passed explicitly from call_tool (_pre_token).
	_greet_pool.submit() does not copy contextvars, so we cannot rely on
	_MCP_API_TOKEN_HINT being available inside the worker threads.
	"""
	if not profile_id:
		return None
	# Check-and-claim under _pending_cache_lock to prevent two concurrent
	# _greet_pool threads for the same profile both passing the cooldown check
	# and both returning a greeting (duplicate alert messages).
	with _pending_cache_lock:
		last = _session_greeted.get(profile_id)
		if last is not None:
			delta = (datetime.utcnow() - last).total_seconds()
			if delta < _GREET_COOLDOWN_SECS:
				return None
		# Stamp now so a concurrent thread sees the cooldown immediately.
		# Cleared below if no urgent items are found.
		_session_greeted[profile_id] = datetime.utcnow()

	urgent: list[str] = []

	# Fetch all 4 data sources in parallel — reduces max latency from 4×2s=8s to max(2s).
	decisions_path_snap = _profile_path("/decisions/merged")
	contradictions_path_snap = _profile_path("/decisions/contradictions")
	threads_path_snap = _profile_path("/threads")
	assumptions_path_snap = _profile_path("/decisions/assumptions/at_risk")
	decisions_qs = urllib.parse.urlencode({"status": "open", "limit": 10})
	threads_qs = urllib.parse.urlencode({"status": "open", "limit": 20})
	assumptions_qs = urllib.parse.urlencode({"window_days": 7, "status": "active", "limit": 5})

	# _greet_pool.submit() does not copy contextvars. Set the token hint manually
	# inside each worker, matching the pattern at lines 2104-2122 (_handle_get_morning_brief).
	_token_value = api_token or _MCP_API_TOKEN_HINT.get("")

	def _with_token(fn):
		def _wrapped():
			if not _token_value:
				raise RuntimeError("MCP token unavailable in greet worker — cannot make authenticated API call")
			tok = _MCP_API_TOKEN_HINT.set(_token_value)
			try:
				return fn()
			finally:
				_MCP_API_TOKEN_HINT.reset(tok)
		return _wrapped

	def _fetch_decisions() -> Any:
		try:
			return _api_call("GET", f"{decisions_path_snap}?{decisions_qs}", timeout_sec=2.0)
		except Exception:
			return []

	def _fetch_contradictions() -> Any:
		try:
			return _api_call("GET", contradictions_path_snap, timeout_sec=2.0)
		except Exception:
			return []

	def _fetch_threads() -> Any:
		try:
			return _api_call("GET", f"{threads_path_snap}?{threads_qs}", timeout_sec=2.0)
		except Exception:
			return []

	def _fetch_assumptions() -> Any:
		try:
			return _api_call("GET", f"{assumptions_path_snap}?{assumptions_qs}", timeout_sec=2.0)
		except Exception:
			return {}

	_f_dec = _greet_pool.submit(_with_token(_fetch_decisions))
	_f_con = _greet_pool.submit(_with_token(_fetch_contradictions))
	_f_thr = _greet_pool.submit(_with_token(_fetch_threads))
	_f_asm = _greet_pool.submit(_with_token(_fetch_assumptions))

	# Collect all 4 results under a shared 3s deadline.
	_done, _not_done = _cf.wait([_f_dec, _f_con, _f_thr, _f_asm], timeout=3.0)

	def _collect(future, default):
		if future in _done:
			try:
				return future.result(), True
			except Exception:
				return default, False
		return default, False

	dec_result, _dec_fetch_ok = _collect(_f_dec, [])
	con_result, _ = _collect(_f_con, [])
	thr_result, _ = _collect(_f_thr, [])
	asm_result, _ = _collect(_f_asm, {})

	# 0. New-user onboarding greeting — detected from already-fetched results.
	# Condition: zero decisions AND exactly one open thread matching the onboarding title.
	# Stamp is set AFTER results confirm condition (unlike _session_greeted which stamps early).
	# Separate cooldown so a timeout on any fetch doesn't silently block new users for 4h.
	try:
		_dec_list = dec_result if isinstance(dec_result, list) else (dec_result.get("decisions", []) if isinstance(dec_result, dict) else [])
		_thr_list = thr_result if isinstance(thr_result, list) else (thr_result.get("threads", []) if isinstance(thr_result, dict) else [])
		_onboarding_title = "Getting started \u2014 3 things to try"
		_open_threads = [t for t in _thr_list if str(t.get("status") or "open").lower() not in ("resolved", "dismissed", "dormant", "abandoned")]
		_onboarding_threads = [t for t in _open_threads if _onboarding_title in str(t.get("title") or "")]
		if _dec_fetch_ok and not _dec_list and _onboarding_threads:
			with _pending_cache_lock:
				_ob_last = _onboarding_greeted.get(profile_id)
				if _ob_last is None or (datetime.utcnow() - _ob_last).total_seconds() >= _GREET_COOLDOWN_SECS:
					_onboarding_greeted[profile_id] = datetime.utcnow()
					# Clear _session_greeted so urgent-item checks aren't blocked
					# for 4h after the onboarding greeting fires.
					_session_greeted.pop(profile_id, None)
					_ob_thread = _onboarding_threads[0]
					_ob_summary = str(_ob_thread.get("summary") or _ob_thread.get("body") or "").strip()
					_ob_msg = f"👋 Welcome to Mnemo — {_onboarding_title}\n\n{_ob_summary}\n" if _ob_summary else f"👋 Welcome to Mnemo.\n\nSay \"what are my open threads?\" to see your getting-started checklist.\n"
					return _ob_msg
	except Exception as exc:
		logger.warning("[greet] onboarding check failed: %s", exc, exc_info=True)

	# 1. Overdue high/critical open decisions
	try:
		decisions = dec_result if isinstance(dec_result, list) else (dec_result.get("decisions", []) if isinstance(dec_result, dict) else [])
		for d in decisions:
			if len(urgent) >= 3:
				break
			imp = str(d.get("importance") or "").lower()
			if imp not in ("high", "critical"):
				continue
			ts_str = str(d.get("updated_at") or d.get("timestamp") or d.get("created_at") or "")
			overdue_days: int = 0
			if ts_str:
				try:
					ts = datetime.fromisoformat(ts_str[:19])
					overdue_days = (datetime.utcnow() - ts).days
				except Exception:
					overdue_days = 0
			if overdue_days >= 7:
				content = str(d.get("content") or "")[:80]
				urgent.append(f"{content} — overdue {overdue_days}d")
	except Exception as exc:
		logger.warning("[greet] decisions processing failed: %s", exc, exc_info=True)

	# 1b. Decisions with review_by date within 7 days
	if len(urgent) < 3:
		try:
			decisions_rb = dec_result if isinstance(dec_result, list) else (dec_result.get("decisions", []) if isinstance(dec_result, dict) else [])
			for d in decisions_rb:
				if len(urgent) >= 3:
					break
				review_by_str = str(d.get("review_by") or "").strip()
				if not review_by_str:
					continue
				try:
					review_ts = datetime.fromisoformat(review_by_str[:19].replace("Z", ""))
					days_until = (review_ts - datetime.utcnow()).days
					if 0 <= days_until <= 7:
						content = str(d.get("content") or "")[:80]
						urgent.append(f"{content} — review due in {days_until}d")
				except Exception:
					continue
		except Exception as exc:
			logger.warning("[greet] review_by processing failed: %s", exc, exc_info=True)

	# 1c. Assumptions at risk within 7 days
	if len(urgent) < 3:
		try:
			asm_items = (
				asm_result.get("items", []) if isinstance(asm_result, dict)
				else (asm_result if isinstance(asm_result, list) else [])
			)
			# Count by criticality and surface the worst ones first
			high_crit = [a for a in asm_items if str(a.get("criticality") or "").lower() in ("critical", "high")]
			show = high_crit or asm_items
			for a in show:
				if len(urgent) >= 3:
					break
				crit = str(a.get("criticality") or "medium").lower()
				text = str(a.get("assumption") or "")[:60]
				review = str(a.get("review_date") or "")[:10]
				review_note = f" — review by {review}" if review else ""
				urgent.append(f"{text} — {crit} assumption{review_note}")
		except Exception as exc:
			logger.warning("[greet] assumptions processing failed: %s", exc, exc_info=True)

	# 2. Contradictions — high-severity pairs (≥0.7) or unresolved older than 3 days
	if len(urgent) < 3:
		try:
			items = con_result if isinstance(con_result, list) else (con_result.get("contradictions", []) if isinstance(con_result, dict) else [])
			# Phase 7: also check pairs from contradiction scan cache (severity field)
			pairs = con_result.get("pairs", []) if isinstance(con_result, dict) else []
			for pair in pairs:
				if len(urgent) >= 3:
					break
				severity = float(pair.get("severity") or 0.0)
				if severity >= 0.7:
					summary = str(pair.get("contradiction_summary") or "Contradiction")[:80]
					urgent.append(f"{summary} — severity {severity:.0%} contradiction")
			for c in items:
				if len(urgent) >= 3:
					break
				dismissed = bool(c.get("dismissed") or c.get("resolved"))
				if dismissed:
					continue
				ts_str = str(c.get("created_at") or "")
				age_days = 0
				if ts_str:
					try:
						ts = datetime.fromisoformat(ts_str[:19])
						age_days = (datetime.utcnow() - ts).days
					except Exception:
						age_days = 0
				if age_days >= 3:
					label = str(c.get("summary") or c.get("message") or "Contradiction")[:80]
					urgent.append(f"{label} — unresolved contradiction ({age_days}d)")
		except Exception as exc:
			logger.warning("[greet] contradictions processing failed: %s", exc, exc_info=True)

	# 3. Threads with 3+ recurrences unresolved
	if len(urgent) < 3:
		try:
			threads_list = thr_result if isinstance(thr_result, list) else (thr_result.get("threads", []) if isinstance(thr_result, dict) else [])
			for t in threads_list:
				if len(urgent) >= 3:
					break
				recurrence = int(t.get("recurrence_count") or t.get("mentions") or 0)
				if recurrence >= 3:
					title = str(t.get("title") or "")[:80]
					urgent.append(f"{title} — recurring ({recurrence}x), unresolved")
		except Exception as exc:
			logger.warning("[greet] threads processing failed: %s", exc, exc_info=True)

	if not urgent:
		# Nothing to show — clear the stamp so the next session-start gets a fresh check.
		with _pending_cache_lock:
			_session_greeted.pop(profile_id, None)
		return None
	lines = "\n".join(f"• {item}" for item in urgent)
	return (
		f"⚡ Mnemo — {len(urgent)} item(s) need your attention:\n"
		f"{lines}\n"
		'(Reply "show decisions" or "show threads" to review)\n'
	)


async def _maybe_greet_async(profile_id: str) -> Optional[str]:
	"""Async, direct-DB replacement for _maybe_greet.

	Makes zero HTTP calls — queries personal_decisions, personal_contradiction_log,
	and personal_threads directly via asyncpg using one pool connection.
	Eliminates the 4-loopback fan-in that exhausted the DB pool under cold-start.

	Behaviour matches _maybe_greet: 4h cooldown, same urgency signals, same
	output format.  Does NOT cover review_by / decision_assumptions (those
	fields do not exist in the current schema).
	"""
	if not profile_id:
		return None

	async with _greet_async_lock:
		last = _session_greeted.get(profile_id)
		if last is not None and (datetime.utcnow() - last).total_seconds() < _GREET_COOLDOWN_SECS:
			return None
		_session_greeted[profile_id] = datetime.utcnow()

	urgent: list[str] = []

	try:
		from backend import db as _db_mod
		pool = await _db_mod.get_pool()
		async with pool.acquire(timeout=3.0) as conn:
			# Wrap all queries in a transaction so set_config(is_local=true) stays
			# active for all three queries. Without BEGIN, asyncpg auto-commits each
			# statement; is_local reverts at statement end, leaving subsequent queries
			# without RLS context (cross-profile data exposure under pooling).
			async with conn.transaction():
				await conn.execute(
					"SELECT set_config('app.current_profile', $1, true)",
					profile_id,
				)
				dec_rows = await conn.fetch(
					"""
					SELECT importance, updated_at, created_at
					FROM personal_decisions
					WHERE profile = $1 AND status = 'open' AND quarantine = FALSE
					  AND importance IN ('high','critical')
					ORDER BY updated_at ASC
					LIMIT 10
					""",
					profile_id,
				)

				# 0. Onboarding: no decisions at all → welcome message (one-shot)
				if not dec_rows:
					dec_total = await conn.fetchval(
						"SELECT COUNT(*) FROM personal_decisions WHERE profile = $1 AND quarantine = FALSE",
						profile_id,
					)
					if dec_total == 0:
						async with _greet_async_lock:
							ob_last = _onboarding_greeted.get(profile_id)
							if ob_last is None or (datetime.utcnow() - ob_last).total_seconds() >= _GREET_COOLDOWN_SECS:
								_onboarding_greeted[profile_id] = datetime.utcnow()
								_session_greeted.pop(profile_id, None)
						return (
							"👋 Welcome to Mnemo.\n\n"
							'Say "what are my open threads?" to see your getting-started checklist.\n'
						)

				for row in dec_rows:
					if len(urgent) >= 3:
						break
					ts = row["updated_at"] or row["created_at"]
					if ts:
						ts_naive = ts.replace(tzinfo=None) if getattr(ts, "tzinfo", None) else ts
						age = (datetime.utcnow() - ts_naive).days
						if age >= 7:
							imp = (row["importance"] or "").capitalize()
							urgent.append(f"{imp} decision — overdue {age}d")

				# 2. Unresolved contradictions older than 3 days
				if len(urgent) < 3:
					con_rows = await conn.fetch(
						"""
						SELECT created_at FROM personal_contradiction_log
						WHERE profile = $1 AND dismissed = FALSE
						  AND created_at < NOW() - INTERVAL '3 days'
						LIMIT 3
						""",
						profile_id,
					)
					for row in con_rows:
						if len(urgent) >= 3:
							break
						ts = row["created_at"]
						age = (datetime.utcnow() - ts.replace(tzinfo=None)).days if ts else 3
						urgent.append(f"Unresolved contradiction — {age}d old")

				# 3. Threads with 3+ recurrences
				if len(urgent) < 3:
					thr_rows = await conn.fetch(
						"""
						SELECT recurrence_count FROM personal_threads
						WHERE profile = $1
						  AND status NOT IN ('resolved','dismissed','dormant','abandoned')
						  AND recurrence_count >= 3
						  AND quarantine = FALSE
						ORDER BY recurrence_count DESC
						LIMIT 3
						""",
						profile_id,
					)
					for row in thr_rows:
						if len(urgent) >= 3:
							break
						urgent.append(f"Recurring thread — {row['recurrence_count']}x unresolved")

	except Exception as exc:
		logger.warning("[greet-async] %s: %s", profile_id, exc, exc_info=True)
		async with _greet_async_lock:
			_session_greeted.pop(profile_id, None)
		return None

	if not urgent:
		async with _greet_async_lock:
			_session_greeted.pop(profile_id, None)
		return None

	lines = "\n".join(f"• {item}" for item in urgent)
	return (
		f"⚡ Mnemo — {len(urgent)} item(s) need your attention:\n"
		f"{lines}\n"
		'(Reply "show decisions" or "show threads" to review)\n'
	)


def _maybe_surface_related(profile_id: str, content: str, pool: Any = None, project: str = "") -> Optional[str]:
	"""Return contextual note about highest-overlap open thread, else None.

	Computes keyword overlap (>=2 significant non-stop-word terms) between
	`content` and each open thread title.  Returns a note for the best match only.
	Silent — no noise when nothing is relevant.

	Project scoping: only threads whose linked_project_id matches `project` are
	considered.  When `project` is empty, only unscoped threads (no linked_project_id)
	are considered — this prevents cross-project false positives.
	"""
	if not profile_id or not content:
		return None

	def _keywords(text: str) -> set[str]:
		words: set[str] = set()
		for w in text.lower().split():
			clean = "".join(c for c in w if c.isalnum())
			if clean and clean not in _SURFACE_STOP_WORDS and len(clean) >= 3:
				words.add(clean)
		return words

	content_keywords = _keywords(content)
	if not content_keywords:
		return None

	canonical_project = str(project or "").strip().lower()
	try:
		params: dict = {"status": "open", "limit": 50}
		if canonical_project:
			params["project"] = canonical_project
		qs = urllib.parse.urlencode(params)
		result = _api_call("GET", f"{_profile_path('/threads')}?{qs}")
		threads_list = result if isinstance(result, list) else (result.get("threads", []) if isinstance(result, dict) else [])
	except Exception:
		return None

	# When no project on the decision, exclude threads that belong to any named project
	# — prevents cross-project noise. When a project is set, server already filtered,
	# but guard client-side too in case the backend returns mixed results.
	scoped: list[dict] = []
	for t in threads_list:
		t_project = str(t.get("linked_project_id") or "").strip().lower()
		if canonical_project:
			if t_project == canonical_project:
				scoped.append(t)
		else:
			if not t_project:
				scoped.append(t)

	best_match: Optional[dict] = None
	best_overlap: int = 0

	for t in scoped:
		title = str(t.get("title") or "")
		t_keywords = _keywords(title)
		overlap = len(content_keywords & t_keywords)
		if overlap >= 2 and overlap > best_overlap:
			best_overlap = overlap
			best_match = t

	if best_match is None:
		return None

	title = str(best_match.get("title") or "")
	age_days: int = 0
	ts_str = str(best_match.get("created_at") or best_match.get("last_mentioned") or "")
	if ts_str:
		try:
			ts = datetime.fromisoformat(ts_str[:19])
			age_days = (datetime.utcnow() - ts).days
		except Exception:
			age_days = 0

	return (
		f'\n📎 Related open thread: "{title}" (opened {age_days}d ago, unresolved)\n'
		f"   — worth linking or closing if this decision addresses it."
	)


# ── Unit E: Privacy Mode session init ─────────────────────────────────────────

async def _maybe_prepend_brief(profile: str, response: dict) -> dict:
	"""Inject morning brief into first MCP response of the day, for all tiers.

	Uses in-process dicts (_brief_delivered, _profile_tier_cache) instead of
	Redis — Redis has a 30 req/sec limit and was historically flaky.
	Process-restart delivers the brief again (once per restart), which is
	acceptable for a single-user Cloud Run instance.

	For Tier 3: silently skip when tier is confirmed from cache or DB.
	All exceptions are swallowed — never block the actual tool response.
	"""
	if not profile:
		return response

	from datetime import date as _date
	today = _date.today()

	# Atomic check-and-claim under _pending_cache_lock to prevent a TOCTOU race
	# where two concurrent requests for the same profile both pass the
	# _brief_delivered check and both generate+persist a duplicate brief entry.
	with _pending_cache_lock:
		if _brief_delivered.get(profile) == today:
			return response
		# Claim delivery slot now — set to today so any concurrent request that
		# acquires the lock next will skip. Cleared back to None in the except
		# block if brief generation ultimately fails, so future calls can retry.
		_brief_delivered[profile] = today

	try:
		import backend.tasks.morning_brief as _brief_mod

		# Tier-3 guard: resolve tier from cache with 60s TTL.
		# Without a TTL, a Tier-1→Tier-3 upgrade goes undetected for the process
		# lifetime (hours), causing plaintext MCP-channel briefs to leak.
		# Fail closed on lookup error: if we can't confirm the tier we must not
		# send a brief that may be confidential — release the slot and return.
		import time as _time_mod
		import backend.db as _db
		_cached = _profile_tier_cache.get(profile)
		_tier_stale = _cached is None or (_time_mod.monotonic() - _cached[1]) > _TIER_CACHE_TTL_S
		if _tier_stale:
			try:
				_tier_val = await _db.get_profile_tier(profile)
				_profile_tier_cache[profile] = (_tier_val, _time_mod.monotonic())
			except Exception:
				# Cannot confirm tier — fail closed: release slot, skip brief.
				with _pending_cache_lock:
					_brief_delivered.pop(profile, None)
				return response
		_tier = _profile_tier_cache[profile][0]
		if _tier == 3:
			# Tier-3 brief requires an active portal session — release the
			# delivery slot so it can be re-attempted after a tier downgrade.
			with _pending_cache_lock:
				_brief_delivered.pop(profile, None)
			return response

		# Fully awaitable: cancellation from wait_for propagates through this await.
		# generate_morning_brief still runs in a bounded 1-worker executor inside
		# run_morning_brief_for_profile_async — see morning_brief.py for details.
		brief = await _brief_mod.run_morning_brief_for_profile_async(profile)
		if brief is not None:
			response["_morning_brief"] = brief
		else:
			# Brief generation failed — release slot so tomorrow's call can retry.
			with _pending_cache_lock:
				_brief_delivered.pop(profile, None)
	except Exception:
		# Release delivery slot on any unexpected error so the next day's call
		# is not permanently suppressed.
		with _pending_cache_lock:
			_brief_delivered.pop(profile, None)

	return response


GATED_MCP_TOOLS: dict[str, str] = {
	"group_decisions":             "di_clusters",
	"get_decision_correlations":   "di_correlations",
	"detect_conflicts":            "di_conflicts",
	# get_decision_lineage is now an MVP endpoint — not gated
	"get_calibration":             "di_calibration",
	"get_decision_contradictions": "di_conflicts",
	"get_project_room":            "project_rooms",
	"get_whisper":                 "whisper_channel",
}

# Startup invariant: every value in GATED_MCP_TOOLS must be a known feature key.
# Catch mismatches at import time — a ValueError at runtime is far worse.
if _FEATURE_GATES_AVAILABLE and _FEATURE_GATES:
	_unknown_gate_keys = [v for v in GATED_MCP_TOOLS.values() if v not in _FEATURE_GATES]
	if _unknown_gate_keys:
		raise RuntimeError(
			f"GATED_MCP_TOOLS references unknown feature keys: {_unknown_gate_keys}. "
			"Fix the key in GATED_MCP_TOOLS or add it to FEATURE_GATES."
		)


def _gate_mcp_tool(tool_name: str, principal: dict) -> dict | None:
	"""Return error envelope if gated, else None.

	Only gates tools in GATED_MCP_TOOLS; all others pass through unchanged.
	"""
	feature_key = GATED_MCP_TOOLS.get(tool_name)
	if not feature_key:
		return None
	if not _FEATURE_GATES_AVAILABLE or _check_feature is None:
		return {
			"error": "feature_gate_unavailable",
			"message": "Feature gate check is temporarily unavailable. Please try again.",
		}
	try:
		allowed = _check_feature(principal, feature_key)
	except ValueError as exc:
		logger.error("_gate_mcp_tool: unknown feature key %r: %s", feature_key, exc)
		return {
			"error": "feature_gate_misconfigured",
			"message": "Internal configuration error. This tool cannot be accessed right now.",
		}
	if not allowed:
		required = _FEATURE_GATES.get(feature_key, "pro")
		return {
			"error": "feature_gated",
			"required_tier": required,
			"message": f"This feature requires the {required} plan. Upgrade at /billing?upgrade={required}",
		}
	return None


# P1 refactor: handler bodies live in mnemo_mcp/tools/; import here to override
# the module-level definitions above so tests patch the right objects.
from mnemo_mcp.tools.decisions import (
    _handle_get_decisions, _handle_get_decision_clusters, _handle_search_decisions,
    _handle_get_decision_precedent, _handle_list_decision_domains,
    _handle_get_decision_lineage, _handle_register_decision_reference,
    _handle_get_entities, _handle_log_decision, _handle_log_decisions, _handle_annotate_decision_outcome,
    _handle_get_adversary_annotation, _handle_get_calibration,
    _handle_get_stale_decisions, _handle_get_blocked_decisions,
    _handle_get_decisions_about_entity, _handle_entity_impact_map,
    _handle_score_decision_outcome, _handle_log_decision_options,
    _handle_get_decision_contradictions,
    _handle_log_assumption, _handle_get_assumptions_at_risk,
    _handle_get_decision_velocity,
    _handle_purge_records, _handle_cancel_draft_decision,
    _handle_get_pending_assumptions, _handle_confirm_pending_assumption,
    _handle_dismiss_pending_assumption,
    _handle_log_assumptions, _handle_confirm_pending_assumptions, _handle_dismiss_pending_assumptions,
)
from mnemo_mcp.tools.memory import (
    _handle_search_memory, _handle_log_session, _handle_wrap_session,
    _handle_log_execution_event, _handle_mnemo_session_init,
)
from mnemo_mcp.tools.threads import (
    _handle_thread_action, _handle_annotate_outcome,
    _handle_get_open_threads, _handle_open_thread, _handle_open_threads,
    _handle_annotate_thread_outcome, _handle_escalate_thread, _handle_escalate_threads,
    _handle_get_overdue_threads,
)
from mnemo_mcp.tools.brief import (
    _handle_get_morning_brief, _handle_get_recent_changes,
    _handle_get_session_handoff_brief,
)
from mnemo_mcp.tools.projects import (
    _handle_list_projects, _handle_create_project,
    _handle_close_project, _handle_get_project_context,
    _handle_set_project_boundary, _handle_get_project_boundary,
    _handle_set_dedup_window,
    _handle_grant_cross_project_visibility, _handle_revoke_cross_project_visibility,
)
from mnemo_mcp.tools.data import (
    _handle_submit_feedback, _handle_export_data, _handle_import_data,
)

def _make_deprecated_handler(old_name: str, new_name: str):
    """Return a handler that emits an error-prefixed deprecation hint.
    Error: prefix is intentional — write callers must not treat this as a success signal."""
    def _handler(args):
        return (
            f"Error: `{old_name}` is deprecated and will be removed in the next release. "
            f"Use `{new_name}` instead."
        )
    return _handler


def _handle_attestation_get_log(args: Dict[str, Any]) -> str:
	"""Return the attestation log for the current profile's session.

	T6: If the attestation backend is unavailable, returns structured error and
	schedules a background recheck so the flag self-heals on DB recovery.
	"""
	if not _ATTESTATION_BACKEND_AVAILABLE:
		_schedule_attestation_backend_recheck()
		return json.dumps({
			"error": "attestation_backend_unavailable",
			"detail": (
				"The attestation backend (audit_log) is currently unreachable. "
				"A reconnection attempt is in progress — please retry in a few moments."
			),
		})
	from mcp_attest.handler import handle_get_log
	try:
		profile = _active_profile()
	except RuntimeError:
		profile = args.get("profile", "")
	log = _attestation.get(profile)
	if log is None:
		return json.dumps({"leaves": [], "count": 0, "session_id": profile})
	from_seq = args.get("from_seq")
	to_seq = args.get("to_seq")
	result = handle_get_log(
		log,
		{"from_sequence": from_seq, "to_sequence": to_seq},
		profile,
	)
	result["count"] = len(result.get("leaves", []))
	return json.dumps(result)


# ── mnemo_help: onboarding + usage guidance ──────────────────────────────────

_HELP_QUICKSTART = """\
**5 things to do in your first session with Mnemo:**

1. **Have a real conversation** — work on something actual. Mnemo indexes content, not test messages.
2. **Search your past** — ask: "what did I decide about X?" or "what did we discuss re: Y?"
3. **Log a decision** — say: "log decision: we chose React over Vue because of team familiarity"
4. **Get your brief** — ask: "get my morning brief" to see what Mnemo has surfaced
5. **Check open threads** — ask: "what are my open threads?" to see unresolved questions Mnemo is tracking

Each of these takes under 30 seconds. Do all five and you'll understand what Mnemo is.\
"""

_HELP_DECISIONS = """\
**Getting the most from decisions:**

- Log decisions as they happen: "log decision: we're going with Postgres over MySQL — better JSON support"
- Add a rationale — Mnemo uses it when checking for contradictions
- Set `importance: high` or `critical` for decisions you'll want to review later
- Use `get_decision_lineage` to see what a decision depends on or supersedes
- Use `score_decision_outcome` after a decision plays out — this improves your calibration score
- Use `get_decisions` filtered by domain or project to see a focused view

**Shortcut:** prefix any statement with "Important:" or say "we will X" and Mnemo logs it automatically.\
"""

_HELP_THREADS = """\
**Getting the most from threads:**

- Threads are unresolved questions or pending actions. Mnemo opens them automatically.
- Use `list_threads` to see what's been open longest
- Use `escalate_thread` when something is genuinely blocking
- Use `annotate_outcome` with `type='thread'` to close or defer a thread
- Threads that stay open for weeks surface in your morning brief as overdue

**Tip:** when you wrap a session, Mnemo automatically checks for threads that can be resolved based on what happened.\
"""

_HELP_MEMORY = """\
**Getting the most from memory:**

- `search_memory` is semantic — ask in plain language: "what did we decide about auth?"
- Memory spans all your sessions and all tools connected to Mnemo
- `get_recent_changes` shows you what was indexed and when — useful after a long break
- `index_session_fragment` lets you manually save a chunk of context mid-session
- `resume_session` gives you a structured handoff brief to start a new session with full context

**Tip:** the more specific your search query, the better the results. "auth token expiry decision" beats "auth".\
"""

_HELP_BRIEF = """\
**Getting the most from your morning brief:**

- Call `get_morning_brief` at the start of any session — it surfaces what's urgent, overdue, and next
- The brief adapts: new users see onboarding nudges; active users see decision debt and thread overdue alerts
- Announcements from your team or enterprise admin appear at the top
- `get_overdue_threads` gives the same data in a flat list if you want to triage directly

**Tip:** use the brief to decide what to work on — then use `get_project_context` to deep-dive into the chosen project.\
"""

_HELP_ADVANCED = """\
**Power-user patterns:**

**Projects** — scope all decisions, sessions, and threads to a project slug. `get_project_context` returns everything at once.

**Assumptions** — after logging a decision, call `log_assumption` to record the premises it depends on. `get_assumptions_at_risk` surfaces these before review dates.

**Calibration** — call `get_calibration` to see how accurate your past confidence scores were. Adjust your confidence level over time.

**Adversary** — `get_adversary_annotation` shows the autonomous stress-test result for any high-importance decision.

**Velocity** — `get_decision_velocity` shows your decision-making pace and reversibility ratio over time.

**Contradictions** — `get_decision_contradictions` finds decisions that conflict with each other within a domain.\
"""

_HELP_TOPIC_MAP: dict[str, str] = {
	"quickstart": _HELP_QUICKSTART,
	"decisions": _HELP_DECISIONS,
	"threads": _HELP_THREADS,
	"memory": _HELP_MEMORY,
	"brief": _HELP_BRIEF,
	"advanced": _HELP_ADVANCED,
}

_HELP_INDEX = """\
**Mnemo help topics** — ask for any by name:

- `quickstart` — 5 things to do in your first session
- `decisions` — logging, rationale, calibration, shortcuts
- `threads` — tracking unresolved questions and actions
- `memory` — search, recent changes, session handoff
- `brief` — morning brief, nudges, overdue alerts
- `advanced` — projects, assumptions, velocity, contradictions

Example: call mnemo_help with topic="decisions"\
"""


def _handle_mnemo_help(args: Dict[str, Any]) -> str:
	topic = str(args.get("topic") or "").strip().lower()
	if len(topic) > 64:
		topic = ""
	_record_mcp_usage("mnemo_help")
	return _HELP_TOPIC_MAP.get(topic, _HELP_INDEX)


_TOOL_HANDLERS = {
    "search_memory": _handle_search_memory,
    # thread_action split into three focused tools
    "list_threads": _handle_get_open_threads,
    "escalate_thread": _handle_escalate_thread,
    "escalate_threads": _handle_escalate_threads,
    "get_overdue_threads": _handle_get_overdue_threads,
    "get_decisions": _handle_get_decisions,
    # renamed: get_decision_clusters → group_decisions
    "group_decisions": _handle_get_decision_clusters,
    "search_decisions": _handle_search_decisions,
    "get_decision_precedent": _handle_get_decision_precedent,
    "get_decision_lineage": _handle_get_decision_lineage,
    # renamed: get_entities → search_entities
    "search_entities": _handle_get_entities,
    "get_morning_brief": _handle_get_morning_brief,
    # renamed: log_session → index_session_fragment
    "index_session_fragment": _handle_log_session,
    "log_decisions": _handle_log_decisions,
    "log_decision": _handle_log_decision,
    "wrap_session": _handle_wrap_session,
    "annotate_outcome": _handle_annotate_outcome,
    "score_decision_outcome": _handle_score_decision_outcome,
    "log_decision_options": _handle_log_decision_options,
    "get_decision_contradictions": _handle_get_decision_contradictions,
    "log_assumption": _handle_log_assumption,
    "log_assumptions": _handle_log_assumptions,
    "get_assumptions_at_risk": _handle_get_assumptions_at_risk,
    "get_pending_assumptions": _handle_get_pending_assumptions,
    "confirm_pending_assumption": _handle_confirm_pending_assumption,
    "confirm_pending_assumptions": _handle_confirm_pending_assumptions,
    "dismiss_pending_assumption": _handle_dismiss_pending_assumption,
    "dismiss_pending_assumptions": _handle_dismiss_pending_assumptions,
    "get_decision_velocity": _handle_get_decision_velocity,
    "purge_records": _handle_purge_records,
    "cancel_draft_decision": _handle_cancel_draft_decision,
    "list_projects": _handle_list_projects,
    "create_project": _handle_create_project,
    # deprecated aliases
    "close_project": _make_deprecated_handler("close_project", "annotate_outcome(type='project', id='<slug>', outcome_status='archived')"),
    "log_execution_event": _make_deprecated_handler("log_execution_event", "annotate_outcome(type='decision', outcome_status='resolved', event_type=...)"),
    "get_project_context": _handle_get_project_context,
    "set_project_boundary": _handle_set_project_boundary,
    "get_project_boundary": _handle_get_project_boundary,
    "set_dedup_window": _handle_set_dedup_window,
    "grant_cross_project_visibility": _handle_grant_cross_project_visibility,
    "revoke_cross_project_visibility": _handle_revoke_cross_project_visibility,
    "get_recent_changes": _handle_get_recent_changes,
    "get_calibration": _handle_get_calibration,
    "get_adversary_annotation": _handle_get_adversary_annotation,
    # renamed: get_session_handoff_brief → resume_session
    "resume_session": _handle_get_session_handoff_brief,
    # renamed: mnemo_session_init → init_private_session
    "init_private_session": _handle_mnemo_session_init,
    # deprecated aliases — return deprecation hint for 1 release
    "get_decision_clusters": _make_deprecated_handler("get_decision_clusters", "group_decisions"),
    "get_entities": _make_deprecated_handler("get_entities", "search_entities"),
    "log_session": _make_deprecated_handler("log_session", "index_session_fragment"),
    "get_session_handoff_brief": _make_deprecated_handler("get_session_handoff_brief", "resume_session"),
    "mnemo_session_init": _make_deprecated_handler("mnemo_session_init", "init_private_session"),
    "thread_action": _make_deprecated_handler(
        "thread_action",
        "list_threads / escalate_thread / get_overdue_threads",
    ),
    # internal helpers kept for delegation — not in MNEMO_TOOLS
    "list_decision_domains": _handle_list_decision_domains,
    "register_decision_reference": _handle_register_decision_reference,
    "get_open_threads": _handle_get_open_threads,
    "get_stale_decisions": _handle_get_stale_decisions,
    "get_blocked_decisions": _handle_get_blocked_decisions,
    "annotate_decision_outcome": _handle_annotate_decision_outcome,
    "open_thread": _handle_open_thread,
    "open_threads": _handle_open_threads,
    "annotate_thread_outcome": _handle_annotate_thread_outcome,
    "get_decisions_about_entity": _handle_get_decisions_about_entity,
    "entity_impact_map": _handle_entity_impact_map,
    "submit_feedback": _handle_submit_feedback,
    "export_data": _handle_export_data,
    "import_data": _handle_import_data,
    "attestation_get_log": _handle_attestation_get_log,
    "mnemo_help": _handle_mnemo_help,
    # W3.1: org/team lifecycle handlers
    **_ORG_TOOL_HANDLERS,
}

# H-35: public allowlist derived from MNEMO_TOOLS. The _TOOL_HANDLERS dict
# also contains internal helpers (e.g. get_open_threads, annotate_decision_outcome)
# used for delegation between handlers; those must not be callable via MCP.
PUBLIC_TOOL_NAMES: set[str] = {t["name"] for t in MNEMO_TOOLS}

# Deprecated aliases: callable for 1 release, return a migration hint.
# Must be in the callable set so call_tool() routes through before returning "Unknown tool".
DEPRECATED_TOOL_NAMES: set[str] = {
    "get_decision_clusters",  # → group_decisions
    "get_entities",           # → search_entities
    "log_session",            # → index_session_fragment
    "get_session_handoff_brief",  # → resume_session
    "mnemo_session_init",     # → init_private_session
    # Phase 2 deprecations
    "close_project",          # → annotate_outcome(type="project", ...)
    "log_execution_event",    # → annotate_outcome(type="decision", event_type=...)
    # Phase 3 deprecations
    "thread_action",          # → list_threads / escalate_thread / get_overdue_threads
}


def _is_public_tool(name: str) -> bool:
    return name in PUBLIC_TOOL_NAMES or name in DEPRECATED_TOOL_NAMES


def _tool_error_response(tool_name: str, exc: BaseException) -> str:
    """C-04: Return a safe, generic error payload to MCP callers.

    The caller only sees the exception class name and a request_id. Full
    exception detail is logged server-side via caller's `exc_info=True`.
    """
    req_id = _uuid_mod.uuid4().hex[:12]
    payload = {
        "error": type(exc).__name__,
        "request_id": req_id,
        "tool": tool_name,
    }
    logger.error(
        "[mnemo-mcp] tool %s failed request_id=%s: %s",
        tool_name, req_id, exc, exc_info=True,
    )
    return json.dumps(payload)


# Fields injected by the auth layer — never user-supplied, never scanned.
_PI_SKIP_FIELDS = {"profile", "user_id", "org_id", "org_tier", "user_tier", "api_url", "token"}

# _REJECTION_RESPONSE does not include the field name — exposing it maps the scan
# surface to the caller and enables targeted bypass of skipped fields.
_PI_REJECTION_RESPONSE = json.dumps({
	"error": "injection_detected",
	"message": "Input contains disallowed patterns and was rejected.",
})


def _scan_write_args(tool_name: str, arguments: Dict[str, Any]) -> tuple[Dict[str, Any] | None, str | None]:
	"""Scan string arguments of a write tool for prompt-injection patterns.

	Returns (sanitized_args, None) on clean input.
	Returns (None, error_json) on detection — caller must hard-reject.
	Recursively scans list and dict values so nested user text is covered.
	Fails open on ImportError (pip-package mode); fails closed on any other exception.
	"""
	if tool_name not in _WRITE_TOOLS:
		return arguments, None
	try:
		from backend.security import scan_for_injection, InjectionDetected, _sanitize_for_prompt
	except ImportError:
		return arguments, None  # pip-package mode — no backend available

	def _scan_value(value: Any, top_key: str) -> Any:
		"""Recursively scan a value. Raises InjectionDetected on detection."""
		if isinstance(value, str):
			if not value:
				return value
			return scan_for_injection(_sanitize_for_prompt(value), top_key)
		if isinstance(value, list):
			return [_scan_value(item, top_key) for item in value]
		if isinstance(value, dict):
			return {k: _scan_value(v, top_key) for k, v in value.items()}
		return value

	try:
		sanitized: Dict[str, Any] = {}
		for key, value in arguments.items():
			if key in _PI_SKIP_FIELDS:
				sanitized[key] = value
				continue
			sanitized[key] = _scan_value(value, key)
		return sanitized, None
	except Exception as exc:
		_is_injection = type(exc).__name__ == "InjectionDetected"
		field = getattr(exc, "field", "unknown") if _is_injection else "unknown"
		if _is_injection:
			logger.warning("[pi-gate] injection_detected tool=%s field=%s", tool_name, field)
		else:
			logger.error("[pi-gate] scan_error tool=%s exc=%s", tool_name, exc, exc_info=True)
		return None, _PI_REJECTION_RESPONSE


_WRITE_TOOLS = {
    "index_session_fragment",
    "log_decisions",
    "log_decision",
    "open_thread",
    "wrap_session",
    "annotate_outcome",
    # log_execution_event removed — absorbed into annotate_outcome (Phase 2)
    "import_data",
    "escalate_thread",
    "score_decision_outcome",
    "log_decision_options",
    "log_assumption",
    "purge_records",
    "cancel_draft_decision",
    "create_project",
    "submit_feedback",
    # SECURITY FIX MCP-WT: these 3 were missing — read-only token could call write tools
    "confirm_pending_assumption",
    "dismiss_pending_assumption",
    "init_private_session",
    # Brief cache eviction: these mutate decisions/threads and must evict cached briefs
    "annotate_decision_outcome",
    "annotate_thread_outcome",
    "thread_action",
    # W3.1: org/team lifecycle write tools
    *_ORG_WRITE_TOOLS,
}

# CoSAI T3/T4: read tools whose user-supplied query arguments are scanned for
# injection patterns.  These fields come directly from the LLM/client — if the
# LLM was compromised by a stored payload, its query may carry the injection.
# Hard-reject (same as write tools) so a poisoned LLM cannot use the read path
# to exfiltrate or amplify.
_READ_TOOL_SCAN_ARGS: Dict[str, frozenset] = {
    "search_memory":    frozenset({"query"}),
    "search_decisions": frozenset({"query", "topic"}),
    "search_entities":  frozenset({"query"}),
    "list_threads":     frozenset({"filter"}),
    "get_decisions":    frozenset({"query", "topic"}),
    "resume_session":   frozenset({"context"}),
}


def _scan_read_args(tool_name: str, arguments: Dict[str, Any]) -> tuple[Dict[str, Any] | None, str | None]:
    """Scan user-supplied string args of read tools for injection patterns.

    Only scans fields listed in _READ_TOOL_SCAN_ARGS — server-injected keys
    (profile, org_id, etc.) are never scanned.  Returns (arguments, None) on
    clean input or when the tool has no registered scan fields.
    Returns (None, error_json) on detection — caller must hard-reject.
    """
    scan_fields = _READ_TOOL_SCAN_ARGS.get(tool_name)
    if not scan_fields:
        return arguments, None
    try:
        from backend.security import scan_for_injection, InjectionDetected, _sanitize_for_prompt
    except ImportError:
        return arguments, None  # pip-package mode — no backend available

    try:
        for key, value in arguments.items():
            if key not in scan_fields:
                continue
            if isinstance(value, str) and value:
                scan_for_injection(_sanitize_for_prompt(value), key)
        return arguments, None
    except Exception as exc:
        _is_injection = type(exc).__name__ == "InjectionDetected"
        field = getattr(exc, "field", "unknown") if _is_injection else "unknown"
        if _is_injection:
            logger.warning("[pi-gate] read_injection_detected tool=%s field=%s", tool_name, field)
        else:
            logger.error("[pi-gate] read_scan_error tool=%s exc=%s", tool_name, exc, exc_info=True)
        return None, _PI_REJECTION_RESPONSE

# Tools that carry user-authored text worth semantic-scanning after successful dispatch.
# Maps tool_name → (db_table, call_arguments_field_with_primary_text).
# Table must be in _TABLE_PK for quarantine UPDATE; others still log injection events
# and trigger write throttle.
_SEMANTIC_SCAN_TOOLS: Dict[str, tuple[str, str]] = {
    "log_decisions":         ("personal_decisions", "content"),
    "log_decision":          ("personal_decisions", "content"),
    "index_session_fragment": ("personal_sessions",  "output"),
    "open_thread":           ("personal_threads",   "title"),
    "wrap_session":          ("personal_sessions",  "output"),
    "log_assumption":        ("personal_decisions", "assumption"),
    "escalate_thread":       ("personal_threads",   "title"),
    "create_project":        ("personal_decisions", "name"),
    "submit_feedback":       ("personal_decisions", "message"),
}


# CoSAI T4: read tools whose output must NOT be wrapped in <retrieved_data>.
# These are system integrity outputs — wrapping them as user data would confuse
# the host LLM's integrity checks and open a confused-deputy channel.
_NO_FRAME_TOOLS: frozenset = frozenset({
    "attestation_get_log",
})


def _required_scopes_for_tool(tool_name: str) -> tuple[str, ...]:
    if tool_name in _WRITE_TOOLS:
        return ("mnemo.write",)
    # Read tools accept either explicit read scope or write scope.
    return ("mnemo.read", "mnemo.write")


def _scope_error_for_tool(tool_name: str, granted_scopes: set[str]) -> str | None:
    required_scopes = _required_scopes_for_tool(tool_name)
    if any(scope in granted_scopes for scope in required_scopes):
        return None
    return (
        "Insufficient MCP token scope.\n"
        f"Tool `{tool_name}` requires one of: {', '.join(required_scopes)}.\n"
        f"Granted: {', '.join(sorted(granted_scopes)) or '(none)'}."
    )


def _claim_prefetch_slot(pre_profile: str, pre_token: str) -> bool:
	"""Return True if a background prefetch should be launched for *pre_profile*.

	Returns False (and discards the in-flight claim) when *pre_token* is falsy —
	prevents scheduling _background_prefetch without an auth token, which would
	produce silent 401s on all background API calls (RCA 2026-04-22, Fix C).
	Must be called only after _pre_profile has been added to _prefetch_in_flight.
	"""
	if not pre_token:
		logger.error(
			"[prefetch] _pre_token empty at call_tool boundary — "
			"skipping _maybe_greet to prevent unauthenticated API calls"
		)
		with _pending_cache_lock:
			_prefetch_in_flight.discard(pre_profile)
		return False
	return True


# ── MCP server builder ────────────────────────────────────────────────────────

def build_mcp_server() -> "Server":
    if not _MCP_AVAILABLE:
        raise RuntimeError("mcp package not installed. Run: pip install mnemo-meridian-mcp")

    server = Server("mnemo-platform")

    @server.list_tools()
    async def list_tools():
        tools = []
        for t in MNEMO_TOOLS:
            ann_data = _TOOL_ANNOTATIONS.get(t["name"])
            tools.append(Tool(
                name=t["name"],
                description=t["description"],
                inputSchema=t["inputSchema"],
                annotations=ToolAnnotations(**ann_data) if ann_data else None,
            ))
        return tools

    @server.call_tool()
    async def call_tool(name: str, arguments: Dict[str, Any]):
        # H-35: gate dispatch on the public allowlist so internal helpers
        # registered only for delegation cannot be invoked by MCP clients.
        if not _is_public_tool(name):
            raise McpError(_ErrorData(code=_MCP_METHOD_NOT_FOUND, message=f"Unknown tool: {name}"))
        handler = _TOOL_HANDLERS.get(name)
        if handler is None:
            raise McpError(_ErrorData(code=_MCP_METHOD_NOT_FOUND, message=f"Unknown tool: {name}"))

        # S3: read progressToken from request context (MCP 2025-11-25 spec).
        # Never read from arguments["_meta"] — that is a client-supplied payload key,
        # not the transport-level metadata field.
        try:
            _ctx = server.request_context
            _ctx_meta = _ctx.meta
        except LookupError:
            _ctx = None
            _ctx_meta = None
        progress_token = _ctx_meta.progressToken if _ctx_meta is not None else None
        logger.debug("[mnemo-mcp] progressToken present: %s", progress_token is not None)

        # Validate before any work begins.  Reject non-string/int types and large tokens.
        if progress_token is not None:
            if not isinstance(progress_token, (str, int)):
                raise McpError(_ErrorData(code=_MCP_INVALID_PARAMS, message="progressToken must be a string or integer"))
            if len(str(progress_token)) > 256:
                raise McpError(_ErrorData(code=_MCP_INVALID_PARAMS, message="progressToken must be ≤ 256 chars"))

        access_token = _current_access_token()
        call_arguments: Dict[str, Any] = dict(arguments or {})

        if access_token is not None:
            raw_token = str(getattr(access_token, "token", "") or "").strip()
            profile_hint = str(getattr(access_token, "client_id", "") or "").strip().lower()
            token_label = str(getattr(access_token, "resource", "") or "").strip().lower()
            granted_scopes = {
                str(scope).strip().lower()
                for scope in (getattr(access_token, "scopes", []) or [])
                if str(scope).strip()
            }
            scope_error = _scope_error_for_tool(name, granted_scopes)
            if scope_error:
                return [TextContent(type="text", text=scope_error)]
            logger.info("[MCP call_tool] access_token found - identity: %s, profile: %s",
                       bool(raw_token) and raw_token[:20], profile_hint)
            # HTTP transport: _mcp_api_token_hint_middleware already set the raw bearer
            # in _MCP_API_TOKEN_HINT.  access_token.token is the DB identity, not the
            # bearer — do NOT overwrite the hint with it.  Save a reset token so the
            # finally block can restore the previous value if needed.
            token_ctx = _MCP_API_TOKEN_HINT.set(_MCP_API_TOKEN_HINT.get(""))
            if profile_hint:
                # Always overwrite — the token-derived profile_hint is authoritative.
                # Using setdefault would allow a client-supplied profile to win.
                call_arguments["profile"] = profile_hint
            client_ctx = set_mcp_client_hint(token_label or "http")
        else:
            if not _API_TOKEN:
                return [TextContent(type="text", text=(
                    "Mnemo MCP: no API token configured.\n"
                    "Set MNEMO_API_TOKEN or create ~/.mnemo/mcp_token.\n"
                    "Get your token: Mnemo → Settings → Connect to Claude Desktop."
                ))]
            token_ctx = set_mcp_api_token_hint(_API_TOKEN)
            try:
                _active_profile()
            except RuntimeError as exc:
                reset_mcp_api_token_hint(token_ctx)
                return [TextContent(type="text", text=f"Mnemo MCP: {exc}")]
            client_ctx = set_mcp_client_hint(_CLIENT_HINT)
            if _PROFILE:
                # Always overwrite with the env-configured profile.
                call_arguments["profile"] = _PROFILE

        # Feature gate check: derive principal entirely from the auth context.
        # CoSAI T02: never accept client-supplied user_tier, org_id, or org_tier —
        # those can be spoofed to bypass tier gates. user_id comes from the token-derived
        # profile, not from tool arguments. The router layer enforces the same gates via
        # require_principal for direct HTTP callers; this covers the MCP transport path.
        try:
            _gate_user_id = _active_profile()
        except RuntimeError:
            _gate_user_id = None
        _user_tier = ""
        try:
            from backend.routers.mcp_http import get_mcp_token_tier
            _at = _current_access_token()
            if _at is not None:
                _user_tier = get_mcp_token_tier(_at.token)
        except Exception:
            pass  # standalone pip-package mode: no backend module available
        if not _user_tier:
            _user_tier = "free"

        _mcp_principal = {
            "user_id": _gate_user_id,
            "user_tier": _user_tier,
            "org_id": None,
            "org_tier": None,
        }
        _gate_result = _gate_mcp_tool(name, _mcp_principal)
        if _gate_result is not None:
            import json as _json
            reset_mcp_api_token_hint(token_ctx)
            reset_mcp_client_hint(client_ctx)
            return [TextContent(type="text", text=_json.dumps(_gate_result))]

        # Fix #32: Synchronous pre-call quota check before dispatching any tool.
        # Capture the resolved token and profile here (in the MCP handler thread)
        # and pass them explicitly so the check is always scoped to the correct tenant.
        _pre_token = _effective_api_token()
        try:
            _pre_profile = _active_profile()
        except RuntimeError:
            _pre_profile = ""

        try:
            await asyncio.to_thread(_check_quota_sync, _pre_token, _pre_profile)
        except QuotaExceededError as qe:
            reset_mcp_api_token_hint(token_ctx)
            reset_mcp_client_hint(client_ctx)
            return [TextContent(type="text", text=(
                f"Mnemo quota exceeded: {qe.used}/{qe.limit} MCP calls used this month.\n"
                f"Upgrade at {_API_URL.rstrip('/')}/settings#upgrade to continue."
            ))]

        # T10: Loop detection and token cost cap (in-memory, per-replica).
        if _pre_profile:
            if _check_cost_cap(_pre_profile):
                reset_mcp_api_token_hint(token_ctx)
                reset_mcp_client_hint(client_ctx)
                logger.warning("[T10] cost_cap_exceeded profile=%s tool=%s", _pre_profile[:20], name)
                return [TextContent(type="text", text=json.dumps({
                    "error": "cost_cap_exceeded",
                    "detail": "Token cost cap exceeded (500k tokens/hour). Please wait before making more calls.",
                }))]
            if _detect_loop(_pre_profile, name):
                reset_mcp_api_token_hint(token_ctx)
                reset_mcp_client_hint(client_ctx)
                logger.warning("[T10] loop_detected profile=%s tool=%s", _pre_profile[:20], name)
                return [TextContent(type="text", text=json.dumps({
                    "error": "loop_detected",
                    "detail": "Tool called too frequently — possible agent loop. Try a different approach.",
                }))]
            # Advisory scope drift check — synchronous, O(1), never raises
            _check_scope_drift(_pre_profile, name)
            _record_token_cost(_pre_profile, call_arguments)

        # PI-4: write throttle check — blocks write tools for flagged profiles
        if name in _WRITE_TOOLS and _pre_profile:
            try:
                from backend.db import get_write_throttle as _get_write_throttle
                import datetime as _dt
                _throttle_until = await _get_write_throttle(_pre_profile)
                if _throttle_until is not None:
                    _now = _dt.datetime.now(_dt.timezone.utc)
                    if hasattr(_throttle_until, 'tzinfo') and _throttle_until.tzinfo is None:
                        import pytz as _pytz
                        _throttle_until = _throttle_until.replace(tzinfo=_dt.timezone.utc)
                    if _throttle_until > _now:
                        reset_mcp_api_token_hint(token_ctx)
                        reset_mcp_client_hint(client_ctx)
                        return [TextContent(type="text", text=json.dumps({
                            "error": "write_access_restricted",
                            "message": "Write access temporarily restricted.",
                        }))]
            except Exception:
                pass  # fail open — throttle check must not block legitimate calls

        # PI-gate: hard-reject write-tool calls containing injection patterns.
        call_arguments, _pi_error = _scan_write_args(name, call_arguments)
        if _pi_error is not None:
            reset_mcp_api_token_hint(token_ctx)
            reset_mcp_client_hint(client_ctx)
            return [TextContent(type="text", text=_pi_error)]

        # CoSAI T3: hard-reject read-tool query args containing injection patterns.
        # Prevents a compromised LLM from using read paths to amplify stored injections.
        call_arguments, _pi_error = _scan_read_args(name, call_arguments)
        if _pi_error is not None:
            reset_mcp_api_token_hint(token_ctx)
            reset_mcp_client_hint(client_ctx)
            return [TextContent(type="text", text=_pi_error)]

        # RFC 12a: append tool_call_received leaf before dispatch (fail-closed).
        # profile is from the server auth context (_pre_profile), never from request params.
        _attest_call_id = f"call_{secrets.token_hex(8)}"
        _attest_client_request_id = _uuid_mod.uuid4().hex
        _attest_log = None
        # Server-injected keys (auth-derived) are stripped so the arguments_hash
        # reflects only what the client actually sent.
        _ATTEST_STRIP_KEYS = {"profile", "user_id", "org_id", "org_tier", "user_tier"}
        if _pre_profile and name != "attestation_get_log":
            try:
                _attest_log = _attestation.get_or_create(_pre_profile)
                _attest_args = {k: v for k, v in call_arguments.items() if k not in _ATTEST_STRIP_KEYS}
                _attest_log.append_tool_call_received(
                    _attest_call_id, name, _attest_args, _attest_client_request_id
                )
            except RuntimeError as _re:
                if "chain integrity" in str(_re):
                    logger.critical(
                        "[attestation] CHAIN TAMPER DETECTED profile=%s tool=%s — "
                        "session blocked: %s",
                        _pre_profile[:20], name, _re,
                    )
                    # Write tamper signal to a separate audit path (not the compromised chain)
                    try:
                        import backend.db as _bdb  # type: ignore[import]
                        _bdb.log_security_event(
                            event_type="chain_tamper_detected",
                            profile_id=_pre_profile,
                            detail=str(_re),
                        )
                    except Exception:
                        pass  # audit write must never mask the primary error response
                    return [TextContent(type="text", text=json.dumps({
                        "error": "AttestationIntegrityError",
                        "message": "Chain integrity violation detected. Session blocked.",
                    }))]
                logger.error("[attestation] attestation RuntimeError — aborting: %s", _re)
                return [TextContent(type="text", text=json.dumps({
                    "error": "AttestationError",
                    "message": "Failed to open attestation leaf; call aborted.",
                }))]
            except Exception as _ae:
                logger.error("[attestation] tool_call_received failed — aborting: %s", _ae)
                return [TextContent(type="text", text=json.dumps({
                    "error": "AttestationError",
                    "message": "Failed to open attestation leaf; call aborted.",
                }))]
        elif not _pre_profile:
            logger.debug("[attestation] skipping — no resolved profile (unauthenticated/stdio)")

        try:
            import time as _time
            _t0 = _time.monotonic()

            # Fix 3: brief content cache — return early on cache hit
            if name == "get_morning_brief" and _pre_profile:
                _cached_brief_hit = _brief_content_cache_get(_pre_profile)
                if _cached_brief_hit is not None:
                    logger.debug("[mnemo-mcp] brief cache HIT profile=%s", _pre_profile)
                    # CoSAI T5: scrub PII from cached brief before returning to LLM client.
                    try:
                        if _scrub_pii is not None:
                            _cached_brief_hit, _ = _scrub_pii(_cached_brief_hit)
                    except Exception:
                        pass  # fail open — PII scrub must not break tool responses
                    # CoSAI T4: frame cached brief same as dispatch path (get_morning_brief
                    # is a read tool — cache hit must not bypass the data boundary).
                    _safe_cached = (
                        _cached_brief_hit
                        .replace("</retrieved_data>", "&lt;/retrieved_data&gt;")
                        .replace("<retrieved_data>", "&lt;retrieved_data&gt;")
                    )
                    _framed_cached = f"<retrieved_data>\n{_safe_cached}\n</retrieved_data>"
                    return [TextContent(type="text", text=_framed_cached)]

            # Deferred greet/brief: results from previous call are cached in
            # _pending_greeting/_pending_brief and prepended here; the background
            # task for THIS call fires after we return.
            _greet_future = None  # unused; kept for test compat references

            # Wrap handler with _run_in_context to preserve context vars through threads.
            # asyncio.to_thread() alone may not preserve contextvars to nested thread pools.
            # Bug 1 fix: _api_semaphore caps concurrent calls to avoid stream closure
            # when multiple MCP tool calls race on urllib shared resources.
            wrapped_handler = lambda: _run_in_context(lambda: handler(call_arguments))

            # S9: Route slow tools through bounded executor to avoid starving fast tools.
            # asyncio.to_thread uses the default executor (40 workers); 8+ concurrent
            # slow calls would exhaust it.  _slow_executor caps slow-path concurrency at 4.
            # Relationship: _api_semaphore(8) caps total concurrent calls; _slow_executor(4)
            # reserves ≥4 slots for fast tools by capping slow-path occupancy.
            async def _dispatch_handler() -> Any:
                if name in _SLOW_TOOLS:
                    # Slow tools: gated by _slow_executor(4) only — no semaphore hold
                    # while waiting in the executor queue, so fast tools stay responsive.
                    # run_in_executor does NOT copy contextvars (unlike asyncio.to_thread).
                    # Capture context now (in the async coroutine) and pass it explicitly,
                    # mirroring what asyncio.to_thread does internally.
                    loop = asyncio.get_running_loop()
                    _ctx = contextvars.copy_context()
                    return await loop.run_in_executor(_slow_executor, _ctx.run, wrapped_handler)
                # Fast tools: acquire semaphore here, inside dispatch, not outside.
                async with _api_semaphore:
                    return await asyncio.to_thread(wrapped_handler)

            # Single dispatch coroutine — all three metrics branches funnel here so
            # attestation wrapping needs only one delivered-leaf site.
            async def _run_dispatch() -> tuple[Any, bool]:
                """Run the tool handler through the appropriate metrics path.

                Returns (result, is_error). Never raises — errors are returned as
                (error_text, True) so the attestation delivered leaf is always appended.
                """
                # Gen-2 metrics: wrap dispatch with timing context manager when available.
                # Fails open — if metrics backend is not importable, dispatch proceeds normally.
                if _METRICS_AVAILABLE and _track_mcp_call is not None:
                    try:
                        _profile_for_metrics = _pre_profile or ""
                        async with _track_mcp_call(
                            name,
                            _profile_for_metrics,
                            transport="http" if access_token is not None else "stdio",
                        ):
                            _r = await _dispatch_handler()
                        return (_r, False)
                    except Exception as _e:
                        logger.error("[mnemo-mcp] tool %s failed: %s", name, _e, exc_info=True)
                        return (_tool_error_response(name, _e), True)
                else:
                    if _metrics_env_enabled:
                        # Track B: time MCP tool dispatch when Gen-2 MetricsCollector is absent.
                        # Fails open — if operation_tracker is unavailable, dispatch proceeds.
                        try:
                            from backend.operation_tracker import track_operation, hash_profile as _hash_ph
                            _mcp_ph = _hash_ph(_pre_profile) if _pre_profile else None
                            async with track_operation("mcp_call", profile_hash=_mcp_ph, tool_name=name):
                                _r = await _dispatch_handler()
                            return (_r, False)
                        except ImportError:
                            try:
                                _r = await _dispatch_handler()
                                return (_r, False)
                            except Exception as _e:
                                logger.error("[mnemo-mcp] tool %s failed: %s", name, _e, exc_info=True)
                                return (_tool_error_response(name, _e), True)
                        except Exception as _e:
                            logger.error("[mnemo-mcp] tool %s failed: %s", name, _e, exc_info=True)
                            return (_tool_error_response(name, _e), True)
                    else:
                        # Metrics explicitly disabled (MNEMO_METRICS_ENABLED=false) — skip Track B.
                        try:
                            _r = await _dispatch_handler()
                            return (_r, False)
                        except Exception as _e:
                            logger.error("[mnemo-mcp] tool %s failed: %s", name, _e, exc_info=True)
                            return (_tool_error_response(name, _e), True)

            # S3: emit progress notifications for eligible tools when a token is present.
            # The SDK handles notifications/cancelled automatically; no custom code needed.
            if progress_token is not None and name in _PROGRESS_ELIGIBLE_TOOLS and _ctx is not None:
                try:
                    await _ctx.session.send_progress_notification(
                        progress_token=progress_token, progress=0.0, total=1.0,
                        message="Indexing fragment…",
                    )
                except Exception as _prog_exc:
                    logger.debug("[mnemo-mcp] progress start notify failed (ignored): %s", _prog_exc)

            result, _dispatch_is_error = await _run_dispatch()

            if progress_token is not None and name in _PROGRESS_ELIGIBLE_TOOLS and _ctx is not None:
                try:
                    await _ctx.session.send_progress_notification(
                        progress_token=progress_token, progress=1.0, total=1.0,
                        message="Done",
                    )
                except Exception as _prog_exc:
                    logger.debug("[mnemo-mcp] progress end notify failed (ignored): %s", _prog_exc)

            # T2-semantic: background semantic injection scan for write tools.
            # Fires async after dispatch — never blocks the response.
            # Catches novel phrasings that pass the regex gate (T1).
            # record_id parsed from result string; UUID fallback still logs injection
            # events and triggers write throttle even without a quarantine UPDATE.
            if not _dispatch_is_error and name in _SEMANTIC_SCAN_TOOLS and _pre_profile:
                try:
                    from backend.security import _dispatch_bg_scan as _pi_t2_dispatch
                    _t2_table, _t2_field = _SEMANTIC_SCAN_TOOLS[name]
                    _t2_content = str(call_arguments.get(_t2_field) or "").strip()[:500]
                    if _t2_content:
                        _t2_record_id = _uuid_mod.uuid4().hex
                        if isinstance(result, str):
                            _t2_m = re.search(r'[a-z]+_[a-zA-Z0-9]{6,}', result)
                            if _t2_m:
                                _t2_record_id = _t2_m.group(0)
                        _pi_t2_dispatch(
                            profile_id=_pre_profile,
                            record_id=_t2_record_id,
                            content=_t2_content,
                            table=_t2_table,
                            user_id=_pre_profile,
                        )
                except ImportError:
                    pass  # pip-package mode — no backend available

            # RFC 12a: append tool_call_delivered leaf after dispatch (fail-closed).
            _attest_leaf: dict | None = None
            if _attest_log is not None:
                try:
                    _dispatch_dur_ms = int((_time.monotonic() - _t0) * 1000)
                    _result_payload = {"text": str(result)[:4096]}
                    _attest_leaf = _attest_log.append_tool_call_delivered(
                        _attest_call_id, name, _result_payload, _dispatch_is_error, _dispatch_dur_ms
                    )
                except Exception as _ae:
                    logger.error("[attestation] tool_call_delivered failed: %s", _ae)

            _t_handler = _time.monotonic()
            logger.debug("[mnemo-mcp] timing tool=%s handler=%.3fs", name, _t_handler - _t0)

            # Fix 3: populate brief content cache on successful dispatch
            if _pre_profile and name == "get_morning_brief" and isinstance(result, str) and result:
                _brief_content_cache_set(_pre_profile, result, is_empty=not result.strip())

            # Prepend any greeting/brief cached by the PREVIOUS call's background task.
            # Lock ensures the pop+read is atomic vs. the background writer.
            if _pre_profile:
                _parts: list[str] = []
                with _pending_cache_lock:
                    _cached_brief = _pending_brief.pop(_pre_profile, None)
                    _cached_greet = _pending_greeting.pop(_pre_profile, None)
                if _cached_brief:
                    _parts.append(_cached_brief)
                if _cached_greet:
                    _parts.append(_cached_greet)
                if _parts:
                    result = "\n\n".join(_parts) + "\n\n" + str(result)

            # Fire background task to compute greeting + brief for the NEXT call.
            # Never awaited here — returns immediately.
            # All state reads and the in-flight claim happen atomically under
            # _pending_cache_lock before ensure_future, eliminating the TOCTOU
            # that would let two concurrent calls both launch a prefetch.
            if _pre_profile:
                with _pending_cache_lock:
                    _now_mono = time.monotonic()
                    _should_prefetch = (
                        _pre_profile not in _pending_brief
                        and _pre_profile not in _pending_greeting
                        and _pre_profile not in _prefetch_in_flight
                        and (_now_mono - _last_prefetch_time.get(_pre_profile, 0.0))
                            >= _PREFETCH_MIN_INTERVAL_S
                    )
                    if _should_prefetch:
                        _prefetch_in_flight.add(_pre_profile)
                        _last_prefetch_time[_pre_profile] = _now_mono
                if _should_prefetch and _claim_prefetch_slot(_pre_profile, _pre_token):
                    # _pre_token captured at call_tool boundary — passed
                    # explicitly so _maybe_greet doesn't rely on contextvar propagation
                    # through ensure_future → to_thread → _greet_pool.submit chain.
                    async def _background_prefetch(
                        _profile: str = _pre_profile,
                        _token: str = _pre_token,
                    ) -> None:
                        try:
                            _g = await asyncio.wait_for(
                                _maybe_greet_async(_profile),
                                timeout=10.0,
                            )
                            if _g:
                                with _pending_cache_lock:
                                    _pending_greeting[_profile] = _g
                        except Exception as exc:
                            logger.warning("[prefetch] greeting failed: %s", exc, exc_info=True)
                        try:
                            _env = await asyncio.wait_for(
                                _maybe_prepend_brief(_profile, {}),
                                timeout=10.0,
                            )
                            _mb = _env.get("_morning_brief")
                            if _mb:
                                _mb_s = _mb.get("summary", "") if isinstance(_mb, dict) else str(_mb)
                                if _mb_s:
                                    with _pending_cache_lock:
                                        _pending_brief[_profile] = f"[Morning Brief] {_mb_s}"
                        except Exception as exc:
                            logger.warning("[prefetch] brief failed: %s", exc, exc_info=True)
                        finally:
                            with _pending_cache_lock:
                                _prefetch_in_flight.discard(_profile)

                    _task = asyncio.get_event_loop().create_task(_background_prefetch())
                    _register_bg_task(_task)

            _t_greet = _time.monotonic()
            logger.debug(
                "[mnemo-mcp] timing tool=%s deferred_prepend=%.3fs total=%.3fs",
                name, _t_greet - _t_handler, _t_greet - _t0,
            )

            # Build the response. Attach the attestation leaf to _meta when available.
            _clipped = clip_tool_output(result)
            # CoSAI T5: scrub PII from read-tool output before returning to LLM client.
            # Write-tool results and error responses are excluded — they contain IDs/status,
            # not stored user content.  Fails open so PII scrub never breaks tool responses.
            if not _dispatch_is_error and name not in _WRITE_TOOLS and name not in _NO_FRAME_TOOLS:
                try:
                    if _scrub_pii is not None:
                        _clipped, _ = _scrub_pii(_clipped)
                except Exception:
                    pass  # fail open — PII scrub must not break tool responses
            # CoSAI T4: frame read-tool output so the host LLM can distinguish
            # retrieved data from instructions.  Write-tool results (confirmations,
            # IDs), error responses, and system integrity outputs are not framed.
            #
            # Defense-in-depth: escape boundary tokens in the content before framing.
            # The write-time scan rejects stored `</retrieved_data>` directly, but a
            # split-across-records concatenation (decision-A ends with `</retrieved`,
            # decision-B starts with `_data>`) bypasses the per-record scan.
            # Escaping on output closes that gap.
            if not _dispatch_is_error and name not in _WRITE_TOOLS and name not in _NO_FRAME_TOOLS:
                _safe = (
                    _clipped
                    .replace("</retrieved_data>", "&lt;/retrieved_data&gt;")
                    .replace("<retrieved_data>", "&lt;retrieved_data&gt;")
                )
                _clipped = f"<retrieved_data>\n{_safe}\n</retrieved_data>"
            if _attest_leaf is not None:
                from mcp.types import CallToolResult, TextContent as _TC
                return CallToolResult(
                    content=[_TC(type="text", text=_clipped)],
                    isError=_dispatch_is_error,
                    **{"_meta": {"attestation": _attest_leaf}},
                )
            return [TextContent(type="text", text=_clipped)]
        except RuntimeError as e:
            if "not provisioned" in str(e).lower():
                logger.warning("[mnemo-mcp] tool %s: profile not provisioned — %s", name, e)
                return [TextContent(type="text", text=(
                    f"Mnemo: profile not provisioned for this token.\n"
                    f"Sign in to the Mnemo portal and run setup: /portal/api/profile/ensure\n"
                    f"({e})"
                ))]
            logger.error("[mnemo-mcp] tool %s failed (outer): %s", name, e, exc_info=True)
            return [TextContent(type="text", text=_tool_error_response(name, e))]
        except Exception as e:
            logger.error("[mnemo-mcp] tool %s failed (outer): %s", name, e, exc_info=True)
            return [TextContent(type="text", text=_tool_error_response(name, e))]
        finally:
            reset_mcp_api_token_hint(token_ctx)
            reset_mcp_client_hint(client_ctx)
            # Fix 3: evict brief cache for write tools — runs even if tool raises
            if _pre_profile and name in _WRITE_TOOLS:
                try:
                    _evict_brief_cache_for_profile(_pre_profile)
                except Exception:
                    pass

    # ── B: Welcome resource for MCP connection ─────────────────────────────────

    @server.list_resources()
    async def list_resources():
        """Expose welcome resource to Claude on connection."""
        from mcp.types import Resource
        return [
            Resource(
                uri="mnemo://welcome",
                name="Welcome to Mnemo",
                description="Getting started with Mnemo — available tools and sample prompts",
                mimeType="text/plain",
            )
        ]

    @server.read_resource()
    async def read_resource(uri: str):
        """Return welcome content when requested."""
        if uri == "mnemo://welcome":
            welcome_text = """\
Welcome to Mnemo!

Track Sessions — Save your work and thinking
Track Decisions — Capture reasoning to learn from outcomes
Calibrate — Review your prediction accuracy
Get Help — Learn Mnemo features

Try this decision prompt:
"I am going to use Mnemo to drive better decisions"

Then use Track Decisions to review and refine your thinking over time.
"""
            from mcp.types import TextResourceContents
            return TextResourceContents(uri=uri, text=welcome_text, mimeType="text/plain")
        else:
            raise ValueError(f"Unknown resource: {uri}")

    return server


# ── Main entry point ──────────────────────────────────────────────────────────

async def main():
    """Run the Mnemo MCP server over stdio."""
    if not _MCP_AVAILABLE:
        print("ERROR: mcp package not installed.\nRun: pip install mnemo-meridian-mcp", file=sys.stderr)
        sys.exit(1)
    try:
        enforce_transport_policy(_API_URL)
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)

    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    profile_hint = _PROFILE.strip() or "<auto>"
    logger.info("[mnemo-mcp] Starting Mnemo Platform MCP server (profile: %s)", profile_hint)
    logger.info("[mnemo-mcp] Platform API: %s", _API_URL)

    # T6: Non-blocking attestation backend check. Failure logs WARNING; server still starts.
    global _ATTESTATION_BACKEND_AVAILABLE
    _ATTESTATION_BACKEND_AVAILABLE = await _check_attestation_backend()
    if not _ATTESTATION_BACKEND_AVAILABLE:
        logger.warning(
            "[T6] attestation backend unavailable at startup — "
            "attestation_get_log will return structured errors until DB is reachable"
        )

    server = build_mcp_server()
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())
