"""Tests for Alembic migrations 0038–0044 (orphaned SQL migration wrap-up)"""
import pytest
from alembic.config import Config
from sqlalchemy import create_engine, inspect
import os


@pytest.fixture
def alembic_config():
    config = Config(os.path.join(os.path.dirname(__file__), '..', 'alembic.ini'))
    config.set_main_option('sqlalchemy.url', os.environ.get('DATABASE_URL', 'postgresql://localhost/mnemo_test'))
    return config


@pytest.fixture
def db_engine(alembic_config):
    return create_engine(alembic_config.get_section_value('sqlalchemy', 'sqlalchemy.url'))


class TestMigration0038_DIPhase2:
    def test_decision_assumptions_table(self, db_engine):
        inspector = inspect(db_engine)
        assert 'decision_assumptions' in inspector.get_table_names()
        columns = {c['name']: c for c in inspector.get_columns('decision_assumptions')}
        assert all(k in columns for k in ['assumption_id', 'profile', 'decision_id', 'status', 'body_enc'])

    def test_decision_patterns_table(self, db_engine):
        inspector = inspect(db_engine)
        assert 'decision_patterns' in inspector.get_table_names()
        columns = {c['name']: c for c in inspector.get_columns('decision_patterns')}
        assert all(k in columns for k in ['pattern_id', 'profile', 'label', 'strength'])


class TestMigration0039_Announcements:
    def test_announcements_table(self, db_engine):
        inspector = inspect(db_engine)
        assert 'announcements' in inspector.get_table_names()
        
    def test_announcement_events_table(self, db_engine):
        inspector = inspect(db_engine)
        assert 'announcement_events' in inspector.get_table_names()
        
    def test_user_dismissals_table(self, db_engine):
        inspector = inspect(db_engine)
        assert 'user_announcement_dismissals' in inspector.get_table_names()


class TestMigration0040_ProjectScoping:
    def test_scope_columns_added(self, db_engine):
        inspector = inspect(db_engine)
        columns = {c['name']: c for c in inspector.get_columns('personal_projects')}
        assert 'visibility_scope' in columns
        assert 'created_by_user_id' in columns


class TestMigration0041_GDPR:
    def test_gdpr_erasure_log_table(self, db_engine):
        inspector = inspect(db_engine)
        assert 'gdpr_erasure_log' in inspector.get_table_names()


class TestMigration0042_ToS:
    def test_tos_columns(self, db_engine):
        inspector = inspect(db_engine)
        columns = {c['name']: c for c in inspector.get_columns('users')}
        assert 'tos_accepted_at' in columns
        assert 'tos_version' in columns


class TestMigration0043_EncSchemaVersion:
    def test_enc_schema_columns(self, db_engine):
        inspector = inspect(db_engine)
        for table in ['personal_decisions', 'personal_threads', 'personal_projects']:
            if table in inspector.get_table_names():
                columns = {c['name']: c for c in inspector.get_columns(table)}
                assert 'enc_schema_version' in columns


class TestMigration0044_OrgTeams:
    def test_org_teams_table(self, db_engine):
        inspector = inspect(db_engine)
        assert 'org_teams' in inspector.get_table_names()
        
    def test_org_team_members_table(self, db_engine):
        inspector = inspect(db_engine)
        assert 'org_team_members' in inspector.get_table_names()
