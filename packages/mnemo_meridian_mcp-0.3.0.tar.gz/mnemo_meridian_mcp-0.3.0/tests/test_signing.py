"""Tests for mcp_attest.signing — keypair generation, signing, verification."""
import base64
import json
import pytest

from cryptography.hazmat.primitives.asymmetric import ec

from mcp_attest.signing import (
	generate_keypair,
	public_key_to_jwk,
	public_key_from_jwk,
	sign_leaf,
	verify_signature,
)


def test_generated_keypair_is_ecdsa_p256():
	priv, pub = generate_keypair()
	assert isinstance(priv, ec.EllipticCurvePrivateKey)
	assert isinstance(pub, ec.EllipticCurvePublicKey)
	assert isinstance(priv.curve, ec.SECP256R1)


def test_signature_verifies_with_public_key():
	priv, pub = generate_keypair()
	leaf = {"leaf_type": "session_root", "sequence": 0, "data": "hello"}
	sig = sign_leaf(priv, leaf)
	signed = {**leaf, "signature": sig}
	assert verify_signature(pub, signed) is True


def test_signature_fails_if_payload_modified():
	priv, pub = generate_keypair()
	leaf = {"leaf_type": "session_root", "sequence": 0}
	sig = sign_leaf(priv, leaf)
	tampered = {"leaf_type": "session_root", "sequence": 999, "signature": sig}
	assert verify_signature(pub, tampered) is False


def test_signature_excludes_signature_field_from_payload():
	"""
	sign_leaf must exclude the 'signature' field from the signed payload.

	Property: a signature produced over a leaf that already contains a
	'signature' field must verify identically to one produced over the same
	leaf without it — because the 'signature' field is always stripped before
	canonicalization.

	Note: ECDSA P-256 is non-deterministic (random nonce k), so the raw
	signature bytes differ between calls. We assert verification, not byte
	equality.
	"""
	priv, pub = generate_keypair()
	leaf = {"leaf_type": "tool_call_received", "sequence": 1}

	# Sign a leaf that already has a 'signature' field (simulates re-signing)
	leaf_with_existing_sig = {**leaf, "signature": "totally_bogus_existing_value"}
	sig = sign_leaf(priv, leaf_with_existing_sig)

	# The produced signature must verify against the real content (sans signature)
	assert verify_signature(pub, {**leaf, "signature": sig}) is True

	# Also verify that a leaf with a *different* bogus signature field
	# produces a signature that verifies — proving the field was excluded
	leaf_other_bogus = {**leaf, "signature": "completely_different_bogus"}
	sig2 = sign_leaf(priv, leaf_other_bogus)
	assert verify_signature(pub, {**leaf, "signature": sig2}) is True


def test_public_key_jwk_roundtrip():
	_, pub = generate_keypair()
	jwk = public_key_to_jwk(pub, "test_kid")
	recovered = public_key_from_jwk(jwk)
	# Same public numbers
	assert pub.public_numbers() == recovered.public_numbers()


def test_regression_public_key_jwk_has_no_d_parameter():
	"""Private key 'd' parameter must never appear in the JWK output."""
	_, pub = generate_keypair()
	jwk = public_key_to_jwk(pub, "kid_test")
	assert "d" not in jwk


def test_verify_signature_wrong_key_returns_false():
	priv, _ = generate_keypair()
	_, other_pub = generate_keypair()
	leaf = {"leaf_type": "session_root", "sequence": 0}
	sig = sign_leaf(priv, leaf)
	signed = {**leaf, "signature": sig}
	assert verify_signature(other_pub, signed) is False


def test_verify_signature_missing_signature_field_returns_false():
	_, pub = generate_keypair()
	leaf = {"leaf_type": "session_root", "sequence": 0}  # no signature field
	assert verify_signature(pub, leaf) is False
