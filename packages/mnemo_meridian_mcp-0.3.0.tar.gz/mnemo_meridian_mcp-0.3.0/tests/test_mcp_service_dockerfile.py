"""
tests/test_mcp_service_dockerfile.py

Structural tests for Dockerfile.mcp — assert it satisfies Cloud Run requirements
without actually running a docker build.
"""
from __future__ import annotations

import os
import re

import pytest

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DOCKERFILE = os.path.join(_REPO_ROOT, "Dockerfile.mcp")
_SERVER_PY = os.path.join(_REPO_ROOT, "mnemo_mcp", "server.py")


@pytest.fixture(scope="module")
def dockerfile_text() -> str:
	with open(_DOCKERFILE, encoding="utf-8") as f:
		return f.read()


@pytest.fixture(scope="module")
def server_py_text() -> str:
	with open(_SERVER_PY, encoding="utf-8") as f:
		return f.read()


# ── Dockerfile structural assertions ─────────────────────────────────────────

def test_dockerfile_exists():
	"""Dockerfile.mcp must exist at repository root."""
	assert os.path.isfile(_DOCKERFILE), f"Dockerfile.mcp not found at {_DOCKERFILE}"


def test_dockerfile_uses_python_base(dockerfile_text):
	"""Must start from a Python base image."""
	assert re.search(r"FROM python:", dockerfile_text), \
		"Dockerfile.mcp must use a python: base image"


def test_dockerfile_copies_mnemo_mcp(dockerfile_text):
	"""Must COPY mnemo_mcp/ into the image."""
	assert re.search(r"COPY\s+mnemo_mcp", dockerfile_text), \
		"Dockerfile.mcp must COPY mnemo_mcp directory"


def test_dockerfile_has_cmd_or_entrypoint(dockerfile_text):
	"""Must define CMD or ENTRYPOINT to start the server."""
	assert re.search(r"^(CMD|ENTRYPOINT)", dockerfile_text, re.MULTILINE), \
		"Dockerfile.mcp must have a CMD or ENTRYPOINT"


def test_dockerfile_references_port(dockerfile_text):
	"""Must reference PORT or 8080 so Cloud Run can route traffic."""
	assert re.search(r"8080|PORT", dockerfile_text), \
		"Dockerfile.mcp must reference PORT or 8080"


def test_dockerfile_runs_mcp_server(dockerfile_text):
	"""CMD/ENTRYPOINT must launch the MCP server (http_app or mnemo_mcp)."""
	assert re.search(r"mnemo_mcp", dockerfile_text), \
		"Dockerfile.mcp CMD must reference mnemo_mcp"


def test_dockerfile_exposes_8080(dockerfile_text):
	"""Must EXPOSE 8080 for Cloud Run."""
	assert re.search(r"EXPOSE\s+8080", dockerfile_text), \
		"Dockerfile.mcp must EXPOSE 8080"


def test_dockerfile_validates_mnemo_api_url(dockerfile_text):
	"""Must guard against missing MNEMO_API_URL at startup."""
	assert "MNEMO_API_URL" in dockerfile_text, \
		"Dockerfile.mcp must reference MNEMO_API_URL (startup validation)"


# ── server.py validation check ────────────────────────────────────────────────

def test_server_py_validates_api_url_via_transport_policy(server_py_text):
	"""server.py main() must call enforce_transport_policy to validate MNEMO_API_URL."""
	assert "enforce_transport_policy" in server_py_text, \
		"server.py must call enforce_transport_policy(_API_URL) to validate the URL"


def test_http_app_exists():
	"""mnemo_mcp/http_app.py must exist — it is the Cloud Run HTTP entry point."""
	http_app = os.path.join(_REPO_ROOT, "mnemo_mcp", "http_app.py")
	assert os.path.isfile(http_app), \
		f"mnemo_mcp/http_app.py not found — required for Cloud Run HTTP transport"


def test_http_app_has_api_url_validation():
	"""http_app.py must exit(1) if MNEMO_API_URL is missing."""
	http_app = os.path.join(_REPO_ROOT, "mnemo_mcp", "http_app.py")
	with open(http_app, encoding="utf-8") as f:
		text = f.read()
	assert "MNEMO_API_URL" in text and "sys.exit(1)" in text, \
		"http_app.py must validate MNEMO_API_URL and call sys.exit(1) if missing"
