"""Tests for SessionAttestationLog — core lifecycle, sequencing, log root chaining."""
import threading
import time
import pytest

from mcp_attest.backends.memory import InMemoryBackend
from mcp_attest.leaves import INITIAL_LOG_ROOT, compute_log_root, leaf_id
from mcp_attest.log import SessionAttestationLog
from mcp_attest.signing import public_key_from_jwk, verify_signature


# ── Session root ──────────────────────────────────────────────────────────────

def test_session_root_leaf_is_sequence_zero():
	log = SessionAttestationLog()
	root = log.session_root_leaf()
	assert root["sequence"] == 0
	assert root["leaf_id"] == leaf_id(0)


def test_session_root_leaf_has_no_prev_leaf_id():
	log = SessionAttestationLog()
	root = log.session_root_leaf()
	assert "prev_leaf_id" not in root


def test_session_root_leaf_signature_is_valid():
	log = SessionAttestationLog()
	root = log.session_root_leaf()
	pub = public_key_from_jwk(root["server_public_key"])
	assert verify_signature(pub, root) is True


def test_session_root_contains_server_public_key():
	log = SessionAttestationLog()
	root = log.session_root_leaf()
	pk = root["server_public_key"]
	assert pk["kty"] == "EC"
	assert pk["crv"] == "P-256"
	assert "x" in pk and "y" in pk and "kid" in pk


def test_session_root_leaf_type():
	log = SessionAttestationLog()
	assert log.session_root_leaf()["leaf_type"] == "session_root"


# ── Tool call leaves ──────────────────────────────────────────────────────────

def test_tool_call_received_increments_sequence():
	log = SessionAttestationLog()
	leaf = log.append_tool_call_received("c1", "my_tool", {"arg": 1}, "req_1")
	assert leaf["sequence"] == 1  # root is 0
	assert leaf["leaf_type"] == "tool_call_received"


def test_tool_call_delivered_references_correct_call_id():
	log = SessionAttestationLog()
	log.append_tool_call_received("c1", "my_tool", {}, "req_1")
	delivered = log.append_tool_call_delivered("c1", "my_tool", {"out": "ok"}, False, 10)
	assert delivered["call_id"] == "c1"
	assert delivered["leaf_type"] == "tool_call_delivered"


def test_log_root_advances_after_each_leaf():
	log = SessionAttestationLog()
	root_log_root = log.session_root_leaf()["log_root"]
	recv = log.append_tool_call_received("c1", "tool", {}, "req_1")
	delivered = log.append_tool_call_delivered("c1", "tool", {}, False, 5)
	roots = [root_log_root, recv["log_root"], delivered["log_root"]]
	assert len(set(roots)) == 3, "Log root must be unique after each leaf"


def test_get_leaves_returns_correct_range():
	log = SessionAttestationLog()
	log.append_tool_call_received("c1", "tool", {}, "req_1")
	log.append_tool_call_delivered("c1", "tool", {}, False, 5)
	all_leaves = log.get_leaves()
	assert len(all_leaves) == 3  # root + received + delivered
	assert log.get_leaves(0, 0)[0]["leaf_type"] == "session_root"
	assert log.get_leaves(1, 1)[0]["leaf_type"] == "tool_call_received"
	assert log.get_leaves(2, 2)[0]["leaf_type"] == "tool_call_delivered"


def test_get_leaves_from_seq_equal_to_seq():
	log = SessionAttestationLog()
	leaves = log.get_leaves(0, 0)
	assert len(leaves) == 1
	assert leaves[0]["leaf_id"] == leaf_id(0)


def test_session_id_consistent_across_leaves():
	log = SessionAttestationLog()
	log.append_tool_call_received("c1", "tool", {}, "req_1")
	log.append_tool_call_delivered("c1", "tool", {}, False, 5)
	leaves = log.get_leaves()
	session_ids = {l.get("session_id") for l in leaves if l.get("session_id")}
	assert len(session_ids) == 1


def test_arguments_hash_in_received_leaf():
	log = SessionAttestationLog()
	args = {"decision": "do it"}
	leaf = log.append_tool_call_received("c1", "tool", args, "req_1")
	assert leaf["arguments_hash"].startswith("sha256:")
	# Arguments themselves not in leaf
	assert "decision" not in str(leaf.get("arguments", ""))


def test_result_hash_in_delivered_leaf():
	log = SessionAttestationLog()
	log.append_tool_call_received("c1", "tool", {}, "req_1")
	result = {"status": "ok", "id": 42}
	leaf = log.append_tool_call_delivered("c1", "tool", result, False, 15)
	assert leaf["result_hash"].startswith("sha256:")


# ── Error cases ───────────────────────────────────────────────────────────────

def test_regression_delivered_with_unknown_call_id_raises():
	"""tool_call_delivered with unmatched call_id must raise ValueError."""
	log = SessionAttestationLog()
	with pytest.raises(ValueError, match="no matching tool_call_received"):
		log.append_tool_call_delivered("nonexistent", "tool", {}, False, 0)


def test_regression_duplicate_received_call_id_raises():
	"""Calling append_tool_call_received twice with same call_id must raise."""
	log = SessionAttestationLog()
	log.append_tool_call_received("c1", "tool", {}, "req_1")
	with pytest.raises(ValueError, match="already has an open"):
		log.append_tool_call_received("c1", "tool", {}, "req_2")


# ── Concurrency ───────────────────────────────────────────────────────────────

def test_regression_concurrent_appends_do_not_corrupt_sequence():
	"""50 threads each appending a received+delivered pair must produce gap-free sequences."""
	log = SessionAttestationLog()
	errors = []

	def worker(i):
		try:
			call_id = f"call_{i}"
			log.append_tool_call_received(call_id, "tool", {"i": i}, f"req_{i}")
			log.append_tool_call_delivered(call_id, "tool", {"r": i}, False, 1)
		except Exception as e:
			errors.append(str(e))

	threads = [threading.Thread(target=worker, args=(i,)) for i in range(50)]
	for t in threads:
		t.start()
	for t in threads:
		t.join()

	assert not errors, f"Errors during concurrent appends: {errors}"
	leaves = log.get_leaves()
	sequences = [l["sequence"] for l in leaves]
	# Must be 0..N with no gaps
	assert sequences == list(range(len(sequences)))
	# 1 root + 50 received + 50 delivered = 101
	assert len(leaves) == 101


# ── Log root correctness ──────────────────────────────────────────────────────

def test_regression_session_id_has_128_bit_entropy():
	"""session_id random component must have >= 128 bits of entropy (adversary finding A-7)."""
	log = SessionAttestationLog()
	sid = log.session_id
	# Format: "sess_<32 hex chars>" = 128 bits
	assert sid.startswith("sess_")
	random_part = sid[len("sess_"):]
	# 32 hex chars = 16 bytes = 128 bits
	assert len(random_part) == 32, f"session_id random component is {len(random_part)*4} bits, need 128"
	# Must be valid hex
	int(random_part, 16)


def test_log_root_formula_correct_for_session_root():
	"""Session root log_root must equal compute_log_root(INITIAL, leaf_id(0), partial)."""
	log = SessionAttestationLog()
	root = log.session_root_leaf()
	partial = {k: v for k, v in root.items() if k not in ("log_root", "signature")}
	expected = compute_log_root(INITIAL_LOG_ROOT, leaf_id(0), partial)
	assert root["log_root"] == expected
