"""Unit tests for implicit-project discovery and merge logic.

Tests cover:
  - discover_implicit_slugs SQL logic (mock DB conn)
  - fetch_implicit_counts (mock DB conn)
  - get_projects router merge logic (mock DBProjectEngine + discovery)
  - archive_project handler (formal and implicit paths)
  - MCP handlers _handle_create_project and _handle_close_project
"""
from __future__ import annotations

import sys
import types
import unittest
from pathlib import Path
from typing import Any, Dict
from unittest.mock import AsyncMock, MagicMock, create_autospec, patch

# ---------------------------------------------------------------------------
# Bootstrap: stub every heavy dep that is not installed in this test env.
# mnemo_mcp.server uses mcp/anthropic at module level.
# backend.routers.legacy uses fastapi/slowapi/requests/bcrypt/etc.
# We stub all of these before importing anything that triggers those chains.
# ---------------------------------------------------------------------------

# ── MCP / anthropic stubs (needed by mnemo_mcp.server) ──────────────────────
for _mod in (
	"mcp",
	"mcp.server",
	"mcp.server.stdio",
	"mcp.server.models",
	"mcp.types",
):
	if _mod not in sys.modules:
		sys.modules[_mod] = types.ModuleType(_mod)

import mcp.server as _mcp_server  # noqa: E402
if not hasattr(_mcp_server, "FastMCP"):
	_mcp_server.FastMCP = MagicMock()  # type: ignore[attr-defined]

# ── fastapi / slowapi / bcrypt / anthropic / etc. (needed by legacy.py) ─────
def _route_deco(*_a, **_kw):
	return lambda f: f

_HEAVY_STUBS = [
	"fastapi", "fastapi.responses", "fastapi.security",
	"slowapi", "slowapi.util", "slowapi.errors",
	"requests", "anthropic", "openai",
	"bcrypt", "jwt", "jose", "jose.jwt", "jose.exceptions",
	"google", "google.cloud", "google.cloud.storage",
	"google.auth", "google.oauth2", "google.oauth2.credentials",
	"google.auth.transport", "google.auth.transport.requests",
	"boto3", "botocore", "botocore.exceptions",
	"chromadb", "chromadb.config", "sentence_transformers", "tavily",
	"redis", "redis.asyncio", "asyncpg",
	"cryptography", "cryptography.fernet",
	"cryptography.hazmat", "cryptography.hazmat.primitives",
	"cryptography.hazmat.primitives.kdf",
	"cryptography.hazmat.primitives.kdf.pbkdf2",
	"cryptography.hazmat.primitives.kdf.scrypt",
	"cryptography.hazmat.primitives.hashes",
	"cryptography.hazmat.backends",
	"argon2", "argon2.exceptions", "httpx",
	"pydantic_settings",
]
for _name in _HEAVY_STUBS:
	sys.modules.setdefault(_name, types.ModuleType(_name))

# fastapi — need real-looking APIRouter + helpers
_APIRouter = type("APIRouter", (object,), {
	"__init__": lambda s, **kw: None,
	"get": staticmethod(_route_deco),
	"post": staticmethod(_route_deco),
	"put": staticmethod(_route_deco),
	"delete": staticmethod(_route_deco),
	"patch": staticmethod(_route_deco),
	"options": staticmethod(_route_deco),
	"head": staticmethod(_route_deco),
	"websocket": staticmethod(_route_deco),
	"include_router": lambda s, *a, **kw: None,
	"add_api_route": lambda s, *a, **kw: None,
})
import fastapi as _fastapi  # noqa: E402
_ORIG_FASTAPI_HTTP_EXCEPTION = getattr(_fastapi, "HTTPException", None)
_fastapi.APIRouter = _APIRouter
for _attr in ["Body", "File", "Header", "Request", "Response",
              "UploadFile", "WebSocket", "WebSocketDisconnect", "status"]:
	setattr(_fastapi, _attr, type(_attr, (object,), {"__init__": lambda s, *a, **kw: None}))
_fastapi.HTTPException = type("HTTPException", (Exception,), {
	"__init__": lambda s, status_code=400, detail="": None,
})
_fastapi.Depends = lambda x=None: x

import fastapi.responses as _fr  # noqa: E402
for _attr in ["FileResponse", "JSONResponse", "StreamingResponse"]:
	setattr(_fr, _attr, type(_attr, (object,), {}))

import fastapi.security as _fs  # noqa: E402
_fs.OAuth2PasswordBearer = type("OAuth2PasswordBearer", (object,), {"__init__": lambda s, **kw: None})

import slowapi as _slowapi  # noqa: E402
_slowapi.Limiter = type("Limiter", (object,), {
	"__init__": lambda s, **kw: None,
	"limit": lambda s, *a, **kw: _route_deco,
	"shared_limit": lambda s, *a, **kw: _route_deco,
})
import slowapi.util as _su  # noqa: E402
_su.get_remote_address = lambda r: "127.0.0.1"

import anthropic as _an  # noqa: E402
for _attr in ["Anthropic", "AsyncAnthropic"]:
	setattr(_an, _attr, type(_attr, (object,), {}))
for _attr in ["APIStatusError", "APIConnectionError"]:
	setattr(_an, _attr, type(_attr, (Exception,), {}))

import bcrypt as _bc  # noqa: E402
_bc.hashpw = lambda pw, salt: b"hash"
_bc.gensalt = lambda rounds=12: b"salt"
_bc.checkpw = lambda pw, hsh: True

# ── Load mnemo_mcp.server (needs mcp + anthropic stubs) ─────────────────────
import importlib  # noqa: E402

server = importlib.import_module("mnemo_mcp.server")
_handle_create_project = server._handle_create_project
_handle_close_project = server._handle_close_project

# ── Load backend.routers.legacy (needs all the fastapi stubs above) ──────────
# Bypass backend/routers/__init__.py (which does `from .legacy import router`)
# by injecting a stub for the package before the real module loads.
if "backend.routers" not in sys.modules:
	sys.modules["backend.routers"] = types.ModuleType("backend.routers")

_legacy_spec = importlib.util.spec_from_file_location(
	"backend.routers.legacy",
	Path(__file__).parent.parent / "backend" / "routers" / "legacy.py",
)
_legacy_mod = importlib.util.module_from_spec(_legacy_spec)
sys.modules["backend.routers.legacy"] = _legacy_mod
_legacy_spec.loader.exec_module(_legacy_mod)  # type: ignore[union-attr]

get_projects = _legacy_mod.get_projects
archive_project = _legacy_mod.archive_project

if _ORIG_FASTAPI_HTTP_EXCEPTION is not None:
	_fastapi.HTTPException = _ORIG_FASTAPI_HTTP_EXCEPTION


# ---------------------------------------------------------------------------
# Group 1: discover_implicit_slugs SQL logic
# ---------------------------------------------------------------------------

class TestDiscoverImplicitSlugs(unittest.IsolatedAsyncioTestCase):
	"""Tests for _discover_implicit_slugs_async with a mocked DB conn."""

	async def _call(self, rows):
		from backend.db_projects import _discover_implicit_slugs_async
		conn = AsyncMock()
		conn.fetch = AsyncMock(return_value=rows)
		return await _discover_implicit_slugs_async("rags", conn)

	async def test_discover_returns_slugs_not_in_formal_projects(self):
		rows = [{"slug": "alpha"}, {"slug": "beta"}]
		result = await self._call(rows)
		assert result == ["alpha", "beta"]

	async def test_discover_returns_empty_when_all_slugs_have_formal_records(self):
		result = await self._call([])
		assert result == []

	async def test_discover_caps_at_50_slugs(self):
		rows = [{"slug": f"proj-{i}"} for i in range(50)]
		result = await self._call(rows)
		assert len(result) == 50

	async def test_discover_normalises_to_lowercase(self):
		# The SQL does LOWER(project_id) — DB returns lowercase slugs
		rows = [{"slug": "mnemo"}]
		result = await self._call(rows)
		assert "mnemo" in result


# ---------------------------------------------------------------------------
# Group 2: fetch_implicit_counts
# ---------------------------------------------------------------------------

class TestFetchImplicitCounts(unittest.IsolatedAsyncioTestCase):
	"""Tests for _fetch_implicit_counts_async with a mocked DB conn."""

	async def _call(self, slugs, rows):
		from backend.db_projects import _fetch_implicit_counts_async
		conn = AsyncMock()
		conn.fetch = AsyncMock(return_value=rows)
		return await _fetch_implicit_counts_async("rags", slugs, conn)

	async def test_fetch_counts_returns_correct_structure(self):
		rows = [
			{"slug": "alpha", "decision_count": 3, "thread_count": 1, "task_count": 2},
			{"slug": "beta",  "decision_count": 0, "thread_count": 5, "task_count": 0},
		]
		result = await self._call(["alpha", "beta"], rows)
		assert result["alpha"] == {"decision_count": 3, "thread_count": 1, "task_count": 2}
		assert result["beta"]  == {"decision_count": 0, "thread_count": 5, "task_count": 0}

	async def test_fetch_counts_empty_slugs_returns_empty_dict(self):
		"""Short-circuit: conn.fetch must NOT be called when slugs is empty."""
		from backend.db_projects import _fetch_implicit_counts_async
		conn = AsyncMock()
		conn.fetch = AsyncMock(return_value=[])
		result = await _fetch_implicit_counts_async("rags", [], conn)
		assert result == {}
		conn.fetch.assert_not_called()

	async def test_fetch_counts_missing_slug_returns_zero_counts(self):
		"""A slug in the input that has no DB row is absent from result."""
		rows = [
			{"slug": "alpha", "decision_count": 1, "thread_count": 0, "task_count": 0},
		]
		result = await self._call(["alpha", "ghost"], rows)
		assert "alpha" in result
		# "ghost" not returned by DB — key is absent; caller uses .get() with default 0
		assert "ghost" not in result


# ---------------------------------------------------------------------------
# Group 3: get_projects router merge logic
# ---------------------------------------------------------------------------

def _make_formal_project(slug: str, status: str = "active") -> dict:
	return {
		"project_id": f"uuid-{slug}",
		"name": slug,
		"slug": slug,
		"goal": "",
		"status": status,
		"color": "#6366F1",
		"milestones": [],
		"created_at": "2026-01-01T00:00:00Z",
		"updated_at": "2026-01-01T00:00:00Z",
		"participant_profiles": [],
	}


class TestGetProjectsRouterMerge(unittest.TestCase):
	"""Tests for get_projects() in backend.routers.legacy."""

	def _call_get_projects(
		self,
		status: str = "all",
		formal_projects: list | None = None,
		implicit_slugs: list | None = None,
		implicit_counts: dict | None = None,
		sessions: list | None = None,
		tasks: list | None = None,
		name: str = "rags",
	) -> list[dict]:
		if formal_projects is None:
			formal_projects = []
		if implicit_slugs is None:
			implicit_slugs = []
		if implicit_counts is None:
			implicit_counts = {}
		if sessions is None:
			sessions = []
		if tasks is None:
			tasks = []

		mock_proj_engine = MagicMock()
		mock_proj_engine.load_dicts.return_value = formal_projects
		mock_task_engine = MagicMock()
		mock_task_engine.load_dicts.return_value = tasks

		# get_projects() uses lazy imports from backend.db_projects and backend.db_tasks
		# so we must patch the symbols in those source modules, not in _legacy_mod.
		with (
			patch("backend.db_projects.DBProjectEngine", return_value=mock_proj_engine),
			patch("backend.db_tasks.DBTaskEngine", return_value=mock_task_engine),
			patch("backend.db_projects.discover_implicit_slugs", return_value=implicit_slugs),
			patch("backend.db_projects.fetch_implicit_counts", return_value=implicit_counts),
			patch.object(_legacy_mod, "Profile") as mock_profile_cls,
			patch.object(_legacy_mod, "_check_profile_access"),
			patch.object(_legacy_mod, "_require_safe_name", side_effect=lambda n: n),
		):
			mock_profile_cls.load_sessions_for_root.return_value = sessions
			return get_projects(name=name, status=status, current_user=name)

	def test_get_projects_includes_implicit_when_status_active(self):
		formal = [_make_formal_project("formal-proj", "active")]
		result = self._call_get_projects(
			status="active",
			formal_projects=formal,
			implicit_slugs=["implicit-proj"],
			implicit_counts={"implicit-proj": {"decision_count": 1, "thread_count": 0, "task_count": 0}},
		)
		slugs = [p["slug"] for p in result]
		assert "formal-proj" in slugs
		assert "implicit-proj" in slugs

	def test_get_projects_skips_implicit_when_status_archived(self):
		formal = [_make_formal_project("archived-proj", "archived")]
		result = self._call_get_projects(
			status="archived",
			formal_projects=formal,
			implicit_slugs=["implicit-proj"],
		)
		slugs = [p["slug"] for p in result]
		assert "archived-proj" in slugs
		assert "implicit-proj" not in slugs

	def test_get_projects_includes_implicit_when_status_all(self):
		formal = [_make_formal_project("formal-proj", "active")]
		result = self._call_get_projects(
			status="all",
			formal_projects=formal,
			implicit_slugs=["implicit-proj"],
			implicit_counts={"implicit-proj": {"decision_count": 2, "thread_count": 1, "task_count": 0}},
		)
		slugs = [p["slug"] for p in result]
		assert "formal-proj" in slugs
		assert "implicit-proj" in slugs

	def test_regression_implicit_project_visible_in_list(self):
		"""Regression: decisions with project_id='mnemo' but no formal record must appear in list."""
		result = self._call_get_projects(
			status="active",
			formal_projects=[],
			implicit_slugs=["mnemo"],
			implicit_counts={"mnemo": {"decision_count": 5, "thread_count": 2, "task_count": 0}},
		)
		slugs = [p["slug"] for p in result]
		assert "mnemo" in slugs
		mnemo_entry = next(p for p in result if p["slug"] == "mnemo")
		assert mnemo_entry["decision_count"] == 5
		assert mnemo_entry["thread_count"] == 2

	def test_formal_project_type_field_is_formal(self):
		formal = [_make_formal_project("proj-x", "active")]
		result = self._call_get_projects(formal_projects=formal)
		formal_entries = [p for p in result if p["slug"] == "proj-x"]
		assert formal_entries, "proj-x not found in result"
		assert formal_entries[0]["type"] == "formal"

	def test_implicit_project_type_field_is_implicit(self):
		result = self._call_get_projects(
			implicit_slugs=["imp-slug"],
			implicit_counts={"imp-slug": {"decision_count": 1, "thread_count": 0, "task_count": 0}},
		)
		implicit_entries = [p for p in result if p["slug"] == "imp-slug"]
		assert implicit_entries, "imp-slug not found in result"
		assert implicit_entries[0]["type"] == "implicit"

	def test_session_count_matches_by_slug_not_uuid(self):
		"""Sessions with project_id='mnemo' count for the formal project with slug='mnemo'."""
		formal = [_make_formal_project("mnemo", "active")]
		sessions = [
			{"project_id": "mnemo", "session_id": "s1"},
			{"project_id": "mnemo", "session_id": "s2"},
			{"project_id": "other-slug", "session_id": "s3"},
		]
		result = self._call_get_projects(
			status="active",
			formal_projects=formal,
			sessions=sessions,
		)
		mnemo_entry = next(p for p in result if p["slug"] == "mnemo")
		assert mnemo_entry["session_count"] == 2

	def test_dedup_formal_wins_over_implicit(self):
		"""If formal project has slug 'foo', it must appear exactly once as 'formal'."""
		formal = [_make_formal_project("foo", "active")]
		# SQL contract: implicit_slugs will never include a slug that has a formal record.
		result = self._call_get_projects(
			status="active",
			formal_projects=formal,
			implicit_slugs=[],  # "foo" excluded by SQL's WHERE NOT IN clause
		)
		foo_entries = [p for p in result if p["slug"] == "foo"]
		assert len(foo_entries) == 1
		assert foo_entries[0]["type"] == "formal"


# ---------------------------------------------------------------------------
# Group 4: archive_project handler
# ---------------------------------------------------------------------------

class TestArchiveProject(unittest.TestCase):
	"""Tests for archive_project() in backend.routers.legacy."""

	def _make_project_record(self, project_id: str, slug: str, status: str = "active"):
		rec = MagicMock()
		rec.project_id = project_id
		rec.slug = slug
		rec.status = status
		return rec

	def _call_archive(self, slug: str, existing_project=None, reason: str = "") -> dict:
		from backend.schemas import ProjectArchiveRequest

		mock_engine = MagicMock()
		mock_engine.get_project_by_slug.return_value = existing_project

		if existing_project:
			updated = self._make_project_record(existing_project.project_id, slug, "archived")
			mock_engine.update_project.return_value = updated
		else:
			created = self._make_project_record("new-uuid", slug, "archived")
			mock_engine.create_project.return_value = created

		req = ProjectArchiveRequest(reason=reason or None)

		# archive_project() lazily imports DBProjectEngine from backend.db_projects
		with (
			patch("backend.db_projects.DBProjectEngine", return_value=mock_engine),
			patch.object(_legacy_mod, "_check_profile_access"),
			patch.object(_legacy_mod, "_require_safe_name", side_effect=lambda n: n),
		):
			return archive_project(name="rags", slug=slug, req=req, current_user="rags")

	def test_archive_formal_project_updates_status(self):
		existing = self._make_project_record("uuid-abc", "my-proj", "active")
		result = self._call_archive("my-proj", existing_project=existing)
		assert result["status"] == "archived"
		assert result["was_implicit"] is False
		assert result["slug"] == "my-proj"
		assert result["project_id"] == "uuid-abc"

	def test_archive_implicit_project_creates_formal_archived(self):
		"""No formal record → create_project is called, was_implicit=True."""
		result = self._call_archive("ghost-slug", existing_project=None, reason="done with it")
		assert result["status"] == "archived"
		assert result["was_implicit"] is True
		assert result["slug"] == "ghost-slug"

	def test_archive_idempotent_already_archived(self):
		"""Second archive call finds existing archived formal record → was_implicit=False."""
		existing = self._make_project_record("uuid-xyz", "old-proj", "archived")
		result = self._call_archive("old-proj", existing_project=existing)
		assert result["status"] == "archived"
		assert result["was_implicit"] is False


# ---------------------------------------------------------------------------
# Group 5: MCP handlers _handle_create_project and _handle_close_project
# ---------------------------------------------------------------------------

class TestHandleCreateProject(unittest.TestCase):
	"""Tests for _handle_create_project in mnemo_mcp.server."""

	def _run(self, args: dict, api_returns=None) -> tuple[str, list]:
		calls: list = []
		if api_returns is None:
			api_returns = {"project_id": "pid-1", "slug": "my-proj"}

		def fake_api(method, path, body=None, **kw):
			calls.append((method, path, body))
			return api_returns

		with (
			patch.object(server, "_api_call", side_effect=fake_api),
			patch.object(server, "_profile_path", side_effect=lambda p: f"/profile/rags{p}"),
			patch.object(server, "_record_mcp_usage", return_value={}),
		):
			result = _handle_create_project(args)
		return result, calls

	def test_handle_create_project_posts_to_projects_endpoint(self):
		_, calls = self._run({"name": "My Project"})
		assert calls, "No API call was made"
		method, path, body = calls[0]
		assert method == "POST"
		assert path.endswith("/projects")

	def test_handle_create_project_missing_name_returns_error(self):
		result, calls = self._run({"name": ""})
		assert result.startswith("Error")
		assert not calls, "API should not be called when name is missing"

	def test_handle_create_project_optional_slug_included_in_body(self):
		_, calls = self._run({"name": "My Project", "slug": "custom-slug"})
		body = calls[0][2]
		assert body.get("slug") == "custom-slug"

	def test_handle_create_project_no_slug_omits_slug_from_body(self):
		_, calls = self._run({"name": "My Project"})
		body = calls[0][2]
		assert "slug" not in body

	def test_handle_create_project_returns_slug_and_id_in_response(self):
		result, _ = self._run({"name": "My Project"})
		assert "my-proj" in result
		assert "pid-1" in result

	def test_handle_create_project_api_error_returns_error_string(self):
		result, _ = self._run(
			{"name": "Duplicate"},
			api_returns={"error": "conflict", "detail": "already exists"},
		)
		assert result.startswith("Error")
		assert "conflict" in result


class TestHandleCloseProject(unittest.TestCase):
	"""Tests for _handle_close_project in mnemo_mcp.server."""

	def _run(self, args: dict, api_returns=None) -> tuple[str, list]:
		calls: list = []
		if api_returns is None:
			api_returns = {"project_id": "pid-1", "slug": "my-proj", "was_implicit": False}

		def fake_api(method, path, body=None, **kw):
			calls.append((method, path, body))
			return api_returns

		with (
			patch.object(server, "_api_call", side_effect=fake_api),
			patch.object(server, "_profile_path", side_effect=lambda p: f"/profile/rags{p}"),
			patch.object(server, "_record_mcp_usage", return_value={}),
		):
			result = _handle_close_project(args)
		return result, calls

	def test_handle_close_project_posts_to_archive_endpoint(self):
		_, calls = self._run({"project": "my-proj"})
		assert calls, "No API call was made"
		method, path, body = calls[0]
		assert method == "POST"
		assert "archive" in path
		assert "my-proj" in path

	def test_handle_close_project_missing_project_returns_error(self):
		result, calls = self._run({"project": ""})
		assert result.startswith("Error")
		assert not calls, "API should not be called when project slug is missing"

	def test_handle_close_project_shows_was_implicit_in_response(self):
		result, _ = self._run(
			{"project": "ghost"},
			api_returns={"project_id": "new-pid", "slug": "ghost", "was_implicit": True},
		)
		assert "implicit" in result.lower()

	def test_handle_close_project_formal_project_no_implicit_note(self):
		result, _ = self._run(
			{"project": "formal-proj"},
			api_returns={"project_id": "pid-1", "slug": "formal-proj", "was_implicit": False},
		)
		assert "implicit" not in result.lower()

	def test_handle_close_project_api_error_returns_error_string(self):
		result, _ = self._run(
			{"project": "bad-slug"},
			api_returns={"error": "not_found", "detail": "no such project"},
		)
		assert result.startswith("Error")
		assert "not_found" in result

	def test_handle_close_project_reason_included_in_body(self):
		_, calls = self._run({"project": "old-proj", "reason": "no longer needed"})
		body = calls[0][2]
		assert body.get("reason") == "no longer needed"

	def test_handle_close_project_no_reason_sends_empty_body(self):
		_, calls = self._run({"project": "old-proj"})
		body = calls[0][2]
		assert "reason" not in body


if __name__ == "__main__":
	unittest.main()
