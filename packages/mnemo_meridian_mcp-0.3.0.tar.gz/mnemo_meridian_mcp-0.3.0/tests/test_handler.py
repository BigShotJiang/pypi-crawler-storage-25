"""Tests for mcp_attest.handler — attestation/get_log handler."""
import pytest

from mcp_attest.handler import handle_get_log
from mcp_attest.log import SessionAttestationLog


def _make_log_with_calls(n: int) -> SessionAttestationLog:
	log = SessionAttestationLog()
	for i in range(n):
		log.append_tool_call_received(f"c{i}", "tool", {"i": i}, f"req_{i}")
		log.append_tool_call_delivered(f"c{i}", "tool", {"r": i}, False, 5)
	return log


def test_get_log_returns_all_leaves():
	log = _make_log_with_calls(2)
	result = handle_get_log(log, {}, log.session_id)
	assert "leaves" in result
	assert len(result["leaves"]) == 5  # 1 root + 2*2


def test_get_log_returns_session_id():
	log = _make_log_with_calls(1)
	result = handle_get_log(log, {}, log.session_id)
	assert result["session_id"] == log.session_id


def test_get_log_from_sequence_filter():
	log = _make_log_with_calls(2)
	result = handle_get_log(log, {"from_sequence": 1}, log.session_id)
	# Should return leaves 1..4 (4 leaves)
	assert len(result["leaves"]) == 4
	assert result["leaves"][0]["sequence"] == 1


def test_get_log_to_sequence_filter():
	log = _make_log_with_calls(2)
	result = handle_get_log(log, {"to_sequence": 2}, log.session_id)
	assert len(result["leaves"]) == 3
	assert result["leaves"][-1]["sequence"] == 2


def test_get_log_session_id_from_context_not_params():
	"""session_id in params must be ignored — only the context session_id is used."""
	log = _make_log_with_calls(1)
	# Pass a different session_id in params — it must be ignored
	result = handle_get_log(log, {"session_id": "ATTACKER_SESSION_ID"}, log.session_id)
	assert result["session_id"] == log.session_id
	assert result["session_id"] != "ATTACKER_SESSION_ID"


def test_get_log_invalid_from_sequence_type_raises():
	log = _make_log_with_calls(1)
	with pytest.raises(ValueError, match="from_sequence"):
		handle_get_log(log, {"from_sequence": "bad"}, log.session_id)


def test_get_log_invalid_to_sequence_type_raises():
	log = _make_log_with_calls(1)
	with pytest.raises(ValueError, match="to_sequence"):
		handle_get_log(log, {"to_sequence": "bad"}, log.session_id)
