#!/usr/bin/env python3
"""Standalone Mnemo MCP smoke suite.

Run directly:
  python3 tests/test_mnemo_mcp.py

This file is intentionally script-style for manual workstation validation.
Pytest users should run backend/tests/* instead.
"""

from __future__ import annotations

import json
import os
import select
import subprocess
import sys
import time
import urllib.error
import urllib.request
from typing import Any

if __name__ != "__main__":
    # Prevent pytest collection from executing script side-effects.
    import pytest

    pytest.skip("script-style MCP smoke suite; run directly via python3", allow_module_level=True)


SERVER_IP = os.getenv("MNEMO_TEST_SERVER_IP", "127.0.0.1")
PORT = int(os.getenv("MNEMO_TEST_PORT", "7432"))
TOKEN = os.getenv("MNEMO_TEST_TOKEN", "")
PROFILE = os.getenv("MNEMO_TEST_PROFILE", "rags")
MCP_SCRIPT = os.getenv("MNEMO_TEST_MCP_SCRIPT", os.path.expanduser("~/mnemo/backend/mcp_server.py"))
PYTHON = os.getenv("MNEMO_TEST_PYTHON", sys.executable or "python3")

BASE_URL = f"http://{SERVER_IP}:{PORT}"
PASS = "\033[92mPASS\033[0m"
FAIL = "\033[91mFAIL\033[0m"
SKIP = "\033[93mSKIP\033[0m"

results: list[tuple[str, str, bool | None, str]] = []


def record(layer: str, name: str, passed: bool, note: str = "") -> None:
    tag = PASS if passed else FAIL
    print(f"  {tag}  {name}" + (f" — {note}" if note else ""))
    results.append((layer, name, passed, note))


def skip_test(layer: str, name: str, reason: str = "backend down") -> None:
    print(f"  {SKIP}  {name} — {reason}")
    results.append((layer, name, None, reason))


def separator(title: str) -> None:
    print(f"\n{'─' * 55}")
    print(f"  {title}")
    print(f"{'─' * 55}")


def http_get(path: str, auth: bool = True, timeout: int = 5) -> tuple[int | None, Any]:
    url = BASE_URL + path
    req = urllib.request.Request(url)
    if auth and TOKEN:
        req.add_header("Authorization", f"Bearer {TOKEN}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        return exc.code, {}
    except Exception as exc:
        return None, str(exc)


def http_post(path: str, body: dict[str, Any], auth: bool = True, timeout: int = 5) -> tuple[int | None, Any]:
    url = BASE_URL + path
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"},
    )
    if auth and TOKEN:
        req.add_header("Authorization", f"Bearer {TOKEN}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        return exc.code, {}
    except Exception as exc:
        return None, str(exc)


def mcp_recv(proc: subprocess.Popen[bytes], timeout: int = 10) -> dict[str, Any] | None:
    ready, _, _ = select.select([proc.stdout], [], [], timeout)
    if not ready:
        return None

    assert proc.stdout is not None
    first_line = proc.stdout.readline().decode()
    if not first_line:
        return None

    headers: dict[str, str] = {}
    if ":" in first_line and not first_line.strip().startswith("{"):
        key, val = first_line.split(":", 1)
        headers[key.strip().lower()] = val.strip()
        while True:
            line = proc.stdout.readline().decode()
            if line in ("\r\n", "\n", ""):
                break
            if ":" in line:
                k, v = line.split(":", 1)
                headers[k.strip().lower()] = v.strip()
        if "content-length" in headers:
            body = proc.stdout.read(int(headers["content-length"])).decode()
        else:
            body = proc.stdout.readline().decode().strip()
    else:
        body = first_line.strip()

    try:
        return json.loads(body)
    except Exception:
        return None


def mcp_send(proc: subprocess.Popen[bytes], payload: dict[str, Any]) -> None:
    assert proc.stdin is not None
    proc.stdin.write((json.dumps(payload) + "\n").encode())
    proc.stdin.flush()


def call_tool(proc: subprocess.Popen[bytes], req_id: int, name: str, arguments: dict[str, Any] | None = None) -> dict[str, Any] | None:
    mcp_send(
        proc,
        {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": "tools/call",
            "params": {"name": name, "arguments": arguments or {}},
        },
    )
    return mcp_recv(proc, timeout=15)


def run_suite() -> int:
    separator("PRE-FLIGHT CONFIG CHECK")
    errors: list[str] = []
    if not TOKEN:
        errors.append("MNEMO_TEST_TOKEN is missing")
    if not os.path.exists(MCP_SCRIPT):
        errors.append(f"mcp_server.py not found at {MCP_SCRIPT}")
    if not os.path.exists(PYTHON):
        errors.append(f"Python not found at {PYTHON}")

    if errors:
        print(f"\n  {FAIL}  Config incomplete — fix these before running:\n")
        for err in errors:
            print(f"    • {err}")
        return 1
    print(f"  {PASS}  Config looks complete")

    separator("LAYER 1 — Backend API")
    status, _ = http_get("/health", auth=False)
    backend_up = status == 200
    record("L1", "GET /health", backend_up, f"status={status}")

    if backend_up:
        status, _ = http_get(f"/profile/{PROFILE}/decisions", auth=False)
        record("L1", "GET /profile/{name}/decisions (no token)", status == 401, f"status={status}")

        status, _ = http_get(f"/profile/{PROFILE}/decisions")
        record("L1", "GET /profile/{name}/decisions (with token)", status == 200, f"status={status}")

        status, _ = http_post("/api/v1/context/retrieve", {"query": "test", "max_tokens": 100})
        record("L1", "POST /api/v1/context/retrieve", status == 200, f"status={status}")
    else:
        skip_test("L1", "Authenticated API checks", "backend unavailable")

    separator("LAYER 2 — MCP Subprocess Startup")
    clean_env = {k: v for k, v in os.environ.items() if k not in ("VIRTUAL_ENV", "PYTHONHOME", "PYTHONPATH")}
    clean_env["PYTHONSAFEPATH"] = "1"
    run_env = {
        **clean_env,
        "MNEMO_API_URL": BASE_URL,
        "MNEMO_API_TOKEN": TOKEN,
        "MNEMO_PROFILE": PROFILE,
    }

    proc = subprocess.Popen(
        [PYTHON, MCP_SCRIPT],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=run_env,
    )
    time.sleep(1.5)
    running = proc.poll() is None
    record("L2", "Subprocess starts and stays alive", running)
    if not running:
        err = (proc.stderr.read(1200).decode() if proc.stderr else "").strip()
        record("L2", "Startup stderr available", bool(err), err[:120])
        return 1

    separator("LAYER 3 — MCP Protocol")
    try:
        mcp_send(
            proc,
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "smoke-test", "version": "1.0"},
                },
            },
        )
        init = mcp_recv(proc)
        record("L3", "initialize", bool(init and "result" in init))

        mcp_send(proc, {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
        listed = mcp_recv(proc)
        tools = []
        if listed and "result" in listed:
            tools = [t.get("name") for t in listed["result"].get("tools", [])]
        record("L3", "tools/list", bool(tools), f"count={len(tools)}")

        if backend_up:
            resp = call_tool(proc, 3, "get_decisions", {"status": "open", "limit": 3})
            record("L3", "tool call get_decisions", bool(resp and "result" in resp))
        else:
            skip_test("L3", "tool call get_decisions", "backend unavailable")
    finally:
        proc.terminate()

    separator("SUMMARY")
    total = len(results)
    passed = sum(1 for r in results if r[2] is True)
    failed = sum(1 for r in results if r[2] is False)
    skipped = sum(1 for r in results if r[2] is None)
    print(f"\n  Total  : {total}")
    print(f"  {PASS}   : {passed}")
    print(f"  {FAIL}   : {failed}")
    if skipped:
        print(f"  {SKIP}   : {skipped}")

    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(run_suite())
