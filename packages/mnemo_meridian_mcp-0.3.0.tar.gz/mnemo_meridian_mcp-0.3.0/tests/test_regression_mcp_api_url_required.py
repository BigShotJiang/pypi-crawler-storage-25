"""
tests/test_regression_mcp_api_url_required.py

Regression test: MNEMO_API_URL must be validated at startup.

Original bug: if MNEMO_API_URL is empty or unset, the MCP service would start
and silently route all API calls to "https://api.mnemomcp.com" (the default),
ignoring the Cloud Run environment's intended backend.  The http_app.py startup
guard and the server.py enforce_transport_policy check must both catch this.
"""
from __future__ import annotations

import importlib
import os
import sys
import types
import unittest.mock as mock

import pytest


# ── Helpers ───────────────────────────────────────────────────────────────────

def _install_backend_stubs():
	"""Minimal stubs so mnemo_mcp.server imports don't fail."""
	stubs = {
		"backend": types.ModuleType("backend"),
		"backend.agent_classifier": types.ModuleType("backend.agent_classifier"),
		"backend.metrics_collector": types.ModuleType("backend.metrics_collector"),
		"backend.pii_scrubber": types.ModuleType("backend.pii_scrubber"),
		"backend.feature_gates": types.ModuleType("backend.feature_gates"),
	}
	stubs["backend.agent_classifier"].classify_wrap_session_decisions = None
	import contextlib
	@contextlib.asynccontextmanager
	async def _noop(*_a, **_kw):
		yield None
	stubs["backend.metrics_collector"].track_mcp_call = _noop
	stubs["backend.pii_scrubber"].scrub_pii = lambda t: (t, [])
	stubs["backend.feature_gates"].FEATURE_GATES = {}
	stubs["backend.feature_gates"].check_feature = lambda *_a, **_kw: False
	for name, mod in stubs.items():
		if name not in sys.modules:
			sys.modules[name] = mod


_install_backend_stubs()


# ── Tests ─────────────────────────────────────────────────────────────────────

class TestHttpAppApiUrlValidation:
	"""http_app.py must exit(1) immediately when MNEMO_API_URL is absent."""

	def test_regression_http_app_exits_when_api_url_empty(self, monkeypatch, tmp_path):
		"""
		Regression: http_app.py must call sys.exit(1) when MNEMO_API_URL is
		empty.  Previously the module would import silently and default to the
		wrong production URL.
		"""
		monkeypatch.setenv("MNEMO_API_URL", "")

		# Remove cached module so re-import triggers module-level validation.
		for key in list(sys.modules.keys()):
			if "mnemo_mcp.http_app" in key:
				del sys.modules[key]

		with pytest.raises(SystemExit) as exc_info:
			import mnemo_mcp.http_app  # noqa: F401

		assert exc_info.value.code == 1, (
			f"Expected sys.exit(1) but got exit code {exc_info.value.code}"
		)

	def test_regression_http_app_exits_when_api_url_unset(self, monkeypatch):
		"""
		Regression: http_app.py must exit(1) when MNEMO_API_URL is not set
		at all (not just empty).
		"""
		monkeypatch.delenv("MNEMO_API_URL", raising=False)

		for key in list(sys.modules.keys()):
			if "mnemo_mcp.http_app" in key:
				del sys.modules[key]

		with pytest.raises(SystemExit) as exc_info:
			import mnemo_mcp.http_app  # noqa: F401

		assert exc_info.value.code == 1, (
			f"Expected sys.exit(1) but got exit code {exc_info.value.code}"
		)

	def test_http_app_imports_successfully_when_api_url_set(self, monkeypatch):
		"""
		http_app.py must NOT exit when a valid MNEMO_API_URL is present.
		"""
		monkeypatch.setenv("MNEMO_API_URL", "https://mnemo-api-bxkfuzweaq-uc.a.run.app")
		monkeypatch.setenv("MNEMO_API_TOKEN", "test-token")

		for key in list(sys.modules.keys()):
			if "mnemo_mcp.http_app" in key:
				del sys.modules[key]

		# Should not raise SystemExit
		import mnemo_mcp.http_app  # noqa: F401
		assert hasattr(mnemo_mcp.http_app, "app"), \
			"http_app.py must define an 'app' ASGI application"


class TestServerEnforceTransportPolicy:
	"""server.py enforce_transport_policy must reject empty/invalid URLs."""

	def test_regression_enforce_transport_policy_rejects_empty_string(self):
		"""
		Regression: enforce_transport_policy('') must raise RuntimeError.
		Previously a missing URL would default silently and route to the wrong host.
		"""
		from mnemo_mcp.core import enforce_transport_policy

		with pytest.raises(RuntimeError, match="Blocked scheme|scheme"):
			enforce_transport_policy("")

	def test_enforce_transport_policy_rejects_non_https(self):
		"""Non-loopback http:// URL must be rejected."""
		from mnemo_mcp.core import enforce_transport_policy

		with pytest.raises(RuntimeError):
			enforce_transport_policy("http://some-remote-host.example.com")

	def test_enforce_transport_policy_accepts_https(self):
		"""Valid https:// URL must not raise."""
		from mnemo_mcp.core import enforce_transport_policy

		# Should not raise
		enforce_transport_policy("https://mnemo-api-bxkfuzweaq-uc.a.run.app")

	def test_enforce_transport_policy_accepts_localhost(self):
		"""http://localhost is allowed for local dev."""
		from mnemo_mcp.core import enforce_transport_policy

		# Should not raise
		enforce_transport_policy("http://localhost:8080")
