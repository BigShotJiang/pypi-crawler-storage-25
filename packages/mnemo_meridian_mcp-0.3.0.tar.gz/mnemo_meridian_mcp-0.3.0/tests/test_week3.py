from __future__ import annotations

import json
from datetime import datetime, timezone

from backend.brief import BriefGenerator
from backend.profile import Profile
from backend.stats import compute_stats


def test_brief_empty_profile(tmp_path):
    """BriefGenerator returns empty list when no sessions exist."""
    (tmp_path / "memory").mkdir()
    (tmp_path / "memory" / "sessions.json").write_text("[]")
    (tmp_path / "skills.json").write_text('{"schema_version": 3, "layer": "individual", "skills": {}}')

    gen = BriefGenerator(tmp_path)
    assert gen.generate() == []


def test_brief_thread_card(tmp_path):
    """Session with open_threads generates a thread card."""
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    session = {
        "session_id": "test_001",
        "timestamp": now_str,
        "profile": "rags",
        "task_raw": "test task",
        "task_type": "general",
        "task_subtype": "general",
        "task_summary": "test",
        "open_threads": ["Follow up on budget approval"],
        "decisions": [],
        "key_entities": [],
        "memories_injected": 0,
    }
    (tmp_path / "memory").mkdir()
    (tmp_path / "memory" / "sessions.json").write_text(json.dumps([session]))
    (tmp_path / "skills.json").write_text('{"schema_version": 3, "layer": "individual", "skills": {}}')

    gen = BriefGenerator(tmp_path)
    cards = gen.generate()
    assert len(cards) == 1
    assert cards[0]["type"] == "thread"
    assert "Follow up" in cards[0]["title"]


def test_stats_basic(tmp_path):
    """compute_stats returns dict with expected keys and correct types."""
    (tmp_path / "memory").mkdir()
    (tmp_path / "memory" / "sessions.json").write_text("[]")
    (tmp_path / "skills.json").write_text('{"schema_version": 3, "layer": "individual", "skills": {}}')

    stats = compute_stats(tmp_path)
    required_keys = [
        "total_sessions",
        "skills_graduated",
        "total_memories_injected",
        "total_input_tokens",
        "total_output_tokens",
        "acceptance_rate",
    ]
    for key in required_keys:
        assert key in stats


def test_delete_session(tmp_path):
    """delete_session removes session from sessions.json."""
    session = {
        "session_id": "del_001",
        "task_raw": "test",
        "timestamp": "2026-01-01T00:00:00Z",
        "schema_version": 3,
        "task_type": "general",
        "task_subtype": "general",
        "task_summary": "test",
        "key_output": "",
        "key_entities": [],
        "decisions": [],
        "open_threads": [],
        "quality_signal": "accepted",
        "acceptance_score": 2,
        "skills_used": [],
        "tokens_input": 0,
        "tokens_output": 0,
        "backend": "api",
        "qwen_confidence": 1.0,
        "memories_injected": 0,
        "sensitive_session": False,
    }
    (tmp_path / "memory").mkdir()
    (tmp_path / "memory" / "sessions.json").write_text(json.dumps([session]))
    meta = {
        "schema_version": 1,
        "name": "test",
        "display_name": "test",
        "role": "test",
        "persona_base": "test",
        "sensitive_domain": False,
        "joined_date": "2026-01-01",
        "last_active": "2026-01-01T00:00:00Z",
        "pin_hash": None,
        "status": "active",
    }
    (tmp_path / "meta.json").write_text(json.dumps(meta))
    (tmp_path / "identity.md").write_text("identity")
    (tmp_path / "skills.json").write_text('{"schema_version": 3, "layer": "individual", "skills": {}}')

    profile = Profile.load(tmp_path.parent, tmp_path.name, allowed_profiles={tmp_path.name})
    profile.delete_session("del_001")

    remaining = profile.load_sessions()
    assert not any(s.get("session_id") == "del_001" for s in remaining)


def test_qwen_json_extraction():
    """_extract_json handles preamble before JSON."""
    from backend.summarizer import QwenSummarizer

    s = QwenSummarizer(ollama_url="http://localhost:11434")
    preamble_input = (
        'Here is the JSON you requested:\n'
        '{"task_summary": "test", "key_entities": [], "decisions": [], "open_threads": [], "confidence": 0.9}'
    )
    result = s._extract_json(preamble_input)
    assert result is not None
    assert result["task_summary"] == "test"
    assert result["confidence"] == 0.9
