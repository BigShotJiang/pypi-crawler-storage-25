"""Tests for mcp_attest backends — InMemoryBackend and PersistentBackend."""
import json
import os
import tempfile
import threading
import time
import pytest

from mcp_attest.backends.memory import InMemoryBackend
from mcp_attest.backends.persistent import PersistentBackend


# ── InMemoryBackend ───────────────────────────────────────────────────────────

def test_memory_backend_appends_in_order():
	b = InMemoryBackend()
	b.append({"seq": 0})
	b.append({"seq": 1})
	b.append({"seq": 2})
	leaves = b.get_range(None, None)
	assert [l["seq"] for l in leaves] == [0, 1, 2]


def test_memory_backend_get_range_from_to():
	b = InMemoryBackend()
	for i in range(5):
		b.append({"seq": i})
	assert [l["seq"] for l in b.get_range(1, 3)] == [1, 2, 3]
	assert [l["seq"] for l in b.get_range(0, 0)] == [0]
	assert [l["seq"] for l in b.get_range(4, None)] == [4]


def test_memory_backend_count():
	b = InMemoryBackend()
	assert b.count() == 0
	b.append({"x": 1})
	assert b.count() == 1


def test_memory_backend_raises_on_max_leaves_exceeded():
	b = InMemoryBackend()
	b.MAX_LEAVES = 3
	b.append({"i": 0})
	b.append({"i": 1})
	b.append({"i": 2})
	with pytest.raises(RuntimeError, match="exceeded"):
		b.append({"i": 3})


def test_memory_backend_is_thread_safe_under_concurrent_writes():
	"""50 threads appending simultaneously must not corrupt the count."""
	b = InMemoryBackend()
	lock = threading.Lock()

	def worker():
		with lock:
			b.append({"thread": threading.get_ident()})

	threads = [threading.Thread(target=worker) for _ in range(50)]
	for t in threads:
		t.start()
	for t in threads:
		t.join()

	assert b.count() == 50


# ── PersistentBackend ─────────────────────────────────────────────────────────

def test_persistent_backend_survives_reload():
	with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
		path = f.name
	try:
		# Write leaves then close
		b1 = PersistentBackend(path)
		b1.append({"seq": 0, "data": "first"})
		b1.append({"seq": 1, "data": "second"})
		b1.close()

		# Reopen and verify leaves are intact
		b2 = PersistentBackend(path)
		leaves = b2.get_range(None, None)
		b2.close()

		assert len(leaves) == 2
		assert leaves[0]["data"] == "first"
		assert leaves[1]["data"] == "second"
	finally:
		os.unlink(path)


def test_persistent_backend_file_is_append_only_mode():
	"""File descriptor must be opened with O_APPEND (cannot seek to beginning)."""
	with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
		path = f.name
	try:
		b = PersistentBackend(path)
		b.append({"seq": 0})
		# O_APPEND: seeking to 0 and writing would not overwrite — but with O_WRONLY | O_APPEND
		# os.lseek raises on some systems or is ignored on write. We verify
		# the file contains exactly 1 JSONL line (not truncated or corrupted).
		b.close()
		with open(path) as f:
			lines = [l for l in f.readlines() if l.strip()]
		assert len(lines) == 1
	finally:
		os.unlink(path)


def test_persistent_backend_raises_on_max_leaves_exceeded():
	with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
		path = f.name
	try:
		b = PersistentBackend(path)
		b.MAX_LEAVES = 2
		b.append({"seq": 0})
		b.append({"seq": 1})
		with pytest.raises(RuntimeError):
			b.append({"seq": 2})
		b.close()
	finally:
		os.unlink(path)


def test_perf_persistent_backend_fsync_under_50ms():
	"""Single append+fsync must complete within 50ms on local disk."""
	with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
		path = f.name
	try:
		b = PersistentBackend(path)
		b.append({"seq": 0, "data": "perf test"})
		assert b.last_fsync_ms < 50, f"fsync took {b.last_fsync_ms:.1f}ms (limit: 50ms)"
		b.close()
	finally:
		os.unlink(path)
