"""
Growth telemetry integration tests.

Run with:  pytest tests/test_growth.py -v
Requires the backend venv active and PostgreSQL running.

Tests are skipped automatically if the DB is unreachable so CI
won't fail in environments without a database.
"""
from __future__ import annotations

import json
import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio

# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_mock_conn(fetchval_return=None, fetch_return=None, execute_return=None):
    """Return a mock asyncpg connection."""
    conn = AsyncMock()
    conn.fetchval = AsyncMock(return_value=fetchval_return)
    conn.fetch = AsyncMock(return_value=fetch_return or [])
    conn.fetchrow = AsyncMock(return_value=None)
    conn.execute = AsyncMock(return_value=execute_return)
    return conn


def _make_mock_pool(conn):
    """Return a mock asyncpg pool whose acquire() yields conn."""
    pool = MagicMock()
    pool.acquire = MagicMock(return_value=AsyncMock(
        __aenter__=AsyncMock(return_value=conn),
        __aexit__=AsyncMock(return_value=False),
    ))
    return pool


# ─────────────────────────────────────────────────────────────────────────────
# 1. Pure-Python unit tests (no DB, no network)
# ─────────────────────────────────────────────────────────────────────────────

class TestScrubReferrer:
    """_scrub_referrer must strip path/query and return hostname only."""

    def setup_method(self):
        from backend.routers.events import _scrub_referrer
        self.scrub = _scrub_referrer

    def test_strips_path_and_query(self):
        assert self.scrub("https://google.com/search?q=secret") == "google.com"

    def test_strips_port(self):
        # urlparse keeps port in netloc; that's fine — no PII there
        result = self.scrub("https://example.com:8080/page?token=abc")
        assert "token" not in result
        assert "example.com" in result

    def test_none_returns_none(self):
        assert self.scrub(None) is None

    def test_empty_returns_none(self):
        assert self.scrub("") is None

    def test_malformed_url_returns_none(self):
        # urlparse is lenient; as long as we don't crash, it's OK
        result = self.scrub("not a url at all !!!")
        # Should either return None or some non-PII string
        assert result is None or "!" not in result

    def test_relative_url_returns_none(self):
        assert self.scrub("/internal/page") is None


class TestAllowedEventTypes:
    """Unknown event types must be silently dropped."""

    @pytest.mark.asyncio
    async def test_unknown_type_returns_ignored(self):
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        from backend.routers.events import router

        app = FastAPI()
        app.include_router(router)

        # Mock db.get_pool so the endpoint doesn't need a real DB
        with patch("backend.routers.events.db") as mock_db:
            mock_conn = _make_mock_conn()
            mock_db.get_pool = AsyncMock(return_value=_make_mock_pool(mock_conn))

            with TestClient(app) as client:
                resp = client.post("/api/events", json={
                    "event_type": "totally_made_up_type",
                    "anonymous_session_id": "test-sid",
                })
                assert resp.status_code == 200
                assert resp.json()["status"] == "ignored"
                # DB must NOT have been called
                mock_conn.execute.assert_not_called()

    @pytest.mark.asyncio
    async def test_valid_type_calls_db(self):
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        from backend.routers.events import router

        app = FastAPI()
        app.include_router(router)

        with patch("backend.routers.events.db") as mock_db:
            mock_conn = _make_mock_conn()
            mock_db.get_pool = AsyncMock(return_value=_make_mock_pool(mock_conn))

            with TestClient(app) as client:
                resp = client.post("/api/events", json={
                    "event_type": "page_view",
                    "anonymous_session_id": "test-sid",
                    "page": "/today",
                })
                assert resp.status_code == 202
                assert resp.json()["status"] == "accepted"
                mock_conn.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_db_failure_still_returns_accepted(self):
        """Telemetry must never surface errors to callers."""
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        from backend.routers.events import router

        app = FastAPI()
        app.include_router(router)

        with patch("backend.routers.events.db") as mock_db:
            mock_db.get_pool = AsyncMock(side_effect=Exception("DB is down"))

            with TestClient(app) as client:
                resp = client.post("/api/events", json={
                    "event_type": "page_view",
                    "page": "/today",
                })
                assert resp.status_code == 202
                assert resp.json()["status"] == "accepted"


class TestEventIdempotency:
    """Duplicate event_ids must not crash (ON CONFLICT DO NOTHING)."""

    @pytest.mark.asyncio
    async def test_same_event_id_twice_is_safe(self):
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        from backend.routers.events import router

        app = FastAPI()
        app.include_router(router)
        eid = str(uuid.uuid4())

        with patch("backend.routers.events.db") as mock_db:
            mock_conn = _make_mock_conn()
            mock_db.get_pool = AsyncMock(return_value=_make_mock_pool(mock_conn))

            with TestClient(app) as client:
                payload = {"event_type": "login", "event_id": eid, "page": "/today"}
                r1 = client.post("/api/events", json=payload)
                r2 = client.post("/api/events", json=payload)
                assert r1.status_code == 202
                assert r2.status_code == 202


# ─────────────────────────────────────────────────────────────────────────────
# 2. Growth admin endpoint unit tests (mocked DB)
# ─────────────────────────────────────────────────────────────────────────────

class TestGrowthOverview:
    """GET /admin/growth/overview returns expected shape."""

    @pytest.mark.asyncio
    async def test_overview_shape(self):
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        from backend.routers.growth_admin import router

        app = FastAPI()
        app.include_router(router)

        with patch("backend.routers.growth_admin.db") as mock_db, \
             patch("backend.routers.growth_admin._require_app_admin", return_value="admin"):

            conn = _make_mock_conn()
            # fetchval returns: signups_7d, signups_30d, total, activation_cohort,
            # activated_count, eligible_for_retention, retained_7d, paid_count
            conn.fetchval = AsyncMock(side_effect=[10, 45, 120, 8, 5, 100, 22, 15])
            mock_db.get_pool = AsyncMock(return_value=_make_mock_pool(conn))

            with TestClient(app) as client:
                resp = client.get("/admin/growth/overview")
                assert resp.status_code == 200
                body = resp.json()
                assert "signups_7d" in body
                assert "activation_rate_7d" in body
                assert "d7_retention" in body
                assert "tier_conversion_rate" in body
                assert body["signups_7d"] == 10
                assert body["signups_30d"] == 45


class TestGrowthFunnel:
    """GET /admin/growth/funnel returns 4 stages in order."""

    @pytest.mark.asyncio
    async def test_funnel_stage_order(self):
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        from backend.routers.growth_admin import router

        app = FastAPI()
        app.include_router(router)

        with patch("backend.routers.growth_admin.db") as mock_db, \
             patch("backend.routers.growth_admin._require_app_admin", return_value="admin"), \
             patch("backend.routers.growth_admin._table_exists", new=AsyncMock(return_value=True)):

            conn = _make_mock_conn()
            # registered=100, activated=60, engaged=30, converted=10
            conn.fetchval = AsyncMock(side_effect=[100, 60, 30, 10])
            mock_db.get_pool = AsyncMock(return_value=_make_mock_pool(conn))

            with TestClient(app) as client:
                resp = client.get("/admin/growth/funnel?window_days=30")
                assert resp.status_code == 200
                stages = resp.json()["stages"]
                assert len(stages) == 4
                assert stages[0]["stage"] == "registered"
                assert stages[1]["stage"] == "activated"
                assert stages[2]["stage"] == "engaged"
                assert stages[3]["stage"] == "converted"
                # Percentages should decrease down the funnel
                assert stages[0]["pct_of_registered"] == 100.0
                assert stages[1]["pct_of_registered"] == 60.0
                assert stages[2]["pct_of_registered"] == 30.0

    def test_funnel_invalid_window(self):
        """Non-integer window_days causes 422."""
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        from backend.routers.growth_admin import router

        app = FastAPI()
        app.include_router(router)

        with patch("backend.routers.growth_admin._require_app_admin", return_value="admin"):
            with TestClient(app) as client:
                resp = client.get("/admin/growth/signups?window_days=999")
                assert resp.status_code == 422


class TestGrowthSignups:
    """GET /admin/growth/signups returns days array with ma7."""

    @pytest.mark.asyncio
    async def test_signups_ma7_present(self):
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        from backend.routers.growth_admin import router

        app = FastAPI()
        app.include_router(router)

        mock_rows = [
            {"day": "2026-03-30 00:00:00+00", "count": 5},
            {"day": "2026-03-31 00:00:00+00", "count": 8},
            {"day": "2026-04-01 00:00:00+00", "count": 3},
        ]

        with patch("backend.routers.growth_admin.db") as mock_db, \
             patch("backend.routers.growth_admin._require_app_admin", return_value="admin"):

            conn = _make_mock_conn(fetch_return=mock_rows)
            mock_db.get_pool = AsyncMock(return_value=_make_mock_pool(conn))

            with TestClient(app) as client:
                resp = client.get("/admin/growth/signups?window_days=7")
                assert resp.status_code == 200
                body = resp.json()
                assert "days" in body
                for d in body["days"]:
                    assert "ma7" in d
                    assert "count" in d


# ─────────────────────────────────────────────────────────────────────────────
# 3. Record activation helper
# ─────────────────────────────────────────────────────────────────────────────

class TestRecordActivation:
    """record_activation is idempotent and never raises."""

    @pytest.mark.asyncio
    async def test_activation_calls_insert(self):
        from backend.routers.events import record_activation

        with patch("backend.routers.events.db") as mock_db:
            conn = _make_mock_conn()
            mock_db.get_pool = AsyncMock(return_value=_make_mock_pool(conn))
            await record_activation("testprofile")
            conn.execute.assert_called_once()
            # Verify ON CONFLICT clause present in the SQL
            sql_call = conn.execute.call_args[0][0]
            assert "ON CONFLICT" in sql_call

    @pytest.mark.asyncio
    async def test_activation_db_failure_does_not_raise(self):
        """Growth analytics must never raise into the MCP path."""
        from backend.routers.events import record_activation

        with patch("backend.routers.events.db") as mock_db:
            mock_db.get_pool = AsyncMock(side_effect=Exception("DB down"))
            # Must not raise
            await record_activation("testprofile")


# ─────────────────────────────────────────────────────────────────────────────
# 4. Live DB integration tests (skipped if DB unreachable)
# ─────────────────────────────────────────────────────────────────────────────

DB_AVAILABLE = False
try:
    import asyncio, asyncpg
    asyncio.get_event_loop().run_until_complete(
        asyncpg.connect("postgresql://127.0.0.1/mnemo", timeout=2)
    )
    DB_AVAILABLE = True
except Exception:
    pass


@pytest.mark.skipif(not DB_AVAILABLE, reason="PostgreSQL not available")
class TestLiveDB:
    """Integration tests against the real database."""

    @pytest.mark.asyncio
    async def test_marketing_events_table_exists(self):
        import asyncpg
        conn = await asyncpg.connect("postgresql://127.0.0.1/mnemo")
        try:
            row = await conn.fetchrow(
                "SELECT 1 FROM information_schema.tables WHERE table_name = 'marketing_events'"
            )
            assert row is not None, "marketing_events table missing — run db.init_db_sync()"

            row2 = await conn.fetchrow(
                "SELECT 1 FROM information_schema.tables WHERE table_name = 'conversion_events'"
            )
            assert row2 is not None, "conversion_events table missing"
        finally:
            await conn.close()

    @pytest.mark.asyncio
    async def test_event_insert_and_idempotency(self):
        import asyncpg
        conn = await asyncpg.connect("postgresql://127.0.0.1/mnemo")
        eid = f"test-{uuid.uuid4()}"
        try:
            # First insert
            await conn.execute(
                """
                INSERT INTO marketing_events (event_id, event_type, page, created_at)
                VALUES ($1, 'page_view', '/test', NOW())
                ON CONFLICT (event_id) DO NOTHING
                """,
                eid,
            )
            count_after_first = await conn.fetchval(
                "SELECT COUNT(*) FROM marketing_events WHERE event_id = $1", eid
            )
            assert count_after_first == 1

            # Second insert with same event_id — ON CONFLICT DO NOTHING
            await conn.execute(
                """
                INSERT INTO marketing_events (event_id, event_type, page, created_at)
                VALUES ($1, 'page_view', '/test', NOW())
                ON CONFLICT (event_id) DO NOTHING
                """,
                eid,
            )
            count_after_second = await conn.fetchval(
                "SELECT COUNT(*) FROM marketing_events WHERE event_id = $1", eid
            )
            assert count_after_second == 1, "Idempotency violated — duplicate row inserted"
        finally:
            # Cleanup test row
            await conn.execute("DELETE FROM marketing_events WHERE event_id = $1", eid)
            await conn.close()

    @pytest.mark.asyncio
    async def test_conversion_events_unique_constraint(self):
        import asyncpg
        conn = await asyncpg.connect("postgresql://127.0.0.1/mnemo")
        profile = f"_test_{uuid.uuid4().hex[:8]}"
        try:
            # Insert twice with same profile/stage — second must be silently ignored
            for _ in range(2):
                await conn.execute(
                    """
                    INSERT INTO conversion_events (profile_id, funnel_stage, days_to_reach)
                    VALUES ($1, 'activated', 1.5)
                    ON CONFLICT (profile_id, funnel_stage) DO NOTHING
                    """,
                    profile,
                )
            count = await conn.fetchval(
                "SELECT COUNT(*) FROM conversion_events WHERE profile_id = $1", profile
            )
            assert count == 1, "UNIQUE constraint on (profile_id, funnel_stage) not working"
        finally:
            await conn.execute("DELETE FROM conversion_events WHERE profile_id = $1", profile)
            await conn.close()

    @pytest.mark.asyncio
    async def test_growth_overview_endpoint_live(self):
        """End-to-end: start app, hit /admin/growth/overview with admin token."""
        # This test requires MNEMO_APP_ADMIN_PROFILES to include 'admin'
        # and a valid admin JWT token in the environment.
        import os
        admin_token = os.getenv("MNEMO_TEST_ADMIN_TOKEN", "")
        if not admin_token:
            pytest.skip("MNEMO_TEST_ADMIN_TOKEN not set")

        import httpx
        async with httpx.AsyncClient(base_url="http://127.0.0.1:7432") as client:
            resp = await client.get(
                "/admin/growth/overview",
                headers={"Authorization": f"Bearer {admin_token}"},
            )
            assert resp.status_code == 200
            body = resp.json()
            assert "signups_7d" in body
            assert "activation_rate_7d" in body
