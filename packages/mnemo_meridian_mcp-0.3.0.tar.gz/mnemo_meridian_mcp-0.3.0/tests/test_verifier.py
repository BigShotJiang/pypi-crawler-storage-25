"""Tests for ChainVerifier — chain integrity, tamper detection, call pairing."""
import copy
import pytest

from mcp_attest.log import SessionAttestationLog
from mcp_attest.verifier import ChainVerifier, VerificationResult


def _make_chain(num_calls: int = 2) -> tuple[list[dict], dict]:
	"""Build a valid chain with num_calls tool calls. Returns (leaves, public_key_jwk)."""
	log = SessionAttestationLog()
	for i in range(num_calls):
		log.append_tool_call_received(f"c{i}", "tool", {"i": i}, f"req_{i}")
		log.append_tool_call_delivered(f"c{i}", "tool", {"r": i}, False, 5)
	root = log.session_root_leaf()
	return log.get_leaves(), root["server_public_key"]


def test_valid_chain_returns_is_valid_true():
	leaves, jwk = _make_chain(3)
	result = ChainVerifier().verify(leaves, jwk)
	assert result.is_valid is True
	assert result.error is None
	assert result.leaves_verified == len(leaves)


def test_chain_with_gap_in_sequence_returns_invalid():
	leaves, jwk = _make_chain(2)
	# Skip leaf at index 2 — create a gap
	gapped = [leaves[0], leaves[1], leaves[3]]
	result = ChainVerifier().verify(gapped, jwk)
	assert result.is_valid is False
	assert "gap" in result.error.lower() or "sequence" in result.error.lower()


def test_chain_with_wrong_prev_leaf_id_returns_invalid():
	leaves, jwk = _make_chain(2)
	tampered = copy.deepcopy(leaves)
	tampered[2]["prev_leaf_id"] = "leaf_9999999999999999"
	result = ChainVerifier().verify(tampered, jwk)
	assert result.is_valid is False
	assert "prev_leaf_id" in result.error.lower()


def test_chain_with_tampered_leaf_content_returns_invalid():
	"""Modify a leaf's content AFTER signing — must fail signature check."""
	leaves, jwk = _make_chain(1)
	tampered = copy.deepcopy(leaves)
	# Modify content of leaf 1 (tool_call_received) after it was signed
	tampered[1]["tool_name"] = "INJECTED_TOOL"
	result = ChainVerifier().verify(tampered, jwk)
	assert result.is_valid is False
	assert "signature" in result.error.lower() or "log_root" in result.error.lower()


def test_chain_with_wrong_signature_returns_invalid():
	leaves, jwk = _make_chain(1)
	tampered = copy.deepcopy(leaves)
	tampered[1]["signature"] = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
	result = ChainVerifier().verify(tampered, jwk)
	assert result.is_valid is False
	assert "signature" in result.error.lower()


def test_chain_with_wrong_log_root_returns_invalid():
	leaves, jwk = _make_chain(1)
	tampered = copy.deepcopy(leaves)
	tampered[1]["log_root"] = "sha256:0000000000000000000000000000000000000000000000000000000000000000"
	result = ChainVerifier().verify(tampered, jwk)
	assert result.is_valid is False
	# log_root check or signature check catches it
	assert result.is_valid is False


def test_unpaired_tool_call_received_returns_invalid():
	log = SessionAttestationLog()
	log.append_tool_call_received("c1", "tool", {}, "req_1")
	# Intentionally do NOT append delivered — get leaves mid-call
	leaves = log.get_leaves()
	jwk = log.session_root_leaf()["server_public_key"]
	result = ChainVerifier().verify(leaves, jwk)
	assert result.is_valid is False
	assert "unpaired" in result.error.lower()


def test_regression_signature_valid_but_log_root_wrong_is_caught():
	"""A leaf where signature is valid but log_root was computed from wrong prev must fail."""
	leaves, jwk = _make_chain(2)
	tampered = copy.deepcopy(leaves)
	# Replace log_root on leaf 2 with leaf 1's log_root (wrong but plausible)
	tampered[2]["log_root"] = tampered[1]["log_root"]
	result = ChainVerifier().verify(tampered, jwk)
	assert result.is_valid is False


def test_empty_leaf_list_returns_invalid():
	result = ChainVerifier().verify([], {"kty": "EC", "crv": "P-256", "x": "", "y": "", "kid": ""})
	assert result.is_valid is False
	assert "empty" in result.error.lower()


def test_first_leaf_not_session_root_returns_invalid():
	leaves, jwk = _make_chain(1)
	result = ChainVerifier().verify(leaves[1:], jwk)  # skip root
	assert result.is_valid is False


def test_valid_10_leaf_chain():
	"""ChainVerifier must return is_valid=True on a 10-leaf chain (5 tool calls)."""
	leaves, jwk = _make_chain(5)
	result = ChainVerifier().verify(leaves, jwk)
	assert result.is_valid is True
	assert result.leaves_verified == 11  # 1 root + 5*2
