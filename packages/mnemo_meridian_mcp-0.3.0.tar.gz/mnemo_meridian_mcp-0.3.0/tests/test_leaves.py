"""Tests for mcp_attest.leaves — leaf ID, content hash, log root computation."""
import hashlib
import json
import pytest

from mcp_attest.leaves import (
	INITIAL_LOG_ROOT,
	compute_log_root,
	content_hash,
	leaf_id,
	utc_now,
)


def test_leaf_id_zero_padded_16_digits():
	assert leaf_id(0) == "leaf_0000000000000000"
	assert leaf_id(1) == "leaf_0000000000000001"
	assert leaf_id(9999999999999999) == "leaf_9999999999999999"


def test_initial_log_root_is_sha256_of_empty_string():
	expected = f"sha256:{hashlib.sha256(b'').hexdigest()}"
	assert INITIAL_LOG_ROOT == expected


def test_content_hash_returns_sha256_prefix():
	obj = {"key": "value"}
	h = content_hash(obj)
	assert h.startswith("sha256:")
	canonical = json.dumps(obj, sort_keys=True).encode()
	expected = f"sha256:{hashlib.sha256(canonical).hexdigest()}"
	assert h == expected


def test_content_hash_is_deterministic():
	obj = {"b": 2, "a": 1}
	assert content_hash(obj) == content_hash(obj)
	# sort_keys=True means key order doesn't affect hash
	assert content_hash({"a": 1, "b": 2}) == content_hash({"b": 2, "a": 1})


def test_compute_log_root_deterministic():
	leaf = {"leaf_type": "session_root", "sequence": 0}
	r1 = compute_log_root(INITIAL_LOG_ROOT, leaf_id(0), leaf)
	r2 = compute_log_root(INITIAL_LOG_ROOT, leaf_id(0), leaf)
	assert r1 == r2
	assert r1.startswith("sha256:")


def test_compute_log_root_changes_with_each_leaf():
	leaf0 = {"leaf_type": "session_root", "sequence": 0}
	leaf1 = {"leaf_type": "tool_call_received", "sequence": 1, "tool_name": "foo"}
	r0 = compute_log_root(INITIAL_LOG_ROOT, leaf_id(0), leaf0)
	r1 = compute_log_root(r0, leaf_id(1), leaf1)
	assert r0 != r1
	assert r1 != INITIAL_LOG_ROOT


def test_compute_log_root_advances_over_n_leaves():
	"""Log root must be unique and strictly advancing for every leaf in a chain."""
	roots = [INITIAL_LOG_ROOT]
	for i in range(10):
		leaf = {"leaf_type": "tool_call_received", "sequence": i, "call_id": f"c{i}"}
		new_root = compute_log_root(roots[-1], leaf_id(i), leaf)
		assert new_root not in roots, f"Root repeated at sequence {i}"
		roots.append(new_root)
	assert len(set(roots)) == 11  # all unique


def test_utc_now_format():
	ts = utc_now()
	assert ts.endswith("Z")
	assert "T" in ts
	# Should parse without error
	import datetime
	datetime.datetime.fromisoformat(ts.replace("Z", "+00:00"))
