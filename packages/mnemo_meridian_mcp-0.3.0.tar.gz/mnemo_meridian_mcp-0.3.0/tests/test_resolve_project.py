"""Unit tests for _resolve_project and project-inference in MCP tool handlers.

Tests cover:
  - _resolve_project helper: explicit arg, CWD inference, General fallback
  - Regression: each handler that was previously conditional now always sends project
  - No handler silently omits project from the API call params/body
"""
from __future__ import annotations

import sys
import types
import unittest
from typing import Any, Dict
from unittest.mock import MagicMock, call, patch

# ---------------------------------------------------------------------------
# Bootstrap: mnemo_mcp.server imports several optional heavy deps at module
# level.  Stub them out so tests run without installing the full stack.
# ---------------------------------------------------------------------------
for mod in (
	"mcp",
	"mcp.server",
	"mcp.server.stdio",
	"mcp.server.models",
	"mcp.types",
	"anthropic",
):
	if mod not in sys.modules:
		sys.modules[mod] = types.ModuleType(mod)

# mcp.server needs a FastMCP attr used at import time
import mcp.server as _mcp_server  # noqa: E402
if not hasattr(_mcp_server, "FastMCP"):
	_mcp_server.FastMCP = MagicMock()  # type: ignore[attr-defined]

import importlib  # noqa: E402

server = importlib.import_module("mnemo_mcp.server")

_resolve_project = server._resolve_project
_infer_project_from_cwd = server._infer_project_from_cwd
_handle_search_memory = server._handle_search_memory
_handle_get_open_threads = server._handle_get_open_threads
_handle_get_decisions = server._handle_get_decisions
_handle_get_entities = server._handle_get_entities
_handle_log_session = server._handle_log_session
_handle_log_decision = server._handle_log_decision
_handle_get_recent_changes = server._handle_get_recent_changes
_handle_get_stale_decisions = server._handle_get_stale_decisions
_handle_get_blocked_decisions = server._handle_get_blocked_decisions
_handle_get_session_handoff_brief = server._handle_get_session_handoff_brief


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _empty_api(*_a, **_kw) -> Dict[str, Any]:
	"""Minimal stub that silences handlers without hitting the network."""
	return {}


def _list_api(*_a, **_kw):
	return []


# ---------------------------------------------------------------------------
# _resolve_project unit tests
# ---------------------------------------------------------------------------

class TestResolveProject(unittest.TestCase):

	def test_explicit_project_returned_as_is(self):
		assert _resolve_project({"project": "my-proj"}) == "my-proj"

	def test_explicit_project_takes_priority_over_cwd(self):
		with patch.object(server, "_infer_project_from_cwd", return_value="cwd-proj"):
			assert _resolve_project({"project": "explicit"}) == "explicit"

	def test_cwd_inference_used_when_no_arg(self):
		with patch.object(server, "_infer_project_from_cwd", return_value="inferred"):
			assert _resolve_project({}) == "inferred"

	def test_general_fallback_when_no_arg_and_no_cwd(self):
		with patch.object(server, "_infer_project_from_cwd", return_value=None):
			assert _resolve_project({}) == "General"

	def test_empty_string_project_arg_falls_through_to_general(self):
		"""Empty string is falsy — should fall through to General."""
		with patch.object(server, "_infer_project_from_cwd", return_value=None):
			assert _resolve_project({"project": ""}) == "General"

	def test_regression_none_project_arg_falls_through_to_general(self):
		"""None project should not be forwarded to API."""
		with patch.object(server, "_infer_project_from_cwd", return_value=None):
			assert _resolve_project({"project": None}) == "General"


# ---------------------------------------------------------------------------
# Per-handler regression tests: project is ALWAYS present in API call
# ---------------------------------------------------------------------------

class TestHandlerAlwaysSendsProject(unittest.TestCase):
	"""Regression: before fix, handlers omitted project when arg was absent."""

	def _captured_params(self, captured: list[tuple]) -> Dict[str, Any]:
		"""Extract query-string dict from urllib.parse.urlencode call args."""
		assert captured, "No API call was recorded"
		url_arg = captured[0][0][1]  # positional arg 1 (path + qs or body)
		if "?" in url_arg:
			import urllib.parse
			return dict(urllib.parse.parse_qsl(url_arg.split("?", 1)[1]))
		return {}

	# -- search_memory -------------------------------------------------------

	def test_regression_search_memory_sends_project_when_missing(self):
		calls: list = []
		def fake_api(method, path, body=None, **kw):
			calls.append((method, path, body))
			return {"context_block": "", "sources": [], "token_estimate": 0}

		with patch.object(server, "_api_call", side_effect=fake_api), \
		     patch.object(server, "_resolve_project", return_value="General"), \
		     patch.object(server, "_record_mcp_usage", return_value={}):
			_handle_search_memory({"query": "test"})

		body = calls[0][2]
		assert body.get("project") == "General"

	def test_search_memory_forwards_explicit_project(self):
		calls: list = []
		def fake_api(method, path, body=None, **kw):
			calls.append((method, path, body))
			return {"context_block": "", "sources": [], "token_estimate": 0}

		with patch.object(server, "_api_call", side_effect=fake_api), \
		     patch.object(server, "_record_mcp_usage", return_value={}):
			_handle_search_memory({"query": "test", "project": "mnemo"})

		body = calls[0][2]
		assert body.get("project") == "mnemo"

	# ---------------------------------------------------------------------------
	# Shared helper: patch profile path + api_call + cwd inference, capture
	# the URL passed to _api_call, return its query-string as a dict.
	# ---------------------------------------------------------------------------

	def _run_handler_capture_qs(self, handler, extra_args=None, project_arg=None, api_returns=None):
		"""Call handler with optional project arg, return parsed QS dict from captured URL."""
		import urllib.parse as _up
		captured: list = []
		if api_returns is None:
			api_returns = []

		def fake_api(method, path, body=None, **kw):
			captured.append((path, body))
			return api_returns

		args = dict(extra_args or {})
		if project_arg is not None:
			args["project"] = project_arg

		with patch.object(server, "_api_call", side_effect=fake_api), \
		     patch.object(server, "_profile_path", side_effect=lambda p: f"/profile/rags{p}"), \
		     patch.object(server, "_infer_project_from_cwd", return_value=None), \
		     patch.object(server, "_record_mcp_usage", return_value={}):
			handler(args)

		assert captured, f"No API call was made by {handler.__name__}"
		path = captured[0][0]
		qs = path.split("?", 1)[1] if "?" in path else ""
		return dict(_up.parse_qsl(qs))

	def _run_handler_capture_body(self, handler, extra_args=None, project_arg=None):
		"""Call handler with optional project arg, return POST body dict."""
		captured: list = []

		def fake_api(method, path, body=None, **kw):
			captured.append(body or {})
			return {}

		args = dict(extra_args or {})
		if project_arg is not None:
			args["project"] = project_arg

		return captured, args

	# -- get_open_threads ----------------------------------------------------

	def _threads_params(self, project_arg=None):
		return self._run_handler_capture_qs(_handle_get_open_threads, project_arg=project_arg)

	def test_regression_get_open_threads_sends_general_when_no_project(self):
		assert self._threads_params().get("project") == "General"

	def test_get_open_threads_forwards_explicit_project(self):
		assert self._threads_params("mnemo").get("project") == "mnemo"

	# -- get_decisions -------------------------------------------------------

	def _decisions_params(self, project_arg=None):
		return self._run_handler_capture_qs(_handle_get_decisions, project_arg=project_arg)

	def test_regression_get_decisions_sends_general_when_no_project(self):
		assert self._decisions_params().get("project") == "General"

	def test_get_decisions_forwards_explicit_project(self):
		assert self._decisions_params("mnemo").get("project") == "mnemo"

	# -- get_entities --------------------------------------------------------

	def _entities_params(self, project_arg=None):
		return self._run_handler_capture_qs(_handle_get_entities, project_arg=project_arg)

	def test_regression_get_entities_sends_general_when_no_project(self):
		assert self._entities_params().get("project") == "General"

	def test_get_entities_forwards_explicit_project(self):
		assert self._entities_params("my-proj").get("project") == "my-proj"

	# -- log_session ---------------------------------------------------------

	def _log_session_body(self, project_arg=None):
		captured: list = []
		def fake_api(method, path, body=None, **kw):
			captured.append(body or {})
			return {"session_id": "s1"}

		args = {"task": "t", "output": "o"}
		if project_arg is not None:
			args["project"] = project_arg

		with patch.object(server, "_api_call", side_effect=fake_api), \
		     patch.object(server, "_profile_path", side_effect=lambda p: f"/profile/rags{p}"), \
		     patch.object(server, "_infer_project_from_cwd", return_value=None), \
		     patch.object(server, "_resolve_profile_write", return_value="rags"), \
		     patch.object(server, "_record_mcp_usage", return_value={}):
			_handle_log_session(args)

		return captured[0] if captured else {}

	def test_regression_log_session_sends_general_when_no_project(self):
		body = self._log_session_body()
		assert body.get("project") == "General"
		assert body.get("project_id") == "General"

	def test_log_session_project_and_project_id_match(self):
		body = self._log_session_body("mnemo")
		assert body.get("project") == "mnemo"
		assert body.get("project_id") == "mnemo"

	# -- log_decision --------------------------------------------------------

	def _log_decision_body(self, project_arg=None):
		captured: list = []
		def fake_api(method, path, body=None, **kw):
			captured.append(body or {})
			return {"decision_id": "d1"}

		args = {"content": "We will use GCP", "domain": "strategy"}
		if project_arg is not None:
			args["project"] = project_arg

		with patch.object(server, "_api_call", side_effect=fake_api), \
		     patch.object(server, "_profile_path", side_effect=lambda p: f"/profile/rags{p}"), \
		     patch.object(server, "_infer_project_from_cwd", return_value=None), \
		     patch.object(server, "_record_mcp_usage", return_value={}):
			_handle_log_decision(args)

		return captured[0] if captured else {}

	def test_regression_log_decision_sends_general_when_no_project(self):
		body = self._log_decision_body()
		assert body.get("project") == "General"
		assert body.get("project_id") == "General"

	def test_log_decision_project_and_project_id_match(self):
		body = self._log_decision_body("mnemo")
		assert body.get("project") == "mnemo"
		assert body.get("project_id") == "mnemo"

	# -- get_recent_changes --------------------------------------------------

	def _recent_changes_params(self, project_arg=None):
		return self._run_handler_capture_qs(_handle_get_recent_changes, project_arg=project_arg)

	def test_regression_get_recent_changes_sends_general_when_no_project(self):
		assert self._recent_changes_params().get("project") == "General"

	def test_get_recent_changes_forwards_explicit_project(self):
		assert self._recent_changes_params("mnemo").get("project") == "mnemo"

	# -- get_stale_decisions -------------------------------------------------

	def _stale_params(self, project_arg=None):
		return self._run_handler_capture_qs(_handle_get_stale_decisions, project_arg=project_arg)

	def test_regression_get_stale_decisions_sends_general_when_no_project(self):
		assert self._stale_params().get("project") == "General"

	def test_get_stale_decisions_forwards_explicit_project(self):
		assert self._stale_params("mnemo").get("project") == "mnemo"

	# -- get_blocked_decisions -----------------------------------------------

	def _blocked_params(self, project_arg=None):
		return self._run_handler_capture_qs(_handle_get_blocked_decisions, project_arg=project_arg)

	def test_regression_get_blocked_decisions_sends_general_when_no_project(self):
		assert self._blocked_params().get("project") == "General"

	def test_get_blocked_decisions_forwards_explicit_project(self):
		assert self._blocked_params("mnemo").get("project") == "mnemo"

	# -- get_session_handoff_brief -------------------------------------------

	def _handoff_params(self, project_arg=None):
		return self._run_handler_capture_qs(
			_handle_get_session_handoff_brief,
			project_arg=project_arg,
			api_returns={"error": "no_session"},
		)

	def test_regression_get_session_handoff_brief_sends_general_when_no_project(self):
		assert self._handoff_params().get("project") == "General"

	def test_get_session_handoff_brief_forwards_explicit_project(self):
		assert self._handoff_params("mnemo").get("project") == "mnemo"

	def test_regression_old_cwd_inference_no_longer_silently_drops_project(self):
		"""Before fix: if CWD inference returned None, project was absent from params."""
		with patch.object(server, "_infer_project_from_cwd", return_value=None):
			result = _resolve_project({})
		# Must never return None or empty — always a string
		assert result and isinstance(result, str)
		assert result == "General"


if __name__ == "__main__":
	unittest.main()
