from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, Optional, Tuple

import requests


PROJECT_ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = PROJECT_ROOT / "data" / "config.json"
SESSIONS_PATH = PROJECT_ROOT / "data" / "profiles" / "rags" / "memory" / "sessions.json"


def load_config() -> Dict[str, object]:
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def server_is_up(base_url: str) -> bool:
    try:
        r = requests.get(f"{base_url}/health", timeout=1.5)
        return r.status_code == 200
    except Exception:
        return False


def start_server(port: int) -> subprocess.Popen:
    proc = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "uvicorn",
            "backend.main:app",
            "--host",
            "127.0.0.1",
            "--port",
            str(port),
        ],
        cwd=PROJECT_ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    deadline = time.time() + 20
    base_url = f"http://127.0.0.1:{port}"
    while time.time() < deadline:
        if server_is_up(base_url):
            return proc
        time.sleep(0.25)

    output = ""
    if proc.stdout:
        output = proc.stdout.read()[:2000]
    proc.terminate()
    raise RuntimeError(f"Uvicorn failed to start on port {port}. Output:\n{output}")


def stream_session(base_url: str, profile: str, task: str) -> Tuple[str, Dict[str, object]]:
    payload = {"profile": profile, "task": task}
    with requests.post(f"{base_url}/session", json=payload, stream=True, timeout=300) as response:
        response.raise_for_status()

        chunks = []
        done_event: Optional[Dict[str, object]] = None

        for line in response.iter_lines(decode_unicode=True):
            if not line:
                continue
            event = json.loads(line)
            event_type = event.get("type")

            if event_type == "chunk":
                text = str(event.get("text", ""))
                chunks.append(text)
                print(text, end="", flush=True)
            elif event_type == "done":
                done_event = event
            elif event_type == "error":
                raise RuntimeError(f"Session failed: {event.get('error')}")

        print()

    if done_event is None:
        raise RuntimeError("Session stream ended without a done event")

    return "".join(chunks), done_event


def session_exists(session_id: str) -> bool:
    data = json.loads(SESSIONS_PATH.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        return False
    return any(item.get("session_id") == session_id for item in data)


def run(count: int, task: Optional[str]) -> int:
    config = load_config()
    port = int(config["web_port"])
    base_url = f"http://127.0.0.1:{port}"

    owned_proc: Optional[subprocess.Popen] = None
    if not server_is_up(base_url):
        print(f"Starting local server on {base_url}...")
        owned_proc = start_server(port)

    tasks = []
    if task:
        for i in range(count):
            suffix = "" if i == 0 else f" (run {i+1})"
            tasks.append(task + suffix)
    else:
        defaults = [
            "Draft a competitive analysis outline for Cohesity vs Rubrik",
            "Write a board-ready one-page summary for GAIA positioning",
            "Create a product strategy brief for Mnemo phase-one rollout",
        ]
        tasks = defaults[:count]

    try:
        for idx, current_task in enumerate(tasks, start=1):
            print(f"\n=== Session {idx}/{len(tasks)} ===")
            _, done = stream_session(base_url, "rags", current_task)

            session_id = str(done.get("session_id", ""))
            tokens_input = int(done.get("tokens_input", -1))
            tokens_output = int(done.get("tokens_output", -1))
            exists = session_exists(session_id)

            if session_id and exists and tokens_input >= 0 and tokens_output >= 0:
                print(
                    f"PASS {idx}: session_id={session_id} tokens_input={tokens_input} tokens_output={tokens_output}"
                )
            else:
                print(
                    f"FAIL {idx}: session_id={session_id} exists={exists} "
                    f"tokens_input={tokens_input} tokens_output={tokens_output}"
                )
                return 1

        return 0
    finally:
        if owned_proc is not None:
            owned_proc.terminate()
            try:
                owned_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                owned_proc.kill()


def main() -> int:
    parser = argparse.ArgumentParser(description="Run Mnemo session tests against /session endpoint")
    parser.add_argument("task", nargs="?", default=None, help="Optional task string to run")
    parser.add_argument("--count", type=int, default=3, help="How many sessions to run")
    args = parser.parse_args()

    if args.count < 1:
        raise SystemExit("--count must be >= 1")

    return run(args.count, args.task)


if __name__ == "__main__":
    raise SystemExit(main())
