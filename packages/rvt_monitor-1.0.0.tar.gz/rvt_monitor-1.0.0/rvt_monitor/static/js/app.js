/**
 * RVT-Monitor Frontend — Entry Point
 */

import { appendLog } from './log.js';
import { initWebSocket, setClientId } from './ws.js';
import {
  initConnectionListeners, initTabListeners, setConnectionStatus,
  updateStatusCardVisibility, updateProfileUI, updateDeviceTypeUI,
  updateDeviceList, updateDeviceInfo, updateDeviceName, setScanButtonState,
  getCurrentDeviceType, setCurrentDeviceType,
  getCurrentProfileId, setCurrentProfileId,
} from './connection.js';
import { initCeilyElements, updateCeilyStatus } from './status-ceily.js';
import { initWallyElements, updateWallyStatus } from './status-wally.js';
import { renderDimensionTable, initDimensionListeners } from './dimension.js';
import { updateWifiStatus, initWifiListeners } from './wifi.js';
import { renderLedStatus, initLedListeners } from './led.js';

// Central message dispatcher
function handleMessage(msg) {
  switch (msg.type) {
    case 'init':
      setClientId(msg.data.client_id);
      if (msg.data.devices && msg.data.devices.length > 0) {
        updateDeviceList(msg.data.devices);
      }
      if (msg.data.scanning) {
        setScanButtonState(true, 'Scanning...');
      }
      appendLog('INFO', `Client ID: ${msg.data.client_id}`);
      break;

    case 'status':
      updateStatus(msg.data);
      break;

    case 'log':
      appendLog(msg.data.level, msg.data.message);
      break;

    case 'scan_result':
      updateDeviceList(msg.data, true);
      break;

    case 'error':
      appendLog('ERROR', msg.data.message);
      break;

    case 'command_result':
      if (!msg.data.success) {
        appendLog('ERROR', `Command failed: ${msg.data.action}`);
      }
      break;

    case 'dimensions':
      if (msg.data) renderDimensionTable(msg.data);
      break;

    case 'dimension_write_result':
      if (msg.data.success) {
        appendLog('INFO', `Dimension ${msg.data.id} set to ${msg.data.value}`);
      }
      break;

    case 'dimensions_save_result':
      if (msg.data.success) {
        appendLog('INFO', 'Dimensions saved to flash');
      }
      break;

    case 'wifi_status':
      if (msg.data) updateWifiStatus(msg.data);
      break;

    case 'wifi_set_result':
      break;

    case 'led_status':
      if (msg.data) renderLedStatus(msg.data);
      break;

    case 'led_mode_result':
      if (!msg.data.success) appendLog('ERROR', `LED mode failed (target=${msg.data.target})`);
      break;
    case 'led_brightness_result':
      if (!msg.data.success) appendLog('ERROR', `LED brightness failed (target=${msg.data.target}, val=${msg.data.value})`);
      break;
    case 'led_color_index_result':
      if (!msg.data.success) appendLog('ERROR', `LED color index failed (index=${msg.data.index})`);
      break;
    case 'led_color_result':
      if (!msg.data.success) appendLog('ERROR', `LED color failed (${msg.data.r},${msg.data.g},${msg.data.b})`);
      break;
  }
}

function updateStatus(data) {
  if (data.device_name) {
    updateDeviceName(data.device_name);
  }

  if (data.profile_id && data.profile_id !== getCurrentProfileId()) {
    console.log(`[UI] Profile switch: ${getCurrentProfileId()} -> ${data.profile_id}`);
    setCurrentProfileId(data.profile_id);
    updateProfileUI(data.profile_id);
  }

  updateDeviceInfo(data);

  if (data.device_type && data.device_type !== getCurrentDeviceType()) {
    setCurrentDeviceType(data.device_type);
    updateDeviceTypeUI(data.device_type);
  }

  if (data.connected !== undefined) {
    setConnectionStatus(data.connected ? 'connected' : 'disconnected');
  }

  if (data.status) {
    if (data.status.device_type && !getCurrentDeviceType()) {
      setCurrentDeviceType(data.status.device_type);
      updateDeviceTypeUI(data.status.device_type);
      updateStatusCardVisibility();
    }

    if (data.status.device_type === 'ceily') {
      updateCeilyStatus(data.status, getCurrentProfileId());
    } else if (data.status.device_type === 'wally') {
      updateWallyStatus(data.status, getCurrentProfileId());
    }
  }
}

// Init — type="module" defers execution until DOM is parsed
initConnectionListeners();
initTabListeners();
initCeilyElements();
initWallyElements();
initDimensionListeners();
initWifiListeners();
initLedListeners();
initWebSocket(handleMessage);
appendLog('INFO', 'RVT-Monitor started');
