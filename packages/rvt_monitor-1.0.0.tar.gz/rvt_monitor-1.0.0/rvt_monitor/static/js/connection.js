/**
 * Connection module — scan, connect/disconnect, device list, card visibility
 */

import { sendWs } from './ws.js';
import { appendLog } from './log.js';

// State
let _connected = false;
let _currentDeviceType = null;
let _currentProfileId = null;

export function isConnected() { return _connected; }
export function getCurrentDeviceType() { return _currentDeviceType; }
export function setCurrentDeviceType(v) { _currentDeviceType = v; }
export function getCurrentProfileId() { return _currentProfileId; }
export function setCurrentProfileId(v) { _currentProfileId = v; }

// DOM elements
let connectionStatus, deviceName, deviceManufacturer, deviceModel, deviceSerial,
    deviceProtocol, deviceHardware, deviceFirmware, ceilyStatusCard, wallyStatusCard,
    tabContainer, deviceSelect, btnScan, btnConnect, btnResetBond,
    btnUp, btnDown, btnStop, btnUserList;

export function initConnectionListeners() {
  connectionStatus = document.getElementById('connection-status');
  deviceName = document.getElementById('device-name');
  deviceManufacturer = document.getElementById('device-manufacturer');
  deviceModel = document.getElementById('device-model');
  deviceSerial = document.getElementById('device-serial');
  deviceProtocol = document.getElementById('device-protocol');
  deviceHardware = document.getElementById('device-hardware');
  deviceFirmware = document.getElementById('device-firmware');
  ceilyStatusCard = document.getElementById('ceily-status-card');
  wallyStatusCard = document.getElementById('wally-status-card');
  tabContainer = document.getElementById('tab-container');
  deviceSelect = document.getElementById('device-select');
  btnScan = document.getElementById('btn-scan');
  btnConnect = document.getElementById('btn-connect');
  btnResetBond = document.getElementById('btn-reset-bond');
  btnUp = document.getElementById('btn-up');
  btnDown = document.getElementById('btn-down');
  btnStop = document.getElementById('btn-stop');
  btnUserList = document.getElementById('btn-user-list');

  btnScan.addEventListener('click', scanDevices);
  btnConnect.addEventListener('click', toggleConnection);
  btnUp.addEventListener('click', () => sendWs('command', { action: 'up' }));
  btnDown.addEventListener('click', () => sendWs('command', { action: 'down' }));
  btnStop.addEventListener('click', () => sendWs('command', { action: 'stop' }));
  btnUserList.addEventListener('click', () => sendWs('request_user_list'));
  deviceSelect.addEventListener('change', () => {
    btnConnect.disabled = !deviceSelect.value;
    btnResetBond.disabled = !deviceSelect.value;
  });
  btnResetBond.addEventListener('click', resetBond);
}

export function setConnectionStatus(status) {
  const textMap = {
    connected: 'Connected',
    disconnected: 'Disconnected',
    connecting: 'Connecting...',
  };
  connectionStatus.textContent = textMap[status] || status;
  connectionStatus.className = `status-text ${status}`;

  _connected = status === 'connected';
  const busy = status === 'connected' || status === 'connecting';
  btnConnect.disabled = false;
  btnConnect.textContent = _connected ? 'Disconnect' : 'Connect';
  btnScan.disabled = busy;
  deviceSelect.disabled = busy;
  btnResetBond.disabled = busy || !deviceSelect.value;

  if (!_connected) {
    _currentDeviceType = null;
    _currentProfileId = null;
    deviceName.textContent = '-';
    deviceManufacturer.textContent = '-';
    deviceModel.textContent = '-';
    deviceSerial.textContent = '-';
    deviceProtocol.textContent = '-';
    deviceHardware.textContent = '-';
    deviceFirmware.textContent = '-';
  }

  updateStatusCardVisibility();
  updateControlButtons();
}

export function updateControlButtons() {
  btnUp.disabled = !_connected;
  btnDown.disabled = !_connected;
  btnStop.disabled = !_connected;
  btnUserList.disabled = !_connected;
  btnConnect.disabled = !deviceSelect.value && !_connected;
}

export function updateStatusCardVisibility() {
  if (_connected && _currentDeviceType) {
    tabContainer.style.display = '';
    ceilyStatusCard.style.display = _currentDeviceType === 'ceily' ? 'block' : 'none';
    wallyStatusCard.style.display = _currentDeviceType === 'wally' ? 'block' : 'none';
  } else {
    tabContainer.style.display = 'none';
    ceilyStatusCard.style.display = 'none';
    wallyStatusCard.style.display = 'none';
  }
}

export function updateDeviceTypeUI(deviceType) {
  const isCeily = deviceType === 'ceily';
  btnUp.textContent = isCeily ? 'UP' : 'OPEN';
  btnDown.textContent = isCeily ? 'DOWN' : 'CLOSE';
  const headRow = document.getElementById('led-head-row');
  if (headRow) headRow.style.display = isCeily ? '' : 'none';
}

export function updateProfileUI(profileId) {
  document.querySelectorAll('.p2-only').forEach(el => {
    el.style.display = '';
  });
  document.querySelectorAll('.p1-only').forEach(el => {
    el.style.display = 'none';
  });
  document.querySelectorAll('.p3-only').forEach(el => {
    el.style.display = '';
  });
}

export function updateDeviceList(deviceList, showLog = false) {
  if (deviceList.length > 0) {
    deviceSelect.innerHTML = '';
    deviceList.forEach(device => {
      const option = document.createElement('option');
      option.value = device.address;
      option.dataset.deviceName = device.name;
      let label = `${device.name} (${device.rssi} dBm)`;
      if (device.pairable === true) label += ' [Pairable]';
      else if (device.pairable === false) label += ' [Locked]';
      option.textContent = label;
      deviceSelect.appendChild(option);
    });
    deviceSelect.selectedIndex = 0;
    deviceSelect.disabled = false;
    btnConnect.disabled = false;
  } else {
    deviceSelect.innerHTML = '<option value="">Select a device</option>';
    deviceSelect.disabled = true;
  }

  btnScan.disabled = false;
  btnScan.textContent = 'Scan';

  if (showLog) {
    appendLog('INFO', `${deviceList.length} device(s) found`);
  }
}

export function resetBond() {
  const address = deviceSelect.value;
  if (!address) return;
  const option = deviceSelect.selectedOptions[0];
  const name = option ? option.dataset.deviceName : '';
  if (!confirm(`Reset bond cache for ${name || address}?`)) return;
  sendWs('reset_bond', { address, name });
}

export function scanDevices() {
  btnScan.disabled = true;
  btnScan.textContent = 'Scanning...';
  sendWs('scan');
}

export function toggleConnection() {
  if (_connected) {
    sendWs('disconnect');
  } else {
    const address = deviceSelect.value;
    const option = deviceSelect.selectedOptions[0];
    const name = option ? (option.dataset.deviceName || option.textContent.split(' (')[0]) : '';

    if (!address) return;

    btnConnect.disabled = true;
    setConnectionStatus('connecting');
    sendWs('connect', { address, name });
  }
}

export function updateDeviceInfo(data) {
  if (data.device_info) {
    deviceManufacturer.textContent = data.device_info.manufacturer_name || '-';
    deviceModel.textContent = data.device_info.model_number || '-';
    deviceSerial.textContent = data.device_info.serial_number || '-';
    deviceProtocol.textContent = data.device_info.protocol_version ? `v${data.device_info.protocol_version}` : '-';
    deviceHardware.textContent = data.device_info.hardware_revision || '-';
    deviceFirmware.textContent = data.device_info.firmware_revision || '-';
  }
}

export function updateDeviceName(name) {
  deviceName.textContent = name;
}

export function setScanButtonState(disabled, text) {
  btnScan.disabled = disabled;
  if (text) btnScan.textContent = text;
}

export function initTabListeners() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.querySelector(`.tab-panel[data-tab="${tab}"]`).classList.add('active');
    });
  });
}
