/**
 * WiFi settings module — status display and credential setting
 */

import { sendWs } from './ws.js';
import { appendLog } from './log.js';

let wifiCurrentSsid, wifiStatus, wifiSsidInput, wifiPasswordInput;

export function initWifiListeners() {
  wifiCurrentSsid = document.getElementById('wifi-current-ssid');
  wifiStatus = document.getElementById('wifi-status');
  wifiSsidInput = document.getElementById('wifi-ssid');
  wifiPasswordInput = document.getElementById('wifi-password');

  document.getElementById('btn-read-wifi').addEventListener('click', () => {
    sendWs('read_wifi_status');
  });

  document.getElementById('btn-set-wifi').addEventListener('click', () => {
    const ssid = wifiSsidInput.value.trim();
    const password = wifiPasswordInput.value;
    if (ssid) {
      sendWs('set_wifi', { ssid, password });
    } else {
      appendLog('ERROR', 'SSID is required');
    }
  });
}

export function updateWifiStatus(data) {
  if (data.ssid !== undefined) {
    wifiCurrentSsid.textContent = data.ssid || '-';
  }
  if (data.connected) {
    wifiStatus.textContent = 'Connected';
    wifiStatus.className = 'status-text connected';
  } else {
    wifiStatus.textContent = 'Disconnected';
    wifiStatus.className = 'status-text disconnected';
  }
}
