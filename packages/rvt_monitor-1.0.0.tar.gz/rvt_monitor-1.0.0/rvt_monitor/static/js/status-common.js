/**
 * Shared status formatter pure functions
 */

export function getMotionStateText(state, deviceType) {
  const ceilyStates = {
    'DOWN': 'Down', 'UP': 'Up',
    'MOVING_DOWN': 'Moving Down', 'MOVING_UP': 'Moving Up',
    'STOP': 'Stopped', 'EMERGENCY': 'Emergency',
    'MANUAL': 'Manual', 'INIT': 'Init',
  };
  const wallyStates = {
    'DOWN': 'Closed', 'UP': 'Opened',
    'MOVING_DOWN': 'Closing', 'MOVING_UP': 'Opening',
    'STOP': 'Stopped', 'EMERGENCY': 'Emergency',
    'MANUAL': 'Manual', 'INIT': 'Init',
  };
  const map = deviceType === 'ceily' ? ceilyStates : wallyStates;
  return map[state] || state || '-';
}

export function formatVoltage(mv) {
  if (mv === undefined || mv === null) return '-';
  return mv > 100 ? (mv / 1000).toFixed(1) : mv;
}

export function formatTemp(raw) {
  if (raw === undefined || raw === null) return '-';
  return raw > 1000 ? (raw / 10).toFixed(1) : raw;
}

export function getSpeedControlStateName(state) {
  const names = {0: 'Stop', 1: 'Accel', 2: 'Constant', 3: 'Decel'};
  return names[state] ?? `Unknown(${state})`;
}

export function getMotionPhaseName(phase, deviceType) {
  if (deviceType === 'wally') {
    const names = {
      0: 'Stop', 1: 'Y Correct', 2: 'Angle Correct', 3: 'In-Place Align',
    };
    return names[phase] ?? `Unknown(${phase})`;
  }
  return phase === 0 ? 'N/A' : `${phase}`;
}

export function formatTofState(tof) {
  if (!tof || tof.state_name === undefined) return '-';
  if (tof.enable === false) return 'Disabled';
  if (tof.error_code === 0) return tof.state_name;
  return `${tof.state_name} (${tof.error_name})`;
}

export function formatLimitSwitch(top, bottom) {
  const parts = [];
  if (top) parts.push('Top');
  if (bottom) parts.push('Bottom');
  return parts.length > 0 ? parts.join(', ') : 'None';
}

export function formatWallyLimitSwitch(state) {
  if (state === undefined || state === null) return '-';
  const parts = [];
  if (state & 0x01) parts.push('Open');
  if (state & 0x10) parts.push('Close');
  return parts.length > 0 ? parts.join(', ') : 'None';
}

export function getLegStateName(state) {
  const names = ['INIT', 'SPREAD', 'FOLD', 'SPREADING', 'FOLDING', 'STOP'];
  return names[state] ?? `Unknown(${state})`;
}

export function getLegDesireStateName(state) {
  const names = ['STOP', 'SPREAD', 'FOLD'];
  return names[state] ?? `Unknown(${state})`;
}

export function formatUptime(seconds) {
  if (seconds === undefined || seconds === null) return '-';
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m ${s}s`;
  return `${m}m ${s}s`;
}

export function formatHeap(bytes) {
  if (bytes === undefined || bytes === null) return '-';
  return `${(bytes / 1024).toFixed(1)} KB`;
}
