/**
 * Ceily status update module
 */

import {
  getMotionStateText, formatVoltage, formatTemp,
  getSpeedControlStateName, getMotionPhaseName,
  formatTofState, formatLimitSwitch,
  getLegStateName, getLegDesireStateName,
  formatUptime, formatHeap,
} from './status-common.js';

let el = {};

export function initCeilyElements() {
  el = {
    motionState: document.getElementById('ceily-motion-state'),
    mcuTemp: document.getElementById('ceily-mcu-temp'),
    // p3-only
    freeHeap: document.getElementById('ceily-free-heap'),
    minHeap: document.getElementById('ceily-min-heap'),
    uptime: document.getElementById('ceily-uptime'),
    // p2-only
    speedControlState: document.getElementById('ceily-speed-control-state'),
    motionPhase: document.getElementById('ceily-motion-phase'),
    position: document.getElementById('ceily-position'),
    positionPct: document.getElementById('ceily-position-pct'),
    remainDistance: document.getElementById('ceily-remain-distance'),
    currentVelocity: document.getElementById('ceily-current-velocity'),
    commandVelocity: document.getElementById('ceily-command-velocity'),
    torque: document.getElementById('ceily-torque'),
    positionVerified: document.getElementById('ceily-position-verified'),
    modelLearning: document.getElementById('ceily-model-learning'),
    limitSwitch: document.getElementById('ceily-limit-switch'),
    // Motor
    servoConnected: document.getElementById('ceily-servo-connected'),
    servoEnabled: document.getElementById('ceily-servo-enabled'),
    alarm: document.getElementById('ceily-alarm'),
    rawVelocity: document.getElementById('ceily-raw-velocity'),
    rawTorque: document.getElementById('ceily-raw-torque'),
    current: document.getElementById('ceily-current'),
    voltage: document.getElementById('ceily-voltage'),
    temperature: document.getElementById('ceily-temperature'),
    // ToF
    tofFrontState: document.getElementById('ceily-tof-front-state'),
    tofFrontGrid: document.getElementById('ceily-tof-front-grid'),
    tofLeftState: document.getElementById('ceily-tof-left-state'),
    tofLeftGrid: document.getElementById('ceily-tof-left-grid'),
    tofRightState: document.getElementById('ceily-tof-right-state'),
    tofRightGrid: document.getElementById('ceily-tof-right-grid'),
    // Legs (p2-only)
    legDesire: document.getElementById('ceily-leg-desire'),
    leftLegState: document.getElementById('ceily-left-leg-state'),
    leftLegCurrent: document.getElementById('ceily-left-leg-current'),
    leftLegTarget: document.getElementById('ceily-left-leg-target'),
    leftLegFold: document.getElementById('ceily-left-leg-fold'),
    leftLegSpread: document.getElementById('ceily-left-leg-spread'),
    rightLegState: document.getElementById('ceily-right-leg-state'),
    rightLegCurrent: document.getElementById('ceily-right-leg-current'),
    rightLegTarget: document.getElementById('ceily-right-leg-target'),
    rightLegFold: document.getElementById('ceily-right-leg-fold'),
    rightLegSpread: document.getElementById('ceily-right-leg-spread'),
  };
}

export function updateCeilyStatus(status, profileId) {
  const isP3 = true;

  el.motionState.textContent = getMotionStateText(status.motion_state, 'ceily');
  el.mcuTemp.textContent = status.mcu_temp ?? '-';

  if (isP3) {
    el.freeHeap.textContent = formatHeap(status.free_heap);
    el.minHeap.textContent = `${status.min_free_heap_kb ?? '-'} KB`;
    el.uptime.textContent = formatUptime(status.uptime_s);
  }

  el.speedControlState.textContent = getSpeedControlStateName(status.speed_control_state);
  el.motionPhase.textContent = getMotionPhaseName(status.motion_phase, 'ceily');
  el.position.textContent = status.position_mm ?? '-';
  el.positionPct.textContent = status.position_percentage ?? '-';
  el.remainDistance.textContent = status.remain_distance ?? '-';
  el.currentVelocity.textContent = status.current_velocity ?? '-';
  el.commandVelocity.textContent = status.command_velocity ?? '-';
  el.torque.textContent = status.torque ?? '-';
  el.positionVerified.textContent = status.is_position_verified ? 'Yes' : 'No';
  el.positionVerified.className = status.is_position_verified ? 'status-ok' : 'status-warn';
  el.modelLearning.textContent = status.is_current_model_learning ? 'Yes' : 'No';
  el.limitSwitch.textContent = formatLimitSwitch(status.top_limit, status.bottom_limit);

  // Motor — servo status common to p1 and p2
  el.servoConnected.textContent = status.servo_connected ? 'OK' : 'N/A';
  el.servoConnected.className = status.servo_connected ? 'status-ok' : 'status-warn';
  el.servoEnabled.textContent = status.servo_enabled ? 'ON' : 'OFF';
  el.servoEnabled.className = status.servo_enabled ? 'status-ok' : 'status-warn';
  el.alarm.textContent = status.servo_current_alarm ? `Code ${status.servo_current_alarm}` : 'None';

  el.rawVelocity.textContent = status.raw_velocity ?? '-';
  el.rawTorque.textContent = status.raw_torque ?? '-';
  el.current.textContent = status.motor_current ?? '-';
  el.voltage.textContent = formatVoltage(status.voltage);
  el.temperature.textContent = formatTemp(status.temperature);

  // ToF sensors — zone grid display
  const tofFront = status.tof_front || {};
  const tofLeft = status.tof_left || {};
  const tofRight = status.tof_right || {};

  updateTofGrid(el.tofFrontState, el.tofFrontGrid, tofFront, status.obstacle_front_bitmap);
  updateTofGrid(el.tofLeftState, el.tofLeftGrid, tofLeft, status.obstacle_left_bitmap);
  updateTofGrid(el.tofRightState, el.tofRightGrid, tofRight, status.obstacle_right_bitmap);

  // Legs
  if (el.leftLegCurrent) {
    el.legDesire.textContent = `(${getLegDesireStateName(status.leg_desire_state)})`;
    el.leftLegState.textContent = getLegStateName(status.left_leg_state);
    el.leftLegCurrent.textContent = status.left_leg_current_angle ?? '-';
    el.leftLegTarget.textContent = status.left_leg_target_angle ?? '-';
    el.leftLegFold.textContent = status.left_leg_fold_limit ? 'ON' : 'OFF';
    el.leftLegFold.className = status.left_leg_fold_limit ? 'status-ok' : '';
    el.leftLegSpread.textContent = status.left_leg_spread_limit ? 'ON' : 'OFF';
    el.leftLegSpread.className = status.left_leg_spread_limit ? 'status-ok' : '';
    el.rightLegState.textContent = getLegStateName(status.right_leg_state);
    el.rightLegCurrent.textContent = status.right_leg_current_angle ?? '-';
    el.rightLegTarget.textContent = status.right_leg_target_angle ?? '-';
    el.rightLegFold.textContent = status.right_leg_fold_limit ? 'ON' : 'OFF';
    el.rightLegFold.className = status.right_leg_fold_limit ? 'status-ok' : '';
    el.rightLegSpread.textContent = status.right_leg_spread_limit ? 'ON' : 'OFF';
    el.rightLegSpread.className = status.right_leg_spread_limit ? 'status-ok' : '';
  }
}

/** Render 2x8 zone grid from 16-bit bitmap */
function updateTofGrid(stateEl, gridEl, tof, bitmap) {
  // State badge
  const stateText = formatTofState(tof);
  stateEl.textContent = stateText;
  stateEl.className = 'tof-state-badge';
  if (tof.enable === false) {
    stateEl.classList.add('state-disabled');
  } else if (tof.error_code && tof.error_code !== 0) {
    stateEl.classList.add('state-error');
  } else if (tof.state === 1) {
    stateEl.classList.add('state-run');
  }

  // Build grid cells once, then reuse
  if (!gridEl._cells) {
    gridEl.innerHTML = '';
    gridEl._cells = [];
    for (let i = 0; i < 16; i++) {
      const cell = document.createElement('div');
      cell.className = 'tof-zone-cell';
      gridEl.appendChild(cell);
      gridEl._cells.push(cell);
    }
  }

  const hasData = tof.enable !== false && tof.state === 1;
  const bm = bitmap ?? 0;

  for (let i = 0; i < 16; i++) {
    const cell = gridEl._cells[i];
    const row = Math.floor(i / 8);
    const col = 7 - (i % 8);       // mirror left-right
    const bitIndex = (1 - row) * 8 + col;  // top row = bits 8-15, bottom row = bits 0-7
    if (!hasData) {
      cell.className = 'tof-zone-cell no-data';
    } else if (bm & (1 << bitIndex)) {
      cell.className = 'tof-zone-cell detected';
    } else {
      cell.className = 'tof-zone-cell';
    }
  }
}
