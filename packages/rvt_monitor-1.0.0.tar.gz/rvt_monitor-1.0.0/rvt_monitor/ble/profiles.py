"""Profile definitions for BLE device version detection.

Only v1-p3 (TLV) is supported.
"""

from typing import List
from uuid import UUID

# BLE SIG Device Information Service UUID
DEVICE_INFO_SERVICE_UUID = UUID("0000180a-0000-1000-8000-00805f9b34fb")

PROFILES = {
    "v1-p3": {
        "has_device_info": True,
        "status_mode": "notify",  # TLV-based status packets
        "description": "TLV status protocol (protocol version 3+)",
    },
}


def detect_profile(service_uuids: List[UUID]) -> str:
    """Detect profile from discovered BLE services.

    Returns:
        Always "v1-p3" — legacy profiles removed.
    """
    return "v1-p3"


def get_profile(profile_id: str) -> dict:
    """Get profile configuration by ID.

    Returns:
        Profile configuration dict. Always v1-p3.
    """
    return PROFILES["v1-p3"]
