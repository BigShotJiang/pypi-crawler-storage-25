"""Shared dataclasses for BLE status parsing."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Union

from ..protocol import MotionState


@dataclass
class TofStatus:
    """ToF sensor status.

    v1-p1: status byte = (state << 4) | error_code
    v1-p2: status byte = enable(1) | state(2) | rsv(1) | error(3) | rsv(1)
    """
    enable: bool = True
    state: int = 0       # 0=Init, 1=Run, 2=Disconnected
    error_code: int = 0  # 0=None, 1=InitFailed, 2=Disconnected, 3=InvalidData, 4=DataNotReady
    object_detected: bool = False

    STATE_NAMES = {0: "Init", 1: "Run", 2: "Disconnected"}
    ERROR_NAMES = {0: "None", 1: "InitFailed", 2: "Disconnected", 3: "InvalidData", 4: "DataNotReady"}

    @classmethod
    def from_bytes_v1(cls, status_byte: int, object_detected: bool) -> "TofStatus":
        """Parse v1-p1 format: high nibble = state, low nibble = error."""
        return cls(
            enable=True,  # v1-p1 has no enable field
            state=(status_byte >> 4) & 0x0F,
            error_code=status_byte & 0x0F,
            object_detected=object_detected,
        )

    @classmethod
    def from_bytes_v2(cls, status_byte: int, data_byte: int) -> "TofStatus":
        """Parse v1-p2 format: new bit layout."""
        return cls(
            enable=bool(status_byte & 0x01),
            state=(status_byte >> 1) & 0x03,
            error_code=(status_byte >> 4) & 0x07,
            object_detected=bool(data_byte),
        )

    def to_dict(self) -> dict:
        return {
            "enable": self.enable,
            "state": self.state,
            "state_name": self.STATE_NAMES.get(self.state, f"Unknown({self.state})"),
            "error_code": self.error_code,
            "error_name": self.ERROR_NAMES.get(self.error_code, f"Unknown({self.error_code})"),
            "object_detected": self.object_detected,
        }


@dataclass
class CeilyStatus:
    """Ceily device status (66 bytes)."""
    motion_state: MotionState = MotionState.INIT
    mcu_temp: int = 0  # MCU temperature in Celsius
    # Common fields (v1-p3)
    free_heap: int = 0          # bytes
    min_free_heap_kb: int = 0   # KB
    uptime_s: int = 0           # seconds
    # Common fields (v1-p2)
    speed_control_state: int = 0
    position_percentage: int = 0
    position_mm: int = 0
    remain_distance: int = 0
    current_velocity: int = 0
    command_velocity: int = 0
    is_position_verified: bool = False
    motion_phase: int = 0
    # Torque (v1-p3)
    torque: int = 0             # legacy alias for torque_measured
    torque_measured: int = 0    # mNm
    torque_predicted: int = 0   # mNm
    torque_estimated_max: int = 0  # mNm
    is_current_model_learning: bool = False
    torque_threshold: int = 0  # mNm
    # ToF sensors
    tof_front: TofStatus = field(default_factory=TofStatus)
    tof_left: TofStatus = field(default_factory=TofStatus)
    tof_right: TofStatus = field(default_factory=TofStatus)
    # Obstacle info (per-zone bitmaps, 16 zones per sensor)
    obstacle_front_bitmap: int = 0
    obstacle_left_bitmap: int = 0
    obstacle_right_bitmap: int = 0
    # Limit switches (bit 0: top ON, bit 4: bottom ON)
    limit_switch_state: int = 0
    top_limit: bool = False
    bottom_limit: bool = False
    # Servo
    servo_connected: bool = False
    servo_enabled: bool = False
    servo_current_alarm: int = 0
    # v1-p1: position, velocity_mm, torque (float)
    servo_position: int = 0
    velocity_mm: float = 0.0
    raw_velocity: int = 0
    raw_torque: int = 0
    # Motor status
    motor_current: int = 0
    voltage: int = 0
    temperature: int = 0
    # Leg status (v1-p2, offset 37)
    left_leg_current_angle: int = 0
    left_leg_target_angle: int = 0
    left_leg_state: int = 0
    left_leg_fold_limit: bool = False
    left_leg_spread_limit: bool = False
    right_leg_current_angle: int = 0
    right_leg_target_angle: int = 0
    right_leg_state: int = 0
    right_leg_fold_limit: bool = False
    right_leg_spread_limit: bool = False
    leg_desire_state: int = 0
    # Comm
    wifi_connected: bool = False
    wifi_rssi: int = 0
    mqtt_connected: bool = False
    ble_connections: int = 0
    last_update: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "device_type": "ceily",
            "motion_state": self.motion_state.name,
            "mcu_temp": self.mcu_temp,
            "free_heap": self.free_heap,
            "min_free_heap_kb": self.min_free_heap_kb,
            "uptime_s": self.uptime_s,
            "speed_control_state": self.speed_control_state,
            "position_percentage": self.position_percentage,
            "position_mm": self.position_mm,
            "remain_distance": self.remain_distance,
            "current_velocity": self.current_velocity,
            "command_velocity": self.command_velocity,
            "is_position_verified": self.is_position_verified,
            "motion_phase": self.motion_phase,
            "torque": self.torque,
            "torque_measured": self.torque_measured,
            "torque_predicted": self.torque_predicted,
            "torque_estimated_max": self.torque_estimated_max,
            "is_current_model_learning": self.is_current_model_learning,
            "torque_threshold": self.torque_threshold,
            "tof_front": self.tof_front.to_dict(),
            "tof_left": self.tof_left.to_dict(),
            "tof_right": self.tof_right.to_dict(),
            "obstacle_front_bitmap": self.obstacle_front_bitmap,
            "obstacle_left_bitmap": self.obstacle_left_bitmap,
            "obstacle_right_bitmap": self.obstacle_right_bitmap,
            "limit_switch_state": self.limit_switch_state,
            "top_limit": self.top_limit,
            "bottom_limit": self.bottom_limit,
            "servo_connected": self.servo_connected,
            "servo_enabled": self.servo_enabled,
            "servo_current_alarm": self.servo_current_alarm,
            "servo_position": self.servo_position,
            "velocity_mm": self.velocity_mm,
            "raw_velocity": self.raw_velocity,
            "raw_torque": self.raw_torque,
            "motor_current": self.motor_current,
            "voltage": self.voltage,
            "temperature": self.temperature,
            "left_leg_current_angle": self.left_leg_current_angle,
            "left_leg_target_angle": self.left_leg_target_angle,
            "left_leg_state": self.left_leg_state,
            "left_leg_fold_limit": self.left_leg_fold_limit,
            "left_leg_spread_limit": self.left_leg_spread_limit,
            "right_leg_current_angle": self.right_leg_current_angle,
            "right_leg_target_angle": self.right_leg_target_angle,
            "right_leg_state": self.right_leg_state,
            "right_leg_fold_limit": self.right_leg_fold_limit,
            "right_leg_spread_limit": self.right_leg_spread_limit,
            "leg_desire_state": self.leg_desire_state,
            "wifi_connected": self.wifi_connected,
            "wifi_rssi": self.wifi_rssi,
            "mqtt_connected": self.mqtt_connected,
            "ble_connections": self.ble_connections,
            "last_update": self.last_update.isoformat(),
        }


@dataclass
class WallyMotorStatus:
    """Single motor status for Wally.

    v1-p2: position (raw), position_mm, velocity, torque (floats)
    v1-p3: is_connected, raw_velocity, raw_torque (int16)
    """
    is_connected: bool = False
    is_enabled: bool = False
    current_alarm: int = 0
    # v1-p2 fields
    position: int = 0
    position_mm: float = 0.0
    velocity: float = 0.0
    torque: float = 0.0
    # v1-p3 fields
    raw_velocity: int = 0
    raw_torque: int = 0
    # Common fields
    current: int = 0
    voltage: int = 0
    temperature: int = 0

    def to_dict(self) -> dict:
        return {
            "is_connected": self.is_connected,
            "is_enabled": self.is_enabled,
            "current_alarm": self.current_alarm,
            "position": self.position,
            "position_mm": self.position_mm,
            "velocity": self.velocity,
            "torque": self.torque,
            "raw_velocity": self.raw_velocity,
            "raw_torque": self.raw_torque,
            "current": self.current,
            "voltage": self.voltage,
            "temperature": self.temperature,
        }


@dataclass
class WallyTofStatus:
    """Wally ToF sensor status with distance.

    v1-p1: status(1) + distance(4B float mm)
    v1-p2: status(1) + distance(1B uint8 cm)
    """
    enable: bool = True
    state: int = 0
    error_code: int = 0
    distance_mm: float = 0.0  # For compatibility, store in mm

    STATE_NAMES = {0: "Init", 1: "Run", 2: "Disconnected"}
    ERROR_NAMES = {0: "None", 1: "InitFailed", 2: "Disconnected", 3: "InvalidData", 4: "DataNotReady"}

    @classmethod
    def from_bytes_v1(cls, status_byte: int, distance_mm: float) -> "WallyTofStatus":
        """Parse v1-p1 format: old status byte + float distance."""
        return cls(
            enable=True,
            state=(status_byte >> 4) & 0x0F,
            error_code=status_byte & 0x0F,
            distance_mm=distance_mm,
        )

    @classmethod
    def from_bytes_v2(cls, status_byte: int, distance_raw: int) -> "WallyTofStatus":
        """Parse v1-p2/v3 format: new status byte + uint8 (mm unit)."""
        return cls(
            enable=bool(status_byte & 0x01),
            state=(status_byte >> 1) & 0x03,
            error_code=(status_byte >> 4) & 0x07,
            distance_mm=float(distance_raw),
        )

    def to_dict(self) -> dict:
        return {
            "enable": self.enable,
            "state": self.state,
            "state_name": self.STATE_NAMES.get(self.state, f"Unknown({self.state})"),
            "error_code": self.error_code,
            "error_name": self.ERROR_NAMES.get(self.error_code, f"Unknown({self.error_code})"),
            "distance_mm": self.distance_mm,
        }


@dataclass
class WallyStatus:
    """Wally device status (v1-p1: 106 bytes, v1-p2: 80 bytes)."""
    motion_state: MotionState = MotionState.INIT
    mcu_temp: int = 0  # MCU temperature in Celsius
    # Common fields (v1-p3)
    free_heap: int = 0          # bytes
    min_free_heap_kb: int = 0   # KB
    uptime_s: int = 0           # seconds
    # Common fields (v1-p2)
    speed_control_state: int = 0
    position_percentage: int = 0
    position_mm: int = 0
    remain_distance: int = 0
    current_velocity: int = 0
    command_velocity: int = 0
    is_position_verified: bool = False
    motion_phase: int = 0
    # Torque (v1-p3)
    torque: int = 0             # legacy alias for torque_measured
    torque_measured: int = 0    # mNm
    torque_predicted: int = 0   # mNm
    torque_estimated_max: int = 0  # mNm
    is_current_model_learning: bool = False
    torque_threshold: int = 0  # mNm
    # ToF sensors
    tof_left: WallyTofStatus = field(default_factory=WallyTofStatus)
    tof_right: WallyTofStatus = field(default_factory=WallyTofStatus)
    # Obstacle info (1 byte: limit switch)
    obstacle_limit_switch: int = 0
    # Limit switch (bit 0: open ON, bit 4: close ON)
    limit_switch_state: int = 0
    open_limit: bool = False
    close_limit: bool = False
    photo_sensor_state: int = 0
    # Angle sync diagnostics
    angle_sync_state: int = 0   # 0=Init, 1=Normal, 2=ErrorSlip, 3=ErrorTof
    # Motors
    motor_left: WallyMotorStatus = field(default_factory=WallyMotorStatus)
    motor_right: WallyMotorStatus = field(default_factory=WallyMotorStatus)
    # Wally kinematics (all floats from Vector2D)
    wally_x: float = 0.0
    wally_y: float = 0.0
    distance_to_wall: int = 0  # int16
    angle: float = 0.0
    angle_source: int = 0  # 0=ToF, 1=Odom
    angle_from_motors: float = 0.0
    angle_from_tof: float = 0.0
    # Control (v1-p1 only)
    target_x: float = 0.0
    target_y: float = 0.0
    target_velocity: float = 0.0
    # Comm
    wifi_connected: bool = False
    wifi_rssi: int = 0
    mqtt_connected: bool = False
    ble_connections: int = 0
    last_update: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "device_type": "wally",
            "motion_state": self.motion_state.name,
            "mcu_temp": self.mcu_temp,
            "free_heap": self.free_heap,
            "min_free_heap_kb": self.min_free_heap_kb,
            "uptime_s": self.uptime_s,
            "speed_control_state": self.speed_control_state,
            "position_percentage": self.position_percentage,
            "position_mm": self.position_mm,
            "remain_distance": self.remain_distance,
            "current_velocity": self.current_velocity,
            "command_velocity": self.command_velocity,
            "is_position_verified": self.is_position_verified,
            "motion_phase": self.motion_phase,
            "torque": self.torque,
            "torque_measured": self.torque_measured,
            "torque_predicted": self.torque_predicted,
            "torque_estimated_max": self.torque_estimated_max,
            "is_current_model_learning": self.is_current_model_learning,
            "torque_threshold": self.torque_threshold,
            "tof_left": self.tof_left.to_dict(),
            "tof_right": self.tof_right.to_dict(),
            "obstacle_limit_switch": self.obstacle_limit_switch,
            "limit_switch_state": self.limit_switch_state,
            "open_limit": self.open_limit,
            "close_limit": self.close_limit,
            "photo_sensor_state": self.photo_sensor_state,
            "angle_sync_state": self.angle_sync_state,
            "motor_left": self.motor_left.to_dict(),
            "motor_right": self.motor_right.to_dict(),
            "wally_x": self.wally_x,
            "wally_y": self.wally_y,
            "distance_to_wall": self.distance_to_wall,
            "angle": self.angle,
            "angle_source": self.angle_source,
            "angle_from_motors": self.angle_from_motors,
            "angle_from_tof": self.angle_from_tof,
            "target_x": self.target_x,
            "target_y": self.target_y,
            "target_velocity": self.target_velocity,
            "wifi_connected": self.wifi_connected,
            "wifi_rssi": self.wifi_rssi,
            "mqtt_connected": self.mqtt_connected,
            "ble_connections": self.ble_connections,
            "last_update": self.last_update.isoformat(),
        }


DeviceStatus = Union[CeilyStatus, WallyStatus]
