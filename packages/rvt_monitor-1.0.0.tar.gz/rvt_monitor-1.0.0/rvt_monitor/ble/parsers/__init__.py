"""BLE status packet parsers — v1-p3 TLV only."""

from .types import (
    TofStatus,
    CeilyStatus,
    WallyMotorStatus,
    WallyTofStatus,
    WallyStatus,
    DeviceStatus,
)


def parse_ceily_status(data: bytes, profile_id: str) -> tuple:
    """Parse Ceily status (TLV).

    Returns:
        (CeilyStatus, effective_profile_id)
    """
    from . import v3
    return v3.parse_ceily(data), "v1-p3"


def parse_wally_status(data: bytes, profile_id: str) -> tuple:
    """Parse Wally status (TLV).

    Returns:
        (WallyStatus, effective_profile_id)
    """
    from . import v3
    return v3.parse_wally(data), "v1-p3"
