"""BLE Connection Manager."""

import asyncio
import logging
import platform
import struct
from datetime import datetime
from enum import Enum
from typing import Callable, Optional

from bleak import BleakClient, BleakScanner
from bleak.exc import BleakError

logger = logging.getLogger(__name__)

from .protocol import (
    CharUUID,
    ServiceUUID,
    MotionCommand,
    MotionState,
    build_led_mode,
    build_led_brightness,
    build_led_color_index,
    build_led_color_rgb,
    build_dimension_write,
    build_wifi_config,
    build_generic_command,
    GenericCommandId,
    LEDTarget,
)
from .scanner import detect_device_type
from .parsers import (
    CeilyStatus,
    WallyStatus,
    DeviceStatus,
    parse_ceily_status,
    parse_wally_status,
)


class ConnectionState(Enum):
    """BLE connection state."""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"


_SECURITY_ERROR_KEYWORDS = [
    "insufficient encryption",
    "insufficient authentication",
    "not paired",
    "pairing",
    "security",
    "bond",
    "encrypt",
]


def _is_security_error(error: Exception) -> bool:
    """Check if a BleakError is related to BLE security/pairing."""
    msg = str(error).lower()
    return any(kw in msg for kw in _SECURITY_ERROR_KEYWORDS)


class _StaleBondError(Exception):
    """Connection failed, possibly due to stale bond keys."""


class _StaleGattCacheError(Exception):
    """GATT cache is stale — all characteristics not found after connect.

    Occurs when the server process restarts and GATT handles change,
    but the client's BlueZ still uses the old cached attribute table.
    Recovery: remove device from BlueZ (clears cache) and reconnect.
    """


class _SecurityDisconnectError(Exception):
    """Connection established but dropped during security setup.

    Indicates a REPEAT_PAIRING scenario: ESP32 deleted stale bond,
    disconnected, and opened pairing mode for clean reconnect.
    """


class BLEManager:
    """BLE connection and communication manager."""

    def __init__(self):
        self.client: Optional[BleakClient] = None
        self.device_address: Optional[str] = None
        self.device_name: Optional[str] = None
        self.device_type: Optional[str] = None
        self.connection_state = ConnectionState.DISCONNECTED
        self.status: Optional[DeviceStatus] = None
        self.device_info: Optional[dict] = None  # BLE SIG Device Information
        self.profile_id: str = "v1-p3"  # Protocol version (TLV)
        self.rssi: int = -100
        self.last_packet_time: Optional[datetime] = None
        self.last_connect_error: Optional[str] = None

        # Status subscription state (for notify mode)
        self._status_subscribed: bool = False

        # Callbacks
        self.on_state_change: Optional[Callable[[ConnectionState], None]] = None
        self.on_status_update: Optional[Callable[[DeviceStatus], None]] = None
        self.on_log_event: Optional[Callable[[str], None]] = None
        self.on_wifi_event: Optional[Callable[[bool], None]] = None
        self.on_disconnect: Optional[Callable[[], None]] = None
        self.on_led_status_update: Optional[Callable[[dict], None]] = None
        self.on_dimensions_update: Optional[Callable[[dict], None]] = None

        # Dimension get response (for v1-p3 notify-based read)
        self._dimension_event: Optional[asyncio.Event] = None
        self._dimension_result: Optional[dict] = None

        # Stats
        self.command_success_count = 0
        self.command_error_count = 0

    @property
    def connected(self) -> bool:
        return (
            self.connection_state == ConnectionState.CONNECTED
            and self.client is not None
            and self.client.is_connected
        )

    def _set_state(self, state: ConnectionState):
        """Update connection state and notify callback."""
        self.connection_state = state
        if self.on_state_change:
            self.on_state_change(state)

    def _on_disconnect(self, client: BleakClient):
        """Handle unexpected disconnection."""
        # Only handle disconnect if we were actually connected
        # Ignore spurious disconnect callbacks during connection attempts
        if self.connection_state != ConnectionState.CONNECTED:
            return
        logger.info("Disconnected from %s", self.device_address)
        self._set_state(ConnectionState.DISCONNECTED)
        self._status_subscribed = False
        self.client = None
        if self.on_disconnect:
            self.on_disconnect()

    def _handle_notification(self, sender, data: bytearray):
        """Handle BLE notification (log events).

        BleLogMessage structure (15 bytes):
        - uint32_t timestamp (4 bytes)
        - uint16_t protocol_version (2 bytes)
        - uint8_t event_type (1 byte)
        - uint8_t data[8] (8 bytes)

        Event types:
        - 3 = WiFi connection status changed
        """
        self.last_packet_time = datetime.now()
        try:
            if len(data) >= 15:
                # Parse binary log message
                timestamp = struct.unpack_from("<I", data, 0)[0]
                protocol_ver = struct.unpack_from("<H", data, 4)[0]
                event_type = data[6]
                event_data = data[7:15]

                message = self._format_log_event(event_type, event_data, timestamp)
                if message and self.on_log_event:
                    self.on_log_event(message)
                # WiFi event: notify status change
                if event_type == 3 and self.on_wifi_event:
                    self.on_wifi_event(event_data[0] == 1)
            else:
                # Try as plain text (fallback)
                message = data.decode("utf-8", errors="replace").strip()
                if message and self.on_log_event:
                    self.on_log_event(message)
        except Exception:
            pass

    def _handle_status_notification(self, sender, data: bytearray):
        """Handle BLE status notification (TLV)."""
        self.last_packet_time = datetime.now()
        try:
            raw = bytes(data)
            if self.device_type == "ceily":
                self.status, _ = parse_ceily_status(raw, self.profile_id)
            elif self.device_type == "wally":
                self.status, _ = parse_wally_status(raw, self.profile_id)

            if self.on_status_update and self.status:
                self.on_status_update(self.status)
        except Exception as e:
            print(f"[BLE] Status parse error: {e} (len={len(data)})")

    def _handle_led_status_notification(self, sender, data: bytearray):
        """Handle BLE LED status notification."""
        self.last_packet_time = datetime.now()
        try:
            from .protocol import parse_led_status
            result = parse_led_status(bytes(data))
            if result and self.on_led_status_update:
                self.on_led_status_update(result)
        except Exception as e:
            print(f"[BLE] LED status notify parse error: {e}")

    def _handle_user_list_notification(self, sender, data: bytearray):
        """Handle BLE user list notification (TLV debug)."""
        self.last_packet_time = datetime.now()
        TLV_TYPE_USER = 0x01
        try:
            raw = bytes(data)
            user_count = 0
            pos = 0
            while pos < len(raw) and raw[pos] == TLV_TYPE_USER:
                name_len = raw[pos + 1]
                name = raw[pos + 2:pos + 2 + name_len].decode("utf-8", errors="replace")
                addr = raw[pos + 2 + name_len:pos + 2 + name_len + 6]
                connected = raw[pos + 2 + name_len + 6]
                last_seen = struct.unpack_from("<I", raw, pos + 2 + name_len + 7)[0]
                addr_str = ":".join(f"{b:02X}" for b in addr)
                logger.info(
                    "  [%d] \"%s\" %s conn=%d last_seen=%d",
                    user_count, name, addr_str, connected, last_seen,
                )
                pos += 1 + 1 + name_len + 6 + 1 + 4
                user_count += 1
            logger.info("user_list NOTIFY: %d users, %d bytes", user_count, len(raw))
        except Exception as e:
            logger.warning("user_list parse error: %s (len=%d)", e, len(data))

    def _get_dimension_meta(self):
        """Get dimension metadata list based on device type and hw version."""
        from .protocol import (
            CEILY_DIMENSIONS_V3, WALLY_DIMENSIONS_V3, WALLY_DIMENSIONS_V2,
        )
        hw = (self.device_info or {}).get("hardware_revision", "")
        if self.device_type == "ceily":
            return CEILY_DIMENSIONS_V3
        elif self.device_type == "wally":
            return WALLY_DIMENSIONS_V2 if hw == "v2" else WALLY_DIMENSIONS_V3
        return None

    def _handle_dimension_notification(self, sender, data: bytearray):
        """Handle BLE dimension notification (v1-p3 TLV push)."""
        self.last_packet_time = datetime.now()
        try:
            from .protocol import parse_dimensions_tlv
            values = parse_dimensions_tlv(bytes(data))
            dim_meta = self._get_dimension_meta()
            if not dim_meta:
                return

            dims = []
            for dim in dim_meta:
                value = values.get(dim["id"], 0)
                # unsigned→signed for int16 types
                if dim["type"] == "int16" and value > 0x7FFF:
                    value -= 0x10000
                dims.append({
                    "id": dim["id"],
                    "name": dim["name"],
                    "unit": dim["unit"],
                    "type": dim["type"],
                    "value": value,
                    "readonly": dim.get("readonly", False),
                })
            result = {
                "device_type": self.device_type,
                "dimensions": dims,
            }
            # Signal pending read_all_dimensions() if waiting
            if self._dimension_event:
                self._dimension_result = result
                self._dimension_event.set()

            if self.on_dimensions_update:
                self.on_dimensions_update(result)
        except Exception as e:
            print(f"[BLE] Dimension notify parse error: {e}")

    def _format_log_event(self, event_type: int, data: bytes, timestamp: int) -> str:
        """Format binary log event to human-readable string."""
        # Event type 0: None - ignore
        if event_type == 0:
            return None

        # Event type 1: Command received
        if event_type == 1:
            sender = data[0]
            command = data[1]
            cmd_names = {0: "Stop", 1: "Up", 2: "Down"}
            sender_names = {0: "None", 1: "Button", 2: "BLE", 3: "System"}
            cmd_str = cmd_names.get(command, f"Unknown({command})")
            sender_str = sender_names.get(sender, f"Unknown({sender})")
            return f"Command: {cmd_str} from {sender_str}"

        # Event type 2: Motion state changed
        if event_type == 2:
            state_from = data[0]
            state_to = data[1]
            position = data[2]
            error_code = data[3]
            state_names = {
                0: "Down", 1: "Up", 2: "Moving Down", 3: "Moving Up",
                4: "Stop", 5: "Emergency", 8: "Manual", 255: "Init"
            }
            error_names = {
                0: "None",
                1: "Not initialized",
                2: "Device error",
                3: "Torque outlier detected",
                4: "Object detected",
                5: "E-stop activated",
                6: "Max torque exceeded",
                0x20: "Wally start env error",
                0x21: "Wally slip occurred",
                0x22: "Wally ToF angle error",
            }
            from_str = state_names.get(state_from, f"Unknown({state_from})")
            to_str = state_names.get(state_to, f"Unknown({state_to})")
            err_str = error_names.get(error_code, f"Unknown({error_code})")
            if error_code == 0:
                return f"State: {from_str} -> {to_str}, pos={position}"
            return f"State: {from_str} -> {to_str}, pos={position}, err={err_str}"

        # Event type 3: WiFi connection status
        if event_type == 3:
            status = data[0]
            rssi = struct.unpack("<b", data[1:2])[0]  # signed int8
            if status == 1:  # Connected
                channel = data[2]
                return f"WiFi Connected: ch={channel}, RSSI={rssi}dBm"
            elif status == 2:  # Disconnected
                reason = data[3]
                reason_text = {
                    1: "Unspecified", 2: "Auth expire", 3: "Auth leave",
                    4: "Assoc expire", 5: "Assoc toomany", 6: "Not authed",
                    7: "Not assoced", 8: "Assoc leave", 9: "Assoc not authed",
                    15: "4-way handshake timeout", 16: "Group key update timeout",
                    23: "802.1X auth failed", 200: "Beacon timeout",
                    201: "No AP found", 202: "Auth fail", 203: "Assoc fail",
                    204: "Handshake timeout",
                }.get(reason, f"Unknown({reason})")
                return f"WiFi Disconnected: reason={reason_text}, RSSI={rssi}dBm"
            else:
                return f"WiFi Status: {status}"

        # Event type 4: BLE connection status
        if event_type == 4:
            status = data[0]
            active_count = data[1]
            bonded = "bonded" if data[2] else "unbonded"
            if status == 1:  # Connected
                rssi = struct.unpack("<b", data[3:4])[0]
                encrypted = "encrypted" if data[4] else "plain"
                return (f"BLE Connected ({bonded}, {encrypted}, "
                        f"RSSI={rssi}dBm) [{active_count} conn]")
            elif status == 2:  # Disconnected
                reason = data[3]
                return (f"BLE Disconnected ({bonded}, "
                        f"reason=0x{reason:02X}) [{active_count} conn]")
            else:
                return f"BLE Status: {status}"

        # Event type 5: Config change
        if event_type == 5:
            result = data[0]
            dim_id = data[1]
            value = struct.unpack_from("<h", data, 2)[0]
            current = struct.unpack_from("<h", data, 4)[0]
            result_names = {0: "changed", 1: "rejected(range)", 2: "rejected(not found)"}
            result_str = result_names.get(result, f"unknown({result})")
            if result == 0:
                return f"Config: dim=0x{dim_id:02X} -> {value} ({result_str})"
            return f"Config: dim=0x{dim_id:02X} val={value} cur={current} ({result_str})"

        # Event type 6: MQTT connection status
        if event_type == 6:
            status = data[0]
            if status == 1:
                return "MQTT Connected"
            elif status == 2:
                return "MQTT Disconnected"
            elif status == 3:
                error_type = data[1] if len(data) > 1 else 0
                return f"MQTT Error (type={error_type})"
            else:
                return f"MQTT Status: {status}"

        # Unknown event type - show hex
        hex_data = data[:8].hex()
        return f"Event[{event_type}]: {hex_data}"

    async def connect(self, address: str, name: str = "",
                      pairable: bool = False) -> bool:
        """Connect to a BLE device.

        Args:
            address: BLE device address
            name: Device name
            pairable: Device pairing flag from scan manufacturer data.
                      If False, skip BLE pairing even for v1-p3+ devices.

        Returns True on success.
        On failure, sets self.last_connect_error with reason string.
        """
        self.last_connect_error = None

        if self.connected:
            await self.disconnect()

        self._set_state(ConnectionState.CONNECTING)
        self.device_address = address
        self.device_name = name
        self.device_type = detect_device_type(name) if name else None

        # Initialize status based on device type
        if self.device_type == "ceily":
            self.status = CeilyStatus()
        elif self.device_type == "wally":
            self.status = WallyStatus()
        else:
            self.status = None

        # On Linux, register BlueZ agent once for Just Works pairing
        if platform.system() == "Linux":
            from .bluez_agent import ensure_bluez_agent
            await ensure_bluez_agent()

        try:
            result = await self._connect_and_pair(address, pairable)
            return result
        except _StaleGattCacheError:
            # GATT cache is stale (server restarted, handles changed).
            # Clear BlueZ cache by removing the device, then retry.
            logger.info(
                "Stale GATT cache — clearing BlueZ device and retrying")
            if self.client:
                try:
                    await self.client.disconnect()
                except Exception:
                    pass
            self.client = None
            if platform.system() == "Linux":
                await self._remove_device_from_bluez(address)
            await asyncio.sleep(1.0)
            try:
                result = await self._connect_and_pair(address, pairable)
                return result
            except Exception as retry_err:
                logger.warning(
                    "Reconnect after GATT cache clear failed: %s", retry_err)
                self.last_connect_error = (
                    "GATT 캐시 초기화 후 재연결 실패. "
                    "페어링 버튼을 눌러주세요."
                )
                self._set_state(ConnectionState.DISCONNECTED)
                self.client = None
                return False
        except _SecurityDisconnectError:
            # Connection dropped during GATT service discovery.
            # Could be transient (radio glitch, GATT cache timing) or
            # REPEAT_PAIRING (server deleted stale bond).
            # Strategy: retry with bond intact first (handles transient
            # issues + V2 BlueZ peripherals). Only clear bond on 2nd fail.
            logger.info(
                "Security disconnect detected — "
                "retrying with bond intact"
            )
            await asyncio.sleep(1.0)
            try:
                result = await self._connect_and_pair(address, pairable)
                return result
            except (_SecurityDisconnectError, _StaleGattCacheError,
                    _StaleBondError, BleakError):
                pass  # Fall through to bond-clearing retry

            # Bond-clearing retry (REPEAT_PAIRING / stale LTK)
            logger.info(
                "Retry with bond failed — "
                "clearing client bond and retrying in 2s"
            )
            if platform.system() == "Linux":
                await self._remove_device_from_bluez(address)
            await asyncio.sleep(2.0)
            try:
                result = await self._connect_and_pair(address, pairable=True)
                return result
            except Exception as retry_err:
                logger.warning(
                    "Reconnect after security disconnect failed: %s",
                    retry_err,
                )
                self.last_connect_error = (
                    "Reconnect after security disconnect failed. "
                    "Use 'Reset Bond' to clear cached keys."
                )
                self._set_state(ConnectionState.DISCONNECTED)
                self.client = None
                return False
        except _StaleBondError as e:
            cause = str(e.__cause__) if e.__cause__ else "unknown"
            self.last_connect_error = (
                f"Stale bond ({cause}). "
                "Use 'Reset Bond' button to clear cached keys."
            )
            logger.warning("Stale bond error: %s", cause)
            self._set_state(ConnectionState.DISCONNECTED)
            self.client = None
            return False
        except BleakError as e:
            logger.warning("BleakError during connect: %s", e)
            self._set_state(ConnectionState.DISCONNECTED)
            if self.client:
                try:
                    await self.client.disconnect()
                except Exception:
                    pass
            self.client = None
            if _is_security_error(e):
                raise BleakError(
                    "기기가 페어링 모드가 아닙니다. "
                    "버튼을 3초간 눌러주세요."
                ) from e
            raise
        except Exception as e:
            logger.warning("Unexpected error during connect: %s", e)
            self.last_connect_error = str(e)
            self._set_state(ConnectionState.DISCONNECTED)
            if self.client:
                try:
                    await self.client.disconnect()
                except Exception:
                    pass
            self.client = None
            return False

    @staticmethod
    async def _is_device_known_to_bluez(address: str) -> bool:
        """Check if BlueZ already has a persistent object for this device.

        Bonded/paired devices are persisted across restarts.
        Non-bonded devices are ephemeral and need a scan to populate.
        """
        try:
            from dbus_fast.aio import MessageBus
            from dbus_fast import BusType
            bus = await MessageBus(bus_type=BusType.SYSTEM).connect()
            try:
                introspect = await bus.introspect("org.bluez", "/")
                proxy = bus.get_proxy_object("org.bluez", "/", introspect)
                obj_mgr = proxy.get_interface(
                    "org.freedesktop.DBus.ObjectManager")
                objects = await obj_mgr.call_get_managed_objects()
                addr_part = address.replace(":", "_")
                for path in objects:
                    if addr_part in path:
                        logger.debug("Device %s found in BlueZ at %s",
                                     address, path)
                        return True
            finally:
                bus.disconnect()
        except Exception as e:
            logger.debug("BlueZ device check failed: %s", e)
        return False

    @staticmethod
    async def _remove_device_from_bluez(address: str) -> bool:
        """Remove device from BlueZ (clears bond keys + GATT cache).

        Equivalent to `bluetoothctl remove <address>`.
        Returns True if device was removed, False otherwise.
        """
        try:
            from dbus_fast.aio import MessageBus
            from dbus_fast import BusType
            bus = await MessageBus(bus_type=BusType.SYSTEM).connect()
            try:
                addr_part = address.replace(":", "_")
                device_path = f"/org/bluez/hci0/dev_{addr_part}"
                introspect = await bus.introspect(
                    "org.bluez", "/org/bluez/hci0")
                proxy = bus.get_proxy_object(
                    "org.bluez", "/org/bluez/hci0", introspect)
                adapter = proxy.get_interface("org.bluez.Adapter1")
                await adapter.call_remove_device(device_path)
                logger.info("Removed device %s from BlueZ", address)
                return True
            finally:
                bus.disconnect()
        except Exception as e:
            logger.debug("BlueZ device removal failed: %s", e)
            return False

    async def _connect_and_pair(self, address: str,
                               pairable: bool = False) -> bool:
        """Internal: connect, detect profile, pair if pairable, set up notifications.

        Raises _StaleBondError if connection fails due to stale bond keys.
        """
        logger.info("Connecting to %s (pairable=%s)", address, pairable)

        # On Linux/BlueZ, BleakClient(address_string) fails for non-bonded
        # devices because BlueZ only keeps persistent objects for paired
        # devices.  For bonded devices, BlueZ already has the object — skip
        # scanning entirely to avoid "Operation already in progress" conflicts.
        # For non-bonded devices, scan to populate BlueZ cache and keep the
        # scanner alive during connect (bleak stops discovery internally
        # before calling Device1.Connect; the device stays in _properties).
        ble_target = address
        self._pre_connect_scanner = None
        if platform.system() == "Linux":
            needs_scan = not await self._is_device_known_to_bluez(address)
            if needs_scan:
                try:
                    found_event = asyncio.Event()
                    found_dev = [None]

                    def _on_detect(device, _adv_data):
                        if device.address == address:
                            found_dev[0] = device
                            found_event.set()

                    self._pre_connect_scanner = BleakScanner(
                        detection_callback=_on_detect)
                    await self._pre_connect_scanner.start()
                    try:
                        await asyncio.wait_for(
                            found_event.wait(), timeout=10.0)
                        ble_target = found_dev[0]
                        logger.info("Resolved BLEDevice via scan: %s",
                                    ble_target.name)
                    except asyncio.TimeoutError:
                        logger.warning("Scan could not find %s in 10s, "
                                       "falling back to address string",
                                       address)
                        await self._pre_connect_scanner.stop()
                        self._pre_connect_scanner = None
                    # Keep scanner alive for found devices. BlueZ removes
                    # non-bonded device objects when scanning stops, so the
                    # scanner must stay alive until connect() completes.
                    # Scan+connect mode conflict can add 5-15s to connect.
                    # Scanner is stopped in the finally block below.
                except Exception as e:
                    logger.warning("Pre-connect scan failed: %s", e)
                    if self._pre_connect_scanner:
                        try:
                            await self._pre_connect_scanner.stop()
                        except Exception:
                            pass
                        self._pre_connect_scanner = None

        self.client = BleakClient(
            ble_target,
            disconnected_callback=self._on_disconnect,
        )

        try:
            try:
                # Pass timeout to bleak's connect() directly — bleak has an
                # internal 10s default timeout that fires before wait_for.
                # Use 20s to give BlueZ time to handle scan+connect mode switch.
                await self.client.connect(timeout=20.0)
            except (BleakError, asyncio.TimeoutError, Exception) as e:
                logger.warning("Connect failed: %s", e)
                if self.client:
                    try:
                        await self.client.disconnect()
                    except Exception:
                        pass
                self.client = None
                # "failed to discover services, device disconnected" means the
                # L2CAP connection succeeded but dropped during GATT discovery
                # (encryption failure / stale bond). Treat as security disconnect
                # so the caller can retry after server opens pairing mode.
                err_msg = str(e).lower()
                if "device disconnected" in err_msg or "services" in err_msg:
                    raise _SecurityDisconnectError() from e
                raise _StaleBondError() from e

            if self.client is None or not self.client.is_connected:
                raise _StaleBondError()

            logger.info("Connected to %s (mtu=%d)", address, self.client.mtu_size)

            # --- Setup phase: any disconnect here indicates security-level
            # failure (e.g., REPEAT_PAIRING). Wrap to detect this pattern. ---
            try:
                return await self._setup_after_connect(pairable)
            except Exception as e:
                if self.client is None or not self.client.is_connected:
                    # Connected then dropped = security disconnect
                    if self.client:
                        try:
                            await self.client.disconnect()
                        except Exception:
                            pass
                    self.client = None
                    raise _SecurityDisconnectError() from e
                raise
        finally:
            # Stop pre-connect scanner (kept alive for non-bonded devices)
            if self._pre_connect_scanner:
                try:
                    await self._pre_connect_scanner.stop()
                except Exception:
                    pass
                self._pre_connect_scanner = None

    async def _setup_after_connect(self, pairable: bool) -> bool:
        """Post-connect setup: profile detection, pairing, subscriptions.

        Separated from _connect_and_pair so that security disconnects
        (e.g., REPEAT_PAIRING) can be detected at the boundary.
        """
        # Wait for connection to stabilize (BlueZ needs time after connect)
        await asyncio.sleep(0.5)

        # Read Device Information Service
        self.profile_id = "v1-p3"
        self.device_info = await self.read_device_info()

        # Detect stale GATT cache: all device_info fields None means
        # BlueZ returned cached attribute handles that no longer exist
        if self.device_info and all(
                v is None for v in self.device_info.values()):
            logger.warning(
                "Stale GATT cache — all characteristics not found")
            raise _StaleGattCacheError()

        logger.info("Profile: %s", self.profile_id)

        # Pair only if device advertised pairable flag
        if pairable:
            logger.info("Initiating BLE pairing...")
            try:
                await self.client.pair()
                logger.info("Pairing completed successfully")
            except Exception as e:
                logger.warning("Pairing failed: %s", e)
                if self.client is None or not self.client.is_connected:
                    raise _StaleBondError() from e
        else:
            logger.info("Skipping pairing (pairable=%s)", pairable)

        if self.client is None or not self.client.is_connected:
            raise _StaleBondError()

        # Start notification for log events
        try:
            if self.client:
                await self.client.start_notify(
                    CharUUID.LOG_EVENT,
                    self._handle_notification,
                )
                logger.info("Subscribed to log event notifications")
        except Exception as e:
            logger.warning("Log event notify subscribe failed: %s", e)

        # Subscribe to LED status notifications
        try:
            if self.client:
                await self.client.start_notify(
                    CharUUID.LED_STATUS,
                    self._handle_led_status_notification,
                )
                logger.info("Subscribed to LED status notifications")
        except Exception as e:
            logger.warning("LED status notify subscribe failed: %s", e)

        # Subscribe to dimension notifications
        try:
            if self.client:
                await self.client.start_notify(
                    CharUUID.DIMENSION,
                    self._handle_dimension_notification,
                )
                logger.info("Subscribed to dimension notifications")
        except Exception as e:
            logger.warning("Dimension notify subscribe failed: %s", e)

        # Subscribe to user list notifications
        try:
            if self.client:
                await self.client.start_notify(
                    CharUUID.USER_LIST,
                    self._handle_user_list_notification,
                )
                logger.info("Subscribed to user list notifications")
        except Exception as e:
            logger.warning("User list notify subscribe failed: %s", e)

        # Set user name on device
        try:
            if self.client:
                await self.client.write_gatt_char(
                    CharUUID.USER_NAME,
                    b"rvt-monitor",
                )
                logger.info("User name set to 'rvt-monitor'")
        except Exception as e:
            logger.debug("User name write skipped: %s", e)

        # Verify still connected after setup
        if self.client is None or not self.client.is_connected:
            raise BleakError("Connection lost during setup")

        self._set_state(ConnectionState.CONNECTED)
        self.last_packet_time = datetime.now()
        logger.info("Connection setup complete (profile=%s)", self.profile_id)

        return True

    async def disconnect(self):
        """Disconnect from current device."""
        if self.client:
            try:
                await self.client.disconnect()
            except Exception:
                pass
            self.client = None
        self.device_info = None
        self._status_subscribed = False
        self._set_state(ConnectionState.DISCONNECTED)

    async def read_status(self) -> Optional[DeviceStatus]:
        """Read device status."""
        if not self.connected:
            return None

        try:
            data = await self.client.read_gatt_char(CharUUID.SYSTEM_STATUS)
            self.last_packet_time = datetime.now()

            if self.device_type == "ceily":
                self.status, _ = parse_ceily_status(data, self.profile_id)
            elif self.device_type == "wally":
                self.status, _ = parse_wally_status(data, self.profile_id)

            if self.on_status_update and self.status:
                self.on_status_update(self.status)

            return self.status

        except BleakError as e:
            self.command_error_count += 1
            if _is_security_error(e):
                if self.on_log_event:
                    self.on_log_event(
                        "암호화된 연결이 필요합니다. "
                        "기기를 재페어링하세요."
                    )
            return None
        except Exception:
            self.command_error_count += 1
            return None

    async def subscribe_status(self) -> bool:
        """Subscribe to status notifications.

        Returns True if successfully subscribed.
        """
        if not self.connected:
            return False

        if self._status_subscribed:
            return True

        try:
            await self.client.start_notify(
                CharUUID.SYSTEM_STATUS,
                self._handle_status_notification,
            )
            self._status_subscribed = True
            return True
        except Exception:
            return False

    async def unsubscribe_status(self) -> bool:
        """Unsubscribe from status notifications.

        Returns True if successfully unsubscribed.
        """
        if not self.connected:
            return False

        if not self._status_subscribed:
            return True

        try:
            await self.client.stop_notify(CharUUID.SYSTEM_STATUS)
            self._status_subscribed = False
            return True
        except Exception:
            return False

    @property
    def status_subscribed(self) -> bool:
        """Return whether status notifications are subscribed."""
        return self._status_subscribed

    async def send_command(self, command: MotionCommand) -> bool:
        """Send motion command (UP/DOWN/STOP)."""
        if not self.connected:
            return False

        try:
            data = build_generic_command(
                GenericCommandId.MOTION_CONTROL, bytes([command])
            )
            await self.client.write_gatt_char(
                CharUUID.GENERIC_CONTROL, data
            )
            self.command_success_count += 1
            self.last_packet_time = datetime.now()
            return True
        except BleakError as e:
            self.command_error_count += 1
            if _is_security_error(e) and self.on_log_event:
                self.on_log_event(
                    "암호화된 연결이 필요합니다. "
                    "기기를 재페어링하세요."
                )
            return False
        except Exception:
            self.command_error_count += 1
            return False

    async def send_up(self) -> bool:
        """Send UP/OPEN command."""
        return await self.send_command(MotionCommand.UP)

    async def send_down(self) -> bool:
        """Send DOWN/CLOSE command."""
        return await self.send_command(MotionCommand.DOWN)

    async def send_stop(self) -> bool:
        """Send STOP command."""
        return await self.send_command(MotionCommand.STOP)

    async def _send_led_command(self, data: bytes) -> bool:
        """Send LED command via generic control (v1-p3) or legacy characteristic."""
        if not self.connected:
            return False

        try:
            payload = build_generic_command(
                GenericCommandId.LED_CONTROL, data
            )
            await self.client.write_gatt_char(
                CharUUID.GENERIC_CONTROL, payload
            )
            self.command_success_count += 1
            return True
        except Exception as e:
            print(f"[BLE] LED command error: {e}")
            self.command_error_count += 1
            return False

    async def set_led_brightness(self, target: LEDTarget, brightness: int) -> bool:
        """Set LED brightness (0-255)."""
        return await self._send_led_command(build_led_brightness(target, brightness))

    async def set_led_color_index(self, index: int) -> bool:
        """Set LED color by index."""
        return await self._send_led_command(build_led_color_index(index))

    async def set_led_color(self, r: int, g: int, b: int) -> bool:
        """Set LED RGB color (writes to custom color slot index 2)."""
        return await self._send_led_command(build_led_color_rgb(2, r, g, b))

    async def set_led_mode(self, target: LEDTarget, on: bool) -> bool:
        """Set LED on/off mode."""
        return await self._send_led_command(build_led_mode(target, on))

    async def read_led_status(self) -> Optional[dict]:
        """Read LED status (22 bytes)."""
        if not self.connected:
            return None

        try:
            data = await self.client.read_gatt_char(CharUUID.LED_STATUS)
            self.last_packet_time = datetime.now()
            from .protocol import parse_led_status
            return parse_led_status(data)
        except Exception:
            self.command_error_count += 1
            return None

    async def read_dimension(self, dimension_id: int) -> Optional[int]:
        """Read dimension value."""
        if not self.connected:
            return None

        try:
            data = build_dimension_write(dimension_id, 0)
            await self.client.write_gatt_char(CharUUID.DIMENSION, data)
            result = await self.client.read_gatt_char(CharUUID.DIMENSION)
            if len(result) >= 8:
                _, value = struct.unpack("<II", result[:8])
                return value
            return None
        except Exception:
            self.command_error_count += 1
            return None

    async def write_dimension(self, dimension_id: int, value: int) -> bool:
        """Write dimension value."""
        if not self.connected:
            return False

        try:
            payload = build_dimension_write(dimension_id, value)
            data = build_generic_command(
                GenericCommandId.DIMENSION_SET, payload
            )
            await self.client.write_gatt_char(
                CharUUID.GENERIC_CONTROL, data
            )
            self.command_success_count += 1
            return True
        except Exception:
            self.command_error_count += 1
            return False

    async def save_dimensions(self) -> bool:
        """Save all dimensions to flash (auto-saved on each DimensionSet)."""
        return self.connected

    async def set_wifi_config(self, ssid: str, password: str) -> bool:
        """Set WiFi configuration."""
        if not self.connected:
            return False

        try:
            data = build_wifi_config(ssid, password)
            await self.client.write_gatt_char(CharUUID.WIFI_CONFIG, data)
            self.command_success_count += 1
            return True
        except Exception:
            self.command_error_count += 1
            return False

    async def read_wifi_status(self) -> Optional[dict]:
        """Read WiFi configuration status (33 bytes: 32 SSID + 1 status)."""
        if not self.connected:
            return None

        try:
            data = await self.client.read_gatt_char(CharUUID.WIFI_CONFIG)
            from .protocol import parse_wifi_status
            return parse_wifi_status(data)
        except Exception:
            self.command_error_count += 1
            return None

    async def read_device_info(self) -> Optional[dict]:
        """Read Device Information Service (BLE SIG 0x180A).

        Returns dict with:
        - manufacturer_name: e.g., "Rovothome"
        - model_number: e.g., "ceily" or "wally"
        - serial_number: e.g., "1234567890123456"
        - hardware_revision: e.g., "v1"
        - firmware_revision: e.g., "2.7.10-efac753f-p3"
        - protocol_version: parsed from firmware_revision suffix (e.g., 3)
        """
        # Use client.is_connected directly (not self.connected)
        # because this may be called during _connect_and_pair before
        # connection_state is set to CONNECTED.
        if not self.client or not self.client.is_connected:
            return None

        result = {
            "manufacturer_name": None,
            "model_number": None,
            "serial_number": None,
            "hardware_revision": None,
            "firmware_revision": None,
            "protocol_version": None,
        }

        try:
            # Read Manufacturer Name (e.g., "Rovothome")
            data = await self.client.read_gatt_char(CharUUID.MANUFACTURER_NAME)
            result["manufacturer_name"] = data.decode("utf-8").rstrip("\x00")
        except Exception as e:
            print(f"[BLE] Failed to read manufacturer_name: {e}")

        try:
            # Read Model Number (e.g., "ceily" or "wally")
            data = await self.client.read_gatt_char(CharUUID.MODEL_NUMBER)
            result["model_number"] = data.decode("utf-8").rstrip("\x00")
        except Exception as e:
            print(f"[BLE] Failed to read model_number: {e}")

        try:
            # Read Serial Number (e.g., "1234567890123456")
            data = await self.client.read_gatt_char(CharUUID.SERIAL_NUMBER)
            result["serial_number"] = data.decode("utf-8").rstrip("\x00")
        except Exception as e:
            print(f"[BLE] Failed to read serial_number: {e}")

        try:
            # Read Hardware Revision (e.g., "v1")
            data = await self.client.read_gatt_char(CharUUID.HARDWARE_REVISION)
            result["hardware_revision"] = data.decode("utf-8").rstrip("\x00")
        except Exception as e:
            print(f"[BLE] Failed to read hardware_revision: {e}")

        try:
            # Read Firmware Revision (e.g., "2.7.10-efac753f-p3")
            data = await self.client.read_gatt_char(CharUUID.FIRMWARE_REVISION)
            result["firmware_revision"] = data.decode("utf-8").rstrip("\x00")
            # Parse protocol version from fw revision suffix (e.g., "...-p3" -> 3)
            fw = result["firmware_revision"]
            if fw and "-p" in fw:
                try:
                    result["protocol_version"] = int(fw.rsplit("-p", 1)[1])
                except (ValueError, IndexError):
                    pass
        except Exception as e:
            print(f"[BLE] Failed to read firmware_revision: {e}")

        self.last_packet_time = datetime.now()
        print(f"[BLE] Device info result: {result}")
        return result

    async def read_all_dimensions(self) -> Optional[dict]:
        """Read all dimensions from device (DimensionGet + notify response)."""
        if not self.connected:
            return None

        try:
            self._dimension_event = asyncio.Event()
            self._dimension_result = None
            data = build_generic_command(GenericCommandId.DIMENSION_GET)
            await self.client.write_gatt_char(
                CharUUID.GENERIC_CONTROL, data
            )
            await asyncio.wait_for(
                self._dimension_event.wait(), timeout=3.0
            )
            return self._dimension_result
        except Exception:
            self.command_error_count += 1
            return None
        finally:
            self._dimension_event = None

    async def request_user_list(self) -> bool:
        """Send generic command 0x05 to request user list."""
        if not self.connected:
            return False
        try:
            data = build_generic_command(GenericCommandId.USER_LIST_REQUEST)
            await self.client.write_gatt_char(CharUUID.GENERIC_CONTROL, data)
            self.command_success_count += 1
            logger.info("Sent USER_LIST_REQUEST (0x05)")
            return True
        except Exception as e:
            logger.warning("USER_LIST_REQUEST failed: %s", e)
            self.command_error_count += 1
            return False

    def get_stats(self) -> dict:
        """Get command statistics."""
        total = self.command_success_count + self.command_error_count
        success_rate = (
            (self.command_success_count / total * 100) if total > 0 else 0
        )
        return {
            "success_count": self.command_success_count,
            "error_count": self.command_error_count,
            "success_rate": round(success_rate, 1),
        }

    def get_connection_info(self) -> dict:
        """Get current connection info."""
        info = {
            "connected": self.connected,
            "state": self.connection_state.value,
            "device_name": self.device_name,
            "device_address": self.device_address,
            "device_type": self.device_type,
            "profile_id": self.profile_id,
            "rssi": self.rssi,
            "last_packet": (
                self.last_packet_time.isoformat()
                if self.last_packet_time else None
            ),
        }
        if self.device_info:
            info["device_info"] = self.device_info
        return info
