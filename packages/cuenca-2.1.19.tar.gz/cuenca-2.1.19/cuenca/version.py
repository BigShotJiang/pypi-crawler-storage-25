__version__ = '2.1.19'
CLIENT_VERSION = __version__
API_VERSION = '2020-03-19'
