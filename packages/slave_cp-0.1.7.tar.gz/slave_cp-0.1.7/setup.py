"""Setup configuration for slave-cp package."""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="slave_cp",
    version="0.1.7",
    author="Ayush Kunwar Singh",
    author_email="block-plant@users.noreply.github.com",
    description="A CLI tool to automate competitive programming workflow - fetch, test, and submit solutions",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/block-plant/slave-cp",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Build Tools",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Environment :: Console",
        "Topic :: Utilities",
    ],
    python_requires=">=3.7",
    install_requires=[
        "click>=8.0.0",
        "requests>=2.25.0",
        "beautifulsoup4>=4.9.0",
        "selenium>=4.0.0",
        "undetected-chromedriver>=3.5.0",
        "setuptools",         
        "rich>=10.0.0",
        "curl_cffi>=0.6.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0.0",
            "pytest-cov>=2.12.0",
            "black>=21.0",
            "flake8>=3.9.0",
            "twine>=3.4.0",
            "build>=0.7.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "slave-cp=slave_cp.cli:main",
        ],
    },
    keywords="competitive-programming codeforces cli automation testing",
    project_urls={
        "Bug Reports": "https://github.com/block-plant/slave-cp/issues",
        "Source": "https://github.com/block-plant/slave-cp",
        "Documentation": "https://github.com/block-plant/slave-cp/blob/main/USER_MANUAL.md",
    },
)