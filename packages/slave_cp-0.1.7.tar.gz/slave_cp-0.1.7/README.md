# slave-cp

> A powerful CLI tool that automates your competitive programming workflow — fetch problems, test locally, and auto-submit solutions.

[![PyPI version](https://badge.fury.io/py/slave-cp.svg)](https://pypi.org/project/slave-cp/)
[![Python 3.7+](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## ✨ Features

- 🚀 **Quick Setup** — One command to initialize your workspace and credentials
- 🌐 **Multi-Platform Support** — Works with Codeforces and CodeChef
- 🔍 **Auto-Fetch** — Automatically scrapes problems and test cases
- 🧪 **Local Testing** — Run solutions against sample inputs with rich diff tables
- 📤 **Auto-Submit** — Submit directly from terminal with real-time verdict tracking
- 🎨 **Rich Terminal UI** — Beautiful colored output with status indicators
- 🔧 **23 Languages Supported** — From C++ to Rust, Python to Haskell

---

## 📦 Installation

```bash
pip install slave-cp
```

**Requirements:**
- Python 3.7 or higher
- Compiler/interpreter for your chosen language (e.g., `g++` for C++, `python` for Python)

---

## 🚀 Quick Start

### 1. Initialize Your Workspace

```bash
slave-cp init ~/competitive
```

This will:
- Set your workspace directory
- Save Codeforces credentials (handle & password)
- Save CodeChef credentials (handle & password)
- Set your default programming language

### 2. Fetch a Contest

**Codeforces:**
```bash
slave-cp fetch CF1234
```

**CodeChef:**
```bash
slave-cp fetch CC-START001
```

This creates a folder with all problems and their test cases:
```
CF1234/
├── A/
│   ├── input1.txt
│   ├── output1.txt
│   ├── input2.txt
│   └── output2.txt
├── B/
│   ├── input1.txt
│   └── ...
└── ...
```

### 3. Write Your Solution

Create your solution file in the problem folder:
```bash
cd CF1234/A
touch solution.cpp  # or .py, .java, etc.
```

### 4. Test Locally

```bash
slave-cp run A
```

Or with explicit contest ID:
```bash
slave-cp run A --contest CF1234
```

**Output:**
```
╭───────────────────────────────────────────────────────────╮
│ Test Case 1                                        ✅ AC  │
├───────────────────────────────────────────────────────────┤
│ Input:     5 3                                            │
│ Expected:  8                                              │
│ Got:       8                                              │
╰───────────────────────────────────────────────────────────╯

All test cases passed! 🎉
Submit to Codeforces? [y/N]:
```

### 5. Submit (Optional)

If all tests pass, you'll be prompted to submit. Type `y` to submit directly to the platform.

---

## 📚 Commands

| Command | Description |
|---------|-------------|
| `slave-cp init <path>` | Initialize workspace and save credentials |
| `slave-cp fetch <contest-id>` | Fetch problems and test cases from a contest |
| `slave-cp run <problem>` | Test your solution against sample inputs |
| `slave-cp run <problem> --contest <id>` | Test with explicit contest ID |
| `slave-cp config` | Display current configuration |
| `slave-cp list` | List all contests in workspace |
| `slave-cp check` | Check installed compilers/interpreters |
| `slave-cp --help` | Show help message |

---

## 🌍 Supported Platforms

### Codeforces
- Contest format: `CF<contest-number>` (e.g., `CF1234`)
- Scrapes problems using `requests` + `BeautifulSoup`
- Auto-login with saved credentials
- Real-time verdict polling

### CodeChef
- Contest format: `CC-<contest-code>` (e.g., `CC-START001`)
- Uses Selenium with headless Chrome
- Supports practice problems and contests
- Automated CodeMirror injection for submission

---

## 💻 Supported Languages (23)

Auto-detected by file extension:

| Language | Extension | Compiler/Interpreter Required |
|----------|-----------|-------------------------------|
| C++ | `.cpp` | `g++` |
| C | `.c` | `gcc` |
| Python | `.py` | `python` or `python3` |
| Java | `.java` | `javac` + `java` |
| Kotlin | `.kt` | `kotlinc` + `kotlin` |
| Go | `.go` | `go` |
| Rust | `.rs` | `rustc` |
| C# | `.cs` | `dotnet-script` |
| Ruby | `.rb` | `ruby` |
| JavaScript | `.js` | `node` |
| TypeScript | `.ts` | `ts-node` |
| Haskell | `.hs` | `ghc` |
| Scala | `.scala` | `scalac` + `scala` |
| D | `.d` | `dmd` |
| Pascal | `.pas` | `fpc` |
| Perl | `.pl` | `perl` |
| PHP | `.php` | `php` |
| Swift | `.swift` | `swift` |
| Lua | `.lua` | `lua` |
| R | `.r` | `Rscript` |
| Dart | `.dart` | `dart` |
| F# | `.fs` | `dotnet fsi` |
| PyPy | `.pypy` | `pypy` or `pypy3` |

Run `slave-cp check` to verify which languages are available on your system.

---

## ⚙️ Configuration

Configuration is stored at `~/.slave-cp/config.json`:

```json
{
  "workspace": "/Users/username/competitive",
  "language": "cpp",
  "codeforces": {
    "handle": "tourist",
    "password": "your-password"
  },
  "codechef": {
    "handle": "gennady.korotkevich",
    "password": "your-password"
  }
}
```

**View current config:**
```bash
slave-cp config
```

**Update workspace or credentials:**
```bash
slave-cp init ~/new-workspace
```

---

## 🧪 Testing Workflow

### Verdicts

| Verdict | Symbol | Meaning |
|---------|--------|---------|
| AC | ✅ | Accepted — correct output |
| WA | ❌ | Wrong Answer — output mismatch |
| TLE | ⏱️ | Time Limit Exceeded (>5s) |
| RE | 💥 | Runtime Error — program crashed |
| CE | 🔧 | Compilation Error — code didn't compile |

### Diff Table

When output doesn't match:
```
╭───────────────────────────────────────────────────────────╮
│ Test Case 2                                        ❌ WA  │
├───────────────────────────────────────────────────────────┤
│ Input:     10 20 30                                       │
│ Expected:  60                                             │
│ Got:       50                                             │
╰───────────────────────────────────────────────────────────╯
```

---

## 🔧 Troubleshooting

### HTTP 403 Error on Codeforces Fetch

**Problem:** Codeforces blocks the scraper

**Solution:** This will be fixed in the next version (0.1.1). For now, try:
- Running the command again (sometimes transient)
- Using a VPN if your IP is rate-limited

### Wrong/Empty Credentials Accepted

**Problem:** Invalid credentials saved without validation

**Solution:** Fixed in version 0.1.1. Meanwhile, manually edit `~/.slave-cp/config.json` to ensure credentials are correct.

### Selenium/Chrome Issues (CodeChef)

**Problem:** `chromedriver not found` or browser errors

**Solution:**
```bash
# macOS
brew install chromedriver

# Ubuntu/Debian
sudo apt-get install chromium-chromedriver

# Windows
Download from https://chromedriver.chromium.org/
```

### Compiler Not Found

**Problem:** `g++: command not found`

**Solution:**
```bash
# macOS
xcode-select --install

# Ubuntu/Debian
sudo apt-get install build-essential

# Windows
Install MinGW or use WSL
```

Check installed compilers:
```bash
slave-cp check
```

---

## 📖 Advanced Usage

### Custom Time Limit

By default, solutions timeout after 5 seconds. This is hardcoded but can be adjusted in future versions.

### Multiple Solutions

You can have multiple solution files (e.g., `solution.cpp`, `brute.cpp`) in the same problem folder. `slave-cp run` will use the first one it finds matching your default language.

### Manual Test Cases

Add your own test cases by creating `input{n}.txt` and `output{n}.txt` pairs in the problem folder.

---

## 🤝 Contributing

Contributions are welcome! Please feel free to submit issues or pull requests.

**Development setup:**
```bash
git clone https://github.com/block-plant/slave-cp.git
cd slave-cp
pip install -e .[dev]
pytest
```

---

## 📄 License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.

---

## 👤 Author

**Ayush Kunwar Singh** ([@block-plant](https://github.com/block-plant))

---

## 🙏 Acknowledgments

- Built with [Click](https://click.palletsprojects.com/) for CLI
- Styled with [Rich](https://rich.readthedocs.io/) for beautiful terminal output
- Web scraping powered by [BeautifulSoup](https://www.crummy.com/software/BeautifulSoup/) and [Selenium](https://www.selenium.dev/)

---

## 📊 Project Status

- ✅ Live on PyPI: `pip install slave-cp`
- ✅ Codeforces support
- ✅ CodeChef support
- ✅ 23 languages supported
- 🚧 Version 0.1.1 coming soon with bug fixes

---

## 🔗 Links

- **PyPI:** https://pypi.org/project/slave-cp/
- **GitHub:** https://github.com/block-plant/slave-cp
- **Issues:** https://github.com/block-plant/slave-cp/issues
- **Documentation:** [USER_MANUAL.md](USER_MANUAL.md)

---

**Happy Coding! 🚀**
