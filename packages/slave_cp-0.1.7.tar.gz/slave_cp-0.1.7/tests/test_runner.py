import os
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock
from slave_cp import runner


# ─── FIXTURES ───────────────────────────────────────────────────────────────

@pytest.fixture
def workspace(tmp_path):
    ws = tmp_path / "competitive"
    ws.mkdir()
    return ws


@pytest.fixture
def contest_folder(workspace):
    folder = workspace / "CF1234"
    folder.mkdir()
    return folder


@pytest.fixture
def problem_folder(contest_folder):
    folder = contest_folder / "A"
    folder.mkdir()
    return folder


def make_testcase(problem_folder, index, input_data, output_data):
    """Helper to write a test case pair."""
    (problem_folder / f"input{index}.txt").write_text(input_data,  encoding="utf-8")
    (problem_folder / f"output{index}.txt").write_text(output_data, encoding="utf-8")


# ─── LOAD TESTCASES ─────────────────────────────────────────────────────────

def test_load_testcases_single(problem_folder):
    make_testcase(problem_folder, 1, "5", "10")
    tcs = runner.load_testcases(problem_folder)
    assert len(tcs) == 1
    assert tcs[0]["input"]    == "5"
    assert tcs[0]["expected"] == "10"
    assert tcs[0]["index"]    == 1


def test_load_testcases_multiple(problem_folder):
    make_testcase(problem_folder, 1, "1", "2")
    make_testcase(problem_folder, 2, "3", "6")
    make_testcase(problem_folder, 3, "5", "10")
    tcs = runner.load_testcases(problem_folder)
    assert len(tcs) == 3


def test_load_testcases_empty(problem_folder):
    tcs = runner.load_testcases(problem_folder)
    assert tcs == []


def test_load_testcases_stops_at_gap(problem_folder):
    """Should stop loading if input2 is missing."""
    make_testcase(problem_folder, 1, "1", "2")
    make_testcase(problem_folder, 3, "5", "10")  # gap at 2
    tcs = runner.load_testcases(problem_folder)
    assert len(tcs) == 1


# ─── DETECT SOLUTION ────────────────────────────────────────────────────────

def test_detect_solution_cpp(contest_folder):
    (contest_folder / "A.cpp").write_text("int main(){}", encoding="utf-8")
    path, lang = runner.detect_solution(contest_folder, "A")
    assert path is not None
    assert lang["name"] == "C++"


def test_detect_solution_python(contest_folder):
    (contest_folder / "A.py").write_text("print(1)", encoding="utf-8")
    path, lang = runner.detect_solution(contest_folder, "A")
    assert path is not None
    assert lang["name"] == "Python 3"


def test_detect_solution_not_found(contest_folder):
    path, lang = runner.detect_solution(contest_folder, "Z")
    assert path is None
    assert lang is None


# ─── RUN TESTCASE ───────────────────────────────────────────────────────────

def test_run_testcase_accepted():
    tc = {"index": 1, "input": "hello", "expected": "hello"}
    lang = runner.LANGUAGES[".py"]

    # Write a trivial python script that echoes input
    import tempfile, sys
    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
        f.write("import sys\nprint(sys.stdin.read().strip())")
        script = f.name

    try:
        result = runner.run_testcase(script, lang, tc)
        assert result["passed"]  == True
        assert result["status"]  == "ACCEPTED"
    finally:
        os.remove(script)


def test_run_testcase_wrong_answer():
    tc = {"index": 1, "input": "hello", "expected": "world"}
    lang = runner.LANGUAGES[".py"]

    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
        f.write("print('hello')")
        script = f.name

    try:
        result = runner.run_testcase(script, lang, tc)
        assert result["passed"] == False
        assert result["status"] == "WRONG ANSWER"
    finally:
        os.remove(script)


def test_run_testcase_tle():
    tc = {"index": 1, "input": "", "expected": "done"}
    lang = runner.LANGUAGES[".py"]

    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
        f.write("while True: pass")
        script = f.name

    try:
        result = runner.run_testcase(script, lang, tc)
        assert result["passed"] == False
        assert result["status"] == "TIME LIMIT EXCEEDED"
    finally:
        os.remove(script)


def test_run_testcase_runtime_error():
    tc = {"index": 1, "input": "", "expected": "ok"}
    lang = runner.LANGUAGES[".py"]

    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
        f.write("raise ValueError('oops')")
        script = f.name

    try:
        result = runner.run_testcase(script, lang, tc)
        assert result["passed"] == False
        assert result["status"] == "RUNTIME ERROR"
    finally:
        os.remove(script)


# ─── RUN PROBLEM ────────────────────────────────────────────────────────────

def test_run_problem_file_not_found(workspace):
    with pytest.raises(FileNotFoundError):
        runner.run_problem("Z", "CF9999", workspace)


def test_run_problem_no_testcases(contest_folder, problem_folder, workspace):
    (contest_folder / "A.py").write_text("print(1)", encoding="utf-8")
    # problem_folder exists but is empty
    result = runner.run_problem("A", "CF1234", workspace)
    assert result == False


# ─── DIFF DISPLAY ───────────────────────────────────────────────────────────

def test_print_result_accepted(capsys):
    result = {
        "passed":   True,
        "status":   "ACCEPTED",
        "actual":   "6",
        "expected": "6",
        "input":    "3"
    }
    # Should not raise
    runner.print_result(1, result)


def test_print_result_wrong_answer(capsys):
    result = {
        "passed":   False,
        "status":   "WRONG ANSWER",
        "actual":   "5",
        "expected": "6",
        "input":    "3"
    }
    runner.print_result(1, result)


def test_print_result_tle(capsys):
    result = {
        "passed":   False,
        "status":   "TIME LIMIT EXCEEDED",
        "actual":   "",
        "expected": "6",
        "input":    "3"
    }
    runner.print_result(1, result)


# ─── SUMMARY ────────────────────────────────────────────────────────────────

def test_print_summary_all_passed():
    results = [
        {"passed": True},
        {"passed": True},
        {"passed": True},
    ]
    runner.print_summary(results)  # should not raise


def test_print_summary_some_failed():
    results = [
        {"passed": True},
        {"passed": False},
        {"passed": True},
    ]
    runner.print_summary(results)  # should not raise