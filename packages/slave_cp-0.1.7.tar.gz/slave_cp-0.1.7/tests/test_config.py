import json
import pytest
from pathlib import Path
from unittest.mock import patch, mock_open
from slave_cp import config


# ─── FIXTURES ───────────────────────────────────────────────────────────────

@pytest.fixture
def temp_config(tmp_path, monkeypatch):
    """Redirect config file to a temp directory for each test."""
    monkeypatch.setattr(config, "CONFIG_DIR",  tmp_path / ".slave-cp")
    monkeypatch.setattr(config, "CONFIG_FILE", tmp_path / ".slave-cp" / "config.json")
    return tmp_path


# ─── INIT CONFIG ────────────────────────────────────────────────────────────

def test_init_config_creates_directory(temp_config):
    config.init_config()
    assert config.CONFIG_DIR.exists()


def test_init_config_creates_file(temp_config):
    config.init_config()
    assert config.CONFIG_FILE.exists()


def test_init_config_default_values(temp_config):
    config.init_config()
    cfg = config.load_config()
    assert cfg["workspace"]  is None
    assert cfg["extension"]  == ".cpp"
    assert cfg["codeforces"]["handle"]   is None
    assert cfg["codeforces"]["password"] is None


def test_init_config_does_not_overwrite(temp_config):
    """If config file already exists, init should not overwrite it."""
    config.init_config()
    cfg = config.load_config()
    cfg["extension"] = ".py"
    config.save_config(cfg)

    config.init_config()  # call again
    cfg2 = config.load_config()
    assert cfg2["extension"] == ".py"  # should still be .py


# ─── SAVE / LOAD ────────────────────────────────────────────────────────────

def test_save_and_load_config(temp_config):
    config.init_config()
    cfg = config.load_config()
    cfg["extension"] = ".java"
    config.save_config(cfg)

    loaded = config.load_config()
    assert loaded["extension"] == ".java"


def test_load_config_returns_dict(temp_config):
    config.init_config()
    cfg = config.load_config()
    assert isinstance(cfg, dict)


# ─── WORKSPACE ──────────────────────────────────────────────────────────────

def test_set_workspace_saves_path(temp_config, tmp_path):
    workspace = tmp_path / "competitive"
    config.set_workspace(str(workspace))
    cfg = config.load_config()
    assert cfg["workspace"] == str(workspace.resolve())


def test_set_workspace_creates_directory(temp_config, tmp_path):
    workspace = tmp_path / "new_workspace"
    assert not workspace.exists()
    config.set_workspace(str(workspace))
    assert workspace.exists()


def test_get_workspace_returns_path(temp_config, tmp_path):
    workspace = tmp_path / "competitive"
    config.set_workspace(str(workspace))
    result = config.get_workspace()
    assert isinstance(result, Path)
    assert result == workspace.resolve()


def test_get_workspace_raises_if_not_set(temp_config):
    config.init_config()
    with pytest.raises(ValueError, match="Workspace not set"):
        config.get_workspace()


# ─── CREDENTIALS ────────────────────────────────────────────────────────────

def test_set_codeforces_credentials(temp_config):
    config.init_config()
    config.set_credentials("codeforces", "myhandle", "mypassword")
    cfg = config.load_config()
    assert cfg["codeforces"]["handle"]   == "myhandle"
    assert cfg["codeforces"]["password"] == "mypassword"


def test_get_credentials_codeforces(temp_config):
    config.init_config()
    config.set_credentials("codeforces", "user1", "pass1")
    creds = config.get_credentials("codeforces")
    assert creds["handle"]   == "user1"
    assert creds["password"] == "pass1"


def test_get_credentials_missing_platform(temp_config):
    config.init_config()
    creds = config.get_credentials("unknown_platform")
    assert creds == {}