__version__ = "0.1.7"
__author__  = "block-plant"
__email__   = "https://github.com/block-plant"
__license__ = "MIT"
__url__     = "https://github.com/block-plant/slave-cp"

from slave_cp.config import (
    get_config, save_config,
    get_workspace, set_workspace,
    get_cf_credentials, set_cf_credentials,
)
from slave_cp.utils import print_banner, print_success, print_error, print_warning, print_info