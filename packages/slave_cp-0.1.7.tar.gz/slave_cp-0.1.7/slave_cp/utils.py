import os
import sys
import platform
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import box

console = Console()


# ─── SYSTEM ─────────────────────────────────────────────────────────────────

def get_os() -> str:
    """Return the current operating system name."""
    system = platform.system().lower()
    if system == "windows":
        return "windows"
    elif system == "darwin":
        return "macos"
    elif system == "linux":
        return "linux"
    return "unknown"


def is_windows() -> bool:
    return get_os() == "windows"


def is_macos() -> bool:
    return get_os() == "macos"


def is_linux() -> bool:
    return get_os() == "linux"


def get_binary_name(name: str) -> str:
    """Return binary name with .exe extension on Windows."""
    return f"{name}.exe" if is_windows() else name


# ─── PATH HELPERS ────────────────────────────────────────────────────────────

def resolve_path(path: str) -> Path:
    """Resolve a path string to an absolute Path object."""
    return Path(path).expanduser().resolve()


def ensure_dir(path: Path) -> Path:
    """Create directory if it doesn't exist. Returns the path."""
    path.mkdir(parents=True, exist_ok=True)
    return path


def safe_read(path: Path, default: str = "") -> str:
    """Read a file safely. Returns default if file doesn't exist."""
    try:
        return path.read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        return default
    except Exception as e:
        console.print(f"[yellow]⚠ Could not read {path}: {e}[/]")
        return default


def safe_write(path: Path, content: str) -> bool:
    """Write to a file safely. Returns True on success."""
    try:
        path.write_text(content, encoding="utf-8")
        return True
    except Exception as e:
        console.print(f"[bold red]✘ Could not write to {path}: {e}[/]")
        return False


# ─── DISPLAY HELPERS ─────────────────────────────────────────────────────────

def print_banner():
    """Print the slave-cp welcome banner."""
    banner = Text()
    banner.append("  ███████╗██╗      █████╗ ██╗   ██╗███████╗      ██████╗██████╗ \n", style="bold cyan")
    banner.append("  ██╔════╝██║     ██╔══██╗██║   ██║██╔════╝     ██╔════╝██╔══██╗\n", style="bold cyan")
    banner.append("  ███████╗██║     ███████║██║   ██║█████╗       ██║     ██████╔╝\n", style="bold cyan")
    banner.append("  ╚════██║██║     ██╔══██║╚██╗ ██╔╝██╔══╝       ██║     ██╔═══╝ \n", style="bold cyan")
    banner.append("  ███████║███████╗██║  ██║ ╚████╔╝ ███████╗     ╚██████╗██║     \n", style="bold cyan")
    banner.append("  ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝      ╚═════╝╚═╝     \n", style="bold cyan")
    banner.append("\n  Automate your competitive programming workflow.\n", style="dim")
    banner.append("  github.com/block-plant/slave-cp\n", style="dim")
    console.print(Panel(banner, box=box.ROUNDED, border_style="cyan"))


def print_success(message: str):
    """Print a success message."""
    console.print(f"[bold green]✔ {message}[/]")


def print_error(message: str):
    """Print an error message."""
    console.print(f"[bold red]✘ {message}[/]")


def print_warning(message: str):
    """Print a warning message."""
    console.print(f"[bold yellow]⚠ {message}[/]")


def print_info(message: str):
    """Print an info message."""
    console.print(f"[dim]{message}[/]")


def print_divider(char: str = "─", length: int = 45):
    """Print a horizontal divider."""
    console.print(char * length)


# ─── DIFF HELPERS ────────────────────────────────────────────────────────────

def diff_strings(expected: str, actual: str) -> list[dict]:
    """
    Compare expected and actual output line by line.
    Returns a list of dicts with line info and match status.
    """
    expected_lines = expected.splitlines()
    actual_lines   = actual.splitlines()
    max_lines      = max(len(expected_lines), len(actual_lines))

    diff = []
    for i in range(max_lines):
        exp = expected_lines[i] if i < len(expected_lines) else None
        act = actual_lines[i]   if i < len(actual_lines)   else None
        diff.append({
            "line":     i + 1,
            "expected": exp if exp is not None else "(missing)",
            "actual":   act if act is not None else "(missing)",
            "match":    exp == act
        })

    return diff


def print_diff_table(input_data: str, expected: str, actual: str):
    """Print a rich colored diff table comparing expected vs actual output."""
    diff = diff_strings(expected, actual)
    input_lines = input_data.splitlines()

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold")
    table.add_column("Line", style="dim",   width=6)
    table.add_column("Input",               style="cyan")
    table.add_column("Expected Output",     style="green")
    table.add_column("Your Output",         style="red")

    for i, row in enumerate(diff):
        inp      = input_lines[i] if i < len(input_lines) else ""
        act_text = Text(row["actual"])

        if not row["match"]:
            act_text.stylize("bold red")

        table.add_row(str(row["line"]), inp, row["expected"], act_text)

    console.print()
    console.print(table)
    console.print()


# ─── VERDICT HELPERS ─────────────────────────────────────────────────────────

def print_verdict(verdict: str):
    """Print a colored verdict based on the result string."""
    verdict_lower = verdict.lower()

    if "accepted" in verdict_lower:
        console.print(f"\n[bold green]  ✔ ACCEPTED[/] 🎉")
    elif "wrong answer" in verdict_lower:
        console.print(f"\n[bold red]  ✘ WRONG ANSWER[/]")
    elif "time limit" in verdict_lower:
        console.print(f"\n[bold yellow]  ✘ TIME LIMIT EXCEEDED[/]")
    elif "memory limit" in verdict_lower:
        console.print(f"\n[bold yellow]  ✘ MEMORY LIMIT EXCEEDED[/]")
    elif "runtime error" in verdict_lower:
        console.print(f"\n[bold red]  ✘ RUNTIME ERROR[/]")
    elif "compilation error" in verdict_lower:
        console.print(f"\n[bold red]  ✘ COMPILATION ERROR[/]")
    elif "skipped" in verdict_lower:
        console.print(f"\n[bold dim]  — SKIPPED[/]")
    else:
        console.print(f"\n[bold cyan]  Verdict: {verdict}[/]")


# ─── CONTEST HELPERS ─────────────────────────────────────────────────────────

def list_contests(workspace: Path):
    """Print all contests available in the workspace."""
    if not workspace.exists():
        print_error(f"Workspace not found: {workspace}")
        return

    contests = [d for d in workspace.iterdir() if d.is_dir()]

    if not contests:
        print_warning("No contests found in workspace.")
        return

    table = Table(title="Available Contests", box=box.ROUNDED, header_style="bold cyan")
    table.add_column("Contest",  style="bold")
    table.add_column("Problems", style="green")
    table.add_column("Path",     style="dim")

    for contest in sorted(contests):
        problems = [f for f in contest.iterdir() if f.suffix in [
            ".cpp", ".py", ".java", ".go", ".rs", ".kt",
            ".c", ".cs", ".rb", ".js", ".ts", ".hs",
            ".scala", ".d", ".pas", ".pl", ".php",
            ".swift", ".lua", ".r", ".dart", ".fs"
        ]]
        table.add_row(
            contest.name,
            str(len(problems)),
            str(contest)
        )

    console.print()
    console.print(table)
    console.print()


def list_problems(contest_folder: Path):
    """Print all problems available in a contest folder."""
    if not contest_folder.exists():
        print_error(f"Contest folder not found: {contest_folder}")
        return

    from slave_cp.runner import LANGUAGES

    problems = []
    for ext in LANGUAGES:
        for f in contest_folder.glob(f"*{ext}"):
            problems.append(f)

    if not problems:
        print_warning(f"No solution files found in {contest_folder.name}")
        return

    table = Table(title=f"Problems in {contest_folder.name}", box=box.ROUNDED, header_style="bold cyan")
    table.add_column("Problem",    style="bold")
    table.add_column("Language",   style="green")
    table.add_column("Test Cases", style="yellow")

    from slave_cp.runner import LANGUAGES as LANG

    for f in sorted(problems):
        lang_name   = LANG.get(f.suffix, {}).get("name", f.suffix)
        tc_folder   = contest_folder / f.stem
        tc_count    = 0
        if tc_folder.exists():
            tc_count = len(list(tc_folder.glob("input*.txt")))

        table.add_row(f.name, lang_name, str(tc_count))

    console.print()
    console.print(table)
    console.print()


# ─── INSTALL CHECK ───────────────────────────────────────────────────────────

def check_dependencies():
    """Check if common compilers/interpreters are installed and print status."""
    import shutil

    tools = [
        ("g++",      "C++"),
        ("gcc",      "C"),
        ("python3",  "Python 3"),
        ("java",     "Java"),
        ("javac",    "Java Compiler"),
        ("kotlinc",  "Kotlin"),
        ("go",       "Go"),
        ("rustc",    "Rust"),
        ("node",     "Node.js"),
        ("tsc",      "TypeScript"),
        ("ghc",      "Haskell"),
        ("ruby",     "Ruby"),
        ("php",      "PHP"),
        ("swift",    "Swift"),
        ("lua",      "Lua"),
        ("Rscript",  "R"),
        ("dart",     "Dart"),
        ("scalac",   "Scala"),
    ]

    table = Table(title="Dependency Check", box=box.ROUNDED, header_style="bold cyan")
    table.add_column("Tool",      style="bold")
    table.add_column("Language",  style="cyan")
    table.add_column("Status",    style="green")

    for tool, lang in tools:
        found  = shutil.which(tool) is not None
        status = Text("✔ installed", style="green") if found else Text("✘ not found", style="red")
        table.add_row(tool, lang, status)

    console.print()
    console.print(table)
    console.print()