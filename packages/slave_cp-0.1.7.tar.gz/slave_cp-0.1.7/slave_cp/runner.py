import os
import subprocess
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich import box
from rich.text import Text

console = Console()

COMPILE_TIMEOUT = 30
RUN_TIMEOUT = 5

# ─── LANGUAGE DEFINITIONS ───────────────────────────────────────────────────

LANGUAGES = {
    ".cpp":  {
        "name": "C++",
        "compile": lambda src, out: ["g++", "-O2", "-std=c++17", "-o", out, src],
        "run":     lambda src, out: [out],
        "binary":  True,
        "template": """\
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    // your code here

    return 0;
}
"""
    },

    ".c": {
        "name": "C",
        "compile": lambda src, out: ["gcc", "-O2", "-o", out, src],
        "run":     lambda src, out: [out],
        "binary":  True,
        "template": """\
#include <stdio.h>

int main() {
    // your code here
    return 0;
}
"""
    },

    ".py": {
        "name": "Python 3",
        "compile": None,
        "run": lambda src, out: (["python3", src] if __import__('shutil').which("python3") else ["python", src]),
        "binary":  False,
        "template": """\
import sys
input = sys.stdin.readline

def main():
    pass  # your code here

main()
"""
    },

    ".java": {
        "name": "Java",
        "compile": lambda src, out: ["javac", src],
        "run":     lambda src, out: [
            "java",
            "-cp", str(Path(src).parent),
            Path(src).stem
        ],
        "binary":  False,
        "template": """\
import java.util.*;
import java.io.*;

public class {classname} {{
    public static void main(String[] args) throws IOException {{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        // your code here
    }}
}}
"""
    },

    ".kt": {
        "name": "Kotlin",
        "compile": lambda src, out: ["kotlinc", src, "-include-runtime", "-d", out + ".jar"],
        "run":     lambda src, out: ["java", "-jar", out + ".jar"],
        "binary":  False,
        "template": """\
fun main() {
    val br = System.`in`.bufferedReader()
    // your code here
}
"""
    },

    ".go": {
        "name": "Go",
        "compile": lambda src, out: ["go", "build", "-o", out, src],
        "run":     lambda src, out: [out],
        "binary":  True,
        "template": """\
package main

import (
    "bufio"
    "fmt"
    "os"
)

var reader *bufio.Reader
var writer *bufio.Writer

func main() {
    reader = bufio.NewReader(os.Stdin)
    writer = bufio.NewWriter(os.Stdout)
    defer writer.Flush()

    // your code here
    _ = fmt.Fscan
}
"""
    },

    ".rs": {
        "name": "Rust",
        "compile": lambda src, out: ["rustc", "-O", "-o", out, src],
        "run":     lambda src, out: [out],
        "binary":  True,
        "template": """\
use std::io::{self, BufRead, Write};

fn main() {
    let stdin = io::stdin();
    let stdout = io::stdout();
    let mut out = io::BufWriter::new(stdout.lock());

    for line in stdin.lock().lines() {
        let _line = line.unwrap();
        // your code here
        writeln!(out, "").unwrap();
    }
}
"""
    },

    ".cs": {
        "name": "C#",
        "compile": None,
        "run":     lambda src, out: ["dotnet-script", src],
        "binary":  False,
        "template": """\
using System;
using System.IO;

class Solution {
    static void Main(string[] args) {
        // your code here
    }
}
"""
    },

    ".rb": {
        "name": "Ruby",
        "compile": None,
        "run":     lambda src, out: ["ruby", src],
        "binary":  False,
        "template": """\
# your code here
"""
    },

    ".js": {
        "name": "JavaScript",
        "compile": None,
        "run":     lambda src, out: ["node", src],
        "binary":  False,
        "template": """\
const readline = require('readline');
const rl = readline.createInterface({ input: process.stdin });
const lines = [];
rl.on('line', line => lines.push(line.trim()));
rl.on('close', () => {
    // your code here
});
"""
    },

    ".ts": {
        "name": "TypeScript",
        "compile": lambda src, out: ["tsc", "--outFile", out + ".js", src],
        "run":     lambda src, out: ["node", out + ".js"],
        "binary":  False,
        "template": """\
import * as readline from 'readline';
const rl = readline.createInterface({ input: process.stdin });
const lines: string[] = [];
rl.on('line', (line: string) => lines.push(line.trim()));
rl.on('close', () => {
    // your code here
});
"""
    },

    ".hs": {
        "name": "Haskell",
        "compile": lambda src, out: ["ghc", "-O2", "-o", out, src],
        "run":     lambda src, out: [out],
        "binary":  True,
        "template": """\
import Control.Monad
import Data.List

main :: IO ()
main = do
    -- your code here
    return ()
"""
    },

    ".scala": {
        "name": "Scala",
        "compile": lambda src, out: ["scalac", "-d", out + ".jar", src],
        "run":     lambda src, out: ["scala", "-cp", out + ".jar", "Main"],
        "binary":  False,
        "template": """\
import scala.io.StdIn._

object Main extends App {
    // your code here
}
"""
    },

    ".d": {
        "name": "D",
        "compile": lambda src, out: ["dmd", "-O", "-of=" + out, src],
        "run":     lambda src, out: [out],
        "binary":  True,
        "template": """\
import std.stdio;
import std.string;

void main() {
    // your code here
}
"""
    },

    ".pas": {
        "name": "Pascal",
        "compile": lambda src, out: ["fpc", "-O2", "-o" + out, src],
        "run":     lambda src, out: [out],
        "binary":  True,
        "template": """\
program Solution;
begin
    { your code here }
end.
"""
    },

    ".pl": {
        "name": "Perl",
        "compile": None,
        "run":     lambda src, out: ["perl", src],
        "binary":  False,
        "template": """\
use strict;
use warnings;

# your code here
"""
    },

    ".php": {
        "name": "PHP",
        "compile": None,
        "run":     lambda src, out: ["php", src],
        "binary":  False,
        "template": """\
<?php
// your code here
?>
"""
    },

    ".swift": {
        "name": "Swift",
        "compile": lambda src, out: ["swiftc", "-O", "-o", out, src],
        "run":     lambda src, out: [out],
        "binary":  True,
        "template": """\
import Foundation

// your code here
"""
    },

    ".lua": {
        "name": "Lua",
        "compile": None,
        "run":     lambda src, out: ["lua", src],
        "binary":  False,
        "template": """\
-- your code here
"""
    },

    ".r": {
        "name": "R",
        "compile": None,
        "run":     lambda src, out: ["Rscript", src],
        "binary":  False,
        "template": """\
# your code here
"""
    },

    ".dart": {
        "name": "Dart",
        "compile": None,
        "run":     lambda src, out: ["dart", src],
        "binary":  False,
        "template": """\
import 'dart:io';

void main() {
    // your code here
}
"""
    },

    ".fs": {
        "name": "F#",
        "compile": None,
        "run":     lambda src, out: ["dotnet-fsi", src],
        "binary":  False,
        "template": """\
open System

// your code here
"""
    },
}


# ─── MAIN ENTRY POINT ───────────────────────────────────────────────────────

def run_problem(problem: str, contest_id: str, workspace: Path) -> bool:
    """Compile and run solution against all test cases. Returns True if all pass."""
    contest_folder = workspace / contest_id.upper()
    problem_folder = contest_folder / problem.upper()

    # ── Find solution file ──
    solution_file, lang = detect_solution(contest_folder, problem)
    if solution_file is None:
        raise FileNotFoundError(
            f"No solution file found for problem {problem.upper()} in {contest_folder}\n"
            f"Supported extensions: {', '.join(LANGUAGES.keys())}"
        )

    console.print(f"[dim]Language detected:[/] [bold]{lang['name']}[/]")

    # ── Validate test cases ──
    if not problem_folder.exists() or not any(problem_folder.iterdir()):
        console.print(
            f"[bold yellow]⚠ No test cases found in: {problem_folder}[/]\n"
            f"[dim]Run 'slave-cp fetch {contest_id}' first.[/]"
        )
        return False

    # ── Compile ──
    binary = None
    if lang["compile"] is not None:
        binary = compile_solution(solution_file, lang)
        if binary is None:
            return False
    else:
        binary = str(solution_file)

    # ── Load test cases ──
    test_cases = load_testcases(problem_folder)
    if not test_cases:
        console.print("[bold yellow]⚠ No test cases found.[/]")
        return False

    console.print(f"[dim]Running {len(test_cases)} test case(s)...[/]\n")

    # ── Run each test case ──
    results = []
    for tc in test_cases:
        result = run_testcase(binary, lang, tc)
        results.append(result)
        print_result(tc["index"], result)

    # ── Summary ──
    print_summary(results)

    # ── Cleanup binary ──
    if lang["binary"] and binary and os.path.exists(binary):
        try:
            os.remove(binary)
        except Exception:
            pass

    return all(r["passed"] for r in results)


# ─── DETECT SOLUTION FILE ───────────────────────────────────────────────────

def detect_solution(contest_folder: Path, problem: str):
    """
    Auto-detect solution file by scanning for known extensions.
    If multiple found, ask user which to run.
    """
    found = []
    for ext, lang in LANGUAGES.items():
        candidate = contest_folder / f"{problem.upper()}{ext}"
        if candidate.exists():
            found.append((candidate, lang))

    if not found:
        return None, None

    if len(found) == 1:
        return found[0]

    # Multiple files found — ask user
    console.print(f"\n[bold yellow]Multiple solution files found for {problem.upper()}:[/]")
    for i, (f, l) in enumerate(found):
        console.print(f"  [{i + 1}] {f.name}  ({l['name']})")

    while True:
        choice = input("\nWhich file to run? (enter number): ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(found):
            return found[int(choice) - 1]
        console.print("[red]Invalid choice. Try again.[/]")


# ─── COMPILE ────────────────────────────────────────────────────────────────

def compile_solution(solution_file: Path, lang: dict) -> str | None:
    binary = str(solution_file.with_suffix("")) + "_bin"
    console.print(f"[bold cyan]Compiling:[/] {solution_file.name} ... ", end="")

    compile_cmd = lang["compile"](str(solution_file), binary)

    try:
        result = subprocess.run(
            compile_cmd,
            capture_output=True,
            text=True,
            timeout=COMPILE_TIMEOUT
        )
    except FileNotFoundError:
        console.print(f"\n[bold red]✘ Compiler not found: {compile_cmd[0]}[/]")
        console.print(f"[dim]Install {lang['name']} and make sure it's in your PATH.[/]")
        return None
    except subprocess.TimeoutExpired:
        console.print("\n[bold red]✘ Compilation timed out.[/]")
        return None

    if result.returncode != 0:
        console.print("[bold red]FAILED[/]")
        console.print("\n[bold red]── Compilation Error ──────────────────────[/]")
        console.print(result.stderr.strip())
        console.print("[bold red]───────────────────────────────────────────[/]\n")
        return None

    console.print("[bold green]OK[/]")
    return binary


# ─── LOAD TEST CASES ────────────────────────────────────────────────────────

def load_testcases(problem_folder: Path) -> list[dict]:
    """Load all input/output pairs from problem folder."""
    test_cases = []
    index = 1
    while True:
        input_file  = problem_folder / f"input{index}.txt"
        output_file = problem_folder / f"output{index}.txt"
        if not input_file.exists() or not output_file.exists():
            break
        test_cases.append({
            "index":    index,
            "input":    input_file.read_text(encoding="utf-8").strip(),
            "expected": output_file.read_text(encoding="utf-8").strip()
        })
        index += 1
    return test_cases


# ─── RUN SINGLE TEST CASE ───────────────────────────────────────────────────

def run_testcase(binary: str, lang: dict, tc: dict) -> dict:
    """Run binary/interpreter against one test case."""
    run_cmd = lang["run"](binary, binary)

    try:
        result = subprocess.run(
            run_cmd,
            input=tc["input"],
            capture_output=True,
            text=True,
            timeout=RUN_TIMEOUT
        )

        if result.returncode != 0:
            return {
                "passed": False,
                "status": "RUNTIME ERROR",
                "actual":   result.stderr.strip(),
                "expected": tc["expected"],
                "input":    tc["input"]
            }

        actual = result.stdout.strip()
        passed = actual == tc["expected"]

        return {
            "passed":   passed,
            "status":   "ACCEPTED" if passed else "WRONG ANSWER",
            "actual":   actual,
            "expected": tc["expected"],
            "input":    tc["input"]
        }

    except subprocess.TimeoutExpired:
        return {
            "passed": False,
            "status": "TIME LIMIT EXCEEDED",
            "actual":   "",
            "expected": tc["expected"],
            "input":    tc["input"]
        }


# ─── PRINT RESULT ───────────────────────────────────────────────────────────

def print_result(index: int, result: dict):
    """Print result of a single test case with diff table if failed."""
    status = result["status"]

    if result["passed"]:
        console.print(f"  [bold green]✔ Test {index}[/]  →  [green]ACCEPTED[/]")
        return

    color = "yellow" if status == "TIME LIMIT EXCEEDED" else "red"
    console.print(f"  [bold {color}]✘ Test {index}[/]  →  [{color}]{status}[/]")

    if status == "TIME LIMIT EXCEEDED":
        console.print(f"    [dim]Exceeded {RUN_TIMEOUT}s time limit.[/]")
        console.print(f"\n    [bold]Input:[/]")
        for line in result["input"].splitlines():
            console.print(f"      {line}")
        console.print()
        return

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold")
    table.add_column("",               style="dim",   width=6)
    table.add_column("Input",          style="cyan")
    table.add_column("Expected Output",style="green")
    table.add_column("Your Output",    style="red")

    input_lines    = result["input"].splitlines()
    expected_lines = result["expected"].splitlines()
    actual_lines   = result["actual"].splitlines() if result["actual"] else ["(no output)"]

    max_rows = max(len(input_lines), len(expected_lines), len(actual_lines))

    for i in range(max_rows):
        inp = input_lines[i]    if i < len(input_lines)    else ""
        exp = expected_lines[i] if i < len(expected_lines) else ""
        act = actual_lines[i]   if i < len(actual_lines)   else ""

        act_text = Text(act)
        if act != exp:
            act_text.stylize("bold red")

        table.add_row(str(i + 1), inp, exp, act_text)

    console.print()
    console.print(table)
    console.print()


# ─── SUMMARY ────────────────────────────────────────────────────────────────

def print_summary(results: list[dict]):
    """Print final pass/fail summary."""
    total  = len(results)
    passed = sum(1 for r in results if r["passed"])
    failed = total - passed

    console.print("─" * 45)
    if failed == 0:
        console.print(f"[bold green]  ✔ All {total}/{total} test cases passed![/]")
    else:
        console.print(f"[bold red]  ✘ {passed}/{total} passed — {failed} failed[/]")
    console.print("─" * 45)