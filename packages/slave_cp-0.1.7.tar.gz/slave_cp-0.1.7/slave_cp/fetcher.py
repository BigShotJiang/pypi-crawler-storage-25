"""Fetcher module for scraping problems and test cases from competitive programming platforms."""

import re
import time
from pathlib import Path
from curl_cffi import requests as cf_requests
from bs4 import BeautifulSoup
from rich.console import Console

console = Console()

def _cf_pre_text(pre_tag) -> str:
    """Extract text from a Codeforces <pre> tag, preserving newlines.
    Handles both <br> tags and <div class='test-example-line'> wrappers."""
    # Case 1: lines wrapped in divs (modern Codeforces)
    divs = pre_tag.find_all("div", class_="test-example-line")
    if divs:
        return "\n".join(d.get_text() for d in divs).strip()

    # Case 2: lines separated by <br> tags (older Codeforces)
    for br in pre_tag.find_all("br"):
        br.replace_with("\n")
    return pre_tag.get_text().strip()


# ─── SOLUTION TEMPLATES ──────────────────────────────────────────────────────

_TEMPLATES = {
    ".cpp": """\
#include <bits/stdc++.h>
using namespace std;

int main() {{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    // TODO: solve {problem}

    return 0;
}}
""",
    ".py": """\
import sys
input = sys.stdin.readline

def main():
    # TODO: solve {problem}
    pass

if __name__ == "__main__":
    main()
""",
    ".java": """\
import java.util.*;
import java.io.*;

public class {problem} {{
    public static void main(String[] args) throws IOException {{
        Scanner sc = new Scanner(System.in);
        // TODO: solve {problem}
    }}
}}
""",
}


# ─── WRITE TESTCASES ─────────────────────────────────────────────────────────

def write_testcases(folder: Path, test_cases: list):
    """Write test cases to input/output files inside folder."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    for tc in test_cases:
        idx = tc["index"]
        (folder / f"input{idx}.txt").write_text(tc["input"],  encoding="utf-8")
        (folder / f"output{idx}.txt").write_text(tc["output"], encoding="utf-8")


# ─── CREATE SOLUTION TEMPLATE ─────────────────────────────────────────────────

def create_solution_template(folder: Path, problem: str, ext: str):
    """Create a solution template. Does NOT overwrite. Falls back to .cpp."""
    folder = Path(folder)
    if ext not in _TEMPLATES:
        ext = ".cpp"
    dest = folder / f"{problem}{ext}"
    if dest.exists():
        return
    dest.write_text(_TEMPLATES[ext].format(problem=problem), encoding="utf-8")


# ─── SCRAPE CODEFORCES TESTCASES ─────────────────────────────────────────────

def scrape_codeforces_testcases(url: str) -> list:
    """
    Fetch a Codeforces problem page and extract sample test cases.
    Uses curl_cffi to mimic real Chrome TLS fingerprint.

    Raises:
        ConnectionError: On any non-200 HTTP response
    """
    session = cf_requests.Session(impersonate="chrome110")
    response = session.get(url, timeout=15)

    if response.status_code != 200:
        raise ConnectionError(
            f"Failed to fetch {url} — HTTP {response.status_code}"
        )

    soup = BeautifulSoup(response.text, "html.parser")
    sample_div = soup.find("div", class_="sample-test")
    if not sample_div:
        return []

    inputs  = sample_div.find_all("div", class_="input")
    outputs = sample_div.find_all("div", class_="output")

    test_cases = []
    for idx, (inp, out) in enumerate(zip(inputs, outputs), 1):
        input_text  = _cf_pre_text(inp.find("pre"))
        output_text = _cf_pre_text(out.find("pre"))
        test_cases.append({
            "index":  idx,
            "input":  input_text,
            "output": output_text,
        })

    return test_cases


# ─── FETCH CODEFORCES ────────────────────────────────────────────────────────

def fetch_codeforces(contest_id: str, workspace: Path, target_folder: Path = None) -> bool:
    """Fetch all problems for a Codeforces contest using curl_cffi."""
    contest_url = f"https://codeforces.com/contest/{contest_id}"

    try:
        session = cf_requests.Session(impersonate="chrome110")

        console.print("[cyan]Establishing session with Codeforces...[/cyan]")
        session.get("https://codeforces.com", timeout=15)
        time.sleep(1)

        console.print(f"[cyan]Fetching contest {contest_id}...[/cyan]")
        response = session.get(contest_url, timeout=15)

        if response.status_code == 403:
            console.print("[red]HTTP 403 — still blocked. Try again in a few minutes.[/red]")
            return False
        elif response.status_code != 200:
            console.print(f"[red]HTTP {response.status_code} error.[/red]")
            return False

        soup = BeautifulSoup(response.text, "html.parser")
        problem_links = soup.find_all(
            "a", href=re.compile(rf"/contest/{contest_id}/problem/[A-Z]")
        )

        if not problem_links:
            console.print("[red]No problems found. Contest may not exist or hasn't started.[/red]")
            return False

        problems = sorted(set(link["href"].split("/")[-1] for link in problem_links))
        console.print(f"[green]Found {len(problems)} problems: {', '.join(problems)}[/green]")

        contest_dir = target_folder if target_folder else Path(workspace) / f"CF{contest_id}"
        contest_dir.mkdir(parents=True, exist_ok=True)

        for problem_id in problems:
            _fetch_cf_problem(session, contest_id, problem_id, contest_dir)

        console.print(f"[bold green]✓ Fetched CF{contest_id}[/bold green]")
        return True

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        return False


def _fetch_cf_problem(session, contest_id: str, problem_id: str, contest_dir: Path):
    """Fetch a single Codeforces problem — clean text, write files, create template."""
    problem_url = f"https://codeforces.com/contest/{contest_id}/problem/{problem_id}"

    try:
        console.print(f"[cyan]  Fetching problem {problem_id}...[/cyan]")
        time.sleep(0.5)

        response = session.get(problem_url, timeout=15)
        if response.status_code != 200:
            console.print(f"[red]    HTTP {response.status_code} for problem {problem_id}[/red]")
            return

        problem_dir = contest_dir / problem_id
        problem_dir.mkdir(parents=True, exist_ok=True)

        soup = BeautifulSoup(response.text, "html.parser")
        sample_div = soup.find("div", class_="sample-test")

        if not sample_div:
            console.print(f"[yellow]    No sample tests for {problem_id}[/yellow]")
        else:
            inputs  = sample_div.find_all("div", class_="input")
            outputs = sample_div.find_all("div", class_="output")

            test_cases = []
            for idx, (inp, out) in enumerate(zip(inputs, outputs), 1):
                test_cases.append({
                    "index":  idx,
                    "input":  _cf_pre_text(inp.find("pre")),
                    "output": _cf_pre_text(out.find("pre")),
                })

            write_testcases(problem_dir, test_cases)
            console.print(f"[green]    ✓ {problem_id}: {len(test_cases)} test case(s)[/green]")

        create_solution_template(contest_dir, problem_id, ".cpp")
        console.print(f"[green]    ✓ {problem_id}.cpp template created[/green]")

    except Exception as e:
        console.print(f"[red]    Error fetching {problem_id}: {e}[/red]")


# ─── FETCH CONTEST (main entry point) ────────────────────────────────────────

def fetch_contest(contest_id: str, platform: str, workspace, config: dict = None, target_folder: Path = None):
    workspace = Path(workspace)

    if contest_id.startswith("CF"):
        cf_id = contest_id[2:]
        return fetch_codeforces(cf_id, workspace, target_folder)
    else:
        console.print("[red]Only Codeforces is supported. Use CF prefix e.g. CF1234[/red]")
        return False