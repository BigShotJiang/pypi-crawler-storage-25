"""Tests for v0.14.x welcome enhancements:
   1. Auto-detect prior certify receipt
   2. Extended summarizers (verify, synergy_scan, auto)
   3. Lifetime token-savings ledger
   4. Polished narrative for non-100/100 repos
"""
from __future__ import annotations

import json
from pathlib import Path

from atomadic_forge.a0_qk_constants.lifetime_savings_constants import (
    LIFETIME_LEDGER_REL,
    SCHEMA_VERSION_LIFETIME_SAVINGS_V1,
)
from atomadic_forge.a1_at_functions.lifetime_savings import (
    append_savings,
    read_savings_summary,
)
from atomadic_forge.a1_at_functions.response_enricher import (
    summarize_auto,
    summarize_for,
    summarize_synergy,
    summarize_verify,
)
from atomadic_forge.a1_at_functions.welcome_narrator import build_narrative
from atomadic_forge.a3_og_features.welcome_feature import welcome

# ---------- 1. auto-detect prior receipt --------------------------------


def test_welcome_auto_discovers_certify_json(tmp_path: Path) -> None:
    """When .atomadic-forge/certify.json exists and no since_receipt
    is passed, welcome must pick it up and emit since_last_scan with
    auto_discovered=True."""
    receipt_dir = tmp_path / ".atomadic-forge"
    receipt_dir.mkdir(parents=True)
    receipt = receipt_dir / "certify.json"
    receipt.write_text(json.dumps({"score": 80, "timestamp": "2026-05-01"}),
                        encoding="utf-8")
    out = welcome(project_root=tmp_path, skip_certify=True)
    diff = out["since_last_scan"]
    assert diff is not None
    assert diff["auto_discovered"] is True
    assert diff["prior_score"] == 80
    assert "certify.json" in diff["receipt_path"]


def test_welcome_explicit_since_receipt_beats_autodiscovery(tmp_path: Path) -> None:
    """Explicit since_receipt always wins, with auto_discovered=False."""
    auto = tmp_path / ".atomadic-forge" / "certify.json"
    auto.parent.mkdir(parents=True)
    auto.write_text(json.dumps({"score": 60, "timestamp": "old"}),
                     encoding="utf-8")
    explicit = tmp_path / "explicit.json"
    explicit.write_text(json.dumps({"score": 95, "timestamp": "newer"}),
                         encoding="utf-8")
    out = welcome(project_root=tmp_path, skip_certify=True,
                   since_receipt=explicit)
    diff = out["since_last_scan"]
    assert diff is not None
    assert diff["auto_discovered"] is False
    assert diff["prior_score"] == 95


def test_welcome_no_receipt_anywhere_returns_none(tmp_path: Path) -> None:
    out = welcome(project_root=tmp_path, skip_certify=True)
    assert out["since_last_scan"] is None


# ---------- 2. extended summarizers ------------------------------------


def test_summarize_verify_pass() -> None:
    s = summarize_verify({
        "verdict": "PASS", "score": 100, "wire_violation_count": 0,
    })
    assert "PASS" in s
    assert "100/100" in s
    assert "all gates green" in s.lower()


def test_summarize_verify_fail_surfaces_blocker_and_next_command() -> None:
    s = summarize_verify({
        "verdict": "FAIL", "score": 60, "wire_violation_count": 3,
        "fail_reasons": ["wire violations", "score under 75"],
        "next_command": "forge wire . --suggest-repairs",
    })
    assert "FAIL" in s
    assert "wire violations" in s
    assert "Suggestion" in s
    assert "suggest-repairs" in s


def test_summarize_synergy_with_pairs() -> None:
    s = summarize_synergy({
        "candidates": [{"name": "auth_pair"}],
    })
    assert "1 feature/CLI pair" in s
    assert "auth_pair" in s


def test_summarize_synergy_empty() -> None:
    s = summarize_synergy({"candidates": []})
    assert "0 feature/CLI pair" in s
    assert "well-connected" in s


def test_summarize_auto_with_certify_pass() -> None:
    s = summarize_auto({
        "verdict": "PASS", "score": 100,
        "cherry": {"symbols_picked": 17},
    })
    assert "PASS" in s
    assert "17 symbols promoted" in s
    assert "clean" in s.lower()


def test_summarize_auto_failing_recommends_wire() -> None:
    s = summarize_auto({
        "verdict": "FAIL", "score": 60,
        "cherry": {"symbols_picked": 5},
    })
    assert "FAIL" in s
    assert "Suggestion" in s
    assert "wire" in s


def test_summarize_for_dispatches_new_tools() -> None:
    assert summarize_for("verify", {"verdict": "PASS", "score": 100,
                                       "wire_violation_count": 0})
    assert summarize_for("synergy_scan", {"candidates": []})
    assert summarize_for("auto", {"verdict": "PASS", "score": 100,
                                    "cherry": {"symbols_picked": 0}})


# ---------- 3. lifetime savings ledger ---------------------------------


def test_append_savings_writes_ledger_jsonl(tmp_path: Path) -> None:
    ok = append_savings(project_root=tmp_path, tool="welcome",
                          tokens_saved=4200)
    assert ok is True
    ledger = tmp_path / LIFETIME_LEDGER_REL
    assert ledger.is_file()
    line = ledger.read_text(encoding="utf-8").splitlines()[0]
    entry = json.loads(line)
    assert entry["schema_version"] == SCHEMA_VERSION_LIFETIME_SAVINGS_V1
    assert entry["tool"] == "welcome"
    assert entry["tokens_saved"] == 4200


def test_append_savings_zero_or_empty_is_noop(tmp_path: Path) -> None:
    assert append_savings(project_root=tmp_path, tool="x", tokens_saved=0) is False
    assert append_savings(project_root=tmp_path, tool="", tokens_saved=10) is False


def test_read_savings_summary_empty(tmp_path: Path) -> None:
    out = read_savings_summary(project_root=tmp_path)
    assert out["ledger_present"] is False
    assert out["entry_count"] == 0
    assert out["tokens_saved_lifetime"] == 0
    assert out["by_tool"] == {}


def test_read_savings_summary_aggregates_by_tool(tmp_path: Path) -> None:
    append_savings(project_root=tmp_path, tool="welcome", tokens_saved=100)
    append_savings(project_root=tmp_path, tool="welcome", tokens_saved=250)
    append_savings(project_root=tmp_path, tool="certify", tokens_saved=50)
    out = read_savings_summary(project_root=tmp_path)
    assert out["entry_count"] == 3
    assert out["tokens_saved_lifetime"] == 400
    assert out["by_tool"] == {"welcome": 350, "certify": 50}
    assert out["first_seen_at"] is not None
    assert out["last_seen_at"] is not None


def test_read_savings_summary_skips_malformed_lines(tmp_path: Path) -> None:
    ledger = tmp_path / LIFETIME_LEDGER_REL
    ledger.parent.mkdir(parents=True)
    ledger.write_text(
        "{not json}\n"
        + json.dumps({"tool": "welcome", "tokens_saved": 80}) + "\n"
        + "\n"  # blank line
        + json.dumps({"tool": "x", "tokens_saved": "not a number"}) + "\n",
        encoding="utf-8",
    )
    out = read_savings_summary(project_root=tmp_path)
    assert out["entry_count"] == 1
    assert out["tokens_saved_lifetime"] == 80


def test_welcome_logs_session_to_ledger_and_reads_lifetime(tmp_path: Path) -> None:
    # First run — establishes the ledger.
    out1 = welcome(project_root=tmp_path, skip_certify=True)
    assert out1["session_tokens_saved_estimate"] >= 0
    assert out1["lifetime_savings"]["entry_count"] == 1
    # Second run — lifetime grows.
    out2 = welcome(project_root=tmp_path, skip_certify=True)
    assert out2["lifetime_savings"]["entry_count"] == 2
    assert (out2["lifetime_savings"]["tokens_saved_lifetime"]
            >= out1["lifetime_savings"]["tokens_saved_lifetime"])


def test_welcome_narrative_surfaces_lifetime_after_two_sessions(tmp_path: Path) -> None:
    # First run won't show lifetime (suppressed at <2 entries to avoid
    # underselling first-time users).
    out1 = welcome(project_root=tmp_path, skip_certify=True)
    assert "Lifetime savings" not in out1["narrative"]
    # Second run shows it.
    out2 = welcome(project_root=tmp_path, skip_certify=True)
    assert "Lifetime savings" in out2["narrative"]


# ---------- 4. polished failing-repo narrative -------------------------


def test_narrative_failing_repo_says_so_honestly() -> None:
    n = build_narrative(
        repo_name="X",
        scout={"primary_language": "python", "symbol_count": 50,
                "tier_distribution": {"a4_sy_orchestration": 50}},
        certify={"score": 60},
        wire={"verdict": "FAIL", "violation_count": 5},
        strengths=[],  # nothing fired
        priorities=[
            {"what": "fix violations", "why": "law", "next_call": "forge wire ."},
        ],
        next_call="forge wire . --suggest-repairs",
        forge_version="0.14.1", tool_count=66,
    )
    # Even with empty strengths list, narrative must say something
    # honest rather than leaving silence.
    assert "What's working: nothing crossed" in n
    assert "Forge is showing you the highest-leverage moves first" in n
    # Priorities now lead with framing line.
    assert "Priorities (highest leverage first" in n
    # Each priority surfaces its next_call as a Try line.
    assert "Try: forge wire ." in n


def test_narrative_clean_repo_keeps_strengths_section() -> None:
    n = build_narrative(
        repo_name="X",
        scout={"primary_language": "python", "symbol_count": 100,
                "tier_distribution": {"a1_at_functions": 100}},
        certify={"score": 100},
        wire={"verdict": "PASS", "violation_count": 0},
        strengths=["score 100 — production-ready."],
        priorities=[],
        next_call="forge emergent scan",
        forge_version="0.14.1", tool_count=66,
    )
    assert "What's working:" in n
    assert "score 100" in n
    # No "nothing crossed" paragraph when strengths fired.
    assert "nothing crossed" not in n


def test_narrative_returning_user_diff_block(tmp_path: Path) -> None:
    n = build_narrative(
        repo_name="X",
        scout={"symbol_count": 100,
                "tier_distribution": {"a1_at_functions": 100}},
        certify={"score": 95},
        wire={"verdict": "PASS", "violation_count": 0},
        strengths=[], priorities=[],
        next_call="x",
        forge_version="0.14.1", tool_count=66,
        diff={
            "score_delta": 5.0,
            "prior_score": 90,
            "current_score": 95,
            "auto_discovered": True,
        },
    )
    assert "Welcome back" in n
    assert "+5" in n or "+5.0" in n
    assert "(90 → 95)" in n or "(90 -> 95)" in n
    assert "auto-discovered" in n
