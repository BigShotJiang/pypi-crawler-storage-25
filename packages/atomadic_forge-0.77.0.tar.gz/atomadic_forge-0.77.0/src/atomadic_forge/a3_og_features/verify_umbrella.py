"""Tier a3 — `verify` umbrella tool.

The single composite go/no-go gate. Combines forge's existing
verification primitives into one MCP call so agents (and CI workflows)
can ask forge a single yes/no question:

    "Is this repo structurally ship-ready?"

Composes:
  * ``wire``           — upward-import violations
  * ``certify``        — 0-100 quality score (docs/tests/layout/imports)
  * ``score_patch``    — pre-merge patch risk (when a diff is supplied)
  * ``preflight_change`` — pre-edit guardrail (when intent + files supplied)

Returns a synthesized verdict (``PASS`` | ``REFINE`` | ``FAIL``) +
the underlying numbers + a single recommended next command.

Strategic positioning (the funding-deck line):
    Tests verify behavior. Security tools verify safety.
    `forge verify` verifies architecture.

This is the direct competitive answer to Qodo's PR-time verification
loop. Qodo verifies tests + security + governance; forge verify
covers the architecture axis those tools don't.

Pure orchestrator: composes existing a1 + a3 primitives, no LLM,
no I/O outside what the underlying tools already do. No side effects.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..a1_at_functions.certify_checks import certify as _certify
from ..a1_at_functions.patch_scorer import score_patch as _score_patch
from ..a1_at_functions.preflight_change import (
    preflight_change as _preflight_change,
)
from ..a1_at_functions.wire_check import scan_violations

SCHEMA_VERSION_VERIFY_V1 = "atomadic-forge.verify/v1"


def verify(
    *,
    project_root: Path,
    package: str | None = None,
    diff: str | None = None,
    intent: str | None = None,
    proposed_files: list[str] | None = None,
    fail_under: float = 75.0,
) -> dict[str, Any]:
    """Composite verification gate.

    Always runs ``wire`` + ``certify``. Optionally adds ``score_patch``
    (when ``diff`` is non-empty) and/or ``preflight_change`` (when
    both ``intent`` and ``proposed_files`` are supplied).

    Verdict synthesis:

      * **FAIL**  if wire has violations OR certify score < ``fail_under``
                  OR score_patch needs_human_review with high arch_risk
                  OR preflight write_scope_too_broad.
      * **REFINE** if certify score >= fail_under but issues remain,
                   OR score_patch needs_human_review for non-arch reasons
                   (test_risk / public_API / release).
      * **PASS**  otherwise.

    The verdict is a single string the agent can switch on. The full
    underlying reports are returned so the agent can drill in if
    needed.
    """
    project_root = Path(project_root).resolve()

    # Always-on gates.
    try:
        wire_report = scan_violations(project_root)
    except (OSError, ValueError) as exc:
        wire_report = {
            "verdict": "ERROR",
            "violation_count": 0,
            "violations": [],
            "error": f"{type(exc).__name__}: {exc}",
        }
    try:
        certify_report = _certify(
            project_root, project=project_root.name, package=package,
        )
    except Exception as exc:  # noqa: BLE001 — gate must not crash
        certify_report = {
            "schema_version": "atomadic-forge.certify/v1",
            "score": 0.0,
            "issues": [f"certify raised: {type(exc).__name__}: {exc}"],
        }

    # Optional gates.
    score_patch_report: dict[str, Any] | None = None
    if diff:
        try:
            score_patch_report = _score_patch(diff, project_root=project_root)
        except Exception as exc:  # noqa: BLE001
            score_patch_report = {
                "error": f"score_patch raised: {type(exc).__name__}: {exc}",
                "needs_human_review": True,
            }

    preflight_report: dict[str, Any] | None = None
    if intent and proposed_files:
        try:
            preflight_report = _preflight_change(
                intent=intent, proposed_files=list(proposed_files),
                project_root=project_root,
            )
        except Exception as exc:  # noqa: BLE001
            preflight_report = {
                "error": f"preflight_change raised: {type(exc).__name__}: {exc}",
                "write_scope_too_broad": True,
            }

    # Synthesize verdict.
    score = float(certify_report.get("score", 0.0))
    wire_pass = wire_report.get("verdict") == "PASS"
    wire_violations = int(wire_report.get("violation_count", 0))

    fail_reasons: list[str] = []
    refine_reasons: list[str] = []

    if wire_violations > 0:
        fail_reasons.append(
            f"wire reports {wire_violations} upward-import violation(s)"
        )
    elif not wire_pass:
        fail_reasons.append(
            f"wire verdict is {wire_report.get('verdict')!r} (expected PASS)"
        )
    if score < fail_under:
        fail_reasons.append(
            f"certify score {score:.1f} below fail_under threshold {fail_under}"
        )

    if score_patch_report and score_patch_report.get("needs_human_review"):
        if score_patch_report.get("architectural_risk"):
            fail_reasons.append(
                "score_patch flagged architectural_risk + needs_human_review"
            )
        elif (score_patch_report.get("test_risk")
              or score_patch_report.get("public_api_risk")
              or score_patch_report.get("release_risk")):
            refine_reasons.append(
                "score_patch flagged test_risk / public_api_risk / "
                "release_risk — review before merge"
            )

    if preflight_report and preflight_report.get("write_scope_too_broad"):
        fail_reasons.append(
            "preflight_change flagged write_scope_too_broad — split the patch"
        )

    if certify_report.get("issues") and score >= fail_under:
        # Score is acceptable but there are issues — REFINE not FAIL.
        refine_reasons.extend(certify_report["issues"][:3])

    if fail_reasons:
        verdict = "FAIL"
    elif refine_reasons:
        verdict = "REFINE"
    else:
        verdict = "PASS"

    # Map the dominant failing axis to a canonical golden-path recipe.
    # An agent reading verify gets verdict + score + next_command + the
    # NAME of the recipe that documents the fix path. Pure lookup; no
    # behaviour change when verdict is PASS.
    suggested_recipe = _suggested_recipe(
        certify_report=certify_report,
        wire_violations=wire_violations,
        score_patch_report=score_patch_report,
        preflight_report=preflight_report,
        score=score,
        fail_under=fail_under,
    )

    # v0.13 — wisdom capture prompt (Phase 4 / closing reflection).
    # When the session crossed trust thresholds (real work, not just
    # reading), assemble a draft insight from lineage events so the
    # agent has a pre-baked starting point for ``forge wisdom record``.
    # Always returns a payload (never None); caller checks
    # ``auto_record_threshold_met`` to decide whether to surface it.
    try:
        from ..a1_at_functions.wisdom_capture import assemble_capture_prompt
        wisdom_capture_prompt = assemble_capture_prompt(
            project_name=project_root.name,
            score_before=float(certify_report.get("score", 0.0)),
            score_after=score,
            lineage_events=_extract_lineage_events(certify_report),
            session_secs=0,  # caller can override; default skips the time gate
            trust_signals={
                "wire_violation_count": wire_violations,
                "certify_score": score,
                "verify_verdict_pre_synthesis": (
                    "PASS" if not fail_reasons else (
                        "REFINE" if not fail_reasons else "FAIL"
                    )
                ),
            },
        )
        # Any clean PASS is meaningful work worth capturing — lower the bar
        # so agents see the draft on every successful verify, not only when
        # score delta or lineage event thresholds are crossed.
        if verdict == "PASS" and not wisdom_capture_prompt.get("auto_record_threshold_met"):
            wisdom_capture_prompt["auto_record_threshold_met"] = True
            tags = wisdom_capture_prompt.get("draft_tags") or []
            wisdom_capture_prompt["next_command"] = (
                "forge wisdom record --insight \"<edit the suggested draft>\" "
                "--scope repo" + (f" --tags {','.join(tags[:3])}" if tags else "")
            )
    except Exception as exc:  # noqa: BLE001 — wisdom is best-effort
        wisdom_capture_prompt = {"error": f"capture failed: {exc!r}"}

    # Surface the wisdom draft at the top level for easy agent access.
    # Agents shouldn't have to dig 6 levels deep to find the capture prompt.
    wisdom_draft: dict | None = None
    if isinstance(wisdom_capture_prompt, dict) and "error" not in wisdom_capture_prompt:
        wisdom_draft = {
            "insight": wisdom_capture_prompt.get("suggested_insight", ""),
            "tags": wisdom_capture_prompt.get("draft_tags", []),
            "command": wisdom_capture_prompt.get("next_command"),
        }

    # Pick the single most actionable next-command.
    next_command = "(no action — verdict PASS)"
    if fail_reasons:
        if wire_violations > 0:
            next_command = (
                f"forge enforce {project_root} --apply  # auto-fix the "
                f"{wire_violations} wire violation(s)"
            )
        elif score < fail_under:
            issues = certify_report.get("issues", [])
            if issues:
                next_command = f"# certify says: {issues[0]}"
        elif preflight_report and preflight_report.get("write_scope_too_broad"):
            next_command = "split the patch into smaller, single-tier changes"
    elif refine_reasons:
        next_command = f"# review: {refine_reasons[0]}"

    # Slim gate summaries — agents need verdicts and counts, not full payloads.
    # Full reports are available by calling certify / wire directly.
    wire_summary = {
        "verdict": wire_report.get("verdict"),
        "violation_count": wire_report.get("violation_count", 0),
        "auto_fixable": wire_report.get("auto_fixable", 0),
        "new_dynamic_warnings": wire_report.get("new_dynamic_warnings",
                                                 len(wire_report.get("dynamic_import_warnings") or [])),
    }
    certify_summary = {
        "score": certify_report.get("score"),
        "verdict": (certify_report.get("health_summary") or {}).get("verdict"),
        "blockers": (certify_report.get("health_summary") or {}).get("blockers", 0),
        "score_components": certify_report.get("score_components"),
        "issues": certify_report.get("issues", []),
        "tests_skipped": certify_report.get("tests_skipped", False),
    }

    base = {
        "schema_version": SCHEMA_VERSION_VERIFY_V1,
        "verdict": verdict,
        "score": score,
        "fail_under": fail_under,
        "wire_violation_count": wire_violations,
        "wire_verdict": wire_report.get("verdict"),
        "fail_reasons": fail_reasons,
        "refine_reasons": refine_reasons,
        "next_command": next_command,
        "suggested_recipe": suggested_recipe,
        "wisdom_draft": wisdom_draft,
        "wisdom_capture_prompt": wisdom_capture_prompt,
        "gates_run": (
            ["wire", "certify"]
            + (["score_patch"] if score_patch_report else [])
            + (["preflight_change"] if preflight_report else [])
        ),
        "wire": wire_summary,
        "certify": certify_summary,
        "score_patch": score_patch_report,
        "preflight": preflight_report,
    }
    from ..a1_at_functions.response_enricher import (
        enrich_response as _enrich,
    )
    from ..a1_at_functions.response_enricher import (
        make_scope as _make_scope,
    )
    from ..a1_at_functions.response_enricher import (
        summarize_verify as _summarize_verify,
    )
    # Aggregate scope from the gates that actually ran.
    files = (wire_report.get("scope", {}) or {}).get("files_scanned", 0)
    syms = (certify_report.get("scope", {}) or {}).get("symbols_analyzed", 0)
    total_ms = (
        (wire_report.get("scope", {}) or {}).get("scan_duration_ms", 0)
        + (certify_report.get("scope", {}) or {}).get("scan_duration_ms", 0)
    )
    return _enrich(
        base,
        scope=_make_scope(
            files_scanned=files,
            symbols_analyzed=syms,
            tiers_traversed=5,
            scan_duration_ms=total_ms,
            basis_kind="files",
        ),
        summary=_summarize_verify(base),
    )


# ── wisdom-capture support ──────────────────────────────────────────
# Lift human-readable event strings out of the certify report so the
# capture prompt can present them as draft material. Best-effort: any
# missing field returns an empty list rather than raising.

def _extract_lineage_events(certify_report: dict[str, Any]) -> list[str]:
    """Pull short, human-readable event strings from a certify report.

    Used as the seed material for the wisdom_capture_prompt's
    ``suggested_insight`` and tag heuristics. Sample sources include
    issues, recommendations, and detail.test_run.failure_excerpts.
    """
    events: list[str] = []
    for issue in certify_report.get("issues") or []:
        events.append(str(issue))
    for rec in certify_report.get("recommendations") or []:
        events.append(str(rec))
    detail = certify_report.get("detail") or {}
    test_run = detail.get("test_run") or {}
    if isinstance(test_run, dict):
        passed = test_run.get("passed")
        failed = test_run.get("failed")
        if passed is not None and failed is not None:
            events.append(f"tests: {passed} passed, {failed} failed")
        for ex in test_run.get("failure_excerpts") or []:
            events.append(f"test failure: {str(ex)[:80]}")
    wire = detail.get("wire") or {}
    if isinstance(wire, dict):
        v = wire.get("violation_count")
        if v:
            events.append(f"wire violations: {v}")
    return events[:25]


# ── recipe linkage ───────────────────────────────────────────────────
# Map the dominant failure mode to a canonical golden-path recipe. The
# names here MUST exist in ``a1_at_functions/recipes.py`` — drift is
# caught by ``test_verify_suggested_recipe_names_resolve``.
_RECIPE_FOR_AXIS: dict[str, str] = {
    "wire_clean":     "fix_wire_violation",
    "no_upward_imports": "fix_wire_violation",
    "tests_pass":     "fix_test_detection",
    "tests_present":  "fix_test_detection",
    "ci_workflow":    "release_hardening",
    "changelog":      "release_hardening",
    "tier_layout":    "add_feature",
    "documentation":  "dev_cycle",
    "no_stubs":       "dev_cycle",
    "importable":     "dev_cycle",
}


def _suggested_recipe(
    *,
    certify_report: dict[str, Any],
    wire_violations: int,
    score_patch_report: dict[str, Any] | None,
    preflight_report: dict[str, Any] | None,
    score: float,
    fail_under: float,
) -> str | None:
    """Return the recipe name that best matches the dominant failure axis.

    Lookup-only — never raises, never returns an unknown recipe name.
    Returns ``None`` when verdict is PASS or no axis maps cleanly.
    """
    # Wire violations are always the loudest signal — fix them first.
    if wire_violations > 0:
        return "fix_wire_violation"

    # Walk certify axes in fail-weight order; return the first axis
    # that's failing AND has a recipe mapping.
    axes = certify_report.get("axes") or {}
    # Stable order: highest score_weight first so the most impactful
    # failing axis wins when multiple are red.
    axes_sorted = sorted(
        axes.items(),
        key=lambda kv: -int((kv[1] or {}).get("score_weight", 0)),
    )
    for axis_name, axis_data in axes_sorted:
        if not isinstance(axis_data, dict):
            continue
        if axis_data.get("ok") is False:
            recipe = _RECIPE_FOR_AXIS.get(axis_name)
            if recipe is not None:
                return recipe

    # Patch-side risks → the release-hardening checklist covers them.
    if score_patch_report and score_patch_report.get("needs_human_review"):
        if (score_patch_report.get("test_risk")
                or score_patch_report.get("public_api_risk")
                or score_patch_report.get("release_risk")):
            return "release_hardening"

    # Preflight write-scope failures point at dev_cycle (split + iterate).
    if preflight_report and preflight_report.get("write_scope_too_broad"):
        return "dev_cycle"

    # Score below threshold but no specific axis matched — give the
    # general dev_cycle as a last resort, only when actually failing.
    if score < fail_under:
        return "dev_cycle"

    return None
