"""``atomadic-forge metrics`` — emit / refresh the canonical forge_metrics.json.

Single source of truth for every public number Forge claims about itself —
mcp tool count, action count, CLI verb count, source/test files, lines of
code, Lean theorem count from the IP-protected proof corpus. Public surfaces (README, CHANGELOG,
welcome handshake, the Cloudflare Worker, shields.io badges) all read from
this artifact.

Usage::

    forge metrics                    # print live metrics, do not write
    forge metrics --apply            # rewrite forge_metrics.json at repo root
    forge metrics --json             # JSON to stdout (no file write)
    forge metrics --proof-corpus <path>   # override proof corpus auto-detect
    forge metrics --self-cert        # also embed certify score (slower)
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a2_mo_composites.repo_public_surface_sync import (
    DEFAULT_REPO_METRICS_CONFIG_PATH,
    plan_repo_public_surface_sync,
    render_repo_metrics_config_json,
)
from atomadic_forge.a3_og_features.forge_metrics_feature import emit_forge_metrics


def _live_cli_verb_count() -> int:
    """a4-side helper: count registered CLI verbs from the live Typer app.

    Lives here (a4) instead of a3 because the metrics feature must not
    import the CLI module — that would be an upward tier import.
    """
    try:
        from atomadic_forge.a4_sy_orchestration import cli as _cli
        commands = getattr(_cli.app, "registered_commands", []) or []
        groups = getattr(_cli.app, "registered_groups", []) or []
        return len(commands) + len(groups)
    except Exception:
        return 0

COMMAND_NAME = "metrics"
COMMAND_HELP = (
    "Emit forge_metrics.json — canonical metrics for README/CHANGELOG/welcome/worker."
)

app = typer.Typer(
    no_args_is_help=False, help=COMMAND_HELP, invoke_without_command=True,
)


@app.callback()
def run(
    ctx: typer.Context,
    apply: Annotated[bool, typer.Option(
        "--apply",
        help="Overwrite <repo_root>/forge_metrics.json with the freshly computed artifact.",
    )] = False,
    json_out: Annotated[bool, typer.Option(
        "--json",
        help="Emit the artifact to stdout as JSON (no human-readable summary).",
    )] = False,
    mhed: Annotated[Path | None, typer.Option(
        "--proof-corpus",
        help="Override proof corpus location (default: autodetect).",
        exists=False, file_okay=False, dir_okay=True, resolve_path=True,
    )] = None,
    self_cert: Annotated[bool, typer.Option(
        "--self-cert",
        help="Embed latest certify score (slower; runs the full pipeline).",
    )] = False,
    tests_passing: Annotated[int | None, typer.Option(
        "--tests-passing",
        help="Embed an externally-computed pytest pass count "
             "(from the most recent CI run).",
    )] = None,
    project: Annotated[Path, typer.Option(
        "--project",
        help="Forge repo root (default: cwd).",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
    )] = Path("."),
) -> None:
    """Compute live forge metrics and optionally write forge_metrics.json."""
    if ctx.invoked_subcommand is not None:
        return
    res = emit_forge_metrics(
        project,
        apply=apply,
        proof_corpus_root=mhed,
        skip_self_cert=not self_cert,
        cli_verbs_count=_live_cli_verb_count(),
        tests_passing=tests_passing,
    )
    if json_out:
        typer.echo(json.dumps(res["metrics"], indent=2, sort_keys=True))
        return
    m = res["metrics"]
    pm = m.get("metrics", {}) if isinstance(m.get("metrics"), dict) else {}
    typer.echo(f"forge_metrics — generated_utc={m.get('generated_utc', '?')}")
    typer.echo(f"  package_version       : {m.get('version', '?')}")
    typer.echo("  monadic_tiers         : 5")
    typer.echo(f"  mcp_tools             : {pm.get('mcp_tool_count', '?')}")
    typer.echo(f"  mcp_actions           : {pm.get('mcp_action_count', '?')}")
    typer.echo(f"  cli_verbs             : {pm.get('cli_verb_count', '?')}")
    typer.echo(f"  source_files          : {pm.get('source_file_count', '?')}")
    typer.echo(f"  source_lines          : {pm.get('source_line_count', '?')}")
    typer.echo(f"  test_files            : {pm.get('test_file_count', '?')}")
    typer.echo(f"  tests_passing         : {pm.get('test_count', '?')}")
    lean_count = int(pm.get("lean4_theorem_count") or 0)
    if lean_count:
        typer.echo(f"  lean_theorems.count   : {lean_count}")
    else:
        typer.echo("  lean_theorems         : not found "
                    "(set FORGE_PROOF_CORPUS or pass --proof-corpus)")
    if res["written_to"]:
        typer.echo(f"\nwritten -> {res['written_to']}")
    else:
        typer.echo("\n(dry-run; pass --apply to write forge_metrics.json)")


@app.command("repo")
def repo_cmd(
    project: Annotated[Path, typer.Option(
        "--project",
        help="Product repo root to update (default: cwd).",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    )] = Path("."),
    apply: Annotated[bool, typer.Option(
        "--apply",
        help="Write repo_metrics.json plus bounded README/server.json updates.",
    )] = False,
    json_out: Annotated[bool, typer.Option(
        "--json",
        help="Emit the plan as JSON.",
    )] = False,
    config: Annotated[Path | None, typer.Option(
        "--config",
        help="Optional repo metrics config JSON path.",
        exists=False,
        file_okay=True,
        dir_okay=False,
        resolve_path=False,
    )] = None,
    init_config: Annotated[bool, typer.Option(
        "--init-config",
        help="Create a starter .atomadic-forge/repo-metrics.config.json.",
    )] = False,
    commit: Annotated[bool, typer.Option(
        "--commit",
        help="After --apply, commit the repo metrics surface changes.",
    )] = False,
    push: Annotated[bool, typer.Option(
        "--push",
        help="After --apply, commit if needed and push the current branch.",
    )] = False,
    message: Annotated[str, typer.Option(
        "--message",
        help="Commit message used with --commit/--push.",
    )] = "docs(metrics): sync repo public metrics",
) -> None:
    """Update a product repo's own public metrics and copy surface.

    This is intentionally not Forge-specific. It computes metrics for the
    target repository, writes ``repo_metrics.json``, refreshes a bounded
    README block between ``<!-- forge:metrics:start -->`` markers, and
    syncs MCP ``server.json`` version/description when present.
    """
    root = project.resolve()
    if init_config:
        target = config if config is not None else Path(DEFAULT_REPO_METRICS_CONFIG_PATH)
        target_path = target if target.is_absolute() else root / target
        content = render_repo_metrics_config_json()
        if json_out:
            typer.echo(json.dumps({
                "schema_version": "atomadic-forge.repo_metrics_config_plan/v1",
                "path": str(target_path),
                "content": content,
                "would_write": not apply,
            }, indent=2, sort_keys=True))
            return
        if apply:
            target_path.parent.mkdir(parents=True, exist_ok=True)
            target_path.write_text(content, encoding="utf-8")
            typer.echo(f"wrote {target_path}")
        else:
            typer.echo(f"would write {target_path}")
            typer.echo("\n(dry-run; pass --apply to create the config)")
        return

    plan = plan_repo_public_surface_sync(root, config_path=config)
    if json_out:
        typer.echo(json.dumps(plan, indent=2, sort_keys=True))
        return
    typer.echo(
        f"repo public surface — {plan['metrics']['project']} "
        f"v{plan['metrics']['version']}"
    )
    typer.echo(
        f"  source_files          : {plan['metrics']['source_file_count']}"
    )
    typer.echo(
        f"  source_lines          : {plan['metrics']['source_line_count']}"
    )
    typer.echo(f"  test_files            : {plan['metrics']['test_file_count']}")
    typer.echo(
        "  languages             : "
        + ", ".join(plan["metrics"].get("languages") or ["unknown"])
    )
    written_paths: list[str] = []
    for write in plan["writes"]:
        target = (root / write["path"]).resolve()
        try:
            target.relative_to(root)
        except ValueError:
            typer.echo(f"  skipped {write['path']} — outside project root", err=True)
            continue
        if apply:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(write["content"], encoding="utf-8")
            written_paths.append(write["path"])
            typer.echo(f"  wrote {write['path']} — {write['reason']}")
        else:
            typer.echo(f"  would write {write['path']} — {write['reason']}")
    if not apply:
        typer.echo("\n(dry-run; pass --apply to update the product surface)")
        return
    if (commit or push) and written_paths:
        subprocess.run(["git", "add", *written_paths], cwd=str(root), check=True)
        diff = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=str(root),
        )
        if diff.returncode == 0:
            typer.echo("  no metric changes to commit")
        else:
            subprocess.run(["git", "commit", "-m", message], cwd=str(root), check=True)
            typer.echo(f"  committed — {message}")
    if push:
        branch = subprocess.run(
            ["git", "branch", "--show-current"],
            cwd=str(root),
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        if not branch:
            typer.echo("  push skipped — detached HEAD", err=True)
            return
        subprocess.run(["git", "push", "-u", "origin", branch], cwd=str(root), check=True)
        typer.echo(f"  pushed origin/{branch}")
