"""Tier a1 — pure response enrichment (scope block + summary line).

Adds two opt-in fields to a Forge tool response without touching any
existing field:

  * ``scope`` — real measurements (files_scanned, symbols_analyzed,
    tiers_traversed, scan_duration_ms) plus a clearly-labeled
    ``tokens_saved_estimate`` with the formula in ``tokens_saved_basis``.
  * ``summary`` — one factual line + one actionable suggestion line
    derived from the actual report contents (not canned).

The enricher is pure: it consumes a report dict and the per-tool
narrative function, returning a NEW dict with the two extra fields.
Existing fields are passed through untouched, so any downstream
consumer that expects the v1 schema continues to work.
"""
from __future__ import annotations

from collections.abc import Callable
from typing import Any

from ..a0_qk_constants.response_enrichment import (
    SCHEMA_VERSION_SCOPE_V1,
    TOKENS_PER_FILE_REVIEW,
    TOKENS_PER_SYMBOL_TRAVERSAL,
)


def make_scope(
    *,
    files_scanned: int = 0,
    symbols_analyzed: int = 0,
    tiers_traversed: int = 0,
    scan_duration_ms: int = 0,
    basis_kind: str = "files",
) -> dict[str, Any]:
    """Build a ``scope`` block.

    ``basis_kind``:
        ``"files"``   — tokens_saved_estimate = files_scanned * 40
        ``"symbols"`` — tokens_saved_estimate = symbols_analyzed * 12
        ``"both"``    — sum of the two
        ``"none"``    — emit zeros (estimate not meaningful for this tool)

    The ``tokens_saved_basis`` field carries the formula in plain text
    so the reader can recompute or substitute their own per-file cost.
    """
    files = max(0, int(files_scanned or 0))
    symbols = max(0, int(symbols_analyzed or 0))
    tiers = max(0, int(tiers_traversed or 0))
    duration = max(0, int(scan_duration_ms or 0))

    if basis_kind == "files":
        est = files * TOKENS_PER_FILE_REVIEW
        basis = (
            f"{files} files × ~{TOKENS_PER_FILE_REVIEW} tok/file "
            f"manual review avoided"
        )
    elif basis_kind == "symbols":
        est = symbols * TOKENS_PER_SYMBOL_TRAVERSAL
        basis = (
            f"{symbols} symbols × ~{TOKENS_PER_SYMBOL_TRAVERSAL} "
            f"tok/symbol traversal avoided"
        )
    elif basis_kind == "both":
        est = (files * TOKENS_PER_FILE_REVIEW
                + symbols * TOKENS_PER_SYMBOL_TRAVERSAL)
        basis = (
            f"{files} files × ~{TOKENS_PER_FILE_REVIEW} tok/file "
            f"+ {symbols} symbols × ~{TOKENS_PER_SYMBOL_TRAVERSAL} "
            f"tok/symbol traversal avoided"
        )
    else:  # "none" or anything else
        est = 0
        basis = "estimate not applicable for this tool"

    return {
        "schema_version": SCHEMA_VERSION_SCOPE_V1,
        "files_scanned": files,
        "symbols_analyzed": symbols,
        "tiers_traversed": tiers,
        "scan_duration_ms": duration,
        "tokens_saved_estimate": est,
        "tokens_saved_basis": basis,
    }


def enrich_response(
    report: dict[str, Any],
    *,
    scope: dict[str, Any] | None = None,
    summary: str = "",
) -> dict[str, Any]:
    """Return ``report`` with ``scope`` and ``summary`` injected.

    Existing keys are not modified. If the report already carries a
    ``scope`` or ``summary`` from upstream, the new values overwrite
    (callers control the order).
    """
    out = dict(report)
    if scope is not None:
        out["scope"] = scope
    if summary:
        out["summary"] = summary
    return out


# ── Per-tool summary builders ──────────────────────────────────────


def summarize_certify(report: dict[str, Any]) -> str:
    """Build a one-or-two-line summary from a certify report.

    Format:
        "Score N/100, verdict V, K blockers."
        + optional " Suggestion: <first actionable hint>." when N<100.
    """
    score = report.get("score")
    verdict = report.get("verdict") or report.get("health_summary", {}).get("verdict", "?")
    blockers = report.get("health_summary", {}).get("blockers", 0)
    line1 = f"Score {score}/100, verdict {verdict}, {blockers} blockers."
    issues = report.get("issues") or []
    recs = report.get("recommendations") or []
    if isinstance(score, int | float) and score >= 100 and not issues and not recs:
        return line1 + " No suggestions — architecture clean."
    if recs:
        first = str(recs[0]).split("\n")[0][:140]
        return line1 + f" Suggestion: {first}"
    if issues:
        first = str(issues[0]).split("\n")[0][:140]
        return line1 + f" First issue: {first}"
    return line1


def summarize_recon(report: dict[str, Any]) -> str:
    """One-line factual + tier-skew suggestion if any."""
    syms = len(report.get("symbols") or [])
    dist = report.get("tier_distribution") or {}
    line1 = f"Catalog: {syms} symbols across {len(dist)} tiers."
    if not dist:
        return line1
    # Skew detection: if any one tier holds >70% of symbols, flag it.
    total = sum(dist.values())
    if total == 0:
        return line1
    largest = max(dist.items(), key=lambda kv: kv[1])
    pct = largest[1] / total
    if pct > 0.70:
        return (line1 + f" Suggestion: tier {largest[0]} holds "
                f"{pct:.0%} of symbols — review for natural splits.")
    return line1 + " Distribution looks balanced."


def summarize_emergent(report: dict[str, Any]) -> str:
    """Top-N candidate count + first-candidate hint."""
    cands = report.get("candidates") or report.get("top_candidates") or []
    n = len(cands)
    catalog = report.get("catalog_size", 0)
    line1 = f"{n} emergent compositions surfaced from {catalog} symbols."
    if n == 0:
        return line1 + " No suggestions — no chains crossed the threshold."
    first = cands[0] if cands else {}
    name = first.get("name") or first.get("chain_name") or first.get("title") or "(unnamed)"
    return (line1 + f" Top candidate: {name}. "
            f"Suggestion: review for synthesis via `forge emergent synthesize`.")


def summarize_wire(report: dict[str, Any]) -> str:
    """Violation count + first-violation hint or all-clear."""
    n = report.get("violation_count", 0)
    verdict = report.get("verdict", "?")
    line1 = f"Wire scan: {verdict}, {n} violations."
    type_only = len(report.get("type_only_imports", []) or [])
    star = len(report.get("star_import_warnings", []) or [])
    dynamic = len(report.get("dynamic_import_warnings", []) or [])
    extras: list[str] = []
    if type_only:
        extras.append(f"{type_only} type-only")
    if star:
        extras.append(f"{star} star-import")
    if dynamic:
        extras.append(f"{dynamic} dynamic")
    if extras:
        line1 += f" Warnings: {', '.join(extras)}."
    if n == 0:
        return line1 + " No suggestions — import law clean."
    violations = report.get("violations") or []
    if violations:
        v = violations[0]
        f = v.get("file", "?")
        ft = v.get("from_tier", "?")
        tt = v.get("to_tier", "?")
        return (line1 + f" Suggestion: {f} (tier {ft}) imports from "
                f"tier {tt} — move file up or invert the dependency.")
    return line1


def summarize_verify(report: dict[str, Any]) -> str:
    """Composite gate: lead with verdict, then the dominant reason."""
    verdict = report.get("verdict", "?")
    score = report.get("score")
    n_violations = report.get("wire_violation_count", 0)
    line1 = (f"Verify: {verdict}. "
              f"Certify {score}/100 · wire {n_violations} violations.")
    fail = report.get("fail_reasons") or []
    refine = report.get("refine_reasons") or []
    nxt = report.get("next_command") or ""
    if verdict == "PASS":
        return line1 + " No suggestions — all gates green."
    if fail:
        return (line1 + f" Top blocker: {fail[0]}. "
                + (f"Suggestion: {nxt}" if nxt else ""))
    if refine:
        return line1 + f" Top refine: {refine[0]}."
    return line1


def summarize_synergy(report: dict[str, Any]) -> str:
    """Pair count + first pair hint."""
    pairs = (report.get("candidates")
              or report.get("synergy_pairs")
              or report.get("pairs")
              or [])
    n = len(pairs)
    line1 = f"Synergy scan: {n} feature/CLI pair(s) eligible to wire."
    if n == 0:
        return line1 + " No suggestions — surfaces appear well-connected."
    first = pairs[0]
    name = first.get("name") or first.get("title") or "(unnamed)"
    return (line1 + f" Top pair: {name}. "
            f"Suggestion: review for adapter synthesis.")


def summarize_auto(report: dict[str, Any]) -> str:
    """Pipeline result — surface what got moved/scored."""
    verdict = report.get("verdict") or report.get("certify", {}).get("verdict", "?")
    score = report.get("score") or report.get("certify", {}).get("score")
    cherry_count = (report.get("cherry", {}) or {}).get("symbols_picked", 0)
    line1 = (f"Auto pipeline: verdict {verdict}, "
              f"score {score}/100, "
              f"{cherry_count} symbols promoted.")
    if verdict == "PASS":
        return line1 + " No suggestions — assimilated package is clean."
    return (line1 + " Suggestion: re-run `forge wire` on the output to "
            "see remaining violations with repair hints.")


_SUMMARIZER_REGISTRY: dict[str, Callable[[dict[str, Any]], str]] = {
    "certify": summarize_certify,
    "recon": summarize_recon,
    "emergent_scan": summarize_emergent,
    "wire": summarize_wire,
    "verify": summarize_verify,
    "synergy_scan": summarize_synergy,
    "auto": summarize_auto,
}


def summarize_for(tool_name: str, report: dict[str, Any]) -> str:
    """Dispatch to the tool-specific summarizer; empty string if none."""
    fn = _SUMMARIZER_REGISTRY.get(tool_name)
    if fn is None:
        return ""
    try:
        return fn(report)
    except (AttributeError, KeyError, TypeError, ValueError):
        # A summarizer must never crash the tool response; return empty
        # so the caller still gets the original report.
        return ""


__all__ = [
    "enrich_response",
    "make_scope",
    "summarize_auto",
    "summarize_certify",
    "summarize_emergent",
    "summarize_for",
    "summarize_recon",
    "summarize_synergy",
    "summarize_verify",
    "summarize_wire",
]
