import asyncio
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

server = Server("uipath-command-mcp-server")

@server.list_tools()
async def list_tools():
    return [
        Tool(
            name="say_hello",
            description="Say hello to a person",
            input_schema={
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                },
                "required": ["name"],
            },
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict):
    if name == "say_hello":
        return [TextContent(text=f"Hello {arguments['name']}")]

# ---- async MCP loop ----
async def _run():
    async with stdio_server() as (read, write):
        await server.run(
            read,
            write,
            {},  # ✅ empty initialization options (compatible)
        )

# ---- sync entrypoint (required for uv / uvx) ----
def main():
    asyncio.run(_run())

if __name__ == "__main__":
    main()
