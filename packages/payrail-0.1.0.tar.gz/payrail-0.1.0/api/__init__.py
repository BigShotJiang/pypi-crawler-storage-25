"""FastAPI service package for PayRail."""
