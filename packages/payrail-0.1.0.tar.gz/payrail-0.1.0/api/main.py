"""FastAPI entrypoint: health check, CORS, and PayRail route modules."""

from __future__ import annotations

from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api.routes import agents, payments, receipts

_ENV_PATH = Path(__file__).resolve().parent.parent / ".env"
load_dotenv(_ENV_PATH)

app = FastAPI(title="PayRail API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost",
        "http://127.0.0.1",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:5500",
        "http://127.0.0.1:5500",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(agents.router, prefix="/agents", tags=["agents"])
app.include_router(payments.router, tags=["payments"])
app.include_router(receipts.router, prefix="/receipts", tags=["receipts"])


@app.get("/health")
def health() -> dict[str, str]:
    """Liveness probe for orchestrators and dashboards."""
    from payrail import __version__

    return {"status": "ok", "version": __version__}
