"""Transaction receipt helpers for dashboards and explorers."""

from __future__ import annotations

import os
from typing import Any

from fastapi import APIRouter, HTTPException
from web3 import Web3
from web3.exceptions import Web3Exception

from payrail._abis import PAYMENT_ABI

router = APIRouter()


def _require_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise HTTPException(status_code=500, detail=f"Missing environment variable {name}.")
    return value


@router.get("/{tx_hash}")
def receipt_by_transaction(tx_hash: str) -> dict[str, Any]:
    """
    Decode ``PaymentSent`` logs for a transaction hash.

    This complements ``payrail.receipt.get_receipt``, which reads the on-chain receipt mapping by task id.
    """
    rpc_url = _require_env("BASE_RPC_URL")
    payment_addr = _require_env("PAYMENT_CONTRACT_ADDR")

    normalized = tx_hash if tx_hash.startswith("0x") else f"0x{tx_hash}"

    try:
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        if not w3.is_connected():
            raise HTTPException(status_code=503, detail="RPC endpoint unavailable.")

        receipt = w3.eth.get_transaction_receipt(normalized)
        payment = w3.eth.contract(address=Web3.to_checksum_address(payment_addr), abi=PAYMENT_ABI)
        event = payment.events.PaymentSent()

        decoded_events: list[dict[str, Any]] = []
        payment_checksum = Web3.to_checksum_address(payment_addr)
        for log in receipt["logs"]:
            log_addr = Web3.to_checksum_address(log["address"])
            if log_addr.lower() != payment_checksum.lower():
                continue
            try:
                processed = event.process_log(log)
            except (ValueError, Web3Exception):
                continue
            args = processed["args"]
            decoded_events.append(
                {
                    "from": args["from"],
                    "to": args["to"],
                    "amount_raw": int(args["amount"]),
                    "task_id": args["taskId"].hex(),
                    "timestamp": int(args["timestamp"]),
                }
            )

        if not decoded_events:
            raise HTTPException(
                status_code=404,
                detail="No PaymentSent events found for this transaction and payment contract.",
            )

        return {"tx_hash": normalized, "block": int(receipt["blockNumber"]), "payments": decoded_events}
    except HTTPException:
        raise
    except Web3Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
