"""Payment endpoints wrapping ``payrail.payment`` and ``payrail.receipt``."""

from __future__ import annotations

import os
from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from payrail._abis import PAYMENT_ABI
from payrail.exceptions import InsufficientBalanceError, PaymentFailedError, WalletError
from payrail.payment import send_payment
from payrail.receipt import list_receipts

router = APIRouter()


class PayRequest(BaseModel):
    """Payload for orchestrated USDC payments."""

    to_address: str = Field(..., description="Registered payee agent address.")
    amount_usdc: float = Field(..., gt=0, description="USDC amount to transfer.")
    task_id: str = Field(..., min_length=1, description="Unique task identifier (hashed on-chain).")


def _require_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise HTTPException(status_code=500, detail=f"Missing environment variable {name}.")
    return value


@router.post("/pay")
def pay(body: PayRequest) -> dict[str, Any]:
    """Spend USDC from ``PRIVATE_KEY`` through the configured ``AgentPayment`` contract."""
    rpc_url = _require_env("BASE_RPC_URL")
    payment_addr = _require_env("PAYMENT_CONTRACT_ADDR")
    private_key = _require_env("PRIVATE_KEY")

    try:
        return send_payment(
            from_private_key=private_key,
            to_address=body.to_address,
            amount_usdc=body.amount_usdc,
            task_id=body.task_id,
            rpc_url=rpc_url,
            payment_contract_address=payment_addr,
            payment_contract_abi=PAYMENT_ABI,
        )
    except InsufficientBalanceError as exc:
        raise HTTPException(status_code=402, detail=str(exc)) from exc
    except PaymentFailedError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except WalletError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@router.get("/payments")
def payments(address: Optional[str] = None, limit: int = 20) -> dict[str, Any]:
    """Return recent ``PaymentSent`` logs involving ``address`` (defaults to ``PRIVATE_KEY`` wallet)."""
    rpc_url = _require_env("BASE_RPC_URL")
    payment_addr = _require_env("PAYMENT_CONTRACT_ADDR")
    private_key = _require_env("PRIVATE_KEY")

    from eth_account import Account

    key = private_key.strip()
    if not key.startswith("0x"):
        key = "0x" + key
    default_addr = Account.from_key(key).address
    target = address or default_addr

    try:
        receipts = list_receipts(
            address=target,
            rpc_url=rpc_url,
            payment_contract_address=payment_addr,
            payment_contract_abi=PAYMENT_ABI,
            limit=limit,
        )
        return {"address": target, "receipts": receipts}
    except WalletError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
