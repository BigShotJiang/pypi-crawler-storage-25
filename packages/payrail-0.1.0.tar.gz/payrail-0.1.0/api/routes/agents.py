"""Agent registry HTTP endpoints."""

from __future__ import annotations

import os
from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from web3 import Web3

from payrail._abis import REGISTRY_ABI
from payrail.exceptions import AgentNotRegisteredError, ContractError, WalletError
from payrail.registry import get_agent_price, register_agent

router = APIRouter()


class RegisterAgentRequest(BaseModel):
    """Payload for registering the configured wallet as an agent."""

    name: str = Field(..., min_length=1, description="Human-readable agent name.")
    price_per_call_usdc: float = Field(..., gt=0, description="Minimum USDC per call.")


def _require_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise HTTPException(status_code=500, detail=f"Missing environment variable {name}.")
    return value


@router.get("")
def list_agents(address: Optional[str] = None) -> dict[str, Any]:
    """
    Return registry metadata.

    When ``address`` is provided, resolves pricing for that wallet. Otherwise returns a hint payload
    because the on-chain contract does not enumerate all agents.
    """
    if address is None:
        return {
            "agents": [],
            "hint": "Provide ?address=0x... to read a specific registry entry from chain.",
        }

    rpc_url = _require_env("BASE_RPC_URL")
    registry_addr = _require_env("REGISTRY_CONTRACT_ADDR")

    try:
        price = get_agent_price(address, rpc_url, registry_addr, REGISTRY_ABI)
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        registry = w3.eth.contract(address=Web3.to_checksum_address(registry_addr), abi=REGISTRY_ABI)
        _wallet, name, price_raw, active = registry.functions.getAgent(Web3.to_checksum_address(address)).call()
        return {
            "address": Web3.to_checksum_address(address),
            "registered": True,
            "active": bool(active),
            "on_chain_name": name,
            "price_per_call_usdc": price,
            "price_per_call_raw": int(price_raw),
        }
    except AgentNotRegisteredError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except WalletError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@router.post("/register")
def register_agent_route(body: RegisterAgentRequest) -> dict[str, Any]:
    """Register ``PRIVATE_KEY``'s wallet on-chain with the supplied name and price."""
    rpc_url = _require_env("BASE_RPC_URL")
    registry_addr = _require_env("REGISTRY_CONTRACT_ADDR")
    private_key = _require_env("PRIVATE_KEY")

    try:
        return register_agent(
            name=body.name,
            price_per_call_usdc=body.price_per_call_usdc,
            private_key=private_key,
            rpc_url=rpc_url,
            registry_contract_address=registry_addr,
            registry_contract_abi=REGISTRY_ABI,
        )
    except ContractError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except WalletError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
