"""
PayRail 3-agent demo
====================

Runs a full research pipeline on Base Sepolia:

  User question
      → Orchestrator pays SearchAgent 0.01 USDC   → search results
      → Orchestrator pays SummariseAgent 0.02 USDC → summary
      → Final answer printed with Basescan links

Usage
-----
    python demo/run_demo.py
    python demo/run_demo.py "How does proof-of-work mining work?"

Environment variables (all read from .env):
    BASE_RPC_URL            — Base Sepolia JSON-RPC endpoint
    PRIVATE_KEY             — Orchestrator wallet private key (must hold USDC + ETH)
    PAYMENT_CONTRACT_ADDR   — Deployed AgentPayment address
    REGISTRY_CONTRACT_ADDR  — Deployed AgentRegistry address
    SEARCH_AGENT_KEY        — (optional) private key for the search agent wallet
    SUMMARISE_AGENT_KEY     — (optional) private key for the summarise agent wallet

If SEARCH_AGENT_KEY / SUMMARISE_AGENT_KEY are absent the demo generates fresh wallets,
funds them with a small ETH top-up from the orchestrator (for gas), registers them in the
AgentRegistry, then proceeds.  The generated keys are printed so you can persist them.
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path

# Ensure project root is on the path so `import payrail` works without install.
_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))

from dotenv import load_dotenv

load_dotenv(_ROOT / ".env")

from eth_account import Account
from web3 import Web3

from payrail._abis import PAYMENT_ABI, REGISTRY_ABI
from payrail.registry import register_agent
from payrail.wallet import create_wallet

# ──────────────────────────────────────────────────────────────────────────────
# Constants
# ──────────────────────────────────────────────────────────────────────────────

_ZERO = "0x0000000000000000000000000000000000000000"
_GAS_TOP_UP_WEI = Web3.to_wei(0.0002, "ether")   # ~0.0002 ETH covers several txns on Base Sepolia
_MIN_ETH_WEI = Web3.to_wei(0.0001, "ether")       # below this we top up


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _normalize_key(key: str) -> str:
    key = key.strip()
    return key if key.startswith("0x") else "0x" + key


def _send_eth(w3: Web3, from_account: Account, to_address: str, amount_wei: int) -> str:
    """Send native ETH from *from_account* to *to_address*. Returns tx hash."""
    nonce = w3.eth.get_transaction_count(from_account.address)
    tx = {
        "to": Web3.to_checksum_address(to_address),
        "value": amount_wei,
        "gas": 21_000,
        "gasPrice": int(w3.eth.gas_price),
        "nonce": nonce,
        "chainId": w3.eth.chain_id,
    }
    signed = from_account.sign_transaction(tx)
    raw = getattr(signed, "raw_transaction", getattr(signed, "rawTransaction", None))
    tx_hash = w3.eth.send_raw_transaction(raw)
    w3.eth.wait_for_transaction_receipt(tx_hash)
    return tx_hash.hex()


def _ensure_funded(w3: Web3, orch_account: Account, agent_address: str, label: str) -> None:
    """Top up *agent_address* with ETH from the orchestrator if its balance is low."""
    balance = w3.eth.get_balance(Web3.to_checksum_address(agent_address))
    if balance < _MIN_ETH_WEI:
        print(f"  Funding {label} ({agent_address[:10]}…) with ETH for gas…")
        _send_eth(w3, orch_account, agent_address, _GAS_TOP_UP_WEI)
        print(f"  ✓ {label} funded")
    else:
        print(f"  {label} already has sufficient ETH for gas")


def _ensure_registered(
    w3: Web3,
    agent_name: str,
    agent_key: str,
    price_usdc: float,
    rpc_url: str,
    registry_address: str,
) -> None:
    """Register *agent_key*'s wallet in AgentRegistry if not already active."""
    acct = Account.from_key(_normalize_key(agent_key))
    registry = w3.eth.contract(
        address=Web3.to_checksum_address(registry_address),
        abi=REGISTRY_ABI,
    )
    wallet, _name, _price, active = registry.functions.getAgent(
        Web3.to_checksum_address(acct.address)
    ).call()

    if wallet == _ZERO or not active:
        print(f"  Registering {agent_name} ({acct.address[:10]}…) in AgentRegistry…")
        register_agent(
            name=agent_name,
            price_per_call_usdc=price_usdc,
            private_key=agent_key,
            rpc_url=rpc_url,
            registry_contract_address=registry_address,
            registry_contract_abi=REGISTRY_ABI,
        )
        print(f"  ✓ {agent_name} registered")
    else:
        print(f"  {agent_name} already registered and active")


def _setup_sub_agents(
    orch_account: Account,
    w3: Web3,
    rpc_url: str,
    registry_address: str,
) -> tuple[str, str, str, str]:
    """
    Return ``(search_key, search_address, summarise_key, summarise_address)``.

    Generates wallets when env vars are absent, funds them, and registers them.
    """
    from demo.agents.search_agent import NAME as SEARCH_NAME, PRICE_PER_CALL_USDC as SEARCH_PRICE
    from demo.agents.summarise_agent import NAME as SUMMARISE_NAME, PRICE_PER_CALL_USDC as SUMMARISE_PRICE

    search_key_raw = os.getenv("SEARCH_AGENT_KEY")
    summarise_key_raw = os.getenv("SUMMARISE_AGENT_KEY")

    generated: list[str] = []

    if not search_key_raw:
        new_wallet = create_wallet()
        search_key_raw = new_wallet["private_key"]
        generated.append(f"  SEARCH_AGENT_KEY={search_key_raw}  # address: {new_wallet['address']}")

    if not summarise_key_raw:
        new_wallet = create_wallet()
        summarise_key_raw = new_wallet["private_key"]
        generated.append(f"  SUMMARISE_AGENT_KEY={summarise_key_raw}  # address: {new_wallet['address']}")

    if generated:
        print("\n  [!] Generated fresh sub-agent wallets. Add to .env to reuse:")
        for line in generated:
            print(line)
        print()

    search_key = _normalize_key(search_key_raw)
    summarise_key = _normalize_key(summarise_key_raw)

    search_address = Account.from_key(search_key).address
    summarise_address = Account.from_key(summarise_key).address

    # Fund agents with ETH for gas if needed
    _ensure_funded(w3, orch_account, search_address, SEARCH_NAME)
    _ensure_funded(w3, orch_account, summarise_address, SUMMARISE_NAME)

    # Register agents in the registry if not already active
    _ensure_registered(w3, SEARCH_NAME, search_key, SEARCH_PRICE, rpc_url, registry_address)
    _ensure_registered(w3, SUMMARISE_NAME, summarise_key, SUMMARISE_PRICE, rpc_url, registry_address)

    return search_key, search_address, summarise_key, summarise_address


# ──────────────────────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────────────────────

def main() -> None:
    user_query = (
        sys.argv[1] if len(sys.argv) > 1
        else "What are autonomous AI agents and how do they pay each other?"
    )

    rpc_url = os.getenv("BASE_RPC_URL", "")
    orch_key_raw = os.getenv("PRIVATE_KEY", "")
    payment_addr = os.getenv("PAYMENT_CONTRACT_ADDR", "")
    registry_addr = os.getenv("REGISTRY_CONTRACT_ADDR", "")

    missing = [
        name
        for name, val in [
            ("BASE_RPC_URL", rpc_url),
            ("PRIVATE_KEY", orch_key_raw),
            ("PAYMENT_CONTRACT_ADDR", payment_addr),
            ("REGISTRY_CONTRACT_ADDR", registry_addr),
        ]
        if not val or val.lower() == _ZERO.lower()
    ]
    if missing:
        print("ERROR: missing or zero env vars:", ", ".join(missing))
        print("Set them in .env (see .env.example).")
        sys.exit(1)

    orch_key = _normalize_key(orch_key_raw)
    orch_account = Account.from_key(orch_key)

    w3 = Web3(Web3.HTTPProvider(rpc_url))
    if not w3.is_connected():
        print(f"ERROR: cannot connect to {rpc_url}")
        sys.exit(1)

    # ── Banner ────────────────────────────────────────────────────────────────
    print()
    print("╔══════════════════════════════════════════════════════════╗")
    print("║              PayRail 3-Agent Demo  (Base Sepolia)        ║")
    print("╚══════════════════════════════════════════════════════════╝")
    print(f"\nQuery  : {user_query}")
    print(f"Wallet : {orch_account.address}")
    print()
    time.sleep(0.3)

    # ── Bootstrap sub-agents ─────────────────────────────────────────────────
    print("── Setup ──────────────────────────────────────────────────")
    search_key, search_addr, summarise_key, summarise_addr = _setup_sub_agents(
        orch_account, w3, rpc_url, registry_addr
    )
    print(f"  SearchAgent    : {search_addr}")
    print(f"  SummariseAgent : {summarise_addr}")
    print()
    time.sleep(0.3)

    # ── Run orchestrator ──────────────────────────────────────────────────────
    print("── Payments ───────────────────────────────────────────────")
    from demo.agents.orchestrator import run as orch_run

    result = orch_run(
        user_query=user_query,
        orchestrator_private_key=orch_key,
        search_agent_address=search_addr,
        summarise_agent_address=summarise_addr,
        rpc_url=rpc_url,
        payment_contract_address=payment_addr,
    )
    print()
    time.sleep(0.3)

    # ── Answer ────────────────────────────────────────────────────────────────
    print("── Answer ─────────────────────────────────────────────────")
    print(result["answer"])
    print()
    time.sleep(0.3)

    # ── Payment trail ─────────────────────────────────────────────────────────
    print("── Payment Trail ──────────────────────────────────────────")
    for p in result["payments"]:
        print(f"  {p['step'].capitalize():12s}  {p['amount_usdc']:.2f} USDC  block {p['block']}")
        print(f"  {'':12s}  {p['basescan']}")
        time.sleep(0.3)
    print(f"\n  Total paid : {result['total_usdc']:.2f} USDC")
    print()
    time.sleep(0.3)

    print("✓ Demo complete — view transactions on Basescan")
    print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
