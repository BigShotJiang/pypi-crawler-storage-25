"""
PayRail Client Demo
===================

Shows the unified ``PayRail`` class in action:

  1. Read wallet balances
  2. Decorate a function with ``@rail.payable``
  3. Call the function — payment confirmed on-chain before execution

Usage
-----
    python demo/client_demo.py

Environment variables (all read from .env):
    BASE_RPC_URL, PRIVATE_KEY, USDC_CONTRACT_ADDR,
    REGISTRY_CONTRACT_ADDR, PAYMENT_CONTRACT_ADDR

Note
----
``@rail.payable`` sends USDC to ``rail._address``, so that wallet must be
registered in the AgentRegistry.  This demo registers it automatically if not
already active (registration is skipped when already registered).
"""

from __future__ import annotations

import sys
from pathlib import Path

# Allow running from the repo root without installing the package.
_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))

from dotenv import load_dotenv

load_dotenv(_ROOT / ".env")

from eth_account import Account
from web3 import Web3

from payrail import PayRail
from payrail._abis import REGISTRY_ABI
from payrail.exceptions import ContractError


def _ensure_registered(rail: PayRail) -> None:
    """Register the demo wallet if it is not already active in the registry."""
    w3 = Web3(Web3.HTTPProvider(rail._rpc_url))
    registry = w3.eth.contract(
        address=Web3.to_checksum_address(rail._registry_address),
        abi=REGISTRY_ABI,
    )
    _wallet, _name, _price, active = registry.functions.getAgent(
        Web3.to_checksum_address(rail._address)
    ).call()

    if not active:
        print("  Registering demo wallet in AgentRegistry…")
        try:
            result = rail.register(name="demo-agent", price_per_call=0.01)
            print(f"  Registered — {result['tx_hash'][:18]}…")
        except ContractError as exc:
            # Already active race condition or contract error — proceed anyway
            print(f"  Registration skipped: {exc}")
    else:
        print("  Demo wallet already registered and active")


def main() -> None:
    print()
    print("╔══════════════════════════════════════════════════════════╗")
    print("║          PayRail Client Demo  (Base Sepolia)             ║")
    print("╚══════════════════════════════════════════════════════════╝")

    rail = PayRail()
    print(f"\nWallet  : {rail._address}")

    # ── Balances ──────────────────────────────────────────────────────────────
    print("\n── Balances ───────────────────────────────────────────────")
    usdc_balance = rail.get_balance()
    eth_balance = rail.get_eth_balance()
    print(f"  USDC  : {usdc_balance:.4f}")
    print(f"  ETH   : {eth_balance:.6f}")

    # ── Ensure the wallet is a registered agent (payable requires this) ────────
    print("\n── Registry ───────────────────────────────────────────────")
    _ensure_registered(rail)

    # ── Payable decorator ─────────────────────────────────────────────────────
    print("\n── Payable decorator ──────────────────────────────────────")

    @rail.payable(price=0.01)
    def search(query: str) -> str:
        """Simulate a web search (replace with a real search API in production)."""
        return f"Search results for: '{query}' — [autonomous agents, on-chain payments, Base]"

    print("  Calling search('autonomous AI agents')…")
    result = search("autonomous AI agents")
    print(f"\n  Result  : {result}")
    print("\n  Payment confirmed on-chain.")

    # ── Recent receipts ───────────────────────────────────────────────────────
    print("\n── Recent receipts ────────────────────────────────────────")
    recent = rail.receipts(limit=3)
    if recent:
        for r in recent:
            print(f"  {r['tx_hash'][:18]}…  {r['amount']:.4f} USDC  {r['timestamp']}")
    else:
        print("  No recent receipts found (may take a few seconds to index).")

    print()
    print("✓ Client demo complete — view transactions on Basescan")
    print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
