"""
PayRail Discovery Demo
======================

Shows the publish → discover → hire pipeline:

  1. Two agents are published (registered on-chain + cached locally)
  2. ``discover()`` finds them by capability keyword
  3. ``hire()`` pays the cheapest match and returns output

Usage
-----
    python demo/discovery_demo.py

Environment variables (all read from .env):
    BASE_RPC_URL, PRIVATE_KEY, USDC_CONTRACT_ADDR,
    REGISTRY_CONTRACT_ADDR, PAYMENT_CONTRACT_ADDR
    SEARCH_AGENT_KEY, SUMMARISE_AGENT_KEY

Note
----
``publish()`` registers the wallet on-chain, so each wallet may only be
published once unless deactivated first.  Existing registrations are detected
and the on-chain step is skipped automatically.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))

from dotenv import load_dotenv

load_dotenv(_ROOT / ".env")

import os

from payrail import PayRail
from payrail._abis import REGISTRY_ABI
from payrail.exceptions import AgentNotRegisteredError, ContractError
from payrail.wallet import create_wallet


def _normalize_key(key: str) -> str:
    key = key.strip()
    return key if key.startswith("0x") else "0x" + key


def _agent_is_registered(rail: PayRail, address: str) -> bool:
    """Return True if *address* is active in the on-chain registry."""
    from web3 import Web3

    try:
        from web3 import Web3

        w3 = Web3(Web3.HTTPProvider(rail._rpc_url))
        registry = w3.eth.contract(
            address=Web3.to_checksum_address(rail._registry_address),
            abi=REGISTRY_ABI,
        )
        _w, _n, _p, active = registry.functions.getAgent(
            Web3.to_checksum_address(address)
        ).call()
        return bool(active)
    except Exception:
        return False


def _publish_agent(
    key: str,
    name: str,
    price: float,
    capability: str,
    rpc_url: str,
    usdc_addr: str,
    registry_addr: str,
    payment_addr: str,
) -> PayRail:
    """Create a PayRail instance for *key* and publish if not already registered."""
    agent_rail = PayRail(
        rpc_url=rpc_url,
        private_key=key,
        usdc_address=usdc_addr,
        registry_address=registry_addr,
        payment_address=payment_addr,
    )

    if _agent_is_registered(agent_rail, agent_rail._address):
        print(f"  {name} ({agent_rail._address[:10]}…) already registered — skipping on-chain step")
        # Still update the local discovery cache so discover() can find it
        entries = agent_rail._load_local_registry()
        entry = {
            "name": name,
            "address": agent_rail._address,
            "price": price,
            "capability": capability,
            "endpoint": None,
        }
        updated = False
        for i, e in enumerate(entries):
            if e.get("address", "").lower() == agent_rail._address.lower():
                entries[i] = entry
                updated = True
                break
        if not updated:
            entries.append(entry)
        agent_rail._save_local_registry(entries)
    else:
        print(f"  Publishing {name} ({agent_rail._address[:10]}…)…")
        try:
            result = agent_rail.publish(
                name=name,
                price=price,
                capability=capability,
                endpoint=None,
            )
            print(f"  ✓ Published — {result['tx_hash'][:18]}…")
        except ContractError as exc:
            print(f"  Registration error (already active?): {exc}")

    return agent_rail


def main() -> None:
    print()
    print("╔══════════════════════════════════════════════════════════╗")
    print("║        PayRail Discovery Demo  (Base Sepolia)            ║")
    print("╚══════════════════════════════════════════════════════════╝")

    # ── Load orchestrator ─────────────────────────────────────────────────────
    rail = PayRail()
    print(f"\nOrchestrator : {rail._address}")

    rpc_url = rail._rpc_url
    usdc_addr = rail._usdc_address
    registry_addr = rail._registry_address
    payment_addr = rail._payment_address

    # ── Resolve sub-agent keys ────────────────────────────────────────────────
    search_key_raw = os.getenv("SEARCH_AGENT_KEY", "")
    summarise_key_raw = os.getenv("SUMMARISE_AGENT_KEY", "")

    if not search_key_raw:
        new_wallet = create_wallet()
        search_key_raw = new_wallet["private_key"]
        print(f"\n  [!] Generated search agent key — add to .env to reuse:")
        print(f"  SEARCH_AGENT_KEY={search_key_raw}")

    if not summarise_key_raw:
        new_wallet = create_wallet()
        summarise_key_raw = new_wallet["private_key"]
        print(f"\n  [!] Generated summarise agent key — add to .env to reuse:")
        print(f"  SUMMARISE_AGENT_KEY={summarise_key_raw}")

    search_key = _normalize_key(search_key_raw)
    summarise_key = _normalize_key(summarise_key_raw)

    # ── Publish agents ────────────────────────────────────────────────────────
    print("\n── Publish ────────────────────────────────────────────────")

    _publish_agent(
        key=search_key,
        name="search-agent",
        price=0.01,
        capability="web search",
        rpc_url=rpc_url,
        usdc_addr=usdc_addr,
        registry_addr=registry_addr,
        payment_addr=payment_addr,
    )

    _publish_agent(
        key=summarise_key,
        name="summarise-agent",
        price=0.02,
        capability="summarise text",
        rpc_url=rpc_url,
        usdc_addr=usdc_addr,
        registry_addr=registry_addr,
        payment_addr=payment_addr,
    )

    time.sleep(0.5)

    # ── Discover ──────────────────────────────────────────────────────────────
    print("\n── Discover ───────────────────────────────────────────────")

    agents = rail.discover("web search")
    print(f"\n  Found {len(agents)} agent(s) for 'web search':")
    for a in agents:
        print(f"    {a['name']:<20s}  {a['price']:.4f} USDC  {a['address'][:12]}…")

    all_agents = rail.discover("")  # discover all
    print(f"\n  Total agents in local registry: {len(all_agents)}")

    # ── Hire ──────────────────────────────────────────────────────────────────
    print("\n── Hire ───────────────────────────────────────────────────")
    print("\n  Hiring cheapest 'web search' agent (budget: 0.05 USDC)…")

    try:
        result = rail.hire("web search", "what is on-chain agent payment?", budget=0.05)
        print(f"\n  Agent   : {result['agent_address'][:18]}…")
        print(f"  Cost    : {result['cost']:.4f} USDC")
        print(f"  Output  : {result['output']}")
        print(f"  Tx      : {result['basescan']}")
    except AgentNotRegisteredError as exc:
        print(f"\n  No agent found: {exc}")

    print()
    print("✓ Discovery demo complete — view transactions on Basescan")
    print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
