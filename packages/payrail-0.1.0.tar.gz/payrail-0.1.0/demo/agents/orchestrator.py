"""
Orchestrator agent — coordinates search and summarise agents, paying each via PayRail.

Flow
----
1. Receive user query.
2. Pay SearchAgent 0.01 USDC → get search results.
3. Pay SummariseAgent 0.02 USDC → get summary.
4. Return final answer + payment trail.
"""

from __future__ import annotations

import time
import uuid
from typing import Any

from eth_account import Account
from web3 import Web3

from payrail._abis import PAYMENT_ABI, REGISTRY_ABI
from payrail.payment import send_payment

SEARCH_PRICE_USDC = 0.01
SUMMARY_PRICE_USDC = 0.02

_BASESCAN_BASE = "https://sepolia.basescan.org/tx/0x"


def _basescan(tx_hash: str) -> str:
    h = tx_hash.lstrip("0x")
    return f"{_BASESCAN_BASE}{h}"


def run(
    user_query: str,
    orchestrator_private_key: str,
    search_agent_address: str,
    summarise_agent_address: str,
    rpc_url: str,
    payment_contract_address: str,
) -> dict[str, Any]:
    """
    Execute the full orchestrated research pipeline, paying each agent on-chain.

    Returns a dict with ``answer``, ``summary``, ``search_results``, and ``payments``.
    """
    from demo.agents import search_agent, summarise_agent

    payments: list[dict[str, Any]] = []

    # --- Step 1: pay search agent and retrieve results ---
    search_task_id = f"search:{uuid.uuid4()}"
    print(f"  Paying SearchAgent {SEARCH_PRICE_USDC} USDC (task: {search_task_id[:24]}…)")
    search_receipt = send_payment(
        from_private_key=orchestrator_private_key,
        to_address=search_agent_address,
        amount_usdc=SEARCH_PRICE_USDC,
        task_id=search_task_id,
        rpc_url=rpc_url,
        payment_contract_address=payment_contract_address,
        payment_contract_abi=PAYMENT_ABI,
    )
    payments.append(
        {
            "step": "search",
            "agent": search_agent_address,
            "amount_usdc": SEARCH_PRICE_USDC,
            "tx_hash": search_receipt["tx_hash"],
            "basescan": _basescan(search_receipt["tx_hash"]),
            "block": search_receipt["block"],
        }
    )
    print(f"  ✓ Search payment confirmed — block {search_receipt['block']}")
    print(f"    {_basescan(search_receipt['tx_hash'])}")

    search_results = search_agent.process(user_query)

    # --- Step 2: pay summarise agent and retrieve summary ---
    summarise_task_id = f"summarise:{uuid.uuid4()}"
    print(f"  Paying SummariseAgent {SUMMARY_PRICE_USDC} USDC (task: {summarise_task_id[:24]}…)")
    summarise_receipt = send_payment(
        from_private_key=orchestrator_private_key,
        to_address=summarise_agent_address,
        amount_usdc=SUMMARY_PRICE_USDC,
        task_id=summarise_task_id,
        rpc_url=rpc_url,
        payment_contract_address=payment_contract_address,
        payment_contract_abi=PAYMENT_ABI,
    )
    payments.append(
        {
            "step": "summarise",
            "agent": summarise_agent_address,
            "amount_usdc": SUMMARY_PRICE_USDC,
            "tx_hash": summarise_receipt["tx_hash"],
            "basescan": _basescan(summarise_receipt["tx_hash"]),
            "block": summarise_receipt["block"],
        }
    )
    print(f"  ✓ Summarise payment confirmed — block {summarise_receipt['block']}")
    print(f"    {_basescan(summarise_receipt['tx_hash'])}")

    summary = summarise_agent.process(search_results, user_query)

    return {
        "query": user_query,
        "search_results": search_results,
        "summary": summary,
        "answer": summary,
        "payments": payments,
        "total_usdc": SEARCH_PRICE_USDC + SUMMARY_PRICE_USDC,
    }
