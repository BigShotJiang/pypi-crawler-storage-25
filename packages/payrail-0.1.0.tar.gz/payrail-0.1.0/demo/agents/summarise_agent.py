"""Summarisation specialist agent — condenses search results into bullet points."""

from __future__ import annotations

NAME = "SummariseAgent"
DESCRIPTION = "Summarises long inputs into concise bullet points."
PRICE_PER_CALL_USDC = 0.02


def quote() -> dict[str, float | str]:
    """Return static pricing metadata used by demos and documentation."""
    return {"name": NAME, "description": DESCRIPTION, "price_usdc": PRICE_PER_CALL_USDC}


def process(content: str, original_query: str) -> str:
    """
    Simulate summarisation of search results.

    In production this would call an LLM (OpenAI, Claude, etc.).
    For the demo it returns a deterministic summary so no API keys are needed.
    """
    _ = content  # would be fed to the LLM in production
    return (
        f"Summary for: '{original_query}'\n"
        "---\n"
        "• AI agents are autonomous programs that perceive, decide, and act using LLMs as "
        "a reasoning core, augmented with tools and memory.\n"
        "• Multi-agent systems decompose complex tasks: an orchestrator coordinates "
        "specialist agents (search, code, analysis) and merges their outputs.\n"
        "• On-chain USDC payments (e.g. via PayRail on Base) give agents a native billing "
        "layer — every service call produces an immutable, auditable receipt on-chain.\n"
        "• PayRail SDK: register a wallet → call send_payment() → receipt stored forever "
        "in the AgentPayment contract, queryable by task ID."
    )
