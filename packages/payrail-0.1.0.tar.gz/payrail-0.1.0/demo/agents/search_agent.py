"""Search specialist agent — returns simulated web-search results."""

from __future__ import annotations

NAME = "SearchAgent"
DESCRIPTION = "Fetches fresh information from the web."
PRICE_PER_CALL_USDC = 0.01


def quote() -> dict[str, float | str]:
    """Return static pricing metadata used by demos and documentation."""
    return {"name": NAME, "description": DESCRIPTION, "price_usdc": PRICE_PER_CALL_USDC}


def process(query: str) -> str:
    """
    Simulate a web search and return structured results.

    In a production system this would call a real search API (Brave, Serper, etc.).
    For the demo it returns deterministic canned results so the demo runs without
    any external API keys.
    """
    return (
        f"Search results for: '{query}'\n"
        "---\n"
        "1. Autonomous AI agents are software programs that can perceive their environment, "
        "make decisions, and take actions without continuous human input. They use large "
        "language models as a reasoning backbone combined with tool use and memory systems.\n\n"
        "2. Multi-agent systems allow specialised agents to collaborate: an orchestrator "
        "delegates subtasks to specialist agents (search, code execution, data analysis) "
        "and aggregates their outputs into a coherent final answer.\n\n"
        "3. On-chain payments between agents (e.g. using USDC on Base) create a verifiable "
        "audit trail and enable agents to compensate each other for compute resources, "
        "API calls, or proprietary data — without a centralised billing layer.\n\n"
        "4. The PayRail SDK provides the payment primitive: register an agent wallet, "
        "call send_payment(), and get an immutable on-chain receipt keyed by task ID."
    )
