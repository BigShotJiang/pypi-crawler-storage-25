const API_BASE = "http://127.0.0.1:8000";

const statusEl = document.querySelector("#status");
const rowsEl = document.querySelector("#rows");
const addressInput = document.querySelector("#address");

function short(addr) {
  if (!addr || addr.length < 10) return addr;
  return `${addr.slice(0, 6)}…${addr.slice(-4)}`;
}

async function fetchPayments() {
  const params = new URLSearchParams();
  const addr = addressInput.value.trim();
  if (addr) params.set("address", addr);
  params.set("limit", "25");

  const response = await fetch(`${API_BASE}/payments?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  return response.json();
}

function renderRows(payload) {
  rowsEl.innerHTML = "";
  const receipts = payload.receipts || [];
  if (receipts.length === 0) {
    statusEl.textContent = "No payments yet (or wallet filter mismatch).";
    return;
  }

  statusEl.textContent = `Showing ${receipts.length} receipts for ${payload.address ?? "default wallet"}.`;

  for (const item of receipts) {
    const tr = document.createElement("tr");
    const txLink = `https://sepolia.basescan.org/tx/${item.tx_hash}`;
    tr.innerHTML = `
      <td>${item.timestamp}</td>
      <td title="${item.from}">${short(item.from)}</td>
      <td title="${item.to}">${short(item.to)}</td>
      <td>${item.amount.toFixed(4)}</td>
      <td title="${item.task_id}">${short(item.task_id)}</td>
      <td><a href="${txLink}" target="_blank" rel="noreferrer">view</a></td>
    `;
    rowsEl.appendChild(tr);
  }
}

async function refresh() {
  try {
    const payload = await fetchPayments();
    renderRows(payload);
  } catch (error) {
    statusEl.textContent = `Could not reach API (${error.message}). Is uvicorn running?`;
    rowsEl.innerHTML = "";
  }
}

addressInput.addEventListener("change", refresh);

refresh();
setInterval(refresh, 5000);
