# PayRail — Future Work

Features intentionally deferred from Phase 2.  Open an issue before starting
any of these to coordinate design first.

---

## x402 HTTP Payment Protocol

Add native support for the Coinbase x402 standard as a payment method alongside
the existing on-chain flow.

- `PayableEndpoint` — wrap any Python function as an HTTP endpoint that returns
  `402 Payment Required` with x402 requirements when called without a valid
  `X-PAYMENT` header
- `PayingClient` — HTTP client that auto-detects `402` responses, reads payment
  requirements, sends USDC via the existing `send_payment()` path, and retries
  with the payment header
- `@rail.payable_http(price=0.01)` decorator composes `PayableEndpoint` with the
  existing `@rail.payable` pattern
- Facilitator integration for off-chain verification (avoids waiting for block
  confirmation on every API call)

x402 should be a *payment method* routed through `PayRail.pay()`, not a
replacement for the AgentRegistry/AgentPayment on-chain architecture.

---

## Shared Registry Backend

`discover()` currently reads `~/.payrail/registry.json` locally.  A hosted
registry would let agents on different machines find each other without
pre-sharing addresses.

- REST API over the on-chain `AgentRegistered` event stream, indexed by
  capability keywords
- Self-hostable as an extension of the existing `api/` FastAPI app
- `discover()` falls back to the on-chain event scan when the server is
  unreachable

---

## React / Web Frontend

- Agent marketplace dashboard built on `api/` endpoints
- Live payment trail visualisation (extend `dashboard/`)
- One-click hire via `PayRail.hire()`

---

## Multi-Chain Support

Only Base Sepolia / Base Mainnet are supported today.

- CAIP-2 network identifiers in `PayRail.__init__`
- Per-network USDC address lookup in `_abis.py`
- Solana support (different signing scheme — non-trivial)

---

## Mainnet Deployment

Current contracts are on Base Sepolia (testnet).

1. Security audit of `AgentRegistry` and `AgentPayment`
2. Re-deploy via `forge script` with mainnet RPC and funded deployer key
3. Update `.env.example` with mainnet addresses
4. Loud warning in `PayRail.__init__` when private key holds real funds

---

## ERC-4337 Account Abstraction

- Gasless transactions via a paymaster
- Multi-sig approval for high-value payments
- Session keys for bounded agent spend without exposing the master key

---

## Merge / release checklist

Before merging or cutting a release, run:

```bash
pytest tests/ -v
```

Check this file for any listed items that should ship with the change.
