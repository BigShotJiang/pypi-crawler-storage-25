"""Unit tests for PayRail discovery methods: publish, discover, hire."""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from payrail.exceptions import AgentNotRegisteredError

# ── Helpers ────────────────────────────────────────────────────────────────────

_TEST_KEY = "0x" + "1" * 64
_ADDR_A = "0x" + "A" * 40  # usdc
_ADDR_B = "0x" + "B" * 40  # registry
_ADDR_C = "0x" + "C" * 40  # payment
_ADDR_AGENT1 = "0x" + "1" * 40
_ADDR_AGENT2 = "0x" + "2" * 40


def _make_rail(registry_path: Path):
    """Return a PayRail instance wired to *registry_path* for local cache I/O."""
    from payrail.client import PayRail

    with patch("payrail.client._LOCAL_REGISTRY", registry_path):
        rail = PayRail(
            rpc_url="https://rpc.example",
            private_key=_TEST_KEY,
            usdc_address=_ADDR_A,
            registry_address=_ADDR_B,
            payment_address=_ADDR_C,
        )
        # Rebind the instance's methods to the patched path
        rail._local_registry_path = registry_path
    return rail, registry_path


def _write_registry(path: Path, entries: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(entries))


# ── publish ────────────────────────────────────────────────────────────────────


def test_publish_saves_to_local_registry(tmp_path: Path) -> None:
    """publish() writes the agent entry to the local registry JSON file."""
    registry_file = tmp_path / "registry.json"

    mock_tx = {
        "name": "search-agent",
        "address": "0x" + "1" * 40,
        "price_per_call": 0.01,
        "tx_hash": "0xabc" + "0" * 61,
    }

    with patch("payrail.client._LOCAL_REGISTRY", registry_file):
        with patch("payrail.client._registry.register_agent", return_value=mock_tx):
            from payrail.client import PayRail

            rail = PayRail(
                rpc_url="https://rpc.example",
                private_key=_TEST_KEY,
                usdc_address=_ADDR_A,
                registry_address=_ADDR_B,
                payment_address=_ADDR_C,
            )
            result = rail.publish(
                name="search-agent",
                price=0.01,
                capability="web search",
                endpoint=None,
            )

    assert registry_file.exists(), "registry.json should be created"
    data = json.loads(registry_file.read_text())
    assert isinstance(data, list)
    assert len(data) == 1
    entry = data[0]
    assert entry["name"] == "search-agent"
    assert entry["capability"] == "web search"
    assert entry["price"] == 0.01
    assert entry["endpoint"] is None
    assert "basescan" in result
    assert result["tx_hash"] == mock_tx["tx_hash"]


def test_publish_updates_existing_entry(tmp_path: Path) -> None:
    """Publishing again with the same wallet address overwrites the existing entry."""
    registry_file = tmp_path / "registry.json"

    with patch("payrail.client._LOCAL_REGISTRY", registry_file):
        with patch("payrail.client._registry.register_agent") as mock_reg:
            from payrail.client import PayRail

            rail = PayRail(
                rpc_url="https://rpc.example",
                private_key=_TEST_KEY,
                usdc_address=_ADDR_A,
                registry_address=_ADDR_B,
                payment_address=_ADDR_C,
            )

            mock_reg.return_value = {
                "name": "agent-v1",
                "address": rail._address,
                "price_per_call": 0.01,
                "tx_hash": "0x" + "a" * 64,
            }
            rail.publish(name="agent-v1", price=0.01, capability="search")

            mock_reg.return_value = {
                "name": "agent-v2",
                "address": rail._address,
                "price_per_call": 0.02,
                "tx_hash": "0x" + "b" * 64,
            }
            rail.publish(name="agent-v2", price=0.02, capability="search enhanced")

    data = json.loads(registry_file.read_text())
    # Only one entry — the second publish replaced the first
    assert len(data) == 1
    assert data[0]["name"] == "agent-v2"
    assert data[0]["capability"] == "search enhanced"


# ── discover ───────────────────────────────────────────────────────────────────


def test_discover_finds_capability_match(tmp_path: Path) -> None:
    """discover() returns agents whose capability contains the keyword."""
    registry_file = tmp_path / "registry.json"
    _write_registry(
        registry_file,
        [
            {
                "name": "search-agent",
                "address": _ADDR_AGENT1,
                "price": 0.01,
                "capability": "web search",
                "endpoint": None,
            },
            {
                "name": "code-agent",
                "address": _ADDR_AGENT2,
                "price": 0.05,
                "capability": "code execution",
                "endpoint": None,
            },
        ],
    )

    with patch("payrail.client._LOCAL_REGISTRY", registry_file):
        from payrail.client import PayRail

        rail = PayRail(
            rpc_url="https://rpc.example",
            private_key=_TEST_KEY,
            usdc_address=_ADDR_A,
            registry_address=_ADDR_B,
            payment_address=_ADDR_C,
        )
        results = rail.discover("web search")

    assert len(results) == 1
    assert results[0]["name"] == "search-agent"
    assert results[0]["price"] == 0.01


def test_discover_case_insensitive(tmp_path: Path) -> None:
    registry_file = tmp_path / "registry.json"
    _write_registry(
        registry_file,
        [
            {
                "name": "Search-Agent",
                "address": _ADDR_AGENT1,
                "price": 0.01,
                "capability": "Web Search",
                "endpoint": None,
            }
        ],
    )

    with patch("payrail.client._LOCAL_REGISTRY", registry_file):
        from payrail.client import PayRail

        rail = PayRail(
            rpc_url="https://rpc.example",
            private_key=_TEST_KEY,
            usdc_address=_ADDR_A,
            registry_address=_ADDR_B,
            payment_address=_ADDR_C,
        )
        results = rail.discover("web search")

    assert len(results) == 1


def test_discover_filters_by_max_price(tmp_path: Path) -> None:
    """discover() excludes agents above max_price."""
    registry_file = tmp_path / "registry.json"
    _write_registry(
        registry_file,
        [
            {
                "name": "cheap-agent",
                "address": _ADDR_AGENT1,
                "price": 0.01,
                "capability": "search",
                "endpoint": None,
            },
            {
                "name": "pricey-agent",
                "address": _ADDR_AGENT2,
                "price": 0.10,
                "capability": "search",
                "endpoint": None,
            },
        ],
    )

    with patch("payrail.client._LOCAL_REGISTRY", registry_file):
        from payrail.client import PayRail

        rail = PayRail(
            rpc_url="https://rpc.example",
            private_key=_TEST_KEY,
            usdc_address=_ADDR_A,
            registry_address=_ADDR_B,
            payment_address=_ADDR_C,
        )
        results = rail.discover("search", max_price=0.05)

    assert len(results) == 1
    assert results[0]["name"] == "cheap-agent"
    assert results[0]["price"] == 0.01


def test_discover_returns_sorted_by_price(tmp_path: Path) -> None:
    """Results are sorted cheapest-first."""
    registry_file = tmp_path / "registry.json"
    _write_registry(
        registry_file,
        [
            {
                "name": "pricey",
                "address": _ADDR_AGENT2,
                "price": 0.10,
                "capability": "analysis",
                "endpoint": None,
            },
            {
                "name": "cheap",
                "address": _ADDR_AGENT1,
                "price": 0.01,
                "capability": "analysis",
                "endpoint": None,
            },
        ],
    )

    with patch("payrail.client._LOCAL_REGISTRY", registry_file):
        from payrail.client import PayRail

        rail = PayRail(
            rpc_url="https://rpc.example",
            private_key=_TEST_KEY,
            usdc_address=_ADDR_A,
            registry_address=_ADDR_B,
            payment_address=_ADDR_C,
        )
        results = rail.discover("analysis")

    assert results[0]["name"] == "cheap"
    assert results[1]["name"] == "pricey"


def test_discover_returns_empty_when_no_match(tmp_path: Path) -> None:
    registry_file = tmp_path / "registry.json"
    _write_registry(registry_file, [])

    with patch("payrail.client._LOCAL_REGISTRY", registry_file):
        from payrail.client import PayRail

        rail = PayRail(
            rpc_url="https://rpc.example",
            private_key=_TEST_KEY,
            usdc_address=_ADDR_A,
            registry_address=_ADDR_B,
            payment_address=_ADDR_C,
        )
        results = rail.discover("nonexistent-capability")

    assert results == []


# ── hire ───────────────────────────────────────────────────────────────────────


def test_hire_pays_cheapest_agent(tmp_path: Path) -> None:
    """hire() picks the cheapest matching agent and calls pay() with its address."""
    registry_file = tmp_path / "registry.json"
    _write_registry(
        registry_file,
        [
            {
                "name": "cheap-search",
                "address": _ADDR_AGENT1,
                "price": 0.01,
                "capability": "web search",
                "endpoint": None,
            },
            {
                "name": "pricey-search",
                "address": _ADDR_AGENT2,
                "price": 0.05,
                "capability": "web search",
                "endpoint": None,
            },
        ],
    )

    mock_receipt = {
        "tx_hash": "0x" + "a" * 64,
        "from": "0x" + "1" * 40,
        "to": _ADDR_AGENT1,
        "amount": 0.01,
        "task_id": "hire:xxx",
        "block": 42,
        "status": "confirmed",
        "basescan": "https://sepolia.basescan.org/tx/0x" + "a" * 64,
    }

    with patch("payrail.client._LOCAL_REGISTRY", registry_file):
        from payrail.client import PayRail

        rail = PayRail(
            rpc_url="https://rpc.example",
            private_key=_TEST_KEY,
            usdc_address=_ADDR_A,
            registry_address=_ADDR_B,
            payment_address=_ADDR_C,
        )

        with patch.object(rail, "pay", return_value=mock_receipt) as mock_pay:
            result = rail.hire("web search", "test query", budget=0.10)

    # Must have paid the cheapest agent
    pay_kwargs = mock_pay.call_args.kwargs
    assert pay_kwargs["to"] == _ADDR_AGENT1
    assert pay_kwargs["amount"] == 0.01

    assert result["cost"] == 0.01
    assert result["agent_address"] == _ADDR_AGENT1
    assert "basescan" in result
    assert result["output"] == "Payment confirmed — no endpoint registered"


def test_hire_with_endpoint_posts_to_it(tmp_path: Path) -> None:
    """hire() POSTs to the agent endpoint when one is configured."""
    registry_file = tmp_path / "registry.json"
    _write_registry(
        registry_file,
        [
            {
                "name": "api-agent",
                "address": _ADDR_AGENT1,
                "price": 0.01,
                "capability": "search",
                "endpoint": "http://agent.example/run",
            }
        ],
    )

    mock_receipt = {
        "tx_hash": "0x" + "b" * 64,
        "from": "0x" + "1" * 40,
        "to": _ADDR_AGENT1,
        "amount": 0.01,
        "task_id": "hire:yyy",
        "block": 43,
        "status": "confirmed",
        "basescan": "https://sepolia.basescan.org/tx/0x" + "b" * 64,
    }

    fake_response = MagicMock()
    fake_response.text = "agent output text"

    with patch("payrail.client._LOCAL_REGISTRY", registry_file):
        from payrail.client import PayRail

        rail = PayRail(
            rpc_url="https://rpc.example",
            private_key=_TEST_KEY,
            usdc_address=_ADDR_A,
            registry_address=_ADDR_B,
            payment_address=_ADDR_C,
        )

        with patch.object(rail, "pay", return_value=mock_receipt):
            with patch("payrail.client.requests.post", return_value=fake_response) as mock_post:
                result = rail.hire("search", "hello", budget=0.10)

    mock_post.assert_called_once_with(
        "http://agent.example/run",
        json={"input": "hello"},
        timeout=30,
    )
    assert result["output"] == "agent output text"


def test_hire_raises_when_no_agents_found(tmp_path: Path) -> None:
    """hire() raises AgentNotRegisteredError when discover() returns nothing."""
    registry_file = tmp_path / "registry.json"
    _write_registry(registry_file, [])

    with patch("payrail.client._LOCAL_REGISTRY", registry_file):
        from payrail.client import PayRail

        rail = PayRail(
            rpc_url="https://rpc.example",
            private_key=_TEST_KEY,
            usdc_address=_ADDR_A,
            registry_address=_ADDR_B,
            payment_address=_ADDR_C,
        )

        with pytest.raises(AgentNotRegisteredError, match="web search"):
            rail.hire("web search", "query", budget=1.0)


def test_hire_respects_budget(tmp_path: Path) -> None:
    """hire() excludes agents above the budget via discover(max_price=budget)."""
    registry_file = tmp_path / "registry.json"
    _write_registry(
        registry_file,
        [
            {
                "name": "expensive",
                "address": _ADDR_AGENT1,
                "price": 0.50,
                "capability": "search",
                "endpoint": None,
            }
        ],
    )

    with patch("payrail.client._LOCAL_REGISTRY", registry_file):
        from payrail.client import PayRail

        rail = PayRail(
            rpc_url="https://rpc.example",
            private_key=_TEST_KEY,
            usdc_address=_ADDR_A,
            registry_address=_ADDR_B,
            payment_address=_ADDR_C,
        )

        with pytest.raises(AgentNotRegisteredError):
            rail.hire("search", "query", budget=0.10)
