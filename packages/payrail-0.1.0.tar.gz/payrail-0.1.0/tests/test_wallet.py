"""Unit tests for ``payrail.wallet`` (no live RPC calls)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from payrail.exceptions import WalletError
from payrail.wallet import create_wallet, get_balance


def test_create_wallet_returns_address_and_key() -> None:
    wallet = create_wallet()
    assert "address" in wallet and "private_key" in wallet
    assert wallet["address"].startswith("0x")
    assert wallet["private_key"].startswith("0x")
    assert len(wallet["private_key"]) == 66


def test_create_wallet_generates_unique_wallets() -> None:
    first = create_wallet()
    second = create_wallet()
    assert first["address"] != second["address"]
    assert first["private_key"] != second["private_key"]


@patch("payrail.wallet.Web3.HTTPProvider", autospec=True)
def test_get_balance_returns_float(mock_provider: MagicMock) -> None:
    mock_w3 = MagicMock()
    mock_w3.is_connected.return_value = True
    mock_contract = MagicMock()
    mock_contract.functions.balanceOf.return_value.call.return_value = 1_500_000
    mock_w3.eth.contract.return_value = mock_contract

    with patch("payrail.wallet.Web3", return_value=mock_w3):
        balance = get_balance(
            "0x0000000000000000000000000000000000000001",
            "https://example.invalid",
            "0x000000000000000000000000000000000000dEaD",
        )

    assert balance == 1.5


@patch("payrail.wallet.Web3.HTTPProvider", autospec=True)
def test_get_balance_raises_on_bad_rpc(mock_provider: MagicMock) -> None:
    mock_w3 = MagicMock()
    mock_w3.is_connected.return_value = False

    with patch("payrail.wallet.Web3", return_value=mock_w3):
        with pytest.raises(WalletError):
            get_balance(
                "0x0000000000000000000000000000000000000001",
                "https://example.invalid",
                "0x000000000000000000000000000000000000dEaD",
            )


@patch("payrail.wallet.Web3.HTTPProvider", autospec=True)
def test_get_balance_raises_when_contract_call_fails(mock_provider: MagicMock) -> None:
    mock_w3 = MagicMock()
    mock_w3.is_connected.return_value = True
    mock_contract = MagicMock()
    mock_contract.functions.balanceOf.return_value.call.side_effect = ValueError("rpc failure")

    with patch("payrail.wallet.Web3", return_value=mock_w3):
        mock_w3.eth.contract.return_value = mock_contract
        with pytest.raises(WalletError):
            get_balance(
                "0x0000000000000000000000000000000000000001",
                "https://example.invalid",
                "0x000000000000000000000000000000000000dEaD",
            )
