"""Unit tests for ``payrail.registry`` (mocked web3)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from payrail.exceptions import AgentNotRegisteredError, WalletError
from payrail.registry import get_agent_price


@patch("payrail.registry.Web3.HTTPProvider", autospec=True)
def test_get_agent_price_returns_float(mock_provider: MagicMock) -> None:
    mock_w3 = MagicMock()
    mock_w3.is_connected.return_value = True
    mock_registry = MagicMock()
    mock_registry.functions.getAgent.return_value.call.return_value = (
        "0x0000000000000000000000000000000000000001",
        "agent",
        1_000_000,
        True,
    )
    mock_w3.eth.contract.return_value = mock_registry

    with patch("payrail.registry.Web3", return_value=mock_w3):
        price = get_agent_price(
            "0x0000000000000000000000000000000000000001",
            "https://rpc.example",
            "0x" + "3" * 40,
            [],
        )

    assert price == 1.0


@patch("payrail.registry.Web3.HTTPProvider", autospec=True)
def test_get_agent_price_raises_when_inactive(mock_provider: MagicMock) -> None:
    mock_w3 = MagicMock()
    mock_w3.is_connected.return_value = True
    mock_registry = MagicMock()
    mock_registry.functions.getAgent.return_value.call.return_value = (
        "0x0000000000000000000000000000000000000001",
        "agent",
        500_000,
        False,
    )
    mock_w3.eth.contract.return_value = mock_registry

    with patch("payrail.registry.Web3", return_value=mock_w3):
        with pytest.raises(AgentNotRegisteredError):
            get_agent_price(
                "0x0000000000000000000000000000000000000001",
                "https://rpc.example",
                "0x" + "4" * 40,
                [],
            )
