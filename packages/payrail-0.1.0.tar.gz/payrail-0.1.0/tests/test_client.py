"""Unit tests for ``payrail.client.PayRail`` (mocked — no live RPC calls)."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, call, patch

import pytest

from payrail._abis import PAYMENT_ABI
from payrail.exceptions import ConfigurationError

# ── Fixtures ───────────────────────────────────────────────────────────────────

# A valid 32-byte private key (non-zero, within secp256k1 range)
_TEST_KEY = "0x" + "1" * 64

_MOCK_ENV = {
    "BASE_RPC_URL": "https://rpc.example",
    "PRIVATE_KEY": _TEST_KEY,
    "USDC_CONTRACT_ADDR": "0x" + "A" * 40,
    "REGISTRY_CONTRACT_ADDR": "0x" + "B" * 40,
    "PAYMENT_CONTRACT_ADDR": "0x" + "C" * 40,
}


def _make_rail():
    """Construct PayRail with mock env vars (no .env file needed)."""
    from payrail.client import PayRail

    return PayRail(
        rpc_url=_MOCK_ENV["BASE_RPC_URL"],
        private_key=_MOCK_ENV["PRIVATE_KEY"],
        usdc_address=_MOCK_ENV["USDC_CONTRACT_ADDR"],
        registry_address=_MOCK_ENV["REGISTRY_CONTRACT_ADDR"],
        payment_address=_MOCK_ENV["PAYMENT_CONTRACT_ADDR"],
    )


# ── Part 1: construction ───────────────────────────────────────────────────────


@patch.dict(os.environ, _MOCK_ENV)
def test_payrail_loads_from_env() -> None:
    """PayRail reads all five required vars from the environment."""
    from payrail.client import PayRail

    rail = PayRail()

    assert rail._rpc_url == "https://rpc.example"
    assert rail._usdc_address == "0x" + "A" * 40
    assert rail._registry_address == "0x" + "B" * 40
    assert rail._payment_address == "0x" + "C" * 40
    # Address is derived from the private key — must be a valid checksum address
    assert rail._address.startswith("0x")
    assert len(rail._address) == 42


@patch.dict(os.environ, {k: v for k, v in _MOCK_ENV.items() if k != "BASE_RPC_URL"}, clear=False)
def test_payrail_raises_config_error_when_env_missing() -> None:
    """ConfigurationError raised when a required env var is absent."""
    # Remove BASE_RPC_URL from the environment entirely
    env_without_rpc = {k: v for k, v in _MOCK_ENV.items() if k != "BASE_RPC_URL"}
    with patch.dict(os.environ, env_without_rpc, clear=True):
        from payrail.client import PayRail

        with pytest.raises(ConfigurationError, match="BASE_RPC_URL"):
            PayRail()


def test_payrail_raises_config_error_for_zero_address() -> None:
    """ConfigurationError raised when a contract address is the zero address."""
    from payrail.client import PayRail

    with pytest.raises(ConfigurationError, match="PAYMENT_CONTRACT_ADDR"):
        PayRail(
            rpc_url="https://rpc.example",
            private_key=_TEST_KEY,
            usdc_address="0x" + "A" * 40,
            registry_address="0x" + "B" * 40,
            payment_address="0x" + "0" * 40,  # zero address
        )


# ── Part 2: wallet delegation ─────────────────────────────────────────────────


def test_get_balance_delegates_to_wallet() -> None:
    """PayRail.get_balance delegates to wallet.get_balance with own address."""
    rail = _make_rail()

    with patch("payrail.client._wallet.get_balance", return_value=5.25) as mock_get:
        result = rail.get_balance()

    assert result == 5.25
    mock_get.assert_called_once_with(rail._address, rail._rpc_url, rail._usdc_address)


def test_get_balance_with_explicit_address() -> None:
    """Explicit address overrides self._address."""
    rail = _make_rail()
    other = "0x" + "D" * 40

    with patch("payrail.client._wallet.get_balance", return_value=1.0) as mock_get:
        rail.get_balance(address=other)

    mock_get.assert_called_once_with(other, rail._rpc_url, rail._usdc_address)


def test_get_eth_balance_delegates_to_wallet() -> None:
    rail = _make_rail()

    with patch("payrail.client._wallet.get_eth_balance", return_value=0.05) as mock_get:
        result = rail.get_eth_balance()

    assert result == 0.05
    mock_get.assert_called_once_with(rail._address, rail._rpc_url)


def test_create_wallet_delegates() -> None:
    rail = _make_rail()

    fake_wallet = {"address": "0x" + "F" * 40, "private_key": "0x" + "E" * 64}
    with patch("payrail.client._wallet.create_wallet", return_value=fake_wallet) as mock_cw:
        result = rail.create_wallet()

    assert result == fake_wallet
    mock_cw.assert_called_once()


# ── Part 3: payment delegation ────────────────────────────────────────────────


def test_pay_returns_receipt_with_basescan() -> None:
    """pay() adds a basescan URL to the receipt returned by send_payment."""
    rail = _make_rail()

    mock_receipt = {
        "tx_hash": "0xdeadbeef" + "0" * 56,
        "from": rail._address,
        "to": "0x" + "2" * 40,
        "amount": 0.01,
        "task_id": "task-abc",
        "block": 12345,
        "status": "confirmed",
    }

    with patch("payrail.client._payment.send_payment", return_value=mock_receipt) as mock_pay:
        result = rail.pay(to="0x" + "2" * 40, amount=0.01, task_id="task-abc")

    assert "basescan" in result
    assert "deadbeef" in result["basescan"]
    assert result["basescan"].startswith("https://sepolia.basescan.org/tx/0x")
    mock_pay.assert_called_once()


def test_verify_delegates_to_payment() -> None:
    rail = _make_rail()

    with patch("payrail.client._payment.verify_payment", return_value=True) as mock_v:
        result = rail.verify("task-xyz")

    assert result is True
    mock_v.assert_called_once_with(
        task_id="task-xyz",
        rpc_url=rail._rpc_url,
        payment_contract_address=rail._payment_address,
        payment_contract_abi=PAYMENT_ABI,
    )


def test_receipt_delegates_to_receipt_module() -> None:
    rail = _make_rail()
    fake = {"from": "0x1", "to": "0x2", "amount": 0.05, "timestamp": "2024-01-01"}

    with patch("payrail.client._receipt.get_receipt", return_value=fake) as mock_r:
        result = rail.receipt("task-abc")

    assert result == fake
    mock_r.assert_called_once()


def test_receipts_defaults_to_own_address() -> None:
    rail = _make_rail()

    with patch("payrail.client._receipt.list_receipts", return_value=[]) as mock_lr:
        rail.receipts()

    args, kwargs = mock_lr.call_args
    # address should be rail._address (first positional arg or kwarg)
    called_address = kwargs.get("address") or (args[0] if args else None)
    assert called_address == rail._address


# ── Part 4: register delegation ───────────────────────────────────────────────


def test_register_delegates_to_registry() -> None:
    rail = _make_rail()
    fake_result = {
        "name": "my-agent",
        "address": rail._address,
        "price_per_call": 0.01,
        "tx_hash": "0xabcd" + "0" * 60,
    }

    with patch("payrail.client._registry.register_agent", return_value=fake_result) as mock_reg:
        result = rail.register("my-agent", 0.01)

    assert result["name"] == "my-agent"
    mock_reg.assert_called_once()
    call_kwargs = mock_reg.call_args.kwargs
    assert call_kwargs["name"] == "my-agent"
    assert call_kwargs["price_per_call_usdc"] == 0.01
    assert call_kwargs["private_key"] == rail._private_key


# ── Part 5: payable decorator ─────────────────────────────────────────────────


def test_payable_calls_pay_then_executes_function() -> None:
    """@rail.payable charges USDC and then returns the function's result."""
    rail = _make_rail()

    mock_receipt = {
        "tx_hash": "0x" + "a" * 64,
        "from": rail._address,
        "to": rail._address,
        "amount": 0.01,
        "task_id": "payable:search:xxx",
        "block": 1,
        "status": "confirmed",
        "basescan": "https://sepolia.basescan.org/tx/0xaaa",
    }

    with patch.object(rail, "pay", return_value=mock_receipt) as mock_pay:

        @rail.payable(price=0.01)
        def search(query: str) -> str:
            return f"results for {query}"

        result = search("agents")

    assert result == "results for agents"
    mock_pay.assert_called_once()
    call_kwargs = mock_pay.call_args.kwargs
    assert call_kwargs["amount"] == 0.01
    assert call_kwargs["to"] == rail._address


def test_payable_preserves_function_name() -> None:
    """@wraps should preserve __name__ and __doc__."""
    rail = _make_rail()

    @rail.payable(price=0.01)
    def my_special_function() -> str:
        """docstring"""
        return "ok"

    assert my_special_function.__name__ == "my_special_function"
    assert my_special_function.__doc__ == "docstring"


def test_payable_currency_parameter_accepted() -> None:
    """currency param is accepted; no TypeError raised."""
    rail = _make_rail()

    mock_receipt = {
        "tx_hash": "0x" + "b" * 64,
        "from": rail._address,
        "to": rail._address,
        "amount": 0.05,
        "task_id": "x",
        "block": 1,
        "status": "confirmed",
        "basescan": "https://sepolia.basescan.org/tx/0xbbb",
    }

    with patch.object(rail, "pay", return_value=mock_receipt):

        @rail.payable(price=0.05, currency="USDC")
        def fn() -> int:
            return 42

        assert fn() == 42
