"""Unit tests for ``payrail.payment`` (mocked web3)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from payrail.exceptions import WalletError
from payrail.payment import verify_payment


@patch("payrail.payment.Web3.HTTPProvider", autospec=True)
def test_verify_payment_returns_bool(mock_provider: MagicMock) -> None:
    mock_w3 = MagicMock()
    mock_w3.is_connected.return_value = True
    mock_payment = MagicMock()
    mock_payment.functions.verifyPayment.return_value.call.return_value = True
    mock_w3.eth.contract.return_value = mock_payment

    with patch("payrail.payment.Web3", return_value=mock_w3):
        assert verify_payment("task-a", "https://rpc.example", "0x" + "1" * 40, []) is True


@patch("payrail.payment.Web3.HTTPProvider", autospec=True)
def test_verify_payment_raises_wallet_error_when_offline(mock_provider: MagicMock) -> None:
    mock_w3 = MagicMock()
    mock_w3.is_connected.return_value = False

    with patch("payrail.payment.Web3", return_value=mock_w3):
        with pytest.raises(WalletError):
            verify_payment("task-a", "https://rpc.example", "0x" + "2" * 40, [])
