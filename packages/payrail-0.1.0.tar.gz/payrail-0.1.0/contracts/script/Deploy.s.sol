// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Script, console2} from "forge-std/Script.sol";
import {AgentRegistry} from "../src/AgentRegistry.sol";
import {AgentPayment} from "../src/AgentPayment.sol";

/// @notice Deploy `AgentRegistry` and `AgentPayment` to Base Sepolia (or any configured RPC).
/// @dev Required env vars: `PRIVATE_KEY` (uint256), `USDC_CONTRACT_ADDR` (address).
contract Deploy is Script {
    function run() external {
        uint256 deployerPrivateKey = vm.envUint("PRIVATE_KEY");
        address deployer = vm.addr(deployerPrivateKey);
        address usdc = vm.envAddress("USDC_CONTRACT_ADDR");

        vm.startBroadcast(deployerPrivateKey);

        AgentRegistry registry = new AgentRegistry(deployer);
        AgentPayment payment = new AgentPayment(address(registry), usdc);

        vm.stopBroadcast();

        console2.log("Deployer:", deployer);
        console2.log("USDC:", usdc);
        console2.log("AgentRegistry:", address(registry));
        console2.log("AgentPayment:", address(payment));
    }
}
