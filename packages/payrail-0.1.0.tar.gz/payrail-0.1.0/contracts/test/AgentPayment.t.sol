// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {AgentRegistry} from "../src/AgentRegistry.sol";
import {AgentPayment} from "../src/AgentPayment.sol";

/// @dev Minimal 6-decimal ERC-20 for tests (matches production USDC units).
contract USDC6Mock is ERC20 {
    constructor() ERC20("USDC", "USDC") {}

    function decimals() public pure override returns (uint8) {
        return 6;
    }

    function mint(address to, uint256 amount) external {
        _mint(to, amount);
    }
}

contract AgentPaymentTest is Test {
    AgentRegistry internal registry;
    AgentPayment internal payment;
    USDC6Mock internal usdc;

    address internal admin = address(0xA11CE);
    address internal payer = address(0xCAFE);
    address internal agent = address(0xBEEF);

    bytes32 internal constant TASK_ID = keccak256("task-1");

    function setUp() public {
        vm.prank(admin);
        registry = new AgentRegistry(admin);

        usdc = new USDC6Mock();
        payment = new AgentPayment(address(registry), address(usdc));

        vm.prank(agent);
        registry.registerAgent("svc", 10_000);

        usdc.mint(payer, 1_000_000e6);
        vm.prank(payer);
        usdc.approve(address(payment), type(uint256).max);
    }

    function test_pay_transfersAndStoresReceipt() public {
        uint256 amount = 50_000;

        vm.prank(payer);
        payment.pay(agent, amount, TASK_ID);

        assertEq(usdc.balanceOf(agent), amount);

        AgentPayment.Receipt memory receipt = payment.getReceipt(TASK_ID);
        assertEq(receipt.from, payer);
        assertEq(receipt.to, agent);
        assertEq(receipt.amount, amount);
        assertEq(receipt.taskId, TASK_ID);
        assertTrue(receipt.timestamp > 0);
        assertTrue(payment.verifyPayment(TASK_ID));
    }

    function test_pay_revertsBelowMinPrice() public {
        vm.prank(payer);
        vm.expectRevert(bytes("AgentPayment: below minimum price"));
        payment.pay(agent, 9_999, keccak256("low"));
    }

    function test_pay_revertsDuplicateTaskId() public {
        vm.startPrank(payer);
        payment.pay(agent, 10_000, TASK_ID);
        vm.expectRevert(bytes("AgentPayment: duplicate taskId"));
        payment.pay(agent, 10_000, TASK_ID);
        vm.stopPrank();
    }

    function test_pay_revertsWhenRecipientNotRegistered() public {
        address stranger = address(0xDEAD);
        vm.prank(payer);
        vm.expectRevert(bytes("AgentPayment: not registered"));
        payment.pay(stranger, 10_000, keccak256("x"));
    }
}
