// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";
import {AgentRegistry} from "../src/AgentRegistry.sol";

contract AgentRegistryTest is Test {
    AgentRegistry internal registry;
    address internal admin = address(0xA11CE);
    address internal agent = address(0xBEEF);

    function setUp() public {
        vm.prank(admin);
        registry = new AgentRegistry(admin);
    }

    function test_registerAgent_setsFieldsAndEmits() public {
        vm.startPrank(agent);
        vm.expectEmit(true, true, true, true);
        emit AgentRegistry.AgentRegistered(agent, "search-bot", 10_000);
        registry.registerAgent("search-bot", 10_000);
        vm.stopPrank();

        (address wallet, string memory name, uint256 price, bool active) = registry.getAgent(agent);
        assertEq(wallet, agent);
        assertEq(name, "search-bot");
        assertEq(price, 10_000);
        assertTrue(active);
        assertTrue(registry.isRegistered(agent));
    }

    function test_registerAgent_revertsWhenActive() public {
        vm.startPrank(agent);
        registry.registerAgent("a", 1);
        vm.expectRevert(bytes("AgentRegistry: already active"));
        registry.registerAgent("b", 2);
        vm.stopPrank();
    }

    function test_deactivateAgent() public {
        vm.startPrank(agent);
        registry.registerAgent("a", 1);
        registry.deactivateAgent();
        vm.stopPrank();

        (,,, bool active) = registry.getAgent(agent);
        assertFalse(active);
    }

    function test_reregister_afterDeactivate() public {
        vm.startPrank(agent);
        registry.registerAgent("a", 1);
        registry.deactivateAgent();
        registry.registerAgent("b", 2);
        vm.stopPrank();

        (, string memory name, uint256 price, bool active) = registry.getAgent(agent);
        assertEq(name, "b");
        assertEq(price, 2);
        assertTrue(active);
    }

    function test_updatePrice() public {
        vm.startPrank(agent);
        registry.registerAgent("a", 1);
        registry.updatePrice(99);
        vm.stopPrank();

        (,, uint256 price,) = registry.getAgent(agent);
        assertEq(price, 99);
    }

    function test_adminDeactivate() public {
        vm.prank(agent);
        registry.registerAgent("a", 1);

        vm.prank(admin);
        registry.adminDeactivate(agent);

        (,,, bool active) = registry.getAgent(agent);
        assertFalse(active);
    }
}
