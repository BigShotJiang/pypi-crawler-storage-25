// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

/**
 * @title AgentRegistry
 * @notice On-chain registry of AI agent wallets, display names, and per-call USDC prices.
 * @dev Each agent registers their own address. Only that address may update price or deactivate.
 *      The contract `owner` (OpenZeppelin `Ownable`) may perform administrative actions.
 */
contract AgentRegistry is Ownable {
    /// @notice On-chain record for a registered agent.
    struct Agent {
        address wallet;
        string name;
        uint256 pricePerCall;
        bool active;
    }

    /// @dev Agent key is the agent's wallet address.
    mapping(address => Agent) private agentsByWallet;

    /// @notice Emitted when an agent successfully registers or re-registers as active.
    event AgentRegistered(address indexed wallet, string name, uint256 pricePerCall);

    /// @notice Emitted when an agent deactivates their listing.
    event AgentDeactivated(address indexed wallet);

    /// @notice Emitted when an agent updates their per-call price.
    event PriceUpdated(address indexed wallet, uint256 newPrice);

    /**
     * @notice Creates the registry and assigns the deployer as the admin `owner`.
     * @param initialOwner Address that receives Ownable admin rights.
     */
    constructor(address initialOwner) Ownable(initialOwner) {}

    /**
     * @notice Register or re-activate the caller as an agent with a name and USDC price per call.
     * @param name Human-readable agent name (must be non-empty).
     * @param pricePerCall Minimum USDC amount per call, in token smallest units (6 decimals for USDC).
     */
    function registerAgent(string calldata name, uint256 pricePerCall) external {
        require(bytes(name).length > 0, "AgentRegistry: empty name");
        require(pricePerCall > 0, "AgentRegistry: price must be positive");

        Agent storage record = agentsByWallet[msg.sender];
        // First-time registration: `wallet` is zero. Re-registration after `deactivateAgent`.
        require(record.wallet == address(0) || !record.active, "AgentRegistry: already active");

        record.wallet = msg.sender;
        record.name = name;
        record.pricePerCall = pricePerCall;
        record.active = true;

        emit AgentRegistered(msg.sender, name, pricePerCall);
    }

    /**
     * @notice Deactivate the caller's agent listing. Only the registered wallet may call.
     */
    function deactivateAgent() external {
        Agent storage record = agentsByWallet[msg.sender];
        require(record.wallet == msg.sender, "AgentRegistry: not registered");
        require(record.active, "AgentRegistry: already inactive");

        record.active = false;
        emit AgentDeactivated(msg.sender);
    }

    /**
     * @notice Update the caller's per-call USDC price. Only the registered wallet may call.
     * @param newPrice New minimum amount per call, in USDC smallest units (6 decimals).
     */
    function updatePrice(uint256 newPrice) external {
        require(newPrice > 0, "AgentRegistry: price must be positive");

        Agent storage record = agentsByWallet[msg.sender];
        require(record.wallet == msg.sender, "AgentRegistry: not registered");
        require(record.active, "AgentRegistry: inactive agent");

        record.pricePerCall = newPrice;
        emit PriceUpdated(msg.sender, newPrice);
    }

    /**
     * @notice Read the full agent struct for an address.
     * @param agent The wallet address to query.
     * @return wallet Registered wallet (equals `agent` when registered).
     * @return name Agent display name.
     * @return pricePerCall Minimum USDC per call in smallest units.
     * @return active Whether the agent is currently active.
     */
    function getAgent(address agent)
        external
        view
        returns (address wallet, string memory name, uint256 pricePerCall, bool active)
    {
        Agent storage record = agentsByWallet[agent];
        return (record.wallet, record.name, record.pricePerCall, record.active);
    }

    /**
     * @notice Returns true if the address has ever registered (wallet field set).
     * @param agent Address to check.
     * @return True if a registration record exists for this wallet.
     */
    function isRegistered(address agent) external view returns (bool) {
        return agentsByWallet[agent].wallet != address(0);
    }

    /**
     * @notice Admin: force-deactivate any agent. Does not clear historical data.
     * @param agent The agent wallet to deactivate.
     */
    function adminDeactivate(address agent) external onlyOwner {
        Agent storage record = agentsByWallet[agent];
        require(record.wallet == agent, "AgentRegistry: not registered");
        require(record.active, "AgentRegistry: already inactive");

        record.active = false;
        emit AgentDeactivated(agent);
    }
}
