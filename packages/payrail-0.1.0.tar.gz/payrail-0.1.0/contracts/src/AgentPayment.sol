// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/**
 * @title AgentPayment
 * @notice Escrows-free USDC payments between agents, with on-chain receipts keyed by task ID.
 * @dev Uses `transferFrom` so payers must approve this contract for USDC first.
 *      All token movements use OpenZeppelin `SafeERC20`.
 */
interface IAgentRegistry {
    function getAgent(address agent)
        external
        view
        returns (address wallet, string memory name, uint256 pricePerCall, bool active);
}

contract AgentPayment {
    using SafeERC20 for IERC20;

    /// @notice Immutable registry used to validate recipients and minimum prices.
    IAgentRegistry public immutable registry;

    /// @notice USDC (or compatible 6-decimal ERC-20) token used for settlement.
    IERC20 public immutable usdc;

    /// @notice Receipt stored after a successful payment.
    struct Receipt {
        address from;
        address to;
        uint256 amount;
        uint256 timestamp;
        bytes32 taskId;
    }

    /// @dev Receipts keyed by unique task identifier.
    mapping(bytes32 => Receipt) private receiptsByTaskId;

    /**
     * @notice Emitted after USDC is transferred and the receipt is stored.
     * @param from Payer address.
     * @param to Recipient agent address.
     * @param amount USDC amount in smallest units.
     * @param taskId Off-chain task identifier (hashed to bytes32 on the client).
     * @param timestamp Block timestamp when mined.
     */
    event PaymentSent(
        address indexed from, address indexed to, uint256 amount, bytes32 indexed taskId, uint256 timestamp
    );

    /**
     * @param registry_ Deployed `AgentRegistry` contract.
     * @param usdc_ USDC token on the target network.
     */
    constructor(address registry_, address usdc_) {
        require(registry_ != address(0), "AgentPayment: zero registry");
        require(usdc_ != address(0), "AgentPayment: zero usdc");
        registry = IAgentRegistry(registry_);
        usdc = IERC20(usdc_);
    }

    /**
     * @notice Pull USDC from the caller and pay a registered active agent.
     * @param to Recipient agent wallet (must be active in the registry).
     * @param amount USDC amount in smallest units; must be >= recipient's `pricePerCall`.
     * @param taskId Unique task id (client should use a hash); must not already be used.
     */
    function pay(address to, uint256 amount, bytes32 taskId) external {
        require(receiptsByTaskId[taskId].timestamp == 0, "AgentPayment: duplicate taskId");

        (address wallet,, uint256 pricePerCall, bool active) = registry.getAgent(to);
        require(wallet == to, "AgentPayment: not registered");
        require(active, "AgentPayment: recipient inactive");
        require(amount >= pricePerCall, "AgentPayment: below minimum price");

        usdc.safeTransferFrom(msg.sender, to, amount);

        receiptsByTaskId[taskId] = Receipt({
            from: msg.sender,
            to: to,
            amount: amount,
            timestamp: block.timestamp,
            taskId: taskId
        });

        emit PaymentSent(msg.sender, to, amount, taskId, block.timestamp);
    }

    /**
     * @notice Return the stored receipt for a task id.
     * @param taskId Task identifier to look up.
     * @return receipt_ Full receipt struct (timestamps zero if missing).
     */
    function getReceipt(bytes32 taskId) external view returns (Receipt memory receipt_) {
        return receiptsByTaskId[taskId];
    }

    /**
     * @notice Returns true if a payment receipt exists for the given task id.
     * @param taskId Task identifier to verify.
     * @return True if `getReceipt` would return a non-empty receipt.
     */
    function verifyPayment(bytes32 taskId) external view returns (bool) {
        return receiptsByTaskId[taskId].timestamp != 0;
    }
}
