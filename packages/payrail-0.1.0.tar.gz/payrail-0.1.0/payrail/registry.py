"""Agent registry helpers: register an agent wallet and read per-call pricing."""

from __future__ import annotations

from typing import Any

from eth_account import Account
from web3 import Web3
from web3.contract import Contract
from web3.exceptions import ContractLogicError, Web3Exception

from payrail.exceptions import AgentNotRegisteredError, ContractError, WalletError

_USDC_DECIMALS = 6


def _normalize_private_key(private_key: str) -> str:
    key = private_key.strip()
    if not key.startswith("0x"):
        key = "0x" + key
    return key


def _price_to_usdc_float(price_smallest: int) -> float:
    return float(price_smallest) / float(10**_USDC_DECIMALS)


def register_agent(
    name: str,
    price_per_call_usdc: float,
    private_key: str,
    rpc_url: str,
    registry_contract_address: str,
    registry_contract_abi: list[dict[str, Any]],
) -> dict[str, Any]:
    """
    Submit ``registerAgent`` for the wallet derived from ``private_key``.

    Args:
        name: Public agent name stored on-chain.
        price_per_call_usdc: Minimum USDC per call as a float (6 decimals).
        private_key: Hex key for the agent wallet paying gas (``0x`` optional).
        rpc_url: HTTPS JSON-RPC URL.
        registry_contract_address: Deployed ``AgentRegistry`` address.
        registry_contract_abi: ABI containing ``registerAgent``.

    Returns:
        Dict with ``name``, ``address``, ``price_per_call``, and ``tx_hash``.

    Raises:
        ContractError: If the transaction fails for a non-revert reason.
        WalletError: If the RPC connection fails.
    """
    try:
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        if not w3.is_connected():
            raise WalletError(f"Could not connect to RPC endpoint: {rpc_url}")

        account = Account.from_key(_normalize_private_key(private_key))
        agent_address = Web3.to_checksum_address(account.address)

        registry: Contract = w3.eth.contract(
            address=Web3.to_checksum_address(registry_contract_address),
            abi=registry_contract_abi,
        )

        price_raw = int(round(price_per_call_usdc * float(10**_USDC_DECIMALS)))
        if price_raw <= 0:
            raise ContractError("price_per_call_usdc must be positive.")

        nonce = w3.eth.get_transaction_count(agent_address)
        chain_id = w3.eth.chain_id

        built = registry.functions.registerAgent(name, price_raw).build_transaction(
            {
                "from": agent_address,
                "nonce": nonce,
                "chainId": chain_id,
            }
        )

        if "gas" not in built or built.get("gas") is None:
            built["gas"] = int(w3.eth.estimate_gas(built))

        if "maxFeePerGas" not in built and "gasPrice" not in built:
            built["gasPrice"] = int(w3.eth.gas_price)

        signed = account.sign_transaction(built)
        raw_tx = getattr(signed, "raw_transaction", getattr(signed, "rawTransaction", None))
        if raw_tx is None:
            raise ContractError("Signed transaction payload missing from signer output.")

        tx_hash = w3.eth.send_raw_transaction(raw_tx)
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

        if receipt["status"] != 1:
            raise ContractError(f"registerAgent transaction failed: {tx_hash.hex()}")

        return {
            "name": name,
            "address": agent_address,
            "price_per_call": price_per_call_usdc,
            "tx_hash": receipt["transactionHash"].hex(),
        }
    except ContractError:
        raise
    except WalletError:
        raise
    except ContractLogicError as exc:
        raise ContractError(f"registerAgent reverted: {exc}") from exc
    except (Web3Exception, ValueError, TypeError) as exc:
        raise ContractError(f"registerAgent failed: {exc}") from exc


def get_agent_price(
    agent_address: str,
    rpc_url: str,
    registry_contract_address: str,
    registry_contract_abi: list[dict[str, Any]],
) -> float:
    """
    Read ``getAgent`` and return ``pricePerCall`` as a USDC float.

    Args:
        agent_address: Agent wallet to query.
        rpc_url: HTTPS JSON-RPC URL.
        registry_contract_address: ``AgentRegistry`` address.
        registry_contract_abi: ABI containing ``getAgent``.

    Returns:
        Price per call in USDC.

    Raises:
        AgentNotRegisteredError: If the wallet is not registered or inactive.
        WalletError: If the RPC connection fails.
    """
    try:
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        if not w3.is_connected():
            raise WalletError(f"Could not connect to RPC endpoint: {rpc_url}")

        registry: Contract = w3.eth.contract(
            address=Web3.to_checksum_address(registry_contract_address),
            abi=registry_contract_abi,
        )

        wallet, _name, price_per_call, active = registry.functions.getAgent(
            Web3.to_checksum_address(agent_address)
        ).call()

        zero_address = "0x0000000000000000000000000000000000000000"
        if wallet == zero_address or not active:
            raise AgentNotRegisteredError(
                f"No active registry entry for agent address {agent_address}."
            )

        return _price_to_usdc_float(int(price_per_call))
    except AgentNotRegisteredError:
        raise
    except WalletError:
        raise
    except (Web3Exception, ValueError, TypeError) as exc:
        raise WalletError(f"getAgent failed: {exc}") from exc
