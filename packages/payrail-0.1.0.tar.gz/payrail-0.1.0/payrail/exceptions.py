"""PayRail-specific exceptions with clear, user-facing messages."""


class PayRailError(Exception):
    """Base class for all PayRail errors."""


class InsufficientBalanceError(PayRailError):
    """Raised when a wallet does not hold enough USDC for the requested payment."""


class AgentNotRegisteredError(PayRailError):
    """Raised when an agent address is missing, inactive, or not present in the registry."""


class PaymentFailedError(PayRailError):
    """Raised when an on-chain payment transaction fails or reverts."""


class ContractError(PayRailError):
    """Raised when a contract call fails for reasons other than a revert (e.g. ABI mismatch)."""


class WalletError(PayRailError):
    """Raised when wallet or RPC operations fail (connectivity, invalid address, etc.)."""


class ConfigurationError(PayRailError):
    """Raised when a required environment variable is missing or set to the zero address."""


class BudgetExceededError(PayRailError):
    """Raised when a PayingAgent's spend budget is exhausted."""
