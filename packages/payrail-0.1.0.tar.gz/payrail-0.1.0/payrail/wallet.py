"""Wallet helpers: create keys and read USDC / ETH balances on Base."""

from __future__ import annotations

from eth_account import Account
from web3 import Web3
from web3.exceptions import Web3Exception

from payrail._abis import ERC20_MINIMAL_ABI
from payrail.exceptions import WalletError

_USDC_DECIMALS = 6


def create_wallet() -> dict[str, str]:
    """
    Generate a new Ethereum externally owned account (EOA).

    Returns:
        A dict with ``address`` (checksummed hex) and ``private_key`` (``0x``-prefixed hex).

    Security:
        Anyone with the private key controls funds. Store encrypted at rest, never commit keys,
        and prefer hardware or KMS-backed signing for production agents.
    """
    account = Account.create()
    private_key_hex = account.key.hex()
    if not private_key_hex.startswith("0x"):
        private_key_hex = "0x" + private_key_hex
    return {
        "address": Web3.to_checksum_address(account.address),
        "private_key": private_key_hex,
    }


def get_balance(address: str, rpc_url: str, usdc_address: str) -> float:
    """
    Read the USDC ``balanceOf`` for an address and return a human-readable float.

    Args:
        address: Checksummed or plain hex wallet address.
        rpc_url: HTTPS JSON-RPC URL (e.g. Base Sepolia).
        usdc_address: USDC token contract on the target network.

    Returns:
        Balance in USDC (divided by ``10**6``).

    Raises:
        WalletError: If the RPC connection fails or the call errors.
    """
    try:
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        if not w3.is_connected():
            raise WalletError(f"Could not connect to RPC endpoint: {rpc_url}")

        token = w3.eth.contract(
            address=Web3.to_checksum_address(usdc_address),
            abi=ERC20_MINIMAL_ABI,
        )
        raw_balance: int = int(token.functions.balanceOf(Web3.to_checksum_address(address)).call())
        return raw_balance / float(10**_USDC_DECIMALS)
    except WalletError:
        raise
    except (Web3Exception, ValueError, TypeError) as exc:
        raise WalletError(f"Failed to read USDC balance: {exc}") from exc


def get_eth_balance(address: str, rpc_url: str) -> float:
    """
    Return the native ETH balance for gas budgeting.

    Args:
        address: Wallet address.
        rpc_url: HTTPS JSON-RPC URL.

    Returns:
        Balance in ETH (not wei).

    Raises:
        WalletError: If the RPC connection fails or the address is invalid.
    """
    try:
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        if not w3.is_connected():
            raise WalletError(f"Could not connect to RPC endpoint: {rpc_url}")

        wei_balance = w3.eth.get_balance(Web3.to_checksum_address(address))
        return float(w3.from_wei(wei_balance, "ether"))
    except WalletError:
        raise
    except (Web3Exception, ValueError, TypeError) as exc:
        raise WalletError(f"Failed to read ETH balance: {exc}") from exc
