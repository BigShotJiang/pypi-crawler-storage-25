"""Read on-chain payment receipts and recent ``PaymentSent`` events."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from web3 import Web3
from web3.contract import Contract
from web3.exceptions import Web3Exception

from payrail.exceptions import ContractError, WalletError

_USDC_DECIMALS = 6
_DEFAULT_LOOKBACK_BLOCKS = 100_000


def _task_id_to_bytes32(task_id: str) -> bytes:
    return Web3.keccak(text=task_id)


def _decode_payment_logs(
    payment: Contract,
    logs: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    decoded: list[dict[str, Any]] = []
    event = payment.events.PaymentSent()
    for entry in logs:
        processed = event.process_log(entry)
        args = processed["args"]
        amount_usdc = float(args["amount"]) / float(10**_USDC_DECIMALS)
        task_hex = args["taskId"].hex()
        txh = entry["transactionHash"]
        tx_hex = txh.hex() if hasattr(txh, "hex") else Web3.to_hex(txh)
        decoded.append(
            {
                "from": args["from"],
                "to": args["to"],
                "amount": amount_usdc,
                "timestamp": datetime.fromtimestamp(int(args["timestamp"]), tz=timezone.utc).isoformat(),
                "task_id": task_hex,
                "tx_hash": tx_hex,
                "block": int(entry["blockNumber"]),
            }
        )
    return decoded


def get_receipt(
    task_id: str,
    rpc_url: str,
    payment_contract_address: str,
    payment_contract_abi: list[dict[str, Any]],
) -> dict[str, Any]:
    """
    Fetch a stored ``Receipt`` struct for a task id (hashed the same way as ``send_payment``).

    Args:
        task_id: Original task string (hashed with Keccak-256).
        rpc_url: HTTPS JSON-RPC URL.
        payment_contract_address: ``AgentPayment`` address.
        payment_contract_abi: ABI containing ``getReceipt``.

    Returns:
        Dict with ``from``, ``to``, ``amount`` (USDC float), ISO ``timestamp``, and ``task_id`` hex.

    Raises:
        ContractError: If no receipt exists for the task id.
        WalletError: If the RPC connection fails.
    """
    try:
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        if not w3.is_connected():
            raise WalletError(f"Could not connect to RPC endpoint: {rpc_url}")

        payment: Contract = w3.eth.contract(
            address=Web3.to_checksum_address(payment_contract_address),
            abi=payment_contract_abi,
        )

        task_bytes = _task_id_to_bytes32(task_id)
        receipt_data = payment.functions.getReceipt(task_bytes).call()

        if isinstance(receipt_data, (list, tuple)):
            payer_addr, payee_addr, amount_raw, ts_raw, task_value = receipt_data
        else:
            payer_addr = receipt_data[0]
            payee_addr = receipt_data[1]
            amount_raw = receipt_data[2]
            ts_raw = receipt_data[3]
            task_value = receipt_data[4]

        ts_int = int(ts_raw)
        if ts_int == 0:
            raise ContractError(f"No on-chain receipt for task_id={task_id!r}.")

        amount_usdc = float(int(amount_raw)) / float(10**_USDC_DECIMALS)
        task_hex = task_value.hex() if hasattr(task_value, "hex") else Web3.to_hex(task_value)

        return {
            "from": Web3.to_checksum_address(payer_addr),
            "to": Web3.to_checksum_address(payee_addr),
            "amount": amount_usdc,
            "timestamp": datetime.fromtimestamp(ts_int, tz=timezone.utc).isoformat(),
            "task_id": task_hex,
        }
    except ContractError:
        raise
    except WalletError:
        raise
    except (Web3Exception, ValueError, TypeError, KeyError) as exc:
        raise WalletError(f"getReceipt failed: {exc}") from exc


def list_receipts(
    address: str,
    rpc_url: str,
    payment_contract_address: str,
    payment_contract_abi: list[dict[str, Any]],
    limit: int = 20,
) -> list[dict[str, Any]]:
    """
    Scan recent ``PaymentSent`` logs where ``from`` or ``to`` matches ``address``.

    Args:
        address: Wallet to match as payer or payee.
        rpc_url: HTTPS JSON-RPC URL.
        payment_contract_address: ``AgentPayment`` address.
        payment_contract_abi: ABI including the ``PaymentSent`` event.
        limit: Maximum number of receipts after sorting (newest first).

    Returns:
        List of receipt dicts including ``tx_hash`` and ``block`` when available.

    Raises:
        WalletError: If the RPC connection fails.
    """
    try:
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        if not w3.is_connected():
            raise WalletError(f"Could not connect to RPC endpoint: {rpc_url}")

        payment: Contract = w3.eth.contract(
            address=Web3.to_checksum_address(payment_contract_address),
            abi=payment_contract_abi,
        )

        checksum_address = Web3.to_checksum_address(address)
        latest = int(w3.eth.block_number)
        from_block = max(0, latest - _DEFAULT_LOOKBACK_BLOCKS)

        def _addr_topic(addr: str) -> bytes:
            body = addr.lower().replace("0x", "")
            return bytes.fromhex("00" * 12 + body)

        event_sig = Web3.to_hex(Web3.keccak(text="PaymentSent(address,address,uint256,bytes32,uint256)"))
        topic_address = Web3.to_hex(_addr_topic(checksum_address))

        base_filter: dict[str, Any] = {
            "fromBlock": from_block,
            "toBlock": "latest",
            "address": Web3.to_checksum_address(payment_contract_address),
        }

        logs_from = w3.eth.get_logs(
            {**base_filter, "topics": [event_sig, topic_address, None, None]}
        )
        logs_to = w3.eth.get_logs(
            {**base_filter, "topics": [event_sig, None, topic_address, None]}
        )

        combined: dict[tuple[str, int], dict[str, Any]] = {}
        for log_entry in logs_from + logs_to:
            txh = log_entry["transactionHash"]
            tx_hex = txh.hex() if hasattr(txh, "hex") else Web3.to_hex(txh)
            key = (tx_hex, int(log_entry["logIndex"]))
            combined[key] = log_entry

        ordered_logs = sorted(
            combined.values(),
            key=lambda item: (int(item["blockNumber"]), int(item["logIndex"])),
            reverse=True,
        )[:limit]

        return _decode_payment_logs(payment, ordered_logs)
    except WalletError:
        raise
    except (Web3Exception, ValueError, TypeError) as exc:
        raise WalletError(f"list_receipts failed: {exc}") from exc
