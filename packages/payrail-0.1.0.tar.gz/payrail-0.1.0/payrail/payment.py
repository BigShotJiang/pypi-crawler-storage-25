"""On-chain USDC payments through the AgentPayment contract."""

from __future__ import annotations

from typing import Any

from eth_account import Account
from web3 import Web3
from web3.contract import Contract
from web3.exceptions import ContractLogicError, Web3Exception

from payrail._abis import ERC20_MINIMAL_ABI
from payrail.exceptions import InsufficientBalanceError, PaymentFailedError, WalletError

_USDC_DECIMALS = 6


def _normalize_private_key(private_key: str) -> str:
    key = private_key.strip()
    if not key.startswith("0x"):
        key = "0x" + key
    return key


def _usdc_amount_to_smallest_units(amount_usdc: float) -> int:
    raw = int(round(amount_usdc * float(10**_USDC_DECIMALS)))
    if raw <= 0:
        raise PaymentFailedError("amount_usdc must be positive after conversion to token units.")
    return raw


def _task_id_to_bytes32(task_id: str) -> bytes:
    """Hash arbitrary task strings to bytes32 to match typical client usage of ``pay``."""
    return Web3.keccak(text=task_id)


def send_payment(
    from_private_key: str,
    to_address: str,
    amount_usdc: float,
    task_id: str,
    rpc_url: str,
    payment_contract_address: str,
    payment_contract_abi: list[dict[str, Any]],
) -> dict[str, Any]:
    """
    Build, sign, and broadcast a transaction calling ``AgentPayment.pay``.

    If the payer's USDC allowance for the payment contract is insufficient, an ``approve``
    transaction is automatically submitted first (max uint256), so callers never need to
    manually approve.

    Args:
        from_private_key: Hex private key of the paying wallet (``0x`` optional).
        to_address: Registered recipient agent address.
        amount_usdc: USDC amount as a float (converted to 6 decimal places).
        task_id: Off-chain task identifier; hashed with Keccak-256 to a ``bytes32`` on-chain.
        rpc_url: HTTPS JSON-RPC URL.
        payment_contract_address: Deployed ``AgentPayment`` address.
        payment_contract_abi: ABI list including ``pay``, ``usdc``, and related views.

    Returns:
        Dict with ``tx_hash``, ``from``, ``to``, ``amount``, ``task_id``, ``block``, ``status``.

    Raises:
        InsufficientBalanceError: If the payer's USDC balance is below the requested amount.
        PaymentFailedError: If the transaction reverts or confirmation fails.
        WalletError: If the RPC connection fails.
    """
    try:
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        if not w3.is_connected():
            raise WalletError(f"Could not connect to RPC endpoint: {rpc_url}")

        account = Account.from_key(_normalize_private_key(from_private_key))
        payer = Web3.to_checksum_address(account.address)
        recipient = Web3.to_checksum_address(to_address)

        payment: Contract = w3.eth.contract(
            address=Web3.to_checksum_address(payment_contract_address),
            abi=payment_contract_abi,
        )

        usdc_address: str = Web3.to_checksum_address(payment.functions.usdc().call())
        usdc = w3.eth.contract(address=usdc_address, abi=ERC20_MINIMAL_ABI)

        amount_raw = _usdc_amount_to_smallest_units(amount_usdc)
        task_bytes = _task_id_to_bytes32(task_id)

        balance: int = int(usdc.functions.balanceOf(payer).call())
        if balance < amount_raw:
            raise InsufficientBalanceError(
                f"Payer USDC balance {balance} is less than required {amount_raw} (smallest units)."
            )

        payment_contract_checksum = Web3.to_checksum_address(payment_contract_address)
        allowance: int = int(usdc.functions.allowance(payer, payment_contract_checksum).call())
        chain_id = w3.eth.chain_id

        if allowance < amount_raw:
            approve_nonce = w3.eth.get_transaction_count(payer)
            approve_tx = usdc.functions.approve(
                payment_contract_checksum,
                2**256 - 1,
            ).build_transaction(
                {
                    "from": payer,
                    "nonce": approve_nonce,
                    "chainId": chain_id,
                }
            )
            if "gas" not in approve_tx or approve_tx.get("gas") is None:
                approve_tx["gas"] = int(w3.eth.estimate_gas(approve_tx))
            if "maxFeePerGas" not in approve_tx and "gasPrice" not in approve_tx:
                approve_tx["gasPrice"] = int(w3.eth.gas_price)
            signed_approve = account.sign_transaction(approve_tx)
            raw_approve = getattr(
                signed_approve, "raw_transaction", getattr(signed_approve, "rawTransaction", None)
            )
            if raw_approve is None:
                raise PaymentFailedError("Signed approval transaction payload missing.")
            approve_hash = w3.eth.send_raw_transaction(raw_approve)
            w3.eth.wait_for_transaction_receipt(approve_hash)

        nonce = w3.eth.get_transaction_count(payer)

        built = payment.functions.pay(recipient, amount_raw, task_bytes).build_transaction(
            {
                "from": payer,
                "nonce": nonce,
                "chainId": chain_id,
            }
        )

        if "gas" not in built or built.get("gas") is None:
            built["gas"] = int(w3.eth.estimate_gas(built))

        if "maxFeePerGas" not in built and "gasPrice" not in built:
            built["gasPrice"] = int(w3.eth.gas_price)

        signed = account.sign_transaction(built)
        raw_tx = getattr(signed, "raw_transaction", getattr(signed, "rawTransaction", None))
        if raw_tx is None:
            raise PaymentFailedError("Signed transaction payload missing from signer output.")
        tx_hash = w3.eth.send_raw_transaction(raw_tx)
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

        if receipt["status"] != 1:
            raise PaymentFailedError(f"Transaction reverted or failed: {tx_hash.hex()}")

        return {
            "tx_hash": receipt["transactionHash"].hex(),
            "from": payer,
            "to": recipient,
            "amount": amount_usdc,
            "task_id": task_id,
            "block": int(receipt["blockNumber"]),
            "status": "confirmed",
        }
    except InsufficientBalanceError:
        raise
    except PaymentFailedError:
        raise
    except WalletError:
        raise
    except ContractLogicError as exc:
        raise PaymentFailedError(f"Contract reverted: {exc}") from exc
    except (Web3Exception, ValueError, TypeError) as exc:
        raise PaymentFailedError(f"Payment transaction failed: {exc}") from exc


def verify_payment(
    task_id: str,
    rpc_url: str,
    payment_contract_address: str,
    payment_contract_abi: list[dict[str, Any]],
) -> bool:
    """
    Call ``verifyPayment`` on-chain for a hashed task id.

    Args:
        task_id: Same string used when sending the payment (hashed identically).
        rpc_url: HTTPS JSON-RPC URL.
        payment_contract_address: ``AgentPayment`` address.
        payment_contract_abi: ABI containing ``verifyPayment``.

    Returns:
        True if a receipt exists for the task id.

    Raises:
        PaymentFailedError: If the contract call fails unexpectedly.
        WalletError: If the RPC connection fails.
    """
    try:
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        if not w3.is_connected():
            raise WalletError(f"Could not connect to RPC endpoint: {rpc_url}")

        payment: Contract = w3.eth.contract(
            address=Web3.to_checksum_address(payment_contract_address),
            abi=payment_contract_abi,
        )
        task_bytes = _task_id_to_bytes32(task_id)
        result = payment.functions.verifyPayment(task_bytes).call()
        return bool(result)
    except WalletError:
        raise
    except (Web3Exception, ValueError, TypeError) as exc:
        raise PaymentFailedError(f"verifyPayment call failed: {exc}") from exc
