"""PayRail public API surface."""

from payrail.client import PayRail
from payrail.exceptions import (
    AgentNotRegisteredError,
    BudgetExceededError,
    ConfigurationError,
    ContractError,
    InsufficientBalanceError,
    PayRailError,
    PaymentFailedError,
    WalletError,
)
from payrail.payment import send_payment, verify_payment
from payrail.receipt import get_receipt, list_receipts
from payrail.registry import get_agent_price, register_agent
from payrail.wallet import create_wallet, get_balance, get_eth_balance

__version__ = "0.2.0"

__all__ = [
    # Unified client
    "PayRail",
    # Exceptions
    "AgentNotRegisteredError",
    "BudgetExceededError",
    "ConfigurationError",
    "ContractError",
    "InsufficientBalanceError",
    "PayRailError",
    "PaymentFailedError",
    "WalletError",
    # Low-level SDK functions
    "create_wallet",
    "get_balance",
    "get_eth_balance",
    "send_payment",
    "verify_payment",
    "register_agent",
    "get_agent_price",
    "get_receipt",
    "list_receipts",
    "__version__",
]
