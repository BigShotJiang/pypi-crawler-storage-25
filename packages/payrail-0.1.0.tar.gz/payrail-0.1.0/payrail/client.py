"""PayRail unified client — wraps all SDK modules into a single ergonomic object."""

from __future__ import annotations

import json
import os
import uuid
from functools import wraps
from pathlib import Path
from typing import Any, Callable, Optional

import requests
from dotenv import load_dotenv
from eth_account import Account
from web3 import Web3

from payrail._abis import PAYMENT_ABI, REGISTRY_ABI
from payrail.exceptions import AgentNotRegisteredError, ConfigurationError
import payrail.payment as _payment
import payrail.receipt as _receipt
import payrail.registry as _registry
import payrail.wallet as _wallet

# ── Constants ──────────────────────────────────────────────────────────────────

_ZERO_ADDR: str = "0x" + "0" * 40
_BASESCAN_BASE: str = "https://sepolia.basescan.org/tx/0x"
_LOCAL_REGISTRY: Path = Path.home() / ".payrail" / "registry.json"
_USDC_DECIMALS: int = 6
_DEFAULT_LOOKBACK: int = 100_000

# Load project-root .env once at import time (override=False preserves existing env vars).
load_dotenv(Path(__file__).resolve().parent.parent / ".env", override=False)


class PayRail:
    """
    Unified entry point for the PayRail SDK.

    Loads configuration from environment variables (or .env) and exposes all
    wallet, registry, payment, discovery, and decorator functionality through
    a single object.

    Args:
        rpc_url: Base Sepolia JSON-RPC URL. Defaults to ``BASE_RPC_URL`` env var.
        private_key: Hex private key of the operating wallet. Defaults to ``PRIVATE_KEY``.
        usdc_address: USDC token address. Defaults to ``USDC_CONTRACT_ADDR``.
        registry_address: AgentRegistry address. Defaults to ``REGISTRY_CONTRACT_ADDR``.
        payment_address: AgentPayment address. Defaults to ``PAYMENT_CONTRACT_ADDR``.

    Raises:
        ConfigurationError: If any required env var is missing or set to the zero address.
    """

    def __init__(
        self,
        rpc_url: Optional[str] = None,
        private_key: Optional[str] = None,
        usdc_address: Optional[str] = None,
        registry_address: Optional[str] = None,
        payment_address: Optional[str] = None,
    ) -> None:
        self._rpc_url: str = rpc_url or self._require_env("BASE_RPC_URL")
        raw_key: str = private_key or self._require_env("PRIVATE_KEY")
        self._private_key: str = _normalize_private_key(raw_key)
        self._usdc_address: str = self._resolve_address(
            usdc_address, "USDC_CONTRACT_ADDR"
        )
        self._registry_address: str = self._resolve_address(
            registry_address, "REGISTRY_CONTRACT_ADDR"
        )
        self._payment_address: str = self._resolve_address(
            payment_address, "PAYMENT_CONTRACT_ADDR"
        )
        self._address: str = Web3.to_checksum_address(
            Account.from_key(self._private_key).address
        )

    # ── Internal helpers ───────────────────────────────────────────────────────

    @staticmethod
    def _require_env(name: str) -> str:
        """Read an env var and raise ConfigurationError if missing or zero address."""
        value = os.getenv(name, "").strip()
        if not value or value.lower() == _ZERO_ADDR.lower():
            raise ConfigurationError(f"Missing required environment variable: {name}")
        return value

    @staticmethod
    def _resolve_address(explicit: Optional[str], env_name: str) -> str:
        """Use a constructor override if set; otherwise read ``env_name`` from the environment."""
        if explicit is not None and explicit.strip():
            raw = explicit.strip()
            if raw.lower() == _ZERO_ADDR.lower():
                raise ConfigurationError(f"Invalid address for {env_name}")
            return raw
        return PayRail._require_env(env_name)

    @staticmethod
    def _basescan(tx_hash: str) -> str:
        return f"{_BASESCAN_BASE}{tx_hash.lstrip('0x')}"

    def _load_local_registry(self) -> list[dict[str, Any]]:
        """Read ~/.payrail/registry.json; return empty list on any error."""
        if not _LOCAL_REGISTRY.exists():
            return []
        try:
            data = json.loads(_LOCAL_REGISTRY.read_text())
            return data if isinstance(data, list) else []
        except (json.JSONDecodeError, OSError):
            return []

    def _save_local_registry(self, entries: list[dict[str, Any]]) -> None:
        """Write entries to ~/.payrail/registry.json, creating the dir as needed."""
        _LOCAL_REGISTRY.parent.mkdir(parents=True, exist_ok=True)
        _LOCAL_REGISTRY.write_text(json.dumps(entries, indent=2))

    # ── Wallet ─────────────────────────────────────────────────────────────────

    def create_wallet(self) -> dict[str, str]:
        """
        Generate a new Ethereum EOA.

        Returns:
            Dict with ``address`` and ``private_key``.
        """
        return _wallet.create_wallet()

    def get_balance(self, address: Optional[str] = None) -> float:
        """
        Return USDC balance for *address* (defaults to own wallet).

        Args:
            address: Wallet address to query. Defaults to ``self._address``.

        Returns:
            USDC balance as a float.

        Raises:
            WalletError: If the RPC call fails.
        """
        return _wallet.get_balance(
            address or self._address,
            self._rpc_url,
            self._usdc_address,
        )

    def get_eth_balance(self, address: Optional[str] = None) -> float:
        """
        Return native ETH balance for *address* (defaults to own wallet).

        Args:
            address: Wallet address to query. Defaults to ``self._address``.

        Returns:
            ETH balance as a float.

        Raises:
            WalletError: If the RPC call fails.
        """
        return _wallet.get_eth_balance(
            address or self._address,
            self._rpc_url,
        )

    # ── Registry ───────────────────────────────────────────────────────────────

    def register(self, name: str, price_per_call: float) -> dict[str, Any]:
        """
        Register own wallet as an agent in the on-chain registry.

        Args:
            name: Public agent display name.
            price_per_call: Minimum USDC price per call.

        Returns:
            Dict with ``name``, ``address``, ``price_per_call``, ``tx_hash``.

        Raises:
            ContractError: If the transaction fails or the agent is already active.
            WalletError: If the RPC connection fails.
        """
        return _registry.register_agent(
            name=name,
            price_per_call_usdc=price_per_call,
            private_key=self._private_key,
            rpc_url=self._rpc_url,
            registry_contract_address=self._registry_address,
            registry_contract_abi=REGISTRY_ABI,
        )

    # ── Payment ────────────────────────────────────────────────────────────────

    def pay(self, to: str, amount: float, task_id: str) -> dict[str, Any]:
        """
        Pay a registered agent in USDC, storing an on-chain receipt.

        Args:
            to: Recipient agent address (must be registered and active).
            amount: USDC amount to transfer.
            task_id: Unique task identifier (hashed on-chain to bytes32).

        Returns:
            Receipt dict with ``tx_hash``, ``from``, ``to``, ``amount``,
            ``task_id``, ``block``, ``status``, and ``basescan`` URL.

        Raises:
            InsufficientBalanceError: If the payer's USDC balance is insufficient.
            PaymentFailedError: If the on-chain transaction reverts or fails.
            WalletError: If the RPC connection fails.
        """
        result = _payment.send_payment(
            from_private_key=self._private_key,
            to_address=to,
            amount_usdc=amount,
            task_id=task_id,
            rpc_url=self._rpc_url,
            payment_contract_address=self._payment_address,
            payment_contract_abi=PAYMENT_ABI,
        )
        result["basescan"] = self._basescan(result["tx_hash"])
        return result

    def verify(self, task_id: str) -> bool:
        """
        Return True if a payment receipt exists on-chain for *task_id*.

        Args:
            task_id: Original task string (hashed identically to ``pay``).

        Returns:
            True if a receipt exists.

        Raises:
            PaymentFailedError: If the contract call fails.
            WalletError: If the RPC connection fails.
        """
        return _payment.verify_payment(
            task_id=task_id,
            rpc_url=self._rpc_url,
            payment_contract_address=self._payment_address,
            payment_contract_abi=PAYMENT_ABI,
        )

    def receipt(self, task_id: str) -> dict[str, Any]:
        """
        Fetch the on-chain receipt struct for *task_id*.

        Args:
            task_id: Original task string.

        Returns:
            Receipt dict with ``from``, ``to``, ``amount``, ``timestamp``, ``task_id``.

        Raises:
            ContractError: If no receipt exists for the task.
            WalletError: If the RPC connection fails.
        """
        return _receipt.get_receipt(
            task_id=task_id,
            rpc_url=self._rpc_url,
            payment_contract_address=self._payment_address,
            payment_contract_abi=PAYMENT_ABI,
        )

    def receipts(self, address: Optional[str] = None, limit: int = 20) -> list[dict[str, Any]]:
        """
        List recent ``PaymentSent`` events for *address* (defaults to own wallet).

        Args:
            address: Wallet to match as payer or payee. Defaults to ``self._address``.
            limit: Maximum number of receipts to return (newest first).

        Returns:
            List of receipt dicts.

        Raises:
            WalletError: If the RPC connection fails.
        """
        return _receipt.list_receipts(
            address=address or self._address,
            rpc_url=self._rpc_url,
            payment_contract_address=self._payment_address,
            payment_contract_abi=PAYMENT_ABI,
            limit=limit,
        )

    # ── Discovery ──────────────────────────────────────────────────────────────

    def publish(
        self,
        name: str,
        price: float,
        capability: str,
        endpoint: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Register own wallet as an agent on-chain and cache it locally for discovery.

        Stores ``capability`` and ``endpoint`` in ``~/.payrail/registry.json``
        alongside the on-chain registration data.

        Args:
            name: Agent display name.
            price: Price per call in USDC.
            capability: Free-text capability description used for discovery.
            endpoint: Optional HTTP endpoint for direct POST calls.

        Returns:
            Dict with ``name``, ``address``, ``price``, ``capability``,
            ``endpoint``, ``tx_hash``, and ``basescan``.

        Raises:
            ContractError: If on-chain registration fails.
            WalletError: If the RPC connection fails.
        """
        result = _registry.register_agent(
            name=name,
            price_per_call_usdc=price,
            private_key=self._private_key,
            rpc_url=self._rpc_url,
            registry_contract_address=self._registry_address,
            registry_contract_abi=REGISTRY_ABI,
        )

        entry: dict[str, Any] = {
            "name": name,
            "address": self._address,
            "price": price,
            "capability": capability,
            "endpoint": endpoint,
        }

        entries = self._load_local_registry()
        updated = False
        for i, existing in enumerate(entries):
            if existing.get("address", "").lower() == self._address.lower():
                entries[i] = entry
                updated = True
                break
        if not updated:
            entries.append(entry)
        self._save_local_registry(entries)

        return {
            **entry,
            "tx_hash": result["tx_hash"],
            "basescan": self._basescan(result["tx_hash"]),
        }

    def discover(
        self,
        capability: str,
        max_price: Optional[float] = None,
    ) -> list[dict[str, Any]]:
        """
        Find registered agents matching a capability keyword.

        Reads ``~/.payrail/registry.json`` for locally cached agents, then
        enriches results with ``AgentRegistered`` events from the on-chain
        registry (best-effort; network failures are silently ignored).

        Args:
            capability: Case-insensitive keyword matched against agent capability.
            max_price: Optional USDC upper bound. Agents above this price are excluded.

        Returns:
            List of matching agent dicts sorted by price ascending. Each item:
            ``{name, address, price, capability, endpoint}``.
        """
        keyword = capability.lower()
        seen: set[str] = set()
        results: list[dict[str, Any]] = []

        # 1. Local registry cache
        for entry in self._load_local_registry():
            if keyword not in entry.get("capability", "").lower():
                continue
            price = float(entry.get("price", 0))
            if max_price is not None and price > max_price:
                continue
            addr = entry.get("address", "")
            seen.add(addr.lower())
            results.append(
                {
                    "name": entry.get("name", ""),
                    "address": addr,
                    "price": price,
                    "capability": entry.get("capability", ""),
                    "endpoint": entry.get("endpoint"),
                }
            )

        # 2. On-chain AgentRegistered events (best-effort enrichment)
        try:
            w3 = Web3(Web3.HTTPProvider(self._rpc_url))
            if w3.is_connected():
                registry = w3.eth.contract(
                    address=Web3.to_checksum_address(self._registry_address),
                    abi=REGISTRY_ABI,
                )
                latest = int(w3.eth.block_number)
                from_block = max(0, latest - _DEFAULT_LOOKBACK)
                event_sig = Web3.to_hex(
                    Web3.keccak(text="AgentRegistered(address,string,uint256)")
                )
                logs = w3.eth.get_logs(
                    {
                        "fromBlock": from_block,
                        "toBlock": "latest",
                        "address": Web3.to_checksum_address(self._registry_address),
                        "topics": [event_sig],
                    }
                )
                for log in logs:
                    try:
                        processed = registry.events.AgentRegistered().process_log(log)
                        args = processed["args"]
                        addr = Web3.to_checksum_address(args["wallet"])
                        if addr.lower() in seen:
                            continue
                        # Verify still active and read current price
                        _w, on_name, price_raw, active = registry.functions.getAgent(addr).call()
                        if not active:
                            continue
                        price = float(price_raw) / float(10**_USDC_DECIMALS)
                        if max_price is not None and price > max_price:
                            continue
                        # Without local capability metadata, match against the agent name
                        if keyword not in on_name.lower():
                            continue
                        seen.add(addr.lower())
                        results.append(
                            {
                                "name": on_name,
                                "address": addr,
                                "price": price,
                                "capability": on_name,
                                "endpoint": None,
                            }
                        )
                    except Exception:  # noqa: BLE001
                        continue
        except Exception:  # noqa: BLE001
            pass  # On-chain enrichment is best-effort; local cache is the primary source

        results.sort(key=lambda a: a["price"])
        return results

    def hire(
        self,
        capability: str,
        input_data: str,
        budget: float = 1.0,
    ) -> dict[str, Any]:
        """
        Discover, pay, and invoke the cheapest agent for a capability.

        Args:
            capability: Capability keyword used to discover candidate agents.
            input_data: Input string forwarded to the agent's HTTP endpoint (if any).
            budget: Maximum USDC to spend per hire; also used as the ``max_price`` filter.

        Returns:
            Dict with ``output``, ``cost``, ``receipt``, ``agent_address``, ``basescan``.

        Raises:
            AgentNotRegisteredError: If no agent found within budget.
            PaymentFailedError: If the on-chain payment fails.
        """
        agents = self.discover(capability, max_price=budget)
        if not agents:
            raise AgentNotRegisteredError(
                f"No registered agents found for capability '{capability}'"
                f" within budget {budget} USDC."
            )

        agent = agents[0]  # cheapest within budget
        task_id = f"hire:{uuid.uuid4()}"
        receipt_data = self.pay(to=agent["address"], amount=agent["price"], task_id=task_id)

        output: str
        if agent.get("endpoint"):
            try:
                response = requests.post(
                    agent["endpoint"],
                    json={"input": input_data},
                    timeout=30,
                )
                output = response.text
            except requests.RequestException:
                output = "Payment confirmed — endpoint call failed"
        else:
            output = "Payment confirmed — no endpoint registered"

        return {
            "output": output,
            "cost": agent["price"],
            "receipt": receipt_data,
            "agent_address": agent["address"],
            "basescan": receipt_data["basescan"],
        }

    # ── Decorator ─────────────────────────────────────────────────────────────

    def payable(
        self,
        price: float,
        currency: str = "USDC",
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """
        Decorator factory that enforces a USDC payment before each function call.

        The payment is sent to ``self._address`` so the agent charges for its own
        services. ``self._address`` must be registered in the AgentRegistry.

        Args:
            price: USDC amount charged per call.
            currency: Token symbol (only ``"USDC"`` is currently supported).

        Returns:
            A decorator that wraps a function with a payment gate.

        Usage::

            rail = PayRail()

            @rail.payable(price=0.01)
            def search(query: str) -> str:
                return "results for: " + query

            result = search("x402 protocol")  # pays 0.01 USDC then runs
        """

        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            @wraps(fn)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                task_id = f"payable:{fn.__name__}:{uuid.uuid4()}"
                self.pay(to=self._address, amount=price, task_id=task_id)
                return fn(*args, **kwargs)

            return wrapper

        return decorator


# ── Module-level helper ────────────────────────────────────────────────────────


def _normalize_private_key(key: str) -> str:
    key = key.strip()
    return key if key.startswith("0x") else "0x" + key
