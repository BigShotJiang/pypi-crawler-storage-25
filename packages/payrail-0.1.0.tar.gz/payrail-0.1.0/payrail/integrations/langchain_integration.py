"""LangChain integration — PayingTool charges USDC per tool call."""

from __future__ import annotations

import uuid
from typing import Any, Callable, Optional

try:
    from langchain.tools import BaseTool
except ImportError as _exc:
    raise ImportError(
        "langchain is required for PayingTool: pip install langchain"
    ) from _exc

try:
    from pydantic import PrivateAttr
except ImportError as _exc:
    raise ImportError("pydantic is required: pip install pydantic") from _exc


class PayingTool(BaseTool):
    """
    LangChain tool wrapper that charges USDC before executing.

    Wraps any callable or acts as a standalone tool that gates on payment.
    All payment receipts are tracked internally and accessible via ``spend_summary()``.

    Args:
        name: Tool name surfaced to the LangChain agent.
        description: Tool description surfaced to the LangChain agent.
        price_usdc: USDC charged per call.
        rail: ``PayRail`` instance used to send payments.
        recipient_address: Wallet address that receives each payment.
        wrapped_func: Optional callable invoked after payment; receives ``query: str``.

    Usage::

        from payrail.integrations.langchain_integration import PayingTool
        from payrail import PayRail

        rail = PayRail()

        paying_search = PayingTool(
            name="web_search",
            description="Search the web for information",
            price_usdc=0.01,
            rail=rail,
            recipient_address="0xSEARCH_AGENT_ADDRESS",
        )
    """

    # Pydantic fields
    price_usdc: float
    rail: Any  # PayRail instance; typed Any to avoid mandatory import at module load
    recipient_address: str
    wrapped_func: Optional[Any] = None  # Optional[Callable[[str], str]]

    # Private per-instance state
    _call_count: int = PrivateAttr(default=0)
    _total_spent: float = PrivateAttr(default=0.0)
    _receipts: list[dict[str, Any]] = PrivateAttr(default_factory=list)

    class Config:
        arbitrary_types_allowed = True

    # ── BaseTool interface ─────────────────────────────────────────────────────

    def _run(self, query: str) -> str:
        """
        Charge USDC then execute the underlying tool logic.

        Args:
            query: Input string forwarded to ``wrapped_func`` (if provided).

        Returns:
            Output from ``wrapped_func``, or a payment confirmation string.

        Raises:
            PaymentFailedError: If the on-chain payment fails.
        """
        task_id = f"langchain:{uuid.uuid4()}"
        receipt = self.rail.pay(
            to=self.recipient_address,
            amount=self.price_usdc,
            task_id=task_id,
        )
        self._call_count += 1
        self._total_spent += self.price_usdc
        self._receipts.append(receipt)

        if self.wrapped_func is not None:
            return self.wrapped_func(query)
        return f"[paid {self.price_usdc} USDC] {query}"

    async def _arun(self, query: str) -> str:
        """Async variant delegates to the synchronous ``_run``."""
        return self._run(query)

    # ── Reporting ─────────────────────────────────────────────────────────────

    def spend_summary(self) -> dict[str, Any]:
        """
        Return a summary of all USDC charged by this tool.

        Returns:
            Dict with ``call_count``, ``total_spent``, ``receipts``,
            and ``basescan_links``.
        """
        return {
            "call_count": self._call_count,
            "total_spent": round(self._total_spent, 4),
            "receipts": self._receipts,
            "basescan_links": [r["basescan"] for r in self._receipts if "basescan" in r],
        }
