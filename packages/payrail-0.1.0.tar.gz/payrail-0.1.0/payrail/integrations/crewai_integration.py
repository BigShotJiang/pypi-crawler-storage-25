"""CrewAI integration — PayingAgent pays registered agents before delegating tasks."""

from __future__ import annotations

import uuid
from typing import Any, Optional

try:
    from crewai import Agent
except ImportError as _exc:
    raise ImportError(
        "crewai is required for PayingAgent: pip install payrail[crewai]"
    ) from _exc

try:
    from pydantic import PrivateAttr
except ImportError as _exc:
    raise ImportError("pydantic is required: pip install pydantic") from _exc

from payrail.exceptions import BudgetExceededError


class PayingAgent(Agent):
    """
    Drop-in CrewAI Agent that autonomously pays registered agents before delegating tasks.

    When ``execute_task`` is called, the agent inspects ``task.description`` for keywords
    matching ``pays_for``. On a match it discovers the cheapest registered provider, pays
    them on-chain via PayRail, and then proceeds with normal CrewAI execution.

    Args:
        budget_usdc: Maximum USDC this agent may spend across all ``execute_task`` calls.
        pays_for: List of capability keywords that trigger auto-payment.
        rail: ``PayRail`` instance. Created from ``.env`` if ``None``.

    Usage::

        from payrail.integrations.crewai_integration import PayingAgent
        from payrail import PayRail

        rail = PayRail()

        researcher = PayingAgent(
            role="researcher",
            goal="research topics thoroughly",
            backstory="You are an expert researcher",
            budget_usdc=1.00,
            pays_for=["search", "summarise"],
            rail=rail,
        )
    """

    # Public Pydantic fields — must be declared so Pydantic includes them in the model
    budget_usdc: float = 1.00
    pays_for: list[str] = []
    rail: Optional[Any] = None  # PayRail instance; typed Any to avoid circular import

    # Private mutable state — not serialised by Pydantic
    _spent: float = PrivateAttr(default=0.0)
    _receipts: list[dict[str, Any]] = PrivateAttr(default_factory=list)

    def model_post_init(self, __context: Any) -> None:
        """Lazily create a PayRail instance when none is provided."""
        super().model_post_init(__context)
        if self.rail is None:
            from payrail.client import PayRail

            object.__setattr__(self, "rail", PayRail())

    # ── Core override ──────────────────────────────────────────────────────────

    def execute_task(
        self,
        task: Any,
        context: Optional[str] = None,
        tools: Optional[list[Any]] = None,
    ) -> str:
        """
        Optionally pay a specialist agent, then delegate to CrewAI's normal execution.

        Args:
            task: CrewAI ``Task`` object with a ``description`` attribute.
            context: Optional context string passed through to the parent executor.
            tools: Optional tool list passed through to the parent executor.

        Returns:
            The string result from CrewAI's task executor.

        Raises:
            BudgetExceededError: If ``self._spent >= self.budget_usdc`` before paying.
        """
        description = getattr(task, "description", "") or ""
        keyword = self._matches_pays_for(description)

        if keyword:
            if self._spent >= self.budget_usdc:
                raise BudgetExceededError(
                    f"Agent budget of {self.budget_usdc} USDC exceeded."
                    f" Spent: {self._spent:.4f} USDC."
                )

            agents = self.rail.discover(keyword)
            if agents:
                agent = agents[0]  # cheapest
                remaining = self.budget_usdc - self._spent
                if agent["price"] <= remaining:
                    receipt = self.rail.pay(
                        to=agent["address"],
                        amount=agent["price"],
                        task_id=f"crewai:{uuid.uuid4()}",
                    )
                    self._spent += agent["price"]
                    self._receipts.append(receipt)
                    print(f"  Paid {agent['price']:.4f} USDC to {agent['name']}")
                    print(f"  {receipt['basescan']}")

        return super().execute_task(task, context=context, tools=tools)

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _matches_pays_for(self, text: str) -> Optional[str]:
        """
        Return the first keyword from ``pays_for`` found in *text*, or ``None``.

        Args:
            text: Task description or any string to search.

        Returns:
            Matching keyword (case-preserved from ``pays_for``), or ``None``.
        """
        lower = text.lower()
        for keyword in self.pays_for:
            if keyword.lower() in lower:
                return keyword
        return None

    def spend_summary(self) -> dict[str, Any]:
        """
        Return a summary of all USDC spent by this agent.

        Returns:
            Dict with ``total_spent``, ``budget_usdc``, ``budget_remaining``,
            ``transaction_count``, ``receipts``, and ``basescan_links``.
        """
        return {
            "total_spent": round(self._spent, 2),
            "budget_usdc": self.budget_usdc,
            "budget_remaining": round(self.budget_usdc - self._spent, 2),
            "transaction_count": len(self._receipts),
            "receipts": self._receipts,
            "basescan_links": [r["basescan"] for r in self._receipts if "basescan" in r],
        }
