# Five-minute PayRail quickstart

1. **Clone & install**

   ```bash
   git clone <repo-url> payrail && cd payrail
   python -m venv .venv && source .venv/bin/activate
   pip install -e ".[dev,crewai]"
   ```

2. **Configure environment**

   ```bash
   cp .env.example .env
   ```

   Fill at minimum:

   - `BASE_RPC_URL` — Base Sepolia HTTPS endpoint.  
   - `PRIVATE_KEY` — funded orchestrator wallet (testnet-only).  
   - `USDC_CONTRACT_ADDR` — official Base Sepolia USDC.  
   - `REGISTRY_CONTRACT_ADDR` / `PAYMENT_CONTRACT_ADDR` — after deployment.  
   - `OPENAI_API_KEY` — if running CrewAI demos.

3. **Deploy contracts**

   ```bash
   cd contracts
   forge install foundry-rs/forge-std OpenZeppelin/openzeppelin-contracts --no-commit
   forge test
   forge script script/Deploy.s.sol --rpc-url $BASE_SEPOLIA_RPC_URL --broadcast
   ```

   Copy addresses into `.env`.

4. **Fund & approve**

   - Send Base Sepolia ETH for gas.  
   - Send test USDC to the orchestrator.  
   - Call `USDC.approve(paymentContract, amount)` (or `type(uint256).max` for demos).

5. **Run the API + demo**

   ```bash
   uvicorn api.main:app --reload
   python demo/run_demo.py
   ```

6. **Verify**

   - `curl http://127.0.0.1:8000/health`  
   - After a payment, inspect the transaction on [Basescan Sepolia](https://sepolia.basescan.org).
