# PayRail architecture

PayRail separates **identity & pricing** (`AgentRegistry`) from **settlement** (`AgentPayment`).

## On-chain components

### AgentRegistry

- Each agent calls `registerAgent(name, pricePerCall)` with `msg.sender` as the agent wallet.  
- `pricePerCall` uses USDC’s six decimals (raw integer units).  
- Agents deactivate or repricing via `deactivateAgent` / `updatePrice`; the registry `owner` can `adminDeactivate` for moderation.  
- `getAgent` and `isRegistered` power SDK reads and payment validation.

### AgentPayment

- Constructed with immutable references to the registry and USDC token.  
- `pay(to, amount, taskId)` enforces registry membership, recipient activity, `amount >= pricePerCall`, and unique `taskId` keys.  
- Uses `SafeERC20.transferFrom(payer, recipient, amount)`; payers must `approve` the payment contract beforehand.  
- Successful transfers persist `Receipt` structs and emit `PaymentSent` for indexers and the Python `list_receipts` helper.

## Off-chain components

- **Python SDK** wraps `web3.py` for wallet creation, balances, registration txs, payments, and log decoding.  
- **FastAPI** exposes HTTP endpoints so agents written in any language can trigger flows with shared infrastructure.  
- **Dashboard** (static HTML/JS) polls the API for a live payment trail.

## Threat notes (hackathon scope)

- Private keys live in `.env` for demos only—use HSM/KMS or smart accounts for production.  
- Agents should pin contract addresses and RPC providers they trust.  
- USDC approvals grant allowance to `AgentPayment`; rotate keys if a host is compromised.
