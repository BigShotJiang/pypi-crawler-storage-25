"""
Common Library Version Report Application
"""

from argparse import ArgumentParser, Namespace

import mhi.common
import mhi.help


def version(_args: Namespace):
    """Display package version info"""

    print(mhi.common.version_msg())


def open_help(_args: Namespace):
    """Open the help document"""

    mhi.help.package_help(mhi.common)


def main():
    """Main: Command Line Interface"""

    parser = ArgumentParser(prog='py -m mhi.common')
    parser.set_defaults(func=version)
    subparsers = parser.add_subparsers()

    subparser = subparsers.add_parser("help",
                                      help="Open the module's help file")
    subparser.set_defaults(func=open_help,
                           help=["help", '--help'])

    args = parser.parse_args()
    args.func(args)


if __name__ == '__main__':
    main()
