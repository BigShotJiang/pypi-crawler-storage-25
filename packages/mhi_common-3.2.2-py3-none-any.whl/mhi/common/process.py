#! /usr/bin/env python3

"""
Process launching and querying
"""

#===============================================================================
# Imports
#===============================================================================

import itertools
import ipaddress
import logging
import random
import sys
from typing import Any, Dict, List, Optional, Set, Tuple

import socket

from .version import Version
from .types import AddressPortPid, AddressPortPidApp
from .warnings import warn

if sys.platform == 'win32':
    try:
        from .win32 import (_process_pids, _tcp_ports_in_use,
                            _listener_ports_by_pid, _exe_path, _launch,
                            )
    except ImportError:
        from .nowin32 import (_process_pids, _tcp_ports_in_use,
                              _listener_ports_by_pid, _exe_path, _launch,
                              )
else:
    from .nowin32 import (_process_pids, _tcp_ports_in_use,
                          _listener_ports_by_pid, _exe_path, _launch,
                          )

#===============================================================================
# Logging
#===============================================================================

_LOG = logging.getLogger(__name__)


#===============================================================================
# Find processes
#===============================================================================

def process_pids(*names: str) -> List[Tuple[str, int]]:
    """
    Return the process id's of any process with the given executable names.

    Application names may include the ``%`` wildcard.  For example,
    the following query might find both ``SkypeApp.exe`` and
    ``SkypeBackgroundHost.exe``::

        process_ids('skype%.exe')

    Since applications may terminate and can be started at any time,
    the returned value is obsolete immediately upon being returned.

    Parameters:
        *names (str): application filename patterns, without any path.

    Returns:
        List[tuple]: A list of process name & process id pairs
    """

    if len(names) == 1 and isinstance(names[0], (tuple, list)):
        names = names[0]

    return _process_pids(names)


def is_running(app_name: str) -> bool:
    """
    Determine if there is an ``app`` process in the list of running processes.

    Application names may include the ``%`` wildcard.  For example,
    the following query might find both ``SkypeApp.exe`` and
    ``SkypeBackgroundHost.exe``::

        is_running('skype%.exe')

    Since applications may terminate and can be started at any time,
    the returned value is obsolete immediately upon being returned.

    Parameters:
        app (str): application filename, without any path.

    Returns:
        bool: `True` if a process can be found, `False` otherwise.
    """

    return len(process_pids(app_name)) > 0


#===============================================================================
# Localhost IP Addresses
#===============================================================================

def host_addresses(host: str) -> Set[str]:
    """
    Convert a host name into one or more IP address (ie, IPv4 & IPv6)
    """

    return {addr[4][0] for addr in socket.getaddrinfo(host, 0)} # type: ignore


def is_local_host(host: str) -> bool:
    """
    Does the given hostname represent the local host?

    Returns True if the given 'host' is a public IP address of the host,
    a loopback address, an IPADDR_ANY-type address, or a symbolic name
    that represents any of these.
    """

    if host in {'', '::1', '127.0.0.1', '::', '0.0.0.0'}:
        return True

    addrs = host_addresses(host)
    if any(ipaddress.ip_address(addr).is_loopback for addr in addrs):
        return True

    if {'::', '0.0.0.0'} & addrs:
        return True

    localhost_addrs = host_addresses(socket.getfqdn())
    if localhost_addrs & addrs:
        return True

    return False


def host_filter(host: str):
    """
    Return a filter function to filter an iterable of ``AddressPortPid`` or
    ``AddressPortPidApp`` listeners against the given host
    """

    addrs = host_addresses(host)
    any_ipv4 = '0.0.0.0' in addrs
    any_ipv6 = '::' in addrs
    ip_versions = {ipaddress.ip_address(addr).version for addr in addrs}
    host_ipv4 = 4 in ip_versions
    host_ipv6 = 6 in ip_versions

    def filter_func(listener):
        if listener.address in addrs:
            return True
        if listener.address == '0.0.0.0' and host_ipv4:
            return True
        if listener.address == '::' and host_ipv6:
            return True

        ipaddr = ipaddress.ip_address(listener.address)
        if ipaddr.version == 4 and any_ipv4:
            return True
        if ipaddr.version == 6 and any_ipv6:
            return True

        return False

    return filter_func


#===============================================================================
# Listening Ports
#===============================================================================

def tcp_ports_in_use() -> Set[int]:
    """
    Find all TCP ports in use

    Returns:
        Set[int]: Set of all ports in use by the TCP protocol
    """

    return _tcp_ports_in_use()


def unused_tcp_port(ports: Optional[range] = None) -> int:
    """
    Find an available TCP ports in the specified range.  If no range is
    given, the dynamic/private range (0xC000--0xFFFF) is used.

    Returns:
        int: an available TCP port
    """

    if ports is None:
        ports = range(49192, 65536)

    valid_range = range(1024, 65536)
    if not ports or ports[0] not in valid_range or ports[-1] not in valid_range:
        raise ValueError("Invalid range")

    used_ports = tcp_ports_in_use()

    # Try ports sequentially
    port_iter = iter(ports)
    if len(ports) > 100:
        # Unless we have a large range, in which case try a few randomly first
        port_iter = itertools.chain(random.sample(ports, 20), port_iter)

    for port in port_iter:
        if port not in used_ports:
            return port

    raise ValueError("No unused TCP port found")


def listener_ports_by_pid(*pid: int) -> List[AddressPortPid]:
    """
    Find all listener ports opened by processes with the given PIDs.

    Since applications may terminate and can be started at any time,
    as well as open and close ports at any time,
    the returned value is obsolete immediately upon being returned.

    Parameters:
        *pid (int): Process ids

    Returns:
        List[tuple]: a list of (addr, port, pid) tuples
    """

    return _listener_ports_by_pid(*pid)


def listener_ports_by_name(*names: str) -> List[AddressPortPidApp]:

    """
    Find all listener ports opened by processes with the given executable name.

    Application names may include the ``%`` wildcard.  For example,
    the following query might find both listener ports opened by both
    ``SkypeApp.exe`` and ``SkypeBackgroundHost.exe``::

        listener_ports_by_name('skype%.exe')

    Since applications may terminate and can be started at any time,
    as well as open and close ports at any time,
    the returned value is obsolete immediately upon being returned.

    Parameters:
        *names (str): application filename patterns, without any path.

    Returns:
        List[tuple]: a list of (addr, port, pid, name) tuples
    """

    name_by_pid = {pid: name for name, pid in process_pids(*names)}

    ports = [AddressPortPidApp(addr, port, pid, name_by_pid[pid])
             for addr, port, pid in listener_ports_by_pid(*name_by_pid.keys())]

    return ports


#===============================================================================
# Launch processes
#===============================================================================

def versions(app_name: str) -> List[Tuple[str, bool]]:
    """
    Find the installed versions of an MHI application.

    Returns:
        List[Tuple]: List of tuples of version and bit-size
    """

    versions32, versions64 = _exe_path(app_name)

    versions_all = [(version, True) for version in versions64]
    for version in versions32:
        versions_all.append((version, False))

    return versions_all


def find_exe(app_name: str,     # pylint: disable=too-many-arguments,too-many-positional-arguments
             version: Optional[str] = None, x64: Optional[bool] = None,
             minimum: Optional[str] = None, maximum: Optional[str] = None,
             allow_alpha: bool = False, allow_beta: bool = False
             ) -> Optional[str]:
    """
    Find an MHI application executable.

    If no ``version`` is specified, the highest version available is used,
    with Alpha and Beta versions being considered the highest and second
    highest respectively.
    If no ``x64`` flag is given, a 32-bit or 64-bit version may be returned,
    with preference given to 64-bit versions.

    Parameters:
        app (str): name of the application (without any extension)
        version (str): application version such as '5.0.1' or '5.1 (Beta)'
        x64 (bool): ``True`` for 64-bit version, ``False`` for 32-bit version
        minimum (str): The lowest allowable version, such as '5.0'
        maximum (str): The highest allowable version, such as '5.0.9'

    Returns:
        str: the path to the executable

    .. versionadded:: 2.1
        ``minimum``, ``maximum``, ``allow_alpha`` & ``allow_beta`` parameters.
    .. versionchanged:: 2.4.5
        ``allow_alpha``, ``allow_beta`` parameters are no longer supported.
    .. versionchanged:: 3.0.3
        ``allow_beta`` parameter is once again supported.
    """

    if allow_alpha:
        warn("allow_alpha is no longer supported and will be removed",
             DeprecationWarning)

    versions32, versions64 = _exe_path(app_name)


    # Select the 32 or 64 bit dictionaries, or merge the two dictionaries
    if x64 is not None:
        all_versions = versions64 if x64 else versions32
    else:
        all_versions = dict(versions32, **versions64)

    # If an explicit version is given, select it.
    if version is not None:
        return all_versions.get(version, None)

    # Filter out any non-standard versions (Alpha, Free, ...)
    filtered = {Version(ver): exe_path for ver, exe_path in all_versions.items()
                if Version.valid(ver)}

    # Filter out beta versions, if not allowed
    if not allow_beta:
        filtered = {ver: exe_path for ver, exe_path in filtered.items()
                    if not ver.beta}

    # Filter any versions outside minimum/maximum limits
    if minimum:
        limit = Version(minimum)
        filtered = {ver: exe_path for ver, exe_path in filtered.items()
                    if ver >= limit}

    if maximum:
        limit = Version(maximum)
        filtered = {ver: exe_path for ver, exe_path in filtered.items()
                    if ver <= limit}

    # Select the highest surviving version
    best_version = max(filtered, default=None)

    if best_version is None:
        return None

    return filtered[best_version]


def launch(*args: str, options: Optional[Dict[str, Any]] = None, **kwargs):

    """
    Launch an application process.

    All ``{keyword}`` format codes in the list of ``args`` strings are
    replaced by the value in the corresponding ``options`` dictionary and/or
    ``kwargs`` key-value argument pairs.

    For example::

        launch("C:\\{dir}\\{name}.exe", "/silent:{silent}", "/title:{title!r}",
               dir="temp", name="app", silent=True, title="Hello world")

    will launch ``C:\\temp\\app.exe`` passing the arguments ``/silent:True``
    and ``/title:'Hello world'``


    Parameters:
        *args (str): the application and the arguments for the application
        options: values which may be substituted in the application arguments
        **kwargs: additional substitution values

    Returns:
        The subprocess handle

    .. table:: Special keyword arguments

        =================== ============================================
        Keyword=Value              Effect
        =================== ============================================
        ``minimize=True``   process started with ``SW_SHOWMINNOACTIVE``
        ``minimize=False``  process started with ``SW_SHOWNOACTIVATE``
        ``debug=True``             process is not started, command line printed
        =================== ============================================
    """

    if not args:
        raise ValueError("An application must be specified")

    if len(args) == 1 and isinstance(args[0], (tuple, list)):
        args = args[0]

    options = dict(options, **kwargs) if options else kwargs
    launch_args = [arg.format(**options) for arg in args]

    if options.get('debug', False):
        print("Awaiting manual launch in debugger", file=sys.stderr)
        print("    args:", " ".join(launch_args[1:]), file=sys.stderr)
        proc = None
    else:
        proc = _launch(launch_args, options)

    return proc

#===============================================================================
# Process Report
#===============================================================================

def report(installed=True, minimums=False, running=True, file=sys.stdout):
    """
    Report known, installed MHI products
    """

    fmt = "    {0:<8} = {1}"

    # Show executables for known apps, but it is ok if they aren't installed.
    if installed:
        print("Installed executables", file=file)
        try:
            for app in ('PSCAD', 'Enerplot'):
                exe = find_exe(app)
                print(fmt.format(app, exe), file=file)
        except NotImplementedError:
            print("    (Not yet implemented)", file=file)
        print(file=file)

        # Installed executables w/ enforced minimums
        if minimums:
            try:
                print("Installed executables (minimum versions)", file=file)
                for app, minimum in {'PSCAD': '5.0', 'Enerplot': '1.1'}.items():
                    exe = find_exe(app, minimum=minimum)
                    print(fmt.format(app, exe), file=file)
            except NotImplementedError:
                print("    (Not yet implemented)", file=file)
            print(file=file)

    if running:
        print("Running", file=file)
        fmt = "    {0:<39} {1:<5} {2:<5} {3}"
        print(fmt.format("Address", "Port", "PID", "Executable"), file=file)
        try:
            for app_name in ('PSCAD%', 'Enerplot%'):
                for data in listener_ports_by_name(app_name):
                    print(fmt.format(*data), file=file)
        except NotImplementedError:
            print("    (Not yet implemented)", file=file)
        print(file=file)


#===============================================================================
# CLI Utility
#===============================================================================

if __name__ == '__main__':
    report()
