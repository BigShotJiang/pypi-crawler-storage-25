"""
Linux-specific functionality

- Registry reading
- Process lookup
- TCP/IP Port availability
"""

import sys

from pathlib import Path
from typing import Any, Dict, List, Set, Sequence, Tuple

from .types import AddressPortPid

def _not_implemented(func_name: str) -> NotImplementedError:
    if sys.platform == 'win32':
        reason = f'{func_name} not supported from internal scripting'
    else:
        reason = f'{func_name} not supported on {sys.platform}'
    return NotImplementedError(reason)

def _process_pids(names: Sequence[str]) -> List[Tuple[str, int]]:
    raise _not_implemented('mhi.common.process.process_ids')

def _tcp_ports_in_use() -> Set[int]:
    raise _not_implemented('mhi.common.process.tcp_ports_in_use')

def _listener_ports_by_pid(*_pid: int) -> List[AddressPortPid]:
    raise _not_implemented('mhi.common.process.listener_ports_by_pid')

def _exe_path(app_name: str) -> Tuple[Dict[str, str], Dict[str, str]]:
    raise _not_implemented('mhi.common.process.exe_path')

def _launch(args: Sequence[str], options: Dict[str, Any]):
    raise _not_implemented('mhi.common.process.launch')

def _shell_folder(name: str) -> Path:
    raise _not_implemented('mhi.common.path.shell_folder')
