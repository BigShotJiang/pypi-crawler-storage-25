"""
mhi.common.process types
"""

from typing import NamedTuple

class AddressPortPid(NamedTuple):
    """
    Tuple of Address, Port, and PID
    """

    address: str
    port: int
    pid: int

class AddressPortPidApp(NamedTuple):
    """
    Tuple of Address, Port, PID, and AppName
    """

    address: str
    port: int
    pid: int
    appname: str
