#! /usr/bin/env python3
"""
Conversion between pathnames with and without expanded %ENVIRONMENT_VARIABLES%.
"""

import os
import re
import sys
from typing import Dict, List, Optional, Sequence, Type, Union

from pathlib import Path, PurePath

if sys.platform == 'win32':
    try:
        from .win32 import _shell_folder
    except ImportError:
        from .nowin32 import _shell_folder
else:
    from .nowin32 import _shell_folder


#===============================================================================
# When run from IDLE, if the HOME environment is not set, Tkinter is setting it
# to %HOMEDRIVE%%HOMEPATH% ... which can be wrong under Windows.
#    https://bugs.python.org/issue27263
# Attempt to detect and restore to correct default
#===============================================================================

if os.name == 'nt':
    if 'idlelib' in sys.modules:
        if os.getenv('HOME') == os.getenv('HOMEDRIVE', '') + os.getenv('HOMEPATH', ''):
            try:
                os.environ['HOME'] = os.getenv('USERPROFILE', '')
            except KeyError:
                del os.environ['HOME']


#===============================================================================
# Expand Path
#===============================================================================

def expand_path(path: Union[str, PurePath], abspath: bool = False,
                folder: Optional[Union[str, PurePath]] = None) -> str:
    """
    Expand ``path``, by replacing a `~` or `~user` prefix, as well as
    expanding any `$var`, `${var}` and `%var%` patterns in the path.

    Parameters:
        path (str): The path to be expanded.
        abspath (bool): If `True`, convert resulting path to an absolute path.
        folder (str): If provided, the path to the filename is resolved
            relative to this folder.

    Returns:
        str: The expanded ``path``, optionally forced to an absolute path.
    """

    path_type: Type[Union[Path, PurePath]] = Path
    if isinstance(folder, PurePath):
        path_type = type(folder)
        if isinstance(path, PurePath):
            # If WindowsPath & PureWindowsPath or PosixPath & PurePosixPath,
            # use the more specific (ie, non-pure) type.
            path_type2 = type(path)
            if issubclass(path_type2, path_type):
                path_type = path_type2
            elif not issubclass(path_type, path_type2):
                raise ValueError("path and folder are incompatible Path types")
    elif isinstance(path, PurePath):
        path_type = type(path)

    if folder:
        path = path_type(folder, path)
    else:
        path = path_type(path)

    filepath = path.as_posix()
    if sys.platform != 'win32':
        filepath = re.sub(r'%(\w+)%', r'${\1}', filepath)

    path = path_type(os.path.expanduser(os.path.expandvars(filepath)))
    if abspath and hasattr(path, 'resolve'):
        path = path.resolve()

    return str(path)

def expand_paths(paths: Sequence[Union[str, PurePath]], abspath: bool = False,
                 folder: Optional[Union[str, PurePath]] = None) -> List[str]:
    """
    Expand ``paths``, by replacing a `~` or `~user` prefix, as well as
    expanding any `$var`, `${var}` and `%var%` patterns in the paths.

    Parameters:
        path (List[str]): A list of paths to be expanded.
        abspath (bool): If `True`, convert resulting paths to absolute paths.
        folder (str): If provided, the paths to the filenames are resolved
            relative to this folder.

    Returns:
        List[str]: A list of expanded ``paths``, optionally forced to
        absolute paths.
    """

    return [expand_path(path, abspath, folder) for path in paths]


#===============================================================================
# Contract Path
#===============================================================================

def contract_path(path: str, *,             # pylint: disable=too-many-branches
                  keys: Optional[List[str]] = None,
                  reverse_map: Optional[Dict[str, str]] = None) -> str:
    """contract_path(path)

    Look for and replace any substring of the path that matches a value
    found in an environment variable with that environment variable:
    `${key}` or `%key%`.  Additionally, replace a path starting with
    the user's home path with `~`.

    Parameters:
        path (str): The path to be shortened by replacing parts with
           environment variables.

    Returns:
        str: The contracted ``path``.
    """

    keys = keys or []
    reverse_map = reverse_map or {}

    if len(keys) == 0:
        for key, val in os.environ.items():
            if os.name == 'nt':
                if ';' in val:
                    continue
                key = f"%{key}%"
            else:
                if ':' in val:
                    continue
                key = f"${{{key}}}"

            val = val.replace('\\', '/') # Work with posix path separators
            if len(key) < len(val) or key in {'%HOME%', '${HOME}'}:
                if val not in reverse_map  or  len(key) < len(reverse_map[val]):
                    reverse_map[val] = key

        keys.extend(sorted(reverse_map.keys(), key=len, reverse=True))

    # Work with posix path separators
    path = str(path).replace('\\', '/')

    for text in keys:
        path = path.replace(text, reverse_map[text])

    if path in {"${HOME}", "%HOME%", "${USERPROFILE}", "%USERPROFILE%"}:
        path = "~"
    elif path.startswith("%HOME%/"):
        path = os.path.join("~", path[7:])
    elif path.startswith("${HOME}/"):
        path = os.path.join("~", path[8:])
    elif path.startswith("%USERPROFILE%/"):
        path = os.path.join("~", path[14:])
    elif path.startswith("${USERPROFILE}/"):
        path = os.path.join("~", path[15:])

    # On windows, use %VAR% instead of ${VAR}
    if sys.platform == 'win32':
        path = re.sub(r'\${(\w+)}', r'%\1%', path)

    # Restore path separators to system default
    return os.path.normpath(path)

def contract_paths(paths):
    """
    Look for and replace any substring of the paths that matches a value
    found in an environment variable with that environment variable:
    `${key}` or `%key%`.  Additionally, replace paths starting with
    the user's home path with `~`.

    Parameters:
        paths (List[str]): The paths to be shortened by replacing parts with
           environment variables.

    Returns:
        List[str]: A list of contracted ``paths``.
    """

    return [contract_path(path) for path in paths]


#===============================================================================
# Shell Folders
#===============================================================================

def shell_folder(name: str) -> Path:
    """
    Return the path to a special folder

    Parameters:
        name (str): The folder name

    Returns:
        Path: The path to the named folder
    """

    return _shell_folder(name)
