git checkout doc man
