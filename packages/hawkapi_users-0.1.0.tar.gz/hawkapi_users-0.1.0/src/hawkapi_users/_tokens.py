"""Short-lived email-verify + password-reset tokens.

Reuses ``hawkapi_auth.TokenIssuer`` for signing — same JWT secret, same
algorithm, same revocation story. The ``type`` claim is ``email_verify``
or ``password_reset`` and is enforced at verify time so a verification
token cannot be replayed as a reset.

The ``pv`` (password version) claim binds the token to the user's current
password hash. Bumping ``password_version`` after a successful reset
invalidates every outstanding token for that user in one DB write.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from hawkapi_auth import JWTConfig, TokenError, TokenIssuer

VERIFY_TYPE = "email_verify"
RESET_TYPE = "password_reset"


@dataclass(slots=True)
class UserTokenConfig:
    secret: str
    algorithm: str = "HS256"
    verify_ttl_seconds: int = 60 * 60  # 1 hour
    reset_ttl_seconds: int = 60 * 60  # 1 hour
    issuer: str | None = None
    audience: str | None = None


class UserTokens:
    """Mint + verify email + reset tokens, scoped to a single secret."""

    def __init__(self, config: UserTokenConfig) -> None:
        if not config.secret or len(config.secret) < 32:
            raise ValueError(
                "UserTokenConfig.secret must be at least 32 characters (RFC 7518 §3.2)"
            )
        self.config = config
        self._verify = TokenIssuer(
            config=JWTConfig(
                secret=config.secret,
                algorithm=config.algorithm,
                access_ttl_seconds=config.verify_ttl_seconds,
                refresh_ttl_seconds=config.verify_ttl_seconds,
                issuer=config.issuer,
                audience=config.audience,
                access_type=VERIFY_TYPE,
                refresh_type=VERIFY_TYPE,
            )
        )
        self._reset = TokenIssuer(
            config=JWTConfig(
                secret=config.secret,
                algorithm=config.algorithm,
                access_ttl_seconds=config.reset_ttl_seconds,
                refresh_ttl_seconds=config.reset_ttl_seconds,
                issuer=config.issuer,
                audience=config.audience,
                access_type=RESET_TYPE,
                refresh_type=RESET_TYPE,
            )
        )

    def issue_verify(self, user_id: str, *, password_version: int = 0) -> str:
        return self._verify.issue_access(user_id, pv=password_version)

    def issue_reset(self, user_id: str, *, password_version: int = 0) -> str:
        return self._reset.issue_access(user_id, pv=password_version)

    def peek_email_token_sub(self, token: str) -> str:
        """Verify signature + type + expiry but NOT ``pv``. Returns ``sub``.

        Callers MUST then call :meth:`verify_email_token` with the user's
        actual ``password_version`` after the DB lookup. The two-step pattern
        exists so a user whose ``password_version`` has been bumped (e.g. by a
        completed password reset) can still verify a freshly-issued token.
        """
        claims = self._verify.verify_access(token)
        _check_type(claims, VERIFY_TYPE)
        sub = claims.get("sub")
        if not isinstance(sub, str) or not sub:
            raise TokenError("token missing sub")
        return sub

    def peek_reset_token_sub(self, token: str) -> str:
        """Same as :meth:`peek_email_token_sub` but for reset tokens."""
        claims = self._reset.verify_access(token)
        _check_type(claims, RESET_TYPE)
        sub = claims.get("sub")
        if not isinstance(sub, str) or not sub:
            raise TokenError("token missing sub")
        return sub

    def verify_email_token(self, token: str, *, expected_password_version: int = 0) -> str:
        """Return ``user_id`` on success; raise :class:`TokenError` otherwise."""
        claims = self._verify.verify_access(token)
        _check_type(claims, VERIFY_TYPE)
        _check_pv(claims, expected_password_version)
        sub = claims.get("sub")
        if not isinstance(sub, str) or not sub:
            raise TokenError("token missing sub")
        return sub

    def verify_reset_token(self, token: str, *, expected_password_version: int = 0) -> str:
        claims = self._reset.verify_access(token)
        _check_type(claims, RESET_TYPE)
        _check_pv(claims, expected_password_version)
        sub = claims.get("sub")
        if not isinstance(sub, str) or not sub:
            raise TokenError("token missing sub")
        return sub


def _check_type(claims: dict[str, Any], expected: str) -> None:
    if claims.get("type") != expected:
        raise TokenError(f"expected {expected!r} token")


def _check_pv(claims: dict[str, Any], expected: int) -> None:
    got = claims.get("pv", 0)
    if not isinstance(got, int) or got != expected:
        raise TokenError("token password_version mismatch")


__all__ = ["RESET_TYPE", "VERIFY_TYPE", "TokenError", "UserTokenConfig", "UserTokens"]
