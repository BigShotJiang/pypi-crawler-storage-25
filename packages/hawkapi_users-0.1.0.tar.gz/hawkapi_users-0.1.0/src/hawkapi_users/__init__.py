"""hawkapi-users — full user lifecycle for HawkAPI.

Sits on top of:
- hawkapi-auth: password hashing (argon2id), JWT issuer reused for verify/reset tokens
- hawkapi-sqlalchemy: declarative ``SQLAlchemyBaseUserTable`` + session DI
- hawkapi-mail: templated verification + reset emails

Mounted routes (default ``/users`` prefix):
- POST /register
- POST /login
- POST /verify/request
- POST /verify/{token}
- POST /password-reset/request
- POST /password-reset/{token}
"""

from __future__ import annotations

from ._emails import (
    default_renderer,
    send_password_reset_email,
    send_verification_email,
)
from ._manager import (
    InactiveUser,
    InvalidCredentials,
    UserAlreadyExists,
    UserManager,
)
from ._models import SQLAlchemyBaseUserTable, normalize_email
from ._plugin import get_user_manager, init_users, resolve_user_manager
from ._tokens import (
    RESET_TYPE,
    VERIFY_TYPE,
    TokenError,
    UserTokenConfig,
    UserTokens,
)

__version__ = "0.1.0"

__all__ = [
    "InactiveUser",
    "InvalidCredentials",
    "RESET_TYPE",
    "SQLAlchemyBaseUserTable",
    "TokenError",
    "UserAlreadyExists",
    "UserManager",
    "UserTokenConfig",
    "UserTokens",
    "VERIFY_TYPE",
    "__version__",
    "default_renderer",
    "get_user_manager",
    "init_users",
    "normalize_email",
    "resolve_user_manager",
    "send_password_reset_email",
    "send_verification_email",
]
