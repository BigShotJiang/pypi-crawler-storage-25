"""HTTP routes — register / login / verify / reset / me."""

from __future__ import annotations

import json
from typing import Any

from hawkapi import HTTPException, Request
from hawkapi.responses import JSONResponse
from hawkapi_auth import TokenError
from hawkapi_sqlalchemy import resolve_database

from ._manager import (
    InactiveUser,
    InvalidCredentials,
    UserAlreadyExists,
    UserManager,
)


async def _session_factory(request: Request) -> Any:
    db = resolve_database(request.scope.get("app"))
    if db is None:
        raise HTTPException(
            500, detail="Database not configured — call init_database(app, ...) first"
        )
    return db.session


async def _read_json(request: Request) -> dict[str, Any]:
    try:
        body = await request.body()
    except Exception as exc:
        raise HTTPException(400, detail=f"could not read body: {exc}") from exc
    if not body:
        return {}
    try:
        parsed = json.loads(body)
    except ValueError as exc:
        raise HTTPException(400, detail=f"invalid JSON: {exc}") from exc
    if not isinstance(parsed, dict):
        raise HTTPException(400, detail="expected JSON object")
    return parsed


def _public_user(user: Any) -> dict[str, Any]:
    """The user record we are willing to return over HTTP."""
    return {
        "id": user.id,
        "email": user.email,
        "is_active": user.is_active,
        "is_verified": user.is_verified,
        "is_superuser": user.is_superuser,
    }


def attach_routes(app: Any, manager: UserManager, *, prefix: str = "/users") -> None:
    prefix = prefix.rstrip("/") or "/users"

    async def _register(request: Request) -> Any:
        body = await _read_json(request)
        email = body.get("email")
        password = body.get("password")
        if not isinstance(email, str) or not isinstance(password, str):
            raise HTTPException(400, detail="email and password are required")
        if len(password) < 8:
            raise HTTPException(400, detail="password too short (min 8 chars)")
        sessions = await _session_factory(request)
        async with sessions() as sess:
            try:
                user = await manager.create(sess, email=email, password=password)
            except UserAlreadyExists as exc:
                raise HTTPException(409, detail="email already registered") from exc
        return JSONResponse(_public_user(user), status_code=201)

    async def _login(request: Request) -> Any:
        body = await _read_json(request)
        email = body.get("email")
        password = body.get("password")
        if not isinstance(email, str) or not isinstance(password, str):
            raise HTTPException(400, detail="email and password are required")
        sessions = await _session_factory(request)
        async with sessions() as sess:
            try:
                user = await manager.authenticate(sess, email=email, password=password)
            except InactiveUser as exc:
                raise HTTPException(403, detail="account disabled") from exc
            except InvalidCredentials as exc:
                raise HTTPException(401, detail="invalid credentials") from exc
        return JSONResponse(_public_user(user))

    async def _request_verify(request: Request) -> Any:
        body = await _read_json(request)
        email = body.get("email")
        if not isinstance(email, str):
            raise HTTPException(400, detail="email is required")
        sessions = await _session_factory(request)
        async with sessions() as sess:
            await manager.request_verify(sess, email=email)
        # Always 202 — do not leak account existence.
        return JSONResponse({"status": "ok"}, status_code=202)

    async def _verify(request: Request) -> Any:
        token = str(request.path_params.get("token", ""))
        if not token:
            raise HTTPException(400, detail="missing token")
        sessions = await _session_factory(request)
        async with sessions() as sess:
            try:
                user = await manager.verify(sess, token=token)
            except TokenError:
                raise HTTPException(400, detail="invalid or expired verification token") from None
            except InvalidCredentials:
                raise HTTPException(404, detail="user not found") from None
        return JSONResponse(_public_user(user))

    async def _request_reset(request: Request) -> Any:
        body = await _read_json(request)
        email = body.get("email")
        if not isinstance(email, str):
            raise HTTPException(400, detail="email is required")
        sessions = await _session_factory(request)
        async with sessions() as sess:
            await manager.request_password_reset(sess, email=email)
        return JSONResponse({"status": "ok"}, status_code=202)

    async def _reset(request: Request) -> Any:
        token = str(request.path_params.get("token", ""))
        body = await _read_json(request)
        new_password = body.get("password")
        if not token:
            raise HTTPException(400, detail="missing token")
        if not isinstance(new_password, str):
            raise HTTPException(400, detail="password is required")
        if len(new_password) < 8:
            raise HTTPException(400, detail="password too short (min 8 chars)")
        sessions = await _session_factory(request)
        async with sessions() as sess:
            try:
                user = await manager.reset_password(sess, token=token, new_password=new_password)
            except TokenError:
                raise HTTPException(400, detail="invalid or expired reset token") from None
            except InvalidCredentials:
                raise HTTPException(404, detail="user not found") from None
        return JSONResponse(_public_user(user))

    app.post(f"{prefix}/register")(_register)
    app.post(f"{prefix}/login")(_login)
    app.post(f"{prefix}/verify/request")(_request_verify)
    app.post(f"{prefix}/verify/{{token}}")(_verify)
    app.post(f"{prefix}/password-reset/request")(_request_reset)
    app.post(f"{prefix}/password-reset/{{token}}")(_reset)


__all__ = ["attach_routes"]
