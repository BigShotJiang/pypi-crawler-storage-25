"""UserManager — orchestrates the full lifecycle."""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from hawkapi_auth import hash_password, needs_rehash, verify_password
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ._models import SQLAlchemyBaseUserTable, normalize_email
from ._tokens import UserTokens

logger = logging.getLogger("hawkapi_users")

# A pre-computed dummy hash used to equalize timing when no user is found.
# Cost matches the production hash so authentication failures take the same
# wall-clock time as successful lookups (CWE-208).
_DUMMY_HASH = hash_password("__dummy_hash_for_timing_equalization__")


class UserAlreadyExists(ValueError):
    """Raised when register tries to use an email that already exists."""


class InvalidCredentials(ValueError):
    """Raised by ``authenticate()`` on bad email/password."""


class InactiveUser(ValueError):
    """Raised when a disabled account tries to authenticate."""


@dataclass
class UserManager:
    """High-level user operations bound to one model + token issuer."""

    model: type[SQLAlchemyBaseUserTable]
    tokens: UserTokens
    on_after_register: Callable[[Any], Awaitable[None]] | None = None
    on_after_login: Callable[[Any], Awaitable[None]] | None = None
    on_after_forgot_password: Callable[[Any, str], Awaitable[None]] | None = None
    on_after_request_verify: Callable[[Any, str], Awaitable[None]] | None = None
    on_after_verify: Callable[[Any], Awaitable[None]] | None = None
    on_after_reset_password: Callable[[Any], Awaitable[None]] | None = None
    _post_register_hooks: list[Callable[[Any], Awaitable[None]]] = field(default_factory=list)

    async def get_by_email(self, session: AsyncSession, email: str) -> Any | None:
        result = await session.execute(
            select(self.model).where(self.model.email == normalize_email(email))
        )
        return result.scalar_one_or_none()

    async def get_by_id(self, session: AsyncSession, user_id: str) -> Any | None:
        return await session.get(self.model, user_id)

    async def create(
        self,
        session: AsyncSession,
        *,
        email: str,
        password: str,
        is_active: bool = True,
        is_verified: bool = False,
        is_superuser: bool = False,
        **extra: Any,
    ) -> Any:
        """Create a new user. Raises :class:`UserAlreadyExists` on duplicate email."""
        normalized = normalize_email(email)
        existing = await self.get_by_email(session, normalized)
        if existing is not None:
            raise UserAlreadyExists(normalized)
        user = self.model(
            email=normalized,
            hashed_password=hash_password(password),
            is_active=is_active,
            is_verified=is_verified,
            is_superuser=is_superuser,
            password_version=0,
            **extra,
        )
        session.add(user)
        await session.flush()
        if self.on_after_register is not None:
            await self.on_after_register(user)
        return user

    async def authenticate(
        self,
        session: AsyncSession,
        *,
        email: str,
        password: str,
    ) -> Any:
        """Verify credentials. Raises :class:`InvalidCredentials` / :class:`InactiveUser`."""
        user = await self.get_by_email(session, email)
        if user is None:
            # Equalize timing: always run verify, even with a dummy hash.
            verify_password(password, _DUMMY_HASH)
            raise InvalidCredentials("invalid credentials")
        if not verify_password(password, user.hashed_password):
            raise InvalidCredentials("invalid credentials")
        if not user.is_active:
            raise InactiveUser("user is not active")
        if needs_rehash(user.hashed_password):
            user.hashed_password = hash_password(password)
            await session.flush()
        if self.on_after_login is not None:
            await self.on_after_login(user)
        return user

    async def request_verify(self, session: AsyncSession, *, email: str) -> None:
        """Mint a verification token + invoke ``on_after_request_verify``.

        Always returns ``None`` and never reveals whether the email exists
        (CWE-204 — account enumeration). The hook is invoked only if the user
        exists; the caller must always reply 202 regardless.
        """
        user = await self.get_by_email(session, email)
        if user is None:
            return
        token = self.tokens.issue_verify(user.id, password_version=user.password_version)
        if self.on_after_request_verify is not None:
            await self.on_after_request_verify(user, token)

    async def verify(self, session: AsyncSession, *, token: str) -> Any:
        """Apply a verification token, marking the user verified."""
        # peek_* extracts ``sub`` after signature+type+expiry but does NOT enforce ``pv``.
        # The pv check happens after we load the user with the correct expected value —
        # otherwise users whose ``password_version`` was bumped by a completed reset
        # would never be able to verify (CWE-287).
        user_id = self.tokens.peek_email_token_sub(token)
        user = await self.get_by_id(session, user_id)
        if user is None:
            raise InvalidCredentials("user not found")
        self.tokens.verify_email_token(token, expected_password_version=user.password_version)
        if not user.is_verified:
            user.is_verified = True
            await session.flush()
        if self.on_after_verify is not None:
            await self.on_after_verify(user)
        return user

    async def request_password_reset(self, session: AsyncSession, *, email: str) -> None:
        """Mint a reset token + invoke ``on_after_forgot_password``.

        Always returns ``None``; never reveals whether the email exists.
        """
        user = await self.get_by_email(session, email)
        if user is None:
            return
        token = self.tokens.issue_reset(user.id, password_version=user.password_version)
        if self.on_after_forgot_password is not None:
            await self.on_after_forgot_password(user, token)

    async def reset_password(
        self,
        session: AsyncSession,
        *,
        token: str,
        new_password: str,
    ) -> Any:
        """Consume a reset token + update the password.

        Bumps ``password_version`` to invalidate every other outstanding token
        for this user (verify + any other reset tokens minted earlier).
        """
        user_id = self.tokens.peek_reset_token_sub(token)
        user = await self.get_by_id(session, user_id)
        if user is None:
            raise InvalidCredentials("user not found")
        # Strict pv check now that we know the user's current password_version
        # (catches replay of a token issued before a prior reset bumped pv).
        self.tokens.verify_reset_token(token, expected_password_version=user.password_version)
        user.hashed_password = hash_password(new_password)
        user.password_version = (user.password_version or 0) + 1
        await session.flush()
        if self.on_after_reset_password is not None:
            await self.on_after_reset_password(user)
        return user

    async def update(
        self,
        session: AsyncSession,
        user: Any,
        *,
        email: str | None = None,
        password: str | None = None,
        is_active: bool | None = None,
        is_verified: bool | None = None,
        is_superuser: bool | None = None,
    ) -> Any:
        if email is not None:
            user.email = normalize_email(email)
            # Email change invalidates verification.
            user.is_verified = False
        if password is not None:
            user.hashed_password = hash_password(password)
            user.password_version = (user.password_version or 0) + 1
        if is_active is not None:
            user.is_active = is_active
        if is_verified is not None:
            user.is_verified = is_verified
        if is_superuser is not None:
            user.is_superuser = is_superuser
        await session.flush()
        return user

    async def delete(self, session: AsyncSession, user: Any) -> None:
        await session.delete(user)
        await session.flush()


__all__ = [
    "InactiveUser",
    "InvalidCredentials",
    "UserAlreadyExists",
    "UserManager",
]
