"""init_users(app, ...) + DI + WeakKeyDictionary registry."""

from __future__ import annotations

from typing import Any
from weakref import WeakKeyDictionary

from hawkapi import HTTPException, Request

from ._manager import UserManager


class _StateNamespace:
    users: Any


_ACTIVE: WeakKeyDictionary[Any, UserManager] = WeakKeyDictionary()
_LAST: list[UserManager | None] = [None]


def init_users(
    app: Any,
    *,
    manager: UserManager,
    mount_routes: bool = True,
    url_prefix: str = "/users",
) -> UserManager:
    """Attach a :class:`UserManager` to ``app.state.users`` and mount HTTP routes."""
    if getattr(app, "state", None) is None:
        app.state = _StateNamespace()
    app.state.users = manager
    try:
        _ACTIVE[app] = manager
    except TypeError:
        pass
    _LAST[0] = manager
    if mount_routes:
        from ._routes import attach_routes

        attach_routes(app, manager, prefix=url_prefix)
    return manager


def resolve_user_manager(app: Any) -> UserManager | None:
    if app is None:
        return _LAST[0]
    try:
        found = _ACTIVE.get(app)
    except TypeError:
        found = None
    if found is not None:
        return found
    state = getattr(app, "state", None)
    if state is not None and hasattr(state, "users"):
        return state.users  # type: ignore[no-any-return]
    return _LAST[0]


def get_user_manager(request: Request) -> UserManager:
    mgr = resolve_user_manager(request.scope.get("app"))
    if mgr is None:
        raise HTTPException(500, detail="UserManager not configured — call init_users(app, ...)")
    return mgr


__all__ = ["get_user_manager", "init_users", "resolve_user_manager"]
