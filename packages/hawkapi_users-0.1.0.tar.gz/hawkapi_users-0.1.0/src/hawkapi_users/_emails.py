"""Email helpers — verify + reset templated via hawkapi-mail."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from hawkapi_mail import EmailMessage, Mailer, TemplateRenderer

_TEMPLATES_DIR = Path(__file__).parent / "templates"


def default_renderer() -> TemplateRenderer:
    return TemplateRenderer(directory=_TEMPLATES_DIR)


async def send_verification_email(
    mailer: Mailer,
    *,
    to: str,
    token: str,
    verify_url_template: str = "https://example.com/verify/{token}",
    sender: str = "",
    subject: str = "Confirm your email",
    template: str = "verify.html",
    text_template: str = "verify.txt",
    renderer: TemplateRenderer | None = None,
    context: dict[str, Any] | None = None,
) -> None:
    ctx = dict(context or {})
    ctx.setdefault("verify_url", verify_url_template.replace("{token}", token))
    renderer = renderer or default_renderer()
    html = await renderer.render_async(template, **ctx)
    text = await renderer.render_async(text_template, **ctx)
    msg = EmailMessage.build(
        subject=subject,
        sender=sender or mailer.default_sender,
        to=to,
        text=text,
        html=html,
    )
    await mailer.send(msg)


async def send_password_reset_email(
    mailer: Mailer,
    *,
    to: str,
    token: str,
    reset_url_template: str = "https://example.com/password-reset/{token}",
    sender: str = "",
    subject: str = "Reset your password",
    template: str = "password_reset.html",
    text_template: str = "password_reset.txt",
    renderer: TemplateRenderer | None = None,
    context: dict[str, Any] | None = None,
) -> None:
    ctx = dict(context or {})
    ctx.setdefault("reset_url", reset_url_template.replace("{token}", token))
    renderer = renderer or default_renderer()
    html = await renderer.render_async(template, **ctx)
    text = await renderer.render_async(text_template, **ctx)
    msg = EmailMessage.build(
        subject=subject,
        sender=sender or mailer.default_sender,
        to=to,
        text=text,
        html=html,
    )
    await mailer.send(msg)


__all__ = ["default_renderer", "send_password_reset_email", "send_verification_email"]
