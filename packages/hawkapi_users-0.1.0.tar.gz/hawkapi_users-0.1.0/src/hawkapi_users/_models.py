"""SQLAlchemy user table mixin."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from hawkapi_sqlalchemy import Base
from sqlalchemy import Boolean, DateTime, String, func
from sqlalchemy.orm import Mapped, mapped_column


class SQLAlchemyBaseUserTable(Base):
    """Abstract user table — subclass and set ``__tablename__``.

    Standard fields: ``id`` (UUID4 string), ``email`` (unique, case-insensitive
    via lower-cased storage), ``hashed_password``, ``is_active`` /
    ``is_verified`` / ``is_superuser``, ``created_at`` / ``updated_at``.
    """

    __abstract__ = True

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    email: Mapped[str] = mapped_column(String(320), unique=True, nullable=False, index=True)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    is_verified: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_superuser: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    password_version: Mapped[int] = mapped_column(default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        server_default=func.current_timestamp(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        server_default=func.current_timestamp(),
        onupdate=lambda: datetime.now(UTC),
        nullable=False,
    )


def normalize_email(email: str) -> str:
    """Lower-case + strip; the only canonicalization we apply to emails."""
    return email.strip().lower()


__all__ = ["SQLAlchemyBaseUserTable", "normalize_email"]
