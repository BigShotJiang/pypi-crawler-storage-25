"""Token type enforcement + password_version binding."""

from __future__ import annotations

import pytest

from hawkapi_users import TokenError, UserTokenConfig, UserTokens

SECRET = "x" * 64


def test_verify_token_roundtrip() -> None:
    t = UserTokens(UserTokenConfig(secret=SECRET))
    token = t.issue_verify("u-1", password_version=3)
    assert t.verify_email_token(token, expected_password_version=3) == "u-1"


def test_reset_token_roundtrip() -> None:
    t = UserTokens(UserTokenConfig(secret=SECRET))
    token = t.issue_reset("u-1", password_version=5)
    assert t.verify_reset_token(token, expected_password_version=5) == "u-1"


def test_verify_token_not_accepted_as_reset() -> None:
    t = UserTokens(UserTokenConfig(secret=SECRET))
    token = t.issue_verify("u-1")
    with pytest.raises(TokenError):
        t.verify_reset_token(token)


def test_reset_token_not_accepted_as_verify() -> None:
    t = UserTokens(UserTokenConfig(secret=SECRET))
    token = t.issue_reset("u-1")
    with pytest.raises(TokenError):
        t.verify_email_token(token)


def test_password_version_mismatch_rejected() -> None:
    t = UserTokens(UserTokenConfig(secret=SECRET))
    token = t.issue_reset("u-1", password_version=2)
    with pytest.raises(TokenError, match="password_version"):
        t.verify_reset_token(token, expected_password_version=3)


def test_short_secret_rejected() -> None:
    with pytest.raises(ValueError, match="32 characters"):
        UserTokens(UserTokenConfig(secret="too-short"))
