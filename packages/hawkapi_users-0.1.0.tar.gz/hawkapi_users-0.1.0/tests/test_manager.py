"""UserManager — full lifecycle."""

from __future__ import annotations

import pytest
from hawkapi_sqlalchemy import resolve_database

from hawkapi_users import (
    InactiveUser,
    InvalidCredentials,
    TokenError,
    UserAlreadyExists,
    UserManager,
)


async def _open(app):
    db = resolve_database(app)
    assert db is not None
    return db.session


async def test_create_and_get(app, manager: UserManager) -> None:
    sessions = await _open(app)
    async with sessions() as sess:
        user = await manager.create(sess, email="A@b.C", password="hunter2-very-secure")
        assert user.email == "a@b.c"  # normalized
        assert user.is_verified is False
        assert user.password_version == 0


async def test_create_duplicate_email_raises(app, manager: UserManager) -> None:
    sessions = await _open(app)
    async with sessions() as sess:
        await manager.create(sess, email="x@y.z", password="hunter2-very-secure")
    async with sessions() as sess:
        with pytest.raises(UserAlreadyExists):
            await manager.create(sess, email="X@Y.Z", password="other-passwords-here")


async def test_authenticate_happy_path(app, manager: UserManager) -> None:
    sessions = await _open(app)
    async with sessions() as sess:
        await manager.create(sess, email="a@b.c", password="hunter2-very-secure")
    async with sessions() as sess:
        user = await manager.authenticate(sess, email="a@b.c", password="hunter2-very-secure")
        assert user.email == "a@b.c"


async def test_authenticate_bad_password_raises(app, manager: UserManager) -> None:
    sessions = await _open(app)
    async with sessions() as sess:
        await manager.create(sess, email="a@b.c", password="hunter2-very-secure")
    async with sessions() as sess:
        with pytest.raises(InvalidCredentials):
            await manager.authenticate(sess, email="a@b.c", password="wrong")


async def test_authenticate_nonexistent_email_raises_same_error(app, manager: UserManager) -> None:
    sessions = await _open(app)
    async with sessions() as sess:
        with pytest.raises(InvalidCredentials):
            await manager.authenticate(sess, email="ghost@x.y", password="anything")


async def test_authenticate_inactive_user_raises(app, manager: UserManager) -> None:
    sessions = await _open(app)
    async with sessions() as sess:
        user = await manager.create(sess, email="a@b.c", password="hunter2-very-secure")
        user.is_active = False
        await sess.flush()
    async with sessions() as sess:
        with pytest.raises(InactiveUser):
            await manager.authenticate(sess, email="a@b.c", password="hunter2-very-secure")


async def test_verify_marks_user_verified(app, manager: UserManager) -> None:
    sessions = await _open(app)
    captured: list[str] = []

    async def on_request(user, token):
        captured.append(token)

    manager.on_after_request_verify = on_request

    async with sessions() as sess:
        await manager.create(sess, email="a@b.c", password="hunter2-very-secure")
    async with sessions() as sess:
        await manager.request_verify(sess, email="a@b.c")
    assert len(captured) == 1
    async with sessions() as sess:
        user = await manager.verify(sess, token=captured[0])
        assert user.is_verified is True


async def test_request_verify_for_unknown_email_does_not_emit(app, manager: UserManager) -> None:
    captured: list[str] = []

    async def on_request(user, token):
        captured.append(token)

    manager.on_after_request_verify = on_request
    sessions = await _open(app)
    async with sessions() as sess:
        await manager.request_verify(sess, email="ghost@x.y")
    assert captured == []  # no enumeration leak


async def test_request_reset_for_unknown_email_does_not_emit(app, manager: UserManager) -> None:
    captured: list[str] = []

    async def on_request(user, token):
        captured.append(token)

    manager.on_after_forgot_password = on_request
    sessions = await _open(app)
    async with sessions() as sess:
        await manager.request_password_reset(sess, email="ghost@x.y")
    assert captured == []


async def test_reset_password_bumps_version_and_invalidates_token(
    app, manager: UserManager
) -> None:
    sessions = await _open(app)
    captured: list[str] = []

    async def on_reset(user, token):
        captured.append(token)

    manager.on_after_forgot_password = on_reset

    async with sessions() as sess:
        await manager.create(sess, email="a@b.c", password="hunter2-very-secure")
    async with sessions() as sess:
        await manager.request_password_reset(sess, email="a@b.c")
    token = captured[0]

    async with sessions() as sess:
        await manager.reset_password(sess, token=token, new_password="brand-new-strong-pw")

    # Replay the same token — password_version was bumped, should fail.
    async with sessions() as sess:
        with pytest.raises(TokenError, match="password_version"):
            await manager.reset_password(sess, token=token, new_password="another-strong-pw")


async def test_verify_works_after_password_reset_bumped_pv(
    app, manager: UserManager
) -> None:
    """Regression: user whose password_version is bumped by a reset must still
    be able to verify a freshly-issued verification token. The double-decode
    bug caused the first decode to enforce pv=0 unconditionally, rejecting any
    user with pv>0 (CWE-287).
    """
    sessions = await _open(app)
    reset_tokens: list[str] = []
    verify_tokens: list[str] = []

    async def on_reset(user, token):
        reset_tokens.append(token)

    async def on_verify_request(user, token):
        verify_tokens.append(token)

    manager.on_after_forgot_password = on_reset
    manager.on_after_request_verify = on_verify_request

    async with sessions() as sess:
        await manager.create(sess, email="a@b.c", password="hunter2-very-secure")
    async with sessions() as sess:
        await manager.request_password_reset(sess, email="a@b.c")
    async with sessions() as sess:
        await manager.reset_password(
            sess, token=reset_tokens[0], new_password="brand-new-strong-pw"
        )
    # Now password_version is 1. Request + apply a fresh verify token.
    async with sessions() as sess:
        await manager.request_verify(sess, email="a@b.c")
    assert len(verify_tokens) == 1
    async with sessions() as sess:
        user = await manager.verify(sess, token=verify_tokens[0])
        assert user.is_verified is True


async def test_consecutive_password_resets_work(app, manager: UserManager) -> None:
    """Regression: a user must be able to reset their password twice in a row."""
    sessions = await _open(app)
    captured: list[str] = []

    async def on_reset(user, token):
        captured.append(token)

    manager.on_after_forgot_password = on_reset

    async with sessions() as sess:
        await manager.create(sess, email="x@y.z", password="hunter2-very-secure")
    # First reset (pv: 0 -> 1).
    async with sessions() as sess:
        await manager.request_password_reset(sess, email="x@y.z")
    async with sessions() as sess:
        await manager.reset_password(
            sess, token=captured[-1], new_password="brand-new-strong-pw"
        )
    # Second reset (pv: 1 -> 2) — must succeed.
    async with sessions() as sess:
        await manager.request_password_reset(sess, email="x@y.z")
    async with sessions() as sess:
        await manager.reset_password(
            sess, token=captured[-1], new_password="yet-another-strong-pw"
        )


async def test_update_email_unverifies(app, manager: UserManager) -> None:
    sessions = await _open(app)
    async with sessions() as sess:
        user = await manager.create(sess, email="a@b.c", password="hunter2-very-secure")
        user.is_verified = True
        await sess.flush()
        await manager.update(sess, user, email="new@b.c")
        assert user.email == "new@b.c"
        assert user.is_verified is False
