"""HTTP routes — register / login / verify / reset."""

from __future__ import annotations

from hawkapi.testing import TestClient

from hawkapi_users import UserManager


def _post_json(client: TestClient, path: str, payload: bytes) -> object:
    return client.post(
        path,
        body=payload,
        headers={"Content-Type": "application/json"},
    )


def test_register_returns_201_and_public_user(app, manager: UserManager) -> None:
    client = TestClient(app)
    r = _post_json(
        client,
        "/users/register",
        b'{"email": "a@b.c", "password": "hunter2-very-secure"}',
    )
    assert r.status_code == 201
    body = r.json()
    assert body["email"] == "a@b.c"
    assert "hashed_password" not in body
    assert "password_version" not in body


def test_register_duplicate_returns_409(app, manager: UserManager) -> None:
    client = TestClient(app)
    _post_json(
        client,
        "/users/register",
        b'{"email": "a@b.c", "password": "hunter2-very-secure"}',
    )
    r = _post_json(
        client,
        "/users/register",
        b'{"email": "a@b.c", "password": "another-strong-password"}',
    )
    assert r.status_code == 409


def test_register_short_password_returns_400(app) -> None:
    client = TestClient(app)
    r = _post_json(client, "/users/register", b'{"email": "a@b.c", "password": "short"}')
    assert r.status_code == 400


def test_login_returns_200_for_valid_credentials(app, manager: UserManager) -> None:
    client = TestClient(app)
    _post_json(
        client,
        "/users/register",
        b'{"email": "a@b.c", "password": "hunter2-very-secure"}',
    )
    r = _post_json(
        client,
        "/users/login",
        b'{"email": "a@b.c", "password": "hunter2-very-secure"}',
    )
    assert r.status_code == 200


def test_login_returns_401_for_bad_password(app, manager: UserManager) -> None:
    client = TestClient(app)
    _post_json(
        client,
        "/users/register",
        b'{"email": "a@b.c", "password": "hunter2-very-secure"}',
    )
    r = _post_json(client, "/users/login", b'{"email": "a@b.c", "password": "wrong"}')
    assert r.status_code == 401


def test_login_returns_401_for_unknown_email(app) -> None:
    client = TestClient(app)
    r = _post_json(client, "/users/login", b'{"email": "ghost@x.y", "password": "anything"}')
    assert r.status_code == 401


def test_verify_request_always_returns_202_no_enumeration(app, manager: UserManager) -> None:
    client = TestClient(app)
    r = _post_json(client, "/users/verify/request", b'{"email": "ghost@x.y"}')
    assert r.status_code == 202


def test_password_reset_request_always_returns_202(app, manager: UserManager) -> None:
    client = TestClient(app)
    r = _post_json(client, "/users/password-reset/request", b'{"email": "ghost@x.y"}')
    assert r.status_code == 202


def test_invalid_verify_token_returns_400(app) -> None:
    client = TestClient(app)
    r = _post_json(client, "/users/verify/not-a-real-token", b"{}")
    assert r.status_code == 400


def test_full_verify_flow(app, manager: UserManager) -> None:
    captured: list[str] = []

    async def hook(user, token):
        captured.append(token)

    manager.on_after_request_verify = hook

    client = TestClient(app)
    _post_json(
        client,
        "/users/register",
        b'{"email": "x@y.z", "password": "strong-password!"}',
    )
    _post_json(client, "/users/verify/request", b'{"email": "x@y.z"}')
    assert len(captured) == 1
    r = _post_json(client, f"/users/verify/{captured[0]}", b"{}")
    assert r.status_code == 200
    assert r.json()["is_verified"] is True
