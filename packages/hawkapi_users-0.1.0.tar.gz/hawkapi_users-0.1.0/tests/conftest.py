"""Shared fixtures — in-memory DB + Mailer + UserManager."""

from __future__ import annotations

import asyncio
from typing import Any

import pytest
from hawkapi import HawkAPI
from hawkapi_mail import InMemoryBackend, Mailer, init_mail
from hawkapi_sqlalchemy import Base, init_database

from hawkapi_users import (
    SQLAlchemyBaseUserTable,
    UserManager,
    UserTokenConfig,
    UserTokens,
    init_users,
)


class User(SQLAlchemyBaseUserTable):
    __tablename__ = "users_test"


STATE_SECRET = "a" * 32  # tests only


def _make_tokens() -> UserTokens:
    return UserTokens(UserTokenConfig(secret=STATE_SECRET))


@pytest.fixture
def app() -> HawkAPI:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    db = init_database(app, url="sqlite+aiosqlite:///:memory:")
    init_mail(app, backend=InMemoryBackend(), default_sender="noreply@example.com")
    tokens = _make_tokens()
    manager = UserManager(model=User, tokens=tokens)
    init_users(app, manager=manager)

    async def _create_schema() -> None:
        engine = db.get("primary").engine
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    asyncio.get_event_loop_policy().new_event_loop().run_until_complete(_create_schema())
    return app


@pytest.fixture
def manager(app: HawkAPI) -> UserManager:
    return app.state.users  # type: ignore[no-any-return]


@pytest.fixture
def mailer(app: HawkAPI) -> Mailer:
    return app.state.mail  # type: ignore[no-any-return]


_ = Any
