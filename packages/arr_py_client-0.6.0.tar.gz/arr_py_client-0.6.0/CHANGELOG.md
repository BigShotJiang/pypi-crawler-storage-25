# Changelog

All notable changes to this project are documented here. This project adheres to
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [0.6.0] — 2026-04-21

**Prowlarr support.** Full typed client + curated indexer/applications/tags
facades, Prowlarr MCP tools, config_sync coverage for Prowlarr's
applications surface, and a live-verified end-to-end workflow.

### Added — Prowlarr

- `ProwlarrClient` / `AsyncProwlarrClient` — sync + async client for the
  Prowlarr v1 API. Pinned to upstream `v2.3.5.5327`. Auto-generated from
  the vendored OpenAPI spec, with three curated facades: `indexers`,
  `applications`, `tags`. Env vars: `PROWLARR_BASE_URL`,
  `PROWLARR_API_KEY`.
- `ProwlarrSettings` (pydantic-settings) built via the shared factory.
- `arr_py_client.testing.make_fake_prowlarr()` — respx-backed in-memory
  client mirroring the Radarr/Sonarr fakes pattern.
- **8 new MCP tools**: `prowlarr_ping`, `prowlarr_system_status`,
  `prowlarr_indexers_list`, `prowlarr_indexer_test_all`,
  `prowlarr_apps_list`, `prowlarr_app_test_all`, `prowlarr_history_list`,
  `prowlarr_logs_list`. All carry uniform `_meta.action_hints` per the
  Phase A policy.
- `arr_health` extended with a new `app="all"` mode that additionally
  reports Prowlarr's indexer + application counts.
- `arr-py-mcp` CLI: `--prowlarr-only` and `--with-prowlarr` flags.
  Default behavior auto-enables Prowlarr when `PROWLARR_BASE_URL` is set.
- Config sync: new `applications` resource (Prowlarr-only), plus silent
  skip of resources that don't apply to Prowlarr (`custom_formats`,
  `quality_profiles`, `root_folders`, `naming`) so a single desired-state
  file can target any brand. Example config extended with a `prowlarr:
  applications:` block.
- Webhook event type: `OnHealthRestored` — paired follow-up to
  `OnHealthIssue`, emitted by Radarr, Sonarr, and Prowlarr.
- Integration test suite: `lscr.io/linuxserver/prowlarr` compose service +
  `prowlarr_container` / `prowlarr_client` fixtures + three smoke tests
  under `tests/integration/prowlarr/`.
- CI: `schema-drift` workflow gained a `prowlarr` job watching upstream
  releases.

### Added — codegen parameterization

- `generate.py` / `gen_resources.py` / `resource.py.j2` now parameterize
  on `api_version` throughout (previously hardcoded to `v3`) so future
  brands or major-version bumps don't need template surgery.
- `render_models()` post-processes the datamodel-codegen output to strip
  per-class `extra='forbid'` declarations. Upstream specs routinely omit
  fields the live server returns (e.g. Prowlarr's `ApplicationResource.enable`);
  the stripped output defers to `ArrBaseModel`'s `extra="ignore"` policy.

### Added — docs

- [docs/product/prowlarr-architecture.md](docs/product/prowlarr-architecture.md)
  — memo mapping which `_common/` modules apply to Prowlarr and which
  don't.
- README gains Prowlarr across feature list, install, quickstart, and
  the comparison table (now four columns: arr-py-client, pyarr,
  Recyclarr, with separate rows for Prowlarr coverage and
  Lidarr/Readarr).

### Changed

- `build_server` and `make_clients` gained a `prowlarr=` parameter. The
  validation that at least one client is provided now accepts Prowlarr
  too.
- `justfile` `drift` recipe now takes an explicit `api_version` arg
  (``just drift prowlarr 1 v2.3.5.5327``) so it works for any brand.

## [0.5.0] — 2026-04-21

Feature + polish release. Phase A (cleanliness) + Phase B (feature
refinement) of the v0.4 PM review landed: coverage gate enforced, MCP
action-hints uniform, named janitor bundles, backfill `.estimate()`,
release-explain `.advice()`, config_sync YAML loader + expanded resource
coverage, webhook receiver helpers, and a truthful README. CLI scope is
now formally frozen.

### Added — feature refinement

- `arr_py_client.POLICIES` — named queue-janitor policy bundles:
  `POLICIES.conservative` (report-only), `.default` (current behavior),
  `.aggressive` (+size cap), `.ratio_preserving` (REMOVE_NO_BLOCKLIST to
  protect private-tracker ratio).
- `arr_py_client._common.backfill.estimate(...)` + `BackfillEstimate`
  dataclass — "128 items in 7 batches; ~3m 00s, done ~15:42:10" for
  planned runs. Wired into `arr_backfill` MCP response as
  `_meta.estimate`.
- `ReleaseExplanation.advice()` — translates rejection-reason rollups
  into plain-English next steps (raise this CF, allow that quality,
  `arr_add(...)` for unknown movies, etc.). Surfaced in
  `arr_explain_grab` MCP response as `advice`.
- `arr_py_client.config_sync.load(path)` + `DesiredState` pydantic
  schema — loads YAML (PyYAML via `[config]` extra) / JSON / TOML config
  files into the desired-state dict consumed by `plan()`. Name-keyed
  resources pivot from list form (YAML-ergonomic) to `{name: body}` form
  (planner-ready) automatically. Unknown top-level keys raise early.
- Config sync resource coverage: **root_folders** (keyed by path),
  **download_clients**, **indexers**, **notifications**,
  **naming** (singleton). All planner actions are dry-run-safe and
  per-change errors are captured in the report.
- `arr_py_client.webhooks.wsgi_app(handler)` — zero-dep WSGI receiver.
- `arr_py_client.webhooks.fastapi_router(handler)` — FastAPI
  `APIRouter` (requires `[webhooks]` extra). Both accept sync or async
  handlers; handler exceptions surface as 500s without killing the
  process.
- MCP `arr_janitor_run` gains `bundle=` kwarg
  (`default|conservative|aggressive|ratio_preserving`).

### Added — cleanliness / policy

- Coverage gate: pytest run via coverage now fails under 80%
  ([pyproject.toml](pyproject.toml) `fail_under = 80`, CI step no longer
  advisory-only).
- `_meta.action_hints` now enforced on every data-returning MCP tool via
  [tests/unit/test_mcp_action_hints_coverage.py](tests/unit/test_mcp_action_hints_coverage.py);
  reference tools (ping / delete / restore /
  `arr_describe_fields` / `arr_list_resources`) are explicitly excluded.
- Docs restructured: `docs/superpowers/` archived to `docs/archive/`;
  new [docs/architecture.md](docs/architecture.md) (current state +
  `Any`-audit policy) and [docs/roadmap.md](docs/roadmap.md) (now / next
  / later / won't).
- `docs/examples/config-sync/config.example.yaml` — canonical desired-state
  example covering every supported resource.

### Changed

- README rewritten to reflect v0.4 capstone features (MCP, workflows,
  webhooks, CLI freeze). Comparison table gained a Recyclarr column.
- CLI scope documented as frozen: status + basic add only. Workflow
  features (config-sync, release-explain, queue janitor, backfill)
  intentionally live in Python/MCP — CLI help text reflects this.
- README coverage badge corrected from 91% → 82% (matches reality).

### Fixed

- `config_sync._dump()` now handles bare dicts so planners can consume
  responses from the transport directly (needed for the `naming`
  singleton).

## [0.4.0] — 2026-04-21

Feature release — full Tier 1 + Tier 3 sweep plus MCP coverage for the new
capabilities. Radarr/Sonarr now have config sync, release explanation,
policy-based queue cleanup, and rate-limited backfill as first-class
workflows reachable from both Python and LLMs.

### Added — MCP composed tools for the new workflows

- `arr_sync_plan(app, desired, strict)` — preview config reconcile.
- `arr_sync_apply(app, desired, strict, dry_run)` — plan + apply. Defaults
  to `dry_run=True` for chat safety; per-change errors captured in report.
- `arr_explain_grab(title, app, episode_id?, season_number?)` — title →
  library id → annotated release table + `summary()` line.
- `arr_janitor_run(app, dry_run, protected_trackers)` — default policy bundle
  (manual-interaction ignore, import-blocked / stalled-6h / stuck →
  blocklist+research). Private-tracker indexers are downgraded to IGNORE.
- `arr_backfill(app, source, batch_size?, delay_between_batches, max_items,
  pause_if_queue_over, monitored_only, dry_run)` — Huntarr-shaped rate-
  limited missing-content search. `batch_size=None` picks brand-appropriate
  defaults (5 movies / 20 episodes).

### Added — new workflows (Tier 1 capstone set)

- `arr_py_client.config_sync` — brand-neutral Recyclarr/Profilarr-shaped
  declarative reconciler. `plan(client, desired)` diffs a desired-state dict
  against the live server and returns a `SyncPlan`; `apply(client, plan)` /
  `apply(..., dry_run=True)` execute (or preview) it. First cut covers
  `tags`, `custom_formats`, and `quality_profiles`; strict mode adds DELETE
  actions for items present on the server but missing from the config.
  Errors are captured per-change, so one broken item doesn't abort the run.
- `client.releases.explain(...)` (both brands) — "why didn't it grab the
  better version?" Fetches candidates + current-file state, scores and
  sorts them, and returns a `ReleaseExplanation` with accepted/rejected
  verdicts, rejection-reason rollups, and a `summary()` line suitable for
  CLI/MCP output. Accepted-first ranking uses CF score → quality weight →
  size ascending.
- `client.queue.janitor(...)` (both brands) — policy-based queue cleanup.
  Pluggable `JanitorPolicy` protocol (`StuckPolicy`, `StalledPolicy`,
  `ImportBlockedPolicy`, `ManualInteractionPolicy`, `SizeOverPolicy`,
  `StatusMessagesContainPolicy`). First-match-wins; `protected_trackers=`
  downgrades blocklist actions to IGNORE on private indexers so ratio
  isn't burned. `dry_run=True` by default.
- `client.library.backfill(...)` (both brands) — Huntarr-shaped safe
  missing-content search loop. Walks `/wanted/missing` (or `/cutoff`, or
  both), batches IDs, and posts `MoviesSearch` / `EpisodeSearch` with a
  delay between batches. Optional `pause_if_queue_over=N` short-circuits
  when the download queue is already saturated. `dry_run=True` returns
  the plan without calling the search command.

### Added — new resource facades (Tier 3 fill-ins)

- `client.parse.title("…")` (both brands) — programmatic access to the
  server's release-name parser. Useful for tests, debuggers, and MCP.
- `client.auto_tagging` (both brands) — CRUD + `schema()` over
  `/autotagging`. Auto-tagging is the "rule-based routing" surface
  (genre → tag, quality profile → tag, etc.) that custom formats don't cover.
- `client.delay_profiles` (both brands) — CRUD + `reorder(id=, after=)`
  over `/delayprofile` (the profile-order editor).
- `client.release_profiles` (both brands) — CRUD over `/releaseprofile`
  (must-contain / ignored / preferred-term scoring; complementary to CFs).
- `client.manual_import` (both brands, curated) — `candidates(...)` +
  `execute(items=, import_mode=)` for the full list → validate → execute
  manual-import workflow. The auto-generated `create()` posted an empty
  body and is superseded by `execute()`.
- `client.rename` (both brands) — `candidates(...)` previews + `execute(...)`
  fires `RenameMovie`/`RenameSeries` (or scoped `RenameFiles` with
  `movie_id=..+files=[...]` / `series_id=..+files=[...]`).

### Added — new webhook event types

- `OnMovieAdded`, `OnMovieDelete`, `OnMovieFileDelete`, `OnEpisodeFileDelete`,
  `OnManualInteractionRequired` — five permissive pydantic models to match
  the v0.3.x webhook catalog. `OnManualInteractionRequired` pairs with the
  new queue-janitor policy.

## [0.3.0] — 2026-04-21

Feature release — 22 planned items from the product-thinking plan, all landed
in one pass. Two waves: the minimum-viable set (v0.2.x → first wave) and this
broader sweep. 401 tests passing, clean basedpyright, clean ruff.

### Added — new resources

- `client.wanted` (both brands) — `missing()` / `iter_missing()` /
  `cutoff_unmet()` / `iter_cutoff_unmet()` paginated iterators over
  `/wanted/missing` and `/wanted/cutoff`.
- `client.library` (both brands) — `health_summary()` fans out to system
  status, health warnings, disk space, queue, and library count in one call
  (async uses `anyio.create_task_group` for parallelism). Also `.diff(tmdb_ids=)`
  / `.diff(tvdb_ids=)` and `.ical_url()`.
- `client.releases` (both brands) — `search()` / `grab()` / `best()` for
  manual indexer search + pick-the-best workflows.
- `client.import_lists` (both brands) — CRUD + `schema()` + `test()` + (Radarr
  only) `fetched_items()` over `/api/v3/importlist`.

### Added — new public modules

- `arr_py_client.testing` — `make_fake_radarr()` / `make_fake_sonarr()`
  context managers returning real clients backed by a preloaded respx router,
  plus `@replay("fixture.json")` decorator for record-on-miss / replay-on-hit
  tests.
- `arr_py_client.webhooks` — typed pydantic event models for Radarr/Sonarr
  webhook POSTs (`OnGrab`, `OnDownload`, `OnUpgrade`, `OnHealthIssue`,
  `OnApplicationUpdate`, `OnTest`, `UnknownEvent`) + `parse_event(payload)`.
- `arr_py_client.cli` + new `arr-py` console script — zero-dep argparse CLI
  with `health`, `config`, `radarr movies list|add`, `sonarr series list`,
  `queue stuck`. Supports `--format table|json|tsv`.

### Added — new public helpers

- `client.movies.iter_all()` / `.page(page=, size=)` / `.filter(tag=, monitored=,
  has_file=, year=, quality_profile=)` — same API on `client.series`.
- `client.movies.tag(ids=, add=[...], remove=[...], create_missing=True)` —
  bulk add/remove tags by name via the editor endpoint; same on `.series`.
- `client.queue.stuck()` / `.nuke_and_redownload(dry_run=)` / `.clear_stuck()` —
  identify warning/error/stalled queue items and optionally bulk-remove +
  blocklist + re-search.
- `client.commands.series_search` / `episode_search` / `movies_search` /
  `refresh_movie` / `rss_sync` / `backup` / `missing_*_search` /
  `cutoff_unmet_*_search` — typed wrappers with `KnownCommand` enums per brand.
- Name-based `.add()` for movies + series: accepts `title=` (uses top lookup
  match), `quality=` (name or id), `root_folder=` (path, auto-picks when sole
  configured), `tags=[...]` (labels with auto-create), `if_exists="skip"|"update"|"error"`.

### Added — new errors

- `ArrResolveError` — raised by resolvers on name/id miss, carries
  `valid_options` for actionable feedback.
- `ArrAlreadyExistsError` — raised by `.add(if_exists="error")` on duplicates.

### Added — MCP composed tools

- `arr_add` — title-based add that auto-dispatches between brands.
- `arr_health` — aggregate dashboard across both apps, with `_meta.action_hints`.
- `arr_cleanup_queue` — default `dry_run=True` for chat safety.
- `arr_upcoming` — ±N days calendar window across apps.
- `arr_find_release` — title → library → indexer search, returns sorted candidates.
- `arr_grab_release` — execute a specific release grab.
- `action_hints` pattern: every data-returning composed tool returns
  `_meta.action_hints` with likely next tool calls. Also added hints to
  `radarr_movies_get`, `sonarr_series_get`, `radarr_queue_list`,
  `sonarr_queue_list`.

### Changed

- Shared `_common/queue.py::is_stuck` helper consumed by both brand queues and
  both brand `library.health_summary()` calls (deduped three copies).
- Shared `_common/resolvers.py` (name→id helpers) consumed by both `.add()`
  implementations and both `.tag()` / `.filter()` implementations.

## [0.2.1] — 2026-04-20

### Changed
- Internal refactor: the two brand clients (Sonarr, Radarr) now share
  construction logic via `_common/client_base.py`. `__init__` bodies went
  from ~50 lines of per-brand assignment boilerplate to a
  `build_sync/async_transport` call plus two `wire_resources` calls.
- Transport sync + async retry loops share a single `_retry_delay` helper,
  deduplicating backoff / `Retry-After` handling.
- Settings factory: `RadarrSettings` / `SonarrSettings` are produced by a
  shared `_make_settings_cls(name, prefix)` and both subclass a new public
  `ArrSettings` base — public usage unchanged.
- `align_offset_to_page` moved from `mcp.server` (private `_page_args`) into
  `_common.pagination` as a public helper alongside `iter_pages` /
  `aiter_pages`.
- MCP paged tools deduplicated via a shared `_run_paged()` awaitable wrapper
  and a `_release_body()` model-build helper.
- Four duplicated `_paging()` test helpers consolidated into
  `tests/unit/_helpers.py`.

### Added
- `arr_py_client.mcp.make_clients` now re-exported from the public `mcp`
  module (previously only reachable via `arr_py_client.mcp.server`).
- 14 new unit tests covering the new shared helpers (`client_base`,
  `_retry_delay`, settings factory, pagination alignment, MCP public API).

## [0.2.0] — 2026-04-20

### Added
- `client.movies.add(tmdb_id=...)` and `client.series.add(tvdb_id=...)`: one-call
  lookup → create convenience wrappers (sync + async).
- `client.movies.delete_many` / `update_many` and `client.series.delete_many` /
  `update_many` via the `movie/editor` and `series/editor` bulk endpoints.
- New MCP tools (both apps): `blocklist_list`, `blocklist_delete`, `log_list`,
  `backup_list`, `backup_restore`, `manual_import_list`, `rename_list`,
  `release_push`, `download_clients_list`.
- `docs.yml` workflow: builds with mkdocs and auto-deploys to GitHub Pages on
  push to `main`.
- `CONTRIBUTING.md` with setup, common recipes, and release process.
- Coverage badge in `README.md`.

### Changed
- **MCP cursor pagination (breaking).** Replaced `radarr_queue_iter` /
  `sonarr_queue_iter` (which walked every page) with `radarr_queue_list` /
  `sonarr_queue_list` taking `limit` + `offset` and returning `_meta.total` and
  `_meta.next_offset`. `radarr_history_list` / new `sonarr_history_list` use
  the same shape. Offsets are aligned to the underlying page boundary.
- Async test coverage raised from 80% → 92% (257 tests).
- Sdist/wheel slimming: wheel no longer ships the `_common/codegen` tooling
  (~600K of OpenAPI specs); sdist still includes them for source consumers.
  Test fixtures excluded from sdist.

## [0.1.0] — 2026-04-20

### Added
- Initial release.
- Typed sync + async clients for Radarr v3 and Sonarr v3.
- Full endpoint coverage generated from upstream OpenAPI specs.
- Auto-generated resource wrappers per OpenAPI tag (`client.movie`, `client.queue`, ...) with
  hand-curated `client.movies` facade for the most-used Radarr resource.
- Env / `.env` fallback for credentials via `pydantic-settings`.
- Configurable retry policy (idempotent GET only by default).
- `py.typed` marker for PEP 561 compliance.
- Pinned upstream specs: Radarr v6.1.1.10360, Sonarr v4.0.17.2952.
