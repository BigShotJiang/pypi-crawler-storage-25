"""Shared types and helpers for safe missing-content backfill loops.

Radarr and Sonarr both let you POST a search command — ``MoviesSearch`` /
``SeriesSearch`` / ``EpisodeSearch`` — with a list of IDs. Hammering these
endpoints in a tight loop will get you indexer-banned, so the practical
pattern (popularized by Huntarr) is: walk the list of missing items in
monitored-only mode, batch IDs, call the search command, wait, and stop
early if the download queue is already saturated.

This module hosts the brand-neutral primitives. The concrete ``backfill()``
methods on ``library`` thread in brand-specific iterators and commands.
"""

from __future__ import annotations

import datetime as _dt
import math
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Literal

BackfillSource = Literal["missing", "cutoff_unmet", "both"]


class BackfillStopReason(StrEnum):
    COMPLETED = "completed"
    MAX_ITEMS = "max_items"
    QUEUE_SATURATED = "queue_saturated"
    DRY_RUN = "dry_run"


@dataclass
class BackfillReport:
    """Outcome of a ``library.backfill()`` run.

    ``searched_ids`` is the ordered list of IDs passed to the search command
    across all batches. In ``dry_run`` mode it holds the IDs that *would* have
    been searched (up to ``max_items``), and ``stopped_reason`` is DRY_RUN.
    """

    source: BackfillSource
    searched_ids: list[int] = field(default_factory=list)
    batches_sent: int = 0
    stopped_reason: BackfillStopReason = BackfillStopReason.COMPLETED
    queue_checks: int = 0
    dry_run: bool = False

    @property
    def searched_count(self) -> int:
        """How many items had a search issued — ``len(searched_ids)``."""
        return len(self.searched_ids)


@dataclass(frozen=True)
class BackfillEstimate:
    """Cost/duration estimate for a planned or completed ``backfill()`` run.

    ``total_items`` is the number of IDs that would be searched; ``batches``
    is how many search commands that splits into; ``duration`` is the expected
    wall-clock time spent in ``time.sleep(delay_between_batches)`` between
    them (not the time the server spends searching — indexers vary). ``eta``
    is a best-effort wall-clock completion time starting from ``start``
    (defaults to "now"), so callers can say "finishes at 15:42."
    """

    total_items: int
    batch_size: int
    batches: int
    delay_between_batches: float
    duration: _dt.timedelta
    eta: _dt.datetime

    def summary(self) -> str:
        """One-line human-readable string.

        Example: ``"128 items in 7 batches; ~3m 00s, done ~15:42:10"``.
        """
        total_seconds = int(self.duration.total_seconds())
        minutes, seconds = divmod(total_seconds, 60)
        hours, minutes = divmod(minutes, 60)
        parts: list[str] = []
        if hours:
            parts.append(f"{hours}h")
        if minutes or hours:
            parts.append(f"{minutes}m")
        parts.append(f"{seconds:02d}s")
        return (
            f"{self.total_items} items in {self.batches} "
            f"batch{'es' if self.batches != 1 else ''}; "
            f"~{' '.join(parts)}, done ~{self.eta:%H:%M:%S}"
        )


def estimate(
    total_items: int,
    *,
    batch_size: int,
    delay_between_batches: float = 30.0,
    start: _dt.datetime | None = None,
) -> BackfillEstimate:
    """Compute cost/duration for a planned backfill run.

    Wall-clock time is ``(batches - 1) * delay_between_batches`` — we only
    sleep *between* batches, not after the last one. Network round-trip and
    server-side search time are excluded; they vary by indexer and are out
    of the library's control.

    Raises ``ValueError`` on non-positive inputs.
    """
    if total_items < 0:
        msg = f"total_items must be >= 0, got {total_items}"
        raise ValueError(msg)
    if batch_size <= 0:
        msg = f"batch_size must be > 0, got {batch_size}"
        raise ValueError(msg)
    if delay_between_batches < 0:
        msg = f"delay_between_batches must be >= 0, got {delay_between_batches}"
        raise ValueError(msg)

    batches = math.ceil(total_items / batch_size) if total_items else 0
    duration_seconds = max(0, batches - 1) * delay_between_batches
    duration = _dt.timedelta(seconds=duration_seconds)
    now = start if start is not None else _dt.datetime.now().astimezone()
    return BackfillEstimate(
        total_items=total_items,
        batch_size=batch_size,
        batches=batches,
        delay_between_batches=delay_between_batches,
        duration=duration,
        eta=now + duration,
    )


def partition(ids: list[int], size: int) -> list[list[int]]:
    """Chunk ``ids`` into batches of at most ``size``. Never emits empty batches."""
    if size <= 0:
        msg = f"batch size must be positive, got {size}"
        raise ValueError(msg)
    return [ids[i : i + size] for i in range(0, len(ids), size)]
