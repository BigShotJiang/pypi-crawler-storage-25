"""Reference/metadata tools for inspecting the projection registry.

Reference tools (``arr_describe_fields``, ``arr_list_resources``)
intentionally omit ``_meta.action_hints`` — they return schema metadata, not
data to pivot on. The hint-uniformity test excludes them by name.
"""

# pyright: reportUnusedFunction=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from arr_py_client.mcp.projection import RESOURCE_REGISTRY, describe

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


def attach_describe_tool(server: FastMCP) -> None:
    @server.tool()
    async def arr_describe_fields(resource: str) -> dict[str, Any]:
        """Return ``{resource, all, summary}`` field names for a resource model.

        ``resource`` is the dotted name like ``"radarr.movie"``, ``"sonarr.series"``,
        ``"radarr.queue"``. Call this when you need to pass a custom comma-list to
        another tool's ``fields=`` arg. Use :func:`arr_list_resources` to discover
        valid resource names.
        """
        return describe(resource)

    @server.tool()
    async def arr_list_resources() -> list[str]:
        """List all dotted-name resource identifiers known to ``arr_describe_fields``."""
        return sorted(RESOURCE_REGISTRY.keys())
