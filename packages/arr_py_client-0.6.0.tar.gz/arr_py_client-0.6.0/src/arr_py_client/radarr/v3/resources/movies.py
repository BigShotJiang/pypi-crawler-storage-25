"""Movies resource for Radarr v3."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, cast

from arr_py_client._common.errors import ArrAlreadyExistsError, ArrNotFoundError
from arr_py_client._common.resolvers import (
    resolve_by_name_or_id,
    resolve_root_folder_path,
    resolve_tag_ids,
)
from arr_py_client.radarr.v3._generated import models as _models
from arr_py_client.radarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Iterator

    from arr_py_client._common.transport import AsyncTransport, SyncTransport

IfExists = Literal["skip", "update", "error"]


def _matches_filter(
    movie: _models.MovieResource,
    *,
    tag: int | None,
    monitored: bool | None,
    has_file: bool | None,
    year: int | tuple[int, int] | None,
    quality_profile_id: int | None,
) -> bool:
    """Client-side filter predicate shared by sync + async movies ``.filter``."""
    if monitored is not None and bool(movie.monitored) != monitored:
        return False
    if has_file is not None and bool(movie.has_file) != has_file:
        return False
    if tag is not None and tag not in (movie.tags or []):
        return False
    if (
        quality_profile_id is not None
        and movie.quality_profile_id != quality_profile_id
    ):
        return False
    if year is not None and movie.year is not None:
        if isinstance(year, int):
            if movie.year != year:
                return False
        else:
            lo, hi = year
            if not (lo <= movie.year <= hi):
                return False
    return True


@dataclass(frozen=True)
class TagResult:
    """Outcome of a bulk tag operation. ``created`` lists newly-minted tag ids."""

    added: list[int]
    removed: list[int]
    created: list[int]


class MoviesResource:
    """Sync movies resource."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list(self) -> list[_models.MovieResource]:
        """Return every movie in the library."""
        return cast(
            "list[_models.MovieResource]",
            _ops.list_movie(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.MovieResource:  # noqa: A002
        """Fetch a single movie by id."""
        return _ops.get_movie_by_id(self._transport, id)

    def get_or_none(self, *, id: int) -> _models.MovieResource | None:  # noqa: A002
        """Like :meth:`get`, but returns ``None`` on 404."""
        try:
            return self.get(id=id)
        except ArrNotFoundError:
            return None

    def delete(
        self,
        *,
        id: int,  # noqa: A002
        delete_files: bool | None = None,
        add_import_exclusion: bool | None = None,
    ) -> None:
        """Delete a movie."""
        _ops.delete_movie_by_id(
            self._transport,
            id,
            delete_files=delete_files,
            add_import_exclusion=add_import_exclusion,
        )

    def lookup(self, *, term: str) -> list[_models.MovieResource]:
        """Full-text lookup against TMDB via Radarr's proxy."""
        return cast(
            "list[_models.MovieResource]",
            _ops.list_movie_lookup(  # pyright: ignore[reportUnknownMemberType]
                self._transport, term=term
            ),
        )

    def lookup_by_imdb(self, *, imdb_id: str) -> list[_models.MovieResource]:
        """Lookup a movie by IMDB id (e.g. ``"tt1160419"``).

        Goes direct to the transport: Radarr returns a list here but the OpenAPI
        spec types this as a single ``MovieResource``.
        """
        response = self._transport.request(
            "GET", "/movie/lookup/imdb", params={"imdbId": imdb_id}
        )
        payload = cast("list[Any] | dict[str, Any]", response.json())
        items = payload if isinstance(payload, list) else [payload]
        return [_models.MovieResource.model_validate(item) for item in items]

    def lookup_by_tmdb(self, *, tmdb_id: int) -> _models.MovieResource:
        """Lookup a movie by TMDB id."""
        response = self._transport.request(
            "GET", "/movie/lookup/tmdb", params={"tmdbId": tmdb_id}
        )
        payload = cast("list[Any] | dict[str, Any]", response.json())
        first = payload[0] if isinstance(payload, list) else payload
        return _models.MovieResource.model_validate(first)

    def add(
        self,
        *,
        # identity (exactly one required)
        tmdb_id: int | None = None,
        title: str | None = None,
        # required fields, name or id accepted for quality
        quality_profile_id: int | None = None,
        quality: str | int | None = None,
        root_folder_path: str | None = None,
        root_folder: str | None = None,
        # optional
        tags: list[str | int] | None = None,
        create_missing_tags: bool = True,
        monitored: bool = True,
        search_on_add: bool = True,
        minimum_availability: _models.MovieStatusType
        | str = _models.MovieStatusType.released,
        if_exists: IfExists = "error",
    ) -> _models.MovieResource:
        """Look up a movie and add it to Radarr in one call.

        Either ``tmdb_id`` or ``title`` must be given (title performs a TMDB
        lookup and uses the top match). Either ``quality_profile_id`` or
        ``quality`` (a name or id) must be given. Either ``root_folder_path``
        or ``root_folder`` (or neither — auto-picks if only one is configured)
        must be given. ``tags`` accepts labels or ids; unknown labels are
        created when ``create_missing_tags=True``.

        ``if_exists``:
            - ``"error"`` (default) — raise :class:`ArrAlreadyExistsError` if a
              movie with the same ``tmdb_id`` already exists.
            - ``"skip"`` — return the existing movie unchanged.
            - ``"update"`` — PUT the resolved fields onto the existing movie
              and return the updated version.
        """
        lookup = self._lookup_for_add(tmdb_id=tmdb_id, title=title)
        effective_tmdb = lookup.tmdb_id or tmdb_id
        # Only pay for a dup-check call when the caller wants to handle it
        # client-side. ``if_exists="error"`` lets the server return 400.
        if if_exists != "error":
            existing = self._existing_by_tmdb(effective_tmdb)
            if existing is not None:
                return self._handle_existing(
                    existing,
                    if_exists=if_exists,
                    quality_profile_id=quality_profile_id,
                    quality=quality,
                    root_folder_path=root_folder_path,
                    root_folder=root_folder,
                    tags=tags,
                    create_missing_tags=create_missing_tags,
                    monitored=monitored,
                )

        resolved_qp = self._resolve_quality(quality_profile_id, quality)
        resolved_rf = self._resolve_root_folder(root_folder_path, root_folder)
        resolved_tags = self._resolve_tags(tags, create_missing=create_missing_tags)

        lookup.quality_profile_id = resolved_qp
        lookup.root_folder_path = resolved_rf
        lookup.monitored = monitored
        lookup.minimum_availability = _models.MovieStatusType(minimum_availability)
        lookup.add_options = _models.AddMovieOptions(search_for_movie=search_on_add)
        if resolved_tags is not None:
            lookup.tags = resolved_tags
        return _ops.create_movie(self._transport, body=lookup)

    # ---- helpers for .add() ----

    def _lookup_for_add(
        self, *, tmdb_id: int | None, title: str | None
    ) -> _models.MovieResource:
        if (tmdb_id is None) == (title is None):
            msg = "add() requires exactly one of tmdb_id= or title="
            raise ValueError(msg)
        if tmdb_id is not None:
            return self.lookup_by_tmdb(tmdb_id=tmdb_id)
        assert title is not None  # noqa: S101  # narrowed by check above
        results = self.lookup(term=title)
        if not results:
            msg = f"no Radarr TMDB match found for title={title!r}"
            raise ValueError(msg)
        return results[0]

    def _existing_by_tmdb(self, tmdb_id: int | None) -> _models.MovieResource | None:
        if tmdb_id is None:
            return None
        for movie in self.list():
            if getattr(movie, "tmdb_id", None) == tmdb_id and getattr(
                movie, "id", None
            ):
                return movie
        return None

    def _handle_existing(
        self,
        existing: _models.MovieResource,
        *,
        if_exists: IfExists,
        quality_profile_id: int | None,
        quality: str | int | None,
        root_folder_path: str | None,
        root_folder: str | None,
        tags: list[str | int] | None,
        create_missing_tags: bool,
        monitored: bool,
    ) -> _models.MovieResource:
        if if_exists == "error":
            raise ArrAlreadyExistsError(
                field="tmdb_id", existing_id=getattr(existing, "id", None)
            )
        if if_exists == "skip":
            return existing
        # update path: resolve new values only if caller supplied them
        if quality_profile_id is not None or quality is not None:
            existing.quality_profile_id = self._resolve_quality(
                quality_profile_id, quality
            )
        if root_folder_path is not None or root_folder is not None:
            existing.root_folder_path = self._resolve_root_folder(
                root_folder_path, root_folder
            )
        if tags is not None:
            resolved = self._resolve_tags(tags, create_missing=create_missing_tags)
            if resolved is not None:
                existing.tags = resolved
        existing.monitored = monitored
        existing_id = getattr(existing, "id", None)
        assert existing_id is not None  # noqa: S101  # from list() filter
        return _ops.update_movie_by_id(self._transport, str(existing_id), body=existing)

    def _resolve_quality(
        self, quality_profile_id: int | None, quality: str | int | None
    ) -> int:
        if quality_profile_id is not None and quality is not None:
            msg = "pass exactly one of quality_profile_id= or quality="
            raise ValueError(msg)
        if quality_profile_id is not None:
            return quality_profile_id
        if quality is None:
            msg = "add() requires quality_profile_id= or quality="
            raise ValueError(msg)
        profiles = cast(
            "list[_models.QualityProfileResource]",
            _ops.list_qualityprofile(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        return resolve_by_name_or_id(
            items=profiles, ref=quality, field="quality_profile"
        )

    def _resolve_root_folder(
        self, root_folder_path: str | None, root_folder: str | None
    ) -> str:
        if root_folder_path is not None and root_folder is not None:
            msg = "pass exactly one of root_folder_path= or root_folder="
            raise ValueError(msg)
        # Fast path: caller gave an explicit, already-server-valid path.
        if root_folder_path is not None:
            return root_folder_path
        # Slow path: caller omitted or used ``root_folder=`` (name-style).
        folders = cast(
            "list[_models.RootFolderResource]",
            _ops.list_rootfolder(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        return resolve_root_folder_path(items=folders, ref=root_folder)

    def _resolve_tags(
        self, tags: list[str | int] | None, *, create_missing: bool
    ) -> list[int] | None:
        if tags is None:
            return None
        existing_tags = cast(
            "list[_models.TagResource]",
            _ops.list_tag(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

        def factory(label: str) -> _models.TagResource:
            return _ops.create_tag(
                self._transport, body=_models.TagResource(id=0, label=label)
            )

        return resolve_tag_ids(
            tags=existing_tags,
            refs=tags,
            create_missing=factory if create_missing else None,
        )

    def delete_many(
        self,
        *,
        ids: list[int],
        delete_files: bool = False,
        add_import_exclusion: bool = False,
    ) -> None:
        """Delete many movies in one call via Radarr's ``movie/editor`` endpoint."""
        body = _models.MovieEditorResource(
            movie_ids=list(ids),
            delete_files=delete_files,
            add_import_exclusion=add_import_exclusion,
        )
        _ops.delete_movie_editor(self._transport, body=body)

    def update_many(self, *, body: _models.MovieEditorResource) -> None:
        """Bulk-edit fields across many movies via ``movie/editor``.

        Pass a populated :class:`MovieEditorResource` (``movie_ids`` plus any
        of ``monitored``, ``quality_profile_id``, ``root_folder_path``,
        ``tags``, ``apply_tags``, ``move_files``, etc.).
        """
        _ops.update_movie_editor(self._transport, body=body)

    # ---- pagination + filtering ----

    def iter_all(self) -> Iterator[_models.MovieResource]:
        """Yield every movie in the library (Radarr returns the full list in one call)."""
        yield from self.list()

    def page(self, *, page: int = 1, size: int = 50) -> list[_models.MovieResource]:
        """Return a ``size``-long slice of the library at 1-indexed ``page``."""
        if page < 1 or size < 1:
            msg = "page and size must be >= 1"
            raise ValueError(msg)
        start = (page - 1) * size
        return self.list()[start : start + size]

    def filter(
        self,
        *,
        tag: str | int | None = None,
        monitored: bool | None = None,
        has_file: bool | None = None,
        year: int | tuple[int, int] | None = None,
        quality_profile: str | int | None = None,
    ) -> Iterator[_models.MovieResource]:
        """Client-side filtered iterator — no new endpoint hits per predicate.

        Fetches the full list once. For 10K+ libraries, prefer
        :meth:`.iter_all` + your own loop.
        """
        tag_id = self._resolve_tag(tag) if tag is not None else None
        qp_id = (
            self._resolve_quality(None, quality_profile)
            if quality_profile is not None
            else None
        )
        for movie in self.list():
            if _matches_filter(
                movie,
                tag=tag_id,
                monitored=monitored,
                has_file=has_file,
                year=year,
                quality_profile_id=qp_id,
            ):
                yield movie

    def _resolve_tag(self, tag: str | int) -> int:
        existing = cast(
            "list[_models.TagResource]",
            _ops.list_tag(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        return resolve_by_name_or_id(
            items=existing, ref=tag, field="tag", name_attr="label"
        )

    # ---- bulk tagging ----

    def tag(
        self,
        *,
        ids: list[int],
        add: list[str | int] | None = None,
        remove: list[str | int] | None = None,
        create_missing: bool = True,
    ) -> TagResult:
        """Bulk add and/or remove tags across movies (resolves names → ids).

        Uses Radarr's ``movie/editor`` endpoint with ``applyTags`` set to
        ``add`` / ``remove`` — one HTTP call per operation.
        """
        if not ids:
            return TagResult(added=[], removed=[], created=[])
        add_refs = list(add or [])
        remove_refs = list(remove or [])
        if not add_refs and not remove_refs:
            return TagResult(added=[], removed=[], created=[])

        existing_tags = cast(
            "list[_models.TagResource]",
            _ops.list_tag(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        known_labels = {
            str(getattr(t, "label", "")).strip().lower()
            for t in existing_tags
            if getattr(t, "label", None)
        }

        def factory(label: str) -> _models.TagResource:
            return _ops.create_tag(
                self._transport, body=_models.TagResource(id=0, label=label)
            )

        created_ids: list[int] = []
        if add_refs:
            before_known = known_labels.copy()
            add_ids = resolve_tag_ids(
                tags=existing_tags,
                refs=add_refs,
                create_missing=factory if create_missing else None,
            )
            # Spot tags created on this call.
            for ref, resolved_id in zip(add_refs, add_ids, strict=False):
                if (
                    isinstance(ref, str)
                    and ref.strip().lower() not in before_known
                    and resolved_id not in created_ids
                ):
                    created_ids.append(resolved_id)
        else:
            add_ids = []
        remove_ids = (
            resolve_tag_ids(tags=existing_tags, refs=remove_refs, create_missing=None)
            if remove_refs
            else []
        )

        if add_ids:
            _ops.update_movie_editor(
                self._transport,
                body=_models.MovieEditorResource(
                    movie_ids=list(ids),
                    tags=add_ids,
                    apply_tags=_models.ApplyTags.add,
                ),
            )
        if remove_ids:
            _ops.update_movie_editor(
                self._transport,
                body=_models.MovieEditorResource(
                    movie_ids=list(ids),
                    tags=remove_ids,
                    apply_tags=_models.ApplyTags.remove,
                ),
            )
        return TagResult(added=add_ids, removed=remove_ids, created=created_ids)


class AsyncMoviesResource:
    """Async movies resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list(self) -> list[_models.MovieResource]:
        return cast(
            "list[_models.MovieResource]",
            await _ops.list_movie_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.MovieResource:  # noqa: A002
        return await _ops.get_movie_by_id_async(self._transport, id)

    async def get_or_none(self, *, id: int) -> _models.MovieResource | None:  # noqa: A002
        try:
            return await self.get(id=id)
        except ArrNotFoundError:
            return None

    async def delete(
        self,
        *,
        id: int,  # noqa: A002
        delete_files: bool | None = None,
        add_import_exclusion: bool | None = None,
    ) -> None:
        await _ops.delete_movie_by_id_async(
            self._transport,
            id,
            delete_files=delete_files,
            add_import_exclusion=add_import_exclusion,
        )

    async def lookup(self, *, term: str) -> list[_models.MovieResource]:
        return cast(
            "list[_models.MovieResource]",
            await _ops.list_movie_lookup_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport, term=term
            ),
        )

    async def lookup_by_imdb(self, *, imdb_id: str) -> list[_models.MovieResource]:
        response = await self._transport.request(
            "GET", "/movie/lookup/imdb", params={"imdbId": imdb_id}
        )
        payload = cast("list[Any] | dict[str, Any]", response.json())
        items = payload if isinstance(payload, list) else [payload]
        return [_models.MovieResource.model_validate(item) for item in items]

    async def lookup_by_tmdb(self, *, tmdb_id: int) -> _models.MovieResource:
        response = await self._transport.request(
            "GET", "/movie/lookup/tmdb", params={"tmdbId": tmdb_id}
        )
        payload = cast("list[Any] | dict[str, Any]", response.json())
        first = payload[0] if isinstance(payload, list) else payload
        return _models.MovieResource.model_validate(first)

    async def add(
        self,
        *,
        tmdb_id: int | None = None,
        title: str | None = None,
        quality_profile_id: int | None = None,
        quality: str | int | None = None,
        root_folder_path: str | None = None,
        root_folder: str | None = None,
        tags: list[str | int] | None = None,
        create_missing_tags: bool = True,
        monitored: bool = True,
        search_on_add: bool = True,
        minimum_availability: _models.MovieStatusType
        | str = _models.MovieStatusType.released,
        if_exists: IfExists = "error",
    ) -> _models.MovieResource:
        """Async twin of :meth:`MoviesResource.add`. See that docstring."""
        lookup = await self._lookup_for_add(tmdb_id=tmdb_id, title=title)
        effective_tmdb = lookup.tmdb_id or tmdb_id
        if if_exists != "error":
            existing = await self._existing_by_tmdb(effective_tmdb)
            if existing is not None:
                return await self._handle_existing(
                    existing,
                    if_exists=if_exists,
                    quality_profile_id=quality_profile_id,
                    quality=quality,
                    root_folder_path=root_folder_path,
                    root_folder=root_folder,
                    tags=tags,
                    create_missing_tags=create_missing_tags,
                    monitored=monitored,
                )

        resolved_qp = await self._resolve_quality(quality_profile_id, quality)
        resolved_rf = await self._resolve_root_folder(root_folder_path, root_folder)
        resolved_tags = await self._resolve_tags(
            tags, create_missing=create_missing_tags
        )

        lookup.quality_profile_id = resolved_qp
        lookup.root_folder_path = resolved_rf
        lookup.monitored = monitored
        lookup.minimum_availability = _models.MovieStatusType(minimum_availability)
        lookup.add_options = _models.AddMovieOptions(search_for_movie=search_on_add)
        if resolved_tags is not None:
            lookup.tags = resolved_tags
        return await _ops.create_movie_async(self._transport, body=lookup)

    # ---- async helpers for .add() ----

    async def _lookup_for_add(
        self, *, tmdb_id: int | None, title: str | None
    ) -> _models.MovieResource:
        if (tmdb_id is None) == (title is None):
            msg = "add() requires exactly one of tmdb_id= or title="
            raise ValueError(msg)
        if tmdb_id is not None:
            return await self.lookup_by_tmdb(tmdb_id=tmdb_id)
        assert title is not None  # noqa: S101  # narrowed by check above
        results = await self.lookup(term=title)
        if not results:
            msg = f"no Radarr TMDB match found for title={title!r}"
            raise ValueError(msg)
        return results[0]

    async def _existing_by_tmdb(
        self, tmdb_id: int | None
    ) -> _models.MovieResource | None:
        if tmdb_id is None:
            return None
        for movie in await self.list():
            if getattr(movie, "tmdb_id", None) == tmdb_id and getattr(
                movie, "id", None
            ):
                return movie
        return None

    async def _handle_existing(
        self,
        existing: _models.MovieResource,
        *,
        if_exists: IfExists,
        quality_profile_id: int | None,
        quality: str | int | None,
        root_folder_path: str | None,
        root_folder: str | None,
        tags: list[str | int] | None,
        create_missing_tags: bool,
        monitored: bool,
    ) -> _models.MovieResource:
        if if_exists == "error":
            raise ArrAlreadyExistsError(
                field="tmdb_id", existing_id=getattr(existing, "id", None)
            )
        if if_exists == "skip":
            return existing
        if quality_profile_id is not None or quality is not None:
            existing.quality_profile_id = await self._resolve_quality(
                quality_profile_id, quality
            )
        if root_folder_path is not None or root_folder is not None:
            existing.root_folder_path = await self._resolve_root_folder(
                root_folder_path, root_folder
            )
        if tags is not None:
            resolved = await self._resolve_tags(
                tags, create_missing=create_missing_tags
            )
            if resolved is not None:
                existing.tags = resolved
        existing.monitored = monitored
        existing_id = getattr(existing, "id", None)
        assert existing_id is not None  # noqa: S101  # from list() filter
        return await _ops.update_movie_by_id_async(
            self._transport, str(existing_id), body=existing
        )

    async def _resolve_quality(
        self, quality_profile_id: int | None, quality: str | int | None
    ) -> int:
        if quality_profile_id is not None and quality is not None:
            msg = "pass exactly one of quality_profile_id= or quality="
            raise ValueError(msg)
        if quality_profile_id is not None:
            return quality_profile_id
        if quality is None:
            msg = "add() requires quality_profile_id= or quality="
            raise ValueError(msg)
        profiles = cast(
            "list[_models.QualityProfileResource]",
            await _ops.list_qualityprofile_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        return resolve_by_name_or_id(
            items=profiles, ref=quality, field="quality_profile"
        )

    async def _resolve_root_folder(
        self, root_folder_path: str | None, root_folder: str | None
    ) -> str:
        if root_folder_path is not None and root_folder is not None:
            msg = "pass exactly one of root_folder_path= or root_folder="
            raise ValueError(msg)
        if root_folder_path is not None:
            return root_folder_path
        folders = cast(
            "list[_models.RootFolderResource]",
            await _ops.list_rootfolder_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        return resolve_root_folder_path(items=folders, ref=root_folder)

    async def _resolve_tags(
        self, tags: list[str | int] | None, *, create_missing: bool
    ) -> list[int] | None:
        if tags is None:
            return None
        existing_tags = cast(
            "list[_models.TagResource]",
            await _ops.list_tag_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

        if create_missing:
            # Synchronous factory is awkward when tag-create is async.
            # Resolve known tags first; create missing ones up-front.
            by_label = {
                str(getattr(t, "label", "")).strip().lower(): t
                for t in existing_tags
                if getattr(t, "label", None)
            }
            for ref in tags:
                if isinstance(ref, str) and ref.strip().lower() not in by_label:
                    created = await _ops.create_tag_async(
                        self._transport,
                        body=_models.TagResource(id=0, label=ref),
                    )
                    existing_tags.append(created)
                    by_label[ref.strip().lower()] = created
        return resolve_tag_ids(tags=existing_tags, refs=tags, create_missing=None)

    async def delete_many(
        self,
        *,
        ids: list[int],
        delete_files: bool = False,
        add_import_exclusion: bool = False,
    ) -> None:
        """Delete many movies in one call via Radarr's ``movie/editor`` endpoint."""
        body = _models.MovieEditorResource(
            movie_ids=list(ids),
            delete_files=delete_files,
            add_import_exclusion=add_import_exclusion,
        )
        await _ops.delete_movie_editor_async(self._transport, body=body)

    async def update_many(self, *, body: _models.MovieEditorResource) -> None:
        """Bulk-edit fields across many movies via ``movie/editor``."""
        await _ops.update_movie_editor_async(self._transport, body=body)

    # ---- pagination + filtering ----

    async def aiter_all(self) -> AsyncIterator[_models.MovieResource]:
        """Yield every movie (Radarr returns the full list in one call)."""
        for movie in await self.list():
            yield movie

    async def page(
        self, *, page: int = 1, size: int = 50
    ) -> list[_models.MovieResource]:
        if page < 1 or size < 1:
            msg = "page and size must be >= 1"
            raise ValueError(msg)
        start = (page - 1) * size
        return (await self.list())[start : start + size]

    async def filter(
        self,
        *,
        tag: str | int | None = None,
        monitored: bool | None = None,
        has_file: bool | None = None,
        year: int | tuple[int, int] | None = None,
        quality_profile: str | int | None = None,
    ) -> list[_models.MovieResource]:
        """Client-side filtered list. Returns a list (not an async iterator)
        since the underlying fetch returns everything at once."""
        tag_id: int | None = None
        if tag is not None:
            existing = cast(
                "list[_models.TagResource]",
                await _ops.list_tag_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
            )
            tag_id = resolve_by_name_or_id(
                items=existing, ref=tag, field="tag", name_attr="label"
            )
        qp_id = None
        if quality_profile is not None:
            qp_id = await self._resolve_quality(None, quality_profile)
        return [
            m
            for m in await self.list()
            if _matches_filter(
                m,
                tag=tag_id,
                monitored=monitored,
                has_file=has_file,
                year=year,
                quality_profile_id=qp_id,
            )
        ]

    # ---- bulk tagging ----

    async def tag(
        self,
        *,
        ids: list[int],
        add: list[str | int] | None = None,
        remove: list[str | int] | None = None,
        create_missing: bool = True,
    ) -> TagResult:
        """Async twin of :meth:`MoviesResource.tag`."""
        if not ids:
            return TagResult(added=[], removed=[], created=[])
        add_refs = list(add or [])
        remove_refs = list(remove or [])
        if not add_refs and not remove_refs:
            return TagResult(added=[], removed=[], created=[])

        existing_tags = cast(
            "list[_models.TagResource]",
            await _ops.list_tag_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        known_labels = {
            str(getattr(t, "label", "")).strip().lower()
            for t in existing_tags
            if getattr(t, "label", None)
        }
        created_ids: list[int] = []
        if add_refs and create_missing:
            for ref in add_refs:
                if isinstance(ref, str) and ref.strip().lower() not in known_labels:
                    created = await _ops.create_tag_async(
                        self._transport,
                        body=_models.TagResource(id=0, label=ref),
                    )
                    existing_tags.append(created)
                    known_labels.add(ref.strip().lower())
                    cid = getattr(created, "id", None)
                    if isinstance(cid, int) and cid not in created_ids:
                        created_ids.append(cid)
        add_ids = (
            resolve_tag_ids(tags=existing_tags, refs=add_refs, create_missing=None)
            if add_refs
            else []
        )
        remove_ids = (
            resolve_tag_ids(tags=existing_tags, refs=remove_refs, create_missing=None)
            if remove_refs
            else []
        )

        if add_ids:
            await _ops.update_movie_editor_async(
                self._transport,
                body=_models.MovieEditorResource(
                    movie_ids=list(ids),
                    tags=add_ids,
                    apply_tags=_models.ApplyTags.add,
                ),
            )
        if remove_ids:
            await _ops.update_movie_editor_async(
                self._transport,
                body=_models.MovieEditorResource(
                    movie_ids=list(ids),
                    tags=remove_ids,
                    apply_tags=_models.ApplyTags.remove,
                ),
            )
        return TagResult(added=add_ids, removed=remove_ids, created=created_ids)
