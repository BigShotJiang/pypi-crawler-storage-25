"""Library (dashboard) resource for Radarr v3.

:meth:`LibraryResource.health_summary` fans out to system status, health
warnings, disk space, queue, and library count in one call and returns a
:class:`LibraryHealth` suitable for dashboards or MCP "what's the state?" tools.

Sub-call failures are captured in ``LibraryHealth.errors`` instead of raising,
so a partial view is always returned.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, cast

import anyio

from arr_py_client._common.backfill import (
    BackfillReport,
    BackfillSource,
    BackfillStopReason,
    partition,
)
from arr_py_client._common.library import (
    DiffResult,
    DiskSummary,
    HealthWarning,
    LibraryHealth,
    QueueSummary,
)
from arr_py_client._common.queue import is_stuck
from arr_py_client.radarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


_STUCK_QUEUE_PAGE = 100


def _health_warning_from(raw: object) -> HealthWarning:
    return HealthWarning(
        source=getattr(raw, "source", None),
        type=str(getattr(raw, "type", None)).rsplit(".", 1)[-1]
        if getattr(raw, "type", None) is not None
        else None,
        message=getattr(raw, "message", None),
        wiki_url=str(getattr(raw, "wiki_url", "") or "") or None,
    )


def _disk_summary_from(raw: object) -> DiskSummary:
    return DiskSummary(
        path=str(getattr(raw, "path", "") or ""),
        label=getattr(raw, "label", None),
        free_bytes=getattr(raw, "free_space", None),
        total_bytes=getattr(raw, "total_space", None),
    )


class LibraryResource:
    """Sync Radarr library dashboard resource."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def health_summary(self) -> LibraryHealth:
        """Aggregate version + health + disks + queue + library count."""
        errors: list[str] = []
        version: str | None = None
        warnings: list[HealthWarning] = []
        disks: list[DiskSummary] = []
        queue = QueueSummary(total=0, stalled=0)
        library_count: int | None = None

        try:
            status = _ops.list_system_status(self._transport)
            version = getattr(status, "version", None)
        except Exception as exc:
            errors.append(f"system_status: {exc}")

        try:
            raw_warnings = cast(
                "list[object]",
                _ops.list_health(self._transport),  # pyright: ignore[reportUnknownMemberType]
            )
            warnings = [_health_warning_from(w) for w in raw_warnings]
        except Exception as exc:
            errors.append(f"health: {exc}")

        try:
            raw_disks = cast(
                "list[object]",
                _ops.list_diskspace(self._transport),  # pyright: ignore[reportUnknownMemberType]
            )
            disks = [_disk_summary_from(d) for d in raw_disks]
        except Exception as exc:
            errors.append(f"diskspace: {exc}")

        try:
            paging = _ops.list_queue(  # pyright: ignore[reportUnknownMemberType]
                self._transport, page=1, page_size=_STUCK_QUEUE_PAGE
            )
            records = list(getattr(paging, "records", None) or [])
            stalled = sum(1 for item in records if is_stuck(item))
            queue = QueueSummary(
                total=int(getattr(paging, "total_records", None) or 0),
                stalled=stalled,
            )
        except Exception as exc:
            errors.append(f"queue: {exc}")

        try:
            movies = cast(
                "list[object]",
                _ops.list_movie(self._transport),  # pyright: ignore[reportUnknownMemberType]
            )
            library_count = len(movies)
        except Exception as exc:
            errors.append(f"movies: {exc}")

        healthy = not errors and not any(
            (w.type or "").lower() in {"error", "warning"} for w in warnings
        )
        return LibraryHealth(
            app="radarr",
            version=version,
            healthy=healthy,
            library_count=library_count,
            warnings=warnings,
            disks=disks,
            queue=queue,
            errors=errors,
        )

    def diff(self, *, tmdb_ids: list[int]) -> DiffResult:
        """Compare a target set of TMDB ids against the library.

        Returns which are present / missing / extra. Use this to answer "what
        am I missing from this TMDB collection?" — callers pipe the result
        into :meth:`MoviesResource.add` for each missing id.
        """
        movies = cast(
            "list[object]",
            _ops.list_movie(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        library_ids = {
            int(getattr(m, "tmdb_id", None) or 0)
            for m in movies
            if getattr(m, "tmdb_id", None)
        }
        target = set(tmdb_ids)
        return DiffResult(
            present_ids=sorted(target & library_ids),
            missing_ids=sorted(target - library_ids),
            extra_ids=sorted(library_ids - target),
        )

    def ical_url(self) -> str:
        """Full URL for Radarr's calendar iCal feed, including the API key.

        Points to ``/api/v3/calendar/radarr.ics?apikey=...``. Users drop this
        in Google Calendar or similar.
        """
        base = self._transport.base_url.rstrip("/")
        api_key = self._transport._config.api_key  # pyright: ignore[reportPrivateUsage]
        return f"{base}/api/v3/calendar/radarr.ics?apikey={api_key}"

    def backfill(
        self,
        *,
        source: BackfillSource = "missing",
        batch_size: int = 5,
        delay_between_batches: float = 30.0,
        max_items: int | None = None,
        pause_if_queue_over: int | None = None,
        monitored_only: bool = True,
        dry_run: bool = False,
    ) -> BackfillReport:
        """Rate-limited search loop over missing / cutoff-unmet movies.

        Iterates wanted movies, batches IDs, and POSTs ``MoviesSearch`` with
        a pause between batches. Stops early if the download queue exceeds
        ``pause_if_queue_over``. In ``dry_run``, plans without searching.

        Use this for periodic backfill jobs (cron / scheduler). Calling it on
        every run with the same parameters is safe — the server coalesces.
        """
        report = BackfillReport(source=source, dry_run=dry_run)
        candidate_ids = self._collect_backfill_ids(
            source=source, monitored_only=monitored_only, max_items=max_items
        )
        batches = partition(candidate_ids, batch_size) if candidate_ids else []

        for batch in batches:
            if pause_if_queue_over is not None and self._queue_over(
                pause_if_queue_over
            ):
                report.queue_checks += 1
                report.stopped_reason = BackfillStopReason.QUEUE_SATURATED
                return report
            if pause_if_queue_over is not None:
                report.queue_checks += 1
            report.searched_ids.extend(batch)
            report.batches_sent += 1
            if dry_run:
                continue
            self._transport.request(
                "POST", "/command", json={"name": "MoviesSearch", "movieIds": batch}
            )
            if delay_between_batches > 0:
                time.sleep(delay_between_batches)

        report.stopped_reason = (
            BackfillStopReason.DRY_RUN
            if dry_run
            else BackfillStopReason.MAX_ITEMS
            if max_items is not None and report.searched_count >= max_items
            else BackfillStopReason.COMPLETED
        )
        return report

    def _collect_backfill_ids(
        self,
        *,
        source: BackfillSource,
        monitored_only: bool,
        max_items: int | None,
    ) -> list[int]:
        from arr_py_client._common.pagination import iter_pages

        monitored_param = True if monitored_only else None

        def _missing_page(page: int, size: int) -> dict[str, list[object]]:
            paging = _ops.list_wanted_missing(  # pyright: ignore[reportUnknownMemberType]
                self._transport, page=page, page_size=size, monitored=monitored_param
            )
            records = cast("list[object]", list(getattr(paging, "records", None) or []))
            return {"records": records}

        def _cutoff_page(page: int, size: int) -> dict[str, list[object]]:
            paging = _ops.list_wanted_cutoff(  # pyright: ignore[reportUnknownMemberType]
                self._transport, page=page, page_size=size, monitored=monitored_param
            )
            records = cast("list[object]", list(getattr(paging, "records", None) or []))
            return {"records": records}

        fetchers = (
            [_missing_page, _cutoff_page]
            if source == "both"
            else [_missing_page if source == "missing" else _cutoff_page]
        )
        ids: list[int] = []
        for fetch in fetchers:
            for movie in iter_pages(fetch, page_size=50):
                mid = getattr(movie, "id", None)
                if mid is None:
                    continue
                ids.append(int(mid))
                if max_items is not None and len(ids) >= max_items:
                    return ids
        return ids

    def _queue_over(self, threshold: int) -> bool:
        paging = _ops.list_queue(  # pyright: ignore[reportUnknownMemberType]
            self._transport, page=1, page_size=1
        )
        total = int(getattr(paging, "total_records", None) or 0)
        return total > threshold


class AsyncLibraryResource:
    """Async Radarr library dashboard resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def health_summary(self) -> LibraryHealth:
        """Async twin of :meth:`LibraryResource.health_summary`.

        Sub-calls run concurrently via ``anyio.create_task_group``.
        """
        errors: list[str] = []
        results: dict[str, object | None] = {
            "version": None,
            "warnings": None,
            "disks": None,
            "queue_paging": None,
            "movies": None,
        }

        async def fetch_version() -> None:
            try:
                status = await _ops.list_system_status_async(self._transport)
                results["version"] = getattr(status, "version", None)
            except Exception as exc:
                errors.append(f"system_status: {exc}")

        async def fetch_warnings() -> None:
            try:
                results["warnings"] = await _ops.list_health_async(  # pyright: ignore[reportUnknownMemberType]
                    self._transport
                )
            except Exception as exc:
                errors.append(f"health: {exc}")

        async def fetch_disks() -> None:
            try:
                results["disks"] = await _ops.list_diskspace_async(  # pyright: ignore[reportUnknownMemberType]
                    self._transport
                )
            except Exception as exc:
                errors.append(f"diskspace: {exc}")

        async def fetch_queue() -> None:
            try:
                results["queue_paging"] = await _ops.list_queue_async(  # pyright: ignore[reportUnknownMemberType]
                    self._transport, page=1, page_size=_STUCK_QUEUE_PAGE
                )
            except Exception as exc:
                errors.append(f"queue: {exc}")

        async def fetch_movies() -> None:
            try:
                results["movies"] = await _ops.list_movie_async(  # pyright: ignore[reportUnknownMemberType]
                    self._transport
                )
            except Exception as exc:
                errors.append(f"movies: {exc}")

        async with anyio.create_task_group() as tg:
            tg.start_soon(fetch_version)
            tg.start_soon(fetch_warnings)
            tg.start_soon(fetch_disks)
            tg.start_soon(fetch_queue)
            tg.start_soon(fetch_movies)

        raw_warnings = cast("list[object] | None", results["warnings"]) or []
        warnings = [_health_warning_from(w) for w in raw_warnings]
        raw_disks = cast("list[object] | None", results["disks"]) or []
        disks = [_disk_summary_from(d) for d in raw_disks]
        paging = results["queue_paging"]
        if paging is not None:
            records = list(getattr(paging, "records", None) or [])
            stalled = sum(1 for item in records if is_stuck(item))
            queue = QueueSummary(
                total=int(getattr(paging, "total_records", None) or 0),
                stalled=stalled,
            )
        else:
            queue = QueueSummary(total=0, stalled=0)
        movies = cast("list[object] | None", results["movies"])
        library_count = len(movies) if movies is not None else None

        healthy = not errors and not any(
            (w.type or "").lower() in {"error", "warning"} for w in warnings
        )
        return LibraryHealth(
            app="radarr",
            version=cast("str | None", results["version"]),
            healthy=healthy,
            library_count=library_count,
            warnings=warnings,
            disks=disks,
            queue=queue,
            errors=errors,
        )

    async def diff(self, *, tmdb_ids: list[int]) -> DiffResult:
        """Async twin of :meth:`LibraryResource.diff`."""
        movies = cast(
            "list[object]",
            await _ops.list_movie_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        library_ids = {
            int(getattr(m, "tmdb_id", None) or 0)
            for m in movies
            if getattr(m, "tmdb_id", None)
        }
        target = set(tmdb_ids)
        return DiffResult(
            present_ids=sorted(target & library_ids),
            missing_ids=sorted(target - library_ids),
            extra_ids=sorted(library_ids - target),
        )

    def ical_url(self) -> str:
        """Full URL for Radarr's calendar iCal feed, including the API key."""
        base = self._transport.base_url.rstrip("/")
        api_key = self._transport._config.api_key  # pyright: ignore[reportPrivateUsage]
        return f"{base}/api/v3/calendar/radarr.ics?apikey={api_key}"

    async def backfill(
        self,
        *,
        source: BackfillSource = "missing",
        batch_size: int = 5,
        delay_between_batches: float = 30.0,
        max_items: int | None = None,
        pause_if_queue_over: int | None = None,
        monitored_only: bool = True,
        dry_run: bool = False,
    ) -> BackfillReport:
        """Async twin of :meth:`LibraryResource.backfill`."""
        report = BackfillReport(source=source, dry_run=dry_run)
        candidate_ids = await self._collect_backfill_ids(
            source=source, monitored_only=monitored_only, max_items=max_items
        )
        batches = partition(candidate_ids, batch_size) if candidate_ids else []

        for batch in batches:
            if pause_if_queue_over is not None and await self._queue_over(
                pause_if_queue_over
            ):
                report.queue_checks += 1
                report.stopped_reason = BackfillStopReason.QUEUE_SATURATED
                return report
            if pause_if_queue_over is not None:
                report.queue_checks += 1
            report.searched_ids.extend(batch)
            report.batches_sent += 1
            if dry_run:
                continue
            await self._transport.request(
                "POST", "/command", json={"name": "MoviesSearch", "movieIds": batch}
            )
            if delay_between_batches > 0:
                await anyio.sleep(delay_between_batches)

        report.stopped_reason = (
            BackfillStopReason.DRY_RUN
            if dry_run
            else BackfillStopReason.MAX_ITEMS
            if max_items is not None and report.searched_count >= max_items
            else BackfillStopReason.COMPLETED
        )
        return report

    async def _collect_backfill_ids(
        self,
        *,
        source: BackfillSource,
        monitored_only: bool,
        max_items: int | None,
    ) -> list[int]:
        from arr_py_client._common.pagination import aiter_pages

        monitored_param = True if monitored_only else None

        async def _missing_page(page: int, size: int) -> dict[str, list[object]]:
            paging = await _ops.list_wanted_missing_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport, page=page, page_size=size, monitored=monitored_param
            )
            records = cast("list[object]", list(getattr(paging, "records", None) or []))
            return {"records": records}

        async def _cutoff_page(page: int, size: int) -> dict[str, list[object]]:
            paging = await _ops.list_wanted_cutoff_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport, page=page, page_size=size, monitored=monitored_param
            )
            records = cast("list[object]", list(getattr(paging, "records", None) or []))
            return {"records": records}

        fetchers = (
            [_missing_page, _cutoff_page]
            if source == "both"
            else [_missing_page if source == "missing" else _cutoff_page]
        )
        ids: list[int] = []
        for fetch in fetchers:
            async for movie in aiter_pages(fetch, page_size=50):
                mid = getattr(movie, "id", None)
                if mid is None:
                    continue
                ids.append(int(mid))
                if max_items is not None and len(ids) >= max_items:
                    return ids
        return ids

    async def _queue_over(self, threshold: int) -> bool:
        paging = await _ops.list_queue_async(  # pyright: ignore[reportUnknownMemberType]
            self._transport, page=1, page_size=1
        )
        total = int(getattr(paging, "total_records", None) or 0)
        return total > threshold
