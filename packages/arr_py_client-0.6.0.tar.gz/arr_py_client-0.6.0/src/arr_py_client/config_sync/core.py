"""Brand-neutral planner/applier for declarative config sync.

This module never imports from ``radarr.v3`` or ``sonarr.v3`` directly — it
relies on the duck-typed surface exposed by both curated clients:

- ``client.tags.list()`` -> list[TagResource]
- ``client.tags.create(body=...)``, ``.update(id=, body=)``, ``.delete(id=)``
- ``client.custom_formats.list()`` -> list[CustomFormatResource]
- ``client.custom_formats.create(body=...)``, ``.update(id=, body=)``, ``.delete(id=)``
- ``client.quality_profiles.list()`` -> list[QualityProfileResource]
- ``client.quality_profiles.create(body=...)``, ``.update(id=, body=)``, ``.delete(id=)``

The diff strategy is "explicitly-listed reconciles, not-listed stays" by
default. Passing ``strict=True`` adds DELETE actions for items present on
the server but missing from the config. Strict mode is destructive — callers
should always dry-run before applying.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal, cast

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

Action = Literal["create", "update", "delete"]
Resource = Literal[
    "tags",
    "custom_formats",
    "quality_profiles",
    "root_folders",
    "download_clients",
    "indexers",
    "notifications",
    "naming",
    "applications",
    "release_profiles",
    "auto_tagging",
]
SUPPORTED_RESOURCES: tuple[Resource, ...] = (
    "tags",
    "custom_formats",
    "quality_profiles",
    "root_folders",
    "download_clients",
    "indexers",
    "notifications",
    "naming",
    "applications",
    "release_profiles",
    "auto_tagging",
)


@dataclass(frozen=True)
class SyncChange:
    """One planned change against one resource item (by ``name``)."""

    resource: Resource
    name: str
    action: Action
    # ``body`` is the pydantic body the applier will POST/PUT, or ``None`` for
    # deletes. ``detail`` is a short human string used by :meth:`SyncPlan.summary`.
    body: object | None = None
    detail: str = ""
    existing_id: int | None = None


@dataclass
class SyncPlan:
    """Ordered list of :class:`SyncChange` actions to reach the desired state."""

    changes: list[SyncChange] = field(default_factory=list)
    strict: bool = False

    @property
    def is_noop(self) -> bool:
        return not self.changes

    def by_action(self, action: Action) -> list[SyncChange]:
        return [c for c in self.changes if c.action == action]

    def summary(self) -> str:
        if self.is_noop:
            return "SyncPlan: no changes (already in desired state)."
        counts: dict[tuple[Resource, Action], int] = {}
        for c in self.changes:
            counts[(c.resource, c.action)] = counts.get((c.resource, c.action), 0) + 1
        parts = [
            f"{n}x {resource}.{action}"
            for (resource, action), n in sorted(counts.items())
        ]
        strict_suffix = " [strict]" if self.strict else ""
        return f"SyncPlan{strict_suffix}: " + ", ".join(parts)


@dataclass
class SyncReport:
    """What actually happened when :func:`apply` ran the plan."""

    applied: list[SyncChange] = field(default_factory=list)
    skipped: list[SyncChange] = field(default_factory=list)
    errors: list[tuple[SyncChange, str]] = field(default_factory=list)
    dry_run: bool = True


# ---------------------------------------------------------------------------
# Name-based indexing helpers
# ---------------------------------------------------------------------------


def _name_of(obj: object) -> str | None:
    n = getattr(obj, "name", None)
    return str(n) if n is not None else None


def _id_of(obj: object) -> int | None:
    value = getattr(obj, "id", None)
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _dump(obj: object) -> dict[str, Any]:
    """Best-effort pydantic-or-dict dump → dict (alias keys)."""
    if isinstance(obj, dict):
        return dict(cast("dict[str, Any]", obj))
    dump_fn = getattr(obj, "model_dump", None)
    if callable(dump_fn):
        result = cast("dict[str, Any]", dump_fn(by_alias=True, exclude_none=True))
        return dict(result)
    return dict(vars(obj))


def _merge(existing: object, desired: Mapping[str, Any]) -> dict[str, Any]:
    """Merge desired-keys over an existing-resource dump. ``id`` is preserved."""
    base = _dump(existing)
    base.update(dict(desired))
    eid = _id_of(existing)
    if eid is not None:
        base["id"] = eid
    return base


def _same(existing: object, desired: Mapping[str, Any]) -> bool:
    """Do the desired-keys already match what's on the server?

    Partial equality: only the keys in ``desired`` are compared against
    ``existing`` — keys not present in ``desired`` are not touched, so a sparse
    config doesn't generate spurious updates.
    """
    base = _dump(existing)
    for key, want in desired.items():
        have = base.get(key)
        if _normalize(have) != _normalize(want):
            return False
    return True


def _normalize(value: object) -> object:
    """Normalize so ``[a,b] == [b,a]`` when comparing unordered resource lists.

    For the config-sync use case we treat lists of dicts keyed by ``name`` as
    sets: order shouldn't cause false diffs on ``format_items`` and similar.
    """
    if not isinstance(value, list):
        return value
    items = cast("list[object]", value)
    if items and all(isinstance(x, dict) and "name" in x for x in items):
        dicts = cast("list[dict[str, Any]]", items)
        return sorted(dicts, key=lambda x: str(x["name"]))
    return items


# ---------------------------------------------------------------------------
# Resource-specific planners
# ---------------------------------------------------------------------------


def _plan_tags(
    client: Any,
    desired: Sequence[str] | Sequence[Mapping[str, Any]],
    *,
    strict: bool,
) -> list[SyncChange]:
    """Tags are names-only. Accepts either ``["anime","4k"]`` or mapping form."""
    desired_names: list[str] = [
        t if isinstance(t, str) else str(t.get("label") or t.get("name") or "")
        for t in desired
    ]
    existing_raw = cast("list[object]", list(client.tags.list()))
    existing: dict[str, object] = {}
    for item in existing_raw:
        label = getattr(item, "label", None) or getattr(item, "name", None)
        if label:
            existing[str(label)] = item

    changes: list[SyncChange] = []
    for name in desired_names:
        if not name or name in existing:
            continue
        changes.append(
            SyncChange(
                resource="tags",
                name=name,
                action="create",
                body={"label": name},
                detail=f"create tag '{name}'",
            )
        )
    if strict:
        want = {n for n in desired_names if n}
        for name, item in existing.items():
            if name not in want:
                changes.append(
                    SyncChange(
                        resource="tags",
                        name=name,
                        action="delete",
                        existing_id=_id_of(item),
                        detail=f"delete tag '{name}'",
                    )
                )
    return changes


def _plan_root_folders(
    existing: Sequence[object],
    desired: Sequence[Mapping[str, Any]],
    *,
    strict: bool,
) -> list[SyncChange]:
    """Root folders are keyed by absolute ``path``, not by ``name``.

    Each desired entry is either a string path or a mapping with a ``path``
    key. Creating a root folder requires the directory to already exist on
    the server filesystem — the server rejects unknown paths. Apply errors
    end up in ``SyncReport.errors`` so one missing directory doesn't block
    other changes.
    """
    existing_by_path: dict[str, object] = {}
    for item in existing:
        path = getattr(item, "path", None)
        if path is not None:
            existing_by_path[str(path)] = item

    changes: list[SyncChange] = []
    desired_paths: set[str] = set()
    for spec in desired:
        path = str(spec.get("path") or "")
        if not path:
            continue
        desired_paths.add(path)
        match = existing_by_path.get(path)
        payload = dict(spec)
        if match is None:
            changes.append(
                SyncChange(
                    resource="root_folders",
                    name=path,
                    action="create",
                    body=payload,
                    detail=f"create root folder '{path}'",
                )
            )
    if strict:
        for path, item in existing_by_path.items():
            if path not in desired_paths:
                changes.append(
                    SyncChange(
                        resource="root_folders",
                        name=path,
                        action="delete",
                        existing_id=_id_of(item),
                        detail=f"delete root folder '{path}'",
                    )
                )
    return changes


def _plan_naming(existing: object, desired: Mapping[str, Any]) -> list[SyncChange]:
    """Naming is a singleton endpoint — one object, GET/PUT, no id needed.

    Emits at most one ``update`` change, with body merged over the existing
    naming config. ``apply`` special-cases the naming path to PUT without an
    id.
    """
    if _same(existing, desired):
        return []
    merged = _merge(existing, desired)
    # Singleton: the existing object does have an id (1); we keep it so
    # callers can inspect it, but apply() PUTs to /config/naming directly
    # regardless of the id.
    return [
        SyncChange(
            resource="naming",
            name="naming",
            action="update",
            body=merged,
            detail="update naming config",
            existing_id=_id_of(existing),
        )
    ]


def _plan_resource_by_name(
    *,
    resource: Resource,
    existing: Sequence[object],
    desired_by_name: Mapping[str, Mapping[str, Any]],
    strict: bool,
) -> list[SyncChange]:
    """Generic name-keyed reconciler for resources that share ``{id, name, ...}``."""
    existing_by_name: dict[str, object] = {}
    for item in existing:
        name = _name_of(item)
        if name is not None:
            existing_by_name[name] = item

    changes: list[SyncChange] = []
    for name, spec in desired_by_name.items():
        payload = dict(spec)
        payload.setdefault("name", name)
        match = existing_by_name.get(name)
        if match is None:
            changes.append(
                SyncChange(
                    resource=resource,
                    name=name,
                    action="create",
                    body=payload,
                    detail=f"create {resource} '{name}'",
                )
            )
            continue
        if _same(match, payload):
            continue
        changes.append(
            SyncChange(
                resource=resource,
                name=name,
                action="update",
                body=_merge(match, payload),
                detail=f"update {resource} '{name}'",
                existing_id=_id_of(match),
            )
        )
    if strict:
        for name, item in existing_by_name.items():
            if name not in desired_by_name:
                changes.append(
                    SyncChange(
                        resource=resource,
                        name=name,
                        action="delete",
                        existing_id=_id_of(item),
                        detail=f"delete {resource} '{name}'",
                    )
                )
    return changes


async def _plan_tags_async(
    client: Any,
    desired: Sequence[str] | Sequence[Mapping[str, Any]],
    *,
    strict: bool,
) -> list[SyncChange]:
    """Async twin of :func:`_plan_tags`."""
    desired_names: list[str] = [
        t if isinstance(t, str) else str(t.get("label") or t.get("name") or "")
        for t in desired
    ]
    raw = await client.tags.list()
    existing_raw = cast("list[object]", list(raw))
    existing: dict[str, object] = {}
    for item in existing_raw:
        label = getattr(item, "label", None) or getattr(item, "name", None)
        if label:
            existing[str(label)] = item

    changes: list[SyncChange] = []
    for name in desired_names:
        if not name or name in existing:
            continue
        changes.append(
            SyncChange(
                resource="tags",
                name=name,
                action="create",
                body={"label": name},
                detail=f"create tag '{name}'",
            )
        )
    if strict:
        want = {n for n in desired_names if n}
        for name, item in existing.items():
            if name not in want:
                changes.append(
                    SyncChange(
                        resource="tags",
                        name=name,
                        action="delete",
                        existing_id=_id_of(item),
                        detail=f"delete tag '{name}'",
                    )
                )
    return changes


def plan(
    client: Any,
    desired: Mapping[str, Any],
    *,
    strict: bool = False,
    include: Sequence[Resource] | None = None,
) -> SyncPlan:
    """Diff ``desired`` against the live server. Returns a :class:`SyncPlan`.

    ``desired`` shape (all keys optional)::

        {
            "tags": ["anime", "4k-only"],
            "custom_formats": {
                "HDR10+": {"specifications": [...]},
            },
            "quality_profiles": {
                "Best Movies": {
                    "upgradeAllowed": True,
                    "cutoff": 2160,
                    "formatItems": [{"name": "HDR10+", "score": 300}],
                },
            },
        }

    ``strict=True`` emits DELETE actions for items on the server but not in
    ``desired``. ``include`` narrows the scope (defaults to every supported
    resource).
    """
    scope: Sequence[Resource] = include if include is not None else SUPPORTED_RESOURCES
    out: list[SyncChange] = []

    if "tags" in scope and "tags" in desired and hasattr(client, "tags"):
        out.extend(_plan_tags(client, desired["tags"], strict=strict))

    if (
        "custom_formats" in scope
        and "custom_formats" in desired
        and hasattr(client, "custom_formats")
    ):
        desired_cf: Mapping[str, Mapping[str, Any]] = desired["custom_formats"]
        existing_cf = cast("list[object]", list(client.custom_formats.list()))
        out.extend(
            _plan_resource_by_name(
                resource="custom_formats",
                existing=existing_cf,
                desired_by_name=desired_cf,
                strict=strict,
            )
        )

    if (
        "quality_profiles" in scope
        and "quality_profiles" in desired
        and hasattr(client, "quality_profiles")
    ):
        desired_qp: Mapping[str, Mapping[str, Any]] = desired["quality_profiles"]
        existing_qp = cast("list[object]", list(client.quality_profiles.list()))
        out.extend(
            _plan_resource_by_name(
                resource="quality_profiles",
                existing=existing_qp,
                desired_by_name=desired_qp,
                strict=strict,
            )
        )

    if (
        "root_folders" in scope
        and "root_folders" in desired
        and hasattr(client, "root_folders")
    ):
        existing_rf = cast("list[object]", list(client.root_folders.list()))
        out.extend(
            _plan_root_folders(
                existing=existing_rf,
                desired=desired["root_folders"],
                strict=strict,
            )
        )

    for key in (
        "download_clients",
        "indexers",
        "notifications",
        "applications",
        "release_profiles",
        "auto_tagging",
    ):
        if key in scope and key in desired and hasattr(client, key):
            desired_map: Mapping[str, Mapping[str, Any]] = desired[key]
            existing_items = cast("list[object]", list(getattr(client, key).list()))
            out.extend(
                _plan_resource_by_name(
                    resource=cast("Resource", key),
                    existing=existing_items,
                    desired_by_name=desired_map,
                    strict=strict,
                )
            )

    if (
        "naming" in scope
        and "naming" in desired
        and hasattr(client, "custom_formats")  # Prowlarr has no naming endpoint
    ):
        existing_nm = client.transport.request(
            "GET", _PATH_BY_RESOURCE["naming"]
        ).json()
        out.extend(_plan_naming(existing_nm, desired["naming"]))

    return SyncPlan(changes=out, strict=strict)


# ---------------------------------------------------------------------------
# Apply
# ---------------------------------------------------------------------------


_PATH_BY_RESOURCE: dict[Resource, str] = {
    "tags": "/tag",
    "custom_formats": "/customformat",
    "quality_profiles": "/qualityprofile",
    "root_folders": "/rootfolder",
    "download_clients": "/downloadclient",
    "indexers": "/indexer",
    "notifications": "/notification",
    "naming": "/config/naming",
    "applications": "/applications",
    "release_profiles": "/releaseprofile",
    "auto_tagging": "/autotagging",
}


def apply(
    client: Any,
    plan_: SyncPlan,
    *,
    dry_run: bool = True,
) -> SyncReport:
    """Execute (or ``dry_run``) a :class:`SyncPlan` against the live server.

    Each change is tried independently; errors are captured in the report so
    one broken change doesn't block the others. HTTP calls go through the
    client's :attr:`transport` directly — we bypass the typed facade so the
    config-sync layer stays brand-neutral and accepts raw dicts.
    """
    report = SyncReport(dry_run=dry_run)
    if dry_run:
        report.skipped = list(plan_.changes)
        return report

    transport = client.transport
    for change in plan_.changes:
        base_path = _PATH_BY_RESOURCE.get(change.resource)
        if base_path is None:
            report.errors.append((change, f"unknown resource: {change.resource}"))
            continue
        try:
            if change.resource == "naming":
                # Singleton endpoint — no id segment, no create/delete.
                transport.request("PUT", base_path, json=change.body)
            elif change.action == "create":
                transport.request("POST", base_path, json=change.body)
            elif change.action == "update":
                if change.existing_id is None:
                    msg = "update change missing existing_id"
                    raise ValueError(msg)
                transport.request(
                    "PUT",
                    f"{base_path}/{change.existing_id}",
                    json=change.body,
                )
            elif change.action == "delete":
                if change.existing_id is None:
                    msg = "delete change missing existing_id"
                    raise ValueError(msg)
                transport.request("DELETE", f"{base_path}/{change.existing_id}")
            report.applied.append(change)
        except Exception as exc:
            report.errors.append((change, str(exc)))
    return report


# ---------------------------------------------------------------------------
# Async twins — mirror ``plan`` / ``apply`` for ``AsyncRadarrClient`` /
# ``AsyncSonarrClient``. Kept as a separate surface so sync callers don't pay
# an anyio/asyncio import cost.
# ---------------------------------------------------------------------------


async def plan_async(
    client: Any,
    desired: Mapping[str, Any],
    *,
    strict: bool = False,
    include: Sequence[Resource] | None = None,
) -> SyncPlan:
    """Async twin of :func:`plan`."""
    scope: Sequence[Resource] = include if include is not None else SUPPORTED_RESOURCES
    out: list[SyncChange] = []

    if "tags" in scope and "tags" in desired and hasattr(client, "tags"):
        out.extend(await _plan_tags_async(client, desired["tags"], strict=strict))

    if (
        "custom_formats" in scope
        and "custom_formats" in desired
        and hasattr(client, "custom_formats")
    ):
        desired_cf: Mapping[str, Mapping[str, Any]] = desired["custom_formats"]
        raw_cf = await client.custom_formats.list()
        existing_cf = cast("list[object]", list(raw_cf))
        out.extend(
            _plan_resource_by_name(
                resource="custom_formats",
                existing=existing_cf,
                desired_by_name=desired_cf,
                strict=strict,
            )
        )

    if (
        "quality_profiles" in scope
        and "quality_profiles" in desired
        and hasattr(client, "quality_profiles")
    ):
        desired_qp: Mapping[str, Mapping[str, Any]] = desired["quality_profiles"]
        raw_qp = await client.quality_profiles.list()
        existing_qp = cast("list[object]", list(raw_qp))
        out.extend(
            _plan_resource_by_name(
                resource="quality_profiles",
                existing=existing_qp,
                desired_by_name=desired_qp,
                strict=strict,
            )
        )

    if (
        "root_folders" in scope
        and "root_folders" in desired
        and hasattr(client, "root_folders")
    ):
        raw_rf = await client.root_folders.list()
        out.extend(
            _plan_root_folders(
                existing=cast("list[object]", list(raw_rf)),
                desired=desired["root_folders"],
                strict=strict,
            )
        )

    for key in (
        "download_clients",
        "indexers",
        "notifications",
        "applications",
        "release_profiles",
        "auto_tagging",
    ):
        if key in scope and key in desired and hasattr(client, key):
            desired_map_a: Mapping[str, Mapping[str, Any]] = desired[key]
            raw_items = await getattr(client, key).list()
            out.extend(
                _plan_resource_by_name(
                    resource=cast("Resource", key),
                    existing=cast("list[object]", list(raw_items)),
                    desired_by_name=desired_map_a,
                    strict=strict,
                )
            )

    if (
        "naming" in scope
        and "naming" in desired
        and hasattr(client, "custom_formats")  # Prowlarr has no naming endpoint
    ):
        resp = await client.transport.request("GET", _PATH_BY_RESOURCE["naming"])
        existing_nm = resp.json()
        out.extend(_plan_naming(existing_nm, desired["naming"]))

    return SyncPlan(changes=out, strict=strict)


async def apply_async(
    client: Any,
    plan_: SyncPlan,
    *,
    dry_run: bool = True,
) -> SyncReport:
    """Async twin of :func:`apply`."""
    report = SyncReport(dry_run=dry_run)
    if dry_run:
        report.skipped = list(plan_.changes)
        return report

    transport = client.transport
    for change in plan_.changes:
        base_path = _PATH_BY_RESOURCE.get(change.resource)
        if base_path is None:
            report.errors.append((change, f"unknown resource: {change.resource}"))
            continue
        try:
            if change.resource == "naming":
                await transport.request("PUT", base_path, json=change.body)
            elif change.action == "create":
                await transport.request("POST", base_path, json=change.body)
            elif change.action == "update":
                if change.existing_id is None:
                    msg = "update change missing existing_id"
                    raise ValueError(msg)
                await transport.request(
                    "PUT",
                    f"{base_path}/{change.existing_id}",
                    json=change.body,
                )
            elif change.action == "delete":
                if change.existing_id is None:
                    msg = "delete change missing existing_id"
                    raise ValueError(msg)
                await transport.request("DELETE", f"{base_path}/{change.existing_id}")
            report.applied.append(change)
        except Exception as exc:
            report.errors.append((change, str(exc)))
    return report
