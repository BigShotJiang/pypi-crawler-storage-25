# SPDX-FileCopyrightText: Copyright 2026 <balparda@github.com> & <BellaKeri@github.com>
# SPDX-License-Identifier: Apache-2.0
"""CLI: Base."""

from __future__ import annotations

import dataclasses
import pathlib
from collections import abc

import click
import typer
from transcrypto.cli import clibase
from transcrypto.utils import base as tbase

from tranzoom.core import ai, fractal, frame, image, palette

# global CLI data, and some test stuff

# if `tests/data/images/demo-mandel-seahorse-tail.png` changes you have to update this hash!
SEAHORSE_TAIL_HASH: str = '38824cdaa58b64496ebfd86facf4d4ba4596ab18db95ac97afd643a7a892ff83'
# this is tested from `tests/cli/base_test.py` & `tests_integration/test_installed_cli.py`!

# CLI options that can be re-used

DEFAULT_IMAGE_PREFIX: str = 'mandel'

# Image: output image
IMAGE_WIDTH_OPTION: typer.models.OptionInfo = typer.Option(
  frame.DEFAULT_IMAGE_SIZE,
  '-w',
  '--width',
  min=frame.MIN_IMAGE_SIZE,
  max=frame.MAX_IMAGE_SIZE,
  help=(
    f'Width of the image; {frame.MIN_IMAGE_SIZE} ≤ w ≤ {frame.MAX_IMAGE_SIZE}; '
    f'default is {frame.DEFAULT_IMAGE_SIZE}'
  ),
)
IMAGE_HEIGHT_OPTION: typer.models.OptionInfo = typer.Option(
  frame.DEFAULT_IMAGE_SIZE,
  '-h',
  '--height',
  min=frame.MIN_IMAGE_SIZE,
  max=frame.MAX_IMAGE_SIZE,
  help=(
    f'Height of the image; {frame.MIN_IMAGE_SIZE} ≤ h ≤ {frame.MAX_IMAGE_SIZE}; '
    f'default is {frame.DEFAULT_IMAGE_SIZE}'
  ),
)
IMAGE_PATH_OUTPUT_OPTION: typer.models.OptionInfo = typer.Option(
  None,
  '-o',
  '--out',
  exists=True,
  file_okay=False,
  dir_okay=True,
  readable=True,
  writable=True,
  help=(
    'The local output root directory path, ex: "~/foo/bar/"; '
    'if not given, the image will be saved in the current working directory'
  ),
)
IMAGE_PREFIX_OPTION: typer.models.OptionInfo = typer.Option(
  DEFAULT_IMAGE_PREFIX,
  '--prefix',
  help=(
    f'Image save prefix; default: {DEFAULT_IMAGE_PREFIX!r} '
    '(the final file name will be "<prefix>[-<date>][-<hash20>].png", note the date and the hash '
    'can be turned off with --no-date and --no-hash, respectively)'
  ),
)
IMAGE_INCLUDE_DATE_OPTION: typer.models.OptionInfo = typer.Option(
  True,
  '--date/--no-date',
  help=(
    'If True, file names will include the date-time as YYYYMMDDhhmmss; '
    'if False, file names will not include the date-time; default is True'
  ),
)
IMAGE_INCLUDE_HASH_OPTION: typer.models.OptionInfo = typer.Option(
  True,
  '--hash/--no-hash',
  help=(
    'If True, file names will include the hash; '
    'if False, file names will not include the hash; default is True'
  ),
)
IMAGE_PRINT_ITERM_OPTION: typer.models.OptionInfo = typer.Option(
  False,
  '--iterm/--no-iterm',
  help=(
    'If True, will output the image to iTerm2 '
    '(only use on macOS with iTerm2! <https://iterm2.com/documentation-images.html>); '
    'if False, will not output the image to iTerm2; default is False'
  ),
)

# Image: input image
IMAGE_PATH_INPUT_ARGUMENT: typer.models.ArgumentInfo = typer.Argument(
  ...,
  exists=True,
  file_okay=True,
  dir_okay=False,
  readable=True,
  writable=False,
  help=('The local input file path, ex: "~/foo/bar/file.png"'),
)

# Frame: the default frame is the one that shows the whole Mandelbrot set, which is centered at
# -0.75+0j and has width 2.5; the height is the same as the width by default;
# The set <https://en.wikipedia.org/wiki/Mandelbrot_set> is contained in the rectangle with corners
# -2.5-1.25j and 0.5+1.25j, which is exactly our default here
FRAME_CENTER_RE_ARGUMENT: typer.models.ArgumentInfo = typer.Argument(
  frame.DEFAULT_FRAME_CENTER_RE,
  help=(
    'Real part of the center point; '
    'this can be a float (ex: "0.34") or a fraction of ints (rational number, ex: "123/451") and '
    'the number will be fed directly to multi-precision arithmetic so no precision is lost; '
    'ALTERNATIVELY: you can use this to input an existing PNG image path, and it will read the '
    "frame from the given image's metadata (overriding/ignoring the other CLI frame parameters!); "
    f'default is {frame.DEFAULT_FRAME_CENTER_RE!r}'
  ),
)
FRAME_CENTER_IM_ARGUMENT: typer.models.ArgumentInfo = typer.Argument(
  frame.DEFAULT_FRAME_CENTER_IM,
  help=(
    'Imaginary part of the center point; '
    'this can be a float (ex: "0.34") or a fraction of ints (rational number, ex: "123/451") and '
    'the number will be fed directly to multi-precision arithmetic so no precision is lost; '
    f'default is {frame.DEFAULT_FRAME_CENTER_IM!r}'
  ),
)
FRAME_WIDTH_ARGUMENT: typer.models.ArgumentInfo = typer.Argument(
  frame.DEFAULT_FRAME_SIZE,
  help=(
    'Width of the frame in the real plane; '
    'this can be a float (ex: "0.34") or a fraction of ints (rational number, ex: "123/451") and '
    'the number will be fed directly to multi-precision arithmetic so no precision is lost; '
    f'default is {frame.DEFAULT_FRAME_SIZE!r}'
  ),
)
FRAME_HEIGHT_ARGUMENT: typer.models.ArgumentInfo = typer.Argument(
  None,
  help=(
    'Height of the frame in the imaginary plane; '
    'this can be a float (ex: "0.34") or a fraction of ints (rational number, ex: "123/451") and '
    'the number will be fed directly to multi-precision arithmetic so no precision is lost; '
    'default is None, i.e, the same as width'
  ),
)

# Computation Options
MAX_ITERATIONS_OPTION: typer.models.OptionInfo = typer.Option(
  None,
  '-i',
  '--iter',
  min=fractal.MIN_ITER,
  max=fractal.MAX_ITER,
  help=(
    'Maximum iterations (depth) to compute before determining escape; '
    f'{fractal.MIN_ITER} ≤ iter ≤ {fractal.MAX_ITER}; '
    f'default is None (automatic search for optimal iterations --- recommended)'
  ),
)
MAX_THREADS_OPTION: typer.models.OptionInfo = typer.Option(
  None,
  '--threads',
  min=1,
  max=fractal.MAX_CONCURRENCE,
  help=(
    'Number of threads to use for rendering; default is None, which means to use all available '
    f'CPU cores; will be limited to {fractal.MAX_CONCURRENCE} threads'
  ),
)
MAX_STEPS_OPTION: typer.models.OptionInfo = typer.Option(
  0,
  '-n',
  '--max-steps',
  min=0,
  help=(
    'Maximum number of zoom steps to run; 0 means run until manually stopped (Ctrl+C); '
    'default is 0 (unlimited, run forever)'
  ),
)

# Color options
PALETTE_OPTION: typer.models.OptionInfo = typer.Option(
  palette.DEFAULT_PALETTE,
  '--palette',
  help=(
    f'Color palette to use for rendering; default is {palette.DEFAULT_PALETTE.value!r}; '
    f'available palettes: {sorted(p.value for p in palette.PALETTES)}'
  ),
)

# AI Options
AI_QUERY_OPTION: typer.models.OptionInfo = typer.Option(
  None,
  '-q',
  '--query',
  help=('Query to be added to the default prompt; default is None, no additional query'),
)
MAX_CHAT_MEMORY_OPTION: typer.models.OptionInfo = typer.Option(
  ai.DEFAULT_MEMORY_SIZE,
  '--memory',
  min=0,
  max=ai.MAX_MEMORY_SIZE,
  help=(
    f'Maximum number of iterations the LLM will remember; 0 ≤ m ≤ {ai.MAX_MEMORY_SIZE}; '
    f'0 (zero) means no memory, every AI call is independent; default is {ai.DEFAULT_MEMORY_SIZE}'
  ),
)
AI_OUTPUT_REASON_FIELD_OPTION: typer.models.OptionInfo = typer.Option(
  False,
  '--reason/--no-reason',
  help=(
    'If True, LLM sector evaluations will include an extra `reason` field for the AI output, '
    'which is great for debugging and understanding the LLM, but is much slower on the LLM; '
    'if False, the field will not be included, which is faster; default is False'
  ),
)


@dataclasses.dataclass(kw_only=True, slots=True, frozen=True)
class TranZoomConfig(clibase.CLIConfig):
  """TranZoom global context, storing the configuration."""

  img_width: int
  img_height: int
  img_output_path: pathlib.Path | None
  img_use_date: bool
  img_use_hash: bool
  img_path_prefix: str
  max_threads: int | None


def MakeFrameFromCLIArgs(
  fractal: frame.Fractal,
  center_re: str,
  center_im: str,
  f_width: str,
  f_height: str | None,
  print_call: abc.Callable[[str], None],
) -> frame.Frame:
  """Make a frame or die. Tries float/mpq first, then tries reading from a file metadata.

  Args:
    fractal: the fractal type to create the frame for
    center_re: the real part of the center, or an image path to read the frame from
    center_im: the imaginary part of the center (ignored if center_re is an image path)
    f_width: the width of the frame (ignored if center_re is an image path)
    f_height: the height of the frame (ignored if center_re is an image path)
    print_call: a callable to print messages, used for logging during frame creation

  Returns:
    A valid frame object

  Raises:
    click.UsageError: if arguments can't be turned into a valid frame
    ValueError: internally (but this is caught and turned into UsageError with a helpful message)

  """
  try:
    # the happy path is one line... if these coords work, we return the frame and we're done
    return frame.Frame.FromCenter(fractal, center_re, center_im, f_width, f_height)
  except ValueError as err:
    if 'invalid' not in str(err).lower():
      raise click.UsageError(f'Error: {center_re=}, {center_im=}, {f_width=}, {f_height=}') from err
    # maybe the user gave us an image path instead of coordinates? let's try to read it as image
    try:
      # convert and validate path
      img_path: pathlib.Path = pathlib.Path(center_re).expanduser().resolve()
      if not img_path.exists() or not img_path.is_file():
        raise ValueError(f'Image "{img_path}" does not exist or is not a file')  # noqa: TRY301
      # make sure we have the needed metadata
      info: tbase.JSONDict = image.GetBasicDataFromPNG(img_path.read_bytes())[-1]
      if (
        image.META_CENTER_RE_KEY not in info
        or image.META_CENTER_IM_KEY not in info
        or image.META_WIDTH_RE_KEY not in info
        or image.META_HEIGHT_IM_KEY not in info
      ):
        raise ValueError(f'Image "{img_path}" missing tranZoom frame metadata keys')  # noqa: TRY301
      version: str = str(info.get(image.META_VERSION_KEY, '')) or 'UNKNOWN'
      fract: str = str(info.get(image.META_FRACTAL_KEY, '')) or 'UNKNOWN'
      print_call(
        f'Reading frame from "{img_path}", [red]tranZoom version {version}[/], {fract} fractal...'
      )
      return frame.Frame.FromCenter(
        fractal,
        str(info[image.META_CENTER_RE_KEY]),
        str(info[image.META_CENTER_IM_KEY]),
        str(info[image.META_WIDTH_RE_KEY]),
        str(info[image.META_HEIGHT_IM_KEY]),
      )
    except Exception as err2:  # this error we cannot forgive
      raise click.UsageError(
        f'Error/not path: {center_re=}, {center_im=}, {f_width=}, {f_height=}'
      ) from err2
  except Exception as err:  # this error we cannot forgive
    raise click.UsageError(f'Error: {center_re=}, {center_im=}, {f_width=}, {f_height=}') from err
