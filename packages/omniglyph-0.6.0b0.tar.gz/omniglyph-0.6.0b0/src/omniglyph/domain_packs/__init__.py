"""Bundled starter domain packs."""
