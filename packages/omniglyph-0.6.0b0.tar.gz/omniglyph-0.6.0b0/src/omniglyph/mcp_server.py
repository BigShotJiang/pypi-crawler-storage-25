import json
import sys
from typing import Any, TextIO

from omniglyph import __version__
from omniglyph.audit import build_audit_event
from omniglyph.code_linter import scan_text
from omniglyph.config import settings
from omniglyph.explanation import explain_code_security, explain_glyph, explain_term
from omniglyph.guardrail import validate_output_terms
from omniglyph.normalization import compact_normalize, normalize_tokens
from omniglyph.repository import GlyphRepository

JSONRPC_VERSION = "2.0"


def build_tools_list() -> list[dict[str, Any]]:
    return [
        {
            "name": "lookup_glyph",
            "description": "Look up a single glyph in the local OmniGlyph symbol fact base.",
            "inputSchema": {
                "type": "object",
                "properties": {"char": {"type": "string", "description": "Exactly one Unicode character to look up."}},
                "required": ["char"],
            },
        },
        {
            "name": "lookup_term",
            "description": "Look up a private or curated lexical/domain term.",
            "inputSchema": {
                "type": "object",
                "properties": {"text": {"type": "string", "description": "Term text or alias to look up."}},
                "required": ["text"],
            },
        },
        {
            "name": "explain_glyph",
            "description": "Explain one Unicode character using the OmniGlyph Explanation Standard.",
            "inputSchema": {
                "type": "object",
                "properties": {"char": {"type": "string", "description": "Exactly one Unicode character to explain."}},
                "required": ["char"],
            },
        },
        {
            "name": "explain_term",
            "description": "Explain a lexical/domain term using the OmniGlyph Explanation Standard.",
            "inputSchema": {
                "type": "object",
                "properties": {"text": {"type": "string", "description": "Term text or alias to explain."}},
                "required": ["text"],
            },
        },
        {
            "name": "explain_code_security",
            "description": "Explain Unicode source-code security findings using the OmniGlyph Explanation Standard.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "Source code text to scan and explain."},
                    "source_name": {"type": "string", "description": "Optional source label for findings."},
                },
                "required": ["text"],
            },
        },
        {
            "name": "normalize_tokens",
            "description": "Normalize glyphs and known domain terms into canonical IDs.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "tokens": {"type": "array", "items": {"type": "string"}},
                    "mode": {"type": "string", "enum": ["full", "compact"]},
                },
                "required": ["tokens"],
            },
        },
        {
            "name": "validate_output_terms",
            "description": "Validate generated output terms against the local fact base.",
            "inputSchema": {
                "type": "object",
                "properties": {"terms": {"type": "array", "items": {"type": "string"}}},
                "required": ["terms"],
            },
        },
        {
            "name": "scan_code_symbols",
            "description": "Scan source code text for invisible Unicode controls and cross-script homoglyph risks.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "Source code text to scan."},
                    "source_name": {"type": "string", "description": "Optional source label for findings."},
                },
                "required": ["text"],
            },
        },
        {
            "name": "scan_unicode_security",
            "description": "Scan source code text with developer-friendly Unicode Security Pack findings.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "Source code text to scan."},
                    "source_name": {"type": "string", "description": "Optional source label for findings."},
                },
                "required": ["text"],
            },
        },
        {
            "name": "audit_explain",
            "description": "Return an OES explanation together with an audit event showing actor, sources, and unknowns.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "actor_id": {"type": "string", "description": "User, service, or agent identifier."},
                    "kind": {"type": "string", "enum": ["glyph", "term", "code"]},
                    "text": {"type": "string", "description": "Glyph, term, or source-code text to explain."},
                    "source_name": {"type": "string", "description": "Optional source label for code explanations."},
                },
                "required": ["actor_id", "kind", "text"],
            },
        },
    ]


def handle_mcp_request(request: dict[str, Any], repository: GlyphRepository | None = None) -> dict[str, Any] | None:
    method = request.get("method")
    request_id = request.get("id")
    glyph_repository = repository or GlyphRepository(settings.sqlite_path)

    if method == "initialize":
        return _result(
            request_id,
            {
                "protocolVersion": "2024-11-05",
                "serverInfo": {"name": "omniglyph", "version": __version__},
                "capabilities": {"tools": {}},
            },
        )

    if method == "notifications/initialized":
        return None

    if method == "tools/list":
        return _result(request_id, {"tools": build_tools_list()})

    if method == "tools/call":
        params = request.get("params") or {}
        tool_name = params.get("name")
        arguments = params.get("arguments") or {}
        if tool_name == "lookup_glyph":
            char = arguments.get("char")
            if not isinstance(char, str) or len(char) != 1:
                return _error(request_id, -32602, "lookup_glyph requires exactly one Unicode character")
            record = glyph_repository.find_by_glyph(char)
            if record is None:
                return _result(request_id, {"content": [{"type": "text", "text": f"Glyph not found: {char}"}], "isError": True})
            return _result(request_id, {"content": [{"type": "json", "json": record}]})

        if tool_name == "lookup_term":
            text = arguments.get("text")
            if not isinstance(text, str) or not text.strip():
                return _error(request_id, -32602, "lookup_term requires non-empty text")
            record = glyph_repository.find_term(text)
            if record is None:
                return _result(request_id, {"content": [{"type": "text", "text": f"Term not found: {text}"}], "isError": True})
            return _result(request_id, {"content": [{"type": "json", "json": record}]})

        if tool_name == "explain_glyph":
            char = arguments.get("char")
            if not isinstance(char, str) or len(char) != 1:
                return _error(request_id, -32602, "explain_glyph requires exactly one Unicode character")
            return _result(request_id, {"content": [{"type": "json", "json": explain_glyph(glyph_repository, char)}]})

        if tool_name == "explain_term":
            text = arguments.get("text")
            if not isinstance(text, str) or not text.strip():
                return _error(request_id, -32602, "explain_term requires non-empty text")
            return _result(request_id, {"content": [{"type": "json", "json": explain_term(glyph_repository, text)}]})

        if tool_name == "explain_code_security":
            text = arguments.get("text")
            source_name = arguments.get("source_name", "<mcp-text>")
            if not isinstance(text, str):
                return _error(request_id, -32602, "explain_code_security requires source code text")
            if not isinstance(source_name, str) or not source_name.strip():
                return _error(request_id, -32602, "explain_code_security source_name must be a string")
            return _result(request_id, {"content": [{"type": "json", "json": explain_code_security(text, source_name=source_name)}]})

        if tool_name == "normalize_tokens":
            tokens = arguments.get("tokens")
            mode = arguments.get("mode", "full")
            if not isinstance(tokens, list) or not all(isinstance(item, str) for item in tokens):
                return _error(request_id, -32602, "normalize_tokens requires a list of string tokens")
            results = normalize_tokens(glyph_repository, tokens)
            payload = compact_normalize(results) if mode == "compact" else {"results": results}
            return _result(request_id, {"content": [{"type": "json", "json": payload}]})

        if tool_name == "validate_output_terms":
            terms = arguments.get("terms")
            if not isinstance(terms, list) or not all(isinstance(item, str) for item in terms):
                return _error(request_id, -32602, "validate_output_terms requires a list of string terms")
            return _result(request_id, {"content": [{"type": "json", "json": validate_output_terms(glyph_repository, terms)}]})

        if tool_name == "scan_code_symbols":
            text = arguments.get("text")
            source_name = arguments.get("source_name", "<mcp-text>")
            if not isinstance(text, str):
                return _error(request_id, -32602, "scan_code_symbols requires source code text")
            if not isinstance(source_name, str) or not source_name.strip():
                return _error(request_id, -32602, "scan_code_symbols source_name must be a string")
            return _result(request_id, {"content": [{"type": "json", "json": scan_text(text, source_name=source_name)}]})

        if tool_name == "scan_unicode_security":
            text = arguments.get("text")
            source_name = arguments.get("source_name", "<mcp-text>")
            if not isinstance(text, str):
                return _error(request_id, -32602, "scan_unicode_security requires source code text")
            if not isinstance(source_name, str) or not source_name.strip():
                return _error(request_id, -32602, "scan_unicode_security source_name must be a string")
            return _result(request_id, {"content": [{"type": "json", "json": scan_text(text, source_name=source_name)}]})

        if tool_name == "audit_explain":
            actor_id = arguments.get("actor_id")
            kind = arguments.get("kind")
            text = arguments.get("text")
            source_name = arguments.get("source_name", "<mcp-text>")
            if not isinstance(actor_id, str) or not actor_id.strip():
                return _error(request_id, -32602, "audit_explain requires actor_id")
            if not isinstance(kind, str) or kind not in {"glyph", "term", "code"}:
                return _error(request_id, -32602, "audit_explain kind must be glyph, term, or code")
            if not isinstance(text, str) or not text.strip():
                return _error(request_id, -32602, "audit_explain requires text")
            if kind == "glyph" and len(text) != 1:
                return _error(request_id, -32602, "audit_explain glyph text must contain exactly one Unicode character")
            if not isinstance(source_name, str) or not source_name.strip():
                return _error(request_id, -32602, "audit_explain source_name must be a string")
            result, action = _explain_for_audit(glyph_repository, kind, text, source_name)
            return _result(request_id, {"content": [{"type": "json", "json": {"result": result, "audit": build_audit_event(actor_id, action, result)}}]})

        return _error(request_id, -32601, f"Unknown tool: {tool_name}")

    return _error(request_id, -32601, f"Unknown method: {method}")


def serve_stdio(input_stream: TextIO = sys.stdin, output_stream: TextIO = sys.stdout) -> None:
    for line in input_stream:
        if not line.strip():
            continue
        try:
            request = json.loads(line)
            response = handle_mcp_request(request)
        except json.JSONDecodeError as exc:
            response = _error(None, -32700, f"Parse error: {exc.msg}")
        except Exception as exc:  # pragma: no cover - defensive stdio server boundary
            response = _error(None, -32603, f"Internal error: {exc}")
        if response is not None:
            output_stream.write(json.dumps(response, ensure_ascii=False) + "\n")
            output_stream.flush()


def main() -> None:
    serve_stdio()


def _result(request_id: Any, result: dict[str, Any]) -> dict[str, Any]:
    return {"jsonrpc": JSONRPC_VERSION, "id": request_id, "result": result}


def _error(request_id: Any, code: int, message: str) -> dict[str, Any]:
    return {"jsonrpc": JSONRPC_VERSION, "id": request_id, "error": {"code": code, "message": message}}


def _explain_for_audit(repository: GlyphRepository, kind: str, text: str, source_name: str) -> tuple[dict, str]:
    if kind == "glyph":
        if len(text) != 1:
            raise ValueError("audit_explain glyph text must contain exactly one Unicode character")
        return explain_glyph(repository, text), "explain_glyph"
    if kind == "term":
        return explain_term(repository, text), "explain_term"
    return explain_code_security(text, source_name=source_name), "explain_code_security"

if __name__ == "__main__":
    main()
