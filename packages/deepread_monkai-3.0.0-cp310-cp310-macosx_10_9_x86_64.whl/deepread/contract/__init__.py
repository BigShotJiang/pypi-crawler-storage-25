# deepread/contract/__init__.py
"""
DeepRead Contract — Validação de documentos e contratos parametrizada por país.

Opt-in subpackage. Instalar via: pip install DeepRead.Monkai[contract]

Uso:
    from deepread.contract import ContractChecker
    checker = ContractChecker(country="BR", api_token="...")
    resultado = checker.verificar("contrato.pdf")
"""

from deepread.contract.exceptions import UnsupportedCountryError
from deepread.contract.registry import get_adapter, list_countries
from deepread.contract.base import CountryAdapter
from deepread.contract.checker import ContractChecker

# Trigger registration of built-in country adapters (side-effect import)
from deepread.contract.countries import br as _br  # noqa: F401

__all__ = [
    "ContractChecker",
    "CountryAdapter",
    "UnsupportedCountryError",
    "get_adapter",
    "list_countries",
]
