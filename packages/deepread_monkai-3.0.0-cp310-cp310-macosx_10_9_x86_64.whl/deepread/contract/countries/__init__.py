# deepread/contract/countries/__init__.py
"""Country-specific adapters for contract validation."""
