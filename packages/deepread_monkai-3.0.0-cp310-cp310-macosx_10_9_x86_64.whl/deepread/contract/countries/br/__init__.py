# deepread/contract/countries/br/__init__.py
"""Brazil (BR) contract validation adapter and utilities."""

from deepread.contract.countries.br.keywords import (
    KEYWORDS_VALIDACAO,
    KEYWORDS_EXCLUSAO,
    MIN_KEYWORDS,
    validar_documento_contrato,
)
from deepread.contract.countries.br.cnpj import (
    consultar_cnpj,
    validar_cnpj,
    formatar_cnpj,
    limpar_cnpj,
    buscar_cnpj_por_nome,
    buscar_empresa,
    buscar_empresa_completo,
    comparar_enderecos,
)
from deepread.contract.countries.br.adapter import BRAdapter

# Self-registration on import
from deepread.contract.registry import register as _register
_register("BR", BRAdapter)

__all__ = [
    "BRAdapter",
    "KEYWORDS_VALIDACAO",
    "KEYWORDS_EXCLUSAO",
    "MIN_KEYWORDS",
    "validar_documento_contrato",
    "consultar_cnpj",
    "validar_cnpj",
    "formatar_cnpj",
    "limpar_cnpj",
    "buscar_cnpj_por_nome",
    "buscar_empresa",
    "buscar_empresa_completo",
    "comparar_enderecos",
]
