import os, base64
from fmconsult.http.api import ApiBase

class SintegraWSApi(ApiBase):

    def __init__(self):
        try:
            self.api_token = os.environ['sintegraws.api.token']
            self.base_url = 'https://www.sintegraws.com.br/api'
            self.headers = {}
        except:
            raise