import logging, jsonpickle
from http import HTTPMethod
from fmconsult.utils.url import UrlUtil
from sintegraws.api import SintegraWSApi

class CNPJApi(SintegraWSApi):
    def __init__(self):
        super().__init__()
        self.endpoint_url = UrlUtil().make_url(SintegraWSApi().base_url, ['v1', 'execute-api.php'])
    
    def consultar(self, cnpj):
        logging.info(f'consulting CNPJ: {cnpj}')
        
        params = {
            'token': self.api_token,
            'plugin': 'RF',
            'cnpj': cnpj
        }
        
        res = self.call_request(HTTPMethod.GET, self.endpoint_url, params=params)
        
        return jsonpickle.decode(res)