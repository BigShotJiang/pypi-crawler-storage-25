from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import secrets
import time
from pathlib import Path
from typing import Any, TYPE_CHECKING
from urllib.parse import urlparse, urlunparse

import aiohttp
import websockets
from cryptography import x509
from cryptography.x509 import ocsp
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed25519

from .crypto import CryptoProvider
from .errors import AuthError, ConnectionError, StateError, ValidationError, map_remote_error, AUNError
from .keystore.file import FileKeyStore

if TYPE_CHECKING:
    from .logger import AUNLogger, NullLogger


def _verify_signature(public_key: Any, sig_bytes: bytes, data_bytes: bytes) -> None:
    if isinstance(public_key, ed25519.Ed25519PublicKey):
        public_key.verify(sig_bytes, data_bytes)
        return
    if isinstance(public_key, ec.EllipticCurvePublicKey):
        if isinstance(public_key.curve, ec.SECP384R1):
            public_key.verify(sig_bytes, data_bytes, ec.ECDSA(hashes.SHA384()))
        else:
            public_key.verify(sig_bytes, data_bytes, ec.ECDSA(hashes.SHA256()))
        return
    raise AuthError(f"unsupported identity public key type: {type(public_key)!r}")


class AuthFlow:
    _INSTANCE_STATE_FIELDS = (
        "access_token",
        "refresh_token",
        "kite_token",
        "access_token_expires_at",
    )

    def __init__(
        self,
        *,
        keystore: FileKeyStore,
        crypto: CryptoProvider,
        aid: str | None = None,
        device_id: str = "",
        slot_id: str = "",
        connection_factory=None,
        root_ca_path: str | None = None,
        chain_cache_ttl: int = 86400,
        verify_ssl: bool = False,
        logger: "AUNLogger | NullLogger | None" = None,
    ) -> None:
        from .logger import NullLogger as _NL
        self._log = logger or _NL()
        self._keystore = keystore
        self._crypto = crypto
        self._aid = aid
        self._device_id = str(device_id or "").strip()
        self._slot_id = str(slot_id or "").strip()
        self._connection_factory = connection_factory or self._default_connection_factory
        self._root_ca_path = root_ca_path
        self._verify_ssl = verify_ssl
        self._root_certs = self._load_root_certs(root_ca_path, keystore=keystore)
        self._gateway_chain_cache: dict[str, list[str]] = {}
        self._gateway_crl_cache: dict[str, dict[str, Any]] = {}
        self._gateway_ocsp_cache: dict[str, dict[str, dict[str, Any]]] = {}
        # 证书链验证结果缓存：cert_serial -> verified_at
        self._chain_verified_cache: dict[str, float] = {}
        self._chain_cache_ttl = chain_cache_ttl
        # Gateway CA 链预验证标记：gateway_url -> verified
        self._gateway_ca_verified: dict[str, bool] = {}

    def load_identity(self, aid: str | None = None) -> dict[str, Any]:
        identity = self._load_identity_or_raise(aid)
        cert = self._keystore.load_cert(identity["aid"])
        if cert:
            identity["cert"] = cert
        instance_state = self._load_instance_state(identity["aid"])
        if isinstance(instance_state, dict):
            identity.update(instance_state)
        return identity

    def load_identity_or_none(self, aid: str | None = None) -> dict[str, Any] | None:
        try:
            return self.load_identity(aid)
        except StateError:
            return None

    def get_access_token_expiry(self, identity: dict[str, Any]) -> float | None:
        expires_at = identity.get("access_token_expires_at")
        if isinstance(expires_at, (int, float)):
            return float(expires_at)
        return None

    def set_instance_context(self, *, device_id: str, slot_id: str = "") -> None:
        self._device_id = str(device_id or "").strip()
        self._slot_id = str(slot_id or "").strip()

    async def create_aid(self, gateway_url: str, aid: str) -> dict[str, Any]:
        _t_start = time.time()
        self._validate_aid_name(aid)
        self._log.debug("auth", "create_aid enter: aid=%s gateway=%s", aid, gateway_url)
        try:
            identity = self._ensure_local_identity(aid)
            if identity.get("cert"):
                self._log.debug("auth", "local cert exists, syncing server state: aid=%s", aid)
                identity = await self._sync_existing_identity_cert(gateway_url, identity)
                self._persist_identity(identity)
                self._aid = identity["aid"]
                self._log.debug("auth", "create_aid exit (synced): elapsed=%.3fs aid=%s", time.time() - _t_start, identity["aid"])
                return {"aid": identity["aid"], "cert": identity["cert"]}

            # 本地有密钥但无证书 — 可能是上次 create_aid 网络失败后的残留状态，
            # 也可能是服务端已注册但本地证书丢失。两种情况都先尝试注册。
            try:
                created = await self._create_aid(gateway_url, identity)
                identity.update(created)
            except AUNError as e:
                if "already exists" not in str(e):
                    self._log.warn("auth", "create_aid registration failed: aid=%s err=%s", aid, e)
                    raise
                # AID 已在服务端注册，本地有密钥但证书丢失。
                # 通过 HTTP PKI 端点下载已注册的证书，验证公钥匹配后恢复。
                self._log.debug("auth", "AID already exists, attempting cert download recovery: aid=%s", aid)
                try:
                    identity = await self._recover_cert_via_download(gateway_url, identity)
                except Exception:
                    self._log.warn("auth", "cert download recovery failed: aid=%s", aid)
                    raise StateError(
                        f"AID {aid} already registered on server but local certificate is missing. "
                        f"Certificate download recovery failed. Options: "
                        f"(1) use a different AID name, or "
                        f"(2) restart Kite server to clear registration."
                    ) from e
            self._persist_identity(identity)
            self._aid = identity["aid"]
            self._log.debug("auth", "create_aid exit: elapsed=%.3fs aid=%s", time.time() - _t_start, identity["aid"])
            return {"aid": identity["aid"], "cert": identity["cert"]}
        except Exception as exc:
            self._log.debug("auth", "create_aid exit (error): elapsed=%.3fs aid=%s err=%s", time.time() - _t_start, aid, exc)
            raise

    async def _sync_existing_identity_cert(self, gateway_url: str, identity: dict[str, Any]) -> dict[str, Any]:
        """本地已有 cert 时，校准服务端登记状态并必要时补签恢复。"""
        cert_pem = await self._download_registered_cert(gateway_url, identity["aid"])
        if cert_pem is None:
            created = await self._create_aid(gateway_url, identity)
            identity["cert"] = created["cert"]
            return identity

        cert = x509.load_pem_x509_certificate(cert_pem.encode("utf-8"))
        cert_pub_der = cert.public_key().public_bytes(
            serialization.Encoding.DER,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        local_pub_der = base64.b64decode(identity["public_key_der_b64"])
        if cert_pub_der != local_pub_der:
            raise StateError(
                f"local identity key does not match server certificate for {identity['aid']}. "
                f"This is a dirty data conflict and must be repaired manually."
            )
        identity["cert"] = cert_pem
        return identity

    async def _recover_cert_via_download(self, gateway_url: str, identity: dict[str, Any]) -> dict[str, Any]:
        """本地有密钥但无证书、服务端已注册 — 通过 PKI HTTP 端点下载证书恢复。"""
        cert_pem = await self._download_registered_cert(gateway_url, identity["aid"])
        if not cert_pem:
            raise AuthError(f"failed to download certificate for {identity['aid']}")

        # 验证下载的证书公钥与本地密钥对匹配
        cert = x509.load_pem_x509_certificate(cert_pem.encode("utf-8"))
        cert_pub_der = cert.public_key().public_bytes(
            serialization.Encoding.DER,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        local_pub_der = base64.b64decode(identity["public_key_der_b64"])
        if cert_pub_der != local_pub_der:
            raise AuthError(
                f"downloaded certificate public key does not match local key pair for {identity['aid']}. "
                f"The server has a different key registered — this AID cannot be recovered with the current key."
            )

        identity["cert"] = cert_pem
        return identity

    async def _download_registered_cert(self, gateway_url: str, aid: str) -> str | None:
        """下载服务端当前登记的证书；404 视为未登记，其它错误抛异常。"""
        cert_url = self._gateway_http_url(gateway_url, f"/pki/cert/{aid}")
        try:
            timeout = aiohttp.ClientTimeout(total=5.0)
            ssl_param = None if self._verify_ssl else False
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(cert_url, ssl=ssl_param) as response:
                    if response.status == 404:
                        return None
                    response.raise_for_status()
                    cert_pem = await response.text()
        except Exception as exc:
            raise AuthError(f"failed to fetch {cert_url}") from exc

        if "BEGIN CERTIFICATE" not in cert_pem:
            raise AuthError(f"invalid certificate payload from {cert_url}")
        return cert_pem

    async def authenticate(self, gateway_url: str, *, aid: str | None = None) -> dict[str, Any]:
        _t_start = time.time()
        identity = self._load_identity_or_raise(aid)
        self._log.debug("auth", "authenticate enter: aid=%s gateway=%s", identity.get("aid"), gateway_url)
        try:
            # 优先复用 keystore 里的 cached access_token（未过期且有 refresh_token）
            # 避免每次调 authenticate 都走两阶段重登的网络往返
            # 注意：_load_identity_or_raise 不带 instance_state（access_token 等），
            # 这里需要主动走 load_instance_state 拿到 token
            instance_state = self._load_instance_state(identity["aid"]) or {}
            identity_with_state = {**identity, **instance_state}
            cached_token = self._get_cached_access_token(identity_with_state)
            cached_refresh = str(identity_with_state.get("refresh_token") or "")
            if cached_token and cached_refresh:
                self._log.debug("auth", "authenticate reusing cached token: aid=%s expires_at=%s",
                                identity["aid"], identity_with_state.get("access_token_expires_at"))
                self._aid = identity["aid"]
                return {
                    "aid": identity["aid"],
                    "access_token": cached_token,
                    "refresh_token": cached_refresh,
                    "expires_at": identity_with_state.get("access_token_expires_at"),
                    "gateway": gateway_url,
                }

            if not identity.get("cert"):
                # 本地有密钥但无证书 — 尝试从 PKI 下载恢复
                self._log.debug("auth", "no local cert, attempting PKI download recovery: aid=%s", identity.get("aid"))
                try:
                    identity = await self._recover_cert_via_download(gateway_url, identity)
                    self._persist_identity(identity)
                except Exception as e:
                    self._log.warn("auth", "cert recovery failed: aid=%s err=%s", identity.get("aid"), e)
                    raise StateError(
                        f"local certificate missing and recovery failed: {e}. "
                        f"Run auth.create_aid() to register a new identity."
                    ) from e
            try:
                login = await self._login(gateway_url, identity)
            except AuthError as e:
                if "not registered" in str(e):
                    self._log.warn("auth", "cert not registered on server, auto re-registering: aid=%s", identity["aid"])
                    created = await self._create_aid(gateway_url, identity)
                    identity["cert"] = created["cert"]
                    self._persist_identity(identity)
                    login = await self._login(gateway_url, identity)
                else:
                    self._log.warn("auth", "auth failed: aid=%s err=%s", identity.get("aid"), e)
                    raise
            self._remember_tokens(identity, login)
            await self._validate_new_cert(identity, gateway_url)
            self._persist_identity(identity)
            self._aid = identity["aid"]
            self._log.debug("auth", "authenticate exit: elapsed=%.3fs aid=%s expires_at=%s", time.time() - _t_start, identity["aid"], identity.get("access_token_expires_at"))
            return {
                "aid": identity["aid"],
                "access_token": identity.get("access_token"),
                "refresh_token": identity.get("refresh_token"),
                "expires_at": identity.get("access_token_expires_at"),
                "gateway": gateway_url,
            }
        except Exception as exc:
            self._log.debug("auth", "authenticate exit (error): elapsed=%.3fs aid=%s err=%s", time.time() - _t_start, identity.get("aid"), exc)
            raise

    async def ensure_authenticated(self, gateway_url: str) -> dict[str, Any]:
        identity = self._ensure_identity()
        if not identity.get("cert"):
            created = await self._create_aid(gateway_url, identity)
            identity.update(created)
            self._persist_identity(identity)

        login = await self._login(gateway_url, identity)
        self._remember_tokens(identity, login)
        await self._validate_new_cert(identity, gateway_url)
        self._persist_identity(identity)

        token = identity.get("access_token") or identity.get("token") or identity.get("kite_token")
        if not token:
            raise AuthError("login2 did not return access token")
        return {"token": token, "identity": identity}

    async def refresh_cached_tokens(self, gateway_url: str, identity: dict[str, Any]) -> dict[str, Any]:
        _t_start = time.time()
        refresh_token = str(identity.get("refresh_token") or "")
        if not refresh_token:
            self._log.warn("auth", "token refresh failed: missing refresh_token aid=%s", identity.get("aid"))
            raise AuthError("missing refresh_token")
        self._log.debug("auth", "refresh_cached_tokens enter: aid=%s gateway=%s", identity.get("aid"), gateway_url)
        try:
            refreshed = await self._refresh_access_token(gateway_url, refresh_token)
            self._remember_tokens(identity, refreshed)
            await self._validate_new_cert(identity, gateway_url)
            self._persist_identity(identity)
            self._log.debug("auth", "refresh_cached_tokens exit: elapsed=%.3fs aid=%s", time.time() - _t_start, identity.get("aid"))
            return identity
        except Exception as exc:
            self._log.debug("auth", "refresh_cached_tokens exit (error): elapsed=%.3fs aid=%s err=%s", time.time() - _t_start, identity.get("aid"), exc)
            raise

    async def initialize_with_token(
        self,
        transport,
        challenge: dict[str, Any] | None,
        access_token: str,
        *,
        device_id: str = "",
        slot_id: str = "",
        delivery_mode: dict[str, Any] | None = None,
        connection_kind: str = "long",
        short_ttl_ms: int = 0,
        extra_info: dict[str, Any] | None = None,
    ) -> None:
        nonce = challenge.get("params", {}).get("nonce", "")
        if not nonce:
            self._log.warn("auth", "challenge missing nonce, cannot initialize session")
            raise AuthError("gateway challenge missing nonce")
        self._log.debug("auth", "initializing session with token: device_id=%s slot_id=%s kind=%s",
                        device_id, slot_id, connection_kind)
        self.set_instance_context(device_id=device_id, slot_id=slot_id)
        await self._initialize_session(
            transport,
            nonce,
            access_token,
            device_id=device_id,
            slot_id=slot_id,
            delivery_mode=delivery_mode,
            connection_kind=connection_kind,
            short_ttl_ms=short_ttl_ms,
            extra_info=extra_info,
        )

    async def connect_session(
        self,
        transport,
        challenge: dict[str, Any] | None,
        gateway_url: str,
        *,
        access_token: str | None = None,
        device_id: str = "",
        slot_id: str = "",
        delivery_mode: dict[str, Any] | None = None,
        connection_kind: str = "long",
        short_ttl_ms: int = 0,
        extra_info: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        _t_start = time.time()
        nonce = challenge.get("params", {}).get("nonce", "")
        if not nonce:
            self._log.warn("auth", "connect_session: challenge missing nonce")
            raise AuthError("gateway challenge missing nonce")
        self._log.debug("auth", "connect_session enter: gateway=%s device_id=%s has_token=%s",
                        gateway_url, device_id, bool(access_token))
        self.set_instance_context(device_id=device_id, slot_id=slot_id)

        try:
            identity = self.load_identity()
        except StateError:
            identity = None

        explicit_token = str(access_token or "")
        if explicit_token and identity is not None:
            try:
                await self._initialize_session(
                    transport,
                    nonce,
                    explicit_token,
                    device_id=device_id,
                    slot_id=slot_id,
                    delivery_mode=delivery_mode,
                    connection_kind=connection_kind,
                    short_ttl_ms=short_ttl_ms,
                )
                identity["access_token"] = explicit_token
                self._persist_identity(identity)
                self._log.debug("auth", "connect_session exit (explicit_token): elapsed=%.3fs aid=%s", time.time() - _t_start, identity.get("aid"))
                return {"token": explicit_token, "identity": identity}
            except (AuthError, ConnectionError, AUNError) as exc:
                self._log.debug("auth", "explicit_token auth failed, trying next method: %s", exc)
                # transport 被 Gateway 关闭（4001）时，后续 fallback 无法使用同一连接，
                # 直接向上抛出让 _reconnect_loop 重新建立连接后再走完整 fallback 链
                if getattr(transport, "_closed", False):
                    self._log.debug("auth", "connect_session exit (transport closed): elapsed=%.3fs", time.time() - _t_start)
                    raise ConnectionError(
                        f"transport closed during auth fallback: {exc}"
                    ) from exc

        if identity is None:
            auth_context = await self.ensure_authenticated(gateway_url)
            token = auth_context["token"]
            await self._initialize_session(
                transport,
                nonce,
                token,
                device_id=device_id,
                slot_id=slot_id,
                delivery_mode=delivery_mode,
                connection_kind=connection_kind,
                short_ttl_ms=short_ttl_ms,
            )
            self._log.debug("auth", "connect_session exit (new identity): elapsed=%.3fs", time.time() - _t_start)
            return auth_context

        cached_token = self._get_cached_access_token(identity)
        if cached_token:
            try:
                await self._initialize_session(
                    transport,
                    nonce,
                    cached_token,
                    device_id=device_id,
                    slot_id=slot_id,
                    delivery_mode=delivery_mode,
                    connection_kind=connection_kind,
                    short_ttl_ms=short_ttl_ms,
                )
                self._log.debug("auth", "connect_session exit (cached_token): elapsed=%.3fs aid=%s", time.time() - _t_start, identity.get("aid"))
                return {"token": cached_token, "identity": identity}
            except (AuthError, ConnectionError, AUNError) as exc:
                self._log.debug("auth", "cached_token auth failed, trying refresh: %s", exc)
                if getattr(transport, "_closed", False):
                    self._log.debug("auth", "connect_session exit (transport closed): elapsed=%.3fs", time.time() - _t_start)
                    raise ConnectionError(
                        f"transport closed during auth fallback: {exc}"
                    ) from exc

        refresh_token = str(identity.get("refresh_token") or "")
        if refresh_token:
            try:
                identity = await self.refresh_cached_tokens(gateway_url, identity)
                cached_token = self._get_cached_access_token(identity)
                if cached_token:
                    await self._initialize_session(
                        transport,
                        nonce,
                        cached_token,
                        device_id=device_id,
                        slot_id=slot_id,
                        delivery_mode=delivery_mode,
                        connection_kind=connection_kind,
                        short_ttl_ms=short_ttl_ms,
                    )
                    self._log.debug("auth", "connect_session exit (refreshed_token): elapsed=%.3fs aid=%s", time.time() - _t_start, identity.get("aid"))
                    return {"token": cached_token, "identity": identity}
            except (AuthError, ConnectionError, AUNError) as exc:
                self._log.debug("auth", "refresh_token auth failed, will re-login: %s", exc)
                if getattr(transport, "_closed", False):
                    self._log.debug("auth", "connect_session exit (transport closed): elapsed=%.3fs", time.time() - _t_start)
                    raise ConnectionError(
                        f"transport closed during auth fallback: {exc}"
                    ) from exc

        login = await self.authenticate(gateway_url, aid=identity.get("aid"))
        token = str(login.get("access_token") or "")
        if not token:
            raise AuthError("authenticate did not return access_token")
        await self._initialize_session(
            transport,
            nonce,
            token,
            device_id=device_id,
            slot_id=slot_id,
            delivery_mode=delivery_mode,
            connection_kind=connection_kind,
            short_ttl_ms=short_ttl_ms,
            extra_info=extra_info,
        )
        identity = self.load_identity(identity.get("aid"))
        self._log.debug("auth", "connect_session exit (re-login): elapsed=%.3fs aid=%s", time.time() - _t_start, identity.get("aid"))
        return {"token": token, "identity": identity}

    async def _initialize_session(
        self,
        transport,
        nonce: str,
        token: str,
        *,
        device_id: str = "",
        slot_id: str = "",
        delivery_mode: dict[str, Any] | None = None,
        connection_kind: str = "long",
        short_ttl_ms: int = 0,
        extra_info: dict[str, Any] | None = None,
    ) -> None:
        # The SDK lifecycle concept is "initialize(token)"; the gateway currently
        # serves it through its internal auth.connect entrypoint.
        request = {
            "nonce": nonce,
            "auth": {"method": "kite_token", "token": token},
            "protocol": {"min": "1.0", "max": "1.0"},
            "device": {"id": str(device_id or ""), "type": "sdk"},
            "client": {"slot_id": str(slot_id or "")},
            "delivery_mode": delivery_mode or {"mode": "fanout"},
            "capabilities": {
                "e2ee": True,
                "group_e2ee": True,
            },
        }
        # extra_info：应用层自定义信息（PID/HOME/备注等），踢人时透传给被踢方
        if extra_info:
            request["extra_info"] = extra_info
        # 长短连接选项：默认 long 时不写入 options（保持 wire 兼容）
        if connection_kind == "short":
            options: dict[str, Any] = {"kind": "short"}
            if int(short_ttl_ms or 0) > 0:
                options["short_ttl_ms"] = int(short_ttl_ms)
            request["options"] = options
        self._log.debug(
            "auth", "auth.connect send: device_id=%s slot_id=%s kind=%s",
            device_id, slot_id, connection_kind,
        )
        result = await transport.call("auth.connect", request)
        status = (result or {}).get("status")
        if status != "ok":
            self._log.warn("auth", "auth.connect failed: status=%s result=%s", status, result)
            raise AuthError(f"initialize failed: {result}")
        self._log.debug("auth", "auth.connect success")

    async def _create_aid(self, gateway_url: str, identity: dict[str, Any]) -> dict[str, Any]:
        response = await self._short_rpc(gateway_url, "auth.create_aid", {
            "aid": identity["aid"],
            "public_key": identity["public_key_der_b64"],
            "curve": identity.get("curve", "P-256"),
        })
        return {"cert": response["cert"]}

    async def _login(self, gateway_url: str, identity: dict[str, Any]) -> dict[str, Any]:
        _t_start = time.time()
        self._log.debug("auth", "_login enter (login1): aid=%s gateway=%s", identity["aid"], gateway_url)
        try:
            client_nonce = self._crypto.new_client_nonce()
            phase1 = await self._short_rpc(gateway_url, "auth.aid_login1", {
                "aid": identity["aid"],
                "cert": identity["cert"],
                "client_nonce": client_nonce,
            })
            self._log.debug("auth", "login1 done, verifying server response: aid=%s request_id=%s", identity["aid"], phase1.get("request_id"))
            await self._verify_phase1_response(gateway_url, phase1, client_nonce)
            self._log.debug("auth", "_login (login2 start): aid=%s request_id=%s", identity["aid"], phase1["request_id"])
            signature, client_time = self._crypto.sign_login_nonce(identity["private_key_pem"], phase1["nonce"])
            phase2 = await self._short_rpc(gateway_url, "auth.aid_login2", {
                "aid": identity["aid"],
                "request_id": phase1["request_id"],
                "nonce": phase1["nonce"],
                "client_time": client_time,
                "signature": signature,
            })
            self._log.debug("auth", "_login exit: elapsed=%.3fs aid=%s has_token=%s has_refresh=%s",
                            time.time() - _t_start, identity["aid"],
                            bool(phase2.get("access_token") or phase2.get("token")),
                            bool(phase2.get("refresh_token")))
            return phase2
        except Exception as exc:
            self._log.debug("auth", "_login exit (error): elapsed=%.3fs aid=%s err=%s", time.time() - _t_start, identity.get("aid"), exc)
            raise

    async def _refresh_access_token(self, gateway_url: str, refresh_token: str) -> dict[str, Any]:
        _t_start = time.time()
        self._log.debug("auth", "_refresh_access_token enter: gateway=%s", gateway_url)
        try:
            result = await self._short_rpc(gateway_url, "auth.refresh_token", {
                "refresh_token": refresh_token,
            })
            if not result.get("success"):
                self._log.warn("auth", "_refresh_access_token exit (server-failed): elapsed=%.3fs err=%s", time.time() - _t_start, result.get("error", "refresh failed"))
                raise AuthError(str(result.get("error", "refresh failed")))
            self._log.debug("auth", "_refresh_access_token exit: elapsed=%.3fs has_token=%s expires_in=%s",
                            time.time() - _t_start, bool(result.get("access_token")), result.get("expires_in"))
            return result
        except Exception as exc:
            self._log.debug("auth", "_refresh_access_token exit (error): elapsed=%.3fs err=%s", time.time() - _t_start, exc)
            raise

    async def _short_rpc(self, gateway_url: str, method: str, params: dict[str, Any]) -> dict[str, Any]:
        _SHORT_RPC_TIMEOUT = 15.0  # 单次 recv 超时（秒）
        ws = await self._connection_factory(gateway_url)
        try:
            # 握手帧接收
            try:
                await asyncio.wait_for(ws.recv(), timeout=_SHORT_RPC_TIMEOUT)
            except asyncio.TimeoutError:
                raise ConnectionError(
                    f"gateway {gateway_url} handshake recv timeout ({_SHORT_RPC_TIMEOUT}s)"
                )
            await ws.send(json.dumps({
                "jsonrpc": "2.0",
                "id": f"pre-{method}",
                "method": method,
                "params": params,
            }))
            # RPC 响应接收
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=_SHORT_RPC_TIMEOUT)
            except asyncio.TimeoutError:
                raise ConnectionError(
                    f"gateway {gateway_url} RPC recv timeout for {method} ({_SHORT_RPC_TIMEOUT}s)"
                )
            message = raw if isinstance(raw, dict) else json.loads(raw)
        finally:
            await ws.close()

        if "error" in message:
            raise map_remote_error(message["error"])
        result = message.get("result")
        if not isinstance(result, dict):
            raise ValidationError(f"invalid pre-auth response for {method}")
        if result.get("success") is False:
            raise AuthError(str(result.get("error", f"{method} failed")))
        return result

    async def _verify_phase1_response(self, gateway_url: str, result: dict[str, Any], client_nonce: str) -> None:
        auth_cert_pem = str(result.get("auth_cert") or "")
        signature_b64 = str(result.get("client_nonce_signature") or "")
        if not auth_cert_pem:
            raise AuthError("aid_login1 missing auth_cert")
        if not signature_b64:
            raise AuthError("aid_login1 missing client_nonce_signature")

        try:
            auth_cert = x509.load_pem_x509_certificate(auth_cert_pem.encode("utf-8"))
        except Exception as exc:
            raise AuthError("aid_login1 returned invalid auth_cert") from exc

        await self._verify_auth_cert_chain(gateway_url, auth_cert)
        try:
            await self._verify_auth_cert_revocation(gateway_url, auth_cert)
        except AuthError as _crl_exc:
            if "revoked" in str(_crl_exc).lower():
                raise
            self._log.warn("auth", "CRL check unavailable, degrading gracefully: %s", _crl_exc)
        try:
            await self._verify_auth_cert_ocsp(gateway_url, auth_cert)
        except AuthError as _ocsp_exc:
            if "revoked" in str(_ocsp_exc).lower():
                raise
            self._log.warn("auth", "OCSP check unavailable, degrading gracefully: %s", _ocsp_exc)

        try:
            signature = base64.b64decode(signature_b64)
            _verify_signature(auth_cert.public_key(), signature, client_nonce.encode("utf-8"))
        except (ValueError, InvalidSignature, AuthError) as exc:
            raise AuthError("aid_login1 server auth signature verification failed") from exc

    async def _verify_auth_cert_chain(self, gateway_url: str, auth_cert: x509.Certificate, chain_aid: str = "") -> None:
        # 检查缓存：已验证过且未过期则跳过
        cert_serial = format(auth_cert.serial_number, "x")
        cached_at = self._chain_verified_cache.get(cert_serial)
        if cached_at and time.time() - cached_at < self._chain_cache_ttl:
            return

        now = time.time()
        self._ensure_cert_time_valid(auth_cert, "auth certificate", now)

        chain = await self._load_gateway_ca_chain(gateway_url, chain_aid)

        if not chain:
            raise AuthError("unable to verify auth certificate chain: missing CA chain")

        # 如果 CA 链已通过完整验证（含受信根锚定），走快速路径：只验 auth_cert → Issuer
        cache_key = f"{gateway_url}:{chain_aid}" if chain_aid else gateway_url
        if self._gateway_ca_verified.get(cache_key):
            issuer = chain[0]
            self._ensure_cert_time_valid(issuer, "Issuer CA", now)
            # 快速路径仍需检查 BasicConstraints
            try:
                bc = issuer.extensions.get_extension_for_class(x509.BasicConstraints).value
                if not bc.ca:
                    raise AuthError("Issuer CA is not marked as CA (fast path)")
            except x509.ExtensionNotFound:
                raise AuthError("Issuer CA missing BasicConstraints (fast path)")
            if auth_cert.issuer != issuer.subject:
                raise AuthError("auth certificate issuer mismatch")
            try:
                _verify_signature(issuer.public_key(), auth_cert.signature, auth_cert.tbs_certificate_bytes)
            except Exception as exc:
                raise AuthError("auth certificate signature verification failed") from exc
            self._chain_verified_cache[cert_serial] = time.time()
            return

        # 首次验证：完整验证 + 预验证 CA 链
        # 构建验证对（cert, issuer_ca, level）
        current = auth_cert
        verify_pairs = []
        for index, ca_cert in enumerate(chain):
            self._ensure_cert_time_valid(ca_cert, f"CA certificate[{index}]", now)
            if current.issuer != ca_cert.subject:
                raise AuthError(f"auth certificate issuer mismatch at chain level {index}")
            verify_pairs.append((current, ca_cert, index))
            current = ca_cert

        # 并行验证所有签名
        import concurrent.futures
        def verify_level(cert, issuer, level):
            try:
                _verify_signature(issuer.public_key(), cert.signature, cert.tbs_certificate_bytes)
                constraints = issuer.extensions.get_extension_for_class(x509.BasicConstraints).value
                if not constraints.ca:
                    raise AuthError(f"CA certificate[{level}] is not marked as CA")
            except x509.ExtensionNotFound:
                raise AuthError(f"CA certificate[{level}] missing BasicConstraints")

        with concurrent.futures.ThreadPoolExecutor(max_workers=len(verify_pairs)) as executor:
            futures = [executor.submit(verify_level, c, ca, i) for c, ca, i in verify_pairs]
            for future in concurrent.futures.as_completed(futures):
                future.result()

        root = chain[-1]
        if root.issuer != root.subject:
            raise AuthError("auth certificate chain root is not self-signed")
        try:
            _verify_signature(root.public_key(), root.signature, root.tbs_certificate_bytes)
        except Exception as exc:
            raise AuthError("auth certificate chain root self-signature verification failed") from exc

        trusted_roots = self._load_trusted_roots()
        root_der = root.public_bytes(serialization.Encoding.DER)
        if not any(
            trusted.public_bytes(serialization.Encoding.DER) == root_der
            for trusted in trusted_roots
        ):
            raise AuthError("auth certificate chain is not anchored by a trusted root")

        # 验证成功，保存到缓存并标记 CA 链已预验证
        self._chain_verified_cache[cert_serial] = time.time()
        self._gateway_ca_verified[cache_key] = True

    async def _load_gateway_ca_chain(self, gateway_url: str, chain_aid: str = "") -> list[x509.Certificate]:
        cache_key = f"{gateway_url}:{chain_aid}" if chain_aid else gateway_url
        cached = self._gateway_chain_cache.get(cache_key)
        if cached is None:
            cached = await self._fetch_gateway_ca_chain(gateway_url, chain_aid)
            self._gateway_chain_cache[cache_key] = cached
            # 注意：此处只缓存 PEM 数据，不设置 _gateway_ca_verified。
            # 信任标记只能在 _verify_auth_cert_chain 完整验证（含受信根锚定）通过后设置。
        return self._load_cert_bundle(cached)

    async def _verify_auth_cert_revocation(self, gateway_url: str, auth_cert: x509.Certificate, chain_aid: str = "") -> None:
        chain = await self._load_gateway_ca_chain(gateway_url, chain_aid)
        if not chain:
            raise AuthError("unable to verify auth certificate revocation: missing issuer certificate")

        # 跨域 peer cert：CRL 请求发到 peer 所在域的 Gateway
        crl_gateway_url = gateway_url
        if chain_aid and "." in chain_aid:
            _, peer_issuer = chain_aid.split(".", 1)
            import re as _re
            m = _re.search(r"gateway\.([^:/]+)", gateway_url)
            local_issuer = m.group(1) if m else ""
            if local_issuer and peer_issuer != local_issuer:
                crl_gateway_url = gateway_url.replace(f"gateway.{local_issuer}", f"gateway.{peer_issuer}")

        revoked_serials = await self._load_gateway_revoked_serials(crl_gateway_url, chain[0])
        serial_hex = format(auth_cert.serial_number, "x").lower()
        if serial_hex in revoked_serials:
            raise AuthError("auth certificate has been revoked")

    async def _verify_auth_cert_ocsp(self, gateway_url: str, auth_cert: x509.Certificate, chain_aid: str = "") -> None:
        chain = await self._load_gateway_ca_chain(gateway_url, chain_aid)
        if not chain:
            raise AuthError("unable to verify auth certificate OCSP status: missing issuer certificate")
        status = await self._load_gateway_ocsp_status(gateway_url, auth_cert, chain[0])
        if status == "revoked":
            raise AuthError("auth certificate OCSP status is revoked")
        if status != "good":
            raise AuthError(f"auth certificate OCSP status is {status}")

    async def verify_peer_certificate(
        self, gateway_url: str, cert: x509.Certificate, expected_aid: str,
    ) -> None:
        """统一的对端证书验证入口：时间有效性 + 链验证 + CRL + OCSP + AID 绑定。"""
        self._ensure_cert_time_valid(cert, "peer certificate", time.time())
        await self._verify_auth_cert_chain(gateway_url, cert, chain_aid=expected_aid)
        try:
            await self._verify_auth_cert_revocation(gateway_url, cert, chain_aid=expected_aid)
        except AuthError as _crl_exc:
            if "revoked" in str(_crl_exc).lower():
                raise
            self._log.warn("auth", "peer cert CRL check unavailable, degrading gracefully: %s", _crl_exc)
        except Exception as exc:
            self._log.warn("auth", "peer cert CRL check unavailable, degrading gracefully: %s", exc)
        try:
            await self._verify_auth_cert_ocsp(gateway_url, cert, chain_aid=expected_aid)
        except AuthError as _ocsp_exc:
            if "revoked" in str(_ocsp_exc).lower():
                raise
            self._log.warn("auth", "peer cert OCSP check unavailable, degrading gracefully: %s", _ocsp_exc)
        except Exception as exc:
            self._log.warn("auth", "peer cert OCSP check unavailable, degrading gracefully: %s", exc)
        cn_attrs = cert.subject.get_attributes_for_oid(x509.oid.NameOID.COMMON_NAME)
        if not cn_attrs or cn_attrs[0].value != expected_aid:
            cert_cn = cn_attrs[0].value if cn_attrs else "none"
            raise AuthError(f"peer cert CN mismatch: expected {expected_aid}, got {cert_cn}")

    async def _load_gateway_revoked_serials(
        self,
        gateway_url: str,
        issuer_cert: x509.Certificate,
    ) -> set[str]:
        cached = self._gateway_crl_cache.get(gateway_url)
        now = time.time()
        if cached is None or float(cached.get("next_refresh_at") or 0.0) <= now:
            cached = await self._fetch_gateway_crl(gateway_url, issuer_cert)
            self._gateway_crl_cache[gateway_url] = cached
        return set(cached.get("revoked_serials") or [])

    async def _load_gateway_ocsp_status(
        self,
        gateway_url: str,
        auth_cert: x509.Certificate,
        issuer_cert: x509.Certificate,
    ) -> str:
        serial_hex = format(auth_cert.serial_number, "x").lower()
        gateway_cache = self._gateway_ocsp_cache.setdefault(gateway_url, {})
        cached = gateway_cache.get(serial_hex)
        now = time.time()
        if cached is None or float(cached.get("next_refresh_at") or 0.0) <= now:
            cached = await self._fetch_gateway_ocsp_status(gateway_url, auth_cert, issuer_cert)
            gateway_cache[serial_hex] = cached
        return str(cached.get("status") or "unknown")

    def _load_trusted_roots(self) -> list[x509.Certificate]:
        if not self._root_certs:
            # fallback: 证书可能在构造之后才写入磁盘，重新加载一次
            self._root_certs = self._load_root_certs(self._root_ca_path, keystore=self._keystore)
            if not self._root_certs:
                raise AuthError("no trusted roots available for auth certificate verification")
        return self._root_certs

    async def _fetch_gateway_ca_chain(self, gateway_url: str, chain_aid: str = "") -> list[str]:
        # 始终用 /pki/chain（不带 AID），返回纯 CA 链
        # 跨域时 gateway_url 已经是 peer 域的 URL
        url = self._gateway_http_url(gateway_url, "/pki/chain")
        text = await self._fetch_text(url)
        return self._split_pem_bundle(text)

    async def _fetch_gateway_crl(
        self,
        gateway_url: str,
        issuer_cert: x509.Certificate,
    ) -> dict[str, Any]:
        url = self._gateway_http_url(gateway_url, "/pki/crl.json")
        payload = await self._fetch_json(url)
        crl_pem = str(payload.get("crl_pem") or "")
        if not crl_pem:
            raise AuthError("gateway CRL endpoint returned no signed CRL")
        try:
            crl = x509.load_pem_x509_crl(crl_pem.encode("utf-8"))
        except Exception as exc:
            raise AuthError("gateway CRL endpoint returned invalid CRL") from exc
        try:
            _verify_signature(
                issuer_cert.public_key(),
                crl.signature,
                crl.tbs_certlist_bytes,
            )
        except Exception as exc:
            raise AuthError("gateway CRL signature verification failed") from exc

        if crl.next_update_utc and time.time() > crl.next_update_utc.timestamp():
            raise AuthError("gateway CRL has expired")

        revoked_serials = {
            format(revoked.serial_number, "x").lower()
            for revoked in crl
        }
        next_refresh_at = crl.next_update_utc.timestamp() if crl.next_update_utc else time.time() + 300
        # 客户端最大缓存 TTL：不信任服务端设置超过 1 小时的 next_update，
        # 以确保紧急吊销（compromise/key theft）能在合理时间窗内生效。
        max_refresh_at = time.time() + 3600
        next_refresh_at = min(next_refresh_at, max_refresh_at)
        return {
            "revoked_serials": revoked_serials,
            "next_refresh_at": next_refresh_at,
        }

    async def _fetch_gateway_ocsp_status(
        self,
        gateway_url: str,
        auth_cert: x509.Certificate,
        issuer_cert: x509.Certificate,
    ) -> dict[str, Any]:
        serial_hex = format(auth_cert.serial_number, "x").lower()
        url = self._gateway_http_url(gateway_url, f"/pki/ocsp/{serial_hex}")
        payload = await self._fetch_json(url)
        status = str(payload.get("status") or "")
        ocsp_b64 = str(payload.get("ocsp_response") or "")
        if not ocsp_b64:
            raise AuthError("gateway OCSP endpoint returned no ocsp_response")
        effective_status: str | None = None
        try:
            response = ocsp.load_der_ocsp_response(base64.b64decode(ocsp_b64))

            if response.response_status is not ocsp.OCSPResponseStatus.SUCCESSFUL:
                # 非 successful（如 UNAUTHORIZED）表示 responder 无法回答，常见于 unknown 证书
                # 降级到 JSON status 字段
                self._log.debug("auth", 
                    "OCSP responseStatus=%s (non-successful)，降级使用 JSON status",
                    response.response_status.name,
                )
            else:
                if response.serial_number != auth_cert.serial_number:
                    raise AuthError("gateway OCSP response serial mismatch")
                expected_issuer_name_hash = hashlib.sha256(issuer_cert.subject.public_bytes()).digest()
                expected_issuer_key_hash = hashlib.sha256(
                    issuer_cert.public_key().public_bytes(
                        serialization.Encoding.DER,
                        serialization.PublicFormat.SubjectPublicKeyInfo,
                    )
                ).digest()
                if response.issuer_name_hash != expected_issuer_name_hash:
                    raise AuthError("gateway OCSP issuer name hash mismatch")
                if response.issuer_key_hash != expected_issuer_key_hash:
                    raise AuthError("gateway OCSP issuer key hash mismatch")
                try:
                    _verify_signature(
                        issuer_cert.public_key(),
                        response.signature,
                        response.tbs_response_bytes,
                    )
                except Exception as exc:
                    raise AuthError("gateway OCSP signature verification failed") from exc

                now = time.time()
                if response.this_update_utc and now < response.this_update_utc.timestamp() - 300:
                    raise AuthError("gateway OCSP response is not yet valid")
                if response.next_update_utc and now > response.next_update_utc.timestamp():
                    raise AuthError("gateway OCSP response has expired")

                cert_status = response.certificate_status
                if cert_status == ocsp.OCSPCertStatus.GOOD:
                    effective_status = "good"
                elif cert_status == ocsp.OCSPCertStatus.REVOKED:
                    effective_status = "revoked"
                else:
                    effective_status = "unknown"
                if status and status != effective_status:
                    raise AuthError("gateway OCSP status mismatch")
        except AuthError:
            raise
        except Exception as exc:
            self._log.debug("auth", "OCSP DER parse failed, degrading to JSON status: %s", exc)

        # DER 解析未得出结果时，降级使用 JSON status
        if effective_status is None:
            if not status:
                raise AuthError("gateway OCSP endpoint returned invalid response and no status field")
            effective_status = status

        # 计算缓存 TTL
        try:
            next_refresh_at = response.next_update_utc.timestamp() if response.response_status == ocsp.OCSPResponseStatus.SUCCESSFUL and response.next_update_utc else time.time() + 300
        except Exception as exc:
            self._log.warn("auth", "OCSP next_update timestamp parse failed, default TTL=300s: %s", exc)
            next_refresh_at = time.time() + 300
        # 客户端最大缓存 TTL：不信任服务端设置超过 24 小时的 next_update
        max_refresh_at = time.time() + 86400
        next_refresh_at = min(next_refresh_at, max_refresh_at)
        return {
            "status": effective_status,
            "next_refresh_at": next_refresh_at,
        }

    async def _fetch_text(self, url: str) -> str:
        try:
            timeout = aiohttp.ClientTimeout(total=5.0)
            ssl_param = None if self._verify_ssl else False
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url, ssl=ssl_param) as response:
                    response.raise_for_status()
                    return await response.text()
        except Exception as exc:
            raise AuthError(f"failed to fetch {url}") from exc

    async def _fetch_json(self, url: str) -> dict[str, Any]:
        try:
            timeout = aiohttp.ClientTimeout(total=5.0)
            ssl_param = None if self._verify_ssl else False
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url, ssl=ssl_param) as response:
                    response.raise_for_status()
                    payload = await response.json()
        except Exception as exc:
            raise AuthError(f"failed to fetch {url}") from exc
        if not isinstance(payload, dict):
            raise AuthError(f"invalid JSON payload from {url}")
        return payload

    @staticmethod
    def _gateway_http_url(gateway_url: str, path: str) -> str:
        parsed = urlparse(gateway_url)
        scheme = "https" if parsed.scheme == "wss" else "http"
        return urlunparse((scheme, parsed.netloc, path, "", "", ""))

    @staticmethod
    def _split_pem_bundle(bundle_text: str) -> list[str]:
        marker = "-----END CERTIFICATE-----"
        certs: list[str] = []
        for part in bundle_text.split(marker):
            part = part.strip()
            if not part:
                continue
            certs.append(f"{part}\n{marker}\n")
        return certs

    @staticmethod
    def _load_cert_bundle(pems: list[str]) -> list[x509.Certificate]:
        certs: list[x509.Certificate] = []
        for pem in pems:
            certs.append(x509.load_pem_x509_certificate(pem.encode("utf-8")))
        return certs

    @staticmethod
    def _ensure_cert_time_valid(cert: x509.Certificate, label: str, now: float) -> None:
        current_ts = now
        if current_ts < cert.not_valid_before_utc.timestamp():
            raise AuthError(f"{label} is not yet valid")
        if current_ts > cert.not_valid_after_utc.timestamp():
            raise AuthError(f"{label} has expired")

    def reload_trusted_roots(self) -> int:
        """重新加载本地信任根证书，供 meta.import_trust_roots 后刷新当前客户端使用。"""
        self._root_certs = self._load_root_certs(self._root_ca_path, keystore=self._keystore)
        self._gateway_ca_verified.clear()
        self._chain_verified_cache.clear()
        return len(self._root_certs)

    @staticmethod
    def _load_root_certs(root_ca_path: str | None, *, keystore: FileKeyStore | None = None) -> list[x509.Certificate]:
        candidate_paths: list[Path] = []
        if root_ca_path:
            candidate_paths.append(Path(root_ca_path))
        if keystore is not None:
            try:
                dynamic_bundle = keystore.trust_root_bundle_path()
                if dynamic_bundle.exists():
                    candidate_paths.append(dynamic_bundle)
            except Exception as exc:
                self._log.warn("auth", "trust root bundle path resolve failed: %s", exc)
        bundled_dir = Path(__file__).resolve().parent / "certs"
        if bundled_dir.exists():
            candidate_paths.extend(sorted(bundled_dir.glob("*.crt")))

        certs: list[x509.Certificate] = []
        seen_der: set[bytes] = set()
        for path in candidate_paths:
            try:
                text = path.read_text(encoding="utf-8")
            except OSError as exc:
                raise AuthError(f"failed to read root certificate bundle: {path}") from exc
            for cert in AuthFlow._load_cert_bundle(AuthFlow._split_pem_bundle(text)):
                der = cert.public_bytes(serialization.Encoding.DER)
                if der in seen_der:
                    continue
                seen_der.add(der)
                certs.append(cert)
        return certs

    @staticmethod
    def _remember_tokens(identity: dict[str, Any], auth_result: dict[str, Any]) -> None:
        default_access_token_ttl = 3600
        access_token = auth_result.get("access_token") or auth_result.get("token") or auth_result.get("kite_token")
        refresh_token = auth_result.get("refresh_token")
        expires_in = auth_result.get("expires_in")

        if access_token:
            identity["access_token"] = access_token
        if refresh_token:
            identity["refresh_token"] = refresh_token
        if auth_result.get("token"):
            identity["kite_token"] = auth_result["token"]
        if isinstance(expires_in, (int, float)):
            identity["access_token_expires_at"] = int(time.time() + float(expires_in))
        elif access_token:
            identity["access_token_expires_at"] = int(time.time() + default_access_token_ttl)
        # 协议要求：login2 响应含 new_cert 时（证书过半自动续期），客户端必须保存
        # 先暂存到 _pending_new_cert，由 _validate_new_cert 验证后再正式接受
        new_cert = auth_result.get("new_cert")
        if new_cert:
            identity["_pending_new_cert"] = new_cert
        # 服务端返回 active_cert 用于同步本地 cert.pem
        active_cert = auth_result.get("active_cert")
        if active_cert:
            identity["_pending_active_cert"] = active_cert

    async def _validate_new_cert(self, identity: dict[str, Any], gateway_url: str = "") -> None:
        """验证服务端返回的 new_cert，通过后才正式接受。

        安全要点：除 CN/公钥/时间外，还必须做完整链验证 + 受信根锚定 + CRL/OCSP，
        防止恶意网关塞入"同公钥但不受信链"的证书。
        """
        new_cert_pem = identity.pop("_pending_new_cert", None)
        if not new_cert_pem:
            return
        try:
            cert = x509.load_pem_x509_certificate(
                new_cert_pem.encode("utf-8") if isinstance(new_cert_pem, str) else new_cert_pem
            )
            # 1. CN 必须匹配当前 AID
            aid = identity.get("aid", "")
            cn_attrs = cert.subject.get_attributes_for_oid(x509.oid.NameOID.COMMON_NAME)
            if not cn_attrs or cn_attrs[0].value != aid:
                raise AuthError(
                    f"new_cert CN mismatch: expected {aid}, got {cn_attrs[0].value if cn_attrs else 'none'}"
                )
            # 2. 公钥必须匹配本地私钥
            cert_pub_der = cert.public_key().public_bytes(
                serialization.Encoding.DER,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            )
            local_pub_b64 = identity.get("public_key_der_b64", "")
            if local_pub_b64:
                local_pub_der = base64.b64decode(local_pub_b64)
                if cert_pub_der != local_pub_der:
                    raise AuthError("new_cert public key does not match local identity key")
            # 3. 时间有效性
            self._ensure_cert_time_valid(cert, "new_cert", time.time())
            # 4. 完整证书链验证 + 受信根锚定 + CRL/OCSP
            if gateway_url:
                await self._verify_auth_cert_chain(gateway_url, cert)
                try:
                    await self._verify_auth_cert_revocation(gateway_url, cert)
                except AuthError as exc:
                    if "revoked" in str(exc).lower():
                        raise
                    self._log.warn("auth", "CRL check unavailable, degrading gracefully: %s", exc)
                try:
                    await self._verify_auth_cert_ocsp(gateway_url, cert)
                except AuthError as exc:
                    if "revoked" in str(exc).lower():
                        raise
                    self._log.info("auth", "OCSP check unavailable, degrading gracefully: %s", exc)
            # 验证通过，正式接受
            identity["cert"] = new_cert_pem if isinstance(new_cert_pem, str) else new_cert_pem.decode("utf-8")
        except AuthError as exc:
            self._log.warn("auth", "rejected server new_cert (%s): %s", identity.get("aid"), exc)
        except Exception as exc:
            self._log.warn("auth", "new_cert validation error (%s): %s", identity.get("aid"), exc)

        # 同步服务端 active_signing 证书到本地
        active_cert_pem = identity.pop("_pending_active_cert", None)
        if active_cert_pem:
            try:
                act = x509.load_pem_x509_certificate(
                    active_cert_pem.encode("utf-8") if isinstance(active_cert_pem, str) else active_cert_pem
                )
                act_pub_der = act.public_key().public_bytes(
                    serialization.Encoding.DER,
                    serialization.PublicFormat.SubjectPublicKeyInfo,
                )
                local_pub_b64 = identity.get("public_key_der_b64", "")
                if local_pub_b64:
                    local_pub_der = base64.b64decode(local_pub_b64)
                    if act_pub_der != local_pub_der:
                        self._log.error("auth",
                            "server active_cert public key mismatch with local private key (%s), refusing sync",
                            identity.get("aid"),
                        )
                    else:
                        identity["cert"] = active_cert_pem if isinstance(active_cert_pem, str) else active_cert_pem.decode("utf-8")
            except Exception as exc:
                self._log.warn("auth", "active_cert sync error (%s): %s", identity.get("aid"), exc)

    @staticmethod
    def _get_cached_access_token(identity: dict[str, Any]) -> str:
        access_token = str(identity.get("access_token") or "")
        if not access_token:
            return ""
        expires_at = identity.get("access_token_expires_at")
        if isinstance(expires_at, (int, float)) and float(expires_at) <= time.time() + 30:
            return ""
        return access_token

    def _ensure_local_identity(self, aid: str) -> dict[str, Any]:
        existing = self._keystore.load_identity(aid)
        # 必须确认有 keypair（private_key_pem + public_key_der_b64）才算"已存在"
        # 否则 keystore 可能只有 metadata（如 gateway_url）但没有真正的密钥材料
        if existing and existing.get("private_key_pem") and existing.get("public_key_der_b64"):
            self._aid = aid
            return existing
        identity = self._crypto.generate_identity()
        identity["aid"] = aid
        # 保留 keystore 已有的 metadata（如 gateway_url），避免覆盖
        if existing:
            for k, v in existing.items():
                if k not in identity and k != "aid":
                    identity[k] = v
        self._persist_identity(identity)  # 立即持久化 keypair，避免服务端拒绝后丢失
        self._aid = aid
        return identity

    # AID name 验证正则：4-64 字符，仅 [a-z0-9_-]，首字符不为 -，不以 guest 开头
    import re as _re
    _AID_NAME_RE = _re.compile(r'^[a-z0-9_][a-z0-9_-]{3,63}$')

    @staticmethod
    def _validate_aid_name(aid: str) -> None:
        """验证 AID name 部分是否符合协议规范（4-64 字符）"""
        name = aid.split(".")[0] if "." in aid else aid
        if not AuthFlow._AID_NAME_RE.match(name):
            raise ValidationError(
                f"Invalid AID name '{name}': must be 4-64 characters, "
                f"only [a-z0-9_-], cannot start with '-'"
            )
        if name.startswith("guest"):
            raise ValidationError("AID name must not start with 'guest'")

    def _load_identity_or_raise(self, aid: str | None = None) -> dict[str, Any]:
        requested_aid = aid or self._aid
        if requested_aid:
            existing = self._keystore.load_identity(requested_aid)
            if existing is None:
                raise StateError(f"identity not found for aid: {requested_aid}")
            self._aid = requested_aid
            if not existing.get("aid"):
                existing["aid"] = requested_aid
            return existing

        load_any_identity = getattr(self._keystore, "load_any_identity", None)
        if callable(load_any_identity):
            existing = load_any_identity()
            if existing is not None:
                loaded_aid = existing.get("aid")
                if isinstance(loaded_aid, str) and loaded_aid:
                    self._aid = loaded_aid
                return existing

        raise StateError("no local identity found, call auth.create_aid() first")

    def _ensure_identity(self) -> dict[str, Any]:
        try:
            return self._load_identity_or_raise()
        except StateError:
            if not self._aid:
                raise StateError("no local identity found, call auth.create_aid() first")
            identity = self._crypto.generate_identity()
            identity["aid"] = self._aid
            self._persist_identity(identity)  # 立即持久化，避免后续网络失败丢失密钥
            return identity

    def _load_instance_state(self, aid: str) -> dict[str, Any] | None:
        if not self._device_id:
            return None
        loader = getattr(self._keystore, "load_instance_state", None)
        if not callable(loader):
            return None
        return loader(aid, self._device_id, self._slot_id)

    def _persist_identity(self, identity: dict[str, Any]) -> None:
        aid = str(identity.get("aid") or "")
        if not aid:
            raise StateError("identity missing aid")
        persisted = dict(identity)
        instance_state = {}
        for key in self._INSTANCE_STATE_FIELDS:
            if key in persisted:
                instance_state[key] = persisted.pop(key)
        self._keystore.save_identity(aid, persisted)
        if self._device_id:
            # 从共享 metadata 中移除实例级字段（它们已保存到 instance_state）
            db = getattr(self._keystore, "_get_db", None)
            if callable(db):
                aid_db = db(aid)
                for key in self._INSTANCE_STATE_FIELDS:
                    aid_db.delete_metadata(key)
                    aid_db.delete_metadata(f"{key}_protection")
        if not self._device_id or not instance_state:
            return
        updater = getattr(self._keystore, "update_instance_state", None)
        if not callable(updater):
            return

        def _merge(current: dict[str, Any]) -> dict[str, Any]:
            current.update(instance_state)
            return current

        updater(aid, self._device_id, self._slot_id, _merge)

    async def _default_connection_factory(self, url: str):
        return await websockets.connect(url, open_timeout=5, close_timeout=5, ping_interval=None)

    def clean_expired_caches(self) -> None:
        """清理过期的 gateway 缓存条目（供外部定时调用）"""
        now = time.time()
        for k in list(self._gateway_crl_cache):
            entry = self._gateway_crl_cache[k]
            if float(entry.get("next_refresh_at") or 0.0) <= now:
                del self._gateway_crl_cache[k]
        for k in list(self._gateway_ocsp_cache):
            inner = self._gateway_ocsp_cache[k]
            for serial in list(inner):
                if float(inner[serial].get("next_refresh_at") or 0.0) <= now:
                    del inner[serial]
            if not inner:
                del self._gateway_ocsp_cache[k]
        ttl = self._chain_cache_ttl
        for k in list(self._chain_verified_cache):
            if now - self._chain_verified_cache[k] >= ttl:
                del self._chain_verified_cache[k]
