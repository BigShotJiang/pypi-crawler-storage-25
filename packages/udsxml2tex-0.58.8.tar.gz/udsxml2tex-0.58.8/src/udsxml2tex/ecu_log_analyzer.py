"""ASC / BLF UDS log analyzer.

Reads a Vector CANalyzer / CANoe ``.asc`` (text) or ``.blf`` (binary)
trace, reconstructs ISO-TP segmented messages, decodes each UDS
request/response pair, and cross-checks them against the
:class:`UdsSpecification` parsed from ARXML (plus the optional RTM
verdict).

ASC is parsed with a small built-in tokenizer so the analyzer works
without optional dependencies; BLF requires ``python-can`` (an
``[ecu-test]`` extra) and is loaded lazily so the rest of the package
keeps working when the library is absent.

Public API:

    analyze_log_stream(spec, data, fmt="asc", rtm=None) -> dict
        spec  — UdsSpecification
        data  — raw file bytes (ASC text or BLF binary)
        fmt   — "asc" | "blf"
        rtm   — optional RtmDocument for compliance cross-check
        returns:
            {
                "frame_count":   int,
                "message_count": int,
                "messages":      [...],          # decoded UDS messages
                "compliance":    {
                    "ok":               bool,
                    "issues":           [str],   # human-readable flags
                    "rejected_responses": int,   # responses for OEM-rejected SIDs
                    "unknown_sids":     [str],
                },
                "summary": {
                    "first_ts": float,           # seconds, relative
                    "last_ts":  float,
                    "duration": float,
                    "request_count":  int,
                    "response_count": int,
                    "negative_count": int,
                },
            }
"""

from __future__ import annotations

import re
from typing import Any, Optional

from udsxml2tex.models import STANDARD_NRCS, UDS_SERVICE_NAMES


__all__ = ["analyze_log_stream", "LogParseError"]


class LogParseError(ValueError):
    """Raised when the supplied log bytes don't look like ASC/BLF."""


# Match Vector ASC v8+ data frames. Examples we support:
#   0.123456 1  641             Rx   d 8 02 10 01 00 00 00 00 00
#   0.123456 1  641x            Rx   d 8 ...        (extended id flag)
#   0.123456 CAN 1 Rx 641 d 8 ...                   (alt ordering)
_ASC_FRAME_RE = re.compile(
    r"""^\s*
        (?P<ts>\d+\.\d+)\s+        # timestamp
        (?:CAN\s+)?
        (?P<chan>\d+)\s+
        (?P<id>[0-9A-Fa-f]+)x?\s+
        (?P<dir>Rx|Tx)\s+
        d\s+(?P<dlc>\d+)\s+
        (?P<data>(?:[0-9A-Fa-f]{2}\s*){0,64})
    """,
    re.VERBOSE,
)


def analyze_log_stream(spec: Any, data: bytes, *,
                          fmt: str = "asc",
                          rtm: Optional[object] = None) -> dict[str, Any]:
    """Top-level entry point used by ``/ecu-test/analyze-log``."""
    if not data:
        raise LogParseError("Empty log payload")
    fmt = (fmt or "").lower()
    if fmt == "asc":
        frames = list(_iter_asc_frames(data))
    elif fmt == "blf":
        frames = list(_iter_blf_frames(data))
    else:
        raise LogParseError(f"Unsupported log format: {fmt!r}")

    if not frames:
        raise LogParseError(
            "No CAN frames recognised; check the file format / version."
        )

    rx_id = _hex_or_none(getattr(spec, "can_rx_id", ""))
    tx_id = _hex_or_none(getattr(spec, "can_tx_id", ""))
    fn_id = _hex_or_none(getattr(spec, "can_functional_id", ""))

    messages = list(_reassemble_isotp(frames,
                                            tx_ids={i for i in (tx_id, fn_id) if i},
                                            rx_ids={i for i in (rx_id,) if i}))

    decoded = [_decode_uds(m, spec) for m in messages]

    summary = _summarise(decoded, frames)
    compliance = _check_compliance(decoded, spec, rtm)

    # Cap returned message detail so the UI stays responsive on
    # multi-megabyte logs (the count summary stays accurate).
    return {
        "frame_count":   len(frames),
        "message_count": len(decoded),
        "messages":       decoded[:500],
        "compliance":    compliance,
        "summary":       summary,
    }


# ---------------------------------------------------------------------------
# Frame readers
# ---------------------------------------------------------------------------

def _iter_asc_frames(data: bytes):
    text = data.decode("utf-8", errors="replace")
    for line in text.splitlines():
        if not line or line.lstrip().startswith(";"):
            continue
        m = _ASC_FRAME_RE.match(line)
        if not m:
            continue
        try:
            can_id = int(m.group("id"), 16)
            dlc = int(m.group("dlc"))
        except ValueError:
            continue
        raw = m.group("data").split()
        try:
            payload = bytes(int(b, 16) for b in raw[:dlc])
        except ValueError:
            continue
        yield {
            "ts": float(m.group("ts")),
            "id": can_id,
            "dir": m.group("dir"),
            "data": payload,
        }


def _iter_blf_frames(data: bytes):
    try:
        import can  # type: ignore  # noqa: PLC0415
    except ImportError as exc:
        raise LogParseError(
            "BLF parsing requires the python-can package: "
            "pip install udsxml2tex[ecu-test]"
        ) from exc
    import io
    try:
        reader = can.BLFReader(io.BytesIO(data))
    except Exception as exc:  # noqa: BLE001
        raise LogParseError(f"BLF reader failed: {exc}") from exc
    for msg in reader:
        if msg.is_error_frame or msg.is_remote_frame:
            continue
        yield {
            "ts": float(msg.timestamp),
            "id": int(msg.arbitration_id),
            "dir": "Rx",
            "data": bytes(msg.data),
        }


def _hex_or_none(s: str) -> Optional[int]:
    if not s:
        return None
    try:
        s = s.strip()
        return int(s, 16) if s.lower().startswith("0x") else int(s)
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# ISO 15765-2 reassembly
# ---------------------------------------------------------------------------

def _reassemble_isotp(frames, *, tx_ids: set[int],
                       rx_ids: set[int]):
    """Walk frames and yield reassembled UDS messages.

    Per-CAN-ID FIFO state machine. Unknown CAN IDs are skipped silently
    so a noisy bus log doesn't trip up the analyzer.
    """
    pending: dict[int, dict[str, Any]] = {}
    for fr in frames:
        cid = fr["id"]
        if cid not in tx_ids and cid not in rx_ids and (tx_ids or rx_ids):
            # No spec-bound IDs — accept everything when we don't know
            # which IDs to filter on; otherwise drop.
            if tx_ids or rx_ids:
                continue
        data = fr["data"]
        if not data:
            continue
        first = data[0]
        pci = (first >> 4) & 0xF
        ts = fr["ts"]
        direction = ("request"
                       if cid in tx_ids
                       else "response" if cid in rx_ids
                       else "unknown")
        if pci == 0:  # Single Frame
            length = first & 0xF
            yield {"ts": ts, "id": cid, "direction": direction,
                     "bytes": list(data[1:1 + length])}
        elif pci == 1:  # First Frame
            length = ((first & 0xF) << 8) | data[1]
            pending[cid] = {"ts": ts, "id": cid, "direction": direction,
                              "expected": length,
                              "bytes": list(data[2:8])}
        elif pci == 2:  # Consecutive Frame
            state = pending.get(cid)
            if state is None:
                continue
            state["bytes"] += list(data[1:8])
            if len(state["bytes"]) >= state["expected"]:
                state["bytes"] = state["bytes"][:state["expected"]]
                yield state
                del pending[cid]
        # pci == 3 (FC) is ignored — we only need request/response bytes.


# ---------------------------------------------------------------------------
# UDS decode + compliance check
# ---------------------------------------------------------------------------

def _decode_uds(msg: dict[str, Any], spec: Any) -> dict[str, Any]:
    payload = msg["bytes"]
    if not payload:
        return {**msg, "kind": "empty"}
    first = payload[0]
    if first == 0x7F and len(payload) >= 3:
        sid = payload[1]
        nrc_code = payload[2]
        return {
            "ts": msg["ts"],
            "can_id": f"0x{msg['id']:X}",
            "direction": msg["direction"],
            "kind": "negative_response",
            "sid": f"0x{sid:02X}",
            "service": UDS_SERVICE_NAMES.get(sid, f"0x{sid:02X}"),
            "nrc": f"0x{nrc_code:02X}",
            "nrc_name": STANDARD_NRCS.get(nrc_code, f"vendor_{nrc_code:02X}"),
            "raw_hex": " ".join(f"{b:02X}" for b in payload),
        }
    if first & 0x40:
        # Positive response (response SID = request SID + 0x40)
        sid = first - 0x40
        return {
            "ts": msg["ts"],
            "can_id": f"0x{msg['id']:X}",
            "direction": msg["direction"],
            "kind": "positive_response",
            "sid": f"0x{sid:02X}",
            "service": UDS_SERVICE_NAMES.get(sid, f"0x{sid:02X}"),
            "data": " ".join(f"{b:02X}" for b in payload[1:]),
            "raw_hex": " ".join(f"{b:02X}" for b in payload),
            **_decode_response_extras(sid, payload, spec),
        }
    # Request
    sid = first
    extras = _decode_request_extras(sid, payload, spec)
    return {
        "ts": msg["ts"],
        "can_id": f"0x{msg['id']:X}",
        "direction": msg["direction"],
        "kind": "request",
        "sid": f"0x{sid:02X}",
        "service": UDS_SERVICE_NAMES.get(sid, f"0x{sid:02X}"),
        "raw_hex": " ".join(f"{b:02X}" for b in payload),
        **extras,
    }


def _decode_request_extras(sid: int, payload: list[int],
                              spec: Any) -> dict[str, Any]:
    extras: dict[str, Any] = {}
    if sid in (0x10, 0x11, 0x27, 0x28, 0x3E) and len(payload) >= 2:
        extras["sub_function"] = f"0x{payload[1] & 0x7F:02X}"
    if sid == 0x22 and len(payload) >= 3:
        ids = [(payload[i] << 8) | payload[i + 1]
                 for i in range(1, len(payload) - 1, 2)]
        extras["did"] = ", ".join(f"0x{i:04X}" for i in ids)
    if sid == 0x2E and len(payload) >= 3:
        extras["did"] = f"0x{(payload[1] << 8) | payload[2]:04X}"
    if sid == 0x31 and len(payload) >= 4:
        extras["sub_function"] = f"0x{payload[1] & 0x7F:02X}"
        extras["routine"] = f"0x{(payload[2] << 8) | payload[3]:04X}"
    return extras


def _decode_response_extras(sid: int, payload: list[int],
                              spec: Any) -> dict[str, Any]:
    extras: dict[str, Any] = {}
    if sid in (0x10, 0x11, 0x27) and len(payload) >= 2:
        extras["sub_function"] = f"0x{payload[1]:02X}"
    if sid == 0x22 and len(payload) >= 3:
        extras["did"] = f"0x{(payload[1] << 8) | payload[2]:04X}"
    if sid == 0x31 and len(payload) >= 4:
        extras["sub_function"] = f"0x{payload[1]:02X}"
        extras["routine"] = f"0x{(payload[2] << 8) | payload[3]:04X}"
    return extras


def _summarise(messages: list[dict[str, Any]], frames: list[dict[str, Any]]):
    first_ts = frames[0]["ts"] if frames else 0.0
    last_ts = frames[-1]["ts"] if frames else 0.0
    req_count = sum(1 for m in messages if m["kind"] == "request")
    rsp_count = sum(1 for m in messages
                     if m["kind"] in ("positive_response", "negative_response"))
    neg_count = sum(1 for m in messages if m["kind"] == "negative_response")
    return {
        "first_ts": first_ts,
        "last_ts": last_ts,
        "duration": max(0.0, last_ts - first_ts),
        "request_count": req_count,
        "response_count": rsp_count,
        "negative_count": neg_count,
    }


def _check_compliance(messages: list[dict[str, Any]], spec: Any,
                       rtm: Optional[object]) -> dict[str, Any]:
    issues: list[str] = []
    rejected_responses = 0
    unknown_sids: set[str] = set()

    spec_sids = {svc.service_id for svc in getattr(spec, "services", []) or []}

    # Collect SIDs the OEM has marked "rejected" via RTM, if available.
    rejected_sids: set[int] = set()
    if rtm is not None:
        try:
            for entry in getattr(rtm, "entries", []) or []:
                if getattr(entry, "status", "") != "rejected":
                    continue
                for tok in (getattr(entry, "traces_to", "") or "").split(";"):
                    tok = tok.strip()
                    if tok.lower().startswith("sid:"):
                        try:
                            rejected_sids.add(
                                int(tok.split(":", 1)[1], 16)
                            )
                        except ValueError:
                            pass
        except Exception:  # noqa: BLE001
            pass

    for m in messages:
        if m["kind"] not in ("request", "positive_response", "negative_response"):
            continue
        sid_int = int(m["sid"], 16)
        if sid_int not in spec_sids and sid_int not in UDS_SERVICE_NAMES:
            unknown_sids.add(m["sid"])
        if sid_int in rejected_sids and m["kind"] == "positive_response":
            rejected_responses += 1
            issues.append(
                f"t={m['ts']:.3f}s: ECU returned POSITIVE on SID {m['sid']} "
                f"({m['service']}) which OEM marked REJECTED in RTM."
            )

    return {
        "ok": not issues and not unknown_sids,
        "issues": issues,
        "rejected_responses": rejected_responses,
        "unknown_sids": sorted(unknown_sids),
    }
