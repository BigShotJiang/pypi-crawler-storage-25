"""LLM-powered analysis and translation for UDS specifications.

Optional integration with cloud and local LLMs. Provides five functions:

    complete_nrc_descriptions(spec, *, model='sonnet', config=None) -> dict
    summarize_spec(spec, *, model='sonnet', length='1page', config=None) -> str
    query_spec(spec, question, *, model='sonnet', config=None) -> str
    translate_text(text, target_lang, *, model='sonnet', config=None) -> str
    chat_stream(spec, messages, *, model='sonnet', api_key=None, config=None) -> Iterator[str]

Backends (selected via `config.provider` or auto-detected):

    "anthropic" — Claude API (cloud, requires ANTHROPIC_API_KEY)
                  pip install udsxml2tex[llm]
    "openai"    — OpenAI-compatible HTTP API. One backend, many servers:
                    - Ollama       (http://localhost:11434/v1, free, local)
                    - llama.cpp    (http://localhost:8080/v1, free, local)
                    - vLLM / LM Studio  (free, local, self-hosted)
                    - OpenRouter / Azure OpenAI / OpenAI proper (cloud)
                  pip install udsxml2tex[llm]   # installs the openai SDK too

Configuration resolution order (highest priority first):
    1. `config` argument passed directly to a function
    2. CLI flags (--llm-provider, --llm-base-url, --llm-model, --llm-api-key)
    3. Environment vars (UDSXML2TEX_LLM_PROVIDER / _BASE_URL / _MODEL / _API_KEY,
       falling back to ANTHROPIC_API_KEY / OPENAI_API_KEY for the legacy paths)
    4. Config file at $UDSXML2TEX_LLM_CONFIG or ~/.udsxml2tex/llm.json
    5. Defaults (provider='anthropic', model='sonnet')

Prompt caching:
    For Anthropic, the serialized UdsSpecification JSON is placed in the
    system prompt with a 1-hour ephemeral cache breakpoint, so repeated
    queries pay the ~1.25-2x write cost once and the 0.1x read cost thereafter.
    The OpenAI-compatible backend doesn't use cache_control (servers vary).
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Iterator, Optional

# Map friendly names → official model IDs
_MODEL_ALIASES = {
    "opus":   "claude-opus-4-7",
    "sonnet": "claude-sonnet-4-6",
    "haiku":  "claude-haiku-4-5",
}

_INSTALL_HINT = (
    "The 'anthropic' package is required for LLM features. "
    "Install with: pip install udsxml2tex[llm]"
)


def _import_anthropic():  # type: ignore[no-untyped-def]
    """Import the Anthropic SDK or raise a helpful ImportError."""
    try:
        import anthropic  # type: ignore[import-not-found]
        return anthropic
    except ImportError as exc:
        raise ImportError(_INSTALL_HINT) from exc


def _resolve_model(name: str) -> str:
    """Map 'opus' / 'sonnet' / 'haiku' to the official model ID; pass through full IDs."""
    return _MODEL_ALIASES.get(name, name)


def _spec_json(spec: Any) -> str:
    """Serialize a UdsSpecification to deterministic JSON for prompt caching."""
    if hasattr(spec, "to_json"):
        return spec.to_json()  # type: ignore[no-any-return]
    if hasattr(spec, "to_dict"):
        return json.dumps(spec.to_dict(), sort_keys=True, ensure_ascii=False, default=str)
    return json.dumps(spec, sort_keys=True, ensure_ascii=False, default=str)


def _spec_quick_index(spec: Any) -> str:
    """Compact authoritative roster of the DID-shaped collections.

    Local 7–8B models reliably enumerate 2 of 3 implemented DIDs from a 15k-
    token spec JSON — the middle item is silently dropped. Listing the
    DID-shaped collections up-front gives the model a short, high-attention
    anchor that survives even when JSON-section attention is noisy. Returns
    "" when the spec exposes none of these collections.
    """
    sections: list[str] = []

    def _did_lines(items: Any, header: str) -> None:
        if not items:
            return
        sections.append(header)
        for d in items:
            sn = getattr(d, "short_name", "?")
            hx = getattr(d, "did_id_hex", "")
            r = getattr(d, "read_access", None)
            w = getattr(d, "write_access", None)
            tail = ""
            if r is not None or w is not None:
                tail = f" — read={r}, write={w}"
            sections.append(f"  - `{sn}` (id `{hx}`){tail}")

    _did_lines(getattr(spec, "dids", None),
               "Implemented DIDs (`spec.dids` — *the* configured DIDs):")
    _did_lines(getattr(spec, "io_control_dids", None),
               "IO-control DIDs (`spec.io_control_dids`):")
    _did_lines(getattr(spec, "periodic_dids", None),
               "Periodic DIDs (`spec.periodic_dids`):")
    _did_lines(getattr(spec, "dynamic_dids", None),
               "Dynamic DIDs (`spec.dynamic_dids`):")

    ranges = getattr(spec, "did_ranges", None)
    if ranges:
        sections.append("DID ranges (`spec.did_ranges`):")
        for r in ranges:
            sn = getattr(r, "short_name", "?")
            lo = getattr(r, "lower_did_hex", "")
            hi = getattr(r, "upper_did_hex", "")
            sections.append(f"  - `{sn}` (`{lo}`-`{hi}`)")

    return "\n".join(sections)


_INVENT_GUARD = (
    "Below is the full UDS (ISO 14229) specification for one ECU "
    "as parsed from AUTOSAR ARXML. Treat it as authoritative ground "
    "truth: do not invent SIDs, DIDs, NRCs, sessions, or security "
    "levels that are not present in the JSON. Cite hex values "
    "exactly as written. When the user asks to list entities of a "
    "given kind (DIDs, services, sessions, …), enumerate every item "
    "in the relevant collection — never a partial list."
)


def _role_with_index(spec: Any, role: str) -> str:
    """Render the role + invent-guard, prefixed with a quick spec index."""
    head = f"{role}\n\n{_INVENT_GUARD}"
    index = _spec_quick_index(spec)
    if index:
        head += "\n\nQuick index of DID-shaped collections (authoritative):\n" + index
    return head


def _build_system_blocks(spec: Any, role: str) -> list[dict]:
    """System prompt: stable role + index, then cached spec JSON.

    Render order is tools -> system -> messages, so a cache breakpoint on the
    last system block caches the JSON for the 1-hour TTL. The role/index block
    is small and intentionally left uncached so we can safely change wording
    without paying a cache miss on the JSON.
    """
    return [
        {
            "type": "text",
            "text": _role_with_index(spec, role),
        },
        {
            "type": "text",
            "text": "UDS specification (JSON):\n```json\n" + _spec_json(spec) + "\n```",
            "cache_control": {"type": "ephemeral", "ttl": "1h"},
        },
    ]


def _client(anthropic_module, api_key: Optional[str] = None) -> Any:  # type: ignore[no-untyped-def]
    """Create an Anthropic client.

    Resolution order: explicit `api_key` argument → ANTHROPIC_API_KEY env var →
    raise RuntimeError. The explicit-arg path lets the browser UI pass a
    user-supplied key without contaminating the server process environment.
    """
    if api_key:
        return anthropic_module.Anthropic(api_key=api_key)
    if not os.environ.get("ANTHROPIC_API_KEY"):
        raise RuntimeError(
            "ANTHROPIC_API_KEY environment variable is not set. "
            "Obtain a key at https://console.anthropic.com and export it before "
            "calling any udsxml2tex.llm_integration function."
        )
    return anthropic_module.Anthropic()


# ===========================================================================
# Provider configuration
# ===========================================================================

# Default base URL when provider="openai" and none is set.
_DEFAULT_OPENAI_BASE_URL = "http://localhost:11434/v1"   # Ollama default

# Common shorthand aliases for OpenAI-compatible servers, expanded into base_url.
_OPENAI_BASE_URL_ALIASES = {
    "ollama":     "http://localhost:11434/v1",
    "llamacpp":   "http://localhost:8080/v1",
    "lmstudio":   "http://localhost:1234/v1",
    "vllm":       "http://localhost:8000/v1",
    "openrouter": "https://openrouter.ai/api/v1",
    "openai":     "https://api.openai.com/v1",
}


@dataclass
class LLMConfig:
    """Resolved LLM provider configuration.

    Attributes:
        provider: 'anthropic' (cloud) or 'openai' (OpenAI-compatible HTTP API).
        model:    Model identifier. For Anthropic, accepts 'sonnet' / 'opus'
                  / 'haiku' aliases. For OpenAI-compatible, pass the server's
                  model name verbatim (e.g. 'llama3.1:8b' for Ollama).
        base_url: Endpoint URL for OpenAI-compatible mode. Ignored for
                  Anthropic. Aliases are accepted: 'ollama', 'llamacpp',
                  'lmstudio', 'vllm', 'openrouter', 'openai'.
        api_key:  API key (cloud providers). Ignored for fully-local servers
                  but most OpenAI-compatible servers still expect *some*
                  string in the header — set to 'ollama' or 'unused' for
                  local servers.
        structured_mode: Strategy for structured output (NRC enrichment).
                  'auto' picks per-provider sensible default; explicit values
                  are 'json_schema' (real OpenAI), 'json_object' (Ollama and
                  most OpenAI-compatible), or 'prompt' (last resort, parse
                  JSON from prose).
        timeout:  Request timeout in seconds (default 600; local LLMs can be
                  slow on first load — qwen2.5:14b cold-starts on Apple
                  Silicon can easily exceed two minutes before the first
                  token streams).
    """
    provider: str = "anthropic"
    model: str = "sonnet"
    base_url: Optional[str] = None
    api_key: Optional[str] = None
    structured_mode: str = "auto"
    timeout: float = 600.0

    def resolved_base_url(self) -> str:
        """Expand alias / fall back to default for openai-compatible mode."""
        if self.provider != "openai":
            return ""
        if not self.base_url:
            return _DEFAULT_OPENAI_BASE_URL
        return _OPENAI_BASE_URL_ALIASES.get(self.base_url, self.base_url)

    def resolved_model(self) -> str:
        """Expand model alias for Anthropic; pass through for openai."""
        if self.provider == "anthropic":
            return _MODEL_ALIASES.get(self.model, self.model)
        return self.model

    def resolved_api_key(self) -> Optional[str]:
        """Resolve API key: explicit → provider-specific env var → None."""
        if self.api_key:
            return self.api_key
        if self.provider == "anthropic":
            return os.environ.get("ANTHROPIC_API_KEY")
        return os.environ.get("OPENAI_API_KEY") or os.environ.get(
            "UDSXML2TEX_LLM_API_KEY"
        )

    def resolved_structured_mode(self) -> str:
        """Pick a structured-output mode when 'auto'."""
        if self.structured_mode != "auto":
            return self.structured_mode
        if self.provider == "anthropic":
            return "json_schema"   # real Anthropic output_config.format
        # For OpenAI-compatible, json_object is the common denominator that
        # works across Ollama, llama.cpp, vLLM, real OpenAI, OpenRouter.
        return "json_object"

    def to_dict(self) -> dict:
        return {
            "provider": self.provider,
            "model": self.model,
            "base_url": self.base_url,
            "api_key": "***" if self.api_key else None,  # never serialize key
            "structured_mode": self.structured_mode,
            "timeout": self.timeout,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "LLMConfig":
        return cls(
            provider=d.get("provider", "anthropic"),
            model=d.get("model", "sonnet"),
            base_url=d.get("base_url"),
            api_key=d.get("api_key"),
            structured_mode=d.get("structured_mode", "auto"),
            timeout=float(d.get("timeout", 600.0)),
        )

    @classmethod
    def from_file(cls, path: "str | Path") -> "LLMConfig":
        """Load from a JSON or TOML config file."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"LLM config file not found: {p}")
        text = p.read_text(encoding="utf-8")
        suffix = p.suffix.lower()
        if suffix in {".json", ""}:
            return cls.from_dict(json.loads(text))
        if suffix == ".toml":
            try:
                import tomllib  # py 3.11+
            except ImportError:
                import tomli as tomllib  # type: ignore[import-not-found]
            data = tomllib.loads(text)
            # Support either flat keys or [default] section.
            if isinstance(data.get("default"), dict):
                data = data["default"]
            return cls.from_dict(data)
        raise ValueError(
            f"Unsupported LLM config format: {suffix!r}. Use .json or .toml"
        )

    @classmethod
    def from_env(cls) -> "LLMConfig":
        """Build from UDSXML2TEX_LLM_* env vars; falls back to defaults."""
        return cls(
            provider=os.environ.get("UDSXML2TEX_LLM_PROVIDER", "anthropic"),
            model=os.environ.get("UDSXML2TEX_LLM_MODEL", "sonnet"),
            base_url=os.environ.get("UDSXML2TEX_LLM_BASE_URL"),
            api_key=os.environ.get("UDSXML2TEX_LLM_API_KEY"),
            structured_mode=os.environ.get(
                "UDSXML2TEX_LLM_STRUCTURED_MODE", "auto"
            ),
        )

    @classmethod
    def auto(cls) -> "LLMConfig":
        """Best-guess config: env var → user config file → defaults.

        Search order for the config file:
            $UDSXML2TEX_LLM_CONFIG
            ~/.udsxml2tex/llm.json
            ~/.udsxml2tex/llm.toml
        """
        # Highest priority: env vars (only when explicitly set)
        if os.environ.get("UDSXML2TEX_LLM_PROVIDER"):
            return cls.from_env()
        # Next: explicit config file
        for env_var in ("UDSXML2TEX_LLM_CONFIG",):
            cfg_path = os.environ.get(env_var)
            if cfg_path and Path(cfg_path).exists():
                return cls.from_file(cfg_path)
        # Default user config locations
        home = Path.home()
        for candidate in (
            home / ".udsxml2tex" / "llm.json",
            home / ".udsxml2tex" / "llm.toml",
        ):
            if candidate.exists():
                return cls.from_file(candidate)
        # Fall-through: defaults
        return cls()


def _resolve_config(
    *, config: Optional[LLMConfig], model: Optional[str],
    api_key: Optional[str] = None,
) -> LLMConfig:
    """Layer per-call kwargs on top of a config.

    Used by every public function so they preserve the existing keyword API
    while gaining a new `config=` override.
    """
    cfg = config if config is not None else LLMConfig.auto()
    # Overlay per-call kwargs only when explicitly set.
    if model is not None:
        cfg.model = model
    if api_key is not None:
        cfg.api_key = api_key
    return cfg


# ===========================================================================
# OpenAI-compatible provider (Ollama / llama.cpp / vLLM / LM Studio /
# OpenRouter / Azure OpenAI / real OpenAI)
# ===========================================================================

_OPENAI_INSTALL_HINT = (
    "The 'openai' package is required for the openai-compatible provider. "
    "Install with: pip install udsxml2tex[llm]"
)


def _import_openai():  # type: ignore[no-untyped-def]
    """Import the OpenAI SDK or return None if unavailable.

    The OpenAI-compatible REST API used by Ollama / llama.cpp / vLLM /
    LM Studio is plain JSON over HTTP, so we can fall back to a stdlib
    ``urllib`` client when the SDK isn't installed. Cloud providers
    (Azure OpenAI, real OpenAI, OpenRouter with auth headers etc.)
    still work fine with this lightweight fallback as long as a bearer
    API key is supplied.
    """
    try:
        import openai  # type: ignore[import-not-found]
        return openai
    except ImportError:
        return None


def _openai_client(config: LLMConfig):  # type: ignore[no-untyped-def]
    """Create an OpenAI-SDK client pointed at ``config.base_url``.

    Returns ``None`` when the SDK isn't installed; callers must then
    use the stdlib HTTP fallback (:func:`_openai_http_chat_complete` /
    :func:`_openai_http_chat_stream`).

    For local servers without auth, OpenAI SDK still requires a non-empty
    api_key; we synthesise one when none is configured.
    """
    openai = _import_openai()
    if openai is None:
        return None
    api_key = config.resolved_api_key() or "unused"
    return openai.OpenAI(
        api_key=api_key,
        base_url=config.resolved_base_url(),
        timeout=config.timeout,
    )


# --- stdlib HTTP fallback for the OpenAI-compatible REST API ---------------
#
# Used when the optional ``openai`` SDK isn't installed. The wire format is
# documented at https://platform.openai.com/docs/api-reference/chat/create
# and is implemented identically by Ollama, llama.cpp, vLLM, LM Studio, etc.

def _openai_http_url(config: LLMConfig) -> str:
    """Join ``base_url`` with the chat-completions endpoint."""
    base = config.resolved_base_url().rstrip("/")
    return f"{base}/chat/completions"


def _openai_http_headers(config: LLMConfig) -> dict[str, str]:
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    api_key = config.resolved_api_key()
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    return headers


def _openai_http_chat_complete(
    config: LLMConfig, *, messages: list[dict], max_tokens: int,
    response_format: Optional[dict] = None,
) -> str:
    """Non-streaming chat completion via stdlib ``urllib``."""
    import urllib.request
    import urllib.error

    payload: dict = {
        "model": config.resolved_model(),
        "messages": messages,
        "max_tokens": max_tokens,
        "stream": False,
    }
    if response_format is not None:
        payload["response_format"] = response_format
    req = urllib.request.Request(
        _openai_http_url(config),
        data=json.dumps(payload).encode("utf-8"),
        headers=_openai_http_headers(config),
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=config.timeout) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(
            f"OpenAI-compatible server returned HTTP {exc.code}: {detail}"
        ) from exc
    data = json.loads(body)
    try:
        return data["choices"][0]["message"]["content"] or ""
    except (KeyError, IndexError, TypeError) as exc:
        raise RuntimeError(
            f"Unexpected response shape from OpenAI-compatible server: {body[:500]}"
        ) from exc


def _openai_http_chat_stream(
    config: LLMConfig, *, messages: list[dict], max_tokens: int,
):  # type: ignore[no-untyped-def]
    """Streaming chat completion via stdlib ``urllib`` (SSE-parsing)."""
    import socket
    import urllib.request
    import urllib.error

    payload = {
        "model": config.resolved_model(),
        "messages": messages,
        "max_tokens": max_tokens,
        "stream": True,
    }
    req = urllib.request.Request(
        _openai_http_url(config),
        data=json.dumps(payload).encode("utf-8"),
        headers=_openai_http_headers(config),
        method="POST",
    )
    try:
        resp = urllib.request.urlopen(req, timeout=config.timeout)
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(
            f"OpenAI-compatible server returned HTTP {exc.code}: {detail}"
        ) from exc
    except (socket.timeout, urllib.error.URLError) as exc:
        # Surface a friendlier message so the chat UI shows context
        # rather than a bare "timed out". The default 600s is usually
        # enough, but qwen2.5:14b cold-starts on 16 GB Apple Silicon
        # can still exceed it the very first time after `ollama pull`.
        raise RuntimeError(
            f"Connection to {config.resolved_base_url()} timed out or "
            f"failed (timeout={config.timeout:g}s). The model may still "
            f"be loading; try again or pre-warm it with "
            f"`ollama run {config.resolved_model()} 'hi'`."
        ) from exc
    try:
        with resp:
            for raw in resp:
                line = raw.decode("utf-8", errors="replace").strip()
                if not line or not line.startswith("data:"):
                    continue
                chunk = line[len("data:"):].strip()
                if chunk == "[DONE]":
                    break
                try:
                    obj = json.loads(chunk)
                except json.JSONDecodeError:
                    continue
                choices = obj.get("choices") or []
                if not choices:
                    continue
                delta = choices[0].get("delta") or {}
                content = delta.get("content")
                if content:
                    yield content
    except (socket.timeout, urllib.error.URLError) as exc:
        # Stream stalled mid-response; surface the configured timeout
        # so the chat UI explains why the connection was dropped.
        raise RuntimeError(
            f"Streaming response from {config.resolved_base_url()} "
            f"stalled (no token for >{config.timeout:g}s). Try a smaller "
            f"model or raise the request timeout."
        ) from exc


def _system_prompt_text(spec: Any, role: str) -> str:
    """Render the spec context as a single OpenAI-style system prompt string."""
    return (
        _role_with_index(spec, role)
        + "\n\nUDS specification (JSON):\n```json\n"
        + _spec_json(spec)
        + "\n```"
    )


def _openai_messages(spec: Any, role_text: str,
                     user_messages: list[dict]) -> list[dict]:
    """Build the messages array for OpenAI-style requests."""
    return [
        {"role": "system", "content": _system_prompt_text(spec, role_text)},
        *user_messages,
    ]


def _openai_chat_complete(
    config: LLMConfig, *, messages: list[dict], max_tokens: int,
    response_format: Optional[dict] = None,
) -> str:
    """Non-streaming chat completion via the OpenAI-compatible API.

    Returns the assistant's full text response.
    """
    client = _openai_client(config)
    if client is None:
        return _openai_http_chat_complete(
            config, messages=messages, max_tokens=max_tokens,
            response_format=response_format,
        )
    kwargs: dict = {
        "model": config.resolved_model(),
        "messages": messages,
        "max_tokens": max_tokens,
    }
    if response_format is not None:
        kwargs["response_format"] = response_format
    completion = client.chat.completions.create(**kwargs)
    return completion.choices[0].message.content or ""


def _openai_chat_stream(
    config: LLMConfig, *, messages: list[dict], max_tokens: int,
):  # type: ignore[no-untyped-def]
    """Streaming chat completion via the OpenAI-compatible API.

    Yields incremental text deltas, mirroring the Anthropic streaming path.
    """
    client = _openai_client(config)
    if client is None:
        yield from _openai_http_chat_stream(
            config, messages=messages, max_tokens=max_tokens,
        )
        return
    stream = client.chat.completions.create(
        model=config.resolved_model(),
        messages=messages,
        max_tokens=max_tokens,
        stream=True,
    )
    for chunk in stream:
        if not chunk.choices:
            continue
        delta = chunk.choices[0].delta
        if delta and getattr(delta, "content", None):
            yield delta.content


# ---------------------------------------------------------------------------
# 1. Enriched NRC descriptions
# ---------------------------------------------------------------------------

_NRC_SCHEMA = {
    "type": "object",
    "properties": {
        "descriptions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "nrc_code": {"type": "integer",
                                 "description": "NRC code, e.g. 34 for 0x22"},
                    "description": {"type": "string",
                                    "description": "Single paragraph, ECU-specific"},
                },
                "required": ["nrc_code", "description"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["descriptions"],
    "additionalProperties": False,
}

_NRC_ROLE = (
    "You are a UDS (ISO 14229-1) diagnostic protocol expert generating "
    "ECU-specific Negative Response Code descriptions for a formal "
    "specification document."
)

_NRC_INSTRUCTION = (
    "For every distinct NRC code that appears anywhere in the spec's "
    "nrc_list across services, write a one-paragraph description that:\n"
    "  1. Names the ISO 14229-1 standard meaning of the NRC\n"
    "  2. Lists which SIDs in this ECU return it\n"
    "  3. Describes the ECU-specific conditions that trigger it, "
    "referencing the configured sessions, security levels, and DIDs/RIDs "
    "by hex code where relevant\n"
    "Return one entry per distinct NRC code."
)


def complete_nrc_descriptions(
    spec: Any, *, model: Optional[str] = None,
    config: Optional[LLMConfig] = None,
) -> dict[int, str]:
    """Generate enriched, ECU-specific descriptions for every NRC in the spec.

    Args:
        spec: Parsed UdsSpecification.
        model: Model alias / full ID. Overrides `config.model` when set.
        config: LLM provider configuration. Defaults to `LLMConfig.auto()`.

    Returns:
        Dict mapping NRC code (int) to a single-paragraph description string.
    """
    cfg = _resolve_config(config=config, model=model)
    if cfg.provider == "anthropic":
        return _nrc_anthropic(spec, cfg)
    if cfg.provider == "openai":
        return _nrc_openai(spec, cfg)
    raise ValueError(f"Unknown LLM provider: {cfg.provider!r}")


def _nrc_anthropic(spec: Any, cfg: LLMConfig) -> dict[int, str]:
    anthropic = _import_anthropic()
    client = _client(anthropic, api_key=cfg.api_key)
    system = _build_system_blocks(spec, role=_NRC_ROLE)
    response = client.messages.create(
        model=cfg.resolved_model(),
        max_tokens=16000,
        system=system,
        messages=[{"role": "user", "content": _NRC_INSTRUCTION}],
        output_config={
            "format": {"type": "json_schema", "schema": _NRC_SCHEMA},
        },
    )
    text = next(b.text for b in response.content if b.type == "text")
    data = json.loads(text)
    return {int(d["nrc_code"]): d["description"] for d in data["descriptions"]}


def _nrc_openai(spec: Any, cfg: LLMConfig) -> dict[int, str]:
    """OpenAI-compatible structured output via the configured response_format mode."""
    mode = cfg.resolved_structured_mode()
    # Augment the prompt with the schema for json_object / prompt modes —
    # smaller models follow it more reliably when the shape is spelled out.
    instruction = _NRC_INSTRUCTION + (
        "\n\nReturn ONLY a JSON object matching this schema (no prose, "
        "no Markdown fences, no commentary):\n"
        + json.dumps(_NRC_SCHEMA, indent=2)
    )
    messages = _openai_messages(spec, _NRC_ROLE, [
        {"role": "user", "content": instruction},
    ])

    response_format: Optional[dict]
    if mode == "json_schema":
        # Real OpenAI strict JSON schema (gpt-4o 2024-08-06+, OpenRouter, vLLM newer)
        response_format = {
            "type": "json_schema",
            "json_schema": {
                "name": "nrc_descriptions",
                "schema": _NRC_SCHEMA,
                "strict": True,
            },
        }
    elif mode == "json_object":
        # Ollama, llama.cpp, LM Studio, real OpenAI legacy
        response_format = {"type": "json_object"}
    else:
        response_format = None  # "prompt" mode: rely on prompting + JSON parse

    text = _openai_chat_complete(
        cfg, messages=messages, max_tokens=16000,
        response_format=response_format,
    )
    # Strip Markdown fences if the model added them despite instructions.
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("```", 2)[1]
        if cleaned.startswith("json"):
            cleaned = cleaned[4:].lstrip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise ValueError(
            f"Model returned non-JSON output (mode={mode}): {cleaned[:200]}"
        ) from e
    return {int(d["nrc_code"]): d["description"] for d in data["descriptions"]}


# ---------------------------------------------------------------------------
# 2. Executive summary
# ---------------------------------------------------------------------------

_LENGTH_GUIDANCE = {
    "short":   "around 200 words (executive blurb)",
    "1page":   "around 600 words (one A4 page)",
    "2page":   "around 1200 words (two A4 pages)",
    "long":    "around 2000 words (full executive briefing)",
}


_SUMMARY_ROLE = (
    "You are a UDS (ISO 14229-1) specification editor producing executive "
    "summaries for engineering and management readers."
)


def _summary_instruction(length: str) -> str:
    target = _LENGTH_GUIDANCE.get(length, _LENGTH_GUIDANCE["1page"])
    return (
        f"Write a concise executive summary in Markdown (target length: "
        f"{target}) covering:\n"
        "  - ECU identity and protocol stack\n"
        "  - Diagnostic sessions and their timing\n"
        "  - Security access design (levels, attempt limits, algorithm)\n"
        "  - Service surface (which SIDs, with hex codes)\n"
        "  - DID and routine inventory (counts plus a few notable entries)\n"
        "  - DTC inventory and any combined / OBD entries\n"
        "  - Any non-obvious risks or gaps an engineer should know\n\n"
        "Use Markdown headings (##, ###), bullet lists, and `code` spans "
        "for hex values. Skip categories the spec doesn't use. Do not "
        "invent data — cite only what is in the JSON."
    )


def summarize_spec(
    spec: Any,
    *,
    model: Optional[str] = None,
    length: str = "1page",
    config: Optional[LLMConfig] = None,
) -> str:
    """Generate a Markdown executive summary of the UDS specification.

    Args:
        spec: Parsed UdsSpecification.
        model: Model alias / full ID. Overrides `config.model` when set.
        length: 'short' | '1page' (default) | '2page' | 'long'.
        config: LLM provider configuration. Defaults to `LLMConfig.auto()`.
    """
    cfg = _resolve_config(config=config, model=model)
    instruction = _summary_instruction(length)

    if cfg.provider == "anthropic":
        anthropic = _import_anthropic()
        client = _client(anthropic, api_key=cfg.api_key)
        system = _build_system_blocks(spec, role=_SUMMARY_ROLE)
        response = client.messages.create(
            model=cfg.resolved_model(),
            max_tokens=8000,
            system=system,
            messages=[{"role": "user", "content": instruction}],
        )
        return next(b.text for b in response.content if b.type == "text")

    if cfg.provider == "openai":
        messages = _openai_messages(spec, _SUMMARY_ROLE, [
            {"role": "user", "content": instruction},
        ])
        return _openai_chat_complete(cfg, messages=messages, max_tokens=8000)

    raise ValueError(f"Unknown LLM provider: {cfg.provider!r}")


# ---------------------------------------------------------------------------
# 3. Natural-language query
# ---------------------------------------------------------------------------

_QUERY_ROLE = (
    "You are a UDS (ISO 14229-1) diagnostic protocol expert answering "
    "questions about one specific ECU's configuration. Answer only from "
    "the supplied JSON spec — never from general UDS knowledge if the "
    "spec doesn't have the data. Be concise and cite hex values exactly "
    "as written."
)


def query_spec(
    spec: Any, question: str, *,
    model: Optional[str] = None,
    config: Optional[LLMConfig] = None,
) -> str:
    """Answer a natural-language question grounded in the UDS spec.

    Examples:
        query_spec(spec, "Which DIDs require security level 2?")
        query_spec(spec, "List every service that returns NRC 0x35.")
        query_spec(spec, "Is there a way to clear DTCs in DefaultSession?")

    Args:
        spec: Parsed UdsSpecification.
        question: The user's natural-language question.
        model: Model alias / full ID. Overrides `config.model` when set.
        config: LLM provider configuration. Defaults to `LLMConfig.auto()`.
    """
    cfg = _resolve_config(config=config, model=model)

    if cfg.provider == "anthropic":
        anthropic = _import_anthropic()
        client = _client(anthropic, api_key=cfg.api_key)
        system = _build_system_blocks(spec, role=_QUERY_ROLE)
        response = client.messages.create(
            model=cfg.resolved_model(),
            max_tokens=4000,
            system=system,
            messages=[{"role": "user", "content": question}],
        )
        return next(b.text for b in response.content if b.type == "text")

    if cfg.provider == "openai":
        messages = _openai_messages(spec, _QUERY_ROLE, [
            {"role": "user", "content": question},
        ])
        return _openai_chat_complete(cfg, messages=messages, max_tokens=4000)

    raise ValueError(f"Unknown LLM provider: {cfg.provider!r}")


# ---------------------------------------------------------------------------
# 4. Translation
# ---------------------------------------------------------------------------

_LANG_NAMES = {
    "en": "English",
    "ja": "Japanese",
    "de": "German",
}


def translate_text(
    text: str,
    target_lang: str,
    *,
    model: Optional[str] = None,
    source_lang: str = "auto",
    config: Optional[LLMConfig] = None,
) -> str:
    """Translate text between English, Japanese, and German.

    Preserves Markdown structure, code spans, hex values, and ISO references
    verbatim. Does not translate technical UDS keywords (SID/NRC/DID/RID/CanTp/
    DCM/DEM/DoIP/OBD/ECU/DTC/P2/P2*/S3/N_As/etc.).

    Args:
        text: The text to translate.
        target_lang: 'en' | 'ja' | 'de'.
        model: Model alias / full ID. Overrides `config.model` when set.
        source_lang: 'auto' (default) | 'en' | 'ja' | 'de'.
        config: LLM provider configuration. Defaults to `LLMConfig.auto()`.
    """
    cfg = _resolve_config(config=config, model=model)

    if target_lang not in _LANG_NAMES:
        raise ValueError(
            f"Unsupported target_lang: {target_lang!r}. "
            f"Use one of: {sorted(_LANG_NAMES)}"
        )
    target_name = _LANG_NAMES[target_lang]

    if source_lang == "auto":
        source_clause = "Detect the source language automatically."
    elif source_lang in _LANG_NAMES:
        source_clause = f"The source language is {_LANG_NAMES[source_lang]}."
    else:
        raise ValueError(
            f"Unsupported source_lang: {source_lang!r}. "
            f"Use 'auto' or one of: {sorted(_LANG_NAMES)}"
        )

    system = (
        "You are a technical translator specializing in automotive diagnostic "
        f"specifications. Translate the user-supplied text into {target_name}. "
        f"{source_clause}\n\n"
        "Preservation rules:\n"
        "  - Keep all Markdown formatting (headings, lists, tables, code spans)\n"
        "  - Keep hex values, ISO standard references, and technical IDs verbatim\n"
        "  - Do NOT translate UDS keywords: SID, NRC, DID, RID, CanTp, DCM, DEM, "
        "DoIP, OBD, ECU, DTC, P2, P2*, S3, N_As, N_Bs, N_Cs, N_Ar, N_Br, N_Cr\n"
        "  - Do NOT translate AUTOSAR container names (DcmDspDid, DemDTC, etc.)\n"
        "  - Output ONLY the translated text, no preamble or commentary"
    )

    if cfg.provider == "anthropic":
        anthropic = _import_anthropic()
        client = _client(anthropic, api_key=cfg.api_key)
        response = client.messages.create(
            model=cfg.resolved_model(),
            max_tokens=16000,
            system=system,
            messages=[{"role": "user", "content": text}],
        )
        return next(b.text for b in response.content if b.type == "text")

    if cfg.provider == "openai":
        # The translator doesn't need spec context — pass system + user only.
        return _openai_chat_complete(cfg, messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": text},
        ], max_tokens=16000)

    raise ValueError(f"Unknown LLM provider: {cfg.provider!r}")


# ---------------------------------------------------------------------------
# 5. Multi-turn streaming chat (browser UI / interactive use)
# ---------------------------------------------------------------------------

_CHAT_ROLE = (
    "You are a UDS (ISO 14229-1) diagnostic protocol expert helping an "
    "engineer explore one specific ECU's configuration through a "
    "conversational interface. Answer only from the supplied JSON spec — "
    "never from general UDS knowledge if the spec doesn't have the data. "
    "Cite hex values exactly as written. When the user's question is "
    "ambiguous, ask a clarifying question rather than guessing. Use "
    "Markdown for formatting (lists, code spans for hex values)."
)


def chat_stream(
    spec: Any,
    messages: list[dict],
    *,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
    config: Optional[LLMConfig] = None,
) -> Iterator[str]:
    """Stream a multi-turn chat response token-by-token (generator).

    Yields incremental text deltas as the model produces them. For the
    Anthropic backend, the spec JSON sits behind a 1-hour cache breakpoint
    in the system prompt; for OpenAI-compatible backends, the spec is sent
    as a regular system message (no cache, since semantics vary across
    OpenAI-compatible servers).

    Args:
        spec: Parsed UdsSpecification.
        messages: Conversation history — [{"role": "user"|"assistant",
                  "content": "..."}, ...]. Must start with a user turn.
        model: Model alias / full ID. Overrides `config.model` when set.
        api_key: Explicit API key. Overrides `config.api_key` when set.
        config: LLM provider configuration. Defaults to `LLMConfig.auto()`.

    Yields:
        str: Each successive text delta. Concatenating all yielded strings
             produces the full assistant response.

    Raises:
        ImportError: If the required SDK isn't installed.
        RuntimeError: If no API key is configured (cloud providers).
        ValueError: If `messages` is empty, malformed, or `provider` is
                    unknown.
    """
    if not messages:
        raise ValueError("messages must contain at least one user turn")
    if messages[0].get("role") != "user":
        raise ValueError("first message must have role='user'")

    cfg = _resolve_config(config=config, model=model, api_key=api_key)

    if cfg.provider == "anthropic":
        anthropic = _import_anthropic()
        client = _client(anthropic, api_key=cfg.api_key)
        system = _build_system_blocks(spec, role=_CHAT_ROLE)
        with client.messages.stream(
            model=cfg.resolved_model(),
            max_tokens=4096,
            system=system,
            messages=messages,
        ) as stream:
            for text in stream.text_stream:
                yield text
        return

    if cfg.provider == "openai":
        full_messages = _openai_messages(spec, _CHAT_ROLE, messages)
        yield from _openai_chat_stream(
            cfg, messages=full_messages, max_tokens=4096,
        )
        return

    raise ValueError(f"Unknown LLM provider: {cfg.provider!r}")


# ---------------------------------------------------------------------------
# 6. ECU test case rationale (WHY each test case exists)
# ---------------------------------------------------------------------------

_RATIONALE_ROLE = (
    "You are a UDS (ISO 14229-1) test engineer reviewing a generated ECU test "
    "suite. For each test case, explain in 1-3 sentences WHY it exists: which "
    "requirement, invariant, or failure mode it guards against. Be specific — "
    "cite the relevant SID, DID, NRC, or session by hex code. Write only what "
    "an engineer who inherits the test suite would find non-obvious."
)

_RATIONALE_SCHEMA: dict = {
    "type": "object",
    "properties": {
        "rationales": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "test_case_id": {"type": "string"},
                    "rationale": {"type": "string"},
                },
                "required": ["test_case_id", "rationale"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["rationales"],
    "additionalProperties": False,
}


def _test_cases_summary(cases: list) -> str:
    """Compact bullet summary of test cases for prompt injection."""
    lines: list[str] = []
    for tc in cases:
        tc_id = getattr(tc, "case_id", getattr(tc, "name", str(tc)))
        category = getattr(tc, "category", "")
        description = getattr(tc, "description", "")
        lines.append(f"- id={tc_id!r}, category={category!r}, description={description!r}")
    return "\n".join(lines)


def generate_test_rationale(
    spec: Any,
    cases: list,
    *,
    model: Optional[str] = None,
    config: Optional[LLMConfig] = None,
) -> dict[str, str]:
    """Generate WHY-focused rationales for each ECU test case.

    Uses the LLM to explain the requirement or failure mode each test case
    guards against, grounded in the actual spec JSON.

    Args:
        spec: Parsed UdsSpecification.
        cases: List of ``TestCase`` objects (from ``udsxml2tex.ecu_test``).
        model: Model alias / full ID. Overrides ``config.model`` when set.
        config: LLM provider configuration. Defaults to ``LLMConfig.auto()``.

    Returns:
        Dict mapping ``test_case_id`` (str) to a 1-3 sentence rationale string.
    """
    cfg = _resolve_config(config=config, model=model)
    tc_summary = _test_cases_summary(cases)
    instruction = (
        "Here is the complete list of generated test cases for this ECU.\n"
        "For EACH test case, write 1-3 sentences explaining WHY it exists — "
        "what requirement, UDS invariant, or failure mode it validates. "
        "Be concrete: cite SIDs, DIDs, sessions, or NRC codes by hex where relevant.\n\n"
        "Test cases:\n" + tc_summary + "\n\nReturn one entry per test_case_id."
    )

    if cfg.provider == "anthropic":
        return _rationale_anthropic(spec, cfg, instruction)
    if cfg.provider == "openai":
        return _rationale_openai(spec, cfg, instruction)
    raise ValueError(f"Unknown LLM provider: {cfg.provider!r}")


def _rationale_anthropic(spec: Any, cfg: LLMConfig, instruction: str) -> dict[str, str]:
    anthropic = _import_anthropic()
    client = _client(anthropic, api_key=cfg.api_key)
    system = _build_system_blocks(spec, role=_RATIONALE_ROLE)
    response = client.messages.create(
        model=cfg.resolved_model(),
        max_tokens=16000,
        system=system,
        messages=[{"role": "user", "content": instruction}],
        output_config={
            "format": {"type": "json_schema", "schema": _RATIONALE_SCHEMA},
        },
    )
    text = next(b.text for b in response.content if b.type == "text")
    data = json.loads(text)
    return {r["test_case_id"]: r["rationale"] for r in data["rationales"]}


def _rationale_openai(spec: Any, cfg: LLMConfig, instruction: str) -> dict[str, str]:
    mode = cfg.resolved_structured_mode()
    full_instruction = instruction + (
        "\n\nReturn ONLY a JSON object matching this schema:\n"
        + json.dumps(_RATIONALE_SCHEMA, indent=2)
    )
    messages = _openai_messages(spec, _RATIONALE_ROLE, [
        {"role": "user", "content": full_instruction},
    ])
    rf: Optional[dict] = (
        {"type": "json_object"} if mode in ("json_schema", "json_object") else None
    )
    text = _openai_chat_complete(cfg, messages=messages, max_tokens=16000, response_format=rf)
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("```", 2)[1]
        if cleaned.startswith("json"):
            cleaned = cleaned[4:].lstrip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise ValueError(f"Model returned non-JSON output: {cleaned[:200]}") from e
    return {r["test_case_id"]: r["rationale"] for r in data["rationales"]}


# ---------------------------------------------------------------------------
# 6. RTM Conditionally-Accepted comment vs. implementation verifier
# ---------------------------------------------------------------------------
#
# Lexical/numeric checks (rtm.condition_warnings / rtm.condition_notes) catch
# obvious divergences but cannot read English prose. This module asks the
# user-configured LLM whether the OEM Comment matches what the parsed ARXML
# actually implements, returning a structured verdict so the HTML UI can
# render a coloured banner alongside the rule-based warnings.

_RTM_VERIFY_ROLE = (
    "You are an embedded-systems compliance reviewer. The user gives you "
    "one Conditionally-Accepted OEM requirement and an excerpt from the "
    "parsed AUTOSAR DCM configuration. Decide whether the OEM Comment's "
    "deviation description matches what the implementation actually ships. "
    "Be conservative: if you cannot decide from the excerpt alone, return "
    "'uncertain' with a one-sentence note about what was missing."
)

_RTM_VERIFY_SCHEMA = {
    "type": "object",
    "properties": {
        "verdict": {
            "type": "string",
            "enum": ["matches", "deviates", "uncertain"],
            "description": (
                "matches = the Comment describes the implementation faithfully; "
                "deviates = the implementation does NOT match the Comment "
                "(legitimate compliance gap); "
                "uncertain = excerpt insufficient to decide."
            ),
        },
        "rationale": {
            "type": "string",
            "description": "Two-to-four sentence explanation citing concrete "
                            "values from the excerpt (no generalities).",
        },
        "evidence": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Up to five concrete bullet points from the "
                            "excerpt that supported the verdict.",
        },
    },
    "required": ["verdict", "rationale"],
}


def verify_rtm_condition(
    *,
    req_id: str,
    description: str,
    comment: str,
    traces_to: str,
    spec_excerpt: str,
    config: Optional[LLMConfig] = None,
) -> dict:
    """Ask the LLM whether an OEM Conditional Comment matches the impl.

    Returns ``{"verdict": str, "rationale": str, "evidence": list[str]}``.
    ``verdict`` is one of ``"matches"``, ``"deviates"``, ``"uncertain"``.
    Raises :class:`ValueError` on malformed model output and the underlying
    transport error on connection failure.
    """
    cfg = config or LLMConfig.auto()

    instruction = (
        f"Requirement {req_id}\n"
        f"Description: {description}\n"
        f"Trace target(s): {traces_to}\n\n"
        f"OEM Comment (Conditionally Accepted):\n{comment}\n\n"
        f"Parsed ARXML excerpt (only the relevant slice — DcmDsd / "
        f"DcmDsl / DcmDsp configuration, ISO 14229 mapping, related "
        f"DIDs / RIDs / sessions / security levels):\n{spec_excerpt}\n\n"
        f"Decide whether the OEM Comment's deviation description matches "
        f"the supplied ARXML excerpt. Cite concrete values (hex IDs, "
        f"timing in ms, NRC codes, session names) from the excerpt in "
        f"your rationale."
    )

    if cfg.provider == "anthropic":
        client = _anthropic_client(cfg)
        response = client.messages.create(
            model=cfg.resolved_model(),
            max_tokens=2000,
            system=_RTM_VERIFY_ROLE,
            messages=[{"role": "user", "content": instruction}],
            output_config={
                "format": {"type": "json_schema",
                            "schema": _RTM_VERIFY_SCHEMA},
            },
        )
        text = next(b.text for b in response.content if b.type == "text")
    else:
        mode = cfg.resolved_structured_mode()
        full_instruction = instruction + (
            "\n\nReturn ONLY a JSON object matching this schema (no "
            "Markdown fences, no commentary):\n"
            + json.dumps(_RTM_VERIFY_SCHEMA, indent=2)
        )
        messages = [
            {"role": "system", "content": _RTM_VERIFY_ROLE},
            {"role": "user", "content": full_instruction},
        ]
        rf: Optional[dict] = (
            {"type": "json_object"}
            if mode in ("json_schema", "json_object") else None
        )
        text = _openai_chat_complete(
            cfg, messages=messages, max_tokens=2000, response_format=rf,
        )

    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("```", 2)[1]
        if cleaned.startswith("json"):
            cleaned = cleaned[4:].lstrip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise ValueError(
            f"RTM verifier returned non-JSON output: {cleaned[:300]}"
        ) from e
    return {
        "verdict": str(data.get("verdict", "uncertain")),
        "rationale": str(data.get("rationale", "")),
        "evidence": list(data.get("evidence", []) or []),
    }
