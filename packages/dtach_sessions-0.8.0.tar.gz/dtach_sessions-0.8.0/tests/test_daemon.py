"""Tests for daemon start/stop lifecycle, socket cleanup, and NDJSON protocol.

Tasks 2.6 and 2.7 of the daemon sprint.  Tests the real DsmDaemon — no mocks.
Uses tmp_path for socket and registry isolation.  Since pytest-asyncio is not
installed, each test uses asyncio.run() internally.
"""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path

import pytest

from dsm.daemon import DsmDaemon, _load_reserved_host_ports
from dsm.registry import ContainerRegistry


# ── Helpers ──────────────────────────────────────────────────────────────────


async def _send_recv(
    socket_path: Path,
    request: dict | str,
) -> dict:
    """Connect, send a single NDJSON request, read one response, close."""
    reader, writer = await asyncio.open_unix_connection(str(socket_path))
    if isinstance(request, dict):
        payload = json.dumps(request).encode() + b"\n"
    else:
        payload = request.encode() if isinstance(request, str) else request
        if not payload.endswith(b"\n"):
            payload += b"\n"
    writer.write(payload)
    await writer.drain()
    line = await asyncio.wait_for(reader.readline(), timeout=5)
    writer.close()
    await writer.wait_closed()
    return json.loads(line)


async def _start_daemon(tmp_path: Path) -> DsmDaemon:
    """Create, start, and return a daemon using tmp_path for isolation."""
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
    await daemon.start()
    return daemon


# ── Task 2.6: Lifecycle and socket cleanup ───────────────────────────────────


def test_daemon_creates_socket(tmp_path: Path):
    """Daemon start creates the Unix socket file."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            assert daemon.socket_path.exists()
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_daemon_accepts_connection(tmp_path: Path):
    """Daemon accepts a client connection on the socket."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            reader, writer = await asyncio.open_unix_connection(
                str(daemon.socket_path)
            )
            # Connection succeeded — send a simple command to confirm
            writer.write(json.dumps({"cmd": "status"}).encode() + b"\n")
            await writer.drain()
            line = await asyncio.wait_for(reader.readline(), timeout=5)
            assert line  # got a response
            writer.close()
            await writer.wait_closed()
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_daemon_stop_removes_socket(tmp_path: Path):
    """Daemon stop cleans up the socket file."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        sock_path = daemon.socket_path
        assert sock_path.exists()
        await daemon.stop()
        assert not sock_path.exists()

    asyncio.run(_run())


def test_clean_shutdown_persists_registry(tmp_path: Path):
    """Clean shutdown persists registry state to disk."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        # Register a container via the protocol
        resp = await _send_recv(
            daemon.socket_path,
            {"cmd": "register_container", "container": "web", "container_id": "abc123", "ip": "10.0.0.2"},
        )
        assert resp["error"] is None

        await daemon.stop()

        # Verify persisted to disk
        reg_file = tmp_path / "registry" / "web.json"
        assert reg_file.exists()
        data = json.loads(reg_file.read_text())
        assert data["container_name"] == "web"
        assert data["container_id"] == "abc123"
        assert data["container_ip"] == "10.0.0.2"

    asyncio.run(_run())


# ── Task 2.7: NDJSON protocol round-trip ─────────────────────────────────────


def test_status_command(tmp_path: Path):
    """status command returns pid, uptime, containers, and forwards."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            resp = await _send_recv(daemon.socket_path, {"cmd": "status"})
            assert resp["error"] is None
            result = resp["result"]
            assert "pid" in result
            assert result["pid"] == os.getpid()
            assert "uptime" in result
            assert isinstance(result["uptime"], (int, float))
            assert "containers" in result
            assert "forwards" in result
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_register_container_command(tmp_path: Path):
    """register_container returns the created entry."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            resp = await _send_recv(
                daemon.socket_path,
                {
                    "cmd": "register_container",
                    "container": "test",
                    "container_id": "abc",
                    "ip": "1.2.3.4",
                },
            )
            assert resp["error"] is None
            result = resp["result"]
            assert result["container_name"] == "test"
            assert result["container_id"] == "abc"
            assert result["container_ip"] == "1.2.3.4"
            assert result["status"] == "running"
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_list_containers_shows_registered(tmp_path: Path):
    """list_containers returns previously registered containers."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            # Register first
            await _send_recv(
                daemon.socket_path,
                {
                    "cmd": "register_container",
                    "container": "test",
                    "container_id": "abc",
                    "ip": "1.2.3.4",
                },
            )
            # List
            resp = await _send_recv(daemon.socket_path, {"cmd": "list_containers"})
            assert resp["error"] is None
            containers = resp["result"]
            assert len(containers) == 1
            assert containers[0]["container_name"] == "test"
            assert containers[0]["container_id"] == "abc"
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_cleanup_stale_forwards_on_startup(tmp_path: Path):
    """Daemon startup prunes ForwardInfo entries with dead PIDs."""
    from dsm.registry import ContainerRegistry, ForwardInfo

    reg_dir = tmp_path / "registry"
    registry = ContainerRegistry(reg_dir)
    registry.load()

    # Register a container with a forward whose PID is definitely dead
    entry = registry.register("stale_test", "abc123", "172.17.0.2")
    entry.forwards.append(ForwardInfo(
        container_port=8080, host_port=8080, socat_pid=999999999, alive=True,
    ))
    registry.persist("stale_test")

    async def _run():
        sock = tmp_path / "dsm.sock"
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        await daemon.start()
        try:
            # The stale forward should have been pruned on startup
            cleaned_entry = daemon.registry.get("stale_test")
            assert cleaned_entry is not None
            assert len(cleaned_entry.forwards) == 0
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_remove_container_command(tmp_path: Path):
    """remove_container deregisters a container and deletes its registry file."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            # Register a container first
            await _send_recv(daemon.socket_path, {
                "id": "1", "cmd": "register_container",
                "container": "to_remove", "container_id": "abc", "ip": "172.17.0.2",
            })

            # Remove it
            resp = await _send_recv(daemon.socket_path, {
                "id": "2", "cmd": "remove_container", "container": "to_remove",
            })
            assert resp["error"] is None
            assert resp["result"]["removed"] == "to_remove"

            # Verify it's gone
            resp = await _send_recv(daemon.socket_path, {
                "id": "3", "cmd": "get_container", "container": "to_remove",
            })
            assert resp["error"] is not None
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_malformed_json_returns_error(tmp_path: Path):
    """Sending malformed JSON returns an error response (not a crash)."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            resp = await _send_recv(daemon.socket_path, "this is not json\n")
            assert resp["error"] is not None
            assert resp["result"] is None
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_create_container_command(tmp_path: Path):
    """create_container runs docker, registers, and returns entry."""
    from unittest.mock import patch, MagicMock
    import subprocess as sp

    def mock_run(cmd, **kw):
        result = MagicMock()
        result.returncode = 0
        result.stderr = ""
        if "inspect" in cmd and "{{.Id}}" in cmd:
            result.stdout = "abc123def456\n"
        elif "inspect" in cmd:
            result.stdout = "172.17.0.5\n"
        else:
            result.stdout = ""
        return result

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            with patch("dsm.daemon.subprocess.run", side_effect=mock_run):
                resp = await _send_recv(daemon.socket_path, {
                    "id": "1", "cmd": "create_container",
                    "container_name": "test_ctr",
                    "docker_cmd": ["docker", "run", "-d", "--name", "test_ctr", "img"],
                })
            assert resp["error"] is None
            entry = resp["result"]
            assert entry["container_name"] == "test_ctr"
            assert entry["container_id"] == "abc123def456"
            assert entry["container_ip"] == "172.17.0.5"
            assert entry["status"] == "running"
            assert entry["docker_cmd"] == ["docker", "run", "-d", "--name", "test_ctr", "img"]

            # Verify it shows up in list
            resp2 = await _send_recv(daemon.socket_path, {"id": "2", "cmd": "list_containers"})
            assert len(resp2["result"]) == 1
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_start_container_command(tmp_path: Path):
    """start_container starts a stopped container and updates registry."""
    from unittest.mock import patch, MagicMock

    def mock_run(cmd, **kw):
        result = MagicMock()
        result.returncode = 0
        result.stderr = ""
        if "inspect" in cmd and "{{.Id}}" in cmd:
            result.stdout = "abc123\n"
        elif "inspect" in cmd:
            result.stdout = "172.17.0.6\n"
        else:
            result.stdout = ""
        return result

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            # Pre-register a stopped container
            entry = daemon.registry.register("test_ctr", "abc123", "172.17.0.5")
            daemon.registry.update("test_ctr", status="stopped")
            daemon.registry.persist("test_ctr")

            with patch("dsm.daemon.subprocess.run", side_effect=mock_run):
                resp = await _send_recv(daemon.socket_path, {
                    "id": "1", "cmd": "start_container", "container": "test_ctr",
                })
            assert resp["error"] is None
            assert resp["result"]["status"] == "running"
            assert resp["result"]["container_ip"] == "172.17.0.6"
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_stop_container_command(tmp_path: Path):
    """stop_container stops a container and updates status."""
    from unittest.mock import patch, MagicMock

    def mock_run(cmd, **kw):
        result = MagicMock()
        result.returncode = 0
        result.stdout = ""
        result.stderr = ""
        return result

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            daemon.registry.register("test_ctr", "abc123", "172.17.0.5")
            daemon.registry.persist("test_ctr")

            with patch("dsm.daemon.subprocess.run", side_effect=mock_run):
                resp = await _send_recv(daemon.socket_path, {
                    "id": "1", "cmd": "stop_container", "container": "test_ctr",
                })
            assert resp["error"] is None
            assert resp["result"]["stopped"] == "test_ctr"
            # Verify status updated
            entry = daemon.registry.get("test_ctr")
            assert entry.status == "stopped"
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_remove_container_with_docker(tmp_path: Path):
    """remove_container calls docker stop/rm and deregisters."""
    from unittest.mock import patch, MagicMock
    docker_calls = []

    def mock_run(cmd, **kw):
        docker_calls.append(cmd)
        result = MagicMock()
        result.returncode = 0
        result.stdout = ""
        result.stderr = ""
        return result

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            daemon.registry.register("test_ctr", "abc123", "172.17.0.5")
            daemon.registry.persist("test_ctr")

            with patch("dsm.daemon.subprocess.run", side_effect=mock_run):
                resp = await _send_recv(daemon.socket_path, {
                    "id": "1", "cmd": "remove_container", "container": "test_ctr",
                })
            assert resp["error"] is None
            assert resp["result"]["removed"] == "test_ctr"
            # Verify docker stop and rm were called
            assert any("stop" in c for c in docker_calls)
            assert any("rm" in c for c in docker_calls)
            # Verify deregistered
            assert daemon.registry.get("test_ctr") is None
            # Verify registry file deleted
            assert not (tmp_path / "registry" / "test_ctr.json").exists()
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_remove_container_force_unknown(tmp_path: Path):
    """remove_container with force=True succeeds even if not in registry."""
    from unittest.mock import patch, MagicMock

    def mock_run(cmd, **kw):
        result = MagicMock()
        result.returncode = 0
        result.stdout = ""
        result.stderr = ""
        return result

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            with patch("dsm.daemon.subprocess.run", side_effect=mock_run):
                resp = await _send_recv(daemon.socket_path, {
                    "id": "1", "cmd": "remove_container",
                    "container": "nonexistent", "force": True,
                })
            assert resp["error"] is None
            assert resp["result"]["removed"] == "nonexistent"
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_shutdown_command_stops_daemon(tmp_path: Path):
    """shutdown command causes the daemon to stop and remove the socket."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        sock_path = daemon.socket_path

        # Send shutdown — daemon schedules stop after responding
        resp = await _send_recv(sock_path, {"cmd": "shutdown"})
        assert resp["error"] is None

        # Give the daemon a moment to complete shutdown
        # The stop is scheduled via call_soon + ensure_future
        await asyncio.sleep(0.2)

        assert not sock_path.exists()

    asyncio.run(_run())


# ── reserved_host_ports loader ──────────────────────────────────────────────


def test_reserved_host_ports_missing_file(tmp_path: Path):
    assert _load_reserved_host_ports(tmp_path / "nope.json") == set()


def test_reserved_host_ports_list_form(tmp_path: Path):
    cfg = tmp_path / "config.json"
    cfg.write_text(json.dumps({"reserved_host_ports": [8007, 8018, 5189]}))
    assert _load_reserved_host_ports(cfg) == {8007, 8018, 5189}


def test_reserved_host_ports_dict_form(tmp_path: Path):
    """Dict form documents what each port is for; daemon reads only the keys."""
    cfg = tmp_path / "config.json"
    cfg.write_text(json.dumps({"reserved_host_ports": {
        "8007": "coder_ui prod backend",
        "5189": "coder_ui Vite dev",
    }}))
    assert _load_reserved_host_ports(cfg) == {8007, 5189}


def test_reserved_host_ports_skips_garbage(tmp_path: Path):
    cfg = tmp_path / "config.json"
    cfg.write_text(json.dumps({"reserved_host_ports": [8007, "not-a-port", None]}))
    assert _load_reserved_host_ports(cfg) == {8007}
