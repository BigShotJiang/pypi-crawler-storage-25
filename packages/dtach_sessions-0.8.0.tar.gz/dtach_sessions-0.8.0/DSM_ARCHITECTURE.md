# DSM Architecture: Features, Constraints, and Required Changes

This document is a comprehensive brief for an agent working in the dsm directory. It covers every DSM feature, the architectural constraints imposed by its primary consumer (ui_coder), known structural issues, and the exact changes needed to reach the correct architecture.

---

## 1. What DSM Is

**dtach session manager** — creates and manages persistent detachable terminal sessions for local, SSH, and Docker container workflows. Provides a background daemon for container lifecycle management, automatic port forwarding, and git worktree isolation.

**Primary consumer:** `ui_coder` — a desktop Claude Code IDE. ui_coder delegates all container operations to dsm via direct function imports from `dsm.cli`.

---

## 2. Complete Feature Inventory

### 2.1 Session Types

| Type | Command | Description |
|------|---------|-------------|
| Local | `dsm local -t TITLE -- CMD` | dtach session in current terminal |
| SSH | `dsm ssh HOST [-t TITLE] [SSH_ARGS]` | SSH session with keepalive |
| Container | `dsm container -t TITLE REPO BRANCH` | Docker container with git worktree |

All sessions get: unique ID, metadata (JSON), dtach socket, output log file.

### 2.2 CLI Subcommands (13)

| Command | Purpose |
|---------|---------|
| `local` | Create local dtach session |
| `ssh` | Create SSH session |
| `container` | Create container session with optional worktree |
| `list` | List active sessions (tabular output) |
| `resume` | Reattach to session via dtach |
| `tail` | Stream session output (live follow) |
| `rm` | Remove session and clean up |
| `clean` | Remove dead/orphaned sessions |
| `alias set\|ls\|rm` | Manage SSH host aliases |
| `ports` | List detected ports and forwards (optionally `--watch`) |
| `forward` | Forward a container port to host |
| `unforward` | Stop forwarding a port |
| `daemon start\|stop\|status` | Manage the background daemon |

### 2.3 Daemon Commands (16)

The daemon (`DsmDaemon`) listens on a Unix socket (`~/.dsm/dsm.sock`) using NDJSON protocol. Commands:

| Command | Purpose |
|---------|---------|
| `create_container` | Run pre-built `docker run` command |
| `start_container` | Start stopped container + re-register |
| `stop_container` | Stop running container |
| `remove_container` | Remove container (optional force) |
| `list_containers` | List registered containers |
| `scan_ports` | One-shot port scan on a container |
| `forward_port` | Create socat forward for a port |
| `unforward_port` | Remove socat forward |
| `list_forwards` | List active forwards |
| `subscribe` | Subscribe to real-time events |
| `unsubscribe` | Unsubscribe from events |
| `status` | Daemon status |
| `ping` | Health check |
| `stop` | Graceful daemon shutdown |
| `list_sessions` | List dsm sessions |
| `remove_session` | Remove a session |

**Key design:** The daemon is a "dumb executor" — it receives pre-built docker commands and runs them. Layout validation lives in `ensure_container`, not the daemon.

### 2.4 Configuration System

Config at `~/.dsm/config.json`. Supports named profiles:

```json
{
  "profiles": {
    "default": {
      "image": "patricksulin/devcontainer:latest",
      "default_access": "ro",
      "repos_dir": "~/repos/dev",
      "repos": ["dsm", "ui_coder"],
      "ssh": { "keys": ["~/.ssh/id_ed25519"] },
      "env": { "ANTHROPIC_API_KEY": "${ANTHROPIC_API_KEY}" },
      "ports": { "auto_forward": true, "scan_interval": 3 }
    }
  }
}
```

Features: image selection, default access mode, repo directory discovery, explicit repo mounts, SSH key forwarding, environment variable expansion (`${VAR}`), port auto-forwarding config, scan intervals.

### 2.5 Port Detection & Forwarding

- **PortWatcher** — polls `/proc/net/tcp` inside containers via `docker exec`, diffs against previous state, emits `PortChange` events
- **ForwardHandle** — manages `socat`-based port forwards (host ↔ container)
- **Registry** — persistent JSON files per container in `~/.dsm/registry/`, tracking metadata, ports, and forwards
- Survives daemon restarts

### 2.6 Agent Context Injection

`_generate_agent_context()` creates a `CLAUDE.md` file mounted into containers. Contains:
- Container environment description
- Available repo mounts and their access modes
- DSM environment variables (container name, repo path, branch)
- Worktree layout documentation

### 2.7 Volume Mount Building

`build_volume_mounts()` builds volume specs from config:
- Discovers repos in `repos_dir` and mounts each at `/repos/{name}`
- Mounts explicitly listed repos
- SSH key mounts
- Access mode control (ro/rw per mount)

### 2.8 Key Functions (with file locations)

| Function | Location | Purpose |
|----------|----------|---------|
| `ensure_container` | cli.py:772 | Single owner of canonical container layout |
| `build_docker_run_cmd` | cli.py:1209 | Builds `docker run` command with all mounts |
| `create_worktree_in_container` | cli.py:870 | Creates worktree inside container via `docker exec` |
| `create_git_worktree` | cli.py:~930 | Creates worktree on HOST (non-container flows only) |
| `container_has_mount` | cli.py:751 | Validates container has expected bind mount |
| `get_container_state` | cli.py:761 | Returns "running", "exited", or None |
| `cmd_container` | cli.py:1253 | CLI entry point — thin wrapper around ensure_container |
| `build_volume_mounts` | cli.py | Config-driven volume mount building |
| `build_env_vars` | cli.py | Config + arg env var building |
| `_generate_agent_context` | cli.py:~601 | Creates CLAUDE.md for container |
| `_build_dsm_env_vars` | cli.py | DSM-specific env vars for container |

---

## 3. Canonical Container Layout

`ensure_container` owns this layout. No other function creates containers.

```
Container filesystem:
/workspace     ← repo root (bind from host repo_path)
/worktrees     ← worktree home (bind from {repo_path}-worktrees/)
/worktrees/{branch}  ← individual worktrees (created by git worktree add)
/repos/{name}  ← other repos (read-only, from config)
```

Host filesystem:
```
~/repos/dev/my-repo/           ← repo root (mounted at /workspace)
~/repos/dev/my-repo-worktrees/ ← worktree bind mount (mounted at /worktrees)
~/repos/dev/my-repo-worktrees/feature-x/  ← worktree files visible on host
```

**Current state:** `ensure_container` passes `workspace_access="rw"` by default. `cmd_container` (CLI) passes the config-driven access mode (default "ro" unless branch specified).

---

## 4. The Architectural Constraint: ui_coder's Model

ui_coder's model is:
1. **One container per repo** — container stays alive across tasks
2. **Git worktrees per branch** — each task gets a worktree inside the container
3. **Host watches files** — inotify on host-side bind mounts detects changes from container
4. **Events propagate to UI** — file changes → artifact updates → WebSocket → frontend

This model requires:
- Container worktrees visible on host via bind mounts (for file watching) ✅
- Host can run git commands on container-created worktrees (for merge, diff, status) — needs `GIT_DIR`/`GIT_WORK_TREE` env vars because container-created `.git` files have container paths
- Main branch (at `/workspace`) should be **protected from accidental writes** while git metadata (`.git/`) remains **writable** for worktree creation and commits

---

## 5. The Mount Access Mode Problem ("The Doom Loop")

### The Conflict

Git operations inside the container need to write to `/workspace/.git/` (worktree metadata, refs, objects). But `/workspace` should be read-only to protect the main branch source files from accidental modification.

**Attempted solutions and why they fail:**

| Approach | Problem |
|----------|---------|
| `/workspace:rw` | Exposes main branch source to writes. Agent can modify files on main. |
| `/workspace:ro` | Blocks ALL writes including `.git/`. Can't create worktrees, can't commit. |
| Host-created worktrees | `.git` file has host paths → doesn't resolve inside container |
| Container worktrees + ro | Can't write `.git/worktrees/` metadata |
| Bare repo in container | No working tree to protect, but disruptive to host layout and breaks `git log`, `git diff`, etc. on host without extra config |

### The Solution: `.git` Overlay Mount

Docker bind mounts support overlaying — a more specific mount path overrides its parent. This is standard Docker behavior, not a hack.

```
-v /host/repo:/workspace:ro          # Repo root: read-only (protects source)
-v /host/repo/.git:/workspace/.git:rw  # Git metadata: read-write (allows git ops)
```

This gives:
- `/workspace/*.py`, `/workspace/src/` → read-only (protected)
- `/workspace/.git/` → read-write (worktrees, commits, refs all work)
- `/worktrees/` → read-write (already handled)

**inotify still works** — kernel-level, operates on inodes, unaffected by mount access modes.

### Where the Change Goes

`build_docker_run_cmd` (cli.py:1209) — after the `/workspace` mount line:

```python
docker_cmd = [
    "docker", "run", "-d", "--name", container_name,
    "-v", f"{mount_path}:/workspace:{ws_access}",
    "-w", "/workspace",
]

# .git overlay: when workspace is read-only, overlay .git as read-write
# so git operations (worktree add, commit, fetch) still work
if ws_access == "ro":
    git_dir = Path(mount_path) / ".git"
    if git_dir.exists():
        docker_cmd.extend(["-v", f"{git_dir}:/workspace/.git:rw"])
```

**Also needed:** `container_has_mount` validation in `ensure_container` should check for the `.git` overlay mount when workspace is `ro`. Old containers without it should be recreated.

### The Bare Repo Alternative

A bare repo inside the container eliminates the access mode tension entirely — there's no working tree to protect because bare repos don't have one. All work happens in worktrees.

**Pros:**
- No mount access conflict — there's no source tree to protect
- Cleaner separation of concerns
- Git operations always work (no mount mode issues)

**Cons:**
- Disruptive to existing host layout (host still has a normal repo)
- Host-side `git log`, `git diff`, `git status` need `--git-dir` or `GIT_DIR`
- Agent context changes (no `/workspace` with source to browse)
- More migration complexity

**Recommendation:** The `.git` overlay is the pragmatic fix. It solves the problem with minimal disruption, uses standard Docker semantics, and preserves all existing workflows. The bare repo approach is architecturally cleaner but the migration cost isn't justified.

---

## 6. What Needs to Change in DSM

### Change 1: `.git` overlay mount in `build_docker_run_cmd`

**File:** `src/dsm/cli.py`, function `build_docker_run_cmd` (~line 1223)

**What:** When `ws_access == "ro"` and the repo has a `.git` directory, add an overlay mount for `.git:rw`.

**Why:** Allows git operations (worktree creation, commits, fetches) while keeping source files read-only.

### Change 2: Layout validation for `.git` overlay

**File:** `src/dsm/cli.py`, function `ensure_container` (~line 815)

**What:** When a container's workspace is mounted `ro`, validate that the `.git` overlay mount exists. If missing (old container), recreate.

**Why:** Backward compatibility — old containers created before this change won't have the overlay.

### Change 3: Update `_generate_agent_context`

**File:** `src/dsm/cli.py`, function `_generate_agent_context` (~line 601)

**What:** Document the mount layout including the `.git` overlay, so agents inside containers understand what's writable and what's not.

### Change 4: Default access mode alignment

**File:** `src/dsm/cli.py`

**Current state:** `ensure_container` defaults to `workspace_access="rw"`. `cmd_container` reads from config (default `"ro"`). ui_coder's `ContainerService.ensure_container` also defaults to config's `default_access`.

**What:** Ensure the default is consistent. With the `.git` overlay in place, `"ro"` is safe and should be the universal default.

### Change 5: Update tests

**File:** `tests/test_config.py` and potentially new test file

**What:** Test the `.git` overlay mount is added when `ws_access == "ro"`, test validation catches missing overlay on existing containers, test that `build_docker_run_cmd` output includes the overlay mount.

### Change 6: Config documentation

**File:** `config.example.json`

**What:** Document that `default_access: "ro"` is now safe for all workflows because `.git` gets an overlay mount automatically.

---

## 7. What Does NOT Need to Change in DSM

- **Daemon** — remains a dumb executor. Layout decisions stay in `ensure_container`.
- **Port watching/forwarding** — orthogonal to mount layout.
- **Registry** — no schema changes needed.
- **Session management** (local, SSH, list, resume, tail, rm, clean) — unaffected.
- **`create_worktree_in_container`** — already correct (creates at `/worktrees/{branch}` via `docker exec`).
- **`create_git_worktree`** — host-side worktree creation for non-container flows. Unaffected.

---

## 8. Interaction with ui_coder

ui_coder imports these dsm functions directly:

```python
from dsm.cli import (
    build_env_vars,
    build_volume_mounts,
    ensure_container as dsm_ensure_container,
    create_worktree_in_container as dsm_create_worktree,
    get_container_state,
    get_named_config,
    load_meta, save_meta, find_session,
    DSM_DIR, REGISTRY_DIR,
)
```

ui_coder's `ContainerService.ensure_container` adds its own volumes (`.claude`, `.claude.json`) then delegates to `dsm_ensure_container`. It does NOT add the `/worktrees` mount — dsm owns that.

**After these changes:** ui_coder needs no modifications. The `.git` overlay is added by dsm's `build_docker_run_cmd`, which ui_coder reaches through `dsm_ensure_container`. The access mode flows through from config.

---

## 9. Testing Strategy

| Test | What it validates |
|------|-------------------|
| `build_docker_run_cmd` with `ws_access="ro"` and `.git` exists | `.git` overlay mount present in command |
| `build_docker_run_cmd` with `ws_access="ro"` and no `.git` | No overlay mount (bare repo case) |
| `build_docker_run_cmd` with `ws_access="rw"` | No overlay mount (not needed) |
| `ensure_container` with existing ro container missing `.git` overlay | Container recreated |
| `ensure_container` with existing ro container WITH `.git` overlay | Container reused |
| Agent context includes overlay documentation | `_generate_agent_context` output |

---

## 10. Summary

DSM's mount access mode has a fundamental tension: read-only workspace protects source but blocks git operations. The `.git` overlay mount resolves this cleanly using standard Docker semantics. The change is localized to `build_docker_run_cmd` (add the overlay) and `ensure_container` (validate it), with test and documentation updates. No changes needed to the daemon, registry, port system, or ui_coder.
