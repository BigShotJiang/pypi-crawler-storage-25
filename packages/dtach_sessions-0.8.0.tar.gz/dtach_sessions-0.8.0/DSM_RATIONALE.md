# DSM Rationale: Why It Exists and What It Must Do

This document establishes DSM's reason for being, its core capabilities, and why each is built rather than delegated to an existing tool. Architecture and implementation follow from this — not the other way around.

---

## 1. What DSM Is

**dtach session manager** — a CLI tool and Python library for managing persistent detachable terminal sessions across local, SSH, and Docker container workflows.

**The one-line framing: DSM owns the workspace, not the workflow.**

DSM creates and manages the environments where work happens — containers, mounts, worktrees, port forwards, agent context. What you do inside those environments (git operations, file edits, running servers) is your business. When you need to change the environment itself (create a worktree, delete a container, forward a port), you come back to DSM.

**Two interfaces:**
- **CLI** — standalone terminal tool for managing sessions (`dsm local`, `dsm container`, `dsm list`, `dsm resume`, etc.)
- **Library** — Python API for programmatic use. The CLI is a thin wrapper over this API. Both interfaces offer the same operations with the same guarantees.

**Primary consumer:** ui_coder (desktop Claude Code IDE). But DSM is fully functional standalone at the CLI.

**Design constraint:** Zero runtime dependencies. Stdlib only.

---

## 2. Policies

These policies define DSM's responsibilities, boundaries, and the expected behavior of its consumers. They are the architecture. Enforcement comes later — some can be enforced structurally (filesystem permissions), others are conventions that consumers are expected to follow.

### Policy 1: The container is the only real isolation boundary

The agent lives inside the container. Its world is defined entirely by what DSM mounts into it. DSM controls what the agent can see and write via mount configuration (ro/rw). The agent cannot reach anything DSM doesn't mount.

This is the one boundary that IS enforced — by Docker, not by DSM. DSM's job is to set up the mounts correctly.

### Policy 2: DSM owns container and worktree lifecycle

DSM creates containers, defines the mount layout, and manages worktrees. Any application that wants a container goes through DSM. No direct `docker run`.

What DSM owns:
- Container creation with canonical volume layout
- Mount access modes (ro/rw) — the structural enforcement of what's writable
- Worktree creation and deletion (because these affect the mount layout)
- Port detection and forwarding
- Agent context injection (telling the agent what it has access to)

### Policy 3: DSM does not own git operations or workflow

Merge, rebase, commit, push, status, diff — these are the consumer's responsibility. DSM provides the environment where they can happen safely. It does not wrap, mediate, or gate git commands.

The exception: worktree creation and deletion ARE DSM operations because they change the physical mount layout that DSM owns. But `git merge`, `git commit`, etc. within a worktree are not DSM's concern.

### Policy 4: Host-side access is unconstrained but conventioned

DSM and ui_coder both run on the host as the same OS user. Neither can truly prevent the other from doing anything. Enforcing host-side isolation would require OS-level user/permission separation, which is out of scope.

The convention is:
- **Reads are always fine.** ui_coder can freely read worktree files (via bind mounts), git state (via `GIT_DIR`/`GIT_WORK_TREE`), and container state.
- **Writes that change DSM's layout should go through DSM.** Creating/deleting worktrees, creating/removing containers. Not because DSM will block you, but because DSM needs to know.
- **Writes within a worktree are the consumer's business.** If ui_coder runs `git merge` on the host after the user clicks "merge" in the UI, that's fine — it's a workflow operation, not a layout operation.

### Policy 5: DSM emits events about things it owns

Port changes, container state changes, worktree lifecycle events. These are things DSM knows about because they happen through DSM.

DSM does NOT emit:
- File change events (ui_coder handles this via inotify on host-side bind mounts)
- Git state change events (consumer's domain)

DSM DOES ensure the bind mounts are set up so consumers CAN watch for file changes.

### Policy 6: DSM provides context to agents

The CLAUDE.md injection tells the agent what it has access to, where things are mounted, and what's writable vs. read-only. This is documentation, not enforcement — the ro mount IS the enforcement.

---

## 3. Directions of Control

How operations flow between the user, ui_coder, DSM, and the container.

```
User action (UI click "merge")
  → ui_coder executes git merge on host (workflow operation, not DSM's job)
  → ui_coder calls dsm.api.remove_worktree() if branch is done (layout operation, DSM's job)
  → DSM cleans up worktree, updates registry, emits event

User action (UI click "new task")
  → ui_coder calls dsm.api.ensure_container() then dsm.api.create_worktree()
  → DSM creates/reuses container, creates worktree, emits event
  → Agent starts inside container, constrained by mounts

Agent works inside container
  → Edits files, runs git commands in its worktree — unconstrained within mount permissions
  → Changes visible on host via bind mounts
  → ui_coder detects changes via inotify (host-side, not DSM)

Port activity inside container
  → DSM's port watcher detects new listening port
  → DSM auto-forwards via socat, emits port_added event
  → ui_coder receives event, updates UI
```

**What DSM does NOT need to know about:**
- Which git commands the agent runs inside its worktree
- Whether ui_coder merged a branch on the host
- What files changed (that's inotify's job on the host)

**What DSM DOES need to know about:**
- Worktree creation/deletion (it owns the layout)
- Container start/stop/removal (it owns the container)
- Port changes (it owns the forwards)

---

## 4. Core Capabilities

### 4.1 Persistent Detachable Sessions

**What:** Wrap commands in dtach sessions with metadata tracking (ID, title, status, output log). Sessions survive terminal disconnects. Users can list, resume, tail, and remove sessions.

**Why build it:**
- dtach provides the detach/reattach primitive but has no session management — no listing, no metadata, no output capture, no cleanup.
- tmux/screen are heavier, require their own configuration, and their session model doesn't map cleanly to "one session per task."
- DSM adds the thin management layer: unique IDs, JSON metadata, output logs, dead session cleanup.

**Status:** Local sessions are important for standalone terminal use and testing. SSH sessions are low priority (Tailscale handles remote access). Container sessions are the primary workflow.

### 4.2 Container Lifecycle with Git Worktree Isolation

**What:** Create Docker containers with a canonical volume layout. One container per repo, multiple worktrees per container. Containers persist across tasks.

**Canonical layout:**
```
Container:
  /workspace          ← repo root (ro, protects main branch source)
  /workspace/.git     ← git metadata (rw overlay, allows git operations)
  /worktrees/{branch} ← individual worktrees (rw)
  /repos/{name}       ← other repos from config (ro)

Host:
  ~/repos/dev/my-repo/                    ← repo root
  ~/repos/dev/my-repo-worktrees/{branch}/ ← worktree files (visible via bind mount)
```

**Why build it:**
- No existing tool provides worktree-per-branch isolation inside containers with host-visible bind mounts.
- The `.git` overlay mount (ro workspace + rw `.git/`) resolves the access mode tension using standard Docker bind mount semantics.
- Dev Containers / Docker Compose assume one container = one branch.

### 4.3 Automatic Port Detection and Forwarding

**What:** Detect listening ports inside containers by reading `/proc/net/tcp` via the container's PID namespace. Automatically forward detected ports to the host using socat.

**Why build it:**
- Docker's `-p` flag is static (set at creation time). DSM containers are long-lived and run different services across tasks.
- `docker port` only shows `-p` mapped ports, not what's actually listening.
- Reading `/proc/net/tcp` via the container PID is zero-overhead — no docker exec needed.
- socat forwarding is needed because container bridge IPs aren't directly routable.

> **OPEN: Is macOS/Docker Desktop support needed? Current implementation is Linux-only.**

### 4.4 Event Streaming

**What:** Real-time notifications for things DSM owns — port changes, container state, worktree lifecycle. Consumers subscribe and receive NDJSON events.

**Why build it:**
- ui_coder needs reactive updates (new port → update UI). Polling is wasteful.
- `docker events` covers container lifecycle but not port detection.
- DSM's PortWatcher + event system is the glue no existing tool provides.

**Scope (per Policy 5):** Events cover DSM-owned state only. Not file changes, not git state.

### 4.5 The Daemon (Persistent Process)

**What:** Background process that runs the PortWatcher, manages socat forwards, owns the registry, and serves events.

**Why it exists:**
- Port watching and forward management need a long-running process.
- Event delivery needs persistent connections.
- Original motivation was single-writer for registry consistency.

**Status:** Not sacred. If we can achieve port watching, event streaming, and registry consistency without a separate daemon process, that's fine. But some form of persistent process is likely needed for the long-running concerns.

> **OPEN: Is the daemon auto-started today, or manual? Should it be automatic?**

---

## 5. Feature Tiers

### Tier 1: Essential (core value proposition)
- Container lifecycle with worktree isolation
- Worktree creation and deletion (layout operations)
- Volume mount building from config profiles (including `.git` overlay)
- Port detection and auto-forwarding
- Event streaming (port changes, worktree lifecycle)

### Tier 2: Important (supports primary workflows)
- Session metadata (list, resume, rm, clean)
- Persistent process for port watching + events
- Config profiles
- Agent context injection (CLAUDE.md generation)
- Local dtach sessions

### Tier 3: Nice-to-have
- SSH sessions
- SSH alias management
- `tail` command
- `--watch` mode on `ports` command

---

## 6. Interface Contract

### CLI (for humans)
```
dsm container -t TITLE REPO BRANCH   # Primary workflow
dsm list / resume / rm / clean        # Session management
dsm ports / forward / unforward       # Port management
dsm daemon start/stop/status          # Daemon lifecycle (if daemon is kept)
dsm local -t TITLE -- CMD            # Local sessions
dsm ssh HOST                          # SSH sessions
```

### Library API (for ui_coder and CLI)

The CLI is a thin wrapper over the public API. Both use the same functions.

```python
import dsm.api

# Container lifecycle (Policy 2 — DSM owns this)
dsm.api.ensure_container(repo_path, branch, config, ...)
dsm.api.get_container_state(container)
dsm.api.start_container(container)
dsm.api.stop_container(container)
dsm.api.remove_container(container)

# Worktree lifecycle (Policy 2 — layout operations)
dsm.api.create_worktree(container, branch)
dsm.api.remove_worktree(container, branch)
dsm.api.list_worktrees(container)

# Port management (Policy 2 — DSM owns forwards)
dsm.api.scan_ports(container)
dsm.api.forward_port(container, port)
dsm.api.unforward_port(container, port)
dsm.api.list_forwards(container)

# Events (Policy 5 — DSM-owned state only)
dsm.api.subscribe(callback)

# Session management
dsm.api.list_sessions()
dsm.api.find_session(identifier)
dsm.api.remove_session(identifier)

# Config
dsm.api.load_config()
dsm.api.get_profile(name)
```

**Not in the API:** git operations (merge, status, diff, commit). Per Policy 3, these are the consumer's responsibility. DSM provides the environment; the consumer does the work.

---

## 7. What DSM Is NOT

- **Not a workflow engine** — it doesn't merge, commit, push, or manage git state. It manages the workspace where those things happen.
- **Not a container orchestrator** — one container per repo, not multi-container applications.
- **Not a dev container spec implementation** — own config format, not devcontainer.json.
- **Not a general Docker wrapper** — only manages containers it created.
- **Not a file watcher** — manages mounts so consumers CAN watch, but doesn't watch itself.
- **Not a git client** — manages worktree lifecycle (create/delete) but not git operations within worktrees.

---

## 8. Resolved Questions

| # | Question | Resolution |
|---|----------|------------|
| 1 | Local/SSH importance? | Local: important for standalone + testing. SSH: low priority. Container: primary. |
| 2 | File changes — DSM or ui_coder? | DSM sets up mounts so ui_coder CAN inotify watch. DSM doesn't watch files. |
| 3 | Daemon necessary? | Not if same functionality achievable otherwise. Long-running concerns likely need some persistent process. |
| 4 | Library API extraction? | Yes. CLI = thin wrapper over public API. |
| 5 | Does DSM own git operations? | No. DSM owns the workspace (containers, mounts, worktrees, ports). Workflow (git ops) is the consumer's job. |
| 6 | Host-side enforcement? | Policy, not enforcement. Would require OS-level user separation. Out of scope. |
| 7 | What about merge? | Consumer does the merge (it's a workflow op). Consumer calls DSM to clean up the worktree after (layout op). |

## 9. Open Questions

1. One container per repo — always?
2. macOS/Docker Desktop support needed?
3. Daemon: auto-start or manual?
4. Feature tiering correct?
5. Does the API surface look right? What's missing?

---

## Next Steps

1. Write the invariant spec (from these policies)
2. Derive the target architecture from the policies + invariants
3. Diff against the current code to find alignment gaps
4. Produce the concrete change list
