# Project Backlog

Rough ideas and future work not yet scoped into sprints.

## Instructions

**Lifecycle:**
1. **Quick Reference** - Pending items not yet assigned to a sprint
2. **Planned** - Items assigned to a sprint (Created/Planned/Current status)
3. **Completed** - Items with completed sprints
4. **Details** - Full descriptions for all items (searchable reference)

**Workflow:**
- Add new ideas to Quick Reference with [#NNN] ID and brief description
- When creating sprint, move item from Quick Reference to Planned
- When sprint completes, move item from Planned to Completed with sprint/commit info
- Always add/update Details section for new items

**Numbering:**
- Ordinals (1, 2, 3...) renumber automatically in Quick Reference
- IDs [#NNN] are immutable and never change
- Gaps in ID sequence show completed work

## Quick Reference (Pending)

1. [#001] **Cleanup bugs**: `dsm rm` hangs on remove_container response; `dsm clean` doesn't purge stale registry entries; daemon re-persists stale entries on shutdown
2. [#002] **API extraction refactor**: Extract `dsm.api` module from cli.py; CLI becomes thin wrapper; ui_coder imports API not internals
3. [#003] **Port forwarding end-to-end**: Agent has no visibility into port mappings; auto-increment is useless without notification; ui_coder doesn't subscribe to port events; need agent-visible port map
4. [#004] **Test teardown leaks daemon subprocesses**: `test_ensure_daemon_running_connect_retry` spawns a detached daemon subprocess that survives pytest exit and holds socat children alive on host ports indefinitely

## Planned

- None yet

## Completed

- None yet

## Details

### [#001] Cleanup bugs

**Description:**
Three related issues with session/container cleanup:

1. **`dsm rm` hangs** — Daemon successfully removes the container but the client blocks on `recv()` waiting for the response. The daemon sends the response but the client either times out or the connection drops before it arrives. Likely a timing issue with `docker stop` taking long and the 5s socket timeout.

2. **`dsm clean` doesn't purge stale registry entries** — Only cleans dead session metadata. If a container is removed outside DSM (or docker is restarted), registry JSON files persist and the daemon shows ghost entries on next startup.

3. **Daemon re-persists stale entries on shutdown** — If registry files are manually deleted while the daemon is running, the daemon writes them back from its in-memory state on shutdown. The correct fix is probably `dsm clean` checking registry entries against `docker ps` and removing entries for containers that no longer exist.

### [#002] API extraction refactor

**Description:**
Extract a public `dsm.api` module from the 2200-line `cli.py`. The CLI becomes a thin wrapper over the API. ui_coder imports from `dsm.api` instead of `dsm.cli` internals.

Key changes:
- Public API: ensure_container, create/remove_worktree, list_worktrees, port management, events, config
- Internal (not exported): build_volume_mounts, build_docker_run_cmd, build_env_vars, DsmClient, ContainerRegistry
- ui_coder customization goes through DSM config profiles, not by calling build functions directly

See DSM_RATIONALE.md section 6 "Interface Contract" for the target API surface.

### [#003] Port forwarding end-to-end

**Description:**
The port forwarding pipeline is broken end-to-end. Individual pieces work but nothing connects:

1. **PortWatcher detects ports** — works (after v0.7.2 event loop fix)
2. **Auto-forward via socat** — works, but auto-increments to different host port when preferred is taken, with no notification
3. **Event emission** — works (after fix), but ui_coder doesn't subscribe, so events go nowhere
4. **Agent awareness** — doesn't exist. Agent guesses same-port mapping. Wrong when port is taken.

The agent has no channel to receive info from DSM (DSM runs on host, agent in container). Only visibility the agent has: env vars (static), mounted files, self-discovery.

**Options to explore:**
- Port map file written to a mounted path (DSM writes, agent reads)
- On Linux, agent could use container bridge IP directly (no forwarding needed for same-machine access)
- For remote access (Tailscale), forwarding needed — agent needs to know the actual host:port mapping
- Consider: fail instead of auto-increment, since unknown forwards are useless
- ui_coder should subscribe to port events so the UI can show the correct URL

### [#004] Test teardown leaks daemon subprocesses

**Description:**
`tests/test_integration_daemon.py::test_ensure_daemon_running_connect_retry` (line 206) leaks detached daemon subprocesses that survive pytest exit and indefinitely hold socat forwards alive on host ports.

**Observed:** 6 orphan processes found on 2026-04-21, ages 6d04h–6d23h, spread across pytest-159, pytest-162, pytest-182 tmpdirs (long since deleted). Each orphan pair: `python3 -m dsm.daemon --socket /tmp/pytest-of-*/dsm.sock` + a socat child. These claimed host ports 8018, 5189, 5188 and blocked coder_ui dev servers from binding until manually killed.

**Mechanism:**
1. Test calls `ensure_daemon_running(sock)` when the socket file does not yet exist (timing is intentional — the test exercises the retry path).
2. `cli.py:147` hits the `subprocess.Popen([sys.executable, "-m", "dsm.daemon", ...], start_new_session=True)` branch. `start_new_session=True` detaches the child from pytest's process group, so it survives test teardown.
3. Test's own `_delayed_start` then calls `daemon.start()` 0.3s later. `daemon.py:108-109` **unlinks the existing socket file**, orphaning the subprocess daemon — the subprocess keeps listening on the detached inode but nothing on disk points to it.
4. Test teardown only calls `daemon.stop()` on the in-process daemon. The subprocess daemon and its socat children keep running forever.

**Affected also:** `test_ensure_daemon_running_spawns_in_thread` may have the same issue depending on timing of when the in-process daemon's socket appears vs. when `ensure_daemon_running` checks.

**Fix options:**
- Track the Popen handle inside `ensure_daemon_running` (or return it) so tests can `terminate()` it in teardown
- Add a pytest fixture that records spawned daemon PIDs and kills any survivors at session end
- Refactor the retry test to start the in-process daemon first (socket pre-exists), avoiding the subprocess path entirely — but this stops exercising the real code path
- Make `cli.py:147` respect an env var (e.g. `DSM_DISABLE_DAEMON_SPAWN=1`) that causes it to skip the Popen and fail fast, so tests opt into no-spawn mode

**Severity:** Low impact on correctness (tests pass), but high nuisance impact — steals host ports from other apps (coder_ui) for days at a time.
