# dsm

dtach session manager — create and manage persistent detachable terminal sessions for local, SSH, and Docker container workflows. Provides a daemon for container lifecycle management, automatic port forwarding, and git worktree isolation.

## Architecture

Four modules in `src/dsm/`:

- **cli** — Entry point and command dispatch. Parses arguments, manages config profiles, orchestrates Docker container creation, git worktree setup, and session lifecycle. Communicates with the daemon via `DsmClient` (synchronous NDJSON over Unix socket).
- **daemon** — Async background process (`DsmDaemon`). Listens on a Unix domain socket, dispatches NDJSON commands, manages event subscriptions for real-time port/container change notifications, and orchestrates the `PortWatcher`.
- **ports** — Port detection and forwarding. Parses `/proc/net/tcp` inside containers, detects port changes via `PortWatcher` polling, and manages `socat`-based port forwards (`ForwardHandle`).
- **registry** — Persistent container metadata store. JSON files per container in `~/.dsm/registry/`, tracking `ContainerEntry`, `PortInfo`, and `ForwardInfo`.

**Communication:** CLI ↔ Daemon via Unix socket (`~/.dsm/dsm.sock`) using NDJSON protocol (one JSON object per line). Daemon ↔ Containers via `docker exec` for port scanning and `socat` for forwarding.

## Tech Stack

- **Language:** Python 3.12+ (stdlib only — zero runtime dependencies)
- **Build:** hatchling
- **Package manager:** uv
- **Testing:** pytest >= 9.0.3
- **External tools:** Docker, dtach, socat, git, ssh
- **CI:** GitHub Actions (PyPI publish on version tags)

## Development

### Setup

```bash
uv sync          # Install dependencies and create venv
```

### Running

```bash
dsm local -t "Title" -- <command>           # Local dtach session
dsm ssh HOST [-t TITLE] [SSH_ARGS...]       # SSH session
dsm container -t TITLE REPO BRANCH          # Container session with worktree
dsm list                                     # List active sessions
dsm resume <id>                              # Reattach to session
dsm tail <id>                                # Stream session output
dsm rm <id>                                  # Remove session
dsm clean                                    # Remove dead sessions
dsm alias set|ls|rm                          # Manage SSH aliases
dsm ports [CONTAINER] [--watch]              # List detected ports and forwards
dsm forward CONTAINER PORT                   # Forward container port to host
dsm unforward CONTAINER PORT                 # Stop forwarding
dsm daemon start|stop|status                 # Manage the background daemon
```

### Configuration

Config lives at `~/.dsm/config.json`. Supports named profiles with image, env vars, repo mounts, SSH settings. See `config.example.json` for examples.

### Testing

```bash
uv run pytest              # Run all tests
uv run pytest tests/test_ports.py   # Run specific test file
```

## Directory Map

```
src/dsm/              Main package (cli, daemon, ports, registry)
tests/                pytest test suite (6 modules)
.github/workflows/    CI — PyPI publish on version tags
config.example.json   Example configuration with multiple profiles
```

## Key Patterns

- **NDJSON protocol** — All daemon communication uses newline-delimited JSON. `DsmClient` sends commands and reads streaming responses. The daemon dispatches by command name to handler methods.
- **Port watching** — `PortWatcher` polls `/proc/net/tcp` via the container's PID namespace on the host (zero overhead, no `docker exec`), diffs against previous state, and emits `PortChange` events. The daemon auto-manages `socat` forwards based on these changes.
- **Container registry** — Each container gets a JSON file in `~/.dsm/registry/` tracking metadata, ports, and forwards. Survives daemon restarts.
- **Config profiles** — Named configurations (`default`, `minimal`, `isolated`, etc.) control image, env vars, repo mounts, and SSH settings. Environment variables support `${VAR}` expansion from host.
- **Canonical container layout** — `ensure_container` owns the container volume layout. Every container gets: `/workspace` (repo root, ro), `/workspace/.git` (git metadata overlay, rw), and `/worktrees` (bind from `{repo}-worktrees/`, rw). The ro workspace protects main branch source files while the `.git` overlay allows git operations (worktree add, commit, fetch). Worktrees are always created inside the container via `create_worktree_in_container` at `/worktrees/{branch}`. The host sees worktree files at `{repo}-worktrees/{branch}/` via the bind mount. Host git operations use `GIT_DIR`/`GIT_WORK_TREE` env vars since container-created worktrees have `.git` files pointing to container paths. `_container_layout_valid` checks for required mounts (`/worktrees`, `.git` overlay when ro) and automatically recreates outdated containers.
- **Agent context injection** — Container sessions generate and mount a `CLAUDE.md` with repository context, and inject DSM environment variables for tool integration.

## Standards

- Zero runtime dependencies — stdlib only
- Commit format: `feat:`, `fix:`, `docs:`, `chore:`, `refactor:` (sprint work uses `feat(sprint-NN):`)
- Testing: pytest with `unittest.mock`, `tmp_path` for isolation, async tests via `asyncio.run()`
- No mocks for integration tests — real daemon/socket tests in `test_integration_daemon.py`

@.organon/CLAUDE.md
