from mcp.server.fastmcp import FastMCP
from strava_mcp_server.strava_client import StravaClient


def register(mcp: FastMCP, strava: StravaClient) -> None:
    @mcp.prompt()
    def analyze_activity(activity_id: str) -> str:
        """
        Prompt to trigger a deep analysis of a specific Strava activity.
        :param activity_id: The numeric ID of the activity to analyze.
        Fetches full details and produces a structured performance report.
        """
        return (
            f"Please analyze my Strava activity with ID {activity_id} in detail.\n\n"
            "Use the get_activity_details tool to fetch the full data, then provide:\n"
            "1. **Summary**: sport type, date, distance, duration, elevation\n"
            "2. **Performance**: average and max heart rate, average power (if available), "
            "pace or speed, cadence\n"
            "3. **Segment highlights**: best segment efforts with PR or KOM ranks\n"
            "4. **Gear**: which bike or shoes was used\n"
            "5. **Takeaways**: 2–3 concrete observations about the effort "
            "(e.g. strong finish, high elevation, good power-to-HR ratio)\n\n"
            "Format the response clearly with headings."
        )

    @mcp.prompt()
    def training_summary(weeks: int = 4) -> str:
        """
        Prompt to generate a training load summary for the last N weeks.
        :param weeks: Number of weeks to cover (default 4).
        Fetches recent activities and athlete stats to produce a summary report.
        """
        from datetime import datetime, timedelta, timezone

        after_dt = (datetime.now(timezone.utc) - timedelta(weeks=weeks)).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        after_iso = after_dt.isoformat().replace("+00:00", "Z")
        return (
            f"Please summarize my Strava training for the last {weeks} weeks.\n\n"
            f"Use list_activities with after='{after_iso}' (ISO 8601) "
            "and a high limit to fetch all recent activities. "
            "Also read the get_athlete_stats tool for overall totals.\n\n"
            "Structure the report as follows:\n"
            "1. **Overview**: total distance, time, elevation, and number of activities\n"
            "2. **By sport**: breakdown for rides, runs, and swims separately\n"
            "3. **Highlights**: longest activity, highest elevation, best average speed/pace\n"
            "4. **Trend**: how does this period compare to the year-to-date stats?\n"
            "5. **Recommendations**: 1–2 observations based on the data "
            "(e.g. volume trend, missing recovery days, sport mix)\n\n"
            "Format with headings and use km, hours, and meters as units."
        )
