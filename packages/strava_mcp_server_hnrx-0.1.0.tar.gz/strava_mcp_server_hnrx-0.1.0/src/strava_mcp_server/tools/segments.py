import json
from mcp.server.fastmcp import FastMCP
from mcp.types import TextContent, Annotations, EmbeddedResource, TextResourceContents
from strava_mcp_server.strava_client import StravaClient


def _resource(uri: str, data) -> EmbeddedResource:
    return EmbeddedResource(
        type="resource",
        resource=TextResourceContents(
            uri=uri, mimeType="application/json", text=json.dumps(data, indent=2)
        ),
        annotations=Annotations(audience=["assistant"]),
    )


def _user_text(text: str) -> TextContent:
    return TextContent(
        type="text", text=text, annotations=Annotations(audience=["user"])
    )


def register(mcp: FastMCP, strava: StravaClient) -> None:
    @mcp.tool()
    async def get_segment(segment_id: int):
        """
        Get detailed information about a specific Strava segment.
        :param segment_id: The numeric ID of the segment.
        Returns segment name, distance, grade, elevation, and effort counts.
        """
        try:
            s = await strava.get_segment(segment_id)
            data = {
                "id": s.get("id"),
                "name": s.get("name"),
                "activity_type": s.get("activity_type"),
                "distance": f"{s.get('distance', 0) / 1000:.2f} km",
                "average_grade": f"{s.get('average_grade', 0):.1f}%",
                "maximum_grade": f"{s.get('maximum_grade', 0):.1f}%",
                "elevation_high": f"{s.get('elevation_high', 0):.0f} m",
                "elevation_low": f"{s.get('elevation_low', 0):.0f} m",
                "total_elevation_gain": f"{s.get('total_elevation_gain', 0):.0f} m",
                "effort_count": s.get("effort_count"),
                "athlete_count": s.get("athlete_count"),
                "kom": s.get("xoms", {}).get("kom") or s.get("xoms", {}).get("qom"),
                "starred": s.get("starred", False),
                "city": s.get("city"),
                "country": s.get("country"),
            }
            loc = ", ".join(filter(None, [data["city"], data["country"]])) or "N/A"
            md = f"""### 📍 Segment: {data["name"]}
| Feld | Wert |
|------|------|
| Sport | {data["activity_type"]} |
| Distanz | {data["distance"]} |
| Ø Steigung | {data["average_grade"]} |
| Max Steigung | {data["maximum_grade"]} |
| Höhe (hoch) | {data["elevation_high"]} |
| Höhe (tief) | {data["elevation_low"]} |
| Höhenmeter | {data["total_elevation_gain"]} |
| Versuche | {data["effort_count"]} |
| Athleten | {data["athlete_count"]} |
| KOM/QOM | {data["kom"] or "N/A"} |
| Ort | {loc} |
| Favorit | {"⭐ Ja" if data["starred"] else "Nein"} |"""
            return [
                _user_text(md.strip()),
                _resource(f"internal://segments/{segment_id}", data),
            ]
        except Exception as e:
            return [TextContent(type="text", text=f"Error fetching segment: {str(e)}")]

    @mcp.tool()
    async def list_starred_segments(limit: int = 30):
        """
        List segments starred by the authenticated athlete.
        :param limit: Number of segments to return (default 30).
        """
        try:
            segments = await strava.get_starred_segments(per_page=limit)
            data = [
                {
                    "id": s.get("id"),
                    "name": s.get("name"),
                    "activity_type": s.get("activity_type"),
                    "distance": f"{s.get('distance', 0) / 1000:.2f} km",
                    "average_grade": f"{s.get('average_grade', 0):.1f}%",
                    "effort_count": s.get("effort_count"),
                    "athlete_count": s.get("athlete_count"),
                }
                for s in segments
            ]
            if not data:
                md = "### ⭐ Keine favorisierten Segmente."
            else:
                md = f"### ⭐ Favorisierte Segmente ({len(data)})\n"
                md += "| Name | Sport | Distanz | Ø Steigung | Versuche |\n"
                md += "|------|-------|---------|------------|----------|\n"
                for s in data:
                    md += f"| {s['name']} | {s['activity_type']} | {s['distance']} | {s['average_grade']} | {s['effort_count']} |\n"
            return [
                _user_text(md.strip()),
                _resource("internal://segments/starred", data),
            ]
        except Exception as e:
            return [
                TextContent(
                    type="text", text=f"Error fetching starred segments: {str(e)}"
                )
            ]

    @mcp.tool()
    async def explore_segments(
        bounds: str,
        activity_type: str = "riding",
    ):
        """
        Explore popular segments within a bounding box.
        :param bounds: Comma-separated lat/lng bounding box: 'min_lat,min_lng,max_lat,max_lng'.
                       Example: '47.5,8.4,48.0,9.0' for a region near Stuttgart.
        :param activity_type: Either 'riding' (default) or 'running'.
        Returns top segments in the area with distance, grade, and elevation.
        """
        try:
            result = await strava.explore_segments(bounds, activity_type)
            data = [
                {
                    "id": s.get("id"),
                    "name": s.get("name"),
                    "distance": f"{s.get('distance', 0) / 1000:.2f} km",
                    "average_grade": f"{s.get('avg_grade', 0):.1f}%",
                    "elevation_difference": f"{s.get('elev_difference', 0):.0f} m",
                    "climb_category": s.get("climb_category"),
                }
                for s in result.get("segments", [])
            ]
            if not data:
                md = "### 🗺️ Keine Segmente in diesem Bereich gefunden."
            else:
                md = f"### 🗺️ Segmente in der Region ({len(data)})\n"
                md += "| Name | Distanz | Ø Steigung | Höhendiff | Kategorie |\n"
                md += "|------|---------|------------|-----------|----------|\n"
                for s in data:
                    md += f"| {s['name']} | {s['distance']} | {s['average_grade']} | {s['elevation_difference']} | {s['climb_category']} |\n"
            return [
                _user_text(md.strip()),
                _resource("internal://segments/explore", data),
            ]
        except Exception as e:
            return [
                TextContent(type="text", text=f"Error exploring segments: {str(e)}")
            ]

    @mcp.tool()
    async def get_segment_streams(
        segment_id: int,
        keys: str = "distance,altitude,latlng,grade_smooth",
    ):
        """
        Get raw data streams for a specific Strava segment.
        :param segment_id: The numeric ID of the segment.
        :param keys: Comma-separated stream types. Available: distance, altitude, latlng, grade_smooth.
        """
        try:
            key_list = [k.strip() for k in keys.split(",") if k.strip()]
            return await strava.get_segment_streams(segment_id, key_list)
        except Exception as e:
            return f"Error fetching segment streams: {str(e)}"
