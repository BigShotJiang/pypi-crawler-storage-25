import json
from mcp.server.fastmcp import FastMCP
from mcp.types import TextContent, Annotations, EmbeddedResource, TextResourceContents
from strava_mcp_server.strava_client import StravaClient


def _resource(uri: str, data) -> EmbeddedResource:
    return EmbeddedResource(
        type="resource",
        resource=TextResourceContents(
            uri=uri, mimeType="application/json", text=json.dumps(data, indent=2)
        ),
        annotations=Annotations(audience=["assistant"]),
    )


def _user_text(text: str) -> TextContent:
    return TextContent(
        type="text", text=text, annotations=Annotations(audience=["user"])
    )


def register(mcp: FastMCP, strava: StravaClient) -> None:
    @mcp.tool()
    async def get_gear_by_id(gear_id: str):
        """
        Get details for a specific piece of gear (bike or shoes) by its ID.
        :param gear_id: The gear ID string (e.g. 'b12345' for bikes, 'g12345' for shoes).
                       The gear_id can be found in activity details under the 'gear_id' field.
        Returns brand, model, name, distance logged, and whether it is the primary gear.
        """
        try:
            g = await strava.get_gear_by_id(gear_id)
            data = {
                "id": g.get("id"),
                "name": g.get("name"),
                "nickname": g.get("nickname"),
                "brand_name": g.get("brand_name"),
                "model_name": g.get("model_name"),
                "description": g.get("description") or "",
                "type": g.get("gear_type") or g.get("frame_type"),
                "distance": f"{g.get('distance', 0) / 1000:.0f} km",
                "primary": g.get("primary", False),
                "retired": g.get("retired", False),
            }
            brand_model = (
                " ".join(filter(None, [data["brand_name"], data["model_name"]]))
                or "N/A"
            )
            md = f"""### 🚲 Ausrüstung: {data["name"] or gear_id}
| Feld | Wert |
|------|------|
| Marke / Modell | {brand_model} |
| Spitzname | {data["nickname"] or "N/A"} |
| Typ | {data["type"] or "N/A"} |
| Gesamt-Distanz | {data["distance"]} |
| Primär | {"✅ Ja" if data["primary"] else "Nein"} |
| Im Ruhestand | {"🛑 Ja" if data["retired"] else "Nein"} |"""
            if data["description"]:
                md += f"\n\n_{data['description']}_"
            return [
                _user_text(md.strip()),
                _resource(f"internal://gear/{gear_id}", data),
            ]
        except Exception as e:
            return [TextContent(type="text", text=f"Error fetching gear: {str(e)}")]
