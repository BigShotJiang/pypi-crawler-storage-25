"""
MCP Tool definitions for the Strava MCP Server.

Register all tools by calling register_tools(mcp, strava).
"""

from mcp.server.fastmcp import FastMCP
from strava_mcp_server.strava_client import StravaClient

from . import athlete
from . import activities
from . import clubs
from . import routes
from . import segments
from . import segment_efforts
from . import gear
from . import prompts


def register_tools(mcp: FastMCP, strava: StravaClient) -> None:
    """Register all available tools and prompts."""
    athlete.register(mcp, strava)
    activities.register(mcp, strava)
    clubs.register(mcp, strava)
    routes.register(mcp, strava)
    segments.register(mcp, strava)
    segment_efforts.register(mcp, strava)
    gear.register(mcp, strava)
    prompts.register(mcp, strava)
