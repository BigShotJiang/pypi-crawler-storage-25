import json
from mcp.server.fastmcp import FastMCP
from mcp.types import TextContent, Annotations, EmbeddedResource, TextResourceContents
from strava_mcp_server.strava_client import StravaClient
from strava_mcp_server.utils import format_date_iso, format_date_human


def _resource(uri: str, data) -> EmbeddedResource:
    return EmbeddedResource(
        type="resource",
        resource=TextResourceContents(
            uri=uri, mimeType="application/json", text=json.dumps(data, indent=2)
        ),
        annotations=Annotations(audience=["assistant"]),
    )


def _user_text(text: str) -> TextContent:
    return TextContent(
        type="text", text=text, annotations=Annotations(audience=["user"])
    )


def register(mcp: FastMCP, strava: StravaClient) -> None:
    @mcp.tool()
    async def get_segment_effort(effort_id: str):
        """
        Get details for a specific segment effort by its ID. Requires Strava subscription.
        :param effort_id: The effort ID string — copy it exactly from get_activity_details
                          (under 'segment_efforts[].id'). Do NOT retype the number manually.
        Returns elapsed time, moving time, power, heart rate, PR rank, and KOM rank.
        """
        try:
            e = await strava.get_segment_effort(effort_id)
            data = {
                "id": str(e.get("id")),
                "name": e.get("name"),
                "elapsed_time": f"{e.get('elapsed_time', 0) / 60:.1f} min",
                "moving_time": f"{e.get('moving_time', 0) / 60:.1f} min",
                "start_date": format_date_iso(e.get("start_date")),
                "distance": f"{e.get('distance', 0) / 1000:.2f} km",
                "average_watts": e.get("average_watts"),
                "average_heartrate": e.get("average_heartrate"),
                "max_heartrate": e.get("max_heartrate"),
                "pr_rank": e.get("pr_rank"),
                "kom_rank": e.get("kom_rank"),
            }
            pr = f"#{data['pr_rank']}" if data["pr_rank"] else "N/A"
            kom = f"#{data['kom_rank']}" if data["kom_rank"] else "N/A"
            w = f"{data['average_watts']:.0f} W" if data["average_watts"] else "N/A"
            hr = (
                f"{data['average_heartrate']:.0f} bpm"
                if data["average_heartrate"]
                else "N/A"
            )
            md = f"""### 🏅 Segment-Effort: {data["name"]}
| Feld | Wert |
|------|------|
| Datum | {format_date_human(data["start_date"])} |
| Distanz | {data["distance"]} |
| Zeit (gesamt) | {data["elapsed_time"]} |
| Fahrzeit | {data["moving_time"]} |
| Ø Leistung | {w} |
| Ø Herzfrequenz | {hr} |
| PR-Rang | {pr} |
| KOM-Rang | {kom} |"""
            return [
                _user_text(md.strip()),
                _resource(f"internal://segment_efforts/{effort_id}", data),
            ]
        except Exception as e:
            return [
                TextContent(
                    type="text", text=f"Error fetching segment effort: {str(e)}"
                )
            ]

    @mcp.tool()
    async def list_segment_efforts(
        segment_id: int,
        start_date_local: str | None = None,
        end_date_local: str | None = None,
        limit: int = 30,
    ):
        """
        List the authenticated athlete's efforts on a specific segment. Requires Strava subscription.
        :param segment_id: The numeric ID of the segment.
        :param start_date_local: Optional filter start date (ISO 8601, e.g. '2024-01-01T00:00:00Z').
        :param end_date_local: Optional filter end date (ISO 8601, e.g. '2024-12-31T23:59:59Z').
        :param limit: Number of efforts to return (default 30).
        """
        try:
            efforts = await strava.list_segment_efforts(
                segment_id,
                start_date_local=start_date_local,
                end_date_local=end_date_local,
                per_page=limit,
            )
            data = [
                {
                    "id": str(e.get("id")),
                    "elapsed_time": f"{e.get('elapsed_time', 0) / 60:.1f} min",
                    "moving_time": f"{e.get('moving_time', 0) / 60:.1f} min",
                    "start_date": format_date_iso(e.get("start_date")),
                    "average_watts": e.get("average_watts"),
                    "average_heartrate": e.get("average_heartrate"),
                    "pr_rank": e.get("pr_rank"),
                }
                for e in efforts
            ]
            if not data:
                md = "### 🏅 Keine Efforts für dieses Segment gefunden."
            else:
                md = f"### 🏅 Segment-Efforts ({len(data)})\n"
                md += "| Datum | Zeit | Fahrzeit | PR-Rang |\n"
                md += "|-------|------|----------|--------|\n"
                for effort in data:
                    pr = f"#{effort['pr_rank']}" if effort["pr_rank"] else "-"
                    md += f"| {format_date_human(effort['start_date'])} | {effort['elapsed_time']} | {effort['moving_time']} | {pr} |\n"
            return [
                _user_text(md.strip()),
                _resource(f"internal://segments/{segment_id}/efforts", data),
            ]
        except Exception as e:
            return [
                TextContent(
                    type="text", text=f"Error fetching segment efforts: {str(e)}"
                )
            ]

    @mcp.tool()
    async def get_segment_effort_streams(
        effort_id: str,
        keys: str = "time,distance,heartrate,altitude,velocity_smooth,cadence,watts",
    ):
        """
        Get raw data streams for a specific segment effort. Requires Strava subscription.
        :param effort_id: The effort ID string — copy it exactly from get_activity_details
                          (under 'segment_efforts[].id'). Do NOT retype the number manually.
        :param keys: Comma-separated stream types. Available: time, distance, latlng,
                     altitude, velocity_smooth, heartrate, cadence, watts, moving, grade_smooth.
        """
        try:
            key_list = [k.strip() for k in keys.split(",") if k.strip()]
            return await strava.get_segment_effort_streams(effort_id, key_list)
        except Exception as e:
            return f"Error fetching segment effort streams: {str(e)}"
