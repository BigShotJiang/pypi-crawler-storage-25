import json
from mcp.server.fastmcp import FastMCP
from mcp.types import TextContent, Annotations, EmbeddedResource, TextResourceContents
from strava_mcp_server.strava_client import StravaClient


def _resource(uri: str, data) -> EmbeddedResource:
    return EmbeddedResource(
        type="resource",
        resource=TextResourceContents(
            uri=uri, mimeType="application/json", text=json.dumps(data, indent=2)
        ),
        annotations=Annotations(audience=["assistant"]),
    )


def _user_text(text: str) -> TextContent:
    return TextContent(
        type="text", text=text, annotations=Annotations(audience=["user"])
    )


def register(mcp: FastMCP, strava: StravaClient) -> None:
    @mcp.tool()
    async def get_routes_by_athlete_id(limit: int = 30):
        """
        List routes created by the authenticated Strava athlete.
        :param limit: Number of routes to return (default 30, max 200).
        Returns route name, type, distance, elevation gain, and estimated move time.
        """
        try:
            routes = await strava.get_routes_by_athlete(per_page=min(limit, 200))
            data = [
                {
                    "id": str(r.get("id")),
                    "name": r.get("name"),
                    "description": r.get("description") or "",
                    "type": "Run"
                    if r.get("type") == 1
                    else "Ride"
                    if r.get("type") == 2
                    else "Other",
                    "sub_type": r.get("sub_type"),
                    "distance": f"{r.get('distance', 0) / 1000:.2f} km",
                    "elevation_gain": f"{r.get('elevation_gain', 0):.0f} m",
                    "estimated_moving_time": f"{r.get('estimated_moving_time', 0) / 60:.0f} min",
                    "starred": r.get("starred", False),
                    "private": r.get("private", False),
                }
                for r in routes
            ]
            if not data:
                md = "### 🗺️ Keine Routen gefunden."
            else:
                md = f"### 🗺️ Routen ({len(data)})\n"
                md += "| Name | Typ | Distanz | Höhenmeter | Dauer |\n"
                md += "|------|-----|---------|------------|-------|\n"
                for r in data:
                    star = "⭐ " if r["starred"] else ""
                    md += f"| {star}{r['name']} | {r['type']} | {r['distance']} | {r['elevation_gain']} | {r['estimated_moving_time']} |\n"
            return [_user_text(md.strip()), _resource("internal://routes/list", data)]
        except Exception as e:
            return [TextContent(type="text", text=f"Error fetching routes: {str(e)}")]

    @mcp.tool()
    async def get_route_by_id(route_id: str):
        """
        Get detailed information about a specific Strava route by its ID.
        :param route_id: The ID of the route (use the string ID from get_routes_by_athlete_id).
        Returns full route details including segments.
        """
        try:
            r = await strava.get_route_by_id(route_id)
            data = {
                "id": str(r.get("id")),
                "name": r.get("name"),
                "description": r.get("description") or "",
                "type": "Run"
                if r.get("type") == 1
                else "Ride"
                if r.get("type") == 2
                else "Other",
                "distance": f"{r.get('distance', 0) / 1000:.2f} km",
                "elevation_gain": f"{r.get('elevation_gain', 0):.0f} m",
                "estimated_moving_time": f"{r.get('estimated_moving_time', 0) / 60:.0f} min",
                "starred": r.get("starred", False),
                "private": r.get("private", False),
                "segments": [
                    {
                        "id": str(s.get("id")),
                        "name": s.get("name"),
                        "distance": f"{s.get('distance', 0) / 1000:.2f} km",
                        "average_grade": f"{s.get('average_grade', 0):.1f}%",
                    }
                    for s in r.get("segments", [])
                ],
            }
            n_seg = len(data["segments"])
            md = f"""### 🗺️ Route: {data["name"]}
| Feld | Wert |
|------|------|
| Typ | {data["type"]} |
| Distanz | {data["distance"]} |
| Höhenmeter | {data["elevation_gain"]} |
| Geschätzte Dauer | {data["estimated_moving_time"]} |
| Segmente | {n_seg} |
| Favorit | {"⭐ Ja" if data["starred"] else "Nein"} |
| Privat | {"🔒 Ja" if data["private"] else "Nein"} |"""
            if data["description"]:
                md += f"\n\n_{data['description']}_"
            return [
                _user_text(md.strip()),
                _resource(f"internal://routes/{route_id}", data),
            ]
        except Exception as e:
            return [TextContent(type="text", text=f"Error fetching route: {str(e)}")]

    @mcp.tool()
    async def get_route_streams(route_id: str):
        """
        Get data streams (distance, altitude, latlng, etc.) for a specific route.
        :param route_id: The ID of the route (use the string ID from get_routes_by_athlete_id).
        """
        try:
            return await strava.get_route_streams(route_id)
        except Exception as e:
            return f"Error fetching route streams: {str(e)}"
