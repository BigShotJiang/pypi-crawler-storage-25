from datetime import datetime, timezone
from typing import Optional


def parse_iso_to_unix(iso_str: Optional[str]) -> Optional[int]:
    """
    Parses an ISO 8601 string into a Unix timestamp.
    Accepts formats like '2024-01-01', '2024-01-01T12:00:00Z', etc.
    """
    if not iso_str:
        return None
    try:
        # Remove 'Z' and replace with +00:00 for fromisoformat compatibility if needed
        # but fromisoformat in Python 3.11+ handles Z correctly.
        # For older versions or varied formats, we use a slightly more robust approach.
        clean_iso = iso_str.replace("Z", "+00:00")
        dt = datetime.fromisoformat(clean_iso)
        # Ensure it has a timezone; default to UTC if missing
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int(dt.timestamp())
    except Exception:
        return None


def format_date_iso(date_input: Optional[str | datetime]) -> str:
    """
    Standardizes a date string or datetime object to ISO 8601 (UTC).
    """
    if not date_input:
        return "N/A"

    try:
        if isinstance(date_input, str):
            # Strava dates are often '2024-01-01T12:00:00Z'
            dt = datetime.fromisoformat(date_input.replace("Z", "+00:00"))
        else:
            dt = date_input

        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)

        return dt.isoformat().replace("+00:00", "Z")
    except Exception:
        return str(date_input)


def format_date_human(date_input: Optional[str | datetime]) -> str:
    """
    Returns a human-readable date/time string (DD.MM.YYYY HH:MM).
    """
    if not date_input:
        return "N/A"

    try:
        if isinstance(date_input, str):
            dt = datetime.fromisoformat(date_input.replace("Z", "+00:00"))
        else:
            dt = date_input

        return dt.strftime("%d.%m.%Y %H:%M")
    except Exception:
        return str(date_input)
