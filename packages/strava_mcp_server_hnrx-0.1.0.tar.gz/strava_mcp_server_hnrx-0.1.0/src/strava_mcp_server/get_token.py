"""
Strava OAuth2 Authorization Helper

This script guides you through the Strava OAuth2 flow to obtain a refresh token
with the correct scopes for the MCP server.

Required scopes:
  - read              → basic athlete profile
  - activity:read     → read your activities
  - activity:read_all → read private activities (optional)

Usage: uv run get_token.py
"""

import os
import webbrowser
import httpx
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from dotenv import load_dotenv

load_dotenv()

CLIENT_ID = os.getenv("STRAVA_CLIENT_ID")
CLIENT_SECRET = os.getenv("STRAVA_CLIENT_SECRET")
REDIRECT_URI = "http://localhost:8765/callback"
SCOPES = "profile:read_all,activity:read_all,activity:read,profile:write"


class CallbackHandler(BaseHTTPRequestHandler):
    client_id: str = ""
    client_secret: str = ""
    tokens: dict = {}
    error: str | None = None

    def do_GET(self):
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)

        if "code" in params:
            code = params["code"][0]
            try:
                # Exchange code for token synchronously
                response = httpx.post(
                    "https://www.strava.com/oauth/token",
                    data={
                        "client_id": self.client_id,
                        "client_secret": self.client_secret,
                        "code": code,
                        "grant_type": "authorization_code",
                    },
                )
                response.raise_for_status()
                self.tokens = response.json()

                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()

                refresh_token = self.tokens.get("refresh_token")

                self.wfile.write(
                    f"""
                    <html>
                    <head>
                        <style>
                            body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 40px auto; padding: 20px; text-align: left; }}
                            .card {{ background: #f4f7f6; border-radius: 8px; padding: 20px; border-left: 5px solid #fc4c02; margin-top: 20px; }}
                            pre {{ background: #222; color: #fff; padding: 15px; border-radius: 5px; overflow-x: auto; font-family: "SF Mono", Monaco, Consolas, monospace; font-size: 13px; }}
                            .success-header {{ text-align: center; margin-bottom: 40px; }}
                            .success-icon {{ color: #2ecc71; font-size: 48px; display: block; margin-bottom: 10px; }}
                            h2, h3 {{ color: #fc4c02; }}
                            .env-label {{ font-weight: bold; color: #666; font-size: 12px; text-transform: uppercase; margin-bottom: 5px; display: block; }}
                            .copy-hint {{ font-size: 12px; color: #666; font-style: italic; }}
                            code {{ background: #eee; padding: 2px 4px; border-radius: 4px; }}
                        </style>
                    </head>
                    <body>
                        <div class="success-header">
                            <span class="success-icon">&#x2705;</span>
                            <h2>Authorization successful!</h2>
                            <p>You have successfully authenticated with Strava. You can now close this window.</p>
                        </div>
                        
                        <h3>1. Local Setup (.env)</h3>
                        <p>Copy the following block into your <code>.env</code> file in the project root:</p>
                        <div class="card">
                            <span class="env-label">Your .env content:</span>
                            <pre>STRAVA_CLIENT_ID={self.client_id}
STRAVA_CLIENT_SECRET={self.client_secret}
STRAVA_REFRESH_TOKEN={refresh_token}</pre>
                        </div>

                        <h3>2. Kubernetes Setup (Secret)</h3>
                        <p>If you are deploying this server to Kubernetes, run the following command to create the required Secret:</p>
                        <div class="card">
                            <span class="env-label">Kubectl Command:</span>
                            <pre>kubectl create secret generic strava-mcp-server-secret \\
  --from-literal=STRAVA_CLIENT_ID={self.client_id} \\
  --from-literal=STRAVA_CLIENT_SECRET={self.client_secret} \\
  --from-literal=STRAVA_REFRESH_TOKEN={refresh_token}</pre>
                        </div>

                        <p style="margin-top: 40px; font-size: 14px; color: #666; text-align: center;">
                            &mdash; Strava MCP Server Authorization Helper &mdash;
                        </p>
                    </body>
                    </html>
                """.encode("utf-8")
                )
            except Exception as e:
                self.error = str(e)
                self.send_response(500)
                self.end_headers()
                self.wfile.write(f"Error exchanging token: {e}".encode())
        else:
            error_msg = params.get("error", ["unknown"])[0]
            self.send_response(400)
            self.end_headers()
            self.wfile.write(f"Error: {error_msg}".encode())

    def log_message(self, format, *args):
        pass  # Suppress server logs


def main():
    if not CLIENT_ID or not CLIENT_SECRET:
        print("❌ Missing STRAVA_CLIENT_ID or STRAVA_CLIENT_SECRET in .env")
        return

    auth_url = (
        f"https://www.strava.com/oauth/authorize"
        f"?client_id={CLIENT_ID}"
        f"&redirect_uri={REDIRECT_URI}"
        f"&response_type=code"
        f"&approval_prompt=force"
        f"&scope={SCOPES}"
    )

    # Configure handler
    CallbackHandler.client_id = CLIENT_ID
    CallbackHandler.client_secret = CLIENT_SECRET
    CallbackHandler.tokens = {}
    CallbackHandler.error = None

    print("=" * 60)
    print("  Strava OAuth2 Authorization")
    print("=" * 60)
    print(f"\nRequesting scopes: {SCOPES}\n")
    print("Opening Strava in your browser...")
    print("If the browser doesn't open, visit this URL manually:\n")
    print(f"  {auth_url}\n")

    webbrowser.open(auth_url)

    print("Waiting for callback on http://localhost:8765 ...")
    server = HTTPServer(("localhost", 8765), CallbackHandler)
    server.handle_request()  # Handle exactly one request (the callback)

    if CallbackHandler.error:
        print(f"❌ Token exchange failed: {CallbackHandler.error}")
        return

    if not CallbackHandler.tokens:
        print("❌ No tokens received.")
        return

    data = CallbackHandler.tokens
    refresh_token = data["refresh_token"]
    athlete = data.get("athlete", {})

    print("\n" + "=" * 60)
    print("  ✅ Authorization successful!")
    print("=" * 60)
    print(f"\nAthlete: {athlete.get('firstname')} {athlete.get('lastname')}")
    print(f"Scopes granted: {data.get('scope', 'unknown')}\n")
    print("Add the following to your .env file:")
    print("-" * 40)
    print(f"STRAVA_CLIENT_ID={CLIENT_ID}")
    print(f"STRAVA_CLIENT_SECRET={CLIENT_SECRET}")
    print(f"STRAVA_REFRESH_TOKEN={refresh_token}")
    print("-" * 40)

    # Optional: Automatically update .env if it exists
    try:
        env_path = ".env"
        if os.path.exists(env_path):
            with open(env_path, "r") as f:
                lines = f.readlines()
            with open(env_path, "w") as f:
                found = False
                for line in lines:
                    if line.startswith("STRAVA_REFRESH_TOKEN="):
                        f.write(f"STRAVA_REFRESH_TOKEN={refresh_token}\n")
                        found = True
                    else:
                        f.write(line)
                if not found:
                    f.write(f"\nSTRAVA_REFRESH_TOKEN={refresh_token}\n")
            print("Successfully updated your .env file!")
    except Exception as e:
        print(f"Could not automatically update .env: {e}")


if __name__ == "__main__":
    main()
