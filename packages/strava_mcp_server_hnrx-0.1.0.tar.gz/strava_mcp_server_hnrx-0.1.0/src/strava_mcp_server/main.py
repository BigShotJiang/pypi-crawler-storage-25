import importlib.metadata
import os
import sys

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

from strava_mcp_server.strava_client import StravaClient
from strava_mcp_server.tools import register_tools

load_dotenv()


def validate_credentials() -> None:
    """Validates that all required Strava credentials are present. Exits on failure."""
    required = {
        "STRAVA_CLIENT_ID": os.getenv("STRAVA_CLIENT_ID"),
        "STRAVA_CLIENT_SECRET": os.getenv("STRAVA_CLIENT_SECRET"),
    }
    missing = [k for k, v in required.items() if not v]
    if missing:
        print("❌ Startup aborted: Missing required environment variables:")
        for key in missing:
            print(f"   - {key}")
        print("\nCopy .env.example to .env and fill in your Strava API credentials.")
        sys.exit(1)

    if not os.getenv("STRAVA_REFRESH_TOKEN"):
        print(
            "ℹ️ No STRAVA_REFRESH_TOKEN found. Server starting in unauthenticated mode."
        )
        print("   Run 'uv run auth' on your local machine to authenticate.")


def main() -> None:
    """Entry point for the strava-mcp console script."""
    load_dotenv()
    validate_credentials()

    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", 8000))

    strava = StravaClient()

    mcp = FastMCP(
        "Strava MCP Server",
        instructions="""
        IMPORTANT ON DATE/TIME: 
        - Always use ISO 8601 (UTC) for date/time inputs (YYYY-MM-DDTHH:MM:SSZ).
        - This server returns dates in ISO 8601 (UTC).
        - When presenting to the user, you may format dates naturally in their local language, but use the raw ISO data for all internal logic and tool calls.
        - Distance is in meters (convert to km for users), elevation in meters, and speed in m/s (convert to km/h or pace).
        """.strip(),
        host=host,
        port=port,
        streamable_http_path="/mcp",
        stateless_http=True,
    )

    try:
        mcp._mcp_server.version = importlib.metadata.version("strava-mcp-server")
    except importlib.metadata.PackageNotFoundError:
        mcp._mcp_server.version = "dev"

    register_tools(mcp, strava)

    # Check transport mode from environment (Default to stdio for local dev)
    transport = os.getenv("MCP_TRANSPORT", "stdio")

    if transport == "http":
        # Run in Streamable HTTP mode (standard for Docker, K8s and OpenWebUI)
        print(f"🚀 Starting Strava MCP Server on http://{host}:{port}")
        print(f"   MCP endpoint: http://{host}:{port}/mcp  (Streamable HTTP)")
        try:
            mcp.run(transport="streamable-http")
        except KeyboardInterrupt:
            pass
    else:
        # Run in STDIO mode (default for local testing and Claude Desktop)
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
