Das Git Repo zu dem Projekt:
"Strava MCP Server"
findest du hier: https://git.hnrx.net/hnrx/strava-mcp-server

Issues: https://git.hnrx.net/hnrx/strava-mcp-server/issues