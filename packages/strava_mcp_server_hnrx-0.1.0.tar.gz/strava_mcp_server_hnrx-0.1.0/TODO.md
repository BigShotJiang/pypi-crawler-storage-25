# Strava MCP Server — Next Steps

## 🐳 Docker Container bauen
- [x] `Dockerfile` erstellen (Python-Base-Image, `uv`-basiert)
- [x] `.dockerignore` anlegen (`.env`, `__pycache__`, `.venv` etc.)
- [x] Umgebungsvariablen via `--env-file` oder Docker Secrets einbinden
- [ ] `docker-compose.yml` für lokales Testing
- [x] Image testen: `docker run -p 8000:8000 strava-mcp-server`

---

## 🔁 Gitea Action erstellen
- [x] `.gitea/workflows/` Verzeichnis anlegen
- [x] CI-Workflow definieren (Lint + ggf. Syntax-Check)
- [x] Build & Push des Docker Images in Gitea Container Registry
- [x] Secrets in Gitea hinterlegen (`STRAVA_CLIENT_ID`, `STRAVA_CLIENT_SECRET`)
- [ ] Optional: Auto-Deploy auf Server nach erfolgreichem Build

---

## 🔑 Anmeldung vereinfachen
- [x] OAuth-Flow direkt in den Server integrieren (kein separates `get_token.py` mehr)
- [x] Callback-Endpoint `/auth/callback` im FastMCP-Server ergänzen
- [x] `STRAVA_REFRESH_TOKEN` automatisch in `.env` zurückschreiben nach Token-Rotation
- [x] Optionaler Hinweis beim Start falls kein Token vorhanden ist


## Bugs
- [x] Server startet nicht ohne Refresh Token. Brauche Möglichkeit das ich Auth über Agentgateway machen kann, damit ich nicht jedes Mal manuell den Auth Prozess anstoßen muss. Siehe Gitea MCP Server.
- [x] Hinweise für Model wie das Datum ausgegeben wird vom MCP Server. Aktuell ist das LLM oft unsicher bzgl. datums formates.