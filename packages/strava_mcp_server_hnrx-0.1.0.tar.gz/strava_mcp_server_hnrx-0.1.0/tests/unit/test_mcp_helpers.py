"""Unit tests for MCP content block helper functions."""

import json

from mcp.types import TextContent, EmbeddedResource

# Import helpers directly from a tool module to test them
from strava_mcp_server.tools.activities import _resource, _user_text


class TestUserTextHelper:
    def test_returns_text_content(self):
        result = _user_text("Hello World")
        assert isinstance(result, TextContent)

    def test_type_is_text(self):
        result = _user_text("Hello")
        assert result.type == "text"

    def test_text_value(self):
        result = _user_text("Test message")
        assert result.text == "Test message"

    def test_audience_is_user(self):
        result = _user_text("Hello")
        assert result.annotations is not None
        assert result.annotations.audience == ["user"]


class TestResourceHelper:
    def test_returns_embedded_resource(self):
        result = _resource("internal://test/data", {"key": "value"})
        assert isinstance(result, EmbeddedResource)

    def test_type_is_resource(self):
        result = _resource("internal://test/data", {"key": "value"})
        assert result.type == "resource"

    def test_mime_type_is_json(self):
        result = _resource("internal://test/data", {"key": "value"})
        assert result.resource.mimeType == "application/json"

    def test_uri_is_set(self):
        result = _resource("internal://athlete/profile", {"id": 1})
        assert str(result.resource.uri) == "internal://athlete/profile"

    def test_text_is_valid_json(self):
        data = {"id": 42, "name": "Test Athlete", "active": True}
        result = _resource("internal://test", data)
        parsed = json.loads(result.resource.text)
        assert parsed == data

    def test_audience_is_assistant(self):
        result = _resource("internal://test", {})
        assert result.annotations is not None
        assert result.annotations.audience == ["assistant"]

    def test_list_data(self):
        data = [{"id": 1}, {"id": 2}]
        result = _resource("internal://activities/list", data)
        parsed = json.loads(result.resource.text)
        assert len(parsed) == 2
        assert parsed[0]["id"] == 1
