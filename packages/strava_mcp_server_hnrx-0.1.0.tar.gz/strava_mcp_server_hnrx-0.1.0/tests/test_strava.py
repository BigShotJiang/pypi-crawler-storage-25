import asyncio
import os
from strava_client import StravaClient
from dotenv import load_dotenv


async def test_connection():
    load_dotenv()

    client_id = os.getenv("STRAVA_CLIENT_ID")
    client_secret = os.getenv("STRAVA_CLIENT_SECRET")
    refresh_token = os.getenv("STRAVA_REFRESH_TOKEN")

    if not all([client_id, client_secret, refresh_token]):
        print("❌ Error: Missing Strava credentials in .env file.")
        print(
            "Please ensure STRAVA_CLIENT_ID, STRAVA_CLIENT_SECRET, and STRAVA_REFRESH_TOKEN are set."
        )
        return

    client = StravaClient()

    print("Testing Strava connection...")
    try:
        athlete = await client.get_athlete()
        print(
            f"✅ Success! Connected as {athlete.get('firstname')} {athlete.get('lastname')}"
        )
        print(f"Athlete ID: {athlete.get('id')}")

        print("\nFetching recent activities...")
        activities = await client.list_activities(limit=3)
        print(f"Found {len(activities)} recent activities:")
        for a in activities:
            print(f"- {a['name']} ({a['type']}) on {a['start_date']}")

    except Exception as e:
        print(f"❌ Connection failed: {str(e)}")
        if "401" in str(e):
            print(
                "Hint: This is likely a scope issue. Your token needs 'activity:read' permission."
            )
            print("Run: uv run get_token.py  to re-authorize with the correct scopes.")


if __name__ == "__main__":
    asyncio.run(test_connection())
