import os
import re

# ==========================================
# PHASE 1: THE CHSL READER (Parser)
# ==========================================
def parse_chsl(text, current_dir=".", _visited=None):
    if _visited is None:
        _visited = set()
        
    lines = text.split('\n')
    config = {}
    scope_path = {-1: config}
    current_level = -1
    
    state = "NORMAL"
    current_key = None
    current_list = []
    current_lines = []
    expected_line = 1
    
    # Absolute path for security with trailing separator
    base_dir = os.path.abspath(current_dir)
    if not base_dir.endswith(os.sep):
        base_dir += os.sep
    
    for line_idx, raw_line in enumerate(lines):
        line = raw_line.strip()
        actual_line_num = line_idx + 1
        
        # Ignore empty lines and comments
        if not line or line.startswith("NOTE:"):
            continue
            
        # Handle Multi-line Bullet Lists (#)
        if state == "IN_LIST":
            if line.startswith("#"):
                item_val = line[1:].strip()
                if item_val == "YES":
                    current_list.append(True)
                elif item_val == "NO":
                    current_list.append(False)
                elif item_val == "EMPTY":
                    current_list.append(None)
                elif item_val.startswith("PIN "):
                    current_list.append(item_val[4:].strip())
                else:
                    try:
                        parsed_num = float(item_val) if "." in item_val else int(item_val)
                        current_list.append(parsed_num)
                    except ValueError:
                        current_list.append(item_val)
                continue
            else:
                scope_path[current_level][current_key] = current_list
                state = "NORMAL"

        # Handle Explicit Multi-line Text (LINE)
        if state == "IN_LINE":
            match = re.match(r"^(\d+)\s*=\s*(.*)", line)
            if match:
                num = int(match.group(1))
                if num != expected_line:
                    raise SyntaxError(f"CHSL ERROR (Line {actual_line_num}): Expected '{expected_line} =', got '{num} ='")
                current_lines.append(match.group(2).strip())
                expected_line += 1
                continue
            else:
                scope_path[current_level][current_key] = "\n".join(current_lines)
                state = "NORMAL"

        # Handle File Loading (LOAD)
        if line.startswith("LOAD "):
            filename = line[5:].strip()
            filepath = os.path.abspath(os.path.join(base_dir, filename))
            
            # Security: Prevent directory traversal
            if not filepath.startswith(base_dir):
                raise PermissionError(f"CHSL SECURITY ERROR (Line {actual_line_num}): Cannot LOAD files outside directory!")
            
            # Security: Prevent circular dependencies
            if filepath in _visited:
                raise RecursionError(f"CHSL ERROR (Line {actual_line_num}): Circular LOAD detected for '{filename}'")
                
            if not os.path.exists(filepath):
                raise FileNotFoundError(f"CHSL ERROR (Line {actual_line_num}): LOAD failed. File '{filename}' not found.")
            
            _new_visited = _visited.copy()
            _new_visited.add(filepath)
            
            with open(filepath, 'r') as f:
                loaded_config = parse_chsl(f.read(), os.path.dirname(filepath), _new_visited)
                
            scope_path[current_level].update(loaded_config)
            continue 
            
        # Handle Explicit Nesting Scopes (e.g., 0Group0)
        group_match = re.match(r"^(\d+)([a-zA-Z0-9_]+)(\d+)$", line)
        if group_match:
            level_start = int(group_match.group(1))
            name = group_match.group(2)
            level_end = int(group_match.group(3))
            
            if level_start != level_end:
                raise SyntaxError(f"CHSL ERROR (Line {actual_line_num}): Group numbers do not match!")
            if level_start > current_level + 1:
                raise SyntaxError(f"CHSL ERROR (Line {actual_line_num}): Skipped a group depth!")
            
            new_scope = {}
            scope_path[level_start - 1][name] = new_scope
            scope_path[level_start] = new_scope
            current_level = level_start
            continue

        # Handle Inline Arrays (ARE) - Anchored strictly to prevent false positives
        are_match = re.match(r"^([^\s=]+)\s+ARE\s+(.*)", line)
        if are_match:
            key = are_match.group(1)
            raw_vals = are_match.group(2).split(",")
            parsed_list = []
            
            for rv in raw_vals:
                v = rv.strip()
                if v == "YES": parsed_list.append(True)
                elif v == "NO": parsed_list.append(False)
                elif v == "EMPTY": parsed_list.append(None)
                elif v.startswith("PIN "): parsed_list.append(v[4:].strip())
                else:
                    try:
                        parsed_list.append(float(v) if "." in v else int(v))
                    except ValueError:
                        parsed_list.append(v)
            
            scope_path[current_level][key] = parsed_list
            continue
            
        # Handle Standard Key-Value Pairs (=)
        if "=" in line:
            key_part, val_part = line.split("=", 1)
            key = key_part.strip()
            val = val_part.strip()
            
            if val == "":
                state = "IN_LIST"
                current_key = key
                current_list = []
                continue
                
            if val == "LINE":
                state = "IN_LINE"
                current_key = key
                current_lines = []
                expected_line = 1
                continue
                
            final_val = None
            if val == "YES":
                final_val = True
            elif val == "NO":
                final_val = False
            elif val == "EMPTY":
                final_val = None
            elif val.startswith("PIN "):
                final_val = val[4:].strip() 
            elif val.startswith("COPY_ENV "):
                env_var = val[9:].strip()
                if env_var not in os.environ:
                    raise EnvironmentError(f"CHSL ERROR (Line {actual_line_num}): Missing Required OS Secret '{env_var}'!")
                final_val = os.environ[env_var]
            elif val.startswith("COPY "):
                ref_key = val[5:].strip()
                found = False
                for lvl in range(current_level, -2, -1):
                    if ref_key in scope_path[lvl]:
                        final_val = scope_path[lvl][ref_key]
                        found = True
                        break
                if not found:
                    raise NameError(f"CHSL ERROR (Line {actual_line_num}): Tried to COPY '{ref_key}', but it doesn't exist!")
            else:
                try:
                    final_val = float(val) if "." in val else int(val)
                except ValueError:
                    final_val = val
                    
            scope_path[current_level][key] = final_val
            continue
            
        raise SyntaxError(f"CHSL ERROR (Line {actual_line_num}): Unrecognized syntax -> '{line}'")
        
    # Flush remaining state at end of file
    if state == "IN_LIST":
        scope_path[current_level][current_key] = current_list
    elif state == "IN_LINE":
        scope_path[current_level][current_key] = "\n".join(current_lines)
        
    return config

def parse_chsl_file(filepath):
    abs_path = os.path.abspath(filepath)
    with open(abs_path, 'r') as f:
        return parse_chsl(f.read(), os.path.dirname(abs_path))

# ==========================================
# PHASE 2: THE CHSL WRITER (Serializer)
# ==========================================
def dump_chsl(config_dict, level=0):
    lines = []
    for key, value in config_dict.items():
        if isinstance(value, dict):
            lines.append(f"\n{level}{key}{level}")
            lines.extend(dump_chsl(value, level + 1))
            
        elif isinstance(value, list):
            # Smart Array Serializer: Choose 'ARE' if safe, otherwise fallback to '#'
            is_safe_for_are = all(not isinstance(i, (dict, list)) and (not isinstance(i, str) or ("\n" not in i and "," not in i)) for i in value)
            
            if is_safe_for_are and len(value) > 0:
                are_items = []
                for item in value:
                    if isinstance(item, bool):
                        are_items.append("YES" if item else "NO")
                    elif item is None:
                        are_items.append("EMPTY")
                    elif isinstance(item, (int, float)):
                        are_items.append(str(item))
                    elif isinstance(item, str) and re.match(r"^-?\d+(\.\d+)?$", item):
                        are_items.append(f"PIN {item}")
                    else:
                        are_items.append(str(item))
                lines.append(f"{key} ARE {', '.join(are_items)}")
            else:
                lines.append(f"{key} =")
                for item in value:
                    if isinstance(item, bool):
                        lines.append(f"#YES" if item else f"#NO")
                    elif item is None:
                        lines.append(f"#EMPTY")
                    elif isinstance(item, (int, float)):
                        lines.append(f"#{item}")
                    elif isinstance(item, str) and re.match(r"^-?\d+(\.\d+)?$", item):
                        lines.append(f"#PIN {item}")
                    else:
                        lines.append(f"#{item}")
                        
        elif isinstance(value, bool):
            lines.append(f"{key} = {'YES' if value else 'NO'}")
            
        elif value is None:
            lines.append(f"{key} = EMPTY")
            
        elif isinstance(value, (int, float)):
            lines.append(f"{key} = {value}")
            
        elif isinstance(value, str):
            if "\n" in value:
                lines.append(f"{key} = LINE")
                for i, text_line in enumerate(value.split("\n"), 1):
                    lines.append(f"{i} = {text_line}")
            elif re.match(r"^-?\d+(\.\d+)?$", value):
                lines.append(f"{key} = PIN {value}")
            else:
                lines.append(f"{key} = {value}")
                
    return lines

def write_chsl_file(config_dict, filename="output.chsl"):
    lines = ["NOTE: Automatically generated by the CHSL Engine\n"]
    lines.extend(dump_chsl(config_dict))
    final_text = "\n".join(lines)
    with open(filename, "w") as f:
        f.write(final_text)
    return final_text