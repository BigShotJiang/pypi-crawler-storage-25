# Emancipation MCP Server Project

## Stack

- Python 3.11+
- MCP module
- No other external dependencies

## Mandatory Workflow

1. Implement the changes
2. Run targeted tests
3. Fix all errors and repeat failed tests
4. Run all QA checks
5. Fix all QA violations and repeat checks until clean
6. Update `README.md` with user facing changes
7. Update `CHANGELOG.md` added/changes/removed user-facing features

## Python Rules

- You must follow PEP8
- Maximum line length is 79 characters
- All MCP tools must have LLM prompt optimized docstrings describing what the tool does and when to use it
- Type hints are required
- Avoid type and QA check suppression by using `# type: ignore`, `# noqa` comments, or `cast()`; you must fix the underlying issue, ask for guidance if necessary

## Version Handling
- Version is in `src/emancipation/__init__.py`.
- Only bump version when explicitly requested.
- Determine bump level according to changes since last version.
- Use Semantic Versioning: patch for bug fixes, minor for new features.
- **Never bump major version unless explicitly requested**.
- After bumping version, you must ensure that `CHANGELOG.md` is updated.

## Testing

Full test suite:
```bash
python -m unittest discover --failfast --buffer tests
```

Targeted tests:
```bash
python -m unittest --failfast --buffer tests.test_module
python -m unittest --failfast --buffer tests.test_module.MyModuleTest
python -m unittest --failfast --buffer tests.test_module.MyModuleTest.test_foo
```

Prefer targeted tests during development to speed up the process.

## QA checks

```bash
ruff check src tests
mypy src
vulture
```

## Changelog Guidelines

- Sections must always be in release order after "Unreleased". Example:
  ```
  ## [Unreleased]

  ### {Added/Changed/Etc.}

  - ...

  ## [0.4.0] - 2026-04-02

  ...

  ## [0.3.0] - 2026-04-02

  ...
  ```
- "Unreleased" section must always come first
- You must add sub-sections (`### Fixed`, `### Added`, etc.) to "Unreleased"
- One changeset = one line
- Focus on user-facing behavior, not implementation details
- Do not document what can be discovered by `git diff`, it's documented somewhere else or in `--help`
- Keep entries brief and meaningful

## Git

- Do not execute any destructive Git command
- Commit only when explicitly requested, even if already committed in the session

### Commit

#### Message Format

- Title: 50 or less characters
- Description: do not add, unless strictly necessary; line wrap to 72 characters if added
- Do not replicate in title/description what can be seen on a diff

#### Commit Gate

Commit only when:
- Task completed as expected and without errors
- Full test suite: pass
- QA checks: pass
- `README.md` updated
- `CHANGELOG.md` updated
