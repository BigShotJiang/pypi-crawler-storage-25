from __future__ import annotations

import argparse
import logging
import os
import sys
from typing import Annotated

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from .config import load_config, load_smtp_config
from . import __version__
from .imap_client import (
    DeleteMessageResult,
    MessageDetails,
    MessageSummary,
    MoveMessageResult,
    delete_message as imap_delete_message,
    get_message as imap_get_message,
    list_mailboxes as imap_list_mailboxes,
    list_messages as imap_list_messages,
    move_message as imap_move_message,
    search_messages as imap_search_messages,
)
from .smtp_client import SendEmailResult, send_email as smtp_send_email

SERVER_NAME = os.getenv("SERVER_NAME", "emancipation")

_LOG_LEVELS = {
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "warning": logging.WARNING,
    "error": logging.ERROR,
    "critical": logging.CRITICAL,
}


def _parse_log_level(name: str) -> int:
    value = os.getenv(name, "info")
    normalized = value.strip().lower()
    if normalized in _LOG_LEVELS:
        return _LOG_LEVELS[normalized]
    allowed_values = ", ".join(sorted(_LOG_LEVELS))
    raise RuntimeError(
        f"Invalid log level for {name}: {value}. "
        f"Expected one of: {allowed_values}"
    )


SERVER_LOG_LEVEL = _parse_log_level("SERVER_LOG_LEVEL")
logging.basicConfig(
    level=SERVER_LOG_LEVEL,
    format="%(asctime)s %(levelname)s %(name)s - %(message)s",
)
logger = logging.getLogger(__name__)


def _parse_enabled_flag(name: str) -> bool:
    value = os.getenv(name)
    if value is None:
        return True
    normalized = value.strip().lower()
    if normalized in {"true", "yes", "1"}:
        return True
    if normalized in {"false", "no", "0"}:
        return False
    raise RuntimeError(
        f"Invalid boolean value for {name}: {value}. "
        "Expected one of: true, yes, 1, false, no, 0"
    )


IMAP_ENABLED = _parse_enabled_flag("IMAP_ENABLED")
SMTP_ENABLED = _parse_enabled_flag("SMTP_ENABLED")

mcp = FastMCP(SERVER_NAME)


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    if argv is None:
        argv = sys.argv[1:]

    parser = argparse.ArgumentParser(prog="emancipation")
    subparsers = parser.add_subparsers(dest="transport")

    shared_network_options = argparse.ArgumentParser(add_help=False)
    shared_network_options.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind for network transport.",
    )
    shared_network_options.add_argument(
        "--port",
        type=int,
        default=8143,
        help="Port to bind for network transport.",
    )

    subparsers.add_parser(
        "stdio",
        help="Run MCP over stdio.",
    )

    for transport_name in ("sse", "streamable-http"):
        subparsers.add_parser(
            transport_name,
            parents=[shared_network_options],
            help=f"Run MCP over {transport_name}.",
        )

    if not argv:
        argv = ["stdio"]

    return parser.parse_args(argv)


def emcp_list_mailboxes() -> list[str]:
    """List IMAP mailboxes for this account.

    Use before mailbox-scoped tools.
    """
    logger.debug("Listing IMAP mailboxes")
    try:
        config = load_config()
        mailboxes = imap_list_mailboxes(config)
    except Exception:
        logger.error("Failed to list IMAP mailboxes")
        raise
    logger.info("Listed %d IMAP mailboxes", len(mailboxes))
    return mailboxes


def emcp_search_messages(
    mailbox: Annotated[
        str | None,
        Field(
            description=(
                "Mailbox to search. Uses configured default "
                "when omitted."
            )
        ),
    ] = None,
    query: Annotated[
        str,
        Field(
            description=(
                "IMAP search query, such as ALL, UNSEEN, "
                'or FROM "alerts@example.com".'
            )
        ),
    ] = "ALL",
    limit: Annotated[
        int,
        Field(
            description=(
                "Requested page size. Service clamps values "
                "to 1..100."
            )
        ),
    ] = 50,
    offset: Annotated[
        int,
        Field(
            description=(
                "Requested page offset. Negative values are "
                "treated as 0."
            )
        ),
    ] = 0,
) -> list[str]:
    """Return message IDs matching an IMAP query.

    Use for polling (for example, `UNSEEN`) and pass IDs to
    emcp_get_message/emcp_move_message/emcp_delete_message.
    """
    logger.debug(
        "Searching IMAP messages mailbox=%s query=%s limit=%d offset=%d",
        mailbox,
        query,
        limit,
        offset,
    )
    try:
        config = load_config()
        selected_mailbox = mailbox or config.mailbox
        message_ids = imap_search_messages(
            config, selected_mailbox, query, limit, offset
        )
    except Exception:
        logger.error("Failed to search IMAP messages")
        raise
    logger.info(
        "Found %d message IDs in mailbox=%s",
        len(message_ids),
        selected_mailbox,
    )
    return message_ids


def emcp_list_messages(
    mailbox: Annotated[
        str | None,
        Field(
            description=(
                "Mailbox to search. Uses configured default "
                "when omitted."
            )
        ),
    ] = None,
    query: Annotated[
        str,
        Field(description="IMAP search query, such as ALL or UNSEEN."),
    ] = "ALL",
    limit: Annotated[
        int,
        Field(
            description=(
                "Requested page size. Service clamps values "
                "to 1..100."
            )
        ),
    ] = 20,
    offset: Annotated[
        int,
        Field(
            description=(
                "Requested page offset. Negative values are "
                "treated as 0."
            )
        ),
    ] = 0,
) -> list[MessageSummary]:
    """List message headers (id, subject, sender, date).

    Use for triage before fetching bodies. Reuse IDs with
    emcp_get_message/emcp_move_message/emcp_delete_message.
    """
    logger.debug(
        "Listing IMAP messages mailbox=%s query=%s limit=%d offset=%d",
        mailbox,
        query,
        limit,
        offset,
    )
    try:
        config = load_config()
        selected_mailbox = mailbox or config.mailbox
        messages = imap_list_messages(
            config, selected_mailbox, query, limit, offset
        )
    except Exception:
        logger.error("Failed to list IMAP messages")
        raise
    logger.info(
        "Listed %d IMAP message summaries from mailbox=%s",
        len(messages),
        selected_mailbox,
    )
    return messages


def emcp_get_message(
    message_id: Annotated[
        str,
        Field(
            description=(
                "Message ID to fetch, typically from "
                "search_messages or list_messages."
            )
        ),
    ],
    mailbox: Annotated[
        str | None,
        Field(
            description=(
                "Source mailbox. Uses configured default "
                "when omitted."
            )
        ),
    ] = None,
    include_body: Annotated[
        bool,
        Field(
            description=(
                "When true, includes extracted text/plain "
                "body in body_text."
            )
        ),
    ] = False,
) -> MessageDetails:
    """Fetch one message by ID, with optional plain-text body.

    Use IDs from search/list results. Fails if the ID is not found.
    """
    logger.debug(
        "Fetching IMAP message id=%s mailbox=%s include_body=%s",
        message_id,
        mailbox,
        include_body,
    )
    try:
        config = load_config()
        selected_mailbox = mailbox or config.mailbox
        message = imap_get_message(
            config,
            selected_mailbox,
            message_id,
            include_body,
        )
    except Exception:
        logger.error("Failed to fetch IMAP message id=%s", message_id)
        raise
    logger.info("Fetched IMAP message id=%s", message_id)
    return message


def emcp_send_email(
    to: Annotated[
        list[str],
        Field(
            description=(
                "Primary recipients. Must include at least "
                "one non-empty address."
            )
        ),
    ],
    subject: Annotated[str, Field(description="Email subject line.")],
    text_body: Annotated[str, Field(description="Plain-text email body.")],
    cc: Annotated[
        list[str] | None,
        Field(description="Optional carbon-copy recipients."),
    ] = None,
    bcc: Annotated[
        list[str] | None,
        Field(description="Optional blind carbon-copy recipients."),
    ] = None,
    reply_to: Annotated[
        str | None,
        Field(description="Optional Reply-To address."),
    ] = None,
) -> SendEmailResult:
    """Send a plain-text email via SMTP.

    Use for notifications, summaries, or replies.
    """
    logger.debug(
        "Sending email to_count=%d cc_count=%d bcc_count=%d",
        len(to),
        len(cc or []),
        len(bcc or []),
    )
    try:
        config = load_smtp_config()
        result = smtp_send_email(
            config,
            to,
            subject,
            text_body,
            cc,
            bcc,
            reply_to,
        )
    except Exception:
        logger.error("Failed to send email")
        raise
    logger.info(
        "Sent email message_id=%s recipients=%d",
        result["message_id"],
        result["accepted_recipients_count"],
    )
    return result


def emcp_delete_message(
    message_id: Annotated[
        str,
        Field(description="Message ID to mark deleted."),
    ],
    mailbox: Annotated[
        str | None,
        Field(
            description=(
                "Mailbox containing the message. Uses "
                "configured default when omitted."
            )
        ),
    ] = None,
    expunge: Annotated[
        bool,
        Field(
            description=(
                "When true, permanently removes deleted "
                "messages immediately."
            )
        ),
    ] = False,
) -> DeleteMessageResult:
    """Mark one message as deleted.

    Use after processing to avoid reprocessing.
    """
    logger.debug(
        "Deleting IMAP message id=%s mailbox=%s expunge=%s",
        message_id,
        mailbox,
        expunge,
    )
    if expunge:
        logger.warning("Deleting message with expunge enabled")
    try:
        config = load_config()
        selected_mailbox = mailbox or config.mailbox
        result = imap_delete_message(
            config,
            selected_mailbox,
            message_id,
            expunge,
        )
    except Exception:
        logger.error("Failed to delete IMAP message id=%s", message_id)
        raise
    logger.info("Deleted IMAP message id=%s", message_id)
    return result


def emcp_move_message(
    message_id: Annotated[
        str,
        Field(description="Message ID to move."),
    ],
    destination_mailbox: Annotated[
        str,
        Field(
            description=(
                "Destination mailbox to receive the "
                "copied message."
            )
        ),
    ],
    source_mailbox: Annotated[
        str | None,
        Field(
            description=(
                "Source mailbox containing the message. "
                "Uses configured default when omitted."
            )
        ),
    ] = None,
    expunge: Annotated[
        bool,
        Field(
            description=(
                "When true, expunges deleted source "
                "messages after move."
            )
        ),
    ] = True,
) -> MoveMessageResult:
    """Move one message from source mailbox to destination mailbox.

    Use to archive or route processed messages.
    """
    logger.debug(
        "Moving IMAP message id=%s source=%s destination=%s expunge=%s",
        message_id,
        source_mailbox,
        destination_mailbox,
        expunge,
    )
    if expunge:
        logger.warning("Moving message with expunge enabled")
    try:
        config = load_config()
        selected_source_mailbox = source_mailbox or config.mailbox
        result = imap_move_message(
            config,
            selected_source_mailbox,
            destination_mailbox,
            message_id,
            expunge,
        )
    except Exception:
        logger.error("Failed to move IMAP message id=%s", message_id)
        raise
    logger.info(
        "Moved IMAP message id=%s to mailbox=%s",
        message_id,
        destination_mailbox,
    )
    return result


if IMAP_ENABLED:
    mcp.tool()(emcp_list_mailboxes)
    mcp.tool()(emcp_search_messages)
    mcp.tool()(emcp_list_messages)
    mcp.tool()(emcp_get_message)
    mcp.tool()(emcp_delete_message)
    mcp.tool()(emcp_move_message)

if SMTP_ENABLED:
    mcp.tool()(emcp_send_email)


def main(argv: list[str] | None = None) -> None:
    args = _parse_args(argv)

    logger.info(
        "Starting %s v%s with transport=%s",
        SERVER_NAME,
        __version__,
        args.transport,
    )
    if not IMAP_ENABLED and not SMTP_ENABLED:
        logger.warning(
            "Tool status: imap=disabled smtp=disabled; "
            "no mail tools will be available"
        )
    else:
        imap_status = "enabled" if IMAP_ENABLED else "disabled"
        smtp_status = "enabled" if SMTP_ENABLED else "disabled"
        logger.info(
            "Tool status: imap=%s smtp=%s",
            imap_status,
            smtp_status,
        )

    run_options = {"transport": args.transport}
    if hasattr(args, "host"):
        run_options["host"] = args.host
    if hasattr(args, "port"):
        run_options["port"] = args.port
    logger.debug("MCP run options: %s", run_options)
    try:
        mcp.run(**run_options)
    except Exception:
        logger.critical("MCP server terminated unexpectedly")
        raise


if __name__ == "__main__":
    main()
