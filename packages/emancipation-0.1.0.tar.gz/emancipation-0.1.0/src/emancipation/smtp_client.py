from __future__ import annotations

import smtplib
import logging
from email.message import EmailMessage
from email.utils import make_msgid
from typing import TypedDict

from .config import SmtpConfig

logger = logging.getLogger(__name__)


class SendEmailResult(TypedDict):
    status: str
    message_id: str
    accepted_recipients_count: int


def _build_message(
    config: SmtpConfig,
    to: list[str],
    subject: str,
    text_body: str,
    cc: list[str] | None,
    bcc: list[str] | None,
    reply_to: str | None,
) -> tuple[EmailMessage, list[str]]:
    recipients_to = [item.strip() for item in to if item.strip()]
    recipients_cc = [item.strip() for item in (cc or []) if item.strip()]
    recipients_bcc = [item.strip() for item in (bcc or []) if item.strip()]

    if not recipients_to:
        raise RuntimeError("At least one recipient is required")

    msg = EmailMessage()
    msg_id = make_msgid()
    msg["Message-ID"] = msg_id
    msg["From"] = config.from_email
    msg["To"] = ", ".join(recipients_to)
    msg["Subject"] = subject
    if recipients_cc:
        msg["Cc"] = ", ".join(recipients_cc)
    if reply_to:
        msg["Reply-To"] = reply_to.strip()
    msg.set_content(text_body)

    all_recipients = recipients_to + recipients_cc + recipients_bcc
    return msg, all_recipients


def send_email(
    config: SmtpConfig,
    to: list[str],
    subject: str,
    text_body: str,
    cc: list[str] | None = None,
    bcc: list[str] | None = None,
    reply_to: str | None = None,
) -> SendEmailResult:
    msg, all_recipients = _build_message(
        config, to, subject, text_body, cc, bcc, reply_to
    )
    logger.debug(
        "Connecting to SMTP server host=%s port=%d ssl=%s tls=%s",
        config.host,
        config.port,
        config.use_ssl,
        config.use_tls,
    )

    if config.use_ssl:
        if config.timeout is None:
            with smtplib.SMTP_SSL(config.host, config.port) as smtp:
                logger.debug("Connected to SMTP server host=%s", config.host)
                smtp.login(config.username, config.password)
                logger.debug(
                    "Authenticated with SMTP server host=%s",
                    config.host,
                )
                smtp.send_message(msg, to_addrs=all_recipients)
                logger.debug(
                    "Disconnecting from SMTP server host=%s",
                    config.host,
                )
        else:
            with smtplib.SMTP_SSL(
                config.host,
                config.port,
                timeout=config.timeout,
            ) as smtp:
                logger.debug("Connected to SMTP server host=%s", config.host)
                smtp.login(config.username, config.password)
                logger.debug(
                    "Authenticated with SMTP server host=%s",
                    config.host,
                )
                smtp.send_message(msg, to_addrs=all_recipients)
                logger.debug(
                    "Disconnecting from SMTP server host=%s",
                    config.host,
                )
    else:
        if config.timeout is None:
            with smtplib.SMTP(config.host, config.port) as smtp:
                logger.debug("Connected to SMTP server host=%s", config.host)
                if config.use_tls:
                    logger.debug(
                        "Starting TLS with SMTP server host=%s",
                        config.host,
                    )
                    smtp.starttls()
                smtp.login(config.username, config.password)
                logger.debug(
                    "Authenticated with SMTP server host=%s",
                    config.host,
                )
                smtp.send_message(msg, to_addrs=all_recipients)
                logger.debug(
                    "Disconnecting from SMTP server host=%s",
                    config.host,
                )
        else:
            with smtplib.SMTP(
                config.host,
                config.port,
                timeout=config.timeout,
            ) as smtp:
                logger.debug("Connected to SMTP server host=%s", config.host)
                if config.use_tls:
                    logger.debug(
                        "Starting TLS with SMTP server host=%s",
                        config.host,
                    )
                    smtp.starttls()
                smtp.login(config.username, config.password)
                logger.debug(
                    "Authenticated with SMTP server host=%s",
                    config.host,
                )
                smtp.send_message(msg, to_addrs=all_recipients)
                logger.debug(
                    "Disconnecting from SMTP server host=%s",
                    config.host,
                )

    return {
        "status": "sent",
        "message_id": str(msg.get("Message-ID", "")),
        "accepted_recipients_count": len(all_recipients),
    }
