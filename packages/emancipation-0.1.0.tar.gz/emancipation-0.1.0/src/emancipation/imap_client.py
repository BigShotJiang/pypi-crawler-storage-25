from __future__ import annotations

import imaplib
import logging
import threading
import time
import atexit
from contextlib import contextmanager
from dataclasses import dataclass
from email import message_from_bytes
from email.header import decode_header
from typing import TypedDict

from .config import ImapConfig

logger = logging.getLogger(__name__)


@dataclass
class _SessionEntry:
    client: imaplib.IMAP4_SSL
    expires_at: float


_session_cache: dict[tuple[str, int, str, float | None], _SessionEntry] = {}
_session_lock = threading.Lock()


class MessageSummary(TypedDict):
    id: str
    subject: str
    sender: str
    date: str


class MessageDetails(TypedDict):
    id: str
    subject: str
    sender: str
    to: str
    date: str
    body_text: str


class DeleteMessageResult(TypedDict):
    status: str
    message_id: str
    mailbox: str
    expunged: bool


class MoveMessageResult(TypedDict):
    status: str
    message_id: str
    source_mailbox: str
    destination_mailbox: str
    expunged: bool


def _decode_header_value(raw_value: str | None) -> str:
    if not raw_value:
        return ""
    parts = decode_header(raw_value)
    decoded: list[str] = []
    for value, encoding in parts:
        if isinstance(value, bytes):
            decoded.append(value.decode(encoding or "utf-8", errors="replace"))
        else:
            decoded.append(value)
    return "".join(decoded).strip()


@contextmanager
def imap_session(config: ImapConfig):
    if config.session_ttl == 0:
        client = _build_client(config)
        try:
            yield client
        finally:
            _safe_logout(client, config.host)
        return

    client = _get_client(config)
    yield client


def _cache_key(config: ImapConfig) -> tuple[str, int, str, float | None]:
    return (config.host, config.port, config.username, config.timeout)


def _build_client(config: ImapConfig) -> imaplib.IMAP4_SSL:
    logger.debug(
        "Connecting to IMAP server host=%s port=%d",
        config.host,
        config.port,
    )
    if config.timeout is None:
        client = imaplib.IMAP4_SSL(config.host, config.port)
    else:
        client = imaplib.IMAP4_SSL(
            config.host,
            config.port,
            timeout=config.timeout,
        )
    logger.debug("Connected to IMAP server host=%s", config.host)
    client.login(config.username, config.password)
    logger.debug("Authenticated with IMAP server host=%s", config.host)
    return client


def _is_client_alive(client: imaplib.IMAP4_SSL) -> bool:
    try:
        status, _ = client.noop()
    except (imaplib.IMAP4.abort, imaplib.IMAP4.error):
        return False
    return status == "OK"


def _safe_logout(client: imaplib.IMAP4_SSL, host: str) -> None:
    try:
        client.logout()
        logger.debug("Disconnected from IMAP server host=%s", host)
    except Exception:
        logger.debug(
            "IMAP disconnect failed host=%s",
            host,
            exc_info=True,
        )


def _get_client(config: ImapConfig) -> imaplib.IMAP4_SSL:
    key = _cache_key(config)
    now = time.monotonic()

    with _session_lock:
        existing = _session_cache.get(key)

        if existing is not None:
            if now >= existing.expires_at:
                logger.debug("IMAP session expired host=%s", config.host)
                _safe_logout(existing.client, config.host)
                del _session_cache[key]
            elif _is_client_alive(existing.client):
                logger.debug("Reusing IMAP session host=%s", config.host)
                existing.expires_at = now + config.session_ttl
                return existing.client
            else:
                logger.debug(
                    "IMAP session unhealthy, reconnecting host=%s",
                    config.host,
                )
                _safe_logout(existing.client, config.host)
                del _session_cache[key]

        client = _build_client(config)
        _session_cache[key] = _SessionEntry(
            client=client,
            expires_at=now + config.session_ttl,
        )
        return client


def _close_cached_sessions() -> None:
    with _session_lock:
        entries = list(_session_cache.values())
        _session_cache.clear()
    for entry in entries:
        _safe_logout(entry.client, "<cached>")


atexit.register(_close_cached_sessions)


def list_mailboxes(config: ImapConfig) -> list[str]:
    with imap_session(config) as client:
        status, mailboxes = client.list()
        if status != "OK":
            raise RuntimeError("Could not list mailboxes")

        names: list[str] = []
        for row in mailboxes or []:
            text = row.decode("utf-8", errors="replace")
            parts = text.rsplit('"', 2)
            if len(parts) >= 2:
                names.append(parts[-2])
            else:
                names.append(text)
        return names


def _select_mailbox(
    client: imaplib.IMAP4_SSL,
    mailbox: str,
    readonly: bool = True,
) -> None:
    status, _ = client.select(mailbox, readonly=readonly)
    if status != "OK":
        raise RuntimeError(f"Could not select mailbox: {mailbox}")


def _bounded(limit: int, maximum: int = 100) -> int:
    return max(1, min(limit, maximum))


def _paged_ids(ids: list[str], limit: int, offset: int) -> list[str]:
    if offset < 0:
        offset = 0
    if not ids:
        return []

    newest_first = list(reversed(ids))
    start = offset
    end = offset + _bounded(limit)
    return newest_first[start:end]


def _fetch_message_bytes(
    client: imaplib.IMAP4_SSL, msg_id: str
) -> bytes | None:
    status, msg_data = client.fetch(msg_id, "(RFC822)")
    if status != "OK" or not msg_data:
        return None

    first = msg_data[0]
    if not isinstance(first, tuple) or len(first) < 2:
        return None
    payload = first[1]
    if not isinstance(payload, bytes):
        return None
    return payload


def _extract_text_body(payload: bytes) -> str:
    message = message_from_bytes(payload)
    if message.is_multipart():
        for part in message.walk():
            content_type = part.get_content_type()
            content_disposition = (
                part.get("Content-Disposition") or ""
            ).lower()
            if (
                content_type == "text/plain"
                and "attachment" not in content_disposition
            ):
                raw = part.get_payload(decode=True)
                if isinstance(raw, bytes):
                    charset = part.get_content_charset() or "utf-8"
                    return raw.decode(charset, errors="replace").strip()
        return ""

    raw = message.get_payload(decode=True)
    if isinstance(raw, bytes):
        charset = message.get_content_charset() or "utf-8"
        return raw.decode(charset, errors="replace").strip()

    raw_text = message.get_payload()
    return raw_text.strip() if isinstance(raw_text, str) else ""


def search_messages(
    config: ImapConfig,
    mailbox: str,
    query: str = "ALL",
    limit: int = 50,
    offset: int = 0,
) -> list[str]:
    with imap_session(config) as client:
        _select_mailbox(client, mailbox)
        status, data = client.search(None, query or "ALL")
        if status != "OK" or not data or not data[0]:
            return []

        ids = [
            item.decode("ascii", errors="replace")
            for item in data[0].split()
        ]
        selected_ids = _paged_ids(ids, limit, offset)
        return selected_ids


def list_messages(
    config: ImapConfig,
    mailbox: str,
    query: str = "ALL",
    limit: int = 20,
    offset: int = 0,
) -> list[MessageSummary]:
    with imap_session(config) as client:
        _select_mailbox(client, mailbox)
        status, data = client.search(None, query or "ALL")
        if status != "OK" or not data or not data[0]:
            return []

        ids = [
            item.decode("ascii", errors="replace")
            for item in data[0].split()
        ]
        selected_ids = _paged_ids(ids, limit, offset)
        messages: list[MessageSummary] = []

        for msg_id in selected_ids:
            payload = _fetch_message_bytes(client, msg_id)
            if payload is None:
                continue

            msg = message_from_bytes(payload)
            messages.append(
                {
                    "id": msg_id,
                    "subject": _decode_header_value(msg.get("Subject")),
                    "sender": _decode_header_value(msg.get("From")),
                    "date": _decode_header_value(msg.get("Date")),
                }
            )

        return messages


def get_message(
    config: ImapConfig,
    mailbox: str,
    message_id: str,
    include_body: bool = False,
) -> MessageDetails:
    with imap_session(config) as client:
        _select_mailbox(client, mailbox)
        payload = _fetch_message_bytes(client, message_id)
        if payload is None:
            raise RuntimeError(f"Could not fetch message: {message_id}")

        msg = message_from_bytes(payload)
        body_text = _extract_text_body(payload) if include_body else ""
        return {
            "id": message_id,
            "subject": _decode_header_value(msg.get("Subject")),
            "sender": _decode_header_value(msg.get("From")),
            "to": _decode_header_value(msg.get("To")),
            "date": _decode_header_value(msg.get("Date")),
            "body_text": body_text,
        }


def delete_message(
    config: ImapConfig,
    mailbox: str,
    message_id: str,
    expunge: bool = False,
) -> DeleteMessageResult:
    with imap_session(config) as client:
        _select_mailbox(client, mailbox, readonly=False)
        status, _ = client.store(message_id, "+FLAGS", r"(\Deleted)")
        if status != "OK":
            raise RuntimeError(
                f"Could not mark message as deleted: {message_id}"
            )

        if expunge:
            status, _ = client.expunge()
            if status != "OK":
                raise RuntimeError("Could not expunge deleted messages")

        return {
            "status": "deleted",
            "message_id": message_id,
            "mailbox": mailbox,
            "expunged": expunge,
        }


def move_message(
    config: ImapConfig,
    source_mailbox: str,
    destination_mailbox: str,
    message_id: str,
    expunge: bool = True,
) -> MoveMessageResult:
    with imap_session(config) as client:
        _select_mailbox(client, source_mailbox, readonly=False)
        status, _ = client.copy(message_id, destination_mailbox)
        if status != "OK":
            raise RuntimeError(
                f"Could not copy message to mailbox: {destination_mailbox}"
            )

        status, _ = client.store(message_id, "+FLAGS", r"(\Deleted)")
        if status != "OK":
            raise RuntimeError(
                f"Could not mark message as deleted: {message_id}"
            )

        if expunge:
            status, _ = client.expunge()
            if status != "OK":
                raise RuntimeError("Could not expunge deleted messages")

        return {
            "status": "moved",
            "message_id": message_id,
            "source_mailbox": source_mailbox,
            "destination_mailbox": destination_mailbox,
            "expunged": expunge,
        }
