from __future__ import annotations

import os
from typing import NamedTuple


class ImapConfig(NamedTuple):
    host: str
    username: str
    password: str
    port: int = 993
    mailbox: str = "INBOX"
    timeout: float | None = None
    session_ttl: float = 120.0


class SmtpConfig(NamedTuple):
    host: str
    username: str
    password: str
    from_email: str
    port: int = 587
    use_tls: bool = True
    use_ssl: bool = False
    timeout: float | None = None


def _parse_bool(value: str | None, *, default: bool) -> bool:
    if value is None:
        return default
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise RuntimeError(f"Invalid boolean value: {value}")


def _parse_optional_timeout(value: str | None, *, name: str) -> float | None:
    if value is None:
        return None

    normalized = value.strip()
    if not normalized:
        return None

    try:
        timeout = float(normalized)
    except ValueError as error:
        message = f"Invalid timeout value for {name}: {value}"
        raise RuntimeError(message) from error

    if timeout <= 0:
        raise RuntimeError(f"Invalid timeout value for {name}: {value}")

    return timeout


def _parse_session_ttl(value: str | None, *, name: str) -> float:
    if value is None:
        return 120.0

    normalized = value.strip()
    if not normalized:
        return 120.0

    try:
        ttl = float(normalized)
    except ValueError as error:
        message = f"Invalid TTL value for {name}: {value}"
        raise RuntimeError(message) from error

    if ttl < 0:
        raise RuntimeError(f"Invalid TTL value for {name}: {value}")

    return ttl


def load_config() -> ImapConfig:
    host = os.getenv("IMAP_HOST", "").strip()
    username = os.getenv("IMAP_USERNAME", "").strip()
    password = os.getenv("IMAP_PASSWORD", "")
    mailbox = os.getenv("IMAP_MAILBOX", "INBOX").strip() or "INBOX"
    port = int(os.getenv("IMAP_PORT", "993"))
    timeout = _parse_optional_timeout(
        os.getenv("IMAP_TIMEOUT"),
        name="IMAP_TIMEOUT",
    )
    session_ttl = _parse_session_ttl(
        os.getenv("IMAP_SESSION_TTL"),
        name="IMAP_SESSION_TTL",
    )

    missing: list[str] = []
    if not host:
        missing.append("IMAP_HOST")
    if not username:
        missing.append("IMAP_USERNAME")
    if not password:
        missing.append("IMAP_PASSWORD")

    if missing:
        joined = ", ".join(missing)
        raise RuntimeError(
            "Missing required IMAP environment variables: "
            f"{joined}"
        )

    return ImapConfig(
        host=host,
        username=username,
        password=password,
        port=port,
        mailbox=mailbox,
        timeout=timeout,
        session_ttl=session_ttl,
    )


def load_smtp_config() -> SmtpConfig:
    host = os.getenv("SMTP_HOST", "").strip()
    username = os.getenv("SMTP_USERNAME", "").strip()
    password = os.getenv("SMTP_PASSWORD", "")
    from_email = os.getenv("SMTP_FROM", "").strip()
    use_ssl = _parse_bool(os.getenv("SMTP_USE_SSL"), default=False)
    use_tls = _parse_bool(os.getenv("SMTP_USE_TLS"), default=not use_ssl)
    timeout = _parse_optional_timeout(
        os.getenv("SMTP_TIMEOUT"),
        name="SMTP_TIMEOUT",
    )
    port_default = "465" if use_ssl else "587"
    port = int(os.getenv("SMTP_PORT", port_default))

    missing: list[str] = []
    if not host:
        missing.append("SMTP_HOST")
    if not username:
        missing.append("SMTP_USERNAME")
    if not password:
        missing.append("SMTP_PASSWORD")
    if not from_email:
        missing.append("SMTP_FROM")

    if missing:
        joined = ", ".join(missing)
        raise RuntimeError(
            "Missing required SMTP environment variables: "
            f"{joined}"
        )

    if use_ssl and use_tls:
        raise RuntimeError("SMTP_USE_SSL and SMTP_USE_TLS cannot both be true")

    return SmtpConfig(
        host=host,
        username=username,
        password=password,
        from_email=from_email,
        port=port,
        use_tls=use_tls,
        use_ssl=use_ssl,
        timeout=timeout,
    )
