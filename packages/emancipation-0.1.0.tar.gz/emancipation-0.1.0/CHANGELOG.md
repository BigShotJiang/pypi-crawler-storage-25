# Changelog

All notable changes to this project will be documented in this file.

The project follows [Semantic Versioning 2.0.0](https://semver.org/).

> **BC BREAK** marks backward-incompatible changes. These require a fresh database or manual migration. Review carefully before updating.

## [Unreleased]

### Added

- Added support for serving MCP over SSE and streamable HTTP, in addition to
  stdio.
- Added `IMAP_ENABLED` and `SMTP_ENABLED` environment toggles to control
  whether IMAP and SMTP tools are exported by the server.
- Added `IMAP_TIMEOUT` and `SMTP_TIMEOUT` environment variables to configure
  connection timeouts for IMAP and SMTP operations.
- Added `SERVER_LOG_LEVEL` to configure runtime log verbosity and startup
  visibility, including remote connection lifecycle debug logs.
- Added long-lived IMAP session reuse controlled by `IMAP_SESSION_TTL`
  (default `120` seconds), with `IMAP_SESSION_TTL=0` to disable reuse and
  reconnect per call.

## [0.1.0] - 2026-05-20

### Added

- Added an MCP server over stdio for IMAP mailbox access and SMTP delivery.
- Added tools to list mailboxes, search/list messages, and fetch message
  details by ID.
- Added tools to delete messages and move messages between mailboxes.
- Added plain-text email sending with optional `cc`, `bcc`, and `reply_to`.
- Added environment-variable configuration for IMAP/SMTP credentials,
  transport security, and server name identity.
