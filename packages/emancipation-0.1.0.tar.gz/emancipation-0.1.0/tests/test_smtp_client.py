from __future__ import annotations

import unittest
from unittest.mock import patch

from emancipation.config import SmtpConfig
from emancipation.smtp_client import send_email


class _FakeSmtp:
    def __init__(self) -> None:
        self.started_tls = False
        self.login_args: tuple[str, str] | None = None
        self.sent_to: list[str] = []
        self.sent_subject = ""

    def __enter__(self) -> _FakeSmtp:
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        _ = exc_type
        _ = exc_value
        _ = traceback

    def starttls(self) -> None:
        self.started_tls = True

    def login(self, username: str, password: str) -> None:
        self.login_args = (username, password)

    def send_message(self, msg, to_addrs: list[str]) -> None:
        self.sent_subject = str(msg.get("Subject", ""))
        self.sent_to = to_addrs


class SmtpClientTest(unittest.TestCase):
    def test_send_email_uses_starttls_when_tls_enabled(self) -> None:
        config = SmtpConfig(
            host="smtp.example.com",
            username="agent",
            password="secret",
            from_email="agent@example.com",
            use_tls=True,
            use_ssl=False,
            port=587,
        )
        fake = _FakeSmtp()

        def fake_smtp(
            host: str,
            port: int,
            timeout: float | None = None,
        ) -> _FakeSmtp:
            self.assertEqual(host, "smtp.example.com")
            self.assertEqual(port, 587)
            self.assertIsNone(timeout)
            return fake

        with patch("emancipation.smtp_client.smtplib.SMTP", fake_smtp):
            result = send_email(
                config,
                to=["to@example.com"],
                subject="Hello",
                text_body="Body",
                cc=["cc@example.com"],
                bcc=["bcc@example.com"],
            )

        self.assertTrue(fake.started_tls)
        self.assertEqual(fake.login_args, ("agent", "secret"))
        self.assertEqual(fake.sent_subject, "Hello")
        self.assertEqual(len(fake.sent_to), 3)
        self.assertEqual(result["status"], "sent")

    def test_send_email_uses_ssl_when_enabled(self) -> None:
        config = SmtpConfig(
            host="smtp.example.com",
            username="agent",
            password="secret",
            from_email="agent@example.com",
            use_tls=False,
            use_ssl=True,
            port=465,
        )
        fake = _FakeSmtp()

        def fake_smtp_ssl(
            host: str,
            port: int,
            timeout: float | None = None,
        ) -> _FakeSmtp:
            self.assertEqual(host, "smtp.example.com")
            self.assertEqual(port, 465)
            self.assertIsNone(timeout)
            return fake

        with patch("emancipation.smtp_client.smtplib.SMTP_SSL", fake_smtp_ssl):
            send_email(
                config,
                to=["to@example.com"],
                subject="SSL",
                text_body="Body",
            )

        self.assertFalse(fake.started_tls)
        self.assertEqual(fake.login_args, ("agent", "secret"))

    def test_send_email_requires_at_least_one_recipient(self) -> None:
        config = SmtpConfig(
            host="smtp.example.com",
            username="agent",
            password="secret",
            from_email="agent@example.com",
            use_tls=True,
            use_ssl=False,
        )

        with self.assertRaises(RuntimeError):
            send_email(config, to=[], subject="Hello", text_body="Body")

    def test_send_email_passes_timeout_to_smtp_constructor(self) -> None:
        config = SmtpConfig(
            host="smtp.example.com",
            username="agent",
            password="secret",
            from_email="agent@example.com",
            use_tls=True,
            use_ssl=False,
            port=587,
            timeout=7.5,
        )
        fake = _FakeSmtp()

        def fake_smtp(
            host: str,
            port: int,
            timeout: float | None = None,
        ) -> _FakeSmtp:
            self.assertEqual(host, "smtp.example.com")
            self.assertEqual(port, 587)
            self.assertEqual(timeout, 7.5)
            return fake

        with patch("emancipation.smtp_client.smtplib.SMTP", fake_smtp):
            send_email(
                config,
                to=["to@example.com"],
                subject="Timeout",
                text_body="Body",
            )
