from __future__ import annotations

from contextlib import contextmanager
from email.message import EmailMessage
import unittest
from unittest.mock import patch

from emancipation.config import ImapConfig
from emancipation import imap_client
from emancipation.imap_client import (
    _decode_header_value,
    _paged_ids,
    _close_cached_sessions,
    delete_message,
    get_message,
    imap_session,
    list_messages,
    move_message,
    search_messages,
)


def _build_email_bytes(
    subject: str, sender: str, to: str, date: str, body: str
) -> bytes:
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = to
    msg["Date"] = date
    msg.set_content(body)
    return msg.as_bytes()


class _FakeClient:
    def __init__(self) -> None:
        self.select_status = "OK"
        self.search_status = "OK"
        self.search_data = [b"1 2 3"]
        self.fetch_by_id: dict[str, bytes] = {}
        self.store_status = "OK"
        self.copy_status = "OK"
        self.expunge_status = "OK"
        self.store_calls: list[tuple[str, str, str]] = []
        self.copy_calls: list[tuple[str, str]] = []
        self.expunge_calls = 0

    def select(
        self, _mailbox: str, readonly: bool = True
    ) -> tuple[str, list[bytes]]:
        _ = readonly
        return self.select_status, []

    def search(self, _charset: None, _query: str) -> tuple[str, list[bytes]]:
        return self.search_status, self.search_data

    def fetch(self, msg_id: str, _spec: str):
        payload = self.fetch_by_id.get(msg_id)
        if payload is None:
            return "NO", []
        return "OK", [(b"RFC822", payload)]

    def store(
        self,
        msg_id: str,
        operation: str,
        flag_list: str,
    ) -> tuple[str, list[bytes]]:
        self.store_calls.append((msg_id, operation, flag_list))
        return self.store_status, []

    def copy(
        self,
        msg_id: str,
        destination_mailbox: str,
    ) -> tuple[str, list[bytes]]:
        self.copy_calls.append((msg_id, destination_mailbox))
        return self.copy_status, []

    def expunge(self) -> tuple[str, list[bytes]]:
        self.expunge_calls += 1
        return self.expunge_status, []


class ImapClientTest(unittest.TestCase):
    def setUp(self) -> None:
        _close_cached_sessions()
        self.config = ImapConfig(
            host="imap.example.com",
            username="user",
            password="pw",
        )

    def tearDown(self) -> None:
        _close_cached_sessions()

    def test_decode_header_value_decodes_encoded_words(self) -> None:
        decoded = _decode_header_value("=?utf-8?q?Ol=C3=A1?=")
        self.assertEqual(decoded, "Olá")

    def test_imap_session_passes_timeout_to_constructor(self) -> None:
        observed: dict[str, float | None] = {"timeout": None}

        class _FakeImapClient:
            def login(self, _username: str, _password: str) -> None:
                return None

            def logout(self) -> None:
                return None

        def fake_imap4_ssl(
            _host: str,
            _port: int,
            timeout: float | None = None,
        ) -> _FakeImapClient:
            observed["timeout"] = timeout
            return _FakeImapClient()

        config = ImapConfig(
            host="imap.example.com",
            username="user",
            password="pw",
            timeout=8.0,
        )

        with patch(
            "emancipation.imap_client.imaplib.IMAP4_SSL",
            fake_imap4_ssl,
        ):
            with imap_session(config):
                pass

        self.assertEqual(observed["timeout"], 8.0)

    def test_imap_session_reuses_client_within_ttl(self) -> None:
        class _FakeImapClient:
            def __init__(self) -> None:
                self.noop_calls = 0
                self.logout_calls = 0

            def login(self, _username: str, _password: str) -> None:
                return None

            def logout(self) -> None:
                self.logout_calls += 1

            def noop(self) -> tuple[str, list[bytes]]:
                self.noop_calls += 1
                return "OK", []

        created: list[_FakeImapClient] = []

        def fake_imap4_ssl(
            _host: str,
            _port: int,
            timeout: float | None = None,
        ) -> _FakeImapClient:
            _ = timeout
            client = _FakeImapClient()
            created.append(client)
            return client

        config = ImapConfig(
            host="imap.example.com",
            username="user",
            password="pw",
            session_ttl=30.0,
        )

        with patch(
            "emancipation.imap_client.imaplib.IMAP4_SSL",
            fake_imap4_ssl,
        ):
            with imap_session(config) as first:
                pass
            with imap_session(config) as second:
                pass

        self.assertIs(first, second)
        self.assertEqual(len(created), 1)

    def test_imap_session_reconnects_after_ttl_expiry(self) -> None:
        class _FakeImapClient:
            def login(self, _username: str, _password: str) -> None:
                return None

            def logout(self) -> None:
                return None

            def noop(self) -> tuple[str, list[bytes]]:
                return "OK", []

        created: list[_FakeImapClient] = []

        def fake_imap4_ssl(
            _host: str,
            _port: int,
            timeout: float | None = None,
        ) -> _FakeImapClient:
            _ = timeout
            client = _FakeImapClient()
            created.append(client)
            return client

        config = ImapConfig(
            host="imap.example.com",
            username="user",
            password="pw",
            session_ttl=30.0,
        )

        now_values = [100.0, 131.0]

        def fake_monotonic() -> float:
            return now_values.pop(0)

        with patch(
            "emancipation.imap_client.imaplib.IMAP4_SSL",
            fake_imap4_ssl,
        ):
            with patch(
                "emancipation.imap_client.time.monotonic",
                fake_monotonic,
            ):
                with imap_session(config) as first:
                    pass
                with imap_session(config) as second:
                    pass

        self.assertIsNot(first, second)
        self.assertEqual(len(created), 2)

    def test_imap_session_reconnects_when_noop_fails(self) -> None:
        class _FakeImapClient:
            def __init__(self) -> None:
                self.should_fail_noop = False

            def login(self, _username: str, _password: str) -> None:
                return None

            def logout(self) -> None:
                return None

            def noop(self) -> tuple[str, list[bytes]]:
                if self.should_fail_noop:
                    raise imap_client.imaplib.IMAP4.abort("connection lost")
                return "OK", []

        created: list[_FakeImapClient] = []

        def fake_imap4_ssl(
            _host: str,
            _port: int,
            timeout: float | None = None,
        ) -> _FakeImapClient:
            _ = timeout
            client = _FakeImapClient()
            created.append(client)
            return client

        config = ImapConfig(
            host="imap.example.com",
            username="user",
            password="pw",
            session_ttl=30.0,
        )

        with patch(
            "emancipation.imap_client.imaplib.IMAP4_SSL",
            fake_imap4_ssl,
        ):
            with imap_session(config) as first:
                pass
            created[0].should_fail_noop = True
            with imap_session(config) as second:
                pass

        self.assertIsNot(first, second)
        self.assertEqual(len(created), 2)

    def test_imap_session_with_zero_ttl_disables_reuse(self) -> None:
        class _FakeImapClient:
            def __init__(self) -> None:
                self.logout_calls = 0

            def login(self, _username: str, _password: str) -> None:
                return None

            def logout(self) -> None:
                self.logout_calls += 1

            def noop(self) -> tuple[str, list[bytes]]:
                return "OK", []

        created: list[_FakeImapClient] = []

        def fake_imap4_ssl(
            _host: str,
            _port: int,
            timeout: float | None = None,
        ) -> _FakeImapClient:
            _ = timeout
            client = _FakeImapClient()
            created.append(client)
            return client

        config = ImapConfig(
            host="imap.example.com",
            username="user",
            password="pw",
            session_ttl=0.0,
        )

        with patch(
            "emancipation.imap_client.imaplib.IMAP4_SSL",
            fake_imap4_ssl,
        ):
            with imap_session(config) as first:
                pass
            with imap_session(config) as second:
                pass

        self.assertIsNot(first, second)
        self.assertEqual(len(created), 2)
        self.assertEqual(created[0].logout_calls, 1)
        self.assertEqual(created[1].logout_calls, 1)

    def test_paged_ids_returns_newest_first_with_offset(self) -> None:
        ids = ["1", "2", "3", "4"]
        self.assertEqual(_paged_ids(ids, limit=2, offset=0), ["4", "3"])
        self.assertEqual(_paged_ids(ids, limit=2, offset=1), ["3", "2"])

    def test_search_messages_returns_paged_message_ids(self) -> None:
        client = _FakeClient()

        @contextmanager
        def fake_imap_session(_config: ImapConfig):
            yield client

        with patch("emancipation.imap_client.imap_session", fake_imap_session):
            ids = search_messages(
                self.config,
                "INBOX",
                query="ALL",
                limit=2,
                offset=0,
            )

        self.assertEqual(ids, ["3", "2"])

    def test_list_messages_returns_basic_metadata(self) -> None:
        client = _FakeClient()
        client.fetch_by_id["2"] = _build_email_bytes(
            subject="Second",
            sender="author2@example.com",
            to="me@example.com",
            date="Tue, 19 May 2026 10:00:00 +0000",
            body="Body two",
        )
        client.fetch_by_id["3"] = _build_email_bytes(
            subject="Third",
            sender="author3@example.com",
            to="me@example.com",
            date="Tue, 19 May 2026 11:00:00 +0000",
            body="Body three",
        )

        @contextmanager
        def fake_imap_session(_config: ImapConfig):
            yield client

        with patch("emancipation.imap_client.imap_session", fake_imap_session):
            messages = list_messages(
                self.config,
                "INBOX",
                query="ALL",
                limit=2,
                offset=0,
            )

        self.assertEqual(len(messages), 2)
        self.assertEqual(messages[0]["id"], "3")
        self.assertEqual(messages[0]["subject"], "Third")
        self.assertEqual(messages[1]["id"], "2")
        self.assertEqual(messages[1]["sender"], "author2@example.com")

    def test_get_message_with_body_returns_headers_and_plain_text(
        self,
    ) -> None:
        client = _FakeClient()
        client.fetch_by_id["8"] = _build_email_bytes(
            subject="Hello",
            sender="sender@example.com",
            to="receiver@example.com",
            date="Tue, 19 May 2026 12:00:00 +0000",
            body="Hello from IMAP",
        )

        @contextmanager
        def fake_imap_session(_config: ImapConfig):
            yield client

        with patch("emancipation.imap_client.imap_session", fake_imap_session):
            message = get_message(
                self.config,
                "INBOX",
                message_id="8",
                include_body=True,
            )

        self.assertEqual(message["id"], "8")
        self.assertEqual(message["subject"], "Hello")
        self.assertEqual(message["sender"], "sender@example.com")
        self.assertEqual(message["to"], "receiver@example.com")
        self.assertIn("Hello from IMAP", message["body_text"])

    def test_delete_message_marks_deleted_without_expunge(self) -> None:
        client = _FakeClient()

        @contextmanager
        def fake_imap_session(_config: ImapConfig):
            yield client

        with patch("emancipation.imap_client.imap_session", fake_imap_session):
            result = delete_message(
                self.config,
                "INBOX",
                message_id="10",
                expunge=False,
            )

        self.assertEqual(result["status"], "deleted")
        self.assertFalse(result["expunged"])
        self.assertEqual(client.store_calls, [("10", "+FLAGS", r"(\Deleted)")])
        self.assertEqual(client.expunge_calls, 0)

    def test_move_message_copies_then_deletes_and_expunges(self) -> None:
        client = _FakeClient()

        @contextmanager
        def fake_imap_session(_config: ImapConfig):
            yield client

        with patch("emancipation.imap_client.imap_session", fake_imap_session):
            result = move_message(
                self.config,
                "INBOX",
                "Archive",
                message_id="20",
                expunge=True,
            )

        self.assertEqual(result["status"], "moved")
        self.assertTrue(result["expunged"])
        self.assertEqual(client.copy_calls, [("20", "Archive")])
        self.assertEqual(client.store_calls, [("20", "+FLAGS", r"(\Deleted)")])
        self.assertEqual(client.expunge_calls, 1)
