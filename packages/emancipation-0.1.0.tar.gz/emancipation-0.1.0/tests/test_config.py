from __future__ import annotations

import os
import unittest
from unittest.mock import patch

from emancipation.config import load_config, load_smtp_config


class LoadConfigTest(unittest.TestCase):
    def test_load_config_reads_expected_values(self) -> None:
        env = {
            "IMAP_HOST": "imap.example.com",
            "IMAP_USERNAME": "agent",
            "IMAP_PASSWORD": "secret",
            "IMAP_PORT": "1993",
            "IMAP_MAILBOX": "Inbox/Work",
            "IMAP_TIMEOUT": "12.5",
        }

        with patch.dict(os.environ, env, clear=True):
            config = load_config()

        self.assertEqual(config.host, "imap.example.com")
        self.assertEqual(config.username, "agent")
        self.assertEqual(config.password, "secret")
        self.assertEqual(config.port, 1993)
        self.assertEqual(config.mailbox, "Inbox/Work")
        self.assertEqual(config.timeout, 12.5)
        self.assertEqual(config.session_ttl, 120.0)

    def test_load_config_defaults_timeout_to_none(self) -> None:
        env = {
            "IMAP_HOST": "imap.example.com",
            "IMAP_USERNAME": "agent",
            "IMAP_PASSWORD": "secret",
        }

        with patch.dict(os.environ, env, clear=True):
            config = load_config()

        self.assertIsNone(config.timeout)
        self.assertEqual(config.session_ttl, 120.0)

    def test_load_config_reads_imap_session_ttl(self) -> None:
        env = {
            "IMAP_HOST": "imap.example.com",
            "IMAP_USERNAME": "agent",
            "IMAP_PASSWORD": "secret",
            "IMAP_SESSION_TTL": "30",
        }

        with patch.dict(os.environ, env, clear=True):
            config = load_config()

        self.assertEqual(config.session_ttl, 30.0)

    def test_load_config_allows_zero_imap_session_ttl(self) -> None:
        env = {
            "IMAP_HOST": "imap.example.com",
            "IMAP_USERNAME": "agent",
            "IMAP_PASSWORD": "secret",
            "IMAP_SESSION_TTL": "0",
        }

        with patch.dict(os.environ, env, clear=True):
            config = load_config()

        self.assertEqual(config.session_ttl, 0.0)

    def test_load_config_rejects_negative_imap_session_ttl(self) -> None:
        env = {
            "IMAP_HOST": "imap.example.com",
            "IMAP_USERNAME": "agent",
            "IMAP_PASSWORD": "secret",
            "IMAP_SESSION_TTL": "-1",
        }

        with patch.dict(os.environ, env, clear=True):
            with self.assertRaises(RuntimeError) as context:
                load_config()

        self.assertIn("IMAP_SESSION_TTL", str(context.exception))

    def test_load_config_rejects_invalid_timeout(self) -> None:
        env = {
            "IMAP_HOST": "imap.example.com",
            "IMAP_USERNAME": "agent",
            "IMAP_PASSWORD": "secret",
            "IMAP_TIMEOUT": "0",
        }

        with patch.dict(os.environ, env, clear=True):
            with self.assertRaises(RuntimeError) as context:
                load_config()

        self.assertIn("IMAP_TIMEOUT", str(context.exception))

    def test_load_config_reports_missing_required_values(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(RuntimeError) as context:
                load_config()

        message = str(context.exception)
        self.assertIn("IMAP_HOST", message)
        self.assertIn("IMAP_USERNAME", message)
        self.assertIn("IMAP_PASSWORD", message)


class LoadSmtpConfigTest(unittest.TestCase):
    def test_load_smtp_config_reads_expected_values(self) -> None:
        env = {
            "SMTP_HOST": "smtp.example.com",
            "SMTP_USERNAME": "agent",
            "SMTP_PASSWORD": "secret",
            "SMTP_FROM": "agent@example.com",
            "SMTP_PORT": "2525",
            "SMTP_USE_TLS": "true",
            "SMTP_USE_SSL": "false",
            "SMTP_TIMEOUT": "9",
        }

        with patch.dict(os.environ, env, clear=True):
            config = load_smtp_config()

        self.assertEqual(config.host, "smtp.example.com")
        self.assertEqual(config.username, "agent")
        self.assertEqual(config.password, "secret")
        self.assertEqual(config.from_email, "agent@example.com")
        self.assertEqual(config.port, 2525)
        self.assertTrue(config.use_tls)
        self.assertFalse(config.use_ssl)
        self.assertEqual(config.timeout, 9.0)

    def test_load_smtp_config_defaults_to_tls(self) -> None:
        env = {
            "SMTP_HOST": "smtp.example.com",
            "SMTP_USERNAME": "agent",
            "SMTP_PASSWORD": "secret",
            "SMTP_FROM": "agent@example.com",
        }

        with patch.dict(os.environ, env, clear=True):
            config = load_smtp_config()

        self.assertEqual(config.port, 587)
        self.assertTrue(config.use_tls)
        self.assertFalse(config.use_ssl)
        self.assertIsNone(config.timeout)

    def test_load_smtp_config_rejects_invalid_timeout(self) -> None:
        env = {
            "SMTP_HOST": "smtp.example.com",
            "SMTP_USERNAME": "agent",
            "SMTP_PASSWORD": "secret",
            "SMTP_FROM": "agent@example.com",
            "SMTP_TIMEOUT": "abc",
        }

        with patch.dict(os.environ, env, clear=True):
            with self.assertRaises(RuntimeError) as context:
                load_smtp_config()

        self.assertIn("SMTP_TIMEOUT", str(context.exception))

    def test_load_smtp_config_rejects_tls_and_ssl_together(self) -> None:
        env = {
            "SMTP_HOST": "smtp.example.com",
            "SMTP_USERNAME": "agent",
            "SMTP_PASSWORD": "secret",
            "SMTP_FROM": "agent@example.com",
            "SMTP_USE_TLS": "true",
            "SMTP_USE_SSL": "true",
        }

        with patch.dict(os.environ, env, clear=True):
            with self.assertRaises(RuntimeError):
                load_smtp_config()
