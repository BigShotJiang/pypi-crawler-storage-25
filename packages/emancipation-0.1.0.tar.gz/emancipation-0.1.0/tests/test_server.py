from __future__ import annotations

import unittest
import types
import sys
import importlib
import logging
from unittest.mock import patch

from emancipation.config import ImapConfig, SmtpConfig


class _DummyFastMCP:
    def __init__(self, _name: str) -> None:
        self.name = _name
        self.tools: list[str] = []

    def tool(self, *_args, **_kwargs):
        def decorator(func):
            self.tools.append(func.__name__)
            return func

        return decorator

    def run(self) -> None:
        return None


class ServerToolsTest(unittest.TestCase):
    server_module = None

    @classmethod
    def setUpClass(cls) -> None:
        mcp_module = types.ModuleType("mcp")
        mcp_server = types.ModuleType("mcp.server")
        mcp_fastmcp = types.ModuleType("mcp.server.fastmcp")
        mcp_fastmcp.FastMCP = _DummyFastMCP
        sys.modules["mcp"] = mcp_module
        sys.modules["mcp.server"] = mcp_server
        sys.modules["mcp.server.fastmcp"] = mcp_fastmcp
        cls.server_module = importlib.import_module("emancipation.server")

    def test_server_name_defaults_to_emancipation(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            importlib.reload(self.server_module)

        self.assertEqual(self.server_module.SERVER_NAME, "emancipation")
        self.assertEqual(self.server_module.mcp.name, "emancipation")

    def test_server_name_uses_server_name_when_set(self) -> None:
        with patch.dict(
            "os.environ",
            {"SERVER_NAME": "mail-secondary"},
            clear=True,
        ):
            importlib.reload(self.server_module)

        self.assertEqual(self.server_module.SERVER_NAME, "mail-secondary")
        self.assertEqual(self.server_module.mcp.name, "mail-secondary")

    def test_server_log_level_defaults_to_info(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            importlib.reload(self.server_module)

        self.assertEqual(self.server_module.SERVER_LOG_LEVEL, logging.INFO)

    def test_server_log_level_accepts_valid_value(self) -> None:
        with patch.dict(
            "os.environ",
            {"SERVER_LOG_LEVEL": "DEBUG"},
            clear=True,
        ):
            importlib.reload(self.server_module)

        self.assertEqual(self.server_module.SERVER_LOG_LEVEL, logging.DEBUG)

    def test_rejects_invalid_server_log_level_value(self) -> None:
        with patch.dict(
            "os.environ",
            {"SERVER_LOG_LEVEL": "verbose"},
            clear=True,
        ):
            with self.assertRaises(RuntimeError):
                importlib.reload(self.server_module)

    def test_tools_enabled_by_default(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            importlib.reload(self.server_module)

        self.assertTrue(self.server_module.IMAP_ENABLED)
        self.assertTrue(self.server_module.SMTP_ENABLED)
        self.assertCountEqual(
            self.server_module.mcp.tools,
            [
                "emcp_list_mailboxes",
                "emcp_search_messages",
                "emcp_list_messages",
                "emcp_get_message",
                "emcp_delete_message",
                "emcp_move_message",
                "emcp_send_email",
            ],
        )

    def test_disables_imap_tools_when_imap_enabled_is_false(self) -> None:
        with patch.dict(
            "os.environ",
            {
                "IMAP_ENABLED": "false",
                "SMTP_ENABLED": "true",
            },
            clear=True,
        ):
            importlib.reload(self.server_module)

        self.assertFalse(self.server_module.IMAP_ENABLED)
        self.assertTrue(self.server_module.SMTP_ENABLED)
        self.assertEqual(self.server_module.mcp.tools, ["emcp_send_email"])

    def test_disables_smtp_tools_when_smtp_enabled_is_no(self) -> None:
        with patch.dict(
            "os.environ",
            {
                "IMAP_ENABLED": "true",
                "SMTP_ENABLED": "no",
            },
            clear=True,
        ):
            importlib.reload(self.server_module)

        self.assertTrue(self.server_module.IMAP_ENABLED)
        self.assertFalse(self.server_module.SMTP_ENABLED)
        self.assertCountEqual(
            self.server_module.mcp.tools,
            [
                "emcp_list_mailboxes",
                "emcp_search_messages",
                "emcp_list_messages",
                "emcp_get_message",
                "emcp_delete_message",
                "emcp_move_message",
            ],
        )

    def test_disables_all_mail_tools_when_both_flags_are_zero(self) -> None:
        with patch.dict(
            "os.environ",
            {
                "IMAP_ENABLED": "0",
                "SMTP_ENABLED": "0",
            },
            clear=True,
        ):
            importlib.reload(self.server_module)

        self.assertFalse(self.server_module.IMAP_ENABLED)
        self.assertFalse(self.server_module.SMTP_ENABLED)
        self.assertEqual(self.server_module.mcp.tools, [])

    def test_rejects_invalid_imap_enabled_value(self) -> None:
        with patch.dict(
            "os.environ",
            {
                "IMAP_ENABLED": "maybe",
            },
            clear=True,
        ):
            with self.assertRaises(RuntimeError):
                importlib.reload(self.server_module)

    def test_rejects_invalid_smtp_enabled_value(self) -> None:
        with patch.dict(
            "os.environ",
            {
                "SMTP_ENABLED": "sometimes",
            },
            clear=True,
        ):
            with self.assertRaises(RuntimeError):
                importlib.reload(self.server_module)

    def test_emcp_search_messages_uses_default_mailbox(self) -> None:
        imap_config = ImapConfig(
            host="imap.example.com",
            username="agent",
            password="secret",
            mailbox="INBOX-DEFAULT",
        )

        with patch(
            "emancipation.server.load_config",
            return_value=imap_config,
        ):
            with patch(
                "emancipation.server.imap_search_messages"
            ) as search_mock:
                search_mock.return_value = ["1"]
                result = self.server_module.emcp_search_messages(
                    query="ALL",
                    limit=10,
                    offset=0,
                )

        self.assertEqual(result, ["1"])
        search_mock.assert_called_once_with(
            imap_config,
            "INBOX-DEFAULT",
            "ALL",
            10,
            0,
        )

    def test_emcp_send_email_uses_loaded_smtp_config(self) -> None:
        smtp_config = SmtpConfig(
            host="smtp.example.com",
            username="agent",
            password="secret",
            from_email="agent@example.com",
        )

        with patch(
            "emancipation.server.load_smtp_config",
            return_value=smtp_config,
        ):
            with patch("emancipation.server.smtp_send_email") as send_mock:
                send_mock.return_value = {
                    "status": "sent",
                    "message_id": "<id@example.com>",
                    "accepted_recipients_count": 1,
                }
                result = self.server_module.emcp_send_email(
                    to=["to@example.com"],
                    subject="Hello",
                    text_body="Body",
                )

        self.assertEqual(result["status"], "sent")
        send_mock.assert_called_once_with(
            smtp_config,
            ["to@example.com"],
            "Hello",
            "Body",
            None,
            None,
            None,
        )

    def test_emcp_delete_message_uses_default_mailbox(self) -> None:
        imap_config = ImapConfig(
            host="imap.example.com",
            username="agent",
            password="secret",
            mailbox="INBOX-DEFAULT",
        )

        with patch(
            "emancipation.server.load_config",
            return_value=imap_config,
        ):
            with patch(
                "emancipation.server.imap_delete_message"
            ) as delete_mock:
                delete_mock.return_value = {
                    "status": "deleted",
                    "message_id": "42",
                    "mailbox": "INBOX-DEFAULT",
                    "expunged": False,
                }
                result = self.server_module.emcp_delete_message(
                    message_id="42"
                )

        self.assertEqual(result["status"], "deleted")
        delete_mock.assert_called_once_with(
            imap_config,
            "INBOX-DEFAULT",
            "42",
            False,
        )

    def test_emcp_move_message_uses_default_source_mailbox(self) -> None:
        imap_config = ImapConfig(
            host="imap.example.com",
            username="agent",
            password="secret",
            mailbox="INBOX-DEFAULT",
        )

        with patch(
            "emancipation.server.load_config",
            return_value=imap_config,
        ):
            with patch("emancipation.server.imap_move_message") as move_mock:
                move_mock.return_value = {
                    "status": "moved",
                    "message_id": "57",
                    "source_mailbox": "INBOX-DEFAULT",
                    "destination_mailbox": "Archive",
                    "expunged": True,
                }
                result = self.server_module.emcp_move_message(
                    message_id="57",
                    destination_mailbox="Archive",
                )

        self.assertEqual(result["status"], "moved")
        move_mock.assert_called_once_with(
            imap_config,
            "INBOX-DEFAULT",
            "Archive",
            "57",
            True,
        )

    def test_main_defaults_to_stdio_transport(self) -> None:
        with patch.object(self.server_module.mcp, "run") as run_mock:
            self.server_module.main([])

        run_mock.assert_called_once_with(transport="stdio")

    def test_main_runs_sse_with_host_and_port(self) -> None:
        with patch.object(self.server_module.mcp, "run") as run_mock:
            self.server_module.main(
                ["sse", "--host", "127.0.0.1", "--port", "8143"]
            )

        run_mock.assert_called_once_with(
            transport="sse",
            host="127.0.0.1",
            port=8143,
        )

    def test_main_runs_streamable_http_with_host_and_port(self) -> None:
        with patch.object(self.server_module.mcp, "run") as run_mock:
            self.server_module.main(
                [
                    "streamable-http",
                    "--host",
                    "127.0.0.1",
                    "--port",
                    "8143",
                ]
            )

        run_mock.assert_called_once_with(
            transport="streamable-http",
            host="127.0.0.1",
            port=8143,
        )

    def test_main_rejects_invalid_transport(self) -> None:
        with self.assertRaises(SystemExit):
            self.server_module.main(["invalid-transport"])
