"""
Unit tests for gitspectre.config module.
"""

import json
import pytest
from unittest.mock import patch, MagicMock

from gitspectre.config import (
    ensure_config_dir, get_config, set_config, unset_config,
    get_api_key, get_git_config, set_git_config
)


class TestConfigDir:
    """Test configuration directory management."""

    def test_ensure_config_dir(self, tmp_path, monkeypatch):
        """Test ensuring config directory exists."""
        config_dir = tmp_path / ".gitspectre"
        monkeypatch.setattr("gitspectre.config.CONFIG_DIR", config_dir)

        ensure_config_dir()
        assert config_dir.exists()
        assert config_dir.is_dir()


class TestConfigOperations:
    """Test configuration file operations."""

    def test_get_config_empty(self, tmp_path, monkeypatch):
        """Test getting config when file doesn't exist."""
        config_file = tmp_path / "config.json"
        monkeypatch.setattr("gitspectre.config.CONFIG_FILE", config_file)

        config = get_config()
        assert config == {}
        assert config_file.exists()

    def test_get_config_existing(self, tmp_path, monkeypatch, sample_config):
        """Test getting existing config."""
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(sample_config))
        monkeypatch.setattr("gitspectre.config.CONFIG_FILE", config_file)

        config = get_config()
        assert config == sample_config

    def test_set_config(self, tmp_path, monkeypatch):
        """Test setting configuration values."""
        config_file = tmp_path / "config.json"
        monkeypatch.setattr("gitspectre.config.CONFIG_FILE", config_file)

        set_config("test_key", "test_value")
        config = get_config()
        assert config["test_key"] == "test_value"

    def test_unset_config_existing(self, tmp_path, monkeypatch):
        """Test unsetting existing config key."""
        config_file = tmp_path / "config.json"
        initial_config = {"key1": "value1", "key2": "value2"}
        config_file.write_text(json.dumps(initial_config))
        monkeypatch.setattr("gitspectre.config.CONFIG_FILE", config_file)

        unset_config("key1")
        config = get_config()
        assert "key1" not in config
        assert config["key2"] == "value2"

    def test_unset_config_nonexistent(self, tmp_path, monkeypatch):
        """Test unsetting nonexistent config key."""
        config_file = tmp_path / "config.json"
        config_file.write_text('{"existing": "value"}')
        monkeypatch.setattr("gitspectre.config.CONFIG_FILE", config_file)

        with pytest.raises(ValueError, match="Key 'nonexistent' not found"):
            unset_config("nonexistent")


class TestApiKey:
    """Test API key retrieval."""

    def test_get_api_key_from_config(self, tmp_path, monkeypatch):
        """Test getting API key from config file."""
        config_file = tmp_path / "config.json"
        config_file.write_text('{"api_key": "config-key"}')
        monkeypatch.setattr("gitspectre.config.CONFIG_FILE", config_file)

        key = get_api_key()
        assert key == "config-key"

    def test_get_api_key_none(self, tmp_path, monkeypatch):
        """Test getting API key when none exists."""
        config_file = tmp_path / "config.json"
        config_file.write_text('{}')
        monkeypatch.setattr("gitspectre.config.CONFIG_FILE", config_file)

        key = get_api_key()
        assert key is None


class TestGitConfig:
    """Test Git configuration operations."""

    @patch('subprocess.run')
    def test_get_git_config_success(self, mock_run):
        """Test getting Git config successfully."""
        mock_process = MagicMock()
        mock_process.stdout = "test-value\n"
        mock_process.returncode = 0
        mock_run.return_value = mock_process

        result = get_git_config("user.name")
        assert result == "test-value"
        mock_run.assert_called_once_with(
            ['git', 'config', '--get', 'user.name'],
            capture_output=True, text=True, check=True, shell=False
        )

    @patch('subprocess.run')
    def test_get_git_config_not_found(self, mock_run):
        """Test getting Git config when key doesn't exist."""
        from subprocess import CalledProcessError
        mock_run.side_effect = CalledProcessError(1, 'git')

        result = get_git_config("nonexistent.key")
        assert result is None

    @patch('subprocess.run')
    def test_set_git_config(self, mock_run):
        """Test setting Git config."""
        mock_process = MagicMock()
        mock_process.returncode = 0
        mock_run.return_value = mock_process

        set_git_config("user.name", "Test User")

        mock_run.assert_called_once_with(
            ['git', 'config', 'user.name', 'Test User'],
            check=True, shell=False
        )

    @patch('subprocess.run')
    def test_set_git_config_error(self, mock_run):
        """Test setting Git config with error."""
        from subprocess import CalledProcessError
        mock_run.side_effect = CalledProcessError(1, 'git')

        with pytest.raises(CalledProcessError):
            set_git_config("invalid.key", "value")