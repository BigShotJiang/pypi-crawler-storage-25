"""
Integration tests for gitspectre.agent module.
"""

import pytest
from unittest.mock import patch, MagicMock

from gitspectre.agent import GitSpectreAgent, run_agent


class TestGitSpectreAgent:
    """Test GitSpectreAgent class."""

    def test_agent_init_no_api_key(self):
        """Test agent initialization without API key."""
        with patch('gitspectre.agent.get_api_key', return_value=None):
            with pytest.raises(ValueError, match="No OpenRouter API key found"):
                GitSpectreAgent()

    def test_agent_init_with_api_key(self, mock_api_key):
        """Test agent initialization with API key."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()
            assert agent.api_key == mock_api_key
            assert agent.repo_context == ""

    def test_agent_init_with_repo_context(self, mock_api_key):
        """Test agent initialization with repository context."""
        repo_context = "Current branch: main"
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent(repo_context)
            assert agent.repo_context == repo_context

    @patch('importlib.resources.files')
    def test_load_prompt(self, mock_files, mock_api_key):
        """Test loading system prompt."""
        mock_prompt_file = MagicMock()
        mock_prompt_file.open.return_value.__enter__.return_value.read.return_value = '{"system_prompt": "Test prompt: {repo_context}"}'
        mock_files.return_value.joinpath.return_value = mock_prompt_file

        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent("test context")
            expected_prompt = "Test prompt: test context"
            assert agent.system_prompt == expected_prompt

    @patch('importlib.resources.files')
    def test_load_prompt_fallback(self, mock_files, mock_api_key):
        """Test loading prompt with fallback on error."""
        mock_files.side_effect = Exception("File not found")

        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()
            assert "GitSpectre, an AI assistant" in agent.system_prompt


class TestAgentAPIInteraction:
    """Test agent API interaction methods."""

    @pytest.mark.asyncio
    async def test_call_openrouter_success(self, mock_api_key, mock_openrouter_response):
        """Test successful OpenRouter API call."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            # Mock the response object
            mock_response = MagicMock()
            mock_response.json.return_value = mock_openrouter_response
            mock_response.raise_for_status.return_value = None

            with patch('gitspectre.agent.run_async') as mock_run_async:
                mock_run_async.return_value = mock_response

                messages = [{"role": "user", "content": "test"}]
                result = await agent._call_openrouter(messages)

                assert result == mock_openrouter_response
                mock_run_async.assert_called_once()

    @pytest.mark.asyncio
    async def test_call_openrouter_error(self, mock_api_key):
        """Test OpenRouter API call with error."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            with patch('gitspectre.agent.run_async') as mock_run_async:
                mock_run_async.side_effect = Exception("API Error")

                messages = [{"role": "user", "content": "test"}]
                with pytest.raises(Exception, match="API Error"):
                    await agent._call_openrouter(messages)


class TestToolExecution:
    """Test tool execution functionality."""

    def test_execute_tool_git_tool(self, mock_api_key):
        """Test executing a Git tool."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            tool_call = {
                "function": {
                    "name": "get_repo_status",
                    "arguments": "{}"
                },
                "id": "test-id"
            }

            with patch('gitspectre.tools.git_tools.get_repo_status') as mock_tool:
                mock_tool.return_value = {"success": "Status retrieved"}

                result = agent._execute_tool(tool_call)
                assert result == {"success": "Status retrieved"}
                mock_tool.assert_called_once_with()

    def test_execute_tool_file_tool(self, mock_api_key):
        """Test executing a file tool."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            tool_call = {
                "function": {
                    "name": "read_file",
                    "arguments": '{"file_path": "test.txt"}'
                },
                "id": "test-id"
            }

            with patch('gitspectre.tools.file_tools.read_file') as mock_tool:
                mock_tool.return_value = "File content"

                result = agent._execute_tool(tool_call)
                assert result == "File content"
                mock_tool.assert_called_once_with(file_path="test.txt")

    def test_execute_tool_utility_tool(self, mock_api_key):
        """Test executing a utility tool."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            tool_call = {
                "function": {
                    "name": "ask_user",
                    "arguments": '{"question": "What now?"}'
                },
                "id": "test-id"
            }

            with patch('gitspectre.tools.utility_tools.ask_user') as mock_tool:
                mock_tool.return_value = {"user_input_needed": "What now?"}

                result = agent._execute_tool(tool_call)
                assert result == {"user_input_needed": "What now?"}
                mock_tool.assert_called_once_with(question="What now?")

    def test_execute_tool_not_found(self, mock_api_key):
        """Test executing non-existent tool."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            tool_call = {
                "function": {
                    "name": "nonexistent_tool",
                    "arguments": "{}"
                },
                "id": "test-id"
            }

            result = agent._execute_tool(tool_call)
            assert result == {"error": "Tool nonexistent_tool not found"}

    def test_execute_tool_error(self, mock_api_key):
        """Test tool execution with error."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            tool_call = {
                "function": {
                    "name": "get_repo_status",
                    "arguments": "{}"
                },
                "id": "test-id"
            }

            with patch('gitspectre.tools.git_tools.get_repo_status') as mock_tool:
                mock_tool.side_effect = Exception("Tool execution failed")

                result = agent._execute_tool(tool_call)
                assert "error" in result
                assert "Tool execution failed" in result["error"]

    def test_execute_tool_respects_working_directory_and_records_calls(self, mock_api_key, tmp_path):
        """Test that tool execution uses the configured working directory and records the tool call."""
        from git import Repo

        repo_path = tmp_path / "repo"
        repo_path.mkdir()
        repo = Repo.init(repo_path)
        (repo_path / "test.txt").write_text("hello")
        repo.index.add(["test.txt"])
        repo.index.commit("Initial commit")

        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent(working_directory=str(repo_path))

            tool_call = {
                "function": {
                    "name": "read_file",
                    "arguments": "{\"file_path\": \"test.txt\"}"
                },
                "id": "test-id"
            }

            result = agent._execute_tool(tool_call)

            assert isinstance(result, str)
            assert result.startswith("File: test.txt")
            assert agent.tool_calls == [{
                "name": "read_file",
                "arguments": {"file_path": "test.txt"}
            }]


class TestProcessResponse:
    """Test response processing."""

    @pytest.mark.asyncio
    async def test_process_response_final_answer(self, mock_api_key):
        """Test processing final answer response."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            response = {
                "choices": [{
                    "message": {
                        "content": "This is the final answer",
                        "tool_calls": None
                    }
                }]
            }

            with patch('click.echo') as mock_echo:
                result = await agent._process_response(response)

                assert result == "This is the final answer"
                mock_echo.assert_called_once()

    @pytest.mark.asyncio
    async def test_process_response_final_answer_with_formatting(self, mock_api_key):
        """Test processing final answer with markdown formatting."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            response = {
                "choices": [{
                    "message": {
                        "content": "**bold text** and ### header and `code`",
                        "tool_calls": None
                    }
                }]
            }

            with patch('click.echo') as mock_echo:
                result = await agent._process_response(response)

                # The result should contain the formatted content (without markdown)
                assert isinstance(result, str)
                assert "bold text" in result
                assert "header" in result
                assert "code" in result
                # Check that echo was called with formatted output
                assert mock_echo.call_count == 1  # One call for the final formatted content

    @pytest.mark.asyncio
    async def test_process_response_empty_content(self, mock_api_key):
        """Test processing response with empty content."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            response = {
                "choices": [{
                    "message": {
                        "content": "",
                        "tool_calls": None
                    }
                }]
            }

            with patch('builtins.print') as mock_print:
                result = await agent._process_response(response)

                assert result == "No response"
                mock_print.assert_called_once()

    @pytest.mark.asyncio
    async def test_process_response_tool_calls(self, mock_api_key):
        """Test processing response with tool calls."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            response = {
                "choices": [{
                    "message": {
                        "content": None,
                        "tool_calls": [{
                            "function": {
                                "name": "get_repo_status",
                                "arguments": "{}"
                            },
                            "id": "call-1"
                        }]
                    }
                }]
            }

            with patch.object(agent, '_execute_tool') as mock_execute:
                mock_execute.return_value = {"success": "Status retrieved"}

                result = await agent._process_response(response)

                assert result is None  # Continue processing
                mock_execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_process_response_tool_calls_verbose(self, mock_api_key):
        """Test processing response with tool calls in verbose mode."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            response = {
                "choices": [{
                    "message": {
                        "content": None,
                        "tool_calls": [{
                            "function": {"name": "get_repo_status", "arguments": "{}"},
                            "id": "call-1"
                        }]
                    }
                }]
            }

            with patch.object(agent, '_execute_tool') as mock_execute:
                mock_execute.return_value = {"success": "Status retrieved"}
                with patch('builtins.print') as mock_print:
                    result = await agent._process_response(response, verbose=True)

                    assert result is None  # Continue processing
                    mock_execute.assert_called_once()
                    # Verify verbose output was printed
                    mock_print.assert_called()

    @pytest.mark.asyncio
    async def test_process_response_ask_user_tool(self, mock_api_key):
        """Test processing response with ask_user tool."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            response = {
                "choices": [{
                    "message": {
                        "content": None,
                        "tool_calls": [{
                            "function": {
                                "name": "ask_user",
                                "arguments": '{"question": "What branch?"}'
                            },
                            "id": "call-1"
                        }]
                    }
                }]
            }

            with patch.object(agent, '_execute_tool') as mock_execute:
                mock_execute.return_value = {"user_input_needed": "What branch?"}

                result = await agent._process_response(response)

                assert result == ("USER_INPUT_NEEDED", "What branch?")
                assert agent.last_ask_user_tool_call == response["choices"][0]["message"]["tool_calls"][0]


class TestConversationFlow:
    """Test conversation flow methods."""

    @pytest.mark.asyncio
    async def test_run_conversation_success(self, mock_api_key, mock_openrouter_response):
        """Test successful conversation run."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            # Mock final answer response
            final_response = {
                "choices": [{
                    "message": {
                        "content": "Command completed successfully",
                        "tool_calls": None
                    }
                }]
            }

            with patch.object(agent, '_call_openrouter') as mock_call:
                mock_call.return_value = final_response

                with patch('gitspectre.agent.yaspin') as mock_spinner:
                    mock_spinner_instance = MagicMock()
                    mock_spinner.return_value = mock_spinner_instance

                    result = await agent.run_conversation("test command")

                    assert result == "Command completed successfully"
                    mock_spinner_instance.start.assert_called_once()
                    # stop() is called twice: once in _process_response and once in run_conversation
                    assert mock_spinner_instance.stop.call_count == 2

    @pytest.mark.asyncio
    async def test_run_conversation_with_tools(self, mock_api_key):
        """Test conversation with tool calls."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            # First response with tool call
            tool_response = {
                "choices": [{
                    "message": {
                        "content": None,
                        "tool_calls": [{
                            "function": {"name": "get_repo_status", "arguments": "{}"},
                            "id": "call-1"
                        }]
                    }
                }]
            }

            # Second response with final answer
            final_response = {
                "choices": [{
                    "message": {
                        "content": "Status retrieved successfully",
                        "tool_calls": None
                    }
                }]
            }

            with patch.object(agent, '_call_openrouter') as mock_call:
                mock_call.side_effect = [tool_response, final_response]

                with patch.object(agent, '_execute_tool') as mock_execute:
                    mock_execute.return_value = {"success": "Status retrieved"}

                    with patch('gitspectre.agent.yaspin'):
                        result = await agent.run_conversation("show status")

                        assert result == "Status retrieved successfully"

    @pytest.mark.asyncio
    async def test_run_conversation_max_iterations(self, mock_api_key):
        """Test conversation hitting max iterations."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            # Response that keeps returning tool calls
            tool_response = {
                "choices": [{
                    "message": {
                        "content": None,
                        "tool_calls": [{
                            "function": {"name": "get_repo_status", "arguments": "{}"},
                            "id": "call-1"
                        }]
                    }
                }]
            }

            with patch.object(agent, '_call_openrouter') as mock_call:
                mock_call.return_value = tool_response

                with patch.object(agent, '_execute_tool') as mock_execute:
                    mock_execute.return_value = {"success": "Continuing"}

                    with patch('gitspectre.agent.yaspin') as mock_spinner:
                        mock_spinner_instance = MagicMock()
                        mock_spinner.return_value = mock_spinner_instance

                        result = await agent.run_conversation("test")

                        assert result == "Conversation timed out"
                        mock_spinner_instance.fail.assert_called_once()
    
        @pytest.mark.asyncio
        async def test_run_conversation_verbose_mode(self, mock_api_key):
            """Test conversation in verbose mode."""
            with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
                agent = GitSpectreAgent()
    
                # First response with tool call
                tool_response = {
                    "choices": [{
                        "message": {
                            "content": None,
                            "tool_calls": [{
                                "function": {"name": "get_repo_status", "arguments": "{}"},
                                "id": "call-1"
                            }]
                        }
                    }]
                }
    
                # Second response with final answer
                final_response = {
                    "choices": [{
                        "message": {
                            "content": "Status retrieved successfully",
                            "tool_calls": None
                        }
                    }]
                }
    
                with patch.object(agent, '_call_openrouter') as mock_call:
                    mock_call.side_effect = [tool_response, final_response]
    
                    with patch.object(agent, '_execute_tool') as mock_execute:
                        mock_execute.return_value = {"success": "Status retrieved"}
    
                        with patch('gitspectre.agent.yaspin') as mock_spinner:
                            mock_spinner_instance = MagicMock()
                            mock_spinner.return_value = mock_spinner_instance
                            
                            with patch('builtins.print') as mock_print:
                                result = await agent.run_conversation("show status", verbose=True)
    
                                assert result == "Status retrieved successfully"
                                # Verify verbose output was printed during tool execution
                                mock_print.assert_called()
    
        @pytest.mark.asyncio
        async def test_continue_conversation(self, mock_api_key):
            """Test continuing conversation after user input."""
            with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
                agent = GitSpectreAgent()

                # Set up pending ask_user tool call
                agent.last_ask_user_tool_call = {
                    "id": "call-1",
                    "function": {"name": "ask_user"}
                }

                final_response = {
                    "choices": [{
                        "message": {
                            "content": "Branch switched successfully",
                            "tool_calls": None
                        }
                    }]
                }

                with patch.object(agent, '_call_openrouter') as mock_call:
                    mock_call.return_value = final_response

                    with patch('gitspectre.agent.yaspin'):
                        result = await agent.continue_conversation("develop")

                        assert result == "Branch switched successfully"
                        assert agent.last_ask_user_tool_call is None

    @pytest.mark.asyncio
    async def test_continue_conversation_no_pending_tool(self, mock_api_key):
        """Test continuing conversation without pending tool call."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            agent = GitSpectreAgent()

            # No pending tool call
            agent.last_ask_user_tool_call = None

            final_response = {
                "choices": [{
                    "message": {
                        "content": "Response received",
                        "tool_calls": None
                    }
                }]
            }

            with patch.object(agent, '_call_openrouter') as mock_call:
                mock_call.return_value = final_response

                with patch('gitspectre.agent.yaspin'):
                    result = await agent.continue_conversation("user response")

                    assert result == "Response received"
                    # Conversation history should have the user response and then assistant
                    assert len(agent.conversation_history) >= 2
                    # Last should be assistant, second-to-last should be user
                    assert agent.conversation_history[-1]["role"] == "assistant"
                    assert agent.conversation_history[-2]["role"] == "user"
                    assert agent.conversation_history[-2]["content"] == "user response"


class TestRunAgentFunction:
    """Test the run_agent convenience function."""

    @pytest.mark.asyncio
    async def test_run_agent_success(self, mock_api_key):
        """Test successful run_agent execution."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            with patch('gitspectre.agent.GitSpectreAgent') as mock_agent_class:
                mock_agent = MagicMock()
                # Make run_conversation return a coroutine that resolves to "Success"
                async def mock_run_conversation(*args, **kwargs):
                    return "Success"
                mock_agent.run_conversation = mock_run_conversation
                mock_agent_class.return_value = mock_agent

                result = await run_agent("test command")

                assert result == "Success"
                mock_agent_class.assert_called_once_with("")

    @pytest.mark.asyncio
    async def test_run_agent_error(self, mock_api_key):
        """Test run_agent with error."""
        with patch('gitspectre.agent.get_api_key', return_value=mock_api_key):
            with patch('gitspectre.agent.GitSpectreAgent') as mock_agent_class:
                mock_agent_class.side_effect = Exception("Agent initialization failed")

                result = await run_agent("test command")

                assert "An error occurred" in result
                assert "Agent initialization failed" in result