"""
Unit tests for gitspectre.utils module.
"""

import pytest
from unittest.mock import patch
from pathlib import Path

from gitspectre.utils import (
    setup_logging, validate_repo_path, sanitize_command,
    format_output, run_async, handle_error, logger
)


class TestSetupLogging:
    """Test logging setup functionality."""

    def test_setup_logging_verbose(self):
        """Test setting up logging with verbose mode."""
        setup_logging(verbose=True)
        assert logger.level == 20  # INFO level

    def test_setup_logging_non_verbose(self):
        """Test setting up logging without verbose mode."""
        setup_logging(verbose=False)
        assert logger.level == 40  # ERROR level


class TestValidateRepoPath:
    """Test repository path validation."""

    @patch('git.Repo')
    def test_validate_repo_path_valid(self, mock_repo_class, git_repo):
        """Test validating a valid repository path."""
        # Mock repo to return our git_repo
        mock_repo_class.return_value = git_repo

        # Create a file in repo
        test_file = Path(git_repo.working_dir) / "test.txt"
        test_file.write_text("test")

        result = validate_repo_path("test.txt")
        assert result is True

    @patch('git.Repo')
    def test_validate_repo_path_invalid(self, mock_repo_class):
        """Test validating an invalid repository path."""
        mock_repo_class.side_effect = Exception("Not a git repo")

        result = validate_repo_path("../outside.txt")
        assert result is False

    @patch('git.Repo')
    def test_validate_repo_path_outside_repo(self, mock_repo_class, git_repo):
        """Test path outside repository."""
        mock_repo_class.return_value = git_repo

        # Path outside repo
        outside_path = Path(git_repo.working_dir).parent / "outside.txt"
        result = validate_repo_path(str(outside_path))
        assert result is False

    @patch('git.Repo')
    def test_validate_repo_path_exception_handling(self, mock_repo_class):
        """Test that any exception in validate_repo_path returns False."""
        # Mock Repo to raise different types of exceptions
        mock_repo_class.side_effect = ValueError("Invalid repo")
        result = validate_repo_path("test.txt")
        assert result is False

        mock_repo_class.side_effect = RuntimeError("Runtime error")
        result = validate_repo_path("test.txt")
        assert result is False

        mock_repo_class.side_effect = AttributeError("Missing attribute")
        result = validate_repo_path("test.txt")
        assert result is False


class TestSanitizeCommand:
    """Test command sanitization."""

    def test_sanitize_command_safe(self):
        """Test sanitizing a safe command."""
        cmd = "git status"
        result = sanitize_command(cmd)
        assert result == cmd

    def test_sanitize_command_dangerous_rm(self):
        """Test sanitizing dangerous rm command."""
        with pytest.raises(ValueError, match="Dangerous command detected"):
            sanitize_command("rm -rf /")

    def test_sanitize_command_dangerous_sudo(self):
        """Test sanitizing dangerous sudo command."""
        with pytest.raises(ValueError, match="Dangerous command detected"):
            sanitize_command("sudo rm -rf /")

    def test_sanitize_command_dangerous_chmod(self):
        """Test sanitizing dangerous chmod command."""
        with pytest.raises(ValueError, match="Dangerous command detected"):
            sanitize_command("chmod 777 file.txt")

    def test_sanitize_command_dangerous_format(self):
        """Test sanitizing dangerous format command."""
        with pytest.raises(ValueError, match="Dangerous command detected"):
            sanitize_command("format c:")

    def test_sanitize_command_dangerous_fdisk(self):
        """Test sanitizing dangerous fdisk command."""
        with pytest.raises(ValueError, match="Dangerous command detected"):
            sanitize_command("fdisk -l")


class TestFormatOutput:
    """Test output formatting."""

    def test_format_output_red(self):
        """Test red color formatting."""
        result = format_output("test", "red")
        assert "test" in result
        assert "\x1b[31m" in result  # Red ANSI code

    def test_format_output_green(self):
        """Test green color formatting."""
        result = format_output("test", "green")
        assert "test" in result
        assert "\x1b[32m" in result  # Green ANSI code

    def test_format_output_bold(self):
        """Test bold formatting."""
        result = format_output("test", bold=True)
        assert "test" in result
        assert "\x1b[1m" in result  # Bold ANSI code

    def test_format_output_unknown_color(self):
        """Test unknown color defaults to white."""
        result = format_output("test", "unknown")
        assert "test" in result
        assert "\x1b[37m" in result  # White ANSI code

    def test_format_output_blue(self):
        """Test blue color formatting."""
        result = format_output("test", "blue")
        assert "test" in result
        assert "\x1b[34m" in result  # Blue ANSI code

    def test_format_output_yellow(self):
        """Test yellow color formatting."""
        result = format_output("test", "yellow")
        assert "test" in result
        assert "\x1b[33m" in result  # Yellow ANSI code

    def test_format_output_cyan(self):
        """Test cyan color formatting."""
        result = format_output("test", "cyan")
        assert "test" in result
        assert "\x1b[36m" in result  # Cyan ANSI code


class TestRunAsync:
    """Test async function execution."""

    @pytest.mark.asyncio
    async def test_run_async_success(self):
        """Test successful async execution."""
        def sync_func(x, y=10):
            return x + y

        result = await run_async(sync_func, 5, y=15)
        assert result == 20

    @pytest.mark.asyncio
    async def test_run_async_exception(self):
        """Test async execution with exception."""
        def failing_func():
            raise ValueError("Test error")

        with pytest.raises(ValueError, match="Test error"):
            await run_async(failing_func)


class TestHandleError:
    """Test error handling."""

    @patch('gitspectre.utils.logger')
    def test_handle_error_with_context(self, mock_logger):
        """Test error handling with context."""
        error = ValueError("Test error")
        result = handle_error(error, "test_context")

        assert "An error occurred" in result
        assert "Test error" in result
        mock_logger.error.assert_called_once()

    @patch('gitspectre.utils.logger')
    def test_handle_error_without_context(self, mock_logger):
        """Test error handling without context."""
        error = RuntimeError("Runtime error")
        result = handle_error(error)

        assert "An error occurred" in result
        assert "Runtime error" in result
        mock_logger.error.assert_called_once()