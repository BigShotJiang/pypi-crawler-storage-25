"""
Unit tests for gitspectre.tools.git_tools module.
"""

from unittest.mock import patch, MagicMock

from gitspectre.tools.git_tools import (
    get_repo, get_repo_context, get_repo_status, get_branches,
    switch_branch, create_branch, delete_branch, add_files, create_commit,
    get_commit_history, merge_branch, detect_conflicts,
    resolve_conflicts, push_changes, pull_changes,
    stash_changes, apply_stash, get_diff, create_tag,
    reset_files, abort_merge, init_repo, clone_repo, reset_to_remote
)


class TestGetRepo:
    """Test repository detection."""

    @patch('gitspectre.tools.git_tools.Repo')
    def test_get_repo_success(self, mock_repo_class):
        """Test getting repo successfully."""
        mock_repo = MagicMock()
        mock_repo_class.return_value = mock_repo

        result = get_repo()
        assert result == mock_repo

    @patch('gitspectre.tools.git_tools.Repo')
    def test_get_repo_failure(self, mock_repo_class):
        """Test getting repo when not in git directory."""
        mock_repo_class.side_effect = Exception("Not a git repo")

        result = get_repo()
        assert result is None


class TestGetRepoContext:
    """Test repository context retrieval."""

    def test_get_repo_context_no_repo(self):
        """Test getting context when not in repo."""
        result = get_repo_context(None)
        assert result == "Not in a Git repository."

    @patch('gitspectre.tools.git_tools.Repo')
    def test_get_repo_context_with_repo(self, mock_repo_class):
        """Test getting context with valid repo."""
        mock_repo = MagicMock()
        mock_repo.active_branch.name = "main"
        mock_repo.git.status.return_value = "On branch main\nnothing to commit"
        mock_repo.git.log.return_value = "commit1\ncommit2"
        mock_repo.git.branch.return_value = "* main\n  develop"

        result = get_repo_context(mock_repo)
        assert "Current branch: main" in result
        assert "Status:" in result
        assert "Recent commits:" in result
        assert "Branches:" in result


class TestGetRepoStatus:
    """Test repository status retrieval."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_get_repo_status_no_repo(self, mock_get_repo):
        """Test getting status when not in repo."""
        mock_get_repo.return_value = None

        result = get_repo_status()
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_get_repo_status_success(self, mock_get_repo):
        """Test getting status successfully."""
        mock_repo = MagicMock()
        mock_repo.is_dirty.return_value = False
        mock_repo.active_branch.name = "main"
        mock_repo.git.status.return_value = "M file1.txt\n?? file2.txt\nA file3.txt"
        mock_get_repo.return_value = mock_repo

        result = get_repo_status()
        assert result["staged"] == ["file1.txt", "file3.txt"]
        assert result["unstaged"] == []
        assert result["untracked"] == ["file2.txt"]
        assert result["is_dirty"] is False
        assert result["active_branch"] == "main"


class TestGetBranches:
    """Test branch retrieval."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_get_branches_no_repo(self, mock_get_repo):
        """Test getting branches when not in repo."""
        mock_get_repo.return_value = None

        result = get_branches()
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_get_branches_success(self, mock_get_repo):
        """Test getting branches successfully."""
        mock_repo = MagicMock()
        mock_repo.branches = [MagicMock(), MagicMock()]
        mock_repo.branches[0].__str__ = lambda self: "main"
        mock_repo.branches[1].__str__ = lambda self: "develop"
        mock_repo.active_branch.name = "main"

        mock_remote = MagicMock()
        mock_remote.refs = [MagicMock(), MagicMock()]
        mock_remote.refs[0].__str__ = lambda self: "origin/main"
        mock_remote.refs[1].__str__ = lambda self: "origin/develop"
        mock_repo.remote.return_value = mock_remote

        mock_get_repo.return_value = mock_repo

        result = get_branches()
        assert result["local"] == ["main", "develop"]
        assert result["remote"] == ["origin/main", "origin/develop"]
        assert result["active"] == "main"


class TestSwitchBranch:
    """Test branch switching."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_switch_branch_no_repo(self, mock_get_repo):
        """Test switching branch when not in repo."""
        mock_get_repo.return_value = None

        result = switch_branch("develop")
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_switch_branch_success(self, mock_get_repo):
        """Test switching branch successfully."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo

        result = switch_branch("develop")
        assert result["success"] == "Switched to branch develop"
        mock_repo.git.checkout.assert_called_once_with("develop")


class TestCreateBranch:
    """Test branch creation."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_create_branch_no_repo(self, mock_get_repo):
        """Test creating branch when not in repo."""
        mock_get_repo.return_value = None

        result = create_branch("feature")
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_create_branch_success(self, mock_get_repo):
        """Test creating branch successfully."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo

        result = create_branch("feature")
        assert result["success"] == "Created branch feature"
        mock_repo.git.branch.assert_called_once_with("feature")


class TestDeleteBranch:
    """Test branch deletion."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_delete_branch_no_repo(self, mock_get_repo):
        """Test deleting branch when not in repo."""
        mock_get_repo.return_value = None

        result = delete_branch("feature")
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_delete_branch_success(self, mock_get_repo):
        """Test deleting branch successfully."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo

        result = delete_branch("feature")
        assert result["success"] == "Deleted branch feature"
        mock_repo.git.branch.assert_called_once_with("-D", "feature")


class TestAddFiles:
    """Test file staging."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_add_files_no_repo(self, mock_get_repo):
        """Test adding files when not in repo."""
        mock_get_repo.return_value = None

        result = add_files(["file1.txt"])
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.validate_repo_path')
    @patch('gitspectre.tools.git_tools.get_repo')
    def test_add_files_invalid_path(self, mock_get_repo, mock_validate):
        """Test adding files with invalid path."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo
        mock_validate.return_value = False

        result = add_files(["../outside.txt"])
        assert result["error"] == "Invalid file path: ../outside.txt"

    @patch('gitspectre.tools.git_tools.validate_repo_path')
    @patch('gitspectre.tools.git_tools.get_repo')
    def test_add_files_success(self, mock_get_repo, mock_validate):
        """Test adding files successfully."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo
        mock_validate.return_value = True

        result = add_files(["file1.txt", "file2.txt"])
        assert result["success"] == "Staged 2 file(s)"
        mock_repo.index.add.assert_called_once_with(["file1.txt", "file2.txt"])


class TestCreateCommit:
    """Test commit creation."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_create_commit_no_repo(self, mock_get_repo):
        """Test creating commit when not in repo."""
        mock_get_repo.return_value = None

        result = create_commit("Test commit")
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.add_files')
    @patch('gitspectre.tools.git_tools.get_repo')
    def test_create_commit_with_files(self, mock_get_repo, mock_add_files):
        """Test creating commit with file staging."""
        mock_repo = MagicMock()
        mock_commit = MagicMock()
        mock_commit.hexsha = "abc123456789"
        mock_repo.index.commit.return_value = mock_commit
        mock_get_repo.return_value = mock_repo
        mock_add_files.return_value = {"success": "Staged files"}

        result = create_commit("Test commit", ["file1.txt"])
        assert result["success"] == "Committed abc12345"
        mock_add_files.assert_called_once_with(["file1.txt"])

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_create_commit_without_files(self, mock_get_repo):
        """Test creating commit without file staging."""
        mock_repo = MagicMock()
        mock_commit = MagicMock()
        mock_commit.hexsha = "abc123456789"
        mock_repo.index.commit.return_value = mock_commit
        mock_get_repo.return_value = mock_repo

        result = create_commit("Test commit")
        assert result["success"] == "Committed abc12345"


class TestGetCommitHistory:
    """Test commit history retrieval."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_get_commit_history_no_repo(self, mock_get_repo):
        """Test getting history when not in repo."""
        mock_get_repo.return_value = None

        result = get_commit_history()
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_get_commit_history_success(self, mock_get_repo):
        """Test getting commit history successfully."""
        mock_repo = MagicMock()
        mock_commit = MagicMock()
        mock_commit.hexsha = "abc123"
        mock_commit.message = "Test commit\n"
        mock_commit.author.name = "Test Author"
        mock_commit.authored_datetime.isoformat.return_value = "2023-01-01T00:00:00"

        mock_repo.iter_commits.return_value = [mock_commit]
        mock_get_repo.return_value = mock_repo

        result = get_commit_history(1)
        assert len(result["commits"]) == 1
        assert result["commits"][0]["hash"] == "abc123"
        assert result["commits"][0]["message"] == "Test commit"


class TestMergeBranch:
    """Test branch merging."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_merge_branch_no_repo(self, mock_get_repo):
        """Test merging when not in repo."""
        mock_get_repo.return_value = None

        result = merge_branch("feature")
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_merge_branch_success(self, mock_get_repo):
        """Test merging branch successfully."""
        mock_repo = MagicMock()
        mock_repo.git.merge.return_value = "Merge made by recursive"
        mock_get_repo.return_value = mock_repo

        result = merge_branch("feature")
        assert result["success"] == "Merged feature: Merge made by recursive"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_merge_branch_conflict(self, mock_get_repo):
        """Test merging with conflicts."""
        from git import GitCommandError

        mock_repo = MagicMock()
        mock_repo.git.merge.side_effect = GitCommandError("merge", 1, "CONFLICT")
        mock_get_repo.return_value = mock_repo

        result = merge_branch("feature")
        assert result["conflict"] == "Merge conflict with feature. Run resolve_conflicts."


class TestDetectConflicts:
    """Test conflict detection."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_detect_conflicts_no_repo(self, mock_get_repo):
        """Test detecting conflicts when not in repo."""
        mock_get_repo.return_value = None

        result = detect_conflicts()
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_detect_conflicts_no_conflicts(self, mock_get_repo):
        """Test detecting no conflicts."""
        mock_repo = MagicMock()
        mock_repo.working_dir = "/tmp/repo"
        mock_get_repo.return_value = mock_repo

        # Mock Path.exists to return False for merge files
        with patch('pathlib.Path.exists', return_value=False):
            result = detect_conflicts()
            assert result["conflicts"] == []

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_detect_conflicts_with_conflicts(self, mock_get_repo):
        """Test detecting conflicts."""
        mock_repo = MagicMock()
        mock_repo.working_dir = "/tmp/repo"
        mock_repo.git.status.return_value = "UU conflicted.txt\nM normal.txt"
        mock_get_repo.return_value = mock_repo

        with patch('pathlib.Path.exists', return_value=True):
            result = detect_conflicts()
            assert result["conflicts"] == ["conflicted.txt"]


class TestResolveConflicts:
    """Test conflict resolution."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_resolve_conflicts_no_repo(self, mock_get_repo):
        """Test resolving conflicts when not in repo."""
        mock_get_repo.return_value = None

        result = resolve_conflicts({"file.txt": "ours"})
        assert "error" in result
        assert "Not in a Git repository" in result["error"]
        assert "hint" in result

    @patch('gitspectre.tools.git_tools.validate_repo_path')
    @patch('gitspectre.tools.git_tools.get_repo')
    def test_resolve_conflicts_invalid_path(self, mock_get_repo, mock_validate):
        """Test resolving conflicts with invalid path."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo
        mock_validate.return_value = False

        result = resolve_conflicts({"../outside.txt": "ours"})
        assert "error" in result
        assert "Invalid file path" in result["error"]
        assert "hint" in result

    @patch('gitspectre.tools.git_tools.validate_repo_path')
    @patch('gitspectre.tools.git_tools.get_repo')
    def test_resolve_conflicts_keep_ours(self, mock_get_repo, mock_validate):
        """Test resolving conflicts by keeping our changes."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo
        mock_validate.return_value = True

        result = resolve_conflicts({"file.txt": "ours"})
        assert result["success"] == "Conflicts resolved and committed"
        mock_repo.git.checkout.assert_called_once_with('--ours', 'file.txt')

    @patch('gitspectre.tools.git_tools.validate_repo_path')
    @patch('gitspectre.tools.git_tools.get_repo')
    def test_resolve_conflicts_keep_theirs(self, mock_get_repo, mock_validate):
        """Test resolving conflicts by keeping their changes."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo
        mock_validate.return_value = True

        result = resolve_conflicts({"file.txt": "theirs"})
        assert result["success"] == "Conflicts resolved and committed"
        mock_repo.git.checkout.assert_called_once_with('--theirs', 'file.txt')

    @patch('gitspectre.tools.git_tools.validate_repo_path')
    @patch('gitspectre.tools.git_tools.get_repo')
    def test_resolve_conflicts_merge(self, mock_get_repo, mock_validate):
        """Test resolving conflicts by merging."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo
        mock_validate.return_value = True

        result = resolve_conflicts({"file.txt": "merge"})
        assert result["success"] == "Conflicts resolved and committed"
        # For merge, it should not call checkout
        mock_repo.git.checkout.assert_not_called()

    @patch('gitspectre.tools.git_tools.validate_repo_path')
    @patch('gitspectre.tools.git_tools.get_repo')
    def test_resolve_conflicts_invalid_resolution(self, mock_get_repo, mock_validate):
        """Test resolving conflicts with invalid resolution type."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo
        mock_validate.return_value = True

        result = resolve_conflicts({"file.txt": "invalid"})
        assert "error" in result
        assert "Invalid resolution" in result["error"]
        assert "hint" in result


class TestPushChanges:
    """Test pushing changes."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_push_changes_no_repo(self, mock_get_repo):
        """Test pushing when not in repo."""
        mock_get_repo.return_value = None

        result = push_changes()
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_push_changes_success(self, mock_get_repo):
        """Test pushing changes successfully."""
        mock_repo = MagicMock()
        mock_repo.active_branch.name = "main"
        mock_get_repo.return_value = mock_repo

        result = push_changes()
        assert result["success"] == "Pushed main to origin"
        mock_repo.git.push.assert_called_once_with('origin', 'main')


class TestPullChanges:
    """Test pulling changes."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_pull_changes_no_repo(self, mock_get_repo):
        """Test pulling when not in repo."""
        mock_get_repo.return_value = None

        result = pull_changes()
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_pull_changes_success(self, mock_get_repo):
        """Test pulling changes successfully."""
        mock_repo = MagicMock()
        mock_repo.active_branch.name = "main"
        mock_repo.git.pull.return_value = "Already up to date"
        mock_get_repo.return_value = mock_repo

        result = pull_changes()
        assert result["success"] == "Pulled from origin/main"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_pull_changes_conflict(self, mock_get_repo):
        """Test pulling with conflicts."""
        mock_repo = MagicMock()
        mock_repo.active_branch.name = "main"
        mock_repo.git.pull.return_value = "CONFLICT (content): Merge conflict"
        mock_get_repo.return_value = mock_repo

        result = pull_changes()
        assert result["conflict"] == "Pull resulted in conflicts on main"


class TestStashChanges:
    """Test stashing changes."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_stash_changes_no_repo(self, mock_get_repo):
        """Test stashing when not in repo."""
        mock_get_repo.return_value = None

        result = stash_changes()
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_stash_changes_success(self, mock_get_repo):
        """Test stashing changes successfully."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo

        result = stash_changes("Work in progress")
        assert result["success"] == "Changes stashed"
        mock_repo.git.stash.assert_called_once_with('push', '-u', '-m', 'Work in progress')


class TestApplyStash:
    """Test applying stashed changes."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_apply_stash_no_repo(self, mock_get_repo):
        """Test applying stash when not in repo."""
        mock_get_repo.return_value = None

        result = apply_stash()
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_apply_stash_success(self, mock_get_repo):
        """Test applying stash successfully."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo

        result = apply_stash(1)
        assert result["success"] == "Applied stash@{1}"
        mock_repo.git.stash.assert_called_once_with('apply', 'stash@{1}')


class TestGetDiff:
    """Test diff retrieval."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_get_diff_no_repo(self, mock_get_repo):
        """Test getting diff when not in repo."""
        mock_get_repo.return_value = None

        result = get_diff()
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_get_diff_working_directory(self, mock_get_repo):
        """Test getting diff of working directory."""
        mock_repo = MagicMock()
        mock_repo.git.diff.return_value = "+ new line\n- old line"
        mock_get_repo.return_value = mock_repo

        result = get_diff()
        assert result["diff"] == "+ new line\n- old line"


class TestCreateTag:
    """Test tag creation."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_create_tag_no_repo(self, mock_get_repo):
        """Test creating tag when not in repo."""
        mock_get_repo.return_value = None

        result = create_tag("v1.0")
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_create_tag_success(self, mock_get_repo):
        """Test creating tag successfully."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo

        result = create_tag("v1.0", "Release version 1.0")
        assert result["success"] == "Created tag v1.0"
        mock_repo.create_tag.assert_called_once_with("v1.0", message="Release version 1.0")


class TestResetFiles:
    """Test file resetting."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_reset_files_no_repo(self, mock_get_repo):
        """Test resetting files when not in repo."""
        mock_get_repo.return_value = None

        result = reset_files(["file.txt"])
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.validate_repo_path')
    @patch('gitspectre.tools.git_tools.get_repo')
    def test_reset_files_invalid_mode(self, mock_get_repo, mock_validate):
        """Test resetting files with invalid mode."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo
        mock_validate.return_value = True

        result = reset_files(["file.txt"], "invalid")
        assert result["error"] == "Invalid reset mode"

    @patch('gitspectre.tools.git_tools.validate_repo_path')
    @patch('gitspectre.tools.git_tools.get_repo')
    def test_reset_files_success(self, mock_get_repo, mock_validate):
        """Test resetting files successfully."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo
        mock_validate.return_value = True

        result = reset_files(["file.txt"], "hard")
        assert result["success"] == "Reset 1 file(s) with hard mode"
        mock_repo.git.reset.assert_called_once_with('hard', '--', 'file.txt')


class TestAbortMerge:
    """Test merge abortion."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_abort_merge_no_repo(self, mock_get_repo):
        """Test aborting merge when not in repo."""
        mock_get_repo.return_value = None

        result = abort_merge()
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_abort_merge_success(self, mock_get_repo):
        """Test aborting merge successfully."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo

        result = abort_merge()
        assert result["success"] == "Merge aborted"
        mock_repo.git.merge.assert_called_once_with('--abort')


class TestInitRepo:
    """Test repository initialization."""

    @patch('gitspectre.tools.git_tools.Repo')
    def test_init_repo_success(self, mock_repo_class):
        """Test initializing repository successfully."""
        mock_repo = MagicMock()
        mock_repo_class.init.return_value = mock_repo

        result = init_repo("/tmp/new-repo")
        assert result["success"] == "Initialized repository at /tmp/new-repo"


class TestCloneRepo:
    """Test repository cloning."""

    @patch('gitspectre.tools.git_tools.Repo')
    def test_clone_repo_success(self, mock_repo_class):
        """Test cloning repository successfully."""
        mock_repo = MagicMock()
        mock_repo_class.clone_from.return_value = mock_repo

        result = clone_repo("https://github.com/user/repo.git", "/tmp/clone")
        assert result["success"] == "Cloned repository to /tmp/clone"


class TestResetToRemote:
    """Test resetting to remote branch."""

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_reset_to_remote_no_repo(self, mock_get_repo):
        """Test resetting to remote when not in repo."""
        mock_get_repo.return_value = None

        result = reset_to_remote()
        assert result["error"] == "Not in a Git repository"

    @patch('gitspectre.tools.git_tools.get_repo')
    def test_reset_to_remote_success(self, mock_get_repo):
        """Test resetting to remote successfully."""
        mock_repo = MagicMock()
        mock_get_repo.return_value = mock_repo

        result = reset_to_remote()
        assert result["success"] == "Reset to origin/main and cleaned untracked files"
        mock_repo.git.fetch.assert_called_once_with('origin')
        mock_repo.git.reset.assert_called_once_with('--hard', 'origin/main')
        mock_repo.git.clean.assert_called_once_with('-fd')