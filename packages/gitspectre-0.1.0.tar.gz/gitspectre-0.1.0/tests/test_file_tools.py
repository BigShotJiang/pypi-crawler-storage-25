"""
Unit tests for gitspectre.tools.file_tools module.
"""

from unittest.mock import patch

from gitspectre.tools.file_tools import (
    read_file, write_file, create_file, search_replace, validate_code,
    analyze_conflicts, apply_conflict_resolution, get_file_info
)


class TestReadFile:
    """Test file reading functionality."""

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_read_file_success(self, mock_validate, temp_dir):
        """Test reading a file successfully."""
        mock_validate.return_value = True
        test_file = temp_dir / "test.txt"
        test_content = "Line 1\nLine 2\nLine 3"
        test_file.write_text(test_content)

        result = read_file(str(test_file))
        assert "File: " in result
        assert "Lines: 3" in result
        assert test_content in result

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_read_file_with_line_range(self, mock_validate, temp_dir):
        """Test reading file with line range."""
        mock_validate.return_value = True
        test_file = temp_dir / "test.txt"
        test_content = "Line 1\nLine 2\nLine 3\nLine 4\nLine 5"
        test_file.write_text(test_content)

        result = read_file(str(test_file), start_line=2, end_line=4)
        assert "Line 2\nLine 3\nLine 4" in result

    def test_read_file_not_exists(self):
        """Test reading non-existent file."""
        result = read_file("nonexistent.txt")
        assert "Error: File does not exist" in result

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_read_file_invalid_path(self, mock_validate):
        """Test reading file with invalid path."""
        mock_validate.return_value = False
        result = read_file("../outside.txt")
        assert "Error: Invalid file path" in result


class TestWriteFile:
    """Test file writing functionality."""

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_write_file_success(self, mock_validate, temp_dir):
        """Test writing to file successfully."""
        mock_validate.return_value = True
        test_file = temp_dir / "test.txt"
        content = "Test content"

        result = write_file(str(test_file), content)
        assert result["success"] == f"Wrote {len(content)} characters to {test_file}"

        # Verify file was written
        assert test_file.read_text() == content

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_create_file_success(self, mock_validate, temp_dir):
        """Test creating a file using the create_file alias."""
        mock_validate.return_value = True
        test_file = temp_dir / "hello.txt"
        content = "Hello World"

        result = create_file(str(test_file), content)
        assert result["success"] == f"Wrote {len(content)} characters to {test_file}"
        assert test_file.read_text() == content

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_write_file_invalid_path(self, mock_validate):
        """Test writing to invalid path."""
        mock_validate.return_value = False
        result = write_file("../outside.txt", "content")
        assert result["error"] == "Invalid file path: ../outside.txt"


class TestSearchReplace:
    """Test search and replace functionality."""

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_search_replace_success(self, mock_validate, temp_dir):
        """Test successful search and replace."""
        mock_validate.return_value = True
        test_file = temp_dir / "test.txt"
        original = "Hello world"
        test_file.write_text(original)

        result = search_replace(str(test_file), "world", "universe")
        assert result["success"] == f"Replaced text in {test_file}"

        # Verify replacement
        assert test_file.read_text() == "Hello universe"

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_search_replace_not_found(self, mock_validate, temp_dir):
        """Test search replace when old string not found."""
        mock_validate.return_value = True
        test_file = temp_dir / "test.txt"
        test_file.write_text("Hello world")

        result = search_replace(str(test_file), "missing", "replacement")
        assert result["error"] == f"Old string not found in {test_file}"

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_search_replace_invalid_path(self, mock_validate):
        """Test search replace with invalid path."""
        mock_validate.return_value = False
        result = search_replace("../outside.txt", "old", "new")
        assert result["error"] == "Invalid file path: ../outside.txt"


class TestValidateCode:
    """Test code validation functionality."""

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_validate_code_python_valid(self, mock_validate, temp_dir):
        """Test validating valid Python code."""
        mock_validate.return_value = True
        test_file = temp_dir / "test.py"
        test_file.write_text("def hello():\n    return 'world'")

        result = validate_code(str(test_file), "python")
        assert result["valid"] is True
        assert "valid" in result["message"]

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_validate_code_python_invalid(self, mock_validate, temp_dir):
        """Test validating invalid Python code."""
        mock_validate.return_value = True
        test_file = temp_dir / "test.py"
        test_file.write_text("def hello(\n    return 'world'")  # Missing closing paren

        result = validate_code(str(test_file), "python")
        assert result["valid"] is False
        assert "Syntax error" in result["message"]

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_validate_code_other_language(self, mock_validate, temp_dir):
        """Test validating non-Python code."""
        mock_validate.return_value = True
        test_file = temp_dir / "test.js"
        test_file.write_text("function hello() { return 'world'; }")

        result = validate_code(str(test_file), "javascript")
        assert result["valid"] is True
        assert "not implemented" in result["message"]

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_validate_code_invalid_path(self, mock_validate):
        """Test validating code with invalid path."""
        mock_validate.return_value = False
        result = validate_code("../outside.py", "python")
        assert result["error"] == "Invalid file path: ../outside.py"


class TestAnalyzeConflicts:
    """Test conflict analysis functionality."""

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_analyze_conflicts_no_conflicts(self, mock_validate, temp_dir):
        """Test analyzing file without conflicts."""
        mock_validate.return_value = True
        test_file = temp_dir / "test.txt"
        test_file.write_text("Normal content")

        result = analyze_conflicts(str(test_file))
        assert result["has_conflicts"] is False
        assert "No merge conflicts detected" in result["message"]

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_analyze_conflicts_with_conflicts(self, mock_validate, temp_dir):
        mock_validate.return_value = True
        """Test analyzing file with merge conflicts."""
        test_file = temp_dir / "test.txt"
        conflict_content = """<<<<<<< HEAD
Local changes
=======
Remote changes
>>>>>>> REMOTE_BRANCH
"""
        test_file.write_text(conflict_content)

        result = analyze_conflicts(str(test_file))
        assert result["has_conflicts"] is True
        assert "Local changes" in result["ours_content"]
        assert "Remote changes" in result["theirs_content"]
        assert len(result["suggestions"]) > 0

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_analyze_conflicts_invalid_path(self, mock_validate):
        """Test analyzing conflicts with invalid path."""
        mock_validate.return_value = False
        result = analyze_conflicts("../outside.txt")
        assert result["error"] == "Invalid file path: ../outside.txt"


class TestApplyConflictResolution:
    """Test conflict resolution application."""

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_apply_conflict_resolution_keep_ours(self, mock_validate, temp_dir):
        mock_validate.return_value = True
        """Test keeping our changes in conflict resolution."""
        test_file = temp_dir / "test.txt"
        conflict_content = """<<<<<<< HEAD
Our changes
=======
Their changes
>>>>>>> REMOTE_BRANCH
"""
        test_file.write_text(conflict_content)

        result = apply_conflict_resolution(str(test_file), "keep_ours")
        assert "success" in result

        # Verify file content
        final_content = test_file.read_text()
        assert "Our changes" in final_content
        assert "<<<<<<< HEAD" not in final_content

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_apply_conflict_resolution_keep_theirs(self, mock_validate, temp_dir):
        mock_validate.return_value = True
        """Test keeping their changes in conflict resolution."""
        test_file = temp_dir / "test.txt"
        conflict_content = """<<<<<<< HEAD
Our changes
=======
Their changes
>>>>>>> REMOTE_BRANCH
"""
        test_file.write_text(conflict_content)

        result = apply_conflict_resolution(str(test_file), "keep_theirs")
        assert "success" in result

        final_content = test_file.read_text()
        assert "Their changes" in final_content
        assert "<<<<<<< HEAD" not in final_content

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_apply_conflict_resolution_manual(self, mock_validate, temp_dir):
        mock_validate.return_value = True
        """Test manual conflict resolution."""
        test_file = temp_dir / "test.txt"
        conflict_content = """<<<<<<< HEAD
Our changes
=======
Their changes
>>>>>>> REMOTE_BRANCH
"""
        test_file.write_text(conflict_content)

        custom_content = "Merged content"

        result = apply_conflict_resolution(str(test_file), "manual_edit", custom_content)
        assert "success" in result

        final_content = test_file.read_text()
        assert final_content == custom_content

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_apply_conflict_resolution_no_conflicts(self, mock_validate, temp_dir):
        mock_validate.return_value = True
        """Test applying resolution to file without conflicts."""
        test_file = temp_dir / "test.txt"
        test_file.write_text("Normal content")

        result = apply_conflict_resolution(str(test_file), "keep_ours")
        assert result["error"] == "No merge conflict markers found"


class TestGetFileInfo:
    """Test file information retrieval."""

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_get_file_info_success(self, mock_validate, temp_dir):
        mock_validate.return_value = True
        """Test getting file information successfully."""
        test_file = temp_dir / "test.txt"
        content = "Test content"
        test_file.write_text(content)

        result = get_file_info(str(test_file))
        assert result["path"] == str(test_file)
        assert result["size"] == len(content)
        assert result["is_file"] is True
        assert result["extension"] == ".txt"

    def test_get_file_info_not_exists(self):
        """Test getting info for non-existent file."""
        result = get_file_info("nonexistent.txt")
        assert result["error"] == "File does not exist: nonexistent.txt"

    @patch('gitspectre.tools.file_tools.validate_repo_path')
    def test_get_file_info_invalid_path(self, mock_validate):
        """Test getting info with invalid path."""
        mock_validate.return_value = False
        result = get_file_info("../outside.txt")
        assert result["error"] == "Invalid file path: ../outside.txt"