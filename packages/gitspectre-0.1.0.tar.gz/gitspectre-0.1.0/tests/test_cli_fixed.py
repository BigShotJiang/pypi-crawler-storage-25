"""
Integration tests for gitspectre.cli module.
"""

from unittest.mock import patch, MagicMock
from click.testing import CliRunner

from gitspectre.cli import cli


class TestCLIConfig:
    """Test CLI configuration menu."""

    @patch('gitspectre.cli.show_config_menu')
    def test_cli_config_menu(self, mock_show_menu):
        """Test --config opens configuration menu."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--config"])

        mock_show_menu.assert_called_once()
        assert result.exit_code == 0

    def test_show_config_menu_exit(self):
        """Test config menu exit option."""
        runner = CliRunner()
        # Provide input "6" to select exit
        result = runner.invoke(cli, ["--config"], input="6\n")

        assert result.exit_code == 0
        assert "Exiting." in result.output


class TestCLIHelp:
    """Test CLI help output."""

    @patch('gitspectre.cli.get_api_key')
    @patch('gitspectre.cli.get_provider')
    def test_cli_help_output(self, mock_get_provider, mock_get_api_key):
        """Test custom help output when no command provided."""
        mock_get_provider.return_value = 'openrouter'
        mock_get_api_key.return_value = "test-key"
        runner = CliRunner()
        result = runner.invoke(cli, [])

        assert result.exit_code == 0
        assert "Usage: spectre [MESSAGE]..." in result.output
        assert "Example: spectre create a new branch and move my current work there" in result.output
        assert "GitSpectre: AI-powered Git CLI tool." in result.output


class TestCLIExecution:
    """Test CLI execution with agent."""

    @patch('gitspectre.cli.get_api_key')
    @patch('gitspectre.cli.get_provider')
    def test_cli_no_api_key(self, mock_get_provider, mock_get_api_key):
        """Test CLI when no API key is set."""
        mock_get_provider.return_value = 'openrouter'
        mock_get_api_key.return_value = None

        runner = CliRunner()
        result = runner.invoke(cli, ["show git status"])

        assert result.exit_code == 0
        assert "No OpenRouter API key found" in result.output

    @patch('gitspectre.cli.get_api_key')
    @patch('gitspectre.cli.get_provider')
    @patch('gitspectre.cli.Repo')
    @patch('gitspectre.cli.GitSpectreAgent')
    @patch('asyncio.run')
    def test_cli_with_command(self, mock_asyncio_run, mock_agent_class, mock_repo_class, mock_get_provider, mock_get_api_key):
        """Test CLI execution with a command."""
        # Setup mocks
        mock_get_provider.return_value = 'openrouter'
        mock_get_api_key.return_value = "test-key"
        mock_repo = MagicMock()
        mock_repo_class.return_value = mock_repo

        mock_agent = MagicMock()
        mock_agent.run_conversation.return_value = "Command executed successfully"
        mock_agent_class.return_value = mock_agent

        # Mock asyncio.run to return the result directly
        mock_asyncio_run.return_value = "Command executed successfully"

        runner = CliRunner()
        result = runner.invoke(cli, ["show git status"])

        assert result.exit_code == 0

    @patch('gitspectre.cli.get_api_key')
    @patch('gitspectre.cli.get_provider')
    @patch('gitspectre.cli.Repo')
    def test_cli_not_in_repo(self, mock_repo_class, mock_get_provider, mock_get_api_key):
        """Test CLI when not in a Git repository."""
        mock_get_provider.return_value = 'openrouter'
        mock_get_api_key.return_value = "test-key"
        mock_repo_class.side_effect = Exception("Not a git repo")

        runner = CliRunner()
        result = runner.invoke(cli, ["show git status"])

        assert result.exit_code == 0
        # Should still work but with "Not in a Git repository" context

    @patch('gitspectre.cli.get_api_key')
    @patch('gitspectre.cli.get_provider')
    @patch('gitspectre.cli.GitSpectreAgent')
    @patch('asyncio.run')
    def test_cli_interactive_conversation(self, mock_asyncio_run, mock_agent_class, mock_get_provider, mock_get_api_key):
        """Test CLI with interactive conversation requiring user input."""
        mock_get_provider.return_value = 'openrouter'
        mock_get_api_key.return_value = "test-key"

        mock_agent = MagicMock()
        # First call returns user input needed
        mock_agent.run_conversation.return_value = ("USER_INPUT_NEEDED", "What branch to switch to?")
        # Second call (after user input) returns final result
        mock_agent.continue_conversation.return_value = "Switched to develop branch"
        mock_agent_class.return_value = mock_agent

        # Mock asyncio.run to simulate the interactive flow
        def mock_run(coro):
            # Simulate the async function behavior
            return ("USER_INPUT_NEEDED", "What branch to switch to?")

        mock_asyncio_run.side_effect = mock_run

        runner = CliRunner()
        # Note: In a real scenario, this would prompt for input
        # For testing, we simulate the flow
        result = runner.invoke(cli, ["switch to develop branch"])

        assert result.exit_code == 0
