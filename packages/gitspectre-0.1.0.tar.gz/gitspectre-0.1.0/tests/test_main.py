import runpy
from unittest.mock import patch


def test_main_entry_point():
    """Test that main.py calls cli.main() when run as __main__."""
    with patch('gitspectre.cli.cli') as mock_cli:
        runpy.run_module('gitspectre.main', run_name='__main__')
        mock_cli.main.assert_called_once()