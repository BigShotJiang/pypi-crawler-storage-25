"""
Unit tests for gitspectre.tools.utility_tools module.
"""

from unittest.mock import patch, MagicMock

from gitspectre.tools.utility_tools import (
    get_git_config_tool, set_git_config_tool, list_git_configs, ask_user
)


class TestGitConfigTool:
    """Test Git config tool functions."""

    @patch('gitspectre.tools.utility_tools.get_git_config')
    def test_get_git_config_tool_success(self, mock_get_config):
        """Test getting Git config successfully."""
        mock_get_config.return_value = "test-value"

        result = get_git_config_tool("user.name")
        assert result == {"value": "test-value"}

    @patch('gitspectre.tools.utility_tools.get_git_config')
    def test_get_git_config_tool_not_found(self, mock_get_config):
        """Test getting Git config when key not found."""
        mock_get_config.return_value = None

        result = get_git_config_tool("nonexistent.key")
        assert result == {"error": "Git config key 'nonexistent.key' not found"}

    @patch('gitspectre.tools.utility_tools.get_git_config')
    def test_get_git_config_tool_error(self, mock_get_config):
        """Test getting Git config with error."""
        mock_get_config.side_effect = Exception("Config error")

        result = get_git_config_tool("user.name")
        assert "error" in result
        assert "Config error" in result["error"]


class TestSetGitConfigTool:
    """Test setting Git config tool."""

    @patch('gitspectre.tools.utility_tools.set_git_config')
    def test_set_git_config_tool_success(self, mock_set_config):
        """Test setting Git config successfully."""
        result = set_git_config_tool("user.name", "Test User")
        assert result == {"success": "Set Git config user.name = Test User"}

    @patch('gitspectre.tools.utility_tools.set_git_config')
    def test_set_git_config_tool_error(self, mock_set_config):
        """Test setting Git config with error."""
        mock_set_config.side_effect = Exception("Set config error")

        result = set_git_config_tool("user.name", "Test User")
        assert "error" in result
        assert "Set config error" in result["error"]


class TestListGitConfigs:
    """Test listing Git configs."""

    @patch('subprocess.run')
    def test_list_git_configs_success(self, mock_run):
        """Test listing Git configs successfully."""
        mock_process = MagicMock()
        mock_process.stdout = "user.name=Test User\nuser.email=test@example.com\n"
        mock_process.returncode = 0
        mock_run.return_value = mock_process

        result = list_git_configs()
        expected = {
            "user.name": "Test User",
            "user.email": "test@example.com"
        }
        assert result == {"configs": expected}

    @patch('subprocess.run')
    def test_list_git_configs_error(self, mock_run):
        """Test listing Git configs with error."""
        mock_run.side_effect = Exception("Git command failed")

        result = list_git_configs()
        assert "error" in result
        assert "Git command failed" in result["error"]


class TestAskUser:
    """Test ask_user tool."""

    def test_ask_user(self):
        """Test ask_user returns expected format."""
        result = ask_user("What is your name?")
        expected = {"user_input_needed": "What is your name?"}
        assert result == expected