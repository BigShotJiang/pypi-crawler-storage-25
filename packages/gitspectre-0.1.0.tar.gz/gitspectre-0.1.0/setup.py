from setuptools import setup, find_packages

setup(
    name='gitspectre',
    version='0.1.0',
    packages=find_packages(),
    package_data={"gitspectre": ["prompts.json"]},
    include_package_data=True,
    install_requires=[
        'GitPython==3.1.40',
        'requests==2.31.0',
        'anthropic>=0.25.0',
        'python-dotenv==1.0.0',
        'click==8.1.7',
        'colorama==0.4.6',
        'yaspin==3.0.1',
        'rich==13.7.1'
    ],
    entry_points={
        'console_scripts': [
            'spectre=gitspectre.cli:cli',
        ],
    },
    author='Haris Naeem',
    author_email='harisnaeem612@outlook.com',
    description='AI-powered Git CLI tool',
    keywords='git ai cli',
    python_requires='>=3.6',
)