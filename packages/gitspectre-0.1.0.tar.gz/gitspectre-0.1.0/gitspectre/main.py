#!/usr/bin/env python3
"""
Entry point for GitSpectre CLI.
Delegates to the modular CLI implementation.
"""

from .cli import cli

if __name__ == '__main__':
    cli.main()