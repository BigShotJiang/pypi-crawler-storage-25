"""
File and code manipulation tools for GitSpectre.
Provides functions for reading, writing, and modifying files, with code analysis capabilities.
"""

import ast
import difflib
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
from ..utils import validate_repo_path, handle_error

def is_binary_file(file_path: str) -> bool:
    """Check if a file is binary by reading its first 8192 bytes.
    
    Args:
        file_path: Path to the file to check
        
    Returns:
        True if file appears to be binary, False otherwise
    """
    try:
        path = Path(file_path)
        if not path.exists():
            return False
            
        # Check file extension first for common binary types
        binary_extensions = {
            '.png', '.jpg', '.jpeg', '.gif', '.bmp', '.ico', '.svg',
            '.pdf', '.zip', '.tar', '.gz', '.rar', '.7z',
            '.exe', '.dll', '.so', '.dylib',
            '.pyc', '.pyo', '.pyd',
            '.db', '.sqlite', '.sqlite3',
            '.mp3', '.mp4', '.avi', '.mov', '.wav',
            '.ttf', '.otf', '.woff', '.woff2'
        }
        
        if path.suffix.lower() in binary_extensions:
            return True
        
        # Read first chunk and check for null bytes
        with open(path, 'rb') as f:
            chunk = f.read(8192)
            if b'\x00' in chunk:
                return True
                
        return False
    except Exception:
        return False

def read_file(file_path: str, start_line: Optional[int] = None, end_line: Optional[int] = None) -> str:
    """Read a file's contents, optionally limiting to specific lines."""
    if not validate_repo_path(file_path):
        return f"Error: Invalid file path: {file_path}"

    try:
        path = Path(file_path)
        if not path.exists():
            return f"Error: File does not exist: {file_path}"

        content = path.read_text(encoding='utf-8')
        lines = content.splitlines()

        if start_line is not None and end_line is not None:
            # 1-based indexing
            start_idx = max(0, start_line - 1)
            end_idx = min(len(lines), end_line)
            selected_lines = lines[start_idx:end_idx]
            content = '\n'.join(selected_lines)

        return f"File: {file_path}\nLines: {len(lines)}\n\n{content}"
    except Exception as e:
        return f"Error reading file: {handle_error(e, 'read_file')}"

def write_file(file_path: str, content: str) -> Dict[str, Any]:
    """Write content to a file."""
    if not validate_repo_path(file_path):
        return {"error": f"Invalid file path: {file_path}"}

    try:
        path = Path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8')
        return {"success": f"Wrote {len(content)} characters to {file_path}"}
    except Exception as e:
        return {"error": handle_error(e, "write_file")}


def create_file(file_path: str, content: str) -> Dict[str, Any]:
    """Create a new file or overwrite an existing file."""
    return write_file(file_path, content)


def search_replace(file_path: str, old_string: str, new_string: str) -> Dict[str, Any]:
    """Search and replace text in a file."""
    if not validate_repo_path(file_path):
        return {"error": f"Invalid file path: {file_path}"}

    try:
        path = Path(file_path)
        if not path.exists():
            return {"error": f"File does not exist: {file_path}"}

        content = path.read_text(encoding='utf-8')
        if old_string not in content:
            return {"error": f"Old string not found in {file_path}"}

        new_content = content.replace(old_string, new_string, 1)  # Replace first occurrence
        path.write_text(new_content, encoding='utf-8')

        return {"success": f"Replaced text in {file_path}"}
    except Exception as e:
        return {"error": handle_error(e, "search_replace")}

def validate_code(file_path: str, language: str = 'python') -> Dict[str, Any]:
    """Validate code syntax in a file."""
    if not validate_repo_path(file_path):
        return {"error": f"Invalid file path: {file_path}"}

    try:
        path = Path(file_path)
        if not path.exists():
            return {"error": f"File does not exist: {file_path}"}

        content = path.read_text(encoding='utf-8')

        if language.lower() == 'python':
            try:
                ast.parse(content)
                return {"valid": True, "message": "Python syntax is valid"}
            except SyntaxError as e:
                return {"valid": False, "message": f"Syntax error: {e}"}
        elif language.lower() == 'json':
            try:
                json.loads(content)
                return {"valid": True, "message": "JSON syntax is valid"}
            except json.JSONDecodeError as e:
                return {"valid": False, "message": f"JSON syntax error: {e}"}
        else:
            # For other languages, basic check
            return {"valid": True, "message": f"Basic validation for {language} (advanced parsing not implemented)"}
    except Exception as e:
        return {"error": handle_error(e, "validate_code")}

def analyze_conflicts(file_path: str) -> Dict[str, Any]:
    """Analyze merge conflicts in a file and suggest resolutions."""
    if not validate_repo_path(file_path):
        return {"error": f"Invalid file path: {file_path}"}

    # Check if file is binary
    if is_binary_file(file_path):
        return {
            "error": "Cannot analyze conflicts in binary file",
            "is_binary": True,
            "hint": "Binary files must be resolved by choosing 'ours' or 'theirs' entirely. Use resolve_conflicts with 'ours' or 'theirs' strategy."
        }

    try:
        path = Path(file_path)
        if not path.exists():
            return {"error": f"File does not exist: {file_path}"}

        content = path.read_text(encoding='utf-8')
        lines = content.splitlines()

        conflict_start = -1
        conflict_end = -1
        separator = -1

        for i, line in enumerate(lines):
            if line.startswith('<<<<<<< '):
                conflict_start = i
            elif line.startswith('======='):
                separator = i
            elif line.startswith('>>>>>>> '):
                conflict_end = i
                break

        if conflict_start == -1 or separator == -1 or conflict_end == -1:
            return {
                "has_conflicts": False,
                "message": "No merge conflicts detected",
                "hint": "File may already be resolved. Use 'detect_conflicts' to find files with active conflicts."
            }

        ours_content = '\n'.join(lines[conflict_start + 1:separator])
        theirs_content = '\n'.join(lines[separator + 1:conflict_end])

        # Simple diff analysis
        diff = list(difflib.unified_diff(
            ours_content.splitlines(),
            theirs_content.splitlines(),
            fromfile='ours',
            tofile='theirs',
            lineterm=''
        ))

        # Calculate conflict size and context
        conflict_size = conflict_end - conflict_start + 1
        lines_before = max(0, conflict_start - 2)
        lines_after = min(len(lines), conflict_end + 3)
        context_before = '\n'.join(lines[lines_before:conflict_start]) if conflict_start > 0 else ""
        context_after = '\n'.join(lines[conflict_end + 1:lines_after]) if conflict_end < len(lines) - 1 else ""

        return {
            "has_conflicts": True,
            "conflict_location": {
                "start_line": conflict_start + 1,  # 1-based line numbering
                "end_line": conflict_end + 1,
                "conflict_size": conflict_size
            },
            "ours_content": ours_content,
            "theirs_content": theirs_content,
            "context_before": context_before,
            "context_after": context_after,
            "diff": '\n'.join(diff),
            "suggestions": [
                "keep_ours: Use the local version",
                "keep_theirs: Use the incoming version",
                "merge_both: Combine both versions manually",
                "manual_edit: Edit the file directly"
            ]
        }
    except Exception as e:
        return {"error": handle_error(e, "analyze_conflicts")}

def apply_conflict_resolution(file_path: str, resolution: str, custom_content: Optional[str] = None, create_backup: bool = True) -> Dict[str, Any]:
    """Apply a conflict resolution to a file.
    
    Args:
        file_path: Path to the conflicted file
        resolution: Resolution strategy ('keep_ours', 'keep_theirs', 'merge_both', 'manual_edit')
        custom_content: Custom content for merge_both or manual_edit
        create_backup: If True, creates a backup before modifying the file (default: True)
    """
    if not validate_repo_path(file_path):
        return {"error": f"Invalid file path: {file_path}"}

    # Check if file is binary
    if is_binary_file(file_path):
        return {
            "error": "Cannot resolve conflicts in binary file using apply_conflict_resolution",
            "is_binary": True,
            "hint": "Binary files must be resolved using resolve_conflicts with 'ours' or 'theirs' strategy."
        }

    try:
        path = Path(file_path)
        if not path.exists():
            return {
                "error": f"File does not exist: {file_path}",
                "hint": "Check the file path and ensure it's relative to the repository root."
            }
        
        # Create backup if requested
        backup_path = None
        if create_backup:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"{file_path}.backup_{timestamp}"
            try:
                shutil.copy2(file_path, backup_path)
            except Exception as e:
                return {
                    "error": f"Failed to create backup: {str(e)}",
                    "hint": "Ensure you have write permissions in the directory."
                }

        content = path.read_text(encoding='utf-8')
        lines = content.splitlines()

        conflict_start = -1
        conflict_end = -1

        for i, line in enumerate(lines):
            if line.startswith('<<<<<<< '):
                conflict_start = i
            elif line.startswith('>>>>>>> '):
                conflict_end = i
                break

        if conflict_start == -1 or conflict_end == -1:
            return {
                "error": "No merge conflict markers found",
                "hint": "This file may already be resolved, or it's not a conflicted file. Use 'analyze_conflicts' to check file status."
            }

        # Remove conflict markers and apply resolution
        before_conflict = lines[:conflict_start]
        after_conflict = lines[conflict_end + 1:]

        if resolution == 'keep_ours':
            # Find the separator
            separator = -1
            for i in range(conflict_start, conflict_end):
                if lines[i].startswith('======='):
                    separator = i
                    break
            resolved = lines[conflict_start + 1:separator]
        elif resolution == 'keep_theirs':
            separator = -1
            for i in range(conflict_start, conflict_end):
                if lines[i].startswith('======='):
                    separator = i
                    break
            resolved = lines[separator + 1:conflict_end]
        elif resolution == 'merge_both' and custom_content:
            resolved = custom_content.splitlines()
        elif resolution == 'manual_edit' and custom_content:
            resolved = custom_content.splitlines()
        else:
            return {
                "error": f"Invalid resolution or missing custom content: {resolution}",
                "hint": "Valid resolutions are: 'keep_ours', 'keep_theirs', 'merge_both', or 'manual_edit'. The last two require custom_content."
            }

        new_content = before_conflict + resolved + after_conflict
        path.write_text('\n'.join(new_content), encoding='utf-8')

        # Validate code after resolution if it's a Python file
        validation_result = None
        if file_path.endswith('.py'):
            validation_result = validate_code(file_path, 'python')
            if validation_result.get('valid') is False:
                return {
                    "warning": f"Applied {resolution} resolution to {file_path}, but code validation failed",
                    "validation_error": validation_result.get('message'),
                    "backup_path": backup_path,
                    "hint": "The conflict was resolved, but the resulting code has syntax errors. Please review and fix manually. A backup was created."
                }

        result = {"success": f"Applied {resolution} resolution to {file_path}"}
        if validation_result and validation_result.get('valid'):
            result["validation"] = "Code syntax is valid"
        if backup_path:
            result["backup_created"] = backup_path
        return result
    except Exception as e:
        return {"error": handle_error(e, "apply_conflict_resolution")}

def get_file_info(file_path: str) -> Dict[str, Any]:
    """Get information about a file."""
    if not validate_repo_path(file_path):
        return {"error": f"Invalid file path: {file_path}"}

    try:
        path = Path(file_path)
        if not path.exists():
            return {"error": f"File does not exist: {file_path}"}

        stat = path.stat()
        return {
            "path": str(path),
            "size": stat.st_size,
            "modified": stat.st_mtime,
            "is_file": path.is_file(),
            "extension": path.suffix
        }
    except Exception as e:
        return {"error": handle_error(e, "get_file_info")}

# Tool definitions for AI agent
FILE_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read the contents of a file and return formatted output, optionally limiting to specific lines.",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {"type": "string", "description": "Path to the file"},
                    "start_line": {"type": "integer", "description": "Starting line number (1-based)"},
                    "end_line": {"type": "integer", "description": "Ending line number (1-based)"}
                },
                "required": ["file_path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "create_file",
            "description": "Create a new file or overwrite an existing file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {"type": "string", "description": "Path to the file"},
                    "content": {"type": "string", "description": "Content to write"}
                },
                "required": ["file_path", "content"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Write content to a file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {"type": "string", "description": "Path to the file"},
                    "content": {"type": "string", "description": "Content to write"}
                },
                "required": ["file_path", "content"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "search_replace",
            "description": "Search and replace text in a file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {"type": "string", "description": "Path to the file"},
                    "old_string": {"type": "string", "description": "Text to replace"},
                    "new_string": {"type": "string", "description": "Replacement text"}
                },
                "required": ["file_path", "old_string", "new_string"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "validate_code",
            "description": "Validate code syntax in a file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {"type": "string", "description": "Path to the file"},
                    "language": {"type": "string", "description": "Programming language", "default": "python"}
                },
                "required": ["file_path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "analyze_conflicts",
            "description": "Analyze merge conflicts in a file and suggest resolutions.",
            "parameters": {
                "type": "object",
                "properties": {"file_path": {"type": "string", "description": "Path to the conflicting file"}},
                "required": ["file_path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "apply_conflict_resolution",
            "description": "Apply a conflict resolution to a file. Automatically creates backup and validates Python code.",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {"type": "string", "description": "Path to the file"},
                    "resolution": {"type": "string", "enum": ["keep_ours", "keep_theirs", "merge_both", "manual_edit"], "description": "Resolution type"},
                    "custom_content": {"type": "string", "description": "Custom content for merge_both or manual_edit"},
                    "create_backup": {"type": "boolean", "description": "Create backup before modifying file (default: true)"}
                },
                "required": ["file_path", "resolution"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_file_info",
            "description": "Get information about a file.",
            "parameters": {
                "type": "object",
                "properties": {"file_path": {"type": "string", "description": "Path to the file"}},
                "required": ["file_path"]
            }
        }
    }
]