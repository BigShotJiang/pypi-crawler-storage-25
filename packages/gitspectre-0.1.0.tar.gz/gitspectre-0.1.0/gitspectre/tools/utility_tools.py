"""
Utility tools for GitSpectre.
Includes Git configuration management and other helper functions.
"""

from typing import Dict, Any
from ..config import get_git_config, set_git_config
from ..utils import handle_error

def get_git_config_tool(key: str) -> Dict[str, Any]:
    """Get a Git configuration value."""
    try:
        value = get_git_config(key)
        if value is None:
            return {"error": f"Git config key '{key}' not found"}
        return {"value": value}
    except Exception as e:
        return {"error": handle_error(e, "get_git_config_tool")}

def set_git_config_tool(key: str, value: str) -> Dict[str, Any]:
    """Set a Git configuration value."""
    try:
        set_git_config(key, value)
        return {"success": f"Set Git config {key} = {value}"}
    except Exception as e:
        return {"error": handle_error(e, "set_git_config_tool")}

def list_git_configs() -> Dict[str, Any]:
    """List all Git configuration values."""
    try:
        import subprocess
        result = subprocess.run(['git', 'config', '--list'], capture_output=True, text=True, check=True, shell=False)
        configs = {}
        for line in result.stdout.splitlines():
            if '=' in line:
                k, v = line.split('=', 1)
                configs[k] = v
        return {"configs": configs}
    except Exception as e:
        return {"error": handle_error(e, "list_git_configs")}

def ask_user(question: str) -> Dict[str, Any]:
    """Ask the user a question and return their response."""
    # This tool signals the CLI to prompt the user
    return {"user_input_needed": question}

# Tool definitions for AI agent
UTILITY_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "get_git_config_tool",
            "description": "Get a Git configuration value.",
            "parameters": {
                "type": "object",
                "properties": {"key": {"type": "string", "description": "Git config key"}},
                "required": ["key"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "set_git_config_tool",
            "description": "Set a Git configuration value.",
            "parameters": {
                "type": "object",
                "properties": {
                    "key": {"type": "string", "description": "Git config key"},
                    "value": {"type": "string", "description": "Git config value"}
                },
                "required": ["key", "value"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_git_configs",
            "description": "List all Git configuration values.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "ask_user",
            "description": "Ask the user a question to get additional input.",
            "parameters": {
                "type": "object",
                "properties": {"question": {"type": "string", "description": "The question to ask the user"}},
                "required": ["question"]
            }
        }
    }
]