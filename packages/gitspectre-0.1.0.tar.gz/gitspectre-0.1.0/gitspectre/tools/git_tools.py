"""
GitPython-based tools for GitSpectre.
Provides programmatic access to Git operations via tool-callable functions.
All functions are designed to be called by the AI agent.
"""

import ast
import json
import os
from typing import List, Dict, Any, Optional
from pathlib import Path
from git import Repo, GitCommandError
from ..utils import logger, validate_repo_path, handle_error

# Suppress git hints by setting environment variables
os.environ['GIT_TERMINAL_PROMPT'] = '0'
os.environ['GIT_ASKPASS'] = 'echo'
os.environ['GIT_SSH_COMMAND'] = 'ssh -o BatchMode=yes'

def get_repo() -> Optional[Repo]:
    """Get the current Git repository instance."""
    try:
        return Repo('.')
    except Exception:
        return None

def get_repo_context(repo=None):
    """Get repository context for AI."""
    if repo is None:
        return "Not in a Git repository."
    context = f"Current branch: {repo.active_branch.name}\n"
    context += f"Status: {repo.git.status()}\n"
    try:
        context += f"Recent commits: {repo.git.log('--oneline', '-5')}\n"
    except Exception as e:
        logger.warning(f"Failed to get recent commits: {e}")
        context += "Recent commits: None\n"
    try:
        branches = repo.git.branch('-a')
        context += f"Branches: {branches}\n"
    except Exception as e:
        logger.warning(f"Failed to get branches: {e}")
        context += "Branches: Unable to fetch\n"
    return context

def get_repo_status() -> Dict[str, Any]:
    """Get the current repository status."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        status = repo.git.status(porcelain=True)
        staged = []
        unstaged = []
        untracked = []

        for line in status.split('\n'):
            if not line:
                continue
            if line.startswith('??'):
                untracked.append(line[3:])
            elif line.startswith('A ') or line.startswith('M ') or line.startswith('D '):
                staged.append(line[2:].strip())
            elif line.startswith(' M') or line.startswith(' D'):
                unstaged.append(line[2:].strip())

        return {
            "staged": staged,
            "unstaged": unstaged,
            "untracked": untracked,
            "is_dirty": repo.is_dirty(),
            "active_branch": repo.active_branch.name if repo.active_branch else None
        }
    except Exception as e:
        return {"error": handle_error(e, "get_repo_status")}

def get_branches() -> Dict[str, Any]:
    """Get all branches (local and remote)."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        logger.info("Attempting to get local branches")
        branches = [str(branch) for branch in repo.branches]
        logger.info(f"Local branches: {branches}")
        remote_branches = []
        try:
            logger.info("Attempting to get remote branches")
            remote_branches = [str(ref) for ref in repo.remote().refs]
            logger.info(f"Remote branches: {remote_branches}")
        except Exception as e:
            logger.warning(f"Failed to get remote branches: {e}")

        active = repo.active_branch.name if repo.active_branch else None
        logger.info(f"Active branch: {active}")
        return {
            "local": branches,
            "remote": remote_branches,
            "active": active
        }
    except Exception as e:
        logger.error(f"Error in get_branches: {e}")
        return {"error": handle_error(e, "get_branches")}

def switch_branch(branch_name: str) -> Dict[str, Any]:
    """Switch to a different branch."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        repo.git.checkout(branch_name)
        return {"success": f"Switched to branch {branch_name}"}
    except Exception as e:
        return {"error": handle_error(e, "switch_branch")}

def create_branch(branch_name: str) -> Dict[str, Any]:
    """Create a new branch."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        repo.git.branch(branch_name)
        return {"success": f"Created branch {branch_name}"}
    except Exception as e:
        return {"error": handle_error(e, "create_branch")}

def delete_branch(branch_name: str, force: bool = True) -> Dict[str, Any]:
    """Delete a branch."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        if force:
            repo.git.branch('-D', branch_name)
        else:
            repo.git.branch('-d', branch_name)
        return {"success": f"Deleted branch {branch_name}"}
    except Exception as e:
        return {"error": handle_error(e, "delete_branch")}

def add_files(files: List[str]) -> Dict[str, Any]:
    """Stage files for commit."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        # Validate paths
        for file in files:
            if not validate_repo_path(file):
                return {"error": f"Invalid file path: {file}"}

        repo.index.add(files)
        return {"success": f"Staged {len(files)} file(s)"}
    except Exception as e:
        return {"error": handle_error(e, "add_files")}

def create_commit(message: str, files: Optional[List[str]] = None) -> Dict[str, Any]:
    """Create a commit with optional file staging."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        # Check if we're in a merge (MERGE_HEAD exists)
        merge_head = Path(repo.working_dir) / '.git' / 'MERGE_HEAD'
        is_merge_in_progress = merge_head.exists()
        
        # If merge is in progress, we can finalize it
        if is_merge_in_progress:
            # Check if all conflicts are resolved (no UU status)
            status = repo.git.status(porcelain=True)
            has_conflicts = any(line.startswith('UU ') for line in status.split('\n'))
            
            if has_conflicts:
                return {"error": "Merge conflicts still exist. Resolve them first."}
            
            # Stage any remaining changes
            repo.index.add(['-u'])
            
            # Complete the merge commit (use message or default)
            commit_message = message if message else "Merge completed"
            commit = repo.index.commit(commit_message)
            return {"success": f"Merge commit created: {commit.hexsha[:8]}"}
        
        # Normal commit flow
        if files:
            add_result = add_files(files)
            if "error" in add_result:
                return add_result

        commit = repo.index.commit(message)
        return {"success": f"Committed {commit.hexsha[:8]}"}
    except Exception as e:
        return {"error": handle_error(e, "create_commit")}

def get_commit_history(limit: int = 10) -> Dict[str, Any]:
    """Get recent commit history."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        commits = list(repo.iter_commits('HEAD', max_count=limit))
        history = []
        for commit in commits:
            history.append({
                "hash": commit.hexsha,
                "message": commit.message.strip(),
                "author": commit.author.name,
                "date": commit.authored_datetime.isoformat()
            })
        return {"commits": history}
    except Exception as e:
        return {"error": handle_error(e, "get_commit_history")}

def merge_branch(branch_name: str) -> Dict[str, Any]:
    """Merge a branch into the current branch."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        result = repo.git.merge(branch_name)
        return {"success": f"Merged {branch_name}: {result}"}
    except GitCommandError as e:
        if "CONFLICT" in str(e):
            return {"conflict": f"Merge conflict with {branch_name}. Run resolve_conflicts."}
        return {"error": handle_error(e, "merge_branch")}
    except Exception as e:
        return {"error": handle_error(e, "merge_branch")}

def detect_conflicts() -> Dict[str, Any]:
    """Detect merge/rebase conflicts and provide statistics."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        # Check for merge head or rebase apply
        merge_head = Path(repo.working_dir) / '.git' / 'MERGE_HEAD'
        rebase_apply = Path(repo.working_dir) / '.git' / 'rebase-apply'

        if not (merge_head.exists() or rebase_apply.exists()):
            return {
                "conflicts": [],
                "statistics": {
                    "total_conflicts": 0,
                    "has_conflicts": False
                }
            }

        # Get conflicting files
        status = repo.git.status(porcelain=True)
        conflicts = [line[3:] for line in status.split('\n') if line.startswith('UU ')]

        # Gather statistics
        binary_conflicts = []
        text_conflicts = []
        total_conflict_size = 0

        for conflict_file in conflicts:
            file_path = Path(repo.working_dir) / conflict_file
            if file_path.exists():
                # Check if binary
                try:
                    from .file_tools import is_binary_file
                    if is_binary_file(str(file_path)):
                        binary_conflicts.append(conflict_file)
                    else:
                        text_conflicts.append(conflict_file)
                        # Count conflict markers for text files
                        try:
                            content = file_path.read_text(encoding='utf-8')
                            conflict_count = content.count('<<<<<<< ')
                            total_conflict_size += conflict_count
                        except Exception:
                            pass
                except Exception:
                    text_conflicts.append(conflict_file)

        statistics = {
            "total_conflicts": len(conflicts),
            "text_conflicts": len(text_conflicts),
            "binary_conflicts": len(binary_conflicts),
            "total_conflict_markers": total_conflict_size,
            "has_conflicts": len(conflicts) > 0,
            "conflict_types": {
                "text_files": text_conflicts,
                "binary_files": binary_conflicts
            }
        }

        return {
            "conflicts": conflicts,
            "statistics": statistics
        }
    except Exception as e:
        return {"error": handle_error(e, "detect_conflicts")}

def resolve_conflicts(resolutions: Dict[str, str], commit_message: Optional[str] = None, stage_only: bool = False) -> Dict[str, Any]:
    """Resolve conflicts with specified resolutions (ours/theirs/manual).
    
    Args:
        resolutions: Dict mapping file_path to resolution strategy ('ours'/'theirs'/'manual'/'merge')
        commit_message: Custom commit message (default: auto-generated based on files)
        stage_only: If True, only stage changes without committing (default: False)
    """
    repo = get_repo()
    if not repo:
        return {
            "error": "Not in a Git repository",
            "hint": "Navigate to a Git repository or use 'init_repo' to initialize one."
        }

    try:
        resolved_files = []
        for file_path, resolution in resolutions.items():
            if not validate_repo_path(file_path):
                return {
                    "error": f"Invalid file path: {file_path}",
                    "hint": "Ensure the file path is within the repository and doesn't reference parent directories."
                }

            if resolution == 'ours':
                repo.git.checkout('--ours', file_path)
            elif resolution == 'theirs':
                repo.git.checkout('--theirs', file_path)
            elif resolution == 'manual' or resolution == 'merge':
                # Assume file has been edited manually or merged
                pass
            else:
                return {
                    "error": f"Invalid resolution: {resolution}",
                    "hint": "Valid resolution strategies are: 'ours', 'theirs', 'manual', or 'merge'."
                }

            repo.git.add(file_path)
            resolved_files.append(file_path)

        if stage_only:
            return {
                "success": f"Staged {len(resolved_files)} resolved file(s)",
                "files": resolved_files,
                "hint": "Changes are staged but not committed. Use 'create_commit' to commit them."
            }

        # Generate commit message if not provided
        merge_msg_path = Path(repo.working_dir) / '.git' / 'MERGE_MSG'
        if not commit_message and merge_msg_path.exists():
            try:
                commit_message = merge_msg_path.read_text(encoding='utf-8').strip()
            except Exception:
                commit_message = None

        if not commit_message:
            if len(resolved_files) == 1:
                commit_message = f"Resolved conflicts in {resolved_files[0]}"
            else:
                commit_message = f"Resolved conflicts in {len(resolved_files)} files: {', '.join(resolved_files[:3])}{'...' if len(resolved_files) > 3 else ''}"
                
        # Validate resolved files before committing
        validation_errors = []
        for file_path in resolved_files:
            path = Path(file_path)
            if path.suffix == '.json':
                try:
                    content = path.read_text(encoding='utf-8')
                    json.loads(content)
                except json.JSONDecodeError as e:
                    validation_errors.append(f"{file_path}: Invalid JSON - {e}")
            elif path.suffix == '.py':
                try:
                    content = path.read_text(encoding='utf-8')
                    ast.parse(content)
                except SyntaxError as e:
                    validation_errors.append(f"{file_path}: Invalid Python syntax - {e}")

        if validation_errors:
            return {
                "error": "Validation failed for resolved files",
                "validation_errors": validation_errors,
                "hint": "Fix the validation errors and try committing again."
            }

        # Complete merge
        try:
            repo.git.commit('-m', commit_message, '--no-edit')
        except Exception as commit_err:
            return {"error": handle_error(commit_err, "resolve_conflicts_commit")}

        return {
            "success": "Conflicts resolved and committed",
            "commit_message": commit_message,
            "files_resolved": resolved_files
        }
    except Exception as e:
        return {"error": handle_error(e, "resolve_conflicts")}

def push_changes(remote: str = 'origin', branch: Optional[str] = None) -> Dict[str, Any]:
    """Push changes to remote."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        if not branch:
            branch = repo.active_branch.name
        repo.git.push(remote, branch)
        return {"success": f"Pushed {branch} to {remote}"}
    except Exception as e:
        return {"error": handle_error(e, "push_changes")}

def pull_changes(remote: str = 'origin', branch: Optional[str] = None) -> Dict[str, Any]:
    """Pull changes from remote."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        if not branch:
            branch = repo.active_branch.name
        result = repo.git.pull(remote, branch)
        if "CONFLICT" in result:
            return {"conflict": f"Pull resulted in conflicts on {branch}"}
        return {"success": f"Pulled from {remote}/{branch}"}
    except Exception as e:
        return {"error": handle_error(e, "pull_changes")}

def stash_changes(message: Optional[str] = None) -> Dict[str, Any]:
    """Stash current changes, including untracked files."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        if message:
            repo.git.stash('push', '-u', '-m', message)
        else:
            repo.git.stash('push', '-u')
        return {"success": "Changes stashed"}
    except Exception as e:
        return {"error": handle_error(e, "stash_changes")}

def apply_stash(index: int = 0) -> Dict[str, Any]:
    """Apply a stashed change."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        repo.git.stash('apply', f'stash@{{{index}}}')
        return {"success": f"Applied stash@{{{index}}}"}
    except Exception as e:
        return {"error": handle_error(e, "apply_stash")}

def get_diff(commit1: Optional[str] = None, commit2: Optional[str] = None) -> Dict[str, Any]:
    """Get diff between commits or working directory."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        if commit1 and commit2:
            diff = repo.git.diff(commit1, commit2)
        elif commit1:
            diff = repo.git.diff(commit1)
        else:
            diff = repo.git.diff()
        return {"diff": diff}
    except Exception as e:
        return {"error": handle_error(e, "get_diff")}

def create_tag(name: str, message: Optional[str] = None) -> Dict[str, Any]:
    """Create a Git tag."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        if message:
            repo.create_tag(name, message=message)
        else:
            repo.create_tag(name)
        return {"success": f"Created tag {name}"}
    except Exception as e:
        return {"error": handle_error(e, "create_tag")}

def reset_files(files: List[str], mode: str = 'soft') -> Dict[str, Any]:
    """Reset files to a previous state."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        if mode not in ['soft', 'mixed', 'hard']:
            return {"error": "Invalid reset mode"}

        for file in files:
            if not validate_repo_path(file):
                return {"error": f"Invalid file path: {file}"}

        repo.git.reset(mode, '--', *files)
        return {"success": f"Reset {len(files)} file(s) with {mode} mode"}
    except Exception as e:
        return {"error": handle_error(e, "reset_files")}

def abort_merge() -> Dict[str, Any]:
    """Abort an ongoing merge."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        repo.git.merge('--abort')
        return {"success": "Merge aborted"}
    except Exception as e:
        return {"error": handle_error(e, "abort_merge")}

def init_repo(path: str = '.') -> Dict[str, Any]:
    """Initialize a new Git repository."""
    try:
        Repo.init(path)
        return {"success": f"Initialized repository at {path}"}
    except Exception as e:
        return {"error": handle_error(e, "init_repo")}

def clone_repo(url: str, path: str) -> Dict[str, Any]:
    """Clone a repository."""
    try:
        Repo.clone_from(url, path)
        return {"success": f"Cloned repository to {path}"}
    except Exception as e:
        return {"error": handle_error(e, "clone_repo")}

def reset_to_remote(remote: str = 'origin', branch: str = 'main') -> Dict[str, Any]:
    """Reset current branch to match remote branch, discarding local changes."""
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        # Fetch latest from remote
        repo.git.fetch(remote)
        # Reset hard to remote branch
        repo.git.reset('--hard', f'{remote}/{branch}')
        # Clean untracked files
        repo.git.clean('-fd')
        return {"success": f"Reset to {remote}/{branch} and cleaned untracked files"}
    except Exception as e:
        return {"error": handle_error(e, "reset_to_remote")}

def run_git_command(command: str) -> Dict[str, Any]:
    """Run an arbitrary git command.
    
    This tool allows running any git command directly when a specific tool doesn't exist.
    Use this as a fallback when other tools don't cover your needs.
    
    Args:
        command: The git command to run (without 'git' prefix, e.g., 'commit -m "message"')
    """
    repo = get_repo()
    if not repo:
        return {"error": "Not in a Git repository"}

    try:
        # Security: validate the command doesn't contain dangerous operations
        dangerous_patterns = ['rm -rf', 'sudo', 'chmod 777', '|', '&&', ';', '>', '>>']
        command_lower = command.lower()
        for pattern in dangerous_patterns:
            if pattern in command_lower:
                return {"error": f"Command contains potentially dangerous pattern: {pattern}"}
        
        # Run the git command
        result = repo.git.execute(command.split())
        return {
            "success": result if result else "Command completed successfully",
            "command": f"git {command}"
        }
    except Exception as e:
        return {"error": handle_error(e, "run_git_command")}

# Tool definitions for AI agent
GIT_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "get_repo_status",
            "description": "Get the current Git repository status including staged, unstaged, and untracked files.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_branches",
            "description": "Get all local and remote branches.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "switch_branch",
            "description": "Switch to a different branch.",
            "parameters": {
                "type": "object",
                "properties": {"branch_name": {"type": "string", "description": "Name of the branch to switch to"}},
                "required": ["branch_name"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "create_branch",
            "description": "Create a new branch.",
            "parameters": {
                "type": "object",
                "properties": {"branch_name": {"type": "string", "description": "Name of the new branch"}},
                "required": ["branch_name"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "delete_branch",
            "description": "Delete a branch.",
            "parameters": {
                "type": "object",
                "properties": {
                    "branch_name": {"type": "string", "description": "Name of the branch to delete"},
                    "force": {"type": "boolean", "description": "Force delete if unmerged", "default": False}
                },
                "required": ["branch_name"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "add_files",
            "description": "Stage files for commit.",
            "parameters": {
                "type": "object",
                "properties": {"files": {"type": "array", "items": {"type": "string"}, "description": "List of file paths to stage"}},
                "required": ["files"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "create_commit",
            "description": "Create a commit with optional file staging.",
            "parameters": {
                "type": "object",
                "properties": {
                    "message": {"type": "string", "description": "Commit message"},
                    "files": {"type": "array", "items": {"type": "string"}, "description": "Optional list of files to stage before commit"}
                },
                "required": ["message"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_commit_history",
            "description": "Get recent commit history.",
            "parameters": {
                "type": "object",
                "properties": {"limit": {"type": "integer", "description": "Number of commits to retrieve", "default": 10}},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "merge_branch",
            "description": "Merge a branch into the current branch.",
            "parameters": {
                "type": "object",
                "properties": {"branch_name": {"type": "string", "description": "Name of the branch to merge"}},
                "required": ["branch_name"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "detect_conflicts",
            "description": "Detect merge/rebase conflicts and provide detailed statistics including binary vs text files, conflict counts, and conflict markers.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "resolve_conflicts",
            "description": "Resolve conflicts with specified resolutions. Can customize commit message and optionally stage without committing.",
            "parameters": {
                "type": "object",
                "properties": {
                    "resolutions": {"type": "object", "description": "Dict of file_path: resolution ('ours'/'theirs'/'manual'/'merge')"},
                    "commit_message": {"type": "string", "description": "Custom commit message (optional, auto-generated if not provided)"},
                    "stage_only": {"type": "boolean", "description": "If true, only stage changes without committing (default: false)"}
                },
                "required": ["resolutions"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "push_changes",
            "description": "Push changes to remote.",
            "parameters": {
                "type": "object",
                "properties": {
                    "remote": {"type": "string", "description": "Remote name", "default": "origin"},
                    "branch": {"type": "string", "description": "Branch name"}
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "pull_changes",
            "description": "Pull changes from remote.",
            "parameters": {
                "type": "object",
                "properties": {
                    "remote": {"type": "string", "description": "Remote name", "default": "origin"},
                    "branch": {"type": "string", "description": "Branch name"}
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "stash_changes",
            "description": "Stash current changes.",
            "parameters": {
                "type": "object",
                "properties": {"message": {"type": "string", "description": "Optional stash message"}},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "apply_stash",
            "description": "Apply a stashed change.",
            "parameters": {
                "type": "object",
                "properties": {"index": {"type": "integer", "description": "Stash index", "default": 0}},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_diff",
            "description": "Get diff between commits or working directory.",
            "parameters": {
                "type": "object",
                "properties": {
                    "commit1": {"type": "string", "description": "First commit hash"},
                    "commit2": {"type": "string", "description": "Second commit hash"}
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "create_tag",
            "description": "Create a Git tag.",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Tag name"},
                    "message": {"type": "string", "description": "Optional tag message"}
                },
                "required": ["name"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "reset_files",
            "description": "Reset files to a previous state.",
            "parameters": {
                "type": "object",
                "properties": {
                    "files": {"type": "array", "items": {"type": "string"}, "description": "List of files to reset"},
                    "mode": {"type": "string", "enum": ["soft", "mixed", "hard"], "description": "Reset mode", "default": "soft"}
                },
                "required": ["files"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "abort_merge",
            "description": "Abort an ongoing merge.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "init_repo",
            "description": "Initialize a new Git repository.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "Path to initialize repo", "default": "."}},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "clone_repo",
            "description": "Clone a repository.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {"type": "string", "description": "Repository URL"},
                    "path": {"type": "string", "description": "Local path for clone"}
                },
                "required": ["url", "path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "reset_to_remote",
            "description": "Reset current branch to match remote branch, discarding local changes and cleaning untracked files.",
            "parameters": {
                "type": "object",
                "properties": {
                    "remote": {"type": "string", "description": "Remote name", "default": "origin"},
                    "branch": {"type": "string", "description": "Branch name", "default": "main"}
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "run_git_command",
            "description": "Run an arbitrary git command directly. Use this as a fallback when specific tools don't exist or when you need direct git access.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "The git command to run (without 'git' prefix, e.g., 'commit -m \"message\"')"}
                },
                "required": ["command"]
            }
        }
    }
]