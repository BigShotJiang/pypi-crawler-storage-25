"""
AI Agent for GitSpectre.
Handles OpenRouter and Anthropic API interactions, tool calling, and conversation management.
"""

import json
import os
import re
from typing import List, Dict, Any, Optional, Union, Tuple
import requests
from yaspin import yaspin
from anthropic import Anthropic
import click

from .config import get_api_key, get_provider, get_anthropic_api_key, get_gitspectre_api_key, get_model
from .utils import logger, format_output, handle_error, run_async
from .tools.git_tools import GIT_TOOLS
from .tools.file_tools import FILE_TOOLS
from .tools.utility_tools import UTILITY_TOOLS

# Combine all tools
ALL_TOOLS = GIT_TOOLS + FILE_TOOLS + UTILITY_TOOLS


# OpenRouter configuration
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
ANTHROPIC_URL = "https://api.anthropic.com"
GITSPECTRE_URL = "http://34.30.152.8/api/chat"

# Default timeout for API calls (in seconds)
DEFAULT_API_TIMEOUT = 180
DEFAULT_GITSPECTRE_MODEL = "qwen3:8b"


class GitSpectreAgent:
    """AI Agent for Git operations with tool calling capabilities."""

    def __init__(self, repo_context: str = "", working_directory: Optional[str] = None):
        self.provider = get_provider()
        self.model = get_model()
        self.working_directory = working_directory
        self.tool_calls: List[Dict[str, Any]] = []

        if self.provider == "anthropic":
            self.api_key = get_anthropic_api_key()
            if not self.api_key:
                raise ValueError(
                    "No Anthropic API key found. Set it with 'spectre config set anthropic_api_key <key>' or run 'spectre --config'"
                )
            self.anthropic_client = Anthropic(api_key=self.api_key)
        elif self.provider == "gitspectre-qwen3-8b":
            self.api_key = get_gitspectre_api_key()
            if not self.api_key:
                raise ValueError(
                    "No GitSpectre API key found. Set it with 'spectre config set gitspectre_api_key <key>' or run 'spectre --config'"
                )
        else:
            # Default to openrouter
            self.provider = "openrouter"
            self.api_key = get_api_key()
            if not self.api_key:
                raise ValueError(
                    "No OpenRouter API key found. Set it with 'spectre config set api_key <key>' or run 'spectre --config'"
                )

        self.repo_context = repo_context
        self.conversation_history: List[Dict[str, Any]] = []
        self.last_ask_user_tool_call: Optional[Dict[str, Any]] = None
        self._load_prompt()

    def _load_prompt(self):
        """Load the system prompt from prompts.json."""
        try:
            import importlib.resources

            with (
                importlib.resources.files("gitspectre")
                .joinpath("prompts.json")
                .open("r") as f
            ):
                prompts = json.load(f)
            self.system_prompt = prompts["system_prompt"].format(
                repo_context=self.repo_context
            )
        except Exception as e:
            logger.error(f"Failed to load prompts: {e}")
            self.system_prompt = (
                "You are GitSpectre, an AI assistant for Git operations."
            )

    async def _call_api(self, messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Make an API call based on the configured provider."""
        if self.provider == "anthropic":
            return await self._call_anthropic(messages)
        elif self.provider == "gitspectre-qwen3-8b":
            return await self._call_gitspectre(messages)
        else:
            return await self._call_openrouter(messages)

    def _get_model(self) -> str:
        """Get the model based on provider."""
        if self.model:
            return self.model
        if self.provider == "anthropic":
            return "claude-sonnet-4-6"
        if self.provider == "gitspectre-qwen3-8b":
            return "qwen3:8b"
        return "nvidia/nemotron-3-nano-30b-a3b:free"

    async def _call_openrouter(self, messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Make an async call to OpenRouter API."""
        model = self._get_model()
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        data = {
            "model": model,
            "messages": messages,
            "tools": ALL_TOOLS,
            "max_tokens": 2000,
            "temperature": 0.1,
            "reasoning": {"enabled": True},
        }

        try:
            response = await run_async(
                requests.post, OPENROUTER_URL, headers=headers, json=data, timeout=DEFAULT_API_TIMEOUT
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"OpenRouter API error: {e}")
            raise

    async def _call_gitspectre(self, messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Make an async call to GitSpectre local LLM API (Ollama-compatible)."""
        model = self._get_model()
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        # Convert messages to Ollama format
        ollama_messages = []
        for msg in messages:
            role = msg.get("role")
            content = msg.get("content", "")

            if role == "system":
                ollama_messages.append({"role": "system", "content": content})

            elif role == "user":
                if isinstance(content, list):
                    # Check if this contains tool_result blocks
                    has_tool_results = any(
                        isinstance(block, dict) and block.get("type") == "tool_result"
                        for block in content
                    )
                    if has_tool_results:
                        # Convert each tool_result block to a separate tool message
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "tool_result":
                                # content must be a string for Ollama
                                raw = block.get("content", "{}")
                                if isinstance(raw, str):
                                    tool_content = raw
                                else:
                                    tool_content = json.dumps(raw)
                                ollama_messages.append({
                                    "role": "tool",
                                    "content": tool_content,
                                    "tool_call_id": block.get("tool_use_id", "")
                                })
                    else:
                        # Regular content blocks - extract text
                        content_str = ""
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "text":
                                content_str += block.get("text", "")
                        ollama_messages.append({"role": "user", "content": content_str})
                else:
                    ollama_messages.append({"role": "user", "content": content})

            elif role == "assistant":
                if isinstance(content, list):
                    text_content = ""
                    tool_calls = []
                    for block in content:
                        if isinstance(block, dict):
                            if block.get("type") == "text":
                                text_content += block.get("text", "")
                            elif block.get("type") == "tool_use":
                                # Ollama expects arguments as a dict, NOT a JSON string
                                tool_calls.append({
                                    "id": block.get("id"),
                                    "type": "function",
                                    "function": {
                                        "name": block.get("name"),
                                        "arguments": block.get("input", {})  # dict, not string
                                    }
                                })

                    ollama_msg = {"role": "assistant", "content": text_content}
                    if tool_calls:
                        ollama_msg["tool_calls"] = tool_calls
                    ollama_messages.append(ollama_msg)
                else:
                    ollama_msg = {"role": "assistant", "content": content}
                    if "tool_calls" in msg:
                        # Ensure arguments are dicts, not strings
                        normalized_tool_calls = []
                        for tc in msg["tool_calls"]:
                            if tc is not None:
                                if "function" in tc and "arguments" in tc["function"]:
                                    args = tc["function"]["arguments"]
                                    if isinstance(args, str):
                                        try:
                                            args = json.loads(args)
                                        except Exception:
                                            args = {}
                                    tc = dict(tc)
                                    tc["function"] = dict(tc["function"])
                                    tc["function"]["arguments"] = args
                                normalized_tool_calls.append(tc)
                        ollama_msg["tool_calls"] = normalized_tool_calls
                    ollama_messages.append(ollama_msg)

            elif role == "tool":
                # Already in Ollama format - ensure content is a string
                raw_content = content
                if not isinstance(raw_content, str):
                    raw_content = json.dumps(raw_content)
                ollama_messages.append({
                    "role": "tool",
                    "content": raw_content,
                    "tool_call_id": msg.get("tool_call_id", "")
                })

        data = {
            "model": model,
            "messages": ollama_messages,
            "stream": False,
            "options": {
                "temperature": 0.6
            },
            "tools": ALL_TOOLS
        }

        logger.info(f"GitSpectre API Request messages: {json.dumps(ollama_messages, indent=2)}")

        try:
            logger.info(f"Making GitSpectre API call with timeout {DEFAULT_API_TIMEOUT}s")
            response = await run_async(
                requests.post, GITSPECTRE_URL, headers=headers, json=data, timeout=DEFAULT_API_TIMEOUT
            )
            response.raise_for_status()
            result = response.json()

            logger.info(f"GitSpectre API response received successfully")

            # Convert Ollama response format to OpenRouter-like format
            # Ollama returns: {"message": {"role": "assistant", "content": "...", "tool_calls": [...]}, "done": true}
            message_data = result.get("message", {})
            converted = {
                "choices": [{
                    "message": {
                        "content": message_data.get("content", ""),
                    }
                }]
            }

            tool_calls = message_data.get("tool_calls")
            if tool_calls:
                valid_tool_calls = []
                for tc in tool_calls:
                    if tc is not None:
                        if "function" in tc and "arguments" in tc["function"]:
                            args = tc["function"]["arguments"]
                            # Normalize to string for _execute_tool which calls json.loads()
                            if not isinstance(args, str):
                                tc = dict(tc)
                                tc["function"] = dict(tc["function"])
                                tc["function"]["arguments"] = json.dumps(args)
                        valid_tool_calls.append(tc)
                if valid_tool_calls:
                    converted["choices"][0]["message"]["tool_calls"] = valid_tool_calls

            return converted

        except requests.exceptions.Timeout as e:
            logger.error(f"GitSpectre API timeout after {DEFAULT_API_TIMEOUT}s: {e}")
            raise Exception(f"GitSpectre API timed out after {DEFAULT_API_TIMEOUT} seconds. The server may be overloaded or experiencing issues.")
        except requests.exceptions.ConnectionError as e:
            logger.error(f"GitSpectre API connection error: {e}")
            raise Exception(f"Cannot connect to GitSpectre API. Please check your internet connection and try again.")
        except requests.exceptions.HTTPError as e:
            if hasattr(e.response, 'status_code') and e.response.status_code == 504:
                logger.error(f"GitSpectre API gateway timeout: {e}")
                raise Exception(f"GitSpectre API server is not responding (504 Gateway Timeout). The server may be overloaded.")
            else:
                logger.error(f"GitSpectre API HTTP error: {e}")
                raise
        except Exception as e:
            logger.error(f"GitSpectre API unexpected error: {e}")
            raise

    async def _call_anthropic(self, messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Make an async call to Anthropic API."""
        model = self._get_model()

        anthropic_messages = []
        system_content = None

        for msg in messages:
            role = msg.get("role")

            if not role:
                logger.warning(f"Skipping message without role: {msg}")
                continue

            if role == "system":
                system_content = msg.get("content", "")
            elif role == "tool":
                logger.debug("Skipping legacy tool message format")
                continue
            elif role == "assistant":
                content = msg.get("content")
                if isinstance(content, list):
                    anthropic_messages.append(msg)
                else:
                    anthropic_messages.append(
                        {
                            "role": "assistant",
                            "content": [{"type": "text", "text": content}]
                            if content
                            else [],
                        }
                    )
            elif role == "user":
                content = msg.get("content")
                if isinstance(content, list):
                    anthropic_messages.append(msg)
                else:
                    anthropic_messages.append(
                        {
                            "role": "user",
                            "content": [{"type": "text", "text": content}]
                            if content
                            else [],
                        }
                    )
            else:
                logger.warning(f"Skipping message with unknown role: {role}")

        anthropic_tools = self._convert_tools_to_anthropic(ALL_TOOLS)

        try:
            def call_anthropic():
                api_kwargs = {
                    "model": model,
                    "max_tokens": 4096,
                    "messages": anthropic_messages,
                    "tools": anthropic_tools,
                }

                if system_content:
                    api_kwargs["system"] = [
                        {
                            "type": "text",
                            "text": system_content,
                            "cache_control": {"type": "ephemeral", "ttl": "1h"},
                        }
                    ]

                api_kwargs["cache_control"] = {"type": "ephemeral"}

                return self.anthropic_client.messages.create(**api_kwargs)

            response = await run_async(call_anthropic)

            usage = response.usage
            if hasattr(usage, "cache_read_input_tokens"):
                logger.info(
                    f"Cache stats: reads={usage.cache_read_input_tokens}, "
                    f"writes={usage.cache_creation_input_tokens}, "
                    f"input={usage.input_tokens}"
                )

            return self._convert_anthropic_response(response)
        except Exception as e:
            logger.error(f"Anthropic API error: {e}")
            raise

    def _convert_anthropic_response(self, response) -> Dict[str, Any]:
        """Convert Anthropic response to OpenRouter-like format."""
        tool_calls = None
        text_content = ""

        for block in response.content:
            if block.type == "text":
                text_content += block.text
            elif block.type == "tool_use":
                tool_calls = [
                    {
                        "id": block.id,
                        "function": {
                            "name": block.name,
                            "arguments": json.dumps(block.input),
                        },
                    }
                ]

        result = {
            "choices": [
                {
                    "message": {
                        "content": text_content,
                    }
                }
            ]
        }

        if tool_calls:
            result["choices"][0]["message"]["tool_calls"] = tool_calls

        return result

    def _convert_tools_to_anthropic(self, tools: List[Dict]) -> List[Dict]:
        """Convert OpenAI-style tools to Anthropic format."""
        anthropic_tools = []
        for tool in tools:
            if "function" in tool:
                func = tool["function"]
                anthropic_tool = {
                    "name": func.get("name"),
                    "description": func.get("description", ""),
                    "input_schema": func.get(
                        "parameters", {"type": "object", "properties": {}}
                    ),
                }
                anthropic_tools.append(anthropic_tool)
        return anthropic_tools

    def _execute_tool(self, tool_call: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a tool call and return the result."""
        try:
            function_name = tool_call["function"]["name"]
            arguments = json.loads(tool_call["function"]["arguments"])

            logger.info(f"Executing tool: {function_name} with args: {arguments}")
            self.tool_calls.append({"name": function_name, "arguments": arguments})

            from .tools import git_tools, file_tools, utility_tools

            if hasattr(git_tools, function_name):
                func = getattr(git_tools, function_name)
            elif hasattr(file_tools, function_name):
                func = getattr(file_tools, function_name)
            elif hasattr(utility_tools, function_name):
                func = getattr(utility_tools, function_name)
            else:
                return {"error": f"Tool {function_name} not found"}

            old_cwd = None
            if self.working_directory:
                old_cwd = os.getcwd()
                os.chdir(self.working_directory)

            try:
                result = func(**arguments)
                return result
            finally:
                if old_cwd is not None:
                    os.chdir(old_cwd)

        except Exception as e:
            error_msg = handle_error(
                e, f"tool_{tool_call.get('function', {}).get('name', 'unknown')}"
            )
            return {"error": error_msg}

    async def _process_response(
        self, response: Dict[str, Any], spinner=None, verbose: bool = False
    ) -> Union[str, Tuple[str, str], None]:
        """Process the AI response, handle tool calls, and return final answer."""
        message = response.get("choices", [{}])[0].get("message", {})

        if message.get("tool_calls"):
            assistant_content = []
            text_content = message.get("content", "")
            if text_content:
                assistant_content.append({"type": "text", "text": text_content})

            for tool_call in message["tool_calls"]:
                if "id" not in tool_call:
                    tool_call["id"] = f"call_{tool_call['function']['name']}"

                assistant_content.append(
                    {
                        "type": "tool_use",
                        "id": tool_call["id"],
                        "name": tool_call["function"]["name"],
                        "input": json.loads(tool_call["function"]["arguments"]),
                    }
                )

            self.conversation_history.append(
                {
                    "role": "assistant",
                    "content": assistant_content,
                }
            )

            tool_results = []
            for tool_call in message["tool_calls"]:
                tool_result = self._execute_tool(tool_call)

                if tool_call["function"]["name"] == "ask_user":
                    if (
                        isinstance(tool_result, dict)
                        and "user_input_needed" in tool_result
                    ):
                        self.last_ask_user_tool_call = tool_call
                        return ("USER_INPUT_NEEDED", tool_result["user_input_needed"])

                if verbose:
                    if isinstance(tool_result, str):
                        print(format_output(tool_result, "cyan"))
                    elif isinstance(tool_result, dict):
                        if "success" in tool_result:
                            print(format_output(tool_result["success"], "green"))
                        elif "error" in tool_result:
                            print(format_output(tool_result["error"], "red"))
                        else:
                            print(format_output(str(tool_result), "cyan"))
                    else:
                        print(format_output(str(tool_result), "cyan"))

                if tool_call["function"]["name"] != "ask_user":
                    tool_results.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": tool_call["id"],
                            "content": json.dumps(tool_result),
                        }
                    )

            if tool_results:
                self.conversation_history.append(
                    {
                        "role": "user",
                        "content": tool_results,
                    }
                )

            return None

        else:
            if spinner:
                spinner.stop()
            content = message.get("content", "").strip()
            if content:
                self.conversation_history.append(
                    {
                        "role": "assistant",
                        "content": content,
                    }
                )

                content = re.sub(
                    r"\*\*(.*?)\*\*",
                    lambda m: click.style(m.group(1), bold=True),
                    content,
                )
                click.echo(content)
                return content
            else:
                print(format_output("No response from AI", "red"))
                return "No response"

    async def run_conversation(
        self, user_input: str, verbose: bool = False
    ) -> Union[str, Tuple[str, str]]:
        """Run the main conversation loop with the AI."""
        self.conversation_history = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": user_input},
        ]

        max_iterations = 50
        iteration = 0

        spinner = yaspin(color="yellow", text="Thinking...")
        spinner.start()
        try:
            while iteration < max_iterations:
                try:
                    response = await self._call_api(self.conversation_history)
                    result = await self._process_response(response, spinner, verbose)

                    if result is not None:
                        spinner.stop()
                        return result

                    iteration += 1
                    if verbose:
                        spinner.text = f"Processing... (iteration {iteration})"

                except Exception as e:
                    spinner.fail("✗")
                    error_msg = handle_error(e, "conversation_loop")
                    print(format_output(error_msg, "red"))
                    return error_msg

            spinner.fail("✗")
            print(format_output("Maximum iterations reached", "red"))
            return "Conversation timed out"
        except:
            spinner.stop()
            raise

    async def continue_conversation(
        self, user_response: str, verbose: bool = False
    ) -> Union[str, Tuple[str, str]]:
        """Continue the conversation with user response to a previous question."""
        if self.last_ask_user_tool_call:
            tool_message = {
                "role": "user",
                "content": [
                    {
                        "type": "tool_result",
                        "tool_use_id": self.last_ask_user_tool_call["id"],
                        "content": json.dumps({"user_response": user_response}),
                    }
                ],
            }
            self.conversation_history.append(tool_message)
            self.last_ask_user_tool_call = None
        else:
            self.conversation_history.append({"role": "user", "content": user_response})

        max_iterations = 50
        iteration = 0

        spinner = yaspin(color="yellow", text="Thinking...")
        spinner.start()
        try:
            while iteration < max_iterations:
                try:
                    response = await self._call_api(self.conversation_history)
                    result = await self._process_response(response, spinner, verbose)

                    if result is not None:
                        spinner.stop()
                        return result

                    iteration += 1
                    if verbose:
                        spinner.text = f"Processing... (iteration {iteration})"

                except Exception as e:
                    spinner.fail("✗")
                    error_msg = handle_error(e, "conversation_loop")
                    print(format_output(error_msg, "red"))
                    return error_msg

            spinner.fail("✗")
            print(format_output("Maximum iterations reached", "red"))
            return "Conversation timed out"
        except:
            spinner.stop()
            raise


async def run_agent(
    user_input: str, repo_context: str = "", verbose: bool = False
) -> Union[str, Tuple[str, str]]:
    """Convenience function to run the agent."""
    try:
        agent = GitSpectreAgent(repo_context)
        return await agent.run_conversation(user_input, verbose)
    except Exception as e:
        return handle_error(e, "run_agent")