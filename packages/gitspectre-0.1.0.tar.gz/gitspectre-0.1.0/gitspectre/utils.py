"""
Utility functions for GitSpectre.
Includes logging, validation, async helpers, and security checks.
"""

import asyncio
import logging
from pathlib import Path
from colorama import init, Fore, Style

# Import config first
from .config import CONFIG_DIR, ensure_config_dir

# Ensure config directory exists
ensure_config_dir()

# Initialize colorama for cross-platform colored output
init(autoreset=True)

logger = logging.getLogger("gitspectre")


def setup_logging(verbose: bool = False):
    """Setup logging configuration."""
    level = logging.INFO if verbose else logging.ERROR
    logger = logging.getLogger("gitspectre")
    logger.setLevel(level)

    # Clear existing handlers to avoid duplicates
    logger.handlers.clear()

    # Console handler for user-facing output
    console = logging.StreamHandler()
    console.setLevel(level)
    formatter = logging.Formatter("%(levelname)s: %(message)s")
    console.setFormatter(formatter)
    logger.addHandler(console)

    # File handler for persistent logs
    file_handler = logging.FileHandler(CONFIG_DIR / "gitspectre.log")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    )
    logger.addHandler(file_handler)

    # Suppress third-party logging
    httpx_level = logging.INFO if verbose else logging.WARNING
    for lib in ["httpx", "urllib3", "httpcore", "anthropic"]:
        logging.getLogger(lib).setLevel(httpx_level)


def validate_repo_path(repo_path: str) -> bool:
    """Validate that a path is within the current Git repository."""
    try:
        from git import Repo

        repo = Repo(".")
        repo_root = Path(repo.working_dir).resolve()

        # Handle both absolute and relative paths
        if Path(repo_path).is_absolute():
            repo_path_obj = Path(repo_path).resolve()
        else:
            repo_path_obj = (repo_root / repo_path).resolve()

        return repo_path_obj.is_relative_to(repo_root)
    except Exception:
        return False


def sanitize_command(command: str) -> str:
    """Sanitize shell command to prevent dangerous operations."""
    dangerous_commands = ["rm -rf", "sudo", "chmod 777", "format", "fdisk"]
    for dangerous in dangerous_commands:
        if dangerous in command.lower():
            raise ValueError(f"Dangerous command detected: {dangerous}")
    return command


def format_output(message: str, color: str = "white", bold: bool = False) -> str:
    """Format output with colors and styles."""
    color_map = {
        "red": Fore.RED,
        "green": Fore.GREEN,
        "blue": Fore.BLUE,
        "yellow": Fore.YELLOW,
        "cyan": Fore.CYAN,
        "white": Fore.WHITE,
    }
    style = Style.BRIGHT if bold else ""
    return f"{color_map.get(color, Fore.WHITE)}{style}{message}"


async def run_async(func, *args, **kwargs):
    """Run a synchronous function asynchronously."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, lambda: func(*args, **kwargs))


def handle_error(error: Exception, context: str = "") -> str:
    """Handle and log errors, return user-friendly message."""
    logger.error(f"Error in {context}: {str(error)}")
    return f"An error occurred: {str(error)}. Check logs for details."
