"""
Command-line interface for GitSpectre.
Handles user input, configuration, and orchestrates AI agent interactions.
"""

import asyncio
import click
from git import Repo

from typing import Optional

from .config import (
    set_config,
    get_api_key,
    unset_config,
    get_config,
    get_provider,
    get_anthropic_api_key,
    get_gitspectre_api_key,
)
from .agent import GitSpectreAgent
from .tools.git_tools import get_repo_context
from .utils import setup_logging, logger


def show_config_menu():
    """Display interactive configuration menu."""
    while True:
        click.echo()
        title = "GitSpectre Configuration Menu"
        width = 35
        padded = title.center(width)
        click.secho(f"╔{'═' * width}╗", fg="cyan", bold=True)
        click.secho(f"║{padded}║", fg="cyan", bold=True)
        click.secho(f"╚{'═' * width}╝", fg="cyan", bold=True)
        click.echo()

        # Get current config to show status
        current_config = get_config()
        provider = current_config.get("provider", "openrouter")

        # Show API key status based on provider
        if provider == "anthropic":
            key_status = (
                "✓ Set" if current_config.get("anthropic_api_key") else "✗ Not Set"
            )
        elif provider == "gitspectre-qwen3-8b":
            key_status = (
                "✓ Set" if current_config.get("gitspectre_api_key") else "✗ Not Set"
            )
        else:
            key_status = "✓ Set" if current_config.get("api_key") else "✗ Not Set"

        model_status = current_config.get("model", "default")
        verbose_status = "ON" if current_config.get("verbose") == "true" else "OFF"

        click.secho(f"  Provider: {provider}", fg="yellow")
        click.secho(f"  API Key: {key_status}", fg="yellow")
        click.secho(f"  Model: {model_status}", fg="yellow")
        click.secho(f"  Verbose: {verbose_status}", fg="yellow")
        click.echo()

        click.echo("  1. Set API Key")
        click.echo("  2. View API Key")
        click.echo("  3. Unset API Key")
        click.echo("  4. Set Provider")
        click.echo("  5. Set Model")
        click.echo("  6. Verbose On")
        click.echo("  7. Verbose Off")
        click.echo("  8. Exit")
        click.echo()

        try:
            choice = click.prompt("Select an option", type=int, default=8)
        except (click.Abort, EOFError, KeyboardInterrupt):
            click.echo()
            click.secho("Configuration cancelled.", fg="yellow")
            return

        click.echo()

        if choice == 1:
            # Set API Key - prompt for the right key based on provider
            provider = get_provider()
            if provider == "anthropic":
                prompt_msg = "Enter your Anthropic API key"
                key_name = "Anthropic"
                config_key = "anthropic_api_key"
            elif provider == "gitspectre-qwen3-8b":
                prompt_msg = "Enter your GitSpectre API key"
                key_name = "GitSpectre"
                config_key = "gitspectre_api_key"
            else:
                prompt_msg = "Enter your OpenRouter API key"
                key_name = "OpenRouter"
                config_key = "api_key"

            try:
                api_key = click.prompt(prompt_msg, type=str)
                if api_key.strip():
                    set_config(config_key, api_key.strip())
                    click.secho(f"✓ {key_name} API key set!", fg="green", bold=True)
                else:
                    click.secho("✗ API key cannot be empty.", fg="red")
            except (click.Abort, EOFError, KeyboardInterrupt):
                click.echo()
                click.secho("Operation cancelled.", fg="yellow")

        elif choice == 2:
            # View API Key - show based on provider
            provider = get_provider()
            if provider == "anthropic":
                api_key = get_anthropic_api_key()
                key_name = "Anthropic"
            elif provider == "gitspectre-qwen3-8b":
                api_key = get_gitspectre_api_key()
                key_name = "GitSpectre"
            else:
                api_key = get_api_key()
                key_name = "OpenRouter"

            if api_key:
                if len(api_key) > 20:
                    masked_key = f"{api_key[:10]}...{api_key[-4:]}"
                else:
                    masked_key = (
                        api_key[:4] + "..." + api_key[-4:]
                        if len(api_key) > 8
                        else "***"
                    )

                click.secho(f"  {key_name} API Key: {masked_key}", fg="cyan")
                click.echo()

                show_full = click.confirm("Reveal full key?", default=False)
                if show_full:
                    click.secho(f"  {api_key}", fg="yellow", bold=True)
                    click.secho("  ⚠ Keep this secret!", fg="red")
            else:
                click.secho(f"No {key_name} API key set.", fg="yellow")

        elif choice == 3:
            # Unset API Key - unset based on provider
            provider = get_provider()
            if provider == "anthropic":
                key_name = "Anthropic"
                config_key = "anthropic_api_key"
            elif provider == "gitspectre-qwen3-8b":
                key_name = "GitSpectre"
                config_key = "gitspectre_api_key"
            else:
                key_name = "OpenRouter"
                config_key = "api_key"

            try:
                if current_config.get(config_key):
                    confirm = click.confirm(f"Remove {key_name} API key?")
                    if confirm:
                        unset_config(config_key)
                        click.secho(
                            f"✓ {key_name} API key removed.", fg="green", bold=True
                        )
                    else:
                        click.secho("Cancelled.", fg="yellow")
                else:
                    click.secho(f"No {key_name} API key set.", fg="yellow")
            except ValueError:
                click.secho(f"No {key_name} API key set.", fg="yellow")
            except (click.Abort, EOFError, KeyboardInterrupt):
                click.echo()
                click.secho("Operation cancelled.", fg="yellow")

        elif choice == 4:
            # Set Provider
            try:
                click.echo("Available providers:")
                click.echo("  openrouter       - Use OpenRouter (many models, free options)")
                click.echo("  anthropic        - Use Latest claude models for best results")
                click.echo("  gitspectre-qwen3-8b - Use local GitSpectre LLM ")
                click.echo()
                provider = click.prompt(
                    "Enter provider", type=str, default="openrouter"
                )
                if provider.strip() in ["openrouter", "anthropic", "gitspectre-qwen3-8b"]:
                    # Clear old model when switching providers
                    if current_config.get("model"):
                        unset_config("model")
                    set_config("provider", provider.strip())
                    click.secho(f"✓ Provider set to {provider}!", fg="green", bold=True)

                    # Prompt for API key if switching to a provider without a key
                    if provider == "anthropic" and not get_anthropic_api_key():
                        click.echo()
                        try:
                            api_key = click.prompt(
                                "Enter your Anthropic API key", type=str
                            )
                            if api_key.strip():
                                set_config("anthropic_api_key", api_key.strip())
                                click.secho(
                                    "✓ Anthropic API key set!", fg="green", bold=True
                                )
                        except (click.Abort, EOFError, KeyboardInterrupt):
                            click.echo()
                    elif provider == "gitspectre-qwen3-8b" and not get_gitspectre_api_key():
                        click.echo()
                        try:
                            api_key = click.prompt(
                                "Enter your GitSpectre API key", type=str
                            )
                            if api_key.strip():
                                set_config("gitspectre_api_key", api_key.strip())
                                click.secho(
                                    "✓ GitSpectre API key set!", fg="green", bold=True
                                )
                        except (click.Abort, EOFError, KeyboardInterrupt):
                            click.echo()
                else:
                    click.secho("✗ Invalid provider.", fg="red")
            except (click.Abort, EOFError, KeyboardInterrupt):
                click.echo()
                click.secho("Operation cancelled.", fg="yellow")

        elif choice == 5:
            # Set Model
            try:
                provider = get_provider()
                if provider == "anthropic":
                    click.echo("Anthropic models:")
                    click.echo("  claude-sonnet-4-6 (default)")
                    click.echo("  claude-opus-4-6")
                    click.echo("  claude-3-5-sonnet-20240620")
                elif provider == "gitspectre-qwen3-8b":
                    click.echo("GitSpectre models:")
                    click.echo("  qwen3:8b (default)")
                else:
                    click.echo("OpenRouter models:")
                    click.echo("  nvidia/nemotron-3-nano-30b-a3b:free (default)")
                    click.echo("  anthropic/claude-3.5-sonnet")
                click.echo()
                model = click.prompt("Enter model name", type=str)
                if model.strip():
                    set_config("model", model.strip())
                    click.secho(f"✓ Model set to {model}!", fg="green", bold=True)
            except (click.Abort, EOFError, KeyboardInterrupt):
                click.echo()
                click.secho("Operation cancelled.", fg="yellow")

        elif choice == 6:
            set_config("verbose", "true")
            click.secho("✓ Verbose mode enabled!", fg="green", bold=True)

        elif choice == 7:
            set_config("verbose", "false")
            click.secho("✓ Verbose mode disabled!", fg="green", bold=True)

        elif choice == 8:
            break

        else:
            click.secho("Invalid option.", fg="red")

        click.echo()
        if choice in [1, 2, 3, 4, 5, 6, 7]:
            continue_menu = click.confirm("More settings?", default=True)
            if not continue_menu:
                click.secho("Exiting.", fg="cyan")
                break


@click.command(
    epilog="Example: spectre create a new branch and move my current work there"
)
@click.option("--config", is_flag=True, help="Open interactive configuration menu.")
@click.argument("message", nargs=-1, required=False)
@click.pass_context
def cli(ctx, config, message):
    """GitSpectre: AI-powered Git CLI tool."""
    # Check if verbose is set in config (for global verbose mode)
    from .config import get_config

    config_data = get_config()
    verbose = config_data.get("verbose") == "true"

    setup_logging(verbose)

    # Handle --config flag for interactive menu
    if config:
        show_config_menu()
        return

    # If no subcommand and no command, show help
    if ctx.invoked_subcommand is None:
        # Always start interactive chat mode
        # If a message was provided, use it as the first input
        first_input = " ".join(message) if message else None
        run_interactive_chat(verbose, first_input)
        return


def _check_api_key():
    """Check if API key is set for current provider."""
    provider = get_provider()
    if provider == "anthropic":
        if not get_anthropic_api_key():
            click.secho(
                "No Anthropic API key found. Run 'spectre --config' to set it.",
                fg="red",
            )
            click.secho("Get a key from: https://console.anthropic.com/", fg="blue")
            return False
    elif provider == "gitspectre-qwen3-8b":
        if not get_gitspectre_api_key():
            click.secho(
                "No GitSpectre API key found. Run 'spectre --config' to set it.",
                fg="red",
            )
            return False
    else:
        if not get_api_key():
            click.secho(
                "No OpenRouter API key found. Run 'spectre --config' to set it.",
                fg="red",
            )
            click.secho("Get a key from: https://openrouter.ai/", fg="blue")
            return False
    return True


def _get_repo_context():
    """Get repository context."""
    try:
        repo = Repo(".")
        return get_repo_context(repo)
    except Exception as e:
        logger.warning(f"Failed to get repository context: {e}")
        return "Not in a Git repository."


def _run_single_command(user_input: str, verbose: bool):
    """Run a single command and exit."""
    if not _check_api_key():
        return

    repo_context = _get_repo_context()

    async def run():
        agent = GitSpectreAgent(repo_context)
        result = await agent.run_conversation(user_input, verbose)

        while isinstance(result, tuple) and result[0] == "USER_INPUT_NEEDED":
            question = result[1]
            click.secho(f"\n{question}", fg="cyan")
            user_response = input("> ").strip()
            if not user_response:
                click.secho("No input provided. Cancelling.", fg="yellow")
                return
            result = await agent.continue_conversation(user_response, verbose)

    asyncio.run(run())


def _process_chat_input(agent, user_input: str, verbose: bool):
    """Process a single chat input and display the response."""

    async def run_chat():
        result = await agent.run_conversation(user_input, verbose)

        # Handle user input needed
        while isinstance(result, tuple) and result[0] == "USER_INPUT_NEEDED":
            question = result[1]
            click.secho(f"\n{question}", fg="cyan")
            try:
                user_response = input("> ").strip()
                if not user_response:
                    click.secho("No input provided.", fg="yellow")
                    break
                result = await agent.continue_conversation(user_response, verbose)
            except (EOFError, KeyboardInterrupt):
                click.echo()
                break

    asyncio.run(run_chat())
    click.echo()


def run_interactive_chat(verbose: bool, first_input: Optional[str] = None):
    """Start an interactive chat session."""
    if not _check_api_key():
        return

    repo_context = _get_repo_context()

    # Create agent once, reuse for all messages
    agent = GitSpectreAgent(repo_context)

    # Track last exchange for compact view
    last_user_input = None
    last_response = None

    def show_compact_header():
        """Show compact header with last exchange."""
        import os

        os.system("cls" if os.name == "nt" else "clear")
        title = "GitSpectre Chat!"
        width = 39
        padded = title.center(width)
        click.secho(f"╔{'═' * width}╗", fg="cyan", bold=True)
        click.secho(f"║{padded}║", fg="cyan", bold=True)
        click.secho(f"╚{'═' * width}╝", fg="cyan", bold=True)
        click.echo()

        # Show last exchange if exists
        if last_user_input and last_response:
            click.secho(f"You: {last_user_input}", fg="yellow")
            click.echo()
            # Show full response (no truncation)
            for line in last_response.split("\n"):
                click.echo(line)
            click.echo()
            click.secho("─" * 40, fg="cyan")
            click.echo()

    # Show initial welcome banner
    show_compact_header()

    # If first_input was provided, process it first
    if first_input:
        last_user_input = first_input

        async def run_first():
            nonlocal last_response
            result = await agent.run_conversation(first_input, verbose)

            # Handle user input needed
            while isinstance(result, tuple) and result[0] == "USER_INPUT_NEEDED":
                question = result[1]
                click.secho(f"\n{question}", fg="cyan")
                user_response = input("> ").strip()
                if not user_response:
                    click.secho("No input provided. Cancelling.", fg="yellow")
                    return
                result = await agent.continue_conversation(user_response, verbose)

            last_response = result if isinstance(result, str) else str(result)

        asyncio.run(run_first())
        show_compact_header()

    while True:
        try:
            prompt = click.style("You", fg="green", bold=True) + "> "
            user_input = input(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            click.echo()
            click.secho("Goodbye!", fg="cyan")
            break

        if not user_input:
            continue

        # Check for exit commands
        if user_input.lower() in ["exit", "quit", "q"]:
            click.secho("Goodbye!", fg="cyan")
            break

        # Check for help
        if user_input.lower() == "help":
            click.echo("Commands:")
            click.echo("  exit, quit, q  - End the session")
            click.echo("  help           - Show this help")
            click.echo()
            click.echo("Examples:")
            click.echo("  create a new branch called feature")
            click.echo("  show me the recent commits")
            click.echo("  what's the current status?")
            click.echo()
            continue

        # Store user input before processing
        last_user_input = user_input

        # Run the command
        async def run_chat():
            nonlocal last_response
            result = await agent.run_conversation(user_input, verbose)

            # Handle user input needed
            while isinstance(result, tuple) and result[0] == "USER_INPUT_NEEDED":
                question = result[1]
                click.secho(f"\n{question}", fg="cyan")
                try:
                    user_response = input("> ").strip()
                    if not user_response:
                        click.secho("No input provided.", fg="yellow")
                        break
                    result = await agent.continue_conversation(user_response, verbose)
                except (EOFError, KeyboardInterrupt):
                    click.echo()
                    break

            last_response = result if isinstance(result, str) else str(result)

        asyncio.run(run_chat())

        # Show compact header for next input
        show_compact_header()


if __name__ == "__main__":
    cli.main()
