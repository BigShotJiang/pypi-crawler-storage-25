"""
Configuration management for GitSpectre.
Handles loading API keys, Git configs, and application settings.
"""


import json
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file if present
load_dotenv()

# Configuration paths
CONFIG_DIR = Path.home() / '.gitspectre'
CONFIG_FILE = CONFIG_DIR / 'config.json'

def ensure_config_dir():
    """Ensure the configuration directory exists."""
    CONFIG_DIR.mkdir(exist_ok=True)

def get_config():
    """Load configuration from JSON file."""
    ensure_config_dir()
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text('{}')
    with open(CONFIG_FILE, 'r') as f:
        return json.load(f)

def set_config(key, value):
    """Set a configuration key-value pair."""
    config = get_config()
    config[key] = value
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)

def unset_config(key):
    """Unset a configuration key."""
    config = get_config()
    if key in config:
        del config[key]
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
    else:
        raise ValueError(f"Key '{key}' not found")

def get_api_key():
    """Get the OpenRouter API key from config."""
    return get_config().get('api_key')

def get_provider():
    """Get the AI provider from config (openrouter, anthropic, or gitspectre-qwen3-8b)."""
    return get_config().get('provider', 'openrouter')

def get_anthropic_api_key():
    """Get the Anthropic API key from config."""
    return get_config().get('anthropic_api_key')

def get_gitspectre_api_key():
    """Get the GitSpectre API key from config."""
    return get_config().get('gitspectre_api_key')

def get_model():
    """Get the model to use from config. Returns None if not set."""
    model = get_config().get('model')
    if model and model != 'default':
        return model
    return None

def get_git_config(key):
    """Get a Git configuration value."""
    import subprocess
    try:
        result = subprocess.run(['git', 'config', '--get', key],
                              capture_output=True, text=True, check=True,
                              shell=False)
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        return None

def set_git_config(key, value):
    """Set a Git configuration value."""
    import subprocess
    subprocess.run(['git', 'config', key, value], check=True, shell=False)