#!/usr/bin/env python3
"""
XYZ CLI Tool - API-based Vulnerability Scanner
Unified command-line interface for vulnerability scanning via XYZ API
"""

import os
import re
import sys

# Windows defaults stdout/stderr to cp1252, which can't encode characters like
# `→` (U+2192) that appear in our setup output. Force UTF-8 on Windows so the
# CLI is portable across shells (cmd.exe, PowerShell, Git Bash, MSYS). No-op
# on macOS/Linux where UTF-8 is already the default.
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        # Older Python (<3.7) or non-stream stdout (e.g. captured) — fall back
        # silently; the chars that broke us only appear in interactive output.
        pass

import atexit
import json
import shutil
import socket
import platform
import subprocess
import stat
import click
import requests as _requests
from importlib import metadata as _pkg_metadata
from typing import Optional, List, Dict, Any
from tabulate import tabulate
from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich.text import Text
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from xyz_cli.client import XYZAPIClient


def _cli_version() -> str:
    try:
        return _pkg_metadata.version("cyberxyz-scanner")
    except _pkg_metadata.PackageNotFoundError:
        return "unknown"

# Initialize Rich console for better formatting
console = Console()

# Global client instance
client = None

def _get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None

def _detect_ci_machine_name():
    """If we're running inside a known CI environment, return a stable
    machine_name derived from the platform's repo / runner identifiers.

    This lets the dashboard show ado/<repo>/<agent_id> instead of the
    Microsoft-auto-named runnervmXXXXXX hostname, and similarly attributes
    GitHub Actions runs to <gha/<owner-repo>/<runner_name> instead of the
    fv-az-XXX hostname.

    Returns None when not in a recognized CI env so the caller falls back
    to the OS hostname (current behaviour).
    """
    # Azure DevOps Pipelines sets these on every hosted + self-hosted run.
    # Build.Repository.Name \u2192 BUILD_REPOSITORY_NAME (project name in the
    # ADO org); Agent.Id \u2192 AGENT_ID (numeric, stable per agent registration).
    ado_repo  = os.environ.get("BUILD_REPOSITORY_NAME")
    ado_agent = os.environ.get("AGENT_ID") or os.environ.get("AGENT_NAME")
    if ado_repo:
        repo_clean = ado_repo.strip().replace(" ", "-")
        return f"ado/{repo_clean}/agent-{(ado_agent or 'unknown').strip()}"

    # GitHub Actions sets GITHUB_REPOSITORY=<owner>/<repo> + RUNNER_NAME on
    # every workflow run, both hosted and self-hosted.
    gha_repo   = os.environ.get("GITHUB_REPOSITORY")
    gha_runner = os.environ.get("RUNNER_NAME")
    if gha_repo:
        return f"gha/{gha_repo.strip()}/{(gha_runner or 'runner').strip()}"

    return None


def get_computer_name():
    # Prefer the CI-aware name when running inside ADO / GitHub Actions so
    # the dashboard's Environments page can attribute the run back to a
    # specific repo + pipeline rather than show Microsoft's opaque
    # `runnervmXXXXXX` / GitHub's `fv-az-XXX` auto-hostnames.
    ci_name = _detect_ci_machine_name()
    if ci_name:
        return ci_name

    system = platform.system()
    if system == "Darwin":
        try:
            name = subprocess.check_output(['scutil', '--get', 'ComputerName']).decode().strip()
        except Exception:
            name = platform.node()
    elif system == "Windows":
        name = platform.node()
    else:
        name = socket.gethostname()
    # Normalize smart quotes to ASCII so machine_name is consistent
    return (name.replace('\u2018', "'").replace('\u2019', "'")
                .replace('\u201c', '"').replace('\u201d', '"'))

# Holds the cli_scans.id returned by the most recent audit upload, keyed by
# scan_type ('npm_audit' | 'python' | 'go_audit'). The daemon reads this
# after invoking an audit subcommand so it can report the cli_scan_id back
# to the platform via /proxy/jobs/{id}/complete. Module-level (not ctx.obj)
# because audit subcommands don't share a ctx with the daemon entry-point.
_LAST_AUDIT_SCAN_ID: Dict[str, Optional[int]] = {}

# Tracks the job currently being executed by `xyz proxy daemon` so we can
# best-effort post a `failed` /complete if the daemon process dies before
# reporting completion (SIGTERM, parent shell close, unhandled exit). Without
# this finalizer, a killed daemon leaks the row in `claimed` status until
# sweep_expired_scan_jobs() runs ~15 min later. Set when daemon starts work,
# cleared once /complete returns.
_DAEMON_ACTIVE_JOB: Optional[Dict[str, Any]] = None


def _atexit_finalize_active_job() -> None:
    """Best-effort finalizer for an in-flight daemon job. Fires on Python
    interpreter shutdown (normal exit, SystemExit, SIGTERM, KeyboardInterrupt
    that propagated past click). Does NOT fire on SIGKILL — that's the
    server-side sweep's job. Swallows all errors; this runs at shutdown."""
    job = _DAEMON_ACTIVE_JOB
    if not job:
        return
    try:
        _requests.post(
            f"{job['api_url']}/api/v1/proxy/jobs/{job['job_id']}/complete",
            headers=job['headers'],
            json={
                'status': 'failed',
                'error_message': 'daemon process exited before job completion',
            },
            timeout=5,
        )
    except Exception:
        pass


atexit.register(_atexit_finalize_active_job)


_LAUNCHD_LABEL = "com.cyberxyz.proxy-daemon"
_LAUNCHD_PLIST_PATH = os.path.expanduser(f"~/Library/LaunchAgents/{_LAUNCHD_LABEL}.plist")
_LAUNCHD_LOG_PATH = os.path.expanduser("~/Library/Logs/cyberxyz-proxy-daemon.log")
_LAUNCHD_ERR_PATH = os.path.expanduser("~/Library/Logs/cyberxyz-proxy-daemon-error.log")


def _handle_service_install(install: bool) -> None:
    """Cross-platform dispatcher for the daemon auto-start installer.

    Each platform writes the right OS-native unit so `xyz proxy daemon`
    starts at login and restarts on crash:

      * macOS:   ~/Library/LaunchAgents/com.cyberxyz.proxy-daemon.plist (launchd)
      * Linux:   ~/.config/systemd/user/cyberxyz-proxy-daemon.service (systemd --user)
      * Windows: scheduled task "CyberXYZProxyDaemon" via schtasks (Task Scheduler)

    Auto-start is the production path: the daemon needs to be alive to
    respond to admin-triggered Scan Now clicks. Manual `xyz proxy daemon`
    works but is easy to forget after a reboot.
    """
    if sys.platform == "darwin":
        _handle_launchd_install(install)
    elif sys.platform.startswith("linux"):
        _handle_systemd_install(install)
    elif sys.platform == "win32":
        _handle_taskscheduler_install(install)
    else:
        console.print(f"[red]--install-service: unsupported platform {sys.platform!r}.[/red]")
        sys.exit(1)


def _handle_launchd_install(install: bool) -> None:
    """Write or remove the macOS LaunchAgent that runs `xyz proxy daemon`
    at every login. KeepAlive=true so launchd restarts it if it crashes.
    """
    if sys.platform != "darwin":
        console.print("[red]--install-launchd is macOS-only.[/red] Use "
                      "--install-service for the cross-platform alias.")
        sys.exit(1)

    # Always uninstall first so re-install is idempotent.
    if os.path.exists(_LAUNCHD_PLIST_PATH):
        try:
            subprocess.run(
                ["launchctl", "unload", _LAUNCHD_PLIST_PATH],
                check=False, capture_output=True, timeout=10,
            )
        except (subprocess.SubprocessError, OSError):
            pass
        try:
            os.remove(_LAUNCHD_PLIST_PATH)
        except OSError:
            pass

    if not install:
        console.print(f"[green]✅ LaunchAgent removed:[/green] {_LAUNCHD_PLIST_PATH}")
        return

    xyz_path = shutil.which("xyz") or sys.argv[0]
    if not os.path.isabs(xyz_path):
        console.print(f"[red]Could not resolve absolute path to `xyz` (got {xyz_path}).[/red]")
        console.print("   Re-run from a shell where `which xyz` returns an absolute path.")
        sys.exit(1)

    home = os.path.expanduser("~")
    plist_xml = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
        '<plist version="1.0">\n'
        '<dict>\n'
        f'    <key>Label</key>\n    <string>{_LAUNCHD_LABEL}</string>\n'
        '    <key>ProgramArguments</key>\n'
        '    <array>\n'
        f'        <string>{xyz_path}</string>\n'
        '        <string>proxy</string>\n'
        '        <string>daemon</string>\n'
        '    </array>\n'
        '    <key>RunAtLoad</key>\n    <true/>\n'
        '    <key>KeepAlive</key>\n    <true/>\n'
        '    <key>ProcessType</key>\n    <string>Background</string>\n'
        # WorkingDirectory: where the daemon (and its `xyz audit`
        # subprocesses) start CWD. Default launchd cwd is /, which means
        # `npm ls` / `pipdeptree` find nothing. Use the user's home so
        # the daemon at least sits in a meaningful location, and audits
        # can be scoped to actual project dirs by passing scan_type via
        # the admin trigger.
        f'    <key>WorkingDirectory</key>\n    <string>{home}</string>\n'
        f'    <key>StandardOutPath</key>\n    <string>{_LAUNCHD_LOG_PATH}</string>\n'
        f'    <key>StandardErrorPath</key>\n    <string>{_LAUNCHD_ERR_PATH}</string>\n'
        '    <key>EnvironmentVariables</key>\n'
        '    <dict>\n'
        f'        <key>HOME</key>\n        <string>{home}</string>\n'
        f'        <key>PATH</key>\n        <string>{os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin")}</string>\n'
        # Without PYTHONUNBUFFERED=1, Python block-buffers stdout when
        # writing to a file (StandardOutPath). The daemon's
        # `console.print` calls would queue up and never appear in the
        # log until the process exits — making the launchd-spawned
        # daemon look frozen.
        '        <key>PYTHONUNBUFFERED</key>\n        <string>1</string>\n'
        '    </dict>\n'
        '</dict>\n'
        '</plist>\n'
    )

    os.makedirs(os.path.dirname(_LAUNCHD_PLIST_PATH), exist_ok=True)
    with open(_LAUNCHD_PLIST_PATH, "w") as f:
        f.write(plist_xml)
    os.chmod(_LAUNCHD_PLIST_PATH, 0o644)

    result = subprocess.run(
        ["launchctl", "load", _LAUNCHD_PLIST_PATH],
        capture_output=True, text=True, timeout=10,
    )
    if result.returncode != 0:
        console.print(f"[red]launchctl load failed:[/red] {result.stderr.strip()}")
        sys.exit(1)

    console.print(f"[green]✅ LaunchAgent installed:[/green] {_LAUNCHD_PLIST_PATH}")
    console.print(f"   Daemon will auto-start at every login.")
    console.print(f"   Logs:   {_LAUNCHD_LOG_PATH}")
    console.print(f"   Errors: {_LAUNCHD_ERR_PATH}")
    console.print(f"   Status: launchctl list | grep {_LAUNCHD_LABEL}")
    console.print(f"   To remove later: xyz proxy daemon --uninstall-launchd")


# ---------------------------------------------------------------------------
# Linux systemd --user unit (1.4.10+)
# ---------------------------------------------------------------------------

_SYSTEMD_UNIT_NAME = "cyberxyz-proxy-daemon.service"
_SYSTEMD_UNIT_PATH = os.path.expanduser(f"~/.config/systemd/user/{_SYSTEMD_UNIT_NAME}")
_SYSTEMD_LOG_DIR  = os.path.expanduser("~/.local/state/cyberxyz-proxy-daemon")


def _handle_systemd_install(install: bool) -> None:
    """Write or remove a `systemd --user` unit so `xyz proxy daemon` starts
    at every login + restarts on crash. User-scoped (no root). Logs go to
    journalctl --user; we also tee stdout to ~/.local/state/cyberxyz-proxy-daemon.log
    via the unit's StandardOutput= file:... directive.
    """
    if not sys.platform.startswith("linux"):
        console.print("[red]--install-service on Linux only.[/red]")
        sys.exit(1)

    if not shutil.which("systemctl"):
        console.print("[red]systemctl not found — this distro doesn't ship systemd.[/red]")
        console.print("   Run `xyz proxy daemon` under your init system manually "
                      "(supervisord, runit, or `nohup ... &`).")
        sys.exit(1)

    # Idempotent uninstall first.
    if os.path.exists(_SYSTEMD_UNIT_PATH):
        subprocess.run(["systemctl", "--user", "stop", _SYSTEMD_UNIT_NAME],
                       check=False, capture_output=True, timeout=10)
        subprocess.run(["systemctl", "--user", "disable", _SYSTEMD_UNIT_NAME],
                       check=False, capture_output=True, timeout=10)
        try:
            os.remove(_SYSTEMD_UNIT_PATH)
        except OSError:
            pass

    if not install:
        subprocess.run(["systemctl", "--user", "daemon-reload"],
                       check=False, capture_output=True, timeout=10)
        console.print(f"[green]✅ systemd unit removed:[/green] {_SYSTEMD_UNIT_PATH}")
        return

    xyz_path = shutil.which("xyz") or sys.argv[0]
    if not os.path.isabs(xyz_path):
        console.print(f"[red]Could not resolve absolute path to `xyz` (got {xyz_path}).[/red]")
        console.print("   Re-run from a shell where `which xyz` returns an absolute path.")
        sys.exit(1)

    os.makedirs(_SYSTEMD_LOG_DIR, exist_ok=True)
    log_path = os.path.join(_SYSTEMD_LOG_DIR, "daemon.log")
    err_path = os.path.join(_SYSTEMD_LOG_DIR, "daemon-error.log")

    # Restart=always + RestartSec=10 mirrors launchd KeepAlive=true. We do
    # NOT use `Type=simple` Restart=on-failure because the npm-batch-503
    # spiral (2026-05-05) can cause a clean exit-1 that we still want to
    # re-poll on. PYTHONUNBUFFERED=1 keeps the daemon's stdout in the log
    # file in real time (same reason as the launchd plist).
    unit = (
        "[Unit]\n"
        "Description=CyberXYZ proxy daemon (admin-triggered scan executor)\n"
        "After=network-online.target\n"
        "\n"
        "[Service]\n"
        f"ExecStart={xyz_path} proxy daemon\n"
        "Restart=always\n"
        "RestartSec=10\n"
        f"WorkingDirectory={os.path.expanduser('~')}\n"
        "Environment=PYTHONUNBUFFERED=1\n"
        f"Environment=PATH={os.environ.get('PATH', '/usr/local/bin:/usr/bin:/bin')}\n"
        f"StandardOutput=append:{log_path}\n"
        f"StandardError=append:{err_path}\n"
        "\n"
        "[Install]\n"
        "WantedBy=default.target\n"
    )

    os.makedirs(os.path.dirname(_SYSTEMD_UNIT_PATH), exist_ok=True)
    with open(_SYSTEMD_UNIT_PATH, "w") as f:
        f.write(unit)
    os.chmod(_SYSTEMD_UNIT_PATH, 0o644)

    # daemon-reload picks up the new unit; enable + start it.
    for cmd in (
        ["systemctl", "--user", "daemon-reload"],
        ["systemctl", "--user", "enable", _SYSTEMD_UNIT_NAME],
        ["systemctl", "--user", "start",  _SYSTEMD_UNIT_NAME],
    ):
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        if result.returncode != 0:
            console.print(f"[red]systemctl {' '.join(cmd[2:])} failed:[/red] {result.stderr.strip()}")
            sys.exit(1)

    console.print(f"[green]✅ systemd unit installed:[/green] {_SYSTEMD_UNIT_PATH}")
    console.print(f"   Daemon will auto-start on every login and restart on crash.")
    console.print(f"   Logs:   {log_path}")
    console.print(f"   Errors: {err_path}")
    console.print(f"   Status: systemctl --user status {_SYSTEMD_UNIT_NAME}")
    console.print(f"   Live:   journalctl --user -u {_SYSTEMD_UNIT_NAME} -f")
    console.print(f"   To remove later: xyz proxy daemon --uninstall-service")
    console.print()
    console.print("[dim]Note: on headless Linux servers, run "
                  "`loginctl enable-linger $USER` once so the user unit "
                  "keeps running after logout.[/dim]")


# ---------------------------------------------------------------------------
# Windows Task Scheduler (1.4.10+)
# ---------------------------------------------------------------------------

_WINTASK_NAME = "CyberXYZProxyDaemon"
_WINTASK_LOG_DIR = os.path.expanduser("~\\AppData\\Local\\CyberXYZ\\proxy-daemon")


def _handle_taskscheduler_install(install: bool) -> None:
    """Register or remove a Windows Task Scheduler task that runs
    `xyz proxy daemon` at logon. Restart-on-failure is configured via
    the task's settings (RestartCount=999, RestartInterval=PT1M)."""
    if sys.platform != "win32":
        console.print("[red]--install-service on Windows only.[/red]")
        sys.exit(1)

    schtasks = shutil.which("schtasks") or "schtasks"
    powershell = shutil.which("powershell") or "powershell"

    # Idempotent uninstall first.
    subprocess.run([schtasks, "/Delete", "/TN", _WINTASK_NAME, "/F"],
                   check=False, capture_output=True, timeout=15)

    if not install:
        console.print(f"[green]✅ Scheduled task removed:[/green] {_WINTASK_NAME}")
        return

    xyz_path = shutil.which("xyz") or sys.argv[0]
    if not os.path.isabs(xyz_path):
        console.print(f"[red]Could not resolve absolute path to `xyz` (got {xyz_path}).[/red]")
        console.print("   Re-run from a shell where `where xyz` returns an absolute path.")
        sys.exit(1)

    os.makedirs(_WINTASK_LOG_DIR, exist_ok=True)
    log_path = os.path.join(_WINTASK_LOG_DIR, "daemon.log")
    # Wrap the daemon in a cmd /c so stdout redirects survive Task Scheduler.
    # /c runs and exits when the daemon ends; the task's RestartOnFailure
    # respawns it. Quotes around xyz_path handle any space in the path.
    action = f'cmd /c ""{xyz_path}" proxy daemon >> "{log_path}" 2>&1"'

    # PowerShell New-ScheduledTask gives us proper restart semantics.
    # We can't easily pass that through schtasks, so we use the PS API.
    ps_script = f"""
$Action = New-ScheduledTaskAction -Execute 'cmd' -Argument '/c "& \\\"{xyz_path}\\\" proxy daemon >> \\\"{log_path}\\\" 2>&1"'
$Trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$Settings = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Days 0) -StartWhenAvailable
$Principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName '{_WINTASK_NAME}' -Action $Action -Trigger $Trigger -Settings $Settings -Principal $Principal -Force | Out-Null
Start-ScheduledTask -TaskName '{_WINTASK_NAME}'
Write-Host 'OK'
"""
    result = subprocess.run(
        [powershell, "-NoProfile", "-NonInteractive", "-Command", ps_script],
        capture_output=True, text=True, timeout=30,
    )
    if result.returncode != 0 or "OK" not in (result.stdout or ""):
        console.print(f"[red]Task Scheduler register failed:[/red] {result.stderr.strip() or result.stdout.strip()}")
        sys.exit(1)

    console.print(f"[green]✅ Scheduled task installed:[/green] {_WINTASK_NAME}")
    console.print(f"   Daemon will auto-start at every logon (RestartCount=999).")
    console.print(f"   Logs: {log_path}")
    console.print(f"   Status:  schtasks /Query /TN {_WINTASK_NAME} /V /FO LIST")
    console.print(f"   Stop:    schtasks /End /TN {_WINTASK_NAME}")
    console.print(f"   Remove:  xyz proxy daemon --uninstall-service")


def _record_audit_scan_id(scan_type: str, response: Any) -> None:
    """Stash the cli_scans.id from a /scans POST response so the daemon
    can echo it back when reporting job completion."""
    if isinstance(response, dict):
        sid = response.get("id")
        if isinstance(sid, int):
            _LAST_AUDIT_SCAN_ID[scan_type] = sid


def _resolve_audit_machine_name() -> str:
    """Get the server-resolved machine_name for audit uploads.

    Why: 1.4.6 and earlier shipped `xyz audit *` with
    `machine_name=get_computer_name()` (local macOS hostname). After
    `xyz proxy setup --machine-name <other>`, that mismatched the
    proxy_token's resolved machine, so audit inventory landed under the
    wrong row in the dashboard. We now ask the platform what machine
    THIS token is bound to and tag the upload with that. Falls back to
    the local hostname if /whoami is unreachable or the token isn't
    set up yet (preserves old behavior on first-run / un-onboarded
    machines).
    """
    fallback = get_computer_name() or socket.gethostname()
    proxy_token = _read_proxy_token_from_npmrc()
    if not proxy_token or not proxy_token.startswith('px_xyz_'):
        return fallback
    api_url = (os.getenv('XYZ_API_URL') or 'https://api.cyberxyz.io').rstrip('/')
    try:
        resp = _requests.get(
            f'{api_url}/api/v1/proxy/whoami',
            headers={'Authorization': f'Bearer {proxy_token}'},
            timeout=5,
        )
        if resp.status_code == 200:
            resolved = resp.json().get('machine_name')
            if resolved:
                return resolved
    except _requests.RequestException:
        pass
    return fallback


def init_client():
    """Initialize the API client"""
    global client
    if client is None:
        try:
            client = XYZAPIClient()
        except ValueError as e:
            console.print(f"[red]Error:[/red] {e}")
            console.print("\n[yellow]Setup Instructions:[/yellow]")
            console.print("1. Login using: [bold]xyz login[/bold]")
            console.print("2. (or) Set your API key: [bold]export XYZ_API_KEY=sk_xyz_your_key_here[/bold]")
            console.print("3. Set API URL (optional): [bold]export XYZ_API_URL=https://api.cyberxyz.io/[/bold]")
            console.print("4. Contact support@xyz-security.com for access.")
            sys.exit(1)
        
        # Check if client is authenticated
        if 'Authorization' not in client.session.headers:
            console.print("[red]Error:[/red] You are not logged in and no API key is configured.")
            console.print("Please run [bold]xyz login[/bold] or set the [bold]XYZ_API_KEY[/bold] environment variable.")
            sys.exit(1)

def format_vulnerability_table(vulnerabilities: List[Dict], include_exploits: bool = False, package_version: Optional[str] = None) -> Table:
    """Format vulnerabilities as a Rich table with deduplication and optimized layout"""
    # Deduplicate vulnerabilities by ID (CVE, GHSA, etc.)
    seen_ids = set()
    unique_vulns = []
    
    for vuln in vulnerabilities:
        # Use multiple ID fields to identify duplicates
        vuln_id = vuln.get('cve_id') or vuln.get('id') or vuln.get('ghsa_id') or vuln.get('osv_id')
        if vuln_id and vuln_id != 'N/A' and vuln_id not in seen_ids:
            seen_ids.add(vuln_id)
            unique_vulns.append(vuln)
        elif not vuln_id or vuln_id == 'N/A':
            # Keep entries without IDs but check for duplicate descriptions
            desc = vuln.get('description', '')[:50]  # First 50 chars as identifier
            if desc and desc not in seen_ids:
                seen_ids.add(desc)
                unique_vulns.append(vuln)
    
    title = f"Vulnerability Results ({len(unique_vulns)} unique)"
    if package_version:
        title += f" for version {package_version}"
    table = Table(title=title, show_lines=True, expand=False)
    
    # Optimized columns — no fixed widths so Rich auto-sizes to terminal
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Package", style="magenta", no_wrap=True)
    table.add_column("Severity", style="red", justify="center", no_wrap=True)
    table.add_column("XYZ Score", justify="center", no_wrap=True)
    table.add_column("EPSS", justify="center", no_wrap=True)
    table.add_column("Published", style="yellow", no_wrap=True)
    table.add_column("Summary", style="dim", ratio=2)
    
    if include_exploits:
        table.add_column("Exploits", style="red")
    
    for vuln in unique_vulns:
        # Get the best available ID
        vuln_id = vuln.get('cve_id') or vuln.get('id') or vuln.get('ghsa_id') or vuln.get('osv_id') or 'Unknown'
        
        # Get package name, handle missing data better
        package_name = vuln.get('package_name') or vuln.get('affected', [{}])[0].get('package', {}).get('name', 'Unknown')
        
        # Format severity with color and status indicators
        severity = (vuln.get('severity') or 'UNKNOWN').upper()
        status_indicators = []
        
        # Check if this is a malicious package (MAL- ID prefix)
        vuln_id = vuln.get('cve_id') or vuln.get('id') or vuln.get('ghsa_id') or vuln.get('osv_id') or ''
        is_malicious = isinstance(vuln_id, str) and vuln_id.startswith('MAL-')
        
        if is_malicious or vuln.get('malicious_info', {}).get('is_malicious'):
            status_indicators.append("🦠")
        if vuln.get('exploit_info', {}).get('has_exploits'):
            status_indicators.append("🔓")
        # Mark malicious packages as exploited in wild (supply chain attacks are active threats)
        if vuln.get('exploited_in_wild') or is_malicious:
            status_indicators.append("⚠️")
        
        # Determine severity from CVSS if available
        cvss_score = vuln.get('cvss_score')
        cvss_display = 'N/A'
        if cvss_score:
            try:
                score = float(cvss_score)
                cvss_display = f"{score:.1f}"
                if score >= 9.0:
                    severity = "CRITICAL"
                elif score >= 7.0:
                    severity = "HIGH"
                elif score >= 4.0:
                    severity = "MEDIUM"
                else:
                    severity = "LOW"
            except (ValueError, TypeError):
                cvss_display = str(cvss_score)
        
        # Color-code severity
        if severity == 'CRITICAL':
            severity_colored = f"[red bold]{severity}[/red bold]"
        elif severity == 'HIGH':
            severity_colored = f"[red]{severity}[/red]"
        elif severity == 'MEDIUM' or severity == 'MODERATE':
            severity_colored = f"[yellow]{severity}[/yellow]"
        elif severity == 'LOW':
            severity_colored = f"[green]{severity}[/green]"
        else:
            severity_colored = f"[dim]{severity}[/dim]"
        
        # Add status indicators to severity on new line to prevent table misalignment
        if status_indicators:
            severity_colored += f"\n{''.join(status_indicators)}"
        
        # Format publication date
        pub_date = vuln.get('publication_date') or vuln.get('published_at') or vuln.get('published')
        if pub_date and pub_date != 'N/A':
            try:
                # Try to format date nicely
                from datetime import datetime
                if 'T' in pub_date:
                    dt = datetime.fromisoformat(pub_date.replace('Z', '+00:00'))
                    pub_date = dt.strftime('%Y-%m-%d')
            except:
                pass  # Keep original format if parsing fails
        else:
            pub_date = 'Unknown'
        
        # Format description/summary
        description = vuln.get('description') or vuln.get('summary') or 'No description available'
        if len(description) > 80:
            description = description[:77] + "..."
        
        # Format XYZ Score with color gradient (orange theme)
        xyz_score = vuln.get('xyz_score') or vuln.get('xyz_score_stored')
        if xyz_score is not None:
            try:
                score_val = float(xyz_score)
                if score_val >= 8.0:
                    xyz_display = f"[bold red]{score_val:.1f}[/bold red]"
                elif score_val >= 6.0:
                    xyz_display = f"[bold orange3]{score_val:.1f}[/bold orange3]"
                elif score_val >= 4.0:
                    xyz_display = f"[orange3]{score_val:.1f}[/orange3]"
                else:
                    xyz_display = f"[dark_orange3]{score_val:.1f}[/dark_orange3]"
            except (ValueError, TypeError):
                xyz_display = "[dim]—[/dim]"
        else:
            xyz_display = "[dim]—[/dim]"
        
        # Format EPSS with color (blue theme)
        epss_score = vuln.get('epss_score')
        if epss_score is not None:
            try:
                epss_val = float(epss_score)
                epss_pct = epss_val * 100
                if epss_pct >= 50:
                    epss_display = f"[bold red]{epss_pct:.1f}%[/bold red]"
                elif epss_pct >= 10:
                    epss_display = f"[bold dodger_blue2]{epss_pct:.1f}%[/bold dodger_blue2]"
                elif epss_pct >= 1:
                    epss_display = f"[dodger_blue2]{epss_pct:.1f}%[/dodger_blue2]"
                else:
                    epss_display = f"[steel_blue1]{epss_pct:.2f}%[/steel_blue1]"
            except (ValueError, TypeError):
                epss_display = "[dim]—[/dim]"
        else:
            epss_display = "[dim]—[/dim]"
        
        # Build row
        row = [
            vuln_id,
            package_name,
            severity_colored,
            xyz_display,
            epss_display,
            pub_date,
            description
        ]
        
        table.add_row(*row)
    
    return table

def print_vulnerability_details(vuln: Dict, include_exploits: bool = False):
    """Print detailed vulnerability information"""
    console.print(f"\n[bold cyan]Vulnerability Details: {vuln.get('id', 'N/A')}[/bold cyan]")
    
    # Basic info
    info_table = Table(show_header=False, box=None)
    info_table.add_column("Field", style="bold")
    info_table.add_column("Value")
    
    info_table.add_row("Package", vuln.get('package_name') or 'N/A')
    info_table.add_row("Ecosystem", vuln.get('ecosystem') or 'N/A')
    info_table.add_row("Severity", vuln.get('severity') or 'N/A')
    info_table.add_row("CVSS Score", str(vuln.get('cvss_score') or 'N/A'))
    info_table.add_row("Description", (vuln.get('description') or 'N/A')[:100] + "..." if len(vuln.get('description', '')) > 100 else (vuln.get('description') or 'N/A'))
    
    console.print(info_table)
    
    # Malicious package info
    if vuln.get('malicious_info', {}).get('is_malicious'):
        console.print("\n[red]⚠️  MALICIOUS PACKAGE DETECTED[/red]")
        malicious_info = vuln['malicious_info']
        console.print(f"Source: {malicious_info.get('source', 'N/A')}")
        console.print(f"Detected: {malicious_info.get('detection_date', 'N/A')}")
        if malicious_info.get('references'):
            console.print(f"References: {', '.join(malicious_info['references'][:3])}")
    
    # Exploit info
    if include_exploits and vuln.get('exploit_info', {}).get('has_exploits'):
        console.print("\n[orange1]🔓 EXPLOIT INFORMATION[/orange1]")
        exploits = vuln['exploit_info'].get('exploits', [])
        
        exploit_table = Table()
        exploit_table.add_column("Author", style="cyan")
        exploit_table.add_column("Type", style="magenta")
        exploit_table.add_column("Platform", style="blue")
        exploit_table.add_column("Verified", style="green")
        
        for exploit in exploits[:5]:  # Show first 5 exploits
            exploit_table.add_row(
                exploit.get('author', 'N/A'),
                exploit.get('type', 'N/A'),
                exploit.get('platform', 'N/A'),
                "✅" if exploit.get('verified') else "❌"
            )
        
        console.print(exploit_table)
        
        if len(exploits) > 5:
            console.print(f"... and {len(exploits) - 5} more exploits")

@click.group()
@click.option('--api-key', envvar='XYZ_API_KEY', help='API key for XYZ Vulnerability API')
@click.option('--api-url', envvar='XYZ_API_URL', help='API base URL')
@click.option('--debug', is_flag=True, help='Enable debug output')
@click.pass_context
def cli(ctx, api_key, api_url, debug):
    """XYZ Vulnerability Scanner - API-based CLI tool"""
    ctx.ensure_object(dict)
    ctx.obj['api_key'] = api_key
    ctx.obj['api_url'] = api_url
    ctx.obj['debug'] = debug
    
    if debug:
        console.print(f"[dim]API URL: {api_url}[/dim]")
        console.print(f"[dim]API Key: {'Set' if api_key else 'Not set'}[/dim]")

@cli.command()
@click.pass_context
def info(ctx):
    """Show API information and capabilities"""
    init_client()
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Fetching API info...", total=None)
            
            api_info = client.get_api_info()
            health = client.health_check()
        
        # User status
        user_info = client.get_user_info()
        if user_info and 'email' in user_info:
            login_status = f"[green]Logged in as: {user_info['email']}[/green]"
        else:
            login_status = "[yellow]Not logged in[/yellow]"

        console.print(Panel.fit(f"[bold green]XYZ Vulnerability API[/bold green]\nVersion: {api_info.get('api_version', 'N/A')}\nStatus: {health.get('status', 'Unknown')}\nUser: {login_status}"))
        
        # Features
        console.print("\n[bold]Features:[/bold]")
        features = api_info.get('features', {})
        features['apt_zero_day'] = True  # Manually add this feature
        for feature, enabled in features.items():
            status = "✅" if enabled else "❌"
            feature_text = feature.replace('_', ' ').title()
            if feature == 'apt_zero_day':
                feature_text = "APT Zero-Day Vulnerabilities Detection + Exploitatbility"
            console.print(f"  {status} {feature_text}")
        
        # Supported formats
        console.print(f"\n[bold]Supported Vulnerability Types:[/bold]")
        for vuln_type in api_info.get('supported_vulnerabilities', []):
            console.print(f"  • {vuln_type}")
        
        # Rate limits
        console.print(f"\n[bold]Rate Limits:[/bold]")
        for tier, limit in api_info.get('rate_limits', {}).items():
            console.print(f"  • {tier.title()}: {limit}")
        
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.argument('vuln_id')
@click.option('-x', '--exploits', is_flag=True, help='Include exploit information')
@click.option('--affected', is_flag=True, help='Show affected packages')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
@click.pass_context
def vuln(ctx, vuln_id, exploits, affected, output_json):
    """Search for a specific vulnerability by ID (CVE, GHSA, OSV, etc.)"""
    init_client()
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description=f"Searching for {vuln_id}...", total=None)
            
            result = client.search_vulnerability_by_id(vuln_id, include_exploits=exploits)
        
        if output_json:
            console.print(json.dumps(result, indent=2))
        else:
            vulnerabilities = result.get('vulnerabilities', [])
            scores = result.get('scores', {})
            
            # Inject scores into each vulnerability for table display
            if scores:
                for v in vulnerabilities:
                    if 'xyz_score' not in v and scores.get('xyz_score') is not None:
                        v['xyz_score'] = scores['xyz_score']
                    if 'epss_score' not in v and scores.get('epss_score') is not None:
                        v['epss_score'] = scores['epss_score']
            
            if vulnerabilities:
                table = format_vulnerability_table(vulnerabilities, include_exploits=exploits)
                console.print(table)
                
                # Show scores summary
                if scores:
                    score_parts = []
                    if scores.get('xyz_score') is not None:
                        score_parts.append(f"[bold orange3]XYZ Score: {scores['xyz_score']:.1f}/10[/bold orange3]")
                    if scores.get('epss_score') is not None:
                        epss_pct = scores['epss_score'] * 100
                        score_parts.append(f"[bold dodger_blue2]EPSS: {epss_pct:.2f}%[/bold dodger_blue2]")
                    if scores.get('epss_percentile') is not None:
                        pctile = scores['epss_percentile'] * 100
                        score_parts.append(f"[dim]Percentile: {pctile:.0f}th[/dim]")
                    if score_parts:
                        console.print(" | ".join(score_parts))
                
                # Show detailed info for first vulnerability
                if vulnerabilities:
                    print_vulnerability_details(vulnerabilities[0], include_exploits=exploits)
                    
                    # Show affected packages if requested
                    if affected:
                        console.print("\n[bold cyan]🎯 Affected Packages:[/bold cyan]")
                        affected_packages = set()
                        for vuln in vulnerabilities:
                            if vuln.get('package_name'):
                                pkg_name = vuln.get('package_name')
                                ecosystem = vuln.get('ecosystem', 'Unknown')
                                affected_packages.add(f"{pkg_name} ({ecosystem})")
                        
                        if affected_packages:
                            for package in sorted(affected_packages):
                                console.print(f"  • {package}")
                        else:
                            console.print("  [dim]No specific package information available[/dim]")
            else:
                console.print(f"[yellow]No vulnerabilities found for {vuln_id}[/yellow]")
        
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.argument('package_name')
@click.option('-e', '--ecosystem', help='Filter by ecosystem (npm, pypi, maven, etc.)')
@click.option('-v', '--version', help='Filter by package version')
@click.option('-s', '--severity', help='Filter by severity (critical, high, medium, low)')
@click.option('-x', '--exploits', is_flag=True, help='Include exploit information')
@click.option('--limit', default=50, help='Maximum results to return')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
@click.pass_context
def package(ctx, package_name, ecosystem, version, severity, exploits, limit, output_json):
    """Search for vulnerabilities affecting a specific package"""
    init_client()
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description=f"Scanning package {package_name}...", total=None)
            
            result = client.search_package_vulnerabilities(
                package_name=package_name,
                ecosystem=ecosystem,
                version=version,
                severity=severity,
                limit=limit,
                include_exploits=exploits,
                machine_name=get_computer_name(),
                os_type=platform.system(),
                computer_name=get_computer_name(),
                scan_command=f"xyz package {package_name}" + (f" -v {version}" if version else "")
            )
        
        if output_json:
            console.print(json.dumps(result, indent=2))
        else:
            packages = result.get('packages', [])
            if packages:
                # Show summary
                summary = result.get('summary', {})
                console.print(f"\n[bold]Scan Results for '{package_name}'[/bold]")
                console.print(f"Packages found: {summary.get('total_packages', 0)}")
                console.print(f"Total vulnerabilities: {summary.get('total_vulnerabilities', 0)}")
                
                # Show each package's vulnerabilities
                for pkg in packages:
                    console.print(f"\n[bold cyan]📦 {pkg['package_name']} ({pkg['ecosystem']})[/bold cyan]")
                    console.print(f"Vulnerabilities: {pkg['vulnerability_count']}")
                    
                    # Show severity breakdown
                    severity_summary = pkg.get('severity_summary', {})
                    if severity_summary:
                        console.print("Severity breakdown:")
                        for sev, count in severity_summary.items():
                            console.print(f"  • {sev.title()}: {count}")
                    
                    # Show vulnerability table
                    if pkg['vulnerabilities']:
                        table = format_vulnerability_table(pkg['vulnerabilities'], include_exploits=exploits, package_version=version)
                        console.print(table)
                        
                        # Show detailed information for malicious packages
                        for vuln in pkg['vulnerabilities']:
                            vuln_id = vuln.get('id') or vuln.get('cve_id') or vuln.get('ghsa_id') or vuln.get('osv_id') or ''
                            is_malicious = isinstance(vuln_id, str) and vuln_id.startswith('MAL-')
                            
                            if is_malicious or vuln.get('details') or vuln.get('affected'):
                                console.print(f"\n[bold red]⚠️  Vulnerability Details: {vuln_id}[/bold red]")
                                
                                # Show affected versions
                                affected = vuln.get('affected', [])
                                if affected and len(affected) > 0:
                                    versions = affected[0].get('versions', [])
                                    if versions:
                                        console.print(f"[yellow]Affected Versions:[/yellow] {', '.join(versions)}")
                                
                                # Show details for malicious packages
                                details = vuln.get('details', '')
                                if details:
                                    console.print(f"\n[bold]Details:[/bold]")
                                    # Extract the important parts of the details
                                    if 'Sha1-Hulud' in details or 'SHA1Hulud' in details:
                                        console.print("[red bold]🦠 MALICIOUS PACKAGE - SUPPLY CHAIN ATTACK[/red bold]")
                                    
                                    # Show details (truncate if too long)
                                    detail_lines = details.split('\n')
                                    for line in detail_lines[:15]:  # Show first 15 lines
                                        if line.strip() and not line.startswith('---') and not line.startswith('_-='):
                                            console.print(f"  {line}")
                                    
                                    if len(detail_lines) > 15:
                                        console.print(f"  [dim]... ({len(detail_lines) - 15} more lines)[/dim]")
                                
                                console.print()  # Add spacing
            else:
                console.print(f"[yellow]No vulnerabilities found for package '{package_name}'[/yellow]")
        
        # Upload scan results to the platform
        if packages:  # Only upload if we found results
            console.print("Sending package scan results to the platform...")
            try:
                client.send_package_scan({
                    **result,
                    "machine_name": get_computer_name(),
                    "os_type": platform.system(),
                    "computer_name": get_computer_name(),
                    "scan_command": f"xyz package {package_name}" + (f" -v {version}" if version else "")
                })
                console.print("[green]Successfully uploaded package scan results.[/green]")
            except Exception as upload_error:
                console.print(f"[yellow]Warning: Failed to upload scan results: {upload_error}[/yellow]")
        
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.option('--python', 'scan_python', is_flag=True, help='Scan Python packages')
@click.option('--npm', 'scan_npm', is_flag=True, help='Scan npm packages')
@click.option('-i', '--system', 'scan_system', is_flag=True, help='Scan system packages')
@click.option('--java', 'scan_java', is_flag=True, help='Scan Java packages')
@click.option('--go', 'scan_go', is_flag=True, help='Scan Go packages')
@click.option('--php', 'scan_php', is_flag=True, help='Scan PHP packages')
@click.option('--microsoft', 'scan_microsoft', is_flag=True, help='Scan Microsoft packages')
@click.option('--all', 'scan_all', is_flag=True, help='Scan all package types')
@click.option('-x', '--exploits', is_flag=True, help='Include exploit information')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
@click.option('--list-packages', is_flag=True, help='Only list installed packages, do not scan for vulnerabilities')
@click.option('-p', '--package', 'specific_package', help='Scan a specific package by name')
@click.pass_context
def scan(ctx, scan_python, scan_npm, scan_system, scan_java, scan_go, scan_php, scan_microsoft, scan_all, exploits, output_json, list_packages, specific_package):
    """Scan installed packages for vulnerabilities"""
    init_client()
    
    if list_packages:
        console.print("[bold]Listing installed packages...[/bold]")
        
        package_types = []
        if scan_python or scan_all:
            package_types.append("python")
        if scan_npm or scan_all:
            package_types.append("npm")
        if scan_system or scan_all:
            package_types.append("system")
        if scan_java or scan_all:
            package_types.append("java")
        if scan_go or scan_all:
            package_types.append("go")
        if scan_php or scan_all:
            package_types.append("php")
        if scan_microsoft or scan_all:
            package_types.append("microsoft")
            
        results = client.list_packages(
            package_types=package_types,
            machine_name=get_computer_name(),
            os_type=platform.system(),
            computer_name=get_computer_name()
        )
        
        for pkg_type, pkgs in results.items():
            console.print(f"\n[bold cyan]{pkg_type.title()} Packages[/bold cyan]")
            if pkgs:
                for pkg in pkgs:
                    if 'type' in pkg:
                        console.print(f"  - {pkg['name']} ({pkg['version']}) [{pkg['type']}]")
                    else:
                        console.print(f"  - {pkg['name']} ({pkg['version']})")
            else:
                console.print("  [dim]No packages found.[/dim]")
        return

    # Handle specific package scanning
    if specific_package:
        console.print(f"[bold]Scanning specific package: {specific_package}[/bold]")
        
        try:
            # Search for vulnerabilities in the specific package
            vulnerabilities = client.search_package_vulnerabilities(
                package_name=specific_package,
                include_exploits=exploits
            )
            
            if output_json:
                import json
                print(json.dumps(vulnerabilities, indent=2))
                return
            
            if vulnerabilities and vulnerabilities.get('vulnerabilities'):
                vulns = vulnerabilities['vulnerabilities']
                console.print(f"\n[bold red]Found {len(vulns)} vulnerabilities for {specific_package}:[/bold red]")
                
                for vuln in vulns:
                    severity = vuln.get('severity', 'Unknown').upper()
                    severity_color = {
                        'CRITICAL': 'bold red',
                        'HIGH': 'red',
                        'MEDIUM': 'yellow',
                        'LOW': 'green',
                        'UNKNOWN': 'dim'
                    }.get(severity, 'dim')
                    
                    console.print(f"  • [{severity_color}]{vuln.get('id', 'N/A')}[/{severity_color}] - {severity}")
                    console.print(f"    Summary: {vuln.get('summary', 'No summary available')}")
                    if vuln.get('affected_versions'):
                        console.print(f"    Affected: {vuln.get('affected_versions')}")
                    if exploits and vuln.get('exploits'):
                        console.print(f"    [bold red]Exploits available: {len(vuln['exploits'])}[/bold red]")
                    console.print()
            else:
                console.print(f"[green]No vulnerabilities found for {specific_package}[/green]")
                
        except Exception as e:
            console.print(f"[red]Error scanning package {specific_package}: {e}[/red]")
            sys.exit(1)
        return

    # Handle scan type selection
    if scan_all:
        scan_python = scan_npm = scan_system = scan_java = scan_go = scan_php = scan_microsoft = True
    elif not any([scan_python, scan_npm, scan_system, scan_java, scan_go, scan_php, scan_microsoft]):
        # Default to Python and npm if none specified (matching legacy behavior)
        scan_python = True
        scan_npm = True
    
    results = {}
    
    try:
        if scan_python:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task(description="Scanning Python packages...", total=None)
                
                results['python'] = client.scan_python_packages(include_exploits=exploits, machine_name=get_computer_name(), os_type=platform.system(), computer_name=get_computer_name())
        
        if scan_npm:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task(description="Scanning npm packages...", total=None)
                
                results['npm'] = client.scan_npm_packages(include_exploits=exploits, machine_name=get_computer_name(), os_type=platform.system(), computer_name=get_computer_name())
        
        if scan_system:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task(description="Scanning system packages...", total=None)
                
                try:
                    # For now, system scanning is not implemented in API backend
                    # This is a placeholder that matches the legacy CLI behavior
                    console.print("\n[yellow]⚠️  System package scanning not yet implemented in API backend[/yellow]")
                    console.print("[dim]Use the legacy CLI for system package scanning: ./xyz scan -i[/dim]")
                    results['system'] = {'scan_results': {'vulnerabilities': []}, 'message': 'Not implemented'}
                except Exception as e:
                    console.print(f"[red]Error scanning system packages:[/red] {e}")
                    results['system'] = {'error': str(e)}
        
        if scan_java:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task(description="Scanning Java packages...", total=None)
                
                results['java'] = client.scan_java_packages(include_exploits=exploits, machine_name=get_computer_name(), os_type=platform.system(), computer_name=get_computer_name())
        
        if scan_go:
            console.print("\n[yellow]⚠️  Go package scanning not yet implemented.[/yellow]")
            results['go'] = {'scan_results': {'vulnerabilities': []}, 'message': 'Not implemented'}
        
        if scan_php:
            console.print("\n[yellow]⚠️  PHP package scanning not yet implemented.[/yellow]")
            results['php'] = {'scan_results': {'vulnerabilities': []}, 'message': 'Not implemented'}

        if scan_microsoft:
            console.print("\n[yellow]⚠️  Microsoft package scanning not yet implemented.[/yellow]")
            results['microsoft'] = {'scan_results': {'vulnerabilities': []}, 'message': 'Not implemented'}
        
        if output_json:
            console.print(json.dumps(results, indent=2))
        else:
            # Display results for each scan type
            for scan_type, result in results.items():
                console.print(f"\n[bold]🔍 {scan_type.title()} Package Scan Results[/bold]")
                
                scan_results = result.get('scan_results', {})
                if scan_results.get('vulnerabilities'):
                    console.print(f"Vulnerabilities found: {len(scan_results['vulnerabilities'])}")
                    
                    # Show summary
                    if scan_results.get('summary'):
                        summary = scan_results['summary']
                        console.print(f"Critical: {summary.get('critical', 0)}")
                        console.print(f"High: {summary.get('high', 0)}")
                        console.print(f"Medium: {summary.get('medium', 0)}")
                        console.print(f"Low: {summary.get('low', 0)}")
                    
                    # Show vulnerability table
                    table = format_vulnerability_table(scan_results['vulnerabilities'][:20], include_exploits=exploits)
                    console.print(table)
                    
                    if len(scan_results['vulnerabilities']) > 20:
                        console.print(f"[dim]... and {len(scan_results['vulnerabilities']) - 20} more vulnerabilities[/dim]")
                else:
                    console.print("[green]✅ No vulnerabilities found[/green]")
        
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.option('--days', default=7, help='Number of days to look back')
@click.option('--limit', default=20, help='Maximum results to return')
@click.option('-x', '--exploits', is_flag=True, help='Include exploit information')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
@click.pass_context
def recent(ctx, days, limit, exploits, output_json):
    """Show recent vulnerabilities"""
    init_client()
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description=f"Fetching recent vulnerabilities ({days} days)...", total=None)
            
            result = client.get_recent_vulnerabilities(days=days, limit=limit, include_exploits=exploits)
        
        if output_json:
            console.print(json.dumps(result, indent=2))
        else:
            vulnerabilities = result.get('recent_vulnerabilities', result.get('vulnerabilities', []))
            if vulnerabilities:
                console.print(f"\n[bold]📅 Recent Vulnerabilities (Last {days} days)[/bold]")
                console.print(f"Total found: {len(vulnerabilities)}")
                
                table = format_vulnerability_table(vulnerabilities, include_exploits=exploits)
                console.print(table)
            else:
                console.print(f"[yellow]No recent vulnerabilities found in the last {days} days[/yellow]")
        
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.pass_context
def stats(ctx):
    """Show database and API statistics"""
    init_client()
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Fetching statistics...", total=None)
            
            # Get database stats with improved error handling
            try:
                db_response = client.get_database_stats()
                db_stats = db_response.get('database_stats', {})
                data_source = db_response.get('data_source', 'unknown')
                status = db_response.get('status', 'unknown')
                
                # Check if we have fallback data
                if status == 'partial' or data_source == 'fallback':
                    console.print("[yellow]⚠️  Database temporarily unavailable - showing cached/fallback data[/yellow]")
                    if 'message' in db_response:
                        console.print(f"[dim]{db_response['message']}[/dim]")
                    console.print()
                    
            except Exception as e:
                console.print(f"[red]Error fetching database stats:[/red] {e}")
                return
            
            # Get ecosystem stats
            try:
                eco_stats = client.get_ecosystem_stats()
            except Exception as e:
                console.print(f"[yellow]Warning:[/yellow] Could not fetch ecosystem stats: {e}")
                eco_stats = {}
        
        # Display database statistics
        console.print("[bold]📊 Database Statistics[/bold]")
        
        stats_table = Table(show_header=False, box=None)
        stats_table.add_column("Metric", style="bold")
        stats_table.add_column("Value", style="cyan")
        
        # Handle both old and new API response formats
        vulnerability_data = db_stats.get('vulnerability_counts', db_stats)
        
        # Display main vulnerability counts
        main_stats = {
            'Total CVE Records': vulnerability_data.get('Total CVE Records', 0),
            'GitHub Advisories': vulnerability_data.get('GitHub Advisories', 0),
            'OSV Records': vulnerability_data.get('OSV Records', 0),
            'RedHat Advisories': vulnerability_data.get('RedHat Advisories', 0),
            'Exploit Records': vulnerability_data.get('Exploit Records', 0),
            'Malicious Packages': vulnerability_data.get('Malicious Packages', 0)
        }
        
        for key, value in main_stats.items():
            if value == 'unavailable':
                stats_table.add_row(key, "[dim]unavailable[/dim]")
            else:
                stats_table.add_row(key, f"{value:,}" if isinstance(value, int) else str(value))
        
        console.print(stats_table)
        
        # Display severity distribution if available
        severity_dist = db_stats.get('severity_distribution', {})
        if severity_dist and severity_dist != {'CRITICAL': 'unavailable', 'HIGH': 'unavailable', 'MEDIUM': 'unavailable', 'LOW': 'unavailable'}:
            console.print("\n[bold]🚨 Severity Distribution[/bold]")
            severity_table = Table()
            severity_table.add_column("Severity", style="bold")
            severity_table.add_column("Count", style="magenta", justify="right")
            
            severity_colors = {
                'CRITICAL': 'red',
                'HIGH': 'orange3', 
                'MEDIUM': 'yellow',
                'LOW': 'green'
            }
            
            for severity in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']:
                if severity in severity_dist:
                    value = severity_dist[severity]
                    color = severity_colors.get(severity, 'white')
                    if value == 'unavailable':
                        severity_table.add_row(f"[{color}]{severity}[/{color}]", "[dim]unavailable[/dim]")
                    else:
                        severity_table.add_row(f"[{color}]{severity}[/{color}]", f"{value:,}" if isinstance(value, int) else str(value))
            
            console.print(severity_table)
        
        # Display ecosystem stats
        if eco_stats and eco_stats.get('ecosystem_stats'):
            console.print("\n[bold]🌍 Top Ecosystems[/bold]")
            ecosystem_table = Table()
            ecosystem_table.add_column("Ecosystem", style="cyan")
            ecosystem_table.add_column("Packages", style="magenta", justify="right")
            
            for ecosystem, count in sorted(eco_stats.get('ecosystem_stats', {}).items(), key=lambda x: x[1], reverse=True)[:10]:
                ecosystem_table.add_row(ecosystem, f"{count:,}" if isinstance(count, int) else str(count))
            
            console.print(ecosystem_table)
        elif db_stats.get('top_ecosystems'):
            # Handle new API format for ecosystems
            console.print("\n[bold]🌍 Top Ecosystems[/bold]")
            ecosystem_table = Table()
            ecosystem_table.add_column("Ecosystem", style="cyan")
            ecosystem_table.add_column("Packages", style="magenta", justify="right")
            
            top_ecosystems = db_stats.get('top_ecosystems', {})
            for ecosystem, count in top_ecosystems.items():
                if count == 'unavailable':
                    ecosystem_table.add_row(ecosystem, "[dim]unavailable[/dim]")
                else:
                    ecosystem_table.add_row(ecosystem, f"{count:,}" if isinstance(count, int) else str(count))
            
            console.print(ecosystem_table)
        
        # Show data source info
        if data_source and data_source != 'unknown':
            console.print(f"\n[dim]Data source: {data_source}[/dim]")
            if 'last_updated' in db_response:
                console.print(f"[dim]Last updated: {db_response['last_updated']}[/dim]")
        
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.option('--email', prompt=True, help='Your email address')
@click.password_option(help='Your password')
@click.pass_context
def login(ctx, email, password):
    """Login to the XYZ API"""
    init_client()
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Logging in...", total=None)
            result = client.login(email, password)
            client.session.headers['Authorization'] = f"Bearer {result['access_token']}"
            client.session.headers['Authorization'] = f"Bearer {result['access_token']}"
        
        console.print(f"[green]✅ Login successful![/green]")
        console.print(f"Welcome, {result['user_info']['email']}")
        console.print(f"Organization ID: {result['user_info']['organization_id']}")
        console.print("Your session is now active.")
        
    except ValueError as e:
        console.print(f"[red]Login failed:[/red] {e}")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]An unexpected error occurred:[/red] {e}")
        sys.exit(1)

@cli.command()
def upgrade():
    """Upgrade XYZ CLI to the latest version"""
    from importlib.metadata import version as pkg_version
    current = pkg_version("cyberxyz-scanner")
    console.print(f"[dim]Current version:[/dim] {current}")
    console.print("Upgrading…\n")
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "cyberxyz-scanner"],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode != 0:
            # Try with --break-system-packages for externally managed envs
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "--upgrade",
                 "--break-system-packages", "cyberxyz-scanner"],
                capture_output=True, text=True, timeout=120,
            )
        if result.returncode == 0:
            new = pkg_version("cyberxyz-scanner")
            if new != current:
                console.print(f"[green]✅ Upgraded:[/green] {current} → {new}")
            else:
                console.print(f"[green]✅ Already on the latest version ({current})[/green]")
        else:
            console.print(f"[red]Upgrade failed:[/red]\n{result.stderr.strip()}")
            sys.exit(1)
    except Exception as e:
        console.print(f"[red]Upgrade failed:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.pass_context
def logout(ctx):
    """Logout and clear your session"""
    init_client()
    try:
        client.logout()
        console.print("[green]✅ You have been successfully logged out.[/green]")
    except Exception as e:
        console.print(f"[red]Error during logout:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.option('--json', 'output_json', is_flag=True, help='Output status as JSON')
@click.pass_context
def status(ctx, output_json):
    """Show session, machine, and environment details"""
    init_client()

    user_info = client.get_user_info()
    computer_name = get_computer_name()
    hostname = socket.gethostname()
    os_type = platform.system()
    os_version = platform.platform()
    py_version = platform.python_version()

    # Proxy config
    npmrc_path = os.path.expanduser('~/.npmrc')
    proxy_registry = None
    proxy_token_set = False
    if os.path.exists(npmrc_path):
        with open(npmrc_path) as f:
            for line in f:
                if line.startswith('registry='):
                    proxy_registry = line.strip().split('=', 1)[1]
                if '_authToken=' in line:
                    proxy_token_set = True

    info = {
        "logged_in": bool(user_info and 'email' in user_info),
        "email": user_info.get('email') if user_info else None,
        "username": user_info.get('username') if user_info else None,
        "role": "Org Admin" if (user_info or {}).get('is_org_admin') else "Member",
        "tier": (user_info.get('tier') or 'free').capitalize() if user_info else None,
        "organization_id": user_info.get('organization_id') if user_info else None,
        "organization_name": user_info.get('organization_name') if user_info else None,
        "machine_name": computer_name,
        "hostname": hostname,
        "ip_address": _get_local_ip(),
        "os": os_type,
        "os_version": os_version,
        "python_version": py_version,
        "cli_version": _cli_version(),
        "api_url": client.base_url,
        "proxy_registry": proxy_registry,
        "proxy_token": "configured" if proxy_token_set else "not set",
    }

    if output_json:
        console.print(json.dumps(info, indent=2))
        return

    # Rich panel output
    if not info["logged_in"]:
        console.print("[yellow]Not logged in.[/yellow] Run [bold]xyz login[/bold] to authenticate.\n")
    else:
        console.print()

    tier_color = {"Free": "white", "Pro": "cyan", "Enterprise": "magenta"}.get(info["tier"] or "", "white")
    role_color = "yellow" if info["role"] == "Org Admin" else "white"

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="bold", min_width=18)
    table.add_column("Value")

    if info["logged_in"]:
        table.add_row("Account", f"[green]{info['email']}[/green]")
        if info["username"]:
            table.add_row("Username", info["username"])
        table.add_row("Role", f"[{role_color}]{info['role']}[/{role_color}]")
        table.add_row("Plan", f"[{tier_color}]{info['tier']}[/{tier_color}]")
        if info["organization_name"]:
            table.add_row("Organization", f"{info['organization_name']} (ID: {info['organization_id']})")
        elif info["organization_id"]:
            table.add_row("Organization ID", str(info["organization_id"]))
        table.add_row("", "")

    table.add_row("Machine", info["machine_name"])
    table.add_row("Hostname", info["hostname"])
    table.add_row("IP Address", info["ip_address"] or "Unknown")
    table.add_row("OS", f"{info['os']} ({info['os_version']})")
    table.add_row("", "")
    table.add_row("CLI Version", info["cli_version"])
    table.add_row("Python", info["python_version"])
    table.add_row("API Endpoint", info["api_url"])
    table.add_row("", "")
    table.add_row("Proxy Registry", info["proxy_registry"] or "[dim]not configured[/dim]")
    table.add_row("Proxy Token", "[green]configured[/green]" if proxy_token_set else "[red]not set[/red]")

    title = "XYZ Status"
    if info["logged_in"]:
        title += f"  [dim]({info['tier']})[/dim]"
    console.print(Panel(table, title=f"[bold]{title}[/bold]", border_style="blue", expand=False))

@cli.group(invoke_without_command=True)
@click.pass_context
def audit(ctx):
    """Audit local development environments.

    With no subcommand, runs npm + python + go audits back-to-back so the
    platform receives one full per-machine inventory snapshot from a single
    command. Each ecosystem still posts its own /scans payload so the
    server-side normalization stays per-ecosystem.

    Use ``xyz audit npm | python | go`` to scope to one ecosystem.
    """
    if ctx.invoked_subcommand is not None:
        return

    console.print("[bold]Running full audit (npm + python + go)…[/bold]\n")

    failures = []

    for label, cmd, kwargs in (
        ("npm",    npm,        {"include_global": True, "output_json": False}),
        ("python", python,     {"output_json": False}),
        ("go",     go,         {"output_json": False}),
    ):
        try:
            ctx.invoke(cmd, **kwargs)
            console.print()  # blank line between ecosystems
        except SystemExit as e:
            # Subcommand called sys.exit on missing toolchain — keep going
            # so a missing `go` doesn't prevent the npm/python audits from
            # uploading.
            if e.code not in (None, 0):
                failures.append(label)
                console.print(
                    f"[yellow]⚠  {label} audit exited early (code={e.code}); "
                    f"continuing with the next ecosystem.[/yellow]\n"
                )
        except Exception as e:
            failures.append(label)
            console.print(
                f"[yellow]⚠  {label} audit raised {type(e).__name__}: {e}; "
                f"continuing with the next ecosystem.[/yellow]\n"
            )

    if failures:
        console.print(
            f"[yellow]Full audit completed with skipped ecosystems: "
            f"{', '.join(failures)}[/yellow]"
        )
    else:
        console.print("[green]✅ Full audit complete (npm + python + go).[/green]")

# ---------------------------------------------------------------------------
# Shared rendering helper for python / go / nuget watchlist-mode audits
# ---------------------------------------------------------------------------

def _render_audit_summary(eco_label: str, total: int, audit_result: Dict[str, Any], output_json: bool) -> None:
    """Render the same risky/clean/errors summary shape that npm uses,
    so python/go/nuget terminal output is consistent."""
    risky = audit_result['risky']
    errors = audit_result['errors']
    clean_count = len(audit_result['clean'])
    pre_filter_skipped = audit_result['pre_filter_skipped']
    pre_filter_used = audit_result['pre_filter_used']
    suspect_count = len(audit_result['suspect_pkgs'])

    if output_json:
        console.print(json.dumps({
            'risky': risky, 'clean_count': clean_count, 'errors': errors,
            'total': total, 'pre_filter_skipped': pre_filter_skipped,
        }, indent=2, default=str))
        return

    if risky:
        table = Table(title=f"⚠️  Risky {eco_label} Packages ({len(risky)})", show_header=True)
        table.add_column("Package", style="red bold")
        table.add_column("Version", style="yellow")
        table.add_column("Decision", style="red")
        table.add_column("Safe Version", style="green")
        for p in risky:
            table.add_row(p['name'], str(p.get('version', '')),
                          str(p.get('decision', '?')),
                          str(p.get('safe_version') or '—'))
        console.print(table)
    else:
        console.print(f"[green]✅ All {clean_count} {eco_label} packages clean.[/green]")

    line = (
        f"  Total scanned: {total}  |  Risky: {len(risky)}  |  "
        f"Clean: {clean_count}  |  Errors: {len(errors)}"
    )
    if pre_filter_used:
        line += (
            f"  |  Pre-filter cleared: {pre_filter_skipped}  |  "
            f"Deep-checked: {suspect_count}"
        )
    console.print(line)


# ---------------------------------------------------------------------------
# xyz audit python
# ---------------------------------------------------------------------------

@audit.command()
@click.option('--full', 'full_check', is_flag=True, default=False,
              help='Send every installed package through /proxy/check/batch '
                   'instead of the watchlist pre-filter. Slower; covers '
                   'advisory matches at scan time. Default: pre-filter via '
                   '/watchlist?ecosystem=pypi.')
@click.option('--legacy', 'use_legacy_script', is_flag=True, default=False,
              help='Use the pre-1.4.13 pipdeptree + pip-audit script for '
                   'local CVE-tree rendering. Much slower. Default: skip the '
                   'tree and let the platform compute exposures async.')
@click.option('--json', 'output_json', is_flag=True, help='Output audit results as JSON')
def python(full_check, use_legacy_script, output_json):
    """Audit installed Python packages.

    \b
    Default (1.4.13+): runs `pip list --format=json` (~1s), pre-filters the
    inventory via /watchlist?ecosystem=pypi, and only deep-checks packages
    whose name appears in the malicious-name watchlist (typically 0-5 of
    several hundred). Wall-clock ~5-10s vs the legacy ~30s.

    \b
    --full       skip the watchlist filter; check every package via
                 /proxy/check/batch (slower).
    --legacy     run the original pipdeptree + pip-audit script (slowest;
                 produces the local CVE tree but the same data is on the
                 dashboard already).
    """
    init_client()

    if use_legacy_script:
        return _legacy_python_audit(output_json)

    console.print("🐍 Starting Python audit (watchlist mode)…")

    # Inventory via `pip list --format=json` — fast, no extra deps required.
    pip_cmd = shutil.which("pip3") or shutil.which("pip") or "pip3"
    try:
        proc = subprocess.run(
            [pip_cmd, 'list', '--format=json'],
            capture_output=True, text=True, timeout=60, check=False,
        )
        listing = json.loads(proc.stdout) if proc.stdout.strip() else []
    except (subprocess.TimeoutExpired, json.JSONDecodeError) as e:
        console.print(f"[red]pip list failed ({type(e).__name__}): {e}[/red]")
        sys.exit(1)

    packages = [
        {'name': str(p.get('name', '')).strip(), 'version': str(p.get('version', '')).strip(), 'depth': 0}
        for p in listing if p.get('name')
    ]
    total = len(packages)
    if total == 0:
        console.print("[yellow]No Python packages found.[/yellow]")
        return

    machine = _resolve_audit_machine_name()
    audit_result = client.smart_audit_via_watchlist(
        packages, ecosystem='pypi',
        machine_name=machine, os_type=platform.system(),
        full_check=full_check,
    )

    _render_audit_summary("Python", total, audit_result, output_json)

    # Inventory upload — server expects scan_results.dependency_tree shape
    # for scan_type='python' (scans.py:_normalize_audit_to_inventory). Build
    # a flat tree (each package as a root with empty deps); pipdeptree-style
    # full nesting is lost in watchlist mode but the per-machine inventory
    # only needs name + installed_version.
    dep_tree = [
        {'package_name': p['name'], 'installed_version': p['version'],
         'dependencies': [], 'vulnerabilities': []}
        for p in packages
    ]
    try:
        _resp = client.send_python_audit({
            "scan_results": {"dependency_tree": dep_tree},
            "summary": {
                "total_packages": total,
                "risky": len(audit_result['risky']),
                "clean": len(audit_result['clean']),
                "pre_filter_skipped": audit_result['pre_filter_skipped'],
            },
            "machine_name": machine,
            "os_type": platform.system(),
            "computer_name": get_computer_name(),
            "scan_command": "xyz audit python" + (" --full" if full_check else ""),
        })
        _record_audit_scan_id("python", _resp)
        console.print("[green]✅ Python inventory uploaded.[/green]")
    except Exception as e:
        console.print(f"[yellow]⚠️  Upload failed (non-fatal): {e}[/yellow]")


def _legacy_python_audit(output_json: bool) -> None:
    """Pre-1.4.13 audit path: pipdeptree + pip-audit. Kept for users who want
    the local CVE tree + per-dep vulnerability listing rendered terminal-side."""
    console.print("🐍 Starting comprehensive Python audit (legacy mode)…")
    script_path = os.path.join(os.path.dirname(__file__), 'audit_python_deps.py')
    if not os.path.exists(script_path):
        console.print(f"[red]Error: legacy audit script not found at {script_path}[/red]")
        sys.exit(1)
    if not os.access(script_path, os.X_OK):
        st = os.stat(script_path); os.chmod(script_path, st.st_mode | stat.S_IEXEC)

    try:
        result = subprocess.run(
            ['python3', script_path],
            capture_output=True, text=True, encoding='utf-8', timeout=300,
        )
        if result.returncode != 0:
            console.print(f"[red]Python audit script failed.[/red]")
            console.print(result.stderr); return
        report_data = json.loads(result.stdout)
        if output_json:
            console.print(json.dumps(report_data, indent=2))
        summary = {"total_vulnerabilities": len(report_data), "severity_distribution": {}}
        for vuln in report_data:
            sev = vuln.get("severity", "unknown").lower()
            summary["severity_distribution"][sev] = summary["severity_distribution"].get(sev, 0) + 1
        _resp = client.send_python_audit({
            "scan_results": {"dependency_tree": report_data},
            "summary": summary,
            "machine_name": _resolve_audit_machine_name(),
            "os_type": platform.system(),
            "computer_name": get_computer_name(),
            "scan_command": "xyz audit python --legacy",
        })
        _record_audit_scan_id("python", _resp)
        console.print("[green]✅ Legacy Python audit uploaded.[/green]")
    except Exception as e:
        console.print(f"[red]Legacy Python audit error: {e}[/red]")
        sys.exit(1)


# ---------------------------------------------------------------------------
# xyz audit go
# ---------------------------------------------------------------------------

@audit.command()
@click.option('--full', 'full_check', is_flag=True, default=False,
              help='Send every Go module through /proxy/check/batch instead '
                   'of the watchlist pre-filter.')
@click.option('--legacy', 'use_legacy_script', is_flag=True, default=False,
              help='Use the pre-1.4.13 audit_go_modules.py script with the '
                   'deps.dev advisory lookup. Slow (~30s for 224 modules).')
@click.option('--json', 'output_json', is_flag=True, help='Output audit results as JSON')
def go(full_check, use_legacy_script, output_json):
    """Audit Go modules in the GOPATH / current module.

    \b
    Default (1.4.13+): runs `go list -m -json all` (~1s), pre-filters via
    /watchlist?ecosystem=go, deep-checks only suspect names. Wall-clock
    ~5-10s vs the legacy ~30s.
    """
    init_client()

    if use_legacy_script:
        return _legacy_go_audit(output_json)

    console.print("🐹 Starting Go audit (watchlist mode)…")

    # Strategy: enumerate the user's Go module cache at $GOPATH/pkg/mod,
    # which is what audit_go_modules.py also crawls. Doesn't require a
    # go.mod in cwd (which `go list -m all` would). Module dirs are named
    # `<encoded_name>@<version>/` with `!X` escaping for capital letters
    # per https://golang.org/ref/mod#module-cache.
    go_path = os.environ.get('GOPATH') or os.path.expanduser('~/go')
    mod_root = os.path.join(go_path, 'pkg', 'mod')
    if not os.path.isdir(mod_root):
        console.print(f"[yellow]No Go module cache at {mod_root}. "
                      f"Run `go mod download` in a Go project first, or pass "
                      f"--legacy.[/yellow]")
        return

    def _decode_name(encoded: str) -> str:
        # `!a` → `A`, `!b` → `B`, etc. Used for case-insensitive filesystems.
        return re.sub(r'!([a-z])', lambda m: m.group(1).upper(), encoded)

    packages: List[Dict[str, Any]] = []
    seen: set = set()
    for root, dirs, _files in os.walk(mod_root):
        # Skip `cache/` (download cache) and `sumdb/` (checksum DB).
        rel = os.path.relpath(root, mod_root)
        if rel.startswith(('cache', 'sumdb')):
            dirs[:] = []
            continue
        for d in dirs:
            if '@' not in d:
                continue
            # Name is everything before the LAST '@' (handles names like
            # `gopkg.in/yaml.v2@2.4.0` and avoids splitting on `@` inside
            # the version which never happens but be safe).
            at = d.rfind('@')
            encoded_name = d[:at]
            version = d[at + 1:]
            if not encoded_name or not version:
                continue
            full_path = os.path.join(rel, encoded_name) if rel != '.' else encoded_name
            module_name = _decode_name(full_path).replace('\\', '/')
            key = (module_name, version)
            if key in seen:
                continue
            seen.add(key)
            packages.append({
                'name': module_name, 'version': version,
                'is_direct': False,  # cache walk can't distinguish direct vs transitive
                'depth': 0,
            })
        # Don't recurse into the @ versioned dirs themselves.
        dirs[:] = [d for d in dirs if '@' not in d]

    total = len(packages)
    if total == 0:
        console.print("[yellow]No Go modules found in current GOPATH / module.[/yellow]")
        return

    machine = _resolve_audit_machine_name()
    audit_result = client.smart_audit_via_watchlist(
        packages, ecosystem='go',
        machine_name=machine, os_type=platform.system(),
        full_check=full_check,
    )

    _render_audit_summary("Go", total, audit_result, output_json)

    # Inventory upload — server's go_audit branch reads either `packages` or
    # `modules` from scan_results (post-2026-05-06 fix). Send both keys for
    # compatibility with older api-backend revisions.
    inv_packages = [
        {'name': p['name'], 'version': p['version'],
         'is_direct': p.get('is_direct', False)}
        for p in packages
    ]
    try:
        _resp = client.send_go_audit({
            "scan_results": {"packages": inv_packages, "modules": inv_packages},
            "summary": {
                "total": total,
                "risky": len(audit_result['risky']),
                "clean": len(audit_result['clean']),
                "pre_filter_skipped": audit_result['pre_filter_skipped'],
            },
            "machine_name": machine,
            "os_type": platform.system(),
            "computer_name": get_computer_name(),
            "scan_command": "xyz audit go" + (" --full" if full_check else ""),
        })
        _record_audit_scan_id("go_audit", _resp)
        console.print("[green]✅ Go inventory uploaded.[/green]")
    except Exception as e:
        console.print(f"[yellow]⚠️  Upload failed (non-fatal): {e}[/yellow]")


def _legacy_go_audit(output_json: bool) -> None:
    """Pre-1.4.13 audit_go_modules.py path with deps.dev advisory lookup.
    Slower but renders the per-module trusted/untrusted/with-advisories table."""
    console.print("🐹 Starting Go module audit (legacy mode)…")
    script_path = os.path.join(os.path.dirname(__file__), 'audit_go_modules.py')
    if not os.path.exists(script_path):
        console.print(f"[red]Error: legacy script not found at {script_path}[/red]")
        sys.exit(1)
    try:
        result = subprocess.run(
            ['python3', script_path, '--json', '--stdout', '--quiet'],
            capture_output=True, text=True, timeout=120, check=False,
        )
        if not result.stdout:
            console.print(f"[red]Go audit script failed.[/red]")
            console.print(result.stderr or '(no stderr)'); sys.exit(1)
        audit_data = json.loads(result.stdout)
        if output_json:
            console.print(json.dumps(audit_data, indent=2))
        else:
            summary = audit_data.get('summary', {})
            console.print(f"  Total modules: {summary.get('total')}")
            console.print(f"  [red]With advisories: {summary.get('with_advisories')}[/red]")
        _resp = client.send_go_audit({
            **audit_data,
            "machine_name": _resolve_audit_machine_name(),
            "scan_command": "xyz audit go --legacy",
        })
        _record_audit_scan_id("go_audit", _resp)
        console.print("[green]✅ Legacy Go audit uploaded.[/green]")
    except Exception as e:
        console.print(f"[red]Legacy Go audit error: {e}[/red]")
        sys.exit(1)


# ---------------------------------------------------------------------------
# xyz audit nuget (1.4.13+)
# ---------------------------------------------------------------------------

@audit.command()
@click.option('--lock-file', 'lock_file', type=click.Path(exists=True), default=None,
              help='Path to a packages.lock.json file. Default: search the '
                   'current dir tree (skips node_modules / venv / .git).')
@click.option('--full', 'full_check', is_flag=True, default=False,
              help='Send every NuGet package through /proxy/check/batch '
                   'instead of the watchlist pre-filter.')
@click.option('--json', 'output_json', is_flag=True, help='Output audit results as JSON')
def nuget(lock_file, full_check, output_json):
    """Audit NuGet packages from a `packages.lock.json` file.

    \b
    NuGet's lock file (`dotnet restore --use-lock-file`) is the source of
    truth for what's actually pinned in the project. We parse the
    `dependencies[*]` map at every target framework, dedupe by
    (name, resolved_version), then run the same /watchlist + /proxy/check
    pipeline as the npm/pypi/go audits.

    \b
    Coverage: this catches every dependency the .NET CLI would actually
    install for this project (direct + transitive). It does NOT include
    machine-wide global tools — NuGet has no per-machine global package
    cache equivalent to npm's `-g`. Use `xyz check -p name@version
    -e nuget` for ad-hoc one-off checks.
    """
    init_client()
    console.print("📦 Starting NuGet audit (watchlist mode)…")

    # ── Locate the lock file(s) ──────────────────────────────────────────
    lock_paths: List[str] = []
    if lock_file:
        lock_paths.append(lock_file)
    else:
        # Skip dirs that almost never contain user .NET projects but ARE
        # huge (or get auto-recreated). The macOS Library + Applications
        # dirs are critical because the daemon's WorkingDirectory is
        # $HOME — without these excludes a single `xyz audit nuget` would
        # crawl Spotlight indexes / browser caches / Xcode caches and
        # take many minutes for nothing.
        skip_dirs = {
            'node_modules', '.git', 'bin', 'obj', '.venv', 'venv',
            '__pycache__', '.tox', '.nox', '.pytest_cache', '.mypy_cache',
            # macOS system / user-data dirs (large, no .NET projects)
            'Library', 'Applications', '.Trash', '.cache', '.npm',
            '.cargo', '.rustup', '.gradle', '.m2', '.go', '.android',
            '.docker', '.vscode', '.cursor', '.zsh_sessions',
            '.tldr', '.dotnet', '.nuget', '.kube', '.aws', '.gcp',
            'go', 'miniconda3', 'anaconda3', 'opt', 'mambaforge',
            # Generic vendor / build dirs
            'vendor', 'build', 'dist', 'target', 'out',
        }
        for root, dirs, files in os.walk(os.getcwd()):
            dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith('.')]
            for f in files:
                if f == 'packages.lock.json':
                    lock_paths.append(os.path.join(root, f))
        if not lock_paths:
            console.print(
                "[yellow]No packages.lock.json found below the current dir. "
                "Run [bold]dotnet restore --use-lock-file[/bold] in your "
                ".NET project first, or pass [bold]--lock-file <path>[/bold].[/yellow]"
            )
            return

    # ── Parse + dedupe ───────────────────────────────────────────────────
    seen: set = set()
    packages: List[Dict[str, Any]] = []
    for path in lock_paths:
        try:
            with open(path) as f:
                lock = json.load(f)
        except Exception as e:
            console.print(f"[yellow]⚠️  Failed to parse {path}: {e}[/yellow]")
            continue
        # NuGet lock file shape:
        #   { "version": 1, "dependencies": {
        #       "<framework>": { "<name>": { "type": "Direct"|"Transitive",
        #                                    "resolved": "1.2.3", … } }
        #   } }
        for fw_name, fw_deps in (lock.get('dependencies') or {}).items():
            if not isinstance(fw_deps, dict):
                continue
            for name, info in fw_deps.items():
                if not isinstance(info, dict):
                    continue
                version = info.get('resolved') or info.get('version')
                if not version:
                    continue
                key = (name.lower(), str(version))
                if key in seen:
                    continue
                seen.add(key)
                packages.append({
                    'name': name, 'version': str(version),
                    'is_direct': info.get('type', '').lower() == 'direct',
                    'lock_file': path, 'framework': fw_name,
                    'depth': 0 if info.get('type', '').lower() == 'direct' else 1,
                })

    total = len(packages)
    if total == 0:
        console.print("[yellow]No NuGet packages found in lock file(s).[/yellow]")
        return

    console.print(f"Parsed [bold]{total}[/bold] NuGet packages from {len(lock_paths)} lock file(s).")

    machine = _resolve_audit_machine_name()
    audit_result = client.smart_audit_via_watchlist(
        packages, ecosystem='nuget',
        machine_name=machine, os_type=platform.system(),
        full_check=full_check,
    )

    _render_audit_summary("NuGet", total, audit_result, output_json)

    # Inventory upload — uses scan_type='nuget_audit' which the server's
    # _AUDIT_SCAN_TYPES picks up as ecosystem='nuget' once
    # commit-companion-server lands. Older revisions silently ignore the
    # inventory normalization (cli_scans row still gets created).
    inv_packages = [
        {'name': p['name'], 'version': p['version'],
         'is_direct': p.get('is_direct', False),
         'source_path': p.get('lock_file')}
        for p in packages
    ]
    try:
        # Reuse send_python_audit's POST shape — the server's /scans
        # endpoint is scan_type-driven, not endpoint-name-driven.
        body = {
            "scan_type": "nuget_audit",
            "scan_command": "xyz audit nuget" + (" --full" if full_check else ""),
            "scan_results": {"packages": inv_packages},
            "summary": {
                "total_packages": total,
                "risky": len(audit_result['risky']),
                "clean": len(audit_result['clean']),
                "pre_filter_skipped": audit_result['pre_filter_skipped'],
            },
            "machine_name": machine,
            "os_type": platform.system(),
            "computer_name": get_computer_name(),
        }
        _resp = client._make_request('POST', '/api/v1/scans', data=body)
        _record_audit_scan_id("nuget_audit", _resp)
        console.print("[green]✅ NuGet inventory uploaded.[/green]")
    except Exception as e:
        console.print(f"[yellow]⚠️  Upload failed (non-fatal): {e}[/yellow]")


@audit.command()
@click.option('--global/--no-global', 'include_global', default=True,
              help='Include globally installed npm packages (default: --global). '
                   'Pre-1.4.12 the dual-flag pairing was broken — the CLI '
                   'silently defaulted to False so global packages never got '
                   'scanned from the terminal. The daemon was unaffected '
                   'because it passes include_global=True explicitly.')
@click.option('--full', 'full_check', is_flag=True, default=False,
              help='Force a full per-package /proxy/check/batch run instead '
                   'of the watchlist pre-filter. Slower (~12 min on 1000+ '
                   'packages), but covers advisory matches at scan time. '
                   'Default: pre-filter via /watchlist so only known-malicious '
                   'package names go through the deep batch check.')
@click.option('--json', 'output_json', is_flag=True, help='Output audit results as JSON')
def npm(include_global, full_check, output_json):
    """Audit npm packages actually installed on this machine.

    Scans node_modules (not just the lock file) so it catches packages
    that were installed before the proxy was configured, orphaned deps,
    and globally installed tools.

    \b
    Default (1.4.12+): smart pre-filter mode. Pulls the malicious-name
    watchlist once (~3s, cached 5 min), intersects with local packages,
    runs the slow /proxy/check/batch ONLY on the intersection (typically
    0-50 of 1000+ packages). Total wall-clock ~7-10s vs the legacy ~12
    min. Full inventory still uploads to the dashboard.
    """
    init_client()
    console.print("📦 Starting npm audit (reading actual node_modules, not lock file)…")

    def run_npm_ls(args):
        try:
            result = subprocess.run(
                ['npm', 'ls'] + args + ['--json'],
                capture_output=True, text=True, timeout=60, check=False
            )
            # npm ls exits non-zero if there are peer-dep issues but still emits valid JSON
            if result.stdout.strip():
                return json.loads(result.stdout)
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass
        except json.JSONDecodeError:
            pass
        return {}

    def flatten_deps(node, packages=None, depth=0):
        """Recursively flatten npm ls --json dependency tree into a list."""
        if packages is None:
            packages = []
        deps = node.get('dependencies', {})
        for name, info in deps.items():
            version = info.get('version', 'unknown')
            packages.append({'name': name, 'version': version, 'depth': depth})
            flatten_deps(info, packages, depth + 1)
        return packages

    # ── Scan local node_modules (current dir) ────────────────────────────
    local_tree = run_npm_ls(['--all'])
    local_pkgs = flatten_deps(local_tree)

    # ── Scan global npm packages ──────────────────────────────────────────
    global_pkgs = []
    if include_global:
        global_tree = run_npm_ls(['-g', '--all'])
        global_pkgs = flatten_deps(global_tree)
        for p in global_pkgs:
            p['scope'] = 'global'

    for p in local_pkgs:
        p.setdefault('scope', 'local')

    all_pkgs = local_pkgs + global_pkgs
    total = len(all_pkgs)

    if total == 0:
        console.print("[yellow]⚠️  No npm packages found. Run inside a project directory or install packages first.[/yellow]")
        return

    # Deduplicate by name@version — same package can appear many times in deep dep trees
    seen_versions: set = set()
    unique_pkgs, skipped_dupes = [], []
    for pkg in all_pkgs:
        key = f"{pkg['name']}@{pkg.get('version', 'unknown')}"
        if key not in seen_versions:
            seen_versions.add(key)
            unique_pkgs.append(pkg)
        else:
            skipped_dupes.append(pkg)

    checkable = [p for p in unique_pkgs if p.get('version') and p['version'] != 'unknown']
    uncheckable = [p for p in unique_pkgs if not p.get('version') or p['version'] == 'unknown']

    # ── Smart pre-filter (1.4.12+): /watchlist diff before deep check ────
    # The vast majority of installed packages are not in malicious_packages
    # — there's no point running a 7-DB-roundtrip /proxy/check on them.
    # Pull the malicious-name watchlist (one HTTP call, server-side filtered
    # to this ecosystem, ~3s for ~200k npm names), intersect with the local
    # set, and only batch-check the intersection. On a typical macOS dev
    # machine (~900 unique npm globals) this drops the deep-check set from
    # ~900 → 0-10 packages and the wall-clock from ~12 min → ~7s.
    #
    # `--full` opts back into the legacy all-packages /proxy/check path —
    # use that when you specifically want advisory (Signal D / vuln-match)
    # coverage at scan time instead of waiting for the platform's async
    # exposure compute.
    pre_filter_used = False
    pre_filter_skipped = 0
    if not full_check and checkable:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task("Fetching malicious-name watchlist…", total=None)
            watchlist = client.proxy_get_watchlist(ecosystem="npm")
        if watchlist:
            local_names = {p['name'] for p in checkable}
            suspect_names = local_names & watchlist
            suspect_pkgs = [p for p in checkable if p['name'] in suspect_names]
            pre_filter_skipped = len(checkable) - len(suspect_pkgs)
            pre_filter_used = True
        else:
            # Watchlist unavailable — fall through to the legacy full path.
            suspect_pkgs = checkable
            console.print(
                "[yellow]⚠️  Watchlist unreachable; falling back to full "
                "per-package check.[/yellow]"
            )
    else:
        suspect_pkgs = checkable

    console.print(
        f"Found [bold]{total}[/bold] packages "
        f"({len(local_pkgs)} local, {len(global_pkgs)} global). "
        f"[dim]{len(skipped_dupes)} duplicate name@version skipped[/dim]. "
        + (
            f"[dim]Pre-filter: {pre_filter_skipped} known-good auto-cleared[/dim]. "
            if pre_filter_used and pre_filter_skipped else ""
        )
        + f"Checking [bold]{len(suspect_pkgs)}[/bold] suspect"
        + (" (via watchlist diff)" if pre_filter_used else "")
        + " against XYZ…\n"
    )

    # ── Batch proxy check (1 HTTP call for all suspect packages) ─────────
    machine = get_computer_name() or socket.gethostname()
    os_type = platform.system()
    risky, clean, errors = [], [], []
    results_map: dict = {}

    if suspect_pkgs:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(f"Checking {len(suspect_pkgs)} packages via XYZ batch API…", total=None)
            batch_input = [{'package': p['name'], 'version': p['version'], 'ecosystem': 'npm'}
                           for p in suspect_pkgs]
            batch_results = client.proxy_check_batch(
                batch_input,
                machine_name=machine,
                os_type=os_type,
            )

        for i, result in enumerate(batch_results):
            pkg = suspect_pkgs[i]
            if isinstance(result, dict) and 'error' in result and 'decision' not in result:
                errors.append({'name': pkg['name'], 'version': pkg['version'], 'error': result['error']})
            else:
                decision = result.get('decision', 'allow')
                pkg['decision'] = decision
                pkg['signals'] = result.get('signals', [])
                pkg['safe_version'] = result.get('safe_version')
                results_map[f"{pkg['name']}@{pkg['version']}"] = decision
                if decision in ('block', 'quarantine'):
                    risky.append(pkg)
                else:
                    clean.append(pkg)

    # Mark all pre-filter-cleared packages as `allow` so the inventory
    # upload + summary line stay accurate. They were not in the malicious
    # watchlist, so by definition no Signal C or H block fires; advisory
    # (Signal D) coverage on these is deferred to the server's async
    # exposure compute.
    if pre_filter_used:
        suspect_set = {p['name'] for p in suspect_pkgs}
        for pkg in checkable:
            if pkg['name'] in suspect_set:
                continue
            pkg['decision'] = 'allow'
            pkg['signals'] = []
            pkg['safe_version'] = None
            clean.append(pkg)
            results_map[f"{pkg['name']}@{pkg['version']}"] = 'allow'

    # Propagate decisions to duplicate entries
    for pkg in skipped_dupes:
        key = f"{pkg['name']}@{pkg.get('version', 'unknown')}"
        pkg['decision'] = results_map.get(key, 'allow')

    # ── Summary ───────────────────────────────────────────────────────────
    if output_json:
        console.print(json.dumps({'risky': risky, 'clean': clean, 'errors': errors}, indent=2))
    else:
        if risky:
            table = Table(title=f"⚠️  Risky Packages ({len(risky)})", show_header=True)
            table.add_column("Package", style="red bold")
            table.add_column("Version", style="yellow")
            table.add_column("Scope")
            table.add_column("Decision", style="red")
            table.add_column("Safe Version", style="green")
            for p in risky:
                table.add_row(p['name'], p['version'], p.get('scope','local'),
                              p['decision'], p.get('safe_version') or '—')
            console.print(table)
        else:
            console.print(f"[green]✅ All {len(clean)} packages clean.[/green]")

        console.print(f"\n  Total scanned: {total}  |  Risky: {len(risky)}  |  Clean: {len(clean)}  |  Errors: {len(errors)}")

    # ── Upload to platform ────────────────────────────────────────────────
    try:
        console.print("\nUploading npm audit report to the platform…")
        _resp = client.send_npm_audit({
            'packages': all_pkgs,
            'summary': {
                'total_packages': total,
                'risky': len(risky),
                'clean': len(clean),
                'errors': len(errors),
            },
            # Resolve from /whoami so audit inventory tags the proxy_token's
            # machine_name, not the local hostname (see _resolve_audit_machine_name).
            'machine_name': _resolve_audit_machine_name(),
            'os_type': platform.system(),
            'computer_name': get_computer_name(),
            'scan_command': 'xyz audit npm',
        })
        _record_audit_scan_id("npm_audit", _resp)
        console.print("[green]✅ Successfully uploaded npm audit report.[/green]")
    except Exception as e:
        console.print(f"[yellow]⚠️  Upload failed (non-fatal): {e}[/yellow]")


# ── Proxy commands ────────────────────────────────────────────────────────────

@cli.group()
def proxy():
    """Manage the XYZ npm safety proxy."""
    pass


@proxy.command()
@click.option('--machine-name', default=None,
              help='Human-readable name for this machine (e.g. "amro-macbook"). '
                   'Defaults to hostname.')
@click.option('--proxy-url', default='https://xyz-npm-proxy-243883377485.us-central1.run.app',
              show_default=True, help='XYZ npm proxy URL.')
@click.option('--pip-proxy-url', default='https://xyz-pip-proxy-243883377485.us-central1.run.app',
              show_default=True, help='XYZ pip proxy URL.')
@click.option('--local', 'use_local', is_flag=True,
              help='Point to local proxy (http://localhost:4873) for testing.')
@click.option('--install-daemon/--no-install-daemon', 'install_daemon', default=True,
              help='Also register the OS service (LaunchAgent / systemd / Task '
                   'Scheduler) that polls for dashboard "Scan now" jobs. Default '
                   'on. Pass --no-install-daemon for CI build agents or any '
                   'environment where you do not want a long-running background '
                   'process.')
def setup(machine_name, proxy_url, pip_proxy_url, use_local, install_daemon):
    """Configure npm and pip to route installs through the XYZ safety proxy.

    Your API key is sent as the auth token so the platform can attribute
    proxy activity to your account and organisation — org_id is resolved
    server-side from your key, never from a client-supplied env var.

    \b
    What this writes:
      ~/.npmrc          → registry + _authToken (npm proxy)
      pip global config → index-url with embedded token (pip proxy)
      OS service        → LaunchAgent (mac) / systemd --user (linux) /
                          Task Scheduler (windows) — auto-installed in
                          1.4.16+ so the dashboard "Scan now" button works
                          out of the box. Pass --no-install-daemon to skip.

    Run this once per machine. Every subsequent npm/pip install will be
    checked and logged under your org automatically, AND the dashboard
    can trigger fresh inventory audits with one click.
    """
    init_client()

    if use_local:
        proxy_url = 'http://localhost:4873'

    # ── Get token from config (login saves access_token JWT) ────────────────
    import json as _json
    token = None
    config_file = os.path.join(os.path.expanduser('~/.xyz'), 'config.json')
    if os.path.exists(config_file):
        with open(config_file) as f:
            cfg = _json.load(f)
        # Prefer sk_xyz_ API key if present, fall back to JWT access_token
        token = cfg.get('api_key') or cfg.get('sk_xyz_key') or cfg.get('access_token')

    if not token:
        token = os.getenv('XYZ_API_KEY')

    if not token:
        console.print("[red]❌ Not logged in. No credentials found.[/red]")
        console.print("Run [bold]xyz login[/bold] first.")
        sys.exit(1)

    # ── Resolve machine name ──────────────────────────────────────────────
    if not machine_name:
        machine_name = get_computer_name() or socket.gethostname()

    # ── Register machine server-side → get a px_xyz_ token ───────────────
    # This stores machine_name in the proxy_tokens table so that every
    # npm install through the proxy is attributed to this machine by name.
    api_url = os.getenv('XYZ_API_URL', 'https://api.cyberxyz.io').rstrip('/')
    proxy_token = None
    try:
        resp = _requests.post(
            f'{api_url}/api/v1/proxy/register-machine',
            json={'machine_name': machine_name, 'description': f'Registered by xyz proxy setup on {socket.gethostname()}'},
            headers={'Authorization': f'Bearer {token}'},
            timeout=30,
        )
        if resp.status_code == 200:
            proxy_token = resp.json()['token']
            console.print(f"[green]✅ Machine registered:[/green] [cyan]{machine_name}[/cyan] → token [dim]{proxy_token[:20]}…[/dim]")
        elif resp.status_code == 401:
            console.print("[red]❌ Your session has expired.[/red]")
            console.print("   Run [bold]xyz login[/bold] and then re-run [bold]xyz proxy setup[/bold].")
            sys.exit(1)
        else:
            console.print(f"[red]❌ Could not register machine ({resp.status_code}): {resp.text[:200]}[/red]")
            console.print("   Aborting setup to avoid writing a dead token to npm/pip config.")
            sys.exit(1)
    except _requests.RequestException as e:
        console.print(f"[red]❌ Registration API unavailable: {e}[/red]")
        console.print("   Aborting setup. Check network / API status and retry.")
        sys.exit(1)

    # ── Write .npmrc ──────────────────────────────────────────────────────
    from urllib.parse import urlparse
    parsed = urlparse(proxy_url)
    proxy_host = parsed.netloc  # e.g. xyz-npm-proxy-243883377485.us-central1.run.app

    npmrc_path = os.path.expanduser('~/.npmrc')
    proxy_registry_line = f'registry={proxy_url}'
    proxy_auth_line = f'//{proxy_host}/:_authToken={proxy_token}'

    existing = ''
    if os.path.exists(npmrc_path):
        with open(npmrc_path) as f:
            existing = f.read()

    # Remove any existing xyz proxy lines to avoid duplicates
    lines = [l for l in existing.splitlines()
             if 'xyz-npm-proxy' not in l and 'localhost:4873' not in l
             and not l.strip().startswith('registry=')]
    lines = [proxy_registry_line, proxy_auth_line] + lines

    with open(npmrc_path, 'w') as f:
        f.write('\n'.join(lines) + '\n')

    console.print(f"\n[green]✅ .npmrc updated:[/green]")
    console.print(f"   registry     → [cyan]{proxy_url}[/cyan]")
    token_type = 'machine proxy token' if proxy_token.startswith('px_xyz_') else 'login token'
    console.print(f"   _authToken   → [dim]{proxy_token[:20]}…[/dim] ({token_type})")
    console.print(f"   machine name → [cyan]{machine_name}[/cyan]")

    # ── Configure pip proxy ──────────────────────────────────────────────
    # Embed the proxy token as Basic auth credentials in the index URL.
    # pip sends these as Authorization: Basic base64(__token__:<token>)
    # which the pip proxy extracts and forwards to the API for attribution.
    pip_parsed = urlparse(pip_proxy_url)
    pip_index_url = f"{pip_parsed.scheme}://__token__:{proxy_token}@{pip_parsed.netloc}/simple/"

    import subprocess as _sp
    try:
        _sp.run(['pip3', 'config', 'set', 'global.index-url', pip_index_url],
                capture_output=True, timeout=10)
        _sp.run(['pip3', 'config', 'set', 'global.timeout', '120'],
                capture_output=True, timeout=10)
        console.print(f"\n[green]✅ pip config updated:[/green]")
        console.print(f"   index-url    → [cyan]{pip_proxy_url}/simple/[/cyan] (token embedded)")
        console.print(f"   timeout      → 120s (handles Cloud Run cold starts)")
    except Exception as e:
        console.print(f"\n[yellow]⚠️  Could not configure pip ({e}).[/yellow]")
        console.print(f"   Run manually: [dim]pip3 config set global.index-url {pip_index_url}[/dim]")

    console.print()
    console.print("Every [bold]npm install[/bold] and [bold]pip install[/bold] will now be checked and logged under your org.")

    # ── Install the OS service (1.4.16+) ─────────────────────────────────
    # The dashboard's "Scan now" button needs a long-running daemon to
    # pick up admin-triggered scan_jobs and execute them. Pre-1.4.16
    # users had to run `xyz proxy daemon --install-service` separately,
    # which surprised every prospect on first onboarding. Default to
    # auto-install. Customers in CI / sealed-build environments pass
    # --no-install-daemon to opt out.
    if install_daemon:
        console.print()
        console.print("[bold]Installing the dashboard scan daemon…[/bold]")
        try:
            _handle_service_install(install=True)
        except SystemExit as e:
            # _handle_service_install sys.exits on platform-specific
            # failures (e.g. missing systemctl on a non-systemd Linux).
            # Don't crash the whole setup — the proxy config is already
            # written and useful on its own. Print a friendly fallback.
            if e.code not in (None, 0):
                console.print(
                    "[yellow]⚠️  Daemon install was skipped. The proxy + "
                    "inventory parts of setup are still active. "
                    "Re-run [bold]xyz proxy daemon --install-service[/bold] "
                    "manually if you want the dashboard 'Scan now' button.[/yellow]"
                )
        except Exception as e:
            console.print(
                f"[yellow]⚠️  Daemon install raised {type(e).__name__}: {e}. "
                f"Setup is otherwise complete; run "
                f"[bold]xyz proxy daemon --install-service[/bold] later.[/yellow]"
            )
    else:
        console.print()
        console.print("[dim]Daemon install skipped (--no-install-daemon). "
                      "The dashboard 'Scan now' button will not work on this "
                      "machine. To enable: xyz proxy daemon --install-service[/dim]")


@proxy.command()
def status():
    """Show current proxy configuration for both npm and pip."""
    npmrc_path = os.path.expanduser('~/.npmrc')
    machine = os.getenv('XYZ_MACHINE_NAME') or get_computer_name()

    console.print("[bold]XYZ Proxy Status[/bold]")
    console.print(f"  Machine name: {machine}\n")

    # --- npm ---
    console.print("[bold]npm[/bold]")
    npm_configured = False
    if os.path.exists(npmrc_path):
        with open(npmrc_path) as f:
            lines = f.read().splitlines()
        registry = next((l for l in lines if l.startswith('registry=')), None)
        token_line = next((l for l in lines if '_authToken=' in l), None)
        console.print(f"  Registry    : {registry or '[red]not set[/red]'}")
        console.print(f"  Auth token  : {'[green]set[/green]' if token_line else '[red]not set[/red]'}")
        npm_configured = bool(registry and 'xyz-npm-proxy' in registry)
    else:
        console.print("  [yellow]~/.npmrc not found[/yellow]")

    # --- pip ---
    console.print("\n[bold]pip[/bold]")
    pip_index_url = None
    pip_configured = False
    try:
        result = subprocess.run(
            ['pip3', 'config', 'get', 'global.index-url'],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            pip_index_url = (result.stdout or '').strip() or None
    except Exception:
        pass
    if pip_index_url:
        # Mask the embedded token in the displayed URL.
        masked = re.sub(r'__token__:[^@]+@', '__token__:***@', pip_index_url)
        console.print(f"  Index URL   : {masked}")
        pip_configured = ('xyz-pip-proxy' in pip_index_url) or ('localhost:8080' in pip_index_url)
    else:
        console.print("  [yellow]pip global.index-url not set[/yellow]")

    console.print()
    if npm_configured and pip_configured:
        console.print("[green]✅ Proxy is configured for both npm and pip.[/green]")
    elif npm_configured or pip_configured:
        which = 'npm' if npm_configured else 'pip'
        other = 'pip' if npm_configured else 'npm'
        console.print(f"[yellow]⚠️  Only {which} is configured. Re-run [bold]xyz proxy setup[/bold] to also wire {other}.[/yellow]")
    else:
        console.print("[yellow]⚠️  Proxy not configured. Run [bold]xyz proxy setup[/bold].[/yellow]")


@proxy.command()
def whoami():
    """Diagnose what the backend resolves your proxy token to.

    If `xyz proxy logs` shows machine_name='--' for your installs, run this
    to confirm whether your .npmrc / pip index-url is wired with a px_xyz_
    token (carries a machine name) or a sk_xyz_ / JWT (no machine attribution).
    """
    npmrc_path = os.path.expanduser('~/.npmrc')
    token = None
    if os.path.exists(npmrc_path):
        with open(npmrc_path) as f:
            for line in f:
                line = line.strip()
                if '_authToken=' in line:
                    token = line.split('_authToken=', 1)[1].strip()
                    break
    if not token:
        console.print("[yellow]No _authToken found in ~/.npmrc.[/yellow] Run [bold]xyz proxy setup[/bold] first.")
        return

    api_url = os.getenv('XYZ_API_URL', 'https://api.cyberxyz.io').rstrip('/')
    try:
        resp = _requests.get(
            f'{api_url}/api/v1/proxy/whoami',
            headers={'Authorization': f'Bearer {token}'},
            timeout=15,
        )
    except _requests.RequestException as e:
        console.print(f"[red]API unreachable:[/red] {e}")
        return
    if resp.status_code != 200:
        console.print(f"[red]whoami failed ({resp.status_code}):[/red] {resp.text[:200]}")
        return
    data = resp.json()
    console.print("[bold]Proxy whoami[/bold]")
    console.print(f"  Token type   : [cyan]{data.get('token_type')}[/cyan]")
    console.print(f"  Org ID       : {data.get('org_id') or '[red]not resolved[/red]'}")
    machine = data.get('machine_name')
    if machine:
        console.print(f"  Machine name : [green]{machine}[/green]")
    else:
        console.print("  Machine name : [yellow]— (will appear as '--' in install logs)[/yellow]")
    if data.get('fix_hint'):
        console.print(f"\n[dim]{data['fix_hint']}[/dim]")


@proxy.command()
def remove():
    """Remove XYZ proxy configuration from .npmrc, restoring default npm registry."""
    npmrc_path = os.path.expanduser('~/.npmrc')
    if not os.path.exists(npmrc_path):
        console.print("[yellow]No ~/.npmrc found — nothing to remove.[/yellow]")
        return

    with open(npmrc_path) as f:
        lines = f.read().splitlines()

    cleaned = [l for l in lines
               if 'xyz-npm-proxy' not in l
               and 'localhost:4873' not in l
               and not l.strip().startswith('registry=')]

    with open(npmrc_path, 'w') as f:
        f.write('\n'.join(cleaned) + '\n')

    console.print("[green]✅ XYZ proxy removed from .npmrc. npm will use the default registry.[/green]")


def _read_proxy_token_from_npmrc() -> Optional[str]:
    """Read the px_xyz_ machine proxy token written by `xyz proxy setup`.

    Match strategy (npm uses last-value-wins when a key is duplicated, and
    `xyz proxy setup` may APPEND on re-register, so a naive "first match"
    parser silently picks the OLD token):

      1. Prefer lines scoped to a cyberxyz proxy host
         (e.g. `//xyz-npm-proxy-...:_authToken=...`).
      2. Among those, take the LAST one (mirrors npm's own resolution).
      3. Fallback: any other `_authToken=` line, also LAST one.

    Returns None if no token line is found. The daemon needs a px_xyz_
    specifically (not sk_xyz_) because /proxy/jobs/poll derives the
    (org, machine) tuple from the proxy_tokens row.
    """
    npmrc_path = os.path.expanduser('~/.npmrc')
    if not os.path.exists(npmrc_path):
        return None
    scoped: List[str] = []
    unscoped: List[str] = []
    try:
        with open(npmrc_path) as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith('#'):
                    continue
                if '_authToken=' not in line:
                    continue
                token = line.split('_authToken=', 1)[1].strip()
                # Strip optional surrounding quotes (`"px_..."` or `'px_...'`)
                if len(token) >= 2 and token[0] == token[-1] and token[0] in ('"', "'"):
                    token = token[1:-1]
                if not token:
                    continue
                # Lines scoped to a cyberxyz proxy take precedence over
                # unscoped or unrelated registry tokens.
                lower = line.lower()
                if 'xyz-npm-proxy' in lower or 'xyz-pip-proxy' in lower or 'cyberxyz' in lower:
                    scoped.append(token)
                else:
                    unscoped.append(token)
    except OSError:
        return None
    if scoped:
        return scoped[-1]
    if unscoped:
        return unscoped[-1]
    return None


def _execute_scan_job(
    ctx: click.Context,
    scan_type: str,
    audit_paths: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Run the audit work for a scan_type pulled from /poll.

    For scan_type='full' we run npm + python + go back-to-back (the same
    behavior as `xyz audit` with no subcommand). For a specific ecosystem
    we invoke just that audit subcommand. We return the cli_scan_id of
    the LAST successfully uploaded audit (which is the one the
    /complete handler stores on scan_jobs.result_scan_id) plus a list
    of every (scan_type, scan_id) recorded during this job for logging.

    audit_paths (1.4.9+): If set, run each audit subcommand once per
    path with that path as cwd. Lets the launchd-spawned daemon escape
    its $HOME WorkingDirectory and actually find node_modules in the
    user's project dirs. If empty/None we run once in the current cwd
    (preserving pre-1.4.9 behavior).
    """
    _LAST_AUDIT_SCAN_ID.clear()

    targets: List[tuple] = []
    if scan_type == 'full':
        targets = [
            ('npm_audit',   npm,   {'include_global': True, 'output_json': False}),
            ('python',      python,{'output_json': False}),
            ('go_audit',    go,    {'output_json': False}),
            # 1.4.15+: nuget joins the rotation. The command exits cleanly
            # when no packages.lock.json exists below cwd, so on machines
            # without .NET projects this is a sub-second no-op.
            ('nuget_audit', nuget, {'lock_file': None, 'output_json': False}),
        ]
    elif scan_type == 'npm_audit':
        targets = [('npm_audit', npm, {'include_global': True, 'output_json': False})]
    elif scan_type == 'python':
        targets = [('python', python, {'output_json': False})]
    elif scan_type == 'go_audit':
        targets = [('go_audit', go, {'output_json': False})]
    elif scan_type == 'nuget_audit':
        targets = [('nuget_audit', nuget, {'lock_file': None, 'output_json': False})]
    else:
        raise click.ClickException(f"Unknown scan_type: {scan_type}")

    # Default to a single pass at current cwd. If admin specified
    # explicit paths in scan_jobs.params.audit_paths, sweep each path
    # independently — every iteration uploads its own /scans payload
    # so the dashboard sees per-path inventory.
    paths_to_sweep: List[Optional[str]] = [None]
    if audit_paths:
        valid = [p for p in audit_paths if isinstance(p, str) and p.strip()]
        if valid:
            paths_to_sweep = list(valid)

    failures: List[str] = []
    original_cwd = os.getcwd()
    for path in paths_to_sweep:
        if path:
            try:
                os.chdir(os.path.expanduser(path))
            except OSError as e:
                failures.append(f"chdir({path}):{type(e).__name__}")
                continue
        for label, cmd, kwargs in targets:
            try:
                ctx.invoke(cmd, **kwargs)
            except SystemExit as e:
                if e.code not in (None, 0):
                    failures.append(label if not path else f"{label}@{path}")
            except Exception as e:
                tag = label if not path else f"{label}@{path}"
                failures.append(f"{tag}:{type(e).__name__}")
    # Always restore cwd in case a subsequent function call relies on it.
    try:
        os.chdir(original_cwd)
    except OSError:
        pass

    last_scan_id: Optional[int] = None
    for label, _, _ in targets:
        sid = _LAST_AUDIT_SCAN_ID.get(label)
        if isinstance(sid, int):
            last_scan_id = sid

    return {
        'cli_scan_id': last_scan_id,
        'recorded': dict(_LAST_AUDIT_SCAN_ID),
        'failures': failures,
        'attempted': [label for label, _, _ in targets],
        'paths_swept': [p for p in paths_to_sweep if p],
    }


@proxy.command()
@click.option('--api-url', default=None,
              help='XYZ API base URL. Defaults to $XYZ_API_URL or https://api.cyberxyz.io.')
@click.option('--poll-interval', default=10, show_default=True, type=int,
              help='Seconds to sleep between empty polls (job available → no sleep).')
@click.option('--once', is_flag=True,
              help='Poll exactly once and exit. Useful for cron / launchd schedules.')
@click.option('--max-jobs', default=0, type=int,
              help='Exit after processing N jobs (0 = run forever).')
@click.option('--install-service', is_flag=True,
              help='Cross-platform: install the daemon as an OS service. '
                   'macOS → LaunchAgent (~/Library/LaunchAgents/...). '
                   'Linux → systemd --user unit (~/.config/systemd/user/...). '
                   'Windows → Task Scheduler entry (run at logon). '
                   'Auto-restarts on crash on every platform.')
@click.option('--uninstall-service', is_flag=True,
              help='Remove the OS service installed by --install-service.')
@click.option('--install-launchd', is_flag=True,
              help='[DEPRECATED — use --install-service instead] macOS LaunchAgent installer.')
@click.option('--uninstall-launchd', is_flag=True,
              help='[DEPRECATED — use --uninstall-service instead] LaunchAgent remover.')
@click.pass_context
def daemon(ctx, api_url, poll_interval, once, max_jobs,
           install_service, uninstall_service, install_launchd, uninstall_launchd):
    """Long-poll for admin-triggered scan jobs and execute them.

    \b
    The platform exposes a "Scan now" button per machine. When the org
    admin clicks it, a row is queued in scan_jobs. This command polls
    /api/v1/proxy/jobs/poll, atomically claims one job at a time, runs
    the matching `xyz audit` flow, and reports the resulting cli_scan_id
    back via /proxy/jobs/{id}/complete.

    \b
    Auth model:
      • This loop uses the px_xyz_ proxy token written by `xyz proxy
        setup` (read from ~/.npmrc) for /poll and /complete — those
        endpoints derive (org, machine) from the token row.
      • The audit subcommands themselves still upload via the user's
        sk_xyz_ key from ~/.xyz/config.json (unchanged path).

    \b
    Run modes:
      xyz proxy daemon                      # forever, sleeps 10s between idle polls
      xyz proxy daemon --once               # one poll, then exit (cron-friendly)
      xyz proxy daemon --max-jobs 3
      xyz proxy daemon --install-service    # mac/linux/windows: auto-start on login
      xyz proxy daemon --uninstall-service  # remove the OS service
    """
    if install_service or uninstall_service:
        return _handle_service_install(install=install_service)
    if install_launchd or uninstall_launchd:
        # Deprecated alias — preserved so existing 1.4.x docs / scripts keep working.
        return _handle_launchd_install(install=install_launchd)
    api_url = (api_url or os.getenv('XYZ_API_URL') or 'https://api.cyberxyz.io').rstrip('/')

    proxy_token = _read_proxy_token_from_npmrc()
    if not proxy_token:
        console.print("[red]❌ No proxy token found in ~/.npmrc.[/red]")
        console.print("   Run [bold]xyz proxy setup[/bold] first to register this machine.")
        sys.exit(1)
    if not proxy_token.startswith('px_xyz_'):
        console.print("[yellow]⚠️  ~/.npmrc auth token does not look like a machine proxy "
                      "token (px_xyz_…).[/yellow]")
        console.print("   The daemon needs a machine token to poll for jobs. "
                      "Re-run [bold]xyz proxy setup[/bold].")
        sys.exit(1)

    headers = {'Authorization': f'Bearer {proxy_token}'}

    # Resolve the token's identity SERVER-SIDE so the display matches the
    # machine_name jobs are actually queued for (not the local hostname,
    # which can drift after `xyz proxy setup --machine-name <other>`).
    machine_label = get_computer_name() or socket.gethostname()
    try:
        whoami = _requests.get(
            f'{api_url}/api/v1/proxy/whoami',
            headers=headers,
            timeout=10,
        )
        if whoami.status_code == 200:
            resolved = whoami.json().get('machine_name')
            if resolved:
                machine_label = resolved
        else:
            console.print(
                f"[yellow]/whoami returned {whoami.status_code} — falling back "
                f"to local hostname for display.[/yellow]"
            )
    except _requests.RequestException as e:
        console.print(
            f"[yellow]/whoami probe failed ({e}) — using local hostname "
            f"for display only.[/yellow]"
        )
    console.print(f"[bold]xyz proxy daemon[/bold] polling {api_url} for [cyan]{machine_label}[/cyan]")
    if once:
        console.print("[dim]Mode: one-shot (--once)[/dim]")
    elif max_jobs:
        console.print(f"[dim]Mode: bounded ({max_jobs} jobs)[/dim]")
    else:
        console.print(f"[dim]Mode: forever, sleep {poll_interval}s between idle polls[/dim]")

    import time as _time
    jobs_done = 0
    try:
        while True:
            try:
                resp = _requests.get(
                    f'{api_url}/api/v1/proxy/jobs/poll',
                    headers=headers,
                    timeout=30,
                )
            except _requests.RequestException as e:
                console.print(f"[yellow]Poll failed: {e}; backing off {poll_interval}s…[/yellow]")
                if once:
                    sys.exit(1)
                _time.sleep(poll_interval)
                continue

            if resp.status_code == 401:
                console.print("[red]❌ Proxy token rejected by /jobs/poll (401). "
                              "Re-run [bold]xyz proxy setup[/bold].[/red]")
                sys.exit(1)
            if resp.status_code == 204 or (resp.status_code == 200 and not resp.content):
                # No pending jobs.
                if once:
                    console.print("[dim]No pending jobs.[/dim]")
                    return
                _time.sleep(poll_interval)
                continue
            if resp.status_code != 200:
                console.print(f"[yellow]Unexpected /poll status {resp.status_code}: "
                              f"{resp.text[:200]}[/yellow]")
                if once:
                    sys.exit(1)
                _time.sleep(poll_interval)
                continue

            try:
                payload = resp.json()
            except ValueError:
                console.print(f"[yellow]Could not parse /poll JSON: {resp.text[:200]}[/yellow]")
                if once:
                    sys.exit(1)
                _time.sleep(poll_interval)
                continue

            # CRITICAL: server returns the job dict DIRECTLY (no {"job": {...}}
            # wrapper). Reading payload.get('job') returned None for every
            # claim since 1.4.4 — root cause of "daemon claims but never
            # audits / completes" pre-1.4.9. Handle both shapes for safety:
            #   - new (current server): payload is the job dict, has 'job_id'
            #   - legacy (if server ever wrapped): payload has 'job' key
            if not isinstance(payload, dict):
                job = None
            elif 'job' in payload and isinstance(payload['job'], dict):
                job = payload['job']
            elif 'job_id' in payload:
                job = payload
            else:
                job = None
            if not job:
                if once:
                    console.print("[dim]No pending jobs.[/dim]")
                    return
                _time.sleep(poll_interval)
                continue

            # Server-side /poll response uses key 'job_id', NOT 'id'.
            # Bug pre-1.4.8: read 'id' which returned None, daemon then
            # called /api/v1/proxy/jobs/None/complete (404), every claim
            # silently failed since 1.4.4. Fixed by matching the server
            # response key here.
            job_id = job.get('job_id') or job.get('id')
            scan_type = job.get('scan_type', 'full')
            if not job_id:
                console.print(
                    "[red]Claimed a job but server response had no job_id "
                    f"key. Response: {job}[/red]"
                )
                _time.sleep(poll_interval)
                continue
            console.print(f"\n[bold]-> Claimed job[/bold] {job_id}  scan_type=[cyan]{scan_type}[/cyan]")

            # Track this job globally so atexit can finalize it as 'failed'
            # if the daemon process is killed before /complete returns.
            global _DAEMON_ACTIVE_JOB
            _DAEMON_ACTIVE_JOB = {
                'job_id': job_id,
                'api_url': api_url,
                'headers': headers,
            }

            status_to_report = 'completed'
            error_message: Optional[str] = None
            cli_scan_id: Optional[int] = None
            try:
                try:
                    result = _execute_scan_job(ctx, scan_type)
                    cli_scan_id = result['cli_scan_id']
                    if result['failures']:
                        # Partial success: some ecosystems failed. We still report
                        # 'completed' if at least one upload landed (cli_scan_id set);
                        # otherwise the whole job is a failure.
                        if cli_scan_id is None:
                            status_to_report = 'failed'
                            error_message = (
                                f"All ecosystems failed: {', '.join(result['failures'])}"
                            )
                        else:
                            error_message = (
                                f"Partial: failed=[{','.join(result['failures'])}] "
                                f"recorded={list(result['recorded'].keys())}"
                            )
                except Exception as e:
                    status_to_report = 'failed'
                    error_message = f"{type(e).__name__}: {e}"
                    console.print(f"[red]Job {job_id} crashed: {error_message}[/red]")

                try:
                    complete_body: Dict[str, Any] = {'status': status_to_report}
                    if cli_scan_id is not None:
                        complete_body['cli_scan_id'] = cli_scan_id
                    if error_message is not None:
                        complete_body['error_message'] = error_message
                    cresp = _requests.post(
                        f'{api_url}/api/v1/proxy/jobs/{job_id}/complete',
                        headers=headers,
                        json=complete_body,
                        timeout=30,
                    )
                    if cresp.status_code == 200:
                        console.print(
                            f"[green]Reported job {job_id} status={status_to_report}"
                            + (f" cli_scan_id={cli_scan_id}" if cli_scan_id else "")
                            + "[/green]"
                        )
                    else:
                        console.print(
                            f"[yellow]/complete returned {cresp.status_code}: "
                            f"{cresp.text[:200]}[/yellow]"
                        )
                except _requests.RequestException as e:
                    console.print(f"[yellow]Failed to report job {job_id}: {e}[/yellow]")
            finally:
                # Job processing is over (success, failure, or partial). Clear
                # the active-job tracker so the atexit finalizer doesn't try
                # to mark it failed if the daemon exits cleanly afterwards.
                _DAEMON_ACTIVE_JOB = None

            jobs_done += 1
            if once:
                return
            if max_jobs and jobs_done >= max_jobs:
                console.print(f"[dim]Reached --max-jobs={max_jobs}; exiting.[/dim]")
                return
    except KeyboardInterrupt:
        console.print("\n[yellow]daemon interrupted; exiting.[/yellow]")
        return


# Log Viewer Commands
@cli.group()
@click.pass_context
def logs(ctx):
    """Log viewer and management commands."""
    init_client()

@logs.command()
@click.option('--file-type', type=click.Choice(['csv', 'evtx', 'txt', 'log', 'json']), help='Filter by file type')
@click.option('--status', default='active', type=click.Choice(['active', 'archived', 'deleted']), help='Filter by status')
@click.option('--limit', default=50, help='Maximum number of files to show')
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def list(ctx, file_type, status, limit, output_json):
    """List available log files."""
    try:
        result = client.list_log_files(file_type=file_type, status=status, limit=limit)
        
        if output_json:
            console.print(json.dumps(result, indent=2))
            return
        
        if not result.get('log_files'):
            console.print("[yellow]No log files found.[/yellow]")
            return
        
        table = Table(title="Log Files")
        table.add_column("ID", style="cyan")
        table.add_column("Filename", style="magenta")
        table.add_column("Type", style="blue")
        table.add_column("Size", justify="right")
        table.add_column("Entries", justify="right")
        table.add_column("Created", style="green")
        table.add_column("Status", style="yellow")
        
        for log_file in result['log_files']:
            size_mb = f"{log_file.get('file_size', 0) / 1024 / 1024:.2f} MB"
            created = log_file.get('created_at', '')[:19] if log_file.get('created_at') else 'Unknown'
            
            table.add_row(
                str(log_file.get('id', '')),
                log_file.get('filename', ''),
                log_file.get('file_type', '').upper(),
                size_mb,
                str(log_file.get('total_entries', 0)),
                created,
                log_file.get('status', '').upper()
            )
        
        console.print(table)
        
    except Exception as e:
        console.print(f"[red]Error listing log files:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('log_id', type=int)
@click.option('--level', type=click.Choice(['DEBUG', 'INFO', 'WARN', 'WARNING', 'ERROR', 'CRITICAL', 'FATAL']), help='Filter by log level')
@click.option('--search', help='Search for specific text in log entries')
@click.option('--start-time', help='Start time filter (ISO format)')
@click.option('--end-time', help='End time filter (ISO format)')
@click.option('--limit', default=100, help='Maximum number of entries to show')
@click.option('--tail', is_flag=True, help='Show latest entries first')
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def view(ctx, log_id, level, search, start_time, end_time, limit, tail, output_json):
    """View log entries from a specific log file."""
    try:
        # Get log file info first
        log_file = client.get_log_file(log_id)
        
        # Get log entries
        entries_result = client.get_log_entries(
            log_id=log_id,
            level=level,
            search=search,
            start_time=start_time,
            end_time=end_time,
            limit=limit
        )
        
        if output_json:
            console.print(json.dumps({
                'log_file': log_file,
                'entries': entries_result
            }, indent=2))
            return
        
        # Display log file info
        console.print(Panel(
            f"[bold]File:[/bold] {log_file.get('filename')}\n"
            f"[bold]Type:[/bold] {log_file.get('file_type', '').upper()}\n"
            f"[bold]Total Entries:[/bold] {log_file.get('total_entries', 0):,}\n"
            f"[bold]Size:[/bold] {log_file.get('file_size', 0) / 1024 / 1024:.2f} MB",
            title="Log File Information"
        ))
        
        entries = entries_result.get('entries', [])
        if not entries:
            console.print("[yellow]No log entries found matching the criteria.[/yellow]")
            return
        
        # Handle CSV files with table view
        if log_file.get('file_type') == 'csv':
            console.print(f"\n[bold]Showing {len(entries)} entries:[/bold]")
            table = Table(show_header=True, header_style="bold magenta")
            
            # Add columns dynamically based on CSV structure
            if entries and entries[0].get('parsed_data'):
                parsed = entries[0]['parsed_data']
                if isinstance(parsed, dict) and 'columns' in parsed:
                    for col in parsed['columns']:
                        table.add_column(col, overflow="fold")
                    
                    for entry in entries:
                        if entry.get('parsed_data', {}).get('values'):
                            table.add_row(*[str(v) for v in entry['parsed_data']['values']])
                else:
                    # Fallback to raw display
                    table.add_column("Line", style="cyan")
                    table.add_column("Content", overflow="fold")
                    for entry in entries:
                        table.add_row(str(entry.get('entry_number', '')), entry.get('raw_line', ''))
            else:
                table.add_column("Line", style="cyan")
                table.add_column("Content", overflow="fold")
                for entry in entries:
                    table.add_row(str(entry.get('entry_number', '')), entry.get('raw_line', ''))
            
            console.print(table)
        else:
            # Regular log display
            console.print(f"\n[bold]Showing {len(entries)} entries:[/bold]")
            for entry in entries:
                timestamp = entry.get('timestamp_parsed', '')[:19] if entry.get('timestamp_parsed') else ''
                level_str = entry.get('log_level', '')
                message = entry.get('message') or entry.get('raw_line', '')
                
                # Color code by level
                level_color = {
                    'DEBUG': 'dim',
                    'INFO': 'blue',
                    'WARN': 'yellow',
                    'WARNING': 'yellow',
                    'ERROR': 'red',
                    'CRITICAL': 'bold red',
                    'FATAL': 'bold red'
                }.get(level_str, 'white')
                
                console.print(f"[dim]{timestamp}[/dim] [{level_color}]{level_str:8}[/{level_color}] {message}")
        
    except Exception as e:
        console.print(f"[red]Error viewing log file:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('file_path', type=click.Path(exists=True))
@click.option('--filename', help='Custom filename for the uploaded file')
@click.option('--file-type', type=click.Choice(['csv', 'evtx', 'txt', 'log', 'json']), help='Specify file type')
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def upload(ctx, file_path, filename, file_type, output_json):
    """Upload a log file for analysis."""
    try:
        result = client.upload_log_file(file_path=file_path, filename=filename, file_type=file_type)
        
        if output_json:
            console.print(json.dumps(result, indent=2))
            return
        
        console.print(f"[green]✓[/green] Successfully uploaded log file: {result.get('filename')}")
        console.print(f"[blue]Log ID:[/blue] {result.get('id')}")
        console.print(f"[blue]File Type:[/blue] {result.get('file_type', '').upper()}")
        console.print(f"[blue]Size:[/blue] {result.get('file_size', 0) / 1024 / 1024:.2f} MB")
        
    except Exception as e:
        console.print(f"[red]Error uploading log file:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('log_id', type=int)
@click.option('--format', 'download_format', default='original', type=click.Choice(['original', 'json', 'csv']), help='Download format')
@click.option('--output-file', help='Output file path')
@click.pass_context
def download(ctx, log_id, download_format, output_file):
    """Download a log file."""
    try:
        result = client.download_log_file(log_id=log_id, format=download_format)
        
        if not output_file:
            log_file = client.get_log_file(log_id)
            filename = log_file.get('filename', f'log_{log_id}')
            if download_format != 'original':
                filename = f"{filename}.{download_format}"
            output_file = filename
        
        # In a real implementation, this would handle file download
        console.print(f"[green]✓[/green] Log file download initiated")
        console.print(f"[blue]Format:[/blue] {download_format}")
        console.print(f"[blue]Output:[/blue] {output_file}")
        console.print(f"[dim]Note: Download URL: {result.get('download_url', 'N/A')}[/dim]")
        
    except Exception as e:
        console.print(f"[red]Error downloading log file:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('log_id', type=int)
@click.option('--confirm', is_flag=True, help='Skip confirmation prompt')
@click.pass_context
def clear(ctx, log_id, confirm):
    """Clear all entries from a log file."""
    try:
        if not confirm:
            log_file = client.get_log_file(log_id)
            filename = log_file.get('filename', f'Log {log_id}')
            if not click.confirm(f"Are you sure you want to clear all entries from '{filename}'?"):
                console.print("[yellow]Operation cancelled.[/yellow]")
                return
        
        result = client.clear_log_entries(log_id)
        console.print(f"[green]✓[/green] Successfully cleared log entries")
        console.print(f"[blue]Entries cleared:[/blue] {result.get('entries_cleared', 0)}")
        
    except Exception as e:
        console.print(f"[red]Error clearing log entries:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('log_id', type=int)
@click.option('--confirm', is_flag=True, help='Skip confirmation prompt')
@click.pass_context
def delete(ctx, log_id, confirm):
    """Delete a log file and all its entries."""
    try:
        if not confirm:
            log_file = client.get_log_file(log_id)
            filename = log_file.get('filename', f'Log {log_id}')
            if not click.confirm(f"Are you sure you want to permanently delete '{filename}'?"):
                console.print("[yellow]Operation cancelled.[/yellow]")
                return
        
        result = client.delete_log_file(log_id)
        console.print(f"[green]✓[/green] Successfully deleted log file")
        
    except Exception as e:
        console.print(f"[red]Error deleting log file:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('query')
@click.option('--file-type', type=click.Choice(['csv', 'evtx', 'txt', 'log', 'json']), help='Filter by file type')
@click.option('--level', type=click.Choice(['DEBUG', 'INFO', 'WARN', 'WARNING', 'ERROR', 'CRITICAL', 'FATAL']), help='Filter by log level')
@click.option('--limit', default=100, help='Maximum number of results')
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def search(ctx, query, file_type, level, limit, output_json):
    """Search across all log files."""
    try:
        result = client.search_logs(query=query, file_type=file_type, level=level, limit=limit)
        
        if output_json:
            console.print(json.dumps(result, indent=2))
            return
        
        results = result.get('results', [])
        if not results:
            console.print(f"[yellow]No results found for query: '{query}'[/yellow]")
            return
        
        console.print(f"[bold]Found {len(results)} results for '{query}':[/bold]\n")
        
        for item in results:
            log_file = item.get('log_file', {})
            entry = item.get('entry', {})
            
            console.print(Panel(
                f"[bold]File:[/bold] {log_file.get('filename', 'Unknown')}\n"
                f"[bold]Line:[/bold] {entry.get('entry_number', 'N/A')}\n"
                f"[bold]Level:[/bold] {entry.get('log_level', 'N/A')}\n"
                f"[bold]Content:[/bold] {entry.get('message') or entry.get('raw_line', '')}",
                title=f"Result {results.index(item) + 1}"
            ))
        
    except Exception as e:
        console.print(f"[red]Error searching logs:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('log_id', type=int)
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def stats(ctx, log_id, output_json):
    """Show statistics for a log file."""
    try:
        result = client.get_log_stats(log_id)
        
        if output_json:
            console.print(json.dumps(result, indent=2))
            return
        
        log_file = result.get('log_file', {})
        stats = result.get('stats', {})
        
        console.print(Panel(
            f"[bold]Filename:[/bold] {log_file.get('filename', 'Unknown')}\n"
            f"[bold]Total Entries:[/bold] {stats.get('total_entries', 0):,}\n"
            f"[bold]File Size:[/bold] {log_file.get('file_size', 0) / 1024 / 1024:.2f} MB\n"
            f"[bold]Log Levels:[/bold]\n" +
            "\n".join([f"  {level}: {count:,}" for level, count in stats.get('level_counts', {}).items()]) +
            f"\n[bold]Date Range:[/bold] {stats.get('date_range', {}).get('start', 'N/A')} to {stats.get('date_range', {}).get('end', 'N/A')}",
            title="Log File Statistics"
        ))
        
    except Exception as e:
        console.print(f"[red]Error getting log statistics:[/red] {e}")
        sys.exit(1)

# Scan History Commands
@cli.group()
def scans():
    """Scan history and management commands."""
    pass

@scans.command()
@click.option('--limit', default=20, help='Maximum number of scans to show')
@click.option('--user', help='Filter by user email')
@click.option('--type', 'scan_type', help='Filter by scan type (python, npm, system, etc.)')
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def list(ctx, limit, user, scan_type, output_json):
    """List scan history for your organization."""
    init_client()
    
    try:
        scans = client.get_scan_history(limit=limit)
        
        # Apply filters
        if user:
            scans = [s for s in scans if user.lower() in s.get('user_email', '').lower()]
        if scan_type:
            scans = [s for s in scans if scan_type.lower() in s.get('scan_type', '').lower()]
        
        if output_json:
            console.print(json.dumps(scans, indent=2))
            return
        
        if not scans:
            console.print("[yellow]No scans found.[/yellow]")
            return
        
        # Create formatted table
        table = Table(title="Scan History")
        table.add_column("ID", style="cyan")
        table.add_column("User", style="magenta")
        table.add_column("Type", style="blue")
        table.add_column("Machine", style="green")
        table.add_column("Vulnerabilities", justify="right")
        table.add_column("Date", style="dim")
        
        for scan in scans:
            # Format vulnerability count
            summary = scan.get('summary', {})
            total_vulns = summary.get('total_vulnerabilities', 0)
            
            # Format severity distribution
            severity_dist = summary.get('severity_distribution', {})
            vuln_display = f"{total_vulns}"
            if severity_dist:
                critical = severity_dist.get('critical', 0)
                high = severity_dist.get('high', 0)
                if critical > 0 or high > 0:
                    vuln_display += f" (C:{critical}, H:{high})"
            
            # Format date
            created_at = scan.get('created_at', '')
            if created_at:
                try:
                    from datetime import datetime
                    dt = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                    date_str = dt.strftime('%Y-%m-%d %H:%M')
                except:
                    date_str = created_at[:16]
            else:
                date_str = 'Unknown'
            
            table.add_row(
                str(scan.get('id', '')),
                scan.get('user_email', 'Unknown'),
                scan.get('scan_type', 'Unknown').title(),
                scan.get('computer_name', scan.get('machine_name', 'Unknown')),
                vuln_display,
                date_str
            )
        
        console.print(table)
        console.print(f"\n[dim]Showing {len(scans)} scans[/dim]")
        
    except Exception as e:
        console.print(f"[red]Error fetching scan history:[/red] {e}")
        sys.exit(1)

@scans.command()
@click.argument('scan_id', type=int)
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def show(ctx, scan_id, output_json):
    """Show detailed information about a specific scan."""
    init_client()
    
    try:
        scan = client.get_scan_details(scan_id)
        
        if output_json:
            console.print(json.dumps(scan, indent=2))
            return
        
        # Display scan details
        console.print(f"\n[bold]Scan Details - ID: {scan.get('id')}[/bold]")
        console.print(f"[blue]User:[/blue] {scan.get('user_email')}")
        console.print(f"[blue]Type:[/blue] {scan.get('scan_type', 'Unknown').title()}")
        console.print(f"[blue]Machine:[/blue] {scan.get('computer_name', scan.get('machine_name', 'Unknown'))}")
        console.print(f"[blue]OS:[/blue] {scan.get('os_type', 'Unknown')}")
        
        # Format date
        created_at = scan.get('created_at', '')
        if created_at:
            try:
                from datetime import datetime
                dt = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                date_str = dt.strftime('%Y-%m-%d %H:%M:%S')
            except:
                date_str = created_at
        else:
            date_str = 'Unknown'
        console.print(f"[blue]Date:[/blue] {date_str}")
        
        # Display scan command if available
        if scan.get('scan_command'):
            console.print(f"[blue]Command:[/blue] {scan.get('scan_command')}")
        
        # Display summary
        summary = scan.get('summary', {})
        scan_results = scan.get('scan_results', {})
        
        # Count packages from scan results if not in summary
        total_packages = summary.get('total_packages', 0)
        if total_packages == 0:
            # Try different data structures
            if scan_results.get('packages'):
                total_packages = len(scan_results.get('packages', []))
            elif scan_results.get('dependency_tree'):
                # Count packages recursively from dependency tree
                def count_packages_recursive(packages):
                    count = 0
                    for pkg in packages:
                        count += 1  # Count this package
                        # Count dependencies recursively
                        deps = pkg.get('dependencies', [])
                        if deps:
                            count += count_packages_recursive(deps)
                    return count
                
                dependency_tree = scan_results.get('dependency_tree', [])
                total_packages = count_packages_recursive(dependency_tree)
        
        if summary:
            console.print(f"\n[bold]Summary:[/bold]")
            console.print(f"[green]Total Vulnerabilities:[/green] {summary.get('total_vulnerabilities', 0)}")
            console.print(f"[green]Packages Scanned:[/green] {total_packages}")
            
            # Severity distribution
            severity_dist = summary.get('severity_distribution', {})
            if severity_dist:
                console.print(f"\n[bold]Severity Distribution:[/bold]")
                for severity, count in severity_dist.items():
                    if count > 0:
                        severity_color = {
                            'critical': 'bold red',
                            'high': 'red',
                            'medium': 'yellow',
                            'low': 'blue',
                            'unknown': 'dim'
                        }.get(severity.lower(), 'white')
                        console.print(f"  [{severity_color}]{severity.title()}:[/{severity_color}] {count}")
        
        # Display scan results summary
        scan_results = scan.get('scan_results', {})
        if scan_results:
            packages = scan_results.get('packages', [])
            if packages:
                console.print(f"\n[bold]Packages with Vulnerabilities:[/bold]")
                vuln_packages = [pkg for pkg in packages if pkg.get('vulnerabilities')]
                console.print(f"[yellow]{len(vuln_packages)} out of {len(packages)} packages have vulnerabilities[/yellow]")
                
                # Show top vulnerable packages
                if vuln_packages:
                    console.print(f"\n[bold]Top Vulnerable Packages:[/bold]")
                    sorted_packages = sorted(vuln_packages, key=lambda x: len(x.get('vulnerabilities', [])), reverse=True)[:5]
                    for pkg in sorted_packages:
                        pkg_name = pkg.get('name', 'Unknown')
                        vuln_count = len(pkg.get('vulnerabilities', []))
                        console.print(f"  • [cyan]{pkg_name}[/cyan]: {vuln_count} vulnerabilities")
        
    except Exception as e:
        console.print(f"[red]Error fetching scan details:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.option('--limit', default=10, help='Maximum number of scans to show')
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def history(ctx, limit, output_json):
    """Show recent scan history (shortcut for 'scans list')."""
    init_client()
    
    try:
        scans = client.get_scan_history(limit=limit)
        
        if output_json:
            console.print(json.dumps(scans, indent=2))
            return
        
        if not scans:
            console.print("[yellow]No scan history found.[/yellow]")
            console.print("Run [bold]xyz scan --help[/bold] to see available scan options.")
            return
        
        console.print(f"[bold]Recent Scan History ({len(scans)} scans)[/bold]\n")
        
        for scan in scans:
            # Format date
            created_at = scan.get('created_at', '')
            if created_at:
                try:
                    from datetime import datetime
                    dt = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                    date_str = dt.strftime('%Y-%m-%d %H:%M')
                except:
                    date_str = created_at[:16]
            else:
                date_str = 'Unknown'
            
            # Format vulnerability summary
            summary = scan.get('summary', {})
            total_vulns = summary.get('total_vulnerabilities', 0)
            severity_dist = summary.get('severity_distribution', {})
            
            vuln_summary = f"{total_vulns} vulnerabilities"
            if severity_dist:
                critical = severity_dist.get('critical', 0)
                high = severity_dist.get('high', 0)
                if critical > 0:
                    vuln_summary += f" ([bold red]{critical} critical[/bold red]"
                    if high > 0:
                        vuln_summary += f", [red]{high} high[/red])"
                    else:
                        vuln_summary += ")"
                elif high > 0:
                    vuln_summary += f" ([red]{high} high[/red])"
            
            console.print(f"[cyan]#{scan.get('id')}[/cyan] {scan.get('user_email')} - {scan.get('scan_type', 'Unknown').title()} Scan")
            console.print(f"  [dim]{date_str}[/dim] • [green]{scan.get('computer_name', 'Unknown')}[/green] • {vuln_summary}")
            console.print()
        
        console.print(f"[dim]Use [bold]scans show <id>[/bold] for detailed information about a specific scan.[/dim]")
        
    except Exception as e:
        console.print(f"[red]Error fetching scan history:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.argument("package")
@click.argument("version")
@click.option("-e", "--ecosystem", default="npm", show_default=True,
              help="Package ecosystem (npm, pypi, maven, nuget, etc.)")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.pass_context
def check(ctx, package, version, ecosystem, output_json):
    """Run an XYZ proxy safety check on PACKAGE@VERSION.

    \b
    Examples:
      xyz check axios 1.14.1
      xyz check lodash 4.17.21 --ecosystem npm
      xyz check forcechatter 1.0.0 --json
    """
    init_client()
    try:
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
                      console=console) as progress:
            progress.add_task(description=f"Checking {package}@{version}…", total=None)
            result = client.proxy_check(package, version, ecosystem,
                                       machine_name=get_computer_name(),
                                       os_type=platform.system())
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)

    if output_json:
        console.print(json.dumps(result, indent=2))
        return

    decision = result.get("decision", "unknown").upper()
    confidence = result.get("confidence", 0) or 0
    safe_ver = result.get("safe_version") or ""
    signals = result.get("signals", []) or []

    DECISION_COLOR = {
        "BLOCK": "bold red",
        "QUARANTINE": "bold yellow",
        "ALERT": "bold blue",
        "ALLOW": "bold green",
    }
    DECISION_ICON = {
        "BLOCK": "🚫",
        "QUARANTINE": "⚠️",
        "ALERT": "ℹ️",
        "ALLOW": "✅",
    }
    color = DECISION_COLOR.get(decision, "white")
    icon  = DECISION_ICON.get(decision, "❓")

    console.print()
    console.print(Panel(
        f"[{color}]{icon}  {decision}[/{color}]"
        + (f"  [dim](confidence: {confidence:.0%})[/dim]" if confidence else ""),
        title=f"[cyan]{package}[/cyan][dim]@[/dim][magenta]{version}[/magenta]  ·  {ecosystem}",
        expand=False,
    ))

    if safe_ver:
        console.print(f"  [green]✓ Safe version:[/green] {safe_ver}")

    if signals:
        console.print(f"\n  [bold]Signals ({len(signals)}):[/bold]")
        for s in signals:
            sig_decision = s.get("decision", "").upper()
            sig_color = DECISION_COLOR.get(sig_decision, "dim")
            console.print(
                f"    [{sig_color}]{sig_decision:12}[/{sig_color}]"
                f"  [{s.get('signal_type','?')}]  {s.get('detail', '')[:120]}"
            )
    else:
        console.print("  [dim]No signals fired — clean.[/dim]")

    console.print()
    if decision == "BLOCK":
        raise SystemExit(1)
    elif decision == "QUARANTINE":
        raise SystemExit(2)


# ─── xyz depalert ──────────────────────────────────────────────────────────────

@cli.group()
def depalert():
    """CI/CD gate: scan a manifest or lockfile and exit non-zero on threats.

    \b
    Exit codes:
      0  All clean
      1  MALWARE / block detected
      2  QUARANTINE detected
      3  ALERT-only (suspicious but not confirmed malicious)
    """


@depalert.command("scan")
@click.option("--package-lock", "package_lock", type=click.Path(exists=True),
              help="Path to package-lock.json")
@click.option("--requirements", "requirements", type=click.Path(exists=True),
              help="Path to requirements.txt")
@click.option("--packages", "-p", multiple=True,
              help="Inline package specs, e.g. --packages axios@1.14.1")
@click.option("--ecosystem", "-e", default="npm", show_default=True,
              help="Ecosystem for --packages input")
@click.option("--fail-on", default="block", show_default=True,
              type=click.Choice(["block", "quarantine", "alert"], case_sensitive=False),
              help="Minimum decision level that causes non-zero exit")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.pass_context
def depalert_scan(ctx, package_lock, requirements, packages, ecosystem,
                  fail_on, output_json):
    """Scan dependencies and gate on threats.

    \b
    Examples:
      xyz depalert scan --package-lock package-lock.json
      xyz depalert scan --requirements requirements.txt --fail-on quarantine
      xyz depalert scan -p axios@1.14.1 -p lodash@4.17.21
    """
    import re

    init_client()

    pkg_list: list[dict] = []

    if package_lock:
        try:
            with open(package_lock) as f:
                lock = json.load(f)
            deps = lock.get("packages") or lock.get("dependencies") or {}
            for name, meta in deps.items():
                clean_name = name.lstrip("node_modules/")
                if not clean_name:
                    continue
                ver = meta.get("version", "0.0.0") if isinstance(meta, dict) else str(meta)
                pkg_list.append({"package": clean_name, "version": ver, "ecosystem": "npm"})
        except Exception as e:
            console.print(f"[red]Failed to parse package-lock.json:[/red] {e}")
            raise SystemExit(1)

    if requirements:
        try:
            eco = "pypi"
            with open(requirements) as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    m = re.match(r"^([A-Za-z0-9_.\-]+)[=><!\s]+=+\s*([\d.]+)", line)
                    if m:
                        pkg_list.append({"package": m.group(1), "version": m.group(2), "ecosystem": eco})
        except Exception as e:
            console.print(f"[red]Failed to parse requirements.txt:[/red] {e}")
            raise SystemExit(1)

    for spec in packages:
        if "@" in spec:
            parts = spec.rsplit("@", 1)
            pkg_list.append({"package": parts[0], "version": parts[1], "ecosystem": ecosystem})
        else:
            pkg_list.append({"package": spec, "version": "latest", "ecosystem": ecosystem})

    if not pkg_list:
        console.print("[yellow]No packages to scan. Provide --package-lock, --requirements, or --packages.[/yellow]")
        raise SystemExit(0)

    console.print(f"[bold]XYZ DepAlert[/bold] — scanning [cyan]{len(pkg_list)}[/cyan] packages…\n")

    results = client.proxy_check_batch(pkg_list,
                                       machine_name=get_computer_name(),
                                       os_type=platform.system())

    if output_json:
        console.print(json.dumps(results, indent=2))
    else:
        _print_depalert_table(results)

    # Determine exit code. Default missing 'decision' to 'error' (fail-CLOSED)
    # so a backend outage cannot silently let a malicious package through.
    decisions = [r.get("decision", "error").lower() for r in results]
    if "error" in decisions:
        worst = "error"
    elif "block" in decisions:
        worst = "block"
    elif "quarantine" in decisions:
        worst = "quarantine"
    elif "alert" in decisions:
        worst = "alert"
    else:
        worst = "allow"

    # 'error' uses exit code 4 (above all gate thresholds) so any --fail-on level
    # treats unreachable-backend as a hard failure.
    EXIT_CODE = {"error": 4, "block": 1, "quarantine": 2, "alert": 3, "allow": 0}
    THRESHOLD = {"block": 1, "quarantine": 2, "alert": 3}

    threshold = THRESHOLD.get(fail_on.lower(), 1)
    worst_code = EXIT_CODE.get(worst, 0)

    if worst == "error":
        err_count = sum(1 for d in decisions if d == "error")
        console.print(f"\n[bold red]✖ Gate FAILED:[/bold red] {err_count} package(s) could not be checked "
                      f"(backend unreachable). Refusing to fail-open.\n")
        raise SystemExit(EXIT_CODE["error"])
    if worst_code >= threshold:
        count = sum(1 for d in decisions if d in ("block", "quarantine", "alert"))
        console.print(f"\n[bold red]✖ Gate FAILED:[/bold red] {count} threat(s) detected (worst: {worst.upper()})\n")
        raise SystemExit(worst_code)
    else:
        console.print(f"\n[bold green]✓ Gate PASSED[/bold green] — no threats at or above '{fail_on}' level.\n")


@cli.group()
def inventory():
    """Customer package inventory: upload an SBOM and get exposure.

    \b
    Examples:
      xyz inventory upload ./my-app                       (runs syft locally)
      xyz inventory upload --sbom syft.json               (already-built SBOM)
      xyz inventory exposure <inventory_id>               (re-fetch decorated rows)
    """


@inventory.command("upload")
@click.argument("target", type=click.Path(exists=True), required=False)
@click.option("--sbom", "sbom_path", type=click.Path(exists=True),
              help="Path to a pre-built Syft / CycloneDX JSON SBOM (skips local syft).")
@click.option("--source-ref", "source_ref", default=None,
              help="Free-form provenance string (image ref, repo url, sha).")
@click.option("--syft-bin", default=None,
              help="Override syft binary path (else uses $SYFT_BINARY or `syft` on PATH).")
@click.option("--only-flagged/--all-rows", default=True, show_default=True,
              help="On follow-up exposure print, restrict to risky rows.")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.pass_context
def inventory_upload(ctx, target, sbom_path, source_ref, syft_bin, only_flagged, output_json):
    """Upload an SBOM and print exposure summary + flagged rows.

    Exit codes:
      0  No flagged rows
      1  At least one is_known_malicious row
      2  Advisory CRITICAL/HIGH only (no malicious)
    """
    init_client()

    if not target and not sbom_path:
        console.print("[red]Either TARGET (a local path to scan) or --sbom is required.[/red]")
        raise SystemExit(2)

    if sbom_path:
        try:
            with open(sbom_path) as f:
                sbom = json.load(f)
            ref = source_ref or os.path.abspath(sbom_path)
        except Exception as e:
            console.print(f"[red]Failed to read --sbom file:[/red] {e}")
            raise SystemExit(2)
    else:
        binary = syft_bin or os.environ.get("SYFT_BINARY") or _which("syft")
        if not binary:
            console.print("[red]syft not found.[/red] Install via `brew install syft` "
                          "or set --syft-bin / $SYFT_BINARY.")
            raise SystemExit(2)
        console.print(f"[dim]running:[/dim] {binary} {target} -o syft-json")
        try:
            proc = subprocess.run(
                [binary, str(target), "-o", "syft-json", "--quiet"],
                capture_output=True, timeout=300, check=False,
            )
        except subprocess.TimeoutExpired:
            console.print("[red]syft timed out (>5m).[/red]")
            raise SystemExit(2)
        if proc.returncode != 0:
            err = (proc.stderr or b"").decode("utf-8", errors="replace")[:1000]
            console.print(f"[red]syft exit {proc.returncode}:[/red] {err}")
            raise SystemExit(2)
        try:
            sbom = json.loads(proc.stdout)
        except json.JSONDecodeError as e:
            console.print(f"[red]syft produced unparseable JSON:[/red] {e}")
            raise SystemExit(2)
        ref = source_ref or os.path.abspath(target)

    console.print(f"[bold]XYZ Inventory[/bold] — uploading SBOM (source_ref={ref})…")
    try:
        resp = client.upload_inventory_sbom(sbom, source_ref=ref)
    except Exception as e:
        console.print(f"[red]Upload failed:[/red] {e}")
        raise SystemExit(2)

    inv_id = resp.get("inventory_id")
    fmt = resp.get("sbom_format")
    accepted = resp.get("accepted_count", 0)
    rejected = resp.get("rejected_count", 0)
    expo = resp.get("exposure", {}) or {}
    n_total = expo.get("total_packages", 0)
    n_mal   = expo.get("flagged_known_malicious", 0)
    n_crit  = expo.get("advisory_critical", 0)
    n_high  = expo.get("advisory_high", 0)

    if output_json:
        console.print(json.dumps(resp, indent=2))
    else:
        console.print(
            f"\n[bold]Inventory[/bold] [cyan]{inv_id}[/cyan]   "
            f"format=[bold]{fmt}[/bold]   accepted={accepted}   rejected={rejected}\n"
        )
        bar = Table(show_header=False, box=None)
        bar.add_row("[bold]Total packages[/bold]",      f"{n_total}")
        bar.add_row("[bold red]Known malicious[/bold red]", f"{n_mal}")
        bar.add_row("[bold red]Advisory CRITICAL[/bold red]", f"{n_crit}")
        bar.add_row("[bold yellow]Advisory HIGH[/bold yellow]", f"{n_high}")
        console.print(bar)
        if n_mal or n_crit or n_high:
            try:
                rows = client.get_inventory_exposure(inv_id, only_flagged=only_flagged)
                _print_inventory_exposure_table(rows)
            except Exception as e:
                console.print(f"[yellow]Could not fetch detailed exposure:[/yellow] {e}")
        console.print(f"\n[dim]Re-query later:[/dim] xyz inventory exposure {inv_id}")

    if n_mal > 0:
        raise SystemExit(1)
    if n_crit > 0 or n_high > 0:
        raise SystemExit(2)


@inventory.command("exposure")
@click.argument("inventory_id")
@click.option("--all-rows", "all_rows", is_flag=True,
              help="Show every inventory row, not just flagged ones.")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.pass_context
def inventory_exposure(ctx, inventory_id, all_rows, output_json):
    """Re-fetch the exposure report for a previously-uploaded inventory."""
    init_client()
    try:
        rows = client.get_inventory_exposure(inventory_id, only_flagged=not all_rows)
    except Exception as e:
        console.print(f"[red]Fetch failed:[/red] {e}")
        raise SystemExit(2)
    if output_json:
        console.print(json.dumps(rows, indent=2))
    else:
        _print_inventory_exposure_table(rows)


def _which(binary: str) -> Optional[str]:
    import shutil
    return shutil.which(binary)


def _print_inventory_exposure_table(rows):
    if not rows:
        console.print("[green]✓ No flagged rows.[/green]")
        return
    table = Table(title=f"Exposure ({len(rows)} flagged row(s))", show_lines=True)
    table.add_column("Package@Version", style="cyan")
    table.add_column("Eco")
    table.add_column("Source", style="dim")
    table.add_column("Malicious")
    table.add_column("Mal Tier")
    table.add_column("Top Adv")
    for r in rows:
        is_mal = r.get("is_known_malicious")
        mal_cell = "[bold red]YES[/bold red]" if is_mal else "[dim]—[/dim]"
        # Only show the malicious-package source tier when THIS version is
        # actually flagged. Otherwise the API leaks tier from a different
        # version's malicious_packages row (e.g. axios@1.7.7 inheriting
        # `human_verified` that only applies to a separate axios version).
        mal_tier_cell = (r.get("mal_source_tier") or "—") if is_mal else "—"
        adv = r.get("top_advisory_severity") or "—"
        adv_color = {"CRITICAL": "bold red", "HIGH": "red",
                     "MEDIUM": "yellow", "LOW": "dim"}.get(adv, "dim")
        table.add_row(
            f"{r.get('package_name')}@{r.get('package_version')}",
            r.get("package_ecosystem") or "?",
            r.get("source_path") or "—",
            mal_cell,
            mal_tier_cell,
            f"[{adv_color}]{adv}[/{adv_color}]",
        )
    console.print(table)


def _format_score_cell(scores: dict) -> str:
    """Format CVSS/EPSS/XYZ scores into a compact Rich-colored cell."""
    if not scores:
        return "[dim]—[/dim]"
    parts = []
    cvss = scores.get("cvss")
    if cvss is not None:
        c = float(cvss)
        if c >= 9.0:
            parts.append(f"[bold red]CVSS {c:.1f}[/bold red]")
        elif c >= 7.0:
            parts.append(f"[red]CVSS {c:.1f}[/red]")
        elif c >= 4.0:
            parts.append(f"[yellow]CVSS {c:.1f}[/yellow]")
        else:
            parts.append(f"[dim]CVSS {c:.1f}[/dim]")
    xyz = scores.get("xyz_score")
    if xyz is not None:
        x = float(xyz)
        if x >= 7.0:
            parts.append(f"[bold orange3]XYZ {x:.1f}[/bold orange3]")
        elif x >= 4.0:
            parts.append(f"[orange3]XYZ {x:.1f}[/orange3]")
        else:
            parts.append(f"[dim]XYZ {x:.1f}[/dim]")
    epss = scores.get("epss")
    if epss is not None:
        e = float(epss) * 100
        if e >= 10:
            parts.append(f"[bold dodger_blue2]EPSS {e:.1f}%[/bold dodger_blue2]")
        elif e >= 1:
            parts.append(f"[dodger_blue2]EPSS {e:.1f}%[/dodger_blue2]")
        else:
            parts.append(f"[steel_blue1]EPSS {e:.2f}%[/steel_blue1]")
    return "\n".join(parts) if parts else "[dim]—[/dim]"


def _print_depalert_table(results: list):
    ICON = {"block": "🚫", "quarantine": "⚠️", "alert": "ℹ️", "allow": "✅", "error": "❌"}
    COLOR = {"block": "red", "quarantine": "yellow", "alert": "blue", "allow": "green", "error": "dim"}

    threats = [r for r in results if r.get("decision", "allow") not in ("allow", "error")]
    clean   = [r for r in results if r.get("decision", "allow") == "allow"]
    errors  = [r for r in results if r.get("decision") == "error"]

    if threats:
        table = Table(title=f"⚠️  {len(threats)} Threat(s) Detected", show_lines=True)
        table.add_column("Package@Version", style="cyan")
        table.add_column("Decision", justify="center")
        table.add_column("Scores", justify="left")
        table.add_column("Signals", justify="right")
        table.add_column("Safe Version", style="green")
        for r in threats:
            inp = r.get("_input", r)
            pkg_ver = f"{inp.get('package','?')}@{inp.get('version','?')}"
            d = r.get("decision", "?")
            icon = ICON.get(d, "?")
            color = COLOR.get(d, "white")
            table.add_row(
                pkg_ver,
                f"[{color}]{icon} {d.upper()}[/{color}]",
                _format_score_cell(r.get("scores")),
                str(len(r.get("signals", []))),
                r.get("safe_version") or "—",
            )
        console.print(table)

    console.print(
        f"[green]✅ {len(clean)} clean[/green]  "
        f"[red]🚫 {sum(1 for r in results if r.get('decision')=='block')} blocked[/red]  "
        f"[yellow]⚠️  {sum(1 for r in results if r.get('decision')=='quarantine')} quarantined[/yellow]  "
        f"[blue]ℹ️  {sum(1 for r in results if r.get('decision')=='alert')} alerted[/blue]"
        + (f"  [dim]❌ {len(errors)} errors[/dim]" if errors else "")
    )


def main():
    """Main entry point for setuptools console_scripts"""
    cli()
 
if __name__ == '__main__':
    main()
