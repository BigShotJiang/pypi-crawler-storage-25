from uuid import uuid4

from opentelemetry.sdk.resources import Resource, ResourceDetector

try:
    from corva_otel.semconv.xtra import X_PROCESS_RUN_ID
except ImportError:
    X_PROCESS_RUN_ID = 'x.process.run.id'

process_run_id = str(uuid4())


class ProcessRunIdDetector(ResourceDetector):
    """Provides 'x.process.run.id' resource attribute, stable for the lifetime of the process."""

    def detect(self) -> Resource:
        return Resource({X_PROCESS_RUN_ID: process_run_id})
