"""Residue Accessibility analysis tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

METADATA = {
    "name": "residue_accessibility",
    "display_name": "Residue Accessibility",
    "category": "analysis",
    "description": "Score residues for binder accessibility beyond SASA using depth, visibility, and curvature",
    "modal_function_name": "residue_accessibility_worker",
    "modal_app_name": "residue-accessibility-api",
    "status": "available",
    "outputs": {
        "json_filepath": "Full structured results (residues, patches, recommendation)",
        "csv_filepath": "Per-residue accessibility scores in CSV format",
        "pdb_filepath": "PDB with B-factors set to accessibility tier scores",
    },
}

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("residue-accessibility")
    def run_residue_accessibility(
        pdb: Path = typer.Option(
            ...,
            "--pdb",
            "-p",
            help="Path to PDB file containing protein structure",
            exists=True,
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required unless --background)",
        ),
        residues: Optional[str] = typer.Option(
            None,
            "--residues",
            "-r",
            help="Residues to score in CHAIN:RESNUM format (e.g., 'A:42,A:43,B:10'). "
            "If omitted, all surface-exposed residues are scored.",
        ),
        rsa_threshold: float = typer.Option(
            0.20,
            "--rsa-threshold",
            help="RSA cutoff for the exposure gate (0.0-1.0). Residues below this are excluded.",
        ),
        n_rays: int = typer.Option(
            200,
            "--n-rays",
            help="Number of hemisphere rays per residue for visibility scoring (10-1000).",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
    ):
        """
        Score protein residues for binder accessibility.

        Goes beyond SASA to measure residue depth, outward visibility (ray casting),
        and surface curvature. Returns a ranked list of residues scored 0–1 for
        binder accessibility.

        Examples:
            amina run residue-accessibility --pdb ./target.pdb -o ./results/
            amina run residue-accessibility --pdb ./target.pdb -r "A:42,A:43,A:45" -o ./results/
            amina run residue-accessibility --pdb ./target.pdb --rsa-threshold 0.15 -o ./results/
            amina run residue-accessibility --pdb ./target.pdb -j myjob -o ./results/ --background
        """
        # Validate required options
        if output is None and not background:
            console.print("[red]Error:[/red] --output / -o is required (unless using --background)")
            raise typer.Exit(1)

        # Validate residue format if provided
        if residues:
            for token in residues.split(","):
                token = token.strip()
                if ":" not in token:
                    console.print(
                        f"[red]Error:[/red] Invalid residue format '{token}'. Expected CHAIN:RESNUM (e.g., 'A:42')."
                    )
                    raise typer.Exit(1)

        # Read PDB file content
        pdb_content = pdb.read_text()
        console.print(f"Read PDB file: {pdb.name}")

        # Build params dict matching worker's expected fields
        params = {
            "pdb_content": pdb_content,
            "rsa_threshold": rsa_threshold,
            "n_rays": n_rays,
        }

        if residues:
            params["residues"] = residues

        if job_name:
            params["job_name"] = job_name

        # Execute
        run_tool_with_progress("residue_accessibility", params, output, background=background)
