"use client";

import { memo } from "react";
import { Handle, Position } from "reactflow";
import type { NodeProps } from "reactflow";

const ROLE_VAR: Record<string, string> = {
  researcher: "var(--role-researcher)",
  implementer: "var(--role-implementer)",
  reviewer: "var(--role-reviewer)",
  critic: "var(--role-critic)",
  analyst: "var(--role-analyst)",
  architect: "var(--role-architect)",
  tester: "var(--role-tester)",
};

export interface StepNodeData {
  label: string;
  role: string;
  assignment: string;
  prompt: string;
  capacity: number;
  timeout: number | null;
  inputs: string[];
  outputs: string[];
  execStatus?: "pending" | "running" | "completed" | "failed";
  // optional badges
  durationSeconds?: number | null;
  errorCount?: number;
  toolCallCount?: number;
}

function StepNodeComponent({ data, selected }: NodeProps<StepNodeData>) {
  const roleColor = ROLE_VAR[data.role] || "var(--content-muted)";
  const status = data.execStatus ?? "pending";

  const borderColor =
    status === "running"
      ? "var(--dag-running-border)"
      : status === "completed"
        ? "var(--dag-completed-border)"
        : status === "failed"
          ? "var(--dag-failed-border)"
          : selected
            ? "var(--status-selected)"
            : "var(--edge-default)";

  const bgColor =
    status === "running"
      ? "var(--dag-running-bg)"
      : status === "completed"
        ? "var(--dag-completed-bg)"
        : status === "failed"
          ? "var(--dag-failed-bg)"
          : "var(--surface-raised)";

  const labelColor =
    status === "running"
      ? "var(--dag-running-label)"
      : status === "completed"
        ? "var(--dag-completed-label)"
        : status === "failed"
          ? "var(--dag-failed-label)"
          : "var(--content-primary)";

  return (
    <div
      className="relative rounded-md px-2.5 py-2"
      style={{
        background: bgColor,
        border: `${selected || status === "running" ? 2 : 1}px solid ${borderColor}`,
        minWidth: 148,
        maxWidth: 210,
        boxShadow:
          status === "running"
            ? "0 0 0 3px color-mix(in srgb, var(--dag-running-border) 18%, transparent)"
            : selected
              ? "0 0 0 2px color-mix(in srgb, var(--status-selected) 22%, transparent)"
              : "0 1px 3px rgba(0,0,0,0.12)",
        transition: "border-color 0.2s, background 0.2s, box-shadow 0.2s",
      }}
    >
      <Handle
        type="target"
        position={Position.Left}
        style={{
          width: 8,
          height: 8,
          background: "var(--edge-default)",
          borderColor: "var(--surface-raised)",
          borderWidth: 1.5,
        }}
      />

      <div className="flex items-center justify-between gap-1.5">
        <span
          className="font-mono text-[11px] font-semibold leading-snug truncate"
          style={{ color: labelColor }}
        >
          {data.label}
        </span>
        {status === "completed" && (
          <span
            className="shrink-0 text-[10px] font-semibold"
            style={{ color: "var(--status-success)" }}
          >
            ✓
          </span>
        )}
        {status === "failed" && (
          <span
            className="shrink-0 text-[10px] font-semibold"
            style={{ color: "var(--status-error)" }}
          >
            ✕
          </span>
        )}
        {status === "running" && (
          <span
            className="shrink-0 h-1.5 w-1.5 rounded-full animate-pulse"
            style={{ background: "var(--dag-running-border)" }}
          />
        )}
      </div>

      {data.role && (
        <span
          className="mt-1 inline-block rounded px-1.5 py-px font-mono text-[9px] leading-tight tracking-wide"
          style={{
            backgroundColor: `color-mix(in srgb, ${roleColor} 14%, transparent)`,
            color: roleColor,
          }}
        >
          {data.role}
        </span>
      )}

      {data.assignment && (
        <div className="mt-0.5 truncate font-mono text-[10px] leading-snug text-content-muted">
          {data.assignment}
        </div>
      )}

      {(data.durationSeconds != null ||
        (data.errorCount ?? 0) > 0 ||
        (data.toolCallCount ?? 0) > 0) && (
        <div className="mt-1 flex items-center gap-2 font-mono text-[9px] tabular-nums text-content-muted">
          {data.durationSeconds != null && data.durationSeconds >= 0 ? (
            <span>{formatStepDuration(data.durationSeconds)}</span>
          ) : null}
          {(data.errorCount ?? 0) > 0 ? (
            <span style={{ color: "var(--status-error)" }}>{data.errorCount} err</span>
          ) : null}
          {(data.toolCallCount ?? 0) > 0 ? (
            <span>{data.toolCallCount} calls</span>
          ) : null}
        </div>
      )}

      {status === "running" && (
        <div
          className="pointer-events-none absolute inset-0 rounded-md"
          style={{
            border: "2px solid var(--dag-running-border)",
            animation: "pulse 1.5s ease-in-out infinite",
            opacity: 0.35,
          }}
        />
      )}

      <Handle
        type="source"
        position={Position.Right}
        style={{
          width: 8,
          height: 8,
          background: "var(--edge-default)",
          borderColor: "var(--surface-raised)",
          borderWidth: 1.5,
        }}
      />
    </div>
  );
}

function formatStepDuration(seconds: number): string {
  if (seconds < 1) return `${Math.round(seconds * 1000)}ms`;
  if (seconds < 60) return `${seconds.toFixed(seconds < 10 ? 1 : 0)}s`;
  const m = Math.floor(seconds / 60);
  return `${m}m`;
}

export default memo(StepNodeComponent);
