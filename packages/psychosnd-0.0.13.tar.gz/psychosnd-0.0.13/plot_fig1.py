"""Reproduce Fig. 1 from Aaronson & Hartmann (2014).

Interaural time difference as a function of azimuth for plane-wave incidence
and antipodal ears. Heavy line: Woodworth formula. Lighter lines: exact
diffraction model at 0.5, 2, 5, 10, and 20 kHz.
"""

import numpy as np
import matplotlib.pyplot as plt
from src.psychosnd.itd import itd_woodworth, itd_diffraction

angles = np.linspace(0, 180, 181)
frequencies = [500, 2000, 5000, 10000, 20000]
labels = ["0.5 kHz", "2 kHz", "5 kHz", "10 kHz", "20 kHz"]
# Linestyles matching the paper: dotted → dashed → solid as frequency increases
linestyles = [":", "--", "-.", "--", "-"]

fig, ax = plt.subplots(figsize=(6, 5))

# Exact diffraction curves (lighter, behind Woodworth)
itds = itd_diffraction(frequencies, angles)
for i, (label, ls) in enumerate(zip(labels, linestyles)):
    ax.plot(angles, itds[i] * 1e6, color="0.55", linestyle=ls, linewidth=1.2, label=label)

# Woodworth (heavy line, plotted last so it sits on top)
ax.plot(angles, itd_woodworth(angles) * 1e6, color="black", linewidth=2.5, label="Woodworth")

ax.set_xlabel("Azimuth (degrees)")
ax.set_ylabel("ITD (µs)")
ax.set_xlim(0, 180)
ax.set_ylim(0, 800)
ax.set_xticks(range(0, 181, 20))

# Build legend with Woodworth first then frequencies
handles, lbls = ax.get_legend_handles_labels()
ax.legend(handles[-1:] + handles[:-1], lbls[-1:] + lbls[:-1],
          fontsize=8, loc="upper left")

ax.set_title("ITD vs Azimuth (plane wave, antipodal ears)\n"
             "— Aaronson & Hartmann 2014, Fig. 1")
fig.tight_layout()
fig.savefig("fig1_itd.png", dpi=150)
print("Saved fig1_itd.png")
plt.show()
