"""Shared fixtures.

Resets the server's module-level RBAClient between tests so a closed event
loop from one test doesn't poison the next one. The reset is best-effort —
during early build, server.py may not exist yet.
"""
from __future__ import annotations

import pytest


@pytest.fixture(autouse=True)
async def _reset_server_client():
    yield
    try:
        from rba_mcp import server
    except ImportError:
        return
    if hasattr(server, "reset_client_for_tests"):
        await server.reset_client_for_tests()
    # 0.8.7: parsed-DataFrame cache is a module-global LRU shared across
    # event loops; reset between tests so a prior run's parsed F1 frame
    # doesn't mask a regression in `_get_parsed_table` for the next test.
    if hasattr(server, "reset_df_cache_for_tests"):
        server.reset_df_cache_for_tests()
