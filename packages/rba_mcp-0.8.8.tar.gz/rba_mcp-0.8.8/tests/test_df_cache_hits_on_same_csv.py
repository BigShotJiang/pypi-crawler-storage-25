"""Parsed-DataFrame cache (0.8.7) — Bug 7 latency fix regression guard.

The byte cache hits in <10 ms but the pandas parse cost 5+ s per call
on a shared CPU for typical F-tables. /v1/real-cash-rate p50 was
4.75 s warm before this cache was added.

These tests pin the cache behaviour so a future refactor can't silently
strip the parse-cache layer and regress us back to 5 s/call.
"""
from __future__ import annotations

import pathlib

import pytest

from rba_mcp import parsing, server

FIXTURES = pathlib.Path(__file__).parent / "fixtures"


async def test_df_cache_hits_on_same_csv(monkeypatch):
    """Same csv bytes → parse_csv called ONCE across N invocations."""
    server.reset_df_cache_for_tests()
    body = (FIXTURES / "f1.1-data.csv").read_bytes()

    parse_calls = 0
    real_parse = parsing.parse_csv

    def counting_parse(buf: bytes):
        nonlocal parse_calls
        parse_calls += 1
        return real_parse(buf)

    # Patch the symbol the server module imported (server.py: `from .parsing
    # import ... parse_csv`). Monkeypatching `parsing.parse_csv` alone
    # wouldn't catch that re-export.
    monkeypatch.setattr(server, "parse_csv", counting_parse)

    # 5 sequential parses of identical bytes.
    for _ in range(5):
        header, df = await server._get_parsed_table("f1.1-data.csv", body)
        assert not df.empty

    assert parse_calls == 1, (
        f"parsed-DataFrame cache regression: expected 1 parse for 5 "
        f"identical-bytes calls, got {parse_calls}. The DF cache layer "
        f"in `_get_parsed_table` is not short-circuiting the warm path."
    )


async def test_df_cache_misses_on_different_bytes(monkeypatch):
    """Different bytes for the same filename → re-parse cleanly."""
    server.reset_df_cache_for_tests()
    body_v1 = (FIXTURES / "f1.1-data.csv").read_bytes()
    body_v2 = body_v1 + b"\n# tail comment changes the md5\n"

    parse_calls = 0
    real_parse = parsing.parse_csv

    def counting_parse(buf: bytes):
        nonlocal parse_calls
        parse_calls += 1
        return real_parse(buf)

    monkeypatch.setattr(server, "parse_csv", counting_parse)

    await server._get_parsed_table("f1.1-data.csv", body_v1)
    await server._get_parsed_table("f1.1-data.csv", body_v1)  # cache hit
    await server._get_parsed_table("f1.1-data.csv", body_v2)  # new md5 → miss
    await server._get_parsed_table("f1.1-data.csv", body_v2)  # cache hit

    assert parse_calls == 2, (
        f"Expected 2 parses (one per distinct body), got {parse_calls}. "
        f"The md5 keying in `_get_parsed_table` is wrong — either the "
        f"hash collides or upstream-republication isn't being detected."
    )


async def test_df_cache_evicts_oldest_at_capacity(monkeypatch):
    """LRU cap holds — oldest entry evicted on (max+1)th insert."""
    server.reset_df_cache_for_tests()
    body = (FIXTURES / "f1.1-data.csv").read_bytes()

    # Drive _DF_CACHE_MAX_ENTRIES + 1 distinct keys through the cache by
    # mutating the bytes (so md5 differs). Each entry corresponds to a
    # different csv_filename so the eviction is also exercised across
    # F-tables.
    cap = server._DF_CACHE_MAX_ENTRIES
    for i in range(cap + 1):
        await server._get_parsed_table(f"synthetic_{i}.csv", body + bytes([i]))

    assert len(server._df_cache) == cap, (
        f"LRU did not cap at {cap}: cache size is {len(server._df_cache)}."
    )
    # The first key inserted should have been evicted.
    assert ("synthetic_0.csv", _md5_hex(body + bytes([0]))) not in server._df_cache


def _md5_hex(body: bytes) -> str:
    import hashlib
    return hashlib.md5(body, usedforsecurity=False).hexdigest()


async def test_reset_df_cache_clears_state(monkeypatch):
    """reset_df_cache_for_tests() empties the LRU."""
    server.reset_df_cache_for_tests()
    body = (FIXTURES / "f1.1-data.csv").read_bytes()
    await server._get_parsed_table("f1.1-data.csv", body)
    assert len(server._df_cache) == 1
    server.reset_df_cache_for_tests()
    assert len(server._df_cache) == 0
