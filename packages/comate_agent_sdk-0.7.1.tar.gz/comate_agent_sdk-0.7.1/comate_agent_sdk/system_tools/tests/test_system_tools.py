import asyncio
import json
import os
import shutil
import stat
import shlex
import subprocess
import tempfile
import time
import unittest
import uuid
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from pydantic import ValidationError

from comate_agent_sdk.agent.interrupt import SessionRunController
from comate_agent_sdk.llm.views import ChatInvokeCompletion, ChatInvokeUsage
from comate_agent_sdk.system_tools import tools as system_tools_module
from comate_agent_sdk.system_tools.team.inbox import Inbox
from comate_agent_sdk.system_tools.tools import (
    Bash,
    Edit,
    Glob,
    Grep,
    LS,
    Read,
    TaskCreate,
    TaskList,
    TaskUpdate,
    WebFetch,
    Write,
)
from comate_agent_sdk.tools import get_default_registry
from comate_agent_sdk.tools.system_context import bind_system_tool_context
from comate_agent_sdk.tokens import TokenCost


class TestSystemTools(unittest.TestCase):
    def setUp(self) -> None:
        system_tools_module._WEBFETCH_CACHE.clear()
        system_tools_module._READ_REGISTRY_MEMORY.clear()
        system_tools_module._find_ripgrep.cache_clear()

    def test_default_registry_contains_core_system_tools(self) -> None:
        names = set(get_default_registry().names())
        self.assertTrue({"Read", "Grep", "Bash", "Glob"}.issubset(names))

    def test_read_offset_line_and_limit_lines(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "a.txt"
            p.write_text("l1\nl2\nl3\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out0 = self._run(Read, file_path=str(p))
                self.assertTrue(out0["ok"])
                data0 = out0["data"]
                self.assertIn("\tl1", data0["content"])
                self.assertEqual(data0["total_lines"], 3)
                self.assertEqual(data0["lines_returned"], 3)

                out1 = self._run(Read, file_path=str(p), offset_line=2, limit_lines=1)
                self.assertTrue(out1["ok"])
                data1 = out1["data"]
                self.assertIn("\tl2", data1["content"])
                self.assertNotIn("\tl1", data1["content"])
                self.assertEqual(data1["lines_returned"], 1)
                self.assertEqual(out1["meta"]["offset_line"], 2)

    def test_read_offset_line_zero_is_tolerated_but_normalized(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "a.txt"
            p.write_text("l1\nl2\nl3\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path=str(p), offset_line=0, limit_lines=1)

            self.assertTrue(out["ok"])
            self.assertIn("\tl1", out["data"]["content"])
            self.assertEqual(out["meta"]["offset_line"], 1)
            self.assertEqual(out["data"]["next_offset_line"], 2)

    def test_observable_input_backfills_high_frequency_tool_defaults(self) -> None:
        self.assertEqual(
            Bash.build_observable_input({"command": "git status"}),
            {
                "command": "git status",
                "timeout_ms": 120000,
                "env": None,
                "max_output_chars": 30000,
                "max_disk_bytes": 104857600,
            },
        )
        self.assertEqual(
            Read.build_observable_input({"file_path": "README.md"}),
            {
                "file_path": "README.md",
                "offset": 1,
                "limit": 2000,
            },
        )
        self.assertEqual(
            Glob.build_observable_input({"pattern": "**/*.py"}),
            {
                "pattern": "**/*.py",
                "path": ".",
            },
        )
        self.assertEqual(
            Grep.build_observable_input({"pattern": "TODO"}),
            {
                "pattern": "TODO",
                "path": ".",
                "glob": None,
                "type": None,
                "output_mode": "files_with_matches",
                "B": None,
                "A": None,
                "C": None,
                "context": None,
                "i": None,
                "n": True,
                "head_limit": 250,
                "offset": 0,
                "multiline": False,
            },
        )
        self.assertEqual(
            LS.build_observable_input({"path": "src"}),
            {
                "path": "src",
                "ignore": None,
                "head_limit": 100,
                "include_hidden": False,
                "sort_by": "name",
            },
        )

    def test_read_new_offset_limit_names_are_accepted(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "a.txt"
            p.write_text("l1\nl2\nl3\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path=str(p), offset=2, limit=1)

            self.assertTrue(out["ok"])
            self.assertIn("\tl2", out["data"]["content"])

    def test_read_omitted_limit_uses_default_page_size_with_exact_total_lines(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "many.txt"
            p.write_text(
                "\n".join(f"line_{idx}" for idx in range(1, 2506)) + "\n",
                encoding="utf-8",
            )

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path=str(p))

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["lines_returned"], system_tools_module._READ_DEFAULT_LIMIT)
            self.assertEqual(out["data"]["total_lines"], 2505)
            self.assertTrue(out["data"]["has_more"])
            self.assertEqual(
                out["data"]["next_offset_line"],
                system_tools_module._READ_DEFAULT_LIMIT + 1,
            )
            self.assertIn("\tline_1", out["data"]["content"])
            self.assertNotIn("\tline_2505", out["data"]["content"])

    def test_read_rejects_legacy_format_parameter(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "a.txt"
            p.write_text("l1\nl2\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                with self.assertRaises(Exception):
                    self._run(Read, file_path=str(p), format="raw")

    def test_read_accepts_relative_path_from_project_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            nested = root / "skill" / "SKILL.md"
            nested.parent.mkdir(parents=True, exist_ok=True)
            nested.write_text("# skill\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path="skill/SKILL.md")
                self.assertTrue(out["ok"])
                self.assertEqual(out["data"]["total_lines"], 1)
                self.assertIn("\t# skill", out["data"]["content"])

    def test_read_not_found_suggests_similar_extension(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            existing = root / "app.tsx"
            existing.write_text("export const value = 1\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path="app.js")

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "NOT_FOUND")
            self.assertIn("Did you mean app.tsx?", out["error"]["message"])

    def test_read_not_found_suggests_first_sorted_similar_file(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "app.tsx").write_text("export const value = 1\n", encoding="utf-8")
            (root / "app.jsx").write_text("export const value = 2\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path="app.js")

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "NOT_FOUND")
            self.assertIn("Did you mean app.jsx?", out["error"]["message"])

    def test_read_not_found_does_not_suggest_directory_with_same_stem(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "app").mkdir()

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path="app.js")

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "NOT_FOUND")
            self.assertEqual(out["error"]["message"], "File not found: app.js.")

    def test_read_denies_team_inbox_json_paths(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with mock.patch.dict("os.environ", {"COMATE_TEAMS_DIR": td}):
                inbox = Inbox(team_name="review-team", agent_name="captain")
                inbox.append_message(from_agent="worker-1", content="done")

                with bind_system_tool_context(
                    project_root=root,
                    extra_read_roots=(Path(td).resolve(),),
                ):
                    out = self._run(Read, file_path=str(inbox.path))

        self.assertFalse(out["ok"])
        self.assertEqual(out["error"]["code"], "POLICY_DENIED")

    def test_read_blocks_device_path(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)

            with bind_system_tool_context(
                project_root=root,
                extra_read_roots=(Path("/dev").resolve(),),
            ):
                out = self._run(Read, file_path="/dev/urandom")

        self.assertFalse(out["ok"])
        self.assertEqual(out["error"]["code"], "DEVICE_PATH_BLOCKED")

    def test_read_rejects_binary_extensions(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            cases = {
                "image.png": b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR",
                "module.wasm": b"\x00asm\x01\x00\x00\x00",
                "cache.pyc": b"\xa7\r\r\n\x00\x00\x00\x00payload",
            }

            for name, payload in cases.items():
                (root / name).write_bytes(payload)

            with bind_system_tool_context(project_root=root):
                for name in cases:
                    with self.subTest(file_path=name):
                        out = self._run(Read, file_path=name)
                        self.assertFalse(out["ok"])
                        self.assertEqual(out["error"]["code"], "BINARY_FILE")

    def test_read_rejects_binary_content_with_unknown_extension(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "blob.dat"
            target.write_bytes(b"text-prefix\x00\x00\x00\x00binary-tail")

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path=str(target))

        self.assertFalse(out["ok"])
        self.assertEqual(out["error"]["code"], "BINARY_FILE")

    def test_read_allows_limit_lines_above_5000(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "small.txt"
            target.write_text("l1\nl2\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path=str(target), limit_lines=10000)

        self.assertTrue(out["ok"])
        self.assertEqual(out["data"]["lines_returned"], 2)

    def test_read_large_limit_lines_still_hits_runtime_budget_guard(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "wide.txt"
            long_line = " ".join(f"token_{i}" for i in range(3000))
            target.write_text("\n".join([long_line] * 10), encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Read,
                    file_path=str(target),
                    limit_lines=10000,
                    max_line_chars=10000,
                )

        self.assertFalse(out["ok"])
        self.assertEqual(out["error"]["code"], "OUTPUT_TOO_LARGE")

    def test_write_rejects_path_outside_all_roots(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            root.mkdir(parents=True, exist_ok=True)
            workspace = root / ".agent_workspace"
            p_ok = workspace / "sub" / "b.txt"
            p_bad = Path(td) / "completely_outside" / "evil.txt"

            with bind_system_tool_context(project_root=root):
                ok_out = self._run(Write, file_path=str(p_ok), content="hello")
                self.assertTrue(ok_out["ok"])
                self.assertTrue(p_ok.exists())

                bad_out = self._run(Write, file_path=str(p_bad), content="nope")
                self.assertFalse(bad_out["ok"])
                self.assertIn(bad_out["error"]["code"], {"PATH_ESCAPE", "PERMISSION_DENIED"})

    def test_write_expands_home_path_under_extra_write_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = (Path(td) / "project").resolve()
            root.mkdir(parents=True, exist_ok=True)
            plans_root = (Path(td) / ".agent" / "plans").resolve()
            plans_root.mkdir(parents=True, exist_ok=True)
            expected_path = (plans_root / "optimize-thinking-blocks-compaction.md").resolve()

            with mock.patch.dict("os.environ", {"HOME": td}, clear=False):
                with bind_system_tool_context(project_root=root, extra_write_roots=(plans_root,)):
                    out = self._run(
                        Write,
                        file_path="~/.agent/plans/optimize-thinking-blocks-compaction.md",
                        content="hello\n",
                    )

            self.assertTrue(out["ok"])
            self.assertTrue(expected_path.exists())
            self.assertEqual(expected_path.read_text(encoding="utf-8"), "hello\n")
            self.assertEqual(out["meta"]["resolved_file_path"], str(expected_path))
            self.assertEqual(out["data"]["relpath"], "optimize-thinking-blocks-compaction.md")

    def test_write_does_not_gain_permission_from_extra_read_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = (Path(td) / "project").resolve()
            skill_root = (Path(td) / ".agent" / "skills" / "demo-skill").resolve()
            target_path = skill_root / "scripts" / "tool.py"
            root.mkdir(parents=True, exist_ok=True)
            skill_root.mkdir(parents=True, exist_ok=True)

            with bind_system_tool_context(project_root=root, extra_read_roots=(skill_root,)):
                out = self._run(Write, file_path=str(target_path), content="print('x')\n")

            self.assertFalse(out["ok"])
            self.assertIn(out["error"]["code"], {"PATH_ESCAPE", "PERMISSION_DENIED"})
            self.assertFalse(target_path.exists())

    def test_write_memory_md_prefers_memory_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            memory_root = session_root.parent / "memory"
            session_root.mkdir(parents=True, exist_ok=True)
            memory_root.mkdir(parents=True, exist_ok=True)

            with bind_system_tool_context(
                project_root=root,
                session_id="s1",
                session_root=session_root,
                extra_write_roots=(memory_root,),
            ):
                out = self._run(Write, file_path="MEMORY.md", content="hello\n")

            self.assertTrue(out["ok"])
            self.assertTrue((memory_root / "MEMORY.md").exists())
            self.assertEqual((memory_root / "MEMORY.md").read_text(encoding="utf-8"), "hello\n")
            self.assertFalse((session_root / "MEMORY.md").exists())

    def test_write_memory_subpath_prefers_memory_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            memory_root = session_root.parent / "memory"
            session_root.mkdir(parents=True, exist_ok=True)
            memory_root.mkdir(parents=True, exist_ok=True)

            with bind_system_tool_context(
                project_root=root,
                session_id="s1",
                session_root=session_root,
                extra_write_roots=(memory_root,),
            ):
                out = self._run(Write, file_path="memory/debugging.md", content="note\n")

            self.assertTrue(out["ok"])
            self.assertTrue((memory_root / "debugging.md").exists())
            self.assertEqual((memory_root / "debugging.md").read_text(encoding="utf-8"), "note\n")
            self.assertFalse((session_root / "memory" / "debugging.md").exists())

    def test_write_to_memory_rejects_high_confidence_secret(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            memory_root = session_root.parent / "memory"
            session_root.mkdir(parents=True, exist_ok=True)
            memory_root.mkdir(parents=True, exist_ok=True)
            content = "token: ghp_1234567890abcdef1234567890abcdef1234\n"

            with bind_system_tool_context(
                project_root=root,
                session_id="s1",
                session_root=session_root,
                extra_write_roots=(memory_root,),
            ):
                out = self._run(Write, file_path="memory/debugging.md", content=content)

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "INVALID_ARGUMENT")
            self.assertFalse((memory_root / "debugging.md").exists())

    def test_write_outside_memory_allows_secret_like_fixture(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "fixture.txt"
            content = "token: ghp_1234567890abcdef1234567890abcdef1234\n"

            with bind_system_tool_context(project_root=root):
                out = self._run(Write, file_path=str(target), content=content)

            self.assertTrue(out["ok"])
            self.assertEqual(target.read_text(encoding="utf-8"), content)

    def test_memory_index_guard_warn_mode_allows_write_with_warning(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            memory_root = session_root.parent / "memory"
            session_root.mkdir(parents=True, exist_ok=True)
            memory_root.mkdir(parents=True, exist_ok=True)
            content = "paragraph line 1\nparagraph line 2\nparagraph line 3\n"

            with mock.patch.dict("os.environ", {"COMATE_MEMORY_INDEX_GUARD_MODE": "warn"}, clear=False):
                with bind_system_tool_context(
                    project_root=root,
                    session_id="s1",
                    session_root=session_root,
                    extra_write_roots=(memory_root,),
                ):
                    out = self._run(Write, file_path="MEMORY.md", content=content)

            self.assertTrue(out["ok"])
            self.assertEqual((memory_root / "MEMORY.md").read_text(encoding="utf-8"), content)
            self.assertIn("memory_index_guard_warning", out["meta"])
            self.assertTrue(out["meta"]["memory_index_guard_warning"])

    def test_memory_index_guard_enforce_blocks_write(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            memory_root = session_root.parent / "memory"
            session_root.mkdir(parents=True, exist_ok=True)
            memory_root.mkdir(parents=True, exist_ok=True)
            content = "paragraph line 1\nparagraph line 2\nparagraph line 3\n"

            with mock.patch.dict("os.environ", {"COMATE_MEMORY_INDEX_GUARD_MODE": "enforce"}, clear=False):
                with bind_system_tool_context(
                    project_root=root,
                    session_id="s1",
                    session_root=session_root,
                    extra_write_roots=(memory_root,),
                ):
                    out = self._run(Write, file_path="MEMORY.md", content=content)

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "INVALID_ARGUMENT")
            self.assertFalse((memory_root / "MEMORY.md").exists())

    def test_memory_index_guard_enforce_blocks_edit(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            memory_root = session_root.parent / "memory"
            session_root.mkdir(parents=True, exist_ok=True)
            memory_root.mkdir(parents=True, exist_ok=True)
            target = memory_root / "MEMORY.md"
            target.write_text("- @debugging.md - old\n", encoding="utf-8")

            with mock.patch.dict("os.environ", {"COMATE_MEMORY_INDEX_GUARD_MODE": "enforce"}, clear=False):
                with bind_system_tool_context(
                    project_root=root,
                    session_id="s1",
                    session_root=session_root,
                    extra_write_roots=(memory_root,),
                ):
                    self.assertTrue(self._run(Read, file_path=str(target))["ok"])
                    out = self._run(
                        Edit,
                        file_path="MEMORY.md",
                        old_string="- @debugging.md - old",
                        new_string="paragraph line 1\nparagraph line 2\nparagraph line 3",
                    )

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "INVALID_ARGUMENT")
            self.assertEqual(target.read_text(encoding="utf-8"), "- @debugging.md - old\n")

    def test_memory_index_guard_enforce_rejects_legacy_format(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            memory_root = session_root.parent / "memory"
            session_root.mkdir(parents=True, exist_ok=True)
            memory_root.mkdir(parents=True, exist_ok=True)

            with mock.patch.dict("os.environ", {"COMATE_MEMORY_INDEX_GUARD_MODE": "enforce"}, clear=False):
                with bind_system_tool_context(
                    project_root=root,
                    session_id="s1",
                    session_root=session_root,
                    extra_write_roots=(memory_root,),
                ):
                    out = self._run(
                        Write,
                        file_path="MEMORY.md",
                        content="- `debugging.md` | legacy summary\n",
                    )

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "INVALID_ARGUMENT")

    def test_memory_index_guard_enforce_allows_new_format(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            memory_root = session_root.parent / "memory"
            session_root.mkdir(parents=True, exist_ok=True)
            memory_root.mkdir(parents=True, exist_ok=True)

            with mock.patch.dict("os.environ", {"COMATE_MEMORY_INDEX_GUARD_MODE": "enforce"}, clear=False):
                with bind_system_tool_context(
                    project_root=root,
                    session_id="s1",
                    session_root=session_root,
                    extra_write_roots=(memory_root,),
                ):
                    out = self._run(
                        Write,
                        file_path="MEMORY.md",
                        content="- @debugging.md - summary\n",
                    )

            self.assertTrue(out["ok"])
            self.assertEqual((memory_root / "MEMORY.md").read_text(encoding="utf-8"), "- @debugging.md - summary\n")

    def test_edit_requires_unique_old_string_unless_replace_all(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            workspace = root / ".agent_workspace"
            p = workspace / "c.txt"
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("x\nx\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                read_out = self._run(Read, file_path=str(p))
                self.assertTrue(read_out["ok"])

                out = self._run(Edit, file_path=str(p), old_string="x", new_string="y")
                self.assertFalse(out["ok"])
                self.assertEqual(out["error"]["code"], "CONFLICT")
                self.assertEqual(p.read_text(encoding="utf-8"), "x\nx\n")

                out2 = self._run(
                    Edit,
                    file_path=str(p),
                    old_string="x",
                    new_string="y",
                    replace_all=True,
                )
                self.assertTrue(out2["ok"])
                self.assertEqual(out2["data"]["replacements"], 2)
                self.assertEqual(p.read_text(encoding="utf-8"), "y\ny\n")

    def test_edit_can_target_existing_project_file_by_relative_path(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "proj.txt"
            p.write_text("hello\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                read_out = self._run(Read, file_path="proj.txt")
                self.assertTrue(read_out["ok"])

                out = self._run(Edit, file_path="proj.txt", old_string="hello", new_string="hi")
                self.assertTrue(out["ok"])
                self.assertEqual(out["data"]["replacements"], 1)
                self.assertEqual(p.read_text(encoding="utf-8"), "hi\n")
                self.assertEqual(out["data"]["relpath"], "proj.txt")

    def test_edit_can_fill_existing_empty_file_with_empty_old_string(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "empty.txt"
            p.write_text("", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(p))["ok"])
                out = self._run(Edit, file_path=str(p), old_string="", new_string="filled\n")

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["replacements"], 1)
            self.assertFalse(out["data"]["created"])
            self.assertEqual(out["data"]["start_line"], 1)
            self.assertEqual(out["data"]["end_line"], 1)
            self.assertEqual(p.read_text(encoding="utf-8"), "filled\n")

    def test_edit_not_found_suggests_similar_extension(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            existing = root / "app.tsx"
            existing.write_text("console.log('hello')\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Edit,
                    file_path="app.js",
                    old_string="console.log('hello')",
                    new_string="console.log('hi')",
                )

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "NOT_FOUND")
            self.assertIn("Did you mean app.tsx?", out["error"]["message"])

    def test_edit_rejects_empty_old_string_for_non_empty_existing_file(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "filled.txt"
            p.write_text("hello\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(p))["ok"])
                out = self._run(Edit, file_path=str(p), old_string="", new_string="world\n")

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "CONFLICT")
            self.assertEqual(p.read_text(encoding="utf-8"), "hello\n")

    def test_edit_matches_curly_quotes_and_preserves_quote_style(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "quotes.txt"
            p.write_text('title = “old value”\n', encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(p))["ok"])
                out = self._run(
                    Edit,
                    file_path=str(p),
                    old_string='title = "old value"',
                    new_string='title = "new value"',
                )

            self.assertTrue(out["ok"])
            self.assertEqual(p.read_text(encoding="utf-8"), 'title = “new value”\n')

    def test_write_strips_trailing_whitespace_for_non_markdown(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "script.py"

            with bind_system_tool_context(project_root=root):
                out = self._run(Write, file_path=str(target), content="x = 1  \ny = 2\t \n")

            self.assertTrue(out["ok"])
            self.assertEqual(target.read_text(encoding="utf-8"), "x = 1\ny = 2\n")

    def test_write_preserves_trailing_whitespace_for_markdown(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "notes.md"
            content = "line 1  \nline 2  \n"

            with bind_system_tool_context(project_root=root):
                out = self._run(Write, file_path=str(target), content=content)

            self.assertTrue(out["ok"])
            self.assertEqual(target.read_text(encoding="utf-8"), content)

    def test_write_create_returns_structured_create_fields(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "created.txt"

            with bind_system_tool_context(project_root=root):
                out = self._run(Write, file_path=str(target), content="hello\n")

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["type"], "create")
            self.assertIsNone(out["data"]["original_file"])
            self.assertEqual(out["data"]["structured_patch"], [])

    def test_write_overwrite_returns_structured_update_fields(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "existing.txt"
            target.write_text("old\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(target))["ok"])
                out = self._run(Write, file_path=str(target), content="new\n")

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["type"], "update")
            self.assertEqual(out["data"]["original_file"], "old\n")
            self.assertTrue(out["data"]["structured_patch"])
            patch_lines = out["data"]["structured_patch"][0]["lines"]
            self.assertIn("-old", patch_lines)
            self.assertIn("+new", patch_lines)

    def test_write_append_requires_read_first(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "existing.txt"
            target.write_text("old\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(Write, file_path=str(target), content="new\n", mode="append")

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "PRECONDITION_FAILED")
            self.assertEqual(target.read_text(encoding="utf-8"), "old\n")

    def test_write_append_returns_structured_append_fields(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "existing.txt"
            target.write_text("old\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(target))["ok"])
                out = self._run(Write, file_path=str(target), content="new\n", mode="append")

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["type"], "append")
            self.assertEqual(out["data"]["original_file"], "old\n")
            self.assertTrue(out["data"]["structured_patch"])
            patch_lines = out["data"]["structured_patch"][0]["lines"]
            self.assertIn("+new", patch_lines)

    def test_write_rejects_external_modification_after_read(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "existing.txt"
            target.write_text("old\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(target))["ok"])
                target.write_text("external\n", encoding="utf-8")
                out = self._run(Write, file_path=str(target), content="new\n")

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "CONFLICT")
            self.assertEqual(target.read_text(encoding="utf-8"), "external\n")

    def test_edit_returns_structured_update_fields(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "existing.txt"
            target.write_text("old\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(target))["ok"])
                out = self._run(Edit, file_path=str(target), old_string="old", new_string="new")

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["type"], "update")
            self.assertEqual(out["data"]["original_file"], "old\n")
            self.assertTrue(out["data"]["structured_patch"])

    def test_edit_create_returns_structured_create_fields(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "created.txt"

            with bind_system_tool_context(project_root=root):
                out = self._run(Edit, file_path=str(target), old_string="", new_string="new\n")

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["type"], "create")
            self.assertIsNone(out["data"]["original_file"])
            self.assertEqual(out["data"]["structured_patch"], [])

    def test_write_preserves_trailing_whitespace_for_mdx(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "notes.mdx"
            content = "line 1  \nline 2  \n"

            with bind_system_tool_context(project_root=root):
                out = self._run(Write, file_path=str(target), content=content)

            self.assertTrue(out["ok"])
            self.assertEqual(target.read_text(encoding="utf-8"), content)

    def test_edit_strips_trailing_whitespace_for_non_markdown(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "script.py"
            target.write_text("value = 1\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(target))["ok"])
                out = self._run(
                    Edit,
                    file_path=str(target),
                    old_string="value = 1\n",
                    new_string="value = 2  \n",
                )

            self.assertTrue(out["ok"])
            self.assertEqual(target.read_text(encoding="utf-8"), "value = 2\n")

    def test_edit_preserves_trailing_whitespace_for_markdown(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "notes.md"
            target.write_text("line 1\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(target))["ok"])
                out = self._run(
                    Edit,
                    file_path=str(target),
                    old_string="line 1\n",
                    new_string="line 2  \n",
                )

            self.assertTrue(out["ok"])
            self.assertEqual(target.read_text(encoding="utf-8"), "line 2  \n")

    def test_edit_rejects_file_too_large(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "huge.py"
            target.write_text("value = 1\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(target))["ok"])
                with mock.patch.object(
                    system_tools_module,
                    "_stat",
                    new=mock.AsyncMock(return_value=SimpleNamespace(st_size=system_tools_module._MAX_EDIT_FILE_SIZE + 1)),
                ):
                    out = self._run(
                        Edit,
                        file_path=str(target),
                        old_string="value = 1",
                        new_string="value = 2",
                    )

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "FILE_TOO_LARGE")

    def test_write_preserves_existing_file_permissions(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "config.txt"
            target.write_text("before\n", encoding="utf-8")
            os.chmod(target, 0o640)

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(target))["ok"])
                out = self._run(Write, file_path=str(target), content="after\n")

            self.assertTrue(out["ok"])
            self.assertEqual(stat.S_IMODE(target.stat().st_mode), 0o640)

    def test_edit_preserves_existing_file_permissions(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "config.txt"
            target.write_text("before\n", encoding="utf-8")
            os.chmod(target, 0o640)

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(target))["ok"])
                out = self._run(
                    Edit,
                    file_path=str(target),
                    old_string="before",
                    new_string="after",
                )

            self.assertTrue(out["ok"])
            self.assertEqual(stat.S_IMODE(target.stat().st_mode), 0o640)

    def test_edit_not_found_message_has_no_extra_spaces_without_suggestion(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Edit,
                    file_path="missing.py",
                    old_string="before",
                    new_string="after",
                )

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "NOT_FOUND")
            self.assertEqual(
                out["error"]["message"],
                "File not found: missing.py. To create a new file with Edit, set old_string to ''.",
            )

    def test_edit_does_not_apply_curly_quote_style_to_unrelated_new_string_quotes(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "quotes.txt"
            p.write_text("don’t\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(p))["ok"])
                out = self._run(
                    Edit,
                    file_path=str(p),
                    old_string="don't",
                    new_string="dict['key']",
                )

            self.assertTrue(out["ok"])
            self.assertEqual(p.read_text(encoding="utf-8"), "dict['key']\n")

    def test_edit_delete_strips_trailing_newline_after_match(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "delete.txt"
            p.write_text("alpha\nbeta\ngamma\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(p))["ok"])
                out = self._run(
                    Edit,
                    file_path=str(p),
                    old_string="beta",
                    new_string="",
                )

            self.assertTrue(out["ok"])
            self.assertEqual(p.read_text(encoding="utf-8"), "alpha\ngamma\n")

    def test_edit_delete_inline_match_keeps_following_line_boundary(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "inline-delete.txt"
            p.write_text("x = foo\nnext\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(p))["ok"])
                out = self._run(
                    Edit,
                    file_path=str(p),
                    old_string="foo",
                    new_string="",
                )

            self.assertTrue(out["ok"])
            self.assertEqual(p.read_text(encoding="utf-8"), "x = \nnext\n")

    def test_edit_reports_matched_line_range_for_partial_edit(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "line-range.txt"
            p.write_text("alpha\nbeta\ngamma\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                self.assertTrue(self._run(Read, file_path=str(p))["ok"])
                out = self._run(
                    Edit,
                    file_path=str(p),
                    old_string="beta",
                    new_string="BETA",
                )

            self.assertTrue(out["ok"])
            self.assertFalse(out["data"]["created"])
            self.assertEqual(out["data"]["start_line"], 2)
            self.assertEqual(out["data"]["end_line"], 2)
            self.assertEqual(p.read_text(encoding="utf-8"), "alpha\nBETA\ngamma\n")

    def test_glob_returns_relative_paths(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "d").mkdir()
            (root / "d" / "f1.txt").write_text("a", encoding="utf-8")
            (root / "d" / "f2.txt").write_text("b", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(Glob, pattern="**/*.txt")
                self.assertTrue(out["ok"])
                self.assertEqual(out["data"]["count"], 2)
                self.assertTrue(all(not Path(m).is_absolute() for m in out["data"]["matches"]))

    def test_glob_marks_count_lower_bound_when_head_limit_reached(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "d").mkdir()
            for idx in range(3):
                (root / "d" / f"f{idx}.txt").write_text("x", encoding="utf-8")

            async def _fake_stream(*_args, **kwargs):
                on_stdout_line = kwargs["on_stdout_line"]
                stopped_early = False
                for rel in ("d/f0.txt", "d/f1.txt", "d/f2.txt"):
                    if not on_stdout_line(rel):
                        stopped_early = True
                        break
                return system_tools_module._StreamingSubprocessResult(
                    returncode=0,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=stopped_early,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ), mock.patch.object(
                    system_tools_module, "_GLOB_DEFAULT_HEAD_LIMIT", 1
                ):
                    out = self._run(Glob, pattern="**/*.txt")
                self.assertTrue(out["ok"])
                self.assertEqual(len(out["data"]["matches"]), 1)
                self.assertTrue(out["data"]["truncated"])
                self.assertTrue(out["data"]["count_is_lower_bound"])
                self.assertEqual(out["data"]["count"], 2)

    def test_glob_include_dirs_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "d").mkdir()

            with bind_system_tool_context(project_root=root):
                with self.assertRaises(Exception):
                    self._run(Glob, pattern="**/*", include_dirs=True)

    def test_glob_uses_rg_primary_path_with_absolute_pattern_base_dir(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            src = root / "src"
            src.mkdir()
            target = src / "tool.py"
            target.write_text("x", encoding="utf-8")

            captured_cmd: list[str] = []
            captured_cwd: Path | None = None

            async def _fake_stream(*args, **kwargs):
                nonlocal captured_cwd
                captured_cmd[:] = list(args[0])
                captured_cwd = kwargs.get("cwd")
                kwargs["on_stdout_line"]("./tool.py")
                return system_tools_module._StreamingSubprocessResult(
                    returncode=0,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(system_tools_module.shutil, "which", return_value="/usr/bin/rg"):
                    with mock.patch.object(
                        system_tools_module,
                        "_run_subprocess_streaming_lines",
                        side_effect=_fake_stream,
                    ):
                        out = self._run(
                            Glob,
                            pattern=str(src / "*.py"),
                        )

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["matches"], ["src/tool.py"])
            self.assertEqual(out["meta"]["engine"], "rg")
            self.assertEqual(out["meta"]["search_path"], "src")
            self.assertEqual(captured_cwd.resolve(), src.resolve())
            self.assertEqual(captured_cmd[-1], ".")
            self.assertIn("--sort=modified", captured_cmd)
            glob_patterns = [
                captured_cmd[idx + 1]
                for idx, arg in enumerate(captured_cmd[:-1])
                if arg == "--glob"
            ]
            self.assertIn("*.py", glob_patterns)

    @unittest.skipUnless(shutil.which("rg"), "ripgrep required")
    def test_glob_rg_primary_path_sorts_by_mtime(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            old_file = root / "old.txt"
            new_file = root / "new.txt"
            old_file.write_text("old", encoding="utf-8")
            new_file.write_text("new", encoding="utf-8")

            now = time.time()
            os.utime(old_file, (now - 10, now - 10))
            os.utime(new_file, (now, now))

            with bind_system_tool_context(project_root=root):
                out = self._run(Glob, pattern="*.txt")

            self.assertTrue(out["ok"])
            self.assertEqual(out["meta"]["engine"], "rg")
            self.assertEqual(out["data"]["matches"], ["old.txt", "new.txt"])

    def test_glob_returns_ripgrep_missing_when_rg_not_found(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with bind_system_tool_context(project_root=root):
                with mock.patch.object(system_tools_module, "_find_ripgrep", return_value=None):
                    out = self._run(Glob, pattern="**/*.py")
            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "RIPGREP_MISSING")
            self.assertIn("ripgrep", out["error"]["message"].lower())

    def test_grep_returns_ripgrep_missing_when_rg_not_found(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "a.py").write_text("x", encoding="utf-8")
            with bind_system_tool_context(project_root=root):
                with mock.patch.object(system_tools_module, "_find_ripgrep", return_value=None):
                    out = self._run(Grep, pattern="foo")
            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "RIPGREP_MISSING")
            self.assertIn("ripgrep", out["error"]["message"].lower())

    def test_find_ripgrep_falls_back_to_sysconfig_scripts_dir(self) -> None:
        """When PATH lacks `rg`, the locator must fall back to the current
        interpreter's scripts directory where the `ripgrep` wheel is installed.
        This is the Windows failure mode (venv Scripts not on parent PATH)."""
        system_tools_module._find_ripgrep.cache_clear()
        try:
            with tempfile.TemporaryDirectory() as td:
                scripts_dir = Path(td)
                rg_name = "rg.exe" if os.name == "nt" else "rg"
                rg_path = scripts_dir / rg_name
                rg_path.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
                if os.name != "nt":
                    rg_path.chmod(0o755)

                with mock.patch.object(system_tools_module.shutil, "which", return_value=None):
                    with mock.patch.object(
                        system_tools_module.sysconfig,
                        "get_path",
                        return_value=str(scripts_dir),
                    ):
                        resolved = system_tools_module._find_ripgrep()

                self.assertEqual(resolved, str(rg_path))
        finally:
            system_tools_module._find_ripgrep.cache_clear()

    def test_glob_and_grep_exec_resolved_rg_path_not_bare_name(self) -> None:
        """Regression: `_find_ripgrep()` must flow into argv[0] of the spawned
        subprocess. If argv[0] is the bare string "rg", Windows CreateProcess
        fails with WinError 2 whenever the venv Scripts dir is not on PATH —
        which is exactly the case the sysconfig fallback is meant to rescue."""
        fake_rg = "/fake/scripts/rg.exe" if os.name == "nt" else "/fake/scripts/rg"
        captured_cmds: list[list[str]] = []

        async def _fake_stream(*args, **kwargs):
            captured_cmds.append(list(args[0]))
            on_line = kwargs.get("on_stdout_line")
            if on_line is not None:
                on_line("./a.py")
            return system_tools_module._StreamingSubprocessResult(
                returncode=0,
                stdout_capture="",
                stderr_capture="",
                stdout_capture_truncated=False,
                stderr_capture_truncated=False,
                stopped_early=False,
                timed_out=False,
            )

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "a.py").write_text("import os\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module, "_find_ripgrep", return_value=fake_rg
                ):
                    with mock.patch.object(
                        system_tools_module,
                        "_run_subprocess_streaming_lines",
                        side_effect=_fake_stream,
                    ):
                        glob_out = self._run(Glob, pattern="**/*.py")
                        grep_out = self._run(Grep, pattern="import")

        self.assertTrue(glob_out["ok"])
        self.assertTrue(grep_out["ok"])
        self.assertEqual(len(captured_cmds), 2)
        for cmd in captured_cmds:
            self.assertEqual(
                cmd[0],
                fake_rg,
                msg=f"argv[0] must be the resolved rg path, got {cmd[0]!r}",
            )

    def test_find_ripgrep_prefers_path_over_sysconfig(self) -> None:
        """Guard against silently reordering resolution: PATH result wins
        over the sysconfig scripts-dir fallback even if both exist."""
        system_tools_module._find_ripgrep.cache_clear()
        try:
            with tempfile.TemporaryDirectory() as td:
                scripts_dir = Path(td)
                rg_name = "rg.exe" if os.name == "nt" else "rg"
                (scripts_dir / rg_name).write_text("fallback", encoding="utf-8")
                path_hit = "/custom/path/rg"

                with mock.patch.object(system_tools_module.shutil, "which", return_value=path_hit):
                    with mock.patch.object(
                        system_tools_module.sysconfig,
                        "get_path",
                        return_value=str(scripts_dir),
                    ):
                        resolved = system_tools_module._find_ripgrep()

                self.assertEqual(resolved, path_hit)
        finally:
            system_tools_module._find_ripgrep.cache_clear()

    def test_glob_rg_args_do_not_exclude_node_modules(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "node_modules" / "pkg").mkdir(parents=True, exist_ok=True)

            captured_cmd: list[str] = []

            async def _fake_stream(*args, **kwargs):
                captured_cmd[:] = list(args[0])
                return system_tools_module._StreamingSubprocessResult(
                    returncode=1,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(system_tools_module.shutil, "which", return_value="/usr/bin/rg"):
                    with mock.patch.object(
                        system_tools_module,
                        "_run_subprocess_streaming_lines",
                        side_effect=_fake_stream,
                    ):
                        out = self._run(Glob, pattern="**/*.js")

            self.assertTrue(out["ok"])
            glob_patterns = [
                captured_cmd[idx + 1]
                for idx, arg in enumerate(captured_cmd[:-1])
                if arg == "--glob"
            ]
            self.assertNotIn("!node_modules", glob_patterns)

    def test_glob_missing_path_suggests_similar_directory(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "src").mkdir()

            with bind_system_tool_context(project_root=root):
                out = self._run(Glob, pattern="*.py", path="srcc")

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "NOT_FOUND")
            self.assertIn("Did you mean src?", out["error"]["message"])

    def test_grep_missing_path_with_wildcards_shows_migration_hint(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "src").mkdir()

            with bind_system_tool_context(project_root=root):
                out = self._run(Grep, pattern="foo", path="src/*.py")

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "NOT_FOUND")
            self.assertIn("put wildcards in glob instead", out["error"]["message"])

    def test_grep_head_limit_accepts_string_digit(self) -> None:
        params = system_tools_module.GrepInput(pattern="foo", head_limit="100")
        self.assertEqual(params.head_limit, 100)

    def test_grep_head_limit_accepts_empty_string_as_default(self) -> None:
        params = system_tools_module.GrepInput(pattern="foo", head_limit="")
        self.assertEqual(params.head_limit, 250)

    def test_grep_bool_fields_accept_string_values(self) -> None:
        params = system_tools_module.GrepInput(pattern="foo", i="yes", n="0", multiline="true")
        self.assertTrue(params.i)
        self.assertFalse(params.n)
        self.assertTrue(params.multiline)

    def test_grep_head_limit_rejects_bool(self) -> None:
        with self.assertRaises(Exception):
            system_tools_module.GrepInput(pattern="foo", head_limit=True)

    def test_grep_head_limit_rejects_garbage(self) -> None:
        with self.assertRaises(Exception):
            system_tools_module.GrepInput(pattern="foo", head_limit="abc")

    def test_glob_unc_path_bypasses_stat_check(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)

            async def _fake_stream(*args, **kwargs):
                return system_tools_module._StreamingSubprocessResult(
                    returncode=1,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module, "_IS_WINDOWS", True,
                ), mock.patch.object(
                    system_tools_module,
                    "_exists",
                    side_effect=AssertionError("UNC path should bypass stat check"),
                ), mock.patch.object(
                    system_tools_module.shutil,
                    "which",
                    return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(Glob, pattern="*.py", path="//server/share")

        self.assertTrue(out["ok"])

    def test_grep_unc_path_bypasses_stat_check(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)

            async def _fake_stream(*args, **kwargs):
                return system_tools_module._StreamingSubprocessResult(
                    returncode=1,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module, "_IS_WINDOWS", True,
                ), mock.patch.object(
                    system_tools_module,
                    "_exists",
                    side_effect=AssertionError("UNC path should bypass stat check"),
                ), mock.patch.object(
                    system_tools_module.shutil,
                    "which",
                    return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(Grep, pattern="foo", path="//server/share")

        self.assertTrue(out["ok"])

    def test_glob_double_slash_path_is_blocked_on_posix(self) -> None:
        if os.name == "nt":
            self.skipTest("POSIX-only: Windows treats // as UNC by design")
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=AssertionError("must reject before spawning rg"),
                ):
                    out_path = self._run(Glob, pattern="*.py", path="//tmp")
                    out_pattern = self._run(Glob, pattern="//tmp/*.py")

        for out in (out_path, out_pattern):
            self.assertFalse(out["ok"])
            self.assertIn(out["error"]["code"], {"PATH_ESCAPE", "PERMISSION_DENIED"})

    def test_grep_double_slash_path_is_blocked_on_posix(self) -> None:
        if os.name == "nt":
            self.skipTest("POSIX-only: Windows treats // as UNC by design")
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=AssertionError("must reject before spawning rg"),
                ):
                    out = self._run(Grep, pattern="foo", path="//tmp")

        self.assertFalse(out["ok"])
        self.assertIn(out["error"]["code"], {"PATH_ESCAPE", "PERMISSION_DENIED"})

    def test_ls_missing_path_suggests_similar_directory(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "packages").mkdir()

            with bind_system_tool_context(project_root=root):
                out = self._run(LS, path="packges")

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "NOT_FOUND")
            self.assertIn("Did you mean packages?", out["error"]["message"])

    def test_grep_alias_flags_with_context(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "e.txt"
            p.write_text("a\nfoo\nb\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Grep,
                    **{
                        "pattern": "foo",
                        "path": str(root),
                        "output_mode": "content",
                        "-A": 1,
                        "-n": False,
                    },
                )
                self.assertTrue(out["ok"])
                self.assertEqual(out["data"]["total_matches"], 1)
                # P1-3: Adapt to new grouped format
                matches_by_file = out["data"]["matches_by_file"]
                self.assertEqual(len(matches_by_file), 1)
                file_data = list(matches_by_file.values())[0]
                m = file_data["matches"][0]
                self.assertIsNone(m["line_number"])
                self.assertEqual(m["after_context"], ["b"])

    def test_grep_context_param_overrides_alias_flags(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "ctx.txt"
            p.write_text("zero\none\nhit\ntwo\nthree\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Grep,
                    **{
                        "pattern": "hit",
                        "path": str(root),
                        "output_mode": "content",
                        "context": 1,
                        "-C": 4,
                        "-A": 3,
                        "-B": 2,
                    },
                )

            self.assertTrue(out["ok"])
            matches_by_file = out["data"]["matches_by_file"]
            file_data = list(matches_by_file.values())[0]
            match = file_data["matches"][0]
            self.assertEqual(match["before_context"], ["one"])
            self.assertEqual(match["after_context"], ["two"])

    def test_grep_content_uses_streaming_path(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "e.txt"
            p.write_text("a\nfoo\nb\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module,
                    "_run_subprocess",
                    side_effect=AssertionError("content mode should not call _run_subprocess"),
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="content",
                    )
                    self.assertTrue(out["ok"])
                    self.assertEqual(out["data"]["total_matches"], 1)

    def test_grep_content_offset_applies_to_match_items(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "content.txt"
            target.write_text("foo\nbar\nbaz\n", encoding="utf-8")

            events = [
                json.dumps(
                    {
                        "type": "match",
                        "data": {
                            "path": {"text": str(target)},
                            "line_number": 1,
                            "lines": {"text": "foo\n"},
                        },
                    }
                ),
                json.dumps(
                    {
                        "type": "match",
                        "data": {
                            "path": {"text": str(target)},
                            "line_number": 2,
                            "lines": {"text": "bar\n"},
                        },
                    }
                ),
                json.dumps(
                    {
                        "type": "match",
                        "data": {
                            "path": {"text": str(target)},
                            "line_number": 3,
                            "lines": {"text": "baz\n"},
                        },
                    }
                ),
            ]

            async def _fake_stream(*_args, **kwargs):
                for row in events:
                    if not kwargs["on_stdout_line"](row):
                        break
                return system_tools_module._StreamingSubprocessResult(
                    returncode=0,
                    stdout_capture="\n".join(events),
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo|bar|baz",
                        path=str(root),
                        output_mode="content",
                        head_limit=1,
                        offset=1,
                    )

            self.assertTrue(out["ok"])
            matches_by_file = out["data"]["matches_by_file"]
            file_data = list(matches_by_file.values())[0]
            self.assertEqual(len(file_data["matches"]), 1)
            self.assertEqual(file_data["matches"][0]["line_number"], 2)
            self.assertEqual(file_data["matches"][0]["line"], "bar")

    def test_grep_files_with_matches_uses_streaming_path(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            a = root / "a.txt"
            b = root / "b.txt"
            a.write_text("foo\n", encoding="utf-8")
            b.write_text("foo\n", encoding="utf-8")

            async def _fake_stream(*_args, **kwargs):
                on_stdout_line = kwargs["on_stdout_line"]
                stopped_early = False
                for line in (str(a), str(b)):
                    if not on_stdout_line(line):
                        stopped_early = True
                        break
                return system_tools_module._StreamingSubprocessResult(
                    returncode=0,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=stopped_early,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess",
                    side_effect=AssertionError("files_with_matches should not call _run_subprocess"),
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="files_with_matches",
                        head_limit=1,
                    )
                    self.assertTrue(out["ok"])
                    self.assertEqual(out["data"]["files"], ["a.txt"])
                    self.assertEqual(out["data"]["count"], 2)
                    self.assertTrue(out["data"]["truncated"])
                    self.assertTrue(out["data"]["total_matches_is_lower_bound"])

    def test_grep_files_with_matches_offset_applies_to_file_items(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            a = root / "a.txt"
            b = root / "b.txt"
            c = root / "c.txt"
            for path in (a, b, c):
                path.write_text("foo\n", encoding="utf-8")

            async def _fake_stream(*_args, **kwargs):
                for line in (str(a), str(b), str(c)):
                    if not kwargs["on_stdout_line"](line):
                        break
                return system_tools_module._StreamingSubprocessResult(
                    returncode=0,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="files_with_matches",
                        head_limit=1,
                        offset=1,
                    )

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["files"], ["b.txt"])

    def test_grep_count_offset_applies_to_count_rows(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            a = root / "a.txt"
            b = root / "b.txt"
            c = root / "c.txt"
            for path in (a, b, c):
                path.write_text("foo\n", encoding="utf-8")

            async def _fake_stream(*_args, **kwargs):
                for line in (
                    f"{a}:1",
                    f"{b}:2",
                    f"{c}:3",
                ):
                    if not kwargs["on_stdout_line"](line):
                        break
                return system_tools_module._StreamingSubprocessResult(
                    returncode=0,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="count",
                        head_limit=1,
                        offset=1,
                    )

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["counts"], [{"file": "b.txt", "count": 2}])
            self.assertEqual(out["data"]["total_matches"], 6)

    def test_grep_count_total_matches_stays_stable_across_head_limits(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            a = root / "a.txt"
            b = root / "b.txt"
            c = root / "c.txt"
            for path in (a, b, c):
                path.write_text("foo\n", encoding="utf-8")

            async def _fake_stream(*_args, **kwargs):
                for line in (
                    f"{a}:1",
                    f"{b}:2",
                    f"{c}:3",
                ):
                    if not kwargs["on_stdout_line"](line):
                        break
                return system_tools_module._StreamingSubprocessResult(
                    returncode=0,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    limited = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="count",
                        head_limit=2,
                    )
                    defaulted = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="count",
                    )

            self.assertTrue(limited["ok"])
            self.assertTrue(defaulted["ok"])
            self.assertEqual(limited["data"]["total_matches"], 6)
            self.assertEqual(defaulted["data"]["total_matches"], 6)
            self.assertEqual(len(limited["data"]["counts"]), 2)
            self.assertEqual(len(defaulted["data"]["counts"]), 3)

    def test_grep_count_timeout_with_partial_results_returns_ok(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "a.txt"
            target.write_text("foo\n", encoding="utf-8")

            async def _fake_stream(*args, **kwargs):
                kwargs["on_stdout_line"](f"{target}:4")
                return system_tools_module._StreamingSubprocessResult(
                    returncode=124,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=True,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="count",
                    )

            self.assertTrue(out["ok"])
            self.assertTrue(out["meta"]["timed_out"])
            self.assertEqual(out["data"]["counts"], [{"file": "a.txt", "count": 4}])
            self.assertEqual(out["data"]["total_matches"], 4)
            self.assertEqual(out["data"]["truncated_reason"], "timeout")
            self.assertTrue(out["data"]["total_matches_is_lower_bound"])

    def test_grep_count_timeout_without_partial_results_returns_timeout_error(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "a.txt"
            target.write_text("foo\n", encoding="utf-8")

            async def _fake_stream(*args, **kwargs):
                return system_tools_module._StreamingSubprocessResult(
                    returncode=124,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=True,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="count",
                    )

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "TIMEOUT")
            self.assertTrue(out["meta"]["timed_out"])

    def test_grep_count_parses_windows_style_drive_paths(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)

            async def _fake_stream(*_args, **kwargs):
                for line in (
                    r"C:\repo\a.txt:3",
                    r"D:\logs\b.txt:2",
                ):
                    if not kwargs["on_stdout_line"](line):
                        break
                return system_tools_module._StreamingSubprocessResult(
                    returncode=0,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="count",
                    )

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["total_matches"], 5)
            self.assertEqual(
                out["data"]["counts"],
                [
                    {"file": r"C:\repo\a.txt", "count": 3},
                    {"file": r"D:\logs\b.txt", "count": 2},
                ],
            )

    def test_grep_head_limit_zero_means_unlimited(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            a = root / "a.txt"
            b = root / "b.txt"
            c = root / "c.txt"
            for path in (a, b, c):
                path.write_text("foo\n", encoding="utf-8")

            async def _fake_stream(*_args, **kwargs):
                for line in (str(a), str(b), str(c)):
                    if not kwargs["on_stdout_line"](line):
                        break
                return system_tools_module._StreamingSubprocessResult(
                    returncode=0,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="files_with_matches",
                        head_limit=0,
                    )

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["files"], ["a.txt", "b.txt", "c.txt"])
            self.assertFalse(out["data"]["truncated"])

    def test_grep_pattern_starting_with_dash_uses_dash_e(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "dash.txt").write_text("-foo\n", encoding="utf-8")

            captured_cmd: list[str] = []

            async def _fake_stream(*args, **kwargs):
                captured_cmd[:] = list(args[0])
                return system_tools_module._StreamingSubprocessResult(
                    returncode=1,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="-foo",
                        path=str(root),
                        output_mode="files_with_matches",
                    )

            self.assertTrue(out["ok"])
            self.assertIn("-e", captured_cmd)
            self.assertLess(captured_cmd.index("-e"), captured_cmd.index("-foo"))

    def test_grep_glob_supports_multi_value_split(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "a.py").write_text("foo\n", encoding="utf-8")

            captured_cmd: list[str] = []

            async def _fake_stream(*args, **kwargs):
                captured_cmd[:] = list(args[0])
                return system_tools_module._StreamingSubprocessResult(
                    returncode=1,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="files_with_matches",
                        glob="*.py,*.md tests/*",
                    )

            self.assertTrue(out["ok"])
            glob_patterns = [
                captured_cmd[idx + 1]
                for idx, arg in enumerate(captured_cmd[:-1])
                if arg == "--glob"
            ]
            self.assertIn("*.py", glob_patterns)
            self.assertIn("*.md", glob_patterns)
            self.assertIn("tests/*", glob_patterns)

    def test_grep_files_with_matches_uses_max_columns_and_mtime_sort_flag(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "a.txt").write_text("foo\n", encoding="utf-8")

            captured_cmd: list[str] = []

            async def _fake_stream(*args, **kwargs):
                captured_cmd[:] = list(args[0])
                return system_tools_module._StreamingSubprocessResult(
                    returncode=1,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="files_with_matches",
                    )

            self.assertTrue(out["ok"])
            self.assertIn("--max-columns", captured_cmd)
            self.assertEqual(captured_cmd[captured_cmd.index("--max-columns") + 1], "500")
            self.assertIn("--hidden", captured_cmd)
            self.assertIn("--sortr=modified", captured_cmd)
            self.assertNotIn("--no-messages", captured_cmd)

    def test_grep_rg_args_do_not_exclude_node_modules(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "a.txt").write_text("foo\n", encoding="utf-8")

            captured_cmd: list[str] = []

            async def _fake_stream(*args, **kwargs):
                captured_cmd[:] = list(args[0])
                return system_tools_module._StreamingSubprocessResult(
                    returncode=1,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="files_with_matches",
                    )

            self.assertTrue(out["ok"])
            glob_patterns = [
                captured_cmd[idx + 1]
                for idx, arg in enumerate(captured_cmd[:-1])
                if arg == "--glob"
            ]
            self.assertNotIn("!node_modules", glob_patterns)

    def test_grep_searches_hidden_dirs_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            hidden = root / ".github" / "workflows" / "ci.yml"
            hidden.parent.mkdir(parents=True, exist_ok=True)
            hidden.write_text("foo\n", encoding="utf-8")

            captured_cmd: list[str] = []

            async def _fake_stream(*args, **kwargs):
                captured_cmd[:] = list(args[0])
                kwargs["on_stdout_line"](str(hidden))
                return system_tools_module._StreamingSubprocessResult(
                    returncode=0,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="files_with_matches",
                    )

            self.assertTrue(out["ok"])
            self.assertIn("--hidden", captured_cmd)
            self.assertEqual(out["data"]["files"], [".github/workflows/ci.yml"])

    @unittest.skipUnless(shutil.which("rg"), "ripgrep required")
    def test_grep_files_with_matches_rg_sorts_by_mtime_desc(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            old_file = root / "old.txt"
            new_file = root / "new.txt"
            old_file.write_text("foo\n", encoding="utf-8")
            new_file.write_text("foo\n", encoding="utf-8")

            now = time.time()
            os.utime(old_file, (now - 10, now - 10))
            os.utime(new_file, (now, now))

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Grep,
                    pattern="foo",
                    path=str(root),
                    output_mode="files_with_matches",
                    head_limit=2,
                )

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["files"], ["new.txt", "old.txt"])

    @unittest.skipUnless(shutil.which("rg"), "ripgrep required")
    def test_grep_count_mode_counts_lines_not_matches(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "todo.txt"
            target.write_text("TODO TODO TODO\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Grep,
                    pattern="TODO",
                    path=str(root),
                    output_mode="count",
                )

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["counts"], [{"file": "todo.txt", "count": 1}])
            self.assertEqual(out["data"]["total_matches"], 1)

    @unittest.skipUnless(shutil.which("rg"), "ripgrep required")
    def test_grep_multiline_matches_crlf_text_when_enabled(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "multi.txt"
            target.write_bytes(b"begin\r\nmiddle\r\nend\r\n")

            with bind_system_tool_context(project_root=root):
                disabled = self._run(
                    Grep,
                    pattern=r"begin[\s\S]*end",
                    path=str(target),
                    output_mode="content",
                    multiline=False,
                )
                enabled = self._run(
                    Grep,
                    pattern=r"begin[\s\S]*end",
                    path=str(target),
                    output_mode="content",
                    multiline=True,
                )

            self.assertTrue(disabled["ok"])
            self.assertTrue(enabled["ok"])
            self.assertEqual(disabled["data"]["total_matches"], 0)
            self.assertEqual(enabled["data"]["total_matches"], 1)

    def test_glob_timeout_with_partial_results_returns_ok(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "a.txt").write_text("x", encoding="utf-8")

            async def _fake_stream(*args, **kwargs):
                kwargs["on_stdout_line"]("./a.txt")
                return system_tools_module._StreamingSubprocessResult(
                    returncode=124,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=True,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(system_tools_module.shutil, "which", return_value="/usr/bin/rg"):
                    with mock.patch.object(
                        system_tools_module,
                        "_run_subprocess_streaming_lines",
                        side_effect=_fake_stream,
                    ):
                        out = self._run(Glob, pattern="*.txt")

            self.assertTrue(out["ok"])
            self.assertTrue(out["meta"]["timed_out"])
            self.assertEqual(out["data"]["matches"], ["a.txt"])
            self.assertEqual(out["data"]["truncated_reason"], "timeout")

    def test_glob_env_flags_can_disable_hidden_and_no_ignore(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "a.txt").write_text("x", encoding="utf-8")
            captured_cmd: list[str] = []

            async def _fake_stream(*args, **kwargs):
                captured_cmd[:] = list(args[0])
                return system_tools_module._StreamingSubprocessResult(
                    returncode=1,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.dict(
                    os.environ,
                    {
                        "CLAUDE_CODE_GLOB_NO_IGNORE": "false",
                        "CLAUDE_CODE_GLOB_HIDDEN": "false",
                    },
                    clear=False,
                ):
                    with mock.patch.object(system_tools_module.shutil, "which", return_value="/usr/bin/rg"):
                        with mock.patch.object(
                            system_tools_module,
                            "_run_subprocess_streaming_lines",
                            side_effect=_fake_stream,
                        ):
                            out = self._run(Glob, pattern="*.txt")

            self.assertTrue(out["ok"])
            self.assertNotIn("--hidden", captured_cmd)
            self.assertNotIn("--no-ignore", captured_cmd)

    def test_grep_timeout_with_partial_results_returns_ok(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            target = root / "a.txt"
            target.write_text("foo\n", encoding="utf-8")

            async def _fake_stream(*args, **kwargs):
                kwargs["on_stdout_line"](str(target))
                return system_tools_module._StreamingSubprocessResult(
                    returncode=124,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=True,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="files_with_matches",
                    )

            self.assertTrue(out["ok"])
            self.assertTrue(out["meta"]["timed_out"])
            self.assertEqual(out["data"]["files"], ["a.txt"])
            self.assertEqual(out["data"]["truncated_reason"], "timeout")
            self.assertTrue(out["data"]["total_matches_is_lower_bound"])

    def test_grep_timeout_seconds_can_be_overridden_by_env(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "a.txt").write_text("foo\n", encoding="utf-8")
            seen_timeout: list[float | None] = []

            async def _fake_stream(*args, **kwargs):
                seen_timeout.append(kwargs.get("timeout_seconds"))
                return system_tools_module._StreamingSubprocessResult(
                    returncode=124,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=True,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.dict(
                    os.environ,
                    {"CLAUDE_CODE_GLOB_TIMEOUT_SECONDS": "3"},
                    clear=False,
                ):
                    with mock.patch.object(
                        system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                    ), mock.patch.object(
                        system_tools_module,
                        "_run_subprocess_streaming_lines",
                        side_effect=_fake_stream,
                    ):
                        out = self._run(
                            Grep,
                            pattern="foo",
                            path=str(root),
                            output_mode="files_with_matches",
                        )

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "TIMEOUT")
            self.assertEqual(seen_timeout, [3.0])
            self.assertEqual(out["meta"]["timeout_seconds"], 3.0)

    def test_grep_timeout_without_partial_results_returns_timeout_error(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "a.txt").write_text("foo\n", encoding="utf-8")

            async def _fake_stream(*args, **kwargs):
                return system_tools_module._StreamingSubprocessResult(
                    returncode=124,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=True,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="files_with_matches",
                    )

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "TIMEOUT")
            self.assertTrue(out["meta"]["timed_out"])

    def test_default_search_rg_timeout_uses_wsl_value_when_wsl_detected(self) -> None:
        system_tools_module._is_wsl.cache_clear()
        with mock.patch.object(system_tools_module, "_is_wsl", return_value=True):
            self.assertEqual(
                system_tools_module._default_search_rg_timeout_seconds(),
                system_tools_module._SEARCH_RG_TIMEOUT_SECONDS_WSL,
            )
            with mock.patch.dict(os.environ, {}, clear=False):
                os.environ.pop("CLAUDE_CODE_GLOB_TIMEOUT_SECONDS", None)
                self.assertEqual(
                    system_tools_module._search_rg_timeout_seconds(),
                    system_tools_module._SEARCH_RG_TIMEOUT_SECONDS_WSL,
                )
        system_tools_module._is_wsl.cache_clear()

    def test_default_search_rg_timeout_uses_default_when_not_wsl(self) -> None:
        system_tools_module._is_wsl.cache_clear()
        with mock.patch.object(system_tools_module, "_is_wsl", return_value=False):
            self.assertEqual(
                system_tools_module._default_search_rg_timeout_seconds(),
                system_tools_module._SEARCH_RG_TIMEOUT_SECONDS,
            )
            with mock.patch.dict(os.environ, {}, clear=False):
                os.environ.pop("CLAUDE_CODE_GLOB_TIMEOUT_SECONDS", None)
                self.assertEqual(
                    system_tools_module._search_rg_timeout_seconds(),
                    system_tools_module._SEARCH_RG_TIMEOUT_SECONDS,
                )
        system_tools_module._is_wsl.cache_clear()

    def test_grep_passes_search_rg_grace_seconds_to_streaming(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "a.txt").write_text("foo\n", encoding="utf-8")
            seen_grace: list[float | None] = []

            async def _fake_stream(*args, **kwargs):
                seen_grace.append(kwargs.get("grace_seconds"))
                return system_tools_module._StreamingSubprocessResult(
                    returncode=1,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="files_with_matches",
                    )

            self.assertEqual(
                seen_grace,
                [system_tools_module._SEARCH_RG_GRACE_SECONDS],
            )

    def test_grep_eagain_retries_single_thread_and_resets_partial_state(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            first = root / "stale.txt"
            second = root / "fresh.txt"
            first.write_text("foo\n", encoding="utf-8")
            second.write_text("foo\n", encoding="utf-8")

            calls: list[list[str]] = []

            async def _fake_stream(*args, **kwargs):
                calls.append(list(args[0]))
                if len(calls) == 1:
                    kwargs["on_stdout_line"](str(first))
                    return system_tools_module._StreamingSubprocessResult(
                        returncode=2,
                        stdout_capture="",
                        stderr_capture="rg: io error: Resource temporarily unavailable (os error 11)",
                        stdout_capture_truncated=False,
                        stderr_capture_truncated=False,
                        stopped_early=False,
                        timed_out=False,
                    )
                kwargs["on_stdout_line"](str(second))
                return system_tools_module._StreamingSubprocessResult(
                    returncode=0,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="files_with_matches",
                    )

            self.assertTrue(out["ok"])
            self.assertEqual(out["data"]["files"], ["fresh.txt"])
            self.assertEqual(out["data"]["count"], 1)
            self.assertTrue(out["meta"]["retried_single_thread"])
            self.assertEqual(calls[1][1:3], ["-j", "1"])

    def test_is_eagain_error_signature_matrix(self) -> None:
        positive = (
            "rg: io error: Resource temporarily unavailable (os error 11)",
            "rg: io error: Resource temporarily unavailable (os error 35)",
            "rg: Resource temporarily unavailable",
        )
        for sample in positive:
            self.assertTrue(
                system_tools_module._is_eagain_error(sample),
                msg=f"expected EAGAIN match for: {sample!r}",
            )

        negative = (
            "",
            "rg: io error: No such file or directory (os error 2)",
            "rg: regex parse error",
        )
        for sample in negative:
            self.assertFalse(
                system_tools_module._is_eagain_error(sample),
                msg=f"unexpected EAGAIN match for: {sample!r}",
            )

    def test_grep_eagain_retries_on_macos_errno_35(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "hit.txt").write_text("foo\n", encoding="utf-8")

            calls: list[list[str]] = []

            async def _fake_stream(*args, **kwargs):
                calls.append(list(args[0]))
                if len(calls) == 1:
                    return system_tools_module._StreamingSubprocessResult(
                        returncode=2,
                        stdout_capture="",
                        stderr_capture=(
                            "rg: io error: Resource temporarily unavailable (os error 35)"
                        ),
                        stdout_capture_truncated=False,
                        stderr_capture_truncated=False,
                        stopped_early=False,
                        timed_out=False,
                    )
                kwargs["on_stdout_line"](str(root / "hit.txt"))
                return system_tools_module._StreamingSubprocessResult(
                    returncode=0,
                    stdout_capture="",
                    stderr_capture="",
                    stdout_capture_truncated=False,
                    stderr_capture_truncated=False,
                    stopped_early=False,
                    timed_out=False,
                )

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(
                    system_tools_module.shutil, "which", return_value="/usr/bin/rg",
                ), mock.patch.object(
                    system_tools_module,
                    "_run_subprocess_streaming_lines",
                    side_effect=_fake_stream,
                ):
                    out = self._run(
                        Grep,
                        pattern="foo",
                        path=str(root),
                        output_mode="files_with_matches",
                    )

            self.assertTrue(out["ok"])
            self.assertTrue(out["meta"]["retried_single_thread"])
            self.assertEqual(len(calls), 2)
            self.assertEqual(calls[1][1:3], ["-j", "1"])

    def test_bash_rg_requires_max_count(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "x.txt").write_text("ok", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Bash,
                    command=f"rg --line-number --no-heading --color=never ok {root}",
                )
                self.assertFalse(out["ok"])
                self.assertEqual(out["error"]["code"], "POLICY_DENIED")

    def test_bash_rg_with_strict_flags_and_scope(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "x.txt").write_text("ok", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Bash,
                    command=f"rg --line-number --no-heading --color=never --max-count 5 ok {root}",
                )
                self.assertTrue(out["ok"])
                self.assertEqual(out["data"]["exit_code"], 0)
                self.assertIn("x.txt", out["data"]["stdout"])

    def test_bash_rejects_removed_cwd_parameter(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)

            with bind_system_tool_context(project_root=root):
                with self.assertRaises(ValidationError):
                    self._run(Bash, command="pwd", cwd="null")

    def test_bash_persists_cd_between_tool_calls(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td).resolve()
            subdir = root / "sub"
            subdir.mkdir()
            bash_cwd = {"path": root}

            with bind_system_tool_context(
                project_root=root,
                bash_cwd_getter=lambda: bash_cwd["path"],
                bash_cwd_setter=lambda path: bash_cwd.update(path=path),
            ):
                first = self._run(Bash, command="cd sub && pwd")
                second = self._run(Bash, command="pwd")

            self.assertTrue(first["ok"])
            self.assertTrue(second["ok"])
            self.assertEqual(bash_cwd["path"], subdir)
            self.assertIn(str(subdir), first["data"]["stdout"])
            self.assertIn(str(subdir), second["data"]["stdout"])

    def test_bash_resets_out_of_bounds_cd_after_command(self) -> None:
        with tempfile.TemporaryDirectory() as project_td, tempfile.TemporaryDirectory() as outside_td:
            root = Path(project_td).resolve()
            outside = Path(outside_td).resolve()
            bash_cwd = {"path": root}

            with bind_system_tool_context(
                project_root=root,
                bash_cwd_getter=lambda: bash_cwd["path"],
                bash_cwd_setter=lambda path: bash_cwd.update(path=path),
            ):
                first = self._run(Bash, command=f"cd {shlex.quote(str(outside))} && pwd")
                second = self._run(Bash, command="pwd")

            self.assertTrue(first["ok"])
            self.assertTrue(second["ok"])
            self.assertEqual(bash_cwd["path"], root)
            self.assertIn(str(outside), first["data"]["stdout"])
            self.assertIn("Shell cwd was reset", first["data"]["stderr"])
            self.assertIn(str(root), second["data"]["stdout"])

    def test_bash_merges_stderr_into_stdout_preview(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)

            with bind_system_tool_context(project_root=root, workspace_root=root):
                with mock.patch.object(system_tools_module, "_validate_bash_command", return_value=None):
                    out = self._run(
                        Bash,
                        command="printf 'out\\n'; printf 'err\\n' >&2",
                    )

                self.assertTrue(out["ok"])
                self.assertEqual(out["data"]["stderr"], "")
                self.assertIn("out", out["data"]["stdout"])
                self.assertIn("err", out["data"]["stdout"])

    def test_bash_subprocess_detaches_stdin_from_terminal(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            popen_kwargs: dict[str, object] = {}

            class _FakePopen:
                pid = 43210
                returncode = 0

                def __init__(self, _cmd, **kwargs) -> None:
                    popen_kwargs.update(kwargs)

                def poll(self) -> int:
                    return int(self.returncode)

                def wait(self, timeout: float | None = None) -> int:
                    return int(self.returncode)

            with bind_system_tool_context(project_root=root, workspace_root=root):
                with mock.patch.object(
                    system_tools_module,
                    "_validate_bash_command",
                    return_value=None,
                ), mock.patch.object(
                    system_tools_module,
                    "_build_bash_command",
                    return_value=["bash", "-lc", "true"],
                ), mock.patch.object(
                    system_tools_module.subprocess,
                    "Popen",
                    side_effect=lambda cmd, **kwargs: _FakePopen(cmd, **kwargs),
                ):
                    out = self._run(Bash, command="true")

            self.assertTrue(out["ok"])
            self.assertIs(popen_kwargs["stdin"], subprocess.DEVNULL)

    def test_bash_large_output_artifact_is_raw_text_file(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            command = "i=0; while [ $i -lt 500 ]; do printf x; i=$((i+1)); done"

            with bind_system_tool_context(project_root=root, workspace_root=root):
                with mock.patch.object(system_tools_module, "_validate_bash_command", return_value=None):
                    out = self._run(
                        Bash,
                        command=command,
                        max_output_chars=200,
                    )

                self.assertTrue(out["ok"])
                self.assertTrue(out["data"]["truncated"])
                self.assertTrue(out["data"]["stdout_truncated"])
                self.assertEqual(out["data"]["stdout_total_bytes"], 500)
                self.assertEqual(out["data"]["stderr_total_bytes"], 0)
                artifact = out["data"]["artifact"]
                self.assertIsNotNone(artifact)
                artifact_path = root / artifact["relpath"]
                self.assertTrue(artifact_path.exists())
                self.assertEqual(artifact_path.suffix, ".txt")
                self.assertEqual(artifact_path.read_text(encoding="utf-8"), "x" * 500)
                self.assertNotIn("read_hint", out["data"])

    def test_bash_interrupt_kills_process_group_and_returns_interrupted(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            controller = SessionRunController()
            cmd = ["bash", "-lc", f"sleep 5; echo alive > {uuid.uuid4().hex}.txt"]

            class _FakePopen:
                def __init__(self) -> None:
                    self.pid = 43210
                    self.returncode: int | None = None

                def communicate(self, timeout: float | None = None):
                    deadline = None if timeout is None else (time.monotonic() + timeout)
                    while self.returncode is None:
                        if deadline is not None and time.monotonic() >= deadline:
                            raise subprocess.TimeoutExpired(cmd=cmd, timeout=timeout)
                        time.sleep(0.01)
                    return ("", "")

                def wait(self, timeout: float | None = None) -> int:
                    deadline = None if timeout is None else (time.monotonic() + timeout)
                    while self.returncode is None:
                        if deadline is not None and time.monotonic() >= deadline:
                            raise subprocess.TimeoutExpired(cmd=cmd, timeout=timeout)
                        time.sleep(0.01)
                    return int(self.returncode)

                def terminate(self) -> None:
                    if self.returncode is None:
                        self.returncode = -15

                def kill(self) -> None:
                    if self.returncode is None:
                        self.returncode = -9

            fake_proc = _FakePopen()

            async def _run_interrupt_case() -> dict:
                async def _fake_io_call(func, /, *args, **kwargs):
                    target_self = getattr(func, "__self__", None)
                    target_name = getattr(func, "__name__", "")
                    if target_self is fake_proc and target_name == "communicate":
                        timeout = float(kwargs.get("timeout", 0.0) or 0.0)
                        waited = 0.0
                        while fake_proc.returncode is None and waited < timeout:
                            await asyncio.sleep(0.01)
                            waited += 0.01
                        if fake_proc.returncode is None:
                            raise subprocess.TimeoutExpired(cmd=cmd, timeout=timeout)
                        return ("", "")

                    if target_self is fake_proc and target_name == "wait":
                        timeout = float(kwargs.get("timeout", 0.0) or 0.0)
                        waited = 0.0
                        while fake_proc.returncode is None and waited < timeout:
                            await asyncio.sleep(0.01)
                            waited += 0.01
                        if fake_proc.returncode is None:
                            raise subprocess.TimeoutExpired(cmd=cmd, timeout=timeout)
                        return int(fake_proc.returncode)

                    return func(*args, **kwargs)

                with bind_system_tool_context(
                    project_root=root,
                    run_controller=controller,
                ):
                    with mock.patch.object(
                        system_tools_module.subprocess,
                        "Popen",
                        return_value=fake_proc,
                    ), mock.patch.object(
                        system_tools_module.os,
                        "killpg",
                        side_effect=lambda _pid, sig: fake_proc.kill()
                        if sig == system_tools_module.signal.SIGKILL
                        else fake_proc.terminate(),
                    ), mock.patch.object(
                        system_tools_module.iu,
                        "io_call",
                        side_effect=_fake_io_call,
                    ):
                        task = asyncio.create_task(
                            Bash.execute(
                                params={
                                    "command": "sleep 5; echo interrupted",
                                    "timeout_ms": 500,
                                }
                            )
                        )
                        await asyncio.sleep(0.2)
                        controller.interrupt("user")
                        raw = await asyncio.wait_for(task, timeout=3.0)
                    return json.loads(raw)

            out = asyncio.run(_run_interrupt_case())
            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "INTERRUPTED")
            self.assertIn("stdout", out["data"])
            self.assertIn("interrupted", out["data"])
            self.assertTrue(out["data"]["interrupted"])
            self.assertNotIn("stdout", out["meta"])

    def test_edit_creates_new_file_when_old_string_is_empty(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            workspace = root / ".agent_workspace"
            p = workspace / "new.txt"

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Edit,
                    file_path=str(p),
                    old_string="",
                    new_string="hello\n",
                )
                self.assertTrue(out["ok"])
                self.assertEqual(out["data"]["replacements"], 1)
                self.assertTrue(out["data"]["created"])
                self.assertEqual(out["data"]["start_line"], 1)
                self.assertEqual(out["data"]["end_line"], 1)
                self.assertTrue(p.exists())
                self.assertEqual(p.read_text(encoding="utf-8"), "hello\n")

    def test_ls_returns_entries_and_supports_ignore(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "a.txt").write_text("a", encoding="utf-8")
            (root / "b.txt").write_text("b", encoding="utf-8")
            (root / "d").mkdir()

            with bind_system_tool_context(project_root=root):
                out = self._run(LS, path=str(root), ignore=["b.txt"])
                self.assertTrue(out["ok"])
                names = [e["name"] for e in out["data"]["entries"]]
                self.assertIn("a.txt", names)
                self.assertIn("d", names)
                self.assertNotIn("b.txt", names)

    def test_ls_returns_invalid_argument_when_path_is_file(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            file_path = root / "only.txt"
            file_path.write_text("x", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(LS, path=str(file_path))
                self.assertFalse(out["ok"])
                self.assertEqual(out["error"]["code"], "INVALID_ARGUMENT")

    def test_read_before_modify_is_enforced_for_existing_files(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            workspace = root / ".agent_workspace"
            target = workspace / "existing.txt"
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text("hello\nhello\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root, session_id="s1", session_root=session_root):
                out_write = self._run(Write, file_path=str(target), content="new\n")
                self.assertFalse(out_write["ok"])
                self.assertEqual(out_write["error"]["code"], "PRECONDITION_FAILED")

                out_edit = self._run(Edit, file_path=str(target), old_string="hello", new_string="hi")
                self.assertFalse(out_edit["ok"])
                self.assertEqual(out_edit["error"]["code"], "PRECONDITION_FAILED")

                read_out = self._run(Read, file_path=str(target))
                self.assertTrue(read_out["ok"])

                ok_edit = self._run(
                    Edit,
                    file_path=str(target),
                    old_string="hello",
                    new_string="hi",
                    replace_all=True,
                )
                self.assertTrue(ok_edit["ok"])
                self.assertEqual(target.read_text(encoding="utf-8"), "hi\nhi\n")

    def test_read_registry_persists_to_session_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            p = root / "a.txt"
            p.write_text("l1\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root, session_id="s1", session_root=session_root):
                out = self._run(Read, file_path=str(p))
                self.assertTrue(out["ok"])

            idx_path = session_root / "read_index.json"
            self.assertTrue(idx_path.exists())
            payload = json.loads(idx_path.read_text(encoding="utf-8"))
            self.assertEqual(payload.get("schema_version"), 5)
            self.assertIn("file_versions", payload)
            self.assertIn("read_ranges", payload)
            self.assertIn(str(p.resolve()), payload.get("files", []))

    def test_read_returns_error_when_output_exceeds_token_budget(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "wide.md"
            long_cell = " ".join(f"token_{i}" for i in range(3000))
            p.write_text("\n".join([f"| col | {long_cell} |" for _ in range(10)]), encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path=str(p), limit_lines=10)

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "OUTPUT_TOO_LARGE")
            self.assertIn("offset", out["error"]["message"])
            self.assertIn("limit", out["error"]["message"])

    def test_read_suggested_limit_uses_token_budget_scan(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "uneven.md"
            short = "short line"
            long = " ".join(f"token_{i}" for i in range(3000))
            p.write_text("\n".join([short] * 5 + [long] * 5), encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Read,
                    file_path=str(p),
                    limit_lines=10,
                )

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "OUTPUT_TOO_LARGE")
            self.assertIsInstance(out["meta"]["suggested_limit"], int)
            self.assertGreater(out["meta"]["suggested_limit"], 0)
            self.assertLess(out["meta"]["suggested_limit"], 10)

    def test_read_suggested_limit_retry_succeeds(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "retry.md"
            long = " ".join(f"token_{i}" for i in range(3000))
            p.write_text("\n".join([long] * 10), encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                first = self._run(Read, file_path=str(p), limit_lines=10)
                self.assertFalse(first["ok"])
                self.assertEqual(first["error"]["code"], "OUTPUT_TOO_LARGE")

                retry = self._run(
                    Read,
                    file_path=str(p),
                    offset=first["meta"]["suggested_offset"],
                    limit=first["meta"]["suggested_limit"],
                )

            self.assertTrue(retry["ok"])

    def test_read_output_too_large_returns_new_retry_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "token_budget.txt"
            line = " ".join(f"token_{i}" for i in range(3000))
            p.write_text("\n".join([line] * 8), encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Read,
                    file_path=str(p),
                    limit_lines=8,
                )

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "OUTPUT_TOO_LARGE")
            self.assertEqual(out["meta"]["suggested_offset"], 1)
            self.assertIsInstance(out["meta"]["suggested_limit"], int)
            self.assertIsNone(out["meta"].get("recommend_alternative"))

    def test_read_output_too_large_no_alternative_when_lines_fit(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "many_token_lines.txt"
            line = " ".join(f"token_{i}" for i in range(3000))
            p.write_text("\n".join([line] * 10), encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Read,
                    file_path=str(p),
                    limit_lines=10,
                )

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "OUTPUT_TOO_LARGE")
            self.assertIsNone(out["meta"].get("recommend_alternative"))

    def test_read_full_file_rejects_large_file_without_limit(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "large.txt"
            p.write_text("x" * (system_tools_module._READ_FULL_FILE_MAX_BYTES + 1024), encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path=str(p))

            self.assertFalse(out["ok"])
            self.assertEqual(out["error"]["code"], "OUTPUT_TOO_LARGE")
            self.assertEqual(out["meta"]["suggested_offset"], 1)
            self.assertEqual(out["meta"]["suggested_limit"], system_tools_module._READ_DEFAULT_LIMIT)
            self.assertEqual(out["meta"]["truncated_reason"], "file_size_limit")

    def test_read_reuses_previous_result_for_same_version_and_range(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            p = root / "a.txt"
            p.write_text("l1\nl2\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root, session_id="s1", session_root=session_root):
                first = self._run(Read, file_path=str(p))
                second = self._run(Read, file_path=str(p))

            self.assertTrue(first["ok"])
            self.assertTrue(second["ok"])
            self.assertFalse(first["data"].get("reused_previous_result", False))
            self.assertTrue(second["data"]["reused_previous_result"])
            self.assertIn("File unchanged since last read", second["data"]["reuse_message"])
            self.assertIn("refer to that instead of re-reading", second["data"]["reuse_message"])

    def test_read_reuse_is_invalidated_by_file_change(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            p = root / "a.txt"
            p.write_text("l1\nl2\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root, session_id="s1", session_root=session_root):
                first = self._run(Read, file_path=str(p))
                p.write_text("l1\nl2\nl3\n", encoding="utf-8")
                second = self._run(Read, file_path=str(p))

            self.assertTrue(first["ok"])
            self.assertTrue(second["ok"])
            self.assertFalse(second["data"].get("reused_previous_result", False))
            self.assertIn("\tl3", second["data"]["content"])

    def test_read_reuse_is_invalidated_by_write_even_when_file_size_matches(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            workspace = root / ".agent_workspace"
            p = workspace / "a.txt"
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("ab\ncd\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root, session_id="s1", session_root=session_root):
                first = self._run(Read, file_path=str(p))
                self.assertTrue(first["ok"])
                write_out = self._run(Write, file_path=str(p), content="wx\nyz\n")
                self.assertTrue(write_out["ok"])
                second = self._run(Read, file_path=str(p))

            self.assertTrue(second["ok"])
            self.assertFalse(second["data"].get("reused_previous_result", False))
            self.assertIn("\twx", second["data"]["content"])
            self.assertNotIn("\tab", second["data"]["content"])

    def test_read_reuse_is_invalidated_by_edit_even_when_file_size_matches(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            workspace = root / ".agent_workspace"
            p = workspace / "a.txt"
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("ab\ncd\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root, session_id="s1", session_root=session_root):
                first = self._run(Read, file_path=str(p))
                self.assertTrue(first["ok"])
                edit_out = self._run(Edit, file_path=str(p), old_string="ab", new_string="xy")
                self.assertTrue(edit_out["ok"])
                second = self._run(Read, file_path=str(p))

            self.assertTrue(second["ok"])
            self.assertFalse(second["data"].get("reused_previous_result", False))
            self.assertIn("\txy", second["data"]["content"])
            self.assertNotIn("\tab", second["data"]["content"])

    def test_read_reuse_can_be_disabled_via_env(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            p = root / "a.txt"
            p.write_text("l1\nl2\n", encoding="utf-8")

            with mock.patch.dict(os.environ, {"COMATE_READ_REUSE_ENABLED": "0"}):
                with bind_system_tool_context(project_root=root, session_id="s1", session_root=session_root):
                    first = self._run(Read, file_path=str(p))
                    second = self._run(Read, file_path=str(p))

            self.assertTrue(first["ok"])
            self.assertTrue(second["ok"])
            self.assertFalse(first["data"].get("reused_previous_result", False))
            self.assertFalse(second["data"].get("reused_previous_result", False))
            self.assertIn("\tl1", second["data"]["content"])

    def test_grep_content_marks_lower_bound_when_truncated(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            line = "foo " + ("x" * 240)
            # Multi-file setup to exceed both per-file --max-count and global match-event limit.
            for i in range(8):
                p = root / f"huge_{i}.txt"
                p.write_text("\n".join([line] * 1200), encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Grep,
                    pattern="foo",
                    path=str(root),
                    output_mode="content",
                )
                self.assertTrue(out["ok"])
                self.assertTrue(out["data"]["truncated"])
                self.assertTrue(out["data"]["total_matches_is_lower_bound"])

    def test_task_tools_persist_to_task_store(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = root / "sessions" / "s1"
            store_root = root / "task-store"

            from comate_agent_sdk.system_tools.task import TaskStore

            with bind_system_tool_context(
                project_root=root,
                session_id="s1",
                session_root=session_root,
                task_store=TaskStore(store_dir=store_root, list_id="shared"),
            ):
                created = self._run(TaskCreate, subject="Regression coverage")
                self.assertTrue(created["ok"])
                self.assertTrue((store_root / "shared.json").exists())

                updated = self._run(TaskUpdate, task_id="1", status="in_progress", owner="s1")
                self.assertTrue(updated["ok"])
                listed = self._run(TaskList)
                self.assertTrue(listed["ok"])
                self.assertEqual(listed["data"]["total"], 1)
                self.assertEqual(listed["data"]["tasks"][0]["status"], "in_progress")
                self.assertEqual(listed["data"]["tasks"][0]["owner"], "s1")

    def test_webfetch_uses_low_llm_and_records_usage(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)

            class DummyLLM:
                model = "dummy-low"

                @property
                def provider(self) -> str:
                    return "dummy"

                @property
                def name(self) -> str:
                    return self.model

                async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
                    return ChatInvokeCompletion(
                        content="answer",
                        usage=ChatInvokeUsage(
                            prompt_tokens=10,
                            prompt_cached_tokens=None,
                            prompt_cache_creation_tokens=None,
                            prompt_image_tokens=None,
                            completion_tokens=5,
                            total_tokens=15,
                        ),
                    )

            token_cost = TokenCost(include_cost=False)
            llm_levels = {"LOW": DummyLLM()}

            def fake_get(url, timeout, impersonate, headers=None):
                return SimpleNamespace(status_code=200, url=url, text="<h1>Hello</h1>", headers=SimpleNamespace())

            with bind_system_tool_context(
                project_root=root,
                session_id="s1",
                session_root=root / "sessions" / "s1",
                token_cost=token_cost,
                llm_levels=llm_levels,
            ):
                with mock.patch.dict("sys.modules", {"curl_cffi": SimpleNamespace(requests=SimpleNamespace(get=fake_get))}):
                    with mock.patch.dict("sys.modules", {"markdownify": SimpleNamespace(markdownify=lambda html: "# Hello")}):
                        out = self._run_raw(WebFetch, url="https://example.com", prompt="Summarize")
                        self.assertTrue(out["ok"])
                        self.assertEqual(out["data"]["summary_text"], "answer")
                        self.assertIn("artifact", out["data"])
                        self.assertEqual(len(token_cost.usage_history), 1)
                        self.assertEqual(token_cost.usage_history[0].model, "dummy-low")
                        self.assertEqual(token_cost.usage_history[0].level, "LOW")
                        self.assertEqual(token_cost.usage_history[0].source, "webfetch")

    def test_webfetch_non_200_does_not_call_llm(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)

            class ExplodingLLM:
                model = "dummy-low"

                @property
                def provider(self) -> str:
                    return "dummy"

                @property
                def name(self) -> str:
                    return self.model

                async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
                    raise AssertionError("should not be called")

            llm_levels = {"LOW": ExplodingLLM()}

            def fake_get(url, timeout, impersonate, headers=None):
                return SimpleNamespace(status_code=404, url=url, text="not found", headers=SimpleNamespace())

            with bind_system_tool_context(
                project_root=root,
                session_id="s1",
                session_root=root / "sessions" / "s1",
                llm_levels=llm_levels,
            ):
                with mock.patch.dict("sys.modules", {"curl_cffi": SimpleNamespace(requests=SimpleNamespace(get=fake_get))}):
                    out = self._run_raw(WebFetch, url="https://example-404.com", prompt="Summarize")
                    self.assertFalse(out["ok"])
                    self.assertEqual(out["error"]["code"], "NOT_FOUND")

    def test_webfetch_records_subagent_prefixed_source(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)

            class DummyLLM:
                model = "dummy-low"

                @property
                def provider(self) -> str:
                    return "dummy"

                @property
                def name(self) -> str:
                    return self.model

                async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
                    return ChatInvokeCompletion(
                        content="answer",
                        usage=ChatInvokeUsage(
                            prompt_tokens=10,
                            prompt_cached_tokens=None,
                            prompt_cache_creation_tokens=None,
                            prompt_image_tokens=None,
                            completion_tokens=5,
                            total_tokens=15,
                        ),
                    )

            token_cost = TokenCost(include_cost=False)
            llm_levels = {"LOW": DummyLLM()}

            def fake_get(url, timeout, impersonate, headers=None):
                return SimpleNamespace(status_code=200, url=url, text="<h1>Hello</h1>", headers=SimpleNamespace())

            with bind_system_tool_context(
                project_root=root,
                session_id="s1",
                session_root=root / "sessions" / "s1",
                token_cost=token_cost,
                llm_levels=llm_levels,
                subagent_name="researcher",
            ):
                with mock.patch.dict("sys.modules", {"curl_cffi": SimpleNamespace(requests=SimpleNamespace(get=fake_get))}):
                    with mock.patch.dict("sys.modules", {"markdownify": SimpleNamespace(markdownify=lambda html: "# Hello")}):
                        out = self._run_raw(WebFetch, url="https://example.com", prompt="Summarize")
                        self.assertTrue(out["ok"])
                        self.assertEqual(len(token_cost.usage_history), 1)
                        self.assertEqual(token_cost.usage_history[0].source, "subagent:researcher:webfetch")

    def test_webfetch_records_subagent_run_prefixed_source(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)

            class DummyLLM:
                model = "dummy-low"

                @property
                def provider(self) -> str:
                    return "dummy"

                @property
                def name(self) -> str:
                    return self.model

                async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
                    return ChatInvokeCompletion(
                        content="answer",
                        usage=ChatInvokeUsage(
                            prompt_tokens=8,
                            prompt_cached_tokens=None,
                            prompt_cache_creation_tokens=None,
                            prompt_image_tokens=None,
                            completion_tokens=4,
                            total_tokens=12,
                        ),
                    )

            token_cost = TokenCost(include_cost=False)
            llm_levels = {"LOW": DummyLLM()}

            def fake_get(url, timeout, impersonate, headers=None):
                return SimpleNamespace(status_code=200, url=url, text="<h1>Hello</h1>", headers=SimpleNamespace())

            with bind_system_tool_context(
                project_root=root,
                session_id="s1",
                session_root=root / "sessions" / "s1",
                token_cost=token_cost,
                llm_levels=llm_levels,
                subagent_name="researcher",
                subagent_source_prefix="subagent:researcher:tc_42",
            ):
                with mock.patch.dict("sys.modules", {"curl_cffi": SimpleNamespace(requests=SimpleNamespace(get=fake_get))}):
                    with mock.patch.dict("sys.modules", {"markdownify": SimpleNamespace(markdownify=lambda html: "# Hello")}):
                        out = self._run_raw(WebFetch, url="https://example.com", prompt="Summarize")
                        self.assertTrue(out["ok"])
                        self.assertEqual(len(token_cost.usage_history), 1)
                        self.assertEqual(
                            token_cost.usage_history[0].source,
                            "subagent:researcher:tc_42:webfetch",
                        )

    def test_read_long_line_early_return_includes_file_bytes(self) -> None:
        """P0-1: Verify that file_bytes is defined in early return path for super-long lines."""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "huge_line.txt"
            # Create a line that exceeds _READ_HARD_LINE_LIMIT (50KB)
            p.write_text("x" * 60_000, encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path=str(p))
                self.assertFalse(out["ok"])
                self.assertEqual(out["error"]["code"], "OUTPUT_TOO_LARGE")
                # Verify file_bytes is present in meta
                self.assertIn("file_bytes", out["meta"])
                self.assertGreater(out["meta"]["file_bytes"], 0)
                self.assertEqual(out["meta"]["problem_line"], 1)

    def test_edit_detects_external_modification(self) -> None:
        """P1-6: Verify that Edit detects external file modifications and returns CONFLICT."""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "foo.py"
            p.write_text("original_content\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root, session_root=root / "sessions" / "s1"):
                # Step 1: Read the file (records version)
                out1 = self._run(Read, file_path=str(p))
                self.assertTrue(out1["ok"])

                # Step 2: External modification (simulating git pull / other editor)
                p.write_text("externally_modified_content\n", encoding="utf-8")

                # Step 3: Try to Edit (should detect conflict)
                out2 = self._run(
                    Edit,
                    file_path=str(p),
                    old_string="original_content",
                    new_string="my_edit",
                )
                self.assertFalse(out2["ok"])
                self.assertEqual(out2["error"]["code"], "CONFLICT")
                self.assertIn("modified externally", out2["error"]["message"])

                # Step 4: Re-read to accept external changes
                out3 = self._run(Read, file_path=str(p))
                self.assertTrue(out3["ok"])

                # Step 5: Now Edit should succeed
                out4 = self._run(
                    Edit,
                    file_path=str(p),
                    old_string="externally_modified_content",
                    new_string="my_edit_after_reread",
                )
                self.assertTrue(out4["ok"])

    def test_relative_path_resolves_to_project_root(self) -> None:
        """Relative paths for new files must resolve under project_root, not extra_write_roots."""
        with tempfile.TemporaryDirectory() as td:
            root = (Path(td) / "project").resolve()
            root.mkdir(parents=True, exist_ok=True)
            memory_root = (Path(td) / "sessions" / "memory").resolve()
            memory_root.mkdir(parents=True, exist_ok=True)

            with bind_system_tool_context(
                project_root=root,
                extra_write_roots=(memory_root,),
            ):
                out = self._run(Write, file_path="src/new_file.py", content="print('hello')\n")

            self.assertTrue(out["ok"])
            expected = root / "src" / "new_file.py"
            self.assertTrue(expected.exists())
            self.assertEqual(expected.read_text(encoding="utf-8"), "print('hello')\n")
            # Must NOT leak to memory_root
            self.assertFalse((memory_root / "src" / "new_file.py").exists())

    def test_relative_path_does_not_leak_to_extra_write_roots(self) -> None:
        """Even a single-segment relative path (e.g. 'report.md') must go to project_root."""
        with tempfile.TemporaryDirectory() as td:
            root = (Path(td) / "project").resolve()
            root.mkdir(parents=True, exist_ok=True)
            extra_dir = (Path(td) / "extra").resolve()
            extra_dir.mkdir(parents=True, exist_ok=True)

            with bind_system_tool_context(
                project_root=root,
                extra_write_roots=(extra_dir,),
            ):
                out = self._run(Write, file_path="report.md", content="content\n")

            self.assertTrue(out["ok"])
            self.assertTrue((root / "report.md").exists())
            self.assertFalse((extra_dir / "report.md").exists())

    def test_absolute_path_matches_extra_write_root(self) -> None:
        """Absolute path under an extra_write_root should resolve correctly."""
        with tempfile.TemporaryDirectory() as td:
            root = (Path(td) / "project").resolve()
            root.mkdir(parents=True, exist_ok=True)
            extra_dir = (Path(td) / "extra_output").resolve()
            extra_dir.mkdir(parents=True, exist_ok=True)
            target = extra_dir / "result.txt"

            with bind_system_tool_context(
                project_root=root,
                extra_write_roots=(extra_dir,),
            ):
                out = self._run(Write, file_path=str(target), content="output\n")

            self.assertTrue(out["ok"])
            self.assertTrue(target.exists())
            self.assertEqual(target.read_text(encoding="utf-8"), "output\n")

    def test_absolute_path_outside_all_roots_rejected(self) -> None:
        """Absolute path not under any known root must be rejected."""
        with tempfile.TemporaryDirectory() as td:
            root = (Path(td) / "project").resolve()
            root.mkdir(parents=True, exist_ok=True)
            bad_target = Path(td) / "unrelated" / "file.txt"

            with bind_system_tool_context(project_root=root):
                out = self._run(Write, file_path=str(bad_target), content="nope\n")

            self.assertFalse(out["ok"])
            self.assertIn(out["error"]["code"], {"PATH_ESCAPE", "PERMISSION_DENIED"})

    def test_tilde_path_routes_through_absolute_stage(self) -> None:
        """Tilde paths expand to absolute and route through Stage 2."""
        with tempfile.TemporaryDirectory() as td:
            root = (Path(td) / "project").resolve()
            root.mkdir(parents=True, exist_ok=True)
            plans_root = (Path(td) / ".agent" / "plans").resolve()
            plans_root.mkdir(parents=True, exist_ok=True)

            with mock.patch.dict("os.environ", {"HOME": td}, clear=False):
                with bind_system_tool_context(
                    project_root=root,
                    extra_write_roots=(plans_root,),
                ):
                    out = self._run(
                        Write,
                        file_path="~/.agent/plans/my-plan.md",
                        content="plan content\n",
                    )

            self.assertTrue(out["ok"])
            self.assertTrue((plans_root / "my-plan.md").exists())

    def test_config_add_dirs_only_match_absolute_path(self) -> None:
        """config_add_dirs in extra_write_roots must not capture relative paths."""
        with tempfile.TemporaryDirectory() as td:
            root = (Path(td) / "project").resolve()
            root.mkdir(parents=True, exist_ok=True)
            config_dir = (Path(td) / "data" / "outputs").resolve()
            config_dir.mkdir(parents=True, exist_ok=True)

            with bind_system_tool_context(
                project_root=root,
                extra_write_roots=(config_dir,),
            ):
                out = self._run(Write, file_path="notes.txt", content="note\n")

            self.assertTrue(out["ok"])
            # Must go to project_root, NOT config_dir
            self.assertTrue((root / "notes.txt").exists())
            self.assertFalse((config_dir / "notes.txt").exists())

    def test_edit_relative_path_resolves_to_project_root(self) -> None:
        """Edit with relative path must also resolve to project_root, not extra_write_roots."""
        with tempfile.TemporaryDirectory() as td:
            root = (Path(td) / "project").resolve()
            root.mkdir(parents=True, exist_ok=True)
            target = root / "existing.py"
            target.write_text("old_value = 1\n", encoding="utf-8")
            extra_dir = (Path(td) / "extra").resolve()
            extra_dir.mkdir(parents=True, exist_ok=True)

            with bind_system_tool_context(
                project_root=root,
                extra_write_roots=(extra_dir,),
            ):
                self.assertTrue(self._run(Read, file_path=str(target))["ok"])
                out = self._run(
                    Edit,
                    file_path="existing.py",
                    old_string="old_value = 1",
                    new_string="new_value = 2",
                )

            self.assertTrue(out["ok"])
            self.assertEqual(target.read_text(encoding="utf-8"), "new_value = 2\n")
            self.assertFalse((extra_dir / "existing.py").exists())

    def test_absolute_path_under_project_root_writable(self) -> None:
        """Absolute path directly under project_root should be writable."""
        with tempfile.TemporaryDirectory() as td:
            root = (Path(td) / "project").resolve()
            root.mkdir(parents=True, exist_ok=True)
            target = root / "new_file.txt"

            with bind_system_tool_context(project_root=root):
                out = self._run(Write, file_path=str(target), content="hello\n")

            self.assertTrue(out["ok"])
            self.assertTrue(target.exists())
            self.assertEqual(target.read_text(encoding="utf-8"), "hello\n")

    def test_session_root_not_writable_via_system_tool(self) -> None:
        """Writing to session_root via absolute path must be rejected when session_root
        is not in extra_write_roots (production config)."""
        with tempfile.TemporaryDirectory() as td:
            root = (Path(td) / "project").resolve()
            root.mkdir(parents=True, exist_ok=True)
            session_root = (Path(td) / "sessions" / "s1").resolve()
            session_root.mkdir(parents=True, exist_ok=True)
            memory_root = (session_root.parent / "memory").resolve()
            memory_root.mkdir(parents=True, exist_ok=True)
            target = session_root / "should_not_exist.txt"

            with bind_system_tool_context(
                project_root=root,
                session_id="s1",
                session_root=session_root,
                extra_write_roots=(memory_root,),  # no session_root
            ):
                out = self._run(Write, file_path=str(target), content="nope\n")

            self.assertFalse(out["ok"])
            self.assertIn(out["error"]["code"], {"PATH_ESCAPE", "PERMISSION_DENIED"})
            self.assertFalse(target.exists())

    def test_read_returns_resolved_file_path_in_meta(self) -> None:
        """Read should include resolved_file_path (absolute) in meta alongside file_path (original input)."""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            test_file = root / "resolve_test.txt"
            test_file.write_text("hello world\n", encoding="utf-8")

            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path="resolve_test.txt")
                self.assertTrue(out["ok"])
                self.assertEqual(out["meta"]["file_path"], "resolve_test.txt")
                self.assertEqual(out["meta"]["resolved_file_path"], str(test_file.resolve()))
                self.assertTrue(Path(out["meta"]["resolved_file_path"]).is_absolute())

    @staticmethod
    def _run(tool_obj, /, **kwargs):
        raw = asyncio.run(tool_obj.execute(**kwargs))
        if isinstance(raw, str) and raw.strip().startswith(("{", "[")):
            return json.loads(raw)
        return raw

    @staticmethod
    def _run_raw(tool_obj, /, **kwargs):
        return TestSystemTools._run(tool_obj, **kwargs)

    def test_read_hard_line_limit_returns_output_too_large(self) -> None:
        from comate_agent_sdk.system_tools.tools import _READ_HARD_LINE_LIMIT

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "huge_line.txt"
            p.write_text("A" * (_READ_HARD_LINE_LIMIT + 1024) + "\n", encoding="utf-8")
            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path=str(p))
        self.assertFalse(out["ok"])
        self.assertEqual(out["error"]["code"], "OUTPUT_TOO_LARGE")
        self.assertEqual(out["meta"]["problem_line"], 1)

    def test_read_hard_line_limit_uses_utf8_bytes_for_unicode(self) -> None:
        from comate_agent_sdk.system_tools.tools import _READ_HARD_LINE_LIMIT

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "unicode.txt"
            char_width = len("你".encode("utf-8"))
            oversized_line = "你" * ((_READ_HARD_LINE_LIMIT // char_width) + 32)
            p.write_text(oversized_line + "\n", encoding="utf-8")
            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path=str(p))
        self.assertFalse(out["ok"])
        self.assertEqual(out["error"]["code"], "OUTPUT_TOO_LARGE")
        self.assertGreater(out["meta"]["line_size_bytes"], _READ_HARD_LINE_LIMIT)
        self.assertEqual(out["meta"]["problem_line"], 1)

    def test_read_hard_line_limit_extract_command_shell_quotes_resolved_path(self) -> None:
        from comate_agent_sdk.system_tools.tools import _READ_HARD_LINE_LIMIT

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "space 'quote'.txt"
            p.write_text("A" * (_READ_HARD_LINE_LIMIT + 1024) + "\n", encoding="utf-8")
            with bind_system_tool_context(project_root=root):
                out = self._run(Read, file_path=str(p))
        self.assertFalse(out["ok"])
        self.assertEqual(out["error"]["code"], "OUTPUT_TOO_LARGE")
        self.assertIn(shlex.quote(str(p.resolve())), out["meta"]["extract_command"])
        self.assertNotIn(f"sed -n '1p' {p}", out["meta"]["extract_command"])

    def test_bash_timeout_returns_partial_output_in_data(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with bind_system_tool_context(project_root=root):
                out = self._run(
                    Bash,
                    command="python3 -c \"import time; print('start'); time.sleep(10)\"",
                    timeout_ms=500,
                )
        self.assertFalse(out["ok"])
        self.assertEqual(out["error"]["code"], "TIMEOUT")
        self.assertIn("stdout", out["data"])
        self.assertIn("timed_out", out["data"])
        self.assertNotIn("stdout", out["meta"])

    def test_bash_returns_bash_not_available_when_discovery_fails(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)

            with bind_system_tool_context(project_root=root):
                with mock.patch.object(system_tools_module, "_validate_bash_command", return_value=None), mock.patch.object(
                    system_tools_module,
                    "_build_bash_command",
                    side_effect=FileNotFoundError("bash not found"),
                ):
                    out = self._run(Bash, command="pwd")

        self.assertFalse(out["ok"])
        self.assertEqual(out["error"]["code"], "BASH_NOT_AVAILABLE")


if __name__ == "__main__":
    unittest.main()
