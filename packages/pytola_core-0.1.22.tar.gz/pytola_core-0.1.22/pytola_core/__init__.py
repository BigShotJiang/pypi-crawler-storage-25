"""Pytola Core - Essential utilities and components for Pytola applications.

This package provides core functionality including:
- Advanced logging system with colored output
- High DPI scaling support for Qt applications
- Security utilities for input validation
- Theme management system
- Environment configuration helpers
- Generic registry system for component management
- Finite state machine for state management.
- High-performance thread-safe SQLite database management.
"""

from pytola_core.logger import get_logger, logger
from pytola_core.patterns.statemachine import (
    InvalidTransitionError,
    StateConfig,
    StateMachine,
    StateMachineError,
    StateNotFoundError,
)
from pytola_core.persistance import DatabaseConnectionPool, DatabaseError, DatabaseManager, PoolConfig, TransactionError

__version__ = "0.1.22"


__all__ = [
    # Database
    "DatabaseConnectionPool",
    "DatabaseError",
    "DatabaseManager",
    # State machine
    "InvalidTransitionError",
    "PoolConfig",
    "StateConfig",
    "StateMachine",
    "StateMachineError",
    "StateNotFoundError",
    "TransactionError",
    # Logger
    "get_logger",
    "logger",
]
