# SPDX-FileCopyrightText: 2026 Phil
# SPDX-License-Identifier: Apache-2.0

"""parse_nvd package."""

from importlib import metadata

try:
    from ._version import version as __version__
except ImportError:
    try:
        __version__ = metadata.version("parse-nvd")
    except metadata.PackageNotFoundError:
        __version__ = "0+unknown"

__all__ = ["__version__"]
