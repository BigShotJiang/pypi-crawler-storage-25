# SPDX-FileCopyrightText: 2026 Phil
# SPDX-License-Identifier: Apache-2.0

"""Core report generation logic for parse_nvd."""

import json
import re
from datetime import date
from dataclasses import dataclass
from functools import lru_cache
from importlib.resources import files
from pathlib import Path
from typing import Any

import jsonschema
import semver

TRAILING_COMMA_RE = re.compile(r",(\s*[}\]])")
NAME_RE = re.compile(r"[^a-z0-9]+")
IDENTIFIER_RE = re.compile(r"[^A-Za-z0-9]+")
TOKEN_RE = re.compile(r"\d+|[A-Za-z]+")
LINUX_SYSTEM_RE = re.compile(
    r"^In the Linux kernel, the following vulnerability has been resolved:\s*([A-Za-z0-9_-]+)(?:/[A-Za-z0-9_-]+)*:",
    re.IGNORECASE,
)

ATTACK_VECTOR_ORDER = {
    "NETWORK": 4,
    "ADJACENT": 3,
    "ADJACENT_NETWORK": 3,
    "LOCAL": 2,
    "PHYSICAL": 1,
}

IMPACT_ORDER = {
    "NONE": 0,
    "LOW": 1,
    "PARTIAL": 1,
    "HIGH": 2,
    "COMPLETE": 2,
}

ATTACK_VECTOR_ALIASES = {
    "N": "NETWORK",
    "A": "ADJACENT",
    "AN": "ADJACENT",
    "ADJACENT_NETWORK": "ADJACENT",
    "L": "LOCAL",
    "P": "PHYSICAL",
}

IMPACT_ALIASES = {
    "N": "NONE",
    "LOW": "LOW",
    "L": "LOW",
    "PARTIAL": "LOW",
    "P": "LOW",
    "H": "HIGH",
    "HIGH": "HIGH",
    "C": "HIGH",
    "COMPLETE": "HIGH",
}

METRIC_FIELDS = {
    "cvssMetricV40": ("4.0", "attackVector", "vulnConfidentialityImpact", "vulnIntegrityImpact", "vulnAvailabilityImpact"),
    "cvssMetricV31": ("3.1", "attackVector", "confidentialityImpact", "integrityImpact", "availabilityImpact"),
    "cvssMetricV30": ("3.0", "attackVector", "confidentialityImpact", "integrityImpact", "availabilityImpact"),
    "cvssMetricV2": ("2.0", "accessVector", "confidentialityImpact", "integrityImpact", "availabilityImpact"),
}


@dataclass(frozen=True)
class CotsEntry:
    """Represent one COTS entry from the inventory input."""

    name: str
    version: str

    @property
    def key(self) -> str:
        """Return a stable key combining name and version.

        Returns:
            Canonical key in the ``name@version`` format.
        """
        return f"{self.name}@{self.version}"


def build_report(
    *,
    nvd_paths: list[Path],
    cots_path: Path,
    output_path: Path,
    cvss_min: float | None,
    cvss_av: str | None,
    impact_c: str | None,
    impact_i: str | None,
    impact_d: str | None,
    with_exploit: bool,
    created_or_updated_after: date | None,
    linux_order_by_system: bool,
    console: Any,
    verbose: bool,
) -> dict[str, Any]:
    """Build the report and write it to the JSON output file.

    Args:
        nvd_paths: One or more NVD JSON documents to process.
        cots_path: Path to the COTS inventory file.
        output_path: Path where the JSON report is written.
        cvss_min: Optional minimum CVSS base score filter.
        cvss_av: Optional minimum attack-vector filter.
        impact_c: Optional minimum confidentiality-impact filter.
        impact_i: Optional minimum integrity-impact filter.
        impact_d: Optional minimum availability-impact filter.
        with_exploit: Whether to keep only CVEs with exploit hints.
        created_or_updated_after: Keep CVEs whose published date or
            last-modified date is strictly after this date.
        linux_order_by_system: Whether linux kernel CVEs should be ordered by
            extracted impacted system.
        console: Console-like object exposing a ``print`` method.
        verbose: Whether to emit progress logs while processing.

    Returns:
        The generated report dictionary.
    """
    cots_entries = load_cots_entries(cots_path)
    schema_validator = load_nvd_schema_validator()
    report_items = [
        {"name": entry.name, "version": entry.version, "cves": []}
        for entry in cots_entries
    ]
    report_index = {entry.key: item for entry, item in zip(cots_entries, report_items, strict=True)}

    filters = {
        "cvss_min": cvss_min,
        "cvss_av": normalize_attack_vector(cvss_av),
        "impact_c": normalize_impact(impact_c),
        "impact_i": normalize_impact(impact_i),
        "impact_d": normalize_impact(impact_d),
        "with_exploit": True if with_exploit else None,
        "created_or_updated_after": (
            created_or_updated_after.isoformat() if created_or_updated_after is not None else None
        ),
        "linux_order_by_system": True if linux_order_by_system else None,
    }

    matched_cve_ids: set[str] = set()
    total_vulnerabilities = 0
    nvd_timestamps: dict[str, str | None] = {}

    for nvd_path in nvd_paths:
        if verbose:
            console.print(f"Loading NVD file {nvd_path}")
        document = load_json_file(nvd_path)
        validate_nvd_document(document, nvd_path, schema_validator)
        nvd_timestamps[str(nvd_path)] = document.get("timestamp")
        vulnerabilities = document.get("vulnerabilities", [])
        total_vulnerabilities += len(vulnerabilities)
        if verbose:
            console.print(f"  {len(vulnerabilities)} vulnerabilities found")

        for vulnerability in vulnerabilities:
            cve_block = vulnerability.get("cve", {})
            cve_id = cve_block.get("id")
            if not cve_id:
                continue

            metric = select_cvss_metric(cve_block.get("metrics", {}))
            if not metric_passes(metric, filters):
                continue

            if not cve_date_passes(cve_block, created_or_updated_after):
                continue

            exploit_available = cve_has_exploit(cve_block)
            if with_exploit and not exploit_available:
                continue

            matches_by_cot = evaluate_vulnerability(vulnerability, cve_block, cots_entries)
            if not matches_by_cot:
                continue

            matched_cve_ids.add(cve_id)
            for cot_key, criteria_matches in matches_by_cot.items():
                cve_entry = {
                    "cve": cve_block,
                    "cvss": metric,
                    "exploit_available": exploit_available,
                    "source_file": str(nvd_path),
                    "matching_criteria": deduplicate_criteria(criteria_matches),
                }
                report_index[cot_key]["cves"].append(cve_entry)

    for item in report_items:
        if linux_order_by_system and item["name"] == "linux_kernel":
            item["cves"].sort(
                key=lambda entry: (
                    extract_linux_system(entry["cve"]).upper(),
                    -entry["cvss"]["base_score"],
                    entry["cve"]["id"],
                )
            )
            continue
        item["cves"].sort(key=lambda entry: (-entry["cvss"]["base_score"], entry["cve"]["id"]))

    report = {
        "summary": {
            "nvd_files": [str(path) for path in nvd_paths],
            "nvd_sources": [
                {"file": str(path), "timestamp": nvd_timestamps.get(str(path))}
                for path in nvd_paths
            ],
            "cots_file": str(cots_path),
            "total_cots": len(cots_entries),
            "matched_cots": sum(1 for item in report_items if item["cves"]),
            "matched_cves": len(matched_cve_ids),
            "total_vulnerabilities_processed": total_vulnerabilities,
            "filters": {
                key: value
                for key, value in filters.items()
                if value is not None
            },
        },
        "cots": report_items,
    }

    output_path.write_text(json.dumps(report, indent=2, sort_keys=False), encoding="utf-8")
    return report


def load_cots_entries(path: Path) -> list[CotsEntry]:
    """Load and validate the COTS inventory file.

    Args:
        path: Path to the COTS JSON file.

    Returns:
        Parsed list of ``CotsEntry`` values.

    Raises:
        ValueError: If the input shape is invalid.
    """
    data = load_json_file(path, allow_trailing_commas=True)
    if not isinstance(data, list):
        raise ValueError("The COTS file must contain a JSON array.")

    entries: list[CotsEntry] = []
    for index, item in enumerate(data, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"COTS entry #{index} must be an object.")
        name = item.get("name")
        version = item.get("version")
        if not name or not version:
            raise ValueError(f"COTS entry #{index} must define both name and version.")
        entries.append(CotsEntry(name=str(name), version=str(version)))
    return entries


def load_json_file(path: Path, allow_trailing_commas: bool = False) -> Any:
    """Load a JSON file from disk.

    Args:
        path: Path of the JSON document to read.
        allow_trailing_commas: Whether to normalize trailing commas first.

    Returns:
        Parsed JSON value.
    """
    text = path.read_text(encoding="utf-8")
    if allow_trailing_commas:
        text = TRAILING_COMMA_RE.sub(r"\1", text)
    return json.loads(text)


def validate_nvd_document(document: Any, path: Path, validator: jsonschema.protocols.Validator) -> None:
    """Validate one NVD document against the bundled schema.

    Args:
        document: Parsed JSON document to validate.
        path: Source path used for user-facing error messages.
        validator: Prepared JSON Schema validator instance.

    Raises:
        ValueError: If the document does not conform to schema.
    """
    errors = sorted(validator.iter_errors(document), key=lambda err: list(err.path))
    if not errors:
        return

    first = errors[0]
    location = " -> ".join(str(part) for part in first.path) or "<root>"
    raise ValueError(f"NVD file {path} does not conform to schema at {location}: {first.message}")


@lru_cache(maxsize=1)
def load_nvd_schema_validator() -> jsonschema.protocols.Validator:
    """Load and cache the NVD JSON Schema validator.

    Returns:
        Validator configured for the bundled NVD schema.

    Raises:
        FileNotFoundError: If the packaged schema resource cannot be located.
    """
    schema_resource = files("parse_nvd").joinpath("data", "cve_api_json_2.0.schema")
    if not schema_resource.is_file():
        raise FileNotFoundError(
            "Unable to locate packaged schema parse_nvd/data/cve_api_json_2.0.schema"
        )

    schema = json.loads(schema_resource.read_text(encoding="utf-8"))
    schema = replace_external_refs(schema)
    validator_cls = jsonschema.validators.validator_for(schema)
    validator_cls.check_schema(schema)
    return validator_cls(schema)


def replace_external_refs(node: Any) -> Any:
    """Replace external schema references with permissive objects.

    The official NVD schema references remote CVSS sub-schemas. This helper
    keeps local validation strict while avoiding network fetches at runtime.

    Args:
        node: Arbitrary JSON-like structure from the schema.

    Returns:
        A deep-copied structure with external ``$ref`` values replaced.
    """
    if isinstance(node, dict):
        ref_value = node.get("$ref")
        if isinstance(ref_value, str) and ref_value.startswith(("http://", "https://")):
            return {"type": "object"}
        return {key: replace_external_refs(value) for key, value in node.items()}
    if isinstance(node, list):
        return [replace_external_refs(item) for item in node]
    return node


def evaluate_vulnerability(
    vulnerability: dict[str, Any],
    cve_block: dict[str, Any],
    cots_entries: list[CotsEntry],
) -> dict[str, list[dict[str, Any]]]:
    """Evaluate one vulnerability against all COTS entries.

    Args:
        vulnerability: Full vulnerability item from the NVD list.
        cve_block: Nested ``cve`` block from the vulnerability item.
        cots_entries: COTS inventory to test.

    Returns:
        Mapping from COTS key to matched CPE criteria blocks.
    """
    matches_by_cot: dict[str, list[dict[str, Any]]] = {}
    configurations = cve_block.get("configurations") or vulnerability.get("configurations", [])
    for configuration in configurations:
        applies, config_matches = evaluate_node(configuration, cots_entries)
        if not applies:
            continue
        for cot_key, match_items in config_matches.items():
            matches_by_cot.setdefault(cot_key, []).extend(match_items)
    return matches_by_cot


def evaluate_node(node: dict[str, Any], cots_entries: list[CotsEntry]) -> tuple[bool, dict[str, list[dict[str, Any]]]]:
    """Evaluate one configuration node against the COTS inventory.

    Args:
        node: Configuration node from NVD ``configurations``.
        cots_entries: COTS inventory to test.

    Returns:
        Tuple of ``(applies, matches)`` where ``matches`` maps COTS keys to
        their matching criteria blocks.
    """
    operator = str(node.get("operator", "OR")).upper()
    components: list[tuple[bool, dict[str, list[dict[str, Any]]]]] = []

    for cpe_match in node.get("cpeMatch", []):
        components.append(evaluate_cpe_match(cpe_match, cots_entries))

    for child in node.get("nodes", []):
        components.append(evaluate_node(child, cots_entries))

    if not components:
        return False, {}

    if operator == "AND":
        applies = all(result for result, _ in components)
        matched = merge_match_maps(match_map for result, match_map in components if result) if applies else {}
    else:
        successful = [match_map for result, match_map in components if result]
        applies = bool(successful)
        matched = merge_match_maps(successful)

    if node.get("negate"):
        return (not applies), {}

    return applies, matched


def evaluate_cpe_match(cpe_match: dict[str, Any], cots_entries: list[CotsEntry]) -> tuple[bool, dict[str, list[dict[str, Any]]]]:
    """Evaluate one CPE match block against all COTS entries.

    Args:
        cpe_match: One CPE matching block from NVD data.
        cots_entries: COTS inventory to test.

    Returns:
        Tuple of ``(matched, matches_map)``.
    """
    if not cpe_match.get("vulnerable", False):
        return False, {}

    criteria = str(cpe_match.get("criteria", ""))
    cpe_parts = parse_cpe(criteria)
    if cpe_parts is None:
        return False, {}

    matches: dict[str, list[dict[str, Any]]] = {}
    for entry in cots_entries:
        if not cots_matches_cpe(entry, cpe_parts):
            continue
        if not version_matches(entry.version, cpe_parts, cpe_match):
            continue
        matches[entry.key] = [
            {
                "criteria": criteria,
                "match_criteria_id": cpe_match.get("matchCriteriaId"),
                "part": cpe_parts["part"],
                "vendor": cpe_parts["vendor"],
                "product": cpe_parts["product"],
                "version": cpe_parts["version"],
                "versionStartIncluding": cpe_match.get("versionStartIncluding"),
                "versionStartExcluding": cpe_match.get("versionStartExcluding"),
                "versionEndIncluding": cpe_match.get("versionEndIncluding"),
                "versionEndExcluding": cpe_match.get("versionEndExcluding"),
            }
        ]
    return bool(matches), matches


def parse_cpe(criteria: str) -> dict[str, str] | None:
    """Parse the CPE 2.3 fields needed for matching.

    Args:
        criteria: CPE criteria string.

    Returns:
        Dictionary with parsed CPE fields, or ``None`` when invalid.
    """
    parts = criteria.split(":")
    if len(parts) < 6 or parts[0] != "cpe" or parts[1] != "2.3":
        return None
    return {
        "part": parts[2],
        "vendor": parts[3],
        "product": parts[4],
        "version": parts[5],
    }


def normalize_name(value: str) -> str:
    """Normalize product and vendor names for tolerant matching.

    Args:
        value: Raw vendor or product value.

    Returns:
        Lowercase normalized token string.
    """
    return NAME_RE.sub("_", value.strip().lower()).strip("_")


def cots_matches_cpe(entry: CotsEntry, cpe_parts: dict[str, str]) -> bool:
    """Check whether one COTS entry maps to a CPE identity.

    Args:
        entry: COTS entry under evaluation.
        cpe_parts: Parsed CPE components.

    Returns:
        ``True`` when names are considered compatible.
    """
    entry_name = normalize_name(entry.name)
    vendor = normalize_name(cpe_parts["vendor"])
    product = normalize_name(cpe_parts["product"])
    candidates = {
        vendor,
        product,
        normalize_name(f"{vendor}_{product}"),
        normalize_name(f"{vendor}-{product}"),
    }
    return entry_name in candidates


def version_matches(version: str, cpe_parts: dict[str, str], cpe_match: dict[str, Any]) -> bool:
    """Check whether a COTS version is in a vulnerable CPE range.

    Args:
        version: COTS version string.
        cpe_parts: Parsed CPE fields.
        cpe_match: CPE match block containing version constraints.

    Returns:
        ``True`` when the version falls inside the vulnerable range.
    """
    version = version.strip()
    criteria_version = cpe_parts["version"]

    if criteria_version not in {"*", "-"} and compare_versions(version, criteria_version) != 0:
        return False

    lower_including = cpe_match.get("versionStartIncluding")
    if lower_including and compare_versions(version, str(lower_including)) < 0:
        return False

    lower_excluding = cpe_match.get("versionStartExcluding")
    if lower_excluding and compare_versions(version, str(lower_excluding)) <= 0:
        return False

    upper_including = cpe_match.get("versionEndIncluding")
    if upper_including and compare_versions(version, str(upper_including)) > 0:
        return False

    upper_excluding = cpe_match.get("versionEndExcluding")
    if upper_excluding and compare_versions(version, str(upper_excluding)) >= 0:
        return False

    return True


def compare_versions(left: str, right: str) -> int:
    """Compare two version strings.

    SemVer comparison is attempted first, with token-based fallback.

    Args:
        left: Left version string.
        right: Right version string.

    Returns:
        ``-1`` if left < right, ``0`` if equal, ``1`` if left > right.
    """
    left_semver = coerce_semver(left)
    right_semver = coerce_semver(right)
    if left_semver is not None and right_semver is not None:
        if left_semver < right_semver:
            return -1
        if left_semver > right_semver:
            return 1
        return 0

    left_tokens = tokenize_version(left)
    right_tokens = tokenize_version(right)
    for left_token, right_token in zip(left_tokens, right_tokens):
        if left_token == right_token:
            continue
        if isinstance(left_token, int) and isinstance(right_token, int):
            return -1 if left_token < right_token else 1
        return -1 if str(left_token) < str(right_token) else 1

    if len(left_tokens) == len(right_tokens):
        return 0
    return -1 if len(left_tokens) < len(right_tokens) else 1


def coerce_semver(value: str) -> semver.Version | None:
    """Convert a non-strict version string to a SemVer object.

    Args:
        value: Version text to coerce.

    Returns:
        Parsed ``semver.Version`` or ``None`` when coercion fails.
    """
    cleaned = value.strip().replace("_", ".")
    match = re.fullmatch(r"v?(\d+(?:\.\d+){0,2})(?:[-+]([0-9A-Za-z.-]+))?", cleaned)
    if not match:
        return None

    core = match.group(1).split(".")
    while len(core) < 3:
        core.append("0")

    version_text = ".".join(core[:3])
    suffix = match.group(2)
    if suffix:
        version_text = f"{version_text}-{suffix}"

    try:
        return semver.Version.parse(version_text)
    except ValueError:
        return None


def tokenize_version(value: str) -> list[int | str]:
    """Tokenize a version string for fallback comparisons.

    Args:
        value: Version text to tokenize.

    Returns:
        Ordered token list containing integers and lowercase strings.
    """
    tokens: list[int | str] = []
    for token in TOKEN_RE.findall(value):
        tokens.append(int(token) if token.isdigit() else token.lower())
    return tokens


def select_cvss_metric(metrics: dict[str, Any]) -> dict[str, Any]:
    """Select the best available CVSS metric across supported versions.

    Args:
        metrics: Raw NVD metrics block.

    Returns:
        Normalized metric dictionary used by downstream filters.
    """
    for key, (version, attack_vector_field, conf_field, integ_field, avail_field) in METRIC_FIELDS.items():
        entries = metrics.get(key) or []
        if not entries:
            continue
        preferred = next((entry for entry in entries if entry.get("type") == "Primary"), entries[0])
        data = preferred.get("cvssData", {})
        return {
            "version": version,
            "base_score": float(data.get("baseScore", 0.0)),
            "base_severity": data.get("baseSeverity") or preferred.get("baseSeverity"),
            "attack_vector": normalize_attack_vector(data.get(attack_vector_field)),
            "impact_confidentiality": normalize_impact(data.get(conf_field)),
            "impact_integrity": normalize_impact(data.get(integ_field)),
            "impact_availability": normalize_impact(data.get(avail_field)),
            "vector_string": data.get("vectorString"),
        }
    return {
        "version": None,
        "base_score": 0.0,
        "base_severity": None,
        "attack_vector": None,
        "impact_confidentiality": None,
        "impact_integrity": None,
        "impact_availability": None,
        "vector_string": None,
    }


def metric_passes(metric: dict[str, Any], filters: dict[str, Any]) -> bool:
    """Apply user-supplied CVSS filters to one metric.

    Args:
        metric: Normalized CVSS metric dictionary.
        filters: Normalized filter dictionary.

    Returns:
        ``True`` when the metric satisfies all configured filters.
    """
    if filters["cvss_min"] is not None and metric["base_score"] < filters["cvss_min"]:
        return False

    if filters["cvss_av"] is not None:
        current = metric["attack_vector"]
        if current is None or ATTACK_VECTOR_ORDER.get(current, -1) < ATTACK_VECTOR_ORDER[filters["cvss_av"]]:
            return False

    impact_checks = [
        ("impact_c", metric["impact_confidentiality"]),
        ("impact_i", metric["impact_integrity"]),
        ("impact_d", metric["impact_availability"]),
    ]
    for filter_key, current in impact_checks:
        required = filters[filter_key]
        if required is None:
            continue
        if current is None or IMPACT_ORDER.get(current, -1) < IMPACT_ORDER[required]:
            return False
    return True


def normalize_attack_vector(value: str | None) -> str | None:
    """Normalize attack-vector values from CLI and NVD payloads.

    Args:
        value: Raw attack-vector value.

    Returns:
        Canonical attack-vector value, or ``None``.

    Raises:
        ValueError: If the value is unsupported.
    """
    if value is None:
        return None
    cleaned = IDENTIFIER_RE.sub("_", str(value).strip()).strip("_").upper()
    cleaned = ATTACK_VECTOR_ALIASES.get(cleaned, cleaned)
    if cleaned not in {"NETWORK", "ADJACENT", "LOCAL", "PHYSICAL"}:
        raise ValueError(f"Unsupported attack vector: {value}")
    return cleaned


def normalize_impact(value: str | None) -> str | None:
    """Normalize CVSS impact values from CLI and NVD payloads.

    Args:
        value: Raw impact value.

    Returns:
        Canonical impact value, or ``None``.

    Raises:
        ValueError: If the value is unsupported.
    """
    if value is None:
        return None
    cleaned = IDENTIFIER_RE.sub("_", str(value).strip()).strip("_").upper()
    cleaned = IMPACT_ALIASES.get(cleaned, cleaned)
    if cleaned not in {"NONE", "LOW", "HIGH"}:
        raise ValueError(f"Unsupported impact level: {value}")
    return cleaned


def merge_match_maps(match_maps: Any) -> dict[str, list[dict[str, Any]]]:
    """Merge match maps returned by child node evaluation.

    Args:
        match_maps: Iterable of COTS-to-match mapping dictionaries.

    Returns:
        Single merged mapping containing all matches.
    """
    merged: dict[str, list[dict[str, Any]]] = {}
    for match_map in match_maps:
        for cot_key, matches in match_map.items():
            merged.setdefault(cot_key, []).extend(matches)
    return merged


def deduplicate_criteria(criteria_matches: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Remove duplicate criteria blocks while preserving order.

    Args:
        criteria_matches: Sequence of criteria dictionaries.

    Returns:
        Deduplicated criteria list.
    """
    seen: set[tuple[Any, ...]] = set()
    result: list[dict[str, Any]] = []
    for item in criteria_matches:
        marker = (
            item.get("criteria"),
            item.get("match_criteria_id"),
            item.get("versionStartIncluding"),
            item.get("versionStartExcluding"),
            item.get("versionEndIncluding"),
            item.get("versionEndExcluding"),
        )
        if marker in seen:
            continue
        seen.add(marker)
        result.append(item)
    return result


def cve_has_exploit(cve_block: dict[str, Any]) -> bool:
    """Determine whether a CVE appears to have an exploit reference.

    Args:
        cve_block: NVD CVE payload block.

    Returns:
        ``True`` when exploit hints are found in tags or URLs.
    """
    for ref in cve_block.get("references", []):
        tags = [str(tag).lower() for tag in ref.get("tags", [])]
        url = str(ref.get("url", "")).lower()
        if any("exploit" in tag or "poc" in tag for tag in tags):
            return True
        if "exploit" in url or "poc" in url:
            return True
    return False


def cve_date_passes(cve_block: dict[str, Any], threshold: date | None) -> bool:
    """Check whether a CVE date passes the created/updated-after filter.

    Args:
        cve_block: NVD CVE payload block.
        threshold: Date threshold. When ``None``, no filtering is applied.

    Returns:
        ``True`` when ``published`` or ``lastModified`` is strictly after
        ``threshold``, or when no threshold is configured.
    """
    if threshold is None:
        return True

    published = extract_nvd_date(cve_block.get("published"))
    last_modified = extract_nvd_date(cve_block.get("lastModified"))
    return (
        (published is not None and published > threshold)
        or (last_modified is not None and last_modified > threshold)
    )


def extract_linux_system(cve_block: dict[str, Any]) -> str:
    """Extract the impacted Linux system from the English CVE description.

    Args:
        cve_block: NVD CVE payload block.

    Returns:
        Extracted Linux subsystem name, or ``UNKNOWN`` when the Linux-specific
        prefix is not present.
    """
    descriptions = cve_block.get("descriptions") or []
    english = next((entry for entry in descriptions if entry.get("lang") == "en"), None)
    if english is None:
        return "UNKNOWN"

    text = str(english.get("value", ""))
    match = LINUX_SYSTEM_RE.match(text)
    if match is None:
        return "UNKNOWN"
    system = match.group(1).strip()
    return system or "UNKNOWN"


def extract_nvd_date(value: Any) -> date | None:
    """Parse an NVD timestamp into a date value.

    Args:
        value: Raw timestamp string such as ``YYYY-MM-DDTHH:MM:SS``.

    Returns:
        Parsed date when possible, otherwise ``None``.
    """
    if not isinstance(value, str) or len(value) < 10:
        return None
    try:
        return date.fromisoformat(value[:10])
    except ValueError:
        return None
