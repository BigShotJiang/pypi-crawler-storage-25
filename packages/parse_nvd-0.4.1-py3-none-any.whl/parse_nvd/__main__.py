# SPDX-FileCopyrightText: 2026 Phil
# SPDX-License-Identifier: Apache-2.0

"""Allow running with `python -m parse_nvd`."""

from .cli import run


if __name__ == "__main__":
    raise SystemExit(run())
