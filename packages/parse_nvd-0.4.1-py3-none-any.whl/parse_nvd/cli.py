# SPDX-FileCopyrightText: 2026 Phil
# SPDX-License-Identifier: Apache-2.0

"""Command-line interface for parse_nvd."""

import argparse
import json
from datetime import date
from pathlib import Path

from rich.console import Console as RichConsole
from rich.table import Table

from .markdown_report import write_markdown_report
from .report import build_report
from .xhtml_report import write_xhtml_report


class QuietConsole:
    """Provide a no-op console used when quiet output is desired."""

    def print(self, message: str) -> None:
        """Discard a message.

        Args:
            message: Message text to ignore.
        """
        _ = message


class PlainConsole:
    """Provide a basic stdout-backed console."""

    def print(self, message: str) -> None:
        """Print a message to stdout.

        Args:
            message: Message text to print.
        """
        print(message)


def print_verbose_summary(console: RichConsole, report: dict[str, object]) -> None:
    """Render a concise rich summary to the terminal.

    Args:
        console: Rich console used for table rendering.
        report: Report dictionary returned by the report builder.
    """
    summary = report["summary"]
    cots_items = report["cots"]

    header = Table(title="parse-nvd: summary")
    header.add_column("Field", style="cyan")
    header.add_column("Value", style="green")
    header.add_row("Total COTS", str(summary["total_cots"]))
    header.add_row("COTS with CVE", str(summary["matched_cots"]))
    header.add_row("Matching CVEs", str(summary["matched_cves"]))
    header.add_row("Vulnerabilities processed", str(summary["total_vulnerabilities_processed"]))
    filters = summary.get("filters", {})
    header.add_row("Filters", json.dumps(filters, ensure_ascii=True) if filters else "none")
    console.print(header)

    details = Table(title="COTS by CVE count")
    details.add_column("Name")
    details.add_column("Version")
    details.add_column("CVE count", justify="right")
    for item in cots_items:
        details.add_row(str(item["name"]), str(item["version"]), str(len(item["cves"])))
    console.print(details)


def parse_date_yyyy_mm_dd(value: str) -> date:
    """Parse and validate a date in YYYY-MM-DD format.

    Args:
        value: Raw CLI argument value.

    Returns:
        Parsed ``date`` value.

    Raises:
        argparse.ArgumentTypeError: If the date format is invalid.
    """
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            "Invalid date for --created-or-updated-after, expected YYYY-MM-DD"
        ) from exc


def build_parser() -> argparse.ArgumentParser:
    """Build and return the CLI argument parser.

    Returns:
        The fully configured argument parser.
    """
    parser = argparse.ArgumentParser(
        prog="parse-nvd",
        description=(
            "Generate a JSON report mapping each COTS entry to the matching "
            "NVD CVE blocks."
        ),
    )
    parser.add_argument(
        "--nvd-db",
        nargs="+",
        required=True,
        metavar="FILE",
        help="One or more NVD JSON files using the official schema.",
    )
    parser.add_argument(
        "--cots-list",
        required=True,
        metavar="FILE",
        help="JSON file listing COTS entries such as essai-cots.json.",
    )
    parser.add_argument(
        "--cvss-min",
        type=float,
        default=None,
        help="Minimum CVSS base score for a CVE to be kept.",
    )
    parser.add_argument(
        "--cvss-av",
        default=None,
        help="Minimum attack vector filter (NETWORK, ADJACENT, LOCAL, PHYSICAL).",
    )
    parser.add_argument(
        "--cvss-impact-c",
        default=None,
        help="Minimum confidentiality impact filter (NONE, LOW, HIGH).",
    )
    parser.add_argument(
        "--cvss-impact-i",
        default=None,
        help="Minimum integrity impact filter (NONE, LOW, HIGH).",
    )
    parser.add_argument(
        "--cvss-impact-d",
        default=None,
        help="Minimum availability impact filter (NONE, LOW, HIGH).",
    )
    parser.add_argument(
        "--output",
        default="parse-nvd-report.json",
        metavar="FILE",
        help="Output report path. Defaults to parse-nvd-report.json.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Display a clear synthetic console report using rich.",
    )
    parser.add_argument(
        "--md",
        default=None,
        metavar="FILE",
        help="Write a markdown report to the provided path.",
    )
    parser.add_argument(
        "--html",
        default=None,
        metavar="FILE",
        help="Write a self-contained XHTML report to the provided path.",
    )
    parser.add_argument(
        "--with-exploit",
        action="store_true",
        help="Keep only CVEs for which an exploit appears to exist.",
    )
    parser.add_argument(
        "--created-or-updated-after",
        type=parse_date_yyyy_mm_dd,
        default=None,
        metavar="YYYY-MM-DD",
        help=(
            "Keep only CVEs created or updated strictly after the provided "
            "date (YYYY-MM-DD)."
        ),
    )
    parser.add_argument(
        "--linux-order-by-system",
        action="store_true",
        help=(
            "Group linux_kernel CVEs by impacted Linux system in markdown "
            "reports and sort them by system."
        ),
    )
    return parser


def run() -> int:
    """Execute the command-line workflow.

    Returns:
        Process-style status code where ``0`` indicates success.
    """
    parser = build_parser()
    args = parser.parse_args()
    quiet_console = QuietConsole()
    plain_console = PlainConsole()

    try:
        report = build_report(
            nvd_paths=[Path(path) for path in args.nvd_db],
            cots_path=Path(args.cots_list),
            output_path=Path(args.output),
            cvss_min=args.cvss_min,
            cvss_av=args.cvss_av,
            impact_c=args.cvss_impact_c,
            impact_i=args.cvss_impact_i,
            impact_d=args.cvss_impact_d,
            with_exploit=args.with_exploit,
            created_or_updated_after=args.created_or_updated_after,
            linux_order_by_system=args.linux_order_by_system,
            console=plain_console if args.verbose else quiet_console,
            verbose=args.verbose,
        )
    except Exception as exc:
        plain_console.print(f"Error: {exc}")
        return 1

    report["summary"]["cli_options"] = {
        "nvd_db": [str(p) for p in args.nvd_db],
        "cots_list": str(args.cots_list),
        "cvss_min": args.cvss_min,
        "cvss_av": args.cvss_av,
        "cvss_impact_c": args.cvss_impact_c,
        "cvss_impact_i": args.cvss_impact_i,
        "cvss_impact_d": args.cvss_impact_d,
        "output": args.output,
        "verbose": args.verbose,
        "md": args.md,
        "html": args.html,
        "with_exploit": args.with_exploit,
        "created_or_updated_after": (
            args.created_or_updated_after.isoformat()
            if args.created_or_updated_after is not None
            else None
        ),
        "linux_order_by_system": args.linux_order_by_system,
    }

    if args.verbose:
        rich_console = RichConsole()
        print_verbose_summary(rich_console, report)
        rich_console.print(f"Output: {args.output}")
        if args.md:
            write_markdown_report(
                report,
                Path(args.md),
                linux_order_by_system=args.linux_order_by_system,
            )
            rich_console.print(f"Markdown: {args.md}")
        if args.html:
            write_xhtml_report(
                report,
                Path(args.html),
                linux_order_by_system=args.linux_order_by_system,
            )
            rich_console.print(f"HTML: {args.html}")
        return 0

    if args.md:
        write_markdown_report(
            report,
            Path(args.md),
            linux_order_by_system=args.linux_order_by_system,
        )
    if args.html:
        write_xhtml_report(
            report,
            Path(args.html),
            linux_order_by_system=args.linux_order_by_system,
        )

    plain_console.print(
        "Report generated "
        f"for {report['summary']['matched_cots']} COTS with "
        f"{report['summary']['matched_cves']} matching CVEs."
    )
    plain_console.print(f"Output: {args.output}")
    if args.md:
        plain_console.print(f"Markdown: {args.md}")
    if args.html:
        plain_console.print(f"HTML: {args.html}")
    return 0
