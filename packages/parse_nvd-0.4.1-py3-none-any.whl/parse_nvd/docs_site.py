# SPDX-FileCopyrightText: 2026 Phil
# SPDX-License-Identifier: Apache-2.0

"""Generate a readable HTML documentation site for the project."""

from html import escape
from pathlib import Path
import os
import pydoc

from .cli import build_parser

MODULES = (
    "parse_nvd",
    "parse_nvd.cli",
    "parse_nvd.report",
    "parse_nvd.markdown_report",
)


def _write_css(site_dir: Path) -> None:
    css = """
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  margin: 0;
  color: #13212f;
  background: #f7fafc;
}
header {
  background: linear-gradient(135deg, #0b4f6c, #1f7a8c);
  color: #fff;
  padding: 1.2rem 1.6rem;
}
main {
  max-width: 980px;
  margin: 1rem auto 2rem auto;
  padding: 0 1rem;
}
.card {
  background: #fff;
  border: 1px solid #d7e3ea;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1rem;
}
a {
  color: #0b4f6c;
  text-decoration: none;
}
a:hover {
  text-decoration: underline;
}
ul {
  line-height: 1.6;
}
table {
  width: 100%;
  border-collapse: collapse;
  background: #fff;
}
th, td {
  border: 1px solid #d7e3ea;
  padding: 0.55rem;
  text-align: left;
  vertical-align: top;
}
th {
  background: #ecf4f8;
}
code {
  background: #eef3f7;
  padding: 0.12rem 0.33rem;
  border-radius: 4px;
}
""".strip()
    (site_dir / "style.css").write_text(css + "\n", encoding="utf-8")


def _write_index(site_dir: Path) -> None:
    links = "\n".join(
        f'<li><a href="{name}.html">{name}</a></li>'
        for name in MODULES
    )
    content = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>parse-nvd - Documentation</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <header>
    <h1>parse-nvd Documentation</h1>
    <p>Static site generated from docstrings and the CLI parser.</p>
  </header>
  <main>
    <section class="card">
      <h2>CLI Arguments</h2>
      <p><a href="cli-arguments.html">View the CLI option descriptions</a></p>
    </section>
    <section class="card">
      <h2>Module documentation</h2>
      <ul>
        {links}
      </ul>
    </section>
  </main>
</body>
</html>
"""
    (site_dir / "index.html").write_text(content, encoding="utf-8")


def _write_cli_arguments_page(site_dir: Path) -> None:
    parser = build_parser()
    rows = []
    for action in parser._actions:
        if action.dest == "help":
            continue
        names = ", ".join(action.option_strings) if action.option_strings else action.dest
        required = "Yes" if action.required else "No"
        default = "" if action.default is None else str(action.default)
        rows.append(
            "<tr>"
            f"<td><code>{escape(names)}</code></td>"
            f"<td>{escape(action.help or '')}</td>"
            f"<td>{required}</td>"
            f"<td><code>{escape(default)}</code></td>"
            "</tr>"
        )

    table_rows = "\n".join(rows)
    content = f"""<!doctype html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
  <title>CLI Arguments - parse-nvd</title>
  <link rel=\"stylesheet\" href=\"style.css\" />
</head>
<body>
  <header>
    <h1>parse-nvd CLI Arguments</h1>
    <p><a href=\"index.html\" style=\"color:#fff;text-decoration:underline;\">Back to index</a></p>
  </header>
  <main>
    <section class=\"card\">
      <table>
        <thead>
          <tr>
            <th>Option</th>
            <th>Description</th>
            <th>Required</th>
            <th>Default</th>
          </tr>
        </thead>
        <tbody>
          {table_rows}
        </tbody>
      </table>
    </section>
  </main>
</body>
</html>
"""
    (site_dir / "cli-arguments.html").write_text(content, encoding="utf-8")


def generate_docs_site(output_dir: Path | None = None) -> Path:
    """Generate the static documentation site.

    Args:
        output_dir: Optional target directory for generated HTML files.

    Returns:
        Path of the generated documentation directory.
    """
    site_dir = output_dir or Path("docs") / "site"
    site_dir.mkdir(parents=True, exist_ok=True)
    _write_css(site_dir)
    _write_index(site_dir)
    _write_cli_arguments_page(site_dir)

    previous_cwd = Path.cwd()
    try:
        os.chdir(site_dir)
        for module_name in MODULES:
            pydoc.writedoc(module_name)
    finally:
        os.chdir(previous_cwd)

    return site_dir


def main() -> None:
    """Generate the documentation site using default settings."""
    site_dir = generate_docs_site()
    print(f"Documentation generated in: {site_dir}")


if __name__ == "__main__":
    main()
