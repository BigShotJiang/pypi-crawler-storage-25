# SPDX-FileCopyrightText: 2026 Phil
# SPDX-License-Identifier: Apache-2.0

"""XHTML report rendering utilities."""

from html import escape
from importlib.resources import files
from pathlib import Path
from typing import Any

from .markdown_report import _extract_description, _has_exploit, _shorten
from .report import extract_linux_system


def load_report_css() -> str:
    """Load the packaged CSS used for XHTML reports.

    Returns:
        CSS stylesheet content bundled with the package.
    """
    return files("parse_nvd").joinpath("data", "report.css").read_text(encoding="utf-8")


def _table_for_cves(cve_entries: list[dict[str, Any]]) -> str:
    """Render one XHTML table for CVE entries.

    Args:
        cve_entries: CVE entries to render.

    Returns:
        XHTML table markup.
    """
    rows: list[str] = [
        "<table>",
        "  <thead>",
        "    <tr>",
        "      <th>CVE ID</th>",
        "      <th class=\"num\">CVSS Score</th>",
        "      <th>Description</th>",
        "      <th>Matched CPE</th>",
        "      <th>CVSS Vector</th>",
        "      <th>Exploit</th>",
        "    </tr>",
        "  </thead>",
        "  <tbody>",
    ]

    if not cve_entries:
        rows.extend(
            [
                "    <tr>",
                "      <td>-</td>",
                "      <td class=\"num\">-</td>",
                "      <td>No results</td>",
                "      <td>-</td>",
                "      <td>-</td>",
                "      <td>-</td>",
                "    </tr>",
            ]
        )
    else:
        for cve_entry in cve_entries:
            cve_block = cve_entry["cve"]
            description = escape(_extract_description(cve_block))
            vector = escape(_shorten(str(cve_entry["cvss"].get("vector_string") or ""), limit=120))
            cpe_list = ", ".join(
                escape(str(match.get("criteria", "")))
                for match in cve_entry.get("matching_criteria", [])
            )
            exploit_available = cve_entry.get("exploit_available")
            if exploit_available is None:
                exploit_available = _has_exploit(cve_block)
            pill_class = "pill" if exploit_available else "pill no"
            pill_label = "Yes" if exploit_available else "No"
            rows.extend(
                [
                    "    <tr>",
                    f"      <td>{escape(str(cve_block.get('id', '')))}</td>",
                    f"      <td class=\"num\">{escape(str(cve_entry['cvss'].get('base_score')))}</td>",
                    f"      <td>{description}</td>",
                    f"      <td>{escape(_shorten(cpe_list, limit=160))}</td>",
                    f"      <td>{vector}</td>",
                    f"      <td><span class=\"{pill_class}\">{pill_label}</span></td>",
                    "    </tr>",
                ]
            )

    rows.extend(["  </tbody>", "</table>"])
    return "\n".join(rows)


def write_xhtml_report(
    report: dict[str, Any],
    html_path: Path,
    *,
    linux_order_by_system: bool = False,
) -> None:
    """Write a self-contained XHTML report.

    Args:
        report: Report dictionary produced by the report builder.
        html_path: Destination path for the XHTML document.
        linux_order_by_system: Whether linux kernel CVEs should be split into
            one table per extracted impacted system.
    """
    summary = report["summary"]
    cots_items = report["cots"]
    css = escape(load_report_css())

    nvd_sources = summary.get("nvd_sources", [])
    nvd_source_rows = [
        "<tr>"
        f"<td>{escape(str(source.get('file', '')))}</td>"
        f"<td>{escape(str(source.get('timestamp') or '\u2014'))}</td>"
        "</tr>"
        for source in nvd_sources
    ]

    filters = summary.get("filters", {})
    filter_items = [f"<li><code>{escape(str(key))}</code>: {escape(str(value))}</li>" for key, value in filters.items()]
    if not filter_items:
        filter_items = ["<li>No filters applied</li>"]

    cli_options = summary.get("cli_options", {})
    cli_option_rows = []
    for key, value in cli_options.items():
        display = "\u2014" if (value is None or value is False) else escape(str(value))
        cli_option_rows.append(
            "<tr>"
            f"<td><code>{escape(str(key))}</code></td>"
            f"<td>{display}</td>"
            "</tr>"
        )

    summary_rows = []
    for item in cots_items:
        summary_rows.append(
            "<tr>"
            f"<td>{escape(str(item['name']))}</td>"
            f"<td class=\"num\">{escape(str(item['version']))}</td>"
            f"<td class=\"num\">{len(item['cves'])}</td>"
            "</tr>"
        )

    detail_sections: list[str] = []
    for item in cots_items:
        section_parts = [
            f"<h3>{escape(str(item['name']))} {escape(str(item['version']))}</h3>",
        ]
        if linux_order_by_system and item["name"] == "linux_kernel" and item["cves"]:
            grouped_entries: dict[str, list[dict[str, Any]]] = {}
            for cve_entry in item["cves"]:
                grouped_entries.setdefault(extract_linux_system(cve_entry["cve"]), []).append(cve_entry)
            for system_name in sorted(grouped_entries, key=str.upper):
                section_parts.append(f"<h4>Impacted system: {escape(system_name)}</h4>")
                section_parts.append(_table_for_cves(grouped_entries[system_name]))
        else:
            section_parts.append(_table_for_cves(item["cves"]))
        detail_sections.append("\n".join(section_parts))

    content = f"""<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>parse-nvd Report</title>
    <style type=\"text/css\">{css}</style>
  </head>
  <body>
    <div class=\"page\">
      <div class=\"hero\">
        <h1>parse-nvd Report</h1>
        <p>Self-contained XHTML report generated locally, without any external resource.</p>
      </div>
      <div class=\"card\">
        <h2>NVD Sources</h2>
        <table>
          <thead>
            <tr>
              <th>File</th>
              <th>Timestamp</th>
            </tr>
          </thead>
          <tbody>
            {''.join(nvd_source_rows)}
          </tbody>
        </table>
      </div>
      <div class=\"card\">
        <h2>Applied Filters</h2>
        <ul class=\"filters\">
          {''.join(filter_items)}
        </ul>
      </div>
      <div class=\"card\">
        <h2>CLI Options</h2>
        <table>
          <thead>
            <tr>
              <th>Option</th>
              <th>Value</th>
            </tr>
          </thead>
          <tbody>
            {''.join(cli_option_rows)}
          </tbody>
        </table>
      </div>
      <div class=\"card\">
        <h2>Summary by COTS</h2>
        <table>
          <thead>
            <tr>
              <th>COTS</th>
              <th class="num">Version</th>
              <th class="num">CVE Count</th>
            </tr>
          </thead>
          <tbody>
            {''.join(summary_rows)}
          </tbody>
        </table>
      </div>
      <div class=\"card\">
        <h2>CVE Details by COTS</h2>
        {' '.join(detail_sections)}
      </div>
    </div>
  </body>
</html>
"""
    html_path.write_text(content, encoding="utf-8")
