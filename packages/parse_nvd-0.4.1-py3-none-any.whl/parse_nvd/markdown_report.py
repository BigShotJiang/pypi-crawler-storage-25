# SPDX-FileCopyrightText: 2026 Phil
# SPDX-License-Identifier: Apache-2.0

"""Markdown report rendering utilities."""

from pathlib import Path
import re
from typing import Any

from .report import extract_linux_system


def _escape_md(value: str) -> str:
    """Escape markdown characters used in table cells.

    Args:
        value: Raw text to render in a Markdown table cell.

    Returns:
        Escaped one-line text safe for table rendering.
    """
    return value.replace("|", "\\|").replace("\n", " ").strip()


def _extract_description(cve_block: dict[str, Any]) -> str:
    """Extract a synthetic CVE description, preferring English text.

    Args:
        cve_block: NVD CVE payload block.

    Returns:
        Synthetic one-sentence description, or an empty string.
    """
    descriptions = cve_block.get("descriptions") or []
    if not descriptions:
        return ""
    english = next((entry for entry in descriptions if entry.get("lang") == "en"), descriptions[0])
    text = re.sub(r"\s+", " ", str(english.get("value", ""))).strip()
    if not text:
        return ""

    sentence_split = re.split(r"(?<=[.!?])\s+", text, maxsplit=1)
    summary = sentence_split[0]
    if len(summary) > 220:
        summary = summary[:217].rstrip() + "..."
    return summary


def _shorten(value: str, limit: int = 100) -> str:
    """Shorten long text values for readable report tables.

    Args:
        value: Text value to shorten.
        limit: Maximum number of characters to keep.

    Returns:
        Shortened text with ellipsis when truncation is needed.
    """
    if len(value) <= limit:
        return value
    return value[: max(0, limit - 3)].rstrip() + "..."


def _has_exploit(cve_block: dict[str, Any]) -> bool:
    """Determine whether a CVE appears to have an exploit reference.

    Args:
        cve_block: NVD CVE payload block.

    Returns:
        ``True`` when an exploit hint is found in tags or URLs.
    """
    for ref in cve_block.get("references", []):
        tags = [str(tag).lower() for tag in ref.get("tags", [])]
        url = str(ref.get("url", "")).lower()
        if any("exploit" in tag or "poc" in tag for tag in tags):
            return True
        if "exploit" in url or "poc" in url:
            return True
    return False


def _render_cve_table(lines: list[str], cve_entries: list[dict[str, Any]]) -> None:
    """Append a CVE markdown table to the output lines.

    Args:
        lines: Mutable markdown line buffer.
        cve_entries: CVE entries to render in the table.
    """
    lines.append("| CVE ID | CVSS Score | Description | Matched CPE | CVSS Vector | Exploit |")
    lines.append("|---|---:|---|---|---|---|")

    if not cve_entries:
        lines.append("| - | - | No results | - | - | - |")
        lines.append("")
        return

    for cve_entry in cve_entries:
        cve_block = cve_entry["cve"]
        cve_id = _escape_md(str(cve_block.get("id", "")))
        score = cve_entry["cvss"].get("base_score")
        vector = _escape_md(_shorten(str(cve_entry["cvss"].get("vector_string") or ""), limit=120))
        description = _escape_md(_extract_description(cve_block))
        cpe_list = ", ".join(
            _escape_md(str(match.get("criteria", "")))
            for match in cve_entry.get("matching_criteria", [])
        )
        cpe_list = _escape_md(_shorten(cpe_list, limit=140))
        exploit_available = cve_entry.get("exploit_available")
        if exploit_available is None:
            exploit_available = _has_exploit(cve_block)
        has_exploit = "Yes" if exploit_available else "No"
        lines.append(
            f"| {cve_id} | {score} | {description} | {cpe_list} | {vector} | {has_exploit} |"
        )
    lines.append("")


def write_markdown_report(
    report: dict[str, Any],
    md_path: Path,
    *,
    linux_order_by_system: bool = False,
) -> None:
    """Write a Markdown report with summary and detailed CVE tables.

    Args:
        report: Report dictionary produced by the report builder.
        md_path: Destination path for the Markdown document.
        linux_order_by_system: Whether linux kernel CVEs should be split into
            one table per extracted impacted system.
    """
    summary = report["summary"]
    cots_items = report["cots"]

    lines: list[str] = ["# parse-nvd Report", ""]

    nvd_sources = summary.get("nvd_sources", [])
    if nvd_sources:
        lines.extend(["## NVD Sources", ""])
        lines.append("| File | Timestamp |")
        lines.append("|---|---|")
        for source in nvd_sources:
            file_name = _escape_md(str(source.get("file", "")))
            timestamp = _escape_md(str(source.get("timestamp") or "\u2014"))
            lines.append(f"| {file_name} | {timestamp} |")
        lines.append("")

    lines.extend(["## Applied Filters", ""])
    filters = summary.get("filters", {})
    if filters:
        for key, value in filters.items():
            lines.append(f"- {key}: {value}")
    else:
        lines.append("- No filters applied")
    lines.append("")

    cli_options = summary.get("cli_options", {})
    if cli_options:
        lines.extend(["## CLI Options", ""])
        lines.append("| Option | Value |")
        lines.append("|---|---|")
        for key, value in cli_options.items():
            display = "\u2014" if (value is None or value is False) else str(value)
            lines.append(f"| {_escape_md(key)} | {_escape_md(display)} |")
        lines.append("")

    lines.extend(["## Summary by COTS", ""])
    lines.append("| COTS | Version | CVE Count |")
    lines.append("|---|---:|---:|")
    for item in cots_items:
        lines.append(
            f"| {_escape_md(str(item['name']))} | {_escape_md(str(item['version']))} | {len(item['cves'])} |"
        )
    lines.append("")

    lines.extend(["## CVE Details by COTS", ""])
    for item in cots_items:
        name = _escape_md(str(item["name"]))
        version = _escape_md(str(item["version"]))
        lines.append(f"### {name} {version}")
        lines.append("")
        if linux_order_by_system and item["name"] == "linux_kernel" and item["cves"]:
            grouped_entries: dict[str, list[dict[str, Any]]] = {}
            for cve_entry in item["cves"]:
                grouped_entries.setdefault(extract_linux_system(cve_entry["cve"]), []).append(cve_entry)

            for system_name in sorted(grouped_entries, key=str.upper):
                lines.append(f"#### Impacted system: {_escape_md(system_name)}")
                lines.append("")
                _render_cve_table(lines, grouped_entries[system_name])
            continue

        _render_cve_table(lines, item["cves"])

    md_path.write_text("\n".join(lines), encoding="utf-8")
