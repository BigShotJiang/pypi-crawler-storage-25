"""Tarnished CLI package."""
