"""Compound pre-change safety check.

Combines blast radius, affected tests, complexity, coupling, conventions,
and fitness violations into a single call -- reducing round-trips for AI
agents from 5-6 calls to 1.
"""

from __future__ import annotations

from collections import Counter, defaultdict

import click

from roam.commands.changed_files import (
    get_changed_files,
    resolve_changed_to_db,
)
from roam.commands.cmd_affected_tests import (
    _gather_affected_tests,
    _looks_like_file,
    _resolve_file_symbols,
)
from roam.commands.cmd_conventions import (
    _group_for_kind,
    classify_case,
)
from roam.commands.cmd_fitness import _CHECKERS, _load_rules
from roam.commands.resolve import ensure_index, find_symbol
from roam.db.connection import find_project_root, open_db
from roam.output.formatter import (
    json_envelope,
    loc,
    to_json,
)

# ---------------------------------------------------------------------------
# Risk-level helpers
# ---------------------------------------------------------------------------


def _blast_severity(affected_syms: int, affected_files: int) -> str:
    if affected_syms >= 50 or affected_files >= 15:
        return "CRITICAL"
    if affected_syms >= 20 or affected_files >= 8:
        return "HIGH"
    if affected_syms >= 5 or affected_files >= 3:
        return "MEDIUM"
    return "LOW"


def _test_severity(direct: int, transitive: int, colocated: int) -> str:
    total = direct + transitive + colocated
    if total == 0:
        return "WARNING"
    return "OK"


def _complexity_severity(cc: float, nesting: int) -> str:
    if cc >= 25:
        return "CRITICAL"
    if cc >= 15 or nesting >= 5:
        return "HIGH"
    if cc >= 8 or nesting >= 4:
        return "MEDIUM"
    return "LOW"


def _coupling_severity(missing_count: int) -> str:
    if missing_count >= 5:
        return "HIGH"
    if missing_count >= 2:
        return "MEDIUM"
    if missing_count >= 1:
        return "LOW"
    return "OK"


def _convention_severity(violation_count: int) -> str:
    if violation_count >= 5:
        return "HIGH"
    if violation_count >= 1:
        return "WARNING"
    return "OK"


def _fitness_severity(failed_rules: int) -> str:
    if failed_rules >= 3:
        return "CRITICAL"
    if failed_rules >= 1:
        return "WARNING"
    return "OK"


_SEVERITY_ORDER = {"CRITICAL": 4, "HIGH": 3, "WARNING": 2, "MEDIUM": 2, "LOW": 1, "OK": 0}


def _overall_risk(*severities: str) -> str:
    """Compute overall risk from individual severity labels."""
    max_val = max(_SEVERITY_ORDER.get(s, 0) for s in severities)
    if max_val >= 4:
        return "CRITICAL"
    if max_val >= 3:
        return "HIGH"
    if max_val >= 2:
        return "MEDIUM"
    return "LOW"


def _risk_driver(blast, tests, compl, coupl, convs, fitns) -> str:
    """Identify the row driving the overall risk verdict.

    Returns a one-line summary like ``complexity (cc=17, HIGH)`` so
    an agent reading the preflight output knows *why* the overall
    verdict is what it is — it doesn't have to scan all six rows
    looking for the worst severity.

    Tie-break by actionability: complexity > fitness > tests > coupling
    > blast > conventions. A complexity warning is more actionable than
    a convention warning even at equal severity.
    """
    rows = [
        ("complexity", compl, f"cc={compl['max_cognitive_complexity']:.0f}"),
        ("fitness", fitns, f"{fitns.get('rules_failed', 0)} rules currently fail"),
        ("tests", tests, f"{tests.get('direct', 0)} direct, {tests.get('transitive', 0)} transitive"),
        ("coupling", coupl, f"{coupl.get('coupled_files', 0)} coupled files"),
        (
            "blast radius",
            blast,
            f"{blast.get('affected_symbols', 0)} symbols in {blast.get('affected_files', 0)} files",
        ),
        ("conventions", convs, f"{convs.get('violation_count', 0)} violations"),
    ]
    # Find max severity
    worst: tuple[int, str, str] | None = None
    for label, row, detail in rows:
        sev = row.get("severity", "OK").upper()
        order = _SEVERITY_ORDER.get(sev, 0)
        if order <= 1:  # OK / LOW — not driving the verdict
            continue
        if worst is None or order > worst[0]:
            worst = (order, label, f"{label} ({detail}, {sev})")
    return worst[2] if worst else ""


def _severity_tag(sev: str) -> str:
    return f"[{sev}]"


# ---------------------------------------------------------------------------
# 1. Blast radius
# ---------------------------------------------------------------------------


def _check_blast_radius(conn, sym_ids, file_paths):
    """Compute blast radius: affected symbols and files via reverse edges."""
    try:
        import networkx as nx

        from roam.graph.builder import build_symbol_graph
    except ImportError:
        return {
            "affected_symbols": 0,
            "affected_files": 0,
            "affected_file_list": [],
            "severity": "LOW",
        }

    G = build_symbol_graph(conn)
    RG = G.reverse()

    all_affected_syms = set()
    all_affected_files = set()

    for sid in sym_ids:
        if sid in RG:
            deps = nx.descendants(RG, sid)
            all_affected_syms.update(deps)
            for d in deps:
                node = G.nodes.get(d, {})
                fp = node.get("file_path")
                if fp and fp not in file_paths:
                    all_affected_files.add(fp)

    severity = _blast_severity(len(all_affected_syms), len(all_affected_files))

    return {
        "affected_symbols": len(all_affected_syms),
        "affected_files": len(all_affected_files),
        "affected_file_list": sorted(all_affected_files)[:20],
        "severity": severity,
    }


# ---------------------------------------------------------------------------
# 2. Affected tests
# ---------------------------------------------------------------------------


# Once the blast radius dumps every test file in the repo, the
# "Suggested tests:" line stops being a suggestion and becomes a wall
# of text. This cap is the boundary between actionable and unactionable.
_MAX_SUGGESTED_TEST_FILES = 15


def _check_affected_tests(conn, sym_ids, file_paths):
    """Find tests that need to run."""
    results = _gather_affected_tests(conn, sym_ids, file_paths)

    direct = sum(1 for r in results if r["kind"] == "DIRECT")
    transitive = sum(1 for r in results if r["kind"] == "TRANSITIVE")
    colocated = sum(1 for r in results if r["kind"] == "COLOCATED")

    # Unique test files
    seen = set()
    test_files = []
    for r in results:
        if r["file"] not in seen:
            seen.add(r["file"])
            test_files.append(r["file"])

    # Pick the actual test runner from package.json / pyproject when
    # possible — round 4 #18 noted preflight suggesting `pytest tests/`
    # for Vitest projects.
    try:
        from roam.db.connection import find_project_root
        from roam.output.project_shape import _detect_test_runner

        runner_name, _runner_cmd = _detect_test_runner(find_project_root())
    except Exception:
        runner_name = None
    runner_token = "pytest"
    if runner_name == "vitest":
        runner_token = "npx vitest run"
    elif runner_name == "jest":
        runner_token = "npx jest"
    elif runner_name == "mocha":
        runner_token = "npx mocha"
    elif runner_name == "playwright":
        runner_token = "npx playwright test"
    elif runner_name == "go test":
        runner_token = "go test"
    elif runner_name == "cargo test":
        runner_token = "cargo test"
    elif runner_name == "rspec":
        runner_token = "bundle exec rspec"

    truncated_files = len(test_files) > _MAX_SUGGESTED_TEST_FILES
    if truncated_files:
        suggested = test_files[:_MAX_SUGGESTED_TEST_FILES]
        suffix = f"  # (+{len(test_files) - _MAX_SUGGESTED_TEST_FILES} more)"
        pytest_cmd = f"{runner_token} " + " ".join(suggested) + suffix
    else:
        pytest_cmd = f"{runner_token} " + " ".join(test_files) if test_files else ""
    severity = _test_severity(direct, transitive, colocated)

    return {
        "direct": direct,
        "transitive": transitive,
        "colocated": colocated,
        "total": len(results),
        "test_files": test_files,
        "pytest_command": pytest_cmd,
        "pytest_command_truncated": truncated_files,
        "severity": severity,
    }


# ---------------------------------------------------------------------------
# 3. Complexity
# ---------------------------------------------------------------------------


def _check_complexity(conn, sym_ids):
    """Check complexity for target symbols."""
    if not sym_ids:
        return {
            "max_cognitive_complexity": 0,
            "max_nesting_depth": 0,
            "high_complexity_symbols": [],
            "severity": "LOW",
        }

    ph = ",".join("?" for _ in sym_ids)
    rows = conn.execute(
        f"""SELECT sm.cognitive_complexity, sm.nesting_depth,
                   sm.param_count, sm.line_count, sm.return_count,
                   sm.bool_op_count, sm.callback_depth,
                   s.name, s.kind, s.line_start, f.path as file_path
            FROM symbol_metrics sm
            JOIN symbols s ON sm.symbol_id = s.id
            JOIN files f ON s.file_id = f.id
            WHERE sm.symbol_id IN ({ph})
            ORDER BY sm.cognitive_complexity DESC""",
        list(sym_ids),
    ).fetchall()

    if not rows:
        return {
            "max_cognitive_complexity": 0,
            "max_nesting_depth": 0,
            "high_complexity_symbols": [],
            "severity": "LOW",
        }

    max_cc = max(r["cognitive_complexity"] for r in rows)
    max_nest = max(r["nesting_depth"] for r in rows)

    high = [
        {
            "name": r["name"],
            "kind": r["kind"],
            "file": r["file_path"],
            "line": r["line_start"],
            "cognitive_complexity": r["cognitive_complexity"],
            "nesting_depth": r["nesting_depth"],
        }
        for r in rows
        if r["cognitive_complexity"] >= 8
    ]

    severity = _complexity_severity(max_cc, max_nest)

    return {
        "max_cognitive_complexity": round(max_cc, 1),
        "max_nesting_depth": max_nest,
        "high_complexity_symbols": high[:10],
        "severity": severity,
    }


# ---------------------------------------------------------------------------
# 4. Coupling (temporal co-change)
# ---------------------------------------------------------------------------


def _check_coupling(conn, file_ids, file_paths):
    """Find temporally-coupled files that should change together."""
    if not file_ids:
        return {
            "coupled_files": 0,
            "missing_partners": [],
            "severity": "OK",
        }

    change_set = set(file_ids)

    # Build lookups
    id_to_path = {}
    file_commits = {}
    for f in conn.execute("SELECT id, path FROM files").fetchall():
        id_to_path[f["id"]] = f["path"]
    for fs in conn.execute("SELECT file_id, commit_count FROM file_stats").fetchall():
        file_commits[fs["file_id"]] = fs["commit_count"] or 1

    missing = []
    min_strength = 0.3
    min_cochanges = 2

    for fid in file_ids:
        partners = conn.execute(
            """SELECT file_id_a, file_id_b, cochange_count
               FROM git_cochange
               WHERE file_id_a = ? OR file_id_b = ?""",
            (fid, fid),
        ).fetchall()

        for p in partners:
            partner_fid = p["file_id_b"] if p["file_id_a"] == fid else p["file_id_a"]
            cochanges = p["cochange_count"]
            if cochanges < min_cochanges:
                continue

            avg = (file_commits.get(fid, 1) + file_commits.get(partner_fid, 1)) / 2
            strength = cochanges / avg if avg > 0 else 0
            if strength < min_strength:
                continue

            if partner_fid not in change_set:
                partner_path = id_to_path.get(partner_fid, f"file_id={partner_fid}")
                source_path = id_to_path.get(fid, f"file_id={fid}")
                missing.append(
                    {
                        "path": partner_path,
                        "strength": round(strength, 2),
                        "cochanges": cochanges,
                        "partner_of": source_path,
                    }
                )

    # Deduplicate by path (keep highest strength)
    seen = {}
    for m in missing:
        if m["path"] not in seen or m["strength"] > seen[m["path"]]["strength"]:
            seen[m["path"]] = m
    missing = sorted(seen.values(), key=lambda x: -x["strength"])

    severity = _coupling_severity(len(missing))

    return {
        "coupled_files": len(missing),
        "missing_partners": missing[:10],
        "severity": severity,
    }


# ---------------------------------------------------------------------------
# 5. Convention compliance
# ---------------------------------------------------------------------------


def _check_conventions(conn, sym_ids):
    """Check if target symbols follow codebase naming conventions."""
    if not sym_ids:
        return {
            "violations": [],
            "violation_count": 0,
            "severity": "OK",
        }

    # First, determine dominant naming style per kind-group from whole codebase
    all_symbols = conn.execute("""
        SELECT s.name, s.kind
        FROM symbols s
        WHERE s.kind IN ('function', 'method', 'class', 'interface',
                         'struct', 'trait', 'enum', 'variable',
                         'constant', 'property', 'field', 'type_alias')
    """).fetchall()

    group_cases = defaultdict(Counter)
    for sym in all_symbols:
        group = _group_for_kind(sym["kind"])
        style = classify_case(sym["name"])
        if style:
            group_cases[group][style] += 1

    # Determine dominant style per group
    dominant = {}
    for group, counter in group_cases.items():
        if counter:
            dominant[group] = counter.most_common(1)[0][0]

    # Now check target symbols
    ph = ",".join("?" for _ in sym_ids)
    target_syms = conn.execute(
        f"""SELECT s.name, s.kind, s.line_start, f.path as file_path
            FROM symbols s
            JOIN files f ON s.file_id = f.id
            WHERE s.id IN ({ph})""",
        list(sym_ids),
    ).fetchall()

    violations = []
    for sym in target_syms:
        group = _group_for_kind(sym["kind"])
        style = classify_case(sym["name"])
        expected = dominant.get(group)
        if style and expected and style != expected:
            violations.append(
                {
                    "name": sym["name"],
                    "kind": sym["kind"],
                    "actual_style": style,
                    "expected_style": expected,
                    "file": sym["file_path"],
                    "line": sym["line_start"],
                }
            )

    severity = _convention_severity(len(violations))

    return {
        "violations": violations,
        "violation_count": len(violations),
        "severity": severity,
    }


# ---------------------------------------------------------------------------
# 6. Fitness rule violations
# ---------------------------------------------------------------------------


def _check_fitness(conn, root, target_paths: set[str] | None = None):
    """Run fitness rules and split target failures from sibling failures.

    Round 4 #11: when ``target_paths`` is provided, every rule's
    violations are bucketed by whether they touch a target file. The
    return now distinguishes ``rules_failing_on_target`` (the question
    the user actually asked) from ``rules_failing_on_siblings`` (other
    code in the same files — context, not blame).
    """
    rules = _load_rules(root)
    if not rules:
        return {
            "rules_checked": 0,
            "rules_failed": 0,
            "rules_currently_failing": 0,
            "rules_failing_on_target": 0,
            "rules_failing_on_siblings": 0,
            "total_violations": 0,
            "failed_rules": [],
            "rule_details": [],
            "severity": "OK",
        }

    target_set = {p.replace("\\", "/").lower() for p in (target_paths or set())}

    def _violation_touches_target(violation: dict) -> bool:
        if not target_set:
            return True
        src = (violation.get("source") or "").replace("\\", "/").lower()
        if not src:
            return False
        path = src.split(":", 1)[0]
        return path in target_set

    all_violations = []
    rule_results = []
    target_fail_count = 0
    sibling_fail_count = 0

    for rule in rules:
        rtype = rule.get("type", "")
        checker = _CHECKERS.get(rtype)
        if checker is None:
            continue

        try:
            violations = checker(rule, conn)
        except Exception:
            violations = []

        on_target = [v for v in violations if _violation_touches_target(v)]
        on_siblings = [v for v in violations if v not in on_target]
        status = "PASS" if not violations else "FAIL"
        rule_results.append(
            {
                "name": rule.get("name", "unnamed"),
                "type": rtype,
                "status": status,
                "violations": len(violations),
                "violations_on_target": len(on_target),
                "violations_on_siblings": len(on_siblings),
            }
        )
        if on_target:
            target_fail_count += 1
        elif on_siblings:
            sibling_fail_count += 1
        all_violations.extend(violations)

    failed = sum(1 for r in rule_results if r["status"] == "FAIL")
    failed_names = [r["name"] for r in rule_results if r["status"] == "FAIL"]
    severity = _fitness_severity(target_fail_count or failed)

    return {
        "rules_checked": len(rule_results),
        "rules_failed": failed,
        "rules_currently_failing": failed,
        "rules_failing_on_target": target_fail_count,
        "rules_failing_on_siblings": sibling_fail_count,
        "total_violations": len(all_violations),
        "failed_rules": failed_names,
        "rule_details": rule_results,
        "severity": severity,
    }


# ---------------------------------------------------------------------------
# Target resolution
# ---------------------------------------------------------------------------


def _resolve_targets(conn, target, staged, root):
    """Resolve CLI arguments into (sym_ids, file_paths, file_ids, label).

    Returns a tuple of:
    - sym_ids: set of symbol IDs
    - file_paths: set of file paths (str)
    - file_ids: list of file IDs (int)
    - label: human-readable label for the target
    """
    sym_ids = set()
    file_paths = set()
    file_ids = []
    label = target or "staged changes"

    if staged:
        changed = get_changed_files(root, staged=True)
        if not changed:
            return sym_ids, file_paths, file_ids, "staged (no changes)"
        file_map = resolve_changed_to_db(conn, changed)
        if not file_map:
            return sym_ids, file_paths, file_ids, "staged (not in index)"
        for path, fid in file_map.items():
            file_paths.add(path)
            file_ids.append(fid)
            syms = conn.execute("SELECT id FROM symbols WHERE file_id = ?", (fid,)).fetchall()
            sym_ids.update(s["id"] for s in syms)
        label = f"staged changes ({len(file_map)} files)"

    if target:
        target_norm = target.replace("\\", "/")
        if _looks_like_file(target_norm):
            sids, fpaths = _resolve_file_symbols(conn, target_norm)
            if not sids:
                return sym_ids, file_paths, file_ids, f"{target} (not found)"
            sym_ids.update(sids)
            file_paths.update(fpaths)
            # Get file IDs for the resolved paths
            for fp in fpaths:
                row = conn.execute("SELECT id FROM files WHERE path = ?", (fp,)).fetchone()
                if row:
                    file_ids.append(row["id"])
            label = target_norm
        else:
            sym = find_symbol(conn, target)
            if sym is None:
                return sym_ids, file_paths, file_ids, f"{target} (not found)"
            sym_ids.add(sym["id"])
            file_paths.add(sym["file_path"])
            # Get file ID
            row = conn.execute("SELECT id FROM files WHERE path = ?", (sym["file_path"],)).fetchone()
            if row:
                file_ids.append(row["id"])
            label = f"{sym['name']} ({loc(sym['file_path'], sym['line_start'])})"

    return sym_ids, file_paths, file_ids, label


# ---------------------------------------------------------------------------
# CLI command
# ---------------------------------------------------------------------------


@click.command("preflight")
@click.argument("target", required=False, default=None)
@click.option("--staged", is_flag=True, help="Check staged changes")
@click.pass_context
def preflight(ctx, target, staged):
    """Run a pre-change safety checklist for a symbol, file, or staged changes.

    Combines blast radius, affected tests, complexity, coupling, conventions,
    and fitness checks into a single report. Ideal for AI agents that want
    one-call risk assessment before making changes.

    Unlike ``guard`` (which provides a deep 0-100 risk score for a single
    symbol with layer analysis and move-sensitive edges), this command
    handles files, staged changes, and multiple symbols at once, combining
    6 signal dimensions into a single CRITICAL/HIGH/MEDIUM/LOW verdict.
    """
    json_mode = ctx.obj.get("json") if ctx.obj else False

    if not target and not staged:
        click.echo("Provide a TARGET symbol/file or use --staged.")
        raise SystemExit(1)

    ensure_index()
    root = find_project_root()

    with open_db(readonly=True) as conn:
        # Resolve targets
        sym_ids, file_paths, file_ids, label = _resolve_targets(
            conn,
            target,
            staged,
            root,
        )

        if not sym_ids:
            if json_mode:
                click.echo(
                    to_json(
                        json_envelope(
                            "preflight",
                            summary={
                                "target": label,
                                "risk_level": "UNKNOWN",
                                "error": "No symbols found",
                            },
                        )
                    )
                )
            else:
                click.echo(f"No symbols found for: {label}")
            return

        # Run all checks
        blast = _check_blast_radius(conn, sym_ids, file_paths)
        tests = _check_affected_tests(conn, sym_ids, file_paths)
        compl = _check_complexity(conn, sym_ids)
        coupl = _check_coupling(conn, file_ids, file_paths)
        convs = _check_conventions(conn, sym_ids)
        fitns = _check_fitness(conn, root, target_paths=set(file_paths))

        # Overall risk
        risk = _overall_risk(
            blast["severity"],
            tests["severity"],
            compl["severity"],
            coupl["severity"],
            convs["severity"],
            fitns["severity"],
        )

        # Verdict
        if risk == "LOW":
            verdict = f"Safe to proceed — {risk} risk for {label}"
        elif risk == "MEDIUM":
            verdict = f"Proceed with caution — {risk} risk for {label}"
        elif risk == "HIGH":
            verdict = f"Review carefully — {risk} risk, {blast['affected_symbols']} symbols affected"
        else:
            verdict = f"Significant risk — {risk}, {blast['affected_symbols']} symbols in blast radius"

        # JSON output
        if json_mode:
            click.echo(
                to_json(
                    json_envelope(
                        "preflight",
                        summary={
                            "verdict": verdict,
                            "target": label,
                            "risk_level": risk,
                            "symbols_checked": len(sym_ids),
                            "files_checked": len(file_paths),
                        },
                        blast_radius={
                            "affected_symbols": blast["affected_symbols"],
                            "affected_files": blast["affected_files"],
                            "affected_file_list": blast["affected_file_list"],
                            "severity": blast["severity"],
                        },
                        tests={
                            "direct": tests["direct"],
                            "transitive": tests["transitive"],
                            "colocated": tests["colocated"],
                            "total": tests["total"],
                            "test_files": tests["test_files"],
                            "pytest_command": tests["pytest_command"],
                            "severity": tests["severity"],
                        },
                        complexity={
                            "max_cognitive_complexity": compl["max_cognitive_complexity"],
                            "max_nesting_depth": compl["max_nesting_depth"],
                            "high_complexity_symbols": compl["high_complexity_symbols"],
                            "severity": compl["severity"],
                        },
                        coupling={
                            "coupled_files": coupl["coupled_files"],
                            "missing_partners": coupl["missing_partners"],
                            "severity": coupl["severity"],
                        },
                        conventions={
                            "violation_count": convs["violation_count"],
                            "violations": convs["violations"],
                            "severity": convs["severity"],
                        },
                        fitness={
                            "rules_checked": fitns["rules_checked"],
                            "rules_failed": fitns["rules_failed"],
                            "total_violations": fitns["total_violations"],
                            "failed_rules": fitns["failed_rules"],
                            "rule_details": fitns["rule_details"],
                            "severity": fitns["severity"],
                        },
                    )
                )
            )
            return

        # Text output
        click.echo(f"VERDICT: {verdict}\n")
        click.echo(f"Pre-flight check for `{label}`:\n")

        # Blast radius
        blast_desc = f"{blast['affected_symbols']} symbols in {blast['affected_files']} files"
        click.echo(f"  Blast radius:     {blast_desc:<40s} {_severity_tag(blast['severity'])}")

        # Affected tests
        test_desc = f"{tests['direct']} direct, {tests['transitive']} transitive"
        if tests["colocated"]:
            test_desc += f", {tests['colocated']} colocated"
        click.echo(f"  Affected tests:   {test_desc:<40s} {_severity_tag(tests['severity'])}")

        # Complexity
        cc = compl["max_cognitive_complexity"]
        nest = compl["max_nesting_depth"]
        compl_desc = f"cc={cc:.0f}, nest={nest}"
        click.echo(f"  Complexity:       {compl_desc:<40s} {_severity_tag(compl['severity'])}")

        # Coupling
        if coupl["coupled_files"] > 0:
            coupl_desc = f"{coupl['coupled_files']} files often change together"
        else:
            coupl_desc = "no missing co-change partners"
        click.echo(f"  Coupling:         {coupl_desc:<40s} {_severity_tag(coupl['severity'])}")

        # Conventions
        if convs["violation_count"] > 0:
            conv_desc = f"{convs['violation_count']} naming violations"
        else:
            conv_desc = "no violations"
        click.echo(f"  Conventions:      {conv_desc:<40s} {_severity_tag(convs['severity'])}")

        # Fitness — distinguish target-attributed vs sibling failures
        # (round 4 #11). The same rule can fail because of OTHER code in
        # the same file ("Max function complexity 50" tripped by a
        # 700-cc neighbour); blaming the changing symbol for that is
        # misleading. We surface both buckets explicitly.
        if fitns["rules_checked"] == 0:
            fit_desc = "no rules configured"
        elif fitns.get("rules_failing_on_target", 0) > 0:
            rule_names = ", ".join(fitns["failed_rules"][:3])
            fit_desc = f"{fitns['rules_failing_on_target']} rules currently fail on target ({rule_names})"
        elif fitns.get("rules_failing_on_siblings", 0) > 0:
            rule_names = ", ".join(fitns["failed_rules"][:3])
            fit_desc = (
                f"target passes; {fitns['rules_failing_on_siblings']} rule(s) fail on sibling symbols ({rule_names})"
            )
        elif fitns["rules_failed"] > 0:
            rule_names = ", ".join(fitns["failed_rules"][:3])
            fit_desc = f"{fitns['rules_failed']} rules currently fail ({rule_names})"
        else:
            fit_desc = f"all {fitns['rules_checked']} rules pass"
        click.echo(f"  Fitness:          {fit_desc:<40s} {_severity_tag(fitns['severity'])}")

        # Overall
        click.echo(f"\n  Overall risk: {risk}")

        # Risk driver — name the row that's pushing the verdict so an
        # agent doesn't have to deduce it (dogfood notes 2026-05-01).
        # Pick the highest-severity row, breaking ties by category
        # priority (complexity > fitness > tests > coupling > blast >
        # conventions — most actionable first).
        driver = _risk_driver(blast, tests, compl, coupl, convs, fitns)
        if driver:
            click.echo(f"  Risk driver:  {driver}")

        # Suggested tests
        if tests["pytest_command"]:
            click.echo(f"  Suggested tests: {tests['pytest_command']}")
