# Brainforge CLI

Command-line interface for Brainforge V3.

## Local Installation (Development)

To install the CLI for local development with real-time updates:

```bash
pip install -e .
```

## Publishing to PyPI

If you want others to install the CLI simply via `pip install brainforge`, follow these steps:

### 1. Install Publishing Tools
You will need Python's official packaging tools. Install them globally:
```bash
pip install --upgrade build twine
```

### 2. Build the Package
From inside the `brainforge-cli` folder (where `setup.py` is), run:
```bash
python -m build
```
*(This generates two files inside a new `dist/` folder: a `.whl` and a `.tar.gz`)*

### 3. Upload to PyPI
You need an account on [PyPI (Python Package Index)](https://pypi.org/).
- Register an account.
- Go to your Account Settings and [create an API token](https://pypi.org/manage/account/token/).
- Upload your build using `twine`:

```bash
twine upload dist/*
```

*(When prompted for a username, type `__token__`. For the password, paste your PyPI API token!)*

> **Note**: If the name `brainforge` is already taken by someone else on PyPI, you will need to rename your package in `setup.py` (e.g. `name="brainforge-cli"` or `name="brainforge-v3"`).
