import sys
import time

import click
import requests
from brainforge.auth import get_access_token

DEFAULT_BASE_URL = "http://localhost:8000/api"

# Terminal Celery states — task has finished (success or failure)
_TERMINAL_STATES = {"SUCCESS", "FAILURE", "REVOKED"}


def _get_headers():
    token = get_access_token()
    if not token:
        click.secho(
            "Error: You are not logged in. Run 'brainforge login' first.", fg="red"
        )
        sys.exit(1)
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }


# ---------------------------------------------------------------------------
# Log Watching
# ---------------------------------------------------------------------------

def _poll_for_start(task_id, base_url, headers, timeout=60):
    """
    Polls GET /api/ingest/task/<id>/ until the task transitions out of PENDING
    or until the timeout is exceeded.  Returns (state, meta) when the task has
    started (or finished), or raises SystemExit on timeout.
    """
    click.echo(f"Waiting for task to start (task_id={task_id}) …")
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            resp = requests.get(
                f"{base_url}/ingest/task/{task_id}/",
                headers=headers,
                timeout=10,
            )
            if resp.status_code == 200:
                data = resp.json()
                state = data.get("state", "PENDING")
                meta = data.get("meta", {})
                if state != "PENDING":
                    return state, meta
        except Exception:
            pass  # network hiccup — keep polling
        time.sleep(1)

    click.secho(
        f"Timed out waiting for task {task_id} to start after {timeout}s.",
        fg="yellow",
    )
    sys.exit(1)


def watch_task_logs(task_id, follow, base_url, headers):
    """
    Stream the server-side log for an ingest task.

    1. Poll the status endpoint until the task has STARTED (so the log file
       path is available in the task metadata).
    2. Call /api/ingest/task/<id>/logs/?follow=<true|false> and stream the
       response line-by-line to stdout.
    3. After streaming finishes, poll one more time to report final status.
    """
    state, meta = _poll_for_start(task_id, base_url, headers)

    if state in _TERMINAL_STATES and not meta.get("log_file"):
        click.secho(
            f"Task {task_id} finished with state={state} but no log file was produced.",
            fg="yellow",
        )
        if meta.get("error"):
            click.secho(f"Error: {meta['error']}", fg="red")
        return

    follow_param = "true" if follow else "false"
    log_url = f"{base_url}/ingest/task/{task_id}/logs/?follow={follow_param}"

    click.secho("--- Log output start ---", fg="cyan")
    try:
        with requests.get(
            log_url,
            headers={k: v for k, v in headers.items() if k != "Content-Type"},
            stream=True,
            timeout=None,  # streaming — no timeout
        ) as resp:
            if resp.status_code != 200:
                click.secho(
                    f"Failed to stream logs (HTTP {resp.status_code}).", fg="red"
                )
                click.echo(resp.text)
                return

            for chunk in resp.iter_lines(decode_unicode=True):
                click.echo(chunk)

    except KeyboardInterrupt:
        click.echo("\n[Streaming interrupted]")

    click.secho("--- Log output end ---", fg="cyan")

    # Final status check
    try:
        resp = requests.get(
            f"{base_url}/ingest/task/{task_id}/",
            headers=headers,
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            final_state = data.get("state", "UNKNOWN")
            if final_state == "SUCCESS":
                click.secho(f"✓ Task completed successfully.", fg="green")
            elif final_state == "FAILURE":
                click.secho(f"✗ Task failed. Check the log above for details.", fg="red")
            else:
                click.echo(f"Task state: {final_state}")
    except Exception:
        pass


# ---------------------------------------------------------------------------
# API Calls
# ---------------------------------------------------------------------------

def ingest_raw_data(bids_root, dataset_label, workers, storage_type, base_url, log, follow, subjects=None, sessions=None):
    """Calls the backend API to trigger a raw BIDS data ingestion."""
    headers = _get_headers()

    payload = {"bids_root": bids_root}
    if dataset_label:
        payload["dataset_label"] = dataset_label
    if workers:
        payload["workers"] = workers
    if storage_type:
        payload["storage_type"] = storage_type
    if subjects:
        payload["subjects"] = list(subjects)
    if sessions:
        payload["sessions"] = list(sessions)

    click.echo(f"Submitting raw data ingestion to {base_url}...")
    click.echo(f"  BIDS Root:     {bids_root}")
    click.echo(f"  Dataset Label: {dataset_label or '(auto-detect from folder name)'}")
    click.echo(f"  Workers:       {workers or '(server default)'}")
    click.echo(f"  Storage Type:  {storage_type or '(auto-detect)'}")
    if subjects:
        click.echo(f"  Subjects:      {', '.join(subjects)}")
    if sessions:
        click.echo(f"  Sessions:      {', '.join(sessions)}")
    click.echo("")

    try:
        resp = requests.post(
            f"{base_url}/ingest/raw-data/",
            json=payload,
            headers=headers,
            timeout=30,
        )

        if resp.status_code in (200, 202):
            data = resp.json()
            task_id = data.get("task_id")
            click.secho("✓ Ingestion task accepted by server.", fg="green")
            click.echo(f"  Task ID:  {task_id}")
            click.echo(f"  Message:  {data.get('message', '')}")

            if log or follow:
                click.echo(f"\n  Use --follow to stream the log, or check later:")
                click.echo(
                    f"  GET {base_url}/ingest/task/{task_id}/logs/"
                )
                if task_id:
                    follow_live = follow  # --follow means live tail
                    watch_task_logs(task_id, follow=follow_live, base_url=base_url, headers=headers)
        else:
            click.secho(f"Error: Server returned HTTP {resp.status_code}", fg="red")
            click.echo(resp.text)
            sys.exit(1)

    except requests.exceptions.ConnectionError:
        click.secho(
            f"Error: Could not connect to BrainForge backend at {base_url}.", fg="red"
        )
        sys.exit(1)
    except Exception as e:
        click.secho(f"Error: {e}", fg="red")
        sys.exit(1)


def ingest_derivatives(
    derivatives_dir,
    dataset_label,
    container_name,
    container_version,
    analysis_instance,
    processing,
    base_url,
    log,
    follow,
):
    """Calls the backend API to trigger a BIDS derivatives ingestion."""
    headers = _get_headers()

    payload = {
        "derivatives_dir": derivatives_dir,
        "dataset_label": dataset_label,
        "container_name": container_name,
        "container_version": container_version,
        "analysis_instance": analysis_instance,
        "processing": processing,
    }

    click.echo(f"Submitting derivatives ingestion to {base_url}...")
    click.echo(f"  Derivatives Dir:    {derivatives_dir}")
    click.echo(f"  Dataset Label:      {dataset_label}")
    click.echo(f"  Container:          {container_name}@{container_version}")
    click.echo(f"  Analysis Instance:  {analysis_instance}")
    click.echo(f"  Mode:               {'Processing' if processing else 'PreProcessing'}")
    click.echo("")

    try:
        resp = requests.post(
            f"{base_url}/ingest/derivatives/",
            json=payload,
            headers=headers,
            timeout=30,
        )

        if resp.status_code in (200, 202):
            data = resp.json()
            task_id = data.get("task_id")
            click.secho("✓ Derivatives ingestion task accepted by server.", fg="green")
            click.echo(f"  Task ID:  {task_id}")
            click.echo(f"  Message:  {data.get('message', '')}")

            if log or follow:
                click.echo(f"\n  Streaming logs for task {task_id}...")
                if task_id:
                    watch_task_logs(task_id, follow=follow, base_url=base_url, headers=headers)
        else:
            click.secho(f"Error: Server returned HTTP {resp.status_code}", fg="red")
            click.echo(resp.text)
            sys.exit(1)

    except requests.exceptions.ConnectionError:
        click.secho(
            f"Error: Could not connect to BrainForge backend at {base_url}.", fg="red"
        )
        sys.exit(1)
    except Exception as e:
        click.secho(f"Error: {e}", fg="red")
        sys.exit(1)
