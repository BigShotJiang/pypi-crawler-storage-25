import sys

import brainforge.auth as auth
import click
from brainforge.ingest import ingest_derivatives as _ingest_derivatives
from brainforge.ingest import ingest_raw_data as _ingest_raw_data
from brainforge.job_logs import fetch_logs
from brainforge.job_status import check_status
from brainforge.run import generate_sbatch_script
from brainforge.run import parse_spec
from brainforge.run import submit_job
from brainforge.run import validate_spec
from brainforge import __version__
from brainforge.template import generate_yaml_template
from brainforge.delete import delete_subject as _delete_subject
from brainforge.delete import delete_session as _delete_session
from brainforge.download import download_subject as _download_subject
from brainforge.download import download_session as _download_session
from brainforge.download import download_analysis as _download_analysis


@click.group()
@click.version_option(version=__version__)
def main():
    """
    BrainForge CLI: The premier interface for executing neuroimaging analyses.

    Provides tools for generating SLURM job configurations, securely
    submitting arrays to the cluster, and tracking runtime statuses.
    """
    pass


@main.command()
def info():
    """Display information about Brainforge CLI and its current version."""
    click.echo(f"Welcome to the Brainforge CLI v{__version__}")
    click.echo("Run 'brainforge --help' to see all available commands.")


@main.command()
def login():
    """Authenticate with Globus."""
    auth.login()


@main.command()
def logout():
    """Logout of Globus."""
    auth.logout()


@main.command(name='ls')
@click.option('--base-url', default="https://brainforge.rs.gsu.edu/api", help="The BrainForge API base URL.")
@click.option('--verbose', '-v', is_flag=True, help="Show detailed error logs.")
def ls_cmd(base_url, verbose):
    """
    List accessible datasets (studies) in BrainForge, including their 
    subject counts, session counts, and roles.
    """
    import requests
    from brainforge.auth import get_access_token
    token = get_access_token()
    if not token:
        click.secho("Error: You are not logged in. Run 'brainforge login' first.", fg="red")
        sys.exit(1)
        
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    
    try:
        resp = requests.get(f"{base_url}/datasets/", headers=headers, timeout=10)
        if resp.status_code != 200:
            click.secho(f"Failed to fetch datasets: Server returned HTTP {resp.status_code}", fg="red")
            if verbose:
                click.secho(f"Response: {resp.text}", fg="red")
            sys.exit(1)
            
        data = resp.json()
        
        # Determine if paginated or direct list
        results = data.get('results', data) if isinstance(data, dict) else data
        
        if not results:
            click.secho("No studies found or you do not have access to any studies.", fg="yellow")
            return
            
        click.echo(f"{'STUDY':<35} | {'SUBJECTS':<10} | {'SESSIONS':<10} | {'USERS':<10} | {'ROLE':<10} | {'CREATED BY':<15}")
        click.echo("-" * 105)
        for d in results:
            name = str(d.get("name") or d.get("label"))[:35]
            subs = str(d.get("subject_count", 0))
            sess = str(d.get("session_count", 0))
            users = str(d.get("user_count", 0))
            role = str(d.get("user_role", "Unknown")).upper()
            creator = str(d.get("created_by", "Unknown"))
            
            click.echo(f"{name:<35} | {subs:<10} | {sess:<10} | {users:<10} | {role:<10} | {creator:<15}")
            
    except requests.exceptions.ConnectionError:
        click.secho(f"Error: Could not connect to BrainForge backend at {base_url}.", fg="red")
        sys.exit(1)
    except Exception as e:
        click.secho(f"Error: {e}", fg="red")
        sys.exit(1)




@main.command(name='run')
@click.argument('spec_file', type=click.Path(exists=True, dir_okay=False), required=False)
@click.option(
    '--yaml',
    'yaml_str',
    help="Parse the YAML spec directly from a string instead of a file.",
)
@click.option(
    '--dry-run',
    is_flag=True,
    help="Generate and print the sbatch script without submitting to SLURM.",
)
@click.option(
    '--participants-file',
    '-p',
    type=click.Path(exists=True, dir_okay=False),
    help="Path to a .txt or .tsv file containing participants.",
)
def run_job(spec_file, yaml_str, dry_run, participants_file):
    """
    Submit a SLURM job using a YAML specification file or string.

    Takes a SPEC_FILE containing `slurm` and `execution` blocks.
    Will automatically detect if this is a single job or a multiple job
    (array job) based on the presence of `participants_file` or `participants`.
    """
    import yaml
    if yaml_str:
        try:
            spec = yaml.safe_load(yaml_str)
        except Exception as e:
            click.secho(f"Error parsing YAML string: {e}", fg="red")
            sys.exit(1)
    elif spec_file:
        spec = parse_spec(spec_file)
    else:
        click.secho("Error: You must provide either a SPEC_FILE argument or a --yaml configuration.", fg="red")
        sys.exit(1)

    if participants_file:
        if 'execution' not in spec:
            spec['execution'] = {}
        spec['execution']['participants_file'] = participants_file

    # Validate the spec
    validate_spec(spec)

    # Generate script
    script_content = generate_sbatch_script(spec)

    # Submit job (or print if dry_run)
    submit_job(script_content, spec, dry_run=dry_run)


@main.command()
@click.argument('job_id', required=False)
@click.option('--json', 'as_json', is_flag=True, help="Output status securely in JSON format")
@click.option('--detailed', '-d', is_flag=True, help="Show detailed job information (scontrol & sacct).")
@click.option('--base-url', default="https://brainforge.rs.gsu.edu", help="The BrainForge API base URL.")
def status(job_id, as_json, detailed, base_url):
    """
    Check authentication status or the queue and runtime status of a scheduled SLURM job.

    If run without arguments, outputs the current authentication status and user identity.
    If a job_id is provided, queries SLURM via `sacct` (and `squeue` fallback).
    """
    if not job_id:
        from brainforge.auth import check_auth_status
        check_auth_status(base_url)
        return
        
    check_status(job_id, as_json=as_json, detailed=detailed)


@main.command()
@click.argument('job_id')
@click.option(
    '--error',
    '-e',
    is_flag=True,
    help="View error logs instead of output logs.",
)
@click.option(
    '--output',
    '-o',
    is_flag=True,
    help="View output logs (default).",
)
@click.option(
    '--follow',
    '-f',
    is_flag=True,
    help="Follow the log contents live.",
)
def logs(job_id, error, output, follow):
    """
    Tail or view the live standard logs of a SLURM job.

    Dynamically finds the output file SLURM is writing to using `scontrol`.
    By default it cats the standard output to the console. Use `-e` for standard error,
    and `-f` to follow the stream live (like tail -f).
    """
    log_type = 'error' if error else 'output'
    fetch_logs(job_id, log_type, follow=follow)


@main.command(name="generate")
@click.option(
    '--name',
    '-n',
    prompt='Enter output filename',
    default='template',
    help="Output filename for the generated template.",
)
def generate_cmd(name):
    """
    Generate a working YAML template for a BrainForge SLURM job.

    Creates a boilerplate .yaml file pre-filled with all required
    variables (`SINGULARITY_IMAGE`, `HOST_INPUT_DIR`, etc.) to run
    an array job over one or more `participants`.
    """
    generate_yaml_template(name)


@main.group()
def ingest():
    """
    Ingest data into the BrainForge database via the backend API.

    Use this group to load raw BIDS datasets or pipeline derivative
    outputs into the BrainForge platform.
    """
    pass


@ingest.command(name="raw")
@click.argument("bids_root", type=click.Path())
@click.option(
    "--dataset-label",
    "-d",
    default=None,
    help="Override the dataset label (defaults to BIDS root folder name).",
)
@click.option(
    "--workers",
    "-w",
    type=int,
    default=None,
    help="Number of parallel worker processes on the server (server default used if omitted).",
)
@click.option(
    "--storage-type",
    type=click.Choice(["qumulo", "filesystem"]),
    default=None,
    help="Explicitly set the storage type. Auto-detected by the server if omitted.",
)
@click.option(
    "--log",
    "log",
    is_flag=True,
    default=False,
    help="Wait for the task to start and print the log output to the console.",
)
@click.option(
    "--follow",
    "-f",
    is_flag=True,
    default=False,
    help="Stream the log output live as the task runs (implies --log).",
)
@click.option(
    "--subject",
    "-s",
    "subjects",
    multiple=True,
    metavar="SUBJECT_LABEL",
    help=(
        "Restrict ingestion to this subject (repeatable). "
        "E.g. -s 01 -s 02"
    ),
)
@click.option(
    "--session",
    "-e",
    "sessions",
    multiple=True,
    metavar="SESSION_LABEL",
    help=(
        "Restrict ingestion to this session (repeatable). "
        "E.g. -e baseline -e followup"
    ),
)
@click.option(
    "--base-url",
    default="http://localhost:8000/api",
    envvar="BRAINFORGE_API_URL",
    show_default=True,
    help="BrainForge backend API base URL.",
)
def ingest_raw(bids_root, dataset_label, workers, storage_type, log, follow, subjects, sessions, base_url):
    """
    Ingest a raw BIDS dataset into the BrainForge database.

    BIDS_ROOT is the absolute path to the root of the BIDS dataset on the
    server's filesystem. The server will index the dataset using pybids
    and populate the Subject, Session, and RawImage tables in parallel.

    Use --subject / --session to restrict ingestion to specific subjects
    or sessions (can be repeated):

        brainforge ingest raw /data/datasets/my_study -s 01 -s 02 -e baseline

    Use --follow to stream the ingestion log live:

        brainforge ingest raw /data/datasets/my_study --follow
    """
    _ingest_raw_data(
        bids_root=bids_root,
        dataset_label=dataset_label,
        workers=workers,
        storage_type=storage_type,
        base_url=base_url,
        log=log,
        follow=follow,
        subjects=list(subjects) if subjects else None,
        sessions=list(sessions) if sessions else None,
    )


@ingest.command(name="derivatives")
@click.option(
    "--derivatives-dir",
    "-p",
    required=True,
    help="Absolute path to the specific pipeline output directory.",
)
@click.option(
    "--dataset-label",
    "-d",
    required=True,
    help="BIDS dataset label to associate the derivatives with.",
)
@click.option(
    "--container-name",
    "-c",
    required=True,
    help="Container/pipeline name (e.g., 'anatprep').",
)
@click.option(
    "--container-version",
    "-V",
    required=True,
    help="Container version string (e.g., '2.0.0').",
)
@click.option(
    "--analysis-instance",
    "-i",
    type=int,
    default=1,
    show_default=True,
    help="Run instance number (used to distinguish multiple runs of the same container).",
)
@click.option(
    "--processing",
    is_flag=True,
    default=False,
    help="Ingest into ProcessingAnalysis table instead of PreProcessingAnalysis.",
)
@click.option(
    "--log",
    "log",
    is_flag=True,
    default=False,
    help="Wait for the task to start and print the log output to the console.",
)
@click.option(
    "--follow",
    "-f",
    is_flag=True,
    default=False,
    help="Stream the log output live as the task runs (implies --log).",
)
@click.option(
    "--base-url",
    default="http://localhost:8000/api",
    envvar="BRAINFORGE_API_URL",
    show_default=True,
    help="BrainForge backend API base URL.",
)
def ingest_derivs(
    derivatives_dir,
    dataset_label,
    container_name,
    container_version,
    analysis_instance,
    processing,
    log,
    follow,
    base_url,
):
    """
    Ingest BIDS derivative outputs into the BrainForge database.

    Links pipeline output files and SLURM job metadata with the
    corresponding Subject and Session records. Supports both
    PreProcessingAnalysis (default) and ProcessingAnalysis (--processing).

    Use --follow to stream the ingestion log live:

        brainforge ingest derivatives \\
            --derivatives-dir /data/datasets/my_study/derivatives/anatprep-2.0.0-1 \\
            --dataset-label my_study \\
            --container-name anatprep \\
            --container-version 2.0.0 \\
            --follow
    """
    _ingest_derivatives(
        derivatives_dir=derivatives_dir,
        dataset_label=dataset_label,
        container_name=container_name,
        container_version=container_version,
        analysis_instance=analysis_instance,
        processing=processing,
        base_url=base_url,
        log=log,
        follow=follow,
    )


@main.group()
def delete():
    """
    Hard delete data from the BrainForge database and filesystem.
    Requires Administrator privileges.
    """
    pass


@delete.command(name="subject")
@click.argument("target", metavar="<dataset>/<subject>")
@click.option(
    "--base-url",
    default="https://brainforge.rs.gsu.edu/api",
    envvar="BRAINFORGE_API_URL",
    help="BrainForge API base URL.",
)
def delete_subject_cmd(target, base_url):
    """
    Hard delete a subject and all associated data.
    Format: <dataset>/<subject>
    """
    parts = target.strip("/").split("/")
    if len(parts) != 2:
        click.secho("Error: Target must be in the format <dataset>/<subject>", fg="red")
        raise click.Abort()
    dataset, subject_label = parts
    _delete_subject(subject_label, dataset, base_url)


@delete.command(name="session")
@click.argument("target", metavar="<dataset>/<subject>/<session>")
@click.option(
    "--base-url",
    default="https://brainforge.rs.gsu.edu/api",
    envvar="BRAINFORGE_API_URL",
    help="BrainForge API base URL.",
)
def delete_session_cmd(target, base_url):
    """
    Hard delete a session and all associated data.
    Format: <dataset>/<subject>/<session>
    """
    parts = target.strip("/").split("/")
    if len(parts) != 3:
        click.secho("Error: Target must be in the format <dataset>/<subject>/<session>", fg="red")
        raise click.Abort()
    dataset, subject, session_label = parts
    _delete_session(session_label, subject, dataset, base_url)


@main.group()
def download():
    """
    Download data from BrainForge to the local file system.
    """
    pass


@download.command(name="subject")
@click.argument("subject_label")
@click.option("--dataset", "-d", required=True, help="Dataset label")
@click.option("--out-dir", "-o", default="./", help="Output directory")
@click.option(
    "--base-url",
    default="https://brainforge.rs.gsu.edu/api",
    envvar="BRAINFORGE_API_URL",
    help="BrainForge API base URL.",
)
def download_subject_cmd(subject_label, dataset, out_dir, base_url):
    """Download raw data for an entire subject."""
    _download_subject(subject_label, dataset, out_dir, base_url)


@download.command(name="session")
@click.argument("session_label")
@click.option("--subject", "-s", required=True, help="Subject label")
@click.option("--dataset", "-d", required=True, help="Dataset label")
@click.option("--out-dir", "-o", default="./", help="Output directory")
@click.option(
    "--base-url",
    default="https://brainforge.rs.gsu.edu/api",
    envvar="BRAINFORGE_API_URL",
    help="BrainForge API base URL.",
)
def download_session_cmd(session_label, subject, dataset, out_dir, base_url):
    """Download raw data for a specific session."""
    _download_session(session_label, subject, dataset, out_dir, base_url)


@download.command(name="analysis")
@click.argument("analysis_id")
@click.option("--type", "analysis_type", type=click.Choice(["pre", "proc"]), required=True, help="Analysis type: pre (Preprocessing) or proc (Processing)")
@click.option("--out-dir", "-o", default="./", help="Output directory")
@click.option(
    "--base-url",
    default="https://brainforge.rs.gsu.edu/api",
    envvar="BRAINFORGE_API_URL",
    help="BrainForge API base URL.",
)
def download_analysis_cmd(analysis_id, analysis_type, out_dir, base_url):
    """Download derivative files for a specific analysis."""
    _download_analysis(analysis_id, analysis_type, out_dir, base_url)


if __name__ == "__main__":
    main()
