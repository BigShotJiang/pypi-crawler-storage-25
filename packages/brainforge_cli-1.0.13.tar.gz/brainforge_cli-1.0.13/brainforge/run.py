import os
import subprocess
import sys
import tempfile

import click
import requests
import yaml
from brainforge.auth import get_access_token


def parse_spec(filepath):
    try:
        with open(filepath, 'r') as f:
            return yaml.safe_load(f)
    except Exception as e:
        click.secho(f"Error reading YAML file: {e}", fg="red")
        sys.exit(1)


def validate_spec(spec):
    """
    Validates that the provided YAML spec has the required structure and fields.
    Exits the CLI with an error if validation fails.
    """
    if not isinstance(spec, dict):
        click.secho("Error: YAML spec must be a dictionary at the top level.", fg="red")
        sys.exit(1)

    if 'slurm' not in spec:
        click.secho(
            "Error: Missing required 'slurm' section in the spec file.", fg="red"
        )
        sys.exit(1)

    if not isinstance(spec['slurm'], dict):
        click.secho("Error: The 'slurm' section must be a dictionary.", fg="red")
        sys.exit(1)

    required_slurm_keys = [
        'job-name',
        'partition',
        'account',
        'time',
        'mem',
        'cpus-per-task',
        'output',
        'error',
    ]
    for key in required_slurm_keys:
        if key not in spec['slurm']:
            click.secho(f"Error: Missing required slurm parameter: '{key}'.", fg="red")
            sys.exit(1)

    if 'execution' not in spec:
        click.secho(
            "Error: Missing required 'execution' section in the spec file.", fg="red"
        )
        sys.exit(1)

    execution = spec['execution']
    if not isinstance(execution, dict):
        click.secho("Error: The 'execution' section must be a dictionary.", fg="red")
        sys.exit(1)

    if 'command' not in execution or not execution['command']:
        click.secho(
            "Error: The 'execution' block must contain a 'command' string to run.",
            fg="red",
        )
        sys.exit(1)

    modules = execution.get('modules', [])
    if not isinstance(modules, list):
        click.secho("Error: 'execution.modules' must be a list.", fg="red")
        sys.exit(1)

    has_singularity = any(
        m == 'singularity' or m.startswith('singularity/') for m in modules
    )
    if not has_singularity:
        click.secho(
            "Error: 'execution.modules' must contain 'singularity' or specify a version (e.g., 'singularity/3.10.2').",
            fg="red",
        )
        sys.exit(1)

    env_vars = execution.get('env', {})
    if not isinstance(env_vars, dict):
        click.secho("Error: 'execution.env' must be a dictionary.", fg="red")
        sys.exit(1)

    required_env_keys = ['SINGULARITY_IMAGE', 'HOST_INPUT_DIR', 'HOST_OUTPUT_DIR']
    for key in required_env_keys:
        if key not in env_vars:
            click.secho(
                f"Error: Missing required execution.env parameter: '{key}'.", fg="red"
            )
            sys.exit(1)

    participants_file = execution.get('participants_file')

    if not participants_file:
        click.secho(
            "Error: You must specify 'participants_file' in the execution block.",
            fg="red",
        )
        sys.exit(1)

    if not isinstance(participants_file, str):
        click.secho("Error: 'participants_file' must be a string.", fg="red")
        sys.exit(1)

    if not os.path.isfile(participants_file):
        click.secho(f"Error: The file '{participants_file}' does not exist locally.", fg="red")
        sys.exit(1)


def generate_sbatch_script(spec):
    lines = ["#!/bin/bash"]

    slurm_config = spec.get('slurm', {})
    execution = spec.get('execution', {})

    # 1. Add #SBATCH directives
    for key, value in slurm_config.items():
        if value is True:
            # Some flags might not have a value, e.g. --exclusive
            lines.append(f"#SBATCH --{key}")
        elif value is False:
            continue
        else:
            lines.append(f"#SBATCH --{key}={value}")

    # Parse participants into a standard list of dictionaries
    participants_file = execution.get('participants_file')
    
    parsed_participants = []
    if participants_file:
        with open(participants_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    entry = {'participant': line}
                    if '_' in line:
                        parts = line.split('_')
                        for part in parts:
                            if part.startswith('sub-'):
                                entry['subject'] = part
                            elif part.startswith('ses-'):
                                entry['session'] = part
                    parsed_participants.append(entry)

    # Extract all unique keys to generate parallel bash arrays
    if parsed_participants:
        all_keys = set()
        for p in parsed_participants:
            all_keys.update(p.keys())
            
        num_items = len(parsed_participants)
        lines.append(f"#SBATCH --array=0-{num_items - 1}")

    lines.append("")
    lines.append("# --- Auto-generated by BrainForge CLI ---")
    lines.append("")

    if parsed_participants:
        import re
        for key in sorted(all_keys):
            # Clean key into valid bash variable uppercase
            bash_var = re.sub(r'[^a-zA-Z0-9_]', '_', key).upper()
            lines.append(f"COLUMN_{bash_var}=(")
            for p in parsed_participants:
                val = str(p.get(key, ""))
                lines.append(f'  "{val}"')
            lines.append(")")
            lines.append(f"{bash_var}=${{COLUMN_{bash_var}[$SLURM_ARRAY_TASK_ID]}}")
            # If the user used the old key 'participant', echo it.
            if key == 'participant' or key == 'subject':
                lines.append(f'echo "BrainForge Task running for {key}: ${bash_var}"')
        lines.append("")

    # 4. Modules loading
    modules = execution.get('modules', [])
    if modules:
        for mod in modules:
            lines.append(f"module load {mod}")
        lines.append("")

    # 5. Environment variables
    env_vars = execution.get('env', {})
    if env_vars:
        for key, val in env_vars.items():
            lines.append(f'export {key}="{val}"')
        lines.append("")

    # 6. Singularity Binds
    binds = execution.get('binds', [])
    if binds:
        bind_str = ",".join(binds)
        lines.append(f'export SINGULARITY_BIND="{bind_str}"')
        lines.append("")

    lines.append('# Create the host output directory automatically')
    lines.append('mkdir -p "$HOST_OUTPUT_DIR"')
    lines.append("")

    # 6. Actual command
    cmd = execution.get('command', '')
    if cmd:
        lines.append(cmd)

    return "\n".join(lines)


def submit_job(script_content, spec, dry_run=False):
    # Optional Database Logging via API
    api_config = spec.get('api', {})
    if 'raw_image_id' in api_config and 'spec_id' in api_config:
        base_url = api_config.get('base_url', 'http://localhost:8000/api')
        token = get_access_token()
        if not token:
            click.secho(
                "Error: API config found but you are not logged in. Run 'brainforge login' first.",
                fg="red",
            )
            if not dry_run:
                sys.exit(1)
        else:
            click.echo("Registering run with BrainForge Backend API...")
            headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            }
            try:
                # Based on the serializers.py, it expects raw_image_id and spec_id
                resp = requests.post(
                    f"{base_url}/preprocessing_analyses/run_analysis/",
                    json={
                        "raw_image_id": api_config['raw_image_id'],
                        "spec_id": api_config['spec_id'],
                    },
                    headers=headers,
                )

                if resp.status_code == 201:
                    click.secho(
                        "Successfully registered job in the backend database.",
                        fg="green",
                    )
                else:
                    click.secho(
                        f"Failed to register job. HTTP {resp.status_code}: {resp.text}",
                        fg="yellow",
                    )
            except Exception as e:
                click.secho(f"API request failed: {e}", fg="red")

    if dry_run:
        click.secho("--- DRY RUN: Generated batch script ---", fg="cyan")
        click.echo(script_content)
        click.secho("---------------------------------------", fg="cyan")
        return

    # Create a temporary file to hold the generated sbatch script
    fd, path = tempfile.mkstemp(suffix=".sh", prefix="bfg_run_")
    with os.fdopen(fd, 'w') as f:
        f.write(script_content)

    try:
        # Run sbatch on the temporary file
        result = subprocess.run(
            ['sbatch', path], capture_output=True, text=True, check=True
        )
        click.secho("Job submitted successfully!", fg="green")
        click.echo(result.stdout.strip())
    except subprocess.CalledProcessError as e:
        click.secho("Failed to submit job to SLURM:", fg="red")
        click.echo(e.stderr)
        sys.exit(1)
    except FileNotFoundError:
        click.secho(
            "Error: 'sbatch' command not found. Are you on a system with SLURM installed?",
            fg="red",
        )
        sys.exit(1)
    finally:
        # Clean up the temporary file
        try:
            os.remove(path)
        except OSError:
            pass
