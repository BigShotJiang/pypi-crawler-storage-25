import sys
import click
import requests
from brainforge.auth import get_access_token

def delete_subject(subject_label, dataset_label, base_url):
    token = get_access_token()
    if not token:
        click.secho("Error: You are not logged in. Run 'brainforge login' first.", fg="red")
        sys.exit(1)

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    
    # First, get the dataset ID
    try:
        resp = requests.get(f"{base_url}/datasets/?search={dataset_label}", headers=headers, timeout=10)
        if resp.status_code != 200:
            click.secho(f"Failed to fetch dataset: HTTP {resp.status_code}", fg="red")
            sys.exit(1)
    except requests.exceptions.ConnectionError:
        click.secho(f"Error: Could not connect to BrainForge backend at {base_url}.", fg="red")
        sys.exit(1)
        
    data = resp.json()
    datasets = data.get('results', data) if isinstance(data, dict) else data
    dataset = next((d for d in datasets if d.get('label') == dataset_label), None)
    
    if not dataset:
        click.secho(f"Error: Dataset '{dataset_label}' not found or you don't have access.", fg="red")
        sys.exit(1)
        
    # Then get the subject ID
    resp = requests.get(f"{base_url}/subjects/?dataset={dataset['id']}&search={subject_label}", headers=headers, timeout=10)
    if resp.status_code != 200:
        click.secho(f"Failed to fetch subject: HTTP {resp.status_code}", fg="red")
        sys.exit(1)
        
    data = resp.json()
    subjects = data.get('results', data) if isinstance(data, dict) else data
    subject = next((s for s in subjects if s.get('label') == subject_label), None)
    
    if not subject:
        click.secho(f"Error: Subject '{subject_label}' not found in dataset '{dataset_label}'.", fg="red")
        sys.exit(1)
        
    click.secho(f"WARNING: You are about to HARD DELETE subject {subject_label} and ALL its data.", fg="red", bold=True)
    click.secho("This will permanently remove the subject, raw images, and all pipeline derivatives from both the file system and the database. This action is IRREVERSIBLE.", fg="red", bold=True)
    confirmation = click.prompt("Please type 'confirm' or 'delete' to proceed")
    if confirmation.lower() not in ['confirm', 'delete']:
        click.echo("Aborted.")
        return
        
    # Send DELETE request
    resp = requests.delete(f"{base_url}/subjects/{subject['id']}/", headers=headers, timeout=10)
    if resp.status_code == 204:
        click.secho(f"Successfully deleted subject {subject_label}.", fg="green")
    else:
        click.secho(f"Failed to delete subject: HTTP {resp.status_code} - {resp.text}", fg="red")


def delete_session(session_label, subject_label, dataset_label, base_url):
    token = get_access_token()
    if not token:
        click.secho("Error: You are not logged in. Run 'brainforge login' first.", fg="red")
        sys.exit(1)

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    
    # Get the dataset ID
    try:
        resp = requests.get(f"{base_url}/datasets/?search={dataset_label}", headers=headers, timeout=10)
        if resp.status_code != 200:
            click.secho(f"Failed to fetch dataset: HTTP {resp.status_code}", fg="red")
            sys.exit(1)
    except requests.exceptions.ConnectionError:
        click.secho(f"Error: Could not connect to BrainForge backend at {base_url}.", fg="red")
        sys.exit(1)
        
    data = resp.json()
    datasets = data.get('results', data) if isinstance(data, dict) else data
    dataset = next((d for d in datasets if d.get('label') == dataset_label), None)
    
    if not dataset:
        click.secho(f"Error: Dataset '{dataset_label}' not found or you don't have access.", fg="red")
        sys.exit(1)
        
    # Get the subject ID
    resp = requests.get(f"{base_url}/subjects/?dataset={dataset['id']}&search={subject_label}", headers=headers, timeout=10)
    if resp.status_code != 200:
        click.secho(f"Failed to fetch subject: HTTP {resp.status_code}", fg="red")
        sys.exit(1)
        
    data = resp.json()
    subjects = data.get('results', data) if isinstance(data, dict) else data
    subject = next((s for s in subjects if s.get('label') == subject_label), None)
    
    if not subject:
        click.secho(f"Error: Subject '{subject_label}' not found in dataset '{dataset_label}'.", fg="red")
        sys.exit(1)

    # Get the session ID
    resp = requests.get(f"{base_url}/sessions/?subject={subject['id']}&search={session_label}", headers=headers, timeout=10)
    if resp.status_code != 200:
        click.secho(f"Failed to fetch session: HTTP {resp.status_code}", fg="red")
        sys.exit(1)
        
    data = resp.json()
    sessions = data.get('results', data) if isinstance(data, dict) else data
    session = next((s for s in sessions if s.get('label') == session_label), None)
    
    if not session:
        click.secho(f"Error: Session '{session_label}' not found in subject '{subject_label}'.", fg="red")
        sys.exit(1)

    click.secho(f"WARNING: You are about to HARD DELETE session {session_label} for subject {subject_label} and ALL its data.", fg="red", bold=True)
    click.secho("This will permanently remove the session, raw images, and all pipeline derivatives from both the file system and the database. This action is IRREVERSIBLE.", fg="red", bold=True)
    confirmation = click.prompt("Please type 'confirm' or 'delete' to proceed")
    if confirmation.lower() not in ['confirm', 'delete']:
        click.echo("Aborted.")
        return
        
    # Send DELETE request
    resp = requests.delete(f"{base_url}/sessions/{session['id']}/", headers=headers, timeout=10)
    if resp.status_code == 204:
        click.secho(f"Successfully deleted session {session_label}.", fg="green")
    else:
        click.secho(f"Failed to delete session: HTTP {resp.status_code} - {resp.text}", fg="red")
