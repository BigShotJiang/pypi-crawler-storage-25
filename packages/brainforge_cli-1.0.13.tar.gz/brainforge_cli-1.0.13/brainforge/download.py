import sys
import os
import requests
import click
from brainforge.auth import get_access_token

def _get_headers():
    token = get_access_token()
    if not token:
        click.secho("Error: You are not logged in. Run 'brainforge login' first.", fg="red")
        sys.exit(1)
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }

def _download_files(urls, out_dir):
    """Downloads files from a list of {"key": "relative/path", "url": "http..."}"""
    if not urls:
        click.secho("No files found to download.", fg="yellow")
        return

    click.secho(f"\nFound {len(urls)} file(s) ready to download.", fg="green", bold=True)
    click.secho(f"Target directory: {os.path.abspath(out_dir)}", fg="cyan")
    
    # Prompt the user
    if not click.confirm("Do you want to start the download now?", default=True):
        click.echo("Download aborted.")
        return

    os.makedirs(out_dir, exist_ok=True)

    with click.progressbar(urls, label="Downloading files", show_pos=True) as bar:
        for file_info in bar:
            key = file_info.get("key")
            url = file_info.get("url")
            if not key or not url:
                continue

            # Strip the dataset slug prefix from the key if it exists to avoid double nesting
            # e.g., 'dataset_slug/sub-X/...' -> 'sub-X/...'
            parts = key.split('/', 1)
            if len(parts) == 2 and not parts[0].startswith('sub-'):
                local_rel_path = parts[1]
            else:
                local_rel_path = key

            local_path = os.path.join(out_dir, local_rel_path)
            local_dir = os.path.dirname(local_path)
            
            os.makedirs(local_dir, exist_ok=True)

            try:
                with requests.get(url, stream=True) as r:
                    r.raise_for_status()
                    with open(local_path, 'wb') as f:
                        for chunk in r.iter_content(chunk_size=8192):
                            f.write(chunk)
            except Exception as e:
                click.secho(f"\nFailed to download {key}: {e}", fg="red")


def _get_dataset(dataset_label, base_url, headers):
    resp = requests.get(f"{base_url}/datasets/?search={dataset_label}", headers=headers, timeout=10)
    if resp.status_code != 200:
        click.secho(f"Failed to fetch dataset: HTTP {resp.status_code}", fg="red")
        sys.exit(1)
    data = resp.json()
    datasets = data.get('results', data) if isinstance(data, dict) else data
    dataset = next((d for d in datasets if d.get('label') == dataset_label), None)
    if not dataset:
        click.secho(f"Error: Dataset '{dataset_label}' not found.", fg="red")
        sys.exit(1)
    return dataset


def _get_subject(subject_label, dataset_id, base_url, headers):
    resp = requests.get(f"{base_url}/subjects/?dataset={dataset_id}&search={subject_label}", headers=headers, timeout=10)
    if resp.status_code != 200:
        click.secho(f"Failed to fetch subject: HTTP {resp.status_code}", fg="red")
        sys.exit(1)
    data = resp.json()
    subjects = data.get('results', data) if isinstance(data, dict) else data
    subject = next((s for s in subjects if s.get('label') == subject_label), None)
    if not subject:
        click.secho(f"Error: Subject '{subject_label}' not found.", fg="red")
        sys.exit(1)
    return subject


def download_subject(subject_label, dataset_label, out_dir, base_url):
    headers = _get_headers()
    dataset = _get_dataset(dataset_label, base_url, headers)
    subject = _get_subject(subject_label, dataset['id'], base_url, headers)

    # Get a raw image to use as proxy for the subject
    resp = requests.get(f"{base_url}/raw-data/?subject={subject['id']}", headers=headers, timeout=10)
    if resp.status_code != 200:
        click.secho(f"Failed to fetch raw data: HTTP {resp.status_code}", fg="red")
        sys.exit(1)
    data = resp.json()
    raw_images = data.get('results', data) if isinstance(data, dict) else data
    if not raw_images:
        click.secho(f"No raw data found for subject '{subject_label}'. Cannot generate download URLs.", fg="yellow")
        sys.exit(1)

    raw_image_id = raw_images[0]['id']

    click.echo(f"Requesting subject-level download URLs for subject {subject_label}...")
    resp = requests.get(f"{base_url}/raw-data/{raw_image_id}/generate-download-urls/?level=subject", headers=headers, timeout=30)
    if resp.status_code != 200:
        click.secho(f"Failed to generate URLs: HTTP {resp.status_code} - {resp.text}", fg="red")
        sys.exit(1)
    
    urls = resp.json().get('urls', [])
    _download_files(urls, out_dir)


def download_session(session_label, subject_label, dataset_label, out_dir, base_url):
    headers = _get_headers()
    dataset = _get_dataset(dataset_label, base_url, headers)
    subject = _get_subject(subject_label, dataset['id'], base_url, headers)

    # Get a raw image to use as proxy for the session
    resp = requests.get(f"{base_url}/raw-data/?subject={subject['id']}&session={session_label}", headers=headers, timeout=10)
    if resp.status_code != 200:
        click.secho(f"Failed to fetch raw data: HTTP {resp.status_code}", fg="red")
        sys.exit(1)
    data = resp.json()
    raw_images = data.get('results', data) if isinstance(data, dict) else data
    if not raw_images:
        click.secho(f"No raw data found for session '{session_label}' of subject '{subject_label}'.", fg="yellow")
        sys.exit(1)

    raw_image_id = raw_images[0]['id']

    click.echo(f"Requesting session-level download URLs for session {session_label}...")
    resp = requests.get(f"{base_url}/raw-data/{raw_image_id}/generate-download-urls/?level=session", headers=headers, timeout=30)
    if resp.status_code != 200:
        click.secho(f"Failed to generate URLs: HTTP {resp.status_code} - {resp.text}", fg="red")
        sys.exit(1)
    
    urls = resp.json().get('urls', [])
    _download_files(urls, out_dir)


def download_analysis(analysis_id, analysis_type, out_dir, base_url):
    headers = _get_headers()
    
    endpoint = "preprocessing-analyses" if analysis_type == "pre" else "processing-analyses"
    
    click.echo(f"Requesting download URLs for analysis ID {analysis_id}...")
    resp = requests.get(f"{base_url}/{endpoint}/{analysis_id}/generate-download-urls/", headers=headers, timeout=30)
    if resp.status_code != 200:
        click.secho(f"Failed to generate URLs: HTTP {resp.status_code} - {resp.text}", fg="red")
        sys.exit(1)
    
    urls = resp.json().get('urls', [])
    _download_files(urls, out_dir)
