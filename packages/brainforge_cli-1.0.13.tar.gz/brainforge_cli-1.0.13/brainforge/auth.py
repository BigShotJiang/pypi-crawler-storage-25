import json
import os

import click
import globus_sdk

# The Client ID should be replaced with a real Globus Native App Client ID
# registered in the Globus Developer Console.
# Default to an environment variable if provided.
CLIENT_ID = os.environ.get("GLOBUS_CLIENT_ID", "64371d44-2d7f-4330-a7fb-046d03f1d418")
CREDENTIALS_FILE = os.path.expanduser("~/.brainforge/credentials.json")


def get_auth_client():
    return globus_sdk.NativeAppAuthClient(CLIENT_ID)


def login():
    try:
        client = get_auth_client()
        # Request necessary scopes to get a recognizable token back
        client.oauth2_start_flow(
            refresh_tokens=True,
            requested_scopes=[
                globus_sdk.scopes.AuthScopes.openid,
                globus_sdk.scopes.AuthScopes.profile,
                globus_sdk.scopes.AuthScopes.email,
            ],
        )

        auth_url = client.oauth2_get_authorize_url()
        click.echo("Please authenticate with Globus here:\n")
        click.secho(f"{auth_url}\n", fg="cyan")

        auth_code = click.prompt("Please enter the authorization code you received")

        token_response = client.oauth2_exchange_code_for_tokens(auth_code.strip())

        # Save tokens
        os.makedirs(os.path.dirname(CREDENTIALS_FILE), exist_ok=True)
        with open(CREDENTIALS_FILE, 'w') as f:
            # We save the dictionary of tokens by resource server
            json.dump(token_response.by_resource_server, f)

        click.secho(
            f"Successfully authenticated! Credentials saved to {CREDENTIALS_FILE}",
            fg="green",
        )
    except globus_sdk.AuthAPIError as e:
        click.secho(f"Globus Auth failed: {e.message}", fg="red")
    except Exception as e:
        click.secho(f"Authentication failed: {e}", fg="red")


def get_access_token():
    """
    Returns the Globus Access Token from local storage.
    """
    if not os.path.exists(CREDENTIALS_FILE):
        return None

    try:
        with open(CREDENTIALS_FILE, 'r') as f:
            tokens = json.load(f)

        # The Auth server's token is typically what we need to pass back to the Django API
        auth_data = tokens.get("auth.globus.org", {})
        return auth_data.get("access_token")
    except Exception:
        return None


def logout():
    """
    Logs out the user by deleting local credentials.
    """
    if os.path.exists(CREDENTIALS_FILE):
        os.remove(CREDENTIALS_FILE)
        click.secho("Successfully logged out (Local credentials deleted).", fg="green")
    else:
        click.secho("You are already logged out.", fg="yellow")


def check_auth_status(base_url):
    """
    Checks the validity of the current token by querying Globus userinfo.
    """
    import requests
    token = get_access_token()
    if not token:
        click.secho("You are not currently logged in.", fg="yellow")
        return
        
    try:
        user_info_url = "https://auth.globus.org/v2/oauth2/userinfo"
        headers = {"Authorization": f"Bearer {token}"}
        response = requests.get(user_info_url, headers=headers, timeout=10)
        
        if response.status_code != 200:
            click.secho("You are not currently logged in.", fg="yellow")
            return
            
        user_info = response.json()
        email = user_info.get("email") or user_info.get("preferred_username") or "Unknown"
        
        click.secho(f"You are currently logged in to {base_url} as {email}", fg="green")
        
    except requests.exceptions.ConnectionError:
        click.secho("Could not verify authentication status (Connection Error).", fg="red")
    except Exception as e:
        click.secho(f"Could not verify authentication status: {e}", fg="red")

