import json
import subprocess

import click


def check_status(job_id, as_json=False, detailed=False):
    """
    Check the status of a SLURM job using sacct.
    If sacct returns empty (sometimes happens right after submission), fall back to squeue.
    """
    try:
        if as_json:
            cmd = ["sacct", "-j", str(job_id), "-X", "-P", "--format=JobID,State,ExitCode,End"]
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            output = result.stdout.strip()
            lines = output.split('\n')
            if len(lines) > 1:
                parts = lines[1].split('|')
                if len(parts) >= 4:
                    click.echo(json.dumps({
                        "job_id": parts[0],
                        "state": parts[1].split(' ')[0],
                        "exit_code": parts[2],
                        "end_time": parts[3]
                    }))
                    return
            # fallback
            cmd2 = ["squeue", "-j", str(job_id), "-O", "jobid,state", "-h"]
            res2 = subprocess.run(cmd2, capture_output=True, text=True)
            if res2.returncode == 0 and res2.stdout.strip():
                parts = res2.stdout.strip().split()
                if len(parts) >= 2:
                    click.echo(json.dumps({
                        "job_id": parts[0],
                        "state": parts[1],
                        "exit_code": "",
                        "end_time": ""
                    }))
                    return
            
            click.echo(json.dumps({}))
            return

        if detailed:
            cmd = ["sacct", "-j", str(job_id), "--format=JobID,JobName,Partition,State,ExitCode,Submit,Start,End,Elapsed,ReqMem,MaxRSS,NodeList"]
        else:
            # -X only shows the main allocation, hiding duplicate .batch and .extern steps
            cmd = ["sacct", "-j", str(job_id), "-X"]
        
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)

        output = result.stdout.strip()

        # sacct prints headers even if empty, but let's check if there are no real data lines
        lines = output.split('\n')

        # Usually sacct has 2 header lines. If there are <= 2 lines, it might not have loaded
        if len(lines) <= 2:
            # Fallback to squeue for very nascent jobs
            cmd2 = ["squeue", "-j", str(job_id)]
            try:
                res2 = subprocess.run(cmd2, capture_output=True, text=True, check=True)
                queue_output = res2.stdout.strip()
                if queue_output:
                    click.secho(
                        f"--- Status for SLURM Job: {job_id} (squeue) ---",
                        fg="cyan",
                        bold=True,
                    )
                    click.echo(queue_output)
                    return
            except subprocess.CalledProcessError:
                pass

        click.secho(f"--- Status for SLURM Job: {job_id} ---", fg="cyan", bold=True)
        click.echo(output)

    except subprocess.CalledProcessError as e:
        if as_json:
            click.echo(json.dumps({"error": f"Failed to query status: {e.stderr}"}))
            return
        click.secho(f"Failed to query status for job ID {job_id}.", fg="red")
        click.echo(e.stderr)
    except FileNotFoundError:
        if as_json:
            click.echo(json.dumps({"error": "sacct command not found"}))
            return
        click.secho(
            "Error: 'sacct' command not found. Are you on a system with SLURM installed?",
            fg="red",
        )
