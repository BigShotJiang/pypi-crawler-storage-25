import os
import subprocess

import click


def fetch_logs(job_id, log_type, follow=False):
    """
    Fetch the StdOut or StdErr log path for a given active SLURM job
    and print its contents (or follow live) to the console.
    """
    try:
        cmd = ["scontrol", "show", "job", str(job_id)]
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)

        stdout_path = None
        stderr_path = None

        for line in res.stdout.split('\n'):
            # scontrol output lines often have multiple key=value pairs separated by spaces
            tokens = line.split()
            for token in tokens:
                if token.startswith("StdOut="):
                    stdout_path = token.split("=", 1)[1]
                elif token.startswith("StdErr="):
                    stderr_path = token.split("=", 1)[1]

        target_path = stdout_path if log_type == 'output' else stderr_path

        if not target_path or target_path == '/dev/null':
            click.secho(
                f"Could not determine the {log_type} file path from SLURM configuration.",
                fg="red",
            )
            return

        if not os.path.exists(target_path):
            click.secho(
                f"Log file does not exist yet (or was deleted):\n{target_path}",
                fg="yellow",
            )
            return

        if follow:
            click.secho(
                f"--- Following {log_type} logs for Job {job_id} ---",
                fg="cyan",
                bold=True,
            )
            click.secho(f"File: {target_path} (Ctrl+C to stop)\n", fg="cyan")
            try:
                subprocess.run(["tail", "-f", target_path])
            except KeyboardInterrupt:
                click.echo("\nStopped following.")
                return
        else:
            click.secho(
                f"--- Viewing {log_type} logs for Job {job_id} ---",
                fg="cyan",
                bold=True,
            )
            click.secho(f"File: {target_path}\n", fg="cyan")

            with open(target_path, 'r') as f:
                content = f.read()

            if not content.strip():
                click.echo("<File is currently empty>")
            else:
                click.echo(content)

    except subprocess.CalledProcessError:
        click.secho(f"Job {job_id} not found in active SLURM queue.", fg="red")
        click.echo(
            "Hint: SLURM only registers paths for currently active or very recently finished jobs."
        )
        click.echo(
            "If your job finished a while ago, check the 'logs/' folder in the directory where you submitted it."
        )
    except FileNotFoundError:
        click.secho(
            "Error: 'scontrol' command not found. Are you on a system with SLURM installed?",
            fg="red",
        )
