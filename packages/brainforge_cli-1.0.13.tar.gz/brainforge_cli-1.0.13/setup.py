import os
import re
from setuptools import find_packages
from setuptools import setup

with open(os.path.join("brainforge", "__init__.py"), "r") as f:
    version_match = re.search(r"^__version__ = ['\"]([^'\"]*)['\"]", f.read(), re.M)
    if version_match:
        version = version_match.group(1)
    else:
        raise RuntimeError("Unable to find version string.")

setup(
    name="brainforge-cli",
    version=version,
    description="Command-line interface for Brainforge",
    author="Daniel Trinh",
    packages=find_packages(),
    install_requires=[
        "requests",
        "click",
        "PyYAML",
        "globus-sdk",
    ],
    entry_points={
        "console_scripts": [
            "brainforge=brainforge.cli:main",
            "bf=brainforge.cli:main",
        ],
    },
    python_requires=">=3.10",
)
