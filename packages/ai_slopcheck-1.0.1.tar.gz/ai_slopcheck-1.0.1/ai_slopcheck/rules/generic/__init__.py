"""Generic reusable rules."""
