"""Rule package."""
