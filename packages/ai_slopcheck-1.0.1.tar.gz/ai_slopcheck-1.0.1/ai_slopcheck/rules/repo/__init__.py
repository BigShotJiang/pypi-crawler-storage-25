"""Repository-aware example rules."""
