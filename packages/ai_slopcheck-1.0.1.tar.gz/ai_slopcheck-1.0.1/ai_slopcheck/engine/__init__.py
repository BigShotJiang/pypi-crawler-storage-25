"""Scanning engine helpers."""
