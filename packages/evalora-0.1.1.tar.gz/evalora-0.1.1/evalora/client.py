"""Evalora synchronous client — main entry point for connected and local mode evals."""

from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

from evalora.core.constants import DEFAULT_BASE_URL, DEFAULT_MAX_WORKERS, DEFAULT_TIMEOUT, SDK_VERSION
from evalora.core.exceptions import ApiError, AuthError
from evalora.run import Run
from evalora.core.types import ComparisonResult, RunStatus

if TYPE_CHECKING:
    from evalora.providers.base import Provider


class Evalora:
    """Evalora SDK client.

    Works in two modes:
        - Connected: api_key provided → results sent to evalora.dev dashboard
        - Local: no api_key → runs locally, shows results in terminal only

    Usage:
        # Connected (results in dashboard)
        ev = Evalora(api_key="evk_...")
        run = ev.run(eval_id="...")

        # Local (no account needed)
        ev = Evalora()
        run = ev.run()
        run.check(ask, "What is 2+2?", expected="4")
        run.complete()
    """

    def __init__(
        self,
        api_key: str = "",
        base_url: str = DEFAULT_BASE_URL,
        verbose: bool = True,
        debug: bool = False,
        parallel: bool = False,
        max_workers: int = DEFAULT_MAX_WORKERS,
        output: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        local: bool = False,
    ):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._verbose = verbose
        self._debug = debug
        self._parallel = parallel
        self._max_workers = max_workers
        self._output_dir = output  # None = default .evalora/, str = custom path
        self._local = local or not api_key
        self._explicit_local = local

        self._http: httpx.Client | None = None
        if not self._local:
            self._http = httpx.Client(
                base_url=f"{self._base_url}/v1",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=timeout,
            )

        if self._verbose:
            from evalora.output.display import print_banner
            print_banner()

            if self._local and not self._explicit_local:
                from evalora.output.display import console
                console.print(
                    "[dim]Local mode — results shown here only. "
                    "Dashboard: [link=https://evalora.dev]evalora.dev[/link][/dim]\n"
                )

        if self._debug and not self._local:
            from evalora.output.display import console
            console.print(f"[dim]debug: base_url={self._base_url}[/dim]")
            console.print(f"[dim]debug: key={api_key[:12]}...[/dim]")

    def _request(self, method: str, path: str, **kwargs) -> dict:
        if self._local:
            return {}

        if not self._http:
            return {}

        if self._debug:
            from evalora.output.display import console
            body_preview = ""
            if "json" in kwargs:
                import json as json_mod
                raw = json_mod.dumps(kwargs["json"])
                body_preview = f" body={raw[:100]}{'...' if len(raw) > 100 else ''}"
            console.print(f"[dim]debug: {method} {path}{body_preview}[/dim]")

        import time as _time

        while True:
            response = self._http.request(method, path, **kwargs)

            if self._debug:
                from evalora.output.display import console
                console.print(f"[dim]debug: {response.status_code} ({len(response.content)} bytes)[/dim]")

            if response.status_code == 429:
                retry_after = float(response.headers.get("retry-after", "2"))
                if self._verbose:
                    from evalora.output.display import console
                    console.print(f"[dim]Slowing down — resuming in {retry_after:.0f}s...[/dim]")
                _time.sleep(retry_after)
                continue

            break

        if response.status_code == 401:
            raise AuthError(
                "Invalid API key. Check that it starts with 'evk_' and hasn't expired. "
                "Generate a new key at https://evalora.dev/dashboard"
            )

        if response.status_code >= 400:
            body = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            message = body.get("error", response.text)
            raise ApiError(message, response.status_code)

        return response.json()

    def run(
        self,
        eval_id: str = "",
        name: str | None = None,
        dataset: list[dict] | None = None,
        dataset_id: str | None = None,
        provider: Provider | None = None,
        system_prompt: str | None = None,
        ghost: bool | str | dict = False,
        ghost_server: bool | None = None,
        model: str | None = None,
        judge_mode: str = "local",
        judges: list[dict] | None = None,
        provider_keys: dict[str, str] | None = None,
        validators: list | None = None,
        scoring: str | None = None,
        similarity_threshold: float = 0.85,
        embedding_api_key: str | None = None,
        embedding_model: str = "text-embedding-3-small",
        resume: bool = False,
        max_cost: float | None = None,
        webhook: str | None = None,
        template: str | None = None,
        scorers: list | None = None,
        score_threshold: float = 0.5,
    ) -> Run:
        """Create a run.

        Args:
            template: Pre-configured eval template name (e.g. "rag-quality", "chatbot").
            scorers: List of scorer functions that return 0.0-1.0 float scores.
            score_threshold: Minimum average scorer score to pass (default 0.5).
            max_cost: Maximum cost in USD. Stops eval_each early if exceeded.
            webhook: URL to POST results to when run completes.
            judges: List of judge configs for AI judge panel mode. Each dict:
                {
                    "name": "Accuracy",
                    "provider": "openai",
                    "model": "gpt-4o",
                    "prompt": "Grade whether the response is accurate...",
                    "api_key": "sk-..." (optional, uses provider_keys fallback)
                }
            judge_mode: "local" (SDK runs judges) or "server" (backend workers run judges).
            provider_keys: Fallback API keys per provider: {"openai": "sk-...", "anthropic": "sk-ant-..."}
            validators: List of callables that take a response string and return True/False.
                Validators run before judges — if any fails, the item is marked failed
                and judges are skipped for that item.
        """
        # Normalize ghost config
        from evalora.ghost import GhostConfig, GhostServerConfig
        ghost_config = GhostConfig.from_param(ghost)
        ghost_server_config = GhostServerConfig.from_param(ghost_server, ghost_config)

        if ghost_config.enabled:
            import warnings
            mode_desc = {
                "full": "all text (prompts, responses, model, judge reasoning) will be redacted",
                "light": "responses will be redacted, prompts kept visible",
                "hash": "all text will be hashed (traceable but unreadable)",
                "custom": "per-field redaction is active",
            }
            desc = mode_desc.get(ghost_config.mode, "text will be redacted")
            warnings.warn(f"Ghost mode ({ghost_config.mode}): {desc}", stacklevel=2)
            if self._verbose:
                from evalora.output.display import console
                console.print(f"[dim italic]Ghost mode ({ghost_config.mode}): {desc}[/dim italic]\n")

        model_name = model or (getattr(provider, "_model", None) if provider else None)

        # Resume logic — load checkpoint if available
        _resumed = False
        _resume_run_id: str | None = None
        _resume_completed_hashes: set[str] = set()
        _resume_fingerprint: str = ""

        if resume:
            if not name:
                raise ValueError(
                    "resume=True requires name= to identify the checkpoint. "
                    "Example: ev.run(name='my-eval', resume=True)"
                )
            else:
                from evalora.output.checkpoint import load_checkpoint, clear_checkpoint

                checkpoint = load_checkpoint(name, self._output_dir)
                if checkpoint:
                    # Fingerprint will be validated later in eval_each when items are known.
                    # For now, store the checkpoint data so Run can use it.
                    _resumed = True
                    _resume_run_id = checkpoint.get("run_id")
                    _resume_completed_hashes = set(
                        checkpoint.get("completed_hashes", [])
                    )
                    _resume_fingerprint = checkpoint.get("fingerprint", "")

                    if self._verbose:
                        from evalora.output.display import console
                        console.print(
                            f"[bold green]Checkpoint found:[/bold green] "
                            f"{checkpoint.get('completed_count', 0)} items completed"
                        )

        # Resolve template — merges template defaults under explicit args
        if template:
            from evalora.templates import TEMPLATES
            key = template.lower().strip().replace(" ", "-")
            if key not in TEMPLATES:
                available = ", ".join(TEMPLATES.keys())
                raise ValueError(f"Unknown template: '{template}'. Available: {available}")
            tmpl = TEMPLATES[key]()
            # Template provides defaults; explicit args override
            if judges is None:
                judges = tmpl.get("judges")
            if validators is None:
                validators = tmpl.get("validators")
            if scoring is None and "scoring" in tmpl:
                scoring = tmpl["scoring"]

        # Smart defaults — auto-detect from what's provided
        if scoring is None:
            scoring = "semantic" if embedding_api_key else "exact"
        if validators:
            validators = _normalize_validators(validators)

        # Can't use dataset_id without API connection
        if dataset_id and (self._local or not eval_id):
            from evalora.output.display import console
            console.print(
                "\n[bold red]Cannot use dataset_id without api_key and eval_id.[/bold red]\n"
                "[dim]To use uploaded datasets:[/dim]\n"
                "  1. Sign up at [bold link=https://evalora.dev]https://evalora.dev[/bold link]\n"
                "  2. Create an eval and generate an API key\n"
                "  3. Pass them to Evalora(api_key=...) and run(eval_id=...)\n"
            )
            raise ValueError("dataset_id requires api_key and eval_id. Sign up at https://evalora.dev")

        # Local mode — no API calls
        if self._local:
            import uuid

            run_id = (
                _resume_run_id
                if _resumed and _resume_run_id
                else f"local-{uuid.uuid4().hex[:8]}"
            )
            run = Run(
                id=run_id,
                status="running",
                _client=self,
                _provider=provider,
                _system_prompt=system_prompt,
                _ghost_config=ghost_config,
                _ghost_server_config=ghost_server_config,
                _eval_id=eval_id or None,
                _model_name=model_name,
                _local=True,
                _output_dir=self._output_dir,
                _judge_mode=judge_mode,
                _judges=judges or [],
                _provider_keys=provider_keys or {},
                _validators=validators or [],
                _scoring=scoring,
                _similarity_threshold=similarity_threshold,
                _embedding_api_key=embedding_api_key,
                _embedding_model=embedding_model,
                name=name,
                _resumed=_resumed,
                _resume_completed_hashes=_resume_completed_hashes,
                _resume_fingerprint=_resume_fingerprint if _resumed else "",
                _max_cost=max_cost,
                _webhook=webhook,
                _scorers=scorers or [],
                _score_threshold=score_threshold,
            )

            if self._verbose:
                from evalora.output.display import print_run_created
                print_run_created(
                    run.id,
                    "",
                    model=model_name,
                    name=name,
                    resumed=_resumed,
                    skipped=len(_resume_completed_hashes) if _resumed else 0,
                )

            return run

        # Connected mode
        if not eval_id:
            if self._verbose:
                from evalora.output.display import console
                console.print(
                    "[yellow]No eval_id provided. Get one at:[/yellow]\n"
                    "[bold link=https://evalora.dev]https://evalora.dev[/bold link]\n"
                )
            # Fall back to local mode for this run
            import uuid
            return Run(
                id=f"local-{uuid.uuid4().hex[:8]}",
                status="running",
                _client=self,
                _provider=provider,
                _system_prompt=system_prompt,
                _ghost_config=ghost_config,
                _ghost_server_config=ghost_server_config,
                _model_name=model_name,
                _local=True,
                _output_dir=self._output_dir,
                _judge_mode=judge_mode,
                _judges=judges or [],
                _provider_keys=provider_keys or {},
                _validators=validators or [],
                _scoring=scoring,
                _similarity_threshold=similarity_threshold,
                _embedding_api_key=embedding_api_key,
                _embedding_model=embedding_model,
                name=name,
                _resumed=_resumed,
                _resume_completed_hashes=_resume_completed_hashes,
                _resume_fingerprint=_resume_fingerprint if _resumed else "",
            )

        # Fetch eval config from server — the dashboard is the source of truth
        _server_mode: str | None = None
        _server_has_server_judges = False
        try:
            config_data = self._request("GET", f"/evals/{eval_id}/config")
            _server_mode = config_data.get("mode")
            _server_has_server_judges = config_data.get("hasServerJudges", False)

            if self._verbose:
                from evalora.output.display import console
                mode_label = _server_mode or "unknown"
                console.print(f"[bold]Eval mode:[/bold] {mode_label} [dim](from dashboard)[/dim]")

                if _server_mode == "ai_judge_panel" and _server_has_server_judges:
                    console.print(
                        "[dim]Judges will run on the server using your BYOK keys.[/dim]"
                    )
                elif _server_mode == "exact_answer" and judges:
                    console.print(
                        "[dim]Server scoring is authoritative. "
                        "Local judges are supplementary.[/dim]"
                    )
                elif _server_mode == "human_review":
                    console.print(
                        "[dim]Items will go to the review queue. "
                        "Local judges provide pre-screening insight.[/dim]"
                    )
        except Exception:
            if self._debug:
                from evalora.output.display import console
                console.print("[dim]debug: failed to fetch eval config[/dim]")

        # Provider + inline dataset
        if provider is not None and dataset is not None:
            dataset = self._run_provider_on_items(provider, dataset, system_prompt)

        body: dict = {
            "evalId": eval_id,
            "name": name,
            "ghostMode": ghost_config.mode,
            "scoringMode": scoring,
            "template": template,
            "runType": "eval",
            "model": model_name,
            "sdkVersion": SDK_VERSION,
        }

        if dataset_id is not None:
            body["datasetId"] = dataset_id

            if provider is not None:
                fetched = self._request("GET", f"/datasets/{dataset_id}")
                items = fetched.get("items", [])
                if items:
                    dataset = self._run_provider_on_items(provider, items, system_prompt)
                    body["items"] = self._format_items(dataset, ghost_config=ghost_config)

        elif dataset is not None:
            body["items"] = self._format_items(dataset, ghost_config=ghost_config)

        # For resumed connected runs, reuse the existing run_id
        if _resumed and _resume_run_id:
            run_id = _resume_run_id
            run_status = "running"
            total_items = 0
        else:
            data = self._request("POST", "/runs", json=body)
            run_data = data.get("run", data)
            run_id = run_data["id"]
            run_status = run_data.get("status", "running")
            total_items = run_data.get("totalItems", 0)

        run = Run(
            id=run_id,
            status=run_status,
            _client=self,
            _provider=provider,
            _system_prompt=system_prompt,
            _ghost_config=ghost_config,
            _ghost_server_config=ghost_server_config,
            _dataset_id=dataset_id,
            _eval_id=eval_id,
            _model_name=model_name,
            _output_dir=self._output_dir,
            _judge_mode=judge_mode,
            _judges=judges or [],
            _provider_keys=provider_keys or {},
            _validators=validators or [],
            _scoring=scoring,
            _similarity_threshold=similarity_threshold,
            _embedding_api_key=embedding_api_key,
            _embedding_model=embedding_model,
            name=name,
            _resumed=_resumed,
            _resume_completed_hashes=_resume_completed_hashes,
            _resume_fingerprint=_resume_fingerprint if _resumed else "",
            _server_mode=_server_mode,
            _server_has_server_judges=_server_has_server_judges,
            _max_cost=max_cost,
            _webhook=webhook,
        )

        if self._verbose:
            from evalora.output.display import print_run_created
            print_run_created(
                run.id,
                run.url,
                total_items=total_items,
                model=model_name,
                name=name,
                resumed=_resumed,
                skipped=len(_resume_completed_hashes) if _resumed else 0,
            )

        return run

    def wrap(self, client, run: Run | None = None, expected: dict | None = None):
        """Wrap an OpenAI or Anthropic client to auto-log all LLM calls.

            client = ev.wrap(OpenAI())
            response = client.chat.completions.create(...)
            # ^ auto-logged to the active run

        Args:
            client: An OpenAI() or Anthropic() client instance.
            run: The Run to log to. If None, uses the most recent run.
            expected: Optional dict mapping prompts to expected answers.
        """
        from evalora.wrappers import wrap
        if run is None:
            raise ValueError("Pass the run to wrap(): ev.wrap(client, run=run)")
        return wrap(client, run, expected)

    def monitor(
        self,
        client,
        judges: list | None = None,
        validators: list | None = None,
        scorers: list | None = None,
        score_threshold: float = 0.5,
        ghost: bool | str | dict = False,
        provider_keys: dict[str, str] | None = None,
        eval_id: str | None = None,
    ):
        """Silently monitor an OpenAI or Anthropic client in production.

        Captures every LLM call without printing anything or changing behavior.
        Data saves incrementally to .evalora/monitor/. Judges run in background.

            client = ev.monitor(OpenAI())
            # All calls silently captured from here on

            # On shutdown:
            ev.flush()

        Args:
            client: An OpenAI() or Anthropic() client instance.
            judges: Optional judge presets for background scoring.
            validators: Optional validators to run on each capture.
            scorers: Optional scorer functions.
            ghost: Ghost mode for redacting captured data.
            provider_keys: API keys for judge providers.
            eval_id: Optional eval ID for dashboard grouping.
        """
        from evalora.ghost import GhostConfig
        from evalora.monitor import MonitorSession
        from evalora.wrappers import wrap, _extract_prompt

        # Normalize config
        ghost_config = GhostConfig.from_param(ghost)
        if validators:
            validators = _normalize_validators(validators)

        # Create session
        session = MonitorSession(
            client=self,
            judges=judges,
            validators=validators,
            scorers=scorers,
            score_threshold=score_threshold,
            ghost_config=ghost_config,
            provider_keys=provider_keys or {},
            eval_id=eval_id,
            output_dir=self._output_dir,
        )

        # Track active sessions
        if not hasattr(self, "_active_monitors"):
            self._active_monitors: list[MonitorSession] = []
        self._active_monitors.append(session)

        # Create a monitored wrapper using MonitoredRun
        monitored_run = _MonitoredRun(session)
        return wrap(client, monitored_run)

    def flush(self):
        """Finalize all active monitor sessions. Call on shutdown.

        Waits for background judges to complete, writes summary files.
        Returns a list of session summaries.
        """
        if not hasattr(self, "_active_monitors"):
            return []
        summaries = []
        for session in self._active_monitors:
            summaries.append(session.flush())
        self._active_monitors.clear()
        return summaries

    def trend(
        self,
        eval_name: str,
        last: int = 10,
        threshold: float = -0.02,
        fail_on_regression: bool = False,
    ):
        """Analyze score trends across saved runs. Detects regression.

            report = ev.trend("my-eval", last=10)
            if report.regression:
                print(f"Scores declining: {report.slope}")

        Args:
            eval_name: Name to filter runs by.
            last: Number of recent runs to analyze.
            threshold: Slope below this = regression (default -0.02 = 2%/run).
            fail_on_regression: Raise EvaloraError if regression detected (for CI).
        """
        from evalora.output.trend import analyze_trend, TrendReport

        report = analyze_trend(
            eval_name,
            output_dir=self._output_dir,
            last=last,
            threshold=threshold,
        )

        if self._verbose:
            from evalora.output.display import console
            if report.runs:
                console.print(f"\n[bold]Trend: {eval_name}[/bold] ({len(report.runs)} runs)")
                for name, rate in report.runs:
                    bar = "█" * int(rate * 20)
                    console.print(f"  {name:<30} {rate:.0%} {bar}")
                color = "red" if report.regression else "green"
                console.print(f"\n  [{color}]{report.message}[/{color}]")
            else:
                console.print(f"[dim]{report.message}[/dim]")

        if fail_on_regression and report.regression:
            from evalora.core.exceptions import EvaloraError
            raise EvaloraError(report.message)

        return report

    def get_run(self, run_id: str) -> RunStatus:
        if self._local:
            return RunStatus(id=run_id, status="completed")
        data = self._request("GET", f"/runs/{run_id}")
        return RunStatus.from_dict(data)

    def wait(
        self,
        run_id: str,
        poll_interval: float = 2.0,
        timeout: float = 300.0,
        run: Run | None = None,
    ) -> RunStatus:
        if self._local and run:
            # Local mode — no polling, just show results
            from evalora.output.display import print_results

            total = run._log_count
            passed = sum(1 for i in run._logged_items if i.get("passed") is True)
            failed = sum(1 for i in run._logged_items if i.get("passed") is False)
            ungraded = sum(1 for i in run._logged_items if i.get("passed") is None)

            status = RunStatus(
                id=run_id,
                status="completed",
                total=total,
                passed=passed,
                failed=failed,
                needs_review=ungraded,
            )
            if self._verbose:
                print_results(status, run=run)
            return status

        if self._verbose:
            from evalora.output.display import wait_with_spinner, print_results

            status = wait_with_spinner(
                get_status=lambda: self.get_run(run_id),
                poll_interval=poll_interval,
                timeout=timeout,
            )
            print_results(status, run=run)
            return status

        import time

        terminal = {"completed", "failed", "canceled"}
        start = time.monotonic()

        while True:
            status = self.get_run(run_id)
            if status.status in terminal:
                return status
            if status.total > 0:
                in_flight = status.total - status.passed - status.failed - status.needs_review
                if in_flight <= 0:
                    return status
            if time.monotonic() - start >= timeout:
                return status
            time.sleep(poll_interval)

    def _get_format_instruction(self, eval_id: str | None = None) -> str:
        import logging
        from evalora.core.formatting import build_format_instruction, SHORT_ANSWER_INSTRUCTION

        if self._local or not eval_id:
            return SHORT_ANSWER_INSTRUCTION

        try:
            data = self._request("GET", f"/evals/{eval_id}/config")
            config = data.get("config", {})
            return build_format_instruction(
                response_format=config.get("responseFormat"),
                valid_answers=config.get("validAnswers"),
            )
        except (ApiError, AuthError, httpx.HTTPError) as exc:
            logging.debug("Failed to fetch eval config: %s", exc)
            return SHORT_ANSWER_INSTRUCTION

    def _get_dataset_items(self, dataset_id: str | None) -> list:
        from evalora.core.types import DatasetItem

        if self._local or not dataset_id:
            return []

        if self._verbose:
            from evalora.output.display import print_fetching_dataset, print_dataset_loaded
            print_fetching_dataset(dataset_id)

        data = self._request("GET", f"/datasets/{dataset_id}")
        items = [DatasetItem.from_dict(item) for item in data.get("items", [])]

        if self._verbose:
            print_dataset_loaded(len(items))

        return items

    def _run_provider_on_items(
        self,
        provider: Provider,
        items: list[dict],
        system_prompt: str | None,
    ) -> list[dict]:
        from evalora.providers.base import Provider

        if not isinstance(provider, Provider):
            raise TypeError(
                f"Expected a Provider instance (e.g. OpenAIProvider, AnthropicProvider), "
                f"got {type(provider).__name__!r}. "
                "See: from evalora.providers import OpenAIProvider"
            )

        def process_item(item: dict) -> dict:
            prompt = item["prompt"]
            if "response" in item and item["response"]:
                return item

            result = provider.complete(prompt, system_prompt=system_prompt)
            return {
                **item,
                "response": result.response,
                "metadata": {
                    **(item.get("metadata") or {}),
                    "_provider": provider.name(),
                    "_model": getattr(provider, "_model", None),
                    "_input_tokens": result.input_tokens,
                    "_output_tokens": result.output_tokens,
                    "_latency_ms": result.latency_ms,
                },
            }

        if self._parallel:
            from concurrent.futures import ThreadPoolExecutor

            with ThreadPoolExecutor(max_workers=self._max_workers) as pool:
                return list(pool.map(process_item, items))

        return [process_item(item) for item in items]

    def _format_items(self, items: list[dict], ghost_config: GhostConfig | None = None) -> list[dict]:
        gc = ghost_config or GhostConfig.from_param(False)
        return [
            {
                "prompt": gc.redact("prompt", item["prompt"]) or "",
                "response": gc.redact("response", item.get("response", "")) or "",
                **({"expected": gc.redact("expected", item["expected"])} if "expected" in item else {}),
                **({"category": item["category"]} if "category" in item else {}),
                **({"metadata": item["metadata"]} if "metadata" in item else {}),
            }
            for item in items
        ]

    def _log_item(
        self,
        run_id: str,
        prompt: str,
        response: str,
        expected: str | None = None,
        category: str | None = None,
        metadata: dict | None = None,
        scorer_results: dict | None = None,
        similarity_score: float | None = None,
    ) -> str:
        if self._local:
            import uuid as _uuid
            return f"local-item-{_uuid.uuid4().hex[:8]}"

        body: dict = {"prompt": prompt, "response": response}
        if expected is not None:
            body["expected"] = expected
        if category is not None:
            body["category"] = category
        if metadata is not None:
            body["metadata"] = metadata
        if scorer_results:
            body["scorerResults"] = scorer_results
        if similarity_score is not None:
            body["similarityScore"] = similarity_score

        data = self._request("POST", f"/runs/{run_id}/items", json=body)
        return data["id"]

    def _complete_run(self, run_id: str) -> RunStatus:
        if self._local:
            return RunStatus(id=run_id, status="completed")

        data = self._request("POST", f"/runs/{run_id}/complete")
        return RunStatus.from_dict(data)

    def compare(self, run_a_id: str, run_b_id: str) -> ComparisonResult:
        """Compare two runs and return the delta.

        Args:
            run_a_id: ID of the first (baseline) run.
            run_b_id: ID of the second (comparison) run.

        Returns:
            ComparisonResult with per-item diffs and aggregate delta.
        """
        if self._local:
            raise ValueError(
                "compare() requires an API connection. "
                "Initialize with an API key: Evalora(api_key='evk_...'). "
                "Get a key at https://evalora.dev/dashboard"
            )

        data = self._request(
            "GET",
            f"/runs/compare?runA={run_a_id}&runB={run_b_id}",
        )
        return ComparisonResult.from_dict(data)

    def close(self):
        if self._http:
            self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class _MonitoredRun:
    """Lightweight adapter that makes MonitorSession compatible with wrap().

    The wrappers expect an object with a log() method. This routes
    log() calls to MonitorSession.capture() silently.
    """

    def __init__(self, session):
        from evalora.monitor import MonitorSession
        self._session: MonitorSession = session
        self._log_count = 0
        self._logged_items: list[dict] = []
        self._client = type("_Silent", (), {"_verbose": False})()

    def log(self, *, prompt, response, expected=None, category=None, metadata=None):
        """Route to MonitorSession.capture(). Compatible with wrapper interface."""
        # Auto-extract response objects
        if not isinstance(response, str):
            from evalora.core.extraction import extract_result
            text, extracted_meta = extract_result(response)
            response = text
            if extracted_meta and not metadata:
                metadata = extracted_meta
            elif extracted_meta and metadata:
                metadata = {**extracted_meta, **metadata}

        self._session.capture(prompt, response, metadata)
        self._log_count += 1
        return f"mon-item-{self._log_count}"


def _normalize_validators(raw: list) -> list:
    """Resolve string validator names to built-in functions. Callables pass through."""
    from evalora.scoring.validators import (
        not_empty, no_refusal, expects_refusal, no_profanity, is_json,
    )

    BUILTINS = {
        "not_empty": not_empty,
        "no_refusal": no_refusal,
        "expects_refusal": expects_refusal,
        "no_profanity": no_profanity,
        "is_json": is_json,
    }
    result = []
    for v in raw:
        if isinstance(v, str):
            if v in BUILTINS:
                result.append(BUILTINS[v])
            else:
                available = ", ".join(BUILTINS.keys())
                raise ValueError(f"Unknown validator: '{v}'. Available: {available}")
        elif callable(v):
            result.append(v)
        else:
            raise ValueError(f"Validator must be callable or string name, got: {type(v)}")
    return result
