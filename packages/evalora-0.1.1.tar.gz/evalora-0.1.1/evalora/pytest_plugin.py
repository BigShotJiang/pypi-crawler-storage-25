"""Pytest plugin for Evalora evals.

Usage in conftest.py:
    pytest_plugins = ["evalora.pytest_plugin"]

Or just use the fixture directly:
    def test_accuracy(evalora_run):
        status = evalora_run.eval_each("questions.csv", fn=ask)
        assert status.passed / status.total >= 0.9

Fixtures:
    evalora       — Evalora client (local mode, verbose=False)
    evalora_run   — A fresh Run for each test
"""

from __future__ import annotations

import pytest


@pytest.fixture
def evalora():
    """Evalora client in local mode for testing."""
    from evalora.client import Evalora
    return Evalora(local=True, verbose=False)


@pytest.fixture
def evalora_run(tmp_path):
    """A fresh Evalora run for each test, with tmp output dir."""
    from evalora.client import Evalora
    ev = Evalora(local=True, verbose=False, output=str(tmp_path / ".evalora"))
    return ev.run()


@pytest.fixture
def evalora_output(evalora, tmp_path):
    """Evalora client with output dir set to a temp path."""
    from evalora.client import Evalora
    return Evalora(local=True, verbose=False, output=str(tmp_path / ".evalora"))
