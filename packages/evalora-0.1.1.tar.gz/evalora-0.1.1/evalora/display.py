"""Backward-compatible re-export. Canonical location: evalora/output/display.py"""
from evalora.output.display import *  # noqa: F401,F403
