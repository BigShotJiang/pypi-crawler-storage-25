"""Backward-compatible re-export. Canonical location: evalora/scoring/pairwise.py"""
from evalora.scoring.pairwise import *  # noqa: F401,F403
