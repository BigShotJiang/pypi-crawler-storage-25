"""Eval templates — pre-configured judge, validator, and criteria combos.

Usage:
    from evalora import Evalora
    from evalora.templates import rag_quality

    ev = Evalora()
    run = ev.run(**rag_quality())
    run.eval_each("questions.csv", fn=ask)

Or use by name:
    run = ev.run(template="rag-quality")
"""

from evalora.templates.rag_quality import rag_quality
from evalora.templates.chatbot import chatbot
from evalora.templates.code_gen import code_gen
from evalora.templates.summarization import summarization
from evalora.templates.translation import translation
from evalora.templates.safety_audit import safety_audit
from evalora.templates.classification import classification

TEMPLATES = {
    "rag-quality": rag_quality,
    "rag_quality": rag_quality,
    "chatbot": chatbot,
    "code-gen": code_gen,
    "code_gen": code_gen,
    "summarization": summarization,
    "translation": translation,
    "safety-audit": safety_audit,
    "safety_audit": safety_audit,
    "classification": classification,
}

__all__ = [
    "rag_quality",
    "chatbot",
    "code_gen",
    "summarization",
    "translation",
    "safety_audit",
    "classification",
    "TEMPLATES",
]
