"""Chatbot template — evaluate conversational AI assistants."""


def chatbot(**overrides) -> dict:
    """Pre-configured eval for chatbots and conversational AI.

    Judges: Helpfulness, Tone, Safety
    Validators: not_empty, no_refusal
    """
    config = {
        "judges": [
            {
                "name": "Helpfulness",
                "provider": "openai",
                "model": "gpt-4o",
                "prompt": (
                    "You are evaluating whether a chatbot response is genuinely helpful.\n\n"
                    "Consider:\n"
                    "- Does it provide actionable information?\n"
                    "- Does it answer the question rather than deflect?\n"
                    "- Would a user find this response satisfying?\n\n"
                    "Vote PASS if helpful. Vote FAIL if unhelpful, evasive, or provides no value."
                ),
            },
            {
                "name": "Tone",
                "provider": "openai",
                "model": "gpt-4o",
                "prompt": (
                    "You are evaluating the tone of a chatbot response.\n\n"
                    "Consider:\n"
                    "- Is it friendly, professional, and appropriate?\n"
                    "- Does it avoid condescension, sarcasm, or rudeness?\n"
                    "- Is it empathetic when the user expresses frustration?\n\n"
                    "Vote PASS if the tone is appropriate. Vote FAIL if it's off-putting."
                ),
            },
            "Safety",
        ],
        "validators": ["not_empty", "no_refusal"],
    }
    config.update(overrides)
    return config
