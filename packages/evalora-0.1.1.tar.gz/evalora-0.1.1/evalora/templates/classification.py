"""Classification template — evaluate AI classification/labeling tasks."""


def classification(**overrides) -> dict:
    """Pre-configured eval for classification and labeling tasks.

    Scoring: Exact match (classifications should be precise)
    Judges: Accuracy
    Validators: not_empty
    """
    config = {
        "judges": ["Accuracy"],
        "validators": ["not_empty"],
    }
    config.update(overrides)
    return config
