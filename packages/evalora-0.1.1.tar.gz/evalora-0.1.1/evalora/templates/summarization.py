"""Summarization template — evaluate AI-generated summaries."""


def summarization(**overrides) -> dict:
    """Pre-configured eval for text summarization.

    Judges: Rubric with faithfulness, coverage, conciseness criteria
    Validators: not_empty
    """
    config = {
        "judges": [
            {
                "name": "Summary Quality",
                "provider": "openai",
                "model": "gpt-4o",
                "criteria": [
                    {
                        "name": "faithfulness",
                        "description": "Does the summary only contain information from the original text?",
                        "weight": 2,
                        "anchors": {
                            1: "Fabricates information not in the source",
                            3: "Mostly faithful with minor additions",
                            5: "Perfectly faithful to the source",
                        },
                    },
                    {
                        "name": "coverage",
                        "description": "Does the summary capture all key points from the original?",
                        "weight": 2,
                        "anchors": {
                            1: "Misses most key points",
                            3: "Covers main points but misses some",
                            5: "Covers all key points",
                        },
                    },
                    {
                        "name": "conciseness",
                        "description": "Is the summary appropriately brief without losing meaning?",
                        "weight": 1,
                    },
                ],
                "pass_threshold": 3.5,
            },
        ],
        "validators": ["not_empty"],
    }
    config.update(overrides)
    return config
