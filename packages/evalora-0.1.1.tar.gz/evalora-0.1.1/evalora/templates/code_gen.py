"""Code generation template — evaluate AI-generated code."""


def code_gen(**overrides) -> dict:
    """Pre-configured eval for code generation tasks.

    Judges: Correctness, Clarity (rubric with criteria)
    Validators: not_empty
    """
    config = {
        "judges": [
            {
                "name": "Correctness",
                "provider": "openai",
                "model": "gpt-4o",
                "prompt": (
                    "You are evaluating whether AI-generated code is correct.\n\n"
                    "Consider:\n"
                    "- Does the code solve the stated problem?\n"
                    "- Would it run without syntax errors?\n"
                    "- Does it handle edge cases mentioned in the prompt?\n"
                    "- If an expected answer is provided, does the code match the intent?\n\n"
                    "Vote PASS if the code is correct. Vote FAIL if it has bugs or doesn't solve the problem."
                ),
            },
            {
                "name": "Code Quality",
                "provider": "openai",
                "model": "gpt-4o",
                "criteria": [
                    {
                        "name": "readability",
                        "description": "Is the code clean, well-named, and easy to follow?",
                        "anchors": {1: "Unreadable", 3: "Acceptable", 5: "Excellent"},
                    },
                    {
                        "name": "efficiency",
                        "description": "Does the code use appropriate data structures and avoid unnecessary work?",
                    },
                    {
                        "name": "best_practices",
                        "description": "Does the code follow language idioms and common conventions?",
                    },
                ],
                "pass_threshold": 3.0,
            },
        ],
        "validators": ["not_empty"],
    }
    config.update(overrides)
    return config
