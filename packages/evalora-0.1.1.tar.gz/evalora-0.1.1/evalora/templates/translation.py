"""Translation template — evaluate AI translations."""


def translation(**overrides) -> dict:
    """Pre-configured eval for translation tasks.

    Judges: Rubric with accuracy, fluency, preservation criteria
    Scoring: Semantic similarity (if embedding key provided)
    """
    config = {
        "judges": [
            {
                "name": "Translation Quality",
                "provider": "openai",
                "model": "gpt-4o",
                "criteria": [
                    {
                        "name": "accuracy",
                        "description": "Does the translation preserve the original meaning?",
                        "weight": 3,
                        "anchors": {
                            1: "Meaning completely changed",
                            3: "Mostly accurate with some errors",
                            5: "Perfect meaning preservation",
                        },
                    },
                    {
                        "name": "fluency",
                        "description": "Does the translation read naturally in the target language?",
                        "weight": 2,
                        "anchors": {
                            1: "Unnatural, clearly machine-translated",
                            3: "Readable but slightly awkward",
                            5: "Reads like native text",
                        },
                    },
                    {
                        "name": "style_preservation",
                        "description": "Does the translation maintain the tone and style of the original?",
                        "weight": 1,
                    },
                ],
                "pass_threshold": 3.5,
            },
        ],
        "validators": ["not_empty"],
    }
    config.update(overrides)
    return config
