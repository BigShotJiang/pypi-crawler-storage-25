"""RAG quality template — evaluate retrieval-augmented generation pipelines."""


def rag_quality(**overrides) -> dict:
    """Pre-configured eval for RAG pipelines.

    Judges: Faithfulness, Relevance, Completeness
    Validators: not_empty
    """
    config = {
        "judges": [
            {
                "name": "Faithfulness",
                "provider": "openai",
                "model": "gpt-4o",
                "prompt": (
                    "You are evaluating whether an AI response is faithful to the provided context.\n\n"
                    "The response should ONLY contain information that can be derived from the context "
                    "or prompt. Any claims not supported by the provided information are hallucinations.\n\n"
                    "Vote PASS if the response is faithful. Vote FAIL if it contains unsupported claims."
                ),
            },
            {
                "name": "Relevance",
                "provider": "openai",
                "model": "gpt-4o",
                "prompt": (
                    "You are evaluating whether an AI response is relevant to the user's question.\n\n"
                    "Consider:\n"
                    "- Does the response directly answer what was asked?\n"
                    "- Is the information useful and on-topic?\n"
                    "- Does it avoid irrelevant tangents?\n\n"
                    "Vote PASS if relevant. Vote FAIL if off-topic or unhelpful."
                ),
            },
            {
                "name": "Completeness",
                "provider": "openai",
                "model": "gpt-4o",
                "prompt": (
                    "You are evaluating whether an AI response completely answers the question.\n\n"
                    "Consider:\n"
                    "- Are all parts of the question addressed?\n"
                    "- Is there missing information the user would need?\n\n"
                    "Vote PASS if complete. Vote FAIL if key information is missing."
                ),
            },
        ],
        "validators": ["not_empty"],
    }
    config.update(overrides)
    return config
