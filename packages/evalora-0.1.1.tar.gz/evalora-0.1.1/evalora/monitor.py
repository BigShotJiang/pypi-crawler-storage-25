"""Silent production monitoring — capture LLM calls without changing code.

Usage:
    from evalora import Evalora
    from openai import OpenAI

    ev = Evalora(verbose=False)
    client = ev.monitor(OpenAI())

    # Existing chatbot code — UNCHANGED
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": user_input}],
    )
    # ^ silently captured to .evalora/monitor/

    # Optional: background scoring
    client = ev.monitor(OpenAI(), judges=["Accuracy", "Safety"],
                        provider_keys={"openai": "sk-..."})

    # On shutdown
    ev.flush()
"""

from __future__ import annotations

import json
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

from evalora.core.constants import DEFAULT_OUTPUT_DIR
from evalora.core.extraction import extract_result
from evalora.core.matching import check_match
from evalora.ghost import GhostConfig

if TYPE_CHECKING:
    from evalora.client import Evalora

__all__ = ["MonitorSession"]


class MonitorSession:
    """Silent production monitoring session.

    Captures every LLM call, saves incrementally to JSONL,
    optionally runs judges in background threads.
    Never prints anything.
    """

    def __init__(
        self,
        client: Evalora,
        judges: list | None = None,
        validators: list | None = None,
        scorers: list | None = None,
        score_threshold: float = 0.5,
        ghost_config: GhostConfig | None = None,
        provider_keys: dict[str, str] | None = None,
        eval_id: str | None = None,
        output_dir: str | None = None,
    ):
        self.session_id = f"mon-{uuid.uuid4().hex[:12]}"
        self._client = client
        self._judges = judges or []
        self._validators = validators or []
        self._scorers = scorers or []
        self._score_threshold = score_threshold
        self._ghost_config = ghost_config or GhostConfig.from_param(False)
        self._provider_keys = provider_keys or {}
        self._eval_id = eval_id
        self._output_dir = output_dir

        self._items: list[dict] = []
        self._lock = threading.Lock()
        self._capture_count = 0
        self._total_input_tokens = 0
        self._total_output_tokens = 0
        self._start_time = time.monotonic()

        # Background judge pool
        self._judge_pool: ThreadPoolExecutor | None = None
        if self._judges:
            self._judge_pool = ThreadPoolExecutor(max_workers=3, thread_name_prefix="evalora-judge")
        self._pending_judges = 0
        self._judge_lock = threading.Lock()

        # Ensure output directory exists
        self._monitor_dir = Path(self._output_dir or DEFAULT_OUTPUT_DIR) / "monitor"
        self._monitor_dir.mkdir(parents=True, exist_ok=True)
        self._jsonl_path = self._monitor_dir / f"{self.session_id}.jsonl"

    def capture(self, prompt: str, response: str, metadata: dict | None = None):
        """Capture a single LLM call. Non-blocking. Thread-safe."""
        timestamp = datetime.now(timezone.utc).isoformat()

        # Extract tokens
        input_tokens = 0
        output_tokens = 0
        model = None
        if metadata:
            input_tokens = metadata.get("_input_tokens", 0) or 0
            output_tokens = metadata.get("_output_tokens", 0) or 0
            model = metadata.get("_model")

        # Run validators (fast, synchronous)
        validator_reason = None
        passed = None  # no expected = ungraded
        if self._validators:
            for i, validator in enumerate(self._validators):
                try:
                    if not validator(response):
                        name = getattr(validator, "__name__", None)
                        label = name if name and name != "<lambda>" else f"#{i + 1}"
                        passed = False
                        validator_reason = f"Validator failed: {label}"
                        break
                except Exception as exc:
                    name = getattr(validator, "__name__", None)
                    label = name if name and name != "<lambda>" else f"#{i + 1}"
                    passed = False
                    validator_reason = f"Validator error ({label}): {exc}"
                    break

        # Run scorers (fast, synchronous)
        scorer_results = {}
        if self._scorers:
            import inspect
            for i, scorer in enumerate(self._scorers):
                sname = getattr(scorer, "__name__", None)
                label = sname if sname and sname != "<lambda>" else f"scorer_{i + 1}"
                try:
                    sig = inspect.signature(scorer)
                    score = scorer(response, None) if len(sig.parameters) >= 2 else scorer(response)
                    score = max(0.0, min(1.0, float(score)))
                    scorer_results[label] = round(score, 4)
                except Exception:
                    scorer_results[label] = 0.0
            if scorer_results:
                avg = sum(scorer_results.values()) / len(scorer_results)
                if avg < self._score_threshold:
                    passed = False

        # Apply ghost redaction
        gc = self._ghost_config
        redacted_prompt = gc.redact("prompt", prompt)
        redacted_response = gc.redact("response", response)
        redacted_model = gc.redact_model(model)

        item = {
            "timestamp": timestamp,
            "prompt": redacted_prompt,
            "response": redacted_response,
            "model": redacted_model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "passed": passed,
            **({"validator_reason": validator_reason} if validator_reason else {}),
            **({"scores": scorer_results} if scorer_results else {}),
        }

        item_index = None
        with self._lock:
            item_index = len(self._items)
            self._items.append(item)
            self._capture_count += 1
            self._total_input_tokens += input_tokens
            self._total_output_tokens += output_tokens

        # Append to JSONL (fast, append-only)
        self._append_jsonl(item)

        # Submit background judge if configured and validator didn't fail
        if self._judge_pool and self._judges and passed is not False:
            with self._judge_lock:
                self._pending_judges += 1
            self._judge_pool.submit(
                self._run_judge_for_item, item_index, prompt, response, model
            )

    def _append_jsonl(self, item: dict):
        """Append a single item to the JSONL file. Thread-safe via append mode."""
        with open(self._jsonl_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(item, default=str) + "\n")

    def _run_judge_for_item(self, item_index: int, prompt: str, response: str, model: str | None):
        """Run judges on a single item in a background thread."""
        try:
            from evalora.scoring.judge_resolver import resolve_judges
            from evalora.scoring.rubric import normalize_criteria, build_criteria_prompt

            resolved = resolve_judges(self._judges)
            verdicts = []

            for judge in resolved:
                provider_name = judge.get("provider", "openai")
                judge_model = judge.get("model", "gpt-4o")
                judge_prompt = judge.get("prompt", "")
                judge_name = judge.get("name", "")
                scoring = judge.get("scoring", "")
                raw_criteria = judge.get("criteria", [])
                criteria = normalize_criteria(raw_criteria)
                pass_threshold = judge.get("pass_threshold", 3.5)

                if not scoring:
                    scoring = "rubric" if criteria else "binary"

                if not judge_prompt and criteria:
                    descs = []
                    for c in criteria:
                        d = c.get("description", "")
                        descs.append(f"- {c['name']}: {d}" if d else f"- {c['name']}")
                    judge_prompt = "Evaluate the response on these criteria:\n" + "\n".join(descs)

                api_key = judge.get("api_key", "") or self._provider_keys.get(provider_name, "")
                if not api_key:
                    continue

                if scoring == "rubric" and criteria:
                    criteria_block = build_criteria_prompt(criteria)
                    scores_example = ", ".join(f'"{c["name"]}": 4' for c in criteria)
                    system_prompt = (
                        f"You are {judge_name}, an AI judge.\n\n"
                        f"Grading instructions:\n{judge_prompt}\n\n"
                        f"Score each criterion from 1 (worst) to 5 (best).\n\n"
                        f"{criteria_block}\n\n"
                        f"Respond with ONLY a JSON object:\n"
                        f'{{"scores": {{{scores_example}}}, "reason": "brief explanation"}}'
                    )
                else:
                    system_prompt = (
                        f"You are {judge_name}, an AI judge.\n\n"
                        f"Grading instructions:\n{judge_prompt}\n\n"
                        'Respond with ONLY a JSON object:\n'
                        '{"vote": "pass" or "fail", "reason": "brief explanation"}'
                    )

                user_message = f"Prompt: {prompt}\nResponse: {response}"

                try:
                    if provider_name == "openai":
                        from evalora.providers.openai_provider import OpenAIProvider
                        p = OpenAIProvider(model=judge_model, api_key=api_key, temperature=0.0, max_tokens=512)
                        result = p.complete(user_message, system_prompt=system_prompt)
                    elif provider_name == "anthropic":
                        from evalora.providers.anthropic_provider import AnthropicProvider
                        p = AnthropicProvider(model=judge_model, api_key=api_key, temperature=0.0, max_tokens=512)
                        result = p.complete(user_message, system_prompt=system_prompt)
                    else:
                        continue

                    # Parse judge response
                    text = result.response
                    start = text.find("{")
                    end = text.rfind("}") + 1
                    if start >= 0 and end > start:
                        parsed = json.loads(text[start:end])
                        vote = parsed.get("vote", "fail") if scoring == "binary" else None
                        reason = parsed.get("reason", "")

                        if scoring == "rubric" and criteria:
                            scores = parsed.get("scores", {})
                            total_weight = sum(c.get("weight", 1) for c in criteria)
                            weighted = sum(scores.get(c["name"], 1) * c.get("weight", 1) for c in criteria)
                            avg = weighted / total_weight if total_weight else 0
                            vote = "pass" if avg >= pass_threshold else "fail"
                            verdicts.append({"judge": judge_name, "vote": vote, "reason": reason, "scores": scores, "avg": round(avg, 2)})
                        else:
                            vote = "pass" if parsed.get("vote") == "pass" else "fail"
                            verdicts.append({"judge": judge_name, "vote": vote, "reason": reason})
                except Exception:
                    verdicts.append({"judge": judge_name, "vote": "error", "reason": "Judge unavailable"})

            # Update item with verdicts
            if verdicts:
                gc = self._ghost_config
                if gc.judge_reasoning:
                    for v in verdicts:
                        v["reason"] = gc.redact("judge_reasoning", v["reason"]) or ""

                with self._lock:
                    if item_index < len(self._items):
                        self._items[item_index]["judge_verdicts"] = verdicts
                        passes = sum(1 for v in verdicts if v["vote"] == "pass")
                        fails = sum(1 for v in verdicts if v["vote"] == "fail")
                        if passes > fails:
                            self._items[item_index]["passed"] = True
                        elif fails > passes:
                            self._items[item_index]["passed"] = False
        finally:
            with self._judge_lock:
                self._pending_judges -= 1

    def flush(self):
        """Finalize the session. Wait for background judges. Write summary."""
        # Wait for all background judges to complete
        if self._judge_pool:
            self._judge_pool.shutdown(wait=True)
            self._judge_pool = None

        # Write summary
        total = len(self._items)
        passed = sum(1 for i in self._items if i.get("passed") is True)
        failed = sum(1 for i in self._items if i.get("passed") is False)
        ungraded = total - passed - failed

        elapsed = time.monotonic() - self._start_time

        summary = {
            "session_id": self.session_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "duration_seconds": round(elapsed, 2),
            "total": total,
            "passed": passed,
            "failed": failed,
            "ungraded": ungraded,
            "pass_rate": f"{(passed / total * 100):.1f}%" if total else "0%",
            "tokens": {
                "input": self._total_input_tokens,
                "output": self._total_output_tokens,
                "total": self._total_input_tokens + self._total_output_tokens,
            },
            "judges": [j.get("name", j) if isinstance(j, dict) else j for j in self._judges] if self._judges else None,
            "ghost_mode": self._ghost_config.mode if self._ghost_config.enabled else None,
        }

        summary_path = self._monitor_dir / f"{self.session_id}-summary.json"
        summary_path.write_text(json.dumps(summary, indent=2, default=str))

        return summary

    def get_results(self):
        """Get current results without finalizing."""
        with self._lock:
            total = len(self._items)
            passed = sum(1 for i in self._items if i.get("passed") is True)
            failed = sum(1 for i in self._items if i.get("passed") is False)
            return {
                "session_id": self.session_id,
                "total": total,
                "passed": passed,
                "failed": failed,
                "pending_judges": self._pending_judges,
                "items": list(self._items),
            }

    @property
    def items(self):
        with self._lock:
            return list(self._items)

    @property
    def count(self):
        return self._capture_count
