"""Evalora SDK — easy AI evals.

Version: 0.1.0

Quick start:
    from evalora import Evalora

    ev = Evalora()
    run = ev.run(template="chatbot")
    run.eval_each("questions.csv", fn=your_function)
    run.done()

Validators (pass as strings or imports):
    from evalora import not_empty, is_json, no_refusal

Judges (pass as strings or imports):
    from evalora.judges import accuracy, safety, hallucination

Templates:
    run = ev.run(template="rag-quality")  # or "chatbot", "code-gen", "summarization", etc.
"""

from evalora.client import Evalora
from evalora.async_client import AsyncEvalora
from evalora.core.exceptions import EvaloraError, ApiError, AuthError
from evalora.scoring.pairwise import PairwiseResult
from evalora.run import Run
from evalora.core.types import ComparisonResult, DatasetItem, ItemResult, RunStatus
from evalora.wrappers import wrap
from evalora.ghost import GhostConfig
from evalora.monitor import MonitorSession

__version__ = "0.1.1"

# Re-export validators so users can do: from evalora import not_empty
from evalora.scoring.validators import (
    max_length,
    min_length,
    not_empty,
    no_refusal,
    expects_refusal,
    no_profanity,
    is_json,
    contains,
    not_contains,
    matches_regex,
)

__all__ = [
    # Core
    "Evalora",
    "AsyncEvalora",
    "Run",
    "wrap",
    "GhostConfig",
    "MonitorSession",
    # Types
    "ComparisonResult",
    "DatasetItem",
    "ItemResult",
    "RunStatus",
    "PairwiseResult",
    # Exceptions
    "EvaloraError",
    "ApiError",
    "AuthError",
    # Validators
    "max_length",
    "min_length",
    "not_empty",
    "no_refusal",
    "expects_refusal",
    "no_profanity",
    "is_json",
    "contains",
    "not_contains",
    "matches_regex",
]
