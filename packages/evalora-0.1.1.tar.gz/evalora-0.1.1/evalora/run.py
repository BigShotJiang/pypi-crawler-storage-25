"""Run class — handle to an active eval run."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable

from evalora.core.extraction import extract_result as _extract_result
from evalora.core.matching import check_match as _check_match, normalize as _normalize
from evalora.ghost import GhostConfig, GhostServerConfig
from evalora.core.rate_limit import RateLimiter as _RateLimiter
from evalora.eval.file_loader import load_items_from_file as _load_items_from_file
from evalora.output.webhook import send_webhook as _send_webhook
from evalora.core.parsing import parse_items
from evalora.scoring.judge_resolver import resolve_judges as _resolve_judges
from evalora.scoring.rubric import build_criteria_prompt as _build_criteria_prompt
from evalora.scoring.rubric import normalize_criteria as _normalize_criteria
from evalora.core.types import DatasetItem, RunStatus

if TYPE_CHECKING:
    from evalora.client import Evalora
    from evalora.providers.base import Provider


@dataclass
class Run:
    """Handle to an active eval run.

    Methods:
        check(fn, prompt, expected) — call your function, log the result
        log(prompt, response, expected) — log a pre-computed result
        eval_each(items, fn) — run your function on every item
        items() — fetch dataset items from the backend
        complete() — signal no more items coming
        wait() — poll until scoring is done

    Properties:
        url — dashboard link for this run
        duration — seconds elapsed
        model — model name
        tokens — (input, output, total) tuple
        cost — estimated cost
    """

    id: str
    status: str
    _client: Evalora = field(repr=False)
    name: str | None = field(default=None, repr=True)
    _provider: Provider | None = field(default=None, repr=False)
    _system_prompt: str | None = field(default=None, repr=False)
    _ghost_config: GhostConfig = field(default_factory=lambda: GhostConfig.from_param(False), repr=False)
    _ghost_server_config: GhostServerConfig = field(
        default_factory=lambda: GhostServerConfig.from_param(None, GhostConfig.from_param(False)), repr=False
    )
    _dataset_id: str | None = field(default=None, repr=False)
    _eval_id: str | None = field(default=None, repr=False)
    _log_count: int = field(default=0, repr=False)
    _start_time: float = field(default_factory=time.monotonic, repr=False)
    _item_times: list[float] = field(default_factory=list, repr=False)
    _total_input_tokens: int = field(default=0, repr=False)
    _total_output_tokens: int = field(default=0, repr=False)
    _total_cost: float = field(default=0.0, repr=False)
    _model_name: str | None = field(default=None, repr=False)
    _local: bool = field(default=False, repr=False)
    _output_dir: str | None = field(default=None, repr=False)
    _logged_items: list[dict] = field(default_factory=list, repr=False)
    _suppress_per_item: bool = field(default=False, repr=False)
    _eval_total: int | None = field(default=None, repr=False)
    _judge_mode: str = field(default="local", repr=False)
    _judges: list[dict] = field(default_factory=list, repr=False)
    _provider_keys: dict = field(default_factory=dict, repr=False)
    _item_run_ids: list[str] = field(default_factory=list, repr=False)
    _validators: list[Callable] = field(default_factory=list, repr=False)
    _scoring: str = field(default="exact", repr=False)
    _similarity_threshold: float = field(default=0.85, repr=False)
    _embedding_api_key: str | None = field(default=None, repr=False)
    _embedding_model: str = field(default="text-embedding-3-small", repr=False)
    _results_path: str | None = field(default=None, repr=False)
    _resumed: bool = field(default=False, repr=False)
    _resume_completed_hashes: set[str] = field(default_factory=set, repr=False)
    _resume_fingerprint: str = field(default="", repr=False)
    _completed_hashes: list[str] = field(default_factory=list, repr=False)
    _items_fingerprint: str = field(default="", repr=False)
    _server_mode: str | None = field(default=None, repr=False)
    _server_has_server_judges: bool = field(default=False, repr=False)
    _max_cost: float | None = field(default=None, repr=False)
    _cost_exceeded: bool = field(default=False, repr=False)
    _webhook: str | None = field(default=None, repr=False)
    _scorers: list = field(default_factory=list, repr=False)
    _score_threshold: float = field(default=0.5, repr=False)

    # --- Public properties ---

    @property
    def url(self) -> str:
        """Dashboard URL for this run."""
        if self._local:
            return "https://evalora.dev"
        from evalora.client import Evalora

        if not isinstance(self._client, Evalora):
            raise TypeError("Expected Evalora client")
        base = self._client._base_url.replace("://api.", "://").replace(":4000", ":3000")
        return f"{base}/dashboard/runs/{self.id}"

    @property
    def duration(self) -> float:
        """Total elapsed seconds since run creation."""
        return time.monotonic() - self._start_time

    @property
    def model(self) -> str | None:
        """Model name used for this run."""
        return self._model_name

    @property
    def tokens(self) -> tuple[int, int, int]:
        """(input_tokens, output_tokens, total_tokens)."""
        return (
            self._total_input_tokens,
            self._total_output_tokens,
            self._total_input_tokens + self._total_output_tokens,
        )

    @property
    def cost(self) -> float:
        """Estimated cost in USD."""
        return self._total_cost

    @property
    def _ghost(self) -> bool:
        """Backward-compat: True if any ghost mode is active."""
        return self._ghost_config.enabled

    @property
    def results_path(self) -> str | None:
        """Path to the saved JSON results file (available after done()/wait())."""
        return self._results_path

    # --- Public methods ---

    def items(self) -> list[DatasetItem]:
        """Fetch items from the dataset linked to this run."""
        from evalora.client import Evalora

        if not isinstance(self._client, Evalora):
            raise TypeError("Expected Evalora client")
        return self._client._get_dataset_items(self._dataset_id)

    def check(
        self, fn: Callable[[str], object], prompt: str, expected: str | None = None
    ) -> str:
        """Call your function and log the result in one shot.

            answer = run.check(ask, "What is 2+2?", expected="4")

        Return a dict for full stats:

            def ask(prompt):
                r = openai.chat.completions.create(...)
                return {
                    "response": r.choices[0].message.content,
                    "input_tokens": r.usage.prompt_tokens,
                    "output_tokens": r.usage.completion_tokens,
                    "model": r.model,
                }
        """
        item_start = time.monotonic()
        # In exact mode with an expected answer, append format instruction
        # so the LLM responds tersely (easier to match). Skip for judges/semantic.
        effective_prompt = prompt
        if self._scoring == "exact" and expected and not self._judges:
            from evalora.core.formatting import with_format_instruction
            effective_prompt = with_format_instruction(prompt, expected)
        result = fn(effective_prompt)
        item_elapsed = time.monotonic() - item_start
        self._item_times.append(item_elapsed)

        response, metadata = _extract_result(result)
        self.log(prompt=prompt, response=response, expected=expected, metadata=metadata)
        return response

    def log_conversation(
        self,
        *,
        messages: list[dict],
        expected: str | None = None,
        category: str | None = None,
        metadata: dict | None = None,
    ) -> str:
        """Log a multi-turn conversation as a single eval item.

            run.log_conversation(
                messages=[
                    {"role": "user", "content": "What is Python?"},
                    {"role": "assistant", "content": "A programming language."},
                    {"role": "user", "content": "What's it used for?"},
                    {"role": "assistant", "content": "Web, data science, AI, etc."},
                ],
                expected="A comprehensive answer about Python use cases",
            )

        The prompt is built from all user messages, the response is the last assistant message.
        """
        user_parts = []
        response_text = None

        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")
            if role == "user":
                user_parts.append(content)
            elif role == "assistant":
                response_text = content

        if response_text is None:
            raise ValueError(
                "log_conversation() requires at least one assistant message. "
                "No assistant turn found in messages."
            )

        prompt = " → ".join(user_parts) if user_parts else "(conversation)"

        return self.log(
            prompt=prompt,
            response=response_text,
            expected=expected,
            category=category,
            metadata=metadata,
        )

    def log(
        self,
        *,
        prompt: str,
        response: object,
        expected: str | None = None,
        category: str | None = None,
        metadata: dict | None = None,
    ) -> str:
        """Log a single item with a pre-computed response. Returns item ID.

        Args:
            prompt: The input prompt (what you asked the AI).
            response: The AI's output. Accepts:
                - str: plain text ("Paris")
                - OpenAI ChatCompletion: auto-extracts .choices[0].message.content + usage
                - Anthropic Message: auto-extracts .content[0].text + usage
                - dict: {"response": "Paris", "input_tokens": 10, "output_tokens": 5, "model": "gpt-4o"}
            expected: The correct answer (optional). Used for pass/fail scoring.
            category: Tag for grouping results (e.g. "math", "science"). Shows in category breakdown.
            metadata: Extra data to store with this item.

        Returns:
            Item ID (str).
        """
        # Auto-extract from response objects (OpenAI, Anthropic, dict)
        if not isinstance(response, str):
            extracted_text, extracted_meta = _extract_result(response)
            response = extracted_text
            if extracted_meta and not metadata:
                metadata = extracted_meta
            elif extracted_meta and metadata:
                metadata = {**extracted_meta, **metadata}
        from evalora.client import Evalora

        if not isinstance(self._client, Evalora):
            raise TypeError("Expected Evalora client")

        # Accumulate stats from metadata
        if metadata:
            self._total_input_tokens += metadata.get("_input_tokens", 0) or 0
            self._total_output_tokens += metadata.get("_output_tokens", 0) or 0
            if not self._model_name and metadata.get("_model"):
                self._model_name = metadata["_model"]

            from evalora.core.pricing import estimate_cost
            self._total_cost += estimate_cost(
                model=metadata.get("_model") or self._model_name,
                input_tokens=metadata.get("_input_tokens", 0) or 0,
                output_tokens=metadata.get("_output_tokens", 0) or 0,
            )

        # Collect for local results file
        # Determine pass/fail based on scoring mode
        similarity_score = None
        # log() always uses fuzzy matching — the format instruction is only injected
        # by check()/eval_each(), not by log(). Use fuzzy to be forgiving.
        if self._scoring == "semantic" and expected and self._embedding_api_key:
            from evalora.scoring.similarity import compute_similarity
            try:
                similarity_score = compute_similarity(
                    response, expected, self._embedding_api_key,
                    model=self._embedding_model,
                )
                passed = similarity_score >= self._similarity_threshold
            except Exception:
                passed = _check_match(response, expected)
        else:
            passed = _check_match(response, expected)

        # Run validators — if any fail, override passed and record reason
        validator_reason = None
        if self._validators:
            v_passed, v_reason = self._run_validators(response)
            if not v_passed:
                passed = False
                validator_reason = v_reason

        # Run scorers — each returns 0.0-1.0 float
        scorer_results = {}
        if self._scorers:
            scores = self._run_scorers(response, expected)
            scorer_results = scores
            if scores:
                avg_score = sum(scores.values()) / len(scores)
                # Scorers can override pass/fail if below threshold
                if avg_score < self._score_threshold:
                    passed = False

        gc = self._ghost_config
        redacted_prompt = gc.redact("prompt", prompt)
        redacted_response = gc.redact("response", response)
        redacted_expected = gc.redact("expected", expected)

        self._logged_items.append({
            "prompt": redacted_prompt,
            "response": redacted_response,
            "expected": redacted_expected,
            "_real_prompt": prompt,
            "_real_response": response,
            "_real_expected": expected,
            "passed": passed,
            "category": category,
            **({"validator_reason": validator_reason} if validator_reason else {}),
            **({"similarity": similarity_score} if similarity_score is not None else {}),
            **({"scores": scorer_results} if scorer_results else {}),
        })

        if self._client._verbose and not self._suppress_per_item:
            from evalora.output.display import print_log_item
            print_log_item(
                self._log_count, redacted_prompt, redacted_response,
                redacted_expected,
                passed=passed, total=self._eval_total,
                validator_reason=validator_reason,
                similarity=similarity_score,
            )

        self._log_count += 1

        # Send to backend — skip if ghost_server is off
        if not self._ghost_server_config.send_to_server and not self._local:
            import uuid as _uuid
            item_run_id = f"ghost-{_uuid.uuid4().hex[:8]}"
        else:
            item_run_id = self._client._log_item(
                run_id=self.id,
                prompt=redacted_prompt or "",
                response=redacted_response or "",
                expected=redacted_expected,
                category=category,
                metadata=metadata,
                scorer_results=scorer_results or None,
                similarity_score=similarity_score,
            )
        self._item_run_ids.append(item_run_id)

        # Save checkpoint after each successful log
        from evalora.output.checkpoint import save_checkpoint, _hash_prompt

        self._completed_hashes.append(_hash_prompt(prompt))
        if self.name and self._items_fingerprint:
            save_checkpoint(
                self.name,
                self.id,
                self._completed_hashes,
                self._items_fingerprint,
                self._output_dir,
            )

        return item_run_id

    def eval(
        self,
        *,
        prompt: str,
        expected: str | None = None,
        category: str | None = None,
        system_prompt: str | None = None,
    ) -> str:
        """Call the provider block with the prompt, then log the result."""
        from evalora.providers.base import Provider
        from evalora.client import Evalora

        if not isinstance(self._client, Evalora):
            raise TypeError("Expected Evalora client")

        if not self._provider or not isinstance(self._provider, Provider):
            raise ValueError("No provider set. Pass provider= to client.run().")

        effective_system = system_prompt or self._system_prompt

        item_start = time.monotonic()
        result = self._provider.complete(prompt, system_prompt=effective_system)
        item_elapsed = time.monotonic() - item_start
        self._item_times.append(item_elapsed)

        self._total_input_tokens += result.input_tokens
        self._total_output_tokens += result.output_tokens

        from evalora.core.pricing import estimate_cost
        self._total_cost += estimate_cost(
            model=getattr(self._provider, "_model", None) or self._model_name,
            input_tokens=result.input_tokens,
            output_tokens=result.output_tokens,
        )

        # Collect for local results file
        similarity_score = None
        if self._scoring == "semantic" and expected and self._embedding_api_key:
            from evalora.scoring.similarity import compute_similarity
            try:
                similarity_score = compute_similarity(
                    result.response, expected, self._embedding_api_key,
                    model=self._embedding_model,
                )
                passed = similarity_score >= self._similarity_threshold
            except Exception:
                passed = _check_match(result.response, expected)
        else:
            passed = _check_match(result.response, expected)

        # Run validators — if any fail, override passed and record reason
        validator_reason = None
        if self._validators:
            v_passed, v_reason = self._run_validators(result.response)
            if not v_passed:
                passed = False
                validator_reason = v_reason

        gc = self._ghost_config
        r_prompt = gc.redact("prompt", prompt)
        r_response = gc.redact("response", result.response)
        r_expected = gc.redact("expected", expected)

        self._logged_items.append({
            "prompt": r_prompt,
            "response": r_response,
            "expected": r_expected,
            "_real_prompt": prompt,
            "_real_response": result.response,
            "_real_expected": expected,
            "passed": passed,
            "category": category,
            **({"validator_reason": validator_reason} if validator_reason else {}),
            **({"similarity": similarity_score} if similarity_score is not None else {}),
        })

        if self._client._verbose and not self._suppress_per_item:
            from evalora.output.display import print_log_item
            print_log_item(
                self._log_count, r_prompt, r_response, r_expected,
                passed=passed, total=self._eval_total,
                validator_reason=validator_reason,
                similarity=similarity_score,
            )

        self._log_count += 1

        return self._client._log_item(
            run_id=self.id,
            prompt=r_prompt or "",
            response=r_response or "",
            expected=r_expected,
            category=category,
            metadata={
                "_provider": self._provider.name(),
                "_model": getattr(self._provider, "_model", None),
                "_input_tokens": result.input_tokens,
                "_output_tokens": result.output_tokens,
                "_latency_ms": result.latency_ms,
            },
        )

    def eval_each(
        self,
        items: list | str | None = None,
        *,
        fn: Callable[[str], object] | None = None,
        parallel: bool | None = None,
        max_workers: int | None = None,
        raise_on_fail: bool = False,
    ) -> RunStatus:
        """Run your function on every item, log results, complete, and wait.

            run.eval_each(fn=ask)                      # from dataset
            run.eval_each([("Q", "A")], fn=ask)        # inline
            run.eval_each("data.csv", fn=ask)          # from file
            run.eval_each("data.jsonl", fn=ask)        # from JSONL
            run.eval_each(fn=ask, parallel=True)       # 10x faster

        Args:
            items: List of (prompt, expected) tuples, dicts, or a file path (.csv, .json, .jsonl).
            fn: Your AI function. Takes a string prompt, returns a string or response object.
                Async functions are auto-detected and run with asyncio.
            parallel: Run items concurrently (default: False).
            max_workers: Max concurrent workers for parallel mode (default: 10).
            raise_on_fail: Raise EvaloraError if any items fail (useful for CI).

        Returns:
            RunStatus with total, passed, failed, needs_review counts.
        """
        from evalora.client import Evalora

        if not isinstance(self._client, Evalora):
            raise TypeError("Expected Evalora client")

        if fn is None:
            raise ValueError("fn is required — pass your AI function.")

        # Load items from file path
        if isinstance(items, str):
            items = _load_items_from_file(items)

        if items is None:
            items = self.items()

        use_parallel = parallel if parallel is not None else self._client._parallel
        workers = max_workers if max_workers is not None else self._client._max_workers

        # Show mode
        if self._client._verbose and self._server_mode:
            from evalora.output.display import console
            mode_label = self._server_mode.replace("_", " ")
            console.print(f"[dim]Mode: {mode_label} (dashboard)[/dim]")

        parsed = parse_items(items)

        # Compute fingerprint for checkpoint validation
        from evalora.output.checkpoint import _hash_prompt, _fingerprint_items

        all_prompts = [p for p, _ in parsed]
        self._items_fingerprint = _fingerprint_items(all_prompts)

        # Resume: validate fingerprint and skip completed items
        if self._resume_completed_hashes:
            if self._resume_fingerprint and self._resume_fingerprint != self._items_fingerprint:
                # Test set changed — warn and start fresh
                if self._client._verbose:
                    from evalora.output.display import console
                    console.print(
                        "[bold yellow]Test set changed since last checkpoint — starting fresh[/bold yellow]"
                    )
                from evalora.output.checkpoint import clear_checkpoint

                if self.name:
                    clear_checkpoint(self.name, self._output_dir)
                self._resume_completed_hashes = set()
                self._resumed = False
            else:
                original_count = len(parsed)
                parsed = [
                    (p, e)
                    for p, e in parsed
                    if _hash_prompt(p) not in self._resume_completed_hashes
                ]
                skipped = original_count - len(parsed)
                # Carry forward the completed hashes so checkpoint stays consistent
                self._completed_hashes = list(self._resume_completed_hashes)
                if self._client._verbose:
                    from evalora.output.display import console
                    console.print(
                        f"[bold]Resuming:[/bold] skipping {skipped} completed, "
                        f"running {len(parsed)} remaining"
                    )

        # Never modify the user's prompt — their function receives exactly what they passed.
        # Fuzzy matching (_check_match) handles verbose LLM responses.

        expected_count = len(parsed)

        import asyncio
        is_async = asyncio.iscoroutinefunction(fn)

        if is_async:
            self._eval_async(parsed, fn, workers if use_parallel else 1)
        elif use_parallel:
            self._eval_parallel(parsed, fn, workers)
        else:
            self._eval_sequential(parsed, fn)

        # Run local judges — respecting the config hierarchy.
        # Server config is authoritative; local judges are supplementary.
        should_run_local_judges = self._should_run_local_judges()
        if should_run_local_judges:
            supplementary = self._server_mode is not None and self._server_mode != "ai_judge_panel"
            self._run_local_judges(supplementary=supplementary)

        self.complete()
        status = self.wait()

        # Only clear checkpoint if ALL items were processed (not interrupted)
        all_processed = self._log_count >= expected_count
        if self.name and all_processed:
            from evalora.output.checkpoint import clear_checkpoint
            clear_checkpoint(self.name, self._output_dir)

        if raise_on_fail and status.failed > 0:
            from evalora.core.exceptions import EvaloraError
            raise EvaloraError(
                f"Eval failed: {status.failed}/{status.total} items did not pass"
            )

        return status

    def complete(self) -> RunStatus:
        """Signal that no more items are coming."""
        from evalora.client import Evalora

        if not isinstance(self._client, Evalora):
            raise TypeError("Expected Evalora client")

        if self._client._verbose:
            from evalora.output.display import console
            console.print(
                f"\n[bold]Completing run...[/bold] ({self._log_count} items logged)"
            )

        return self._client._complete_run(self.id)

    def done(self) -> RunStatus:
        """Complete the run and wait for results. Shorthand for complete() + wait().

        Also runs local judges if configured (for check()/log() workflows
        where eval_each wasn't used).
        """
        # Run judges if they haven't been run yet (eval_each runs them, but
        # check()/log() workflows skip them — run them here before completing)
        should_run = self._should_run_local_judges()
        if should_run and self._logged_items:
            # Check if judges already ran (eval_each sets judge_verdicts)
            already_ran = any(
                item.get("judge_verdicts") for item in self._logged_items
            )
            if not already_ran:
                supplementary = self._server_mode is not None and self._server_mode != "ai_judge_panel"
                self._run_local_judges(supplementary=supplementary)

        self.complete()
        return self.wait()

    def wait(
        self, poll_interval: float = 2.0, timeout: float = 300.0
    ) -> RunStatus:
        """Wait for scoring to finish. Saves results to local file."""
        from evalora.client import Evalora

        if not isinstance(self._client, Evalora):
            raise TypeError("Expected Evalora client")

        try:
            status = self._client.wait(
                self.id,
                poll_interval=poll_interval,
                timeout=timeout,
                run=self,
            )
        except KeyboardInterrupt:
            if self._client._verbose:
                from evalora.output.display import console
                console.print(
                    "\n[bold yellow]Interrupted![/bold yellow] Fetching partial results..."
                )
            status = self._client.get_run(self.id)
            if self._client._verbose:
                from evalora.output.display import print_results
                print_results(status, run=self)

        self._save_results(status)
        self._send_webhook_notification(status)
        return status

    def _send_webhook_notification(self, status):
        """Send run results to webhook URL if configured."""
        _send_webhook(self, status)

    # --- Internal ---

    def _save_results(self, status: RunStatus):
        """Save run results to a local JSON file with version detection."""
        from evalora.output.results import save_run, _fingerprint, _detect_version
        from pathlib import Path
        from evalora.core.constants import DEFAULT_OUTPUT_DIR

        try:
            base = Path(self._output_dir) if self._output_dir else Path(DEFAULT_OUTPUT_DIR)
            runs_dir = base / "runs"
            fp = _fingerprint(self._logged_items)
            version, prev_run = _detect_version(runs_dir, fp)

            # Strip internal fields before saving to disk
            save_items = [
                {k: v for k, v in item.items() if not k.startswith("_")}
                for item in self._logged_items
            ]

            # Determine source of truth metadata
            local_judges_ran = any(
                item.get("judge_verdicts") for item in save_items
            )
            if self._local or self._server_mode is None:
                source_of_truth = "local"
                sot_note = "Local mode — SDK is the source of truth."
            else:
                source_of_truth = "server"
                sot_note = (
                    "Server scoring is authoritative. "
                    "Local judge results are supplementary."
                    if local_judges_ran
                    else "Server scoring is authoritative."
                )

            file_path = save_run(
                run_id=self.id,
                status=status.status if status else "unknown",
                items=save_items,
                model=self._ghost_config.redact_model(self._model_name),
                ghost_mode=self._ghost_config.mode if self._ghost_config.enabled else None,
                duration=self.duration,
                input_tokens=self._total_input_tokens,
                output_tokens=self._total_output_tokens,
                cost=self._total_cost,
                name=self.name,
                output_dir=self._output_dir,
                source_of_truth=source_of_truth,
                server_mode=self._server_mode,
                local_judges_ran=local_judges_ran,
                sot_note=sot_note,
            )
            self._results_path = str(file_path)

            from evalora.client import Evalora
            if isinstance(self._client, Evalora) and self._client._verbose:
                from evalora.output.display import console
                console.print(f"[dim]Results saved to {file_path}[/dim]")
                console.print(f"[dim]Test version: [bold]{version}[/bold] (fingerprint: {fp})[/dim]")
                if prev_run and prev_run != self.id:
                    console.print(f"[dim]Previous run: {prev_run} — use ev.compare() to diff[/dim]")
        except Exception:
            pass  # Don't fail the run over file IO

    def _eval_sequential(
        self,
        items: list[tuple[str, str | None]],
        fn: Callable[[str], object],
    ):
        total = len(items)
        self._eval_total = total
        use_progress_bar = total > 25 and self._client._verbose

        if use_progress_bar:
            self._suppress_per_item = True

        progress_ctx = None
        try:
            if use_progress_bar:
                from evalora.output.display import create_eval_progress
                progress, task_id = create_eval_progress(total)
                progress_ctx = progress
                progress.start()

            for prompt, expected in items:
                if self._check_cost_guard():
                    break

                effective_prompt = prompt
                if self._scoring == "exact" and expected and not self._judges:
                    from evalora.core.formatting import with_format_instruction
                    effective_prompt = with_format_instruction(prompt, expected)

                item_start = time.monotonic()
                try:
                    result = fn(effective_prompt)
                    response, metadata = _extract_result(result)
                except Exception as exc:
                    response = f"[ERROR] {type(exc).__name__}: {exc}"
                    metadata = None
                item_elapsed = time.monotonic() - item_start
                self._item_times.append(item_elapsed)

                self.log(
                    prompt=prompt,
                    response=response,
                    expected=expected,
                    metadata=metadata,
                )

                if use_progress_bar:
                    avg = sum(self._item_times) / len(self._item_times)
                    progress.update(
                        task_id,
                        completed=self._log_count,
                        avg=f"{avg:.1f}s avg",
                    )
        except KeyboardInterrupt:
            self._print_interrupted()
        finally:
            self._suppress_per_item = False
            self._eval_total = None
            if progress_ctx is not None:
                progress_ctx.stop()

    def _eval_parallel(
        self,
        items: list[tuple[str, str | None]],
        fn: Callable[[str], object],
        max_workers: int,
    ):
        from concurrent.futures import ThreadPoolExecutor, as_completed
        from evalora.client import Evalora

        if not isinstance(self._client, Evalora):
            raise TypeError("Expected Evalora client")

        total = len(items)
        self._eval_total = total
        use_progress_bar = total > 25 and self._client._verbose

        if self._client._verbose:
            from evalora.output.display import console
            console.print(
                f"[bold]Running {total} items in parallel[/bold] "
                f"(max {max_workers} workers)\n"
            )

        if use_progress_bar:
            self._suppress_per_item = True

        def process(prompt: str, expected: str | None):
            effective_prompt = prompt
            if self._scoring == "exact" and expected and not self._judges:
                from evalora.core.formatting import with_format_instruction
                effective_prompt = with_format_instruction(prompt, expected)
            item_start = time.monotonic()
            try:
                result = fn(effective_prompt)
                response, metadata = _extract_result(result)
            except Exception as exc:
                response = f"[ERROR] {type(exc).__name__}: {exc}"
                metadata = None
            item_elapsed = time.monotonic() - item_start
            return prompt, response, expected, item_elapsed, metadata

        progress_ctx = None
        try:
            if use_progress_bar:
                from evalora.output.display import create_eval_progress
                progress, task_id = create_eval_progress(total)
                progress_ctx = progress
                progress.start()

            with ThreadPoolExecutor(max_workers=max_workers) as pool:
                futures = [pool.submit(process, p, e) for p, e in items]
                for future in as_completed(futures):
                    prompt, response, expected, elapsed, metadata = future.result()
                    self._item_times.append(elapsed)
                    if self._check_cost_guard():
                        continue
                    self.log(
                        prompt=prompt, response=response,
                        expected=expected, metadata=metadata,
                    )

                    if use_progress_bar:
                        avg = sum(self._item_times) / len(self._item_times)
                        progress.update(
                            task_id,
                            completed=self._log_count,
                            avg=f"{avg:.1f}s avg",
                        )
        except KeyboardInterrupt:
            self._print_interrupted()
        finally:
            self._suppress_per_item = False
            self._eval_total = None
            if progress_ctx is not None:
                progress_ctx.stop()

    def _eval_async(
        self,
        items: list[tuple[str, str | None]],
        fn,
        max_concurrent: int = 10,
    ):
        """Run an async function on all items using asyncio with a semaphore."""
        import asyncio

        total = len(items)
        self._eval_total = total
        use_progress_bar = total > 25 and self._client._verbose

        if self._client._verbose:
            from evalora.output.display import console
            if max_concurrent > 1:
                console.print(
                    f"[bold]Running {total} items async[/bold] "
                    f"(max {max_concurrent} concurrent)\n"
                )

        if use_progress_bar:
            self._suppress_per_item = True

        sem = asyncio.Semaphore(max_concurrent)

        async def process(prompt: str, expected: str | None):
            effective_prompt = prompt
            if self._scoring == "exact" and expected and not self._judges:
                from evalora.core.formatting import with_format_instruction
                effective_prompt = with_format_instruction(prompt, expected)
            async with sem:
                item_start = time.monotonic()
                try:
                    result = await fn(effective_prompt)
                    response, metadata = _extract_result(result)
                except Exception as exc:
                    response = f"[ERROR] {type(exc).__name__}: {exc}"
                    metadata = None
                item_elapsed = time.monotonic() - item_start
            return prompt, response, expected, item_elapsed, metadata

        async def run_all():
            tasks = [process(p, e) for p, e in items]

            progress_ctx = None
            try:
                if use_progress_bar:
                    from evalora.output.display import create_eval_progress
                    progress, task_id = create_eval_progress(total)
                    progress_ctx = progress
                    progress.start()

                for coro in asyncio.as_completed(tasks):
                    prompt, response, expected, elapsed, metadata = await coro
                    self._item_times.append(elapsed)
                    self.log(
                        prompt=prompt, response=response,
                        expected=expected, metadata=metadata,
                    )
                    if use_progress_bar:
                        avg = sum(self._item_times) / len(self._item_times)
                        progress.update(
                            task_id,
                            completed=self._log_count,
                            avg=f"{avg:.1f}s avg",
                        )
            except KeyboardInterrupt:
                self._print_interrupted()
            finally:
                self._suppress_per_item = False
                self._eval_total = None
                if progress_ctx is not None:
                    progress_ctx.stop()

        # Run in existing loop if available, otherwise create one
        try:
            asyncio.get_running_loop()
            # Already in an async context (Jupyter, FastAPI, etc.)
            # Spawn a new thread with its own event loop
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(asyncio.run, run_all())
                future.result()
        except RuntimeError:
            # No event loop running — safe to use asyncio.run
            asyncio.run(run_all())

    def _check_cost_guard(self) -> bool:
        """Check if cost guard has been exceeded. Returns True if over budget."""
        if self._max_cost is None or self._max_cost <= 0 or self._cost_exceeded:
            return self._cost_exceeded
        # Use 90% threshold to stop BEFORE exceeding, not after
        if self._total_cost >= self._max_cost * 0.9:
            self._cost_exceeded = True
            if self._client._verbose:
                from evalora.output.display import console
                console.print(
                    f"\n[bold yellow]Cost guard triggered:[/bold yellow] "
                    f"${self._total_cost:.4f} >= ${self._max_cost:.2f} budget. "
                    f"Stopping early."
                )
            return True
        return False

    def _run_validators(self, response: str) -> tuple[bool, str | None]:
        """Run all validators on a response.

        Returns (passed, reason). If all pass, returns (True, None).
        If any fails, returns (False, "Validator failed: <name or index>").
        """
        for i, validator in enumerate(self._validators):
            try:
                result = validator(response)
                if not result:
                    name = getattr(validator, "__name__", None)
                    label = name if name and name != "<lambda>" else f"#{i + 1}"
                    return False, f"Validator failed: {label}"
            except Exception as exc:
                name = getattr(validator, "__name__", None)
                label = name if name and name != "<lambda>" else f"#{i + 1}"
                return False, f"Validator error ({label}): {exc}"
        return True, None

    def _run_scorers(self, response: str, expected: str | None = None) -> dict[str, float]:
        """Run all scorer functions. Each returns a 0.0-1.0 float.

        Scorers can accept (response) or (response, expected).
        """
        import inspect

        results = {}
        for i, scorer in enumerate(self._scorers):
            name = getattr(scorer, "__name__", None)
            label = name if name and name != "<lambda>" else f"scorer_{i + 1}"
            try:
                sig = inspect.signature(scorer)
                if len(sig.parameters) >= 2:
                    score = scorer(response, expected)
                else:
                    score = scorer(response)
                score = max(0.0, min(1.0, float(score)))
                results[label] = round(score, 4)
            except Exception as exc:
                results[label] = 0.0
                if self._client._verbose:
                    from evalora.output.display import console
                    console.print(f"[yellow]Scorer '{label}' error: {exc}[/yellow]")
        return results

    def _should_run_local_judges(self) -> bool:
        """Decide whether local judges should run based on the config hierarchy.

        Rules:
        - Local mode (no server): run if judges are configured
        - ai_judge_panel + server judge_mode + no inline judges: skip (workers handle it)
        - ai_judge_panel + local judge_mode: run (fetch configs from server or use inline)
        - ai_judge_panel + server judge_mode + inline judges: run inline (supplementary to server)
        - exact_answer / human_review + inline judges: run (supplementary)
        - No judges configured at all: skip
        """
        # Local mode — SDK is the only source of truth
        if self._local:
            return bool(self._judges)

        # No server mode fetched — fall back to original behavior
        if self._server_mode is None:
            return self._judge_mode == "local" and (bool(self._judges) or not self._local)

        # ai_judge_panel with server-side judges and no inline judges:
        # Workers handle it, nothing to do locally
        if (
            self._server_mode == "ai_judge_panel"
            and self._server_has_server_judges
            and self._judge_mode == "server"
            and not self._judges
        ):
            return False

        # ai_judge_panel with local judge_mode: run local judges (fetch or inline)
        if self._server_mode == "ai_judge_panel" and self._judge_mode == "local":
            return True

        # ai_judge_panel + server judge_mode + inline judges: run inline as supplementary
        if (
            self._server_mode == "ai_judge_panel"
            and self._judge_mode == "server"
            and self._judges
        ):
            return True

        # exact_answer or human_review with inline judges: run as supplementary
        if self._server_mode in ("exact_answer", "human_review") and self._judges:
            return True

        return False

    def _run_local_judges(self, supplementary: bool = False):
        """Run judges locally. Uses inline judges if provided, otherwise fetches from backend."""
        from evalora.client import Evalora

        if not isinstance(self._client, Evalora):
            raise TypeError("Expected Evalora client")

        if self._client._verbose:
            from evalora.output.display import console
            if supplementary:
                console.print(
                    "\n[bold]Running local judges[/bold] "
                    "[dim](supplementary — server scoring is authoritative)[/dim]"
                )
            else:
                console.print("\n[bold]Running local judges...[/bold]")

        # Use inline judges if provided, otherwise fetch from backend
        if self._judges:
            resolved = _resolve_judges(self._judges)
            local_judges = [
                {
                    "id": f"inline-{i}",
                    "name": j.get("name", f"Judge {i + 1}"),
                    "provider": j.get("provider", "openai"),
                    "model": j.get("model", "gpt-4o"),
                    "prompt": j.get("prompt", ""),
                    "api_key": j.get("api_key", ""),
                    "scoring": j.get("scoring", ""),
                    "criteria": j.get("criteria", []),
                    "pass_threshold": j.get("pass_threshold", 3.5),
                    "criterion_thresholds": j.get("criterion_thresholds"),
                }
                for i, j in enumerate(resolved)
            ]
        elif self._eval_id and not self._local:
            try:
                config_data = self._client._request("GET", f"/evals/{self._eval_id}/config")
                config = config_data.get("config", {})
                backend_judges = config.get("judges", [])
                local_judges = [
                    {
                        "id": j.get("id", ""),
                        "name": j.get("name", ""),
                        "provider": j.get("provider", ""),
                        "model": j.get("model", ""),
                        "prompt": j.get("prompt", ""),
                        "api_key": "",
                    }
                    for j in backend_judges
                    if j.get("executionMode", "local") == "local" and j.get("enabled", True)
                ]
            except Exception as exc:
                if self._client._verbose:
                    from evalora.output.display import console
                    console.print(f"[red]Failed to fetch judge config: {exc}[/red]")
                return
        else:
            return

        if not local_judges:
            return

        # Get all logged items with their responses
        items_with_ids = list(zip(self._item_run_ids, self._logged_items))

        if not items_with_ids:
            return

        # Build all judgment tasks: (item_run_id, item, judge)
        # Skip items that already failed validators — no point wasting judge calls
        tasks = []
        for item_run_id, item in items_with_ids:
            if item.get("validator_reason"):
                continue
            for judge in local_judges:
                tasks.append((item_run_id, item, judge))

        if not tasks:
            return

        total_judgments = len(tasks)

        if self._client._verbose:
            from evalora.output.display import console
            judge_names = ", ".join(j["name"] for j in local_judges)
            console.print(f"  Judges: [magenta]{judge_names}[/magenta]")
            console.print(f"  {total_judgments} judgments ({len(items_with_ids)} items × {len(local_judges)} judges)\n")

        def execute_judgment(task):
            item_run_id, item, judge = task
            provider_name = judge.get("provider", "")
            model = judge.get("model", "")
            judge_prompt = judge.get("prompt", "")
            judge_id = judge.get("id", "")
            judge_name = judge.get("name", "")
            pass_threshold = judge.get("pass_threshold", 3.5)
            criterion_thresholds = judge.get("criterion_thresholds")
            api_key = judge.get("api_key", "") or self._provider_keys.get(provider_name, "")

            # Normalize criteria: strings → dicts, auto-detect rubric mode
            raw_criteria = judge.get("criteria", [])
            criteria = _normalize_criteria(raw_criteria)
            scoring = judge.get("scoring", "")
            if not scoring:
                scoring = "rubric" if criteria else "binary"

            if not api_key:
                return {
                    "itemRunId": item_run_id,
                    "judgeConfigId": judge_id,
                    "vote": "error",
                    "reason": f"No API key for provider '{provider_name}'",
                    "rawOutput": {},
                    "_judgeName": judge_name,
                    "_scoring": scoring,
                }

            # Auto-generate prompt from criteria descriptions when no prompt given
            if not judge_prompt and criteria:
                descs = []
                for c in criteria:
                    d = c.get("description", "")
                    descs.append(f"- {c['name']}: {d}" if d else f"- {c['name']}")
                judge_prompt = "Evaluate the response on these criteria:\n" + "\n".join(descs)

            if scoring == "rubric" and criteria:
                criteria_block = _build_criteria_prompt(criteria)
                scores_example = ", ".join(f'"{c["name"]}": 4' for c in criteria)
                system_prompt = (
                    f"You are {judge_name}, an AI judge.\n\n"
                    f"Grading instructions:\n{judge_prompt}\n\n"
                    f"Score each criterion from 1 (worst) to 5 (best).\n\n"
                    f"{criteria_block}\n\n"
                    f"Respond with ONLY a JSON object:\n"
                    f'{{"scores": {{{scores_example}}}, "reason": "brief explanation"}}'
                )
            else:
                system_prompt = (
                    f"You are {judge_name}, an AI judge evaluating the quality of an AI response.\n\n"
                    f"Grading instructions:\n{judge_prompt}\n\n"
                    "Respond with ONLY a JSON object:\n"
                    '{"vote": "pass" or "fail", "reason": "brief explanation"}'
                )

            # Use _real_ fields so judges work even in ghost mode
            item_prompt = item.get("_real_prompt") or item.get("prompt", "")
            item_response = item.get("_real_response") or item.get("response", "")
            item_expected = item.get("_real_expected") or item.get("expected")

            user_message = (
                f"Item to evaluate:\n"
                f"Prompt: {item_prompt}\n"
                f"Response: {item_response}"
            )
            if item_expected:
                user_message += f"\nExpected: {item_expected}"

            try:
                result = self._call_local_judge(
                    provider_name, model, api_key, system_prompt, user_message,
                    scoring=scoring,
                    criteria=criteria,
                    pass_threshold=pass_threshold,
                    criterion_thresholds=criterion_thresholds,
                )
                return {
                    "itemRunId": item_run_id,
                    "judgeConfigId": judge_id,
                    **result,
                    "_judgeName": judge_name,
                    "_scoring": scoring,
                }
            except Exception as exc:
                # API errors are NOT judgments — skip this judge, don't count as fail
                return {
                    "itemRunId": item_run_id,
                    "judgeConfigId": judge_id,
                    "vote": "error",
                    "reason": f"Judge unavailable: {exc}",
                    "rawOutput": {"error": str(exc)},
                    "_judgeName": judge_name,
                    "_scoring": scoring,
                }

        # Run all judgments in parallel with progress bar and rate limiting
        from concurrent.futures import ThreadPoolExecutor, as_completed

        verdicts = []
        judge_start = time.monotonic()

        # Rate limiter: max N judge API calls per second (avoids 429s)
        rate_limiter = _RateLimiter(max_per_second=20)

        def rate_limited_judgment(task):
            rate_limiter.acquire()
            return execute_judgment(task)

        if self._client._verbose:
            from evalora.output.display import Progress, SpinnerColumn, TextColumn, BarColumn, console
            progress = Progress(
                SpinnerColumn("dots"),
                TextColumn("[bold]Judging..."),
                BarColumn(bar_width=30),
                TextColumn("{task.completed}/{task.total}"),
                console=console,
                transient=True,
            )
            task_id = progress.add_task("Judging...", total=total_judgments)
            progress.start()

        try:
            with ThreadPoolExecutor(max_workers=self._client._max_workers) as pool:
                futures = {pool.submit(rate_limited_judgment, t): t for t in tasks}
                for future in as_completed(futures):
                    verdict = future.result()
                    verdict["_judgeName"] = verdict.pop("_judgeName", "")
                    verdicts.append(verdict)
                    if self._client._verbose:
                        progress.update(task_id, completed=len(verdicts))
        finally:
            if self._client._verbose:
                progress.stop()

        judge_elapsed = time.monotonic() - judge_start

        # Show per-item judge breakdown
        if verdicts and self._client._verbose:
            from evalora.output.display import console

            # Group verdicts by item
            item_verdicts: dict[str, list[dict]] = {}
            for v in verdicts:
                item_verdicts.setdefault(v["itemRunId"], []).append(v)

            for item_run_id, item_vs in item_verdicts.items():
                idx = next(
                    (i for i, rid in enumerate(self._item_run_ids) if rid == item_run_id),
                    None,
                )
                prompt_short = ""
                if idx is not None and idx < len(self._logged_items):
                    prompt_short = self._logged_items[idx].get("prompt", "")[:50]

                real = [v for v in item_vs if v["vote"] in ("pass", "fail")]
                errors = [v for v in item_vs if v["vote"] == "error"]
                passes = sum(1 for v in real if v["vote"] == "pass")
                fails = sum(1 for v in real if v["vote"] == "fail")

                if not real:
                    overall = "[yellow]NEEDS REVIEW[/yellow] (all judges errored)"
                elif passes > fails:
                    overall = "[green]PASS[/green]"
                elif fails > passes:
                    overall = "[red]FAIL[/red]"
                else:
                    overall = "[yellow]TIE[/yellow]"
                if errors:
                    overall += f" [dim]({len(errors)} judge error)[/dim]"

                console.print(f"\n  [cyan]{prompt_short}...[/cyan] → {overall}")
                for v in item_vs:
                    if v["vote"] == "pass":
                        indicator = "[green]✓[/green]"
                    elif v["vote"] == "fail":
                        indicator = "[red]✗[/red]"
                    else:
                        indicator = "[yellow]⚠[/yellow]"
                    # Show rubric scores inline if present
                    if v.get("scores") and v.get("_scoring") == "rubric":
                        scores_str = " ".join(
                            f"{k}={s}" for k, s in v["scores"].items()
                        )
                        avg = v.get("avg_score", 0)
                        console.print(
                            f"    {indicator} [dim]{v['_judgeName']}:[/dim] "
                            f"{scores_str} (avg {avg:.1f}) — {v.get('reason', '')[:60]}"
                        )
                    else:
                        console.print(f"    {indicator} [dim]{v['_judgeName']}:[/dim] {v.get('reason', '')[:60]}")

            total_passes = sum(1 for v in verdicts if v["vote"] == "pass")
            total_fails = sum(1 for v in verdicts if v["vote"] == "fail")
            total_errors = sum(1 for v in verdicts if v["vote"] == "error")
            parts = [
                f"[green]{total_passes} pass[/green]",
                f"[red]{total_fails} fail[/red]",
            ]
            if total_errors:
                parts.append(f"[yellow]{total_errors} error[/yellow]")
            console.print(
                f"\n  [bold]{len(verdicts)} judgments in {judge_elapsed:.1f}s[/bold] — "
                + " · ".join(parts)
            )

        # Clean verdicts for storage (strip display-only fields)
        clean_verdicts = [
            {k: v for k, v in vd.items() if not k.startswith("_")}
            for vd in verdicts
        ]

        # Send verdicts to backend (skip in local mode)
        if clean_verdicts and not self._local:
            try:
                self._client._request(
                    "POST", f"/runs/{self.id}/verdicts", json=clean_verdicts
                )
                if self._client._verbose:
                    from evalora.output.display import console
                    console.print(f"  [dim]Sent {len(verdicts)} verdicts to backend[/dim]")
            except Exception as exc:
                if self._client._verbose:
                    from evalora.output.display import console
                    console.print(f"  [red]Failed to send verdicts: {exc}[/red]")

        # Update local logged items with judge verdicts for local results file
        item_verdicts: dict[str, list[dict]] = {}
        for v in verdicts:
            item_verdicts.setdefault(v["itemRunId"], []).append(v)

        for item_run_id, item_vs in item_verdicts.items():
            passes = sum(1 for v in item_vs if v["vote"] == "pass")
            fails = len(item_vs) - passes
            idx = next(
                (i for i, rid in enumerate(self._item_run_ids) if rid == item_run_id),
                None,
            )
            if idx is not None and idx < len(self._logged_items):
                stored_verdicts = []
                gc = self._ghost_config
                for v in item_vs:
                    reason = v["reason"]
                    if gc.judge_reasoning:
                        reason = gc.redact("judge_reasoning", reason) or ""
                    verdict_entry: dict = {"vote": v["vote"], "reason": reason}
                    if v.get("scores"):
                        verdict_entry["scores"] = v["scores"]
                        verdict_entry["avg_score"] = v.get("avg_score")
                    stored_verdicts.append(verdict_entry)
                self._logged_items[idx]["judge_verdicts"] = stored_verdicts

                # When supplementary, don't override server's pass/fail.
                if supplementary:
                    self._logged_items[idx]["local_judges_supplementary"] = True
                    continue

                # Only count real votes — errors are skipped
                real_votes = [v for v in item_vs if v["vote"] in ("pass", "fail")]
                passes = sum(1 for v in real_votes if v["vote"] == "pass")
                fails = sum(1 for v in real_votes if v["vote"] == "fail")

                if not real_votes:
                    self._logged_items[idx]["passed"] = None
                elif passes > fails:
                    self._logged_items[idx]["passed"] = True
                elif fails > passes:
                    self._logged_items[idx]["passed"] = False
                else:
                    self._logged_items[idx]["passed"] = None

        # Ghost mode: clear _real_* fields from memory now that judges are done.
        if self._ghost_config.enabled:
            for item in self._logged_items:
                item.pop("_real_prompt", None)
                item.pop("_real_response", None)
                item.pop("_real_expected", None)

    def _call_local_judge(
        self,
        provider: str,
        model: str,
        api_key: str,
        system_prompt: str,
        user_message: str,
        scoring: str = "binary",
        criteria: list[dict] | None = None,
        pass_threshold: float = 3.5,
        criterion_thresholds: dict[str, float] | None = None,
    ) -> dict:
        """Call a provider to execute a judge and parse the JSON response."""
        import json as json_mod

        if provider == "openai":
            from evalora.providers.openai_provider import OpenAIProvider
            p = OpenAIProvider(model=model, api_key=api_key, temperature=0.0, max_tokens=512)
            result = p.complete(user_message, system_prompt=system_prompt)
        elif provider == "anthropic":
            from evalora.providers.anthropic_provider import AnthropicProvider
            p = AnthropicProvider(model=model, api_key=api_key, temperature=0.0, max_tokens=512)
            result = p.complete(user_message, system_prompt=system_prompt)
        else:
            return {
                "vote": "fail",
                "reason": (
                    f"Unsupported judge provider: {provider!r}. "
                    "Use 'openai' or 'anthropic' in your judge config."
                ),
                "rawOutput": {},
            }

        # Parse JSON from response
        text = result.response
        try:
            json_match = None
            # Try to find JSON in the response
            start = text.find("{")
            end = text.rfind("}") + 1
            if start >= 0 and end > start:
                json_match = text[start:end]

            if json_match:
                parsed = json_mod.loads(json_match)

                # Rubric scoring mode — extract per-criterion scores
                if scoring == "rubric" and criteria:
                    scores = parsed.get("scores", {})
                    reason = parsed.get("reason", "No reason provided")
                    # Ensure all criteria have scores, default to 1 if missing
                    for c in criteria:
                        name = c["name"] if isinstance(c, dict) else c
                        if name not in scores:
                            scores[name] = 1
                    # Weighted average — uses weight from criteria dicts
                    total_weight = 0
                    weighted_sum = 0
                    for c in criteria:
                        name = c["name"] if isinstance(c, dict) else c
                        w = c.get("weight", 1) if isinstance(c, dict) else 1
                        weighted_sum += scores.get(name, 1) * w
                        total_weight += w
                    avg_score = weighted_sum / total_weight if total_weight else 0
                    vote = "pass" if avg_score >= pass_threshold else "fail"
                    # Check per-criterion thresholds — fail if ANY criterion is below its threshold
                    if vote == "pass" and criterion_thresholds:
                        for crit, threshold in criterion_thresholds.items():
                            if crit in scores and scores[crit] < threshold:
                                vote = "fail"
                                reason = f"{reason} (criterion '{crit}' scored {scores[crit]}, needs >= {threshold})"
                                break
                    return {
                        "vote": vote,
                        "reason": reason,
                        "scores": scores,
                        "avg_score": round(avg_score, 2),
                        "rawOutput": parsed,
                    }

                # Binary scoring mode (default)
                vote = "pass" if parsed.get("vote") == "pass" else "fail"
                reason = parsed.get("reason", "No reason provided")
                return {"vote": vote, "reason": reason, "rawOutput": parsed}
        except (json_mod.JSONDecodeError, ValueError):
            pass

        preview = text[:120] + ("..." if len(text) > 120 else "")
        return {
            "vote": "fail",
            "reason": f"Judge returned unparseable output (expected JSON). Got: {preview!r}",
            "rawOutput": {"raw": text},
        }

    def _print_interrupted(self):
        from evalora.client import Evalora

        if not isinstance(self._client, Evalora):
            raise TypeError("Expected Evalora client")
        if self._client._verbose:
            from evalora.output.display import console
            console.print(
                "\n[bold yellow]Interrupted![/bold yellow] "
                "Completing with partial results..."
            )

