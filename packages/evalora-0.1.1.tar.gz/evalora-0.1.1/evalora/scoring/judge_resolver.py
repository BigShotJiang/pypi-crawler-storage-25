"""Judge resolver — convert strings and dicts to fully-resolved judge configs."""

from __future__ import annotations

__all__ = ["resolve_judges"]


def resolve_judges(judges: list) -> list[dict]:
    """Resolve judge entries: strings become presets, dicts pass through.

    Accepts:
        - "Accuracy" or "accuracy" → looks up preset and returns its default config
        - {"name": "Accuracy", ...} → pass through (name also checked for preset defaults)
        - accuracy() → already a dict, pass through
    """
    from evalora.judges import PRESETS

    resolved = []
    for j in judges:
        if isinstance(j, str):
            key = j.lower().strip()
            if key in PRESETS:
                resolved.append(PRESETS[key]())
            else:
                available = ", ".join(PRESETS.keys())
                raise ValueError(
                    f"Unknown judge preset: '{j}'. "
                    f"Available presets: {available}. "
                    f"Or pass a dict with 'name', 'provider', 'model', 'prompt'."
                )
        elif isinstance(j, dict):
            name = j.get("name", "")
            key = name.lower().strip()
            if key in PRESETS and "prompt" not in j:
                preset = PRESETS[key]()
                merged = {**preset, **j}
                resolved.append(merged)
            else:
                resolved.append(j)
        else:
            resolved.append(j)
    return resolved
