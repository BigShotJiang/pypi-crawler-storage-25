"""Pairwise comparison — compare two runs head-to-head using an AI judge."""

from __future__ import annotations

import json as json_mod
import random

__all__ = ["PairwiseResult", "run_pairwise"]

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from evalora.core.constants import DEFAULT_OUTPUT_DIR

if TYPE_CHECKING:
    from evalora.client import Evalora


@dataclass
class PairwiseResult:
    """Result of a pairwise comparison between two runs."""

    a_wins: int
    b_wins: int
    ties: int
    total: int
    a_win_rate: str
    b_win_rate: str
    items: list[dict] = field(default_factory=list)


def _load_local_run(run_id: str, output_dir: str | None = None) -> list[dict]:
    """Load run items from local .evalora/runs/*.json files."""
    base = Path(output_dir) if output_dir else Path(DEFAULT_OUTPUT_DIR)
    run_file = base / "runs" / f"{run_id}.json"
    if not run_file.exists():
        raise FileNotFoundError(f"Run file not found: {run_file}")
    data = json_mod.loads(run_file.read_text())
    return data.get("items", [])


def _call_pairwise_judge(
    provider_name: str,
    model: str,
    api_key: str,
    system_prompt: str,
    user_message: str,
) -> dict:
    """Call the judge provider and parse the pairwise JSON response."""
    if provider_name == "openai":
        from evalora.providers.openai_provider import OpenAIProvider
        p = OpenAIProvider(model=model, api_key=api_key, temperature=0.0, max_tokens=512)
        result = p.complete(user_message, system_prompt=system_prompt)
    elif provider_name == "anthropic":
        from evalora.providers.anthropic_provider import AnthropicProvider
        p = AnthropicProvider(model=model, api_key=api_key, temperature=0.0, max_tokens=512)
        result = p.complete(user_message, system_prompt=system_prompt)
    else:
        return {
            "winner": "tie",
            "reason": (
                f"Unsupported pairwise judge provider: {provider_name!r}. "
                "Use 'openai' or 'anthropic'."
            ),
        }

    text = result.response
    try:
        start = text.find("{")
        end = text.rfind("}") + 1
        if start >= 0 and end > start:
            parsed = json_mod.loads(text[start:end])
            winner = parsed.get("winner", "tie").upper()
            reason = parsed.get("reason", "No reason provided")
            if winner not in ("A", "B", "TIE"):
                winner = "TIE"
            return {"winner": winner, "reason": reason}
    except (json_mod.JSONDecodeError, ValueError):
        pass

    return {"winner": "TIE", "reason": "Judge output unparseable"}


def run_pairwise(
    client: Evalora,
    run_a_id: str,
    run_b_id: str,
    judge: dict,
) -> PairwiseResult:
    """Compare two runs head-to-head using an AI judge.

    Loads items from both runs, matches by prompt, and has the judge pick
    a winner for each pair. Order is randomized to avoid position bias.
    """
    # Load items from both runs
    if client._local:
        items_a = _load_local_run(run_a_id, client._output_dir)
        items_b = _load_local_run(run_b_id, client._output_dir)
    else:
        try:
            items_a = _load_local_run(run_a_id, client._output_dir)
        except FileNotFoundError:
            data = client._request("GET", f"/runs/{run_a_id}")
            items_a = data.get("items", [])
        try:
            items_b = _load_local_run(run_b_id, client._output_dir)
        except FileNotFoundError:
            data = client._request("GET", f"/runs/{run_b_id}")
            items_b = data.get("items", [])

    # Match items by prompt text
    b_by_prompt = {item["prompt"]: item for item in items_b if item.get("prompt")}
    matched_pairs = []
    for item_a in items_a:
        prompt = item_a.get("prompt", "")
        if prompt and prompt in b_by_prompt:
            matched_pairs.append((prompt, item_a, b_by_prompt[prompt]))

    if not matched_pairs:
        return PairwiseResult(
            a_wins=0, b_wins=0, ties=0, total=0,
            a_win_rate="0%", b_win_rate="0%", items=[],
        )

    judge_name = judge.get("name", "Head-to-Head")
    judge_prompt = judge.get("prompt", "Which response is better?")
    provider_name = judge.get("provider", "openai")
    model = judge.get("model", "gpt-4o")
    api_key = judge.get("api_key", "")

    if client._verbose:
        from evalora.output.display import console
        console.print(f"\n[bold]Pairwise comparison[/bold] — {len(matched_pairs)} matched items")
        console.print(f"  Judge: [magenta]{judge_name}[/magenta] ({model})\n")

    def judge_pair(pair):
        prompt, item_a, item_b = pair
        response_a = item_a.get("response", "")
        response_b = item_b.get("response", "")

        # Randomize order to avoid position bias
        swapped = random.random() < 0.5
        if swapped:
            first, second = response_b, response_a
        else:
            first, second = response_a, response_b

        system_prompt = (
            f"You are judging which AI response better answers the question.\n\n"
            f"{judge_prompt}\n\n"
            "Which response is better? Respond with ONLY a JSON object:\n"
            '{"winner": "A" or "B" or "tie", "reason": "brief explanation"}'
        )

        user_message = (
            f"Question: {prompt}\n\n"
            f"Response A:\n{first}\n\n"
            f"Response B:\n{second}"
        )

        result = _call_pairwise_judge(provider_name, model, api_key, system_prompt, user_message)
        winner = result["winner"]

        # Un-swap if we randomized the order
        if swapped:
            if winner == "A":
                winner = "B"
            elif winner == "B":
                winner = "A"

        return {
            "prompt": prompt,
            "response_a": response_a,
            "response_b": response_b,
            "winner": winner,
            "reason": result["reason"],
        }

    # Run all judgments in parallel
    comparison_items = []
    with ThreadPoolExecutor(max_workers=client._max_workers) as pool:
        futures = [pool.submit(judge_pair, pair) for pair in matched_pairs]
        for future in as_completed(futures):
            comparison_items.append(future.result())

    a_wins = sum(1 for i in comparison_items if i["winner"] == "A")
    b_wins = sum(1 for i in comparison_items if i["winner"] == "B")
    ties = sum(1 for i in comparison_items if i["winner"] == "TIE")
    total = len(comparison_items)

    a_pct = f"{(a_wins / total * 100):.0f}%" if total > 0 else "0%"
    b_pct = f"{(b_wins / total * 100):.0f}%" if total > 0 else "0%"

    result = PairwiseResult(
        a_wins=a_wins,
        b_wins=b_wins,
        ties=ties,
        total=total,
        a_win_rate=a_pct,
        b_win_rate=b_pct,
        items=comparison_items,
    )

    if client._verbose:
        from evalora.output.display import print_pairwise_result
        print_pairwise_result(result, run_a_id, run_b_id)

    return result
