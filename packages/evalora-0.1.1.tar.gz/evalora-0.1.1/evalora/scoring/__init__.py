"""Scoring mechanisms — judges, validators, scorers, rubrics, similarity."""
