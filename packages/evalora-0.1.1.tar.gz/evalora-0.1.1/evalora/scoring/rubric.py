"""Rubric utilities — normalize criteria and build scoring prompts."""

from __future__ import annotations

__all__ = ["normalize_criteria", "build_criteria_prompt"]


def normalize_criteria(raw: list) -> list[dict]:
    """Normalize criteria: strings become dicts, dicts pass through."""
    result = []
    for c in raw:
        if isinstance(c, str):
            result.append({"name": c})
        elif isinstance(c, dict):
            result.append(c)
    return result


def build_criteria_prompt(criteria: list[dict]) -> str:
    """Build detailed scoring instructions from structured criteria."""
    lines = ["Criteria:"]
    for c in criteria:
        name = c["name"]
        desc = c.get("description", "")
        weight = c.get("weight")
        anchors = c.get("anchors", {})

        header = f"- {name}"
        if desc:
            header += f": {desc}"
        if weight and weight != 1:
            header += f" (weight: {weight}x)"
        lines.append(header)

        if anchors:
            for score in sorted(anchors, key=lambda x: int(x)):
                lines.append(f"    {score} = {anchors[score]}")

    return "\n".join(lines)
