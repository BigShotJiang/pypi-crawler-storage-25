"""Semantic similarity via OpenAI embeddings (no SDK dependency)."""

from __future__ import annotations

__all__ = ["compute_similarity"]

import math

import httpx


def _get_embeddings(texts: list[str], api_key: str, model: str) -> list[list[float]]:
    """Fetch embeddings from OpenAI API via raw HTTP."""
    response = httpx.post(
        "https://api.openai.com/v1/embeddings",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json={"input": texts, "model": model},
        timeout=30.0,
    )
    if response.status_code != 200:
        raise RuntimeError(f"Embeddings API error {response.status_code}: {response.text}")
    data = response.json()
    # Sort by index to preserve order
    sorted_data = sorted(data["data"], key=lambda d: d["index"])
    return [d["embedding"] for d in sorted_data]


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors."""
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def compute_similarity(
    text_a: str,
    text_b: str,
    api_key: str,
    model: str = "text-embedding-3-small",
) -> float:
    """Compute cosine similarity between two texts using OpenAI embeddings.

    Returns a float between 0 and 1.
    """
    embeddings = _get_embeddings([text_a, text_b], api_key, model)
    return _cosine_similarity(embeddings[0], embeddings[1])
