"""Anthropic provider — wraps the Anthropic API for use in local judge scoring."""

from __future__ import annotations

import time

from evalora.providers.base import CompletionResult, Provider


class AnthropicProvider(Provider):
    """Block for calling Anthropic models.

    Usage:
        provider = AnthropicProvider(model="claude-sonnet-4-6")
        provider = AnthropicProvider(model="claude-haiku-4-5-20251001", api_key="sk-ant-...")
    """

    def __init__(
        self,
        model: str = "claude-sonnet-4-6",
        api_key: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 1024,
    ):
        try:
            from anthropic import Anthropic
        except ImportError:
            raise ImportError("Install anthropic: pip install anthropic")

        self._model = model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._client = Anthropic(api_key=api_key) if api_key else Anthropic()

    def name(self) -> str:
        return "anthropic"

    def complete(self, prompt: str, system_prompt: str | None = None) -> CompletionResult:
        kwargs: dict = {
            "model": self._model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": self._temperature,
            "max_tokens": self._max_tokens,
        }
        if system_prompt:
            kwargs["system"] = system_prompt

        start = time.perf_counter()
        response = self._client.messages.create(**kwargs)
        elapsed = (time.perf_counter() - start) * 1000

        text = ""
        for block in response.content:
            if block.type == "text":
                text += block.text

        return CompletionResult(
            response=text,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            latency_ms=elapsed,
        )
