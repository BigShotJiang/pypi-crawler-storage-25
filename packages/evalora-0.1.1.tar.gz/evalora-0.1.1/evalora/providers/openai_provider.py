"""OpenAI provider — wraps the OpenAI API for use in local judge scoring."""

from __future__ import annotations

import time

from evalora.providers.base import CompletionResult, Provider


class OpenAIProvider(Provider):
    """Block for calling OpenAI models.

    Usage:
        provider = OpenAIProvider(model="gpt-4o")
        provider = OpenAIProvider(model="gpt-4o-mini", api_key="sk-...")
        provider = OpenAIProvider(model="gpt-4o", temperature=0.0)
    """

    def __init__(
        self,
        model: str = "gpt-4o",
        api_key: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 1024,
    ):
        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError("Install openai: pip install openai")

        self._model = model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._client = OpenAI(api_key=api_key) if api_key else OpenAI()

    def name(self) -> str:
        return "openai"

    def complete(self, prompt: str, system_prompt: str | None = None) -> CompletionResult:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        start = time.perf_counter()
        response = self._client.chat.completions.create(
            model=self._model,
            messages=messages,
            temperature=self._temperature,
            max_tokens=self._max_tokens,
        )
        elapsed = (time.perf_counter() - start) * 1000

        choice = response.choices[0]
        usage = response.usage

        return CompletionResult(
            response=choice.message.content or "",
            input_tokens=usage.prompt_tokens if usage else 0,
            output_tokens=usage.completion_tokens if usage else 0,
            latency_ms=elapsed,
        )
