"""Abstract base class and result type for AI provider implementations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

__all__ = ["CompletionResult", "Provider"]


@dataclass
class CompletionResult:
    """Result from calling an AI provider."""

    response: str
    input_tokens: int = 0
    output_tokens: int = 0
    latency_ms: float = 0


class Provider(ABC):
    """Base class for AI provider blocks.

    Subclass this to add support for any AI provider.
    """

    @abstractmethod
    def complete(self, prompt: str, system_prompt: str | None = None) -> CompletionResult:
        """Send a prompt to the AI and return the response."""
        ...

    @abstractmethod
    def name(self) -> str:
        """Provider name (e.g. 'openai', 'anthropic')."""
        ...
