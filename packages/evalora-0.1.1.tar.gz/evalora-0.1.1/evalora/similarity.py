"""Backward-compatible re-export. Canonical location: evalora/scoring/similarity.py"""
from evalora.scoring.similarity import *  # noqa: F401,F403
