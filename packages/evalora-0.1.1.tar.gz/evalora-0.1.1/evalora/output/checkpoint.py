"""Checkpoint system for resumable eval runs."""

from __future__ import annotations

__all__ = [
    "load_checkpoint",
    "save_checkpoint",
    "clear_checkpoint",
    # Private helpers re-exported for backward compat via evalora/checkpoint.py shim
    "_checkpoint_path",
    "_hash_prompt",
    "_fingerprint_items",
]

import hashlib
import json
from pathlib import Path

from evalora.core.constants import DEFAULT_OUTPUT_DIR


def _checkpoint_path(name: str, output_dir: str | None = None) -> Path:
    base = Path(output_dir) if output_dir else Path(DEFAULT_OUTPUT_DIR)
    return base / "checkpoints" / f"{name}.json"


def _hash_prompt(prompt: str) -> str:
    """Hash a prompt for privacy-safe checkpoint storage (ghost mode)."""
    return hashlib.sha256(prompt.encode()).hexdigest()[:16]


def _fingerprint_items(prompts: list[str]) -> str:
    """Hash all prompts to detect if test set changed."""
    return hashlib.sha256("|".join(sorted(prompts)).encode()).hexdigest()[:12]


def load_checkpoint(name: str, output_dir: str | None = None) -> dict | None:
    path = _checkpoint_path(name, output_dir)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def save_checkpoint(
    name: str,
    run_id: str,
    completed_hashes: list[str],
    fingerprint: str,
    output_dir: str | None = None,
) -> None:
    path = _checkpoint_path(name, output_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "run_id": run_id,
                "name": name,
                "completed_hashes": completed_hashes,
                "fingerprint": fingerprint,
                "completed_count": len(completed_hashes),
            },
            indent=2,
        )
    )


def clear_checkpoint(name: str, output_dir: str | None = None) -> None:
    path = _checkpoint_path(name, output_dir)
    if path.exists():
        path.unlink()
