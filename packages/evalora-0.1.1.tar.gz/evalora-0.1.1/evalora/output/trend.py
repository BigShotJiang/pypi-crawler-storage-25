"""Trend tracking — detect score regression across runs.

Usage:
    from evalora import Evalora

    ev = Evalora()
    report = ev.trend("my-eval", last=10)
    # report.regression → True if scores are declining
    # report.slope → rate of change per run
    # report.runs → list of (run_name, pass_rate) tuples

    # CI mode — exit code 1 on regression
    ev.trend("my-eval", last=10, fail_on_regression=True)
"""

from __future__ import annotations

import json
from dataclasses import dataclass

__all__ = ["TrendReport", "analyze_trend"]
from pathlib import Path


@dataclass
class TrendReport:
    """Result of trend analysis across runs."""
    eval_name: str
    runs: list[tuple[str, float]]  # (run_name/version, pass_rate)
    slope: float  # change in pass_rate per run
    regression: bool  # True if slope < threshold
    threshold: float
    message: str


def analyze_trend(
    eval_name: str,
    output_dir: str | None = None,
    last: int = 10,
    threshold: float = -0.02,
) -> TrendReport:
    """Analyze pass rate trends across saved runs.

    Args:
        eval_name: Name prefix to filter runs (matches run name or eval name in results).
        output_dir: Directory containing .evalora/runs/ results. Defaults to .evalora.
        last: Number of most recent runs to analyze.
        threshold: Slope below this triggers regression (default: -0.02 = 2% decline per run).

    Returns:
        TrendReport with slope, regression flag, and per-run data.
    """
    base = Path(output_dir) if output_dir else Path(".evalora")
    runs_dir = base / "runs"

    if not runs_dir.exists():
        return TrendReport(
            eval_name=eval_name,
            runs=[],
            slope=0.0,
            regression=False,
            threshold=threshold,
            message="No runs directory found",
        )

    # Collect all run result files matching the eval name
    run_data: list[tuple[str, float, float]] = []  # (name, pass_rate, timestamp)

    for path in sorted(runs_dir.glob("**/*.json")):
        try:
            with open(path) as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            continue

        name = data.get("name") or data.get("eval_name") or path.stem
        if eval_name.lower() not in name.lower() and eval_name.lower() not in path.stem.lower():
            continue

        total = data.get("total", 0)
        passed = data.get("passed", 0)
        if total == 0:
            # Try computing from items
            items = data.get("items", [])
            total = len(items)
            passed = sum(1 for i in items if i.get("passed") is True)

        if total == 0:
            continue

        pass_rate = passed / total
        mtime = path.stat().st_mtime
        run_data.append((name, pass_rate, mtime))

    # Sort by modification time (oldest first) and take last N
    run_data.sort(key=lambda x: x[2])
    run_data = run_data[-last:]

    if len(run_data) < 2:
        return TrendReport(
            eval_name=eval_name,
            runs=[(name, rate) for name, rate, _ in run_data],
            slope=0.0,
            regression=False,
            threshold=threshold,
            message=f"Need at least 2 runs for trend analysis, found {len(run_data)}",
        )

    # Linear regression: ordinary least squares
    n = len(run_data)
    xs = list(range(n))
    ys = [rate for _, rate, _ in run_data]

    x_mean = sum(xs) / n
    y_mean = sum(ys) / n

    numerator = sum((x - x_mean) * (y - y_mean) for x, y in zip(xs, ys))
    denominator = sum((x - x_mean) ** 2 for x in xs)

    slope = numerator / denominator if denominator != 0 else 0.0
    regression = slope < threshold

    runs = [(name, rate) for name, rate, _ in run_data]

    if regression:
        message = (
            f"Regression detected: pass rate declining {abs(slope):.1%} per run "
            f"over last {n} runs (threshold: {abs(threshold):.1%})"
        )
    else:
        direction = "improving" if slope > 0 else "stable"
        message = f"Trend {direction}: {slope:+.1%} per run over last {n} runs"

    return TrendReport(
        eval_name=eval_name,
        runs=runs,
        slope=round(slope, 6),
        regression=regression,
        threshold=threshold,
        message=message,
    )
