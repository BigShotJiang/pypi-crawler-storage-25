"""Pretty console output for Evalora SDK."""

from __future__ import annotations

import random
import time

__all__ = [
    "console",
    "print_banner",
    "print_run_created",
    "print_log_item",
    "create_eval_progress",
    "print_fetching_dataset",
    "print_dataset_loaded",
    "wait_with_spinner",
    "print_results",
    "print_pairwise_result",
    "print_ghost_warning",
    # Rich helpers accessed via this module by run.py
    "Progress",
    "SpinnerColumn",
    "TextColumn",
    "BarColumn",
]

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.table import Table
from rich.text import Text

from evalora.core import colors as C

console = Console()

PULL_MESSAGES = [
    "Pulling your eval set...",
    "Loading the test gauntlet...",
    "Summoning your dataset...",
    "Grabbing the goods...",
]

WAIT_MESSAGES = [
    "Grading in progress...",
    "Your AI is in the hot seat...",
    "Crunching the verdicts...",
    "The eval gods deliberate...",
    "Almost there, no peeking...",
]

DONE_MESSAGES = [
    "Verdict is in.",
    "Scores locked.",
    "Eval sealed.",
]


def print_banner():
    banner = Text()
    banner.append("evalora", style="bold magenta")
    banner.append(" — easy AI evals", style="dim")
    console.print(banner)
    console.print()


def print_run_created(
    run_id: str,
    url: str,
    total_items: int = 0,
    model: str | None = None,
    name: str | None = None,
    resumed: bool = False,
    skipped: int = 0,
):
    console.print()
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column(style="dim")
    table.add_column()
    if name:
        table.add_row("Name", f"[{C.BOLD}]{name}[/{C.BOLD}]")
    table.add_row("Run", f"[{C.BOLD}]{run_id}[/{C.BOLD}]")
    if model:
        table.add_row("Model", f"[{C.MODEL}]{model}[/{C.MODEL}]")
    if total_items:
        table.add_row("Items", str(total_items))
    if resumed and skipped:
        table.add_row("Skipped", f"[{C.INFO}]{skipped} completed[/{C.INFO}]")
    if url:
        table.add_row("Live", f"[link={url}]{url}[/link]")

    title = f"[{C.BOLD} {C.PASS}]Run resumed[/{C.BOLD} {C.PASS}]" if resumed else f"[{C.BOLD} {C.PASS}]Run created[/{C.BOLD} {C.PASS}]"
    console.print(Panel(table, title=title, border_style=C.PASS))


def print_log_item(
    index: int,
    prompt: str,
    response: str,
    expected: str | None = None,
    passed: bool | None = None,
    total: int | None = None,
    validator_reason: str | None = None,
    similarity: float | None = None,
):
    counter = f"#{index + 1}/{total}" if total else f"#{index + 1}"
    num = f"[{C.DIM}]{counter}[/{C.DIM}]"
    prompt_short = prompt.replace("\n", " ")[:60] + ("..." if len(prompt) > 60 else "")
    response_clean = response.replace("\n", " ").strip()
    response_short = response_clean[:50] + ("..." if len(response_clean) > 50 else "")

    if passed is True:
        indicator = C.SYM_PASS
    elif passed is False:
        indicator = C.SYM_FAIL
    else:
        indicator = C.SYM_SKIP

    suffix = ""
    if validator_reason:
        suffix = f" [{C.WARN}]({validator_reason})[/{C.WARN}]"
    elif similarity is not None:
        suffix = f" [{C.DIM}](sim: {similarity:.2f})[/{C.DIM}]"

    console.print(f"  {indicator} {num} [{C.PROMPT}]{prompt_short}[/{C.PROMPT}]{suffix}")
    console.print(f"      {C.SYM_ARROW} {response_short}")
    if expected and expected != "None":
        expected_clean = expected.replace("\n", " ")[:50]
        console.print(f"      [{C.EXPECTED}]expected:[/{C.EXPECTED}] {expected_clean}")


def create_eval_progress(total: int):
    """Create a Rich progress bar for large eval runs (>25 items).

    Returns (progress, task_id) tuple. Caller must use `progress` as a context manager.
    """
    progress = Progress(
        SpinnerColumn("dots"),
        TextColumn("[bold]{task.description}"),
        BarColumn(bar_width=30),
        TextColumn("{task.completed}/{task.total}"),
        TextColumn("[dim]{task.fields[avg]}[/dim]"),
        console=console,
        transient=True,
    )
    task_id = progress.add_task("Evaluating...", total=total, avg="")
    return progress, task_id


def print_fetching_dataset(dataset_id: str):
    msg = random.choice(PULL_MESSAGES)
    console.print(f"\n[bold yellow]>[/bold yellow] {msg}")
    console.print(f"  [dim]dataset: {dataset_id}[/dim]")


def print_dataset_loaded(count: int):
    console.print(f"  [green]Loaded {count} items[/green]\n")


def wait_with_spinner(
    get_status,
    poll_interval: float = 2.0,
    timeout: float = 300.0,
):
    """Show a spinner while waiting for scoring to complete. Returns final status."""
    terminal = {"completed", "failed", "canceled"}
    msg = random.choice(WAIT_MESSAGES)

    with Progress(
        SpinnerColumn("dots"),
        TextColumn("[bold]{task.description}"),
        BarColumn(bar_width=30),
        TaskProgressColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task(msg, total=None)
        start = time.monotonic()

        while True:
            status = get_status()

            if status.total > 0:
                done = status.passed + status.failed + status.needs_review
                progress.update(task, total=status.total, completed=done)

                if status.status in terminal:
                    break
                if done >= status.total:
                    break

            elapsed = time.monotonic() - start
            if elapsed >= timeout:
                break

            # Rotate funny messages
            if random.random() < 0.15:
                msg = random.choice(WAIT_MESSAGES)
                progress.update(task, description=msg)

            time.sleep(poll_interval)

    return status


def _format_duration(seconds: float) -> str:
    """Format a duration in seconds to a human-readable string."""
    if seconds < 1:
        return f"{seconds * 1000:.0f}ms"
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes = int(seconds // 60)
    secs = seconds % 60
    return f"{minutes}m {secs:.1f}s"


def print_results(status, run=None):
    console.print()
    done_msg = random.choice(DONE_MESSAGES)
    console.print(f"[{C.BOLD}]{done_msg}[/{C.BOLD}]\n")

    table = Table(title="Results", show_lines=False, padding=(0, 2))
    table.add_column("Metric", style=C.BOLD)
    table.add_column("Count", justify="right")
    table.add_column("", justify="left")

    total = status.total or 1
    passed_pct = f"{(status.passed / total) * 100:.0f}%"
    failed_pct = f"{(status.failed / total) * 100:.0f}%"
    review_pct = f"{(status.needs_review / total) * 100:.0f}%"

    if run is not None and run._model_name:
        model_display = run._ghost_config.redact_model(run._model_name) if run._ghost_config.enabled else run._model_name
        table.add_row("Model", f"[{C.BOLD} {C.MODEL}]{model_display}[/{C.BOLD} {C.MODEL}]", "")

    table.add_row("Total", str(status.total), "")
    table.add_row(
        f"[{C.STAT_PASS}]Passed[/{C.STAT_PASS}]",
        f"[{C.STAT_PASS}]{status.passed}[/{C.STAT_PASS}]",
        f"[{C.STAT_PASS}]{passed_pct}[/{C.STAT_PASS}]",
    )
    table.add_row(
        f"[{C.STAT_FAIL}]Failed[/{C.STAT_FAIL}]",
        f"[{C.STAT_FAIL}]{status.failed}[/{C.STAT_FAIL}]",
        f"[{C.STAT_FAIL}]{failed_pct}[/{C.STAT_FAIL}]",
    )
    if status.needs_review > 0:
        table.add_row(
            f"[{C.STAT_REVIEW}]Needs review[/{C.STAT_REVIEW}]",
            f"[{C.STAT_REVIEW}]{status.needs_review}[/{C.STAT_REVIEW}]",
            f"[{C.STAT_REVIEW}]{review_pct}[/{C.STAT_REVIEW}]",
        )

    table.add_row("Status", f"[{C.STAT_STATUS}]{status.status}[/{C.STAT_STATUS}]", "")

    if run is not None:
        table.add_row("", "", "")
        table.add_row(
            f"[{C.STAT_METRIC}]Duration[/{C.STAT_METRIC}]",
            f"[{C.STAT_METRIC}]{_format_duration(run.duration)}[/{C.STAT_METRIC}]",
            "",
        )
        if run._item_times:
            avg_time = sum(run._item_times) / len(run._item_times)
            table.add_row(
                f"[{C.STAT_METRIC}]Avg item time[/{C.STAT_METRIC}]",
                f"[{C.STAT_METRIC}]{_format_duration(avg_time)}[/{C.STAT_METRIC}]",
                f"[{C.DIM}]({len(run._item_times)} items)[/{C.DIM}]",
            )

        total_tokens = run._total_input_tokens + run._total_output_tokens
        if total_tokens > 0:
            table.add_row(
                f"[{C.STAT_METRIC}]Input tokens[/{C.STAT_METRIC}]",
                f"[{C.STAT_METRIC}]{run._total_input_tokens:,}[/{C.STAT_METRIC}]",
                "",
            )
            table.add_row(
                f"[{C.STAT_METRIC}]Output tokens[/{C.STAT_METRIC}]",
                f"[{C.STAT_METRIC}]{run._total_output_tokens:,}[/{C.STAT_METRIC}]",
                "",
            )
            table.add_row(
                f"[{C.STAT_METRIC}]Total tokens[/{C.STAT_METRIC}]",
                f"[{C.STAT_METRIC}]{total_tokens:,}[/{C.STAT_METRIC}]",
                "",
            )
        if run._total_cost > 0:
            table.add_row(
                f"[{C.STAT_METRIC}]Est. cost[/{C.STAT_METRIC}]",
                f"[{C.STAT_METRIC}]${run._total_cost:.4f}[/{C.STAT_METRIC}]",
                "",
            )

    console.print(table)
    console.print()

    # Failed items summary
    if run is not None and run._logged_items:
        failed_items = [i for i in run._logged_items if i.get("passed") is False]
        if failed_items:
            console.print(f"[{C.BOLD} {C.FAIL}]Failed items[/{C.BOLD} {C.FAIL}]")
            show = failed_items[:10]
            for item in show:
                prompt = item.get("prompt", "")
                response = item.get("response", "")
                expected = item.get("expected", "")
                prompt_short = prompt[:60] + ("..." if len(prompt) > 60 else "")
                response_short = response[:40] + ("..." if len(response) > 40 else "")
                expected_short = (expected[:40] + ("..." if len(expected) > 40 else "")) if expected else ""
                console.print(f"  [{C.PROMPT}]{prompt_short}[/{C.PROMPT}]")
                console.print(f"    {C.SYM_ARROW} {response_short}")
                if expected_short:
                    console.print(f"    [{C.EXPECTED}]expected:[/{C.EXPECTED}] {expected_short}")
                if item.get("validator_reason"):
                    console.print(f"    [{C.DIM}]reason:[/{C.DIM}] {item['validator_reason']}")
                if item.get("judge_verdicts"):
                    for jv in item["judge_verdicts"]:
                        indicator = C.SYM_PASS if jv["vote"] == "pass" else C.SYM_FAIL
                        console.print(f"    {indicator} {jv.get('reason', '')[:60]}")
            remaining = len(failed_items) - len(show)
            if remaining > 0:
                console.print(f"  [{C.DIM}]...and {remaining} more[/{C.DIM}]")
            console.print()

    # Category breakdown
    if run is not None and run._logged_items:
        categories: dict[str, dict] = {}
        for item in run._logged_items:
            cat = item.get("category")
            if not cat:
                continue
            if cat not in categories:
                categories[cat] = {"total": 0, "passed": 0, "failed": 0}
            categories[cat]["total"] += 1
            if item.get("passed") is True:
                categories[cat]["passed"] += 1
            elif item.get("passed") is False:
                categories[cat]["failed"] += 1

        if categories:
            cat_table = Table(title="By Category", show_lines=False, padding=(0, 2))
            cat_table.add_column("Category", style="bold")
            cat_table.add_column("Total", justify="right")
            cat_table.add_column("Passed", justify="right")
            cat_table.add_column("Rate", justify="right")
            for cat_name in sorted(categories):
                stats = categories[cat_name]
                rate = stats["passed"] / stats["total"] if stats["total"] else 0
                color = C.CATEGORY_GOOD if rate >= 0.8 else C.CATEGORY_MID if rate >= 0.5 else C.CATEGORY_BAD
                cat_table.add_row(
                    cat_name,
                    str(stats["total"]),
                    f"[{color}]{stats['passed']}[/{color}]",
                    f"[{color}]{rate:.0%}[/{color}]",
                )
            console.print(cat_table)
            console.print()


def print_pairwise_result(result, run_a_id: str, run_b_id: str):
    """Print a summary of a pairwise comparison."""
    console.print()
    a_short = run_a_id[:16]
    b_short = run_b_id[:16]
    console.print(f"[{C.BOLD}]Pairwise: {a_short} vs {b_short}[/{C.BOLD}]")

    total = result.total or 1
    tie_pct = f"{(result.ties / total * 100):.0f}%"

    console.print(f"  [{C.MODEL_A}]Model A wins: {result.a_wins} ({result.a_win_rate})[/{C.MODEL_A}]")
    console.print(f"  [{C.MODEL_B}]Model B wins: {result.b_wins} ({result.b_win_rate})[/{C.MODEL_B}]")
    console.print(f"  [{C.DIM}]Ties: {result.ties} ({tie_pct})[/{C.DIM}]")
    console.print()


def print_ghost_warning(mode: str = "full"):
    mode_desc = {
        "full": "all text (prompts, responses, model, judge reasoning) will be redacted",
        "light": "responses will be redacted, prompts kept visible",
        "hash": "all text will be hashed (traceable but unreadable)",
        "custom": "per-field redaction is active",
    }
    desc = mode_desc.get(mode, "text will be redacted")
    console.print(f"[dim italic]Ghost mode ({mode}): {desc}[/dim italic]")
