"""Results writer — saves eval run data to local files with auto-versioning."""

from __future__ import annotations

__all__ = [
    "list_dataset_versions",
    "save_run",
    # Private helpers re-exported for backward compat via evalora/results.py shim
    "_fingerprint",
    "_detect_version",
]

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from evalora.core.constants import DEFAULT_OUTPUT_DIR


def list_dataset_versions(output_dir: str | None = None) -> list[dict]:
    """List all dataset versions detected from saved runs.

    Returns a list of dicts: [{"version": "A", "fingerprint": "abc123", "runs": 5, "latest": "2024-..."}]
    """
    base = Path(output_dir) if output_dir else Path(DEFAULT_OUTPUT_DIR)
    runs_dir = base / "runs"

    if not runs_dir.exists():
        return []

    versions: dict[str, dict] = {}  # fingerprint -> version info

    for f in sorted(runs_dir.glob("*.json"), key=lambda p: p.stat().st_mtime):
        try:
            data = json.loads(f.read_text())
            fp = data.get("fingerprint", "")
            version = data.get("version", "")
            ts = data.get("timestamp", "")
            if not fp:
                continue

            if fp not in versions:
                versions[fp] = {
                    "version": version or chr(ord("A") + len(versions)),
                    "fingerprint": fp,
                    "runs": 0,
                    "latest": "",
                    "pass_rates": [],
                }
            versions[fp]["runs"] += 1
            if ts > versions[fp]["latest"]:
                versions[fp]["latest"] = ts

            summary = data.get("summary", {})
            total = summary.get("total", 0)
            passed = summary.get("passed", 0)
            if total > 0:
                versions[fp]["pass_rates"].append(passed / total)
        except Exception:
            continue

    result = []
    for info in versions.values():
        rates = info.pop("pass_rates", [])
        if rates:
            info["avg_pass_rate"] = round(sum(rates) / len(rates), 4)
        result.append(info)

    return sorted(result, key=lambda v: v["version"])


def _fingerprint(items: list[dict]) -> str:
    """Hash of all prompts + expected answers. If this changes, the test set changed."""
    parts = []
    for item in sorted(items, key=lambda i: i.get("prompt", "")):
        parts.append(item.get("prompt", ""))
        parts.append(item.get("expected", "") or "")
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:12]


def _detect_version(runs_dir: Path, fingerprint: str) -> tuple[str, str | None]:
    """Check previous runs to determine test version and detect changes.

    Returns (version_label, previous_run_id or None).
    """
    if not runs_dir.exists():
        return "A", None

    # Load all previous runs, find fingerprints
    fingerprints: dict[str, str] = {}  # fingerprint -> version label
    latest_run_id: str | None = None
    latest_time: str = ""

    for f in sorted(runs_dir.glob("*.json"), key=lambda p: p.stat().st_mtime):
        try:
            data = json.loads(f.read_text())
            fp = data.get("fingerprint", "")
            if fp and fp not in fingerprints:
                label = chr(ord("A") + len(fingerprints))
                fingerprints[fp] = label
            ts = data.get("timestamp", "")
            if ts > latest_time:
                latest_time = ts
                latest_run_id = data.get("run_id")
        except Exception:
            continue

    if fingerprint in fingerprints:
        return fingerprints[fingerprint], latest_run_id

    # New fingerprint = new version
    label = chr(ord("A") + len(fingerprints))
    return label, latest_run_id


def save_run(
    run_id: str,
    status: str,
    items: list[dict],
    model: str | None = None,
    duration: float = 0.0,
    input_tokens: int = 0,
    output_tokens: int = 0,
    cost: float = 0.0,
    output_dir: str | None = None,
    name: str | None = None,
    source_of_truth: str = "local",
    server_mode: str | None = None,
    local_judges_ran: bool = False,
    sot_note: str = "",
    ghost_mode: str | None = None,
) -> Path:
    """Save run results to a JSON file.

    Auto-detects if the test set (prompts/expected) changed from previous runs
    and assigns a version label (A, B, C...).
    """
    base = Path(output_dir) if output_dir else Path(DEFAULT_OUTPUT_DIR)
    runs_dir = base / "runs"
    runs_dir.mkdir(parents=True, exist_ok=True)

    fingerprint = _fingerprint(items)
    version, previous_run = _detect_version(runs_dir, fingerprint)

    total = len(items)
    passed = sum(1 for i in items if i.get("passed"))
    failed = total - passed

    result = {
        "run_id": run_id,
        "name": name,
        "version": version,
        "fingerprint": fingerprint,
        "status": status,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "model": model,
        "source_of_truth": source_of_truth,
        "server_mode": server_mode,
        "local_judges_ran": local_judges_ran,
        "ghost_mode": ghost_mode,
        "note": sot_note,
        "summary": {
            "total": total,
            "passed": passed,
            "failed": failed,
            "pass_rate": f"{(passed / total * 100):.1f}%" if total > 0 else "0%",
        },
        "timing": {
            "duration_seconds": round(duration, 2),
        },
        "tokens": {
            "input": input_tokens,
            "output": output_tokens,
            "total": input_tokens + output_tokens,
        },
        "cost_usd": round(cost, 6),
        "items": items,
    }

    # Add category breakdown if any items have categories
    categories: dict[str, dict] = {}
    for item in items:
        cat = item.get("category")
        if not cat:
            continue
        if cat not in categories:
            categories[cat] = {"total": 0, "passed": 0, "failed": 0}
        categories[cat]["total"] += 1
        if item.get("passed") is True:
            categories[cat]["passed"] += 1
        elif item.get("passed") is False:
            categories[cat]["failed"] += 1

    if categories:
        result["categories"] = {
            name: {
                **stats,
                "pass_rate": f"{(stats['passed'] / stats['total'] * 100):.1f}%" if stats["total"] else "0%",
            }
            for name, stats in sorted(categories.items())
        }

    file_path = runs_dir / f"{run_id}.json"
    file_path.write_text(json.dumps(result, indent=2))

    return file_path
