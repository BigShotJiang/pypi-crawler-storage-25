"""Webhook notifications — POST run results on completion."""

from __future__ import annotations

__all__ = ["send_webhook"]

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from evalora.run import Run


def send_webhook(run: Run, status) -> None:
    """Send run results to webhook URL. Auto-detects Slack format."""
    if not run._webhook:
        return
    try:
        import httpx

        total = status.total or 0
        passed = status.passed or 0
        failed = status.failed or 0
        pass_rate = f"{(passed / total * 100):.1f}%" if total else "0%"

        payload = {
            "run_id": run.id,
            "name": run.name,
            "status": status.status,
            "total": total,
            "passed": passed,
            "failed": failed,
            "pass_rate": pass_rate,
            "model": run._model_name,
            "duration": round(run.duration, 2),
            "cost": round(run._total_cost, 4),
        }

        # Detect Slack webhook format
        if "hooks.slack.com" in run._webhook:
            emoji = "✅" if failed == 0 else "❌"
            payload = {
                "text": (
                    f"{emoji} *Evalora run complete*: {run.name or run.id}\n"
                    f"Pass rate: {pass_rate} ({passed}/{total})\n"
                    f"Model: {run._model_name or 'unknown'} | "
                    f"Duration: {run.duration:.1f}s | "
                    f"Cost: ${run._total_cost:.4f}"
                )
            }

        httpx.post(
            run._webhook,
            json=payload,
            timeout=10.0,
            headers={"Content-Type": "application/json"},
        )

        if run._client._verbose:
            from evalora.output.display import console
            console.print(f"[dim]Webhook sent to {run._webhook[:50]}...[/dim]")
    except Exception as exc:
        if run._client._verbose:
            from evalora.output.display import console
            console.print(f"[yellow]Webhook failed: {exc}[/yellow]")
