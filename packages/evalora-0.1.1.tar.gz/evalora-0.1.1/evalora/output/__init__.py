"""Output — display, results, webhooks, checkpoints, trends."""
