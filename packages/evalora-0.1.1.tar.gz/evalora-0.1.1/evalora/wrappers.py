"""Client wrappers for auto-logging LLM calls to Evalora runs.

Usage:
    from evalora import Evalora
    from openai import OpenAI

    ev = Evalora()
    run = ev.run(judges=["Accuracy"])

    client = ev.wrap(OpenAI())
    # All chat.completions.create() calls are auto-logged to the run

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "What is 2+2?"}],
    )
    # ^ auto-logged with prompt, response, tokens, model

    run.done()
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from evalora.run import Run

__all__ = ["wrap", "WrappedOpenAIClient", "WrappedAnthropicClient"]


class _WrappedCompletions:
    """Wraps client.chat.completions to intercept create() calls."""

    def __init__(self, original, run: Run, expected_map: dict | None = None):
        self._original = original
        self._run = run
        self._expected_map = expected_map or {}

    def create(self, **kwargs):
        stream = kwargs.get("stream", False)
        messages = kwargs.get("messages", [])
        prompt = _extract_prompt(messages)
        expected = self._expected_map.get(prompt)

        if stream:
            return self._create_streaming(kwargs, prompt, expected)

        response = self._original.create(**kwargs)

        from evalora.core.extraction import extract_result as _extract_result
        response_text, metadata = _extract_result(response)

        self._run.log(
            prompt=prompt,
            response=response_text,
            expected=expected,
            metadata=metadata,
        )

        return response

    def _create_streaming(self, kwargs, prompt, expected):
        """Handle stream=True: buffer chunks, log complete response, yield chunks."""
        stream = self._original.create(**kwargs)
        return _StreamBuffer(stream, self._run, prompt, expected, kwargs.get("model"))

    def __getattr__(self, name):
        return getattr(self._original, name)


class _StreamBuffer:
    """Buffers streaming chunks, yields them to caller, logs complete response when done."""

    def __init__(self, stream, run: Run, prompt: str, expected: str | None, model: str | None):
        self._stream = stream
        self._run = run
        self._prompt = prompt
        self._expected = expected
        self._model = model
        self._chunks: list[str] = []
        self._input_tokens = 0
        self._output_tokens = 0

    def __iter__(self):
        return self._iterate()

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        if hasattr(self._stream, "__exit__"):
            self._stream.__exit__(*args)
        self._log_complete()

    def _iterate(self):
        try:
            for chunk in self._stream:
                # Extract text from chunk
                delta = None
                if hasattr(chunk, "choices") and chunk.choices:
                    delta = getattr(chunk.choices[0], "delta", None)
                    if delta and hasattr(delta, "content") and delta.content:
                        self._chunks.append(delta.content)

                # Extract usage from final chunk if available
                usage = getattr(chunk, "usage", None)
                if usage:
                    self._input_tokens = getattr(usage, "prompt_tokens", 0) or 0
                    self._output_tokens = getattr(usage, "completion_tokens", 0) or 0

                yield chunk
        finally:
            self._log_complete()

    def _log_complete(self):
        if not self._chunks:
            return
        full_response = "".join(self._chunks)
        self._chunks = []  # Prevent double-logging

        metadata = {}
        if self._model:
            metadata["_model"] = self._model
        if self._input_tokens:
            metadata["_input_tokens"] = self._input_tokens
        if self._output_tokens:
            metadata["_output_tokens"] = self._output_tokens

        self._run.log(
            prompt=self._prompt,
            response=full_response,
            expected=self._expected,
            metadata=metadata or None,
        )


class _WrappedChat:
    """Wraps client.chat to intercept chat.completions."""

    def __init__(self, original_chat, run: Run, expected_map: dict | None = None):
        self._original_chat = original_chat
        self._run = run
        self._expected_map = expected_map

    @property
    def completions(self):
        return _WrappedCompletions(
            self._original_chat.completions,
            self._run,
            self._expected_map,
        )

    def __getattr__(self, name):
        if name == "completions":
            return self.completions
        return getattr(self._original_chat, name)


class _WrappedAnthropicMessages:
    """Wraps client.messages to intercept create() calls."""

    def __init__(self, original, run: Run, expected_map: dict | None = None):
        self._original = original
        self._run = run
        self._expected_map = expected_map or {}

    def create(self, **kwargs):
        stream = kwargs.get("stream", False)
        messages = kwargs.get("messages", [])
        prompt = _extract_prompt(messages)
        expected = self._expected_map.get(prompt)

        if stream:
            return self._create_streaming(kwargs, prompt, expected)

        response = self._original.create(**kwargs)

        from evalora.core.extraction import extract_result as _extract_result
        response_text, metadata = _extract_result(response)

        self._run.log(
            prompt=prompt,
            response=response_text,
            expected=expected,
            metadata=metadata,
        )

        return response

    def _create_streaming(self, kwargs, prompt, expected):
        """Handle stream=True for Anthropic: buffer events, log complete response."""
        stream = self._original.create(**kwargs)
        return _AnthropicStreamBuffer(stream, self._run, prompt, expected, kwargs.get("model"))

    def __getattr__(self, name):
        return getattr(self._original, name)


class _AnthropicStreamBuffer:
    """Buffers Anthropic streaming events, yields them, logs complete response."""

    def __init__(self, stream, run: Run, prompt: str, expected: str | None, model: str | None):
        self._stream = stream
        self._run = run
        self._prompt = prompt
        self._expected = expected
        self._model = model
        self._chunks: list[str] = []
        self._input_tokens = 0
        self._output_tokens = 0

    def __iter__(self):
        return self._iterate()

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        if hasattr(self._stream, "__exit__"):
            self._stream.__exit__(*args)
        self._log_complete()

    def _iterate(self):
        try:
            for event in self._stream:
                # Anthropic streams MessageStreamEvent with different types
                event_type = getattr(event, "type", "")

                if event_type == "content_block_delta":
                    delta = getattr(event, "delta", None)
                    if delta:
                        text = getattr(delta, "text", "")
                        if text:
                            self._chunks.append(text)

                elif event_type == "message_delta":
                    usage = getattr(event, "usage", None)
                    if usage:
                        self._output_tokens = getattr(usage, "output_tokens", 0) or 0

                elif event_type == "message_start":
                    msg = getattr(event, "message", None)
                    if msg:
                        usage = getattr(msg, "usage", None)
                        if usage:
                            self._input_tokens = getattr(usage, "input_tokens", 0) or 0

                yield event
        finally:
            self._log_complete()

    def _log_complete(self):
        if not self._chunks:
            return
        full_response = "".join(self._chunks)
        self._chunks = []

        metadata = {}
        if self._model:
            metadata["_model"] = self._model
        if self._input_tokens:
            metadata["_input_tokens"] = self._input_tokens
        if self._output_tokens:
            metadata["_output_tokens"] = self._output_tokens

        self._run.log(
            prompt=self._prompt,
            response=full_response,
            expected=self._expected,
            metadata=metadata or None,
        )


class WrappedOpenAIClient:
    """OpenAI client wrapper that auto-logs LLM calls to an Evalora run.

    All other methods/properties are proxied to the original client.
    """

    def __init__(self, client, run: Run, expected_map: dict | None = None):
        self._client = client
        self._run = run
        self._expected_map = expected_map

    @property
    def chat(self):
        return _WrappedChat(self._client.chat, self._run, self._expected_map)

    def __getattr__(self, name):
        if name == "chat":
            return self.chat
        return getattr(self._client, name)


class WrappedAnthropicClient:
    """Anthropic client wrapper that auto-logs LLM calls to an Evalora run.

    All other methods/properties are proxied to the original client.
    """

    def __init__(self, client, run: Run, expected_map: dict | None = None):
        self._client = client
        self._run = run
        self._expected_map = expected_map

    @property
    def messages(self):
        return _WrappedAnthropicMessages(
            self._client.messages, self._run, self._expected_map
        )

    def __getattr__(self, name):
        if name == "messages":
            return self.messages
        return getattr(self._client, name)


def wrap(client, run: Run, expected: dict | None = None) -> WrappedOpenAIClient | WrappedAnthropicClient:
    """Wrap an OpenAI or Anthropic client to auto-log all LLM calls to a run.

    Args:
        client: An OpenAI() or Anthropic() client instance.
        run: The active Evalora Run to log to.
        expected: Optional dict mapping prompt strings to expected answers.

    Returns:
        A wrapped client that auto-logs every call.

    Example:
        client = ev.wrap(OpenAI(), expected={"What is 2+2?": "4"})
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "What is 2+2?"}],
        )
        # ^ auto-logged to the active run
    """
    client_type = type(client).__name__

    # Detect OpenAI client
    if hasattr(client, "chat") and hasattr(getattr(client, "chat", None), "completions"):
        return WrappedOpenAIClient(client, run, expected)

    # Detect Anthropic client
    if hasattr(client, "messages") and hasattr(getattr(client, "messages", None), "create"):
        return WrappedAnthropicClient(client, run, expected)

    raise TypeError(
        f"Unsupported client type: {client_type}. "
        "wrap() supports OpenAI() and Anthropic() clients."
    )


def _extract_prompt(messages: list) -> str:
    """Extract the user prompt from a messages array.

    Takes the last user message. Falls back to joining all messages.
    """
    # Find the last user message
    for msg in reversed(messages):
        if isinstance(msg, dict) and msg.get("role") == "user":
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
            # Handle content blocks (OpenAI vision, etc.)
            if isinstance(content, list):
                texts = [
                    part.get("text", "") if isinstance(part, dict) else str(part)
                    for part in content
                ]
                return " ".join(t for t in texts if t)

    # Fallback: join all message contents
    parts = []
    for msg in messages:
        if isinstance(msg, dict):
            c = msg.get("content", "")
            if isinstance(c, str):
                parts.append(c)
    return " | ".join(parts) if parts else ""
