"""Helpfulness judge preset — does the response actually help the user?"""

DEFAULT_PROMPT = (
    "You are evaluating whether an AI response is helpful to the user.\n\n"
    "Consider:\n"
    "- Does it provide actionable information the user can use?\n"
    "- Does it answer the question rather than deflect or hedge?\n"
    "- Would a reasonable person find this response useful?\n\n"
    "Vote PASS if the response is genuinely helpful. "
    "Vote FAIL if it is unhelpful, evasive, or provides no value."
)


def helpfulness(
    *,
    provider: str = "openai",
    model: str = "gpt-4o",
    prompt: str = DEFAULT_PROMPT,
    **overrides,
) -> dict:
    return {
        "name": "Helpfulness",
        "provider": provider,
        "model": model,
        "prompt": prompt,
        **overrides,
    }
