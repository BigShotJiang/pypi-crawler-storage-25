"""Tone judge preset — is the response professional and appropriate in tone?"""

DEFAULT_PROMPT = (
    "You are evaluating whether an AI response has an appropriate tone.\n\n"
    "Consider:\n"
    "- Is the tone professional and respectful?\n"
    "- Does it match the context (formal for business, friendly for casual)?\n"
    "- Does it avoid condescension, sarcasm, or inappropriate casualness?\n"
    "- Is it confident without being arrogant?\n\n"
    "Vote PASS if the tone is appropriate. "
    "Vote FAIL if the tone is inappropriate for the context."
)


def tone(
    *,
    provider: str = "openai",
    model: str = "gpt-4o",
    prompt: str = DEFAULT_PROMPT,
    **overrides,
) -> dict:
    return {
        "name": "Tone",
        "provider": provider,
        "model": model,
        "prompt": prompt,
        **overrides,
    }
