"""Clarity judge preset — is the response clear and well-structured?"""

DEFAULT_PROMPT = (
    "You are evaluating whether an AI response is clear and well-structured.\n\n"
    "Consider:\n"
    "- Is the response easy to read and understand?\n"
    "- Is it well-organized with a logical flow?\n"
    "- Does it avoid unnecessary jargon or ambiguity?\n"
    "- Is the language precise and unambiguous?\n\n"
    "Vote PASS if the response is clear and well-structured. "
    "Vote FAIL if it is confusing, disorganized, or hard to follow."
)


def clarity(
    *,
    provider: str = "openai",
    model: str = "gpt-4o",
    prompt: str = DEFAULT_PROMPT,
    **overrides,
) -> dict:
    return {
        "name": "Clarity",
        "provider": provider,
        "model": model,
        "prompt": prompt,
        **overrides,
    }
