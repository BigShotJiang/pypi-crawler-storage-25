"""Completeness judge preset — does the response fully address the question?"""

DEFAULT_PROMPT = (
    "You are evaluating whether an AI response completely addresses the prompt.\n\n"
    "Consider:\n"
    "- Does it answer all parts of the question?\n"
    "- Are there gaps or missing information the user would need?\n"
    "- If the prompt has multiple sub-questions, are all addressed?\n\n"
    "Vote PASS if the response is complete. "
    "Vote FAIL if it only partially answers or misses key parts."
)


def completeness(
    *,
    provider: str = "openai",
    model: str = "gpt-4o",
    prompt: str = DEFAULT_PROMPT,
    **overrides,
) -> dict:
    return {
        "name": "Completeness",
        "provider": provider,
        "model": model,
        "prompt": prompt,
        **overrides,
    }
