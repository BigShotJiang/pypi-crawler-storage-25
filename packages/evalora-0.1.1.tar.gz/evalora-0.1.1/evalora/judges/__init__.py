"""Built-in judge presets.

Usage:
    from evalora.judges import accuracy, safety, hallucination

    run = ev.run(
        provider_keys={"openai": "sk-..."},
        judges=[accuracy(), safety()],
    )

Or just use the name — the SDK auto-resolves:

    run = ev.run(
        provider_keys={"openai": "sk-..."},
        judges=["Accuracy", "Safety"],
    )
"""

from evalora.judges.accuracy import accuracy
from evalora.judges.clarity import clarity
from evalora.judges.completeness import completeness
from evalora.judges.conciseness import conciseness
from evalora.judges.faithfulness import faithfulness
from evalora.judges.hallucination import hallucination
from evalora.judges.helpfulness import helpfulness
from evalora.judges.relevance import relevance
from evalora.judges.safety import safety
from evalora.judges.tone import tone

PRESETS = {
    "accuracy": accuracy,
    "clarity": clarity,
    "completeness": completeness,
    "conciseness": conciseness,
    "faithfulness": faithfulness,
    "hallucination": hallucination,
    "helpfulness": helpfulness,
    "relevance": relevance,
    "safety": safety,
    "tone": tone,
}

__all__ = [
    "accuracy",
    "clarity",
    "completeness",
    "conciseness",
    "faithfulness",
    "hallucination",
    "helpfulness",
    "relevance",
    "safety",
    "tone",
    "PRESETS",
]
