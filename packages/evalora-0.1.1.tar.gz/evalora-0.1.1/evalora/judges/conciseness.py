"""Conciseness judge preset — is the response appropriately concise?"""

DEFAULT_PROMPT = (
    "You are evaluating whether an AI response is appropriately concise.\n\n"
    "Consider:\n"
    "- Does it communicate the answer without unnecessary verbosity?\n"
    "- Is there filler, repetition, or padding that could be removed?\n"
    "- Does it strike the right balance between thorough and succinct?\n\n"
    "Vote PASS if the response is concise and well-edited. "
    "Vote FAIL if it is unnecessarily long, repetitive, or padded."
)


def conciseness(
    *,
    provider: str = "openai",
    model: str = "gpt-4o",
    prompt: str = DEFAULT_PROMPT,
    **overrides,
) -> dict:
    return {
        "name": "Conciseness",
        "provider": provider,
        "model": model,
        "prompt": prompt,
        **overrides,
    }
