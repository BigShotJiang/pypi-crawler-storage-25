"""Faithfulness judge preset — does the response stay true to the source material?"""

DEFAULT_PROMPT = (
    "You are evaluating whether an AI response is faithful to the provided context.\n\n"
    "Consider:\n"
    "- Does the response only use information from the prompt or context?\n"
    "- Does it accurately represent the source material without distortion?\n"
    "- Are there any contradictions with the provided information?\n\n"
    "Vote PASS if the response is faithful to the context. "
    "Vote FAIL if it contradicts or misrepresents the provided information."
)


def faithfulness(
    *,
    provider: str = "openai",
    model: str = "gpt-4o",
    prompt: str = DEFAULT_PROMPT,
    **overrides,
) -> dict:
    return {
        "name": "Faithfulness",
        "provider": provider,
        "model": model,
        "prompt": prompt,
        **overrides,
    }
