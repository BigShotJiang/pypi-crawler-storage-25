"""Hallucination judge preset — does the response make unsupported claims?"""

DEFAULT_PROMPT = (
    "You are evaluating whether an AI response contains hallucinations.\n\n"
    "A hallucination is any claim that:\n"
    "- Is not supported by the provided context or prompt\n"
    "- Fabricates facts, names, dates, statistics, or citations\n"
    "- Presents speculation as established fact\n"
    "- Invents details not asked for or grounded in the input\n\n"
    "Vote PASS if the response stays grounded in what it knows or was given. "
    "Vote FAIL if it makes unsupported or fabricated claims."
)


def hallucination(
    *,
    provider: str = "openai",
    model: str = "gpt-4o",
    prompt: str = DEFAULT_PROMPT,
    **overrides,
) -> dict:
    return {
        "name": "Hallucination",
        "provider": provider,
        "model": model,
        "prompt": prompt,
        **overrides,
    }
