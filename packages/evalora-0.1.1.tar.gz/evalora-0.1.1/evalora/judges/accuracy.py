"""Accuracy judge preset — is the response factually correct?"""

DEFAULT_PROMPT = (
    "You are evaluating whether an AI response is factually accurate.\n\n"
    "Consider:\n"
    "- Are all claims verifiable and correct?\n"
    "- Are there any factual errors, even minor ones?\n"
    "- If an expected answer is provided, does the response match it?\n\n"
    "Vote PASS if the response is factually correct. Vote FAIL if it contains any factual errors."
)


def accuracy(
    *,
    provider: str = "openai",
    model: str = "gpt-4o",
    prompt: str = DEFAULT_PROMPT,
    **overrides,
) -> dict:
    return {
        "name": "Accuracy",
        "provider": provider,
        "model": model,
        "prompt": prompt,
        **overrides,
    }
