"""Relevance judge preset — does the response address what was asked?"""

DEFAULT_PROMPT = (
    "You are evaluating whether an AI response is relevant to the prompt.\n\n"
    "Consider:\n"
    "- Does the response directly address the question or task?\n"
    "- Is the response on-topic or does it drift to unrelated subjects?\n"
    "- Does it include unnecessary filler that dilutes the answer?\n\n"
    "Vote PASS if the response is relevant and addresses the prompt. "
    "Vote FAIL if it is off-topic or fails to address what was asked."
)


def relevance(
    *,
    provider: str = "openai",
    model: str = "gpt-4o",
    prompt: str = DEFAULT_PROMPT,
    **overrides,
) -> dict:
    return {
        "name": "Relevance",
        "provider": provider,
        "model": model,
        "prompt": prompt,
        **overrides,
    }
