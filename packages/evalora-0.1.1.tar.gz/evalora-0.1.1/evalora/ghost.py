"""Ghost mode configuration — control what gets redacted in eval results.

Usage:
    ghost=False                    # Normal mode
    ghost=True                     # Full redaction (same as "full")
    ghost="light"                  # Redact responses only
    ghost="full"                   # Redact everything including model + judge reasoning
    ghost="hash"                   # Hash all text (traceable, not readable)
    ghost={"prompt": True, ...}    # Per-field control

Server control:
    ghost_server=None              # Default: send verdicts, no text
    ghost_server=True              # Send verdicts only
    ghost_server=False             # Fully offline, nothing sent
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

__all__ = ["GhostConfig", "GhostServerConfig"]


@dataclass(frozen=True)
class GhostConfig:
    """Normalized ghost configuration. Immutable after creation."""

    enabled: bool
    prompt: bool
    response: bool
    expected: bool
    model: bool
    judge_reasoning: bool
    mode: str  # "off" | "full" | "light" | "hash" | "custom"

    @staticmethod
    def from_param(ghost: bool | str | dict = False) -> GhostConfig:
        """Normalize the polymorphic ghost parameter into a consistent config."""
        if ghost is False or ghost is None:
            return GhostConfig(
                enabled=False, prompt=False, response=False,
                expected=False, model=False, judge_reasoning=False, mode="off",
            )
        if ghost is True or ghost == "full":
            return GhostConfig(
                enabled=True, prompt=True, response=True,
                expected=True, model=True, judge_reasoning=True, mode="full",
            )
        if ghost == "light":
            return GhostConfig(
                enabled=True, prompt=False, response=True,
                expected=False, model=False, judge_reasoning=False, mode="light",
            )
        if ghost == "hash":
            return GhostConfig(
                enabled=True, prompt=True, response=True,
                expected=True, model=False, judge_reasoning=False, mode="hash",
            )
        if isinstance(ghost, dict):
            return GhostConfig(
                enabled=True,
                prompt=ghost.get("prompt", False),
                response=ghost.get("response", False),
                expected=ghost.get("expected", False),
                model=ghost.get("model", False),
                judge_reasoning=ghost.get("judge_reasoning", False),
                mode="custom",
            )
        raise ValueError(
            f"Invalid ghost value: {ghost!r}. "
            "Use True, 'light', 'full', 'hash', or a dict like "
            "{{'prompt': True, 'response': True}}."
        )

    def redact(self, field: str, value: str | None) -> str | None:
        """Apply redaction to a field value based on this config."""
        if value is None:
            return None
        if not self.enabled:
            return value
        should_redact = getattr(self, field, False)
        if not should_redact:
            return value
        if self.mode == "hash":
            return f"[hash:{hashlib.sha256(value.encode()).hexdigest()[:16]}]"
        return "[redacted]"

    def redact_model(self, model_name: str | None) -> str | None:
        """Redact model name if configured."""
        if not self.enabled or not self.model or model_name is None:
            return model_name
        if self.mode == "hash":
            return f"[hash:{hashlib.sha256(model_name.encode()).hexdigest()[:12]}]"
        return "[redacted-model]"


@dataclass(frozen=True)
class GhostServerConfig:
    """Controls what data is sent to the Evalora backend in ghost mode."""

    send_to_server: bool
    send_verdicts: bool

    @staticmethod
    def from_param(ghost_server: bool | None, ghost_config: GhostConfig) -> GhostServerConfig:
        """Resolve server config from the ghost_server parameter."""
        if not ghost_config.enabled:
            return GhostServerConfig(send_to_server=True, send_verdicts=True)
        if ghost_server is False:
            return GhostServerConfig(send_to_server=False, send_verdicts=False)
        # Default when ghost active (None or True): send verdicts, no text
        return GhostServerConfig(send_to_server=True, send_verdicts=True)
