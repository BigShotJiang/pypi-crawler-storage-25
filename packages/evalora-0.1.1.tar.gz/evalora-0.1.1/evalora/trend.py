"""Backward-compatible re-export. Canonical location: evalora/output/trend.py"""
from evalora.output.trend import *  # noqa: F401,F403
