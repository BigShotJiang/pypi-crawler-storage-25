"""Prompt formatting logic.

Controls how the SDK modifies prompts to ensure AI responses match
the eval's expected format. Configured via the eval version in the dashboard.
"""

from __future__ import annotations

__all__ = [
    "SHORT_ANSWER_INSTRUCTION",
    "build_format_instruction",
    "with_format_instruction",
]

SHORT_ANSWER_INSTRUCTION = (
    "\n\nRespond with ONLY the exact answer. "
    "No units, no punctuation, no explanation, no extra words. "
    "Just the answer itself."
)


def build_format_instruction(
    response_format: str | None = None,
    valid_answers: list[str] | None = None,
) -> str:
    """Build format instruction from eval config (set in dashboard).

    - "classification" + valid_answers: tells AI to pick from the list.
    - "short_answer" (default): tells AI to respond concisely.
    - "free": no instruction added (for judge/human review modes).
    """
    if response_format == "classification" and valid_answers:
        options = ", ".join(valid_answers)
        return (
            f"\n\nRespond with EXACTLY one of these options: {options}\n"
            "No explanation, no extra words. Just one of the listed options."
        )

    if response_format == "free":
        return ""

    return SHORT_ANSWER_INSTRUCTION


def with_format_instruction(
    prompt: str,
    expected: str | None,
    format_instruction: str | None = None,
) -> str:
    """Append format instruction to a prompt when expected answer is provided."""
    if expected is not None and format_instruction:
        return prompt + format_instruction
    if expected is not None:
        return prompt + SHORT_ANSWER_INSTRUCTION
    return prompt
