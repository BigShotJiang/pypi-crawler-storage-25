"""Core types for the Evalora SDK."""

from __future__ import annotations

__all__ = [
    "DatasetItem",
    "ItemResult",
    "RunStatus",
    "RunSide",
    "ComparisonDelta",
    "ItemComparison",
    "ComparisonResult",
]

from dataclasses import dataclass, field


@dataclass
class DatasetItem:
    """An item from an uploaded dataset."""

    id: str
    prompt: str
    response: str = ""
    expected: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> DatasetItem:
        return cls(
            id=data.get("id", ""),
            prompt=data.get("prompt", ""),
            response=data.get("response", ""),
            expected=data.get("expected"),
        )


@dataclass
class ItemResult:
    """A single scored item from a completed run."""

    id: str
    prompt: str
    response: str
    status: str
    reason: str | None = None
    score: float | None = None
    expected: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> ItemResult:
        return cls(
            id=data["id"],
            prompt=data.get("prompt", ""),
            response=data.get("response", ""),
            status=data["status"],
            reason=data.get("reason"),
            score=data.get("score"),
            expected=data.get("expected"),
        )


@dataclass
class RunStatus:
    """Status and aggregate results of a run."""

    id: str
    status: str
    total: int = 0
    passed: int = 0
    failed: int = 0
    needs_review: int = 0
    items: list[ItemResult] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> RunStatus:
        items = [ItemResult.from_dict(i) for i in data.get("items", [])]
        return cls(
            id=data["id"],
            status=data["status"],
            total=data.get("totalItems", data.get("total", 0)),
            passed=data.get("passedItems", data.get("passed", 0)),
            failed=data.get("failedItems", data.get("failed", 0)),
            needs_review=data.get("needsReviewItems", data.get("needs_review", 0)),
            items=items,
        )


@dataclass
class RunSide:
    """Summary of one side of a run comparison."""

    id: str
    status: str
    total: int = 0
    passed: int = 0
    failed: int = 0


@dataclass
class ComparisonDelta:
    """Difference between two runs."""

    passed: int = 0
    failed: int = 0
    pass_rate: str = ""


@dataclass
class ItemComparison:
    """Per-item comparison between two runs."""

    prompt: str
    runA_status: str
    runB_status: str
    changed: bool


@dataclass
class ComparisonResult:
    """Result of comparing two runs."""

    runA: RunSide
    runB: RunSide
    delta: ComparisonDelta
    item_comparison: list[ItemComparison] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> ComparisonResult:
        delta_data = data.get("delta", {})
        items = [
            ItemComparison(
                prompt=i.get("prompt", ""),
                runA_status=i.get("runA_status", ""),
                runB_status=i.get("runB_status", ""),
                changed=i.get("changed", False),
            )
            for i in data.get("itemComparison", [])
        ]

        def parse_side(side: dict) -> RunSide:
            return RunSide(
                id=side.get("id", ""),
                status=side.get("status", ""),
                total=side.get("total", 0),
                passed=side.get("passed", 0),
                failed=side.get("failed", 0),
            )

        return cls(
            runA=parse_side(data.get("runA", {})),
            runB=parse_side(data.get("runB", {})),
            delta=ComparisonDelta(
                passed=delta_data.get("passed", 0),
                failed=delta_data.get("failed", 0),
                pass_rate=delta_data.get("passRate", ""),
            ),
            item_comparison=items,
        )
