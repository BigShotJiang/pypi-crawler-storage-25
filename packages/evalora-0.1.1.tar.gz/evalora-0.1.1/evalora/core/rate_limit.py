"""Thread-safe rate limiter for API calls."""

from __future__ import annotations

__all__ = ["RateLimiter"]

import threading
import time


class RateLimiter:
    """Token bucket rate limiter — thread-safe."""

    def __init__(self, max_per_second: float = 20.0):
        self._interval = 1.0 / max_per_second
        self._lock = threading.Lock()
        self._last_call = 0.0

    def acquire(self):
        with self._lock:
            now = time.monotonic()
            wait = self._last_call + self._interval - now
            if wait > 0:
                time.sleep(wait)
            self._last_call = time.monotonic()
