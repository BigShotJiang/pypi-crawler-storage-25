"""Text matching utilities for local pass/fail scoring."""

from __future__ import annotations

import re

__all__ = ["normalize", "check_match"]
import unicodedata

_NEGATIONS = frozenset({
    "not", "no", "never", "none", "neither", "nor", "without",
    "isnt", "wasnt", "dont", "doesnt", "cant", "wont", "shouldnt",
    "wouldnt", "couldnt", "hardly", "barely", "scarcely",
})


def normalize(text: str) -> str:
    """Normalize text for comparison: lowercase, strip accents, remove common punctuation."""
    text = text.strip().lower()
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = text.strip("¿¡")
    return text


def _has_negation_before(words: list[str], target_words: set[str]) -> bool:
    """Check if any target word is preceded by a negation word."""
    for i, word in enumerate(words):
        if word in target_words and i > 0 and words[i - 1] in _NEGATIONS:
            return True
    # Also catch "not" at the start of a short response
    if len(words) <= 3 and words and words[0] in _NEGATIONS:
        return True
    return False


def check_match(response: str, expected: str | None, strict: bool = False) -> bool | None:
    """Check if a response matches the expected value.

    Returns True if match, False if mismatch, None if no expected value.

    Args:
        response: The AI response string to check.
        expected: The expected answer. If None, returns None (ungraded).
        strict: If True, only exact normalized match counts. No fuzzy.

    Matching rules (normalized):
      1. Exact match (always checked)
      2. Word-set match with negation awareness (only when strict=False)
    """
    if expected is None:
        return None
    r = normalize(response)
    e = normalize(expected)

    # Exact match (normalized)
    if r == e:
        return True

    # Strict mode: only exact normalized match
    if strict:
        return False

    # Split into word lists
    r_words_list = [w for w in re.split(r'[\s,;./]+', r) if w]
    e_words = set(re.split(r'[\s,;./]+', e)) - {""}
    r_words = set(r_words_list)

    if not e_words:
        return False

    # All expected words must be present
    if not e_words.issubset(r_words):
        return False

    # Negation check — reject if expected words are negated
    if _has_negation_before(r_words_list, e_words):
        return False

    return True
