"""Terminal color theme — single source of truth for all Rich markup colors.

Change these values to restyle the entire SDK terminal output.
Uses Rich markup syntax: https://rich.readthedocs.io/en/latest/markup.html

Example — switch to a blue/orange theme:
    PASS = "blue"
    FAIL = "bright_red"
    ACCENT = "orange1"
"""

# ── Status indicators ─────────────────────────
PASS = "green"
FAIL = "red"
WARN = "yellow"
INFO = "cyan"
ACCENT = "magenta"
DIM = "dim"
BOLD = "bold"

# ── Symbols ───────────────────────────────────
SYM_PASS = f"[{PASS}]✓[/{PASS}]"
SYM_FAIL = f"[{FAIL}]✗[/{FAIL}]"
SYM_WARN = f"[{WARN}]⚠[/{WARN}]"
SYM_SKIP = f"[{DIM}]–[/{DIM}]"
SYM_ARROW = f"[{DIM}]→[/{DIM}]"

# ── Composite styles ──────────────────────────
PROMPT = INFO          # How prompts are highlighted
RESPONSE = ""          # Response text (no color by default)
EXPECTED = DIM         # Expected answer label
MODEL = ACCENT         # Model name
JUDGE_NAME = DIM       # Judge name in verdict list
CATEGORY_GOOD = PASS   # Category with >= 80% pass rate
CATEGORY_MID = WARN    # Category with 50-79% pass rate
CATEGORY_BAD = FAIL    # Category with < 50% pass rate

# ── Results table ─────────────────────────────
STAT_PASS = PASS
STAT_FAIL = FAIL
STAT_REVIEW = WARN
STAT_METRIC = INFO     # Duration, tokens, cost labels
STAT_STATUS = BOLD

# ── Judge verdicts ────────────────────────────
JUDGE_PASS = PASS
JUDGE_FAIL = FAIL
JUDGE_ERROR = WARN
JUDGE_TIE = WARN
JUDGE_LABEL = ACCENT   # "Judges: Accuracy, Safety"

# ── Pairwise ──────────────────────────────────
MODEL_A = PASS
MODEL_B = ACCENT
