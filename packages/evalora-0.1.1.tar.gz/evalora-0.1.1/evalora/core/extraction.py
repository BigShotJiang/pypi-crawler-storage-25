"""Response extraction — auto-detect OpenAI, Anthropic, dict, and string responses."""

from __future__ import annotations

__all__ = ["extract_result"]


def extract_result(result: object) -> tuple[str, dict | None]:
    """Extract response string and optional metadata from a function return.

    Supports:
        - str: plain response
        - dict: {"response": "...", "input_tokens": N, "output_tokens": N, "model": "..."}
        - OpenAI ChatCompletion: auto-extracts .choices[0].message.content, usage, model
        - Anthropic Message: auto-extracts .content[0].text, usage, model
    """
    # OpenAI ChatCompletion — has .choices and .usage
    if hasattr(result, "choices") and hasattr(result, "usage"):
        try:
            response = result.choices[0].message.content or ""
            metadata: dict = {"_model": getattr(result, "model", None)}
            usage = result.usage
            if usage:
                metadata["_input_tokens"] = getattr(usage, "prompt_tokens", 0) or 0
                metadata["_output_tokens"] = getattr(usage, "completion_tokens", 0) or 0
            return response.strip(), metadata
        except (IndexError, AttributeError):
            pass

    # Anthropic Message — has .content list and .usage with input_tokens/output_tokens
    if hasattr(result, "content") and hasattr(result, "stop_reason"):
        try:
            content = result.content
            if isinstance(content, list) and len(content) > 0:
                text = getattr(content[0], "text", str(content[0]))
            else:
                text = str(content)
            metadata = {"_model": getattr(result, "model", None)}
            usage = getattr(result, "usage", None)
            if usage:
                metadata["_input_tokens"] = getattr(usage, "input_tokens", 0) or 0
                metadata["_output_tokens"] = getattr(usage, "output_tokens", 0) or 0
            return text.strip(), metadata
        except (IndexError, AttributeError):
            pass

    # Dict with explicit fields
    if isinstance(result, dict):
        response = str(result.get("response", "")).strip()
        metadata = {}
        if "input_tokens" in result:
            metadata["_input_tokens"] = result["input_tokens"] or 0
        if "output_tokens" in result:
            metadata["_output_tokens"] = result["output_tokens"] or 0
        if "model" in result:
            metadata["_model"] = result["model"]
        return response, metadata if metadata else None

    return str(result).strip(), None
