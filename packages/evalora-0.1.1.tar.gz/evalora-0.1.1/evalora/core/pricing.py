"""Token pricing lookup for cost estimation.

Prices are per 1M tokens. Even rough estimates are fine — this is
informational only. Unknown models return (0, 0).
"""

from __future__ import annotations

__all__ = ["MODEL_PRICES", "estimate_cost"]

# (input_price_per_1M, output_price_per_1M)
MODEL_PRICES: dict[str, tuple[float, float]] = {
    # OpenAI
    "gpt-4o": (2.50, 10.00),
    "gpt-4o-2024-11-20": (2.50, 10.00),
    "gpt-4o-2024-08-06": (2.50, 10.00),
    "gpt-4o-2024-05-13": (5.00, 15.00),
    "gpt-4o-mini": (0.15, 0.60),
    "gpt-4o-mini-2024-07-18": (0.15, 0.60),
    "gpt-4.1": (2.00, 8.00),
    "gpt-4.1-mini": (0.40, 1.60),
    "gpt-4.1-nano": (0.10, 0.40),
    "o1": (15.00, 60.00),
    "o1-mini": (3.00, 12.00),
    "o3": (10.00, 40.00),
    "o3-mini": (1.10, 4.40),
    "o4-mini": (1.10, 4.40),
    # Anthropic
    "claude-sonnet-4-6": (3.00, 15.00),
    "claude-sonnet-4-20250514": (3.00, 15.00),
    "claude-haiku-4-5": (0.80, 4.00),
    "claude-3-5-haiku-20241022": (0.80, 4.00),
    "claude-3-5-sonnet-20241022": (3.00, 15.00),
    "claude-3-opus-20240229": (15.00, 75.00),
    "claude-opus-4-0": (15.00, 75.00),
}


def estimate_cost(
    model: str | None,
    input_tokens: int,
    output_tokens: int,
) -> float:
    """Return estimated cost in USD. Returns 0.0 for unknown models."""
    if not model:
        return 0.0

    prices = MODEL_PRICES.get(model)
    if not prices:
        return 0.0

    input_price, output_price = prices
    return (input_tokens * input_price + output_tokens * output_price) / 1_000_000
