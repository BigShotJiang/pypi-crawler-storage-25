"""Item parsing helpers.

Converts various input formats (tuples, dicts, DatasetItems) into
a uniform list of (prompt, expected) pairs.
"""

from __future__ import annotations

__all__ = ["parse_items"]

from evalora.core.types import DatasetItem


def parse_items(items: list) -> list[tuple[str, str | None]]:
    """Normalize a list of items into (prompt, expected) tuples.

    Accepts:
        - DatasetItem objects
        - (prompt, expected) tuples
        - {"prompt": ..., "expected": ...} dicts
        - plain strings (no expected)
    """
    parsed = []
    for item in items:
        if isinstance(item, DatasetItem):
            parsed.append((item.prompt, item.expected))
        elif isinstance(item, (list, tuple)) and len(item) >= 2:
            parsed.append((str(item[0]), str(item[1]) if item[1] is not None else None))
        elif isinstance(item, dict):
            parsed.append((str(item.get("prompt", "")), item.get("expected")))
        else:
            parsed.append((str(item), None))
    return parsed
