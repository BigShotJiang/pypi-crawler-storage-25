"""Core utilities — constants, types, exceptions, and helpers."""
