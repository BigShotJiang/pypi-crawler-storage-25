"""Core exceptions for the Evalora SDK."""


__all__ = ["EvaloraError", "AuthError", "ApiError"]


class EvaloraError(Exception):
    """Base exception for Evalora SDK."""


class AuthError(EvaloraError):
    """Invalid or missing API key."""


class ApiError(EvaloraError):
    """Backend returned an error."""

    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code
