"""Async Evalora client and run — full feature parity with sync client.

Usage:
    async with AsyncEvalora(api_key="evk_...") as ev:
        run = await ev.run(eval_id="...", template="chatbot")
        await run.eval_each(fn=ask)

    # Local mode (no account)
    ev = AsyncEvalora()
    run = await ev.run(judges=["Accuracy"], provider_keys={"openai": "sk-..."})
    await run.check(ask, "What is 2+2?", expected="4")
    await run.done()
"""

from __future__ import annotations

import asyncio
import time
from typing import Callable

import httpx

from evalora.core.constants import DEFAULT_BASE_URL, DEFAULT_TIMEOUT
from evalora.core.extraction import extract_result as _extract_result
from evalora.core.matching import check_match as _check_match
from evalora.core.exceptions import ApiError, AuthError
from evalora.ghost import GhostConfig, GhostServerConfig
from evalora.core.parsing import parse_items
from evalora.core.types import DatasetItem, RunStatus


class AsyncRun:
    """Async handle to an active eval run. Full parity with sync Run."""

    def __init__(
        self,
        id: str,
        status: str,
        client: AsyncEvalora,
        name: str | None = None,
        ghost_config: GhostConfig | None = None,
        ghost_server_config: GhostServerConfig | None = None,
        dataset_id: str | None = None,
        eval_id: str | None = None,
        model_name: str | None = None,
        local: bool = False,
        output_dir: str | None = None,
        validators: list | None = None,
        scoring: str = "exact",
        similarity_threshold: float = 0.85,
        embedding_api_key: str | None = None,
        embedding_model: str = "text-embedding-3-small",
        judges: list | None = None,
        judge_mode: str = "local",
        provider_keys: dict[str, str] | None = None,
        scorers: list | None = None,
        score_threshold: float = 0.5,
        max_cost: float | None = None,
        webhook: str | None = None,
    ):
        self.id = id
        self.status = status
        self.name = name
        self._client = client
        self._ghost_config = ghost_config or GhostConfig.from_param(False)
        self._ghost_server_config = ghost_server_config or GhostServerConfig.from_param(None, self._ghost_config)
        self._dataset_id = dataset_id
        self._eval_id = eval_id
        self._model_name = model_name
        self._local = local
        self._output_dir = output_dir
        self._log_count = 0
        self._logged_items: list[dict] = []
        self._validators = validators or []
        self._scoring = scoring
        self._similarity_threshold = similarity_threshold
        self._embedding_api_key = embedding_api_key
        self._embedding_model = embedding_model
        self._judges = judges or []
        self._judge_mode = judge_mode
        self._provider_keys = provider_keys or {}
        self._scorers = scorers or []
        self._score_threshold = score_threshold
        self._max_cost = max_cost
        self._cost_exceeded = False
        self._webhook = webhook
        self._results_path: str | None = None
        self._start_time = time.monotonic()
        self._total_input_tokens = 0
        self._total_output_tokens = 0
        self._total_cost = 0.0
        self._item_run_ids: list[str] = []

    @property
    def _ghost(self) -> bool:
        return self._ghost_config.enabled

    @property
    def url(self) -> str:
        if self._local:
            return "https://evalora.dev"
        base = self._client._base_url.replace("://api.", "://").replace(":4000", ":3000")
        return f"{base}/dashboard/runs/{self.id}"

    @property
    def results_path(self) -> str | None:
        return self._results_path

    @property
    def duration(self) -> float:
        return time.monotonic() - self._start_time

    @property
    def cost(self) -> float:
        return self._total_cost

    async def items(self) -> list[DatasetItem]:
        """Fetch dataset items from the backend."""
        if self._local or not self._dataset_id:
            return []
        data = await self._client._request("GET", f"/datasets/{self._dataset_id}")
        return [DatasetItem.from_dict(item) for item in data.get("items", [])]

    async def check(self, fn: Callable[[str], object], prompt: str, expected: str | None = None) -> str:
        """Call your function and log the result.

        fn can be sync or async — both are handled.
        """
        # Format instruction only in exact mode with expected and no judges
        effective_prompt = prompt
        if self._scoring == "exact" and expected and not self._judges:
            from evalora.core.formatting import with_format_instruction
            effective_prompt = with_format_instruction(prompt, expected)

        start = time.monotonic()
        if asyncio.iscoroutinefunction(fn):
            result = await fn(effective_prompt)
        else:
            result = fn(effective_prompt)
        elapsed = time.monotonic() - start

        response, metadata = _extract_result(result)
        await self.log(prompt=prompt, response=response, expected=expected, metadata=metadata)
        return response

    async def log(
        self,
        *,
        prompt: str,
        response: object,
        expected: str | None = None,
        category: str | None = None,
        metadata: dict | None = None,
    ) -> str:
        """Log a single item. response accepts str, OpenAI/Anthropic objects, or dicts."""
        # Auto-extract from response objects
        if not isinstance(response, str):
            extracted_text, extracted_meta = _extract_result(response)
            response = extracted_text
            if extracted_meta and not metadata:
                metadata = extracted_meta
            elif extracted_meta and metadata:
                metadata = {**extracted_meta, **metadata}

        # Track tokens/cost
        if metadata:
            self._total_input_tokens += metadata.get("_input_tokens", 0) or 0
            self._total_output_tokens += metadata.get("_output_tokens", 0) or 0
            if not self._model_name and metadata.get("_model"):
                self._model_name = metadata["_model"]
            from evalora.core.pricing import estimate_cost
            self._total_cost += estimate_cost(
                model=metadata.get("_model") or self._model_name,
                input_tokens=metadata.get("_input_tokens", 0) or 0,
                output_tokens=metadata.get("_output_tokens", 0) or 0,
            )

        # Scoring
        if self._scoring == "semantic" and expected and self._embedding_api_key:
            from evalora.scoring.similarity import compute_similarity
            try:
                similarity_score = compute_similarity(
                    response, expected, self._embedding_api_key,
                    model=self._embedding_model,
                )
                passed = similarity_score >= self._similarity_threshold
            except Exception:
                passed = _check_match(response, expected)
        else:
            passed = _check_match(response, expected)

        # Validators
        validator_reason = None
        if self._validators:
            for i, validator in enumerate(self._validators):
                try:
                    if not validator(response):
                        name = getattr(validator, "__name__", None)
                        label = name if name and name != "<lambda>" else f"#{i + 1}"
                        passed = False
                        validator_reason = f"Validator failed: {label}"
                        break
                except Exception as exc:
                    name = getattr(validator, "__name__", None)
                    label = name if name and name != "<lambda>" else f"#{i + 1}"
                    passed = False
                    validator_reason = f"Validator error ({label}): {exc}"
                    break

        # Scorers
        scorer_results = {}
        if self._scorers:
            import inspect
            for i, scorer in enumerate(self._scorers):
                sname = getattr(scorer, "__name__", None)
                label = sname if sname and sname != "<lambda>" else f"scorer_{i + 1}"
                try:
                    sig = inspect.signature(scorer)
                    if len(sig.parameters) >= 2:
                        score = scorer(response, expected)
                    else:
                        score = scorer(response)
                    score = max(0.0, min(1.0, float(score)))
                    scorer_results[label] = round(score, 4)
                except Exception:
                    scorer_results[label] = 0.0
            if scorer_results:
                avg = sum(scorer_results.values()) / len(scorer_results)
                if avg < self._score_threshold:
                    passed = False

        # Ghost redaction
        gc = self._ghost_config
        redacted_prompt = gc.redact("prompt", prompt)
        redacted_response = gc.redact("response", response)
        redacted_expected = gc.redact("expected", expected)

        self._logged_items.append({
            "prompt": redacted_prompt,
            "response": redacted_response,
            "expected": redacted_expected,
            "_real_prompt": prompt,
            "_real_response": response,
            "_real_expected": expected,
            "passed": passed,
            "category": category,
            **({"validator_reason": validator_reason} if validator_reason else {}),
            **({"scores": scorer_results} if scorer_results else {}),
        })

        if self._client._verbose:
            from evalora.output.display import print_log_item
            print_log_item(self._log_count, redacted_prompt, redacted_response, redacted_expected, passed=passed)

        self._log_count += 1

        # Send to backend
        if not self._ghost_server_config.send_to_server and not self._local:
            import uuid
            item_run_id = f"ghost-{uuid.uuid4().hex[:8]}"
        elif self._local:
            import uuid
            item_run_id = f"local-item-{uuid.uuid4().hex[:8]}"
        else:
            body: dict = {"prompt": redacted_prompt or "", "response": redacted_response or ""}
            if redacted_expected is not None:
                body["expected"] = redacted_expected
            if category:
                body["category"] = category
            data = await self._client._request("POST", f"/runs/{self.id}/items", json=body)
            item_run_id = data.get("id", "")

        self._item_run_ids.append(item_run_id)
        return item_run_id

    async def log_conversation(
        self,
        *,
        messages: list[dict],
        expected: str | None = None,
        category: str | None = None,
        metadata: dict | None = None,
    ) -> str:
        """Log a multi-turn conversation as a single eval item."""
        user_parts = []
        response_text = ""
        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")
            if role == "user":
                user_parts.append(content)
            elif role == "assistant":
                response_text = content
        prompt = " → ".join(user_parts) if user_parts else "(conversation)"
        return await self.log(prompt=prompt, response=response_text, expected=expected, category=category, metadata=metadata)

    async def eval_each(
        self,
        items: list | str | None = None,
        *,
        fn: Callable[[str], object] | None = None,
        raise_on_fail: bool = False,
    ) -> RunStatus:
        """Run your function on every item, log, complete, wait.

        Args:
            items: List of tuples/dicts, or a file path (.csv, .json, .jsonl).
            fn: Your AI function (sync or async).
            raise_on_fail: Raise EvaloraError if any items fail.
        """
        if fn is None:
            raise ValueError("fn is required — pass your AI function.")

        if isinstance(items, str):
            from evalora.eval.file_loader import load_items_from_file
            items = load_items_from_file(items)

        if items is None:
            items = await self.items()

        parsed = parse_items(items)
        is_async = asyncio.iscoroutinefunction(fn)

        for prompt, expected in parsed:
            if self._check_cost_guard():
                break

            effective_prompt = prompt
            if self._scoring == "exact" and expected and not self._judges:
                from evalora.core.formatting import with_format_instruction
                effective_prompt = with_format_instruction(prompt, expected)

            try:
                if is_async:
                    result = await fn(effective_prompt)
                else:
                    result = fn(effective_prompt)
                response, metadata = _extract_result(result)
            except Exception as exc:
                response = f"[ERROR] {type(exc).__name__}: {exc}"
                metadata = None

            await self.log(prompt=prompt, response=response, expected=expected, metadata=metadata)

        await self.complete()
        status = await self.wait()

        if raise_on_fail and status.failed > 0:
            from evalora.core.exceptions import EvaloraError
            raise EvaloraError(f"Eval failed: {status.failed}/{status.total} items did not pass")

        return status

    def _check_cost_guard(self) -> bool:
        if self._max_cost is None or self._max_cost <= 0 or self._cost_exceeded:
            return self._cost_exceeded
        if self._total_cost >= self._max_cost * 0.9:
            self._cost_exceeded = True
            if self._client._verbose:
                from evalora.output.display import console
                console.print(
                    f"\n[bold yellow]Cost guard triggered:[/bold yellow] "
                    f"${self._total_cost:.4f} >= ${self._max_cost:.2f} budget."
                )
            return True
        return False

    async def complete(self) -> RunStatus:
        """Signal no more items coming."""
        if self._client._verbose:
            from evalora.output.display import console
            console.print(f"\n[bold]Completing run...[/bold] ({self._log_count} items logged)")

        if self._local:
            return RunStatus(id=self.id, status="completed")

        data = await self._client._request("POST", f"/runs/{self.id}/complete")
        return RunStatus.from_dict(data)

    async def done(self) -> RunStatus:
        """Complete the run and wait for results."""
        await self.complete()
        status = await self.wait()

        # Send webhook
        if self._webhook:
            from evalora.output.webhook import send_webhook
            send_webhook(self, status)

        return status

    async def wait(self, poll_interval: float = 2.0, timeout: float = 300.0) -> RunStatus:
        """Wait for scoring to finish."""
        if self._local:
            total = self._log_count
            passed = sum(1 for i in self._logged_items if i.get("passed") is True)
            failed = sum(1 for i in self._logged_items if i.get("passed") is False)
            ungraded = sum(1 for i in self._logged_items if i.get("passed") is None)

            status = RunStatus(
                id=self.id, status="completed",
                total=total, passed=passed, failed=failed, needs_review=ungraded,
            )
            if self._client._verbose:
                from evalora.output.display import print_results
                print_results(status, run=self)

            self._save_results(status)
            return status

        terminal = {"completed", "failed", "canceled"}
        start = time.monotonic()
        while True:
            status = await self._client.get_run(self.id)
            if status.status in terminal:
                return status
            if time.monotonic() - start >= timeout:
                return status
            await asyncio.sleep(poll_interval)

    def _save_results(self, status):
        """Save run results to local JSON file."""
        from evalora.output.results import save_run
        from pathlib import Path
        from evalora.core.constants import DEFAULT_OUTPUT_DIR

        try:
            save_items = [
                {k: v for k, v in item.items() if not k.startswith("_")}
                for item in self._logged_items
            ]
            file_path = save_run(
                run_id=self.id,
                status=status.status if status else "unknown",
                items=save_items,
                model=self._ghost_config.redact_model(self._model_name),
                ghost_mode=self._ghost_config.mode if self._ghost_config.enabled else None,
                duration=self.duration,
                input_tokens=self._total_input_tokens,
                output_tokens=self._total_output_tokens,
                cost=self._total_cost,
                name=self.name,
                output_dir=self._output_dir,
            )
            self._results_path = str(file_path)
        except Exception:
            pass


class AsyncEvalora:
    """Async Evalora SDK client.

    Usage:
        # Connected
        async with AsyncEvalora(api_key="evk_...") as ev:
            run = await ev.run(eval_id="...")

        # Local (no account)
        ev = AsyncEvalora()
        run = await ev.run(template="chatbot")
    """

    def __init__(
        self,
        api_key: str = "",
        base_url: str = DEFAULT_BASE_URL,
        verbose: bool = True,
        timeout: float = DEFAULT_TIMEOUT,
        local: bool = False,
        output: str | None = None,
    ):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._verbose = verbose
        self._local = local or not api_key
        self._output_dir = output

        self._http: httpx.AsyncClient | None = None
        if not self._local:
            self._http = httpx.AsyncClient(
                base_url=f"{self._base_url}/v1",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=timeout,
            )

        if self._verbose:
            from evalora.output.display import print_banner
            print_banner()

    async def _request(self, method: str, path: str, **kwargs) -> dict:
        if self._local or not self._http:
            return {}

        while True:
            response = await self._http.request(method, path, **kwargs)

            if response.status_code == 429:
                retry_after = float(response.headers.get("retry-after", "2"))
                await asyncio.sleep(retry_after)
                continue
            break

        if response.status_code == 401:
            raise AuthError(
                "Invalid API key. Check that it starts with 'evk_' and hasn't expired. "
                "Generate a new key at https://evalora.dev/dashboard"
            )
        if response.status_code >= 400:
            body = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            raise ApiError(body.get("error", response.text), response.status_code)

        return response.json()

    async def run(
        self,
        eval_id: str = "",
        name: str | None = None,
        dataset_id: str | None = None,
        ghost: bool | str | dict = False,
        ghost_server: bool | None = None,
        judges: list | None = None,
        judge_mode: str = "local",
        provider_keys: dict[str, str] | None = None,
        validators: list | None = None,
        scoring: str | None = None,
        similarity_threshold: float = 0.85,
        embedding_api_key: str | None = None,
        embedding_model: str = "text-embedding-3-small",
        template: str | None = None,
        scorers: list | None = None,
        score_threshold: float = 0.5,
        max_cost: float | None = None,
        webhook: str | None = None,
    ) -> AsyncRun:
        """Create a run."""
        # Ghost config
        ghost_config = GhostConfig.from_param(ghost)
        ghost_server_config = GhostServerConfig.from_param(ghost_server, ghost_config)

        if ghost_config.enabled:
            import warnings
            mode_desc = {
                "full": "all text (prompts, responses, model, judge reasoning) will be redacted",
                "light": "responses will be redacted, prompts kept visible",
                "hash": "all text will be hashed (traceable but unreadable)",
                "custom": "per-field redaction is active",
            }
            desc = mode_desc.get(ghost_config.mode, "text will be redacted")
            warnings.warn(f"Ghost mode ({ghost_config.mode}): {desc}", stacklevel=2)

        # Template resolution
        if template:
            from evalora.templates import TEMPLATES
            key = template.lower().strip().replace(" ", "-")
            if key not in TEMPLATES:
                raise ValueError(f"Unknown template: '{template}'. Available: {', '.join(TEMPLATES.keys())}")
            tmpl = TEMPLATES[key]()
            if judges is None:
                judges = tmpl.get("judges")
            if validators is None:
                validators = tmpl.get("validators")

        # Smart defaults
        if scoring is None:
            scoring = "semantic" if embedding_api_key else "exact"
        if validators:
            from evalora.client import _normalize_validators
            validators = _normalize_validators(validators)

        # Local mode
        if self._local:
            import uuid
            run = AsyncRun(
                id=f"local-{uuid.uuid4().hex[:8]}",
                status="running",
                client=self,
                name=name,
                ghost_config=ghost_config,
                ghost_server_config=ghost_server_config,
                eval_id=eval_id or None,
                local=True,
                output_dir=self._output_dir,
                validators=validators or [],
                scoring=scoring,
                similarity_threshold=similarity_threshold,
                embedding_api_key=embedding_api_key,
                embedding_model=embedding_model,
                judges=judges or [],
                judge_mode=judge_mode,
                provider_keys=provider_keys or {},
                scorers=scorers or [],
                score_threshold=score_threshold,
                max_cost=max_cost,
                webhook=webhook,
            )
            if self._verbose:
                from evalora.output.display import print_run_created
                print_run_created(run.id, "", name=name)
            return run

        # Connected mode
        if not eval_id:
            raise ValueError(
                "eval_id is required when using an API key. "
                "Create an eval at https://evalora.dev/dashboard and pass its ID: "
                "ev.run(eval_id='evl_...')"
            )

        body: dict = {"evalId": eval_id}
        if dataset_id:
            body["datasetId"] = dataset_id

        data = await self._request("POST", "/runs", json=body)
        run_data = data.get("run", data)

        run = AsyncRun(
            id=run_data["id"],
            status=run_data.get("status", "running"),
            client=self,
            name=name,
            ghost_config=ghost_config,
            ghost_server_config=ghost_server_config,
            dataset_id=dataset_id,
            eval_id=eval_id,
            output_dir=self._output_dir,
            validators=validators or [],
            scoring=scoring,
            similarity_threshold=similarity_threshold,
            embedding_api_key=embedding_api_key,
            embedding_model=embedding_model,
            judges=judges or [],
            judge_mode=judge_mode,
            provider_keys=provider_keys or {},
            scorers=scorers or [],
            score_threshold=score_threshold,
            max_cost=max_cost,
            webhook=webhook,
        )

        if self._verbose:
            from evalora.output.display import print_run_created
            print_run_created(run.id, run.url, name=name, total_items=run_data.get("totalItems", 0))

        return run

    async def get_run(self, run_id: str) -> RunStatus:
        data = await self._request("GET", f"/runs/{run_id}")
        return RunStatus.from_dict(data)

    async def close(self):
        if self._http:
            await self._http.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
