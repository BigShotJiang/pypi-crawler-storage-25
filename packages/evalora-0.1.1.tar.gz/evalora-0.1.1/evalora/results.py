"""Backward-compatible re-export. Canonical location: evalora/output/results.py"""
from evalora.output.results import *  # noqa: F401,F403
from evalora.output.results import _fingerprint, _detect_version  # noqa: F401
