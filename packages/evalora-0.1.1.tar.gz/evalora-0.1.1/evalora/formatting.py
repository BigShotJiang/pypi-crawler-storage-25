"""Backward-compatible re-export. Canonical location: evalora/core/formatting.py"""
from evalora.core.formatting import *  # noqa: F401,F403
