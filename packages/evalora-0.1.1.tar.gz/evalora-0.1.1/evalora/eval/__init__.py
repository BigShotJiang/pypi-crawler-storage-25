"""Eval execution strategies — sequential, parallel, async."""
