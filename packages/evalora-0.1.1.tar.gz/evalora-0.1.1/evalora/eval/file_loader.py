"""Load eval items from files — CSV, JSON, JSONL."""

from __future__ import annotations

import json as json_mod
from pathlib import Path


def load_items_from_file(path: str) -> list[tuple[str, str | None]]:
    """Load eval items from a file. Auto-detects format from extension.

    Supported formats:
        - .csv: expects 'prompt' column, optional 'expected' column
        - .json: expects list of {"prompt": ..., "expected": ...} or [prompt, expected] tuples
        - .jsonl: one JSON object per line with 'prompt' and optional 'expected'
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Items file not found: {path}")

    suffix = p.suffix.lower()

    if suffix == ".csv":
        import csv
        items = []
        with open(p, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                prompt = row.get("prompt", "") or row.get("question", "") or row.get("input", "")
                expected = row.get("expected", "") or row.get("answer", "") or row.get("output", "") or None
                if expected == "":
                    expected = None
                items.append((prompt, expected))
        return items

    if suffix == ".jsonl":
        items = []
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                obj = json_mod.loads(line)
                if isinstance(obj, dict):
                    prompt = obj.get("prompt", "") or obj.get("question", "") or obj.get("input", "")
                    expected = obj.get("expected") or obj.get("answer") or obj.get("output")
                    items.append((prompt, expected))
                elif isinstance(obj, (list, tuple)) and len(obj) >= 2:
                    items.append((str(obj[0]), str(obj[1]) if obj[1] is not None else None))
        return items

    if suffix == ".json":
        with open(p, encoding="utf-8") as f:
            data = json_mod.load(f)
        if isinstance(data, list):
            from evalora.core.parsing import parse_items
            return parse_items(data)
        raise ValueError(f"JSON file must contain a list, got {type(data).__name__}")

    raise ValueError(f"Unsupported file format: {suffix}. Use .csv, .json, or .jsonl")
