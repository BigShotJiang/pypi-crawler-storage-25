"""LlamaIndex integration — auto-capture LLM calls into Evalora runs.

Usage:
    from evalora import Evalora
    from evalora.integrations.llamaindex import EvaloraCallbackHandler

    ev = Evalora()
    run = ev.run(judges=["Accuracy"])

    handler = EvaloraCallbackHandler(run)

    # Attach globally
    from llama_index.core import Settings
    Settings.callback_manager.add_handler(handler)

    # Or per-query
    index.as_query_engine(callbacks=[handler]).query("What is 2+2?")

    run.done()
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from evalora.run import Run


class EvaloraCallbackHandler:
    """LlamaIndex callback handler that logs LLM calls to an Evalora run.

    Implements the CBEventType.LLM event flow from llama_index.core.callbacks.
    Does not require llama_index as a dependency; uses duck typing.
    """

    def __init__(
        self,
        run: Run,
        expected: dict[str, str] | None = None,
    ):
        self._run = run
        self._expected = expected or {}
        self._pending: dict[str, dict] = {}

    def on_event_start(
        self,
        event_type: Any,
        payload: dict | None = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> str:
        """Called when a callback event starts."""
        import time

        # Check for LLM event type (works with string comparison too)
        event_name = str(event_type).lower() if event_type else ""
        if "llm" not in event_name:
            return event_id

        payload = payload or {}

        # Extract prompt from messages or serialized prompt
        prompt = ""
        messages = payload.get("messages")
        if messages:
            # LlamaIndex wraps messages as ChatMessage objects
            for msg in reversed(messages):
                role = getattr(msg, "role", "") or ""
                content = getattr(msg, "content", "") or ""
                if isinstance(role, str) and role.lower() in ("user", "human"):
                    prompt = content
                    break
                elif isinstance(msg, dict):
                    if msg.get("role", "").lower() in ("user", "human"):
                        prompt = msg.get("content", "")
                        break
            if not prompt and messages:
                first = messages[-1]
                prompt = getattr(first, "content", str(first))

        if not prompt:
            prompt = str(payload.get("template", ""))

        model = payload.get("model_name", "") or payload.get("model", "")

        self._pending[event_id] = {
            "prompt": prompt,
            "start_time": time.monotonic(),
            "model": model,
        }

        return event_id

    def on_event_end(
        self,
        event_type: Any,
        payload: dict | None = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> None:
        """Called when a callback event ends."""
        event_name = str(event_type).lower() if event_type else ""
        if "llm" not in event_name:
            return

        pending = self._pending.pop(event_id, None)
        if not pending:
            return

        payload = payload or {}

        # Extract response
        response_text = ""
        response_obj = payload.get("response")
        if response_obj:
            if hasattr(response_obj, "text"):
                response_text = response_obj.text
            elif hasattr(response_obj, "message") and hasattr(response_obj.message, "content"):
                response_text = response_obj.message.content
            elif isinstance(response_obj, str):
                response_text = response_obj

        if not response_text:
            completion = payload.get("completion")
            if completion:
                if hasattr(completion, "text"):
                    response_text = completion.text
                else:
                    response_text = str(completion)

        # Extract tokens
        metadata: dict[str, Any] = {}
        raw = payload.get("raw", {})
        usage = getattr(raw, "usage", None) or (raw.get("usage") if isinstance(raw, dict) else None)
        if usage:
            if hasattr(usage, "prompt_tokens"):
                metadata["_input_tokens"] = usage.prompt_tokens
                metadata["_output_tokens"] = usage.completion_tokens
            elif isinstance(usage, dict):
                metadata["_input_tokens"] = usage.get("prompt_tokens", 0)
                metadata["_output_tokens"] = usage.get("completion_tokens", 0)

        if pending.get("model"):
            metadata["_model"] = pending["model"]

        prompt = pending["prompt"]
        expected = self._expected.get(prompt)

        self._run.log(
            prompt=prompt,
            response=response_text,
            expected=expected,
            metadata=metadata or None,
        )

    # Required interface stubs
    def start_trace(self, trace_id: str | None = None) -> None: pass
    def end_trace(self, trace_id: str | None = None, trace_map: dict | None = None) -> None: pass
