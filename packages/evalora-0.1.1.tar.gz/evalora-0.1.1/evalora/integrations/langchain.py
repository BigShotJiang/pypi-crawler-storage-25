"""LangChain integration — auto-capture LLM calls into Evalora runs.

Usage:
    from evalora import Evalora
    from evalora.integrations.langchain import EvaloraCallbackHandler

    ev = Evalora()
    run = ev.run(judges=["Accuracy"])

    handler = EvaloraCallbackHandler(run)

    # Works with any LangChain chain, agent, or LLM
    chain.invoke("What is 2+2?", config={"callbacks": [handler]})

    # Or attach to an LLM directly
    llm = ChatOpenAI(callbacks=[handler])
    llm.invoke("What is 2+2?")

    run.done()
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from evalora.run import Run


class EvaloraCallbackHandler:
    """LangChain callback handler that logs LLM calls to an Evalora run.

    Implements the minimal callback interface — works with LangChain v0.1+ and v0.2+.
    Does not require langchain as a dependency; uses duck typing.
    """

    def __init__(
        self,
        run: Run,
        expected: dict[str, str] | None = None,
    ):
        """
        Args:
            run: The active Evalora Run to log to.
            expected: Optional dict mapping input prompts to expected answers.
        """
        self._run = run
        self._expected = expected or {}
        self._pending: dict[str, dict] = {}  # run_id -> {prompt, start_time, ...}

        # Required by LangChain's callback manager — must exist as attributes
        self.raise_error = False
        self.run_inline = False
        self.ignore_llm = False
        self.ignore_chat_model = False
        self.ignore_chain = True
        self.ignore_agent = True
        self.ignore_retriever = True
        self.ignore_retry = True
        self.ignore_custom_event = True

    # --- LangChain BaseCallbackHandler interface ---

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM starts generating."""
        import time
        prompt = prompts[0] if prompts else ""
        key = str(run_id) if run_id else str(id(prompts))
        self._pending[key] = {
            "prompt": prompt,
            "start_time": time.monotonic(),
            "model": serialized.get("kwargs", {}).get("model_name", ""),
        }

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[Any]],
        *,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Called when a chat model starts generating."""
        import time
        # Extract last user message
        prompt = ""
        if messages and messages[0]:
            for msg in reversed(messages[0]):
                content = ""
                if hasattr(msg, "content"):
                    content = msg.content
                elif isinstance(msg, dict):
                    content = msg.get("content", "")

                role = ""
                if hasattr(msg, "type"):
                    role = msg.type
                elif isinstance(msg, dict):
                    role = msg.get("role", "")

                if role in ("human", "user"):
                    prompt = content if isinstance(content, str) else str(content)
                    break

            if not prompt:
                first = messages[0][0]
                if hasattr(first, "content"):
                    prompt = first.content if isinstance(first.content, str) else str(first.content)

        key = str(run_id) if run_id else str(id(messages))
        model = serialized.get("kwargs", {}).get("model_name", "") or kwargs.get("invocation_params", {}).get("model", "")
        self._pending[key] = {
            "prompt": prompt,
            "start_time": time.monotonic(),
            "model": model,
        }

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM finishes generating."""
        key = str(run_id) if run_id else ""
        pending = self._pending.pop(key, None)

        # Extract response text
        text = ""
        if hasattr(response, "generations") and response.generations:
            gen = response.generations[0]
            if gen:
                first = gen[0]
                if hasattr(first, "text"):
                    text = first.text
                elif hasattr(first, "message") and hasattr(first.message, "content"):
                    text = first.message.content

        # Extract token usage
        metadata: dict[str, Any] = {}
        llm_output = getattr(response, "llm_output", None) or {}
        usage = llm_output.get("token_usage", {})
        if usage:
            metadata["_input_tokens"] = usage.get("prompt_tokens", 0)
            metadata["_output_tokens"] = usage.get("completion_tokens", 0)

        if pending:
            metadata["_model"] = pending.get("model", "")

        prompt = pending["prompt"] if pending else ""
        expected = self._expected.get(prompt)

        self._run.log(
            prompt=prompt,
            response=text,
            expected=expected,
            metadata=metadata or None,
        )

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM errors."""
        key = str(run_id) if run_id else ""
        pending = self._pending.pop(key, None)
        prompt = pending["prompt"] if pending else ""

        self._run.log(
            prompt=prompt,
            response=f"[ERROR] {type(error).__name__}: {error}",
        )

    # Stubs for the full interface — prevents AttributeError
    def on_chain_start(self, *args, **kwargs): pass
    def on_chain_end(self, *args, **kwargs): pass
    def on_chain_error(self, *args, **kwargs): pass
    def on_tool_start(self, *args, **kwargs): pass
    def on_tool_end(self, *args, **kwargs): pass
    def on_tool_error(self, *args, **kwargs): pass
    def on_text(self, *args, **kwargs): pass
    def on_agent_action(self, *args, **kwargs): pass
    def on_agent_finish(self, *args, **kwargs): pass
    def on_retriever_start(self, *args, **kwargs): pass
    def on_retriever_end(self, *args, **kwargs): pass
    def on_retriever_error(self, *args, **kwargs): pass
    def on_retry(self, *args, **kwargs): pass
