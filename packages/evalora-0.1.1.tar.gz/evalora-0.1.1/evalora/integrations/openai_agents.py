"""OpenAI Agents SDK integration — log agent runs to Evalora.

Usage:
    from agents import Agent, Runner
    from evalora import Evalora
    from evalora.integrations.openai_agents import from_agent_run

    ev = Evalora()
    run = ev.run(judges=["Accuracy", "Faithfulness"])

    agent = Agent(name="assistant", instructions="...")
    result = Runner.run_sync(agent, "What is 2+2?")

    # Log to Evalora — one line
    from_agent_run(result, run, expected="4")

    run.done()
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from evalora.run import Run


def from_agent_run(
    result: Any,
    run: Run,
    expected: str | None = None,
    category: str | None = None,
) -> str:
    """Log an OpenAI Agents SDK RunResult to an Evalora run.

    Args:
        result: The RunResult from Runner.run() or Runner.run_sync().
        run: Active Evalora run.
        expected: Optional expected answer.
        category: Optional category tag.

    Returns:
        The item ID from logging.
    """
    # Extract final output
    response_text = ""
    if hasattr(result, "final_output"):
        response_text = str(result.final_output) if result.final_output else ""
    elif isinstance(result, str):
        response_text = result

    # Extract prompt from input
    prompt = ""
    if hasattr(result, "input"):
        prompt = str(result.input) if result.input else ""

    # Try to get prompt from the first user message in new_items
    if not prompt and hasattr(result, "new_items"):
        for item in result.new_items:
            if hasattr(item, "role") and str(getattr(item, "role", "")).lower() == "user":
                content = getattr(item, "content", "")
                if isinstance(content, list):
                    texts = [getattr(c, "text", str(c)) for c in content]
                    prompt = " ".join(t for t in texts if t)
                elif isinstance(content, str):
                    prompt = content
                break

    if not prompt:
        prompt = "(agent task)"

    # Extract token usage
    metadata: dict[str, Any] = {}
    usage = getattr(result, "raw_responses", None)
    if usage and isinstance(usage, list):
        total_input = 0
        total_output = 0
        model = ""
        for resp in usage:
            u = getattr(resp, "usage", None)
            if u:
                total_input += getattr(u, "input_tokens", 0) or getattr(u, "prompt_tokens", 0) or 0
                total_output += getattr(u, "output_tokens", 0) or getattr(u, "completion_tokens", 0) or 0
            if not model:
                model = getattr(resp, "model", "")
        if total_input or total_output:
            metadata["_input_tokens"] = total_input
            metadata["_output_tokens"] = total_output
        if model:
            metadata["_model"] = model

    # Check for model on the result directly
    if "_model" not in metadata:
        model = getattr(result, "model", "")
        if model:
            metadata["_model"] = model

    return run.log(
        prompt=prompt,
        response=response_text,
        expected=expected,
        category=category or "openai-agents",
        metadata=metadata or None,
    )


def from_agent_messages(
    result: Any,
    run: Run,
    expected: dict[str, str] | None = None,
):
    """Log each agent message exchange as a separate eval item.

    Useful for multi-turn agent conversations where each turn should be evaluated.

    Args:
        result: The RunResult from Runner.run() or Runner.run_sync().
        run: Active Evalora run.
        expected: Optional dict mapping prompts to expected answers.
    """
    expected = expected or {}
    new_items = getattr(result, "new_items", [])

    # Pair user messages with assistant responses
    user_msg = ""
    for item in new_items:
        role = str(getattr(item, "role", "")).lower()
        content = getattr(item, "content", "")

        if isinstance(content, list):
            texts = [getattr(c, "text", str(c)) for c in content]
            content = " ".join(t for t in texts if t)

        if role == "user":
            user_msg = content if isinstance(content, str) else str(content)
        elif role == "assistant" and user_msg:
            response = content if isinstance(content, str) else str(content)
            run.log(
                prompt=user_msg,
                response=response,
                expected=expected.get(user_msg),
                category="openai-agents",
            )
            user_msg = ""
