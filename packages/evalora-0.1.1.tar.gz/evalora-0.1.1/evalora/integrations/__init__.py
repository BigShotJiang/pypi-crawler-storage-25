"""Framework integrations for Evalora.

Auto-capture LLM calls from popular frameworks into Evalora runs.

Usage:
    # LangChain
    from evalora.integrations.langchain import EvaloraCallbackHandler
    handler = EvaloraCallbackHandler(run)
    chain.invoke(input, config={"callbacks": [handler]})

    # LlamaIndex
    from evalora.integrations.llamaindex import EvaloraCallbackHandler
    llm = OpenAI(callbacks=[EvaloraCallbackHandler(run)])

    # CrewAI
    from evalora.integrations.crewai import from_crewai
    from_crewai(crew_output, run)

    # OpenAI Agents SDK
    from evalora.integrations.openai_agents import from_agent_run
    from_agent_run(result, run)
"""
