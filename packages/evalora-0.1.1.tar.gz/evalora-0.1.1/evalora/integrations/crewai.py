"""CrewAI integration — log crew execution results to Evalora runs.

Usage:
    from crewai import Crew, Agent, Task
    from evalora import Evalora
    from evalora.integrations.crewai import from_crewai

    ev = Evalora()
    run = ev.run(judges=["Accuracy", "Completeness"])

    # Run your crew normally
    crew = Crew(agents=[...], tasks=[...])
    result = crew.kickoff()

    # Log to Evalora — one line
    from_crewai(result, run)

    run.done()
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from evalora.run import Run


def from_crewai(
    result: Any,
    run: Run,
    expected: str | None = None,
    category: str | None = None,
) -> str:
    """Log a CrewAI kickoff result to an Evalora run.

    Args:
        result: The CrewOutput from crew.kickoff().
        run: Active Evalora run.
        expected: Optional expected answer.
        category: Optional category tag.

    Returns:
        The item ID from logging.
    """
    # Extract the final output
    raw = ""
    if hasattr(result, "raw"):
        raw = result.raw
    elif isinstance(result, str):
        raw = result
    elif hasattr(result, "__str__"):
        raw = str(result)

    # Extract prompt from tasks
    prompt = ""
    tasks_output = getattr(result, "tasks_output", [])
    if tasks_output:
        # Use the first task's description as the prompt
        first_task = tasks_output[0]
        prompt = getattr(first_task, "description", "") or getattr(first_task, "name", "")
    elif hasattr(result, "tasks") and result.tasks:
        prompt = getattr(result.tasks[0], "description", "")

    if not prompt:
        prompt = "(crew task)"

    # Extract token usage if available
    metadata: dict[str, Any] = {}
    usage = getattr(result, "token_usage", None)
    if usage:
        if isinstance(usage, dict):
            metadata["_input_tokens"] = usage.get("prompt_tokens", 0) or usage.get("total_tokens", 0)
            metadata["_output_tokens"] = usage.get("completion_tokens", 0)
        elif hasattr(usage, "prompt_tokens"):
            metadata["_input_tokens"] = usage.prompt_tokens
            metadata["_output_tokens"] = usage.completion_tokens

    return run.log(
        prompt=prompt,
        response=raw,
        expected=expected,
        category=category or "crewai",
        metadata=metadata or None,
    )


def from_crewai_tasks(
    result: Any,
    run: Run,
    expected: dict[str, str] | None = None,
):
    """Log each CrewAI task output as a separate eval item.

    Args:
        result: The CrewOutput from crew.kickoff().
        run: Active Evalora run.
        expected: Optional dict mapping task descriptions to expected answers.
    """
    expected = expected or {}
    tasks_output = getattr(result, "tasks_output", [])

    for task in tasks_output:
        description = getattr(task, "description", "") or getattr(task, "name", "Task")
        output = getattr(task, "raw", "") or str(task)

        run.log(
            prompt=description,
            response=output,
            expected=expected.get(description),
            category="crewai",
        )
