"""Tests for the Evalora Python SDK.

Covers parsing, matching, validators, formatting, pricing, checkpoint,
results, run basics, and extract_result. No real API server or OpenAI
keys required.
"""

import json
import time
from pathlib import Path

import pytest

from evalora.parsing import parse_items
from evalora.types import DatasetItem
from evalora.core.matching import check_match as _check_match, normalize as _normalize
from evalora.core.extraction import extract_result as _extract_result
from evalora.scoring.rubric import normalize_criteria as _normalize_criteria, build_criteria_prompt as _build_criteria_prompt
from evalora.scoring.judge_resolver import resolve_judges as _resolve_judges
from evalora.run import Run
from evalora.validators import (
    max_length,
    not_empty,
    no_refusal,
    expects_refusal,
    is_json,
    contains,
    matches_regex,
)
from evalora.formatting import (
    with_format_instruction,
    build_format_instruction,
    SHORT_ANSWER_INSTRUCTION,
)
from evalora.pricing import estimate_cost
from evalora.checkpoint import (
    save_checkpoint,
    load_checkpoint,
    clear_checkpoint,
    _hash_prompt,
    _fingerprint_items,
)
from evalora.results import save_run
from evalora.client import Evalora


# ──────────────────────────────────────────────
# 1. Parsing
# ──────────────────────────────────────────────


class TestParsing:
    def test_tuples(self):
        result = parse_items([("Q", "A")])
        assert result == [("Q", "A")]

    def test_none_expected_stays_none(self):
        result = parse_items([("Q", None)])
        assert result == [("Q", None)]
        # Must be actual None, not the string "None"
        assert result[0][1] is None

    def test_dicts(self):
        result = parse_items([{"prompt": "Q", "expected": "A"}])
        assert result == [("Q", "A")]

    def test_dataset_items(self):
        item = DatasetItem(id="1", prompt="Q", expected="A")
        result = parse_items([item])
        assert result == [("Q", "A")]

    def test_plain_strings(self):
        result = parse_items(["Q"])
        assert result == [("Q", None)]

    def test_mixed_inputs(self):
        items = [
            ("Q1", "A1"),
            {"prompt": "Q2", "expected": "A2"},
            DatasetItem(id="3", prompt="Q3", expected="A3"),
            "Q4",
        ]
        result = parse_items(items)
        assert result == [
            ("Q1", "A1"),
            ("Q2", "A2"),
            ("Q3", "A3"),
            ("Q4", None),
        ]

    def test_dict_missing_expected(self):
        result = parse_items([{"prompt": "Q"}])
        assert result == [("Q", None)]


# ──────────────────────────────────────────────
# 2. Matching
# ──────────────────────────────────────────────


class TestMatching:
    def test_exact_match(self):
        assert _check_match("Paris", "Paris") is True

    def test_contains_match(self):
        assert _check_match("The capital is Paris", "Paris") is True

    def test_word_set_match(self):
        assert _check_match(
            "executive legislative judicial",
            "Legislative, Executive, Judicial",
        ) is True

    def test_case_insensitive(self):
        assert _check_match("paris", "Paris") is True

    def test_unicode(self):
        assert _check_match("Buenos días", "Buenos dias") is True

    def test_no_match(self):
        assert _check_match("London", "Paris") is False

    def test_none_expected(self):
        assert _check_match("anything", None) is None

    def test_normalize_strips_accents(self):
        assert _normalize("café") == "cafe"

    def test_normalize_lowercases(self):
        assert _normalize("HELLO") == "hello"

    def test_normalize_strips_inverted_punctuation(self):
        assert _normalize("¿Hola?") == "hola?"


# ──────────────────────────────────────────────
# 3. Validators
# ──────────────────────────────────────────────


class TestValidators:
    def test_max_length_passes(self):
        assert max_length(10)("short") is True

    def test_max_length_fails(self):
        assert max_length(3)("long text") is False

    def test_not_empty_passes(self):
        assert not_empty("hello") is True

    def test_not_empty_fails_empty(self):
        assert not_empty("") is False

    def test_not_empty_fails_whitespace(self):
        assert not_empty("   ") is False

    def test_no_refusal_passes(self):
        assert no_refusal("Hello!") is True

    def test_no_refusal_fails(self):
        assert no_refusal("I'm sorry, I cannot") is False

    def test_expects_refusal_passes(self):
        assert expects_refusal("I can't do that") is True

    def test_expects_refusal_fails(self):
        assert expects_refusal("Sure, here you go") is False

    def test_is_json_valid(self):
        assert is_json('{"a": 1}') is True

    def test_is_json_invalid(self):
        assert is_json("not json") is False

    def test_contains_passes(self):
        assert contains("hello")("say hello world") is True

    def test_contains_fails(self):
        assert contains("hello")("goodbye") is False

    def test_matches_regex_passes(self):
        assert matches_regex(r"\d+")("abc123") is True

    def test_matches_regex_fails(self):
        assert matches_regex(r"\d+")("no digits") is False


# ──────────────────────────────────────────────
# 4. Formatting
# ──────────────────────────────────────────────


class TestFormatting:
    def test_with_format_instruction_appends(self):
        result = with_format_instruction("Q", "A")
        assert result.startswith("Q")
        assert len(result) > len("Q")
        assert SHORT_ANSWER_INSTRUCTION in result

    def test_with_format_instruction_no_expected(self):
        result = with_format_instruction("Q", None)
        assert result == "Q"

    def test_build_classification(self):
        result = build_format_instruction("classification", ["A", "B", "C"])
        assert "A" in result
        assert "B" in result
        assert "C" in result
        assert "EXACTLY one" in result

    def test_build_short_answer(self):
        result = build_format_instruction("short_answer", None)
        assert result == SHORT_ANSWER_INSTRUCTION

    def test_build_free(self):
        result = build_format_instruction("free", None)
        assert result == ""

    def test_with_custom_format_instruction(self):
        custom = "\n\nRespond in JSON."
        result = with_format_instruction("Q", "A", format_instruction=custom)
        assert result == "Q\n\nRespond in JSON."


# ──────────────────────────────────────────────
# 5. Pricing
# ──────────────────────────────────────────────


class TestPricing:
    def test_known_model(self):
        cost = estimate_cost("gpt-4o-mini", 1000, 500)
        assert isinstance(cost, float)
        assert cost > 0

    def test_unknown_model(self):
        assert estimate_cost("unknown-model", 1000, 500) == 0.0

    def test_none_model(self):
        assert estimate_cost(None, 0, 0) == 0.0

    def test_zero_tokens(self):
        assert estimate_cost("gpt-4o-mini", 0, 0) == 0.0


# ──────────────────────────────────────────────
# 6. Checkpoint
# ──────────────────────────────────────────────


class TestCheckpoint:
    def test_save_and_load_roundtrip(self, tmp_output):
        save_checkpoint(
            "test-run",
            "run-123",
            ["hash1", "hash2"],
            "fp-abc",
            output_dir=tmp_output,
        )
        data = load_checkpoint("test-run", output_dir=tmp_output)
        assert data is not None
        assert data["run_id"] == "run-123"
        assert data["completed_hashes"] == ["hash1", "hash2"]
        assert data["fingerprint"] == "fp-abc"
        assert data["completed_count"] == 2

    def test_load_missing_returns_none(self, tmp_output):
        result = load_checkpoint("nonexistent", output_dir=tmp_output)
        assert result is None

    def test_clear_removes_file(self, tmp_output):
        save_checkpoint("clear-me", "run-1", ["h"], "fp", output_dir=tmp_output)
        assert load_checkpoint("clear-me", output_dir=tmp_output) is not None
        clear_checkpoint("clear-me", output_dir=tmp_output)
        assert load_checkpoint("clear-me", output_dir=tmp_output) is None

    def test_hash_prompt_consistent(self):
        h1 = _hash_prompt("What is 2+2?")
        h2 = _hash_prompt("What is 2+2?")
        assert h1 == h2
        assert isinstance(h1, str)
        assert len(h1) > 0

    def test_hash_prompt_different_inputs(self):
        assert _hash_prompt("a") != _hash_prompt("b")

    def test_fingerprint_items_consistent(self):
        fp1 = _fingerprint_items(["Q1", "Q2"])
        fp2 = _fingerprint_items(["Q1", "Q2"])
        assert fp1 == fp2
        assert isinstance(fp1, str)
        assert len(fp1) > 0

    def test_fingerprint_items_order_independent(self):
        fp1 = _fingerprint_items(["Q1", "Q2"])
        fp2 = _fingerprint_items(["Q2", "Q1"])
        assert fp1 == fp2


# ──────────────────────────────────────────────
# 7. Results
# ──────────────────────────────────────────────


class TestResults:
    def test_save_run_creates_file(self, tmp_output):
        items = [
            {"prompt": "Q1", "response": "A1", "expected": "A1", "passed": True},
            {"prompt": "Q2", "response": "wrong", "expected": "A2", "passed": False},
        ]
        path = save_run(
            run_id="run-test-1",
            status="completed",
            items=items,
            output_dir=tmp_output,
        )
        assert path.exists()
        assert path.suffix == ".json"

    def test_save_run_contains_expected_fields(self, tmp_output):
        items = [{"prompt": "Q", "response": "A", "expected": "A", "passed": True}]
        path = save_run(
            run_id="run-fields",
            status="completed",
            items=items,
            output_dir=tmp_output,
        )
        data = json.loads(path.read_text())
        assert data["run_id"] == "run-fields"
        assert "summary" in data
        assert "items" in data
        assert data["summary"]["total"] == 1
        assert data["summary"]["passed"] == 1

    def test_version_detection_same_prompts(self, tmp_output):
        items = [{"prompt": "Q", "response": "A", "expected": "A", "passed": True}]
        path1 = save_run(
            run_id="run-v1",
            status="completed",
            items=items,
            output_dir=tmp_output,
        )
        path2 = save_run(
            run_id="run-v2",
            status="completed",
            items=items,
            output_dir=tmp_output,
        )
        data1 = json.loads(path1.read_text())
        data2 = json.loads(path2.read_text())
        assert data1["version"] == data2["version"]

    def test_version_detection_different_prompts(self, tmp_output):
        items_a = [{"prompt": "Q1", "response": "A", "expected": "A", "passed": True}]
        items_b = [{"prompt": "Q2", "response": "A", "expected": "A", "passed": True}]
        path_a = save_run(
            run_id="run-a",
            status="completed",
            items=items_a,
            output_dir=tmp_output,
        )
        path_b = save_run(
            run_id="run-b",
            status="completed",
            items=items_b,
            output_dir=tmp_output,
        )
        data_a = json.loads(path_a.read_text())
        data_b = json.loads(path_b.read_text())
        assert data_a["version"] != data_b["version"]


# ──────────────────────────────────────────────
# 8. Run basics
# ──────────────────────────────────────────────


class TestRun:
    def test_local_mode(self):
        ev = Evalora(local=True, verbose=False)
        run = ev.run()
        assert run.id.startswith("local-")
        assert run._local is True

    def test_done(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        run.log(prompt="Q", response="A", expected="A")
        status = run.done()
        assert status.status == "completed"

    def test_check_with_string_return(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        response = run.check(lambda p: "Paris", "What is the capital of France?", expected="Paris")
        assert response == "Paris"

    def test_check_with_dict_return(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()

        def mock_fn(prompt):
            return {
                "response": "Paris",
                "input_tokens": 10,
                "output_tokens": 5,
                "model": "test-model",
            }

        response = run.check(mock_fn, "Capital?", expected="Paris")
        assert response == "Paris"
        assert run._total_input_tokens == 10
        assert run._total_output_tokens == 5

    def test_eval_each_with_tuples(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        status = run.eval_each(
            [("What is 1+1?", "2"), ("What is 2+2?", "4")],
            fn=lambda p: "2" if "1+1" in p else "4",
        )
        assert status.status == "completed"
        assert run._log_count == 2

    def test_eval_each_skips_completed_on_resume(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)

        # First run: complete some items
        run1 = ev.run(name="resume-test")
        run1.eval_each(
            [("Q1", "A1"), ("Q2", "A2")],
            fn=lambda p: "A1" if "Q1" in p else "A2",
        )

        # Save a checkpoint manually that marks Q1 as completed
        from evalora.checkpoint import _hash_prompt, _fingerprint_items

        q1_hash = _hash_prompt("Q1")
        fingerprint = _fingerprint_items(["Q1", "Q2"])
        save_checkpoint(
            "resume-test",
            "local-resumed",
            [q1_hash],
            fingerprint,
            output_dir=tmp_output,
        )

        # Second run: resume should skip Q1
        run2 = ev.run(name="resume-test", resume=True)
        call_count = 0

        def counting_fn(prompt):
            nonlocal call_count
            call_count += 1
            return "A2"

        run2.eval_each([("Q1", "A1"), ("Q2", "A2")], fn=counting_fn)
        assert call_count == 1  # Only Q2 should have been called

    def test_ghost_mode(self, tmp_output):
        import warnings
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            run = ev.run(ghost=True)
        run.log(prompt="secret prompt", response="secret answer", expected="secret answer")
        logged = run._logged_items[0]
        # ghost=True → "full" mode: everything redacted
        assert logged["prompt"] == "[redacted]"
        assert logged["response"] == "[redacted]"
        assert logged["expected"] == "[redacted]"
        assert "secret" not in logged["prompt"]
        # _real_ fields exist for judges
        assert logged["_real_prompt"] == "secret prompt"

    def test_validators_run_before_logging(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(validators=[not_empty])
        run.log(prompt="Q", response="", expected="A")
        logged = run._logged_items[0]
        assert logged["passed"] is False
        assert "validator_reason" in logged

    def test_name_shows_in_run(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(name="my-eval")
        assert run.name == "my-eval"

    def test_results_path_set_after_done(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        run.log(prompt="Q", response="A", expected="A")
        assert run.results_path is None
        run.done()
        assert run.results_path is not None
        assert Path(run.results_path).exists()

    def test_run_properties(self):
        ev = Evalora(local=True, verbose=False)
        run = ev.run(model="gpt-4o-mini")
        assert run.model == "gpt-4o-mini"
        assert run.duration >= 0
        assert run.tokens == (0, 0, 0)
        assert run.cost == 0.0


# ──────────────────────────────────────────────
# 9. Extract result
# ──────────────────────────────────────────────


class TestExtractResult:
    def test_string_input(self):
        response, metadata = _extract_result("Hello")
        assert response == "Hello"
        assert metadata is None

    def test_dict_input(self):
        result = {
            "response": "Paris",
            "input_tokens": 10,
            "output_tokens": 5,
            "model": "gpt-4o",
        }
        response, metadata = _extract_result(result)
        assert response == "Paris"
        assert metadata["_input_tokens"] == 10
        assert metadata["_output_tokens"] == 5
        assert metadata["_model"] == "gpt-4o"

    def test_dict_response_only(self):
        response, metadata = _extract_result({"response": "Hello"})
        assert response == "Hello"
        assert metadata is None

    def test_string_stripped(self):
        response, metadata = _extract_result("  Hello  ")
        assert response == "Hello"

    def test_non_string_coerced(self):
        response, metadata = _extract_result(42)
        assert response == "42"
        assert metadata is None


# ──────────────────────────────────────────────
# 10. Rubric criteria and auto-detection
# ──────────────────────────────────────────────


class TestRubricCriteria:
    def test_normalize_string_criteria(self):
        result = _normalize_criteria(["accuracy", "clarity"])
        assert result == [{"name": "accuracy"}, {"name": "clarity"}]

    def test_normalize_dict_criteria(self):
        raw = [{"name": "accuracy", "description": "Is it correct?", "weight": 2}]
        result = _normalize_criteria(raw)
        assert result == raw

    def test_normalize_mixed_criteria(self):
        raw = ["tone", {"name": "accuracy", "weight": 3}]
        result = _normalize_criteria(raw)
        assert result == [{"name": "tone"}, {"name": "accuracy", "weight": 3}]

    def test_normalize_empty(self):
        assert _normalize_criteria([]) == []

    def test_build_criteria_prompt_basic(self):
        criteria = [{"name": "accuracy"}, {"name": "clarity"}]
        prompt = _build_criteria_prompt(criteria)
        assert "accuracy" in prompt
        assert "clarity" in prompt

    def test_build_criteria_prompt_with_descriptions(self):
        criteria = [
            {"name": "accuracy", "description": "Is the response factually correct?"},
        ]
        prompt = _build_criteria_prompt(criteria)
        assert "accuracy: Is the response factually correct?" in prompt

    def test_build_criteria_prompt_with_anchors(self):
        criteria = [
            {
                "name": "accuracy",
                "anchors": {1: "Completely wrong", 5: "Perfectly accurate"},
            },
        ]
        prompt = _build_criteria_prompt(criteria)
        assert "1 = Completely wrong" in prompt
        assert "5 = Perfectly accurate" in prompt

    def test_build_criteria_prompt_with_weight(self):
        criteria = [{"name": "accuracy", "weight": 3}]
        prompt = _build_criteria_prompt(criteria)
        assert "weight: 3x" in prompt

    def test_build_criteria_prompt_weight_1_hidden(self):
        criteria = [{"name": "accuracy", "weight": 1}]
        prompt = _build_criteria_prompt(criteria)
        assert "weight" not in prompt


class TestAutoDetection:
    def test_auto_semantic_from_embedding_key(self):
        ev = Evalora(local=True, verbose=False)
        run = ev.run(embedding_api_key="sk-test")
        assert run._scoring == "semantic"

    def test_explicit_exact_overrides_embedding_key(self):
        ev = Evalora(local=True, verbose=False)
        run = ev.run(scoring="exact", embedding_api_key="sk-test")
        assert run._scoring == "exact"

    def test_default_scoring_is_exact(self):
        ev = Evalora(local=True, verbose=False)
        run = ev.run()
        assert run._scoring == "exact"

    def test_string_validators_resolved(self):
        ev = Evalora(local=True, verbose=False)
        run = ev.run(validators=["not_empty", "is_json"])
        assert len(run._validators) == 2
        assert all(callable(v) for v in run._validators)
        assert run._validators[0]("") is False
        assert run._validators[0]("hello") is True

    def test_mixed_validators(self):
        ev = Evalora(local=True, verbose=False)
        custom = lambda r: len(r) > 5
        run = ev.run(validators=["not_empty", custom])
        assert len(run._validators) == 2
        assert callable(run._validators[0])
        assert run._validators[1] is custom

    def test_unknown_string_validator_raises(self):
        ev = Evalora(local=True, verbose=False)
        with pytest.raises(ValueError, match="Unknown validator"):
            ev.run(validators=["nonexistent_validator"])

    def test_callable_validators_pass_through(self):
        ev = Evalora(local=True, verbose=False)
        fn = lambda r: True
        run = ev.run(validators=[fn])
        assert run._validators[0] is fn


class TestWeightedAverage:
    def test_equal_weights(self):
        """Weighted average with default weight=1 equals simple average."""
        criteria = _normalize_criteria(["a", "b", "c"])
        scores = {"a": 4, "b": 3, "c": 5}
        total_weight = sum(c.get("weight", 1) for c in criteria)
        weighted = sum(scores[c["name"]] * c.get("weight", 1) for c in criteria)
        assert weighted / total_weight == 4.0

    def test_weighted_scores(self):
        """Heavier criteria pull the average."""
        criteria = [
            {"name": "accuracy", "weight": 3},
            {"name": "tone", "weight": 1},
        ]
        scores = {"accuracy": 5, "tone": 1}
        total_weight = sum(c.get("weight", 1) for c in criteria)
        weighted = sum(scores[c["name"]] * c.get("weight", 1) for c in criteria)
        avg = weighted / total_weight
        # (5*3 + 1*1) / 4 = 16/4 = 4.0
        assert avg == 4.0

    def test_single_criterion_weight_irrelevant(self):
        criteria = [{"name": "quality", "weight": 10}]
        scores = {"quality": 3}
        total_weight = sum(c.get("weight", 1) for c in criteria)
        weighted = sum(scores[c["name"]] * c.get("weight", 1) for c in criteria)
        assert weighted / total_weight == 3.0


# ──────────────────────────────────────────────
# 12. Judge presets
# ──────────────────────────────────────────────


class TestJudgePresets:
    def test_resolve_string_preset(self):
        result = _resolve_judges(["Accuracy"])
        assert len(result) == 1
        assert result[0]["name"] == "Accuracy"
        assert result[0]["provider"] == "openai"
        assert result[0]["model"] == "gpt-4o"
        assert "prompt" in result[0]

    def test_resolve_case_insensitive(self):
        result = _resolve_judges(["accuracy", "SAFETY", "Hallucination"])
        assert len(result) == 3
        assert result[0]["name"] == "Accuracy"
        assert result[1]["name"] == "Safety"
        assert result[2]["name"] == "Hallucination"

    def test_resolve_all_presets(self):
        from evalora.judges import PRESETS
        all_names = list(PRESETS.keys())
        result = _resolve_judges(all_names)
        assert len(result) == len(all_names)
        for r in result:
            assert "name" in r
            assert "provider" in r
            assert "model" in r
            assert "prompt" in r

    def test_unknown_preset_raises(self):
        with pytest.raises(ValueError, match="Unknown judge preset"):
            _resolve_judges(["nonexistent_judge"])

    def test_dict_passthrough(self):
        custom = {
            "name": "Custom",
            "provider": "anthropic",
            "model": "claude-sonnet-4-6",
            "prompt": "Is this good?",
        }
        result = _resolve_judges([custom])
        assert result[0] is custom

    def test_dict_name_merges_preset_defaults(self):
        """A dict with a preset name but no prompt gets preset defaults merged in."""
        result = _resolve_judges([{"name": "Accuracy", "model": "gpt-4o-mini"}])
        assert result[0]["model"] == "gpt-4o-mini"  # user override wins
        assert result[0]["provider"] == "openai"  # preset default
        assert "factually accurate" in result[0]["prompt"].lower()  # preset prompt

    def test_dict_with_custom_prompt_no_merge(self):
        """A dict with a preset name AND a custom prompt keeps the custom prompt."""
        result = _resolve_judges([{
            "name": "Accuracy",
            "prompt": "My custom prompt",
            "provider": "anthropic",
            "model": "claude-sonnet-4-6",
        }])
        assert result[0]["prompt"] == "My custom prompt"
        assert result[0]["provider"] == "anthropic"

    def test_mixed_strings_and_dicts(self):
        result = _resolve_judges([
            "Safety",
            {"name": "Custom", "provider": "openai", "model": "gpt-4o", "prompt": "Check it"},
            "Accuracy",
        ])
        assert len(result) == 3
        assert result[0]["name"] == "Safety"
        assert result[1]["name"] == "Custom"
        assert result[2]["name"] == "Accuracy"

    def test_preset_function_call(self):
        from evalora.judges import accuracy, safety
        result = _resolve_judges([accuracy(), safety(model="gpt-4o-mini")])
        assert result[0]["name"] == "Accuracy"
        assert result[1]["name"] == "Safety"
        assert result[1]["model"] == "gpt-4o-mini"

    def test_preset_with_overrides(self):
        from evalora.judges import hallucination
        j = hallucination(provider="anthropic", model="claude-sonnet-4-6")
        assert j["provider"] == "anthropic"
        assert j["model"] == "claude-sonnet-4-6"
        assert j["name"] == "Hallucination"


# ──────────────────────────────────────────────
# 13. Smart response extraction
# ──────────────────────────────────────────────


class _FakeUsage:
    def __init__(self, prompt_tokens=10, completion_tokens=5):
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens


class _FakeMessage:
    def __init__(self, content="Paris"):
        self.content = content


class _FakeChoice:
    def __init__(self, message=None):
        self.message = message or _FakeMessage()


class _FakeOpenAIResponse:
    """Mimics openai.types.chat.ChatCompletion."""
    def __init__(self, content="Paris", model="gpt-4o"):
        self.choices = [_FakeChoice(_FakeMessage(content))]
        self.usage = _FakeUsage()
        self.model = model


class _FakeAnthropicContent:
    def __init__(self, text="Paris"):
        self.text = text


class _FakeAnthropicUsage:
    def __init__(self):
        self.input_tokens = 15
        self.output_tokens = 8


class _FakeAnthropicResponse:
    """Mimics anthropic.types.Message."""
    def __init__(self, text="Paris", model="claude-sonnet-4-6"):
        self.content = [_FakeAnthropicContent(text)]
        self.stop_reason = "end_turn"
        self.usage = _FakeAnthropicUsage()
        self.model = model


class TestSmartExtraction:
    def test_openai_response(self):
        resp = _FakeOpenAIResponse("The answer is 4", "gpt-4o-mini")
        text, meta = _extract_result(resp)
        assert text == "The answer is 4"
        assert meta["_model"] == "gpt-4o-mini"
        assert meta["_input_tokens"] == 10
        assert meta["_output_tokens"] == 5

    def test_anthropic_response(self):
        resp = _FakeAnthropicResponse("Hello world", "claude-sonnet-4-6")
        text, meta = _extract_result(resp)
        assert text == "Hello world"
        assert meta["_model"] == "claude-sonnet-4-6"
        assert meta["_input_tokens"] == 15
        assert meta["_output_tokens"] == 8

    def test_string_still_works(self):
        text, meta = _extract_result("plain text")
        assert text == "plain text"
        assert meta is None

    def test_dict_still_works(self):
        text, meta = _extract_result({"response": "ok", "input_tokens": 3})
        assert text == "ok"
        assert meta["_input_tokens"] == 3

    def test_log_accepts_openai_response(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        resp = _FakeOpenAIResponse("Paris", "gpt-4o")
        run.log(prompt="Capital of France?", response=resp, expected="Paris")
        assert run._logged_items[0]["passed"] is True
        assert run._total_input_tokens == 10
        assert run._total_output_tokens == 5

    def test_log_accepts_anthropic_response(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        resp = _FakeAnthropicResponse("Paris")
        run.log(prompt="Capital of France?", response=resp, expected="Paris")
        assert run._logged_items[0]["passed"] is True
        assert run._total_input_tokens == 15

    def test_check_auto_extracts_openai(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        response = run.check(
            lambda p: _FakeOpenAIResponse("4", "gpt-4o"),
            "What is 2+2?",
            expected="4",
        )
        assert response == "4"
        assert run._total_input_tokens == 10


# ──────────────────────────────────────────────
# 14. File loading
# ──────────────────────────────────────────────


class TestFileLoading:
    def test_csv_loading(self, tmp_path):
        from evalora.eval.file_loader import load_items_from_file as _load_items_from_file
        csv_file = tmp_path / "data.csv"
        csv_file.write_text("prompt,expected\nWhat is 2+2?,4\nCapital of France?,Paris\n")
        items = _load_items_from_file(str(csv_file))
        assert len(items) == 2
        assert items[0] == ("What is 2+2?", "4")
        assert items[1] == ("Capital of France?", "Paris")

    def test_csv_alt_columns(self, tmp_path):
        from evalora.eval.file_loader import load_items_from_file as _load_items_from_file
        csv_file = tmp_path / "data.csv"
        csv_file.write_text("question,answer\nWhat is 2+2?,4\n")
        items = _load_items_from_file(str(csv_file))
        assert items[0] == ("What is 2+2?", "4")

    def test_jsonl_loading(self, tmp_path):
        from evalora.eval.file_loader import load_items_from_file as _load_items_from_file
        jsonl_file = tmp_path / "data.jsonl"
        jsonl_file.write_text(
            '{"prompt": "Q1", "expected": "A1"}\n'
            '{"prompt": "Q2", "expected": "A2"}\n'
        )
        items = _load_items_from_file(str(jsonl_file))
        assert len(items) == 2
        assert items[0] == ("Q1", "A1")

    def test_json_loading(self, tmp_path):
        import json
        from evalora.eval.file_loader import load_items_from_file as _load_items_from_file
        json_file = tmp_path / "data.json"
        json_file.write_text(json.dumps([
            {"prompt": "Q1", "expected": "A1"},
            {"prompt": "Q2", "expected": "A2"},
        ]))
        items = _load_items_from_file(str(json_file))
        assert len(items) == 2

    def test_csv_no_expected(self, tmp_path):
        from evalora.eval.file_loader import load_items_from_file as _load_items_from_file
        csv_file = tmp_path / "data.csv"
        csv_file.write_text("prompt\nWhat is AI?\nExplain ML\n")
        items = _load_items_from_file(str(csv_file))
        assert items[0] == ("What is AI?", None)
        assert items[1] == ("Explain ML", None)

    def test_missing_file_raises(self):
        from evalora.eval.file_loader import load_items_from_file as _load_items_from_file
        with pytest.raises(FileNotFoundError):
            _load_items_from_file("/nonexistent/file.csv")

    def test_unsupported_format_raises(self, tmp_path):
        from evalora.eval.file_loader import load_items_from_file as _load_items_from_file
        txt_file = tmp_path / "data.txt"
        txt_file.write_text("hello")
        with pytest.raises(ValueError, match="Unsupported file format"):
            _load_items_from_file(str(txt_file))

    def test_eval_each_with_csv(self, tmp_output, tmp_path):
        csv_file = tmp_path / "data.csv"
        csv_file.write_text("prompt,expected\nQ1,A1\nQ2,A2\n")
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        status = run.eval_each(str(csv_file), fn=lambda p: "A1" if "Q1" in p else "A2")
        assert status.total == 2


# ──────────────────────────────────────────────
# 15. Wrapper tests
# ──────────────────────────────────────────────


class TestWrappers:
    def test_extract_prompt_from_messages(self):
        from evalora.wrappers import _extract_prompt
        messages = [
            {"role": "system", "content": "You are helpful"},
            {"role": "user", "content": "What is 2+2?"},
        ]
        assert _extract_prompt(messages) == "What is 2+2?"

    def test_extract_prompt_last_user(self):
        from evalora.wrappers import _extract_prompt
        messages = [
            {"role": "user", "content": "First question"},
            {"role": "assistant", "content": "First answer"},
            {"role": "user", "content": "Follow up"},
        ]
        assert _extract_prompt(messages) == "Follow up"

    def test_extract_prompt_empty(self):
        from evalora.wrappers import _extract_prompt
        assert _extract_prompt([]) == ""

    def test_wrap_unsupported_raises(self):
        from evalora.wrappers import wrap
        ev = Evalora(local=True, verbose=False)
        run = ev.run()
        with pytest.raises(TypeError, match="Unsupported client type"):
            wrap("not a client", run)


# ──────────────────────────────────────────────
# 16. Format instruction skipping
# ──────────────────────────────────────────────


class TestPromptFormatting:
    def test_exact_mode_adds_format_instruction(self, tmp_output):
        """In exact mode with expected, format instruction IS appended to help LLM be terse."""
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()  # defaults to scoring="exact"

        received_prompt = None
        def capture_fn(prompt):
            nonlocal received_prompt
            received_prompt = prompt
            return "4"

        run.check(capture_fn, "What is 2+2?", expected="4")
        assert "What is 2+2?" in received_prompt
        assert "exact answer" in received_prompt.lower()

    def test_no_expected_no_format_instruction(self, tmp_output):
        """Without expected, no format instruction even in exact mode."""
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()

        received_prompt = None
        def capture_fn(prompt):
            nonlocal received_prompt
            received_prompt = prompt
            return "something"

        run.check(capture_fn, "What is 2+2?")
        assert received_prompt == "What is 2+2?"

    def test_judges_skip_format_instruction(self, tmp_output):
        """With judges, prompt is passed raw — judges evaluate the natural response."""
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(judges=["Accuracy"])

        received_prompt = None
        def capture_fn(prompt):
            nonlocal received_prompt
            received_prompt = prompt
            return "response"

        run.check(capture_fn, "What is 2+2?", expected="4")
        assert received_prompt == "What is 2+2?"

    def test_semantic_mode_skips_format_instruction(self, tmp_output):
        """In semantic mode, no format instruction — let the LLM respond naturally."""
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(scoring="semantic")

        received_prompt = None
        def capture_fn(prompt):
            nonlocal received_prompt
            received_prompt = prompt
            return "The capital of France is Paris"

        run.check(capture_fn, "Capital of France?", expected="Paris")
        assert received_prompt == "Capital of France?"


# ──────────────────────────────────────────────
# 17. Async eval_each
# ──────────────────────────────────────────────


class TestAsyncEvalEach:
    def test_detects_async_function(self, tmp_output):
        import asyncio

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()

        async def async_ask(prompt):
            return "42"

        status = run.eval_each([("Q1", "42"), ("Q2", "42")], fn=async_ask)
        assert status.total == 2
        assert run._log_count == 2

    def test_async_with_dict_return(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()

        async def async_ask(prompt):
            return {"response": "Paris", "input_tokens": 10, "output_tokens": 5}

        status = run.eval_each(
            [("Capital of France?", "Paris")],
            fn=async_ask,
        )
        assert status.total == 1
        assert run._total_input_tokens == 10

    def test_async_with_openai_response(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()

        async def async_ask(prompt):
            return _FakeOpenAIResponse("4", "gpt-4o")

        status = run.eval_each([("2+2?", "4")], fn=async_ask)
        assert status.total == 1
        assert run._total_input_tokens == 10


# ──────────────────────────────────────────────
# 18. Cost guard
# ──────────────────────────────────────────────


class TestCostGuard:
    def test_max_cost_stops_early(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(max_cost=0.0001)

        def expensive_fn(prompt):
            return {"response": "ok", "input_tokens": 1000, "output_tokens": 500, "model": "gpt-4o"}

        # With a near-zero budget, should stop after 1-2 items
        items = [(f"Q{i}", "ok") for i in range(100)]
        status = run.eval_each(items, fn=expensive_fn)
        assert run._log_count < 100  # Should have stopped early

    def test_no_cost_guard_runs_all(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()

        status = run.eval_each(
            [("Q1", "A"), ("Q2", "A"), ("Q3", "A")],
            fn=lambda p: "A",
        )
        assert run._log_count == 3


# ──────────────────────────────────────────────
# 19. Trend tracking
# ──────────────────────────────────────────────


class TestTrend:
    def test_no_runs(self, tmp_path):
        from evalora.trend import analyze_trend
        report = analyze_trend("test", output_dir=str(tmp_path))
        assert report.regression is False
        assert len(report.runs) == 0

    def test_regression_detected(self, tmp_path):
        import json

        from evalora.trend import analyze_trend
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir(parents=True)

        # Create 5 runs with declining pass rates
        for i in range(5):
            pass_rate = 0.9 - (i * 0.1)
            total = 10
            passed = int(pass_rate * total)
            data = {
                "name": f"test-run-{i}",
                "total": total,
                "passed": passed,
                "items": [],
            }
            path = runs_dir / f"test-run-{i}.json"
            path.write_text(json.dumps(data))
            # Ensure different mtimes
            import os
            os.utime(path, (1000 + i, 1000 + i))

        report = analyze_trend("test", output_dir=str(tmp_path))
        assert report.regression is True
        assert report.slope < 0

    def test_stable_trend(self, tmp_path):
        import json

        from evalora.trend import analyze_trend
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir(parents=True)

        for i in range(5):
            data = {"name": f"test-{i}", "total": 10, "passed": 9, "items": []}
            path = runs_dir / f"test-{i}.json"
            path.write_text(json.dumps(data))
            import os
            os.utime(path, (1000 + i, 1000 + i))

        report = analyze_trend("test", output_dir=str(tmp_path))
        assert report.regression is False

    def test_needs_two_runs(self, tmp_path):
        import json

        from evalora.trend import analyze_trend
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir(parents=True)
        (runs_dir / "test-0.json").write_text(
            json.dumps({"name": "test-0", "total": 10, "passed": 8, "items": []})
        )
        report = analyze_trend("test", output_dir=str(tmp_path))
        assert "Need at least 2" in report.message


# ──────────────────────────────────────────────
# 20. Category slicing
# ──────────────────────────────────────────────


class TestCategorySlicing:
    def test_categories_in_results(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        run.log(prompt="Q1", response="A1", expected="A1", category="math")
        run.log(prompt="Q2", response="wrong", expected="A2", category="math")
        run.log(prompt="Q3", response="A3", expected="A3", category="science")
        status = run.done()

        # Check that categories are tracked in logged items
        cats = {}
        for item in run._logged_items:
            cat = item.get("category")
            if cat:
                cats.setdefault(cat, {"total": 0, "passed": 0})
                cats[cat]["total"] += 1
                if item.get("passed"):
                    cats[cat]["passed"] += 1

        assert cats["math"]["total"] == 2
        assert cats["math"]["passed"] == 1
        assert cats["science"]["total"] == 1
        assert cats["science"]["passed"] == 1


# ──────────────────────────────────────────────
# 21. Rate limiter
# ──────────────────────────────────────────────


class TestRateLimiter:
    def test_rate_limiter_spacing(self):
        from evalora.core.rate_limit import RateLimiter as _RateLimiter
        limiter = _RateLimiter(max_per_second=100)
        start = time.monotonic()
        for _ in range(10):
            limiter.acquire()
        elapsed = time.monotonic() - start
        # 10 calls at 100/sec should take ~0.09s minimum
        assert elapsed >= 0.08

    def test_rate_limiter_thread_safe(self):
        from evalora.core.rate_limit import RateLimiter as _RateLimiter
        from concurrent.futures import ThreadPoolExecutor
        limiter = _RateLimiter(max_per_second=200)
        results = []

        def task():
            limiter.acquire()
            results.append(time.monotonic())

        with ThreadPoolExecutor(max_workers=5) as pool:
            futures = [pool.submit(task) for _ in range(20)]
            for f in futures:
                f.result()

        assert len(results) == 20


# ──────────────────────────────────────────────
# 22. Webhook
# ──────────────────────────────────────────────


class TestWebhook:
    def test_webhook_field_set(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(webhook="https://example.com/hook")
        assert run._webhook == "https://example.com/hook"

    def test_no_webhook_by_default(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        assert run._webhook is None


# ──────────────────────────────────────────────
# 23. pytest plugin
# ──────────────────────────────────────────────


class TestPytestPlugin:
    def test_plugin_fixtures_exist(self):
        from evalora.pytest_plugin import evalora, evalora_run, evalora_output
        assert callable(evalora)
        assert callable(evalora_run)
        assert callable(evalora_output)


# ──────────────────────────────────────────────
# 24. Streaming wrapper
# ──────────────────────────────────────────────


class TestStreamBuffer:
    def test_stream_buffer_collects_chunks(self, tmp_output):
        from evalora.wrappers import _StreamBuffer

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()

        class FakeDelta:
            def __init__(self, text):
                self.content = text

        class FakeChunkChoice:
            def __init__(self, text):
                self.delta = FakeDelta(text)

        class FakeChunk:
            def __init__(self, text):
                self.choices = [FakeChunkChoice(text)]
                self.usage = None

        class FakeStream:
            def __iter__(self):
                yield FakeChunk("Hello")
                yield FakeChunk(" world")

        buf = _StreamBuffer(FakeStream(), run, "Say hello", None, "gpt-4o")
        chunks = list(buf)
        assert len(chunks) == 2
        assert run._log_count == 1
        assert run._logged_items[0]["response"] == "Hello world"


# ──────────────────────────────────────────────
# 25. Framework integrations
# ──────────────────────────────────────────────


class TestLangChainIntegration:
    def test_callback_handler_logs_llm_call(self, tmp_output):
        from evalora.integrations.langchain import EvaloraCallbackHandler

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        handler = EvaloraCallbackHandler(run, expected={"What is 2+2?": "4"})

        # Simulate LangChain LLM start
        handler.on_llm_start(
            {"kwargs": {"model_name": "gpt-4o"}},
            ["What is 2+2?"],
            run_id="test-1",
        )

        # Simulate LLM end with a fake response
        class FakeGen:
            def __init__(self, text):
                self.text = text

        class FakeResponse:
            def __init__(self):
                self.generations = [[FakeGen("4")]]
                self.llm_output = {"token_usage": {"prompt_tokens": 10, "completion_tokens": 3}}

        handler.on_llm_end(FakeResponse(), run_id="test-1")

        assert run._log_count == 1
        assert run._logged_items[0]["response"] == "4"
        assert run._logged_items[0]["passed"] is True

    def test_callback_stubs_dont_error(self, tmp_output):
        from evalora.integrations.langchain import EvaloraCallbackHandler

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        handler = EvaloraCallbackHandler(run)

        handler.on_chain_start()
        handler.on_chain_end()
        handler.on_tool_start()
        handler.on_tool_end()
        handler.on_agent_action()
        handler.on_agent_finish()


class TestCrewAIIntegration:
    def test_from_crewai_basic(self, tmp_output):
        from evalora.integrations.crewai import from_crewai

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()

        class FakeTaskOutput:
            description = "Write a haiku about Python"
            name = "poetry-task"
            raw = "Code flows like water"

        class FakeCrewOutput:
            raw = "Code flows like water\nIndentation matters much\nSnake language speaks truth"
            tasks_output = [FakeTaskOutput()]
            token_usage = {"prompt_tokens": 50, "completion_tokens": 20}

        from_crewai(FakeCrewOutput(), run, expected="A haiku about Python")
        assert run._log_count == 1
        assert "Code flows" in run._logged_items[0]["response"]


class TestOpenAIAgentsIntegration:
    def test_from_agent_run_basic(self, tmp_output):
        from evalora.integrations.openai_agents import from_agent_run

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()

        class FakeResult:
            final_output = "4"
            input = "What is 2+2?"
            raw_responses = []
            model = "gpt-4o"

        from_agent_run(FakeResult(), run, expected="4")
        assert run._log_count == 1
        assert run._logged_items[0]["response"] == "4"
        assert run._logged_items[0]["passed"] is True


class TestLlamaIndexIntegration:
    def test_callback_handler_event_flow(self, tmp_output):
        from evalora.integrations.llamaindex import EvaloraCallbackHandler

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        handler = EvaloraCallbackHandler(run)

        # Simulate LLM event
        handler.on_event_start("CBEventType.LLM", {"messages": [], "model_name": "gpt-4o"}, event_id="e1")

        class FakeCompletion:
            text = "Paris"

        handler.on_event_end("CBEventType.LLM", {"completion": FakeCompletion()}, event_id="e1")

        assert run._log_count == 1
        assert run._logged_items[0]["response"] == "Paris"

    def test_non_llm_events_ignored(self, tmp_output):
        from evalora.integrations.llamaindex import EvaloraCallbackHandler

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        handler = EvaloraCallbackHandler(run)

        handler.on_event_start("CBEventType.EMBEDDING", {}, event_id="e1")
        handler.on_event_end("CBEventType.EMBEDDING", {}, event_id="e1")

        assert run._log_count == 0


# ──────────────────────────────────────────────
# 26. Eval templates
# ──────────────────────────────────────────────


class TestEvalTemplates:
    def test_rag_quality(self):
        from evalora.templates import rag_quality
        config = rag_quality()
        assert "judges" in config
        assert len(config["judges"]) == 3
        assert config["validators"] == ["not_empty"]

    def test_chatbot(self):
        from evalora.templates import chatbot
        config = chatbot()
        assert len(config["judges"]) == 3
        # Third judge should be "Safety" string preset
        assert config["judges"][2] == "Safety"

    def test_code_gen_has_rubric(self):
        from evalora.templates import code_gen
        config = code_gen()
        # Second judge should have criteria (rubric)
        assert "criteria" in config["judges"][1]

    def test_template_overrides(self):
        from evalora.templates import summarization
        config = summarization(max_cost=5.00)
        assert config["max_cost"] == 5.00
        assert "judges" in config

    def test_all_templates_return_judges(self):
        from evalora.templates import TEMPLATES
        for name, fn in TEMPLATES.items():
            config = fn()
            assert "judges" in config, f"Template '{name}' missing judges"

    def test_template_in_run(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(template="rag-quality")
        assert len(run._judges) == 3

    def test_unknown_template_raises(self):
        ev = Evalora(local=True, verbose=False)
        with pytest.raises(ValueError, match="Unknown template"):
            ev.run(template="nonexistent")

    def test_explicit_judges_override_template(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(template="chatbot", judges=["Safety"])
        assert len(run._judges) == 1


# ──────────────────────────────────────────────
# 27. Custom scorers
# ──────────────────────────────────────────────


class TestCustomScorers:
    def test_scorer_runs(self, tmp_output):
        def word_count_score(response):
            return min(len(response.split()) / 10, 1.0)

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(scorers=[word_count_score])
        run.log(prompt="Q", response="one two three four five", expected="anything")
        assert "scores" in run._logged_items[0]
        assert run._logged_items[0]["scores"]["word_count_score"] == 0.5

    def test_scorer_with_expected(self, tmp_output):
        def overlap_score(response, expected):
            if not expected:
                return 0.5
            r_words = set(response.lower().split())
            e_words = set(expected.lower().split())
            if not e_words:
                return 0.5
            return len(r_words & e_words) / len(e_words)

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(scorers=[overlap_score])
        run.log(prompt="Q", response="hello world", expected="hello world foo")
        scores = run._logged_items[0]["scores"]
        assert scores["overlap_score"] == pytest.approx(0.6667, abs=0.01)

    def test_scorer_below_threshold_fails(self, tmp_output):
        def always_low(response):
            return 0.1

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(scorers=[always_low], score_threshold=0.5)
        run.log(prompt="Q", response="any", expected="any")
        assert run._logged_items[0]["passed"] is False

    def test_scorer_above_threshold_passes(self, tmp_output):
        def always_high(response):
            return 0.9

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(scorers=[always_high], score_threshold=0.5)
        run.log(prompt="Q", response="any", expected="any")
        assert run._logged_items[0]["passed"] is True

    def test_scorer_clamped_to_0_1(self, tmp_output):
        def over_one(response):
            return 5.0

        def under_zero(response):
            return -3.0

        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(scorers=[over_one, under_zero])
        run.log(prompt="Q", response="any", expected="any")
        scores = run._logged_items[0]["scores"]
        assert scores["over_one"] == 1.0
        assert scores["under_zero"] == 0.0


# ──────────────────────────────────────────────
# 28. Multi-turn eval
# ──────────────────────────────────────────────


class TestMultiTurn:
    def test_log_conversation(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        run.log_conversation(
            messages=[
                {"role": "user", "content": "What is Python?"},
                {"role": "assistant", "content": "A language."},
                {"role": "user", "content": "What's it for?"},
                {"role": "assistant", "content": "Web, AI, data science."},
            ],
            expected="Web, AI, data science",
        )
        assert run._log_count == 1
        assert "What is Python?" in run._logged_items[0]["prompt"]
        assert "What's it for?" in run._logged_items[0]["prompt"]
        assert run._logged_items[0]["response"] == "Web, AI, data science."

    def test_multi_turn_with_category(self, tmp_output):
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()
        run.log_conversation(
            messages=[
                {"role": "user", "content": "Hi"},
                {"role": "assistant", "content": "Hello!"},
            ],
            category="greeting",
        )
        assert run._logged_items[0]["category"] == "greeting"


# ──────────────────────────────────────────────
# 29. Dataset versioning
# ──────────────────────────────────────────────


class TestDatasetVersioning:
    def test_list_versions_empty(self, tmp_path):
        from evalora.results import list_dataset_versions
        versions = list_dataset_versions(str(tmp_path))
        assert versions == []

    def test_list_versions_with_runs(self, tmp_path):
        import json as json_mod
        from evalora.results import list_dataset_versions

        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()

        for i in range(3):
            data = {
                "run_id": f"run-{i}",
                "version": "A",
                "fingerprint": "abc123",
                "timestamp": f"2024-01-0{i+1}T00:00:00Z",
                "summary": {"total": 10, "passed": 8},
            }
            (runs_dir / f"run-{i}.json").write_text(json_mod.dumps(data))

        versions = list_dataset_versions(str(tmp_path))
        assert len(versions) == 1
        assert versions[0]["version"] == "A"
        assert versions[0]["runs"] == 3
        assert versions[0]["avg_pass_rate"] == 0.8


# ──────────────────────────────────────────────
# 30. Ghost mode redesign
# ──────────────────────────────────────────────


class TestGhostConfig:
    def test_false(self):
        from evalora.ghost import GhostConfig
        gc = GhostConfig.from_param(False)
        assert gc.enabled is False
        assert gc.mode == "off"
        assert gc.redact("prompt", "hello") == "hello"

    def test_true_equals_full(self):
        from evalora.ghost import GhostConfig
        gc = GhostConfig.from_param(True)
        assert gc.enabled is True
        assert gc.mode == "full"
        assert gc.prompt is True
        assert gc.response is True
        assert gc.model is True
        assert gc.judge_reasoning is True

    def test_full(self):
        from evalora.ghost import GhostConfig
        gc = GhostConfig.from_param("full")
        assert gc.redact("prompt", "secret") == "[redacted]"
        assert gc.redact("response", "secret") == "[redacted]"
        assert gc.redact_model("gpt-4o") == "[redacted-model]"

    def test_light(self):
        from evalora.ghost import GhostConfig
        gc = GhostConfig.from_param("light")
        assert gc.redact("prompt", "visible") == "visible"  # NOT redacted
        assert gc.redact("response", "hidden") == "[redacted]"
        assert gc.redact("expected", "visible") == "visible"  # NOT redacted
        assert gc.redact_model("gpt-4o") == "gpt-4o"  # NOT redacted
        assert gc.judge_reasoning is False

    def test_hash(self):
        from evalora.ghost import GhostConfig
        gc = GhostConfig.from_param("hash")
        result = gc.redact("prompt", "hello")
        assert result.startswith("[hash:")
        assert "hello" not in result
        # Deterministic
        assert gc.redact("prompt", "hello") == gc.redact("prompt", "hello")
        # Different inputs → different hashes
        assert gc.redact("prompt", "hello") != gc.redact("prompt", "world")

    def test_dict_per_field(self):
        from evalora.ghost import GhostConfig
        gc = GhostConfig.from_param({"prompt": True, "response": False, "model": True})
        assert gc.redact("prompt", "secret") == "[redacted]"
        assert gc.redact("response", "visible") == "visible"
        assert gc.redact_model("gpt-secret") == "[redacted-model]"
        assert gc.mode == "custom"

    def test_none_value(self):
        from evalora.ghost import GhostConfig
        gc = GhostConfig.from_param("full")
        assert gc.redact("prompt", None) is None

    def test_invalid_raises(self):
        from evalora.ghost import GhostConfig
        with pytest.raises(ValueError, match="Invalid ghost"):
            GhostConfig.from_param("invalid_mode")


class TestGhostServerConfig:
    def test_default_when_ghost_off(self):
        from evalora.ghost import GhostConfig, GhostServerConfig
        gc = GhostConfig.from_param(False)
        sc = GhostServerConfig.from_param(None, gc)
        assert sc.send_to_server is True

    def test_default_when_ghost_on(self):
        from evalora.ghost import GhostConfig, GhostServerConfig
        gc = GhostConfig.from_param(True)
        sc = GhostServerConfig.from_param(None, gc)
        assert sc.send_to_server is True
        assert sc.send_verdicts is True

    def test_server_false(self):
        from evalora.ghost import GhostConfig, GhostServerConfig
        gc = GhostConfig.from_param(True)
        sc = GhostServerConfig.from_param(False, gc)
        assert sc.send_to_server is False
        assert sc.send_verdicts is False


class TestGhostModeIntegration:
    def test_full_mode_redacts_everything(self, tmp_output):
        import warnings
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            run = ev.run(ghost=True)
        run.log(prompt="secret", response="classified", expected="classified")
        item = run._logged_items[0]
        assert item["prompt"] == "[redacted]"
        assert item["response"] == "[redacted]"
        assert item["expected"] == "[redacted]"
        assert item["passed"] is True  # matching still works via _real_ fields

    def test_light_mode_keeps_prompts(self, tmp_output):
        import warnings
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            run = ev.run(ghost="light")
        run.log(prompt="What is 2+2?", response="secret answer", expected="4")
        item = run._logged_items[0]
        assert item["prompt"] == "What is 2+2?"  # visible
        assert item["response"] == "[redacted]"
        assert item["expected"] == "4"  # visible

    def test_hash_mode_produces_hashes(self, tmp_output):
        import warnings
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            run = ev.run(ghost="hash")
        run.log(prompt="hello", response="world", expected="world")
        item = run._logged_items[0]
        assert item["prompt"].startswith("[hash:")
        assert item["response"].startswith("[hash:")
        assert "hello" not in item["prompt"]

    def test_custom_dict_mode(self, tmp_output):
        import warnings
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            run = ev.run(ghost={"response": True})
        run.log(prompt="visible prompt", response="hidden response", expected="visible expected")
        item = run._logged_items[0]
        assert item["prompt"] == "visible prompt"
        assert item["response"] == "[redacted]"
        assert item["expected"] == "visible expected"

    def test_ghost_server_false_skips_backend(self, tmp_output):
        import warnings
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            run = ev.run(ghost=True, ghost_server=False)
        assert run._ghost_server_config.send_to_server is False

    def test_backward_compat_ghost_property(self, tmp_output):
        import warnings
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            run = ev.run(ghost=True)
        assert run._ghost is True  # backward compat property

    def test_real_fields_exist_for_judges(self, tmp_output):
        import warnings
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            run = ev.run(ghost=True)
        run.log(prompt="secret", response="classified", expected="classified")
        # _real_ fields exist in memory for judges to use
        assert run._logged_items[0].get("_real_prompt") == "secret"
        assert run._logged_items[0].get("_real_response") == "classified"
        # But the visible fields are redacted
        assert run._logged_items[0]["prompt"] == "[redacted]"
        assert run._logged_items[0]["response"] == "[redacted]"


# ──────────────────────────────────────────────
# TestBugFixes — regression tests for confirmed logic bugs
# ──────────────────────────────────────────────


@pytest.fixture
def tmp_output(tmp_path):
    return str(tmp_path)


class TestBugFixes:
    """Regression tests for real logic bugs found in the SDK.

    Each test documents the bug, reproduces it, and verifies the fix.
    """

    # ── Bug 1 ──────────────────────────────────
    # AsyncRun.log() ignores scoring="semantic" — always uses exact matching
    # Impact: semantic scoring never applied in async runs; items wrongly
    # marked pass/fail when embedding similarity should be used.
    # ───────────────────────────────────────────

    def test_async_run_log_uses_exact_match_when_semantic_not_configured(self, tmp_output):
        """AsyncRun.log() should fall back to exact match when no embedding key."""
        import asyncio
        from evalora.async_client import AsyncEvalora

        ev = AsyncEvalora(local=True, verbose=False, output=tmp_output)

        async def run():
            run_ = await ev.run(scoring="exact")
            await run_.log(prompt="Q", response="Paris", expected="Paris")
            await run_.log(prompt="Q2", response="wrong", expected="Paris")
            return run_

        r = asyncio.run(run())
        assert r._logged_items[0]["passed"] is True
        assert r._logged_items[1]["passed"] is False

    def test_async_run_log_semantic_scoring_respected(self, tmp_output):
        """AsyncRun.log() must apply semantic scoring when embedding_api_key set.

        Bug: before the fix, line 179 in async_client.py always called
        _check_match() regardless of self._scoring, so setting
        scoring='semantic' had no effect in async runs.
        """
        import asyncio
        from evalora.async_client import AsyncEvalora, AsyncRun

        # Patch compute_similarity at the canonical location (where async_client imports from)
        from evalora.scoring import similarity as _sim_mod
        original = getattr(_sim_mod, "compute_similarity", None)

        def fake_similarity(a, b, api_key, model="text-embedding-3-small"):
            # Return high similarity for "Paris" vs "the city of Paris"
            if "Paris" in a and "Paris" in b:
                return 0.95
            return 0.10

        _sim_mod.compute_similarity = fake_similarity
        try:
            ev = AsyncEvalora(local=True, verbose=False, output=tmp_output)

            async def run():
                run_ = await ev.run(
                    scoring="semantic",
                    embedding_api_key="fake-key",
                    similarity_threshold=0.85,
                )
                # High similarity — should pass
                await run_.log(prompt="Capital of France?", response="Paris", expected="the city of Paris")
                # Low similarity — should fail
                await run_.log(prompt="Capital of France?", response="Berlin", expected="the city of Paris")
                return run_

            r = asyncio.run(run())
            assert r._logged_items[0]["passed"] is True, "High-similarity pair should pass"
            assert r._logged_items[1]["passed"] is False, "Low-similarity pair should fail"
        finally:
            if original is not None:
                _sim_mod.compute_similarity = original

    # ── Bug 2 ──────────────────────────────────
    # max_cost=0 triggers cost guard immediately, skipping all items silently.
    # Impact: users who pass max_cost=0 intending "no limit" (or by mistake)
    # get a run that processes zero items with no error or warning.
    # ───────────────────────────────────────────

    def test_max_cost_zero_does_not_skip_items(self, tmp_output):
        """max_cost=0 must not trigger the cost guard.

        Bug: _check_cost_guard() computed self._max_cost * 0.9 == 0, and
        self._total_cost (0.0) >= 0 is True, so the guard fired on item 0.
        Fix: skip guard when max_cost <= 0.
        """
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(max_cost=0)

        items = [("Q1", "A1"), ("Q2", "A2"), ("Q3", "A3")]
        run.eval_each(items, fn=lambda p: "A1")

        assert run._log_count == 3, (
            f"All 3 items should be processed when max_cost=0, got {run._log_count}"
        )

    def test_max_cost_none_does_not_skip_items(self, tmp_output):
        """max_cost=None (default) must never trigger the cost guard."""
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()  # max_cost defaults to None

        items = [("Q1", "A1"), ("Q2", "A2")]
        run.eval_each(items, fn=lambda p: "A1")

        assert run._log_count == 2

    def test_max_cost_positive_stops_eval_early(self, tmp_output):
        """max_cost > 0 should stop eval when 90% of budget is reached."""
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run(max_cost=0.000001)  # tiny budget — will trip after first cost

        # Simulate cost accumulation by pre-spending the budget
        run._total_cost = 0.000001  # at 100% — guard should fire

        items = [("Q1", "A1"), ("Q2", "A2"), ("Q3", "A3")]
        run.eval_each(items, fn=lambda p: "A1")

        # Cost guard should have stopped early — fewer than 3 items logged
        assert run._log_count < 3, "Cost guard should stop eval early when budget exceeded"

    # ── Bug 3 ──────────────────────────────────
    # log_conversation() silently logs an empty response string when no
    # assistant turn exists in the messages list.
    # Impact: corrupt data in the eval — empty response is logged as if it
    # were the model's output, no error raised.
    # ───────────────────────────────────────────

    def test_log_conversation_raises_when_no_assistant_turn(self, tmp_output):
        """log_conversation() must raise ValueError if no assistant message.

        Bug: response_text was initialized to '' and never set when the
        messages list had no assistant turn. An empty string was silently
        logged as the response.
        """
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()

        messages_no_assistant = [
            {"role": "user", "content": "What is Python?"},
            {"role": "user", "content": "I really want to know"},
        ]

        with pytest.raises(ValueError, match="assistant"):
            run.log_conversation(messages=messages_no_assistant, expected="A language")

    def test_log_conversation_empty_messages_raises(self, tmp_output):
        """log_conversation() with an empty list must raise ValueError."""
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()

        with pytest.raises(ValueError, match="assistant"):
            run.log_conversation(messages=[])

    def test_log_conversation_valid_conversation_logs_correctly(self, tmp_output):
        """log_conversation() should correctly log the last assistant message."""
        ev = Evalora(local=True, verbose=False, output=tmp_output)
        run = ev.run()

        run.log_conversation(
            messages=[
                {"role": "user", "content": "What is Python?"},
                {"role": "assistant", "content": "A programming language."},
                {"role": "user", "content": "What's it used for?"},
                {"role": "assistant", "content": "Web, data science, AI."},
            ],
            expected="Web, data science, AI.",
        )

        assert run._log_count == 1
        item = run._logged_items[0]
        assert item["response"] == "Web, data science, AI."
        assert "What is Python?" in item["prompt"]
        assert item["passed"] is True

    # ── Bug 4 ──────────────────────────────────
    # _eval_parallel ignores max_cost — cost guard never checked in parallel mode.
    # Impact: parallel runs have no budget enforcement; max_cost is silently
    # ignored, potentially running all items regardless of cost.
    # ───────────────────────────────────────────

    def test_eval_parallel_respects_max_cost(self, tmp_output):
        """_eval_parallel must skip logging when cost guard fires.

        Bug: _eval_sequential called _check_cost_guard() in its loop, but
        _eval_parallel never checked it — all futures were submitted and their
        results logged regardless of the budget.
        """
        ev = Evalora(local=True, verbose=False, output=tmp_output, parallel=True, max_workers=4)
        run = ev.run(max_cost=0.000001)

        # Pre-exceed the budget so cost guard fires immediately
        run._total_cost = 0.001  # way over 90% of 0.000001

        items = [(f"Q{i}", f"A{i}") for i in range(10)]
        run.eval_each(items, fn=lambda p: "some answer", parallel=True)

        # With cost guard active, parallel mode should have skipped logging
        assert run._log_count < 10, (
            f"Parallel mode should respect max_cost, but logged {run._log_count}/10 items"
        )
