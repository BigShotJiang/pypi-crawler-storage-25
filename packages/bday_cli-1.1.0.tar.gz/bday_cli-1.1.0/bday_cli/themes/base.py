import random

class BaseTheme:
    def cpu_message(self, cpu: float, intensity: str) -> str:
        raise NotImplementedError

    def memory_message(self, memory: float, intensity: str) -> str:
        raise NotImplementedError

    def git_message(self, dirty: bool, intensity: str) -> str:
        raise NotImplementedError

    def random_quote(self):
        if hasattr(self, "quotes"):
            return random.choice(self.quotes)
        return "No quote available."