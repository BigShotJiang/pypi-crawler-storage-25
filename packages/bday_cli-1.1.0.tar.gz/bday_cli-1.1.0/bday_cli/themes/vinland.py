from .base import BaseTheme

class VinlandSaga(BaseTheme):

    quotes = [
        "I have no enemies ",
        "I want to be a kinder, gentler person. I want to be... a stronger person",
        "Where is your sword...Dont need it",
        "A true warrior dosent need a sword",
        "There is no meaning to dying for someone else... But there's meaning in dying together with someone",
        "You're young. Time is on your side. You'll grow up and I'll grow old. Someday you'll likely beat me. It's only natural. Even the strongest man must die",
        "To be free is to own your choices, however hard the road may be"
    ]
    def cpu_message(self, cpu, intensity):
        if intensity == "low":
            return "System stable." if cpu < 70 else "High CPU usage."
        
        if cpu > 90:
            return "Thats THORKELL on the bridge destroying the CPU"
        elif cpu > 70:
            return "Dual dagger weilding CPU"
        return "Far across the sea....lies a place....Vinland"

    def memory_message(self, memory, intensity):
        if intensity == "low":
            return "Memory usage normal." if memory < 80 else "Memory usage high."

        return "The memories of your murder is pulling you down" if memory > 80 else "Quick on your toes huh...see still got will to live?"

    def git_message(self, dirty, intensity):
        if intensity == "low":
            return "Repo clean." if not dirty else "Uncommitted changes."

        return "You need to move forward with the things you have done" if dirty else "Now that you are truly empty you can we can fill that up with something"
