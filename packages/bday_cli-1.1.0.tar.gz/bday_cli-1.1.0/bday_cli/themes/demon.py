from .base import BaseTheme

class DemonTheme(BaseTheme):

    quotes = [
        "Set your heart ablaze ",
        "Having such a simple mind that you call this simple, I envy you",
        "Life is a series of decisions. You never have unlimited options or unlimited time to think, but what you choose in that instant defines who you are",
        "Train until it kills you. Because really, when you get down to it, there's nothing else you can do",
        "All that lives must die. Only feelings are eternal and undying",
        "Even the strongest attcks are pointless if they dont hit"
    ]
    def cpu_message(self, cpu, intensity):
        if intensity == "low":
            return "System stable." if cpu < 70 else "High CPU usage."
        
        if cpu > 90:
            return "Hinokami Kagura! You're pushing past your CPU limits"
        elif cpu > 70:
            return " Total Concentration: CPU You are in a flow state"
        return " CPU Resting at the Butterfly Mansion"

    def memory_message(self, memory, intensity):
        if intensity == "low":
            return "Memory usage normal." if memory < 80 else "Memory usage high."

        return " Final Selection. Your RAM is packed with demons" if memory > 80 else "Memory might be infinite castle"

    def git_message(self, dirty, intensity):
        if intensity == "low":
            return "Repo clean." if not dirty else "Uncommitted changes."

        return " Repo turning to Infinite castle not clean" if dirty else "Water Breathing 6th form Calm sea repo clean"
