from .base import BaseTheme

class AOTTheme(BaseTheme):

    quotes = [
        "If you don’t fight, you can’t win.",
        "The world is cruel, but also beautiful.",
        "What a Beautiful Day It Is",
        "Those Who Can’t Abandon Anything Can’t Change Anything",
        "On the Other Side of the Ocean",
        "There is no truth in this world. Anyone can become a God or a Devil",
        "He is already great. Because he was born into this world",
        "On the other side of the sea..is freedom",
        "What are you doing? Stand up, dad. Did you forget what you came here to do?"
    ]

    def cpu_message(self, cpu, intensity):
        if intensity == "low":
            return "System stable." if cpu < 70 else "High CPU usage."
        
        if cpu > 90:
            return " Titans have broken wall Maria!!!"
        elif cpu > 70:
            return "The CPU rumbling has begun!!!!"
        return " The CPU walls stand strong."

    def memory_message(self, memory, intensity):
        if intensity == "low":
            return "Memory usage normal." if memory < 80 else "Memory usage high."

        return "King Firtz might erase memory !!" if memory > 80 else "Eren regained Memory"

    def git_message(self, dirty, intensity):
        if intensity == "low":
            return "Repo clean." if not dirty else "Uncommitted changes."

        return " Levi says not clean enough!!" if dirty else " Levi approves your cleanliness."
