from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.live import Live
from rich.text import Text
import random
import time
import os

console = Console()

FADE_STEPS = [
    ("░", "grey30"),
    ("▒", "grey53"),
    ("▓", "grey74"),
    ("█", "white"),   # brief full-block flash before real render
]

def animate_banner(art: str, title: str):
    """Smooth fade-in using Rich Live — no screen flashing."""
    lines = art.splitlines()

    with Live(console=console, refresh_per_second=20, transient=False) as live:
        # Fade in phase — ░ → ▒ → ▓ → █
        for fade_char, color in FADE_STEPS:
            faded_lines = []
            for line in lines:
                faded = "".join(fade_char if c not in (" ", "\t") else c for c in line)
                faded_lines.append(faded)
            faded_text = "\n".join(faded_lines)
            live.update(Panel(Text(faded_text, style=color), title=title))
            time.sleep(0.1)

        # Final — render real art in full bright white
        live.update(Panel(Text(art, style="bold bright_white"), title=title))
        time.sleep(0.15)

def render_professional(data, messages):
    table = Table(title="System Overview")

    table.add_column("Metric")
    table.add_column("Value")

    table.add_row("CPU", f"{data['cpu']}%")
    table.add_row("Memory", f"{data['memory']}%")
    table.add_row("Disk", f"{data['disk']}%")
    table.add_row("Uptime (s)", str(data["uptime"]))

    console.print(table)

    if "git_msg" in messages:
        console.print(messages["git_msg"])


def render_anime(data, messages):
    text = f"""
CPU: {data['cpu']}%
Memory: {data['memory']}%
Disk: {data['disk']}%
Uptime: {data['uptime']} sec

{messages['cpu_msg']}
{messages['mem_msg']}
"""

    if "git_msg" in messages:
        text += f"\n{messages['git_msg']}"

    console.print(Panel(text, title="⚔ Titan Mode"))


def show_banner(theme, mode, animate=False):
    """
    Show the banner for the current theme/mode.
    Pass animate=True to trigger the fade-in animation (on theme change).
    """
    os.system("cls" if os.name == "nt" else "clear")
    time.sleep(0.1)

    if mode == "anime":
        if theme == "aot":
            art = r"""
████████╗██╗████████╗ █████╗ ███╗   ██╗
╚══██╔══╝██║╚══██╔══╝██╔══██╗████╗  ██║
   ██║   ██║   ██║   ███████║██╔██╗ ██║
   ██║   ██║   ██║   ██╔══██║██║╚██╗██║
   ██║   ██║   ██║   ██║  ██║██║ ╚████║
   ╚═╝   ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝

            TITAN MODE ACTIVATED"""
            title = "⚔ THEME UPDATED"

        elif theme == "demon":
            art = r"""██████╗ ███████╗███╗   ███╗ ██████╗ ███╗   ██╗    ███████╗██╗      █████╗ ██╗   ██╗███████╗██████╗ 
██╔══██╗██╔════╝████╗ ████║██╔═══██╗████╗  ██║    ██╔════╝██║     ██╔══██╗╚██╗ ██╔╝██╔════╝██╔══██╗
██║  ██║█████╗  ██╔████╔██║██║   ██║██╔██╗ ██║    ███████╗██║     ███████║ ╚████╔╝ █████╗  ██████╔╝
██║  ██║██╔══╝  ██║╚██╔╝██║██║   ██║██║╚██╗██║    ╚════██║██║     ██╔══██║  ╚██╔╝  ██╔══╝  ██╔══██╗
██████╔╝███████╗██║ ╚═╝ ██║╚██████╔╝██║ ╚████║    ███████║███████╗██║  ██║   ██║   ███████╗██║  ██║
╚═════╝ ╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝    ╚══════╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝

            DEMON SLAYER MODE ENGAGED"""
            title = "⚔ THEME UPDATED"

        elif theme == "vinland":
            art = r"""██╗   ██╗██╗███╗   ██╗██╗      █████╗ ███╗   ██╗██████╗     ███████╗ █████╗  ██████╗  █████╗ 
██║   ██║██║████╗  ██║██║     ██╔══██╗████╗  ██║██╔══██╗    ██╔════╝██╔══██╗██╔════╝ ██╔══██╗
██║   ██║██║██╔██╗ ██║██║     ███████║██╔██╗ ██║██║  ██║    ███████╗███████║██║  ███╗███████║
╚██╗ ██╔╝██║██║╚██╗██║██║     ██╔══██║██║╚██╗██║██║  ██║    ╚════██║██╔══██║██║   ██║██╔══██║
 ╚████╔╝ ██║██║ ╚████║███████╗██║  ██║██║ ╚████║██████╔╝    ███████║██║  ██║╚██████╔╝██║  ██║
  ╚═══╝  ╚═╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝     ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝

                VINLAND SAGA MODE ENGAGED"""
            title = "⚔ THEME UPDATED"

        else:
            art = "ANIME MODE ENGAGED"
            title = "⚔ THEME UPDATED"

        if animate:
            animate_banner(art, title)
        else:
            console.print(Panel(art, title=title))

    elif mode == "we9":
        if theme == "archit":
            art = r"""     ___      .______        ______  __    __   __  .___________. 
    /   \     |   _  \      /      ||  |  |  | |  | |           |
   /  ^  \    |  |_)  |    |  ,----'|  |__|  | |  | `---|  |----`
  /  /_\  \   |      /     |  |     |   __   | |  |     |  |     
 /  _____  \  |  |\  \----.|  `----.|  |  |  | |  |     |  |     
/__/     \__\ | _| `._____| \______||__|  |__| |__|     |__|     

            ARCHIT MODE ENGAGED"""

        elif theme == "arya":
            art = r"""
                                                
     ▄▄      ▄▄▄▄▄▄     ▄▄▄          ▄▄    
   ▄█▀▀█▄   █▀██▀▀▀█▄  █▀██  ██    ▄█▀▀█▄  
   ██  ██     ██▄▄▄█▀    ██  ██    ██  ██  
   ██▀▀██     ██▀▀█▄     ██  ██    ██▀▀██  
 ▄ ██  ██   ▄ ██  ██     ██  ██  ▄ ██  ██  
 ▀██▀  ▀█▄█ ▀██▀  ▀██▀   ▀█████▄ ▀██▀  ▀█▄█
                         ▄   ██            
                         ▀████▀            
        ARYA MODE ENGAGED  🚀🚀"""

        elif theme == "archana":
            art = r""" ________  ________  ________  ___  ___  ________  ________   ________     
|\   __  \|\   __  \|\   ____\|\  \|\  \|\   __  \|\   ___  \|\   __  \    
\ \  \|\  \ \  \|\  \ \  \___|\ \  \\\  \ \  \|\  \ \  \\ \  \ \  \|\  \   
 \ \   __  \ \   _  _\ \  \    \ \   __  \ \   __  \ \  \\ \  \ \   __  \  
  \ \  \ \  \ \  \\  \\ \  \____\ \  \ \  \ \  \ \  \ \  \\ \  \ \  \ \  \ 
   \ \__\ \__\ \__\\ _\\ \_______\ \__\ \__\ \__\ \__\ \__\\ \__\ \__\ \__\
    \|__|\|__|\|__|\|__|\|_______|\|__|\|__|\|__|\|__|\|__| \|__|\|__|\|__|
                                                                           
                                                                           
                                                                             
            ARCHANA MODE ENGAGED"""

        elif theme == "abhay":
            art = r""" ________  ________  ___  ___  ________      ___    ___ 
|\   __  \|\   __  \|\  \|\  \|\   __  \    |\  \  /  /|
\ \  \|\  \ \  \|\ /\ \  \\\  \ \  \|\  \   \ \  \/  / /
 \ \   __  \ \   __  \ \   __  \ \   __  \   \ \    / / 
  \ \  \ \  \ \  \|\  \ \  \ \  \ \  \ \  \   \/  /  /  
   \ \__\ \__\ \_______\ \__\ \__\ \__\ \__\__/  / /    
    \|__|\|__|\|_______|\|__|\|__|\|__|\|__|\___/ /     
                                           \|___|/      
                                                        
                                                        
                    ABHAY MODE ENGAGED"""

        elif theme == "anagha":
            art = r"""                                    
                                    
                         █▄         
       ▄              ▄▄ ██         
 ▄▀▀█▄ ████▄ ▄▀▀█▄ ▄████ ████▄ ▄▀▀█▄
 ▄█▀██ ██ ██ ▄█▀██ ██ ██ ██ ██ ▄█▀██
▄▀█▄██▄██ ▀█▄▀█▄██▄▀████▄██ ██▄▀█▄██
                      ██            
                    ▀▀▀             
            
            ANAGHA MODE ENGAGED"""

        elif theme == "deeksha":
            art = r"""                                               
  ▄▄▄▄▄▄                                       
 █▀██▀▀██                           █▄         
   ██   ██             ▄▄           ██         
   ██   ██ ▄█▀█▄ ▄█▀█▄ ██ ▄█▀ ▄██▀█ ████▄ ▄▀▀█▄
 ▄ ██   ██ ██▄█▀ ██▄█▀ ████   ▀███▄ ██ ██ ▄█▀██
 ▀██▀███▀ ▄▀█▄▄▄▄▀█▄▄▄▄██ ▀█▄█▄▄██▀▄██ ██▄▀█▄██
                                               
                        
                    DEEKSHA MODE ENGAGED"""

        elif theme == "krupa":
            art = r"""   ▄█   ▄█▄    ▄████████ ███    █▄     ▄███████▄    ▄████████ 
  ███ ▄███▀   ███    ███ ███    ███   ███    ███   ███    ███ 
  ███▐██▀     ███    ███ ███    ███   ███    ███   ███    ███ 
 ▄█████▀     ▄███▄▄▄▄██▀ ███    ███   ███    ███   ███    ███ 
▀▀█████▄    ▀▀███▀▀▀▀▀   ███    ███ ▀█████████▀  ▀███████████ 
  ███▐██▄   ▀███████████ ███    ███   ███          ███    ███ 
  ███ ▀███▄   ███    ███ ███    ███   ███          ███    ███ 
  ███   ▀█▀   ███    ███ ████████▀   ▄████▀        ███    █▀  
  ▀           ███    ███                                      
  
                    KRUPA MODE ENGAGED"""

        elif theme == "lavanya":
            art = r""" ▄█          ▄████████  ▄█    █▄     ▄████████ ███▄▄▄▄   ▄██   ▄      ▄████████ 
███         ███    ███ ███    ███   ███    ███ ███▀▀▀██▄ ███   ██▄   ███    ███ 
███         ███    ███ ███    ███   ███    ███ ███   ███ ███▄▄▄███   ███    ███ 
███         ███    ███ ███    ███   ███    ███ ███   ███ ▀▀▀▀▀▀███   ███    ███ 
███       ▀███████████ ███    ███ ▀███████████ ███   ███ ▄██   ███ ▀███████████ 
███         ███    ███ ███    ███   ███    ███ ███   ███ ███   ███   ███    ███ 
███▌    ▄   ███    ███ ███    ███   ███    ███ ███   ███ ███   ███   ███    ███ 
█████▄▄██   ███    █▀   ▀██████▀    ███    █▀   ▀█   █▀   ▀█████▀    ███    █▀  
▀                                                                               
                    LAVANYA MODE ENGAGED"""

        else:
            art = "WE9 MODE ENGAGED"

        title = "👥 WE9 THEME UPDATED"

        if animate:
            animate_banner(art, title)
        else:
            console.print(Panel(art, title=title))

    else:
        art = "THEME UPDATED"
        title = "THEME UPDATED"
        if animate:
            animate_banner(art, title)
        else:
            console.print(Panel(art, title=title))


def show_birthday():
    confetti = ["✨", "🎉", "🎊", "🔥", "⚔"]

    for _ in range(3):
        line = " ".join(random.choice(confetti) for _ in range(20))
        console.print(line)
        time.sleep(0.2)

    art = r"""
██╗   ██╗ █████╗ ██████╗ ███████╗
██║   ██║██╔══██╗██╔══██╗██╔════╝
██║   ██║███████║██║  ██║█████╗  
╚██╗ ██╔╝██╔══██║██║  ██║██╔══╝  
 ╚████╔╝ ██║  ██║██████╔╝███████╗
  ╚═══╝  ╚═╝  ╚═╝╚═════╝ ╚══════╝

██╗  ██╗ █████╗ ██████╗ ██████╗ ██╗   ██╗    ██████╗ ██╗██████╗ ████████╗██╗  ██╗██████╗  █████╗ ██╗   ██╗
██║  ██║██╔══██╗██╔══██╗██╔══██╗╚██╗ ██╔╝    ██╔══██╗██║██╔══██╗╚══██╔══╝██║  ██║██╔══██╗██╔══██╗╚██╗ ██╔╝
███████║███████║██████╔╝██████╔╝ ╚████╔╝     ██████╔╝██║██████╔╝   ██║   ███████║██║  ██║███████║ ╚████╔╝ 
██╔══██║██╔══██║██╔═══╝ ██╔═══╝   ╚██╔╝      ██╔══██╗██║██╔══██╗   ██║   ██╔══██║██║  ██║██╔══██║  ╚██╔╝  
██║  ██║██║  ██║██║     ██║        ██║       ██████╔╝██║██║  ██║   ██║   ██║  ██║██████╔╝██║  ██║   ██║   
╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝        ╚═╝       ╚═════╝ ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝   ╚═╝   
                                                                                                          
    """

    console.print(Panel(art, title="🎂 SYSTEM OVERRIDE 🎂"))
    console.print("\nThe system bends to your will today.\n")


def show_quote(quote, mode="anime"):
    if mode == "we9":
        title = "👥 WE9 Quote"
        border = "bright_cyan"
    elif mode == "professional":
        title = "💼 Quote"
        border = "bright_blue"
    else:
        title = "⚔ Anime Quote"
        border = "bright_magenta"

    console.print(
        Panel(
            quote,
            title=title,
            border_style=border
        )
    )