import random
import time
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.live import Live

console = Console()

# --------------------------------------------------
# Per-member move sets  (attack, dodge, counter)
# --------------------------------------------------

MOVES = {
    "archit": {
        "attacks": [
            "{name} pulls out a laptop and deploys a bug directly into reality 💻",
            "{name} stares silently — the opponent loses 30 HP from discomfort 👁️",
            "{name} opens 47 browser tabs simultaneously, crashing the universe 🌐",
            "{name} whispers something cryptic about system architecture 🏗️",
        ],
        "dodges": [
            "{name} phases out of existence momentarily — completely unreachable 👻",
            "{name} opens a terminal and rm -rf's the incoming attack 💀",
            "{name} was never really there to begin with 🕳️",
        ],
        "counters": [
            "{name} git commits the dodge and pushes a counter-attack 🔀",
            "{name} refactors the opponent's move into nothing ♻️",
        ],
    },
    "arya": {
        "attacks": [
            "{name} delivers a perfectly timed roast — opponent is stunned 🔥",
            "{name} laughs so hard the shockwave knocks the opponent back 😂",
            "{name} sends a 3 AM voice note that causes existential dread 🌙",
            "{name} speaks facts with such confidence the opponent doubts their existence 💅",
        ],
        "dodges": [
            "{name} saw that coming from three conversations ago 🔮",
            "{name} simply pivots  defends like MAX VERSTAPPEN💁",
            "{name} was already two universes ahead 🧠",
        ],
        "counters": [
            "{name} Switchbacks on to your right and overtakes you right away",
            "{name} THEEE VADEEEE OF DEATHHH",
        ],
    },
    "archana": {
        "attacks": [
            "{name} organises the battlefield so efficiently the opponent gets confused 📋",
            "{name} delivers a presentation on why they are losing — opponent cries 📊",
            "{name} plans 6 moves ahead and executes all of them at once ♟️",
            "{name} brings home-cooked energy — opponents feel guilty fighting back 🍱",
        ],
        "dodges": [
            "{name} had already scheduled this dodge three days ago 📅",
            "{name} calmly steps aside with the grace of someone who planned everything 🌸",
            "{name} was never in the line of fire — too organised for that 📁",
        ],
        "counters": [
            "{name} files a formal complaint and somehow it works ⚖️",
            "{name} counter-attacks with a perfectly colour-coded strategy 🖍️",
        ],
    },
    "abhay": {
        "attacks": [
            "{name} Enters the room in style, everyone is literally stunned",
            "{name} arrives late but immediately takes control of the situation by consulting chatgpt 🚶",
            "{name} starts asking about your future plans and hits you with anxiety + depression combo🌍",
            "{name} pulls a wildcard move nobody saw coming — not even {name} 🃏",
        ],
        "dodges": [
            "{name} Didnt listen to what you said and the attack misses completely 🤷",
            "{name} wasn't paying attention — and somehow that saves them 😴",
            "{name} Busy sleeping, attacks have no effects 😎",
        ],
        "counters": [
            "{name} laughs it off and hits back twice as hard 😤",
            "{name} turns the attack into a joke — and then attacks 🎭",
        ],
    },
    "anagha": {
        "attacks": [
            "{name} hums a tune that causes the opponent to lose focus entirely 🎵",
            "{name} brings such warm energy the opponent feels bad fighting 🌻",
            "{name} quietly does something incredibly competent — opponent panics 🧩",
            "{name} smiles and somehow that's the most threatening thing here 😊",
        ],
        "dodges": [
            "{name} floats out of the way like it was choreographed 🩰",
            "{name} was too busy being wholesome to even notice the attack 🌈",
            "{name} sidesteps gracefully — zero stress, zero effort 🌿",
        ],
        "counters": [
            "{name} responds with kindness so disarming it counts as damage 💛",
            "{name} counter-attacks mid-hum, never missing a beat 🎶",
        ],
    },
    "deeksha": {
        "attacks": [
            "{name} delivers a glare so sharp it cuts through steel 🗡️",
            "{name} speaks once — opponent immediately reconsiders their life 💬",
            "{name} enters the arena and the temperature rises by 10 degrees ",
            "{name} moves with the precision of someone who has never lost 🎯",
        ],
        "dodges": [
            "{name} steps aside elegantly — didn't even blink 😐",
            "{name} anticipated this. {name} anticipates everything 🔭",
            "{name} is simply not where the attack lands 🌫️",
        ],
        "counters": [
            "{name} responds with exactly three words — opponent is destroyed 💀",
            "{name} counter-attacks with terrifying calm 🧊",
        ],
    },
    "krupa": {
        "attacks": [
            "{name} unleashes a burst of chaotic energy — nobody knows what happened 💥",
            "{name} speedruns the entire fight in 10 seconds 🏃",
            "{name} throws confetti and somehow it causes damage 🎊",
            "{name} pulls out a completely unexpected move from nowhere 🎲",
        ],
        "dodges": [
            "{name} zips out of the way before the attack even starts ⚡",
            "{name} turns the dodge into a dance move 💃",
            "{name} was already somewhere else entirely 🌪️",
        ],
        "counters": [
            "{name} counters with chaotic precision — somehow it works 🔥",
            "{name} laughs mid-dodge and delivers a spinning counter 🌀",
        ],
    },
    "lavanya": {
        "attacks": [
            "{name} writes a poem about the opponent's downfall — it's beautiful and brutal 📜",
            "{name} speaks with such eloquence the opponent forgets to defend 🗣️",
            "{name} channels pure artistic fury into a single strike 🎨",
            "{name} overwhelms with creative energy — too much to process 🌊",
        ],
        "dodges": [
            "{name} spins away gracefully like a protagonist in slow motion 🎬",
            "{name} was composing something in their head — attack passes right through 🎼",
            "{name} dodges like it's part of a performance 🌹",
        ],
        "counters": [
            "{name} reframes the attack as inspiration and hits back with it 💡",
            "{name} counters with something so creative the opponent applauds 👏",
        ],
    },
}

ALL_MEMBERS = list(MOVES.keys())

# --------------------------------------------------
# VS Banner
# --------------------------------------------------

def show_vs_banner(fighters: list[str]):
    names = " ⚔️  VS  ⚔️ ".join(f.upper() for f in fighters)
    art = f"""
{'═' * 60}
{'':^10}  {names}  {'':^10}
{'═' * 60}
    """
    console.print(Panel(Text(art, style="bold bright_yellow", justify="center"), title="🥊 FIGHT CLUB"))
    time.sleep(1.2)


# --------------------------------------------------
# Single round commentary
# --------------------------------------------------

def play_round(attacker: str, defender: str, round_num: int):
    attack = random.choice(MOVES[attacker]["attacks"]).format(name=attacker.capitalize())
    response_type = random.choice(["dodge", "counter", "hit"])

    console.print(f"\n  [bold cyan]── Round {round_num} ──[/bold cyan]")
    time.sleep(0.4)

    console.print(f"  [bold yellow]⚡ {attack}[/bold yellow]")
    time.sleep(1.0)

    if response_type == "dodge":
        dodge = random.choice(MOVES[defender]["dodges"]).format(name=defender.capitalize())
        console.print(f"  [bold green]🛡️  {dodge}[/bold green]")
    elif response_type == "counter":
        counter = random.choice(MOVES[defender]["counters"]).format(name=defender.capitalize())
        console.print(f"  [bold magenta]🔄 {counter}[/bold magenta]")
    else:
        console.print(f"  [bold red]💥 {defender.capitalize()} takes the hit — staggers back![/bold red]")

    time.sleep(1.2)


# --------------------------------------------------
# Core fight function
# --------------------------------------------------

def theme_fight(fighters: list[str]):
    """
    Run a fight between 2+ fighters (we9 member names).
    Returns the name of the winner (string).
    """
    console.clear()
    time.sleep(0.1)

    # Validate all fighter names
    valid = [f for f in fighters if f in MOVES]
    if len(valid) < 2:
        console.print("[red]Need at least 2 valid we9 members to fight![/red]")
        console.print(f"[dim]Valid names: {', '.join(ALL_MEMBERS)}[/dim]")
        return None

    show_vs_banner(valid)

    rounds = 4 if (len(valid)< 3) else 10
    # 3 rounds — pick random attacker/defender pairs each round
    for round_num in range(1, rounds):
        pair = random.sample(valid, 2)
        play_round(pair[0], pair[1], round_num)

    # Random winner
    winner = random.choice(valid)

    console.print("\n")
    console.print(Panel(
        Text(f"🏆  {winner.upper()}  WINS THE FIGHT! 🏆\n\nSwitching to {winner.capitalize()}'s theme...",
             style="bold bright_white", justify="center"),
        title="⚔️  FIGHT OVER",
        border_style="bright_yellow"
    ))
    time.sleep(1.5)
    console.print("\n[dim]Press Enter to continue...[/dim]")
    input()
    return winner