import psutil
import time

def get_uptime():
    boot = psutil.boot_time()
    return int(time.time() - boot)
