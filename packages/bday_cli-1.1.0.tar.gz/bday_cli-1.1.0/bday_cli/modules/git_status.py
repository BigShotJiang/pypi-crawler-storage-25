import os
from git import Repo, InvalidGitRepositoryError

def get_git_status():
    try:
        repo = Repo(os.getcwd())
        return {
            "branch": repo.active_branch.name,
            "dirty": repo.is_dirty()
        }
    except InvalidGitRepositoryError:
        return None
