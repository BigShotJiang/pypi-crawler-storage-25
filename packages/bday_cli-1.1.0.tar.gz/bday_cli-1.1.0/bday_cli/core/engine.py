import bday_cli.modules.cpu as cpu
import bday_cli.modules.memory as memory
import bday_cli.modules.disk as disk
import bday_cli.modules.git_status as git_status
import bday_cli.modules.uptime as uptime

class Engine:

    def collect(self):
        return {
            "cpu": cpu.get_cpu(),
            "memory": memory.get_memory(),
            "disk": disk.get_disk(),
            "git": git_status.get_git_status(),
            "uptime": uptime.get_uptime()
        }

    def process(self, theme, intensity):
        data = self.collect()

        messages = {
            "cpu_msg": theme.cpu_message(data["cpu"], intensity),
            "mem_msg": theme.memory_message(data["memory"], intensity),
        }

        if data["git"]:
            messages["git_msg"] = theme.git_message(
                data["git"]["dirty"], intensity
            )

        return data, messages
