import argparse
import json
import os

from rich.console import Console
from bday_cli.core.engine import Engine

from bday_cli.themes.aot import AOTTheme
from bday_cli.themes.demon import DemonTheme
from bday_cli.themes.vinland import VinlandSaga

from bday_cli.personal_themes.abhay import Abhay
from bday_cli.personal_themes.archana import Archana
from bday_cli.personal_themes.anagha import Anagha
from bday_cli.personal_themes.archit import Archit             
from bday_cli.personal_themes.arya import Arya
from bday_cli.personal_themes.deeksha import Deeksha
from bday_cli.personal_themes.krupa import Krupa
from bday_cli.personal_themes.lavanya import Lavanya
from bday_cli.modes import professional, anime, we9
import bday_cli.utils.display as display

from bday_cli.utils.fight import theme_fight

CONFIG_PATH = os.path.expanduser("~/.bday_config.json")

console=Console()
# ---------------------------
# Config Handling
# ---------------------------

def load_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return None  # Signal that setup is needed


def save_config(mode, theme):
    with open(CONFIG_PATH, "w") as f:
        json.dump({"mode": mode, "theme": theme}, f)


def run_setup():
    from rich.prompt import Prompt
    from rich.panel import Panel

    console = Console()
    console.print(Panel("Welcome to bday CLI\nLet's get you set up.", title="⚔ SETUP"))

    mode = Prompt.ask(
        "Choose your mode",
        choices=["anime", "professional","we9"],
        default="anime"
    )

    if(mode=="anime"):
        theme = Prompt.ask(
            "\nChoose your theme",
            choices=["aot", "demon", "vinland", "archit"],
            default="aot"
            )
    elif (mode == "we9"):
        theme = Prompt.ask(
            "\nChoose your theme",
            choices=["abhay", "anagha","archana","archit","arya","deeksha","krupa","lavanya"],
            default="archit"
            )

    save_config(mode, theme)
    display.show_banner(theme, mode)
    console.print("\n[green]Setup complete! Run `bday --pcinfo` to get started.[/green]")


# ---------------------------
# Theme Factory
# ---------------------------

def get_theme(theme_name):
    themes = {
        "aot": AOTTheme,
        "demon": DemonTheme,
        "vinland":VinlandSaga,
        "abhay":Abhay,
        "anagha":Anagha,
        "archana":Archana,
        "archit":Archit,
        "arya":Arya,
        "deeksha":Deeksha,
        "krupa":Krupa,
        "lavanya":Lavanya,
    }

    theme_class = themes.get(theme_name)
    if theme_class:
        return theme_class()

    # Fallback safety
    return AOTTheme()


# ---------------------------
# Main CLI Logic
# ---------------------------

def main():
    config_data = load_config()

    if config_data is None:
        run_setup()
        config_data = load_config()  # Reload after setup
        return

    parser = argparse.ArgumentParser()
    parser.add_argument("--setup", action="store_true")
    parser.add_argument("--mode", choices=["professional", "anime","we9"])
    
    # Build choices based on current mode
    if config_data and config_data["mode"] == "anime":
        theme_choices = ["aot", "demon", "vinland"]
    elif config_data and config_data["mode"] == "we9":
        theme_choices = ["abhay", "anagha", "archana", "archit", "arya", "ashwith", "deeksha", "krupa", "lavanya"]
    else:
        theme_choices = ["aot", "demon", "vinland", "archit",
                        "abhay", "anagha", "archana", "arya", 
                        "ashwith", "deeksha", "krupa", "lavanya"]
    parser.add_argument("--theme", choices=theme_choices)
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--pcinfo", action="store_true")
    parser.add_argument("--quote", action="store_true")
    parser.add_argument("--animate", action="store_true", default=True)
    parser.add_argument("--no-animate", dest="animate", action="store_false")

    # Hidden birthday flag
    parser.add_argument("--birthday", action="store_true", help=argparse.SUPPRESS)

    #Fights
    parser.add_argument("--fight", nargs="*", metavar="MEMBER")

    args = parser.parse_args()

    # ---------------------------
    # Birthday Override
    # ---------------------------
    if args.birthday:
        display.show_birthday()
        return

    # ---------------------------
    # Config Change (Theme / Mode)
    # ---------------------------
    if args.setup:
        run_setup()
        return

    if args.mode or args.theme:
        new_mode = args.mode if args.mode else config_data["mode"]
        new_theme = args.theme if args.theme else config_data["theme"]

        theme_changed = (new_mode != config_data["mode"]) or (new_theme != config_data["theme"])

        save_config(new_mode, new_theme)

        display.show_banner(new_theme, new_mode, animate=theme_changed and args.animate)
        return

    # ---------------------------
    # Quote Command
    # ---------------------------
    if args.quote:
        theme = get_theme(config_data["theme"])
        display.show_quote(theme.random_quote(), config_data["mode"])
        return

    # ---------------------------
    # PC Info Command
    # ---------------------------
    if args.pcinfo:
        engine = Engine()

        theme = get_theme(config_data["theme"])
        mode_name = config_data["mode"]

        if mode_name == "professional":
            professional.run(engine, theme, display, watch=args.watch)
        elif mode_name == "anime":
            anime.run(engine, theme, display, watch=args.watch)
        else:
            we9.run(engine,theme,display,watch=args.watch)
        return

    # ---------------------------
    # Fight Command
    # ---------------------------
    if args.fight is not None:
        if config_data["mode"] != "we9":
            console.print("[red]--fight is only available in we9 mode![/red]")
            return

        from bday_cli.utils.fight import theme_fight

        #fighters = args.fight if len(args.fight) >= 2 else list(MOVES.keys())
        # MOVES keys imported from fight module — or just hardcode the fallback:
        fighters = args.fight if len(args.fight) >= 2 else ["archit","arya","archana","abhay","anagha","deeksha","krupa","lavanya"]

        winner = theme_fight(fighters)

        if winner:
            save_config(config_data["mode"], winner)
            display.show_banner(winner, config_data["mode"], animate=True)
        return

    # ---------------------------
    # Default Behavior
    # ---------------------------
    # If no arguments provided → show help
    parser.print_help()


# ---------------------------
# Entry Point
# ---------------------------

if __name__ == "__main__":
    main()
