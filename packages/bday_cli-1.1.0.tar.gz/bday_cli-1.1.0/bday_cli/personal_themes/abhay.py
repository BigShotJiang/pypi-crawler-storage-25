from ..themes.base import BaseTheme

class Abhay(BaseTheme):

    quotes = [
        "I dont want to do it, not interested",
        "buy me shawarma please",
        "Eh? What happened?",
        "What color is your lamborghini?"  
    ]
    def cpu_message(self, cpu, intensity):
        if intensity == "low":
            return "System stable." if cpu < 70 else "High CPU usage."
        
        if cpu > 90:
            return "Explosion Imminent! you have 3 seconds to evacuate to safety."
        elif cpu > 70:
            return "Chill bruh! Get me an Ice pack."
        return "Wanna watch a movie? Go grab popcorn"

    def memory_message(self, memory, intensity):
        if intensity == "low":
            return "Memory usage normal." if memory < 80 else "Memory usage high."

        return "Sometimes I get deja vu and amnesia at the same time, like I have forgotten this before too." if memory > 80 else "Ask me anything lol, 1+1 = 11 for sure..."

    def git_message(self, dirty, intensity):
        if intensity == "low":
            return "Repo clean." if not dirty else "Uncommitted changes."

        return " Touch git file again and ill make everything vanish" if dirty else "Abi push karde warna mauka hath se nikal jaayega"
