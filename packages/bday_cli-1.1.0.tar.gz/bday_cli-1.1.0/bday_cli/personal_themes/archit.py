from ..themes.base import BaseTheme

class Archit(BaseTheme):

    quotes = [
        "Muh diya toh kuch bhi bolega",
        "AAAP yaha aajaye",
        "PC hai toh kuch bhi karega",
        "Accha londe"
        
    ]
    def cpu_message(self, cpu, intensity):
        if intensity == "low":
            return "System stable." if cpu < 70 else "High CPU usage."
        
        if cpu > 90:
            return "PC band mado ley!!"
        elif cpu > 70:
            return ""
        return "YEEEHH baaat !!!"

    def memory_message(self, memory, intensity):
        if intensity == "low":
            return "Memory usage normal." if memory < 80 else "Memory usage high."

        return " Memory diya tho kuch bhi karega " if memory > 80 else " Full memory easy peasy"

    def git_message(self, dirty, intensity):
        if intensity == "low":
            return "Repo clean." if not dirty else "Uncommitted changes."

        return " Repo clean madoo " if dirty else "NOICE repo clean"
