from ..themes.base import BaseTheme

class Anagha(BaseTheme):

    quotes = [
        "lalalala"
        "happpppy birthdayyy boyyyyyyy"
        "hahahaha oooooooo"
        "babaaaaaaaa"
        "DSA...!" 
        "u r too nosy..."
        "byebye"
    ]
    def cpu_message(self, cpu, intensity):
        if intensity == "low":
            return "System stable." if cpu < 70 else "High CPU usage."
        
        if cpu > 90:
            return "PC band mado ley!!"
        elif cpu > 70:
            return ""
        return " CPU Resting at the Butterfly Mansion"

    def memory_message(self, memory, intensity):
        if intensity == "low":
            return "Memory usage normal." if memory < 80 else "Memory usage high."

        return " Final Selection. Your RAM is packed with demons" if memory > 80 else "Memory might be infinite castle"

    def git_message(self, dirty, intensity):
        if intensity == "low":
            return "Repo clean." if not dirty else "Uncommitted changes."

        return " Repo turning to Infinite castle not clean" if dirty else "Water Breathing 6th form Calm sea repo clean"
