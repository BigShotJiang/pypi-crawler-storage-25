from ..themes.base import BaseTheme

class Arya(BaseTheme):

    quotes = [
        "NIGGGGAAAAA",
        "Vade !!",
        "BRUHHH",
        "Do all humans see the same colours ??!",
        "5+5 is NOT DEFINNNEDD!!",
        "What ra Ashwith too much ... ",
        "Remember to call me the day before exam to discuss once",
        "Jai",
        "I can prove free will exists",
        "Log(i) and Log(-ve) damn",
        "Bro for this exact reason we joined this group NOW ITS TIMEE",
        "Agaya Ganduuu :)"
    ]
    def cpu_message(self, cpu, intensity):
        if intensity == "low":
            return "System stable." if cpu < 70 else "High CPU usage."
        
        if cpu > 90:
            return "Nigga CPU is cooked !!"
        elif cpu > 50:
            return ""
        return "Vade CPU no job only"

    def memory_message(self, memory, intensity):
        if intensity == "low":
            return "Memory usage normal." if memory < 80 else "Memory usage high."

        return "Bro Memory out of universe bounds" if memory > 60 else "Memory Chill bro"

    def git_message(self, dirty, intensity):
        if intensity == "low":
            return "Repo clean." if not dirty else "Uncommitted changes."

        return "Repd Dirty re niggaa" if dirty else "Repo Clean re nigga"
