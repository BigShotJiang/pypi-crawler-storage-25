from ..themes.base import BaseTheme

class Deeksha(BaseTheme):

    quotes = [
        "Much and beee"
        "Aww so Pwettyy"
        "Humko kya CHUUUU- samjha hai"
        "Beetch"
        "GAYYY"
        "Mera Bollywood dance partner"
        ""
        
    ]
    def cpu_message(self, cpu, intensity):
        if intensity == "low":
            return "System stable." if cpu < 70 else "High CPU usage."
        
        if cpu > 90:
            return "CPU ke dimaag ka dahi kar diya"
        elif cpu > 70:
            return ""
        return " CPU Thek hai bhai"

    def memory_message(self, memory, intensity):
        if intensity == "low":
            return "Memory usage normal." if memory < 80 else "Memory usage high."

        return "Memory chedta hai?" if memory > 80 else "Memory decent"

    def git_message(self, dirty, intensity):
        if intensity == "low":
            return "Repo clean." if not dirty else "Uncommitted changes."

        return " What ya? You dirtying git ahh?" if dirty else "Abba full clean git uve kept"
    
