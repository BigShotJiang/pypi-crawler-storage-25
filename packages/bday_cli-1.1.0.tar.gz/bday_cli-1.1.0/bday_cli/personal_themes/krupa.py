from ..themes.base import BaseTheme

class Krupa(BaseTheme):

    quotes = [
        "My brain is not working",
        "Brooooooo!!!u know what??",
        "Let's gooooooo",
        "67"
        
    ]
    def cpu_message(self, cpu, intensity):
        if intensity == "low":
            return "System stable." if cpu < 70 else "High CPU usage."
        
        if cpu > 90:
            return "FIREEE!!"
        elif cpu > 70:
            return ":)"
        return " CPU in Heaven"

    def memory_message(self, memory, intensity):
        if intensity == "low":
            return "Memory usage normal." if memory < 80 else "Memory usage high."

        return " My brain is still not working" if memory > 80 else "i'm sleepy!!"

    def git_message(self, dirty, intensity):
        if intensity == "low":
            return "Repo clean." if not dirty else "Uncommitted changes."

        return "wash the repo first " if dirty else "bye"
