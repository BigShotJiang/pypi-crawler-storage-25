from ..themes.base import BaseTheme

class Lavanya(BaseTheme):

    quotes = [
        "Muh diya toh kuch bhi bolega",
        "AAAP yaha aajaye",
        "PC hai toh kuch bhi karega",
        "Accha londe"
        
    ]
    def cpu_message(self, cpu, intensity):
        if intensity == "low":
            return "System stable." if cpu < 70 else "High CPU usage."
        
        if cpu > 90:
            return "100% usage ah? What are you even overthinking now?"
        elif cpu > 70:
            return ""
        return " Bro entered power saving mode"

    def memory_message(self, memory, intensity):
        if intensity == "low":
            return "Memory usage normal." if memory < 80 else "Memory usage high."

        return " Memory full agide ashwith , delete some useless thoughts." if memory > 80 else "Memory is good"

    def git_message(self, dirty, intensity):
        if intensity == "low":
            return "Repo clean." if not dirty else "Uncommitted changes."

        return "Repo Clean" if dirty else "Everything about you just… makes sense"
