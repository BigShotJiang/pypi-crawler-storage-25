def run(engine, theme, display, watch=False):
    import time

    while True:
        display.console.clear()
        data, messages = engine.process(theme, intensity="high")
        display.render_anime(data, messages)

        if not watch:
            break
        time.sleep(1)
