# config.py

DEFAULT_THEME = "aot"
DEFAULT_MODE = "professional"
