# CLI_TOOL1
This is an anime themed CLI tool for Ashwith's Bday !!!!

So what we are making is a CLI tool which is anime based
It has functions like checking CPU/memory status etc

Current Anime Themes:
1)Attack On Titan
2)Demon Slayer
3)Fire Force
4)Vinland Saga

bday_cli/
│
├── main.py
├── config.py
├── modes/
│   ├── professional.py
│   └── anime.py
│
├── core/
│   └── engine.py  
├── themes/
│   ├── base.py
│   ├── aot.py
│   ├── demon.py
│   ├── vinland.py
│
│
├── personal_themes/ 
│   ├── abhay.py
│   ├── anagha.py 
│   ├── archana.py
│   ├── archit.py  
│   ├── arya.py
│   ├── deeksha.py
│   ├── krupa.py
│   ├── lavanya.py    
│
├── modules/
│   ├── cpu.py
│   ├── memory.py
│   ├── disk.py
│   ├── git_status.py
│   └── uptime.py
│
└── utils/
    └── display.py
    └── fight.py

#### FOR ASHWITH

bday --setup

bday --mode mode_name 

bday --theme theme_name --animate/--no-animate   -------> last part optional default is animate 

bday --quote

bday --birthday

bday --fight name1 name2 name3... or just bday --fight for all  (only in we9 mode)

bday --pcinfo


####  FOR EVERYONE OTHER THAN ASHWITH
Change you quotes and sayings in    personal_themes->your_name.py (check arya.py or archit.py for reference)

Add your ASCII banner in    utils->display.py (Check archit's elif part for refrence)

Change your moves at if needed at  utils->fight.py 

Dont touch other code unless absolutely needed 
