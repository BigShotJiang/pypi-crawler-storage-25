# django-settings2

A simple Django app to store and retrieve application settings in the database.

## Requirements

- Python >= 3.6
- Django >= 3.2

## Installation

```bash
pip install django-settings2
```

## Configuration

### Add to `INSTALLED_APPS`

```python
INSTALLED_APPS = [
    ...
    "django_settings2",
]
```

### Run migrations

```bash
python manage.py migrate
```

## Usage

```python
from django_settings2.models import DjangoSettings

# Store a value
DjangoSettings.set_value("my_key", "hello")
DjangoSettings.set_value("max_retries", 5, cls=int)
DjangoSettings.set_value("threshold", 0.75, cls=float)

# Retrieve a value
value = DjangoSettings.get_value("my_key", default="fallback")

# Retrieve a JSON value stored as text
data = DjangoSettings.get_value_json("my_json_key", default={})

# Retrieve with row-level lock (useful in transactions)
data = DjangoSettings.get_value_json("my_json_key", lock=True)
```

## License

MIT
