# -*- coding: utf-8 -*-
from django.contrib import admin
from .models import DjangoSettings


class DjangoSettingsAdmin(admin.ModelAdmin):
    list_display = ('id', 'key', 'int_val', 'float_val', 'text_val')
    list_display_links = ('key',)
    search_fields = ['key', 'int_val', 'float_val', 'text_val']


admin.site.register(DjangoSettings, DjangoSettingsAdmin)
