from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='DjangoSettings',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('key', models.CharField(max_length=100, unique=True)),
                ('int_val', models.IntegerField(blank=True, null=True)),
                ('float_val', models.FloatField(blank=True, null=True)),
                ('text_val', models.TextField(blank=True, null=True)),
            ],
            options={
                'db_table': 'django_settings2',
            },
        ),
    ]
