# -*- coding: utf-8 -*-
import json
from django.db import models


class DjangoSettings(models.Model):
    key = models.CharField(max_length=100, unique=True)
    int_val = models.IntegerField(blank=True, null=True)
    float_val = models.FloatField(blank=True, null=True)
    text_val = models.TextField(blank=True, null=True)

    class Meta:
        db_table = "django_settings2"

    def __str__(self):
        return '{}'.format(self.key)

    @staticmethod
    def get_value(key, default=None):
        try:
            setting = DjangoSettings.objects.get(key=key)
            if setting.int_val:
                return setting.int_val
            elif setting.float_val:
                return setting.float_val
            else:
                return setting.text_val
        except Exception:
            return default

    @staticmethod
    def get_value_json(key, default=None, lock=False):
        try:
            if lock:
                setting = DjangoSettings.objects.select_for_update().get(key=key)
            else:
                setting = DjangoSettings.objects.get(key=key)
            return json.loads(str(setting.text_val))
        except Exception:
            return default

    @staticmethod
    def set_value(key, value, cls=None):
        setting, created = DjangoSettings.objects.get_or_create(key=key)
        if cls == int:
            setting.int_val = int(value)
        elif cls == float:
            setting.float_val = float(value)
        else:
            setting.text_val = str(value)
        setting.save()
