import numpy as np
import pytest

import marlenv
from marlenv import ContinuousSpace, MARLEnv, MultiDiscreteSpace, Observation, State, catalog
from marlenv.adapters import PymarlAdapter

skip_gym = not marlenv.adapters.HAS_GYM
skip_pettingzoo = not marlenv.adapters.HAS_PETTINGZOO
skip_smac = not marlenv.adapters.HAS_SMAC
skip_smacv2 = not marlenv.adapters.HAS_SMACv2


@pytest.mark.skipif(skip_gym, reason="Gymnasium is not installed")
def test_gym_adapter_discrete():
    # Discrete action space
    env = marlenv.make("CartPole-v1")
    assert isinstance(env.action_space, MultiDiscreteSpace)
    obs, state = env.reset()
    assert isinstance(obs, Observation)
    assert isinstance(state, State)
    assert isinstance(env, MARLEnv)
    assert env.n_actions == 2
    assert env.n_agents == 1

    step = env.step(env.sample_action())
    assert isinstance(step.obs, Observation)
    assert isinstance(step.reward, np.ndarray)
    assert step.reward.shape == (1,)
    assert isinstance(step.done, bool)
    assert isinstance(step.truncated, bool)
    assert isinstance(step.info, dict)


@pytest.mark.skipif(skip_gym, reason="Gymnasium is not installed")
def test_gym_adapter_continuous():
    env = marlenv.make("Pendulum-v1")
    assert isinstance(env.action_space, ContinuousSpace)
    obs, state = env.reset()
    assert isinstance(obs, Observation)
    assert isinstance(state, State)
    assert isinstance(env, MARLEnv)
    assert env.n_actions == 1
    assert env.n_agents == 1

    step = env.step(env.sample_action())
    assert isinstance(step.obs, Observation)
    assert isinstance(step.reward, np.ndarray)
    assert step.reward.shape == (1,)
    assert isinstance(step.done, bool)
    assert isinstance(step.truncated, bool)
    assert isinstance(step.info, dict)

    # Continuous action space
    env = marlenv.make("Pendulum-v1")
    env.reset()


@pytest.mark.skipif(skip_pettingzoo, reason="PettingZoo is not installed")
def test_pettingzoo_adapter_discrete_action():
    # https://pettingzoo.farama.org/environments/sisl/pursuit/#pursuit
    from pettingzoo.sisl import pursuit_v4

    env = marlenv.adapters.PettingZoo(pursuit_v4.parallel_env())
    env.reset()
    action = env.action_space.sample()
    step = env.step(action)
    assert isinstance(step.obs, Observation)
    assert isinstance(step.reward, np.ndarray)
    assert step.reward.shape == (1,)
    assert isinstance(step.done, bool)
    assert isinstance(step.truncated, bool)
    assert isinstance(step.info, dict)
    assert env.n_agents == 8
    assert env.n_actions == 5
    assert isinstance(env.action_space, MultiDiscreteSpace)


@pytest.mark.skipif(skip_pettingzoo, reason="PettingZoo is not installed")
def test_pettingzoo_adapter_continuous_action():
    from pettingzoo.butterfly import pistonball_v6

    pz_env = pistonball_v6.env(continuous=True)
    pz_env.reset()
    action_space = pz_env.action_space(pz_env.agents[0])
    env = marlenv.adapters.PettingZoo(pistonball_v6.parallel_env(continuous=True))
    env.reset()
    step = env.random_step()
    assert isinstance(step.obs, Observation)
    assert isinstance(step.reward, np.ndarray)
    assert step.reward.shape == (1,)
    assert isinstance(step.done, bool)
    assert isinstance(step.truncated, bool)
    assert isinstance(step.info, dict)
    assert action_space.shape is not None
    assert env.n_actions == action_space.shape[0]
    assert env.n_agents == len(pz_env.agents)
    assert isinstance(env.action_space, ContinuousSpace)


def _check_env_3m(env):
    from marlenv.adapters import SMAC

    assert isinstance(env, SMAC)
    obs, state = env.reset()
    assert isinstance(obs, Observation)
    assert env.n_agents == 3
    assert isinstance(env.action_space, MultiDiscreteSpace)

    step = env.random_step()
    assert isinstance(step.obs, Observation)
    assert isinstance(step.reward, np.ndarray)
    assert step.reward.shape == (1,)
    assert isinstance(step.done, bool)
    assert isinstance(step.truncated, bool)
    assert isinstance(step.info, dict)


@pytest.mark.skipif(skip_smac, reason="SMAC is not installed")
def test_smac_from_class():
    from smac.env import StarCraft2Env  # pyright: ignore[reportMissingImports]

    from marlenv.adapters import SMAC

    env = SMAC(StarCraft2Env("3m"))
    _check_env_3m(env)


@pytest.mark.skipif(skip_smac, reason="SMAC is not installed")
def test_smac_render():
    from marlenv.adapters import SMAC

    env = SMAC("3m")
    env.reset()
    env.render()


@pytest.mark.skipif(skip_smac, reason="SMAC is not installed")
def test_smac_two_resets():
    from marlenv.adapters import SMAC

    def run_episode(env: SMAC):
        env.reset()
        done = False
        while not done:
            step = env.random_step()
            done = step.is_terminal

    env = SMAC("3m")
    run_episode(env)
    run_episode(env)


@pytest.mark.skipif(skip_smac, reason="SMAC is not installed")
def test_smac_obs():
    from marlenv.adapters import SMAC

    def check(obs: Observation, state: State):
        assert isinstance(obs.data, np.ndarray)
        assert isinstance(obs.extras, np.ndarray)
        assert isinstance(obs.available_actions, np.ndarray)

        assert isinstance(state.data, np.ndarray)
        assert isinstance(state.extras, np.ndarray)

    env = SMAC("3m")
    obs, state = env.reset()
    check(obs, state)

    done = False
    while not done:
        step = env.random_step()
        check(step.obs, step.state)
        done = step.is_terminal


@pytest.mark.skipif(skip_smacv2, reason="SMACv2 is not installed")
def test_smacv2():
    from smacv2.env.starcraft2.wrapper import StarCraftCapabilityEnvWrapper

    from marlenv.adapters import SMACv2

    smac_env = StarCraftCapabilityEnvWrapper(
        capability_config={
            "n_units": 5,
            "n_enemies": 5,
            "team_gen": {
                "dist_type": "weighted_teams",
                "unit_types": ["marine", "marauder", "medivac"],
                "exception_unit_types": ["medivac"],
                "weights": [0.45, 0.45, 0.1],
                "observe": True,
            },
            "start_positions": {
                "dist_type": "surrounded_and_reflect",
                "p": 0.5,
                "n_enemies": 5,
                "map_x": 32,
                "map_y": 32,
            },
        },
        map_name="10gen_terran",
        debug=True,
        conic_fov=False,
        obs_own_pos=True,
        use_unit_ranges=True,
        min_attack_range=2,
    )
    env = SMACv2(smac_env)
    n_episodes = 2
    for _ in range(n_episodes):
        env.reset()
        stop = False
        while not stop:
            step = env.random_step()
            stop = step.is_terminal


@pytest.mark.skipif(skip_smac, reason="SMAC is not installed")
def test_smac_action_space_labels():
    from marlenv.adapters import SMAC

    env = SMAC()
    for label in env.action_space.labels:
        assert not label.startswith("Dim")


@pytest.mark.skipif(skip_smac, reason="SMAC is not installed")
def test_smac_blank_init():
    from marlenv.adapters import SMAC

    SMAC()


@pytest.mark.skipif(skip_smacv2, reason="SMAC is not installed")
def test_smacv2_blank_init():
    from marlenv.adapters import SMACv2

    SMACv2()


def test_pymarl():
    LIMIT = 20
    N_AGENTS = 2
    N_ACTIONS = 5
    UNIT_STATE_SIZE = 1
    OBS_SIZE = 42
    REWARD_STEP = 1
    env = PymarlAdapter(
        catalog.DiscreteMockEnv(
            N_AGENTS,
            n_actions=N_ACTIONS,
            agent_state_size=UNIT_STATE_SIZE,
            obs_size=OBS_SIZE,
            reward_step=REWARD_STEP,
        ),
        LIMIT,
    )

    info = env.get_env_info()
    assert info["n_agents"] == N_AGENTS
    assert info["n_actions"] == N_ACTIONS
    assert env.get_total_actions() == N_ACTIONS
    assert info["state_shape"] == UNIT_STATE_SIZE * N_AGENTS
    assert env.get_state_size() == UNIT_STATE_SIZE * N_AGENTS
    assert info["obs_shape"] == OBS_SIZE
    assert env.get_obs_size() == OBS_SIZE
    assert info["episode_limit"] == LIMIT

    try:
        env.get_obs()
        assert False, "Should raise ValueError because the environment has not yet been reset"
    except ValueError:
        pass

    env.reset()
    obs = env.get_obs()
    assert obs.shape == (N_AGENTS, OBS_SIZE)
    state = env.get_state()
    assert len(state.shape) == 1 and state.shape[0] == env.get_state_size()

    for _ in range(LIMIT - 1):
        reward, done, _ = env.step([0] * N_AGENTS)
        assert reward == REWARD_STEP
        assert not done
    reward, done, _ = env.step([0] * N_AGENTS)
    assert reward == REWARD_STEP
    assert done


@pytest.mark.skipif(skip_gym, reason="Gymnasium is not installed")
def test_from_gym_togym():
    from gymnasium import make

    from marlenv.adapters import Gym, ToGym

    cartpole = make("CartPole-v1", render_mode="rgb_array")
    marlenv_cartpole = Gym(cartpole)
    to_gym = ToGym(marlenv_cartpole, render_mode="rgb_array")

    copy = make("CartPole-v1", render_mode="rgb_array")

    obs1, _ = copy.reset(seed=0)
    obs2, _ = to_gym.reset(seed=0)
    assert np.array_equal(obs1, obs2)

    done = False
    while not done:
        action = copy.action_space.sample()
        obs1, r1, done1, trunc1, _ = copy.step(action)
        obs2, r2, done2, trunc2, _ = to_gym.step(action)
        assert np.array_equal(obs1, obs2)
        assert r1 == r2
        assert done1 == done2
        assert trunc1 == trunc2
        done = done1 or trunc1


@pytest.mark.skipif(skip_gym, reason="Gymnasium is not installed")
def test_togym():
    from marlenv.adapters import ToGym

    env = ToGym(catalog.DiscreteMockEnv(n_agents=1))

    obs, info = env.reset(seed=123)
    assert isinstance(obs, np.ndarray)
    assert isinstance(info, dict)

    obs, reward, done, trucated, info = env.step(0)
    assert isinstance(obs, np.ndarray)
    assert isinstance(reward, float)
    assert isinstance(done, bool)
    assert isinstance(trucated, bool)
    assert isinstance(info, dict)


@pytest.mark.skipif(skip_gym, reason="Gymnasium is not installed")
def test_togym_multi():
    from marlenv.adapters import ToGym

    with pytest.raises(AssertionError):
        ToGym(catalog.DiscreteMockEnv(n_agents=3))


@pytest.mark.skipif(skip_gym, reason="Gymnasium is not installed")
def test_togym_unavailable_action_default_random():
    """When the agent performs an action that is unavailable, we should decide what to do !"""
    from marlenv.adapters import ToGym

    env = marlenv.Builder(catalog.DiscreteMockEnv(n_agents=1, n_actions=5)).mask_actions(0).build()
    env = ToGym(env)
    env.reset()
    env.step(0)  # Random step


@pytest.mark.skipif(skip_gym, reason="Gymnasium is not installed")
def test_togym_unavailable_action_default_error():
    """When the agent performs an action that is unavailable, we should decide what to do !"""
    from marlenv.adapters import ToGym

    env = marlenv.Builder(catalog.DiscreteMockEnv(n_agents=1, n_actions=5)).mask_actions(0).build()
    env = ToGym(env, on_unavailable_action="error")
    env.reset()
    with pytest.raises(NotImplementedError):
        env.step(0)
