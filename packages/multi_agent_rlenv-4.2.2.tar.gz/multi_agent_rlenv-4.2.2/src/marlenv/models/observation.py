import math
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal, Sequence, overload

import numpy as np
import numpy.typing as npt
from deprecated import deprecated

if TYPE_CHECKING:
    from torch import Tensor  # pyright: ignore[reportMissingImports]


@dataclass
class Observation:
    """
    Container class for policy input arguments.
    """

    data: npt.NDArray[np.float32]
    """The actual environment observation. The shape is [n_agents, *obs_shape]"""
    extras: npt.NDArray[np.float32]
    """The extra information to provide to the dqn alongisde the features (agent ID, last action, ...)"""
    available_actions: npt.NDArray[np.bool]
    """The available actions at the time of the observation"""
    n_agents: int

    def __init__(
        self,
        data: npt.NDArray[np.float32],
        available_actions: Sequence[bool] | npt.NDArray[np.bool],
        extras: npt.NDArray[np.float32] | None = None,
    ):
        self.data = data
        if not isinstance(available_actions, np.ndarray):
            available_actions = np.array(available_actions)
        self.available_actions = available_actions
        self.n_agents = available_actions.shape[0]
        if extras is not None:
            self.extras = extras
        else:
            self.extras = np.zeros((self.n_agents, 0), dtype=np.float32)

    def add_extra(self, extra: list[list[float]] | npt.ArrayLike):
        """Append an extra feature to the observation"""
        self.extras = np.concatenate((self.extras, extra), axis=1, dtype=np.float32)

    def of_agent(self, agent_id: int, keep_dim: bool = True) -> "Observation":
        """
        Return the observation of the given agent.

        If `keep_dim` is True, the resulting shape is [1, *obs_shape].
        Otherwise, the resulting shape is [*obs_shape].
        """
        if keep_dim:
            return Observation(
                data=self.data[agent_id : agent_id + 1],
                extras=self.extras[agent_id : agent_id + 1],
                available_actions=self.available_actions[agent_id : agent_id + 1],
            )
        return Observation(
            data=self.data[agent_id],
            extras=self.extras[agent_id],
            available_actions=self.available_actions[agent_id],
        )

    @deprecated(reason="Use `of_agent` instead")
    def agent(self, agent_id: int, keep_dim: bool = True):
        """
        See `of_agent`. This method is deprecated and will be removed in a future version.
        """
        return self.of_agent(agent_id, keep_dim)

    @property
    def forbidden_actions(self):
        """Actions that are not available (i.e.: `~self.available_actions`)"""
        return ~self.available_actions

    @property
    def shape(self) -> tuple[int, ...]:
        """The individual shape of the observation data"""
        return self.data[0].shape

    @property
    def extras_shape(self) -> tuple[int, ...]:
        """The individual shape of the observation extras"""
        return self.extras[0].shape

    @property
    def extras_size(self):
        return math.prod(self.extras_shape)

    def __hash__(self):
        if isinstance(self.data, np.ndarray):
            d = hash(self.data.tobytes())
        else:
            d = hash(self.data)
        return hash((d, self.extras.tobytes()))

    def __ne__(self, other):
        return not self.__eq__(other)

    def __eq__(self, other):
        if not isinstance(other, Observation):
            return False
        if isinstance(self.data, np.ndarray):
            if not isinstance(other.data, np.ndarray):
                return False
            if not np.array_equal(self.data, other.data):
                return False
        return np.array_equal(self.extras, other.extras) and np.array_equal(self.available_actions, other.available_actions)

    @overload
    def as_tensors(self, device=None, *, batch_dim: Literal[True]) -> "tuple[Tensor, Tensor]":
        """Convert the observation data and extras to a tuple of tensors of shape `(1, n_agents, *self.shape)` and `(1, n_agents, *self.extras_shape)` respectively."""

    @overload
    def as_tensors(self, device=None, *, batch_dim: bool = False) -> "tuple[Tensor, Tensor]":
        """Convert the observation data and extras to a tuple of tensors of shape `(n_agents, *self.shape)` and `(n_agents, *self.extras_shape)` respectively."""

    @overload
    def as_tensors(self, device=None, *, batch_dim: Literal[True], actions: Literal[True]) -> "tuple[Tensor, Tensor, Tensor]":
        """Convert the observation data, extras and available actions to a tuple of tensors of shape `(1, n_agents, *self.shape)`, `(1, n_agents, *self.extras_shape)` and `(1, n_agents, *self.available_actions_shape)` respectively."""

    def as_tensors(self, device=None, *, batch_dim=False, actions=False):
        import torch  # pyright: ignore[reportMissingImports]

        data = torch.from_numpy(self.data).to(device, non_blocking=True)
        extras = torch.from_numpy(self.extras).to(device, non_blocking=True)
        to_return = [data, extras]
        if actions:
            available_actions = torch.from_numpy(self.available_actions).to(device, non_blocking=True)
            to_return.append(available_actions)
        if batch_dim:
            to_return = (t.unsqueeze(0) for t in to_return)
        return tuple(to_return)
