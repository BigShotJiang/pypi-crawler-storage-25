from __future__ import annotations

import hashlib
import hmac
import json
import platform
import time
import urllib.error
import urllib.request
import uuid
from typing import Any, Dict, Optional


class AuthixClient:
    """
    Authix HTTP client. Point ``base_url`` at your API host (e.g. https://getauthix.online).
    (e.g. http://localhost:3003 or https://your-domain).
    """

    def __init__(self, options: Dict[str, Any]) -> None:
        self.name = options["name"]
        self.ownerid = options["ownerid"]
        self.secret = options["secret"]
        self.version = options.get("version", "1.0")
        self.base_url = (options.get("base_url") or "http://localhost:3003").rstrip("/")
        self.session_id: Optional[str] = None
        self.user_data: Optional[Dict[str, Any]] = None
        self.app_data: Optional[Dict[str, Any]] = None

    def _build_payload(self, extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        base = extra or {}
        return {
            **base,
            "name": self.name,
            "ownerid": self.ownerid,
            "secret": self.secret,
            "version": self.version,
        }

    def _verify_signature(self, parsed: Dict[str, Any]) -> None:
        if not parsed or "signature" not in parsed:
            return
        copy = {k: v for k, v in parsed.items() if k != "signature"}
        body = json.dumps(copy, separators=(",", ":"), ensure_ascii=True)
        expected = hmac.new(
            self.secret.encode("utf-8"),
            body.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        if parsed.get("signature") != expected:
            raise ValueError("Invalid response signature")

    def request(self, path: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        rel = path if path.startswith("/") else f"/{path}"
        url = f"{self.base_url}{rel}"
        post_data = json.dumps(self._build_payload(data or {}), separators=(",", ":")).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=post_data,
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                raw = resp.read().decode("utf-8")
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", errors="replace")
            try:
                parsed = json.loads(raw or "{}")
            except json.JSONDecodeError as err:
                raise ValueError(f"Invalid JSON from server (HTTP {e.code})") from err
            self._verify_signature(parsed)
            return parsed
        except urllib.error.URLError as e:
            raise ConnectionError(str(e.reason)) from e

        try:
            parsed = json.loads(raw or "{}")
        except json.JSONDecodeError as e:
            raise ValueError("Invalid JSON response from server") from e
        self._verify_signature(parsed)
        return parsed

    def init(self) -> Dict[str, Any]:
        response = self.request("/api/1.2/init")
        if not response.get("success"):
            raise RuntimeError(response.get("message") or "Initialization failed")
        self.session_id = response.get("sessionid")
        self.app_data = {
            "version": response.get("version"),
            "customerPanelLink": response.get("customerPanelLink"),
            "numUsers": response.get("numUsers"),
            "numOnlineUsers": response.get("numOnlineUsers"),
            "numKeys": response.get("numKeys"),
            "numSubscriptions": response.get("numSubscriptions"),
        }
        return response

    def license(self, key: str, hwid: Optional[str] = None) -> Dict[str, Any]:
        response = self.request("/api/1.2/license", {"key": key, "hwid": hwid})
        if not response.get("success"):
            raise RuntimeError(response.get("message") or "License validation failed")
        self.session_id = response.get("sessionid")
        self.user_data = response.get("user_data")
        return response

    def login(self, username: str, password: str, hwid: Optional[str] = None) -> Dict[str, Any]:
        response = self.request(
            "/api/1.2/login",
            {"username": username, "password": password, "hwid": hwid},
        )
        if not response.get("success"):
            raise RuntimeError(response.get("message") or "Login failed")
        self.session_id = response.get("sessionid")
        self.user_data = response.get("user_data")
        return response

    def register(
        self,
        username: str,
        password: str,
        key: str,
        email: Optional[str] = None,
        hwid: Optional[str] = None,
    ) -> Dict[str, Any]:
        response = self.request(
            "/api/1.2/register",
            {
                "username": username,
                "password": password,
                "key": key,
                "email": email,
                "hwid": hwid,
            },
        )
        if not response.get("success"):
            raise RuntimeError(response.get("message") or "Registration failed")
        self.session_id = response.get("sessionid")
        self.user_data = response.get("user_data")
        return response

    def check(self) -> Dict[str, Any]:
        if not self.session_id:
            raise RuntimeError("No active session")
        response = self.request("/api/1.2/check", {"sessionid": self.session_id})
        if not response.get("success"):
            raise RuntimeError(response.get("message") or "Session check failed")
        self.user_data = response.get("user_data")
        return response

    def checkblack(self, hwid: Optional[str] = None, ip: Optional[str] = None) -> Dict[str, Any]:
        response = self.request("/api/1.2/checkblack", {"hwid": hwid, "ip": ip})
        if not response.get("success"):
            raise RuntimeError(response.get("message") or "Blacklist check failed")
        return response

    def is_subscribed(self, subscription_name: str) -> bool:
        if not self.user_data or not self.user_data.get("subscriptions"):
            return False
        now = time.time()
        for sub in self.user_data["subscriptions"]:
            if sub.get("subscription") == subscription_name and (sub.get("expiry") or 0) > now:
                return True
        return False

    def get_subscription(self, subscription_name: str) -> Optional[Dict[str, Any]]:
        if not self.user_data or not self.user_data.get("subscriptions"):
            return None
        for sub in self.user_data["subscriptions"]:
            if sub.get("subscription") == subscription_name:
                return sub
        return None

    @staticmethod
    def generate_hwid() -> str:
        try:
            components = []
            proc = platform.processor() or "unknown"
            components.append(proc)
            components.append(str(uuid.getnode()))
            components.append(platform.node() or "unknown")
            h = hashlib.sha256()
            for c in components:
                h.update(str(c).encode("utf-8"))
            return h.hexdigest()[:32]
        except Exception:
            return hashlib.sha256(str(time.time()).encode()).hexdigest()[:32]
