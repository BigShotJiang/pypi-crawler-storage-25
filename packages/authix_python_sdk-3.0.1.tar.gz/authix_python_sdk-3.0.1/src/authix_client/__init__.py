"""
Authix client — POST /api/1.2/* (production: https://getauthix.online).
"""

from authix_client.client import AuthixClient

__all__ = ["AuthixClient"]
__version__ = "3.0.1"
