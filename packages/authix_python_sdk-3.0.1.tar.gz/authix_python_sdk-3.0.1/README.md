# authix-python-sdk

Official Python SDK for [Authix](https://getauthix.online): `POST /api/1.2/*` — `init`, `license`, `login`, `register`, `check`, `checkblack`. Uses only the **standard library** (no extra runtime dependencies).

**PyPI:** [`authix-python-sdk`](https://pypi.org/project/authix-python-sdk/)  
**Import:** `from authix_client import AuthixClient`

## Install

```bash
pip install authix-python-sdk
```

## Quick start

```python
from authix_client import AuthixClient

client = AuthixClient({
    "name": "your_app_name",
    "ownerid": "your_owner_id",
    "secret": "your_app_secret",
    "version": "1.0",
    "base_url": "https://getauthix.online",
})

client.init()
hwid = AuthixClient.generate_hwid()
client.license("YOUR-LICENSE-KEY", hwid)
client.check()
print(client.user_data)
```

## Maintainer: build & publish

From the **repository root** (requires [PyPI API token](https://pypi.org/manage/account/token/)):

```bash
# .env: PYPI_UPLOAD_TOKEN=pypi-...
npm run pypi:publish
```

Or manually from `sdk/pypi/`:

```bash
pip install build twine
python -m build
twine upload dist/* --username __token__ --password YOUR_PYPI_TOKEN
```

## License

MIT
