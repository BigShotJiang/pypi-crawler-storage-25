from __future__ import annotations


import json
import os
from typing import Any

import httpx
from mcp.server.auth.settings import AuthSettings, ClientRegistrationOptions
from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings
from pydantic import AnyHttpUrl

from heronintelligence_mcp._analysis_prompts import ANALYSIS_PROMPTS
from heronintelligence_mcp._context import _request_api_key  # noqa: F401 — re-exported for http_app

# Import provider lazily to avoid circular import at module load time.
# http_app.py calls get_oauth_provider() and passes it to FastMCP.
def _build_mcp() -> FastMCP:
    from heronintelligence_mcp.oauth_provider import get_oauth_provider  # noqa: PLC0415

    _base_url = os.environ.get(
        "MCP_BASE_URL", "https://mcp.heron-intelligence.com"
    )
    return FastMCP(
        "Heron Intelligence",
        auth_server_provider=get_oauth_provider(),
        auth=AuthSettings(
            issuer_url=AnyHttpUrl(_base_url),
            resource_server_url=AnyHttpUrl(_base_url),
            client_registration_options=ClientRegistrationOptions(
                enabled=True,
                valid_scopes=["mcp:read", "mcp:write"],
                default_scopes=["mcp:read"],
            ),
        ),
        transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False),
    instructions=(
        "Heron Intelligence provides financial research intelligence based on curated earnings call "
        "transcripts and due diligence interviews.\n\n"
        "Core tools:\n"
        "1. search_company — find the company and get its ID (always start here)\n"
        "2. get_company_overview — check coverage depth before committing to analysis\n"
        "3. get_recent_transcripts — browse transcripts; company_id or company_ids is required\n"
        "4. get_transcript_content — fetch verbatim Q&A for a specific transcript\n\n"
        "Typical workflow:\n"
        "  search_company → get_company_overview → get_recent_transcripts → get_transcript_content\n"
    ),
    )


mcp = _build_mcp()

_API_URL = "https://ubjzp9xp6w.us-west-2.awsapprunner.com"
_API_KEY = os.environ.get("HERON_API_KEY", "")
_TIMEOUT = float(os.environ.get("HERON_TIMEOUT", "120.0"))


def _headers() -> dict[str, str]:
    key = _request_api_key.get("") or _API_KEY
    return {"X-API-KEY": key, "Content-Type": "application/json"}


def _check_config() -> str | None:
    # In HTTP mode the key comes from the URL via ContextVar; env var only needed for stdio mode
    if not (_API_KEY or _request_api_key.get("")):
        return "HERON_API_KEY is not set. Add it to the MCP server environment config."
    return None


class QuotaExceededError(Exception):
    """Raised when the API returns HTTP 429."""


def _quota_error_message(resp: httpx.Response) -> str:
    """Return a human-readable message for 429 quota responses."""
    reset_at = resp.headers.get("X-Quota-Reset", "")
    retry_after = resp.headers.get("Retry-After", "")
    try:
        detail = resp.json().get("detail", "Quota exceeded.")
    except Exception:
        detail = "Quota exceeded."
    msg = f"Heron Intelligence quota limit reached: {detail}"
    if reset_at:
        msg += f" Your quota resets at {reset_at}."
    elif retry_after:
        msg += f" Retry after {retry_after} seconds."
    msg += " Please contact us to upgrade your plan."
    return msg


def _api_error_message(exc: httpx.HTTPStatusError) -> str:
    """Return a clean error message from an HTTP error response."""
    status = exc.response.status_code
    if status >= 500:
        return f"Service error ({status}). Please try again."
    try:
        detail = exc.response.json().get("detail", "")
        if detail:
            first_line = str(detail).split("\n")[0]
            return f"Error {status}: {first_line}"
    except Exception:
        pass
    return f"Error {status}"


def _api_error_payload(exc: httpx.HTTPStatusError) -> dict[str, Any]:
    """Return a structured error payload from an HTTP error response.

    When the backend returns a structured 4xx body — e.g. 422 `unknown_field`
    with `valid_fields`, or 409 `wrong_step` with `expected_steps` and `hint`
    — pass the payload through intact so the caller can act on it (choose the
    canonical field name, orient to the right step, etc.). Flattening to a
    string loses the signal that lets the caller self-correct.
    """
    status = exc.response.status_code
    if status >= 500:
        return {
            "error": f"Service error ({status}). Please try again.",
            "status_code": status,
        }
    try:
        body = exc.response.json()
        detail = body.get("detail")
        if isinstance(detail, dict):
            return {**detail, "status_code": status}
        if detail:
            return {"error": str(detail), "status_code": status}
    except Exception:
        pass
    return {"error": f"Error {status}", "status_code": status}


async def _post(path: str, body: dict) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        resp = await client.post(f"{_API_URL}{path}", json=body, headers=_headers())
        if resp.status_code == 429:
            raise QuotaExceededError(_quota_error_message(resp))
        resp.raise_for_status()
        return resp.json()


async def _get(path: str) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        resp = await client.get(f"{_API_URL}{path}", headers=_headers())
        if resp.status_code == 429:
            raise QuotaExceededError(_quota_error_message(resp))
        resp.raise_for_status()
        return resp.json()


@mcp.tool()
async def search_company(query: str, limit: int = 1) -> str:
    """
    Search the Heron Intelligence catalog and return the single best-matching company.

    Use this FIRST before any other tool — all other tools require the company ID
    this returns.

    Search strategy:
    - Use the exact ticker when you know it (e.g. "NU", "MELI") — faster and unambiguous
    - Use the company name when you're unsure of the ticker (e.g. "Nubank", "MercadoLibre")
    - Descriptions also work (e.g. "Brazilian digital bank") but are less reliable

    Set limit > 1 to get multiple candidates when you're unsure which company is the right one,
    or when you want to compare coverage across similar companies.
    Returns results sorted by similarity score (best match first).

    Args:
        query: Ticker symbol, company name, or description
               (e.g. "Nubank", "NU", "Mexican e-commerce")
        limit: Max number of companies to return (default: 1, max: 10)

    Returns:
        JSON with the best-matched company including enriched metadata:
        {
          "id": "uuid",
          "name": "Nu Holdings Ltd.",
          "ticker": "NU",
          "exchange": "NYSE",
          "is_public": true,
          "official_name": "Nu Holdings Ltd.",
          "description": "...",
          "website": "https://...",
          "sector_name": "Financials",
          "sector_gics_code": "40",
          "industry_name": "Consumer Finance",
          "industry_gics_code": "402020",
          "geography_name": "Brazil",
          "isin": "...",
        }

        IMPORTANT — lineage resolution:
        The tool automatically resolves subsidiaries and legacy names to their current
        root parent. Searching "MetaMap" returns Incode Technologies Inc. (its parent).
        Searching "Facebook" returns Meta Platforms Inc. Transcript coverage includes
        the full corporate family (all subsidiaries) automatically.

        Returns {"error": "..."} if no match is found or the API is unreachable.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post("/api/v1/companies/search", {"query": query, "limit": limit})
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps({"error": f"Heron API returned an error ({exc.response.status_code}). Please try again or contact support."})
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def get_recent_transcripts(
    company_id: str | None = None,
    company_ids: list[str] | None = None,
    quarters: int = 3,
    limit: int = 20,
    offset: int = 0,
    due_diligence_type: str | None = None,
    source_tone: str | None = None,
    call_quality: str | None = None,
    query: str | None = None,
) -> str:
    """
    List metadata for transcripts in the Heron Intelligence library.

    Either company_id or company_ids is REQUIRED — unscoped library searches are not allowed.
    Pass company_ids (list) to pull transcripts from multiple companies in one call.
    Returns METADATA ONLY — use get_transcript_content to read verbatim Q&A.

    Use this to:
    - Browse transcripts for a known company (pass company_id)
    - Pull transcripts from multiple companies at once (pass company_ids list)
    - Paginate large result sets: use offset to retrieve subsequent pages
    - Free-text search: describe what you're looking for in the `query` param

    Key fields returned per transcript:
    - due_diligence_type: type of interview ("MDD" = management DD, "BDD" = business DD)
    - call_quality: transcript reliability signal — "Good", "Fair", "Poor"
    - source_tone: interviewee sentiment — "Positive", "Negative", "Neutral"
    - sentiment: overall sentiment of the transcript
    - call_date: date of the interview or earnings call
    - company_name: name of the company discussed
    - id: pass to get_transcript_content or analyze_red_flags

    Args:
        company_id:          Single company UUID from search_company (REQUIRED unless company_ids is set)
        company_ids:         List of company UUIDs to search across multiple companies at once (REQUIRED unless company_id is set)
        quarters:            Look-back window in quarters (default: 3, always enforced)
        limit:               Max transcripts to return per page (default: 20, max: 1000)
        offset:              Number of results to skip for pagination (default: 0)
        due_diligence_type:  Filter by DD type: "MDD" or "BDD" (optional)
        source_tone:         Filter by tone: "Positive", "Negative", or "Neutral" (optional)
        call_quality:        Filter by quality: "Good", "Fair", or "Poor" (optional)
        query:               Free-text search query to find relevant transcripts (optional)

    Returns:
        JSON object with a "transcripts" list. Each entry:
        {
          "id": "uuid",
          "title": "Senior Executive, Marketing (2015-2023)",
          "company_name": "Meta Platforms, Inc.",
          "call_date": "2026-03-16",
          "due_diligence_type": "MDD",
          "source_tone": "Positive",
          "call_quality": "Good",
          "sentiment": "positive",
          "summary": "AI-driven ad impression growth..."
        }
        Returns {"error": "..."} on failure.
    """
    if not company_id and not company_ids:
        return json.dumps({"error": "company_id or company_ids is required. Use search_company first to get a company UUID."})
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        body: dict[str, Any] = {
            "quarters": quarters,
            "limit": max(1, min(limit, 1000)),
            "offset": max(0, offset),
        }
        if company_id is not None:
            body["company_id"] = company_id
        if company_ids is not None:
            body["company_ids"] = company_ids
        if due_diligence_type is not None:
            body["due_diligence_type"] = due_diligence_type
        if source_tone is not None:
            body["source_tone"] = source_tone
        if call_quality is not None:
            body["call_quality"] = call_quality
        if query is not None:
            body["query"] = query
        data = await _post("/api/v1/transcripts/search", body)
        # Strip internal field from each transcript object
        transcripts = data if isinstance(data, list) else data.get("transcripts", data.get("results", data))
        if isinstance(transcripts, list):
            for t in transcripts:
                t.pop("transcript_type", None)
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps({"error": f"Heron API returned an error ({exc.response.status_code}). Please try again or contact support."})
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def get_company_overview(company_id: str) -> str:
    """
    Get a high-level summary of a company's research coverage in Heron Intelligence.

    Use this after search_company to understand what coverage exists before
    committing to a full analysis. Returns: transcript count, date range covered,
    types of documents available, and a brief coverage quality assessment.

    This is more efficient than get_recent_transcripts when you only need to know
    whether sufficient coverage exists to support a meaningful analysis.

    Args:
        company_id: The company ID returned by search_company

    Returns:
        JSON with coverage summary:
        {
          "company_id": "uuid",
          "company_name": "Meta Platforms, Inc.",
          "ticker": "META",
          "total_transcripts": 8,
          "earliest_date": "2022-08-10",
          "latest_date": "2024-11-12",
          "quarters_available": 8,
          "recommended_quarters": 4
        }
        Returns {"error": "..."} on failure.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        # Fetch company metadata and transcripts in parallel
        import asyncio
        company_task = asyncio.create_task(_get(f"/api/v1/companies/{company_id}"))
        transcripts_task = asyncio.create_task(
            _post("/api/v1/transcripts/search", {"company_id": company_id, "quarters": 40, "limit": 1000})
        )
        company_data_result = await asyncio.gather(company_task, transcripts_task, return_exceptions=True)
        company_meta = company_data_result[0] if not isinstance(company_data_result[0], Exception) else {}
        data = company_data_result[1] if not isinstance(company_data_result[1], Exception) else {}

        transcripts: list[dict] = data if isinstance(data, list) else data.get("transcripts", data.get("results", []))

        if not transcripts:
            return json.dumps(
                {
                    "company_id": company_id,
                    "company_name": company_meta.get("name") or company_meta.get("official_name"),
                    "ticker": company_meta.get("ticker"),
                    "total_transcripts": 0,
                    "earliest_date": None,
                    "latest_date": None,
                    "quarters_available": 0,
                    "recommended_quarters": 0,
                    "by_dd_type": {},
                    "by_transcript_type": {},
                    "by_data_provider": {},
                }
            )

        # Dates — field is call_date in the API response
        dates = sorted(t["call_date"] for t in transcripts if t.get("call_date"))

        # Distinct quarters
        quarters_set: set[str] = set()
        for t in transcripts:
            d = t.get("call_date", "")
            if len(d) >= 7:
                year, month = d[:4], int(d[5:7])
                quarter = (month - 1) // 3 + 1
                quarters_set.add(f"{year}Q{quarter}")

        n_quarters = len(quarters_set)
        recommended = min(n_quarters, 8)

        # Breakdown by DD type (BDD / MDD / null)
        by_dd_type: dict[str, int] = {}
        for t in transcripts:
            key = t.get("due_diligence_type") or "unknown"
            by_dd_type[key] = by_dd_type.get(key, 0) + 1

        # Breakdown by transcript type
        by_transcript_type: dict[str, int] = {}
        for t in transcripts:
            key = t.get("transcript_type") or "unknown"
            by_transcript_type[key] = by_transcript_type.get(key, 0) + 1

        # Breakdown by data provider (human-readable name)
        by_data_provider: dict[str, int] = {}
        for t in transcripts:
            key = t.get("data_provider_name") or "unknown"
            by_data_provider[key] = by_data_provider.get(key, 0) + 1

        summary = {
            "company_id": company_id,
            "company_name": company_meta.get("name") or company_meta.get("official_name"),
            "ticker": company_meta.get("ticker"),
            "total_transcripts": len(transcripts),
            "earliest_date": dates[0] if dates else None,
            "latest_date": dates[-1] if dates else None,
            "quarters_available": n_quarters,
            "recommended_quarters": recommended,
            "by_dd_type": by_dd_type,
            "by_transcript_type": by_transcript_type,
            "by_data_provider": by_data_provider,
        }
        return json.dumps(summary, ensure_ascii=False)

    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps({"error": f"Heron API returned an error ({exc.response.status_code}). Please try again or contact support."})
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def get_transcript_content(transcript_id: str) -> str:
    """
    Retrieve the full verbatim content of a specific transcript.

    The response is an array of Q&A pairs, each with:
    - speaker: name of the person speaking
    - role: their role (e.g. "CEO", "Analyst", "CFO")
    - text: verbatim spoken content

    When to use this vs. analyze_red_flags:
    - Use get_transcript_content for verbatim quotes, close reading, or when you need
      the exact words management used
    - Use analyze_red_flags for high-level risk synthesis across multiple transcripts —
      it is faster and does not consume your token budget on raw text

    WARNING: Transcripts can be large (10,000+ tokens). Avoid fetching multiple
    transcripts in a single response unless necessary. Use get_recent_transcripts
    to identify the most relevant transcript first.

    Args:
        transcript_id: The UUID of the transcript (from get_recent_transcripts or
                       a citation in analyze_red_flags output)

    Returns:
        JSON with full transcript payload. Key metadata fields include:
        - data_provider_name: human-readable source name (e.g. "Heron AI", "Blue Heron")
        The Q&A content is in a "content" array:
        [
          {"speaker": "David Vélez", "role": "CEO", "text": "We saw record..."},
          {"speaker": "James Friedman", "role": "Analyst", "text": "Can you clarify..."},
          ...
        ]
        Returns {"error": "..."} on failure or {"found": false} if ID is not found.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _get(f"/api/v1/transcripts/{transcript_id}")
        if isinstance(data, dict):
            data.pop("transcript_type", None)
            data.pop("is_primary", None)
            data.pop("data_provider_id", None)
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            return json.dumps({"found": False, "message": f"No transcript found: '{transcript_id}'"})
        return json.dumps({"error": _api_error_message(exc)})
    except Exception as exc:
        return json.dumps({"error": str(exc)})


# ============================================================
# Research Projects MCP Flow (Steps 1–4)
# ============================================================

@mcp.tool()
async def start_research_project() -> str:
    """
    Start a new Research Project intake flow.

    Call this ONCE at the very beginning, before any research conversation.
    It creates a new project record in Heron Intelligence and returns a project_id
    that you MUST pass to all subsequent research project tools.

    Workflow:
      start_research_project()
        → define_research_brief(project_id, ...)              [Step 1, per turn]
        → prepopulate_research_configuration(project_id)      [ONCE at Step 1→2]
        → configure_research_project(project_id, ...)         [Step 2, per turn]
        → generate_research_questions(project_id, ...)        [Step 3]
        → submit_research_project(project_id, ...)            [Step 4]

      At any point: get_project_status(project_id) to re-orient when a user
      message does not match the active step, or after a 409/422 response.

    Returns:
        JSON with { "project_id": "uuid" }
        or { "error": "..." } on failure.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post("/api/v1/intake/start-project", {})
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def define_research_brief(
    project_id: str,
    user_message: str,
    chat_history: list[dict],
    current_artifact: dict | None = None,
    last_follow_up: str | None = None,
) -> str:
    """
    Step 1 (Scope) — Process one turn of the research brief conversation.

    Call this on EVERY user turn during Step 1 to build the Research Brief artifact
    conversationally. The tool calls the AI, saves the conversation to the database,
    and returns an updated structured artifact.

    DISPLAY RULES — after every call you MUST:
    1. Render the full Research Brief artifact (all 5 elements, even if empty):
       - Research Objective
       - Primary Use
       - Scope (type + context)
       - Desired Insight
       - Preferred Experts
    2. Show the readiness assessment (overall + per element: Low / Medium / High)
    3. Ask the suggested_follow_up question
    4. End EVERY response with these three options:
       Option 1: Answer the follow-up question to keep refining the brief
       Option 2: Continue to project configuration with what has been captured so far
       Option 3: Send it to a Heron Intelligence representative who can help from here

    AUTO-CHAIN: When the user chooses Option 2, call configure_research_project immediately.
    HANDOFF: When the user chooses Option 3, call submit_research_project with submission_type="bh_review_only".

    WHEN NOT TO CALL THIS:
      - The project has already moved past Step 1 (current_step is setup, questions,
        or submitted). The backend will return 409 `wrong_step` — do not retry blindly.
        Call get_project_status(project_id) to orient, then use the tool named in the
        error hint.
      - You are unsure whether the project is in Step 1. Call get_project_status first.

    ERROR HANDLING: on 4xx responses the backend returns a structured JSON payload
    with `status_code`, `error`, and tool-specific fields (e.g. `expected_steps`,
    `hint`, `current_step`). Read those fields and act accordingly.

    Args:
        project_id:       The project_id returned by start_research_project
        user_message:     The user's latest message
        chat_history:     Full conversation so far as [{role, content}, ...]
        current_artifact: The artifact returned by the previous call (None on first turn)
        last_follow_up:   The follow_up_question from the previous call (None on first turn)

    Returns:
        JSON with:
        {
          "project_id": "uuid",
          "artifact": { research_objective, primary_use, scope, desired_insight, preferred_experts },
          "global_readiness": "Low | Medium | High",
          "element_readiness": { objective, use, scope, insight, experts },
          "follow_up_question": "string",
          "next_action": "continue_conversation"
        }
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        body: dict[str, Any] = {
            "project_id": project_id,
            "user_message": user_message,
            "chat_history": chat_history,
        }
        if current_artifact is not None:
            body["current_artifact"] = current_artifact
        if last_follow_up is not None:
            body["last_follow_up"] = last_follow_up
        data = await _post("/api/v1/intake/research-brief", body)
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def configure_research_project(
    project_id: str,
    user_message: str,
    chat_history: list[dict],
    force_next_step: bool = False,
) -> str:
    """
    Step 2 (Setup) — Process one turn of the conversational project configuration.

    Call this on EVERY user turn during Step 2. You pass the user's raw message
    and the backend AI extracts the relevant canonical Step 2 fields, persists
    them, and returns the next follow-up question.

    YOU DO NOT NAME FIELDS. The backend owns the Step 2 field vocabulary — your
    only job is to forward the user's message and the running Step 2 chat
    history. Never try to pre-parse the user's words into a schema; that is
    exactly the failure mode this tool is designed to avoid.

    AFTER EVERY SUCCESSFUL CALL:
    1. Show a running summary of the configuration captured so far
       (`configuration_summary` in the response).
    2. If `off_topic` is true, the user's message did not address Step 2
       (e.g. they were still refining the brief). Show the returned
       `follow_up_question` as a clarifying question and do NOT add anything
       to the configuration summary on this turn.
    3. Otherwise, ask the `follow_up_question` verbatim.
    4. End every response with these three options:
       Option 1: Answer the next question to keep filling in the configuration
       Option 2: Continue to topics and questions with what has been captured so far
       Option 3: Send it to a Heron Intelligence representative who can help from here

    AUTO-CHAIN: When `next_action` is "invoke_generate_research_questions",
    immediately call generate_research_questions(project_id, action="generate_all").

    HANDOFF: When the user chooses Option 3, call submit_research_project with
    submission_type="partial_step2".

    ERROR HANDLING — on 4xx responses the backend returns a structured JSON
    payload with `status_code`, `error`, and actionable fields:
      - 409 `wrong_step` → the project is not in Step 2. Read `hint` and
        call the tool named there, or call get_project_status(project_id).
      - 404 `project_not_found` → bad project_id.

    WHEN NOT TO CALL THIS:
      - The user is still refining the Research Brief (Step 1) — call
        define_research_brief instead.
      - The user is curating topics or questions — call generate_research_questions.
      - You are unsure which step is active — call get_project_status first.

    Args:
        project_id:      The project_id from start_research_project.
        user_message:    The user's latest message — forwarded as-is.
        chat_history:    Step 2 conversation so far as [{role, content}, ...].
                         Do NOT include Step 1 messages — the brief artifact
                         is already available to the extractor.
        force_next_step: Set True only when the user explicitly chose to move
                         to Step 3 with the fields captured so far.

    Returns:
        JSON with:
        {
          "project_id": "uuid",
          "configuration_summary": { all fields collected },
          "missing_required_fields": [list],
          "next_question_group": { "name": "...", "fields": [...], "prompt": "..." },
          "next_action": "continue_collecting | invoke_generate_research_questions",
          "mentioned_fields": [ list of canonical fields updated this turn ],
          "off_topic": true | false,
          "follow_up_question": "string — ask this next, verbatim"
        }
        On error, JSON with status_code + the structured fields described above.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post("/api/v1/intake/configure-project", {
            "project_id": project_id,
            "user_message": user_message,
            "chat_history": chat_history,
            "force_next_step": force_next_step,
        })
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def generate_research_questions(
    project_id: str,
    action: str = "generate_all",
    existing_items: dict | None = None,
    target_item_id: str | None = None,
) -> str:
    """
    Step 3 (Topics & Questions) — Generate, curate, and manage research topics and questions.

    On first call use action="generate_all". The AI generates topics and questions from
    the Research Brief and project configuration. The user then curates the list.

    CURATION ACTIONS — handle these conversationally:
      "Add all" / "Keep these"  → move all proposed items to confirmed list (update existing_items)
      "Add #N"                  → move item N to confirmed list
      "Replace #N"              → call again with action="regenerate_single", target_item_id=item_id
      "Regenerate all"          → call again with action="regenerate_all"
      "Add my own: [text]"      → add directly to user_added_topics or user_added_questions
      "Remove #N"               → remove from confirmed list

    15-ITEM CAP: total_items must not exceed 15. Warn the user when remaining_slots ≤ 3.
    Never add items when remaining_slots == 0.

    DISPLAY RULES — after every call you MUST:
    1. Show the full confirmed items list and running count (X of 15)
    2. Show any proposed items awaiting review
    3. End EVERY response with these three options:
       Option 1: Continue curating — add, remove, or replace items
       Option 2: Continue to submission with what has been confirmed so far
       Option 3: Send it to a Heron Intelligence representative who can help from here

    AUTO-CHAIN: When next_action is "invoke_submit_research_project", show the user a
    pre-submission summary and ask for confirmation, THEN call submit_research_project.

    HANDOFF: When the user chooses Option 3, call submit_research_project with
    submission_type="partial_step3".

    WHEN NOT TO CALL THIS:
      - Required Step 2 configuration fields are not yet captured. Call
        configure_research_project or get_project_status first — the backend
        will return 409 `wrong_step` if you try to generate too early.
      - The project has already been submitted. The backend will reject the call.

    ERROR HANDLING: on 4xx responses the backend returns a structured JSON payload
    with `status_code`, `error`, and tool-specific fields (e.g. `expected_steps`,
    `hint`). Read those fields and act accordingly — do not retry blindly.

    Args:
        project_id:     The project_id from start_research_project
        action:         "generate_all" | "regenerate_all" | "regenerate_single"
        existing_items: Current item state dict with keys:
                          user_added_topics, user_added_questions,
                          item_type (for regenerate_single),
                          item_to_replace (for regenerate_single)
        target_item_id: ID of the item to replace (for regenerate_single)

    Returns:
        JSON with:
        {
          "system_proposed_topics": [...],
          "system_proposed_questions": [...],
          "user_added_topics": [...],
          "user_added_questions": [...],
          "total_items": N,
          "next_action": "continue_curating | invoke_submit_research_project"
        }
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        body: dict[str, Any] = {
            "project_id": project_id,
            "action": action,
        }
        if existing_items is not None:
            body["existing_items"] = existing_items
        if target_item_id is not None:
            body["target_item_id"] = target_item_id
        data = await _post("/api/v1/intake/topics-questions", body)
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def submit_research_project(
    project_id: str,
    submission_type: str,
    research_brief: dict | None = None,
    configuration: dict | None = None,
    confirmed_items: list | None = None,
) -> str:
    """
    Step 4 — Submit the research project to a Blue Heron representative.

    PRE-SUBMISSION CONFIRMATION REQUIRED: Before calling this tool, you MUST show
    the user a summary of everything that will be submitted and ask for explicit
    confirmation. Only call this tool after the user confirms.

    Summary content by submission_type:
      "full"           → full brief + configuration + confirmed topics/questions
      "bh_review_only" → Research Brief only (from Step 1)
      "partial_step2"  → Research Brief + configuration collected so far
      "partial_step3"  → Research Brief + configuration + confirmed items so far

    RETURN PATH ON DECLINE: If the user reviews the summary and decides not to submit,
    return them to exactly where they left off:
      "full"           → return to Step 3 (keep curating)
      "bh_review_only" → return to Step 1 (keep refining brief)
      "partial_step2"  → return to Step 2 (keep filling configuration)
      "partial_step3"  → return to Step 3 (keep curating items)
    No data is lost on any decline path.

    WHEN NOT TO CALL THIS:
      - The project has already been submitted (current_step="submitted"). The
        backend will return 409 `wrong_step`.
      - The user has not confirmed. Show the summary and wait for explicit
        confirmation first.

    Args:
        project_id:      The project_id from start_research_project
        submission_type: "full" | "bh_review_only" | "partial_step2" | "partial_step3"
        research_brief:  Final brief artifact (for context / display)
        configuration:   Final configuration (for context / display)
        confirmed_items: Final confirmed topics/questions (for context / display)

    Returns:
        JSON with:
        {
          "confirmation_number": "uuid",
          "submitted_at": "ISO timestamp",
          "message": "Your research project has been submitted..."
        }
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post("/api/v1/intake/submit-project", {
            "project_id": project_id,
            "submission_type": submission_type,
        })
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def get_project_status(project_id: str) -> str:
    """
    Read-only snapshot of a Research Project's current flow state.

    Call this whenever you are unsure which step the project is on, the user's
    message does not match the active tool's contract, or you need to recover
    from a 409 `wrong_step` error. The response tells you exactly which tool
    to call next.

    This tool does not change any state — it is safe to call at any time.

    WHEN TO CALL THIS:
      - The user just sent a message and you are not sure which step it
        belongs to.
      - A previous call returned 409 or 422 and you need to re-orient.
      - The user asks "where are we in the flow?" / "what's left?".

    Args:
        project_id: The project_id from start_research_project.

    Returns:
        JSON with:
        {
          "project_id": "uuid",
          "current_step": "scope | setup | questions | submitted",
          "status": "submitted | null",
          "completed_fields": ["list of Step 2 fields already captured"],
          "missing_fields": ["Step 2 fields still required"],
          "last_artifact": { research brief artifact },
          "global_readiness": "Low | Medium | High | null",
          "element_readiness": { per-element readiness scores },
          "last_follow_up": "the last follow-up question asked, or null"
        }
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _get(f"/api/v1/intake/project-status/{project_id}")
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"error": str(exc)})


@mcp.tool()
async def prepopulate_research_configuration(project_id: str) -> str:
    """
    One-shot Step 1 → Step 2 transition helper.

    Call this ONCE, right before the first call to configure_research_project,
    so any configuration fields the user already mentioned during the brief
    (companies, executives, geographies, source types, etc.) are pre-filled
    without re-asking.

    The backend reads the Research Brief artifact + conversation history,
    asks the AI to infer pre-populatable fields, and merges them into the
    project's configuration. The returned `prepopulated_fields` list tells
    you what was filled so you can surface it to the user for confirmation.

    WHEN TO CALL THIS:
      - After Step 1 is complete and the user chose to continue to Step 2
        (Option 2 in define_research_brief).

    WHEN NOT TO CALL THIS:
      - More than once per project — subsequent calls will re-run extraction
        unnecessarily.
      - Before the user has added meaningful content to the brief.
      - After the project is already deep into Step 2 (current_step="questions"
        or "submitted"). The backend returns 409 `wrong_step`.

    Args:
        project_id: The project_id from start_research_project.

    Returns:
        JSON with:
        {
          "project_id": "uuid",
          "prepopulated_fields": ["list of canonical field names filled"],
          "configuration_summary": { merged configuration },
          "missing_required_fields": [...],
          "next_question_group": { ... },
          "next_action": "continue_collecting | invoke_generate_research_questions",
          "note": "optional message when nothing could be pre-populated"
        }
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post(
            "/api/v1/intake/prepopulate-setup", {"project_id": project_id}
        )
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"error": str(exc)})


# @mcp.tool()  # DISABLED — service turned off; logic preserved
async def analyze_red_flags(company: str, quarters: int = 3) -> str:
    """
    Flagship analysis tool. Runs a deep, structured risk analysis for a company using
    Heron Intelligence's ReAct agent, powered by curated transcripts and due diligence
    interviews.

    This tool automatically searches for the company, retrieves and cross-references
    multiple transcripts across the requested time window, and produces a structured
    risk report with source citations. Prefer this over manually chaining
    get_transcript_content calls for risk analysis.

    Args:
        company: Company name or ticker (e.g. "Rappi", "MELI", "Nubank")
        quarters: How many past quarters to analyze (default: 3, max recommended: 8)

    Returns:
        Structured markdown analysis covering red flags by category, key quotes,
        positive signals, and an overall risk rating with citations. Returns a
        formatted error message (starting with "## Error") if analysis cannot be run.
    """
    err = _check_config()
    if err:
        return f"## Error\n\n{err}"
    try:
        prompt = (
            f"Perform a comprehensive red flag analysis for **{company}** "
            f"covering the last {quarters} quarters.\n\n"
            "Instructions:\n"
            "- Cross-reference ALL available transcripts in the window, not just the most recent one. "
            "Note when signals appear consistently across multiple periods.\n"
            "- Pay close attention to management language: flag evasive answers, hedging that "
            "increases over time, sudden changes in tone between quarters, or topics that are "
            "consistently avoided.\n"
            "- Identify discrepancies between stated strategy and actual results — e.g. guidance "
            "misses, pivots that contradict prior commitments, or KPIs that are quietly redefined.\n"
            "- Where data allows, compare the company's trajectory against sector peers or macro "
            "context (e.g. rising rates, FX pressure, regulatory shifts in its market).\n\n"
            "Structure your response as follows:\n"
            "1. **Executive Summary** — 2-3 sentence overview of the risk profile\n"
            "2. **Red Flags** — organized by category (Operational, Financial, Management, "
            "Competitive, Macro). For each flag: description, severity (high/medium/low), "
            "trend (improving/worsening/stable), and source citations\n"
            "3. **Positive Signals** — counter-evidence or strengths worth noting\n"
            "4. **Overall Risk Assessment** — high / medium / low with rationale\n"
            "5. **Key Quotes** — 3-5 verbatim quotes from transcripts that best capture the "
            "risk sentiment or management posture. Format each as:\n"
            '   > "Quote text here."\n'
            "   — Speaker Name, Role, [Document Type: title](ID), Date\n\n"
            "Include [Document Type: title](ID) citations for every factual claim. "
            "If no transcripts are found for this company, clearly state that."
        )
        data = await _post("/api/v1/agents/aura/query", {"query": prompt})
        return data.get("response", json.dumps(data, ensure_ascii=False))
    except QuotaExceededError as exc:
        return f"## Error: Quota Exceeded\n\n{str(exc)}"
    except httpx.HTTPStatusError as exc:
        return f"## Error\n\n{_api_error_message(exc)}"
    except Exception as exc:
        return f"## Error\n\nAnalysis could not be completed: {str(exc)}"


async def _run_deep_analysis(analysis_key: str, company: str, quarters: int) -> str:
    """Shared execution logic for all deep-dive analysis tools."""
    err = _check_config()
    if err:
        return f"## Error\n\n{err}"
    prompt = ANALYSIS_PROMPTS[analysis_key]["prompt"].format(company=company, quarters=quarters)
    try:
        data = await _post("/api/v1/agents/aura/query", {"query": prompt})
        return data.get("response", json.dumps(data, ensure_ascii=False))
    except QuotaExceededError as exc:
        return f"## Error: Quota Exceeded\n\n{str(exc)}"
    except httpx.HTTPStatusError as exc:
        return f"## Error\n\n{_api_error_message(exc)}"
    except Exception as exc:
        return f"## Error\n\nAnalysis could not be completed: {str(exc)}"


# @mcp.tool()  # DISABLED — service turned off; logic preserved
async def analyze_orientation(company: str, quarters: int = 6) -> str:
    """
    Run a full orientation & company overview analysis for a company.

    Use this when the user asks for: company overview, orientation, "what does X do",
    investor briefing, value chain, or an introduction to a company.

    Produces a 5-section investment-grade report:
    1. Investor framing — non-technical and sector-specialist versions with key differences called out
    2. Value chain map — before/after transformation table showing the core problem solved
    3. Content inventory — transcript count, year distribution, top 10 topics by frequency
    4. Interviewee profiles — role, perspective, credibility rating per source
    5. One-page executive briefing — 300-word synthesis for meeting prep

    Args:
        company: Company name or ticker (e.g. "Meta", "Nubank", "MELI")
        quarters: How many past quarters of transcripts to analyze (default: 6)

    Returns:
        Structured markdown report with tables, inventories, and source citations.
        Returns a formatted error message (starting with "## Error") if analysis cannot be run.
    """
    return await _run_deep_analysis("orientation", company, quarters)


# @mcp.tool()  # DISABLED — service turned off; logic preserved
async def analyze_competitive(company: str, quarters: int = 6) -> str:
    """
    Run a comprehensive competitive landscape analysis for a company.

    Use this when the user asks for: competitive analysis, competitors, market position,
    competitive intelligence, how X compares to rivals, market share, or competitive threats.

    Produces a 5-section investment-grade report:
    1. Competitor map — tiered table classifying direct competitors, adjacent threats, future entrants
    2. Head-to-head comparison matrix — top 3–5 competitors rated across 6 dimensions with winner signals
    3. Competitive momentum — timeline of share gains/losses with direct quotes vs. inferred signals
    4. Emerging threat matrix — non-obvious threats (AI, adjacent markets) with severity and time horizon
    5. Competitive durability score — 1–10 rating with explanation of what moves the score ±2 points

    Args:
        company: Company name or ticker (e.g. "Meta", "Nubank", "MELI")
        quarters: How many past quarters of transcripts to analyze (default: 6)

    Returns:
        Structured markdown report with tables, matrices, and source citations.
        Returns a formatted error message (starting with "## Error") if analysis cannot be run.
    """
    return await _run_deep_analysis("competitive", company, quarters)


# @mcp.tool()  # DISABLED — service turned off; logic preserved
async def analyze_product(company: str, quarters: int = 6) -> str:
    """
    Run a deep product & service quality assessment for a company.

    Use this when the user asks for: product analysis, product quality, feature review,
    strengths and weaknesses, product-market fit, customer feedback on product, or PMF.

    Produces a 5-section investment-grade report:
    1. Strengths vs. weaknesses — top 5 of each ranked by mention frequency and buying impact
    2. Sentiment clustering — patterns in praise and criticism by product area and customer segment
    3. Comparative quality scorecard — 6–8 dimensions rated 1–5 vs. top 2 competitors
    4. Improvement prioritization matrix — top 3 gaps by urgency and difficulty to fix
    5. Product-market fit health score — 1–10 with investment thesis (moat / parity / liability)

    Args:
        company: Company name or ticker (e.g. "Meta", "Nubank", "MELI")
        quarters: How many past quarters of transcripts to analyze (default: 6)

    Returns:
        Structured markdown report with tables, scorecards, and source citations.
        Returns a formatted error message (starting with "## Error") if analysis cannot be run.
    """
    return await _run_deep_analysis("product", company, quarters)


# @mcp.tool()  # DISABLED — service turned off; logic preserved
async def analyze_management(company: str, quarters: int = 6) -> str:
    """
    Run a thorough management & leadership evaluation for a company.

    Use this when the user asks for: management analysis, leadership assessment, CEO evaluation,
    governance review, executive team quality, culture, red flags, or strategic vision.

    Produces a 6-section investment-grade report:
    1. Leadership scorecard — perceived strengths, weaknesses, key decisions, and trajectory per executive
    2. Organizational culture assessment — 5 dimensions rated 1–10 (morale, retention, innovation, etc.)
    3. Red flag register — all concerns classified by confidence level with governance risk score
    4. Strategic vision assessment — top 3 bets with expert consensus (smart / risky / misguided)
    5. CEO spotlight — 360° assessment with Leadership Alpha Score (1–10)
    6. Management quality summary — composite score and the one thing that would change the assessment

    Args:
        company: Company name or ticker (e.g. "Meta", "Nubank", "MELI")
        quarters: How many past quarters of transcripts to analyze (default: 6)

    Returns:
        Structured markdown report with scorecards, risk register, and source citations.
        Returns a formatted error message (starting with "## Error") if analysis cannot be run.
    """
    return await _run_deep_analysis("management", company, quarters)


# @mcp.tool()  # DISABLED — service turned off; logic preserved
async def analyze_customer(company: str, quarters: int = 6) -> str:
    """
    Run a customer & retention dynamics analysis for a company.

    Use this when the user asks for: customer analysis, retention, churn, NPS, customer health,
    buyer journey, onboarding, land-and-expand, or customer lifetime value.

    Produces a 6-section investment-grade report:
    1. Acquisition — buyer journey funnel with conversion drivers at each stage
    2. Onboarding & value realization — implementation timeline and ROI/payback signals
    3. Stickiness scorecard — 7 retention drivers rated 1–5 (integration depth, switching cost, etc.)
    4. Churn risk matrix — top 3 risk factors with severity and early warning signals
    5. Expansion motion — evidence of land-and-expand with cross-sell/upsell signals
    6. Customer health index — composite score across acquisition, retention, churn, and expansion

    Args:
        company: Company name or ticker (e.g. "Meta", "Nubank", "MELI")
        quarters: How many past quarters of transcripts to analyze (default: 6)

    Returns:
        Structured markdown report with scorecards, funnels, and source citations.
        Returns a formatted error message (starting with "## Error") if analysis cannot be run.
    """
    return await _run_deep_analysis("customer", company, quarters)


# @mcp.tool()  # DISABLED — service turned off; logic preserved
async def analyze_pricing(company: str, quarters: int = 6) -> str:
    """
    Run a pricing & revenue model analysis for a company.

    Use this when the user asks for: pricing analysis, revenue model, monetization strategy,
    pricing power, total cost of ownership (TCO), contract structure, or revenue quality.

    Produces a 5-section investment-grade report:
    1. Pricing architecture — tier/package table with inclusions, price signals, and flexibility
    2. Competitive pricing position — TCO comparison table vs. top 2–3 competitors
    3. Value-to-price ratio — how the company justifies pricing, with customer ROI signals (1–10)
    4. Revenue model resilience — recurring mix, pricing power, and downturn behavior
    5. Revenue quality score — 1–10 across predictability, pricing power, expansion potential, defensibility

    Args:
        company: Company name or ticker (e.g. "Meta", "Nubank", "MELI")
        quarters: How many past quarters of transcripts to analyze (default: 6)

    Returns:
        Structured markdown report with comparison tables and source citations.
        Returns a formatted error message (starting with "## Error") if analysis cannot be run.
    """
    return await _run_deep_analysis("pricing", company, quarters)


# @mcp.tool()  # DISABLED — service turned off; logic preserved
async def analyze_growth(company: str, quarters: int = 6) -> str:
    """
    Run a growth, market & TAM analysis for a company.

    Use this when the user asks for: growth analysis, market sizing, TAM, expansion strategy,
    market share trajectory, growth quality, bull/base/bear scenario, or market opportunity.

    Produces a 5-section investment-grade report:
    1. Market sizing — segment map with growth rates and company positioning
    2. Company growth trajectory — growth engines rated on sustainability (cyclical vs. structural)
    3. Expansion vectors — geographies, segments, and M&A mapped by attractiveness and readiness
    4. Growth risk — scenario analysis table (bull / base / bear) with assumptions and primary risks
    5. Growth quality score — 1–10 across TAM tailwinds, momentum, optionality, and downside resilience

    Args:
        company: Company name or ticker (e.g. "Meta", "Nubank", "MELI")
        quarters: How many past quarters of transcripts to analyze (default: 6)

    Returns:
        Structured markdown report with scenario tables and source citations.
        Returns a formatted error message (starting with "## Error") if analysis cannot be run.
    """
    return await _run_deep_analysis("growth", company, quarters)


# @mcp.tool()  # DISABLED — service turned off; logic preserved
async def analyze_risk(company: str, quarters: int = 6) -> str:
    """
    Run a comprehensive risk & resilience assessment for a company.

    Use this when the user asks for: risk analysis, risk assessment, resilience, downside,
    investment risk, regulatory risk, AI disruption risk, recession sensitivity, or portfolio risk.

    Produces a 6-section investment-grade report suitable for investment committee use:
    1. Business risk inventory — heatmap by category (competitive / operational / regulatory / macro)
    2. Cyclicality stress test — revenue sensitivity under mild / moderate / severe recession
    3. Growth deceleration triggers — top 5 triggers with probability, control, and early warning signals
    4. AI disruption assessment — net AI impact rating with detailed explanation
    5. Regulatory & legal exposure — compliance posture and pending risks from transcripts
    6. Portfolio risk score — 1–10 (1=fortress, 10=fragile) plus the key unanswered investor question

    Args:
        company: Company name or ticker (e.g. "Meta", "Nubank", "MELI")
        quarters: How many past quarters of transcripts to analyze (default: 6)

    Returns:
        Structured markdown report with risk heatmaps and source citations.
        Returns a formatted error message (starting with "## Error") if analysis cannot be run.
    """
    return await _run_deep_analysis("risk", company, quarters)


# @mcp.tool()  # DISABLED — service turned off; logic preserved
async def analyze_operations(company: str, quarters: int = 6) -> str:
    """
    Run an operational deep-dive analysis for a company.

    Use this when the user asks for: operations analysis, operating leverage, M&A activity,
    organizational capacity, hidden growth segments, geographic concentration, or talent signals.

    Produces a 6-section investment-grade report:
    1. Operating leverage — cost structure scenario (if revenue 2x, what happens to costs?)
    2. M&A & consolidation — acquisition history, strategic logic, execution quality (1–10)
    3. Hidden growth segments — emerging segments with % revenue today vs. 3-year forecast
    4. Geographic concentration risk — revenue mix by geography with risk flags
    5. Talent & organizational capacity — turnover, hiring, bench strength rated 1–10
    6. Operational quality score — 1–10 composite across all five dimensions

    Args:
        company: Company name or ticker (e.g. "Meta", "Nubank", "MELI")
        quarters: How many past quarters of transcripts to analyze (default: 6)

    Returns:
        Structured markdown report with scenario tables and source citations.
        Returns a formatted error message (starting with "## Error") if analysis cannot be run.
    """
    return await _run_deep_analysis("operations", company, quarters)
