"""Consent page for the DCR /authorize flow.

Claude org installations register a single shared DCR client_id via RFC 7591.
That client_id is not user-specific, so the MCP cannot resolve identity from
it alone, and Claude's current desktop/org surface does not forward a
login_hint either. To bridge the gap without requiring Claude changes, this
module renders a minimal HTML form at /authorize that asks the end user to
present their *own* OAuth credentials — a per-user (client_id, client_secret)
pair that ops provisioned in Sauron and stored in mcp_clients. Validated
submissions redirect back to Claude's callback with a fresh auth code bound
to the user's mcp_client row.

Exposed via two handlers used by DualAuthMiddleware:
  - render_consent_form(request)  — GET /authorize with DCR client
  - handle_consent_submit(request) — POST /authorize/consent
"""
from __future__ import annotations

import html
import logging
from typing import Optional
from urllib.parse import urlencode

from starlette.requests import Request
from starlette.responses import HTMLResponse, RedirectResponse, Response

from heronintelligence_mcp.oauth_provider import issue_auth_code
from heronintelligence_mcp.oauth_storage_client import get_storage_client

logger = logging.getLogger("heronintelligence_mcp.consent_page")


# The OAuth params we need to preserve through the consent form round-trip.
_PRESERVED_PARAMS = (
    "response_type",
    "client_id",
    "redirect_uri",
    "code_challenge",
    "code_challenge_method",
    "state",
    "scope",
    "resource",
)


async def render_consent_form(request: Request) -> Optional[Response]:
    """Render the consent HTML form if this /authorize call needs it.

    Returns None when the request is either not a DCR authorize (let FastMCP
    handle it normally) or is malformed in a way better surfaced by FastMCP.
    """
    client_id = request.query_params.get("client_id", "")
    if not client_id:
        return None

    storage = get_storage_client()
    view = await storage.get_client(client_id)
    if not view or view.status != "active":
        return None  # FastMCP will surface the invalid_client error
    if view.source != "dcr":
        return None  # manual clients auto-approve; skip consent

    preserved = {
        name: request.query_params.get(name, "")
        for name in _PRESERVED_PARAMS
    }
    return HTMLResponse(_render_html(preserved, error=None))


async def handle_consent_submit(request: Request) -> Response:
    """Validate the posted (client_id, client_secret) and redirect with code."""
    form = await request.form()
    preserved = {name: str(form.get(name, "")) for name in _PRESERVED_PARAMS}
    user_client_id = str(form.get("user_client_id", "")).strip()
    user_client_secret = str(form.get("user_client_secret", "")).strip()

    required = (
        preserved["client_id"],
        preserved["redirect_uri"],
        preserved["code_challenge"],
        user_client_id,
        user_client_secret,
    )
    if not all(required):
        return HTMLResponse(
            _render_html(preserved, error="All fields are required."),
            status_code=400,
        )

    storage = get_storage_client()

    # The DCR session Claude opened — sanity check it still exists.
    dcr_view = await storage.get_client(preserved["client_id"])
    if not dcr_view or dcr_view.source != "dcr" or dcr_view.status != "active":
        return HTMLResponse(
            _render_html(preserved, error="This authorization session is no longer valid."),
            status_code=400,
        )

    # The user-submitted credentials must resolve to an active manual client
    # row with a bound mcp_clients identity.
    user_view = await storage.get_client(user_client_id)
    if (
        not user_view
        or user_view.source != "manual"
        or user_view.status != "active"
        or not user_view.mcp_client_id
    ):
        logger.info("consent_rejected reason=unknown_client client_id=%s", user_client_id)
        return HTMLResponse(
            _render_html(preserved, error="Invalid client ID or client secret."),
            status_code=401,
        )

    secret_ok = await storage.verify_client_secret(user_client_id, user_client_secret)
    if not secret_ok:
        logger.info("consent_rejected reason=bad_secret client_id=%s", user_client_id)
        return HTMLResponse(
            _render_html(preserved, error="Invalid client ID or client secret."),
            status_code=401,
        )

    scopes = preserved["scope"].split() if preserved["scope"] else []
    code = await issue_auth_code(
        oauth_client_id=preserved["client_id"],  # the DCR session Claude will present at /token
        mcp_client_id=user_view.mcp_client_id,
        consumption_user_id=user_view.consumption_user_id,
        redirect_uri=preserved["redirect_uri"],
        code_challenge=preserved["code_challenge"],
        scopes=scopes,
        resource=preserved["resource"] or None,
        state=preserved["state"] or None,
    )

    query = {"code": code}
    if preserved["state"]:
        query["state"] = preserved["state"]
    sep = "&" if "?" in preserved["redirect_uri"] else "?"
    location = f"{preserved['redirect_uri']}{sep}{urlencode(query)}"
    logger.info(
        "consent_approved dcr_client_id=%s mcp_client_id=%s",
        preserved["client_id"],
        user_view.mcp_client_id,
    )
    return RedirectResponse(location, status_code=302)


def _render_html(params: dict, error: Optional[str]) -> str:
    def esc(name: str) -> str:
        return html.escape(params.get(name, "") or "", quote=True)

    error_block = (
        f'<div class="error">{html.escape(error)}</div>' if error else ""
    )
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Connect Heron Intelligence</title>
  <style>
    :root {{ color-scheme: light dark; }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: #0f172a;
      color: #f8fafc;
      margin: 0;
      display: flex;
      min-height: 100vh;
      align-items: center;
      justify-content: center;
    }}
    .card {{
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 12px;
      padding: 32px;
      width: 100%;
      max-width: 420px;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.35);
    }}
    h1 {{ margin: 0 0 4px; font-size: 20px; }}
    p.sub {{ margin: 0 0 24px; color: #94a3b8; font-size: 14px; }}
    label {{ display: block; font-size: 13px; margin-top: 16px; color: #cbd5e1; }}
    input[type="text"], input[type="password"] {{
      width: 100%;
      box-sizing: border-box;
      margin-top: 6px;
      padding: 10px 12px;
      border-radius: 8px;
      border: 1px solid #475569;
      background: #0f172a;
      color: #f8fafc;
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
      font-size: 13px;
    }}
    button {{
      width: 100%;
      margin-top: 24px;
      padding: 12px;
      border-radius: 8px;
      border: 0;
      background: #6366f1;
      color: white;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
    }}
    button:hover {{ background: #4f46e5; }}
    .error {{
      background: #7f1d1d;
      color: #fecaca;
      padding: 10px 12px;
      border-radius: 8px;
      font-size: 13px;
      margin-bottom: 16px;
    }}
    .hint {{ margin-top: 20px; font-size: 12px; color: #64748b; text-align: center; }}
  </style>
</head>
<body>
  <form class="card" method="POST" action="/authorize/consent">
    <h1>Connect to Heron Intelligence</h1>
    <p class="sub">Enter the credentials issued to you to authorize Claude.</p>
    {error_block}
    <input type="hidden" name="response_type" value="{esc('response_type')}" />
    <input type="hidden" name="client_id" value="{esc('client_id')}" />
    <input type="hidden" name="redirect_uri" value="{esc('redirect_uri')}" />
    <input type="hidden" name="code_challenge" value="{esc('code_challenge')}" />
    <input type="hidden" name="code_challenge_method" value="{esc('code_challenge_method')}" />
    <input type="hidden" name="state" value="{esc('state')}" />
    <input type="hidden" name="scope" value="{esc('scope')}" />
    <input type="hidden" name="resource" value="{esc('resource')}" />

    <label for="user_client_id">Client ID</label>
    <input type="text" id="user_client_id" name="user_client_id"
           autocomplete="off" spellcheck="false" required placeholder="hc-..." />

    <label for="user_client_secret">Client Secret</label>
    <input type="password" id="user_client_secret" name="user_client_secret"
           autocomplete="off" required placeholder="cs-..." />

    <button type="submit">Authorize</button>
    <div class="hint">Ask your Heron administrator if you do not have credentials.</div>
  </form>
</body>
</html>
"""
