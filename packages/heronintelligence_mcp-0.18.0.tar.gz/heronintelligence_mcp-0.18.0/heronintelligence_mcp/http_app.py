"""HTTP transport wrapper for the Heron Intelligence MCP server.

Supports three authentication modes simultaneously:

  1. **OAuth 2.1 with JWT (new, per-user)**
       POST /mcp  →  Authorization: Bearer <jwt>
       JWT is issued via the OAuth flow at /authorize + /token + /register.
       Claims include sub=consumption_user_id → per-user identity.

  2. **OAuth 2.1 with legacy-manual client_id (existing personal Claude)**
       Same endpoints, but client_id lives in mcp_clients.oauth_client_id.
       Auto-approves without login_hint — preserves the existing UX.

  3. **Legacy URL-path api_key (backwards-compatible)**
       POST /hk-abc123/mcp  →  api_key extracted from URL path
       The key is injected as a Bearer token; the provider recognises hk-*.

Additional endpoints:
  - GET /.well-known/oauth-protected-resource — Protected Resource Metadata (RFC 9728)
  - GET /.well-known/oauth-authorization-server — served by FastMCP automatically
"""
from __future__ import annotations

import os

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from heronintelligence_mcp._context import _request_api_key
from heronintelligence_mcp.consent_page import (
    handle_consent_submit,
    render_consent_form,
)
from heronintelligence_mcp.oauth_provider import set_login_hint
from heronintelligence_mcp.server import mcp

_MCP_CANONICAL_URI = os.environ.get(
    "MCP_CANONICAL_URI", "https://mcp.heron-intelligence.com"
)
# Paths that must never require auth (OAuth endpoints + discovery metadata).
# FastMCP mounts /authorize, /token, /register, /revoke at root.
_NO_AUTH_PREFIXES = (
    "/.well-known/",
    "/authorize",
    "/token",
    "/register",
    "/revoke",
)

# WWW-Authenticate header returned on 401 to tell Claude where to find the PRM
_WWW_AUTH_CHALLENGE = (
    f'Bearer resource_metadata="{_MCP_CANONICAL_URI}/.well-known/oauth-protected-resource"'
)


# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------

# Note: /.well-known/oauth-protected-resource is mounted automatically by
# FastMCP via AuthSettings(resource_server_url=...). We intentionally do not
# add our own — it would conflict with FastMCP's route.

class DualAuthMiddleware(BaseHTTPMiddleware):
    """Handles all three auth modes.

    Evaluation order:
    0. POST /authorize/consent → validate the user-entered client_id/secret
       and redirect back to Claude with a fresh auth code.
    1. Public OAuth / discovery paths → pass through without auth.
       On GET /authorize, if a login_hint is present it is stashed for the
       provider; otherwise we try to render the consent form (only fires for
       DCR clients — manual clients auto-approve).
    2. Authorization: Bearer <token> → FastMCP validates via provider.
    3. /{hk-key}/mcp URL path → inject key as Bearer, rewrite path.
    4. Anything else → 401 with WWW-Authenticate: Bearer resource_metadata=…
    """

    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        method = request.method

        # ── 0. Consent form POST ────────────────────────────────────────────
        # Handled by the consent module; produces either a 302 to the client's
        # callback with a fresh auth code, or a 400/401 re-render on failure.
        if path == "/authorize/consent" and method == "POST":
            return await handle_consent_submit(request)

        # ── 1. Public OAuth / discovery paths ───────────────────────────────
        if any(path.startswith(p) for p in _NO_AUTH_PREFIXES):
            if path.startswith("/authorize"):
                hint = request.query_params.get("login_hint")
                if hint:
                    # Claude supplied an identity hint explicitly — use it and
                    # skip the consent page.
                    set_login_hint(hint)
                elif method == "GET":
                    # DCR clients can't be mapped to a user from client_id
                    # alone. If this is one, render the credentials form;
                    # otherwise let FastMCP's authorize handler run.
                    consent = await render_consent_form(request)
                    if consent is not None:
                        return consent
            return await call_next(request)

        # ── 2. Bearer token (OAuth — either JWT or legacy hk-*) ─────────────
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            return await call_next(request)

        # ── 3. Legacy URL-path key (/hk-abc123/mcp) ────────────────────────
        parts = path.lstrip("/").split("/", 1)
        if len(parts) == 2 and parts[1].startswith("mcp"):
            api_key = parts[0]
            if api_key:
                request.scope["path"] = "/" + parts[1]
                raw_headers = [
                    (k, v)
                    for k, v in request.scope["headers"]
                    if k.lower() != b"authorization"
                ]
                raw_headers.append(
                    (b"authorization", f"Bearer {api_key}".encode())
                )
                request.scope["headers"] = raw_headers
                ctx_token = _request_api_key.set(api_key)
                try:
                    return await call_next(request)
                finally:
                    _request_api_key.reset(ctx_token)

        # ── 4. No valid auth ────────────────────────────────────────────────
        return JSONResponse(
            status_code=401,
            content={
                "error": "Authentication required. Use OAuth (Authorization: "
                "Bearer <token>) or the legacy URL format."
            },
            headers={"WWW-Authenticate": _WWW_AUTH_CHALLENGE},
        )


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def create_app():
    """Factory function for uvicorn --factory.

    Returns the FastMCP Starlette app (with OAuth routes + RequireAuthMiddleware)
    wrapped with DualAuthMiddleware.
    """
    starlette_app = mcp.streamable_http_app()
    starlette_app.add_middleware(DualAuthMiddleware)
    return starlette_app
