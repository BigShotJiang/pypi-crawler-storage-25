"""JWT access-token encode/decode for the Heron MCP authorization server.

HS256 signed with OAUTH_JWT_SECRET (shared with aura-core-ai). Claims:

    iss            — OAUTH_JWT_ISSUER (default https://mcp.heron-intelligence.com)
    sub            — consumption_user_id (UUID) — empty string if unknown
    aud            — MCP_CANONICAL_URI (resource binding per RFC 8707)
    client_id      — the OAuth client_id (DCR or manual)
    mcp_client_id  — UUID of mcp_clients.id (custom claim, lets the RS skip a lookup)
    scope          — space-separated scope list
    iat / exp      — issued-at / expiry (unix seconds)
    jti            — unique JWT id
"""
from __future__ import annotations

import os
import time
import uuid as _uuid
from typing import Any, Optional

import jwt  # PyJWT

# MVP default: hardcoded for local + staging smoke tests. Production deployments
# SHOULD override via env var (AWS Secrets Manager → OAUTH_JWT_SECRET). Rotating
# this value invalidates all outstanding access tokens and refresh tokens.
_SECRET: str = os.environ.get(
    "OAUTH_JWT_SECRET",
    "8e41b337e4a3a0e84a336153d1bfe3f4901cfd9c6f8b963491337444507b18f7",
)
_ISSUER: str = os.environ.get(
    "OAUTH_JWT_ISSUER", "https://mcp.heron-intelligence.com"
)
_AUDIENCE: str = os.environ.get(
    "MCP_CANONICAL_URI", "https://mcp.heron-intelligence.com"
)
_ALGORITHM: str = "HS256"
_ACCESS_TOKEN_TTL: int = int(os.environ.get("OAUTH_ACCESS_TOKEN_TTL", "3600"))


def encode_access_token(
    *,
    mcp_client_id: str,
    consumption_user_id: Optional[str],
    client_id: str,
    scopes: list[str],
    ttl_seconds: Optional[int] = None,
) -> tuple[str, int]:
    """Return (encoded_jwt, expires_in_seconds)."""
    now = int(time.time())
    ttl = ttl_seconds if ttl_seconds is not None else _ACCESS_TOKEN_TTL
    payload: dict[str, Any] = {
        "iss": _ISSUER,
        "sub": consumption_user_id or "",
        "aud": _AUDIENCE,
        "client_id": client_id,
        "mcp_client_id": mcp_client_id,
        "scope": " ".join(scopes or []),
        "iat": now,
        "exp": now + ttl,
        "jti": str(_uuid.uuid4()),
    }
    token = jwt.encode(payload, _SECRET, algorithm=_ALGORITHM)
    return token, ttl


def decode_access_token(token: str) -> Optional[dict[str, Any]]:
    """Validate and decode a JWT. Returns claims dict on success, None on failure."""
    try:
        return jwt.decode(
            token,
            _SECRET,
            algorithms=[_ALGORITHM],
            audience=_AUDIENCE,
            issuer=_ISSUER,
        )
    except jwt.PyJWTError:
        return None


def get_canonical_uri() -> str:
    return _AUDIENCE


def get_issuer() -> str:
    return _ISSUER


def get_access_token_ttl() -> int:
    return _ACCESS_TOKEN_TTL
