#!/usr/bin/env python3
"""
n8n REST API CLI — manage workflows from the command line.
No external dependencies required.

Usage:
    n8n <command> [args...]

Workflow Commands:
    list-workflows [--active] [--tag <name>] [--limit <n>]   List workflows
    get-workflow <id>                                         Get workflow details (JSON)
    create-workflow <json>                                    Create from JSON payload
    update-workflow <id> <json>                               Update existing workflow
    delete-workflow <id>                                      Delete permanently

Lifecycle Commands:
    activate <id>                                             Activate workflow triggers
    deactivate <id>                                           Deactivate workflow triggers
    run <id> [--data '{}']                                    Execute workflow manually

Execution Commands:
    list-executions [workflowId] [--status <s>] [--limit <n>] List executions
    get-execution <id>                                         Get execution details (JSON)

Template Commands:
    list-templates                                            List built-in templates
    create-from-template <name> [--name 'My Workflow']        Create from template

Utility Commands:
    export <id> [--file output.json]                          Export workflow to JSON
    import <file.json>                                        Import workflow from JSON

Environment:
    N8N_HOST     — Base URL of n8n instance (e.g. http://localhost:5678)
    N8N_API_KEY  — API key from n8n Settings > API

Global options:
    -o, --output <format>    Output format: tsv (default), json
"""

import csv
import importlib.resources
import io
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request


# ---------------------------------------------------------------------------
# Auth & config
# ---------------------------------------------------------------------------

def get_config():
    """Return (host, api_key) from environment, exit if missing."""
    host = os.environ.get("N8N_HOST", "").rstrip("/")
    api_key = os.environ.get("N8N_API_KEY")
    if not host:
        print("Error: N8N_HOST environment variable not set", file=sys.stderr)
        sys.exit(1)
    if not api_key:
        print("Error: N8N_API_KEY environment variable not set", file=sys.stderr)
        sys.exit(1)
    return host, api_key


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

def api_request(method, url, data=None):
    """Make an authenticated request to the n8n API."""
    _, api_key = get_config()
    headers = {
        "X-N8N-API-KEY": api_key,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read().decode()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        try:
            error_json = json.loads(error_body)
            print(json.dumps(error_json, indent=2), file=sys.stderr)
        except json.JSONDecodeError:
            print(f"HTTP {e.code}: {error_body}", file=sys.stderr)
        sys.exit(1)


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------

def _cell(val):
    if val is None:
        return ""
    if isinstance(val, bool):
        return str(val).lower()
    if isinstance(val, list):
        return "; ".join(str(v) for v in val)
    if isinstance(val, dict):
        return json.dumps(val, separators=(",", ":"))
    return str(val)


def _write_delimited(headers, rows, delimiter="\t", file=sys.stdout):
    if not headers:
        return
    if delimiter == "\t" and hasattr(file, "isatty") and file.isatty():
        all_rows = [headers] + rows
        col_widths = [0] * len(headers)
        for row in all_rows:
            for i, val in enumerate(row):
                if i < len(col_widths):
                    col_widths[i] = min(max(col_widths[i], len(str(val))), 40)
        for row in all_rows:
            parts = []
            for i, val in enumerate(row):
                s = str(val)
                if i < len(col_widths) - 1:
                    s = s.ljust(col_widths[i])
                parts.append(s)
            print("  ".join(parts), file=file)
    else:
        writer = csv.writer(file, delimiter=delimiter, lineterminator="\n")
        writer.writerow(headers)
        for row in rows:
            writer.writerow(row)


# ---------------------------------------------------------------------------
# Flag extraction & JSON input
# ---------------------------------------------------------------------------

def extract_output_flag(argv):
    remaining = []
    output_format = "tsv"
    i = 0
    while i < len(argv):
        if argv[i] in ("--output", "-o") and i + 1 < len(argv):
            output_format = argv[i + 1].lower()
            i += 2
        else:
            remaining.append(argv[i])
            i += 1
    if output_format not in ("tsv", "json"):
        print(f"Error: unknown output format '{output_format}'. Use tsv or json.", file=sys.stderr)
        sys.exit(1)
    return output_format, remaining


def _read_json_payload(args):
    """Read JSON from args: inline string, @file reference, or - for stdin."""
    if not args:
        print("Error: JSON payload required (inline, @file, or - for stdin)", file=sys.stderr)
        sys.exit(1)
    raw = args[0]
    if raw == "-":
        raw = sys.stdin.read()
    elif raw.startswith("@"):
        path = raw[1:]
        try:
            with open(path) as f:
                raw = f.read()
        except FileNotFoundError:
            print(f"Error: file not found: {path}", file=sys.stderr)
            sys.exit(1)
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        print(f"Error: invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)


# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------

def parse_cli_args(argv, known_flags):
    """Parse --flag value pairs from argv. Returns (flags_dict, remaining_positional_args)."""
    flags = {}
    positional = []
    i = 0
    while i < len(argv):
        if argv[i].startswith("--") and argv[i][2:] in known_flags and i + 1 < len(argv):
            flags[argv[i][2:]] = argv[i + 1]
            i += 2
        elif argv[i].startswith("--") and argv[i][2:] in known_flags:
            # Boolean flag (no value)
            flags[argv[i][2:]] = True
            i += 1
        else:
            positional.append(argv[i])
            i += 1
    return flags, positional


# ---------------------------------------------------------------------------
# Workflow CRUD
# ---------------------------------------------------------------------------

def list_workflows(argv, fmt):
    host, _ = get_config()
    flags, _ = parse_cli_args(argv, {"active", "tag", "limit"})
    params = {}
    if "active" in flags:
        params["active"] = "true" if flags["active"] is True else flags["active"]
    if "tag" in flags:
        params["tags"] = flags["tag"]
    if "limit" in flags:
        params["limit"] = flags["limit"]
    url = f"{host}/api/v1/workflows"
    if params:
        url += "?" + urllib.parse.urlencode(params)
    result = api_request("GET", url)
    if fmt == "json":
        print(json.dumps(result, indent=2))
        return
    workflows = result.get("data", [])
    headers = ["id", "name", "active", "createdAt", "updatedAt", "tags"]
    rows = []
    for w in workflows:
        tags = "; ".join(t.get("name", "") for t in w.get("tags", []))
        rows.append([
            w.get("id", ""),
            w.get("name", ""),
            _cell(w.get("active")),
            w.get("createdAt", ""),
            w.get("updatedAt", ""),
            tags,
        ])
    delim = "\t" if fmt == "tsv" else ","
    _write_delimited(headers, rows, delimiter=delim)


def get_workflow(workflow_id):
    host, _ = get_config()
    url = f"{host}/api/v1/workflows/{workflow_id}"
    result = api_request("GET", url)
    print(json.dumps(result, indent=2))


def create_workflow(argv, fmt):
    host, _ = get_config()
    payload = _read_json_payload(argv)
    url = f"{host}/api/v1/workflows"
    result = api_request("POST", url, payload)
    if fmt == "json":
        print(json.dumps(result, indent=2))
    else:
        print(f"id\t{result.get('id', '')}")
        print(f"name\t{result.get('name', '')}")
        print(f"active\t{_cell(result.get('active'))}")


def update_workflow(workflow_id, argv, fmt):
    host, _ = get_config()
    payload = _read_json_payload(argv)
    url = f"{host}/api/v1/workflows/{workflow_id}"
    result = api_request("PATCH", url, payload)
    if fmt == "json":
        print(json.dumps(result, indent=2))
    else:
        print(f"id\t{result.get('id', '')}")
        print(f"name\t{result.get('name', '')}")
        print(f"active\t{_cell(result.get('active'))}")


def delete_workflow(workflow_id):
    host, _ = get_config()
    url = f"{host}/api/v1/workflows/{workflow_id}"
    api_request("DELETE", url)
    print(f"deleted\t{workflow_id}")


# ---------------------------------------------------------------------------
# Lifecycle commands
# ---------------------------------------------------------------------------

def activate_workflow(workflow_id, fmt):
    host, _ = get_config()
    url = f"{host}/api/v1/workflows/{workflow_id}/activate"
    result = api_request("POST", url)
    if fmt == "json":
        print(json.dumps(result, indent=2))
    else:
        print(f"id\t{result.get('id', '')}")
        print(f"active\ttrue")


def deactivate_workflow(workflow_id, fmt):
    host, _ = get_config()
    url = f"{host}/api/v1/workflows/{workflow_id}/deactivate"
    result = api_request("POST", url)
    if fmt == "json":
        print(json.dumps(result, indent=2))
    else:
        print(f"id\t{result.get('id', '')}")
        print(f"active\tfalse")


def run_workflow(workflow_id, argv, fmt):
    host, _ = get_config()
    flags, remaining = parse_cli_args(argv, {"data"})
    payload = {}
    if "data" in flags:
        try:
            payload = json.loads(flags["data"])
        except json.JSONDecodeError as e:
            print(f"Error: invalid --data JSON: {e}", file=sys.stderr)
            sys.exit(1)
    url = f"{host}/api/v1/workflows/{workflow_id}/run"
    result = api_request("POST", url, payload if payload else None)
    print(json.dumps(result, indent=2))


# ---------------------------------------------------------------------------
# Execution commands
# ---------------------------------------------------------------------------

def list_executions(argv, fmt):
    host, _ = get_config()
    flags, positional = parse_cli_args(argv, {"status", "limit"})
    params = {}
    if positional:
        params["workflowId"] = positional[0]
    if "status" in flags:
        params["status"] = flags["status"]
    if "limit" in flags:
        params["limit"] = flags["limit"]
    url = f"{host}/api/v1/executions"
    if params:
        url += "?" + urllib.parse.urlencode(params)
    result = api_request("GET", url)
    if fmt == "json":
        print(json.dumps(result, indent=2))
        return
    executions = result.get("data", [])
    headers = ["id", "workflowId", "status", "startedAt", "stoppedAt"]
    rows = []
    for ex in executions:
        wf = ex.get("workflowData", {}) or {}
        rows.append([
            ex.get("id", ""),
            ex.get("workflowId", wf.get("id", "")),
            ex.get("status", ""),
            ex.get("startedAt", ""),
            ex.get("stoppedAt", ""),
        ])
    delim = "\t" if fmt == "tsv" else ","
    _write_delimited(headers, rows, delimiter=delim)


def get_execution(execution_id):
    host, _ = get_config()
    url = f"{host}/api/v1/executions/{execution_id}"
    result = api_request("GET", url)
    print(json.dumps(result, indent=2))


# ---------------------------------------------------------------------------
# Template commands
# ---------------------------------------------------------------------------

def _get_template_dir():
    """Return path to templates directory."""
    if sys.version_info >= (3, 9):
        return importlib.resources.files("n8n_cli") / "templates"
    else:
        # Python 3.8 fallback
        return os.path.join(os.path.dirname(__file__), "templates")


def _load_template(name):
    """Load a template JSON file by name (without .json extension)."""
    tpl_dir = _get_template_dir()
    if sys.version_info >= (3, 9):
        tpl_path = tpl_dir / f"{name}.json"
        try:
            raw = tpl_path.read_text()
        except FileNotFoundError:
            print(f"Error: unknown template '{name}'. Use list-templates to see available.", file=sys.stderr)
            sys.exit(1)
    else:
        tpl_path = os.path.join(tpl_dir, f"{name}.json")
        try:
            with open(tpl_path) as f:
                raw = f.read()
        except FileNotFoundError:
            print(f"Error: unknown template '{name}'. Use list-templates to see available.", file=sys.stderr)
            sys.exit(1)
    return raw


def list_templates():
    """List available built-in templates."""
    tpl_dir = _get_template_dir()
    if sys.version_info >= (3, 9):
        names = sorted(p.name[:-5] for p in tpl_dir.iterdir() if p.name.endswith(".json"))
    else:
        names = sorted(f[:-5] for f in os.listdir(tpl_dir) if f.endswith(".json"))
    for name in names:
        print(name)


def create_from_template(argv, fmt):
    """Create a workflow from a built-in template."""
    flags, positional = parse_cli_args(argv, {"name"})
    if not positional:
        print("Usage: n8n create-from-template <template> [--name 'My Workflow']", file=sys.stderr)
        sys.exit(1)
    template_name = positional[0]
    workflow_name = flags.get("name", f"{template_name.title()} Workflow")
    raw = _load_template(template_name)
    raw = raw.replace("{{name}}", workflow_name)
    payload = json.loads(raw)
    host, _ = get_config()
    url = f"{host}/api/v1/workflows"
    result = api_request("POST", url, payload)
    if fmt == "json":
        print(json.dumps(result, indent=2))
    else:
        print(f"id\t{result.get('id', '')}")
        print(f"name\t{result.get('name', '')}")
        print(f"active\t{_cell(result.get('active'))}")


# ---------------------------------------------------------------------------
# Utility commands
# ---------------------------------------------------------------------------

def export_workflow(workflow_id, argv):
    """Export workflow JSON to stdout or file."""
    flags, _ = parse_cli_args(argv, {"file"})
    host, _ = get_config()
    url = f"{host}/api/v1/workflows/{workflow_id}"
    result = api_request("GET", url)
    output = json.dumps(result, indent=2)
    if "file" in flags:
        with open(flags["file"], "w") as f:
            f.write(output + "\n")
        print(f"Exported to {flags['file']}", file=sys.stderr)
    else:
        print(output)


def import_workflow(filepath, fmt):
    """Import workflow from a JSON file."""
    try:
        with open(filepath) as f:
            payload = json.load(f)
    except FileNotFoundError:
        print(f"Error: file not found: {filepath}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"Error: invalid JSON in {filepath}: {e}", file=sys.stderr)
        sys.exit(1)
    # Remove id if present — API assigns a new one
    payload.pop("id", None)
    host, _ = get_config()
    url = f"{host}/api/v1/workflows"
    result = api_request("POST", url, payload)
    if fmt == "json":
        print(json.dumps(result, indent=2))
    else:
        print(f"id\t{result.get('id', '')}")
        print(f"name\t{result.get('name', '')}")
        print(f"active\t{_cell(result.get('active'))}")


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

def main():
    fmt, argv = extract_output_flag(sys.argv[1:])
    if not argv:
        print(__doc__.strip())
        sys.exit(1)
    cmd = argv[0]
    args = argv[1:]

    if cmd == "list-workflows":
        list_workflows(args, fmt)
    elif cmd == "get-workflow":
        if not args:
            print("Usage: n8n get-workflow <id>", file=sys.stderr)
            sys.exit(1)
        get_workflow(args[0])
    elif cmd == "create-workflow":
        create_workflow(args, fmt)
    elif cmd == "update-workflow":
        if not args:
            print("Usage: n8n update-workflow <id> <json>", file=sys.stderr)
            sys.exit(1)
        update_workflow(args[0], args[1:], fmt)
    elif cmd == "delete-workflow":
        if not args:
            print("Usage: n8n delete-workflow <id>", file=sys.stderr)
            sys.exit(1)
        delete_workflow(args[0])
    elif cmd == "activate":
        if not args:
            print("Usage: n8n activate <id>", file=sys.stderr)
            sys.exit(1)
        activate_workflow(args[0], fmt)
    elif cmd == "deactivate":
        if not args:
            print("Usage: n8n deactivate <id>", file=sys.stderr)
            sys.exit(1)
        deactivate_workflow(args[0], fmt)
    elif cmd == "run":
        if not args:
            print("Usage: n8n run <id> [--data '{}']", file=sys.stderr)
            sys.exit(1)
        run_workflow(args[0], args[1:], fmt)
    elif cmd == "list-executions":
        list_executions(args, fmt)
    elif cmd == "get-execution":
        if not args:
            print("Usage: n8n get-execution <id>", file=sys.stderr)
            sys.exit(1)
        get_execution(args[0])
    elif cmd == "list-templates":
        list_templates()
    elif cmd == "create-from-template":
        create_from_template(args, fmt)
    elif cmd == "export":
        if not args:
            print("Usage: n8n export <id> [--file output.json]", file=sys.stderr)
            sys.exit(1)
        export_workflow(args[0], args[1:])
    elif cmd == "import":
        if not args:
            print("Usage: n8n import <file.json>", file=sys.stderr)
            sys.exit(1)
        import_workflow(args[0], fmt)
    else:
        print(f"Error: unknown command '{cmd}'", file=sys.stderr)
        print("Run 'n8n' with no arguments to see available commands.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
