# n8n CLI

Zero-dependency CLI for the n8n REST API. Create, manage, and run workflows from the command line.

## Install

```bash
pip install n8n-workflow-cli
```

## Setup

```bash
export N8N_HOST=http://localhost:5678
export N8N_API_KEY=your-api-key
```

## Usage

```bash
n8n list-workflows
n8n get-workflow <id>
n8n create-from-template webhook --name "My Webhook"
n8n run <id> --data '{"key": "value"}'
n8n export <id> --file backup.json
```

Run `n8n` with no arguments to see all commands.
