# n8n CLI Design

## Overview

A zero-dependency Python CLI that wraps the n8n REST API to let users create and manage workflows from the command line. Mirrors the architecture of [airtable-cli](https://github.com/arnoldadlv/airtable-cli) — single-file, `urllib` only, TSV-first output, publishable to PyPI.

## Problem

n8n's existing CLI is admin-only (server management, import/export, license). There is no CLI for workflow authoring — creating, updating, activating, running, or templating workflows. This CLI fills that gap.

## Project Structure

```
n8n-cli/
├── pyproject.toml          # hatchling build, entry point: n8n
├── LICENSE                  # MIT
├── README.md
└── src/
    └── n8n_cli/
        ├── __init__.py
        ├── cli.py           # all commands
        └── templates/
            ├── blank.json
            ├── webhook.json
            └── schedule.json
```

## Authentication

Two environment variables:

- `N8N_HOST` — base URL of the n8n instance (e.g. `http://localhost:5678`)
- `N8N_API_KEY` — API key created in n8n Settings > API

The CLI validates both are set before any API call and exits with a clear error if missing. No config files, no dotenv.

## Commands (14 total)

### Workflow CRUD

| Command | Method | Endpoint | Description |
|---------|--------|----------|-------------|
| `list-workflows [--active] [--tag <name>] [--limit <n>]` | GET | `/api/v1/workflows` | List workflows |
| `get-workflow <id>` | GET | `/api/v1/workflows/<id>` | Get single workflow |
| `create-workflow <json>` | POST | `/api/v1/workflows` | Create from raw JSON |
| `update-workflow <id> <json>` | PATCH | `/api/v1/workflows/<id>` | Update existing |
| `delete-workflow <id>` | DELETE | `/api/v1/workflows/<id>` | Delete permanently |

### Lifecycle

| Command | Method | Endpoint | Description |
|---------|--------|----------|-------------|
| `activate <id>` | POST | `/api/v1/workflows/<id>/activate` | Activate triggers |
| `deactivate <id>` | POST | `/api/v1/workflows/<id>/deactivate` | Deactivate triggers |
| `run <id> [--data '{}']` | POST | `/api/v1/workflows/<id>/run` | Execute manually |

### Executions

| Command | Method | Endpoint | Description |
|---------|--------|----------|-------------|
| `list-executions <workflowId> [--status <s>] [--limit <n>]` | GET | `/api/v1/executions` | List execution history |
| `get-execution <id>` | GET | `/api/v1/executions/<id>` | Get execution details |

### Templates

| Command | Description |
|---------|-------------|
| `create-from-template <name> [--name "My Workflow"]` | Create workflow from built-in template |
| `list-templates` | List available templates |

### Utility

| Command | Description |
|---------|-------------|
| `export <id> [--file output.json]` | Export workflow JSON to stdout or file |
| `import <file>` | Import workflow from JSON file |

## Output Format

- **Global option:** `-o json|tsv` (default: TSV)
- **List commands** render as TSV with aligned columns on TTY, raw TSV when piped
- **Detail commands** (`get-workflow`, `get-execution`) output JSON since workflow structures are deeply nested

### TSV Columns

- `list-workflows`: id, name, active, createdAt, updatedAt, tags
- `list-executions`: id, workflowId, status, startedAt, stoppedAt

## API Layer

Single `api_request(method, url, data=None)` function:

- Auth: `X-N8N-API-KEY` header
- Base URL: `{N8N_HOST}/api/v1/`
- JSON body when data is provided
- Catches `HTTPError`, parses n8n JSON error response, prints readable message, exits 1

## JSON Input (3 calling conventions)

1. Inline arg: `n8n create-workflow '{"name": "test", "nodes": [...]}'`
2. File reference: `n8n create-workflow @workflow.json`
3. Stdin pipe: `cat workflow.json | n8n create-workflow -`

## Templates

Three built-in templates stored as JSON files in `src/n8n_cli/templates/`:

### blank.json
Minimal workflow with a Manual Trigger node. Starting point for building anything.

### webhook.json
Webhook Trigger -> Code node (placeholder transform) -> Respond to Webhook node. Common pattern for receiving external events.

### schedule.json
Schedule Trigger (every hour default) -> HTTP Request node (placeholder URL) -> Code node (placeholder transform). Common for recurring data pulls.

Each template uses a `{{name}}` placeholder replaced by `--name` flag or a default. Node positions are pre-set for clean rendering in the n8n editor.

## Dependencies

Zero. Python standard library only (`urllib`, `json`, `sys`, `os`, `csv`, `io`).

## Distribution

- Package name: `n8n-workflow-cli` (to avoid conflict with n8n's own packages)
- Entry point: `n8n` command
- Build: hatchling
- Target: PyPI
