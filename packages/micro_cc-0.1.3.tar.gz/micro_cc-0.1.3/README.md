# micro·cc — cognitive compute

```
  ███╗   ███╗ ██████╗ ██████╗ ███████╗██╗
  ████╗ ████║██╔═══██╗██╔══██╗██╔════╝██║
  ██╔████╔██║██║   ██║██║  ██║█████╗  ██║
  ██║╚██╔╝██║██║   ██║██║  ██║██╔══╝  ██║
  ██║ ╚═╝ ██║╚██████╔╝██████╔╝███████╗███████╗
  ╚═╝     ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚══════╝
  ─────── on the metal ─────────────────────
```

Harness that gives frontier models full system access — shell, filesystem, browser, MCP — running directly on the metal. Planning, memory, and tool orchestration let models perform complex multi-step work autonomously. Point it at any project directory and go.

## Install

```bash
pip install micro-cc
```

## Environment

Create `~/.micro-cc/.env` with **one** endpoint — set Anthropic OR LiteLLM, not both. If both are set, Anthropic takes priority.

```
# Anthropic (direct)
ANTHROPIC_API_KEY=sk-ant-

# OR LiteLLM (proxy to Bedrock, Azure, etc.)
LITELLM_BASE_URL=https://your-proxy.com
LITELLM_API_KEY=sk-...

# Shared
OPENAI_API_KEY=sk-proj-
SERPAPI_KEY=
```

## Usage

```bash
microcc /path/to/your/project
```

**Controls:**
- `Enter` — submit prompt
- `Shift+Enter` — newline
- `Escape` — interrupt
- `/clear` — reset conversation
- `/model` — switch model
- `/exit` — quit

## Data

All conversation history and project state is stored in:

```
~/.micro-cc/
  .env                              API keys (you create this)
  projects/
    {project}_{hash}/
      messages.jsonl                conversation history
      summary.json                  sliding-window summary
      project_path.txt              maps hash back to directory
```

## Architecture

```
start_live_.py (CLI)                textual TUI + rich rendering
       │
       │ async for event in claude_loop()
       ▼
claude_loop_.py (Core)              API calls, tool execution, JSONL storage
       │
       │ execute_tool_call()
       ▼
tools/                              bash_, read_, write_, edit_, glob_, grep_
       │
       ▼
~/.micro-cc/projects/{hash}/        conversation persistence
```

**How it works:**
1. CLI starts FileWatcher on project dir, enters prompt loop
2. User query → `claude_loop()` async generator
3. Builds system prompt with project's `CLAUDE.md` + any file changes detected
4. Calls Anthropic API with tool definitions
5. Executes tool calls locally, loops until the model stops calling tools
6. Yields events (`thinking`, `tool_call`, `tool_result`, `final_text`) for CLI to render
7. Saves conversation to JSONL (stripped of thinking blocks for replay)

**Tools:**
| Tool | Description |
|------|-------------|
| `bash_` | Subprocess execution in project_dir, timeout support |
| `read_` | Read files with line numbers, offset/limit |
| `write_` | Create/overwrite files, auto-creates dirs |
| `edit_` | Surgical string replacement (fails if ambiguous) |
| `glob_` | Find files by pattern, sorted by mtime |
| `grep_` | Regex search with context lines |

**Path handling:** Relative paths resolve to `project_dir`, absolute paths work anywhere.

**File watcher:** Detects external changes, injects into system prompt so the model sees what you edited.
