from fastmcp import FastMCP

mcp = FastMCP("Anaplan MCP")
