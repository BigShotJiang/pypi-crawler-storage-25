"""Multi-model training orchestrator.

Manages training of multiple models with three execution modes:

* **sequential** -- train models one at a time in the order given.
* **parallel** -- train models concurrently in separate subprocesses
  (using ``multiprocessing`` with *spawn* context to avoid CUDA
  re-initialisation issues).
* **mixed** -- train some models sequentially and others in parallel.

Supports both holdout (single split) and k-fold cross-validation.
When ``splitting.method`` is ``"StratifiedGroupKFold"``, the orchestrator
loops over all folds and aggregates results into ``kfold_summary.yaml``.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import logging
import multiprocessing
import shutil
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from eemoclas.config.dataclasses import (
    Config,
    ModelGroupConfig,
    _dataclass_to_dict,
)
from eemoclas.training.experiment import ExperimentManager

logger = logging.getLogger("dglz.orchestrator")


class MultiModelTrainer:
    """Orchestrate multi-model training runs.

    Parameters
    ----------
    config:
        Full :class:`Config` dataclass.
    model_names:
        Ordered list of model-group names to train.
    mode:
        ``"sequential"`` | ``"parallel"`` | ``"mixed"``.
    parallel_models:
        When *mode* is ``"mixed"``, the subset of *model_names* that should
        be trained in parallel.  Ignored for the other two modes.
    experiment_mgr:
        Optional pre-built :class:`ExperimentManager`.  If ``None`` one is
        created from ``config.experiment``.
    verbose:
        When ``True`` log high-level progress messages.
    fresh:
        When ``True`` ignore any existing checkpoints and train from scratch.
    """

    def __init__(
        self,
        config: Config,
        model_names: list[str],
        mode: str = "sequential",
        parallel_models: list[str] | None = None,
        experiment_mgr: ExperimentManager | None = None,
        verbose: bool = True,
        fresh: bool = False,
    ) -> None:
        if mode not in ("sequential", "parallel", "mixed"):
            raise ValueError(
                f"Invalid mode '{mode}'. Must be one of: sequential, parallel, mixed"
            )
        self.config = config
        self.model_names = model_names
        self.mode = mode
        self.parallel_models = parallel_models or []
        self.experiment_mgr = experiment_mgr or ExperimentManager(config.experiment)
        self.verbose = verbose
        self.fresh = fresh
        self.results: dict[str, dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self) -> dict[str, dict[str, Any]]:
        """Execute training for all models and return results per model.

        Returns
        -------
        dict[str, dict]
            Mapping of model name to its training summary dict (keys
            include ``epochs_trained``, ``best_epoch``, ``best_metrics``,
            ``total_time_seconds``, ``early_stopped``).
        """
        self.experiment_mgr.init_training_state(self.model_names)
        self.experiment_mgr.save_config_snapshot(
            self.config.config_snapshot(),
            getattr(self.config, "_source_yaml_path", None),
        )

        if self.mode == "sequential":
            self._train_sequential(self.model_names)
        elif self.mode == "parallel":
            self._train_parallel(self.model_names)
        elif self.mode == "mixed":
            seq = [m for m in self.model_names if m not in self.parallel_models]
            par = [m for m in self.model_names if m in self.parallel_models]
            self._train_sequential(seq)
            self._train_parallel(par)

        return self.results

    # ------------------------------------------------------------------
    # Execution strategies
    # ------------------------------------------------------------------

    def _train_sequential(self, model_names: list[str]) -> None:
        """Train *model_names* one by one."""
        for name in model_names:
            self.experiment_mgr.update_model_state(name, "running")
            try:
                result = self._train_single(name)
                self.results[name] = result
                # K-fold results have "method" key; holdout has "best_epoch"
                if result.get("method") == "StratifiedGroupKFold":
                    best_fold_idx = result.get("best_fold_idx", 0)
                    fold_info = result.get("folds", {}).get(
                        f"fold_{best_fold_idx}", {}
                    )
                    self.experiment_mgr.update_model_state(
                        name,
                        "completed",
                        best_epoch=fold_info.get("best_epoch", 0),
                        best_metric=fold_info.get("best_metrics", {}).get(
                            "val_accuracy", 0.0
                        ),
                        method="StratifiedGroupKFold",
                        n_splits=result.get("n_splits", 0),
                    )
                else:
                    self.experiment_mgr.update_model_state(
                        name,
                        "completed",
                        best_epoch=result.get("best_epoch", 0),
                        best_metric=result.get("best_metrics", {}).get(
                            "val_accuracy", 0.0
                        ),
                    )
                if self.verbose:
                    logger.info("Model '%s' completed training.", name)
            except KeyboardInterrupt:
                self.experiment_mgr.update_model_state(name, "failed")
                raise
            except Exception:
                self.experiment_mgr.update_model_state(name, "failed")
                if self.verbose:
                    logger.exception("Model '%s' failed.", name)
                raise

    def _train_parallel(self, model_names: list[str]) -> None:
        """Train *model_names* concurrently in separate processes.

        Uses ``multiprocessing.get_context("spawn")`` to avoid CUDA
        re-initialisation issues when training on GPU.
        """
        if not model_names:
            return

        ctx = multiprocessing.get_context("spawn")
        config_dict = _dataclass_to_dict(self.config)
        experiment_dir = str(self.experiment_mgr.config.experiment_dir)

        processes: list[tuple[str, multiprocessing.process.BaseProcess]] = []
        for name in model_names:
            p = ctx.Process(
                target=_train_model_in_process,
                args=(config_dict, name, experiment_dir),
                name=f"dglz-train-{name}",
            )
            p.start()
            processes.append((name, p))

        # Collect results -- wait for all processes to finish
        failed: list[str] = []
        try:
            for name, p in processes:
                p.join(timeout=3600)  # 1h max per process
                if p.is_alive():
                    p.terminate()
                    p.join(timeout=5)
                if p.exitcode != 0:
                    failed.append(name)
                    self.experiment_mgr.update_model_state(name, "failed")
                else:
                    self.results[name] = _placeholder_result()
                    self.experiment_mgr.update_model_state(name, "completed")
        except KeyboardInterrupt:
            for name, p in processes:
                if p.is_alive():
                    p.terminate()
                    p.join(timeout=3)
            raise

        if failed:
            raise RuntimeError(
                f"Parallel training failed for models: {failed}"
            )

    # ------------------------------------------------------------------
    # Single-model training (dispatches holdout vs kfold)
    # ------------------------------------------------------------------

    def _train_single(self, model_name: str) -> dict[str, Any]:
        """Train a single model end-to-end.

        Detects the splitting method from config.  For ``"holdout"`` trains
        a single split.  For ``"StratifiedGroupKFold"`` iterates over all
        folds, then aggregates and saves a ``kfold_summary.yaml``.
        """
        import pandas as pd
        from eemoclas.datasets.resampled_dataset import ResampledTensorDataset
        from eemoclas.datasets.splitting import build_group_splits

        model_cfg = self.config.get_model_config(model_name)
        raw = self._build_raw_dict(model_name, model_cfg)

        # --- Resolve device ---
        device_str = raw["training"].get("device", "auto")
        if device_str == "auto":
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            device = torch.device(device_str)

        if self.verbose:
            logger.info("Training '%s' on %s", model_name, device)

        # --- Resolve manifest path ---
        manifest_path = _resolve_manifest_path(self.config, model_name)
        if manifest_path is None or not Path(manifest_path).is_file():
            raise FileNotFoundError(
                f"Manifest not found for model '{model_name}'. "
                f"Looked at: {manifest_path}. "
                f"Run `eemo resample` first to generate training data."
            )

        manifest_df = pd.read_csv(manifest_path)

        if self.verbose:
            logger.info(
                "Manifest: %s (%d samples)", manifest_path, len(manifest_df)
            )

        # --- Create dataset (with optional batch_index filtering) ---
        _load_raw = model_name.startswith("dual_")
        data_source = raw.get("training", {}).get("data_source", {})
        batch_index_csv = None
        if data_source.get("mode") == "batch_index":
            batch_index_csv = data_source.get("batch_index_csv")
            if not batch_index_csv:
                raise ValueError(
                    f"data_source.mode is 'batch_index' for '{model_name}' "
                    f"but batch_index_csv is not specified"
                )
            if not Path(batch_index_csv).exists():
                raise FileNotFoundError(
                    f"batch_index_csv not found: {batch_index_csv}"
                )
            if self.verbose:
                logger.info("Batch index mode: loading %s", batch_index_csv)

        dataset = ResampledTensorDataset(
            manifest_path, load_raw=_load_raw, batch_index_csv=batch_index_csv,
        )

        # --- Auto-detect C_eff from data ---
        c_eff = self._detect_c_eff(manifest_df, dataset, model_name)

        # --- Train/val split ---
        splitting_cfg = raw.get("splitting", {})
        splitting_method = splitting_cfg.get("method", "holdout")
        stratify_key = (
            "group_label"
            if model_name.endswith("subject_state") or model_name == "all_in_one"
            else "emotion_label"
        )
        if stratify_key not in manifest_df.columns:
            stratify_key = None

        splits = build_group_splits(
            manifest_path,
            group_key="subject_id",
            stratify_key=stratify_key,
            n_splits=splitting_cfg.get("n_splits", 5),
            seed=splitting_cfg.get("seed", 42),
            method=splitting_method,
            train_ratio=splitting_cfg.get("train_ratio", 0.8),
            val_ratio=splitting_cfg.get("val_ratio", 0.2),
        )

        if splitting_method == "holdout":
            # --- Holdout: single split ---
            train_idx, val_idx = splits[0]
            if self.verbose:
                logger.info(
                    "Holdout split: %d train / %d val",
                    len(train_idx), len(val_idx),
                )
            # Auto-discover checkpoint for resume
            resume_path = None
            if not self.fresh:
                ckpt_dir = self.experiment_mgr.model_checkpoint_dir(model_name)
                auto_ckpt = ckpt_dir / "latest_model.ckpt"
                if auto_ckpt.exists():
                    resume_path = str(auto_ckpt)
                    if self.verbose:
                        logger.info("Auto-detected checkpoint: %s", resume_path)
            return self._train_one_fold(
                model_name, raw, dataset, manifest_df,
                train_idx, val_idx, device, fold_idx=None,
                c_eff=c_eff, resume_path=resume_path,
            )
        else:
            # --- K-fold: iterate all folds ---
            n_splits = len(splits)
            checkpoint_metric = raw["training"].get(
                "checkpoint_metric",
                raw["training"].get("monitor_best", {}).get(
                    "monitor_metric", "val_accuracy"
                ),
            )
            if self.verbose:
                logger.info(
                    "K-fold: %d folds, metric=%s", n_splits, checkpoint_metric,
                )
            self.experiment_mgr.update_model_state(
                model_name, "running",
                method="StratifiedGroupKFold", n_splits=n_splits,
            )

            # --- Shared preloader for k-fold full-mode reuse ---
            shared_preloader = None
            preload_cfg = raw["training"].get("preload", {})
            preload_enabled = (
                preload_cfg.get("enabled", True)
                if isinstance(preload_cfg, dict)
                else False
            )
            if preload_enabled:
                from eemoclas.datasets.preloaded_dataset import (
                    CompressedPreloader,
                    PreloadDisplay,
                )
                display = PreloadDisplay(model_name, verbose=self.verbose)
                preloader = CompressedPreloader(
                    dataset,
                    compression=preload_cfg.get("compression", "float16"),
                    system_reserve_ratio=preload_cfg.get("system_reserve_ratio", 0.05),
                    skip_meta=preload_cfg.get("skip_meta", True),
                    display=display,
                )
                if preloader.preload_all(len(dataset)):
                    shared_preloader = preloader
                    if self.verbose:
                        logger.info(
                            "K-fold: full-mode preload successful — "
                            "reusing across all %d folds",
                            n_splits,
                        )
                else:
                    preloader.clear()
                    if self.verbose:
                        logger.info(
                            "K-fold: full-mode preload incomplete — "
                            "using per-fold streaming",
                        )

            fold_results: list[dict[str, Any]] = []
            for fold_idx, (train_idx, val_idx) in enumerate(splits):
                if self.verbose:
                    logger.info(
                        "[Fold %d/%d] Train/Val: %d/%d",
                        fold_idx + 1, n_splits,
                        len(train_idx), len(val_idx),
                    )

                # --- K-fold resume: check fold status ---
                fold_resume_path = None
                state = self.experiment_mgr.load_training_state()
                fold_status = (
                    state.get("models", {})
                    .get(model_name, {})
                    .get("folds", {})
                    .get(str(fold_idx), {})
                    .get("status", "pending")
                )
                if fold_status == "completed":
                    if self.verbose:
                        logger.info("[Fold %d] Already completed, skipping.", fold_idx)
                    fold_state = state["models"][model_name]["folds"][str(fold_idx)]
                    fold_results.append({
                        "best_epoch": fold_state.get("best_epoch", 0),
                        "best_metrics": {checkpoint_metric.replace("val_", ""): fold_state.get("best_metric", 0.0)},
                        "early_stopped": False,
                        "epochs_trained": fold_state.get("best_epoch", 0),
                        "total_time_seconds": 0,
                    })
                    continue

                # Check for existing checkpoint in this fold
                if fold_status == "running" and not self.fresh:
                    fold_ckpt_dir = self.experiment_mgr.model_fold_checkpoint_dir(model_name, fold_idx)
                    auto_ckpt = fold_ckpt_dir / "latest_model.ckpt"
                    if auto_ckpt.exists():
                        fold_resume_path = str(auto_ckpt)
                        if self.verbose:
                            logger.info(
                                "[Fold %d] Resuming from checkpoint: %s",
                                fold_idx, fold_resume_path,
                            )

                self.experiment_mgr.update_model_state(
                    model_name, "running",
                    method="StratifiedGroupKFold", n_splits=n_splits,
                    fold_idx=fold_idx,
                )
                result = self._train_one_fold(
                    model_name, raw, dataset, manifest_df,
                    train_idx, val_idx, device, fold_idx=fold_idx,
                    preloader=shared_preloader, c_eff=c_eff,
                    resume_path=fold_resume_path,
                )
                fold_results.append(result)
                self.experiment_mgr.update_model_state(
                    model_name, "completed",
                    best_epoch=result.get("best_epoch", 0),
                    best_metric=result.get("best_metrics", {}).get(
                        checkpoint_metric.replace("val_", ""), 0.0
                    ),
                    method="StratifiedGroupKFold", n_splits=n_splits,
                    fold_idx=fold_idx,
                )

            # Release shared preloader after all folds complete
            if shared_preloader is not None:
                shared_preloader.clear()

            # Aggregate across folds and save summary
            summary = self._aggregate_kfold(
                model_name, fold_results, checkpoint_metric,
            )
            # Copy best fold's checkpoints to fold_best/
            self._copy_best_fold(
                model_name, summary["best_fold_idx"], checkpoint_metric,
            )
            return summary

    # ------------------------------------------------------------------
    # Per-fold training
    # ------------------------------------------------------------------

    def _train_one_fold(
        self,
        model_name: str,
        raw: dict[str, Any],
        dataset,
        manifest_df,
        train_idx: np.ndarray,
        val_idx: np.ndarray,
        device: torch.device,
        *,
        fold_idx: int | None = None,
        preloader: Any = None,
        c_eff: int | None = None,
        resume_path: str | None = None,
    ) -> dict[str, Any]:
        """Train a single fold (or holdout split).

        Parameters
        ----------
        fold_idx:
            When ``None``, uses holdout paths (``checkpoints/{model}/``).
            When an integer, uses fold paths (``checkpoints/{model}/fold_{i}/``).
        """
        from eemoclas.model.model_factory import create_model
        from eemoclas.datasets.collate import collate_subject_state, collate_emotion
        from eemoclas.training.trainer import Trainer

        # Build fold-specific config overrides
        fold_raw = dict(raw)  # shallow copy
        if fold_idx is not None:
            fold_raw["checkpoint_dir"] = str(
                self.experiment_mgr.model_fold_checkpoint_dir(model_name, fold_idx)
            )
            fold_raw["log_dir"] = str(
                self.experiment_mgr.model_fold_log_dir(model_name, fold_idx)
            )

        # --- DataLoaders ---
        batch_size = fold_raw["training"].get("batch_size", 16)
        num_workers = fold_raw["training"].get("num_workers", 0)
        seed = int(fold_raw.get("seeding", {}).get("random_seed", 42))

        _collate = (
            collate_subject_state
            if model_name in ("subject_state", "dual_subject_state", "all_in_one")
            else collate_emotion
        )

        # --- Preload configuration ---
        preload_cfg = fold_raw["training"].get("preload", {})
        preload_enabled = (
            preload_cfg.get("enabled", True)
            if isinstance(preload_cfg, dict)
            else False
        )

        own_preloader = False  # whether this fold owns (and must clear) the preloader
        if preloader is not None:
            # Shared preloader from k-fold full-mode reuse — skip creation
            from eemoclas.datasets.preloaded_dataset import (
                PreloadingTrainLoader,
                PreloadedDataset,
            )
            train_loader = PreloadingTrainLoader(
                preloader,
                dataset,
                train_idx,
                batch_size=batch_size,
                collate_fn=_collate,
                seed=seed,
            )
            preload_val = preload_cfg.get("preload_val", False)
            if preload_val:
                val_subset = PreloadedDataset(preloader, dataset, val_idx)
                val_loader = DataLoader(
                    val_subset,
                    batch_size=batch_size,
                    shuffle=False,
                    collate_fn=_collate,
                    num_workers=num_workers,
                    pin_memory=(device.type == "cuda"),
                )
            else:
                val_loader = DataLoader(
                    Subset(dataset, val_idx),
                    batch_size=batch_size,
                    shuffle=False,
                    collate_fn=_collate,
                    num_workers=num_workers,
                    pin_memory=(device.type == "cuda"),
                )
        elif preload_enabled:
            from eemoclas.datasets.preloaded_dataset import (
                CompressedPreloader as _CompressedPreloader,
                PreloadingTrainLoader,
                PreloadDisplay,
                PreloadedDataset,
            )

            display = PreloadDisplay(model_name, verbose=self.verbose)
            own_preloader = True
            preloader = _CompressedPreloader(
                dataset,
                compression=preload_cfg.get("compression", "float16"),
                system_reserve_ratio=preload_cfg.get("system_reserve_ratio", 0.05),
                skip_meta=preload_cfg.get("skip_meta", True),
                val_indices=val_idx if preload_cfg.get("preload_val", False) else None,
                display=display,
            )
            train_loader = PreloadingTrainLoader(
                preloader,
                dataset,
                train_idx,
                batch_size=batch_size,
                collate_fn=_collate,
                seed=seed,
            )

            preload_val = preload_cfg.get("preload_val", False)
            if preload_val:
                val_subset = PreloadedDataset(preloader, dataset, val_idx)
                val_loader = DataLoader(
                    val_subset,
                    batch_size=batch_size,
                    shuffle=False,
                    collate_fn=_collate,
                    num_workers=num_workers,
                    pin_memory=(device.type == "cuda"),
                )
            else:
                val_loader = DataLoader(
                    Subset(dataset, val_idx),
                    batch_size=batch_size,
                    shuffle=False,
                    collate_fn=_collate,
                    num_workers=num_workers,
                    pin_memory=(device.type == "cuda"),
                )

            if self.verbose:
                logger.info("Preloading enabled for '%s'.", model_name)
        else:
            train_loader = DataLoader(
                Subset(dataset, train_idx),
                batch_size=batch_size,
                shuffle=True,
                collate_fn=_collate,
                num_workers=num_workers,
                pin_memory=(device.type == "cuda"),
            )
            val_loader = DataLoader(
                Subset(dataset, val_idx),
                batch_size=batch_size,
                shuffle=False,
                collate_fn=_collate,
                num_workers=num_workers,
                pin_memory=(device.type == "cuda"),
            )

        # --- Inject auto-detected C_eff into model config ---
        if c_eff is not None:
            model_section = fold_raw.setdefault("model", {})
            if model_name.startswith("dual_"):
                # Dual-branch: PP branch uses C_eff; raw is always 30 channels
                pp_cfg = model_section.setdefault("pp_trial_encoder", {})
                pp_cfg["input_channels"] = c_eff
            else:
                # Single-branch: trial encoder uses C_eff
                te_cfg = model_section.setdefault("trial_encoder", {})
                te_cfg["input_channels"] = c_eff
            if self.verbose:
                logger.info(
                    "Auto-detected C_eff=%d for '%s'",
                    c_eff, model_name,
                )

        # --- Create model ---
        model = create_model(model_name, fold_raw)

        if self.verbose:
            total_params = sum(p.numel() for p in model.parameters())
            fold_label = f" (fold {fold_idx})" if fold_idx is not None else ""
            logger.info("Model parameters%s: %s", fold_label, f"{total_params:,}")

        # --- Create Trainer and fit ---
        trainer = Trainer(
            config=fold_raw,
            model=model,
            device=device,
            manifest_df=manifest_df,
            verbose=self.verbose,
        )
        result = trainer.fit(train_loader, val_loader, resume_path=resume_path)

        # Only clear preloader if this fold owns it (not shared from k-fold)
        if own_preloader and preloader is not None:
            preloader.clear()

        return result

    # ------------------------------------------------------------------
    # K-fold aggregation
    # ------------------------------------------------------------------

    def _aggregate_kfold(
        self,
        model_name: str,
        fold_results: list[dict[str, Any]],
        checkpoint_metric: str,
    ) -> dict[str, Any]:
        """Aggregate metrics across folds and save kfold_summary.yaml.

        Returns a summary dict with per-fold details, aggregated mean/std,
        and the index of the best fold.
        """
        import time

        metric_key = checkpoint_metric  # e.g. "val_accuracy"
        mode = _metric_mode(metric_key)

        # Build per-fold summary
        folds_summary: dict[str, dict[str, Any]] = {}
        best_fold_idx = 0
        best_fold_score = -float("inf") if mode == "max" else float("inf")

        for i, result in enumerate(fold_results):
            best_metrics = result.get("best_metrics", {})
            fold_score = best_metrics.get(metric_key, 0.0)
            folds_summary[f"fold_{i}"] = {
                "best_epoch": result.get("best_epoch", 0),
                "epochs_trained": result.get("epochs_trained", 0),
                "best_metrics": best_metrics,
                "total_time_seconds": result.get("total_time_seconds", 0.0),
                "early_stopped": result.get("early_stopped", False),
            }
            if (mode == "max" and fold_score > best_fold_score) or (
                mode == "min" and fold_score < best_fold_score
            ):
                best_fold_score = fold_score
                best_fold_idx = i

        # Collect all numeric metric keys across folds
        all_metric_keys: set[str] = set()
        for result in fold_results:
            best_metrics = result.get("best_metrics", {})
            for k, v in best_metrics.items():
                if isinstance(v, (int, float)):
                    all_metric_keys.add(k)

        # Compute mean/std for each metric
        aggregated: dict[str, dict[str, Any]] = {}
        for key in sorted(all_metric_keys):
            values = []
            for result in fold_results:
                v = result.get("best_metrics", {}).get(key)
                if isinstance(v, (int, float)):
                    values.append(v)
            if values:
                aggregated[key] = {
                    "mean": float(np.mean(values)),
                    "std": float(np.std(values)) if len(values) > 1 else 0.0,
                    "values": [float(v) for v in values],
                }

        total_time = sum(
            r.get("total_time_seconds", 0.0) for r in fold_results
        )

        summary: dict[str, Any] = {
            "method": "StratifiedGroupKFold",
            "n_splits": len(fold_results),
            "checkpoint_metric": checkpoint_metric,
            "best_fold_idx": best_fold_idx,
            "folds": folds_summary,
            "aggregated": aggregated,
            "total_time_seconds": total_time,
        }

        self.experiment_mgr.save_kfold_summary(model_name, summary)

        if self.verbose:
            logger.info(
                "K-fold complete: %d folds, best_fold=%d (%s=%.4f), time=%.1fs",
                len(fold_results),
                best_fold_idx,
                checkpoint_metric,
                best_fold_score,
                total_time,
            )

        return summary

    def _copy_best_fold(
        self,
        model_name: str,
        best_fold_idx: int,
        checkpoint_metric: str,
    ) -> None:
        """Copy the best fold's checkpoints to ``fold_best/``."""
        src_dir = self.experiment_mgr.model_fold_checkpoint_dir(
            model_name, best_fold_idx
        )
        dst_dir = self.experiment_mgr.model_fold_best_dir(model_name)

        for ckpt_name in ("best_model.ckpt", "latest_model.ckpt"):
            src = src_dir / ckpt_name
            if src.exists():
                shutil.copy2(str(src), str(dst_dir / ckpt_name))

        if self.verbose:
            logger.info(
                "Best fold (%d) checkpoints copied to %s",
                best_fold_idx, dst_dir,
            )

    def _detect_c_eff(
        self,
        manifest_df,
        dataset,
        model_name: str,
    ) -> int:
        """Auto-detect effective channel count from data.

        Detection priority:
        1. ``c_eff`` column in the manifest CSV (written by ``eemo resample``).
        2. Shape of the first sample's ``x`` tensor.
        3. Raise ``ValueError`` if neither source is available.

        Parameters
        ----------
        manifest_df:
            Loaded manifest CSV as a DataFrame.
        dataset:
            :class:`ResampledTensorDataset` instance.
        model_name:
            Model name (used for logging / error messages).

        Returns
        -------
        int
            The effective channel count (always > 0).
        """
        # Level 1: Manifest c_eff column
        if "c_eff" in manifest_df.columns:
            c_eff = int(manifest_df["c_eff"].iloc[0])
            if c_eff > 0:
                if self.verbose:
                    logger.info(
                        "C_eff=%d detected from manifest for '%s'",
                        c_eff, model_name,
                    )
                return c_eff

        # Level 2: First sample shape
        try:
            sample = dataset[0]
            x = sample["x"]
            if x.dim() == 3:   # [8, C_eff, T] — subject_state
                c_eff = x.shape[1]
            elif x.dim() == 2:  # [C_eff, T] — emotion
                c_eff = x.shape[0]
            else:
                c_eff = 0
            if c_eff > 0:
                if self.verbose:
                    logger.info(
                        "C_eff=%d detected from sample shape for '%s'",
                        c_eff, model_name,
                    )
                return c_eff
        except Exception as exc:
            logger.debug("Failed to detect C_eff from sample: %s", exc)

        raise ValueError(
            f"Cannot auto-detect C_eff for model '{model_name}'. "
            f"Manifest has no 'c_eff' column and first sample could not be "
            f"loaded.  Re-run `eemo resample` to regenerate data."
        )

    def _build_raw_dict(self, model_name: str, mc: ModelGroupConfig) -> dict[str, Any]:
        """Convert a :class:`ModelGroupConfig` to a raw dict for Trainer."""
        raw: dict[str, Any] = _dataclass_to_dict(self.config)
        raw["task"] = _dataclass_to_dict(mc.task)
        raw["model"] = _dataclass_to_dict(mc.model)
        raw["training"] = _dataclass_to_dict(mc.training)
        raw["augmentation"] = _dataclass_to_dict(mc.augmentation)
        raw["splitting"] = _dataclass_to_dict(mc.splitting)
        raw["seeding"] = _dataclass_to_dict(mc.seeding)
        raw["checkpoint_dir"] = str(
            self.experiment_mgr.model_checkpoint_dir(model_name)
        )
        raw["log_dir"] = str(self.experiment_mgr.config.log_dir)
        return raw


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _metric_mode(metric_name: str) -> str:
    """Determine whether a metric should be maximised or minimised."""
    loss_keywords = ("loss",)
    lower = metric_name.lower()
    for kw in loss_keywords:
        if kw in lower:
            return "min"
    return "max"


def _placeholder_result() -> dict[str, Any]:
    """Return a placeholder training result for parallel mode."""
    return {
        "epochs_trained": 0,
        "best_epoch": 0,
        "best_metrics": {},
        "total_time_seconds": 0,
        "early_stopped": False,
    }


def _resolve_manifest_path(config: Config, model_name: str) -> str | None:
    """Resolve the manifest CSV path for a given model.

    Checks in order:
    1. ``config.data.manifests[model_name]``
    2. Conventional path ``data/resampled/{model_name}/version_001/manifest.csv``

    For dual-branch models (``dual_*``), falls back to the corresponding
    single-branch data source (e.g. ``dual_normal_emotion`` → ``normal_emotion``).
    """
    # Strip dual_ prefix for data source resolution
    data_source = model_name.removeprefix("dual_")

    # 1. From config data.manifests
    manifests = config.data.manifests
    for name in (model_name, data_source):
        if manifests and name in manifests:
            path = manifests[name]
            if path:
                return path

    # 2. Conventional path (try dual name first, then stripped name)
    for name in (model_name, data_source):
        conventional = Path("data/resampled") / name / "version_001" / "manifest.csv"
        if conventional.is_file():
            return str(conventional)

    # 3. Return the conventional path anyway (will fail with clear message)
    return str(Path("data/resampled") / data_source / "version_001" / "manifest.csv")


def _train_model_in_process(
    config_dict: dict[str, Any],
    model_name: str,
    experiment_dir: str,
) -> None:
    """Entry point for parallel training subprocesses.

    Reconstructs a :class:`Config` from *config_dict*, creates a fresh
    :class:`ExperimentManager`, and delegates to a single-model
    :class:`MultiModelTrainer` run.
    """
    from eemoclas.config.loader import _dict_to_config

    config = _dict_to_config(config_dict)
    mgr = ExperimentManager(config.experiment)
    orchestrator = MultiModelTrainer(
        config,
        [model_name],
        "sequential",
        experiment_mgr=mgr,
        verbose=False,
    )
    orchestrator.run()
