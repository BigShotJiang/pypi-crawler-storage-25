"""Training implementation for ``eemo train``.

Uses the unified training config (``train_full.yaml``) to train CNN-Transformer
classifier models.  Supports sequential, parallel, and mixed training modes.
"""

from __future__ import annotations

import warnings

from eemoclas.cli.utils import console, print_cli_success


def run_training(
    config_path: str,
    model_names: list[str] | None = None,
    mode: str = "sequential",
    parallel_models: list[str] | None = None,
    overrides: list[str] | None = None,
    experiment_name: str | None = None,
    verbose: bool = True,
    resume: str | None = None,
    fresh: bool = False,
) -> None:
    """Main training entry point using unified config.

    Parameters
    ----------
    config_path:
        Path to a unified YAML config file.
    model_names:
        Optional list of model-group names to train.  When ``None`` all
        models from the config are trained.
    mode:
        ``"sequential"`` | ``"parallel"`` | ``"mixed"``.
    parallel_models:
        When *mode* is ``"mixed"``, the subset of *model_names* that
        should be trained in parallel.
    overrides:
        Optional list of dotted-key ``key=value`` override strings.
    experiment_name:
        Override the experiment name from the config.
    verbose:
        When ``True`` print detailed Rich output.
    """
    from eemoclas.config.loader import load_config
    from eemoclas.config.overrides import apply_overrides
    from eemoclas.training.orchestrator import MultiModelTrainer
    from eemoclas.training.experiment import ExperimentManager

    # 1. Load config

    # Suppress UserWarnings (e.g. PyTorch scheduler deprecation, Transformer
    # enable_nested_tensor) so they don't break the Rich Live display.
    warnings.filterwarnings("ignore", category=UserWarning)
    config = load_config(config_path)

    if verbose:
        console.print(f"  Config loaded from [cyan]{config_path}[/cyan]")
        n_models = len(config.models)
        console.print(f"  Models in config: [cyan]{n_models}[/cyan]")

    # 2. Apply overrides
    if overrides:
        apply_overrides(config, overrides)
        if verbose:
            console.print(f"  Applied [cyan]{len(overrides)}[/cyan] override(s)")

    # 3. Override experiment name if provided
    if experiment_name:
        config.experiment.name = experiment_name

    # 4. Resolve model names
    if not model_names:
        model_names = config.model_names()

    if verbose:
        console.print(f"  Models to train: [cyan]{model_names}[/cyan]")
        console.print(f"  Mode: [cyan]{mode}[/cyan]")

    # 5. Create experiment manager
    exp_mgr = ExperimentManager(config.experiment)

    # 5b. Configure file logging
    from eemoclas.utils.logger import setup_experiment_logger
    setup_experiment_logger(
        "dglz.training",
        exp_mgr.training_log_path(),
        verbose=verbose,
    )

    # 6. Print config panel
    try:
        from eemoclas.utils.display import (
            print_training_config_panel,
            print_multi_model_summary,
        )
        print_training_config_panel(config.runtime_config_display_sections())
    except Exception:
        # Display helpers are optional; do not fail if Rich is missing
        pass

    # 7. Create and run orchestrator
    trainer = MultiModelTrainer(
        config=config,
        model_names=model_names,
        mode=mode,
        parallel_models=parallel_models or [],
        experiment_mgr=exp_mgr,
        verbose=verbose,
        fresh=fresh,
    )
    try:
        results = trainer.run()
    except KeyboardInterrupt:
        console.print("\n[yellow]训练已中断，正在清理资源...[/yellow]")
        raise SystemExit(130)

    # 8. Print results
    try:
        print_multi_model_summary(results)
    except Exception:
        pass

    console.print()
    print_cli_success("所有训练任务已完成")
