
"""
Tests for datalens.profiler — Profiler stats engine.
Coverage: NumericStats, CategoricalStats, DatetimeStats, TextStats,
          DatasetReport, warnings generation.
"""
import pytest
import pandas as pd
import numpy as np

from datalens.profiler import (
    Profiler, DatasetReport, ColumnReport,
    NumericStats, CategoricalStats, DatetimeStats, TextStats,
)
from datalens.detector import ColType


class TestDatasetReport:
    def test_returns_dataset_report(self, simple_dataset_report):
        assert isinstance(simple_dataset_report, DatasetReport)

    def test_shape_correct(self, simple_dataset_report, simple_df):
        assert simple_dataset_report.n_rows == len(simple_df)
        assert simple_dataset_report.n_cols == len(simple_df.columns)

    def test_all_columns_in_report(self, simple_dataset_report, simple_df):
        assert set(simple_dataset_report.columns.keys()) == set(simple_df.columns)

    def test_memory_mb_positive(self, simple_dataset_report):
        assert simple_dataset_report.memory_mb > 0

    def test_pct_complete_clean(self, simple_dataset_report):
        assert simple_dataset_report.pct_complete == pytest.approx(1.0)

    def test_pct_complete_dirty(self, profiler, dirty_df, detector):
        profiles = detector.detect_all(dirty_df)
        report = profiler.profile(dirty_df, profiles)
        assert report.pct_complete < 1.0

    def test_duplicates_counted(self, profiler, detector):
        df = pd.DataFrame({"x": [1, 1, 2, 3, 4, 5, 6, 7, 8, 9]})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        assert report.n_duplicates == 1

    def test_type_counts_correct(self, multi_dataset_report):
        assert multi_dataset_report.n_numeric >= 1
        assert multi_dataset_report.n_categorical >= 1
        assert multi_dataset_report.n_datetime >= 1

    def test_dataset_warnings_is_list(self, simple_dataset_report):
        assert isinstance(simple_dataset_report.dataset_warnings, list)


class TestNumericStats:
    @pytest.fixture(scope="class")
    def num_report(self, simple_dataset_report):
        for col, rep in simple_dataset_report.columns.items():
            if rep.numeric:
                return rep.numeric
        pytest.skip("No numeric column found")

    def test_mean_in_range(self, simple_dataset_report):
        for col, rep in simple_dataset_report.columns.items():
            if rep.numeric:
                assert rep.numeric.min <= rep.numeric.mean <= rep.numeric.max

    def test_median_in_range(self, simple_dataset_report):
        for col, rep in simple_dataset_report.columns.items():
            if rep.numeric:
                assert rep.numeric.min <= rep.numeric.median <= rep.numeric.max

    def test_std_non_negative(self, simple_dataset_report):
        for col, rep in simple_dataset_report.columns.items():
            if rep.numeric:
                assert rep.numeric.std >= 0

    def test_percentile_ordering(self, simple_dataset_report):
        for col, rep in simple_dataset_report.columns.items():
            if rep.numeric:
                ns = rep.numeric
                assert ns.p1 <= ns.p5 <= ns.p25 <= ns.p75 <= ns.p95 <= ns.p99

    def test_iqr_positive(self, simple_dataset_report):
        for col, rep in simple_dataset_report.columns.items():
            if rep.numeric:
                assert rep.numeric.iqr >= 0

    def test_outlier_pct_between_0_and_1(self, simple_dataset_report):
        for col, rep in simple_dataset_report.columns.items():
            if rep.numeric:
                assert 0.0 <= rep.numeric.pct_outliers <= 1.0

    def test_best_distribution_string(self, simple_dataset_report):
        for col, rep in simple_dataset_report.columns.items():
            if rep.numeric and len(simple_dataset_report.columns[col].sample_values) >= 10:
                assert isinstance(rep.numeric.best_distribution, str)

    def test_skewness_is_float(self, simple_dataset_report):
        for col, rep in simple_dataset_report.columns.items():
            if rep.numeric:
                assert isinstance(rep.numeric.skewness, float)

    def test_known_skewed_column(self, profiler, detector):
        """Log-normal data should show positive skewness."""
        np.random.seed(42)
        df = pd.DataFrame({"income": np.random.lognormal(10, 1.5, 200)})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        assert report.columns["income"].numeric.skewness > 0.5

    def test_zero_counting(self, profiler, detector):
        df = pd.DataFrame({"x": [0, 0, 0, 1, 2, 3, 4, 5, 6, 7]})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        assert report.columns["x"].numeric.n_zeros == 3

    def test_negative_counting(self, profiler, detector):
        df = pd.DataFrame({"x": [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6]})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        assert report.columns["x"].numeric.n_negative == 3


class TestCategoricalStats:
    def test_n_unique_correct(self, profiler, detector):
        df = pd.DataFrame({"city": ["A", "B", "C", "A", "B"] * 4})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        assert report.columns["city"].categorical.n_unique == 3

    def test_top_value_correct(self, profiler, detector):
        df = pd.DataFrame({"city": ["Delhi"] * 10 + ["Mumbai"] * 5 + ["Pune"] * 3})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        assert report.columns["city"].categorical.top_value == "Delhi"

    def test_top_pct_between_0_and_1(self, profiler, detector):
        df = pd.DataFrame({"x": ["A"] * 8 + ["B"] * 2})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        assert 0.0 <= report.columns["x"].categorical.top_pct <= 1.0

    def test_entropy_non_negative(self, profiler, detector):
        df = pd.DataFrame({"x": ["A", "B", "C", "A", "B", "C", "A", "B", "C", "A"]})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        assert report.columns["x"].categorical.entropy >= 0

    def test_rare_values_detected(self, profiler, detector):
        df = pd.DataFrame({"x": ["A"] * 90 + ["B"] * 5 + ["C"] * 3 + ["D"] * 2})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        # B, C, D are < 1% when n=100
        cs = report.columns["x"].categorical
        assert isinstance(cs.rare_values, list)

    def test_value_counts_top10(self, profiler, detector):
        df = pd.DataFrame({"x": list("ABCDEFGHIJKLMNOPQRST") * 5})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        assert len(report.columns["x"].categorical.value_counts) <= 10


class TestDatetimeStats:
    def test_date_range_computed(self, profiler, detector):
        df = pd.DataFrame({"date": pd.date_range("2020-01-01", periods=10)})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        ds = report.columns["date"].datetime
        assert ds.range_days == 9

    def test_min_max_dates(self, profiler, detector):
        df = pd.DataFrame({"date": pd.date_range("2022-06-01", periods=5)})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        ds = report.columns["date"].datetime
        assert ds.min_date == "2022-06-01"
        assert ds.max_date == "2022-06-05"

    def test_future_dates_detected(self, profiler, detector):
        future = pd.date_range("2030-01-01", periods=5)
        past   = pd.date_range("2020-01-01", periods=5)
        df = pd.DataFrame({"date": list(past) + list(future)})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        assert report.columns["date"].datetime.has_future_dates is True


class TestTextStats:
    def test_avg_length_positive(self, multi_dataset_report):
        for col, rep in multi_dataset_report.columns.items():
            if rep.text:
                assert rep.text.avg_length > 0

    def test_word_count_positive(self, multi_dataset_report):
        for col, rep in multi_dataset_report.columns.items():
            if rep.text:
                assert rep.text.avg_word_count > 0

    def test_min_max_length(self, multi_dataset_report):
        for col, rep in multi_dataset_report.columns.items():
            if rep.text:
                assert rep.text.min_length <= rep.text.max_length


class TestWarnings:
    def test_high_null_warning_generated(self, profiler, detector):
        df = pd.DataFrame({
            "x": [None] * 40 + list(range(60)),
        })
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        warnings = report.columns["x"].warnings
        assert any("null" in w.lower() or "missing" in w.lower() for w in warnings)

    def test_outlier_warning_generated(self, profiler, detector):
        normal = list(range(90))
        outliers = [10000, 20000, 30000, 40000, 50000,
                    60000, 70000, 80000, 90000, 100000]
        df = pd.DataFrame({"x": normal + outliers})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        warnings = report.columns["x"].warnings
        assert any("outlier" in w.lower() for w in warnings)

    def test_duplicate_warning_at_dataset_level(self, profiler, detector):
        df = pd.DataFrame({"x": [1] * 50 + list(range(50))})
        profiles = detector.detect_all(df)
        report = profiler.profile(df, profiles)
        assert any("duplicate" in w.lower() for w in report.dataset_warnings)