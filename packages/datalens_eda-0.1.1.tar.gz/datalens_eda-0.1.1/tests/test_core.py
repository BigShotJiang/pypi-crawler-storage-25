"""
Tests for datalens.core — DataLens main class and AnalysisResult container.
Coverage: analyze(), target validation, file loading, result fields.
"""
import pytest
import pandas as pd
import numpy as np

from datalens import DataLens, analyze
from datalens.core import AnalysisResult
from datalens.exceptions import ColumnNotFoundError, EmptyDataError


class TestAnalyzeBasic:
    def test_returns_analysis_result(self, lens, simple_df):
        result = lens.analyze(simple_df, verbose=False)
        assert isinstance(result, AnalysisResult)

    def test_shape_matches_input(self, lens, simple_df):
        result = lens.analyze(simple_df, verbose=False)
        assert result.shape == simple_df.shape

    def test_profiles_all_columns(self, lens, simple_df):
        result = lens.analyze(simple_df, verbose=False)
        assert set(result.profiles.keys()) == set(simple_df.columns)

    def test_df_stored_in_result(self, lens, simple_df):
        result = lens.analyze(simple_df, verbose=False)
        assert isinstance(result.df, pd.DataFrame)
        assert result.df.shape == simple_df.shape

    def test_module_level_shortcut(self, simple_df):
        result = analyze(simple_df, verbose=False)
        assert isinstance(result, AnalysisResult)

    def test_multiple_calls_independent(self, lens, simple_df, dirty_df):
        r1 = lens.analyze(simple_df, verbose=False)
        r2 = lens.analyze(dirty_df, verbose=False)
        assert r1.shape != r2.shape


class TestResultFields:
    def test_memory_mb_positive(self, simple_analysis):
        assert simple_analysis.memory_mb > 0

    def test_pct_complete_between_0_and_1(self, simple_analysis):
        assert 0.0 <= simple_analysis.pct_complete <= 1.0

    def test_clean_data_fully_complete(self, lens, simple_df):
        result = lens.analyze(simple_df, verbose=False)
        assert result.pct_complete == pytest.approx(1.0)

    def test_dirty_data_not_complete(self, lens, dirty_df):
        result = lens.analyze(dirty_df, verbose=False)
        assert result.pct_complete < 1.0

    def test_duplicates_detected(self, lens):
        df = pd.DataFrame({"a": [1, 1, 2, 3, 3, 4, 5, 6, 7, 8]})
        result = lens.analyze(df, verbose=False)
        assert result.n_duplicates == 2

    def test_no_duplicates_in_clean_data(self, simple_analysis):
        assert simple_analysis.n_duplicates == 0

    def test_load_time_recorded(self, simple_analysis):
        assert simple_analysis.load_time_s >= 0.0

    def test_repr_is_informative(self, simple_analysis):
        r = repr(simple_analysis)
        assert "rows" in r
        assert "cols" in r


class TestTargetValidation:
    def test_valid_target_accepted(self, lens, simple_df):
        result = lens.analyze(simple_df, target="active", verbose=False)
        assert isinstance(result, AnalysisResult)

    def test_invalid_target_raises(self, lens, simple_df):
        with pytest.raises(ColumnNotFoundError):
            lens.analyze(simple_df, target="nonexistent_col", verbose=False)

    def test_error_message_shows_column_name(self, lens, simple_df):
        with pytest.raises(ColumnNotFoundError) as exc:
            lens.analyze(simple_df, target="ghost_col", verbose=False)
        assert "ghost_col" in str(exc.value)

    def test_error_message_shows_available_cols(self, lens, simple_df):
        with pytest.raises(ColumnNotFoundError) as exc:
            lens.analyze(simple_df, target="ghost_col", verbose=False)
        assert any(col in str(exc.value) for col in simple_df.columns)


class TestFileLoading:
    def test_analyze_csv_file(self, lens, csv_file, simple_df):
        result = lens.analyze(csv_file, verbose=False)
        assert result.shape[1] == simple_df.shape[1]

    def test_analyze_excel_file(self, lens, excel_file, simple_df):
        result = lens.analyze(excel_file, verbose=False)
        assert result.shape[1] == simple_df.shape[1]

    def test_analyze_parquet_file(self, lens, parquet_file, simple_df):
        result = lens.analyze(parquet_file, verbose=False)
        assert result.shape[1] == simple_df.shape[1]

    def test_analyze_json_file(self, lens, json_file, simple_df):
        result = lens.analyze(json_file, verbose=False)
        assert result.shape[1] == simple_df.shape[1]


class TestSamplingIntegration:
    def test_large_df_auto_sampled(self, lens, large_df):
        from datalens.config import config
        result = lens.analyze(large_df, verbose=False)
        assert result.shape[0] <= config.sampling.max_rows

    def test_sampling_disabled(self, lens, large_df):
        result = lens.analyze(large_df, sample=False, verbose=False)
        assert result.shape[0] == len(large_df)


class TestEdgeCases:
    def test_single_column_df(self, lens):
        df = pd.DataFrame({"value": range(10)})
        result = lens.analyze(df, verbose=False)
        assert result.shape[1] == 1

    def test_all_null_column_handled(self, lens):
        df = pd.DataFrame({
            "good":    [1, 2, 3, 4, 5],
            "all_null": [None, None, None, None, None],
        })
        result = lens.analyze(df, verbose=False)
        assert "all_null" in result.profiles

    def test_wide_dataframe(self, lens):
        np.random.seed(5)
        df = pd.DataFrame(
            np.random.randn(20, 30),
            columns=[f"f{i}" for i in range(30)]
        )
        result = lens.analyze(df, verbose=False)
        assert result.shape[1] == 30