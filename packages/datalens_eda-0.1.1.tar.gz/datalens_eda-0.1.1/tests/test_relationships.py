"""
Tests for datalens.relationships — RelationshipEngine.
Coverage: Pearson, Spearman, Cramér's V, Eta, VIF, multicollinearity detection.
"""
import pytest
import pandas as pd
import numpy as np

from datalens.relationships import (
    RelationshipEngine, RelationshipReport,
    PairCorrelation, VIFResult,
)
from datalens.detector import ColType


class TestRelationshipReportBasic:
    def test_returns_report(self, relationship_engine, simple_df, simple_profiles):
        report = relationship_engine.analyze(simple_df, simple_profiles)
        assert isinstance(report, RelationshipReport)

    def test_correlations_is_list(self, relationship_engine, simple_df, simple_profiles):
        report = relationship_engine.analyze(simple_df, simple_profiles)
        assert isinstance(report.correlations, list)

    def test_vif_results_is_list(self, relationship_engine, simple_df, simple_profiles):
        report = relationship_engine.analyze(simple_df, simple_profiles)
        assert isinstance(report.vif_results, list)

    def test_warnings_is_list(self, relationship_engine, simple_df, simple_profiles):
        report = relationship_engine.analyze(simple_df, simple_profiles)
        assert isinstance(report.warnings, list)


class TestPearsonCorrelation:
    def test_perfect_positive_correlation(self, relationship_engine, detector):
        x = np.arange(1, 51, dtype=float)
        df = pd.DataFrame({"x": x, "y": x * 2 + 5})
        profiles = detector.detect_all(df)
        report = relationship_engine.analyze(df, profiles)
        pair = report.correlations[0]
        assert abs(pair.value) > 0.99

    def test_perfect_negative_correlation(self, relationship_engine, detector):
        x = np.arange(1, 51, dtype=float)
        df = pd.DataFrame({"x": x, "y": -x + 100})
        profiles = detector.detect_all(df)
        report = relationship_engine.analyze(df, profiles)
        pair = report.correlations[0]
        assert pair.value < -0.99

    def test_zero_correlation_noise(self, relationship_engine, detector):
        np.random.seed(0)
        df = pd.DataFrame({
            "a": np.random.randn(100),
            "b": np.random.randn(100),
        })
        profiles = detector.detect_all(df)
        report = relationship_engine.analyze(df, profiles)
        assert len(report.correlations) > 0
        pair = report.correlations[0]
        assert abs(pair.value) < 0.5

    def test_method_is_pearson_or_spearman(self, relationship_engine, detector):
        np.random.seed(1)
        x = np.random.randn(50)
        df = pd.DataFrame({"a": x, "b": x + np.random.randn(50) * 0.3})
        profiles = detector.detect_all(df)
        report = relationship_engine.analyze(df, profiles)
        for pair in report.correlations:
            assert pair.method in ("pearson", "spearman")


class TestCramersV:
    def test_identical_categories_high_v(self, relationship_engine, detector):
        cats = ["A", "B", "C", "D"] * 25
        df = pd.DataFrame({"x": cats, "y": cats})
        profiles = detector.detect_all(df)
        report = relationship_engine.analyze(df, profiles)
        assert len(report.correlations) > 0
        pair = report.correlations[0]
        assert pair.method == "cramers_v"
        assert pair.value > 0.9

    def test_independent_categories_low_v(self, relationship_engine, detector):
        np.random.seed(42)
        df = pd.DataFrame({
            "x": np.random.choice(["A", "B", "C"], 100),
            "y": np.random.choice(["X", "Y", "Z"], 100),
        })
        profiles = detector.detect_all(df)
        report = relationship_engine.analyze(df, profiles)
        for pair in report.correlations:
            if pair.method == "cramers_v":
                assert pair.value < 0.5


class TestEtaCorrelation:
    def test_eta_used_for_num_cat_pair(self, relationship_engine, detector):
        np.random.seed(5)
        df = pd.DataFrame({
            "score":   [80, 85, 90, 60, 65, 70, 50, 55, 58, 88] * 5,
            "group":   (["A"] * 5 + ["B"] * 5) * 5,
        })
        profiles = detector.detect_all(df)
        report = relationship_engine.analyze(df, profiles)
        eta_pairs = [p for p in report.correlations if p.method == "eta"]
        assert len(eta_pairs) > 0


class TestStrengthLabels:
    @pytest.mark.parametrize("value,expected", [
        (0.05, "negligible"),
        (0.20, "weak"),
        (0.40, "moderate"),
        (0.60, "strong"),
        (0.80, "very strong"),
    ])
    def test_strength_label(self, value, expected):
        from datalens.relationships import _strength_label
        assert _strength_label(value) == expected

    def test_direction_positive(self):
        from datalens.relationships import _direction_label
        assert _direction_label(0.5) == "positive"

    def test_direction_negative(self):
        from datalens.relationships import _direction_label
        assert _direction_label(-0.5) == "negative"

    def test_direction_none(self):
        from datalens.relationships import _direction_label
        assert _direction_label(0.02) == "none"


class TestVIF:
    def test_vif_computed_for_numeric(self, relationship_engine, detector):
        np.random.seed(10)
        df = pd.DataFrame({
            "a": np.random.randn(50),
            "b": np.random.randn(50),
            "c": np.random.randn(50),
        })
        profiles = detector.detect_all(df)
        report = relationship_engine.analyze(df, profiles)
        assert len(report.vif_results) == 3

    def test_vif_values_positive(self, relationship_engine, detector):
        np.random.seed(10)
        df = pd.DataFrame({
            "x": np.random.randn(50),
            "y": np.random.randn(50),
        })
        profiles = detector.detect_all(df)
        report = relationship_engine.analyze(df, profiles)
        for v in report.vif_results:
            assert v.vif > 0

    def test_high_vif_flagged(self, relationship_engine, detector):
        """Two nearly identical columns should produce high VIF."""
        np.random.seed(7)
        base = np.random.randn(100)
        df = pd.DataFrame({
            "a": base,
            "b": base + np.random.randn(100) * 0.01,
            "c": np.random.randn(100),
        })
        profiles = detector.detect_all(df)
        report = relationship_engine.analyze(df, profiles)
        high_vif = [v for v in report.vif_results if v.vif > 10]
        assert len(high_vif) > 0

    def test_vif_warning_labels_correct(self, relationship_engine, detector):
        np.random.seed(3)
        df = pd.DataFrame({
            "a": np.random.randn(50),
            "b": np.random.randn(50),
        })
        profiles = detector.detect_all(df)
        report = relationship_engine.analyze(df, profiles)
        for v in report.vif_results:
            assert v.warning in ("", "moderate", "high", "extreme")


class TestTargetCorrelations:
    def test_target_correlations_populated(self, relationship_engine, regression_df, detector):
        profiles = detector.detect_all(regression_df)
        report = relationship_engine.analyze(regression_df, profiles, target="target")
        assert len(report.target_correlations) > 0

    def test_target_in_all_target_pairs(self, relationship_engine, regression_df, detector):
        profiles = detector.detect_all(regression_df)
        report = relationship_engine.analyze(regression_df, profiles, target="target")
        for pair in report.target_correlations:
            assert "target" in (pair.col_a, pair.col_b)

    def test_target_correlations_sorted_descending(self, relationship_engine, regression_df, detector):
        profiles = detector.detect_all(regression_df)
        report = relationship_engine.analyze(regression_df, profiles, target="target")
        values = [abs(p.value) for p in report.target_correlations]
        assert values == sorted(values, reverse=True)