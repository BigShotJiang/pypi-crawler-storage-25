"""
Tests for datalens.viz — ChartSelector and chart builders (Phase 3 stubs).
These tests validate the chart selector logic which is chart-type-agnostic.
Full chart rendering tests run in Phase 3 when charts.py is complete.
"""
import pytest
import pandas as pd
import numpy as np

from datalens.detector import ColType


class TestChartSelectorImport:
    def test_chart_selector_importable(self):
        try:
            from datalens.viz.chart_selector import ChartSelector
            assert ChartSelector is not None
        except ImportError:
            pytest.skip("viz module not yet built (Phase 3)")


class TestChartSelectorLogic:
    @pytest.fixture
    def selector(self):
        try:
            from datalens.viz.chart_selector import ChartSelector
            return ChartSelector()
        except ImportError:
            pytest.skip("Phase 3 not yet implemented")

    def test_numeric_col_gets_histogram(self, selector):
        chart = selector.select_for_column(ColType.NUMERIC_CONTINUOUS, n_unique=100)
        assert "hist" in chart.lower() or "distribution" in chart.lower()

    def test_categorical_low_gets_bar(self, selector):
        chart = selector.select_for_column(ColType.CATEGORICAL_LOW, n_unique=5)
        assert "bar" in chart.lower() or "count" in chart.lower()

    def test_datetime_gets_line(self, selector):
        chart = selector.select_for_column(ColType.DATETIME, n_unique=50)
        assert "line" in chart.lower() or "time" in chart.lower()

    def test_boolean_gets_pie_or_bar(self, selector):
        chart = selector.select_for_column(ColType.BOOLEAN, n_unique=2)
        assert any(c in chart.lower() for c in ("pie", "bar", "donut"))

    def test_num_num_pair_gets_scatter(self, selector):
        chart = selector.select_for_pair(
            ColType.NUMERIC_CONTINUOUS, ColType.NUMERIC_CONTINUOUS
        )
        assert "scatter" in chart.lower()

    def test_cat_cat_pair_gets_heatmap(self, selector):
        chart = selector.select_for_pair(
            ColType.CATEGORICAL_LOW, ColType.CATEGORICAL_LOW
        )
        assert any(c in chart.lower() for c in ("heat", "crosstab", "bar"))

    def test_num_cat_pair_gets_box(self, selector):
        chart = selector.select_for_pair(
            ColType.NUMERIC_CONTINUOUS, ColType.CATEGORICAL_LOW
        )
        assert any(c in chart.lower() for c in ("box", "violin", "strip"))


class TestThemesImport:
    def test_themes_importable(self):
        try:
            from datalens.viz.themes import get_theme
            assert get_theme is not None
        except ImportError:
            pytest.skip("Phase 3 not yet built")

    def test_light_theme_returns_dict(self):
        try:
            from datalens.viz.themes import get_theme
            theme = get_theme("light")
            assert isinstance(theme, dict)
        except ImportError:
            pytest.skip("Phase 3 not yet built")

    def test_dark_theme_returns_dict(self):
        try:
            from datalens.viz.themes import get_theme
            theme = get_theme("dark")
            assert isinstance(theme, dict)
        except ImportError:
            pytest.skip("Phase 3 not yet built")


class TestChartsImport:
    def test_charts_module_importable(self):
        try:
            from datalens.viz import charts
            assert charts is not None
        except ImportError:
            pytest.skip("Phase 3 not yet built")