"""
Tests for datalens.anomaly — AnomalyDetector 3-method outlier detection.
Coverage: Z-score, IQR, Isolation Forest, consensus, severity labels.
"""
import pytest
import pandas as pd
import numpy as np

from datalens.anomaly import AnomalyDetector, AnomalyReport, OutlierResult, ColumnAnomalyReport
from datalens.detector import ColType


class TestAnomalyReportBasic:
    def test_returns_report(self, anomaly_detector, simple_df, simple_profiles):
        report = anomaly_detector.detect(simple_df, simple_profiles)
        assert isinstance(report, AnomalyReport)

    def test_only_numeric_cols_analysed(self, anomaly_detector, multi_type_df, multi_profiles):
        report = anomaly_detector.detect(multi_type_df, multi_profiles)
        for col in report.columns:
            assert multi_profiles[col].col_type in (
                ColType.NUMERIC_CONTINUOUS, ColType.NUMERIC_DISCRETE
            )

    def test_warnings_is_list(self, anomaly_detector, simple_df, simple_profiles):
        report = anomaly_detector.detect(simple_df, simple_profiles)
        assert isinstance(report.warnings, list)

    def test_worst_columns_is_list(self, anomaly_detector, simple_df, simple_profiles):
        report = anomaly_detector.detect(simple_df, simple_profiles)
        assert isinstance(report.worst_columns, list)


class TestCleanData:
    def test_clean_data_verdict_clean(self, anomaly_detector, detector):
        np.random.seed(42)
        df = pd.DataFrame({"x": np.random.normal(50, 5, 200)})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        assert report.columns["x"].verdict in ("clean", "mild")

    def test_no_outliers_in_uniform_data(self, anomaly_detector, detector):
        df = pd.DataFrame({"x": list(range(100))})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        assert report.columns["x"].n_consensus < 5


class TestZScoreMethod:
    def test_extreme_outliers_detected_by_zscore(self, anomaly_detector, detector):
        normal = list(np.random.normal(50, 2, 90))
        extreme = [500, -500, 1000, -1000, 9999]
        df = pd.DataFrame({"x": normal + extreme})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        assert report.columns["x"].zscore.n_outliers >= 3

    def test_zscore_bounds_computed(self, anomaly_detector, detector):
        df = pd.DataFrame({"x": list(range(50))})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        zr = report.columns["x"].zscore
        assert zr.lower_bound is not None
        assert zr.upper_bound is not None
        assert zr.lower_bound < zr.upper_bound

    def test_zscore_method_label(self, anomaly_detector, detector):
        df = pd.DataFrame({"x": list(range(20))})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        assert report.columns["x"].zscore.method == "zscore"


class TestIQRMethod:
    def test_iqr_detects_outliers(self, anomaly_detector, detector):
        q_data  = list(np.random.normal(50, 3, 90))
        outliers = [300, 400, 500, 600, 700]
        df = pd.DataFrame({"x": q_data + outliers})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        assert report.columns["x"].iqr.n_outliers >= 3

    def test_iqr_bounds_ordered(self, anomaly_detector, detector):
        df = pd.DataFrame({"x": list(range(50))})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        ir = report.columns["x"].iqr
        assert ir.lower_bound < ir.upper_bound

    def test_iqr_pct_between_0_and_1(self, anomaly_detector, detector):
        df = pd.DataFrame({"x": list(range(50)) + [10000]})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        assert 0.0 <= report.columns["x"].iqr.pct_outliers <= 1.0

    def test_custom_multiplier(self, detector):
        """Wider fence (3.0) should catch fewer outliers than default (1.5)."""
        data = list(np.random.normal(50, 3, 90)) + [200, 300, 400, 500, 600]
        df   = pd.DataFrame({"x": data})
        profiles = detector.detect_all(df)

        det_tight = AnomalyDetector(iqr_multiplier=1.5)
        det_wide  = AnomalyDetector(iqr_multiplier=3.0)

        r_tight = det_tight.detect(df, profiles)
        r_wide  = det_wide.detect(df, profiles)

        assert (r_tight.columns["x"].iqr.n_outliers >=
                r_wide.columns["x"].iqr.n_outliers)


class TestIsolationForest:
    def test_isolation_runs_on_sufficient_data(self, anomaly_detector, detector):
        np.random.seed(0)
        df = pd.DataFrame({"x": np.random.randn(100).tolist() + [50, 60, 70, 80, 90]})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        # Isolation Forest should produce a result
        assert report.columns["x"].isolation is not None

    def test_isolation_skipped_small_data(self, anomaly_detector, detector):
        df = pd.DataFrame({"x": list(range(8))})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        # too few rows — should be None
        assert report.columns["x"].isolation is None

    def test_isolation_method_label(self, anomaly_detector, detector):
        np.random.seed(1)
        df = pd.DataFrame({"x": np.random.randn(50).tolist() + [100, 200]})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        if report.columns["x"].isolation:
            assert report.columns["x"].isolation.method == "isolation_forest"


class TestConsensusAndSeverity:
    def test_severe_outliers_flagged(self, anomaly_detector, detector):
        normal   = list(np.random.normal(0, 1, 80))
        outliers = [100 + i * 10 for i in range(20)]
        df = pd.DataFrame({"x": normal + outliers})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        assert report.columns["x"].verdict in ("mild", "severe")

    def test_worst_columns_sorted(self, anomaly_detector, detector):
        np.random.seed(5)
        df = pd.DataFrame({
            "clean":  np.random.normal(0, 1, 100),
            "dirty":  np.random.normal(0, 1, 100).tolist() + [1000] * 0,
        })
        df.loc[0:10, "dirty"] = 9999
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        if len(report.worst_columns) >= 2:
            idx0 = report.summary.get(report.worst_columns[0], 0)
            idx1 = report.summary.get(report.worst_columns[1], 0)
            assert idx0 >= idx1

    def test_severity_labels_valid(self, anomaly_detector, detector):
        df = pd.DataFrame({"x": list(range(50)) + [10000]})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        valid = {"low", "medium", "high", "critical"}
        for method_r in [
            report.columns["x"].zscore,
            report.columns["x"].iqr,
        ]:
            if method_r:
                assert method_r.severity in valid

    def test_recommendation_populated(self, anomaly_detector, detector):
        normal   = list(np.random.normal(50, 2, 80))
        outliers = [500] * 20
        df = pd.DataFrame({"x": normal + outliers})
        profiles = detector.detect_all(df)
        report = anomaly_detector.detect(df, profiles)
        assert len(report.columns["x"].recommendation) > 10