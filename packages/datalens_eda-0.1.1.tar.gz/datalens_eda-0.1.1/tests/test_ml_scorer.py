"""
Tests for datalens.ml_scorer — MLScorer readiness engine.
Coverage: score ranges, grade labels, all 6 dimensions, target analysis.
"""
import pytest
import pandas as pd
import numpy as np

from datalens.ml_scorer import MLScorer, MLReadinessScore


class TestMLScorerBasic:
    def test_returns_score_object(self, ml_scorer, simple_df, simple_profiles):
        score = ml_scorer.score(simple_df, simple_profiles)
        assert isinstance(score, MLReadinessScore)

    def test_overall_between_0_and_100(self, ml_scorer, simple_df, simple_profiles):
        score = ml_scorer.score(simple_df, simple_profiles)
        assert 0 <= score.overall <= 100

    def test_grade_is_valid(self, ml_scorer, simple_df, simple_profiles):
        score = ml_scorer.score(simple_df, simple_profiles)
        assert score.grade in ("A", "B", "C", "D", "F")

    def test_verdict_is_valid(self, ml_scorer, simple_df, simple_profiles):
        score = ml_scorer.score(simple_df, simple_profiles)
        assert score.verdict in ("ready", "needs_work", "not_ready")

    def test_breakdown_has_all_dimensions(self, ml_scorer, simple_df, simple_profiles):
        score = ml_scorer.score(simple_df, simple_profiles)
        expected_keys = {
            "completeness", "size", "feature_quality",
            "target_quality", "encoding_ready", "leakage_risk"
        }
        assert expected_keys == set(score.breakdown.keys())

    def test_breakdown_values_between_0_and_100(self, ml_scorer, simple_df, simple_profiles):
        score = ml_scorer.score(simple_df, simple_profiles)
        for k, v in score.breakdown.items():
            assert 0 <= v <= 100, f"Dimension '{k}' out of range: {v}"

    def test_recommendations_is_list(self, ml_scorer, simple_df, simple_profiles):
        score = ml_scorer.score(simple_df, simple_profiles)
        assert isinstance(score.recommendations, list)

    def test_penalties_is_list(self, ml_scorer, simple_df, simple_profiles):
        score = ml_scorer.score(simple_df, simple_profiles)
        assert isinstance(score.penalties, list)

    def test_bonuses_is_list(self, ml_scorer, simple_df, simple_profiles):
        score = ml_scorer.score(simple_df, simple_profiles)
        assert isinstance(score.bonuses, list)


class TestGradeBoundaries:
    @pytest.mark.parametrize("score,expected_grade", [
        (95, "A"), (85, "B"), (70, "C"), (55, "D"), (30, "F")
    ])
    def test_grade_from_score(self, score, expected_grade):
        assert MLScorer._grade(score) == expected_grade


class TestCompletenessScore:
    def test_complete_data_scores_high(self, ml_scorer, simple_df, simple_profiles):
        score = ml_scorer.score(simple_df, simple_profiles)
        assert score.breakdown["completeness"] >= 80

    def test_many_nulls_scores_low(self, ml_scorer, detector):
        df = pd.DataFrame({
            "a": [None] * 60 + list(range(40)),
            "b": list(range(100)),
        })
        profiles = detector.detect_all(df)
        score = ml_scorer.score(df, profiles)
        assert score.breakdown["completeness"] < 60


class TestSizeScore:
    def test_large_dataset_high_size_score(self, ml_scorer, detector):
        np.random.seed(1)
        df = pd.DataFrame({"x": np.random.randn(200_000), "y": np.random.randn(200_000)})
        profiles = detector.detect_all(df)
        score = ml_scorer.score(df, profiles)
        assert score.breakdown["size"] >= 90

    def test_tiny_dataset_low_size_score(self, ml_scorer, detector):
        df = pd.DataFrame({"a": range(10), "b": range(10)})
        profiles = detector.detect_all(df)
        score = ml_scorer.score(df, profiles)
        assert score.breakdown["size"] < 50

    def test_tiny_dataset_penalised(self, ml_scorer, detector):
        df = pd.DataFrame({"a": range(10), "b": range(10)})
        profiles = detector.detect_all(df)
        score = ml_scorer.score(df, profiles)
        assert any("row" in p.lower() or "small" in p.lower() for p in score.penalties)


class TestFeatureQuality:
    def test_id_cols_penalised(self, ml_scorer, detector):
        df = pd.DataFrame({
            "user_id": range(50),
            "feature": np.random.randn(50),
        })
        profiles = detector.detect_all(df)
        score = ml_scorer.score(df, profiles)
        assert any("id" in p.lower() for p in score.penalties)

    def test_constant_cols_penalised(self, ml_scorer, detector):
        df = pd.DataFrame({
            "x":    range(50),
            "const": [1] * 50,
        })
        profiles = detector.detect_all(df)
        score = ml_scorer.score(df, profiles)
        assert any("constant" in p.lower() for p in score.penalties)

    def test_good_features_bonus(self, ml_scorer, regression_df, detector):
        profiles = detector.detect_all(regression_df)
        score = ml_scorer.score(regression_df, profiles)
        assert score.breakdown["feature_quality"] >= 60


class TestTargetQuality:
    def test_no_target_penalised(self, ml_scorer, simple_df, simple_profiles):
        score = ml_scorer.score(simple_df, simple_profiles, target=None)
        assert any("target" in p.lower() for p in score.penalties)

    def test_clean_numeric_target_scores_high(self, ml_scorer, regression_df, detector):
        profiles = detector.detect_all(regression_df)
        score = ml_scorer.score(regression_df, profiles, target="target")
        assert score.breakdown["target_quality"] >= 70

    def test_imbalanced_target_penalised(self, ml_scorer, imbalanced_df, detector):
        profiles = detector.detect_all(imbalanced_df)
        score = ml_scorer.score(imbalanced_df, profiles, target="label")
        assert any("imbalance" in p.lower() or "minority" in p.lower()
                   for p in score.penalties)

    def test_target_analysis_populated(self, ml_scorer, regression_df, detector):
        profiles = detector.detect_all(regression_df)
        score = ml_scorer.score(regression_df, profiles, target="target")
        assert score.target_analysis.get("column") == "target"

    def test_classification_task_detected(self, ml_scorer, multi_type_df, multi_profiles):
        score = ml_scorer.score(multi_type_df, multi_profiles, target="churn")
        assert score.target_analysis.get("task") == "classification"

    def test_regression_task_detected(self, ml_scorer, regression_df, detector):
        profiles = detector.detect_all(regression_df)
        score = ml_scorer.score(regression_df, profiles, target="target")
        assert score.target_analysis.get("task") == "regression"


class TestLeakageDetection:
    def test_near_perfect_correlation_flagged(self, ml_scorer, detector):
        np.random.seed(42)
        x = np.random.randn(100)
        df = pd.DataFrame({
            "feature":      x,
            "leaked_feature": x + np.random.randn(100) * 0.001,
            "target":       x * 2,
        })
        profiles = detector.detect_all(df)

        # mock top_correlations with a near-perfect pair
        from datalens.relationships import PairCorrelation
        fake_corr = [
            PairCorrelation("leaked_feature", "target", "pearson",
                            0.999, 0.0, True, "very strong", "positive")
        ]
        score = ml_scorer.score(df, profiles, target="target",
                                top_correlations=fake_corr)
        assert any("leakage" in p.lower() for p in score.penalties)