"""
Tests for datalens.cli — command line interface.
Coverage: analyze command, version command, serve command, error handling.
"""
import pytest
import sys
from unittest.mock import patch, MagicMock
from pathlib import Path

from datalens.cli import main, cmd_analyze, cmd_version, cmd_serve


class TestCLIVersion:
    def test_version_command_runs(self, capsys):
        args = MagicMock()
        cmd_version(args)
        captured = capsys.readouterr()
        assert len(captured.out) > 0

    def test_version_contains_number(self, capsys):
        args = MagicMock()
        cmd_version(args)
        captured = capsys.readouterr()
        import re
        assert re.search(r"\d+\.\d+\.\d+", captured.out)

    def test_version_contains_datalens(self, capsys):
        args = MagicMock()
        cmd_version(args)
        captured = capsys.readouterr()
        assert "DataLens" in captured.out


class TestCLIAnalyze:
    def test_analyze_valid_csv(self, capsys, csv_file):
        args = MagicMock()
        args.file = str(csv_file)
        args.html = False
        cmd_analyze(args)
        captured = capsys.readouterr()
        assert len(captured.out) > 0

    def test_analyze_missing_file_exits_with_code_1(self, capsys):
        args = MagicMock()
        args.file = "/nonexistent/path/data.csv"
        args.html = False
        with pytest.raises(SystemExit) as exc:
            cmd_analyze(args)
        assert exc.value.code == 1

    def test_analyze_missing_file_shows_error_message(self, capsys):
        args = MagicMock()
        args.file = "/nonexistent/file.csv"
        args.html = False
        with pytest.raises(SystemExit):
            cmd_analyze(args)
        captured = capsys.readouterr()
        assert "not found" in captured.out.lower()

    def test_analyze_with_html_flag(self, capsys, csv_file, tmp_path):
        args = MagicMock()
        args.file  = str(csv_file)
        args.html  = str(tmp_path / "out.html")
        cmd_analyze(args)
        assert Path(args.html).exists()

    def test_analyze_excel_file(self, capsys, excel_file):
        args = MagicMock()
        args.file = str(excel_file)
        args.html = False
        cmd_analyze(args)
        captured = capsys.readouterr()
        assert len(captured.out) > 0

    def test_analyze_parquet_file(self, capsys, parquet_file):
        args = MagicMock()
        args.file = str(parquet_file)
        args.html = False
        cmd_analyze(args)
        captured = capsys.readouterr()
        assert len(captured.out) > 0


class TestCLIServe:
    def test_serve_without_streamlit_exits(self, capsys):
        args = MagicMock()
        args.file = None
        with patch.dict("sys.modules", {"streamlit": None}):
            with pytest.raises(SystemExit) as exc:
                cmd_serve(args)
            assert exc.value.code == 1

    def test_serve_without_streamlit_shows_install_msg(self, capsys):
        args = MagicMock()
        args.file = None
        with patch.dict("sys.modules", {"streamlit": None}):
            with pytest.raises(SystemExit):
                cmd_serve(args)
        captured = capsys.readouterr()
        assert "pip" in captured.out.lower() or "install" in captured.out.lower()

    def test_serve_with_streamlit_calls_subprocess(self):
        args = MagicMock()
        args.file = None
        mock_st = MagicMock()
        with patch.dict("sys.modules", {"streamlit": mock_st}):
            with patch("subprocess.run") as mock_run:
                cmd_serve(args)
                mock_run.assert_called_once()

    def test_serve_passes_file_to_streamlit(self, csv_file):
        args = MagicMock()
        args.file = str(csv_file)
        mock_st = MagicMock()
        with patch.dict("sys.modules", {"streamlit": mock_st}):
            with patch("subprocess.run") as mock_run:
                cmd_serve(args)
                call_args = mock_run.call_args[0][0]
                assert str(csv_file) in call_args


class TestMainEntrypoint:
    def test_no_args_exits_zero(self):
        with patch("sys.argv", ["datalens"]):
            with pytest.raises(SystemExit) as exc:
                main()
            assert exc.value.code == 0

    def test_version_subcommand(self, capsys):
        with patch("sys.argv", ["datalens", "version"]):
            main()
        captured = capsys.readouterr()
        assert "DataLens" in captured.out

    def test_analyze_valid_file(self, capsys, csv_file):
        with patch("sys.argv", ["datalens", "analyze", str(csv_file)]):
            main()
        captured = capsys.readouterr()
        assert len(captured.out) > 0

    def test_analyze_bad_file_exits_1(self):
        with patch("sys.argv", ["datalens", "analyze", "/fake/path.csv"]):
            with pytest.raises(SystemExit) as exc:
                main()
            assert exc.value.code == 1

    def test_help_flag_exits_zero(self):
        with patch("sys.argv", ["datalens", "--help"]):
            with pytest.raises(SystemExit) as exc:
                main()
            assert exc.value.code == 0
