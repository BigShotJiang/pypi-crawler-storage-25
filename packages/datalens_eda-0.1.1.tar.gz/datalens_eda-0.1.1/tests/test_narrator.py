"""
Tests for datalens.narrator — RuleBasedNarrator and LLMNarrator.
Coverage: narrative fields, rule-based content, LLM fallback, factory function.
"""
import json
import pytest
import pandas as pd
import numpy as np
from unittest.mock import patch, MagicMock

from datalens.narrator import (
    RuleBasedNarrator, LLMNarrator, Narrative, get_narrator
)


class TestNarrativeObject:
    def test_returns_narrative(self, rule_narrator, simple_dataset_report):
        n = rule_narrator.narrate(simple_dataset_report)
        assert isinstance(n, Narrative)

    def test_dataset_summary_non_empty(self, rule_narrator, simple_dataset_report):
        n = rule_narrator.narrate(simple_dataset_report)
        assert len(n.dataset_summary) > 20

    def test_column_insights_all_columns(self, rule_narrator, simple_dataset_report):
        n = rule_narrator.narrate(simple_dataset_report)
        for col in simple_dataset_report.columns:
            assert col in n.column_insights

    def test_column_insights_non_empty(self, rule_narrator, simple_dataset_report):
        n = rule_narrator.narrate(simple_dataset_report)
        for col, insight in n.column_insights.items():
            assert len(insight) > 10, f"Insight for '{col}' is too short"

    def test_quality_story_non_empty(self, rule_narrator, simple_dataset_report):
        n = rule_narrator.narrate(simple_dataset_report)
        assert len(n.quality_story) > 10

    def test_top_findings_is_list(self, rule_narrator, simple_dataset_report):
        n = rule_narrator.narrate(simple_dataset_report)
        assert isinstance(n.top_findings, list)

    def test_generated_by_rule_based(self, rule_narrator, simple_dataset_report):
        n = rule_narrator.narrate(simple_dataset_report)
        assert n.generated_by == "rule_based"


class TestDatasetSummaryContent:
    def test_summary_mentions_row_count(self, rule_narrator, simple_dataset_report):
        n = rule_narrator.narrate(simple_dataset_report)
        assert str(simple_dataset_report.n_rows) in n.dataset_summary

    def test_summary_mentions_completeness(self, rule_narrator, simple_dataset_report):
        n = rule_narrator.narrate(simple_dataset_report)
        keywords = ["complete", "missing", "present"]
        assert any(kw in n.dataset_summary.lower() for kw in keywords)

    def test_small_dataset_described_as_small(self, rule_narrator, profiler, detector):
        df = pd.DataFrame({
            "x": range(10), "y": range(10), "z": range(10)
        })
        profiles = detector.detect_all(df)
        # manually create a tiny report
        rpt = profiler.profile(df, profiles)
        n = rule_narrator.narrate(rpt)
        assert "small" in n.dataset_summary.lower()

    def test_large_dataset_described_as_large(self, rule_narrator, profiler, detector):
        np.random.seed(0)
        df = pd.DataFrame({"x": np.random.randn(20_000), "y": np.random.randn(20_000)})
        profiles = detector.detect_all(df)
        rpt = profiler.profile(df, profiles)
        n = rule_narrator.narrate(rpt)
        assert "large" in n.dataset_summary.lower()


class TestMLReadinessText:
    def test_ml_text_generated_when_score_given(
        self, rule_narrator, simple_dataset_report, ml_scorer, simple_df, simple_profiles
    ):
        score = ml_scorer.score(simple_df, simple_profiles)
        n = rule_narrator.narrate(simple_dataset_report, ml_score=score)
        assert len(n.ml_readiness_text) > 10

    def test_ml_text_contains_score(
        self, rule_narrator, simple_dataset_report, ml_scorer, simple_df, simple_profiles
    ):
        score = ml_scorer.score(simple_df, simple_profiles)
        n = rule_narrator.narrate(simple_dataset_report, ml_score=score)
        assert str(int(score.overall)) in n.ml_readiness_text

    def test_ml_text_empty_without_score(self, rule_narrator, simple_dataset_report):
        n = rule_narrator.narrate(simple_dataset_report, ml_score=None)
        assert n.ml_readiness_text == ""


class TestTopFindings:
    def test_top_findings_not_empty(self, rule_narrator, simple_dataset_report):
        n = rule_narrator.narrate(simple_dataset_report)
        assert len(n.top_findings) > 0

    def test_top_findings_max_6(self, rule_narrator, simple_dataset_report):
        n = rule_narrator.narrate(simple_dataset_report)
        assert len(n.top_findings) <= 6

    def test_null_column_finding_mentioned(
        self, rule_narrator, profiler, detector
    ):
        df = pd.DataFrame({
            "x":    [1, 2, 3, 4, 5],
            "nulls": [None] * 5,
        })
        profiles = detector.detect_all(df)
        rpt = profiler.profile(df, profiles)
        n = rule_narrator.narrate(rpt)
        assert any("null" in f.lower() or "missing" in f.lower()
                   for f in n.top_findings)


class TestLLMNarratorFallback:
    def test_falls_back_on_api_failure(self, simple_dataset_report):
        narrator = LLMNarrator(provider="openai", api_key="fake_key")
        with patch("openai.OpenAI") as mock_cls:
            mock_cls.return_value.chat.completions.create.side_effect = Exception("API down")
            n = narrator.narrate(simple_dataset_report)
        assert isinstance(n, Narrative)
        assert n.generated_by == "rule_based"

    def test_openai_success_path(self, simple_dataset_report):
        narrator = LLMNarrator(provider="openai", api_key="fake_key")
        payload = json.dumps({
            "dataset_summary": "A clean dataset.",
            "column_insights": {},
            "quality_story":   "Good quality.",
            "ml_readiness_text": "Score 85/100.",
            "top_findings": ["Finding 1"],
        })
        mock_resp = MagicMock()
        mock_resp.choices[0].message.content = payload

        with patch("openai.OpenAI") as mock_cls:
            mock_cls.return_value.chat.completions.create.return_value = mock_resp
            n = narrator.narrate(simple_dataset_report)

        assert n.dataset_summary == "A clean dataset."
        assert n.generated_by == "openai"

    def test_ollama_fallback_on_error(self, simple_dataset_report):
        narrator = LLMNarrator(provider="ollama")
        with patch("requests.post", side_effect=Exception("Connection refused")):
            n = narrator.narrate(simple_dataset_report)
        assert isinstance(n, Narrative)


class TestGetNarratorFactory:
    def test_get_narrator_rule_based(self):
        n = get_narrator(ai_enabled=False)
        assert isinstance(n, RuleBasedNarrator)

    def test_get_narrator_llm(self):
        n = get_narrator(ai_enabled=True, provider="openai", api_key="x")
        assert isinstance(n, LLMNarrator)