"""
Tests for datalens.detector — ColumnDetector type inference engine.
Coverage: all 13 ColTypes, edge cases, pct_null, n_unique computation.
"""
import pytest
import pandas as pd
import numpy as np

from datalens.detector import ColumnDetector, ColType, ColProfile


class TestNumericTypes:
    def test_float_is_continuous(self, detector):
        df = pd.DataFrame({"price": [9.99, 19.49, 5.00, 99.95, 14.50]})
        p = detector.detect_all(df)["price"]
        assert p.col_type == ColType.NUMERIC_CONTINUOUS

    def test_integer_low_unique_is_discrete(self, detector):
        df = pd.DataFrame({"stars": [1, 2, 3, 4, 5, 1, 2, 3, 4, 5]})
        p = detector.detect_all(df)["stars"]
        assert p.col_type == ColType.NUMERIC_DISCRETE

    def test_large_integer_is_continuous(self, detector):
        df = pd.DataFrame({"salary": [50000, 60000, 75000, 82000, 91000,
                                       55000, 67000, 71000, 88000, 95000,
                                       52000, 63000, 78000, 84000, 93000,
                                       58000, 69000, 74000, 86000, 97000,
                                       53000, 64000, 79000, 85000, 94000]})
        p = detector.detect_all(df)["salary"]
        assert p.col_type == ColType.NUMERIC_CONTINUOUS

    def test_geospatial_lat_detected(self, detector, geo_df):
        p = detector.detect_all(geo_df)["latitude"]
        assert p.col_type == ColType.GEOSPATIAL_LAT

    def test_geospatial_lon_detected(self, detector, geo_df):
        p = detector.detect_all(geo_df)["longitude"]
        assert p.col_type == ColType.GEOSPATIAL_LON

    def test_column_named_lat_in_range(self, detector):
        df = pd.DataFrame({"lat": [28.6, 19.0, 18.5, 13.0, 22.5]})
        p = detector.detect_all(df)["lat"]
        assert p.col_type == ColType.GEOSPATIAL_LAT

    def test_id_integer_detected(self, detector):
        df = pd.DataFrame({"user_id": list(range(50))})
        p = detector.detect_all(df)["user_id"]
        assert p.col_type == ColType.ID_COLUMN

    def test_non_id_integer_not_flagged(self, detector):
        df = pd.DataFrame({"age": [25, 30, 35, 40, 45, 25, 30, 35, 40, 45]})
        p = detector.detect_all(df)["age"]
        assert p.col_type != ColType.ID_COLUMN


class TestCategoricalTypes:
    def test_low_cardinality_categorical(self, detector):
        df = pd.DataFrame({"city": ["Delhi", "Mumbai", "Pune", "Delhi", "Mumbai"] * 4})
        p = detector.detect_all(df)["city"]
        assert p.col_type == ColType.CATEGORICAL_LOW

    def test_high_cardinality_categorical(self, detector):
        df = pd.DataFrame({"sku": [f"PROD-{i:04d}" for i in range(100)]})
        p = detector.detect_all(df)["sku"]
        assert p.col_type == ColType.CATEGORICAL_HIGH

    def test_boolean_true_false(self, detector):
        df = pd.DataFrame({"flag": [True, False, True, True, False]})
        p = detector.detect_all(df)["flag"]
        assert p.col_type == ColType.BOOLEAN

    def test_boolean_yes_no_strings(self, detector):
        df = pd.DataFrame({"active": ["Yes", "No", "Yes", "Yes", "No"]})
        p = detector.detect_all(df)["active"]
        assert p.col_type == ColType.BOOLEAN

    def test_boolean_zero_one(self, detector):
        df = pd.DataFrame({"flag": [0, 1, 0, 1, 1, 0, 1, 0, 1, 0]})
        p = detector.detect_all(df)["flag"]
        assert p.col_type == ColType.BOOLEAN

    def test_string_id_column(self, detector):
        df = pd.DataFrame({"order_id": [f"ORD-{i}" for i in range(30)]})
        p = detector.detect_all(df)["order_id"]
        assert p.col_type == ColType.ID_COLUMN


class TestSpecialTypes:
    def test_email_detection(self, detector):
        df = pd.DataFrame({
            "email": ["a@b.com", "c@d.org", "e@f.in", "g@h.co", "i@j.net"]
        })
        p = detector.detect_all(df)["email"]
        assert p.col_type == ColType.EMAIL

    def test_url_detection(self, detector):
        df = pd.DataFrame({
            "website": [
                "https://google.com", "https://github.com",
                "http://example.org", "https://openai.com", "https://anthropic.com"
            ]
        })
        p = detector.detect_all(df)["website"]
        assert p.col_type == ColType.URL

    def test_text_column_long_strings(self, detector):
        df = pd.DataFrame({
            "review": [
                "This product is absolutely amazing and I loved every single bit of it",
                "Terrible experience I would never buy again from this terrible seller",
                "Good quality for the money fast delivery and very well packaged",
                "Average product nothing special but does the job fine enough",
                "Highly recommend this to anyone who is looking for a reliable option",
            ]
        })
        p = detector.detect_all(df)["review"]
        assert p.col_type == ColType.TEXT

    def test_constant_column(self, detector):
        df = pd.DataFrame({"version": ["v1.0"] * 10})
        p = detector.detect_all(df)["version"]
        assert p.col_type == ColType.CONSTANT

    def test_constant_numeric_column(self, detector):
        df = pd.DataFrame({"flag": [1] * 10})
        p = detector.detect_all(df)["flag"]
        assert p.col_type == ColType.CONSTANT

    def test_datetime_native_dtype(self, detector):
        df = pd.DataFrame({"ts": pd.date_range("2024-01-01", periods=5)})
        p = detector.detect_all(df)["ts"]
        assert p.col_type == ColType.DATETIME

    def test_datetime_string_parseable(self, detector):
        df = pd.DataFrame({
            "date": ["2024-01-01", "2024-02-15", "2024-03-20",
                     "2024-04-10", "2024-05-05"]
        })
        p = detector.detect_all(df)["date"]
        assert p.col_type == ColType.DATETIME


class TestProfileMetadata:
    def test_pct_null_correct(self, detector):
        df = pd.DataFrame({"x": [1.0, None, 3.0, None, 5.0]})
        p = detector.detect_all(df)["x"]
        assert p.pct_null == pytest.approx(0.4)

    def test_pct_null_zero_for_clean(self, detector, simple_df):
        profiles = detector.detect_all(simple_df)
        assert all(p.pct_null == 0.0 for p in profiles.values()
                   if simple_df[p.name].isna().sum() == 0)

    def test_n_unique_correct(self, detector):
        df = pd.DataFrame({"city": ["A", "B", "A", "C", "B"]})
        p = detector.detect_all(df)["city"]
        assert p.n_unique == 3

    def test_sample_values_populated(self, detector, simple_df):
        profiles = detector.detect_all(simple_df)
        for p in profiles.values():
            assert len(p.sample_values) > 0

    def test_pandas_dtype_recorded(self, detector, simple_df):
        profiles = detector.detect_all(simple_df)
        for p in profiles.values():
            assert isinstance(p.pandas_dtype, str)
            assert len(p.pandas_dtype) > 0

    def test_all_columns_profiled(self, detector, multi_type_df):
        profiles = detector.detect_all(multi_type_df)
        assert set(profiles.keys()) == set(multi_type_df.columns)

    def test_returns_col_profile_instances(self, detector, simple_df):
        profiles = detector.detect_all(simple_df)
        for p in profiles.values():
            assert isinstance(p, ColProfile)