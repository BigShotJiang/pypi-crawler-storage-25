"""
Tests for datalens.ingestor — DataIngestor universal file loader.
Coverage: CSV, Excel, Parquet, JSON, DataFrame, URL, sampling, validation.
"""
import io
import pytest
import pandas as pd
import numpy as np
from unittest.mock import patch, MagicMock

from datalens.ingestor import DataIngestor
from datalens.exceptions import (
    EmptyDataError,
    UnsupportedFormatError,
    InsufficientDataError,
)


# ── load from DataFrame ───────────────────────────────────────────────────────

class TestLoadDataFrame:
    def test_returns_dataframe(self, ingestor, simple_df):
        result = ingestor.load(simple_df)
        assert isinstance(result, pd.DataFrame)

    def test_shape_preserved(self, ingestor, simple_df):
        result = ingestor.load(simple_df)
        assert result.shape == simple_df.shape

    def test_columns_preserved(self, ingestor, simple_df):
        result = ingestor.load(simple_df)
        assert list(result.columns) == list(simple_df.columns)

    def test_does_not_mutate_original(self, ingestor, simple_df):
        original_len = len(simple_df)
        _ = ingestor.load(simple_df)
        assert len(simple_df) == original_len

    def test_index_is_reset(self, ingestor, simple_df):
        sliced = simple_df.iloc[5:15]
        result = ingestor.load(sliced)
        assert list(result.index) == list(range(len(result)))


# ── load from CSV ─────────────────────────────────────────────────────────────

class TestLoadCSV:
    def test_basic_csv_load(self, ingestor, csv_file, simple_df):
        result = ingestor.load(csv_file)
        assert result.shape == simple_df.shape

    def test_columns_match(self, ingestor, csv_file, simple_df):
        result = ingestor.load(csv_file)
        assert list(result.columns) == list(simple_df.columns)

    def test_csv_with_path_string(self, ingestor, csv_file):
        result = ingestor.load(str(csv_file))
        assert len(result) > 0

    def test_csv_with_custom_separator(self, ingestor, tmp_path, simple_df):
        p = tmp_path / "pipe_sep.csv"
        simple_df.to_csv(p, sep="|", index=False)
        result = ingestor.load(p, sep="|")
        assert result.shape == simple_df.shape

    def test_latin1_encoding_handled(self, ingestor, tmp_path):
        p = tmp_path / "latin.csv"
        df = pd.DataFrame({"name": ["André", "Müller", "Rémi", "José", "Björn"]})
        p.write_bytes(df.to_csv(index=False).encode("latin-1"))
        result = ingestor.load(p)
        assert len(result) == 5


# ── load from Excel ───────────────────────────────────────────────────────────

class TestLoadExcel:
    def test_basic_excel_load(self, ingestor, excel_file, simple_df):
        result = ingestor.load(excel_file)
        assert result.shape == simple_df.shape

    def test_excel_columns_match(self, ingestor, excel_file, simple_df):
        result = ingestor.load(excel_file)
        assert set(result.columns) == set(simple_df.columns)


# ── load from Parquet ─────────────────────────────────────────────────────────

class TestLoadParquet:
    def test_basic_parquet_load(self, ingestor, parquet_file, simple_df):
        result = ingestor.load(parquet_file)
        assert len(result) == len(simple_df)

    def test_parquet_dtypes_preserved(self, ingestor, tmp_path):
        df = pd.DataFrame({
            "int_col":   pd.array([1, 2, 3, 4, 5], dtype="int32"),
            "float_col": [1.1, 2.2, 3.3, 4.4, 5.5],
            "str_col":   ["a", "b", "c", "d", "e"],
        })
        p = tmp_path / "typed.parquet"
        df.to_parquet(p, index=False)
        result = ingestor.load(p)
        assert result["float_col"].dtype == float


# ── load from JSON ────────────────────────────────────────────────────────────

class TestLoadJSON:
    def test_basic_json_load(self, ingestor, json_file, simple_df):
        result = ingestor.load(json_file)
        assert result.shape == simple_df.shape

    def test_newline_json(self, ingestor, tmp_path):
        p = tmp_path / "ndjson.json"
        lines = [
            '{"a": 1, "b": "x"}',
            '{"a": 2, "b": "y"}',
            '{"a": 3, "b": "z"}',
            '{"a": 4, "b": "w"}',
            '{"a": 5, "b": "v"}',
        ]
        p.write_text("\n".join(lines))
        result = ingestor.load(p)
        assert len(result) == 5


# ── URL loading ───────────────────────────────────────────────────────────────

class TestLoadURL:
    def test_url_csv_load(self, ingestor):
        mock_resp = MagicMock()
        mock_resp.content = b"a,b,c\n1,2,3\n4,5,6\n7,8,9\n10,11,12\n13,14,15"
        mock_resp.headers = {"content-type": "text/csv"}
        mock_resp.raise_for_status = MagicMock()

        with patch("requests.get", return_value=mock_resp):
            result = ingestor.load("https://example.com/data.csv")
        assert result.shape == (5, 3)

    def test_url_json_load(self, ingestor):
        import json
        data = [{"x": i, "y": i * 2} for i in range(5)]
        mock_resp = MagicMock()
        mock_resp.content = json.dumps(data).encode()
        mock_resp.headers = {"content-type": "application/json"}
        mock_resp.raise_for_status = MagicMock()

        with patch("requests.get", return_value=mock_resp):
            result = ingestor.load("https://example.com/data.json")
        assert len(result) == 5


# ── validation errors ─────────────────────────────────────────────────────────

class TestValidation:
    def test_empty_dataframe_raises(self, ingestor):
        with pytest.raises(EmptyDataError):
            ingestor.load(pd.DataFrame())

    def test_too_few_rows_raises(self, ingestor):
        df = pd.DataFrame({"a": [1, 2, 3]})
        with pytest.raises(InsufficientDataError):
            ingestor.load(df)

    def test_unsupported_format_raises(self, ingestor, tmp_path):
        p = tmp_path / "data.xyz"
        p.write_text("hello world")
        with pytest.raises(UnsupportedFormatError):
            ingestor.load(p)

    def test_unsupported_format_message_helpful(self, ingestor, tmp_path):
        p = tmp_path / "data.abc"
        p.write_text("x")
        with pytest.raises(UnsupportedFormatError) as exc_info:
            ingestor.load(p)
        assert "csv" in str(exc_info.value).lower()


# ── sampling ──────────────────────────────────────────────────────────────────

class TestSampling:
    def test_large_df_sampled(self, ingestor, large_df):
        from datalens.config import config
        result = ingestor.load(large_df, sample=True)
        assert len(result) <= config.sampling.max_rows

    def test_sampling_can_be_disabled(self, ingestor, large_df):
        result = ingestor.load(large_df, sample=False)
        assert len(result) == len(large_df)

    def test_small_df_not_sampled(self, ingestor, simple_df):
        result = ingestor.load(simple_df, sample=True)
        assert len(result) == len(simple_df)

    def test_sampled_df_has_correct_columns(self, ingestor, large_df):
        result = ingestor.load(large_df, sample=True)
        assert set(result.columns) == set(large_df.columns)