"""
Tests for datalens.report — HTML, PDF and web app output (Phase 5 stubs).
These tests validate report generation logic and file outputs.
"""
import pytest
import os
from pathlib import Path


class TestHTMLReportImport:
    def test_html_report_importable(self):
        try:
            from datalens.report.html_report import HTMLReporter
            assert HTMLReporter is not None
        except ImportError:
            pytest.skip("Phase 5 not yet built")


class TestHTMLReportGeneration:
    @pytest.fixture
    def reporter(self):
        try:
            from datalens.report.html_report import HTMLReporter
            return HTMLReporter()
        except ImportError:
            pytest.skip("Phase 5 not yet built")

    def test_generates_html_file(self, reporter, simple_dataset_report, tmp_path):
        out = tmp_path / "report.html"
        reporter.generate(simple_dataset_report, output_path=out)
        assert out.exists()

    def test_html_file_not_empty(self, reporter, simple_dataset_report, tmp_path):
        out = tmp_path / "report.html"
        reporter.generate(simple_dataset_report, output_path=out)
        assert out.stat().st_size > 100

    def test_html_contains_column_names(self, reporter, simple_dataset_report, tmp_path):
        out = tmp_path / "report.html"
        reporter.generate(simple_dataset_report, output_path=out)
        content = out.read_text()
        for col in simple_dataset_report.columns:
            assert col in content

    def test_html_has_valid_structure(self, reporter, simple_dataset_report, tmp_path):
        out = tmp_path / "report.html"
        reporter.generate(simple_dataset_report, output_path=out)
        content = out.read_text()
        assert "<html" in content.lower()
        assert "</html>" in content.lower()


class TestPDFReportImport:
    def test_pdf_report_importable(self):
        try:
            from datalens.report.pdf_report import PDFReporter
            assert PDFReporter is not None
        except ImportError:
            pytest.skip("Phase 5 not yet built")


class TestPDFReportGeneration:
    @pytest.fixture
    def pdf_reporter(self):
        try:
            from datalens.report.pdf_report import PDFReporter
            return PDFReporter()
        except ImportError:
            pytest.skip("Phase 5 not yet built")

    def test_generates_pdf_file(self, pdf_reporter, simple_dataset_report, tmp_path):
        out = tmp_path / "report.pdf"
        pdf_reporter.generate(simple_dataset_report, output_path=out)
        assert out.exists()

    def test_pdf_file_not_empty(self, pdf_reporter, simple_dataset_report, tmp_path):
        out = tmp_path / "report.pdf"
        pdf_reporter.generate(simple_dataset_report, output_path=out)
        assert out.stat().st_size > 500

    def test_pdf_starts_with_pdf_header(self, pdf_reporter, simple_dataset_report, tmp_path):
        out = tmp_path / "report.pdf"
        pdf_reporter.generate(simple_dataset_report, output_path=out)
        header = out.read_bytes()[:4]
        assert header == b"%PDF"


class TestWebAppImport:
    def test_web_app_importable(self):
        try:
            from datalens.report.web_app import launch
            assert launch is not None
        except ImportError:
            pytest.skip("Phase 5 not yet built")