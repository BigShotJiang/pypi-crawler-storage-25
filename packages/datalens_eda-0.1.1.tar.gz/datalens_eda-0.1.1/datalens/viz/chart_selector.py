"""
datalens/viz/chart_selector.py
Auto-selects the best chart type for any column or column-pair.
"""
from __future__ import annotations
from datalens.detector import ColType
from datalens.profiler import ColumnReport


class ChartSelector:
    """Selects the best chart type for a single column or a pair."""

    def select_for_column(self, col_type: ColType, n_unique: int = 0) -> str:
        if col_type in (ColType.NUMERIC_CONTINUOUS, ColType.NUMERIC_DISCRETE):
            return "histogram_box"
        if col_type == ColType.BOOLEAN:
            return "pie"
        if col_type == ColType.CATEGORICAL_LOW:
            return "pie" if n_unique <= 5 else "bar_horizontal"
        if col_type == ColType.CATEGORICAL_HIGH:
            return "bar_horizontal"
        if col_type == ColType.DATETIME:
            return "time_series_line"
        if col_type == ColType.TEXT:
            return "wordcloud"
        return "none"

    def select_for_pair(self, type_a: ColType, type_b: ColType) -> str:
        NUM = {ColType.NUMERIC_CONTINUOUS, ColType.NUMERIC_DISCRETE,
               ColType.GEOSPATIAL_LAT, ColType.GEOSPATIAL_LON}
        CAT = {ColType.CATEGORICAL_LOW, ColType.CATEGORICAL_HIGH, ColType.BOOLEAN}
        a_num = type_a in NUM
        b_num = type_b in NUM
        a_cat = type_a in CAT
        b_cat = type_b in CAT
        if a_num and b_num:    return "scatter"
        if a_cat and b_cat:    return "stacked_bar"
        if (a_num and b_cat) or (a_cat and b_num): return "box_violin"
        if ColType.DATETIME in (type_a, type_b):   return "time_series_line"
        return "none"


_selector = ChartSelector()

def select_univariate_chart(col_rep: ColumnReport) -> str:
    return _selector.select_for_column(col_rep.col_type, col_rep.n_unique)

def select_bivariate_chart(col_rep_a: ColumnReport, col_rep_b: ColumnReport) -> str:
    return _selector.select_for_pair(col_rep_a.col_type, col_rep_b.col_type)
