"""
DataLens CLI — datalens <command>

Commands
--------
  datalens analyze <file>   run full EDA and print summary
  datalens serve  [file]    launch Streamlit web dashboard  
  datalens version          print installed version
"""
from __future__ import annotations
import sys
import pathlib
import argparse

from rich.console import Console
console = Console()


def cmd_analyze(args) -> None:
    path = pathlib.Path(args.file)
    if not path.exists():
        console.print(f"[red]File not found:[/red] {path}")
        sys.exit(1)
    from datalens import analyze
    console.print(f"[bold]DataLens[/bold] analyzing [cyan]{path.name}[/cyan] ...")
    result = analyze(path, verbose=True)
    if getattr(args, "html", False):
        from datalens.report.html_report import HTMLReporter
        out = pathlib.Path(args.html)
        HTMLReporter().generate(result, output_path=out)
        console.print(f"[green]HTML report saved:[/green] {out}")


def cmd_serve(args) -> None:
    try:
        import streamlit  # noqa
    except ImportError:
        console.print(
            "[red]Streamlit not installed.[/red]\n"
            "Run: [bold]pip install datalens-eda\\[web][/bold]"
        )
        sys.exit(1)
    import subprocess
    base = pathlib.Path(__file__).parent
    app  = base / "web_app.py"
    console.print("[bold green]Launching DataLens web dashboard...[/bold green]")
    console.print("Press [bold]Ctrl+C[/bold] to stop.\n")
    cmd = [sys.executable, "-m", "streamlit", "run", str(app)]
    if getattr(args, "file", None):
        cmd += ["--", args.file]
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        console.print("\n[dim]Dashboard stopped.[/dim]")


def cmd_version(args) -> None:
    from datalens import __version__
    console.print(f"[bold]DataLens[/bold] v{__version__}")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="datalens",
        description="DataLens — Intelligent AutoEDA library",
    )
    sub = parser.add_subparsers(dest="command")

    p_an = sub.add_parser("analyze", help="Run full EDA on a file")
    p_an.add_argument("file", help="Data file: CSV, Excel, Parquet, JSON...")
    p_an.add_argument("--html", metavar="PATH", help="Also save HTML report to PATH")
    p_an.set_defaults(func=cmd_analyze)

    p_sv = sub.add_parser("serve", help="Launch the Streamlit web dashboard")
    p_sv.add_argument("file", nargs="?", help="Optional data file to preload")
    p_sv.set_defaults(func=cmd_serve)

    p_vr = sub.add_parser("version", help="Show installed version")
    p_vr.set_defaults(func=cmd_version)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)
    args.func(args)


if __name__ == "__main__":
    main()
