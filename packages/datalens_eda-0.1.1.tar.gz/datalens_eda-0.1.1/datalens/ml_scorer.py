from __future__ import annotations
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .detector import ColType, ColProfile


# ── result container ──────────────────────────────────────────────────────────

@dataclass
class MLReadinessScore:
    overall:          float              # 0–100
    grade:            str               # A / B / C / D / F
    verdict:          str               # ready / needs_work / not_ready
    breakdown:        dict[str, float]  = field(default_factory=dict)
    penalties:        list[str]         = field(default_factory=list)
    bonuses:          list[str]         = field(default_factory=list)
    recommendations:  list[str]         = field(default_factory=list)
    target_analysis:  dict              = field(default_factory=dict)


# ── scorer ────────────────────────────────────────────────────────────────────

class MLScorer:
    """
    Scores how ML-ready a dataset is from 0 to 100 across 6 dimensions:

      1. Completeness   — how many values are present (nulls kill models)
      2. Size           — enough rows to learn from
      3. Feature quality — useful columns vs ID/constant junk
      4. Target quality — is the target column clean and balanced?
      5. Leakage risk   — features suspiciously correlated with target
      6. Encoding ready — categorical columns manageable

    Each dimension is weighted and penalised/bonused independently.
    """

    # weights must sum to 1.0
    WEIGHTS = {
        "completeness":    0.25,
        "size":            0.20,
        "feature_quality": 0.20,
        "target_quality":  0.20,
        "encoding_ready":  0.10,
        "leakage_risk":    0.05,
    }

    def score(
        self,
        df: pd.DataFrame,
        profiles: dict[str, ColProfile],
        target: str | None = None,
        top_correlations: list | None = None,
    ) -> MLReadinessScore:

        penalties: list[str] = []
        bonuses:   list[str] = []
        recs:      list[str] = []

        # ── 1. completeness ───────────────────────────────────────────────────
        pct_complete = 1 - df.isna().mean().mean()
        c_score      = self._completeness_score(pct_complete, df, penalties, recs)

        # ── 2. size ───────────────────────────────────────────────────────────
        s_score = self._size_score(len(df), len(df.columns), penalties, bonuses, recs)

        # ── 3. feature quality ────────────────────────────────────────────────
        fq_score = self._feature_quality_score(profiles, penalties, bonuses, recs)

        # ── 4. target quality ─────────────────────────────────────────────────
        tq_score, target_analysis = self._target_quality_score(
            df, profiles, target, penalties, bonuses, recs
        )

        # ── 5. encoding readiness ─────────────────────────────────────────────
        enc_score = self._encoding_score(profiles, penalties, recs)

        # ── 6. leakage risk (penalise near-perfect feature↔target corr) ───────
        leak_score = self._leakage_score(top_correlations, target, penalties, recs)

        breakdown = {
            "completeness":    round(c_score,   1),
            "size":            round(s_score,   1),
            "feature_quality": round(fq_score,  1),
            "target_quality":  round(tq_score,  1),
            "encoding_ready":  round(enc_score, 1),
            "leakage_risk":    round(leak_score,1),
        }

        overall = sum(
            breakdown[k] * self.WEIGHTS[k] for k in breakdown
        )
        overall = round(min(max(overall, 0), 100), 1)

        grade   = self._grade(overall)
        verdict = ("ready" if overall >= 75
                   else "needs_work" if overall >= 50
                   else "not_ready")

        return MLReadinessScore(
            overall=overall,
            grade=grade,
            verdict=verdict,
            breakdown=breakdown,
            penalties=penalties,
            bonuses=bonuses,
            recommendations=recs,
            target_analysis=target_analysis,
        )

    # ── dimension scorers ──────────────────────────────────────────────────────

    def _completeness_score(
        self, pct: float, df: pd.DataFrame,
        penalties: list, recs: list
    ) -> float:
        score = pct * 100
        null_cols = (df.isna().mean() > 0.5).sum()
        if null_cols:
            score -= null_cols * 5
            penalties.append(f"{null_cols} columns >50% missing — heavy imputation needed")
            recs.append("Drop or impute columns with >50% nulls before training.")
        if pct < 0.7:
            penalties.append(f"Overall completeness only {pct*100:.1f}% — risky for most models")
            recs.append("Use iterative imputer (IterativeImputer) for numeric columns.")
        return max(score, 0)

    def _size_score(
        self, n_rows: int, n_cols: int,
        penalties: list, bonuses: list, recs: list
    ) -> float:
        ratio = n_rows / max(n_cols, 1)
        if n_rows < 50:
            penalties.append(f"Only {n_rows} rows — almost any model will overfit")
            recs.append("Collect more data. At minimum 10× rows per feature.")
            return 10.0
        if n_rows < 200:
            penalties.append(f"Only {n_rows} rows — limited model options")
            recs.append("Use simple models: logistic regression, decision tree, k-NN.")
            return 35.0
        if n_rows < 1000:
            return 60.0
        if n_rows < 10_000:
            if ratio > 10:
                bonuses.append(f"Good row-to-feature ratio ({ratio:.0f}:1)")
            return 80.0
        if n_rows >= 100_000:
            bonuses.append(f"Large dataset ({n_rows:,} rows) — deep learning viable")
            return 100.0
        return 90.0

    def _feature_quality_score(
        self, profiles: dict[str, ColProfile],
        penalties: list, bonuses: list, recs: list
    ) -> float:
        total    = len(profiles)
        n_id     = sum(1 for p in profiles.values() if p.col_type == ColType.ID_COLUMN)
        n_const  = sum(1 for p in profiles.values() if p.col_type == ColType.CONSTANT)
        n_useful = total - n_id - n_const

        if n_id:
            penalties.append(f"{n_id} ID columns detected — should be dropped before training")
            recs.append(f"Drop ID columns: they leak row identity, not patterns.")
        if n_const:
            penalties.append(f"{n_const} constant columns — zero variance, useless for ML")
            recs.append("Remove constant/zero-variance columns.")

        pct_useful = n_useful / max(total, 1)
        score      = pct_useful * 100

        if n_useful >= 5:
            bonuses.append(f"{n_useful} useful feature columns available")
        if n_useful < 2:
            penalties.append("Too few usable features for reliable ML")
        return score

    def _target_quality_score(
        self, df: pd.DataFrame,
        profiles: dict[str, ColProfile],
        target: str | None,
        penalties: list, bonuses: list, recs: list
    ) -> tuple[float, dict]:
        if not target or target not in profiles:
            penalties.append("No target column specified — cannot assess target quality")
            recs.append("Specify target= when calling analyze() for full ML scoring.")
            return 50.0, {}

        prof  = profiles[target]
        s     = df[target].dropna()
        score = 100.0
        info  = {"column": target, "type": prof.col_type.name}

        null_pct = df[target].isna().mean()
        if null_pct > 0:
            score -= null_pct * 200
            penalties.append(f"Target '{target}' has {null_pct*100:.1f}% nulls")
            recs.append(f"Target column should have 0 nulls — drop or impute rows.")

        # classification: check class balance
        if prof.col_type in (ColType.CATEGORICAL_LOW, ColType.BOOLEAN):
            vc   = s.value_counts(normalize=True)
            minority = float(vc.iloc[-1]) if len(vc) > 1 else 1.0
            info["task"] = "classification"
            info["n_classes"] = len(vc)
            info["minority_class_pct"] = round(minority, 4)
            if minority < 0.05:
                penalties.append(f"Severe class imbalance: minority class only {minority*100:.1f}%")
                recs.append("Use SMOTE, class_weight='balanced', or oversampling.")
                score -= 30
            elif minority < 0.2:
                penalties.append(f"Moderate class imbalance: minority {minority*100:.1f}%")
                recs.append("Consider stratified k-fold cross-validation.")
                score -= 10
            else:
                bonuses.append(f"Target classes reasonably balanced (minority: {minority*100:.1f}%)")

        # regression: check skewness of target
        elif prof.col_type in (ColType.NUMERIC_CONTINUOUS, ColType.NUMERIC_DISCRETE):
            from scipy import stats as sp
            skew = float(sp.skew(s.astype(float)))
            info["task"] = "regression"
            info["skewness"] = round(skew, 4)
            if abs(skew) > 1.5:
                penalties.append(f"Target '{target}' is highly skewed ({skew:.2f}) — log-transform recommended")
                recs.append("Apply np.log1p() to target before training regression models.")
                score -= 15

        return max(score, 0), info

    def _encoding_score(
        self, profiles: dict[str, ColProfile],
        penalties: list, recs: list
    ) -> float:
        high_card = [
            col for col, p in profiles.items()
            if p.col_type == ColType.CATEGORICAL_HIGH
        ]
        if not high_card:
            return 100.0
        if len(high_card) <= 2:
            recs.append(f"High-cardinality columns {high_card}: use target encoding or embeddings.")
            return 70.0
        penalties.append(f"{len(high_card)} high-cardinality columns — one-hot encoding will explode dimensionality")
        recs.append("Use TargetEncoder, HashingEncoder, or dimensionality reduction for high-cardinality columns.")
        return 40.0

    def _leakage_score(
        self, top_correlations: list | None,
        target: str | None,
        penalties: list, recs: list
    ) -> float:
        if not top_correlations or not target:
            return 100.0

        leaky = [
            p for p in top_correlations
            if target in (p.col_a, p.col_b) and abs(p.value) > 0.95
        ]
        if leaky:
            cols = [p.col_a if p.col_b == target else p.col_b for p in leaky]
            penalties.append(f"LEAKAGE RISK: {cols} are >95% correlated with target")
            recs.append(f"Investigate {cols} — they may be derived from the target (data leakage).")
            return 0.0
        return 100.0

    # ── grading ───────────────────────────────────────────────────────────────

    @staticmethod
    def _grade(score: float) -> str:
        if score >= 90: return "A"
        if score >= 80: return "B"
        if score >= 65: return "C"
        if score >= 50: return "D"
        return "F"