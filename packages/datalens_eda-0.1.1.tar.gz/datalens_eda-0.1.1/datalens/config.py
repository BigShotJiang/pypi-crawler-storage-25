from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings


class SamplingConfig(BaseModel):
    enabled: bool = True
    max_rows: int = 100_000          # auto-sample above this
    seed: int = 42


class AIConfig(BaseModel):
    enabled: bool = False
    provider: Literal["openai", "ollama", "groq"] = "openai"
    api_key: str | None = None
    model: str = "gpt-4o-mini"
    ollama_url: str = "http://localhost:11434"


class DataLensConfig(BaseSettings):
    theme: Literal["light", "dark", "auto"] = "auto"
    sampling: SamplingConfig = SamplingConfig()
    ai: AIConfig = AIConfig()
    verbose: bool = True
    n_top_correlations: int = 20
    outlier_threshold: float = 0.05    # flag if >5% are outliers

    model_config = {"env_prefix": "DATALENS_", "env_nested_delimiter": "__"}


# Global singleton — users can mutate before calling analyze()
config = DataLensConfig()