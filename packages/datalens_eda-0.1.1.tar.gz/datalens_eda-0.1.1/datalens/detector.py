from __future__ import annotations
import re
from dataclasses import dataclass
from enum import Enum, auto

import pandas as pd
import numpy as np


class ColType(Enum):
    NUMERIC_CONTINUOUS = auto()
    NUMERIC_DISCRETE   = auto()
    CATEGORICAL_LOW    = auto()   # cardinality <= 20
    CATEGORICAL_HIGH   = auto()   # cardinality > 20
    BOOLEAN            = auto()
    DATETIME           = auto()
    TEXT               = auto()   # free-form text (avg words > 5)
    ID_COLUMN          = auto()   # likely identifier — skip analysis
    CONSTANT           = auto()   # single unique value
    GEOSPATIAL_LAT     = auto()
    GEOSPATIAL_LON     = auto()
    EMAIL              = auto()
    URL                = auto()
    PHONE              = auto()


@dataclass
class ColProfile:
    name: str
    col_type: ColType
    pandas_dtype: str
    n_unique: int
    pct_null: float
    sample_values: list


_EMAIL_RE  = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")
_URL_RE    = re.compile(r"https?://|www\.", re.I)
_PHONE_RE  = re.compile(r"[\+\d][\d\s\-\(\)]{7,15}")
_LAT_RANGE = (-90.0, 90.0)
_LON_RANGE = (-180.0, 180.0)


class ColumnDetector:
    """
    Infers a semantic ColType for every column in a DataFrame.
    Goes beyond pandas dtypes — understands emails, IDs, geo coords, etc.
    """

    def detect_all(self, df: pd.DataFrame) -> dict[str, ColProfile]:
        return {col: self._detect_column(df[col], col) for col in df.columns}

    def _detect_column(self, s: pd.Series, name: str) -> ColProfile:
        n_unique   = s.nunique()
        pct_null   = s.isna().mean()
        dtype_str  = str(s.dtype)
        samples    = s.dropna().head(5).tolist()
        col_type   = self._infer_type(s, name, n_unique)

        return ColProfile(
            name=name,
            col_type=col_type,
            pandas_dtype=dtype_str,
            n_unique=n_unique,
            pct_null=pct_null,
            sample_values=samples,
        )

    def _infer_type(self, s: pd.Series, name: str, n_unique: int) -> ColType:
        # --- constant ---
        if n_unique <= 1:
            return ColType.CONSTANT

        # --- datetime (try parsing if object) ---
        if pd.api.types.is_datetime64_any_dtype(s):
            return ColType.DATETIME
        if s.dtype == object:
            try:
                pd.to_datetime(s.dropna().head(50), infer_datetime_format=True)
                return ColType.DATETIME
            except Exception:
                pass

        # --- boolean ---
        if set(s.dropna().unique()).issubset({0, 1, True, False, "True", "False",
                                              "true", "false", "yes", "no",
                                              "Yes", "No", "Y", "N"}):
            if n_unique <= 2:
                return ColType.BOOLEAN

        # --- numeric ---
        if pd.api.types.is_numeric_dtype(s):
            # geo detection
            col_lower = name.lower()
            if any(k in col_lower for k in ("lat", "latitude")):
                vals = s.dropna()
                if vals.between(*_LAT_RANGE).mean() > 0.95:
                    return ColType.GEOSPATIAL_LAT
            if any(k in col_lower for k in ("lon", "lng", "longitude")):
                vals = s.dropna()
                if vals.between(*_LON_RANGE).mean() > 0.95:
                    return ColType.GEOSPATIAL_LON

            # ID heuristic: name contains 'id', all unique, integer
            if ("id" in col_lower or col_lower.endswith("_key")) and n_unique == len(s.dropna()):
                return ColType.ID_COLUMN

            # discrete vs continuous
            if pd.api.types.is_integer_dtype(s) and n_unique <= 20:
                return ColType.NUMERIC_DISCRETE
            return ColType.NUMERIC_CONTINUOUS

        # --- string-based ---
        if s.dtype == object:
            sample_str = s.dropna().astype(str).head(100)

            if sample_str.str.match(_EMAIL_RE).mean() > 0.8:
                return ColType.EMAIL
            if sample_str.str.contains(_URL_RE).mean() > 0.8:
                return ColType.URL

            # text detection: avg word count
            avg_words = sample_str.str.split().str.len().mean()
            if avg_words > 6:
                return ColType.TEXT

            # ID heuristic for strings
            if ("id" in name.lower() or name.lower().endswith("_key")) and n_unique == len(s.dropna()):
                return ColType.ID_COLUMN

            if n_unique <= 20:
                return ColType.CATEGORICAL_LOW
            return ColType.CATEGORICAL_HIGH

        return ColType.CATEGORICAL_LOW