from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import pathlib
import time
import subprocess
import tempfile
import pickle
import os

import pandas as pd
from rich.console import Console
from rich.table import Table
from rich import box as rich_box

from .ingestor import DataIngestor
from .detector import ColumnDetector, ColProfile
from .config import DataLensConfig, config as _global_config
from .exceptions import ColumnNotFoundError

from .profiler import Profiler
from .relationships import RelationshipEngine
from .anomaly import AnomalyDetector
from .ml_scorer import MLScorer
from .fix_engine import FixEngine
from .narrator import get_narrator

console = Console()

@dataclass
class AnalysisResult:
    """Container for the full analysis. Passed to every downstream module."""
    df:             pd.DataFrame
    profiles:       dict[str, ColProfile]
    shape:          tuple[int, int]
    memory_mb:      float
    load_time_s:    float
    n_duplicates:   int
    pct_complete:   float           # % cells that are not null
    stats:          Any             = None  # DatasetReport
    viz:            dict[str, Any]  = field(default_factory=dict)
    narrative:      Any             = None  # Narrative
    ml_score:       Any             = None  # MLReadinessScore
    fix_suggestions: list[dict]     = field(default_factory=list)

    def __repr__(self) -> str:
        score_str = self.ml_score.overall if self.ml_score else 'not computed'
        return (
            f"AnalysisResult("
            f"{self.shape[0]:,} rows × {self.shape[1]} cols | "
            f"ML score: {score_str} | "
            f"Fixes: {len(self.fix_suggestions)})"
        )
        
    def show_browser(self) -> None:
        """Launches the interactive Streamlit web dashboard in the browser."""
        fd, path = tempfile.mkstemp(suffix=".pkl")
        with os.fdopen(fd, "wb") as f:
            pickle.dump(self, f)
            
        base_dir = pathlib.Path(__file__).parent
        app_path = base_dir / "web_app.py"
        
        console.print(f"[bold green]Launching DataLens Web App...[/bold green]")
        console.print(f"Dashboard reading from temporary payload: {path}")
        
        subprocess.Popen(
            ["streamlit", "run", str(app_path), "--", path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

class DataLens:
    """
    Main entry point for DataLens AutoEDA.
    """

    def __init__(self, cfg: DataLensConfig | None = None):
        self._cfg      = cfg or _global_config
        self._ingestor = DataIngestor()
        self._detector = ColumnDetector()
        
        self._profiler = Profiler()
        self._rel_eng  = RelationshipEngine()
        self._anomaly  = AnomalyDetector()
        self._scorer   = MLScorer()
        self._fixer    = FixEngine()
        
        # safely handle narrator instantiation
        ai_kwargs = {}
        if hasattr(self._cfg.ai, "model_dump"):
            ai_kwargs = self._cfg.ai.model_dump()
        elif hasattr(self._cfg.ai, "dict"):
            ai_kwargs = self._cfg.ai.dict()
            
        if "enabled" in ai_kwargs:
            del ai_kwargs["enabled"]
            
        self._narrator = get_narrator(ai_enabled=self._cfg.ai.enabled, **ai_kwargs)

    def analyze(
        self,
        source,
        *,
        target: str | None = None,
        sql_query: str | None = None,
        sql_connection=None,
        sample: bool | None = None,
        verbose: bool | None = None,
        **read_kwargs,
    ) -> AnalysisResult:
        
        be_verbose = verbose if verbose is not None else self._cfg.verbose

        # 1. load
        t0 = time.perf_counter()
        if be_verbose: console.print("[bold]DataLens[/bold] loading data...", style="dim")

        df = self._ingestor.load(
            source, sql_query=sql_query, sql_connection=sql_connection,
            sample=sample, **read_kwargs
        )
        load_time = time.perf_counter() - t0

        # 2. detect column types
        if be_verbose:
            console.print(f"  Loaded [green]{len(df):,}[/green] rows × [green]{len(df.columns)}[/green] columns ")
            console.print("  Computing statistics, relationships, and anomalies...", style="dim")

        profiles = self._detector.detect_all(df)
        
        # 3. Validation
        if target and target not in df.columns:
            raise ColumnNotFoundError(target, list(df.columns))

        # 4. Profiling & Engines
        dataset_report = self._profiler.profile(df, profiles)
        rel_report = self._rel_eng.analyze(df, profiles, target=target, top_n=self._cfg.n_top_correlations)
        anomaly_report = self._anomaly.detect(df, profiles)
        ml_score = self._scorer.score(df, profiles, target=target, top_correlations=rel_report.top_correlations)
        fixes = self._fixer.generate(dataset_report, df_name="df")
        narrative = self._narrator.narrate(dataset_report, ml_score, fixes)

        # 5. Build Result
        result = AnalysisResult(
            df=df,
            profiles=profiles,
            shape=df.shape,
            memory_mb=df.memory_usage(deep=True).sum() / 1e6,
            load_time_s=load_time,
            n_duplicates=int(df.duplicated().sum()),
            pct_complete=round(1 - df.isna().mean().mean(), 4),
            stats=dataset_report,
            viz={"relationships": rel_report, "anomalies": anomaly_report},
            narrative=narrative,
            ml_score=ml_score,
            fix_suggestions=fixes
        )

        if be_verbose:
            self._print_summary(result)

        return result

    def _print_summary(self, r: AnalysisResult) -> None:
        table = Table(title="DataLens — Dataset Overview", box=rich_box.ROUNDED)
        table.add_column("Metric", style="dim", width=22)
        table.add_column("Value", justify="right")

        table.add_row("Rows",          f"{r.shape[0]:,}")
        table.add_row("Columns",       str(r.shape[1]))
        table.add_row("Memory",        f"{r.memory_mb:.2f} MB")
        table.add_row("Completeness",  f"{r.pct_complete * 100:.1f}%")
        table.add_row("Duplicates",    str(r.n_duplicates))
        
        if r.ml_score:
            table.add_row("ML Readiness", f"{r.ml_score.overall}/100 (Grade {r.ml_score.grade})")

        console.print(table)
        console.print("💡 Tip: use [bold cyan]result.show_browser()[/bold cyan] to open the interactive web application!")