"""
datalens/report/pdf_report.py
PDF report using fpdf2. Falls back to Markdown if fpdf2 not installed.
"""
from __future__ import annotations
import pathlib
import textwrap
from datetime import datetime


class PDFReporter:
    """
    Usage:
        from datalens.report.pdf_report import PDFReporter
        PDFReporter().generate(result, output_path="report.pdf")
    """

    def generate(
        self,
        analysis_result,
        output_path: str | pathlib.Path = "datalens_report.pdf",
    ) -> pathlib.Path:
        out = pathlib.Path(output_path)
        try:
            from fpdf import FPDF
            return self._generate_pdf(analysis_result, out)
        except ImportError:
            md_out = out.with_suffix(".md")
            return self._generate_markdown(analysis_result, md_out)

    def _generate_pdf(self, r, out: pathlib.Path) -> pathlib.Path:
        from fpdf import FPDF
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()

        pdf.set_font("Helvetica", "B", 20)
        pdf.set_text_color(56, 189, 248)
        pdf.cell(0, 12, "DataLens AutoEDA Report", ln=True, align="C")
        pdf.set_font("Helvetica", size=9)
        pdf.set_text_color(100, 116, 139)
        pdf.cell(0, 8, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", ln=True, align="C")
        pdf.ln(6)

        self._section(pdf, "1. Dataset Overview")
        rows = [
            ("Rows",          f"{r.shape[0]:,}"),
            ("Columns",       str(r.shape[1])),
            ("Memory",        f"{r.memory_mb:.2f} MB"),
            ("Completeness",  f"{r.pct_complete*100:.1f}%"),
            ("Duplicates",    str(r.n_duplicates)),
        ]
        if r.ml_score:
            rows.append(("ML Grade", f"{r.ml_score.overall}/100 — Grade {r.ml_score.grade}"))
        for k, v in rows:
            self._kv_row(pdf, k, v)

        if r.narrative and r.narrative.dataset_summary:
            self._section(pdf, "2. AI Narrative")
            self._body(pdf, r.narrative.dataset_summary)
            if r.narrative.top_findings:
                pdf.ln(3)
                self._bold(pdf, "Top Findings:")
                for f_ in r.narrative.top_findings:
                    self._bullet(pdf, f_)

        if r.ml_score:
            s = r.ml_score
            self._section(pdf, "3. ML Readiness")
            for dim, val in s.breakdown.items():
                self._kv_row(pdf, dim.replace("_", " ").title(), f"{val:.1f}/100")
            if s.penalties:
                pdf.ln(3)
                self._bold(pdf, "Issues:")
                for p in s.penalties:
                    self._bullet(pdf, p)
            if s.recommendations:
                pdf.ln(3)
                self._bold(pdf, "Recommendations:")
                for rec in s.recommendations[:5]:
                    self._bullet(pdf, rec)

        if r.fix_suggestions:
            self._section(pdf, "4. Recommended Fixes")
            for fix in r.fix_suggestions[:15]:
                icon = "[CRITICAL]" if fix.severity == "critical" else "[WARNING]" if fix.severity == "warning" else "[INFO]"
                self._bold(pdf, f"{icon} {fix.title}")
                self._body(pdf, fix.explanation)
                self._code_block(pdf, fix.code)
                pdf.ln(2)

        pdf.output(str(out))
        return out

    def _generate_markdown(self, r, out: pathlib.Path) -> pathlib.Path:
        lines = [
            "# DataLens Summary Report",
            f"*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*", "",
            "## 1. Dataset Overview",
            "| Metric | Value |", "|--------|-------|",
            f"| Rows | {r.shape[0]:,} |",
            f"| Columns | {r.shape[1]} |",
            f"| Memory | {r.memory_mb:.2f} MB |",
            f"| Completeness | {r.pct_complete*100:.1f}% |",
            f"| Duplicates | {r.n_duplicates} |", "",
        ]
        if r.narrative and r.narrative.dataset_summary:
            lines += ["## 2. AI Narrative", r.narrative.dataset_summary, ""]
            if r.narrative.top_findings:
                lines.append("**Top Findings:**")
                for f_ in r.narrative.top_findings:
                    lines.append(f"- {f_}")
                lines.append("")
        if r.ml_score:
            s = r.ml_score
            lines += [f"## 3. ML Readiness", f"**Score:** {s.overall}/100  **Grade:** {s.grade}", ""]
            for p in s.penalties:
                lines.append(f"- {p}")
            lines.append("")
        if r.fix_suggestions:
            lines += ["## 4. Recommended Fixes", ""]
            for fix in r.fix_suggestions[:15]:
                lines += [f"### {fix.title}", f"*{fix.explanation}*", "```python", fix.code, "```", ""]
        out.write_text("\n".join(lines), encoding="utf-8")
        return out

    @staticmethod
    def _section(pdf, title):
        pdf.ln(4)
        pdf.set_font("Helvetica", "B", 13)
        pdf.set_text_color(226, 232, 240)
        pdf.cell(0, 10, title, ln=True)
        pdf.set_draw_color(51, 65, 85)
        pdf.line(10, pdf.get_y(), 200, pdf.get_y())
        pdf.ln(3)

    @staticmethod
    def _body(pdf, text):
        pdf.set_font("Helvetica", size=10)
        pdf.set_text_color(148, 163, 184)
        pdf.multi_cell(0, 6, textwrap.fill(text, width=90))

    @staticmethod
    def _bold(pdf, text):
        pdf.set_font("Helvetica", "B", 10)
        pdf.set_text_color(226, 232, 240)
        pdf.cell(0, 8, text, ln=True)

    @staticmethod
    def _bullet(pdf, text):
        pdf.set_font("Helvetica", size=10)
        pdf.set_text_color(148, 163, 184)
        pdf.multi_cell(0, 6, textwrap.fill(f"  • {text}", width=88))

    @staticmethod
    def _kv_row(pdf, key, val):
        pdf.set_font("Helvetica", "B", 10)
        pdf.set_text_color(203, 213, 225)
        pdf.cell(60, 7, key, border=0)
        pdf.set_font("Helvetica", size=10)
        pdf.set_text_color(148, 163, 184)
        pdf.cell(0, 7, val, ln=True)

    @staticmethod
    def _code_block(pdf, code):
        pdf.set_font("Courier", size=8)
        pdf.set_text_color(125, 211, 252)
        pdf.set_fill_color(15, 23, 42)
        for line in code.splitlines()[:20]:
            pdf.cell(0, 5, line[:110], ln=True, fill=True)
        pdf.ln(2)
