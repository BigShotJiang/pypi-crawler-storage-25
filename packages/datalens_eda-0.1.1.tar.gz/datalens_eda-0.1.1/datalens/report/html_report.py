"""
datalens/report/html_report.py
Generates a fully standalone interactive HTML report — no server needed.
"""
from __future__ import annotations
import uuid
import pathlib
from datetime import datetime

from datalens.charts import ChartGenerator
from datalens.detector import ColType


class HTMLReporter:
    """
    Usage:
        from datalens.report.html_report import HTMLReporter
        HTMLReporter().generate(result, output_path="report.html")
    """

    def generate(
        self,
        analysis_result,
        output_path: str | pathlib.Path = "datalens_report.html",
    ) -> pathlib.Path:
        out = pathlib.Path(output_path)
        out.write_text(self._build(analysis_result), encoding="utf-8")
        return out

    def _build(self, r) -> str:
        cg  = ChartGenerator()
        df  = r.df
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        parts: list[str] = []

        parts += [
            "<!DOCTYPE html>",
            "<html lang='en'><head>",
            "<meta charset='utf-8'>",
            "<title>DataLens Report</title>",
            "<script src='https://cdn.plot.ly/plotly-2.24.1.min.js'></script>",
            self._css(), "</head><body><div class='container'>",
            "<h1>DataLens AutoEDA Report</h1>",
            f"<p class='subtitle'>Generated: {now}</p>",
        ]

        # Overview metrics
        parts += ["<div class='card'><h2>Dataset Overview</h2><div class='metric-grid'>"]
        metrics = [
            ("Rows",         f"{r.shape[0]:,}"),
            ("Columns",      str(r.shape[1])),
            ("Completeness", f"{r.pct_complete*100:.1f}%"),
            ("Duplicates",   str(r.n_duplicates)),
            ("Memory",       f"{r.memory_mb:.1f} MB"),
        ]
        if r.ml_score:
            metrics.append(("ML Grade", f"{r.ml_score.grade} — {r.ml_score.overall}/100"))
        for title, val in metrics:
            parts.append(
                f"<div class='metric'><div class='metric-val'>{val}</div>"
                f"<div class='metric-lbl'>{title}</div></div>"
            )
        parts.append("</div></div>")

        # AI Narrative
        if r.narrative and r.narrative.dataset_summary:
            parts += [
                "<div class='card'><h2>AI Narrative</h2>",
                f"<p class='narrative'>{r.narrative.dataset_summary}</p>",
            ]
            if r.narrative.top_findings:
                parts.append("<ul class='findings'>")
                for f_ in r.narrative.top_findings:
                    parts.append(f"<li>{f_}</li>")
                parts.append("</ul>")
            parts.append("</div>")

        # ML Score
        if r.ml_score:
            s = r.ml_score
            parts += [
                "<div class='card'><h2>ML Readiness</h2>",
                f"<div class='score-badge'>Score: {s.overall}/100 &nbsp; Grade: {s.grade}</div>",
            ]
            if s.penalties:
                parts.append("<h3>Issues</h3><ul class='issues'>")
                for p in s.penalties:
                    parts.append(f"<li>{p}</li>")
                parts.append("</ul>")
            if s.bonuses:
                parts.append("<h3>Strengths</h3><ul class='strengths'>")
                for b in s.bonuses:
                    parts.append(f"<li>{b}</li>")
                parts.append("</ul>")
            parts.append("</div>")

        # Missing values
        parts += ["<div class='card'><h2>Missing Values</h2>"]
        parts += self._plotly_div(cg.plot_missing_values(df))
        parts += ["</div>"]

        # Correlation heatmap
        if r.viz and "relationships" in r.viz:
            rel = r.viz["relationships"]
            if rel.correlations:
                parts += ["<div class='card'><h2>Feature Correlations</h2>"]
                parts += self._plotly_div(cg.plot_correlation_heatmap(rel.correlations))
                parts += ["</div>"]

        # Column distributions
        parts += ["<div class='card'><h2>Column Distributions</h2>"]
        for col, prof in r.profiles.items():
            fig = None
            if prof.col_type in (ColType.NUMERIC_CONTINUOUS, ColType.NUMERIC_DISCRETE):
                fig = cg.plot_numeric_distribution(df, col)
            elif prof.col_type in (ColType.CATEGORICAL_LOW, ColType.CATEGORICAL_HIGH, ColType.BOOLEAN):
                fig = cg.plot_categorical_distribution(df, col)
            elif prof.col_type == ColType.DATETIME:
                fig = cg.plot_datetime_trend(df, col)
            if fig is not None:
                parts.append(f"<h3>{col}</h3>")
                parts += self._plotly_div(fig)
                parts.append("<hr class='col-sep'>")
        parts.append("</div>")

        # Fix suggestions
        if r.fix_suggestions:
            parts += ["<div class='card'><h2>Recommended Fixes</h2>"]
            for fix in r.fix_suggestions:
                icon = "🚨" if fix.severity == "critical" else "⚠️" if fix.severity == "warning" else "💡"
                parts += [
                    f"<div class='fix-block fix-{fix.severity}'>",
                    f"<div class='fix-title'>{icon} {fix.title}</div>",
                    f"<p class='fix-exp'>{fix.explanation}</p>",
                    f"<pre class='fix-code'>{fix.code}</pre>",
                    "</div>",
                ]
            parts.append("</div>")

        parts += [
            "<div class='footer'>Generated by <strong>DataLens AutoEDA</strong></div>",
            "</div></body></html>",
        ]
        return "\n".join(parts)

    @staticmethod
    def _plotly_div(fig) -> list[str]:
        div_id   = "plot_" + uuid.uuid4().hex
        fig_json = fig.to_json()
        return [
            f"<div id='{div_id}' style='width:100%;height:420px;margin:8px 0'></div>",
            f"<script>Plotly.newPlot('{div_id}',{fig_json}.data,{fig_json}.layout,{{responsive:true}});</script>",
        ]

    @staticmethod
    def _css() -> str:
        return """<style>
body{font-family:'Inter',Helvetica,sans-serif;background:#0f172a;color:#f1f5f9;margin:0;padding:40px}
.container{max-width:1200px;margin:0 auto}
h1{color:#38bdf8;text-align:center;font-size:2.2em;margin-bottom:4px}
h2{color:#e2e8f0;border-bottom:1px solid #334155;padding-bottom:10px;margin-top:0}
h3{color:#94a3b8;margin:12px 0 6px}
.subtitle{text-align:center;color:#64748b;margin-bottom:30px}
.card{background:#1e293b;border:1px solid #334155;border-radius:12px;padding:24px;margin-bottom:24px}
.metric-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:16px;margin-top:16px}
.metric{text-align:center;padding:14px;background:#0f172a;border-radius:8px;border:1px solid #334155}
.metric-val{font-size:1.8em;font-weight:700;color:#38bdf8}
.metric-lbl{font-size:.8em;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;margin-top:4px}
.narrative{color:#cbd5e1;line-height:1.7}
.findings{color:#94a3b8;line-height:1.9;padding-left:20px}
.score-badge{display:inline-block;background:#1d4ed8;color:#bfdbfe;padding:6px 18px;border-radius:20px;font-weight:600;font-size:1.1em;margin-bottom:12px}
.issues li{color:#fca5a5;margin-bottom:4px}
.strengths li{color:#86efac;margin-bottom:4px}
.col-sep{border:0;height:1px;background:#334155;margin:20px 0}
.fix-block{border-radius:8px;padding:16px;margin-bottom:14px;border-left:4px solid}
.fix-critical{background:#1c0a0a;border-color:#ef4444}
.fix-warning{background:#1c1200;border-color:#f59e0b}
.fix-info{background:#0a0f1c;border-color:#38bdf8}
.fix-title{font-weight:600;font-size:1em;margin-bottom:6px;color:#f1f5f9}
.fix-exp{color:#94a3b8;font-size:.9em;margin:4px 0 8px}
.fix-code{background:#0f172a;color:#7dd3fc;border-radius:6px;padding:12px;font-size:.85em;overflow-x:auto;white-space:pre}
.footer{text-align:center;color:#475569;font-size:.85em;margin-top:40px;padding-top:20px;border-top:1px solid #1e293b}
</style>"""
