from __future__ import annotations
import json
from dataclasses import dataclass, field

from .profiler import DatasetReport, ColumnReport
from .ml_scorer import MLReadinessScore
from .fix_engine import FixSuggestion
from .detector import ColType


# ── result container ──────────────────────────────────────────────────────────

@dataclass
class Narrative:
    dataset_summary:   str
    column_insights:   dict[str, str]   = field(default_factory=dict)
    quality_story:     str              = ""
    ml_readiness_text: str              = ""
    top_findings:      list[str]        = field(default_factory=list)
    generated_by:      str              = "rule_based"   # rule_based / openai / ollama


# ── rule-based narrative (offline, no API key needed) ─────────────────────────

class RuleBasedNarrator:
    """
    Generates plain-English narratives from DatasetReport without any LLM.
    Fast, offline, deterministic.
    Used as fallback when AI is disabled or API key missing.
    """

    def narrate(
        self,
        report:     DatasetReport,
        ml_score:   MLReadinessScore | None = None,
        fixes:      list[FixSuggestion] | None = None,
    ) -> Narrative:

        summary  = self._dataset_summary(report)
        col_ins  = {col: self._column_insight(r)
                    for col, r in report.columns.items()}
        quality  = self._quality_story(report)
        ml_text  = self._ml_text(ml_score) if ml_score else ""
        findings = self._top_findings(report, ml_score, fixes)

        return Narrative(
            dataset_summary=summary,
            column_insights=col_ins,
            quality_story=quality,
            ml_readiness_text=ml_text,
            top_findings=findings,
            generated_by="rule_based",
        )

    def _dataset_summary(self, r: DatasetReport) -> str:
        size_desc = (
            "small" if r.n_rows < 500
            else "medium-sized" if r.n_rows < 10_000
            else "large"
        )
        complete_desc = (
            "highly complete" if r.pct_complete > 0.95
            else "mostly complete" if r.pct_complete > 0.80
            else "partially complete" if r.pct_complete > 0.60
            else "significantly incomplete"
        )
        dup_note = (
            f" {r.pct_duplicates*100:.1f}% of rows are duplicates."
            if r.pct_duplicates > 0.01 else ""
        )
        return (
            f"This is a {size_desc} dataset with {r.n_rows:,} rows and "
            f"{r.n_cols} columns ({r.memory_mb:.1f} MB). "
            f"It contains {r.n_numeric} numeric, {r.n_categorical} categorical, "
            f"{r.n_datetime} datetime, and {r.n_text} text column(s). "
            f"The data is {complete_desc} ({r.pct_complete*100:.1f}% cells present).{dup_note}"
        )

    def _column_insight(self, col: ColumnReport) -> str:
        parts: list[str] = []

        null_note = (
            f"Has {col.pct_null*100:.1f}% missing values."
            if col.pct_null > 0 else "No missing values."
        )
        parts.append(null_note)

        if col.numeric:
            ns = col.numeric
            parts.append(
                f"Ranges from {ns.min} to {ns.max} (mean: {ns.mean:.2f}, "
                f"median: {ns.median:.2f}, std: {ns.std:.2f})."
            )
            if abs(ns.skewness) > 0.5:
                direction = "right" if ns.skewness > 0 else "left"
                parts.append(f"Moderately {direction}-skewed (skewness: {ns.skewness:.2f}).")
            if ns.pct_outliers > 0.02:
                parts.append(f"{ns.pct_outliers*100:.1f}% of values are potential outliers.")
            if ns.best_distribution:
                parts.append(f"Best fits a {ns.best_distribution} distribution.")

        elif col.categorical:
            cs = col.categorical
            parts.append(
                f"Has {cs.n_unique} unique categories. "
                f"Most common: '{cs.top_value}' ({cs.top_pct*100:.1f}%)."
            )
            if cs.is_high_cardinality:
                parts.append("High cardinality — consider encoding carefully.")
            if len(cs.rare_values) > 0:
                parts.append(f"{len(cs.rare_values)} rare categories (<1% frequency).")

        elif col.datetime:
            ds = col.datetime
            parts.append(
                f"Covers {ds.range_days} days from {ds.min_date} to {ds.max_date}."
            )
            if ds.has_future_dates:
                parts.append("Contains future dates — verify if expected.")
            if ds.freq_detected:
                parts.append(f"Detected frequency: {ds.freq_detected}.")

        elif col.text:
            ts = col.text
            parts.append(
                f"Average {ts.avg_word_count:.1f} words per entry "
                f"(length range: {ts.min_length}–{ts.max_length} chars)."
            )

        if col.warnings:
            top_warn = col.warnings[0]
            parts.append(f"Note: {top_warn}")

        return " ".join(parts)

    def _quality_story(self, r: DatasetReport) -> str:
        issues: list[str] = []
        positives: list[str] = []

        if r.pct_complete >= 0.95:
            positives.append("excellent data completeness")
        elif r.pct_complete < 0.70:
            issues.append(f"low completeness ({r.pct_complete*100:.0f}%)")

        if r.pct_duplicates > 0.05:
            issues.append(f"significant duplicate rows ({r.pct_duplicates*100:.1f}%)")
        elif r.pct_duplicates == 0:
            positives.append("no duplicate rows")

        if r.n_constant > 0:
            issues.append(f"{r.n_constant} zero-variance column(s)")

        if r.n_id_cols > 0:
            issues.append(f"{r.n_id_cols} identifier column(s) detected")

        pos_str  = f"Strengths: {', '.join(positives)}. " if positives else ""
        iss_str  = (f"Issues to address: {', '.join(issues)}. "
                    if issues else "No major issues detected. ")

        return pos_str + iss_str

    def _ml_text(self, ml: MLReadinessScore) -> str:
        verdict_map = {
            "ready":      "ready for machine learning",
            "needs_work": "usable for ML but needs preprocessing",
            "not_ready":  "not yet ready for ML without significant work",
        }
        text = (
            f"ML Readiness Score: {ml.overall}/100 (Grade {ml.grade}) — "
            f"this dataset is {verdict_map.get(ml.verdict, ml.verdict)}. "
        )
        if ml.penalties:
            text += f"Key issues: {'; '.join(ml.penalties[:3])}. "
        if ml.bonuses:
            text += f"Positives: {'; '.join(ml.bonuses[:2])}."
        return text

    def _top_findings(
        self,
        r: DatasetReport,
        ml: MLReadinessScore | None,
        fixes: list[FixSuggestion] | None,
    ) -> list[str]:
        findings: list[str] = []

        # most-null column
        nulls = {col: rep.pct_null for col, rep in r.columns.items() if rep.pct_null > 0}
        if nulls:
            worst = max(nulls, key=nulls.get)
            findings.append(
                f"'{worst}' has the most missing data ({nulls[worst]*100:.1f}%)."
            )

        # strongest outlier column
        outlier_cols = {
            col: rep.numeric.pct_outliers
            for col, rep in r.columns.items()
            if rep.numeric and rep.numeric.pct_outliers > 0.02
        }
        if outlier_cols:
            worst_out = max(outlier_cols, key=outlier_cols.get)
            findings.append(
                f"'{worst_out}' has the most outliers "
                f"({outlier_cols[worst_out]*100:.1f}%)."
            )

        # dataset size note
        if r.n_rows < 200:
            findings.append(
                "Dataset is very small — statistical results may not generalise well."
            )
        elif r.n_rows > 100_000:
            findings.append("Large dataset — consider deep learning approaches.")

        # ML score
        if ml:
            findings.append(
                f"ML Readiness: {ml.overall}/100 (Grade {ml.grade}). "
                f"{'Ready to model!' if ml.verdict == 'ready' else 'Preprocessing needed.'}"
            )

        # critical fixes
        if fixes:
            critical = [f for f in fixes if f.severity == "critical"]
            if critical:
                findings.append(
                    f"{len(critical)} critical issue(s) need attention before modelling."
                )

        return findings[:6]


# ── LLM narrator (AI-powered) ─────────────────────────────────────────────────

class LLMNarrator:
    """
    Sends a structured summary to an LLM (OpenAI / Ollama) and gets
    a rich, human-readable narrative back.
    Falls back to RuleBasedNarrator if the API call fails.
    """

    def __init__(self, provider: str = "openai", api_key: str | None = None,
                 model: str = "gpt-4o-mini", ollama_url: str = "http://localhost:11434"):
        self.provider   = provider
        self.api_key    = api_key
        self.model      = model
        self.ollama_url = ollama_url
        self._fallback  = RuleBasedNarrator()

    def narrate(
        self,
        report:     DatasetReport,
        ml_score:   MLReadinessScore | None = None,
        fixes:      list[FixSuggestion] | None = None,
    ) -> Narrative:

        # build a compact JSON summary to send to the LLM
        prompt_data = self._build_prompt_data(report, ml_score, fixes)

        try:
            if self.provider == "openai":
                text = self._call_openai(prompt_data)
            elif self.provider == "ollama":
                text = self._call_ollama(prompt_data)
            else:
                return self._fallback.narrate(report, ml_score, fixes)
        except Exception as e:
            print(f"[DataLens] LLM call failed ({e}), falling back to rule-based narrator.")
            return self._fallback.narrate(report, ml_score, fixes)

        # parse structured JSON response from LLM
        try:
            parsed = json.loads(text)
            return Narrative(
                dataset_summary=parsed.get("dataset_summary", ""),
                column_insights=parsed.get("column_insights", {}),
                quality_story=parsed.get("quality_story", ""),
                ml_readiness_text=parsed.get("ml_readiness_text", ""),
                top_findings=parsed.get("top_findings", []),
                generated_by=self.provider,
            )
        except json.JSONDecodeError:
            # LLM returned plain text instead of JSON — use as summary
            rule_n = self._fallback.narrate(report, ml_score, fixes)
            rule_n.dataset_summary = text
            rule_n.generated_by = self.provider
            return rule_n

    def _build_prompt_data(
        self,
        report: DatasetReport,
        ml_score: MLReadinessScore | None,
        fixes: list[FixSuggestion] | None,
    ) -> str:
        cols_summary = {}
        for col, r in list(report.columns.items())[:20]:   # max 20 cols in prompt
            entry: dict = {
                "type": r.col_type.name,
                "pct_null": r.pct_null,
                "n_unique": r.n_unique,
                "warnings": r.warnings[:2],
            }
            if r.numeric:
                ns = r.numeric
                entry.update({
                    "mean": ns.mean, "std": ns.std,
                    "skewness": ns.skewness, "pct_outliers": ns.pct_outliers,
                })
            elif r.categorical:
                cs = r.categorical
                entry.update({
                    "top_value": cs.top_value, "top_pct": cs.top_pct,
                    "entropy": cs.entropy,
                })
            cols_summary[col] = entry

        data = {
            "dataset": {
                "n_rows": report.n_rows,
                "n_cols": report.n_cols,
                "pct_complete": report.pct_complete,
                "pct_duplicates": report.pct_duplicates,
                "n_numeric": report.n_numeric,
                "n_categorical": report.n_categorical,
                "n_datetime": report.n_datetime,
                "memory_mb": report.memory_mb,
            },
            "columns": cols_summary,
            "ml_score": {
                "overall": ml_score.overall,
                "grade": ml_score.grade,
                "breakdown": ml_score.breakdown,
                "penalties": ml_score.penalties[:5],
            } if ml_score else None,
            "critical_fixes": [
                {"title": f.title, "column": f.column}
                for f in (fixes or []) if f.severity == "critical"
            ][:5],
        }

        system = (
            "You are DataLens, an expert data scientist assistant. "
            "Analyse the dataset summary below and return a JSON object with these keys:\n"
            "  dataset_summary (string): 2-3 sentence overview\n"
            "  column_insights (object): column_name -> 1-2 sentence insight\n"
            "  quality_story (string): 2 sentences on data quality strengths and issues\n"
            "  ml_readiness_text (string): 2 sentences on ML readiness\n"
            "  top_findings (list of strings): 4-6 most important observations\n"
            "Return ONLY valid JSON, no markdown fences, no extra text."
        )
        user = f"Dataset summary:\n{json.dumps(data, indent=2)}"

        return json.dumps({"system": system, "user": user})

    def _call_openai(self, prompt_data: str) -> str:
        import openai
        msgs = json.loads(prompt_data)
        client = openai.OpenAI(api_key=self.api_key)
        resp = client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": msgs["system"]},
                {"role": "user",   "content": msgs["user"]},
            ],
            temperature=0.3,
            max_tokens=1500,
        )
        return resp.choices[0].message.content.strip()

    def _call_ollama(self, prompt_data: str) -> str:
        import requests
        msgs = json.loads(prompt_data)
        payload = {
            "model": self.model,
            "prompt": f"{msgs['system']}\n\n{msgs['user']}",
            "stream": False,
            "format": "json",
        }
        resp = requests.post(
            f"{self.ollama_url}/api/generate",
            json=payload,
            timeout=60,
        )
        resp.raise_for_status()
        return resp.json().get("response", "")


# ── public factory ────────────────────────────────────────────────────────────

def get_narrator(ai_enabled: bool = False, **kwargs):
    """Return the right narrator based on config."""
    if ai_enabled:
        return LLMNarrator(**kwargs)
    return RuleBasedNarrator()