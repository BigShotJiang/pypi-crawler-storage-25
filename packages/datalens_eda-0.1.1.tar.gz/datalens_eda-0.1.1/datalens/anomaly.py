from __future__ import annotations
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .detector import ColType, ColProfile


# ── result containers ─────────────────────────────────────────────────────────

@dataclass
class OutlierResult:
    column:      str
    method:      str          # zscore / iqr / isolation_forest
    n_outliers:  int
    pct_outliers: float
    outlier_indices: list[int]
    outlier_values:  list[float]
    lower_bound: float | None
    upper_bound: float | None
    severity:    str          # low / medium / high / critical


@dataclass
class ColumnAnomalyReport:
    column:       str
    zscore:       OutlierResult | None = None
    iqr:          OutlierResult | None = None
    isolation:    OutlierResult | None = None
    consensus_indices: list[int]       = field(default_factory=list)
    n_consensus:  int                  = 0
    verdict:      str                  = ""   # clean / mild / severe
    recommendation: str                = ""


@dataclass
class AnomalyReport:
    columns:        dict[str, ColumnAnomalyReport] = field(default_factory=dict)
    summary:        dict[str, int]                 = field(default_factory=dict)
    worst_columns:  list[str]                      = field(default_factory=list)
    warnings:       list[str]                      = field(default_factory=list)


# ── severity helper ───────────────────────────────────────────────────────────

def _severity(pct: float) -> str:
    if pct < 0.01: return "low"
    if pct < 0.05: return "medium"
    if pct < 0.15: return "high"
    return "critical"


# ── main detector ─────────────────────────────────────────────────────────────

class AnomalyDetector:
    """
    Detects outliers using 3 independent methods per numeric column:
      1. Z-Score   — standard deviations from mean (sensitive to normal data)
      2. IQR fence — Tukey fences (robust, non-parametric)
      3. Isolation Forest — ML-based (catches complex multivariate outliers)

    Consensus outliers = flagged by at least 2 out of 3 methods.
    """

    def __init__(self, zscore_threshold: float = 3.0, iqr_multiplier: float = 1.5):
        self.zscore_threshold = zscore_threshold
        self.iqr_multiplier   = iqr_multiplier

    def detect(
        self,
        df: pd.DataFrame,
        profiles: dict[str, ColProfile],
    ) -> AnomalyReport:

        report = AnomalyReport()
        numeric_cols = [
            col for col, prof in profiles.items()
            if prof.col_type in (
                ColType.NUMERIC_CONTINUOUS,
                ColType.NUMERIC_DISCRETE,
            )
        ]

        for col in numeric_cols:
            s     = df[col].dropna()
            if len(s) < 5:
                continue
            col_r = self._analyze_column(df[col], col, len(df))
            report.columns[col] = col_r

        # summary
        report.summary = {
            col: r.n_consensus
            for col, r in report.columns.items()
            if r.n_consensus > 0
        }
        report.worst_columns = sorted(
            report.summary, key=report.summary.get, reverse=True
        )[:5]
        report.warnings = self._build_warnings(report)
        return report

    # ── per-column ────────────────────────────────────────────────────────────

    def _analyze_column(
        self, s: pd.Series, col: str, n_total: int
    ) -> ColumnAnomalyReport:

        valid = s.dropna()
        arr   = valid.astype(float).values
        idx   = valid.index.tolist()

        zscore_r  = self._zscore(arr, idx, col, n_total)
        iqr_r     = self._iqr(arr, idx, col, n_total)
        iso_r     = self._isolation_forest(arr, idx, col, n_total)

        # consensus: indices flagged by >= 2 methods
        sets = [
            set(r.outlier_indices) for r in [zscore_r, iqr_r, iso_r]
            if r is not None
        ]
        if len(sets) >= 2:
            consensus = sets[0]
            for s2 in sets[1:]:
                consensus = consensus & s2 | (
                    (sets[0] | sets[1]) & sets[min(2, len(sets)-1)]
                    if len(sets) > 2 else set()
                )
            # simpler: flagged by at least 2
            from collections import Counter
            all_flagged = []
            for s_ in sets:
                all_flagged.extend(s_)
            cnt = Counter(all_flagged)
            consensus_idx = sorted([i for i, c in cnt.items() if c >= 2])
        else:
            consensus_idx = list(sets[0]) if sets else []

        n_con  = len(consensus_idx)
        pct    = n_con / max(n_total, 1)
        verdict = "clean" if pct == 0 else "mild" if pct < 0.05 else "severe"

        rec = self._recommendation(verdict, col, pct)

        return ColumnAnomalyReport(
            column=col,
            zscore=zscore_r,
            iqr=iqr_r,
            isolation=iso_r,
            consensus_indices=consensus_idx,
            n_consensus=n_con,
            verdict=verdict,
            recommendation=rec,
        )

    # ── method 1: z-score ─────────────────────────────────────────────────────

    def _zscore(
        self, arr: np.ndarray, idx: list, col: str, n_total: int
    ) -> OutlierResult:
        if len(arr) < 3:
            return self._empty_result(col, "zscore")

        z     = np.abs(scipy_stats.zscore(arr))
        mask  = z > self.zscore_threshold
        out_i = [idx[i] for i in np.where(mask)[0]]
        out_v = arr[mask].tolist()
        pct   = len(out_i) / max(n_total, 1)
        mean_ = arr.mean()
        std_  = arr.std()

        return OutlierResult(
            column=col,
            method="zscore",
            n_outliers=len(out_i),
            pct_outliers=round(pct, 4),
            outlier_indices=out_i,
            outlier_values=[round(v, 4) for v in out_v],
            lower_bound=round(mean_ - self.zscore_threshold * std_, 4),
            upper_bound=round(mean_ + self.zscore_threshold * std_, 4),
            severity=_severity(pct),
        )

    # ── method 2: IQR fence ───────────────────────────────────────────────────

    def _iqr(
        self, arr: np.ndarray, idx: list, col: str, n_total: int
    ) -> OutlierResult:
        q25, q75 = np.percentile(arr, [25, 75])
        iqr_val  = q75 - q25
        lower    = q25 - self.iqr_multiplier * iqr_val
        upper    = q75 + self.iqr_multiplier * iqr_val
        mask     = (arr < lower) | (arr > upper)
        out_i    = [idx[i] for i in np.where(mask)[0]]
        out_v    = arr[mask].tolist()
        pct      = len(out_i) / max(n_total, 1)

        return OutlierResult(
            column=col,
            method="iqr",
            n_outliers=len(out_i),
            pct_outliers=round(pct, 4),
            outlier_indices=out_i,
            outlier_values=[round(v, 4) for v in out_v],
            lower_bound=round(lower, 4),
            upper_bound=round(upper, 4),
            severity=_severity(pct),
        )

    # ── method 3: isolation forest ────────────────────────────────────────────

    def _isolation_forest(
        self, arr: np.ndarray, idx: list, col: str, n_total: int
    ) -> OutlierResult | None:
        try:
            from sklearn.ensemble import IsolationForest
        except ImportError:
            return None

        if len(arr) < 10:
            return None

        X    = arr.reshape(-1, 1)
        iso  = IsolationForest(contamination=0.05, random_state=42, n_jobs=-1)
        pred = iso.fit_predict(X)          # -1 = outlier, 1 = inlier
        mask = pred == -1
        out_i = [idx[i] for i in np.where(mask)[0]]
        out_v = arr[mask].tolist()
        pct   = len(out_i) / max(n_total, 1)

        return OutlierResult(
            column=col,
            method="isolation_forest",
            n_outliers=len(out_i),
            pct_outliers=round(pct, 4),
            outlier_indices=out_i,
            outlier_values=[round(v, 4) for v in out_v],
            lower_bound=None,
            upper_bound=None,
            severity=_severity(pct),
        )

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _empty_result(col: str, method: str) -> OutlierResult:
        return OutlierResult(col, method, 0, 0.0, [], [], None, None, "low")

    @staticmethod
    def _recommendation(verdict: str, col: str, pct: float) -> str:
        if verdict == "clean":
            return f"Column '{col}' looks clean — no outliers detected."
        if verdict == "mild":
            return (
                f"Column '{col}' has {pct*100:.1f}% outliers. "
                f"Consider: capping with IQR bounds, or log-transform if right-skewed."
            )
        return (
            f"Column '{col}' has {pct*100:.1f}% outliers — SEVERE. "
            f"Investigate: data entry errors, sensor faults, or genuine extreme events. "
            f"Options: remove, cap, or treat separately."
        )

    def _build_warnings(self, report: AnomalyReport) -> list[str]:
        w = []
        severe = [col for col, r in report.columns.items() if r.verdict == "severe"]
        mild   = [col for col, r in report.columns.items() if r.verdict == "mild"]
        if severe:
            w.append(f"SEVERE OUTLIERS in: {', '.join(severe)}")
        if mild:
            w.append(f"Mild outliers in: {', '.join(mild)}")
        if not severe and not mild:
            w.append("No significant outliers detected across numeric columns.")
        return w