from enum import Enum
import plotly.express as px

class ThemePalette(Enum):
    MODERN_DARK = "plotly_dark"
    CLEAN_LIGHT = "plotly_white"
    SEABORN = "seaborn"
    GGPLOT2 = "ggplot2"
    
def get_plotly_theme(theme_name: str) -> str:
    """Returns a valid Plotly template string based on a simple name."""
    mapping = {
        "dark": "plotly_dark",
        "light": "plotly_white",
        "modern": "plotly",
    }
    return mapping.get(theme_name.lower(), "plotly_dark")

def get_premium_colors():
    """Returns a curated list of hex colors for a gorgeous, premium UI feel."""
    return [
        "#0ea5e9", # Sky blue
        "#8b5cf6", # Violet
        "#10b981", # Emerald green
        "#f59e0b", # Amber
        "#ef4444", # Red
        "#ec4899", # Pink
        "#6366f1", # Indigo
    ]
    
def apply_custom_layout(fig, title: str = ""):
    """Standardizes margin, fonts, and backgrounds for an ultra-premium look."""
    fig.update_layout(
        title=dict(text=title, font=dict(family="Inter, sans-serif", size=20, color="#f1f5f9")),
        font=dict(family="Inter, sans-serif", color="#94a3b8"),
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        margin=dict(t=60, l=40, r=40, b=40),
        hoverlabel=dict(
            bgcolor="#1e293b",
            font_size=14,
            font_family="Inter, sans-serif",
            bordercolor="#334155"
        )
    )
    # Add subtle gridlines
    fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor="#334155")
    fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor="#334155")
    return fig
