from __future__ import annotations
import io
import pathlib
from typing import Any
from urllib.parse import urlparse

import pandas as pd

from .exceptions import UnsupportedFormatError, EmptyDataError, InsufficientDataError
from .config import config

SUPPORTED_FORMATS = ["csv", "xlsx", "xls", "json", "parquet", "feather",
                     "tsv", "sql", "url", "dataframe"]


class DataIngestor:
    """
    One entry point for all data sources.
    Returns a clean pd.DataFrame every time.
    """

    READERS: dict[str, Any] = {
        ".csv":     ("_read_csv",     {}),
        ".tsv":     ("_read_csv",     {"sep": "\t"}),
        ".xlsx":    ("_read_excel",   {}),
        ".xls":     ("_read_excel",   {}),
        ".json":    ("_read_json",    {}),
        ".parquet": ("_read_parquet", {}),
        ".feather": ("_read_feather", {}),
    }

    def load(
        self,
        source: str | pathlib.Path | pd.DataFrame,
        *,
        sql_query: str | None = None,
        sql_connection: Any = None,
        sample: bool | None = None,
        **read_kwargs,
    ) -> pd.DataFrame:

        # --- already a DataFrame ---
        if isinstance(source, pd.DataFrame):
            df = source.copy()

        # --- URL ---
        elif isinstance(source, str) and self._is_url(source):
            df = self._read_url(source, **read_kwargs)

        # --- SQL ---
        elif sql_query and sql_connection:
            df = pd.read_sql(sql_query, sql_connection)

        # --- file path ---
        else:
            path = pathlib.Path(source)
            suffix = path.suffix.lower()
            if suffix not in self.READERS:
                raise UnsupportedFormatError(suffix.lstrip("."), SUPPORTED_FORMATS)
            method_name, defaults = self.READERS[suffix]
            merged_kwargs = {**defaults, **read_kwargs}
            df = getattr(self, method_name)(path, **merged_kwargs)

        # --- validation ---
        self._validate(df)

        # --- optional smart sampling ---
        should_sample = sample if sample is not None else config.sampling.enabled
        if should_sample and len(df) > config.sampling.max_rows:
            df = self._smart_sample(df)

        return df.reset_index(drop=True)

    # ── readers ──────────────────────────────────────────────────────────────

    def _read_csv(self, path: pathlib.Path, **kw) -> pd.DataFrame:
        # auto-detect encoding
        try:
            return pd.read_csv(path, **kw)
        except UnicodeDecodeError:
            return pd.read_csv(path, encoding="latin-1", **kw)

    def _read_excel(self, path: pathlib.Path, **kw) -> pd.DataFrame:
        return pd.read_excel(path, engine="openpyxl", **kw)

    def _read_json(self, path: pathlib.Path, **kw) -> pd.DataFrame:
        try:
            return pd.read_json(path, **kw)
        except ValueError:
            # might be newline-delimited JSON
            return pd.read_json(path, lines=True, **kw)

    def _read_parquet(self, path: pathlib.Path, **kw) -> pd.DataFrame:
        return pd.read_parquet(path, **kw)

    def _read_feather(self, path: pathlib.Path, **kw) -> pd.DataFrame:
        return pd.read_feather(path, **kw)

    def _read_url(self, url: str, **kw) -> pd.DataFrame:
        import requests
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        ct = resp.headers.get("content-type", "")
        raw = io.BytesIO(resp.content)
        if "json" in ct:
            return pd.read_json(raw, **kw)
        # default assume CSV
        return pd.read_csv(raw, **kw)

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _is_url(s: str) -> bool:
        parsed = urlparse(s)
        return parsed.scheme in ("http", "https")

    @staticmethod
    def _validate(df: pd.DataFrame) -> None:
        if df.empty:
            raise EmptyDataError()
        if len(df) < 5:
            raise InsufficientDataError(len(df))

    def _smart_sample(self, df: pd.DataFrame) -> pd.DataFrame:
        """Stratified sample if a categorical column exists, else random."""
        n = config.sampling.max_rows
        cat_cols = df.select_dtypes(include="object").columns.tolist()
        if cat_cols:
            col = cat_cols[0]
            try:
                return (
                    df.groupby(col, group_keys=False)
                    .apply(lambda g: g.sample(
                        min(len(g), max(1, int(n * len(g) / len(df)))),
                        random_state=config.sampling.seed,
                    ))
                    .head(n)
                )
            except Exception:
                pass
        return df.sample(n, random_state=config.sampling.seed)