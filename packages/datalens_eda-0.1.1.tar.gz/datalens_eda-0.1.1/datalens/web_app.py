"""
datalens/web_app.py — Streamlit interactive dashboard.
Launch via:  result.show_browser()   OR   datalens serve myfile.csv
"""
import sys
import pickle
import pathlib

import pandas as pd
import streamlit as st

from datalens.detector import ColType          # FIXED: correct import
from datalens.charts import ChartGenerator

st.set_page_config(
    page_title="DataLens AutoEDA",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
h1,h2,h3{font-family:'Inter',sans-serif}
.metric-box{background:#1e293b;border-radius:8px;padding:15px;
  box-shadow:0 4px 6px rgba(0,0,0,.3);text-align:center;border:1px solid #334155}
.metric-value{font-size:2rem;font-weight:700;color:#38bdf8}
.metric-label{font-size:.9rem;color:#94a3b8;text-transform:uppercase;letter-spacing:1px}
</style>
""", unsafe_allow_html=True)


@st.cache_data
def _load(filepath: str):
    with open(filepath, "rb") as f:
        return pickle.load(f)


def _metric(label: str, value: str) -> str:
    return (
        f"<div class='metric-box'>"
        f"<div class='metric-value'>{value}</div>"
        f"<div class='metric-label'>{label}</div>"
        f"</div>"
    )


def run_app():
    if len(sys.argv) < 2:
        st.error("No payload. Use result.show_browser() or datalens serve myfile.csv")
        st.stop()
    try:
        result = _load(sys.argv[1])
    except Exception as e:
        st.error(f"Could not load analysis result: {e}")
        st.stop()

    df = result.df
    cg = ChartGenerator(theme="plotly_dark")

    with st.sidebar:
        st.title("🔍 DataLens")
        st.caption("Automated Exploratory Data Analysis")
        st.markdown("---")
        mode = st.radio("Navigation",
            ["Overview", "Column Details", "Correlations", "Fix Suggestions"])
        st.markdown("---")
        st.markdown(f"**Shape:** `{result.shape[0]:,}` rows × `{result.shape[1]}` cols")
        st.markdown(f"**Memory:** `{result.memory_mb:.1f} MB`")

    # ── Overview ──────────────────────────────────────────────────────────────
    if mode == "Overview":
        st.title("Dataset Overview")
        if result.ml_score:
            s = result.ml_score
            st.markdown(f"### ML Readiness: **{s.overall}/100** — Grade **{s.grade}**")
            if s.bonuses:   st.success(" | ".join(s.bonuses))
            if s.penalties: st.error(" | ".join(s.penalties))

        c1, c2, c3, c4 = st.columns(4)
        with c1: st.markdown(_metric("Completeness", f"{result.pct_complete*100:.1f}%"), unsafe_allow_html=True)
        with c2: st.markdown(_metric("Duplicates", str(result.n_duplicates)), unsafe_allow_html=True)
        with c3: st.markdown(_metric("Memory MB", f"{result.memory_mb:.1f}"), unsafe_allow_html=True)
        with c4: st.markdown(_metric("Load Time", f"{result.load_time_s:.2f}s"), unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        cc1, cc2 = st.columns(2)
        with cc1:
            st.subheader("Missing Values")
            st.plotly_chart(cg.plot_missing_values(df), use_container_width=True)
        with cc2:
            st.subheader("Sample Data")
            st.dataframe(df.head(10), use_container_width=True)

        if result.narrative:
            st.markdown("### AI Data Narrative")
            st.info(result.narrative.dataset_summary)
            if result.narrative.top_findings:
                st.markdown("**Top Findings:**")
                for finding in result.narrative.top_findings:
                    st.markdown(f"- {finding}")

    # ── Column Details ────────────────────────────────────────────────────────
    elif mode == "Column Details":
        st.title("Column Deep Dive")
        selected = st.selectbox("Select a feature:", list(result.profiles.keys()))
        prof     = result.profiles[selected]
        st.markdown(
            f"**Type:** `{prof.col_type.name}` &nbsp; "
            f"**Unique:** `{prof.n_unique}` &nbsp; "
            f"**Missing:** `{prof.pct_null*100:.1f}%`"
        )

        # FIXED: ColType imported correctly at top of file
        if prof.col_type in (ColType.NUMERIC_CONTINUOUS, ColType.NUMERIC_DISCRETE):
            st.plotly_chart(cg.plot_numeric_distribution(df, selected), use_container_width=True)
            if result.stats and selected in result.stats.columns:
                ns = result.stats.columns[selected].numeric
                if ns:
                    s1, s2, s3, s4 = st.columns(4)
                    s1.metric("Mean",     round(ns.mean, 2))
                    s2.metric("Median",   round(ns.median, 2))
                    s3.metric("Std Dev",  round(ns.std, 2))
                    s4.metric("Outliers", f"{ns.pct_outliers*100:.1f}%")

        elif prof.col_type in (ColType.CATEGORICAL_LOW, ColType.CATEGORICAL_HIGH, ColType.BOOLEAN):
            st.plotly_chart(cg.plot_categorical_distribution(df, selected), use_container_width=True)
            if result.stats and selected in result.stats.columns:
                cs = result.stats.columns[selected].categorical
                if cs:
                    st.caption(f"Top value: **{cs.top_value}** ({cs.top_pct*100:.1f}%) | Entropy: {cs.entropy:.2f}")

        elif prof.col_type == ColType.DATETIME:
            st.plotly_chart(cg.plot_datetime_trend(df, selected), use_container_width=True)
        else:
            st.info("No standard visualization for this column type.")
            st.write("Sample values:", prof.sample_values)

    # ── Correlations ──────────────────────────────────────────────────────────
    elif mode == "Correlations":
        st.title("Feature Interactions")
        if result.viz and "relationships" in result.viz:
            rel = result.viz["relationships"]
            st.plotly_chart(cg.plot_correlation_heatmap(rel.correlations), use_container_width=True)
            if rel.top_correlations:
                st.subheader("Strongest Relationships")
                corr_df = pd.DataFrame([{
                    "Feature A": c.col_a, "Feature B": c.col_b,
                    "Value": round(c.value, 4), "Method": c.method,
                    "Strength": c.strength, "Significant": c.significant,
                } for c in rel.top_correlations])
                st.dataframe(corr_df, use_container_width=True)
            if rel.multicollinear_pairs:
                st.error("Multicollinearity detected:")
                for a, b in rel.multicollinear_pairs:
                    st.write(f"- `{a}` ↔ `{b}`")
            if rel.vif_results:
                st.subheader("Variance Inflation Factors (VIF)")
                vif_df = pd.DataFrame([{"Column": v.column, "VIF": v.vif, "Warning": v.warning or "OK"} for v in rel.vif_results])
                st.dataframe(vif_df, use_container_width=True)
        else:
            st.warning("No relationship data available.")

    # ── Fix Suggestions ───────────────────────────────────────────────────────
    elif mode == "Fix Suggestions":
        st.title("Recommended Code Fixes")
        st.caption("Copy these snippets directly into your notebook.")
        if result.fix_suggestions:
            for fix in result.fix_suggestions:
                icon = "🚨" if fix.severity == "critical" else "⚠️" if fix.severity == "warning" else "💡"
                with st.expander(f"{icon} {fix.title}"):
                    st.write(f"**Explanation:** {fix.explanation}")
                    st.write(f"**Column:** `{fix.column or 'dataset-level'}` | **Effort:** {fix.effort} | **Impact:** {fix.impact}")
                    st.code(fix.code, language="python")
        else:
            st.success("Dataset looks clean — no fixes suggested!")


if __name__ == "__main__":
    run_app()
