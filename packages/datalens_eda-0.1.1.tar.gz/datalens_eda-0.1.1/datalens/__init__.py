"""
DataLens — The most intelligent AutoEDA library.
"""
from .core import DataLens, AnalysisResult
from .config import DataLensConfig, config
from .exceptions import DataLensError

__version__ = "0.1.0"
__all__ = ["DataLens", "AnalysisResult", "DataLensConfig", "config",
           "DataLensError", "analyze"]

# convenience shortcut: import datalens as dl; dl.analyze("data.csv")
_lens = DataLens()

def analyze(source, **kwargs) -> AnalysisResult:
    """Module-level shortcut for DataLens().analyze(source)."""
    return _lens.analyze(source, **kwargs)