from __future__ import annotations
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .detector import ColType, ColProfile


# ── result containers ─────────────────────────────────────────────────────────

@dataclass
class PairCorrelation:
    col_a:       str
    col_b:       str
    method:      str       # pearson / spearman / cramers_v / eta / point_biserial
    value:       float
    p_value:     float | None
    significant: bool      # p < 0.05
    strength:    str       # negligible / weak / moderate / strong / very strong
    direction:   str       # positive / negative / none


@dataclass
class VIFResult:
    column:  str
    vif:     float
    warning: str   # "" / "moderate" / "high" / "extreme"


@dataclass
class RelationshipReport:
    correlations:          list[PairCorrelation] = field(default_factory=list)
    top_correlations:      list[PairCorrelation] = field(default_factory=list)   # |r| > 0.5
    vif_results:           list[VIFResult]        = field(default_factory=list)
    multicollinear_pairs:  list[tuple[str, str]]  = field(default_factory=list)
    target_correlations:   list[PairCorrelation]  = field(default_factory=list)  # if target given
    warnings:              list[str]              = field(default_factory=list)


# ── helpers ───────────────────────────────────────────────────────────────────

def _strength_label(r: float) -> str:
    a = abs(r)
    if a < 0.10: return "negligible"
    if a < 0.30: return "weak"
    if a < 0.50: return "moderate"
    if a < 0.70: return "strong"
    return "very strong"


def _direction_label(r: float) -> str:
    if abs(r) < 0.05: return "none"
    return "positive" if r > 0 else "negative"


def _cramers_v(s1: pd.Series, s2: pd.Series) -> tuple[float, float | None]:
    """Cramér's V for two categorical columns."""
    ct    = pd.crosstab(s1.astype(str), s2.astype(str))
    chi2, p, _, _ = scipy_stats.chi2_contingency(ct)
    n     = ct.values.sum()
    k     = min(ct.shape) - 1
    if n == 0 or k == 0:
        return 0.0, None
    v = float(np.sqrt(chi2 / (n * k)))
    return min(v, 1.0), float(p)


def _eta_squared(numeric: pd.Series, categorical: pd.Series) -> tuple[float, float | None]:
    """Correlation ratio η² between a numeric and categorical column."""
    groups  = [numeric[categorical == cat].dropna().values
               for cat in categorical.unique()]
    groups  = [g for g in groups if len(g) > 0]
    if len(groups) < 2:
        return 0.0, None
    f, p = scipy_stats.f_oneway(*groups)
    # convert F to eta-squared approximation
    grand_mean = numeric.mean()
    ss_between = sum(len(g) * (g.mean() - grand_mean) ** 2 for g in groups)
    ss_total   = sum((numeric - grand_mean) ** 2)
    eta2 = float(ss_between / ss_total) if ss_total > 0 else 0.0
    return min(eta2 ** 0.5, 1.0), float(p)   # return sqrt for comparable scale


# ── main engine ───────────────────────────────────────────────────────────────

class RelationshipEngine:
    """
    Computes the right correlation method for every column pair automatically:
      - Numeric  ↔ Numeric   → Pearson + Spearman
      - Cat      ↔ Cat       → Cramér's V
      - Numeric  ↔ Cat       → Eta (η)
      - Boolean  ↔ Numeric   → Point-biserial
    Also computes VIF for multicollinearity detection.
    """

    def analyze(
        self,
        df: pd.DataFrame,
        profiles: dict[str, ColProfile],
        target: str | None = None,
        top_n: int = 20,
    ) -> RelationshipReport:

        report = RelationshipReport()

        # filter out ID/constant columns — useless for correlation
        usable = {
            col: prof for col, prof in profiles.items()
            if prof.col_type not in (ColType.ID_COLUMN, ColType.CONSTANT,
                                     ColType.TEXT, ColType.URL)
        }
        cols = list(usable.keys())

        # ── pairwise correlations ─────────────────────────────────────────────
        pairs: list[PairCorrelation] = []
        for i, col_a in enumerate(cols):
            for col_b in cols[i + 1:]:
                pair = self._compute_pair(
                    df[col_a], df[col_b],
                    col_a, col_b,
                    usable[col_a], usable[col_b],
                )
                if pair:
                    pairs.append(pair)

        report.correlations     = pairs
        report.top_correlations = sorted(
            [p for p in pairs if abs(p.value) >= 0.5],
            key=lambda x: abs(x.value), reverse=True
        )[:top_n]

        # ── VIF (numeric columns only) ────────────────────────────────────────
        numeric_cols = [c for c, p in usable.items()
                        if p.col_type in (ColType.NUMERIC_CONTINUOUS,
                                          ColType.NUMERIC_DISCRETE)]
        if len(numeric_cols) >= 2:
            report.vif_results = self._compute_vif(df[numeric_cols].dropna())

        report.multicollinear_pairs = [
            (p.col_a, p.col_b) for p in pairs
            if abs(p.value) > 0.85 and p.method in ("pearson", "spearman")
        ]

        # ── target correlations ───────────────────────────────────────────────
        if target and target in usable:
            report.target_correlations = sorted(
                [p for p in pairs if target in (p.col_a, p.col_b)],
                key=lambda x: abs(x.value), reverse=True,
            )

        report.warnings = self._build_warnings(report)
        return report

    # ── pair computation ──────────────────────────────────────────────────────

    def _compute_pair(
        self,
        sa: pd.Series, sb: pd.Series,
        col_a: str, col_b: str,
        prof_a: ColProfile, prof_b: ColProfile,
    ) -> PairCorrelation | None:

        _NUM = {ColType.NUMERIC_CONTINUOUS, ColType.NUMERIC_DISCRETE,
                ColType.GEOSPATIAL_LAT, ColType.GEOSPATIAL_LON}
        _CAT = {ColType.CATEGORICAL_LOW, ColType.CATEGORICAL_HIGH,
                ColType.BOOLEAN, ColType.EMAIL}

        a_num = prof_a.col_type in _NUM
        b_num = prof_b.col_type in _NUM
        a_cat = prof_a.col_type in _CAT
        b_cat = prof_b.col_type in _CAT

        # align and drop nulls
        combined = pd.concat([sa, sb], axis=1).dropna()
        if len(combined) < 5:
            return None
        xa, xb = combined.iloc[:, 0], combined.iloc[:, 1]

        value, p_value, method = 0.0, None, "unknown"

        if a_num and b_num:
            # Pearson (linear) + Spearman (monotonic) — report stronger one
            r_p, p_p = scipy_stats.pearsonr(xa.astype(float), xb.astype(float))
            r_s, p_s = scipy_stats.spearmanr(xa.astype(float), xb.astype(float))
            if abs(r_p) >= abs(r_s):
                value, p_value, method = float(r_p), float(p_p), "pearson"
            else:
                value, p_value, method = float(r_s), float(p_s), "spearman"

        elif a_cat and b_cat:
            value, p_value = _cramers_v(xa, xb)
            method = "cramers_v"

        elif a_num and b_cat:
            value, p_value = _eta_squared(xa.astype(float), xb)
            method = "eta"

        elif a_cat and b_num:
            value, p_value = _eta_squared(xb.astype(float), xa)
            method = "eta"

        else:
            return None

        significant = (p_value is not None and p_value < 0.05)

        return PairCorrelation(
            col_a=col_a,
            col_b=col_b,
            method=method,
            value=round(value, 4),
            p_value=round(p_value, 4) if p_value is not None else None,
            significant=significant,
            strength=_strength_label(value),
            direction=_direction_label(value),
        )

    # ── VIF ───────────────────────────────────────────────────────────────────

    def _compute_vif(self, df_num: pd.DataFrame) -> list[VIFResult]:
        from numpy.linalg import lstsq
        results = []
        cols = list(df_num.columns)
        X = df_num.values.astype(float)

        for i, col in enumerate(cols):
            y   = X[:, i]
            X_  = np.delete(X, i, axis=1)
            # add intercept
            X_  = np.hstack([np.ones((len(X_), 1)), X_])
            try:
                coef, _, _, _ = lstsq(X_, y, rcond=None)
                y_hat  = X_ @ coef
                ss_res = np.sum((y - y_hat) ** 2)
                ss_tot = np.sum((y - y.mean()) ** 2)
                r2     = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
                vif    = 1 / (1 - r2) if r2 < 1.0 else float("inf")
            except Exception:
                vif = float("inf")

            vif_r  = round(float(vif), 2)
            warn   = ("" if vif_r < 5
                      else "moderate" if vif_r < 10
                      else "high"     if vif_r < 20
                      else "extreme")
            results.append(VIFResult(column=col, vif=vif_r, warning=warn))

        return sorted(results, key=lambda x: x.vif, reverse=True)

    # ── warnings ──────────────────────────────────────────────────────────────

    def _build_warnings(self, report: RelationshipReport) -> list[str]:
        w = []
        if report.multicollinear_pairs:
            pairs_str = ", ".join(f"({a} ↔ {b})"
                                  for a, b in report.multicollinear_pairs[:5])
            w.append(f"MULTICOLLINEARITY: highly correlated pairs: {pairs_str}")

        extreme_vif = [v for v in report.vif_results if v.warning in ("high", "extreme")]
        if extreme_vif:
            cols_str = ", ".join(v.column for v in extreme_vif)
            w.append(f"HIGH VIF: consider removing/combining: {cols_str}")

        if not report.top_correlations:
            w.append("LOW CORRELATION: no strong relationships found (|r| < 0.5)")

        return w