from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .detector import ColType, ColProfile


# ── result containers ─────────────────────────────────────────────────────────

@dataclass
class NumericStats:
    # central tendency
    mean:       float = 0.0
    median:     float = 0.0
    mode:       float | None = None
    trimmed_mean_10: float = 0.0   # 10% trimmed mean

    # spread
    std:        float = 0.0
    variance:   float = 0.0
    iqr:        float = 0.0
    mad:        float = 0.0        # median absolute deviation
    cv:         float = 0.0        # coefficient of variation (std/mean)
    range:      float = 0.0

    # shape
    skewness:   float = 0.0
    kurtosis:   float = 0.0        # excess kurtosis
    is_normal:  bool  = False      # Shapiro-Wilk p > 0.05
    normality_p: float = 0.0

    # percentiles
    p1:   float = 0.0
    p5:   float = 0.0
    p25:  float = 0.0
    p75:  float = 0.0
    p95:  float = 0.0
    p99:  float = 0.0
    min:  float = 0.0
    max:  float = 0.0

    # outliers
    n_outliers_zscore: int = 0
    n_outliers_iqr:    int = 0
    pct_outliers:      float = 0.0

    # distribution fit (best fitting)
    best_distribution: str = ""
    dist_fit_score:    float = 0.0

    # zeros & negatives
    n_zeros:    int = 0
    pct_zeros:  float = 0.0
    n_negative: int = 0
    has_inf:    bool = False


@dataclass
class CategoricalStats:
    n_unique:       int   = 0
    top_value:      str   = ""
    top_freq:       int   = 0
    top_pct:        float = 0.0
    bottom_value:   str   = ""
    bottom_freq:    int   = 0
    entropy:        float = 0.0    # Shannon entropy — measures diversity
    is_high_cardinality: bool = False
    value_counts:   dict  = field(default_factory=dict)   # top 10
    rare_values:    list  = field(default_factory=list)   # freq < 1%


@dataclass
class DatetimeStats:
    min_date:       str   = ""
    max_date:       str   = ""
    range_days:     int   = 0
    n_unique_dates: int   = 0
    most_common_year:  int | None = None
    most_common_month: int | None = None
    most_common_dow:   str | None = None   # day of week
    has_future_dates:  bool = False
    has_past_1900:     bool = False
    freq_detected:     str  = ""   # D, W, M, Q, Y or ""


@dataclass
class TextStats:
    avg_length:     float = 0.0
    min_length:     int   = 0
    max_length:     int   = 0
    avg_word_count: float = 0.0
    n_unique:       int   = 0
    pct_unique:     float = 0.0
    most_common:    list  = field(default_factory=list)


@dataclass
class ColumnReport:
    name:        str
    col_type:    ColType
    n_total:     int
    n_null:      int
    pct_null:    float
    n_unique:    int
    pct_unique:  float
    sample_values: list
    # only one of these will be populated based on col_type
    numeric:     NumericStats     | None = None
    categorical: CategoricalStats | None = None
    datetime:    DatetimeStats    | None = None
    text:        TextStats        | None = None
    # human-readable flags
    warnings:    list[str] = field(default_factory=list)


@dataclass
class DatasetReport:
    n_rows:         int
    n_cols:         int
    n_duplicates:   int
    pct_duplicates: float
    memory_mb:      float
    pct_complete:   float
    n_numeric:      int
    n_categorical:  int
    n_datetime:     int
    n_text:         int
    n_boolean:      int
    n_id_cols:      int
    n_constant:     int
    columns: dict[str, ColumnReport] = field(default_factory=dict)
    dataset_warnings: list[str]      = field(default_factory=list)


# ── main profiler ─────────────────────────────────────────────────────────────

_DISTRIBUTIONS = ["norm", "expon", "lognorm", "gamma", "beta",
                  "weibull_min", "uniform", "laplace", "logistic"]

_DOW_MAP = {0:"Monday", 1:"Tuesday", 2:"Wednesday",
            3:"Thursday", 4:"Friday", 5:"Saturday", 6:"Sunday"}


class Profiler:
    """
    Computes 100+ statistics per column and dataset-level quality metrics.
    Works on any DataFrame that has been processed by ColumnDetector.
    """

    def profile(
        self,
        df: pd.DataFrame,
        profiles: dict[str, ColProfile],
    ) -> DatasetReport:
        n_rows, n_cols = df.shape

        # dataset-level counts
        type_counts = self._type_counts(profiles)

        report = DatasetReport(
            n_rows=n_rows,
            n_cols=n_cols,
            n_duplicates=int(df.duplicated().sum()),
            pct_duplicates=round(df.duplicated().mean(), 4),
            memory_mb=round(df.memory_usage(deep=True).sum() / 1e6, 3),
            pct_complete=round(1 - df.isna().mean().mean(), 4),
            **type_counts,
        )

        for col, prof in profiles.items():
            report.columns[col] = self._profile_column(df[col], prof)

        report.dataset_warnings = self._dataset_warnings(report, df)
        return report

    # ── per-column dispatcher ─────────────────────────────────────────────────

    def _profile_column(self, s: pd.Series, prof: ColProfile) -> ColumnReport:
        n_total  = len(s)
        n_null   = int(s.isna().sum())
        n_unique = int(s.nunique())

        col_rep = ColumnReport(
            name=prof.name,
            col_type=prof.col_type,
            n_total=n_total,
            n_null=n_null,
            pct_null=round(n_null / n_total, 4),
            n_unique=n_unique,
            pct_unique=round(n_unique / max(n_total, 1), 4),
            sample_values=s.dropna().head(5).tolist(),
        )

        clean = s.dropna()

        if prof.col_type in (
            ColType.NUMERIC_CONTINUOUS,
            ColType.NUMERIC_DISCRETE,
            ColType.GEOSPATIAL_LAT,
            ColType.GEOSPATIAL_LON,
        ):
            col_rep.numeric  = self._numeric_stats(clean)
            col_rep.warnings = self._numeric_warnings(col_rep.numeric, prof)

        elif prof.col_type in (
            ColType.CATEGORICAL_LOW,
            ColType.CATEGORICAL_HIGH,
            ColType.BOOLEAN,
            ColType.EMAIL,
            ColType.URL,
            ColType.PHONE,
        ):
            col_rep.categorical = self._categorical_stats(clean)
            col_rep.warnings    = self._categorical_warnings(col_rep.categorical, prof)

        elif prof.col_type == ColType.DATETIME:
            col_rep.datetime = self._datetime_stats(s)
            col_rep.warnings = self._datetime_warnings(col_rep.datetime)

        elif prof.col_type == ColType.TEXT:
            col_rep.text = self._text_stats(clean)

        # universal null warning
        if col_rep.pct_null > 0.3:
            col_rep.warnings.append(
                f"HIGH NULLS: {col_rep.pct_null*100:.1f}% missing values"
            )
        elif col_rep.pct_null > 0.05:
            col_rep.warnings.append(
                f"Nulls present: {col_rep.pct_null*100:.1f}% missing"
            )

        return col_rep

    # ── numeric ───────────────────────────────────────────────────────────────

    def _numeric_stats(self, s: pd.Series) -> NumericStats:
        arr = s.astype(float).values
        n   = len(arr)

        if n == 0:
            return NumericStats()

        q25, q50, q75 = np.percentile(arr, [25, 50, 75])
        iqr_val = float(q75 - q25)
        mean_   = float(np.mean(arr))
        std_    = float(np.std(arr, ddof=1)) if n > 1 else 0.0

        # outliers
        z_scores    = np.abs(scipy_stats.zscore(arr)) if n > 2 else np.zeros(n)
        n_out_z     = int((z_scores > 3).sum())
        lower, upper = q25 - 1.5 * iqr_val, q75 + 1.5 * iqr_val
        n_out_iqr   = int(((arr < lower) | (arr > upper)).sum())

        # normality (Shapiro-Wilk, max 5000 samples)
        is_normal, norm_p = False, 0.0
        if 3 <= n <= 5000:
            try:
                _, norm_p = scipy_stats.shapiro(arr if n <= 5000 else
                                                 np.random.choice(arr, 5000, replace=False))
                is_normal = norm_p > 0.05
            except Exception:
                pass

        # trimmed mean
        try:
            trimmed = float(scipy_stats.trim_mean(arr, 0.10))
        except Exception:
            trimmed = mean_

        # mode
        try:
            mode_val = float(scipy_stats.mode(arr, keepdims=True).mode[0])
        except Exception:
            mode_val = None

        # MAD
        mad = float(np.median(np.abs(arr - np.median(arr))))

        # best distribution fit (top candidate only, fast)
        best_dist, best_score = self._fit_distribution(arr)

        return NumericStats(
            mean=round(mean_, 6),
            median=round(float(q50), 6),
            mode=round(mode_val, 6) if mode_val is not None else None,
            trimmed_mean_10=round(trimmed, 6),
            std=round(std_, 6),
            variance=round(float(np.var(arr, ddof=1)) if n > 1 else 0.0, 6),
            iqr=round(iqr_val, 6),
            mad=round(mad, 6),
            cv=round(std_ / mean_, 4) if mean_ != 0 else 0.0,
            range=round(float(arr.max() - arr.min()), 6),
            skewness=round(float(scipy_stats.skew(arr)), 4),
            kurtosis=round(float(scipy_stats.kurtosis(arr)), 4),
            is_normal=is_normal,
            normality_p=round(norm_p, 4),
            p1=round(float(np.percentile(arr, 1)), 4),
            p5=round(float(np.percentile(arr, 5)), 4),
            p25=round(float(q25), 4),
            p75=round(float(q75), 4),
            p95=round(float(np.percentile(arr, 95)), 4),
            p99=round(float(np.percentile(arr, 99)), 4),
            min=round(float(arr.min()), 4),
            max=round(float(arr.max()), 4),
            n_outliers_zscore=n_out_z,
            n_outliers_iqr=n_out_iqr,
            pct_outliers=round(max(n_out_z, n_out_iqr) / n, 4),
            best_distribution=best_dist,
            dist_fit_score=round(best_score, 4),
            n_zeros=int((arr == 0).sum()),
            pct_zeros=round((arr == 0).mean(), 4),
            n_negative=int((arr < 0).sum()),
            has_inf=bool(np.isinf(arr).any()),
        )

    def _fit_distribution(self, arr: np.ndarray) -> tuple[str, float]:
        """Try top distributions, return best by KS statistic (lower = better)."""
        if len(arr) < 10:
            return "", 0.0
        sample = arr if len(arr) <= 2000 else np.random.choice(arr, 2000, replace=False)
        best_name, best_ks = "", 1.0
        for dist_name in _DISTRIBUTIONS:
            try:
                dist  = getattr(scipy_stats, dist_name)
                params = dist.fit(sample)
                ks, _ = scipy_stats.kstest(sample, dist_name, args=params)
                if ks < best_ks:
                    best_ks, best_name = ks, dist_name
            except Exception:
                continue
        return best_name, 1 - best_ks   # convert to score: higher = better fit

    # ── categorical ───────────────────────────────────────────────────────────

    def _categorical_stats(self, s: pd.Series) -> CategoricalStats:
        vc    = s.astype(str).value_counts()
        n     = len(s)
        probs = vc / n
        entropy = float(-(probs * np.log2(probs + 1e-12)).sum())

        top_val   = str(vc.index[0]) if len(vc) else ""
        top_freq  = int(vc.iloc[0])  if len(vc) else 0
        bot_val   = str(vc.index[-1]) if len(vc) else ""
        bot_freq  = int(vc.iloc[-1])  if len(vc) else 0

        rare = [v for v, c in vc.items() if c / n < 0.01]

        return CategoricalStats(
            n_unique=int(s.nunique()),
            top_value=top_val,
            top_freq=top_freq,
            top_pct=round(top_freq / max(n, 1), 4),
            bottom_value=bot_val,
            bottom_freq=bot_freq,
            entropy=round(entropy, 4),
            is_high_cardinality=s.nunique() > 20,
            value_counts=vc.head(10).to_dict(),
            rare_values=rare[:10],
        )

    # ── datetime ──────────────────────────────────────────────────────────────

    def _datetime_stats(self, s: pd.Series) -> DatetimeStats:
        try:
            dt = pd.to_datetime(s, infer_datetime_format=True, errors="coerce").dropna()
        except Exception:
            return DatetimeStats()

        if len(dt) == 0:
            return DatetimeStats()

        now      = pd.Timestamp.now()
        range_d  = int((dt.max() - dt.min()).days)
        dow_mode = _DOW_MAP.get(int(dt.dt.dayofweek.mode()[0]), "") if len(dt) else ""

        freq = ""
        try:
            inferred = pd.infer_freq(dt.sort_values())
            freq = inferred or ""
        except Exception:
            pass

        return DatetimeStats(
            min_date=str(dt.min().date()),
            max_date=str(dt.max().date()),
            range_days=range_d,
            n_unique_dates=int(dt.nunique()),
            most_common_year=int(dt.dt.year.mode()[0]) if len(dt) else None,
            most_common_month=int(dt.dt.month.mode()[0]) if len(dt) else None,
            most_common_dow=dow_mode,
            has_future_dates=bool((dt > now).any()),
            has_past_1900=bool((dt.dt.year < 1900).any()),
            freq_detected=freq,
        )

    # ── text ──────────────────────────────────────────────────────────────────

    def _text_stats(self, s: pd.Series) -> TextStats:
        lengths    = s.astype(str).str.len()
        word_counts = s.astype(str).str.split().str.len()
        vc          = s.value_counts().head(5)

        return TextStats(
            avg_length=round(float(lengths.mean()), 2),
            min_length=int(lengths.min()),
            max_length=int(lengths.max()),
            avg_word_count=round(float(word_counts.mean()), 2),
            n_unique=int(s.nunique()),
            pct_unique=round(s.nunique() / max(len(s), 1), 4),
            most_common=list(vc.index),
        )

    # ── warnings ──────────────────────────────────────────────────────────────

    def _numeric_warnings(self, ns: NumericStats, prof: ColProfile) -> list[str]:
        w = []
        if ns.pct_outliers > 0.05:
            w.append(f"OUTLIERS: {ns.pct_outliers*100:.1f}% of values are outliers")
        if abs(ns.skewness) > 1:
            direction = "right (positive)" if ns.skewness > 0 else "left (negative)"
            w.append(f"HIGH SKEW: distribution is skewed {direction} ({ns.skewness:.2f})")
        if ns.pct_zeros > 0.5:
            w.append(f"ZERO HEAVY: {ns.pct_zeros*100:.1f}% values are zero")
        if ns.has_inf:
            w.append("INFINITE VALUES: column contains Inf or -Inf")
        if ns.cv > 1:
            w.append(f"HIGH VARIANCE: coefficient of variation = {ns.cv:.2f}")
        if not ns.is_normal:
            w.append("NON-NORMAL: data does not follow a normal distribution")
        return w

    def _categorical_warnings(self, cs: CategoricalStats, prof: ColProfile) -> list[str]:
        w = []
        if cs.top_pct > 0.9:
            w.append(f"DOMINANT VALUE: '{cs.top_value}' appears in {cs.top_pct*100:.1f}% of rows")
        if cs.is_high_cardinality:
            w.append(f"HIGH CARDINALITY: {cs.n_unique} unique values — consider encoding strategy")
        if len(cs.rare_values) > 0:
            w.append(f"RARE VALUES: {len(cs.rare_values)} categories appear in <1% of rows")
        if cs.entropy < 0.5:
            w.append("LOW ENTROPY: column has very little diversity")
        return w

    def _datetime_warnings(self, ds: DatetimeStats) -> list[str]:
        w = []
        if ds.has_future_dates:
            w.append("FUTURE DATES: column contains dates in the future")
        if ds.has_past_1900:
            w.append("SUSPICIOUS DATES: some dates are before year 1900")
        return w

    def _dataset_warnings(self, report: DatasetReport, df: pd.DataFrame) -> list[str]:
        w = []
        if report.pct_duplicates > 0.05:
            w.append(f"DUPLICATES: {report.pct_duplicates*100:.1f}% of rows are duplicates")
        if report.pct_complete < 0.8:
            w.append(f"LOW COMPLETENESS: only {report.pct_complete*100:.1f}% cells have values")
        if report.n_constant > 0:
            w.append(f"CONSTANT COLUMNS: {report.n_constant} columns have only 1 unique value")
        if report.n_id_cols > 0:
            w.append(f"ID COLUMNS DETECTED: {report.n_id_cols} columns look like identifiers")
        if report.n_rows < 100:
            w.append(f"SMALL DATASET: only {report.n_rows} rows — stats may not be reliable")
        return w

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _type_counts(profiles: dict[str, ColProfile]) -> dict[str, int]:
        from collections import Counter
        counts = Counter(p.col_type for p in profiles.values())
        return {
            "n_numeric":     counts.get(ColType.NUMERIC_CONTINUOUS, 0) +
                             counts.get(ColType.NUMERIC_DISCRETE, 0),
            "n_categorical": counts.get(ColType.CATEGORICAL_LOW, 0) +
                             counts.get(ColType.CATEGORICAL_HIGH, 0),
            "n_datetime":    counts.get(ColType.DATETIME, 0),
            "n_text":        counts.get(ColType.TEXT, 0),
            "n_boolean":     counts.get(ColType.BOOLEAN, 0),
            "n_id_cols":     counts.get(ColType.ID_COLUMN, 0),
            "n_constant":    counts.get(ColType.CONSTANT, 0),
        }