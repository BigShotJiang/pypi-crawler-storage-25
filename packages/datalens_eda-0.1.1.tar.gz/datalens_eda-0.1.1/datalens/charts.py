from __future__ import annotations
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np

# We'll rely on dictionaries and raw data to avoid circular imports.

class ChartGenerator:
    """
    Generates standard interactive Plotly visualizations for DataLens.
    """
    def __init__(self, theme: str = "plotly_dark"):
        self.theme = theme
        # Use a rich color palette to make it look premium
        self.color_discrete_sequence = px.colors.qualitative.Pastel

    def plot_numeric_distribution(self, df: pd.DataFrame, col_name: str) -> go.Figure:
        """Plots a histogram with a marginal box plot for numeric columns."""
        s = df[col_name].dropna()
        if s.empty:
            return go.Figure()

        fig = px.histogram(
            df, 
            x=col_name,
            marginal="box", # Adds a boxplot above the histogram
            nbins=50,
            title=f"Distribution of <b>{col_name}</b>",
            template=self.theme,
            color_discrete_sequence=[self.color_discrete_sequence[0]]
        )
        fig.update_layout(
            bargap=0.1,
            margin=dict(t=50, l=20, r=20, b=20),
            hoverlabel=dict(bgcolor="rgba(0,0,0,0.8)", font_size=14)
        )
        return fig

    def plot_categorical_distribution(self, df: pd.DataFrame, col_name: str, top_n: int = 15) -> go.Figure:
        """Plots a sleek bar chart for categorical properties."""
        s = df[col_name].astype(str).dropna()
        if s.empty:
            return go.Figure()
            
        vc = s.value_counts().head(top_n)
        plot_df = pd.DataFrame({"Category": vc.index, "Count": vc.values})
        plot_df = plot_df.sort_values("Count", ascending=True) # For horizontal bar
        
        fig = px.bar(
            plot_df, 
            x="Count", 
            y="Category",
            orientation="h",
            title=f"Top {top_n} Categories in <b>{col_name}</b>",
            template=self.theme,
            color="Count",
            color_continuous_scale=px.colors.sequential.Blues
        )
        fig.update_layout(
            margin=dict(t=50, l=20, r=20, b=20),
            coloraxis_showscale=False # hide colorbar for cleaner look
        )
        return fig

    def plot_correlation_heatmap(self, correlations: list) -> go.Figure:
        """
        Takes a list of PairCorrelation objects and plots a heatmap.
        We build a symmetric matrix from the pairwise lists.
        """
        if not correlations:
            return go.Figure()
            
        # Extract unique columns
        cols = set()
        for p in correlations:
            cols.add(p.col_a)
            cols.add(p.col_b)
        cols = sorted(list(cols))
        
        if not cols:
            return go.Figure()
            
        # Initialize matrix with NaN, except diagonal = 1.0
        n = len(cols)
        matrix = np.full((n, n), np.nan)
        np.fill_diagonal(matrix, 1.0)
        
        col_idx = {c: i for i, c in enumerate(cols)}
        
        # Fill in the values (symmetric)
        for p in correlations:
            i, j = col_idx[p.col_a], col_idx[p.col_b]
            matrix[i, j] = p.value
            matrix[j, i] = p.value
            
        # We need a heatmap
        fig = px.imshow(
            matrix,
            x=cols,
            y=cols,
            color_continuous_scale="RdBu_r",
            zmin=-1, zmax=1,
            title="Interactive Feature Correlation Matrix",
            template=self.theme
        )
        fig.update_layout(
            margin=dict(t=50, l=50, r=20, b=50),
            xaxis_tickangle=-45
        )
        return fig

    def plot_missing_values(self, df: pd.DataFrame) -> go.Figure:
        """Plots a bar chart showing the percentage of missing values per column."""
        missing = df.isna().mean().sort_values(ascending=False)
        missing = missing[missing > 0]
        
        if missing.empty:
            # Return an empty dummy plot or a nice message
            fig = go.Figure()
            fig.add_annotation(text="No Missing Data!", showarrow=False, font_size=20)
            fig.update_layout(template=self.theme)
            return fig
            
        plot_df = pd.DataFrame({"Feature": missing.index, "Missing (%)": missing.values * 100})
        fig = px.bar(
            plot_df, 
            x="Feature", 
            y="Missing (%)",
            title="Missing Values Overview",
            template=self.theme,
            color="Missing (%)",
            color_continuous_scale=px.colors.sequential.OrRd
        )
        fig.update_layout(xaxis_tickangle=-45, coloraxis_showscale=False)
        return fig

    def plot_datetime_trend(self, df: pd.DataFrame, col_name: str) -> go.Figure:
        """Plots a time series count of rows per day/month."""
        s = pd.to_datetime(df[col_name], errors="coerce").dropna()
        if s.empty:
            return go.Figure()
            
        # Count by day if < 1000 days, else by month
        range_days = (s.max() - s.min()).days
        freq = "D" if range_days <= 730 else "M"
        
        counts = s.dt.to_period(freq).value_counts().sort_index()
        counts.index = counts.index.to_timestamp()
        
        plot_df = pd.DataFrame({"Date": counts.index, "Count": counts.values})
        fig = px.line(
            plot_df, 
            x="Date", 
            y="Count",
            title=f"Record Frequency over Time (<b>{col_name}</b>)",
            template=self.theme
        )
        # Add slight area fill for premium feel
        fig.update_traces(fill="tozeroy", line_color=self.color_discrete_sequence[2])
        return fig

