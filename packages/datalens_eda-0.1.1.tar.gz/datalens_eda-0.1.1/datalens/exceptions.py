class DataLensError(Exception):
    """Base exception for all DataLens errors."""

class UnsupportedFormatError(DataLensError):
    def __init__(self, fmt: str, supported: list[str]):
        self.fmt = fmt
        super().__init__(
            f"Format '{fmt}' is not supported.\n"
            f"Supported formats: {', '.join(supported)}\n"
            f"Tip: Pass a DataFrame directly with dl.analyze(df)"
        )

class EmptyDataError(DataLensError):
    def __init__(self):
        super().__init__(
            "The dataset is empty (0 rows). "
            "Please provide a dataset with at least 1 row."
        )

class InsufficientDataError(DataLensError):
    def __init__(self, n_rows: int, minimum: int = 5):
        super().__init__(
            f"Dataset has only {n_rows} row(s). "
            f"DataLens needs at least {minimum} rows for meaningful analysis."
        )

class ColumnNotFoundError(DataLensError):
    def __init__(self, col: str, available: list[str]):
        super().__init__(
            f"Column '{col}' not found.\n"
            f"Available columns: {', '.join(available[:10])}"
            + ("..." if len(available) > 10 else "")
        )