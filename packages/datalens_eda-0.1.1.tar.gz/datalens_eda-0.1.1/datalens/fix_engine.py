from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto

import pandas as pd

from .detector import ColType, ColProfile
from .profiler import ColumnReport, DatasetReport


# ── enums & containers ────────────────────────────────────────────────────────

class FixCategory(Enum):
    NULL_HANDLING    = auto()
    OUTLIER_HANDLING = auto()
    ENCODING         = auto()
    TYPE_CONVERSION  = auto()
    FEATURE_REMOVAL  = auto()
    SCALING          = auto()
    SKEW_CORRECTION  = auto()
    DEDUPLICATION    = auto()
    DATE_EXTRACTION  = auto()
    TEXT_PROCESSING  = auto()


@dataclass
class FixSuggestion:
    column:     str | None          # None = dataset-level fix
    category:   FixCategory
    severity:   str                 # info / warning / critical
    title:      str
    explanation: str
    code:       str                 # ready-to-paste Python code
    effort:     str                 # low / medium / high
    impact:     str                 # low / medium / high


# ── engine ────────────────────────────────────────────────────────────────────

class FixEngine:
    """
    Inspects ColumnReports and DatasetReport, then generates actionable
    fix suggestions WITH copy-paste Python code for each issue found.
    """

    def generate(
        self,
        dataset_report: DatasetReport,
        df_name: str = "df",
    ) -> list[FixSuggestion]:

        fixes: list[FixSuggestion] = []

        # ── dataset-level fixes ───────────────────────────────────────────────
        fixes += self._dataset_fixes(dataset_report, df_name)

        # ── per-column fixes ──────────────────────────────────────────────────
        for col, col_rep in dataset_report.columns.items():
            fixes += self._column_fixes(col_rep, df_name)

        # sort: critical first, then warning, then info
        order = {"critical": 0, "warning": 1, "info": 2}
        fixes.sort(key=lambda f: order.get(f.severity, 3))

        return fixes

    # ── dataset-level ─────────────────────────────────────────────────────────

    def _dataset_fixes(
        self, dr: DatasetReport, df: str
    ) -> list[FixSuggestion]:
        fixes = []

        # duplicates
        if dr.pct_duplicates > 0.01:
            sev = "critical" if dr.pct_duplicates > 0.1 else "warning"
            fixes.append(FixSuggestion(
                column=None,
                category=FixCategory.DEDUPLICATION,
                severity=sev,
                title=f"Remove {dr.n_duplicates} duplicate rows ({dr.pct_duplicates*100:.1f}%)",
                explanation=(
                    "Duplicate rows cause data leakage in train/test splits "
                    "and inflate model performance metrics."
                ),
                code=(
                    f"# Remove duplicate rows\n"
                    f"print(f'Before: {{{df}.shape}}')\n"
                    f"{df} = {df}.drop_duplicates().reset_index(drop=True)\n"
                    f"print(f'After:  {{{df}.shape}}')"
                ),
                effort="low",
                impact="high",
            ))

        # constant columns
        const_cols = [
            col for col, r in dr.columns.items()
            if r.col_type == ColType.CONSTANT
        ]
        if const_cols:
            cols_str = str(const_cols)
            fixes.append(FixSuggestion(
                column=None,
                category=FixCategory.FEATURE_REMOVAL,
                severity="warning",
                title=f"Drop {len(const_cols)} constant column(s)",
                explanation="Constant columns have zero variance and provide no information to ML models.",
                code=(
                    f"# Drop constant columns\n"
                    f"constant_cols = {cols_str}\n"
                    f"{df} = {df}.drop(columns=constant_cols)"
                ),
                effort="low",
                impact="medium",
            ))

        # ID columns
        id_cols = [
            col for col, r in dr.columns.items()
            if r.col_type == ColType.ID_COLUMN
        ]
        if id_cols:
            cols_str = str(id_cols)
            fixes.append(FixSuggestion(
                column=None,
                category=FixCategory.FEATURE_REMOVAL,
                severity="warning",
                title=f"Drop {len(id_cols)} ID column(s)",
                explanation="ID columns are unique identifiers, not features. They cause overfitting.",
                code=(
                    f"# Drop ID columns\n"
                    f"id_cols = {cols_str}\n"
                    f"{df} = {df}.drop(columns=id_cols)"
                ),
                effort="low",
                impact="high",
            ))

        return fixes

    # ── per-column ────────────────────────────────────────────────────────────

    def _column_fixes(
        self, col_rep: ColumnReport, df: str
    ) -> list[FixSuggestion]:
        fixes = []
        col   = f'"{col_rep.name}"'

        # ── nulls ──────────────────────────────────────────────────────────────
        if col_rep.pct_null > 0:
            fixes += self._null_fixes(col_rep, df, col)

        # ── numeric-specific ───────────────────────────────────────────────────
        if col_rep.numeric:
            ns = col_rep.numeric

            # outliers
            if ns.pct_outliers > 0.02:
                fixes.append(self._outlier_fix(col_rep, df, col, ns))

            # skewness
            if abs(ns.skewness) > 1.0:
                fixes.append(self._skew_fix(col_rep, df, col, ns))

            # scaling reminder
            fixes.append(self._scaling_fix(col_rep, df, col, ns))

        # ── categorical ────────────────────────────────────────────────────────
        if col_rep.categorical:
            cs = col_rep.categorical
            fixes += self._encoding_fixes(col_rep, df, col, cs)

        # ── datetime ───────────────────────────────────────────────────────────
        if col_rep.datetime:
            fixes.append(self._datetime_fix(col_rep, df, col))

        # ── text ───────────────────────────────────────────────────────────────
        if col_rep.text:
            fixes.append(self._text_fix(col_rep, df, col))

        return fixes

    # ── null strategies ───────────────────────────────────────────────────────

    def _null_fixes(
        self, col_rep: ColumnReport, df: str, col: str
    ) -> list[FixSuggestion]:
        fixes = []
        pct   = col_rep.pct_null

        if pct > 0.5:
            # recommend dropping
            sev = "critical"
            fixes.append(FixSuggestion(
                column=col_rep.name,
                category=FixCategory.NULL_HANDLING,
                severity=sev,
                title=f"Column {col} has {pct*100:.1f}% nulls — consider dropping",
                explanation="More than half the values are missing. Imputing this column may introduce more noise than signal.",
                code=(
                    f"# Option A: Drop the column entirely\n"
                    f"{df} = {df}.drop(columns=[{col}])\n\n"
                    f"# Option B: Keep but flag missingness as a feature\n"
                    f"{df}[{col}_missing] = {df}[{col}].isna().astype(int)"
                ),
                effort="low",
                impact="high",
            ))
        elif col_rep.numeric:
            ns  = col_rep.numeric
            sev = "warning" if pct > 0.1 else "info"
            strategy = "median" if abs(ns.skewness) > 0.5 else "mean"
            fixes.append(FixSuggestion(
                column=col_rep.name,
                category=FixCategory.NULL_HANDLING,
                severity=sev,
                title=f"Impute {pct*100:.1f}% nulls in {col} with {strategy}",
                explanation=(
                    f"Column is {'skewed' if abs(ns.skewness) > 0.5 else 'roughly symmetric'}. "
                    f"{strategy.capitalize()} imputation is recommended."
                ),
                code=(
                    f"from sklearn.impute import SimpleImputer\n"
                    f"imp = SimpleImputer(strategy='{strategy}')\n"
                    f"{df}[[{col}]] = imp.fit_transform({df}[[{col}]])"
                ),
                effort="low",
                impact="medium",
            ))
        elif col_rep.categorical:
            sev = "warning" if pct > 0.1 else "info"
            fixes.append(FixSuggestion(
                column=col_rep.name,
                category=FixCategory.NULL_HANDLING,
                severity=sev,
                title=f"Impute {pct*100:.1f}% nulls in {col} with mode or 'Unknown'",
                explanation="For categorical columns, fill nulls with the most frequent value or a dedicated 'Unknown' category.",
                code=(
                    f"# Option A: Most frequent value\n"
                    f"{df}[{col}] = {df}[{col}].fillna({df}[{col}].mode()[0])\n\n"
                    f"# Option B: Explicit unknown category\n"
                    f"{df}[{col}] = {df}[{col}].fillna('Unknown')"
                ),
                effort="low",
                impact="medium",
            ))

        return fixes

    # ── outlier fix ───────────────────────────────────────────────────────────

    def _outlier_fix(
        self, col_rep: ColumnReport, df: str, col: str, ns
    ) -> FixSuggestion:
        sev = "critical" if ns.pct_outliers > 0.1 else "warning"
        return FixSuggestion(
            column=col_rep.name,
            category=FixCategory.OUTLIER_HANDLING,
            severity=sev,
            title=f"Handle {ns.pct_outliers*100:.1f}% outliers in {col}",
            explanation=(
                f"IQR bounds: [{ns.p25} – {ns.p75}]. "
                f"Values outside [{ns.p25 - 1.5*(ns.p75-ns.p25):.2f}, "
                f"{ns.p75 + 1.5*(ns.p75-ns.p25):.2f}] are flagged."
            ),
            code=(
                f"# Cap outliers at IQR fences (Winsorization)\n"
                f"Q1  = {df}[{col}].quantile(0.25)\n"
                f"Q3  = {df}[{col}].quantile(0.75)\n"
                f"IQR = Q3 - Q1\n"
                f"lower = Q1 - 1.5 * IQR\n"
                f"upper = Q3 + 1.5 * IQR\n"
                f"{df}[{col}] = {df}[{col}].clip(lower=lower, upper=upper)\n\n"
                f"# Or: remove rows with outliers\n"
                f"# {df} = {df}[{df}[{col}].between(lower, upper)]"
            ),
            effort="low",
            impact="high",
        )

    # ── skew fix ──────────────────────────────────────────────────────────────

    def _skew_fix(
        self, col_rep: ColumnReport, df: str, col: str, ns
    ) -> FixSuggestion:
        if ns.n_negative > 0:
            transform = "np.cbrt"
            code_line = f"{df}[{col}] = np.cbrt({df}[{col}])"
        elif ns.n_zeros > 0:
            transform = "log1p"
            code_line = f"{df}[{col}] = np.log1p({df}[{col}])"
        else:
            transform = "log"
            code_line = f"{df}[{col}] = np.log({df}[{col}])"

        return FixSuggestion(
            column=col_rep.name,
            category=FixCategory.SKEW_CORRECTION,
            severity="warning",
            title=f"Fix skewness ({ns.skewness:.2f}) in {col} with {transform} transform",
            explanation=(
                f"Skewness of {ns.skewness:.2f} violates normality assumption of "
                f"linear models. Log/Box-Cox transforms often help."
            ),
            code=(
                f"import numpy as np\n"
                f"from scipy import stats\n\n"
                f"# Option A: {transform} transform\n"
                f"{code_line}\n\n"
                f"# Option B: Box-Cox (auto-selects best power)\n"
                f"# {df}[{col}], _ = stats.boxcox({df}[{col}] + 1e-6)"
            ),
            effort="low",
            impact="medium",
        )

    # ── scaling ───────────────────────────────────────────────────────────────

    def _scaling_fix(
        self, col_rep: ColumnReport, df: str, col: str, ns
    ) -> FixSuggestion:
        return FixSuggestion(
            column=col_rep.name,
            category=FixCategory.SCALING,
            severity="info",
            title=f"Scale {col} before distance-based / regularized models",
            explanation=(
                f"Range: [{ns.min}, {ns.max}]. "
                "Models like SVM, KNN, Ridge, Lasso are sensitive to feature scale."
            ),
            code=(
                f"from sklearn.preprocessing import StandardScaler, MinMaxScaler\n\n"
                f"# Standard scaling (mean=0, std=1) — use for normal-ish data\n"
                f"scaler = StandardScaler()\n"
                f"{df}[[{col}]] = scaler.fit_transform({df}[[{col}]])\n\n"
                f"# Min-Max scaling (0–1) — use for bounded / skewed data\n"
                f"# scaler = MinMaxScaler()\n"
                f"# {df}[[{col}]] = scaler.fit_transform({df}[[{col}]])"
            ),
            effort="low",
            impact="medium",
        )

    # ── encoding ──────────────────────────────────────────────────────────────

    def _encoding_fixes(
        self, col_rep: ColumnReport, df: str, col: str, cs
    ) -> list[FixSuggestion]:
        fixes = []
        if cs.n_unique <= 2:
            fixes.append(FixSuggestion(
                column=col_rep.name,
                category=FixCategory.ENCODING,
                severity="info",
                title=f"Binary encode {col} (2 unique values)",
                explanation="Binary column — map to 0/1 for ML compatibility.",
                code=(
                    f"{df}[{col}] = {df}[{col}].map({{{df}[{col}].unique()[0]: 0, "
                    f"{df}[{col}].unique()[-1]: 1}})"
                ),
                effort="low",
                impact="medium",
            ))
        elif cs.n_unique <= 10:
            fixes.append(FixSuggestion(
                column=col_rep.name,
                category=FixCategory.ENCODING,
                severity="info",
                title=f"One-hot encode {col} ({cs.n_unique} categories)",
                explanation="Low cardinality — one-hot encoding is safe and interpretable.",
                code=(
                    f"{df} = pd.get_dummies({df}, columns=[{col}], "
                    f"prefix={col}, drop_first=True)"
                ),
                effort="low",
                impact="medium",
            ))
        else:
            fixes.append(FixSuggestion(
                column=col_rep.name,
                category=FixCategory.ENCODING,
                severity="warning",
                title=f"High-cardinality encode {col} ({cs.n_unique} unique values)",
                explanation="Too many categories for one-hot. Use target encoding or hashing.",
                code=(
                    f"# Option A: Target encoding (use with cross-val to avoid leakage)\n"
                    f"from category_encoders import TargetEncoder\n"
                    f"enc = TargetEncoder(cols=[{col}])\n"
                    f"{df}[[{col}]] = enc.fit_transform({df}[[{col}]], y)\n\n"
                    f"# Option B: Frequency encoding\n"
                    f"freq = {df}[{col}].value_counts(normalize=True)\n"
                    f"{df}[{col}_freq] = {df}[{col}].map(freq)"
                ),
                effort="medium",
                impact="high",
            ))
        return fixes

    # ── datetime ──────────────────────────────────────────────────────────────

    def _datetime_fix(
        self, col_rep: ColumnReport, df: str, col: str
    ) -> FixSuggestion:
        return FixSuggestion(
            column=col_rep.name,
            category=FixCategory.DATE_EXTRACTION,
            severity="info",
            title=f"Extract date features from {col}",
            explanation="ML models cannot use raw datetime. Extract year, month, day, weekday as numeric features.",
            code=(
                f"{df}[{col}] = pd.to_datetime({df}[{col}])\n"
                f"{df}[{col}_year]    = {df}[{col}].dt.year\n"
                f"{df}[{col}_month]   = {df}[{col}].dt.month\n"
                f"{df}[{col}_day]     = {df}[{col}].dt.day\n"
                f"{df}[{col}_weekday] = {df}[{col}].dt.weekday\n"
                f"{df}[{col}_quarter] = {df}[{col}].dt.quarter\n"
                f"{df} = {df}.drop(columns=[{col}])"
            ),
            effort="low",
            impact="high",
        )

    # ── text ──────────────────────────────────────────────────────────────────

    def _text_fix(
        self, col_rep: ColumnReport, df: str, col: str
    ) -> FixSuggestion:
        return FixSuggestion(
            column=col_rep.name,
            category=FixCategory.TEXT_PROCESSING,
            severity="info",
            title=f"Vectorize text column {col}",
            explanation="Free-text columns need vectorization. TF-IDF is fast; sentence transformers are powerful.",
            code=(
                f"# Option A: TF-IDF (fast, interpretable)\n"
                f"from sklearn.feature_extraction.text import TfidfVectorizer\n"
                f"tfidf = TfidfVectorizer(max_features=100, stop_words='english')\n"
                f"tfidf_matrix = tfidf.fit_transform({df}[{col}].fillna(''))\n"
                f"import pandas as pd\n"
                f"tfidf_df = pd.DataFrame(tfidf_matrix.toarray(), "
                f"columns=tfidf.get_feature_names_out())\n"
                f"{df} = pd.concat([{df}.drop(columns=[{col}]), tfidf_df], axis=1)\n\n"
                f"# Option B: Sentence embeddings (better semantics)\n"
                f"# from sentence_transformers import SentenceTransformer\n"
                f"# model = SentenceTransformer('all-MiniLM-L6-v2')\n"
                f"# embeddings = model.encode({df}[{col}].fillna('').tolist())"
            ),
            effort="medium",
            impact="high",
        )