"""
Session Manager — manages conversation sessions backed by SQLite.

Each agent has a single sessions.db with:
- sessions table: metadata (id, title, timestamps, options)
- turns table: conversation turns (role, content, timestamp)
- turns_fts: FTS5 virtual table for full-text search across all turns
"""

import json
import logging
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    title TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    turn_count INTEGER DEFAULT 0,
    options TEXT
);

CREATE TABLE IF NOT EXISTS turns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    timestamp TEXT NOT NULL
);

CREATE VIRTUAL TABLE IF NOT EXISTS turns_fts USING fts5(
    content,
    content=turns,
    content_rowid=id
);

-- Triggers to keep FTS index in sync
CREATE TRIGGER IF NOT EXISTS turns_ai AFTER INSERT ON turns BEGIN
    INSERT INTO turns_fts(rowid, content) VALUES (new.id, new.content);
END;

CREATE TRIGGER IF NOT EXISTS turns_ad AFTER DELETE ON turns BEGIN
    INSERT INTO turns_fts(turns_fts, rowid, content) VALUES('delete', old.id, old.content);
END;

CREATE TRIGGER IF NOT EXISTS turns_au AFTER UPDATE ON turns BEGIN
    INSERT INTO turns_fts(turns_fts, rowid, content) VALUES('delete', old.id, old.content);
    INSERT INTO turns_fts(rowid, content) VALUES (new.id, new.content);
END;
"""


class SessionManager:
    """Manages conversation sessions stored in SQLite with FTS5 search."""

    def __init__(self, sessions_dir: Path):
        self.sessions_dir = sessions_dir
        self._db: Optional[sqlite3.Connection] = None

    def _get_db(self) -> sqlite3.Connection:
        """Lazy-init the SQLite connection."""
        if self._db is not None:
            return self._db
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        db_path = self.sessions_dir / "sessions.db"
        self._db = sqlite3.connect(str(db_path))
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA foreign_keys=ON")
        self._db.row_factory = sqlite3.Row
        self._db.executescript(_SCHEMA)
        return self._db

    # -- Session lifecycle -----------------------------------------------------

    def create_session(self, title: str = "") -> str:
        """Create a new session. Returns session_id."""
        session_id = str(uuid.uuid4())[:8]
        now = _timestamp()
        db = self._get_db()
        db.execute(
            "INSERT INTO sessions (id, title, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (session_id, title or None, now, now),
        )
        db.commit()
        return session_id

    def list_sessions(self) -> List[Dict[str, Any]]:
        """List all sessions with metadata, most recent first."""
        db = self._get_db()
        rows = db.execute(
            "SELECT id, title, created_at, updated_at, turn_count, options FROM sessions ORDER BY updated_at DESC"
        ).fetchall()
        return [_row_to_dict(r) for r in rows]

    def delete_session(self, session_id: str) -> bool:
        """Delete a session and its turns (CASCADE)."""
        db = self._get_db()
        cursor = db.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
        db.commit()
        return cursor.rowcount > 0

    # -- Conversation recording ------------------------------------------------

    def append_turn(self, session_id: str, role: str, content: str) -> None:
        """Append a conversation turn to a session."""
        now = _timestamp()
        db = self._get_db()
        db.execute(
            "INSERT INTO turns (session_id, role, content, timestamp) VALUES (?, ?, ?, ?)",
            (session_id, role, content, now),
        )
        db.execute(
            "UPDATE sessions SET updated_at = ?, turn_count = turn_count + 1 WHERE id = ?",
            (now, session_id),
        )
        # Auto-set title from first user message
        if role == "user":
            db.execute(
                "UPDATE sessions SET title = ? WHERE id = ? AND (title IS NULL OR title = '')",
                (content[:80], session_id),
            )
        db.commit()

    def load_turns(self, session_id: str) -> List[Dict[str, str]]:
        """Load all conversation turns from a session."""
        db = self._get_db()
        rows = db.execute(
            "SELECT role, content, timestamp FROM turns WHERE session_id = ? ORDER BY id",
            (session_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_session_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get metadata for a session."""
        db = self._get_db()
        row = db.execute(
            "SELECT id, title, created_at, updated_at, turn_count, options FROM sessions WHERE id = ?",
            (session_id,),
        ).fetchone()
        if row is None:
            return None
        return _row_to_dict(row)

    # -- Options ---------------------------------------------------------------

    def save_options(self, session_id: str, options: Dict[str, Any]) -> None:
        """Persist session options as JSON."""
        clean = {k: v for k, v in options.items() if v is not None and k != "statusbar"}
        db = self._get_db()
        db.execute(
            "UPDATE sessions SET options = ? WHERE id = ?",
            (json.dumps(clean, ensure_ascii=False), session_id),
        )
        db.commit()

    def load_options(self, session_id: str) -> Dict[str, Any]:
        """Load persisted session options."""
        db = self._get_db()
        row = db.execute("SELECT options FROM sessions WHERE id = ?", (session_id,)).fetchone()
        if row is None or row["options"] is None:
            return {}
        try:
            return json.loads(row["options"])
        except (json.JSONDecodeError, TypeError):
            return {}

    # -- Title -----------------------------------------------------------------

    def update_title(self, session_id: str, title: str) -> None:
        """Update the title of a session."""
        db = self._get_db()
        db.execute("UPDATE sessions SET title = ? WHERE id = ?", (title, session_id))
        db.commit()

    # -- Search ----------------------------------------------------------------

    def search(self, query: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Full-text search across all session turns.

        Returns list of dicts with session metadata and matching snippets,
        grouped by session, ordered by relevance.
        """
        db = self._get_db()
        # Use FTS5 match to find matching turns with snippets
        rows = db.execute(
            """
            SELECT
                t.session_id,
                t.role,
                snippet(turns_fts, 0, '**', '**', '...', 32) AS snippet,
                s.title,
                s.created_at,
                s.turn_count
            FROM turns_fts
            JOIN turns t ON t.id = turns_fts.rowid
            JOIN sessions s ON s.id = t.session_id
            WHERE turns_fts MATCH ?
            ORDER BY rank
            LIMIT ?
            """,
            (query, limit * 5),  # fetch more rows, then group by session
        ).fetchall()

        # Group by session
        sessions: Dict[str, Dict[str, Any]] = {}
        for row in rows:
            sid = row["session_id"]
            if sid not in sessions:
                sessions[sid] = {
                    "session_id": sid,
                    "title": row["title"],
                    "created_at": row["created_at"],
                    "turn_count": row["turn_count"],
                    "snippets": [],
                }
            sessions[sid]["snippets"].append(
                {
                    "role": row["role"],
                    "content": row["snippet"],
                }
            )

        result = list(sessions.values())
        return result[:limit]

    def close(self) -> None:
        """Close the database connection."""
        if self._db:
            self._db.close()
            self._db = None


def _row_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
    """Convert a sqlite3.Row to a plain dict, parsing options JSON."""
    d = dict(row)
    if "options" in d and d["options"]:
        try:
            d["options"] = json.loads(d["options"])
        except (json.JSONDecodeError, TypeError):
            d["options"] = {}
    return d


def _timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
