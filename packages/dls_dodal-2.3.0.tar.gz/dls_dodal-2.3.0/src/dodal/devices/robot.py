import asyncio
from asyncio import ALL_COMPLETED, FIRST_COMPLETED, CancelledError, Task, wait_for
from dataclasses import dataclass
from enum import IntEnum

from bluesky.protocols import Movable
from ophyd_async.core import (
    AsyncStatus,
    Device,
    StandardReadable,
    StandardReadableFormat,
    StrictEnum,
    set_and_wait_for_value,
    wait_for_value,
)
from ophyd_async.epics.core import (
    epics_signal_r,
    epics_signal_rw,
    epics_signal_rw_rbv,
    epics_signal_x,
)

from dodal.log import LOGGER

WAIT_FOR_BEAMLINE_DISABLE_MSG = "Waiting on beamline disable"
WAIT_FOR_BEAMLINE_ENABLE_MSG = "Waiting on beamline enable"


class RobotLoadError(Exception):
    error_code: int
    error_string: str

    def __init__(self, error_code: int, error_string: str) -> None:
        self.error_code, self.error_string = error_code, error_string
        super().__init__(error_string)

    def __str__(self) -> str:
        return self.error_string


@dataclass
class SampleLocation:
    puck: int
    pin: int


SAMPLE_LOCATION_EMPTY = SampleLocation(-1, -1)


class PinMounted(StrictEnum):
    NO_PIN_MOUNTED = "No Pin Mounted"
    PIN_MOUNTED = "Pin Mounted"


class BeamlineStatus(IntEnum):
    ENABLED = 0
    DISABLED = 1


class ErrorStatus(Device):
    def __init__(self, prefix: str) -> None:
        self.str = epics_signal_r(str, prefix + "_ERR_MSG")
        self.code = epics_signal_r(int, prefix + "_ERR_CODE")
        super().__init__()

    async def raise_if_error(self, raise_from: Exception):
        error_code = await self.code.get_value()
        if error_code:
            error_string = await self.str.get_value()
            raise RobotLoadError(int(error_code), error_string) from raise_from


# Error codes that we do special things on
class ProgErrorCode(IntEnum):
    NO_ERROR = 0
    SAMPLE_POSITION_NOT_READY = 9
    NO_PIN_ERROR_CODE = 25

    @classmethod
    def is_retryable(cls, error_code: int) -> bool:
        return error_code in {
            ProgErrorCode.NO_ERROR,
            ProgErrorCode.SAMPLE_POSITION_NOT_READY,
        }


class ControllerErrorCode(IntEnum):
    NO_ERROR = 0
    LIGHT_CURTAIN_TRIPPED = 40

    @classmethod
    def is_retryable(cls, error_code: int) -> bool:
        return error_code in {
            ControllerErrorCode.NO_ERROR,
            ControllerErrorCode.LIGHT_CURTAIN_TRIPPED,
        }


class BartRobot(StandardReadable, Movable[SampleLocation]):
    """The sample changing robot."""

    # How long to wait for the robot if it is busy soaking/drying
    NOT_BUSY_TIMEOUT = 5 * 60

    # How long to wait for the actual load to happen
    LOAD_TIMEOUT = 60

    # How far the gonio position can be out before loading will fail
    LOAD_TOLERANCE_MM = 0.02

    # mode constants for CRYO_MODE - TODO when https://jira.diamond.ac.uk/browse/I03-1056
    # is completed these should be made into a proper enum
    CRYO_MODE_WARM = 0.0
    CRYO_MODE_CRYO = 1.0

    NO_PIN_LOCATION = SampleLocation(0, 0)

    def __init__(self, prefix: str, name: str = "") -> None:
        with self.add_children_as_readables(StandardReadableFormat.HINTED_SIGNAL):
            self.barcode = epics_signal_r(str, prefix + "BARCODE")
            self.gonio_pin_sensor = epics_signal_r(PinMounted, prefix + "PIN_MOUNTED")

            self.current_puck = epics_signal_r(float, prefix + "CURRENT_PUCK_RBV")
            self.current_pin = epics_signal_r(float, prefix + "CURRENT_PIN_RBV")

        self.beamline_disabled = epics_signal_r(int, prefix + "ROBOT_OP_16_BITS.B8")

        self.next_pin = epics_signal_rw_rbv(float, prefix + "NEXT_PIN")
        self.next_puck = epics_signal_rw_rbv(float, prefix + "NEXT_PUCK")

        self.sample_id = epics_signal_r(int, prefix + "CURRENT_ID_RBV")
        self.next_sample_id = epics_signal_rw_rbv(int, prefix + "NEXT_ID")

        self.load = epics_signal_x(prefix + "LOAD.PROC")
        self.unload = epics_signal_x(prefix + "UNLD.PROC")
        self.program_running = epics_signal_r(bool, prefix + "PROGRAM_RUNNING")
        self.program_name = epics_signal_r(str, prefix + "PROGRAM_NAME")

        self.prog_error = ErrorStatus(prefix + "PRG")
        self.controller_error = ErrorStatus(prefix + "CNTL")

        self.reset = epics_signal_x(prefix + "RESET.PROC")
        self.abort = epics_signal_x(prefix + "ABORT.PROC")
        self.init = epics_signal_x(prefix + "INIT.PROC")
        self.soak = epics_signal_x(prefix + "SOAK.PROC")
        self.home = epics_signal_x(prefix + "GOHM.PROC")
        self.dry = epics_signal_x(prefix + "DRY.PROC")
        self.open = epics_signal_x(prefix + "COLO.PROC")
        self.close = epics_signal_x(prefix + "COLC.PROC")
        self.cryomode_rbv = epics_signal_r(float, prefix + "CRYO_MODE_RBV")
        self.cryomode = epics_signal_rw(str, prefix + "CRYO_MODE_CTRL")
        self.gripper_temp = epics_signal_r(float, prefix + "GRIPPER_TEMP")
        self.dewar_lid_temperature = epics_signal_rw(
            float, prefix + "DW_1_TEMP", prefix + "DW_1_SET_POINT"
        )
        super().__init__(name=name)

    async def beamline_status_or_error(
        self,
        expected_state: BeamlineStatus,
        sample_location: SampleLocation | None = None,
    ):
        """This co-routine will finish when either the beamline reaches the specified
        state or the robot gives an error (whichever happens first). In the case where
        there is an error a RobotLoadError error is raised.

        Args:
            expected_state (BeamlineStatus): The beamline state to wait for
            sample_location (SampleLocation): The loaded puck and pin to wait for, or None to not
            wait.
        """

        async def raise_if_prog_error():
            await wait_for_value(
                self.prog_error.code,
                lambda value: value != ProgErrorCode.NO_ERROR,
                None,
            )
            error_code = await self.prog_error.code.get_value()
            error_msg = await self.prog_error.str.get_value()
            raise RobotLoadError(error_code, error_msg)

        async def raise_if_ctl_error():
            await wait_for_value(
                self.controller_error.code,
                lambda value: value != ControllerErrorCode.NO_ERROR,
                None,
            )
            error_code = await self.controller_error.code.get_value()
            error_msg = await self.controller_error.str.get_value()
            raise RobotLoadError(error_code, error_msg)

        async def wait_for_expected_state():
            await wait_for_value(self.beamline_disabled, expected_state.value, None)

        async def wait_for_puck(_sample_location: SampleLocation):
            await wait_for_value(self.current_puck, _sample_location.puck, None)

        async def wait_for_pin(_sample_location: SampleLocation):
            await wait_for_value(self.current_pin, _sample_location.pin, None)

        check_for_prog_error_task = Task(raise_if_prog_error())
        check_for_ctl_error_task = Task(raise_if_ctl_error())
        tasks = [
            (Task(wait_for_expected_state())),
        ]
        if sample_location:
            tasks += [
                Task(wait_for_puck(sample_location)),
                Task(wait_for_pin(sample_location)),
            ]
        check_for_completion_conditions = asyncio.create_task(
            asyncio.wait(tasks, return_when=ALL_COMPLETED)
        )
        try:
            finished, unfinished = await asyncio.wait(
                [
                    check_for_prog_error_task,
                    check_for_ctl_error_task,
                    check_for_completion_conditions,
                ],
                return_when=FIRST_COMPLETED,
            )
            for task in unfinished:
                task.cancel()
            for task in finished:
                await task
        except CancelledError:
            # If the outer enclosing task cancels after a timeout, this causes CancelledError to be raised
            # in the current task, when it propagates to here we should cancel all pending tasks before bubbling up
            for task in tasks:
                task.cancel()
            check_for_prog_error_task.cancel()
            check_for_ctl_error_task.cancel()
            raise

    async def _check_errors_and_clear_if_retryable(self):
        ctl_err_code = await self.controller_error.code.get_value()
        prog_err_code = await self.prog_error.code.get_value()
        if (
            ctl_err_code != ControllerErrorCode.NO_ERROR
            or prog_err_code != ProgErrorCode.NO_ERROR
        ):
            ctl_err_msg = await self.controller_error.str.get_value()
            prog_err_msg = await self.prog_error.str.get_value()
            if ctl_err_code != ControllerErrorCode.NO_ERROR:
                LOGGER.info(
                    f"Detected error from previous load/unload attempt controller_error {ctl_err_code}:{ctl_err_msg}"
                )
            if prog_err_code != ProgErrorCode.NO_ERROR:
                LOGGER.info(
                    f"Detected error from previous load/unload attempt prog_error {prog_err_code}:{prog_err_msg}"
                )
            if not ProgErrorCode.is_retryable(prog_err_code):
                raise RobotLoadError(prog_err_code, prog_err_msg)
            if not ControllerErrorCode.is_retryable(ctl_err_code):
                raise RobotLoadError(ctl_err_code, ctl_err_msg)

            LOGGER.info("Errors are retryable, resetting errors and trying again")
            await self.reset.trigger()

    async def _load_pin_and_puck(self, sample_location: SampleLocation):
        LOGGER.info(f"Loading pin {sample_location}")
        if await self.program_running.get_value():
            LOGGER.info(
                f"Waiting on robot to finish {await self.program_name.get_value()}"
            )
            await wait_for_value(
                self.program_running, False, timeout=self.NOT_BUSY_TIMEOUT
            )
        await asyncio.gather(
            set_and_wait_for_value(self.next_puck, sample_location.puck),
            set_and_wait_for_value(self.next_pin, sample_location.pin),
        )
        await self.load.trigger()
        await self._wait_for_beamline_enabled_after_load_or_unload(sample_location)

    async def _wait_for_beamline_enabled_after_load_or_unload(
        self, sample_location: SampleLocation
    ):
        if await self.beamline_disabled.get_value() == BeamlineStatus.ENABLED.value:
            LOGGER.info(WAIT_FOR_BEAMLINE_DISABLE_MSG)
            await self.beamline_status_or_error(BeamlineStatus.DISABLED)

        LOGGER.info(WAIT_FOR_BEAMLINE_ENABLE_MSG)
        await self.beamline_status_or_error(BeamlineStatus.ENABLED, sample_location)

    @AsyncStatus.wrap
    async def set(self, value: SampleLocation):
        """Perform a sample load from the specified sample location.

        Args:
            value (SampleLocation): The pin and puck to load, or SAMPLE_LOCATION_EMPTY
                to unload the sample.

        Raises:
            RobotLoadError: If a timeout occurs, or if an error occurs loading the
                sample.
        """
        try:
            await self._check_errors_and_clear_if_retryable()
            if value != SAMPLE_LOCATION_EMPTY:
                await wait_for(
                    self._load_pin_and_puck(value),
                    timeout=self.LOAD_TIMEOUT + self.NOT_BUSY_TIMEOUT,
                )
            else:
                await self.unload.trigger(timeout=self.LOAD_TIMEOUT)
                await wait_for(
                    self._wait_for_beamline_enabled_after_load_or_unload(
                        self.NO_PIN_LOCATION
                    ),
                    timeout=self.LOAD_TIMEOUT + self.NOT_BUSY_TIMEOUT,
                )
        except TimeoutError as e:
            await self.prog_error.raise_if_error(e)
            await self.controller_error.raise_if_error(e)
            raise RobotLoadError(0, "Robot timed out") from e
