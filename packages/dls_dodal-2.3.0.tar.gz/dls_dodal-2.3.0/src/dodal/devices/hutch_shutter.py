from abc import ABC, abstractmethod
from math import isclose

from bluesky.protocols import Movable
from ophyd_async.core import (
    DEFAULT_TIMEOUT,
    AsyncStatus,
    EnumTypes,
    SignalR,
    StandardReadable,
    StandardReadableFormat,
    StrictEnum,
    derived_signal_r,
    wait_for_value,
)
from ophyd_async.epics.core import epics_signal_r, epics_signal_w

from dodal.log import LOGGER

HUTCH_SAFE_FOR_OPERATIONS = 0  # Hutch is locked and can't be entered
PSS_SHUTTER_SUFFIX = "-PS-IOC-01:M14:LOP"
EXP_SHUTTER_1_INFIX = "-PS-SHTR-01"
EXP_SHUTTER_2_INFIX = "-PS-SHTR-02"

# Enable to allow testing when the beamline is down, do not change in production!
TEST_MODE = False
# will be made more generic in https://github.com/DiamondLightSource/dodal/issues/754


class ShutterNotSafeToOperateError(Exception):
    pass


class ShutterDemand(StrictEnum):
    OPEN = "Open"
    CLOSE = "Close"
    RESET = "Reset"


class ShutterState(StrictEnum):
    FAULT = "Fault"
    OPEN = "Open"
    OPENING = "Opening"
    CLOSED = "Closed"
    CLOSING = "Closing"


class InterlockState(StrictEnum):
    FAILED = "Failed"
    RUN_ILKS_OK = "Run Ilks Ok"
    OK = "OK"
    DISARMED = "Disarmed"


class BaseHutchInterlock(ABC, StandardReadable):
    status: SignalR[float | EnumTypes]
    bl_prefix: str

    def __init__(
        self,
        signal_type: type[EnumTypes] | type[float],
        bl_prefix: str,
        interlock_infix: str,
        interlock_suffix: str,
        name: str = "",
    ) -> None:
        pv_address = f"{bl_prefix}{interlock_infix}{interlock_suffix}"

        with self.add_children_as_readables():
            self.status = epics_signal_r(signal_type, pv_address)

        with self.add_children_as_readables(StandardReadableFormat.HINTED_SIGNAL):
            self.is_safe = derived_signal_r(
                self._safe_to_operate,
                status=self.status,
            )
        super().__init__(name)

    @abstractmethod
    def _safe_to_operate(self, status: float | EnumTypes) -> bool:
        """Abstract method to define if interlock allows shutter to operate."""


class HutchInterlock(BaseHutchInterlock):
    """Device to check the interlock status of the hutch using PSS pv."""

    def __init__(
        self,
        bl_prefix: str,
        shtr_infix: str = "",
        interlock_suffix: str = PSS_SHUTTER_SUFFIX,
        name: str = "",
    ) -> None:
        super().__init__(
            signal_type=float,
            bl_prefix=bl_prefix,
            interlock_infix=shtr_infix,
            interlock_suffix=interlock_suffix,
            name=name,
        )

    def _safe_to_operate(self, status: float | EnumTypes) -> bool:
        """If the status value is 0, hutch has been searched and locked and it is safe \
        to operate the shutter.
        If the status value is not 0 (usually set to 7), the hutch is open and the \
        shutter should not be in use.
        """
        return isclose(float(status), HUTCH_SAFE_FOR_OPERATIONS, abs_tol=5e-2)


class PLCShutterInterlock(BaseHutchInterlock):
    """Device to check the interlock state of the shutter using PLC pv."""

    def __init__(
        self,
        bl_prefix: str,
        shtr_infix: str = "",
        interlock_suffix: str = EXP_SHUTTER_1_INFIX,
        name: str = "",
    ) -> None:
        super().__init__(
            signal_type=InterlockState,
            bl_prefix=bl_prefix,
            interlock_infix=shtr_infix,
            interlock_suffix=interlock_suffix,
            name=name,
        )

    def _safe_to_operate(self, status: float | EnumTypes) -> bool:
        """If the status value is OK or Run Ilk OK, shutter is open or safe to operate.

        If the status value is "OK", valve or shutter is open and interlocks are OK to
        operate. If the status value is "Run Ilks Ok", the opening action can be
        started. If the status value is not OK ("Failed" or "Disarmed"), interlocks have
        failed and the shutter cannot be operated. Disarmed status applies only to fast
        shutters.
        """
        return (status == InterlockState.OK) | (status == InterlockState.RUN_ILKS_OK)


class BaseHutchShutter(ABC, StandardReadable, Movable[ShutterDemand]):
    """Device to operate the hutch shutter.

    Base class for HutchShutters - extended by some that do not use an interlock
    and by others that do.  See child classes for details

    Attributes:
        control: An writeable EPICS signal to drive the shutter state changes
        status: A readable EPICS signal to read the present shutter state
    """

    def __init__(
        self,
        bl_shutter_prefix: str,
        name: str = "",
    ) -> None:
        self.control = epics_signal_w(ShutterDemand, f"{bl_shutter_prefix}:CON")
        with self.add_children_as_readables():
            self.status = epics_signal_r(ShutterState, f"{bl_shutter_prefix}:STA")
        super().__init__(name)

    @AsyncStatus.wrap
    async def set(self, value: ShutterDemand):
        if TEST_MODE:
            self._test_mode_set()
        else:
            if value == ShutterDemand.OPEN:
                await self._pre_open_shutter_actions()
                required_match: ShutterState = ShutterState.OPEN
            else:
                required_match: ShutterState = ShutterState.CLOSED
            await self._shutter_action(value=value, required_match=required_match)

    @abstractmethod
    async def _pre_open_shutter_actions(self):
        """Provides internal implementation of pre-requisite steps that support opening of the shutter."""

    async def _shutter_action(self, value: ShutterDemand, required_match: ShutterState):
        await self.control.set(value)
        await wait_for_value(self.status, match=required_match, timeout=DEFAULT_TIMEOUT)

    def _test_mode_set(self):
        LOGGER.warning("Running in test mode, will not operate the experiment shutter.")


class HutchShutter(BaseHutchShutter):
    """Device to operate the hutch shutter.

    When a demand is sent, the shutter can be operated without checking
    the hutch status, instead relying on default shutter interlock (:ILKSTA).

    If the requested shutter position is "Open", the shutter control PV should first
    go to "Reset" and then move to "Open". This is because before opening the hutch
    shutter, the interlock status will show as `failed` until the hutch shutter is
    reset. The reset will set the interlock status to `OK`, allowing for shutter operations.
    Until this step is done, the hutch shutter can't be opened. The reset is not needed
    for closing the shutter.
    """

    def __init__(
        self,
        bl_prefix: str,
        shtr_infix: str = EXP_SHUTTER_1_INFIX,
        name: str = "",
    ) -> None:
        super().__init__(f"{bl_prefix}{shtr_infix}", name)

    async def _pre_open_shutter_actions(self):
        """Required by parent class API - resets the shutter prior to opening."""
        await self.control.set(ShutterDemand.RESET)


class InterlockedHutchShutter(BaseHutchShutter):
    """Device to operate the hutch shutter.  With an interlock.

    When a demand is sent the device should first check the hutch status and
    raise an error if it's not interlocked (searched and locked), as not interlocked
    means it's not safe to operate the shutter.

    If the requested shutter position is "Open", the shutter control PV should first
    go to "Reset" and then move to "Open". This is because before opening the hutch
    shutter, the interlock status will show as `failed` until the hutch shutter is
    reset. The reset will set the interlock status to `OK`, allowing for shutter operations.
    Until this step is done, the hutch shutter can't be opened. The reset is not needed
    for closing the shutter.

    Attributes:
        interlock : Hutch PSS based interlock status checker
    """

    def __init__(
        self,
        bl_prefix: str,
        interlock: BaseHutchInterlock,
        shtr_infix: str = EXP_SHUTTER_1_INFIX,
        name: str = "",
    ) -> None:
        with self.add_children_as_readables():
            self.interlock = interlock
        super().__init__(f"{bl_prefix}{shtr_infix}", name)

    async def _pre_open_shutter_actions(self):
        """Required by parent class API - checks interlock, then resets the shutter prior to opening."""
        await self._check_interlock()
        await self.control.set(ShutterDemand.RESET)

    async def _check_interlock(self):
        """Disrupts shutter opening if the interlock is not in a safe to operate state.

        Raises:
             ShutterNotSafeToOperateError - whereby an unhappy interlock will veto any attempt to open the shutter.
        """
        interlock_state = await self.interlock.is_safe.get_value()
        if not interlock_state:
            raise ShutterNotSafeToOperateError(
                "The hutch has not been locked, not operating shutter."
            )
