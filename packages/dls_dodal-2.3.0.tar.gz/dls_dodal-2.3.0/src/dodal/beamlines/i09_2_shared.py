from pathlib import Path

from daq_config_server import ConfigClient

from dodal.device_manager import DeviceManager
from dodal.devices.beamlines.i09.enums import Grating
from dodal.devices.beamlines.i09_2_shared.i09_apple2 import (
    J09_GAP_POLY_DEG_COLUMNS,
    J09_PHASE_POLY_DEG_COLUMNS,
)
from dodal.devices.hutch_shutter import HutchShutter
from dodal.devices.insertion_device import (
    Apple2,
    Apple2EnforceLHMoveController,
    BeamEnergy,
    InsertionDeviceEnergy,
    InsertionDevicePolarisation,
    UndulatorGap,
    UndulatorPhaseAxes,
)
from dodal.devices.insertion_device.energy_motor_lookup import (
    ConfigServerEnergyMotorLookup,
)
from dodal.devices.insertion_device.lookup_table_models import LookupTableColumnConfig
from dodal.devices.pgm import PlaneGratingMonochromator
from dodal.utils import BeamlinePrefix, get_beamline_name

J09_CONF_CLIENT = ConfigClient(url="https://daq-config.diamond.ac.uk")
LOOK_UPTABLE_DIR = "/dls_sw/i09-2/software/gda/workspace_git/gda-diamond.git/configurations/i09-2-shared/lookupTables/"
GAP_LOOKUP_FILE_NAME = "JIDEnergy2GapCalibrations.csv"
PHASE_LOOKUP_FILE_NAME = "JIDEnergy2PhaseCalibrations.csv"

BL = get_beamline_name("i09-2-shared")
J_PREFIX = BeamlinePrefix(BL, suffix="J")
K_PREFIX = BeamlinePrefix(BL, suffix="K")

devices = DeviceManager()


@devices.factory()
def psk1() -> HutchShutter:
    return HutchShutter(K_PREFIX.beamline_prefix)


@devices.factory()
def pgm() -> PlaneGratingMonochromator:
    return PlaneGratingMonochromator(
        prefix=f"{J_PREFIX.beamline_prefix}-MO-PGM-01:",
        grating=Grating,
    )


@devices.factory()
def jgap() -> UndulatorGap:
    return UndulatorGap(prefix=f"{J_PREFIX.insertion_prefix}-MO-SERVC-01:")


@devices.factory()
def jphase() -> UndulatorPhaseAxes:
    return UndulatorPhaseAxes(
        prefix=f"{J_PREFIX.insertion_prefix}-MO-SERVC-01:",
        top_outer="PUO",
        top_inner="PUI",
        btm_inner="PLI",
        btm_outer="PLO",
    )


@devices.factory()
def jid(jgap: UndulatorGap, jphase: UndulatorPhaseAxes) -> Apple2[UndulatorPhaseAxes]:
    """I09 soft x-ray insertion device."""
    return Apple2[UndulatorPhaseAxes](id_gap=jgap, id_phase=jphase)


@devices.factory()
def jidcontroller(
    jid: Apple2[UndulatorPhaseAxes],
) -> Apple2EnforceLHMoveController[UndulatorPhaseAxes]:
    """J09 insertion device controller."""
    return Apple2EnforceLHMoveController[UndulatorPhaseAxes](
        apple2=jid,
        gap_energy_motor_lut=ConfigServerEnergyMotorLookup(
            lut_config=LookupTableColumnConfig(poly_deg=J09_GAP_POLY_DEG_COLUMNS),
            config_client=J09_CONF_CLIENT,
            path=Path(LOOK_UPTABLE_DIR, GAP_LOOKUP_FILE_NAME),
        ),
        phase_energy_motor_lut=ConfigServerEnergyMotorLookup(
            lut_config=LookupTableColumnConfig(poly_deg=J09_PHASE_POLY_DEG_COLUMNS),
            config_client=J09_CONF_CLIENT,
            path=Path(LOOK_UPTABLE_DIR, PHASE_LOOKUP_FILE_NAME),
        ),
        units="keV",
    )


@devices.factory()
def jidenergy(
    jidcontroller: Apple2EnforceLHMoveController[UndulatorPhaseAxes],
) -> InsertionDeviceEnergy:
    return InsertionDeviceEnergy(id_controller=jidcontroller)


@devices.factory()
def jpolarisation(
    jidcontroller: Apple2EnforceLHMoveController[UndulatorPhaseAxes],
) -> InsertionDevicePolarisation:
    return InsertionDevicePolarisation(id_controller=jidcontroller)


@devices.factory()
def jenergy(
    jidenergy: InsertionDeviceEnergy, pgm: PlaneGratingMonochromator
) -> BeamEnergy:
    """Beam energy."""
    return BeamEnergy(id_energy=jidenergy, mono=pgm.energy)
