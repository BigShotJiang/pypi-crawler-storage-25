from ophyd_async.core import InOut, SignalRW
from ophyd_async.epics.core import epics_signal_rw

from dodal.beamlines.i09_1_shared import devices as i09_1_shared_devices
from dodal.beamlines.i09_2_shared import devices as i09_2_shared_devices
from dodal.common.beamlines.beamline_utils import set_beamline as set_utils_beamline
from dodal.device_manager import DeviceManager
from dodal.devices.beamlines.i09 import (
    IntensityProtection,
    LensMode,
    PassEnergy,
    PsuMode,
)
from dodal.devices.common_dcm import DoubleCrystalMonochromatorWithDSpacing
from dodal.devices.electron_analyser.base import DualEnergySource
from dodal.devices.electron_analyser.vgscienta import VGScientaDetector
from dodal.devices.fast_shutter import DualFastShutter, FastShutter
from dodal.devices.hutch_shutter import EXP_SHUTTER_2_INFIX, HutchShutter
from dodal.devices.motors import XYZAzimuthPolarStage
from dodal.devices.pgm import PlaneGratingMonochromator
from dodal.devices.selectable_source import SourceSelector
from dodal.devices.synchrotron import Synchrotron
from dodal.devices.temperture_controller import Lakeshore336
from dodal.log import set_beamline as set_log_beamline
from dodal.utils import BeamlinePrefix, get_beamline_name

BL = get_beamline_name("i09")
I_PREFIX = BeamlinePrefix(BL, suffix="I")
J_PREFIX = BeamlinePrefix(BL, suffix="J")
set_log_beamline(BL)
set_utils_beamline(BL)

devices = DeviceManager()
devices.include(i09_1_shared_devices)
devices.include(i09_2_shared_devices)


@devices.factory()
def synchrotron() -> Synchrotron:
    return Synchrotron()


@devices.factory()
def psi2() -> HutchShutter:
    return HutchShutter(
        bl_prefix=I_PREFIX.beamline_prefix,
        shtr_infix=EXP_SHUTTER_2_INFIX,
    )


@devices.factory()
def psj1() -> HutchShutter:
    return HutchShutter(J_PREFIX.beamline_prefix)


@devices.factory()
def psj2() -> HutchShutter:
    return HutchShutter(
        bl_prefix=J_PREFIX.beamline_prefix,
        shtr_infix=EXP_SHUTTER_2_INFIX,
    )


@devices.factory()
def source_selector() -> SourceSelector:
    return SourceSelector()


@devices.factory()
def dual_energy_source(
    dcm: DoubleCrystalMonochromatorWithDSpacing,
    pgm: PlaneGratingMonochromator,
    source_selector: SourceSelector,
) -> DualEnergySource:
    return DualEnergySource(
        dcm.energy_in_eV,
        pgm.energy.user_readback,
        source_selector.selected_source,
    )


@devices.factory()
def fsi1() -> FastShutter[InOut]:
    return FastShutter[InOut](
        f"{I_PREFIX.beamline_prefix}-EA-FSHTR-01:CTRL",
        open_state=InOut.OUT,
        close_state=InOut.IN,
    )


@devices.factory()
def fsj1() -> FastShutter[InOut]:
    return FastShutter[InOut](
        f"{J_PREFIX.beamline_prefix}-EA-FSHTR-01:CTRL",
        open_state=InOut.OUT,
        close_state=InOut.IN,
    )


@devices.factory()
def dual_fast_shutter(
    fsi1: FastShutter, fsj1: FastShutter, source_selector: SourceSelector
) -> DualFastShutter[InOut]:
    return DualFastShutter[InOut](fsi1, fsj1, source_selector.selected_source)


# CAM:IMAGE will fail to connect outside the beamline network,
# see https://github.com/DiamondLightSource/dodal/issues/1852
@devices.factory()
def ew4000(
    dual_fast_shutter: DualFastShutter,
    dual_energy_source: DualEnergySource,
    source_selector: SourceSelector,
) -> VGScientaDetector[LensMode, PsuMode, PassEnergy]:
    return VGScientaDetector[LensMode, PsuMode, PassEnergy](
        prefix=f"{I_PREFIX.beamline_prefix}-EA-DET-01:CAM:",
        lens_mode_type=LensMode,
        psu_mode_type=PsuMode,
        pass_energy_type=PassEnergy,
        energy_source=dual_energy_source,
        shutter=dual_fast_shutter,
        source_selector=source_selector,
    )


@devices.factory()
def lakeshore() -> Lakeshore336:
    return Lakeshore336(prefix="BL09L-VA-LAKE-01:")


@devices.factory()
def smpm() -> XYZAzimuthPolarStage:
    """Sample Manipulator."""
    return XYZAzimuthPolarStage(prefix=f"{I_PREFIX.beamline_prefix}-MO-SMPM-01:")


@devices.factory
def intensity_protection() -> SignalRW[IntensityProtection]:
    return epics_signal_rw(
        IntensityProtection, f"{I_PREFIX.beamline_prefix}-DI-EAN-01:PROT:ILK"
    )
