import pytest
from daq_config_server import ConfigClient
from ophyd_async.core import init_devices

from dodal.devices.beamlines.i07.id import InsertionDevice
from dodal.devices.undulator import UndulatorOrder
from tests.devices.beamlines.i07 import TEST_LOOKUP_TABLE_PATH


@pytest.fixture
def harmonic() -> UndulatorOrder:
    with init_devices(mock=True):
        harmonic = UndulatorOrder()
    return harmonic


@pytest.fixture
async def id(harmonic: UndulatorOrder) -> InsertionDevice:
    async with init_devices(mock=True):
        id = InsertionDevice(
            "ID-01",
            harmonic,
            ConfigClient(""),
            TEST_LOOKUP_TABLE_PATH,
        )
    return id


@pytest.mark.parametrize(
    "energy_kev, gap",
    [(14, 5.81), (15, 6.25)],
)
async def test_id_gap_calculation(energy_kev: float, gap: float, id: InsertionDevice):
    id.harmonic.set(5)
    interpolated_gap = await id._get_gap_to_match_energy(energy_kev)
    assert interpolated_gap == pytest.approx(gap, abs=0.01)
