from unittest.mock import patch

import pytest
from daq_config_server import ConfigClient

from dodal.common.beamlines.beamline_parameters import (
    get_beamline_parameters,
)
from dodal.common.beamlines.beamline_utils import set_config_client
from tests.test_data import (
    I04_BEAMLINE_PARAMETERS,
    TEST_BEAMLINE_PARAMETERS_TXT,
)


@pytest.fixture(autouse=True)
def patch_beamline_parameter_paths():
    with patch(
        "dodal.common.beamlines.beamline_parameters.BEAMLINE_PARAMETER_PATHS",
        {
            "test": TEST_BEAMLINE_PARAMETERS_TXT,
            "i04": I04_BEAMLINE_PARAMETERS,
            "i03": I04_BEAMLINE_PARAMETERS,
        },
    ):
        yield


@pytest.fixture(autouse=True)
def always_set_config_client():
    set_config_client(ConfigClient("test"))


def test_beamline_parameters():
    params = get_beamline_parameters("test")
    assert params["sg_x_MEDIUM_APERTURE"] == 5.285
    assert params["col_parked_downstream_x"] == 0
    assert params["beamLineEnergy__pitchStep"] == 0.002
    assert params["DataCollection_TurboMode"] is True
    assert params["beamLineEnergy__adjustSlits"] is False


def test_i03_beamline_parameters():
    params = get_beamline_parameters("i03")
    assert params["flux_predict_polynomial_coefficients_5"] == [
        -0.0000707134131045123,
        7.0205491504418,
        -194299.6440518530,
        1835805807.3974800,
        -3280251055671.100,
    ]


def test_get_beamline_parameters_errors_if_no_filepath_found_for_beamline():
    with pytest.raises(KeyError):
        assert get_beamline_parameters("not a key")


def test_get_beamline_parameters():
    params = get_beamline_parameters("test")
    assert params["col_parked_downstream_x"] == 0
    assert params["BackStopZyag"] == 19.1
    assert params["store_data_collections_in_ispyb"] is True
    assert params["attenuation_optimisation_type"] == "deadtime"
