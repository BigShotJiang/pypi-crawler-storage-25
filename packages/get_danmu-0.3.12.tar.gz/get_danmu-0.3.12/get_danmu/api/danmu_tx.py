import re
import sys
import time
import json
# import pandas as pd
import requests
from lxml import etree

class TencentFetcher():
    """腾讯视频弹幕抓取器"""
    STEP_MS = 30000
    MAX_DURATION_MS = 7200000
    RETRY_COUNT = 3

    def __init__(self, url,proxy=''):
        super().__init__()
        self.url = url
        self.proxy=proxy
        self.proxies = {
"http": self.proxy,
"https": self.proxy,
} if proxy else None

    def fetch_page_html(self):
        """缓存页面 HTML"""
        if hasattr(self, "_page_html"):
            return self._page_html
        try:
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"}
            resp = requests.get(self.url, headers=headers, timeout=5,proxies=self.proxies)
            resp.raise_for_status()
            # if resp.status_code!=200:
            #     resp = requests.get(self.url, headers=headers, timeout=10,proxies=self.proxies if self.proxy else None)
            #     print(resp.status_code)
            # print(resp.status_code)
            # time.sleep(1)
            resp.encoding='utf-8'
            self._page_html = resp.text
        except Exception:
            self._page_html = ""
        return self._page_html

    def extract_video_info_from_page(self):
        """从 HTML 直接匹配 currentVideoInfo 后的 vid/duration/title"""
        if hasattr(self, "_video_info"):
            return self._video_info

        info = {"vid": None, "duration": self.MAX_DURATION_MS, "title": "弹幕"}
        html = self.fetch_page_html()
        script_text=html

        # with open('1.html','w',encoding='utf-8') as f:
        #     f.write(html)

        # parser = etree.HTMLParser(encoding='utf-8')
        # tree = etree.HTML(html, parser=parser)
        # # script_elem=tree
        # script_elem = tree.xpath('/html/head/script[11]')
        # # if not script_elem:
        # #     print("未找到XPath为/html/head/script[6]的script标签")
        # #     self._video_info = info
        # #     return info
        
        # # 2. 提取script标签内的完整文本
        # script_text = script_elem[0].text
        # if not script_text:
        #     print("目标script标签内无文本内容")
        #     self._video_info = info
        #     return info

        # 匹配duration的值（如 duration:1807,）
        # 正则说明：匹配duration:后接数字，直到逗号/分号/大括号/空格等终止
        duration_pattern = re.compile(r'duration:(\d+)[,;\}\s]')
        duration_match = duration_pattern.search(script_text)
        if duration_match:
            info["duration"] = int(duration_match.group(1))*1000

        # 匹配title的值（如 playTitle:"剑来 第二季 第7话",）
        # 正则说明：匹配title:后接双引号包裹的字符串，支持中文/特殊字符
        title_pattern = re.compile(r'playTitle:"([^"]+)"')
        title_match = title_pattern.search(script_text)
        # print(title_match)
        if title_match:
            info["title"] = self._replace_season_part_with_chinese_num(title_match.group(1))  # 去除双引号
            # self._replace_season_part_with_chinese_num()

        # 匹配vid的值（如 vid:"k4101qgvmtx",）
        # 正则说明：匹配vid:后接双引号包裹的字符串
        vid_pattern = re.compile(r'vid:"([^"]+)"[,;\}\s]')
        vid_match = vid_pattern.search(script_text)
        if vid_match:
            info["vid"] = vid_match.group(1)  # 去除双引号
        # print(vid_match)
        else:
            info["vid"] = self.url.split('/')[-1].split('.')[0]  # 去除双引号


        self._video_info = info
        return info

    def get_video_info(self):
        """返回文件名信息"""
        return {"title": self.extract_video_info_from_page().get("title")}

    def get_video_duration(self):
        """返回视频时长（毫秒）"""
        return self.extract_video_info_from_page().get("duration", self.MAX_DURATION_MS)

    def run(self,start_second=None,end_second=None,progress_callback=None):
        """执行弹幕抓取任务"""
        info = self.extract_video_info_from_page()
        self.vid = info.get("vid")
        duration = info.get("duration", self.MAX_DURATION_MS)
        if not self.vid:
            raise "无法提取腾讯视频ID"
            # return

        # print(duration,self.vid)

        danmu = []
        # print(start_second,end_second)
        total_steps = max((duration + self.STEP_MS - 1) // self.STEP_MS, 1)
        if end_second:
            total_steps = max((end_second*1000 + self.STEP_MS - 1) // self.STEP_MS, 1)
            duration=end_second*1000
        current_step = 0
        if start_second:
            current_step=start_second*1000 // self.STEP_MS
        start = current_step*self.STEP_MS
        # start=0
        # print(current_step,start)

        headers={
        'user-agent':'''Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'''
    }

        while start < duration:
            # end = min(start + self.STEP_MS, duration)
            end =start + self.STEP_MS
            api_url = f"https://dm.video.qq.com/barrage/segment/{self.vid}/t/v1/{start}/{end}"
            block = []
            for attempt in range(self.RETRY_COUNT):
                try:
                    resp = requests.get(api_url,headers=headers, timeout=1,proxies=self.proxies)
                    resp.raise_for_status()
                    # print(resp.status_code)
                    try:
                        data = resp.json()
                    except Exception:
                        data = {}
                    block = data.get("barrage_list", []) if isinstance(data, dict) else []
                    break
                except Exception:
                    if attempt == self.RETRY_COUNT - 1:
                        block = []

            for item in block:
                # 弹幕样式处理
                color = 16777215
                mode = 1
                content_style = item.get("content_style", {})
                style = {}
                if isinstance(content_style, dict):
                    style = content_style
                elif isinstance(content_style, str):
                    try:
                        style = json.loads(content_style)
                    except Exception:
                        style = {}
                try:
                    if "gradient_colors" in style and style["gradient_colors"]:
                        color = int(style["gradient_colors"][0], 16)
                    elif "color" in style:
                        color = int(style["color"], 16)
                    if style.get("position") == 1:
                        mode = 5
                except Exception:
                    pass

                try:
                    timestamp = int(float(item.get("create_time", time.time())))
                except Exception:
                    timestamp = int(time.time())
                try:
                    time_offset = int(float(item.get("time_offset", 0)))
                except Exception:
                    time_offset = 0

                content = item.get("content", "")
                if not isinstance(content, str):
                    content = str(content) if content is not None else ""

                danmu.append({
                    "time_offset": time_offset,
                    "mode": mode,
                    "font_size": 25,
                    "color": color,
                    "timestamp": timestamp,
                    "content": content,
                    'cid':item.get("id", 0)
                })

            current_step += 1
            if progress_callback:
                progress_callback(current=current_step,total=total_steps)

            start = end


        return danmu,duration/1000,info.get("title")


    def _replace_season_part_with_chinese_num(self,text):
        """
        格式化视频标题：
        - 第xxx季/部 → Sxx（支持汉字序号转数字），无季/部但有集/话则自动补S1
        - 第xxx集/话 → Exx（仅数字，不转汉字）
        - 最终格式：名称 SxxExx（名称和编号间空格，S和E之间无空格）
        """
        # 汉字数字到阿拉伯数字的映射（处理季/部的汉字序号）
        chinese_num_map = {
            '零': 0, '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
            '六': 6, '七': 7, '八': 8, '九': 9, '十': 10, '十一': 11,
            '十二': 12, '十三': 13, '十四': 14, '十五': 15, '十六': 16,
            '十七': 17, '十八': 18, '十九': 19, '二十': 20, '三十': 30,
            '四十': 40, '五十': 50, '六十': 60, '七十': 70, '八十': 80, '九十': 90
        }
        # 补充特殊汉字数字
        chinese_num_map.update({'廿': 20, '卅': 30, '卌': 40})

        # 初始化变量
        season_num = None  # 季/部数字
        episode_nums = []  # 集/话数字（支持多个，拼接为ExxExx）
        title_core = text  # 核心名称（最终清理冗余空格）

        # 1. 匹配并提取【季/部】信息，同时从核心名称中移除对应内容
        season_pattern = re.compile(r'\s*第\s*([零一二三四五六七八九十廿卅卌\d]+)\s*(季|部)\s*')
        season_match = season_pattern.search(title_core)
        if season_match:
            num_str = season_match.group(1)
            # 数字直接转，汉字按映射/组合处理
            if num_str.isdigit():
                season_num = int(num_str)
            else:
                if num_str in chinese_num_map:
                    season_num = chinese_num_map[num_str]
                else:
                    season_num = 0
                    # 处理组合汉字（如三十一=30+1、五十八=50+8）
                    ten_match = re.match(r'([零一二三四五六七八九]?)十', num_str)
                    if ten_match and ten_match.group(1):
                        season_num += chinese_num_map[ten_match.group(1)] * 10
                    elif num_str.startswith('十'):  # 十/十一/十九等
                        season_num += 10
                    # 匹配个位
                    unit_match = re.search(r'([零一二三四五六七八九])$', num_str)
                    if unit_match:
                        season_num += chinese_num_map[unit_match.group(1)]
            # 移除季/部相关内容
            title_core = season_pattern.sub('', title_core)

        # 2. 匹配并提取【集/话】信息，支持多个集/话，同时从核心名称中移除对应内容
        episode_pattern = re.compile(r'\s*第\s*(\d+)\s*(集|话)\s*')
        episode_matches = episode_pattern.findall(title_core)
        if episode_matches:
            episode_nums = [num.strip() for num, _ in episode_matches]
            # 移除所有集/话相关内容
            title_core = episode_pattern.sub('', title_core)

        # 3. 格式拼接核心逻辑
        # 清理核心名称的多余空格（连续空格→单空格、首尾去空）
        title_core = re.sub(r'\s+', ' ', title_core).strip()
        # 拼接季/集编号：无季则补S1，有季则Sxx；集/话拼接为ExxExx（多个）
        season_str = f"S{season_num}" if season_num is not None else "S1" if episode_nums else ""
        episode_str = ''.join([f"E{int(num)}" for num in episode_nums]) if episode_nums else ""
        full_code = f"{season_str}{episode_str}"  # S和E之间无空格

        # 4. 最终组合（名称和编号间单空格，无编号则仅返回名称）
        if full_code:
            final_title = f"{title_core} {full_code}"
        else:
            final_title = title_core

        return final_title