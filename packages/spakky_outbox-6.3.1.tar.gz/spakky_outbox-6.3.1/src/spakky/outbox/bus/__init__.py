"""Outbox bus module."""
