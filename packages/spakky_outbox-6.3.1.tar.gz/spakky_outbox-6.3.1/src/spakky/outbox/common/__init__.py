"""Outbox common module."""
