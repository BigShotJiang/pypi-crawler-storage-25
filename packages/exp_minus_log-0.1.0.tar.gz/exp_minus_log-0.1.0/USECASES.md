# Use cases for the EML operator

A single Boolean primitive (NAND) is the basis of all of digital
hardware. The EML operator is its continuous-mathematics analogue: a
single binary operator from which every elementary function is built.
Once you have that, several quite different application areas open up.

This document catalogues the ones that are *immediately implementable
with the code in this repository* (each section names the relevant
module and example) and a longer tail of more speculative directions.

## 1. One-instruction continuous CPU

If a calculator only knew how to (a) push the constant 1 and (b) do
EML, it would still cover every button on a scientific calculator —
this is the whole point of the paper. Concretely:

* **`eml.vm`** is a working stack VM with that exact opcode set. A
  programme is `tuple[Instr, ...]` over `{PUSH_1, PUSH_VAR, EML}`.
  `to_bytes` packs it into a one-byte-per-opcode bytestream so chains
  can be shipped to embedded targets.
* The bytestream is the simplest possible *continuous OISC* (one
  instruction set computer) — analogous to SUBLEQ but for
  real-valued elementary computation.

**What you can build now:** a tiny EML interpreter in C/Rust that
reads the bytestream from `to_bytes()` and runs your formula on a
microcontroller without linking `libm`. (Bring your own `exp` / `log`,
or implement them in Taylor series.)

**Run:** `examples/04_vm_bytecode.py`

## 2. FPGA / analog circuit synthesis

The paper notes (§4.2) that a single repeatable building block makes
elementary functions look like *digital hardware built from NAND gates*
or *analog circuits built from OpAmps*. The visualization in
`examples/03_visualise.py` already draws each chain in OpAmp style.

Because every EML node has identical fan-in/fan-out, a synthesizer
only has to lay out *one* cell and tile it. Concretely you could:

* generate Verilog from `eml.vm.compile_tree(tree)` — each `EML`
  opcode becomes an instance of a single configurable cell
  implementing `exp(a) − ln(b)` (e.g. CORDIC + LUT);
* feed the resulting netlist to Yosys for an actual FPGA target;
* or, for analog: each node becomes a fixed log-amp + diff-amp pair,
  fan-in routed by the tree topology (cf. `eml.viz.render_mpl`).

The hardware win is *scheduling*: in pure EML there is nothing to
schedule — every internal node is the same op. A NAND-style
floor-plan with one cell type and one routing pattern.

## 3. Differentiable symbolic regression

`eml.regression.MasterFormula` implements §4.3 of the paper.

The pitch: a fixed-topology level-`n` master formula has `5·2ⁿ − 6`
parameters — every tree input is a softmax over `{1, x, f}` (constant,
input variable, recursive sub-tree result). You can train the simplex
weights with Adam and *snap* them to vertices to get an exact
closed-form expression.

Compared with classic SR (PySR, gplearn, AI-Feynman):

* The grammar is **uniform**: one operator, one terminal. No need to
  pick an operator set up front.
* The search space is **complete** by construction: every elementary
  function is reachable.
* Optimisation is **continuous and differentiable** — Adam works.
* Snap-to-vertex gives **exact** discovery, not just a low-MSE
  approximation. (Paper: 100% recovery at depth 2, ≈25 % at 3-4.)

**Run:** `examples/06_symbolic_regression.py` (recovers `exp(x)` from
data, exact match in 6/8 random seeds).

## 4. Neural-network interpretability

Every standard activation function (ReLU, sigmoid, GELU, tanh) is an
elementary function. So *any* feed-forward NN with elementary
activations is a special case of an EML circuit — its weights can in
principle be re-expressed as exact subtrees of EML nodes plus linear
combinations.

Conversely, the master-formula architecture *is* a neural network, and
its trained weights *can be discrete*. That gives a form of
interpretability that conventional NNs do not have: when a sub-circuit
snaps to a vertex it becomes a legible elementary expression.

**Practical entry point:** start with `MasterFormula(level=2)`, train
on a known law, snap, and inspect the resulting RPN string. If the
RPN string is `"x1E"` you have rediscovered `exp`. If it is
`"11xE1EE"` you have rediscovered `log`.

## 5. Cross-language code generation

A single-operator IR is unusually easy to retarget. From an
`eml.tree.Node` you can emit, in roughly fifty lines each:

* **Python** — already done (`eml.vm.run`).
* **NumPy / vectorised** — already done (`eml.core.eml`).
* **mpmath / arbitrary precision** — already done (`eml.eml_mp`).
* **SymPy / symbolic** — already done (`eml.sympy_eml`).
* **C** — emit a sequence of `cexp() - clog()` lines.
* **Rust** — same.
* **CUDA / Triton kernel** — fuse all EML ops into a single kernel.
* **WASM / JS** — for in-browser elementary-function gadgets.

Because the IR has no operator zoo, the back-end is genuinely
~50 LoC. (Compare with implementing a code generator for SymPy's full
expression tree, which is hundreds of node classes.)

**Why this matters:** hot inner loops (Fourier-transform twiddle
factors, RKF45 ODE solvers, special-function libraries) often spend
most of their time in elementary function evaluation. Fusing entire
chains into a single EML kernel removes the per-call overhead of
calling `libm` and lets the compiler do better instruction
scheduling.

## 6. Approximation-theoretic compression of formulas

Take any closed-form expression and run it through the brute-force
shortest-search (`eml.search.shortest`). The output is the smallest
RPN string that reproduces the value to floating-point precision.
Storage size of a function in EML form is *one* opcode byte per RPN
instruction plus a small symbol table.

For libraries that ship lots of elementary identities (e.g. tables of
Maclaurin coefficients), this is a uniform compression scheme: the
"binary" of every special function looks the same and only the byte
sequence varies.

A neat downstream consequence: shortest-RPN length is a *concrete*
analogue of Kolmogorov complexity over the elementary class. The paper
calls it `K` and reports it in Table 4. We compute it with
`eml.search.shortest`.

## 7. High-precision evaluation as a sanity check on numerical
   libraries

`eml.core.evalf(node, dps=30, real=True)` evaluates an EML chain at
30-digit mpmath precision and rounds once to `complex128`. This
produces results that are bit-identical to `math.pi`, `math.sin(1)`,
`math.log(2)` — i.e. the EML chain is a correctly-rounded
double-precision implementation of any elementary function.

That makes EML a kind of cross-check for hand-tuned `libm`
implementations: any disagreement at the last ULP between
`math.cos(x)` and `evalf(build_unary("cos", "x"), {"x": x}, real=True)`
is a candidate `libm` rounding bug.

(Of course `math.*` in CPython is reasonably bug-free, so the use is
mostly to sanity-check *novel* `libm`s and SIMD trig kernels.)

## 8. Pedagogy and puzzle generation

The "broken calculator" puzzle (paper ref [34]) generalises naturally
to "given only the EML key, compute X". Because every elementary
operation has a definite, often non-obvious EML chain, the package
becomes a generator of arbitrarily-many such puzzles.

**Concrete:** call `eml.search.shortest(target, max_K=11)` to get a
puzzle ("write `√2` using only the EML key and 1") together with its
shortest known solution.

## 9. Theorem-prover-friendly elementary-function library

All Lean 4 tactics over `Real.log` / `Real.exp` immediately apply
inside an EML chain because every internal node is the same operator.
A formal library could expose just the EML lemma set and derive every
trigonometric identity from it mechanically.

(The paper notes that Lean's totality discipline gives `Complex.log 0
= 0` rather than `−∞`, so the EML chains for `0` and `−1` have to be
re-derived without extended reals; the "without extended reals"
variant numbers in Table 4 exist precisely for this.)

## 10. Symbolic differentiation in EML form

Every EML node has a clean two-component partial derivative:

```
∂/∂x  eml(x, y) =  exp(x)
∂/∂y  eml(x, y) = -1/y
```

So the gradient of an EML circuit is *another* EML circuit (only
slightly larger). Forward-mode AD becomes one rule. This makes EML a
natural fit for low-overhead AD systems on hardware where the
fully-fused kernel matters more than expression size.

## 11. Compact representation for tiny ML

Large language and vision models embed gigabytes of weights. Many of
them, after training, *are* approximating elementary functions of low
intrinsic complexity (the paper compares depth-40 trees to "trillions
of parameters"). For the elementary-functioned subspace of a model,
an EML form is potentially *thousands* of orders of magnitude
smaller. This is the most speculative item on the list, but it follows
directly from the universality result.

## 12. Drop-in single-operator activation

`σ(x) = 1/(1 + e^{−x})` is itself an EML chain (`eml.library.t_sigmoid`,
K=85). So you can already plug a "discrete" sigmoid into a tiny model
without a sigmoid op-code: just compile the chain.

More interestingly, the paper hypothesises (§5, last row of Table 2)
that there might be a *univariate* Sheffer operator that doubles as a
neural activation. If found, every "elementary-on-the-inside" neural
network would compile to a uniform circuit of just one cell type.

## 13. Graph / circuit isomorphism for formula deduplication

Two elementary expressions that simplify to the same closed form will
have *different* EML trees in general (because the natural composition
isn't unique). But the canonical *shortest* EML tree is unique up to
chirality, so:

1. simplify both expressions in SymPy;
2. compile each to its shortest EML form via `eml.search.shortest`;
3. compare the RPN strings byte-wise.

This is a fast, hash-friendly equality check that doesn't require a
full computer-algebra normaliser.

## 14. Continuous Sheffer-stroke logic gates

In Boolean logic, every gate is built from NAND. In fuzzy / continuous
logic (paper ref [20]) people study fuzzy Sheffer strokes — these are
exactly the EML cousins. `eml.cousins.edl` and `eml.cousins.neml`
provide two more such strokes; new ones can be searched programmatically
by re-running the `VerifyBaseSet`-style routine on candidate operators.

## 15. Compact "mathematical assembly" for spacecraft / radiation-hard
    embedded systems

Old space-rated CPUs sometimes ship without an FPU's transcendental
function unit. Whatever they have, they always have `ADD`, `SUB`,
`MUL`, plus a way to compute `exp` and `ln` (CORDIC, polynomial). In
that environment, every elementary function lookup becomes a few
EML steps — no library code path, no branch prediction, no new
opcode. Plus the bytestream is comparable in size to a Taylor series
truncation.

---

## Code map

| use case            | module(s)                               | example                              |
|---------------------|-----------------------------------------|--------------------------------------|
| 1, 5, 15            | `eml.vm`                                | `examples/04_vm_bytecode.py`         |
| 2                   | `eml.viz`, `eml.vm`                     | `examples/03_visualise.py`           |
| 3, 4, 11, 12        | `eml.regression`                        | `examples/06_symbolic_regression.py` |
| 6, 13               | `eml.search`                            | `examples/05_search.py`              |
| 7                   | `eml.core.evalf`                        | (see this file's example below)      |
| 8                   | `eml.search`                            | `examples/05_search.py`              |
| 9, 10               | `eml.sympy_eml`                         | `examples/08_sympy_calculus.py`      |
| 14                  | `eml.cousins`                           | `examples/09_cousins.py`             |

### One-liner for use case 7

```python
import math
from eml.core import evalf
from eml.library import build_constant, build_unary

assert evalf(build_constant("pi"), real=True) == math.pi
assert evalf(build_unary("sin", "x"), {"x": 1.0}, real=True) == math.sin(1.0)
assert evalf(build_unary("ln",  "x"), {"x": 2.0}, real=True) == math.log(2.0)
```
