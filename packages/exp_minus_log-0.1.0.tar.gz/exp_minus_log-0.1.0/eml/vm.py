"""Single-instruction stack machine for pure-EML execution.

The paper notes (§4.1) that any EML expression can be executed by a
machine "that has only a single instruction: the EML itself."  This
module provides exactly that: a tiny RPN VM whose opcode set is

* ``PUSH_1``   — push the constant 1
* ``PUSH_VAR`` — push the value of a free variable
* ``EML``      — pop two operands, push ``eml(a, b) = exp(a) - ln(b)``

The VM accepts both the paper's compact RPN strings (``"11xE1EE"``) and
explicit token lists (``["1", "1", "x", "E", "1", "E", "E"]``).  A
canonical *programme* is a tuple of opcodes; we keep that representation
so multiple instances can be JIT-compiled or shipped to FPGA/analog
backends as bytestreams (cf. paper §4.2 — "Pure-EML form could possibly
be implemented efficiently in FPGA or analog circuits").

The VM is parameterised on the EML implementation, so the same bytecode
can run against:

* the NumPy float/complex backend  (default)
* the mpmath arbitrary-precision backend
* the symbolic SymPy ``EmlFn`` backend
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Any, Callable, Mapping, Sequence

from .core import eml as eml_np
from .tree import Node, One, Var, Eml, parse_rpn


class Op(IntEnum):
    PUSH_1 = 0
    PUSH_VAR = 1
    EML = 2


@dataclass(frozen=True)
class Instr:
    op: Op
    arg: str | None = None  # variable name for PUSH_VAR, else None

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        if self.op is Op.PUSH_1:
            return "PUSH 1"
        if self.op is Op.PUSH_VAR:
            return f"PUSH {self.arg}"
        return "EML"


Program = tuple[Instr, ...]


# ---------------------------------------------------------------------------
# Compilation


def compile_tree(node: Node) -> Program:
    """Lower an EML expression tree to a flat program."""
    out: list[Instr] = []

    def emit(n: Node) -> None:
        if isinstance(n, One):
            out.append(Instr(Op.PUSH_1))
        elif isinstance(n, Var):
            out.append(Instr(Op.PUSH_VAR, n.name))
        elif isinstance(n, Eml):
            emit(n.left)
            emit(n.right)
            out.append(Instr(Op.EML))
        else:
            raise TypeError(type(n))

    emit(node)
    return tuple(out)


def compile_rpn(rpn: str | Sequence[str], *, vars: tuple[str, ...] | None = None) -> Program:
    """Compile an RPN string (or token list) directly to a program."""
    if isinstance(rpn, str):
        return compile_tree(parse_rpn(rpn, vars=vars))
    return compile_tree(parse_rpn(" ".join(rpn), vars=vars))


def disassemble(prog: Program) -> str:
    """Pretty-print a program."""
    lines = []
    for i, instr in enumerate(prog):
        lines.append(f"{i:4d}  {instr}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Execution


def run(
    prog: Program,
    env: Mapping[str, Any] | None = None,
    *,
    op: Callable[[Any, Any], Any] | None = None,
    one: Any = 1,
) -> Any:
    """Execute the program and return the final stack value.

    Parameters
    ----------
    prog : Program
    env  : mapping, optional
        Values for free variables (PUSH_VAR opcodes).
    op   : callable, optional
        EML implementation (defaults to :func:`eml.core.eml`).
    one  : object, optional
        Value to push for ``PUSH_1`` (defaults to the integer ``1``).
    """
    env = dict(env or {})
    op = op or eml_np

    stack: list[Any] = []
    push = stack.append
    pop = stack.pop

    for instr in prog:
        if instr.op is Op.PUSH_1:
            push(one)
        elif instr.op is Op.PUSH_VAR:
            push(env[instr.arg])
        else:  # EML
            b = pop()
            a = pop()
            push(op(a, b))

    if len(stack) != 1:
        raise RuntimeError(
            f"VM ended with {len(stack)} stack items, expected 1"
        )
    return stack[0]


# ---------------------------------------------------------------------------
# Trace mode (for debugging / pedagogy)


def trace(prog: Program, env: Mapping[str, Any] | None = None,
          *, op: Callable[[Any, Any], Any] | None = None, one: Any = 1) -> list[tuple[Instr, list[Any]]]:
    """Execute the program in single-step mode, returning a list of
    ``(instruction, stack_after)`` snapshots."""
    env = dict(env or {})
    op = op or eml_np
    stack: list[Any] = []
    log: list[tuple[Instr, list[Any]]] = []
    for instr in prog:
        if instr.op is Op.PUSH_1:
            stack.append(one)
        elif instr.op is Op.PUSH_VAR:
            stack.append(env[instr.arg])
        else:
            b = stack.pop()
            a = stack.pop()
            stack.append(op(a, b))
        log.append((instr, list(stack)))
    return log


# ---------------------------------------------------------------------------
# Bytestream encoding (for embedded targets / FPGA bring-up)
#
# The encoding uses one byte per opcode; PUSH_VAR is followed by a single
# byte holding a variable index (looked up in the program's symbol table).


def to_bytes(prog: Program) -> tuple[bytes, list[str]]:
    """Pack a program into a compact bytestream + variable table."""
    var_table: list[str] = []
    table_lookup: dict[str, int] = {}
    out = bytearray()
    for instr in prog:
        out.append(int(instr.op))
        if instr.op is Op.PUSH_VAR:
            name = instr.arg
            if name not in table_lookup:
                table_lookup[name] = len(var_table)
                var_table.append(name)
            out.append(table_lookup[name])
    return bytes(out), var_table


def from_bytes(stream: bytes, var_table: list[str]) -> Program:
    """Decode the inverse of :func:`to_bytes`."""
    out: list[Instr] = []
    i = 0
    while i < len(stream):
        op = Op(stream[i])
        i += 1
        if op is Op.PUSH_VAR:
            idx = stream[i]
            i += 1
            out.append(Instr(op, var_table[idx]))
        else:
            out.append(Instr(op))
    return tuple(out)


__all__ = [
    "Op", "Instr", "Program",
    "compile_tree", "compile_rpn", "disassemble",
    "run", "trace",
    "to_bytes", "from_bytes",
]
