"""EML expression trees and Reverse-Polish-Notation compiler.

The grammar is exactly the one given in the paper::

    S -> 1 | x | y | z | ... | eml(S, S)

Every elementary expression in the EML system is a *full binary tree* whose
internal nodes are all the same operator. This module provides:

* :class:`Node` — an immutable EML AST with structural sharing
* :class:`One`, :class:`Var`, :class:`Eml` — node subclasses
* :func:`parse_rpn` / :func:`to_rpn` — round-trip with the RPN notation
  used by the paper, e.g. ``"11xE1EE"`` for ``ln(x)``
* :func:`evaluate` — numerical evaluation against any backend (numpy by
  default, mpmath / sympy on request)
* :func:`leaf_count` — equivalent to Mathematica's ``LeafCount``,
  matching the K column in Table 4
* :func:`to_sympy` — emit a sympy ``Expr`` for symbolic verification

The classes deliberately have value semantics: two equal-shaped trees
hash the same, so they slot into Python ``set`` / ``dict`` for memoised
search.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterator, Mapping

import numpy as np

from .core import eml as _eml_np

# ---------------------------------------------------------------------------
# AST


class Node:
    """Abstract EML AST node. Subclasses are :class:`One`, :class:`Var`,
    :class:`Eml`. All nodes are immutable and hashable."""

    __slots__ = ()

    # ----- structural traversal -------------------------------------------
    def walk(self) -> Iterator["Node"]:
        """Pre-order traversal of the tree."""
        yield self

    def leaf_count(self) -> int:
        """Number of *leaf* occurrences (counts ``1`` and variables)."""
        return 1

    def rpn_length(self) -> int:
        """K — the length of the RPN code (matches Table 4 of the paper).

        For a full binary tree with ``L`` leaves and ``L-1`` internal
        nodes this is ``2*L - 1``; for a bare leaf it is ``1``.
        """
        return 1

    def depth(self) -> int:
        return 0

    # ----- evaluation -----------------------------------------------------
    def __call__(self, **env: Any):
        return self.evaluate(env)

    def evaluate(
        self,
        env: Mapping[str, Any] | None = None,
        *,
        op: Callable[[Any, Any], Any] | None = None,
        one: Any = 1,
    ):
        """Evaluate the tree.

        Parameters
        ----------
        env : mapping
            Values to substitute for free variables.
        op : callable, optional
            Override for the EML node operation. Defaults to the NumPy
            implementation in :mod:`eml.core`.
        one : object, optional
            Value to substitute for the leaf ``1``. Useful when working
            inside another semiring (e.g. mpmath, sympy).
        """
        env = dict(env or {})
        op = op or _eml_np
        return self._eval(env, op, one)

    def _eval(self, env, op, one):  # pragma: no cover - abstract
        raise NotImplementedError

    # ----- pretty-printing -----------------------------------------------
    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return self.to_str()

    def to_str(self) -> str:
        raise NotImplementedError

    def to_rpn(self) -> str:
        out: list[str] = []
        self._rpn(out)
        return "".join(out)

    def _rpn(self, out: list[str]) -> None:  # pragma: no cover - abstract
        raise NotImplementedError


@dataclass(frozen=True)
class One(Node):
    """The terminal symbol ``1``."""

    __slots__ = ()

    def _eval(self, env, op, one):
        return one

    def to_str(self) -> str:
        return "1"

    def _rpn(self, out):
        out.append("1")


@dataclass(frozen=True)
class Var(Node):
    """A free variable (terminal symbol other than ``1``)."""

    name: str

    def _eval(self, env, op, one):
        if self.name not in env:
            raise KeyError(f"variable {self.name!r} not bound in env")
        return env[self.name]

    def to_str(self) -> str:
        return self.name

    def _rpn(self, out):
        out.append(self.name)


@dataclass(frozen=True)
class Eml(Node):
    """An ``eml(left, right)`` internal node."""

    left: Node
    right: Node

    def walk(self) -> Iterator[Node]:
        yield self
        yield from self.left.walk()
        yield from self.right.walk()

    def leaf_count(self) -> int:
        return self.left.leaf_count() + self.right.leaf_count()

    def rpn_length(self) -> int:
        return self.left.rpn_length() + self.right.rpn_length() + 1

    def depth(self) -> int:
        return 1 + max(self.left.depth(), self.right.depth())

    def _eval(self, env, op, one):
        a = self.left._eval(env, op, one)
        b = self.right._eval(env, op, one)
        return op(a, b)

    def to_str(self) -> str:
        return f"eml({self.left.to_str()}, {self.right.to_str()})"

    def _rpn(self, out):
        self.left._rpn(out)
        self.right._rpn(out)
        out.append("E")


# ---------------------------------------------------------------------------
# Convenience constructors

ONE = One()


def V(name: str) -> Var:
    return Var(name)


def E(a: Node, b: Node) -> Eml:
    """Shorthand for ``Eml(a, b)``."""
    return Eml(a, b)


# ---------------------------------------------------------------------------
# RPN round-trip


def parse_rpn(code: str, *, vars: tuple[str, ...] | None = None) -> Node:
    """Parse an RPN string in the paper's notation.

    The alphabet is::

        '1'              -> ONE
        'E'              -> apply the EML operator (pop two, push eml(a,b))
        single-letter id -> Var(letter)              (default: x, y, z, ...)
        word in vars     -> Var(word)                (if a vars list is given)

    Examples
    --------
    >>> parse_rpn("11xE1EE").to_str()
    'eml(1, eml(eml(1, x), 1))'
    """
    stack: list[Node] = []
    if vars is None:
        # interpret any non-'1', non-'E' single letter as a variable
        for ch in code:
            if ch == "1":
                stack.append(ONE)
            elif ch == "E":
                if len(stack) < 2:
                    raise ValueError(f"RPN underflow at: {code!r}")
                b = stack.pop()
                a = stack.pop()
                stack.append(Eml(a, b))
            elif ch.isspace():
                continue
            elif ch.isalpha():
                stack.append(Var(ch))
            else:
                raise ValueError(f"unknown RPN symbol {ch!r} in {code!r}")
    else:
        # token-based parser, splitting on whitespace
        tokens = code.split()
        for tok in tokens:
            if tok == "1":
                stack.append(ONE)
            elif tok == "E" or tok == "eml":
                if len(stack) < 2:
                    raise ValueError(f"RPN underflow at: {code!r}")
                b = stack.pop()
                a = stack.pop()
                stack.append(Eml(a, b))
            elif tok in vars:
                stack.append(Var(tok))
            else:
                raise ValueError(f"unknown RPN token {tok!r} in {code!r}")

    if len(stack) != 1:
        raise ValueError(f"RPN code {code!r} did not reduce to a single tree")
    return stack[0]


def to_rpn(node: Node) -> str:
    """Inverse of :func:`parse_rpn`. Returns the canonical RPN string."""
    return node.to_rpn()


# ---------------------------------------------------------------------------
# Sympy bridge


def to_sympy(node: Node, *, free: Mapping[str, Any] | None = None):
    """Convert ``node`` to a sympy ``Expr`` using ``exp``/``log``."""
    import sympy as sp

    free = dict(free or {})

    def lift(n: Node):
        if isinstance(n, One):
            return sp.Integer(1)
        if isinstance(n, Var):
            return free.setdefault(n.name, sp.Symbol(n.name))
        if isinstance(n, Eml):
            a = lift(n.left)
            b = lift(n.right)
            return sp.exp(a) - sp.log(b)
        raise TypeError(type(n))

    return lift(node)


# ---------------------------------------------------------------------------
# Test vectors (canonical identities from the paper)

LN_RPN = "11xE1EE"  # ln(x)
EXP_RPN = "x1E"     # exp(x)
E_RPN = "11E"       # the constant e
ZERO_RPN = "111E1EE"   # 0 = ln(1) = eml(1, eml(eml(1, 1), 1))


__all__ = [
    "Node",
    "One",
    "Var",
    "Eml",
    "ONE",
    "V",
    "E",
    "parse_rpn",
    "to_rpn",
    "to_sympy",
    "LN_RPN",
    "EXP_RPN",
    "E_RPN",
    "ZERO_RPN",
]
