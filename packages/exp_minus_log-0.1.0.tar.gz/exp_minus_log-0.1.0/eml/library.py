"""The EML *library*: every primitive of Table 1 expressed as an EML tree.

Each entry of :data:`LIBRARY` is a callable that takes the relevant input
:class:`~eml.tree.Var` nodes and returns the EML :class:`~eml.tree.Node`
that computes the primitive. Constants take no arguments; unary functions
take one variable; binary operators take two.

The chains here are **natural compositional** chains (matching the
"EML Compiler" column of Table 4 in the paper). Optimal/shortest chains
(the "Direct search" column) are produced by :mod:`eml.search`.

All chains are correct over the complex plane (principal branch).  A few
of them — typically those that route through ``ln(0) = -inf`` — only give
the standard real value when evaluated in IEEE-754 floating point with
signed zeros and infinities, exactly as the paper documents (§4.1).
"""

from __future__ import annotations

from typing import Callable, Mapping

import numpy as np

from .tree import E, ONE, Node, Var, V


# ---------------------------------------------------------------------------
# Building blocks (all return Node)


def t_exp(t: Node) -> Node:
    """``exp(t)`` -> ``eml(t, 1)``."""
    return E(t, ONE)


def t_ln(t: Node) -> Node:
    """``ln(t)`` -> ``eml(1, eml(eml(1, t), 1))``  (Eq. (5) in the paper)."""
    return E(ONE, E(E(ONE, t), ONE))


def t_e() -> Node:
    """The constant ``e``."""
    return E(ONE, ONE)


def t_zero() -> Node:
    """The constant ``0`` (= ``ln 1``)."""
    return t_ln(ONE)


def t_sub(a: Node, b: Node) -> Node:
    """Subtraction: ``a - b`` over C."""
    return E(t_ln(a), t_exp(b))


def t_neg(b: Node) -> Node:
    """Negation: ``-b``."""
    return t_sub(t_zero(), b)


def t_add(a: Node, b: Node) -> Node:
    """Addition: ``a + b = -((-a) - b)``."""
    return t_neg(t_sub(t_neg(a), b))


def t_inv(b: Node) -> Node:
    """Reciprocal: ``1/b = exp(-ln b)``."""
    return t_exp(t_neg(t_ln(b)))


def t_mul(a: Node, b: Node) -> Node:
    """Multiplication: ``a*b = exp(ln a + ln b)``."""
    return t_exp(t_add(t_ln(a), t_ln(b)))


def t_div(a: Node, b: Node) -> Node:
    """Division: ``a/b``."""
    return t_mul(a, t_inv(b))


def t_pow(a: Node, b: Node) -> Node:
    """Power: ``a^b = exp(b * ln a)``."""
    return t_exp(t_mul(b, t_ln(a)))


def t_sqr(t: Node) -> Node:
    return t_mul(t, t)


# constants in named form -- each builds the integer/fraction from the
# primitive root constants {1, e, 0} via subtraction and inversion.

def t_minus_one() -> Node:
    """``-1 = 0 - 1``."""
    return t_sub(t_zero(), ONE)


def t_two() -> Node:
    """``2 = 1 - (-1)``."""
    return t_sub(ONE, t_minus_one())


def t_minus_two() -> Node:
    return t_neg(t_two())


def t_half() -> Node:
    return t_inv(t_two())


def t_minus_half() -> Node:
    return t_neg(t_half())


def t_three() -> Node:
    """``3 = 2 + 1`` (used internally)."""
    return t_add(t_two(), ONE)


def t_two_thirds() -> Node:
    """``2/3``."""
    return t_div(t_two(), t_three())


def t_minus_two_thirds() -> Node:
    return t_neg(t_two_thirds())


def t_sqrt(t: Node) -> Node:
    return t_pow(t, t_half())


def t_sqrt2() -> Node:
    return t_sqrt(t_two())


def t_i() -> Node:
    """``i = sqrt(-1)``."""
    return t_sqrt(t_minus_one())


def t_pi() -> Node:
    """``pi = ln(-1) / i``  (since ``ln(-1) = i*pi`` in principal branch)."""
    return t_div(t_ln(t_minus_one()), t_i())


def t_sigmoid(t: Node) -> Node:
    """``sigma(t) = 1/(1 + e^{-t})``."""
    return t_inv(t_add(ONE, t_exp(t_neg(t))))


# ----- trigonometric / hyperbolic ------------------------------------------


def t_sinh(t: Node) -> Node:
    """``sinh t = (e^t - e^{-t})/2``."""
    return t_half_of(t_sub(t_exp(t), t_exp(t_neg(t))))


def t_cosh(t: Node) -> Node:
    return t_half_of(t_add(t_exp(t), t_exp(t_neg(t))))


def t_tanh(t: Node) -> Node:
    return t_div(t_sinh(t), t_cosh(t))


def t_half_of(t: Node) -> Node:
    """Apply ``x -> x/2`` to a *subtree* (used as syntactic sugar)."""
    return t_div(t, t_two())


def t_sin(t: Node) -> Node:
    """``sin t = (e^{it} - e^{-it})/(2i)``."""
    it = t_mul(t_i(), t)
    num = t_sub(t_exp(it), t_exp(t_neg(it)))
    return t_div(num, t_mul(t_two(), t_i()))


def t_cos(t: Node) -> Node:
    """``cos t = (e^{it} + e^{-it})/2``."""
    it = t_mul(t_i(), t)
    return t_half_of(t_add(t_exp(it), t_exp(t_neg(it))))


def t_tan(t: Node) -> Node:
    return t_div(t_sin(t), t_cos(t))


def t_arcsin(t: Node) -> Node:
    """``arcsin t = -i ln(it + sqrt(1 - t^2))``."""
    it = t_mul(t_i(), t)
    rad = t_sqrt(t_sub(ONE, t_sqr(t)))
    return t_mul(t_neg(t_i()), t_ln(t_add(it, rad)))


def t_arccos(t: Node) -> Node:
    """``arccos t = -i ln(t + i sqrt(1 - t^2))``."""
    rad = t_mul(t_i(), t_sqrt(t_sub(ONE, t_sqr(t))))
    return t_mul(t_neg(t_i()), t_ln(t_add(t, rad)))


def t_arctan(t: Node) -> Node:
    """``arctan t = (1/(2i)) ln((1+it)/(1-it))``."""
    it = t_mul(t_i(), t)
    num = t_add(ONE, it)
    den = t_sub(ONE, it)
    return t_div(t_ln(t_div(num, den)), t_mul(t_two(), t_i()))


def t_arsinh(t: Node) -> Node:
    return t_ln(t_add(t, t_sqrt(t_add(t_sqr(t), ONE))))


def t_arcosh(t: Node) -> Node:
    return t_ln(t_add(t, t_sqrt(t_sub(t_sqr(t), ONE))))


def t_artanh(t: Node) -> Node:
    return t_half_of(t_ln(t_div(t_add(ONE, t), t_sub(ONE, t))))


# ----- binary operations from Table 1 --------------------------------------


def t_log_base(x: Node, y: Node) -> Node:
    """``log_x(y) = ln y / ln x``."""
    return t_div(t_ln(y), t_ln(x))


def t_avg(x: Node, y: Node) -> Node:
    return t_half_of(t_add(x, y))


def t_hypot(x: Node, y: Node) -> Node:
    return t_sqrt(t_add(t_sqr(x), t_sqr(y)))


# ---------------------------------------------------------------------------
# Master library — Table 1 reproduced exactly

X, Y = V("x"), V("y")


def _fn(builder: Callable, *args) -> Node:
    return builder(*args)


# Each entry: name -> (builder, arity, reference Python implementation)
import cmath as _cm
import math as _m


def _ref_eml(x, y):
    return _cm.exp(x) - _cm.log(y)


# unary reference (use cmath so they're complex-safe)
_unary_ref = {
    "exp":     lambda x: _cm.exp(x),
    "ln":      lambda x: _cm.log(x),
    "inv":     lambda x: 1 / x,
    "half":    lambda x: x / 2,
    "minus":   lambda x: -x,
    "sqr":     lambda x: x * x,
    "sqrt":    lambda x: _cm.sqrt(x),
    "sigma":   lambda x: 1 / (1 + _cm.exp(-x)),
    "sin":     lambda x: _cm.sin(x),
    "cos":     lambda x: _cm.cos(x),
    "tan":     lambda x: _cm.tan(x),
    "arcsin":  lambda x: _cm.asin(x),
    "arccos":  lambda x: _cm.acos(x),
    "arctan":  lambda x: _cm.atan(x),
    "sinh":    lambda x: _cm.sinh(x),
    "cosh":    lambda x: _cm.cosh(x),
    "tanh":    lambda x: _cm.tanh(x),
    "arsinh":  lambda x: _cm.asinh(x),
    "arcosh":  lambda x: _cm.acosh(x),
    "artanh":  lambda x: _cm.atanh(x),
}


_binary_ref = {
    "add":     lambda a, b: a + b,
    "sub":     lambda a, b: a - b,
    "mul":     lambda a, b: a * b,
    "div":     lambda a, b: a / b,
    "log":     lambda a, b: _cm.log(b) / _cm.log(a),  # log_a(b)
    "pow":     lambda a, b: a ** b,
    "avg":     lambda a, b: (a + b) / 2,
    "hypot":   lambda a, b: _cm.sqrt(a * a + b * b),
}


# unary builders (one Var argument)
_unary_builder: dict[str, Callable[[Node], Node]] = {
    "exp":     t_exp,
    "ln":      t_ln,
    "inv":     t_inv,
    "half":    t_half_of,
    "minus":   t_neg,
    "sqr":     t_sqr,
    "sqrt":    t_sqrt,
    "sigma":   t_sigmoid,
    "sin":     t_sin,
    "cos":     t_cos,
    "tan":     t_tan,
    "arcsin":  t_arcsin,
    "arccos":  t_arccos,
    "arctan":  t_arctan,
    "sinh":    t_sinh,
    "cosh":    t_cosh,
    "tanh":    t_tanh,
    "arsinh":  t_arsinh,
    "arcosh":  t_arcosh,
    "artanh":  t_artanh,
}

# binary builders (two Var arguments)
_binary_builder: dict[str, Callable[[Node, Node], Node]] = {
    "add":     t_add,
    "sub":     t_sub,
    "mul":     t_mul,
    "div":     t_div,
    "log":     t_log_base,
    "pow":     t_pow,
    "avg":     t_avg,
    "hypot":   t_hypot,
}

# constant builders (no arguments)
_const_builder: dict[str, Callable[[], Node]] = {
    "1":       lambda: ONE,
    "e":       t_e,
    "0":       t_zero,
    "-1":      t_minus_one,
    "2":       t_two,
    "-2":      t_minus_two,
    "1/2":     t_half,
    "-1/2":    t_minus_half,
    "2/3":     t_two_thirds,
    "-2/3":    t_minus_two_thirds,
    "sqrt(2)": t_sqrt2,
    "i":       t_i,
    "pi":      t_pi,
}


_const_ref: dict[str, complex] = {
    "1":       1.0,
    "e":       _m.e,
    "0":       0.0,
    "-1":      -1.0,
    "2":       2.0,
    "-2":      -2.0,
    "1/2":     0.5,
    "-1/2":    -0.5,
    "2/3":     2 / 3,
    "-2/3":    -2 / 3,
    "sqrt(2)": _m.sqrt(2),
    "i":       1j,
    "pi":      _m.pi,
}


def build_constant(name: str) -> Node:
    return _const_builder[name]()


def build_unary(name: str, var: Var | str = "x") -> Node:
    if isinstance(var, str):
        var = V(var)
    return _unary_builder[name](var)


def build_binary(name: str, x: Var | str = "x", y: Var | str = "y") -> Node:
    if isinstance(x, str):
        x = V(x)
    if isinstance(y, str):
        y = V(y)
    return _binary_builder[name](x, y)


def reference(name: str) -> Callable:
    """Return a callable Python reference implementation of ``name``."""
    if name in _unary_ref:
        return _unary_ref[name]
    if name in _binary_ref:
        return _binary_ref[name]
    if name in _const_ref:
        v = _const_ref[name]
        return lambda: v
    raise KeyError(name)


CONSTANTS = list(_const_builder.keys())
UNARY = list(_unary_builder.keys())
BINARY = list(_binary_builder.keys())
ALL_NAMES = CONSTANTS + UNARY + BINARY


__all__ = [
    "build_constant", "build_unary", "build_binary", "reference",
    "CONSTANTS", "UNARY", "BINARY", "ALL_NAMES",
    "t_exp", "t_ln", "t_e", "t_zero", "t_sub", "t_neg", "t_add",
    "t_inv", "t_mul", "t_div", "t_pow", "t_sqr", "t_sqrt",
    "t_minus_one", "t_two", "t_half", "t_i", "t_pi",
    "t_sin", "t_cos", "t_tan", "t_arcsin", "t_arccos", "t_arctan",
    "t_sinh", "t_cosh", "t_tanh", "t_arsinh", "t_arcosh", "t_artanh",
    "t_sigmoid", "t_log_base", "t_avg", "t_hypot",
]
