"""SymPy custom :class:`Function` for the EML operator.

This is the symbolic counterpart of :func:`eml.core.eml`. It plugs into
sympy's standard machinery for differentiation, rewriting, evaluation
and ``lambdify``, so symbolic chains can be simplified, differentiated
and code-generated like any other sympy expression.

The implementation follows the canonical pattern documented at
https://docs.sympy.org/latest/guides/custom-functions.html .

Examples
--------
>>> from sympy import symbols, simplify, exp, log
>>> from eml.sympy_eml import EmlFn, eml_to_explog, explog_to_eml
>>> x = symbols('x', positive=True, real=True)
>>> EmlFn(1, EmlFn(EmlFn(1, x), 1))           # the canonical ln chain
EmlFn(1, EmlFn(EmlFn(1, x), 1))
>>> simplify(eml_to_explog(_))                # simplifies to log(x)
log(x)
"""

from __future__ import annotations

from sympy import (
    E as sym_E,
    Expr,
    Function,
    Integer,
    S,
    exp,
    log,
    sympify,
    Wild,
    Symbol,
)


class EmlFn(Function):
    """Symbolic ``eml(x, y) = exp(x) - log(y)``."""

    nargs = 2

    @classmethod
    def eval(cls, x, y):
        # Auto-evaluate a few canonical sub-expressions.
        x = sympify(x)
        y = sympify(y)

        # eml(x, 1) = exp(x)        (ln 1 = 0)
        if y == S.One:
            return exp(x)
        # eml(1, 1) = e
        if x == S.One and y == S.One:
            return sym_E
        # eml(0, y) = 1 - ln(y)
        if x == S.Zero:
            return S.One - log(y)
        # eml(x, e) = exp(x) - 1
        if y == sym_E:
            return exp(x) - 1
        # No automatic simplification beyond that — let users opt-in via
        # ``rewrite(exp)`` so that the EML grammar is preserved.
        return None

    def fdiff(self, argindex=1):
        """Partial derivatives.

        ``d/dx eml(x, y) =  exp(x)``
        ``d/dy eml(x, y) = -1/y``.
        """
        x, y = self.args
        if argindex == 1:
            return exp(x)
        if argindex == 2:
            return -1 / y
        raise ValueError(f"bad argindex {argindex}")

    def _eval_rewrite(self, rule, args, **hints):
        """Allow ``expr.rewrite(exp)`` -> ``exp(x) - log(y)``."""
        x, y = args
        if rule is exp or rule is log:
            return exp(x) - log(y)
        return None

    def _eval_evalf(self, prec):
        x, y = self.args
        return (exp(x) - log(y))._eval_evalf(prec)

    def _eval_is_real(self):
        # Real iff x is real and y is positive real.
        x, y = self.args
        return x.is_real and y.is_positive

    def _eval_conjugate(self):
        x, y = self.args
        return EmlFn(x.conjugate(), y.conjugate())

    def _latex(self, printer):  # pragma: no cover - cosmetic
        x, y = self.args
        return rf"\operatorname{{eml}}\!\left({printer._print(x)},\,{printer._print(y)}\right)"


# ---------------------------------------------------------------------------
# Bidirectional conversion between EML form and exp/log form


def eml_to_explog(expr):
    """Replace every :class:`EmlFn` node with ``exp(x) - log(y)``."""
    expr = sympify(expr)
    return expr.replace(EmlFn, lambda x, y: exp(x) - log(y))


def explog_to_eml(expr):
    """Best-effort reverse: pattern-match ``exp(x) - log(y)`` to ``EmlFn``.

    This rewrites every subexpression of the *exact* shape
    ``exp(_) - log(_)`` into an :class:`EmlFn` node.  It is a syntactic
    rewrite (not full normalisation): pre-simplify with
    :func:`sympy.expand_log` if the source uses log identities.
    """
    expr = sympify(expr)
    a, b = Wild("a"), Wild("b")
    pattern = exp(a) - log(b)
    return expr.replace(pattern, lambda a, b: EmlFn(a, b))


# ---------------------------------------------------------------------------
# Tree <-> sympy bridge


def tree_to_sympy(node, free=None):
    """Convert an :mod:`eml.tree` node to a sympy expression using
    :class:`EmlFn` (preserves EML structure).

    Use :func:`eml.tree.to_sympy` if you want the raw exp/log form.
    """
    from .tree import One, Var, Eml

    free = dict(free or {})

    def lift(n):
        if isinstance(n, One):
            return Integer(1)
        if isinstance(n, Var):
            return free.setdefault(n.name, Symbol(n.name))
        if isinstance(n, Eml):
            return EmlFn(lift(n.left), lift(n.right))
        raise TypeError(type(n))

    return lift(node)


__all__ = ["EmlFn", "eml_to_explog", "explog_to_eml", "tree_to_sympy"]
