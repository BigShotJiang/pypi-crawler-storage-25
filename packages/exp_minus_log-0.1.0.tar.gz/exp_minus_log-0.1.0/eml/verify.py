"""``VerifyBaseSet``-style verification suite for EML chains.

Two complementary checks, mirroring §2 of the paper:

* :func:`numeric_witness` — substitute every free variable with an
  algebraically-independent transcendental (γ, A, ...) and compare the
  EML chain's value against a high-precision evaluation of the target.
  Under Schanuel's conjecture, agreement at such a witness is
  overwhelming evidence for symbolic equality.
* :func:`symbolic_check` — a sympy-level check using ``simplify``,
  ``expand_log`` and ``logcombine`` to fold an EML chain back to its
  putative target.

A high-level :func:`verify_library` driver applies both checks to every
primitive in :mod:`eml.library` and prints a summary table (mirroring
the reproducibility report described in Supplementary Information,
Sect. II of the paper).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

import math
import cmath

import mpmath as mp

from .library import (
    CONSTANTS, UNARY, BINARY,
    build_constant, build_unary, build_binary, reference,
)
from .tree import Node


# ---------------------------------------------------------------------------
# Arbitrary-precision reference implementations (mpmath versions of every
# Table-1 primitive).  These are used by :func:`verify_library` so that the
# error budget is set by the EML chain itself, not by double-precision
# rounding of a cmath reference.

def _mp_ref():
    return {
        # constants
        "1":       lambda: mp.mpf(1),
        "e":       lambda: mp.e,
        "0":       lambda: mp.mpf(0),
        "-1":      lambda: mp.mpf(-1),
        "2":       lambda: mp.mpf(2),
        "-2":      lambda: mp.mpf(-2),
        "1/2":     lambda: mp.mpf(1) / 2,
        "-1/2":    lambda: -mp.mpf(1) / 2,
        "2/3":     lambda: mp.mpf(2) / 3,
        "-2/3":    lambda: -mp.mpf(2) / 3,
        "sqrt(2)": lambda: mp.sqrt(2),
        "i":       lambda: mp.mpc(0, 1),
        "pi":      lambda: mp.pi,
        # unaries
        "exp":     mp.exp,
        "ln":      mp.log,
        "inv":     lambda x: mp.mpf(1) / x,
        "half":    lambda x: x / 2,
        "minus":   lambda x: -x,
        "sqr":     lambda x: x * x,
        "sqrt":    mp.sqrt,
        "sigma":   lambda x: 1 / (1 + mp.exp(-x)),
        "sin":     mp.sin,
        "cos":     mp.cos,
        "tan":     mp.tan,
        "arcsin":  mp.asin,
        "arccos":  mp.acos,
        "arctan":  mp.atan,
        "sinh":    mp.sinh,
        "cosh":    mp.cosh,
        "tanh":    mp.tanh,
        "arsinh":  mp.asinh,
        "arcosh":  mp.acosh,
        "artanh":  mp.atanh,
        # binaries
        "add":     lambda a, b: a + b,
        "sub":     lambda a, b: a - b,
        "mul":     lambda a, b: a * b,
        "div":     lambda a, b: a / b,
        "log":     lambda a, b: mp.log(b) / mp.log(a),
        "pow":     lambda a, b: a ** b,
        "avg":     lambda a, b: (a + b) / 2,
        "hypot":   lambda a, b: mp.sqrt(a * a + b * b),
    }


# ---------------------------------------------------------------------------
# Witnesses


# Algebraically independent transcendentals (paper uses γ and A).
WITNESSES = {
    "x": mp.euler,             # γ ≃ 0.5772156649...
    "y": mp.glaisher,          # A ≃ 1.282427129...
    "z": mp.khinchin,          # K ≃ 2.685452001...
}


def _eval_at(target_fn: Callable, vars: Sequence[str], dps: int):
    """Evaluate the reference target at the witness, using mpmath.

    Returns an ``mpc`` for full precision (don't truncate to complex).
    """
    old = mp.mp.dps
    mp.mp.dps = dps
    try:
        args = tuple(mp.mpc(WITNESSES[v]) for v in vars)
        return mp.mpc(target_fn(*args))
    finally:
        mp.mp.dps = old


def _eval_tree(tree: Node, vars: Sequence[str], dps: int):
    """Evaluate an EML tree numerically at the witness, mpmath backend."""
    from .core import eml_mp
    old = mp.mp.dps
    mp.mp.dps = dps
    try:
        env = {v: mp.mpc(WITNESSES[v]) for v in vars}
        v = tree.evaluate(env, op=eml_mp, one=mp.mpc(1))
        return mp.mpc(v)
    finally:
        mp.mp.dps = old


# ---------------------------------------------------------------------------
# Public checks


@dataclass
class VerificationResult:
    name: str
    passed: bool
    abs_err: float
    K: int
    detail: str = ""


def numeric_witness(tree: Node, target: Callable, vars: Sequence[str] = (),
                    *, dps: int = 50, tol: float = 1e-25) -> VerificationResult:
    """Check ``tree`` against ``target`` at a transcendental witness.

    Returns a :class:`VerificationResult`.
    """
    eml_val = _eval_tree(tree, vars, dps)
    ref_val = _eval_at(target, vars, dps)
    err = float(abs(eml_val - ref_val))
    rel_scale = float(max(mp.mpf(1), abs(ref_val)))
    return VerificationResult(
        name=getattr(target, "__name__", str(target)),
        passed=err < tol * rel_scale,
        abs_err=err,
        K=tree.rpn_length(),
        detail=f"eml={eml_val!r} ref={ref_val!r}",
    )


def symbolic_check(tree: Node, expected_sympy) -> bool:
    """Best-effort sympy-level check that ``tree`` simplifies to
    ``expected_sympy``.  Returns True if the simplified difference is 0.
    """
    import sympy as sp
    from .tree import to_sympy

    e = sp.simplify(sp.logcombine(sp.expand_log(to_sympy(tree), force=True), force=True))
    diff = sp.simplify(e - sp.sympify(expected_sympy))
    return diff == 0


# ---------------------------------------------------------------------------
# Driver: verify the entire library


def verify_library(*, dps: int = 30, tol: float = 1e-25) -> list[VerificationResult]:
    """Run :func:`numeric_witness` over every primitive in
    :mod:`eml.library`.

    The default precision (30 decimal digits) is enough to comfortably
    distinguish elementary constants from their transcendental neighbours
    while keeping the run-time of the whole sweep below a second.
    """
    results: list[VerificationResult] = []
    refs = _mp_ref()

    # constants
    for c in CONSTANTS:
        tree = build_constant(c)
        ref = refs[c]
        ref_named = (lambda r=ref, n=c: r())
        ref_named.__name__ = c
        r = numeric_witness(tree, ref_named, vars=(), dps=dps, tol=tol)
        results.append(r)

    # unaries
    for u in UNARY:
        tree = build_unary(u, "x")
        ref = refs[u]
        named = (lambda r=ref, n=u: r(*((),)[0]) if False else r)  # passthrough
        wrapper = (lambda *a, _r=ref: _r(*a))
        wrapper.__name__ = u
        r = numeric_witness(tree, wrapper, vars=("x",), dps=dps, tol=tol)
        results.append(r)

    # binaries
    for b in BINARY:
        tree = build_binary(b, "x", "y")
        ref = refs[b]
        wrapper = (lambda *a, _r=ref: _r(*a))
        wrapper.__name__ = b
        r = numeric_witness(tree, wrapper, vars=("x", "y"), dps=dps, tol=tol)
        results.append(r)

    return results


def print_verification_report(results: list[VerificationResult]) -> None:
    print(f"{'name':<10s} {'K':>5s}  {'passed':>7s}  {'abs_err':>14s}")
    print("-" * 50)
    for r in results:
        ok = "ok" if r.passed else "FAIL"
        print(f"{r.name:<10s} {r.K:>5d}  {ok:>7s}  {r.abs_err:>14.3e}")
    n_pass = sum(r.passed for r in results)
    print(f"\n{n_pass}/{len(results)} passed")


__all__ = [
    "VerificationResult",
    "numeric_witness",
    "symbolic_check",
    "verify_library",
    "print_verification_report",
    "WITNESSES",
]
