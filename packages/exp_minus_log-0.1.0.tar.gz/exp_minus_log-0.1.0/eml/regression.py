"""EML *master formula* and gradient-based symbolic regression.

The paper proposes (§4.3) a "master formula" that is a fully-parametrised
EML binary tree whose every input slot is the simplex combination

    α + β·x + γ·f                           (Eq. 6)

where ``f`` is the value piped up from the next-level subtree.  Setting
``(α, β, γ)`` to one of the three vertices ``(1,0,0)``, ``(0,1,0)``,
``(0,0,1)`` recovers the three legal leaf semantics ``1``, ``x`` and
"propagate-up".  The total parameter count for a level-n master formula
is ``5·2^n - 6`` (γ is dropped at the leaves of the tree).

This module implements the master formula, its evaluation, a numerical
gradient via finite differences (no torch dependency), and a snap-to-
vertex hardening step that recovers exact symbolic expressions in the
basin of an elementary function.

The training loop closely follows the protocol in §4.3:

1. parameterise the tree with simplex weights (softmax of logits);
2. Adam-style optimisation of the MSE against the target data;
3. hardening phase pushing weights toward 0 or 1;
4. snap to vertices and rebuild the recovered :class:`~eml.tree.Node`.

This is purely numpy / scipy — no torch — so it runs anywhere.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Mapping

import numpy as np

from .tree import Eml, Node, ONE, Var
from .core import eml as eml_np


# ---------------------------------------------------------------------------
# Master-formula evaluation


def n_params(level: int) -> int:
    """Number of parameters in the level-n master formula: 5·2^n − 6."""
    if level < 1:
        raise ValueError("level must be >= 1")
    return 5 * (2 ** level) - 6


def _softmax(z: np.ndarray, axis: int = -1) -> np.ndarray:
    z = z - z.max(axis=axis, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=axis, keepdims=True)


@dataclass
class MasterFormula:
    """A level-``n`` EML master formula.

    Internally the parameters are stored as logits in a single flat
    ``np.ndarray``; the simplex weights are obtained by per-input
    softmax. This keeps the optimisation unconstrained.

    Attributes
    ----------
    level : int
        Tree depth (1 means a single eml node with two leaves).
    logits : ndarray, shape (P, k) where k=2 for leaves, k=3 for internals
        Parameter logits.  The dataclass keeps it as an *object* array of
        small arrays so that leaves and internals can have different
        widths; in practice we use a flat (P,) view for optimisation.
    """
    level: int
    logits: list[np.ndarray]   # one (k,) array per slot

    @classmethod
    def random(cls, level: int, *, scale: float = 0.1, rng: np.random.Generator | None = None) -> "MasterFormula":
        rng = rng or np.random.default_rng()
        # We need to enumerate slots in tree order. We store them in
        # pre-order, with leaves having k=2 weights (1 vs x) and internals
        # having k=3 weights (1 vs x vs f). 'f' is forbidden at leaves.
        slots = _slot_widths(level)
        logits = [rng.standard_normal(k) * scale for k in slots]
        return cls(level=level, logits=logits)

    def flatten(self) -> np.ndarray:
        return np.concatenate(self.logits)

    def set_flat(self, vec: np.ndarray) -> None:
        i = 0
        for j, l in enumerate(self.logits):
            k = l.size
            self.logits[j] = vec[i:i + k].astype(np.float64)
            i += k

    # ----- evaluation -------------------------------------------------
    def __call__(self, x: np.ndarray | float) -> np.ndarray | float:
        return self.evaluate(x)

    def evaluate(self, x: np.ndarray | float) -> np.ndarray | float:
        slots = _slot_widths(self.level)
        # softmax weights per slot
        weights = [_softmax(l) for l in self.logits]
        # post-order eval; we walk the tree following the linear slot order
        return _eval_master(self.level, list(weights), x)

    def loss(self, x: np.ndarray, y: np.ndarray) -> float:
        z = self.evaluate(x)
        # complex-safe MSE: use abs-squared so we work in C
        z = np.asarray(z)
        diff = z - y
        return float(np.mean(np.abs(diff) ** 2).real)

    # ----- gradient ---------------------------------------------------
    def grad_fd(self, x: np.ndarray, y: np.ndarray, *, eps: float = 1e-5) -> np.ndarray:
        """Finite-difference gradient of the MSE wrt the flat logits."""
        v = self.flatten()
        g = np.zeros_like(v)
        base = self.loss(x, y)
        for i in range(v.size):
            v[i] += eps
            self.set_flat(v)
            plus = self.loss(x, y)
            v[i] -= 2 * eps
            self.set_flat(v)
            minus = self.loss(x, y)
            v[i] += eps
            g[i] = (plus - minus) / (2 * eps)
        self.set_flat(v)
        return g

    # ----- snap-to-vertex hardening ----------------------------------
    def snap(self) -> Node | None:
        """Project the simplex weights to their nearest vertex and rebuild
        a discrete EML tree.

        Returns ``None`` if any internal slot picked the disallowed
        ``'f'`` vertex at a leaf.
        """
        slots = _slot_widths(self.level)
        weights = [_softmax(l) for l in self.logits]
        vertices = [int(np.argmax(w)) for w in weights]
        try:
            tree, _ = _build_from_vertices(self.level, list(vertices))
        except _BadSnap:
            return None
        return tree


# ---------------------------------------------------------------------------
# Tree-shape utilities

# slot order: pre-order traversal, with each EML node contributing two
# input slots (its two children); the root has no incoming γ component.
# Because every input slot is a leaf {1,x} or an internal eml(...) whose
# output is f, we represent slots as either:
#   - LEAF slot (k=2 weights: [α, β]), or
#   - INTERNAL slot (k=3 weights: [α, β, γ]),
# where α is the coefficient of "1", β of x, γ of "f" (the eml subtree).


def _slot_widths(level: int) -> list[int]:
    """Return the sequence of softmax widths for level-n master formula."""
    if level == 1:
        # single eml(left_leaf, right_leaf): two leaves only
        return [2, 2]
    # at level n: two inputs to root eml; each input is either a leaf
    # (giving width 2) or a level-(n-1) subtree (whose result is the f
    # propagated upward).  In the master formula we *always* allow the
    # f path, so the input is a 3-way mixture: [1, x, f].
    out = [3]   # left input mixture weights
    out += _slot_widths_internal(level - 1)
    out += [3]  # right input mixture weights
    out += _slot_widths_internal(level - 1)
    return out


def _slot_widths_internal(level: int) -> list[int]:
    """Recursive helper: slot widths inside a sub-formula."""
    if level == 1:
        # internal eml at the deepest level: its two inputs are 3-way
        # mixtures whose 'f' fallback is itself a leaf-level mixture.
        # But since we're at the bottom of the tree, the 'f' path is
        # really another sub-tree of depth 0 (just a leaf), so we treat
        # the inputs as leaves with width 2.
        return [2, 2]
    out = [3]
    out += _slot_widths_internal(level - 1)
    out += [3]
    out += _slot_widths_internal(level - 1)
    return out


def _eval_master(level: int, weights: list[np.ndarray], x):
    """Evaluate by recursively consuming ``weights`` (mutated)."""
    return _eval_node(level, weights, x)


def _eval_node(level: int, weights: list[np.ndarray], x):
    if level == 0:
        # bare leaf — just one slot of width 2
        w = weights.pop(0)
        return w[0] * 1 + w[1] * x
    # left input
    left = _eval_input(level, weights, x)
    right = _eval_input(level, weights, x)
    return eml_np(left, right)


def _eval_input(level: int, weights: list[np.ndarray], x):
    """Evaluate an input slot to its eml's parent."""
    if level == 1:
        # leaf input: width-2 mixture {1, x}
        w = weights.pop(0)
        return w[0] * 1 + w[1] * x
    # internal input: width-3 mixture {1, x, f} where f is the recursive
    # eml subtree at level-1.
    w = weights.pop(0)
    f = _eval_node(level - 1, weights, x)
    return w[0] * 1 + w[1] * x + w[2] * f


class _BadSnap(Exception):
    pass


def _build_from_vertices(level: int, verts: list[int]) -> tuple[Node, list[int]]:
    """Reconstruct the discrete EML tree from a list of vertex picks."""
    if level == 0:
        v = verts.pop(0)
        return (ONE if v == 0 else Var("x")), verts
    left, verts = _build_input(level, verts)
    right, verts = _build_input(level, verts)
    return Eml(left, right), verts


def _build_input(level: int, verts: list[int]) -> tuple[Node, list[int]]:
    if level == 1:
        v = verts.pop(0)
        return (ONE if v == 0 else Var("x")), verts
    v = verts.pop(0)
    if v == 0:
        # consume the f-subtree's vertex picks but discard them
        _, verts = _build_node(level - 1, verts)
        return ONE, verts
    if v == 1:
        _, verts = _build_node(level - 1, verts)
        return Var("x"), verts
    # v == 2: take the f path
    return _build_node(level - 1, verts)


def _build_node(level: int, verts: list[int]) -> tuple[Node, list[int]]:
    if level == 0:
        v = verts.pop(0)
        return (ONE if v == 0 else Var("x")), verts
    left, verts = _build_input(level, verts)
    right, verts = _build_input(level, verts)
    return Eml(left, right), verts


# ---------------------------------------------------------------------------
# Adam optimiser (numpy)


def adam_train(
    formula: MasterFormula,
    x: np.ndarray,
    y: np.ndarray,
    *,
    lr: float = 0.05,
    iters: int = 2000,
    harden_every: int | None = None,
    harden_strength: float = 0.0,
    eps: float = 1e-5,
    callback: Callable | None = None,
) -> dict:
    """Train ``formula`` to fit ``y = formula(x)`` using Adam + FD gradients."""
    v = formula.flatten()
    m = np.zeros_like(v)
    s = np.zeros_like(v)
    b1, b2 = 0.9, 0.999
    history = []
    for t in range(1, iters + 1):
        g = formula.grad_fd(x, y, eps=eps)
        # add hardening pull toward {-3, +3} logits depending on sign
        if harden_strength:
            g = g + harden_strength * np.tanh(v) * (-1)  # pull away from 0
        m = b1 * m + (1 - b1) * g
        s = b2 * s + (1 - b2) * g * g
        m_hat = m / (1 - b1 ** t)
        s_hat = s / (1 - b2 ** t)
        v = v - lr * m_hat / (np.sqrt(s_hat) + 1e-8)
        formula.set_flat(v)
        if t % 100 == 0 or t == 1:
            loss = formula.loss(x, y)
            history.append((t, loss))
            if callback:
                callback(t, loss, formula)
    return {"history": history, "final_loss": formula.loss(x, y)}


__all__ = [
    "MasterFormula", "n_params", "adam_train",
]
