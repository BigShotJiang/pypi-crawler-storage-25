"""Brute-force shortest-EML search (the *Direct search* column of Table 4).

The verification methodology of the paper is a numeric witness:

* substitute each free variable with an algebraically-independent
  transcendental constant (paper uses Euler-Mascheroni γ and
  Glaisher-Kinkelin A);
* evaluate every candidate EML tree numerically;
* under Schanuel's conjecture, two distinct elementary expressions
  cannot agree at such a point, so a numerical match is overwhelming
  evidence for symbolic equality.

Translated into Python::

    >>> from eml.search import shortest
    >>> shortest(target=lambda x: -x, max_K=15, vars=("x",), value=0.5772156649)
    Eml(left=One(), right=Eml(left=Eml(left=One(), right=Var(name='x')), right=One()))

The search enumerates *full binary trees with N leaves* in increasing
order of K = 2N - 1 = 1, 3, 5, ...  For each tree it tries every leaf
labelling drawn from ``{1} ∪ vars`` and evaluates it.  We dedupe on
numerical value (with a tolerance) so the inner loop stays compact even
at K = 11.

The number of full binary trees with N leaves is the (N-1)-st Catalan
number; combined with leaf labelling we have
``C_{N-1} * (1+|vars|)^N`` candidates per K, which is tractable up to
about K = 13 in pure Python.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Callable, Iterator, Sequence

import math

from .tree import Node, One, Var, Eml, ONE


# ---------------------------------------------------------------------------
# Catalan-style enumeration of *tree shapes*


@lru_cache(maxsize=None)
def _shapes(n_leaves: int) -> tuple[tuple, ...]:
    """All full-binary-tree shapes with ``n_leaves`` leaves.

    Each shape is encoded as a tuple ``("L",)`` for a leaf, or
    ``("E", left, right)`` for an internal node — using strings to keep
    the cache hashable.
    """
    if n_leaves == 1:
        return (("L",),)
    out: list = []
    for k in range(1, n_leaves):
        left_shapes = _shapes(k)
        right_shapes = _shapes(n_leaves - k)
        for L in left_shapes:
            for R in right_shapes:
                out.append(("E", L, R))
    return tuple(out)


def _instantiate(shape, leaves: list[Node]) -> tuple[Node, list[Node]]:
    """Substitute the next leaves into a shape, returning the resulting
    :class:`Node` and the remainder of ``leaves``."""
    if shape[0] == "L":
        return leaves[0], leaves[1:]
    L, leaves2 = _instantiate(shape[1], leaves)
    R, leaves3 = _instantiate(shape[2], leaves2)
    return Eml(L, R), leaves3


def _enumerate_trees(n_leaves: int, leaf_pool: Sequence[Node]) -> Iterator[Node]:
    """Yield every full-binary-tree of size ``n_leaves`` whose leaves come
    from ``leaf_pool``."""
    shapes = _shapes(n_leaves)
    L = len(leaf_pool)
    for shape in shapes:
        # iterate over n_leaves-tuples of leaf indices
        for mask in range(L ** n_leaves):
            leaves: list[Node] = []
            m = mask
            for _ in range(n_leaves):
                leaves.append(leaf_pool[m % L])
                m //= L
            tree, rest = _instantiate(shape, leaves)
            assert not rest
            yield tree


# ---------------------------------------------------------------------------
# Numerical witness comparison


def _safe_eval(tree: Node, env: dict) -> complex | None:
    try:
        v = tree.evaluate(env)
        return complex(v)
    except (OverflowError, ValueError, ZeroDivisionError, FloatingPointError):
        return None


def shortest(
    target: complex | Callable,
    *,
    max_K: int = 15,
    vars: Sequence[str] = (),
    value: float | complex | None = None,
    tol: float = 1e-9,
    progress: bool = False,
) -> Node | None:
    """Brute-force search for the shortest EML tree matching ``target``.

    Parameters
    ----------
    target : complex or callable
        Either the constant we want to reproduce, or a callable
        ``f(*xs)`` taking ``len(vars)`` floats.  In the latter case we
        evaluate ``f`` at the witness point ``value`` (or at default
        transcendental witnesses if ``value`` is ``None``).
    max_K : int
        Maximum RPN length to consider.  The search stops as soon as it
        finds *any* witness; expect runtime ~ Catalan(K/2) * (1+|vars|)^K.
    vars : sequence of str
        Names of the free variables.  Each is bound to a transcendental
        witness (γ, A, or values of ``value``) for the numeric check.
    value : float, complex, or tuple, optional
        Witness value(s) for the variable(s).  Defaults to (γ, A, ...).
    tol : float
        Numerical equality tolerance.
    progress : bool
        Print one line per K.

    Returns
    -------
    Node or None
        Shortest EML tree whose evaluation matches the target at the
        chosen witness, or ``None`` if no match within ``max_K``.
    """
    # --- canonical witnesses (algebraically independent transcendentals) ---
    # γ ≃ 0.577216 (Euler-Mascheroni) and A ≃ 1.282427 (Glaisher-Kinkelin)
    # are the same pair the paper uses for VerifyBaseSet.
    witnesses = (0.5772156649015329, 1.282427129100623, 1.4596100345414635)
    if value is not None:
        if isinstance(value, (tuple, list)):
            witness_vals = tuple(value)
        else:
            witness_vals = (value,)
    else:
        witness_vals = witnesses[: len(vars)]

    env = dict(zip(vars, witness_vals))

    if callable(target):
        target_val = complex(target(*witness_vals))
    else:
        target_val = complex(target)

    leaf_pool: list[Node] = [ONE] + [Var(name) for name in vars]

    # K = 2N - 1, so iterate N = 1, 2, 3, ...
    n_max = (max_K + 1) // 2
    for n_leaves in range(1, n_max + 1):
        K = 2 * n_leaves - 1
        if progress:
            n_shapes = len(_shapes(n_leaves))
            n_cands = n_shapes * (len(leaf_pool) ** n_leaves)
            print(f"  K = {K:3d}  ({n_cands} candidates)")
        for tree in _enumerate_trees(n_leaves, leaf_pool):
            v = _safe_eval(tree, env)
            if v is None:
                continue
            if abs(v - target_val) < tol * max(1.0, abs(target_val)):
                return tree
    return None


def search_constant(value: complex, *, max_K: int = 15, **kw) -> Node | None:
    """Convenience: search for an EML tree of a constant value."""
    return shortest(value, vars=(), max_K=max_K, **kw)


def search_function(fn: Callable, *, vars: Sequence[str] = ("x",),
                     max_K: int = 11, **kw) -> Node | None:
    """Convenience: search for an EML tree representing a univariate or
    bivariate function."""
    return shortest(fn, vars=vars, max_K=max_K, **kw)


__all__ = ["shortest", "search_constant", "search_function"]
