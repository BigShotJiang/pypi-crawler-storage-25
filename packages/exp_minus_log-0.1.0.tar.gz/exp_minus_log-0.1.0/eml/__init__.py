"""eml — a single-operator implementation of all elementary functions.

The package implements the EML (Exp-Minus-Log) operator from
A. Odrzywolek, *All elementary functions from a single operator*,
arXiv:2603.21852, together with its companion infrastructure:
expression trees, an RPN compiler, a single-instruction stack VM, a
sympy custom function, gradient-based symbolic regression, exhaustive
search for shortest chains, visualisation, and a verification suite.

Two-line crash course::

    >>> from eml import eml, parse_rpn
    >>> parse_rpn("11xE1EE")(x=7.5)        # ln(7.5)
    2.0149030205422647
    >>> eml(1, 1)                          # the constant e
    2.718281828459045
"""

from .core import eml, edl, neml, eml_mp, evalf, fix_i_sign
from .tree import (
    Node, One, Var, Eml, ONE, V, E,
    parse_rpn, to_rpn, to_sympy,
    LN_RPN, EXP_RPN, E_RPN, ZERO_RPN,
)
from .library import (
    build_constant, build_unary, build_binary, reference,
    CONSTANTS, UNARY, BINARY, ALL_NAMES,
)

__version__ = "0.1.0"

__all__ = [
    "eml", "edl", "neml", "eml_mp", "evalf", "fix_i_sign",
    "Node", "One", "Var", "Eml", "ONE", "V", "E",
    "parse_rpn", "to_rpn", "to_sympy",
    "LN_RPN", "EXP_RPN", "E_RPN", "ZERO_RPN",
    "build_constant", "build_unary", "build_binary", "reference",
    "CONSTANTS", "UNARY", "BINARY", "ALL_NAMES",
]
