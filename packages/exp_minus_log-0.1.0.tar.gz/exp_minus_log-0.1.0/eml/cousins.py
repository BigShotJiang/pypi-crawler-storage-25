"""The two cousin operators identified in the paper.

Eq. (4) of arXiv:2603.21852 lists three Sheffer-style operators::

    eml(x, y) = exp(x) - ln(y)        with constant 1     (Eq. 4a)
    edl(x, y) = exp(x) / ln(y)        with constant e     (Eq. 4b)
    -eml(y, x)= ln(x) - exp(y)        with constant -inf  (Eq. 4c)

The numerical core is in :mod:`eml.core`; this module repeats the
expression-tree machinery so the cousins enjoy the same toolchain
(VM, sympy, search, regression).

Each cousin pairs with a different distinguished constant.  The
Boolean-logic analogue is that NAND (Sheffer stroke) and NOR (Peirce
arrow) are duals, generating the same logic family from different
distinguished bits.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Callable, Mapping

import numpy as np

from .core import edl as _edl_np, neml as _neml_np
from .tree import Node, One, Var, Eml as TreeEml


# ---------------------------------------------------------------------------
# EDL: exp(x) / ln(y), terminal constant = e


@dataclass(frozen=True)
class EConst(Node):
    """The constant ``e`` as a leaf of an EDL tree."""

    __slots__ = ()

    def _eval(self, env, op, one):
        return one  # caller must supply 'one' = e for EDL

    def to_str(self) -> str:
        return "e"

    def _rpn(self, out):
        out.append("e")


# Convenience: the EDL "e" leaf and the EML "1" leaf are interchangeable
# in the API.  We just make a separate concrete class so that
# Eml-tree-printing distinguishes 1 from e visually.

EDL_E = EConst()


def edl_evaluate(node: Node, env: Mapping[str, Any] | None = None) -> Any:
    """Evaluate ``node`` interpreting every leaf '1'/'e' as the constant
    *e* and every internal eml as the EDL operator."""
    return node.evaluate(env, op=_edl_np, one=math.e)


def edl_exp(t: Node) -> Node:
    """``exp(t) = edl(t, e)``  (since ``ln e = 1``)."""
    return TreeEml(t, EDL_E)


def edl_e_const() -> Node:
    return EDL_E


def edl_ln(t: Node) -> Node:
    """``ln(t) = e / edl(e, t)`` — but `/` is not a primitive, so this is
    not directly trivial.  The simplest correct EDL chain is

        ln(t) = ln(e) * (e / edl(e, t))

    which after EDL simplifications collapses to ``ln(t)``.
    Concretely: ``edl(e, t) = e^e / ln(t)``, so
    ``edl(e, edl(e, t)) = exp(e)/ln(e^e/ln t) = exp(e) / (e - ln ln t)``,
    which is not ``ln t``.  Closing the EDL chain for ``ln`` requires more
    work.  See :mod:`eml.search` for a brute-force search over EDL trees.
    """
    raise NotImplementedError(
        "EDL chain for ln(t) requires brute-force search; see eml.search"
    )


# ---------------------------------------------------------------------------
# -EML (negative EML): ln(x) - exp(y), terminal constant = -inf


@dataclass(frozen=True)
class NegInfConst(Node):
    """The constant ``-inf`` as a leaf of a -EML tree."""

    __slots__ = ()

    def _eval(self, env, op, one):
        return one  # caller supplies one = -inf

    def to_str(self) -> str:
        return "-inf"

    def _rpn(self, out):
        out.append("-inf")


NEML_NEG_INF = NegInfConst()


def neml_evaluate(node: Node, env: Mapping[str, Any] | None = None) -> Any:
    """Evaluate using ``-eml(y, x) = ln(x) - exp(y)``."""
    return node.evaluate(env, op=_neml_np, one=-math.inf)


def neml_ln(t: Node) -> Node:
    """``ln(t) = -eml(t, -inf)``  (since exp(-inf) = 0)."""
    return TreeEml(t, NEML_NEG_INF)


def neml_exp(t: Node) -> Node:
    """``exp(t) = -eml(-inf, t)`` ?  Let's check::

        -eml(-inf, t) = ln(-inf) - exp(t) = +inf - exp(t)

    which is not exp(t).  The correct chain involves more depth; use
    :mod:`eml.search` to find shortest -EML chains for given primitives.
    """
    raise NotImplementedError(
        "-EML chain for exp(t) requires brute-force search; see eml.search"
    )


# ---------------------------------------------------------------------------
# Numeric verification of the cousins on a single witness


def verify_cousins(witness: float = 0.577215664901533) -> dict[str, bool]:
    """Sanity-check that each cousin reproduces simple identities.

    Returns a dict of identity-name -> bool result.
    """
    g = witness
    out = {}

    # EML core
    from .core import eml
    out["EML  exp(x) = eml(x, 1)"] = abs(eml(g, 1) - math.exp(g)) < 1e-12

    # EDL: e^e / ln(e^e) = e^e / e = e^(e-1)
    out["EDL  edl(e, e^e) = e^(e-1)"] = abs(
        _edl_np(math.e, math.exp(math.e)) - math.exp(math.e - 1)
    ) < 1e-12

    # -EML: ln(t) = -eml(t, -inf)
    out["-EML ln(t) = -eml(t, -inf)"] = abs(
        _neml_np(g, -math.inf) - math.log(g)
    ) < 1e-12

    return out


__all__ = [
    "EConst", "NegInfConst", "EDL_E", "NEML_NEG_INF",
    "edl_evaluate", "edl_exp", "edl_e_const",
    "neml_evaluate", "neml_ln",
    "verify_cousins",
]
