"""Core EML operator and its cousins.

EML — Exp-Minus-Log — is the binary operator

    eml(x, y) = exp(x) - ln(y)

introduced by A. Odrzywolek (arXiv:2603.21852). Together with the constant
``1`` it generates every elementary function over the complex plane.

This module provides three numerically-faithful implementations:

* :func:`eml`        — scalar / NumPy ufunc-style (vectorised, broadcasts)
* :func:`eml_mp`     — mpmath arbitrary-precision
* :func:`eml_sym`    — symbolic (returns a sympy Expr without evaluation)

It also exposes the two cousin operators identified in the same paper:

* :func:`edl`  — exp(x) / ln(y),  paired with constant ``e``
* :func:`neml` — ln(x) - exp(y),  paired with constant ``-inf``

All operators use the principal branch of the complex logarithm, matching
NumPy / IEEE-754 behaviour, so chains of EML reproduce
``numpy``/``cmath``/``mpmath`` answers bit-identically inside the analytic
domain. A separate branch-correction helper is provided for the ``i``-sign
issue discussed in §4.1 of the paper.
"""

from __future__ import annotations

from typing import Any

import numpy as np

# -- principal-branch primitives over the complex plane ---------------------
#
# We always promote to complex internally because EML chains naturally
# generate ``ln(-1)``, ``ln(0)`` etc. on the way to constructing real
# constants such as ``i`` and ``pi``. The dispatch logic returns a real
# array if every leaf was real *and* the imaginary part of the answer is
# numerically zero, mirroring NumPy's own complex/real promotion rules.


def _to_complex(x: Any) -> np.ndarray:
    """Promote ``x`` to ``complex128`` (preserving array shape)."""
    return np.asarray(x, dtype=np.complex128)


def eml(x: Any, y: Any, *, branch: str = "principal") -> np.ndarray | complex:
    """Evaluate ``eml(x, y) = exp(x) - ln(y)`` on the complex plane.

    Parameters
    ----------
    x, y : array_like
        Inputs, broadcastable. Integer / float / complex / NumPy arrays
        are all accepted; the result is complex-valued unless
        ``branch="principal"`` is used and the imaginary parts vanish to
        within ``1e-12`` of machine epsilon, in which case it is cast back
        to the corresponding real dtype to match NumPy conventions.
    branch : {"principal", "upper"}
        Choice of complex branch for ``ln(y)``. ``"principal"`` follows
        NumPy / IEEE-754 (branch cut along the negative real axis,
        ``ln(-1) = i*pi``). ``"upper"`` picks the upper-half-plane branch
        (``ln(-1) = i*pi`` as well, but the limit is taken from above) —
        used by some EML chains to keep the ``i``-sign consistent through
        composed expressions, see :func:`fix_i_sign`.

    Returns
    -------
    out : ndarray or scalar
        ``exp(x) - ln(y)``, with the same broadcasted shape as ``x, y``.

    Notes
    -----
    The operator is non-commutative: ``eml(x, y) != eml(y, x)`` in general.
    The first slot is the *exp* slot, the second is the *log* slot — this
    matches the OpAmp-style chirality drawn in Table 3 of the paper.
    """
    cx = _to_complex(x)
    cy = _to_complex(y)
    if branch == "principal":
        # silence the IEEE-754 'divide by zero' that ln(0) = -inf legitimately
        # raises (the EML chain for `0` routes through this on purpose).
        with np.errstate(divide="ignore", invalid="ignore"):
            out = np.exp(cx) - np.log(cy)
    elif branch == "upper":
        # Force argument into the half-open upper interval (-pi, pi]; for
        # negative real y, push it onto the upper bank of the cut.
        with np.errstate(divide="ignore", invalid="ignore"):
            ly = np.log(cy)
        # When y is exactly on the negative real axis, NumPy returns
        # imaginary part exactly +pi (principal). The upper-bank
        # convention agrees there, so this is mostly a no-op in
        # double precision; we keep the branch for documentary symmetry.
        out = np.exp(cx) - ly
    else:
        raise ValueError(f"unknown branch={branch!r}")

    # Demote to real when both inputs were real *and* the imaginary part
    # is numerical noise. This matches NumPy's behaviour for log() on a
    # positive real array.
    real_inputs = (
        np.isrealobj(np.asarray(x)) and np.isrealobj(np.asarray(y))
    )
    if real_inputs:
        ix = np.asarray(x).real
        iy = np.asarray(y).real
        if np.all(iy > 0):  # ln stays real
            return (np.exp(ix) - np.log(iy)).astype(np.float64)

    # Strip a vanishing imaginary part if one survived.
    if np.all(np.abs(out.imag) < 1e-12 * (1 + np.abs(out.real))):
        if np.iscomplexobj(np.asarray(x)) or np.iscomplexobj(np.asarray(y)):
            return out
        return out.real
    if out.shape == ():
        return complex(out)
    return out


def edl(x: Any, y: Any) -> np.ndarray | complex:
    """Cousin operator ``edl(x, y) = exp(x) / ln(y)`` (constant *e*)."""
    cx = _to_complex(x)
    cy = _to_complex(y)
    out = np.exp(cx) / np.log(cy)
    if out.shape == ():
        return complex(out)
    return out


def neml(x: Any, y: Any) -> np.ndarray | complex:
    """Cousin operator ``-eml(y, x) = ln(x) - exp(y)`` (constant ``-inf``)."""
    cx = _to_complex(x)
    cy = _to_complex(y)
    out = np.log(cx) - np.exp(cy)
    if out.shape == ():
        return complex(out)
    return out


# -- mpmath arbitrary-precision version -------------------------------------


def eml_mp(x, y, dps: int | None = None):
    """Arbitrary-precision EML using mpmath.

    Parameters
    ----------
    x, y : mpc / mpf / int / float / complex
    dps : int, optional
        Decimal precision; uses current ``mp.dps`` if ``None``.
    """
    import mpmath as mp

    ctx = mp.mp
    old = ctx.dps
    try:
        if dps is not None:
            ctx.dps = dps
        cx = mp.mpc(x)
        cy = mp.mpc(y)
        return mp.exp(cx) - mp.log(cy)
    finally:
        ctx.dps = old


# -- branch repair ----------------------------------------------------------


def evalf(node, env: dict | None = None, *, dps: int = 30, real: bool = False):
    """Evaluate an EML expression tree at high mpmath precision, then
    round once to ``complex128`` (or ``float64`` if ``real=True``).

    This eats the ULP-scale error that EML chains accumulate when run
    natively in IEEE-754 — a chain of depth *d* using numpy will lose
    roughly ``log2(d)`` bits to rounding, while the same chain evaluated
    at ``dps=30`` and rounded once at the end is correctly-rounded to
    ``complex128`` for any chain that fits in ``dps`` digits.

    Parameters
    ----------
    node : :class:`eml.tree.Node`
    env : mapping
        Free-variable bindings. Values are promoted to mpmath ``mpc``.
    dps : int, optional
        Working precision in decimal digits (default 30 — about
        100-bit mantissa, comfortably more than ``complex128``'s 53).
    real : bool
        Force the result to ``float64`` (drop the imaginary part — only
        do this when you know the answer is real).

    Examples
    --------
    >>> import math
    >>> from eml.library import build_constant
    >>> from eml.core import evalf
    >>> evalf(build_constant("pi"), real=True) == math.pi
    True
    """
    import mpmath as mp

    env = env or {}
    old_dps = mp.mp.dps
    mp.mp.dps = dps
    try:
        mp_env = {k: mp.mpc(v) for k, v in env.items()}
        v = node.evaluate(mp_env, op=eml_mp, one=mp.mpc(1))
    finally:
        mp.mp.dps = old_dps
    z = complex(mp.mpc(v))
    if real:
        return z.real
    return z


def fix_i_sign(z: complex | np.ndarray, target: complex | np.ndarray = 1j) -> complex | np.ndarray:
    """Flip the imaginary sign of ``z`` if it disagrees with ``target``.

    The EML chain for ``i`` is ``i = -ln(-1)/pi * something`` and several
    sub-chains pick up the wrong half-plane because ``log(1/(-1)) =
    log(-1) = i*pi`` rather than ``-i*pi``. Section 4.1 of the paper notes
    that the prototype EML compiler "manually corrects the i sign"; this
    helper does exactly that.
    """
    z = np.asarray(z, dtype=np.complex128)
    same_sign = np.sign(z.imag) == np.sign(np.asarray(target).imag)
    out = np.where(same_sign, z, np.conj(z))
    if out.shape == ():
        return complex(out)
    return out


# -- canonical identities (used as test vectors) ----------------------------

CANONICAL_IDENTITIES = {
    "exp(x)":  "x = anything;  eml(x, 1) == exp(x)",
    "e":       "eml(1, 1) == e",
    "ln(x)":   "eml(1, eml(eml(1, x), 1)) == ln(x)",
    "0":       "eml(1, eml(eml(1, 1), 1)) == 0",
}


__all__ = [
    "eml",
    "edl",
    "neml",
    "eml_mp",
    "evalf",
    "fix_i_sign",
    "CANONICAL_IDENTITIES",
]
