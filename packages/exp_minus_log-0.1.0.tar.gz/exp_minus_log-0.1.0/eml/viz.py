"""Visualisation helpers for EML circuits / binary trees.

Two output formats:

* :func:`render_ascii`  — a quick text-mode view (no deps)
* :func:`render_mpl`    — a matplotlib drawing mimicking the OpAmp/EML
  symbol from Table 3 of the paper (a circle with an arrow showing
  chirality and a dot marking the output).
"""

from __future__ import annotations

from typing import Any

from .tree import Eml, Node, One, Var


# ---------------------------------------------------------------------------
# ASCII tree


def render_ascii(node: Node, *, indent: str = "    ") -> str:
    """Pretty ASCII rendering of an EML tree, root at the top."""
    lines: list[str] = []

    def walk(n: Node, prefix: str, is_last: bool) -> None:
        connector = "└── " if is_last else "├── "
        if isinstance(n, One):
            lines.append(prefix + connector + "1")
        elif isinstance(n, Var):
            lines.append(prefix + connector + n.name)
        elif isinstance(n, Eml):
            lines.append(prefix + connector + "eml")
            child_prefix = prefix + ("    " if is_last else "│   ")
            walk(n.left, child_prefix, is_last=False)
            walk(n.right, child_prefix, is_last=True)
        else:
            lines.append(prefix + connector + repr(n))

    # render root without a connector
    if isinstance(node, One):
        return "1"
    if isinstance(node, Var):
        return node.name
    if isinstance(node, Eml):
        lines.append("eml")
        walk(node.left, "", is_last=False)
        walk(node.right, "", is_last=True)
        return "\n".join(lines)
    return repr(node)


# ---------------------------------------------------------------------------
# Matplotlib renderer


def _layout(node: Node) -> dict:
    """Compute (x, y) positions in a tidy left-to-right tree layout."""
    pos: dict[int, tuple[float, float]] = {}
    edges: list[tuple[int, int, str]] = []
    labels: dict[int, str] = {}
    types: dict[int, str] = {}
    leaf_y = [0]

    def walk(n: Node, depth: int, nid: list[int]):
        my = nid[0]
        nid[0] += 1
        if isinstance(n, (One, Var)):
            x = float(depth)
            y = float(leaf_y[0])
            leaf_y[0] += 1
            pos[my] = (x, y)
            labels[my] = "1" if isinstance(n, One) else n.name
            types[my] = "leaf"
            return my, (x, y)
        l_id, (lx, ly) = walk(n.left, depth + 1, nid)
        r_id, (rx, ry) = walk(n.right, depth + 1, nid)
        x = float(depth)
        y = (ly + ry) / 2.0
        pos[my] = (x, y)
        labels[my] = "eml"
        types[my] = "eml"
        edges.append((my, l_id, "exp"))
        edges.append((my, r_id, "log"))
        return my, (x, y)

    walk(node, 0, [0])
    return {"pos": pos, "labels": labels, "types": types, "edges": edges}


def render_mpl(
    node: Node,
    *,
    ax=None,
    title: str | None = None,
    show_legend: bool = True,
    node_radius: float | None = None,
    fontsize: float | None = None,
):
    """Draw an EML tree with matplotlib.  Returns the Matplotlib Axes.

    The drawing uses the OpAmp-style symbol from Table 3 of the paper:
    a circle for each EML node with a small dot marking the output, and
    differently-coloured arrows for the *exp* and *log* input slots.
    """
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyArrowPatch, Circle

    layout = _layout(node)
    pos = layout["pos"]
    labels = layout["labels"]
    types = layout["types"]
    edges = layout["edges"]

    n_leaves = sum(1 for k in types if types[k] == "leaf")
    max_x = max(p[0] for p in pos.values()) if pos else 0
    depth = max_x + 1

    # auto-scale fonts and node sizes to the tree's geometry so big
    # trees don't visually overlap.
    if node_radius is None:
        node_radius = max(0.07, min(0.20, 1.5 / max(n_leaves, depth + 1)))
    if fontsize is None:
        # leaves carry text; size them so labels fit inside the circles
        fontsize = max(5, min(11, 7 * node_radius / 0.18))

    if ax is None:
        # 1 unit of leaf-spacing ~ 0.55", 1 unit of depth ~ 0.65"
        figw = 0.8 + 0.65 * (depth + 1)
        figh = 0.6 + 0.55 * max(n_leaves, 2)
        fig, ax = plt.subplots(figsize=(figw, figh))

    # invert x so root sits on the right
    pos_flip = {nid: (max_x - x, y) for nid, (x, y) in pos.items()}

    # edges
    for parent, child, kind in edges:
        x0, y0 = pos_flip[child]
        x1, y1 = pos_flip[parent]
        col = "tab:blue" if kind == "exp" else "tab:red"
        # shrink ratio in *points* — convert from data using the figure
        ax.add_patch(FancyArrowPatch(
            (x0, y0), (x1, y1),
            arrowstyle="-|>", mutation_scale=10,
            color=col, linewidth=1.2,
            shrinkA=node_radius * 80,    # rough px/data-unit scaling
            shrinkB=node_radius * 80,
        ))

    # nodes
    for nid, (x, y) in pos_flip.items():
        if types[nid] == "leaf":
            ax.add_patch(Circle((x, y), node_radius, facecolor="white",
                                  edgecolor="black", linewidth=1.0,
                                  zorder=5))
            ax.text(x, y, labels[nid], ha="center", va="center",
                    fontsize=fontsize, zorder=6)
        else:
            ax.add_patch(Circle((x, y), node_radius, facecolor="#fff7d4",
                                  edgecolor="black", linewidth=1.2,
                                  zorder=5))
            # output dot on the right side of the circle
            ax.scatter([x + node_radius], [y], s=10, color="black", zorder=7)

    # margins so labels and dots aren't clipped
    pad_x = node_radius * 1.5
    pad_y = node_radius * 1.5
    ax.set_xlim(-pad_x, max_x + pad_x + node_radius)
    ax.set_ylim(-1.0 if show_legend else -pad_y, n_leaves - 1 + pad_y)
    ax.set_aspect("equal")
    ax.axis("off")
    if title:
        ax.set_title(title, fontsize=max(9, fontsize + 1))

    if show_legend:
        # single non-overlapping legend below the drawing
        y_legend = -0.7
        x_left = 0.1
        ax.plot([x_left, x_left + 0.4], [y_legend, y_legend],
                color="tab:blue", linewidth=1.5)
        ax.text(x_left + 0.5, y_legend, "exp slot",
                color="tab:blue", fontsize=fontsize, va="center")
        x_right = max_x * 0.5 + 0.5
        ax.plot([x_right, x_right + 0.4], [y_legend, y_legend],
                color="tab:red", linewidth=1.5)
        ax.text(x_right + 0.5, y_legend, "log slot",
                color="tab:red", fontsize=fontsize, va="center")

    return ax


__all__ = ["render_ascii", "render_mpl"]
