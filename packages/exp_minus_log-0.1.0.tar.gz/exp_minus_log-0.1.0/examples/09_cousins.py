"""Demonstrate the two cousin operators identified in Eq. (4) of the
paper: EDL and -EML."""
import math

from eml.cousins import (
    edl_evaluate, EDL_E, edl_exp,
    neml_evaluate, NEML_NEG_INF, neml_ln, verify_cousins,
)
from eml.tree import V

print("Identity sanity-check:")
for name, ok in verify_cousins().items():
    print(f"  {'ok ' if ok else 'FAIL'}  {name}")

# EDL: exp via edl(x, e) = e^x / 1 = e^x
print("\nEDL  exp(e)  =", edl_evaluate(edl_exp(EDL_E)))
print("expected      =", math.exp(math.e))

# -EML: ln via -eml(x, -inf) = ln(x) - exp(-inf) = ln(x) - 0 = ln(x)
print("\n-EML ln(7.5) =", neml_evaluate(neml_ln(V("x")), {"x": 7.5}))
print("expected      =", math.log(7.5))
