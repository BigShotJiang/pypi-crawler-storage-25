"""Canonical identities of the EML operator (the `Hello, World!` of EML)."""
import math

from eml import eml, parse_rpn

# 1. Constants and the simplest function.
print(f"eml(1, 1) = {eml(1, 1)}        # the constant e ({math.e})")
print(f"eml(0, 1) = {eml(0, 1)}                          # exp(0) = 1")

# 2. The natural logarithm chain (Eq. (5) of the paper).
ln = parse_rpn("11xE1EE")        # RPN length K = 7
print(f"K(ln) = {ln.rpn_length()}    leaves = {ln.leaf_count()}")
for v in [0.5, 2.5, 7.5, 100.0]:
    print(f"  ln({v}) via EML = {ln(x=v):.15g}   numpy: {math.log(v):.15g}")

# 3. The constant zero (= ln 1).
zero = parse_rpn("111E1EE")
print(f"\nzero RPN: {zero.to_rpn()}    value = {zero()}")
