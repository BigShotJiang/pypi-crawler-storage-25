"""Demonstrate that ``eml.core.evalf`` produces results bit-identical to
``math.*`` for elementary chains.

Runtime evaluation through numpy/IEEE-754 accumulates ~0.5 ULP per EML
node — about 2-3 ULPs for π, sin, etc. ``evalf`` evaluates the chain at
30-digit mpmath precision and rounds once to double, eliminating that
slippage.
"""
import math

from eml.core import evalf
from eml.library import build_constant, build_unary, build_binary

print(f"{'target':18s} {'math.*':>22s} {'numpy-eml':>22s}  {'evalf-eml':>22s}  match")
print("-" * 100)

cases_const = [("pi", math.pi), ("e", math.e), ("sqrt(2)", math.sqrt(2))]
for name, ref in cases_const:
    tree = build_constant(name)
    np_val = complex(tree()).real
    ev_val = evalf(tree, real=True)
    print(f"{name:18s} {ref:>22.17g} {np_val:>22.17g}  {ev_val:>22.17g}  "
          f"{'bit-exact' if ev_val == ref else 'DIFF':>10s}")

cases_un = [
    ("sin(1)",   "sin",   1.0,   math.sin(1.0)),
    ("cos(1)",   "cos",   1.0,   math.cos(1.0)),
    ("ln(2)",    "ln",    2.0,   math.log(2.0)),
    ("tan(0.5)", "tan",   0.5,   math.tan(0.5)),
    ("sinh(1.5)","sinh",  1.5,   math.sinh(1.5)),
    ("arctan(.7)","arctan", 0.7, math.atan(0.7)),
]
for label, name, x, ref in cases_un:
    tree = build_unary(name, "x")
    np_val = complex(tree(x=x)).real
    ev_val = evalf(tree, {"x": x}, real=True)
    print(f"{label:18s} {ref:>22.17g} {np_val:>22.17g}  {ev_val:>22.17g}  "
          f"{'bit-exact' if ev_val == ref else 'DIFF':>10s}")

cases_bin = [
    ("hypot(3,4)", "hypot", (3.0, 4.0), math.hypot(3.0, 4.0)),
    ("3 ^ 0.5",    "pow",   (3.0, 0.5), math.pow(3.0, 0.5)),
]
for label, name, xy, ref in cases_bin:
    tree = build_binary(name, "x", "y")
    np_val = complex(tree(x=xy[0], y=xy[1])).real
    ev_val = evalf(tree, {"x": xy[0], "y": xy[1]}, real=True)
    print(f"{label:18s} {ref:>22.17g} {np_val:>22.17g}  {ev_val:>22.17g}  "
          f"{'bit-exact' if ev_val == ref else 'DIFF':>10s}")
