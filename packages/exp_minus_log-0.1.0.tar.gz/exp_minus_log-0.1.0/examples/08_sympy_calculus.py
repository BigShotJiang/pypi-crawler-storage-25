"""Use the SymPy bridge to differentiate, simplify and code-generate
EML chains."""
import sympy as sp

from eml.sympy_eml import EmlFn, eml_to_explog, tree_to_sympy
from eml.tree import parse_rpn, LN_RPN

x, y = sp.symbols("x y", positive=True)

print("EmlFn auto-evaluations:")
print("  EmlFn(x, 1) =", EmlFn(x, 1))      # exp(x)
print("  EmlFn(1, 1) =", EmlFn(1, 1))      # E
print("  EmlFn(0, y) =", EmlFn(0, y))      # 1 - log(y)

print("\nSymbolic differentiation:")
print("  d/dx eml(x,y) =", sp.diff(EmlFn(x, y), x))
print("  d/dy eml(x,y) =", sp.diff(EmlFn(x, y), y))

print("\nLN chain unfolded and simplified:")
ln_tree = parse_rpn(LN_RPN)
chain = tree_to_sympy(ln_tree, free={"x": x})
raw = eml_to_explog(chain)
print("  raw exp/log form:", raw)
print("  simplified:      ",
      sp.logcombine(sp.expand_log(raw, force=True), force=True))

print("\nLambdify -> Python callable:")
f = sp.lambdify(x, raw, modules=["math"])
import math
for v in [0.5, 1.0, 2.0]:
    print(f"  lambdified ln({v}) = {f(v):.12g}   math.log: {math.log(v):.12g}")
