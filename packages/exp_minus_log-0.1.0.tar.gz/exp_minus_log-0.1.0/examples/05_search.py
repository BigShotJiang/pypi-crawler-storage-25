"""Brute-force search for the shortest EML expression of a target.

Reproduces the `Direct search` column of Table 4 for the small entries
that pure-Python search can finish in a few seconds.
"""
import math

from eml.search import search_constant, search_function

print("constant   K   RPN")
print("-" * 40)
for value, name, max_K in [
    (1.0,    "1",    1),
    (math.e, "e",    3),
    (0.0,    "0",    7),
    (-1.0,   "-1",  17),  # paper Direct: 15
]:
    n = search_constant(value, max_K=max_K)
    if n is None:
        print(f"{name:8s}   -   no expression up to K = {max_K}")
    else:
        print(f"{name:8s}   {n.rpn_length():>2d}   {n.to_rpn()}")

print()
print("function   K   RPN")
print("-" * 40)
for fn, name, max_K in [
    (math.exp,  "exp(x)",  3),
    (math.log,  "ln(x)",   7),
]:
    n = search_function(fn, vars=("x",), max_K=max_K)
    print(f"{name:8s}   {n.rpn_length():>2d}   {n.to_rpn()}")
