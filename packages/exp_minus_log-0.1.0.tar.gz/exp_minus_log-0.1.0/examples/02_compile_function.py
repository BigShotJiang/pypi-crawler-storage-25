"""EML compiler: convert any of the 36 Table-1 primitives into an EML
expression tree, examine its RPN, and verify it numerically against the
standard math library."""
import math

from eml.library import build_unary, build_binary, build_constant, ALL_NAMES
from eml.viz import render_ascii

# A handful of named functions, their RPN, and their value at a point.
named = [
    ("sin",   "x", 1.0),
    ("cos",   "x", 1.0),
    ("tanh",  "x", 0.7),
    ("arcosh","x", 1.5),
    ("hypot", "(x,y)", (3.0, 4.0)),
]

for name, var, val in named:
    if isinstance(val, tuple):
        tree = build_binary(name, "x", "y")
        v = tree(x=val[0], y=val[1])
    else:
        tree = build_unary(name, "x")
        v = tree(x=val)
    print(f"\n{name}{var}     K = {tree.rpn_length()}    depth = {tree.depth()}")
    print(f"  RPN ≈ {tree.to_rpn()[:50]}{'…' if tree.rpn_length() > 50 else ''}")
    print(f"  value at {val} = {v}")

# i and pi: these constants live in the complex plane natively.
i_t = build_constant("i")
pi_t = build_constant("pi")
print(f"\ni  via EML = {complex(i_t()):.6g}   K = {i_t.rpn_length()}")
print(f"pi via EML = {complex(pi_t()):.10g}   K = {pi_t.rpn_length()}")

# Pretty ASCII view of a small chain.
print("\nASCII tree of ln(x):")
print(render_ascii(build_unary("ln", "x")))
