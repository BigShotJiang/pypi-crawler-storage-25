"""Recover ``exp(x)`` from data using the level-2 EML master formula
and Adam optimisation, then snap the trained simplex weights back to a
discrete EML tree.

Mirrors §4.3 of the paper at small scale (no torch dependency)."""
import warnings

import numpy as np

from eml.regression import MasterFormula, adam_train

warnings.filterwarnings("ignore")

# generate noiseless training data from the unknown 'law'
true_fn = np.exp
x = np.linspace(-1.0, 1.0, 30)
y = true_fn(x)

print("Training level-2 master formula to fit exp(x) ...")
print(f"  parameters: {sum(w.size for w in MasterFormula.random(2).logits)}")
recoveries = []
for seed in range(8):
    rng = np.random.default_rng(seed)
    mf = MasterFormula.random(2, scale=0.5, rng=rng)
    res = adam_train(mf, x, y, lr=0.1, iters=400)
    tree = mf.snap()
    if tree is None:
        print(f"  seed={seed}  no valid snap")
        continue
    preds = np.array([complex(tree.evaluate({"x": float(v)})) for v in x])
    snap_mse = float(np.mean(np.abs(preds - y) ** 2))
    flag = "✓ exact!" if snap_mse < 1e-12 else " "
    print(f"  seed={seed}  loss={res['final_loss']:.2e}  snap_MSE={snap_mse:.2e}"
          f"  K={tree.rpn_length()}  RPN={tree.to_rpn()}  {flag}")
    if snap_mse < 1e-12:
        recoveries.append(tree.to_rpn())

print(f"\n{len(recoveries)}/8 seeds recovered the exact formula.")
if recoveries:
    print("recovered RPNs:", set(recoveries))
