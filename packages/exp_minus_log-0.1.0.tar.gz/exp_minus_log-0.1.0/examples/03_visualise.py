"""Render a small zoo of EML circuits, mirroring Fig. 2 of the paper."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from eml.library import build_unary, build_constant
from eml.tree import V
from eml.viz import render_mpl

fig, axes = plt.subplots(2, 3, figsize=(13, 8))
axes = axes.flatten()

specs = [
    ("ln(x)",   build_unary("ln",    "x")),
    ("exp(x)",  build_unary("exp",   "x")),
    ("-x",      build_unary("minus", "x")),
    ("1/x",     build_unary("inv",   "x")),
    ("e",       build_constant("e")),
    ("0",       build_constant("0")),
]
for ax, (label, tree) in zip(axes, specs):
    render_mpl(tree, ax=ax, title=f"{label}    (K={tree.rpn_length()})")

plt.tight_layout()
out = "examples/eml_zoo.png"
plt.savefig(out, dpi=130, bbox_inches="tight")
print(f"saved {out}")
