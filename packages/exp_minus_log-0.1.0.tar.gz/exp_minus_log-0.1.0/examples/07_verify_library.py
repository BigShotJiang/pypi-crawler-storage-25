"""Run the Schanuel-style witness verification over every primitive in
``eml.library`` and print the report (mirrors Supplementary Information,
Sect. II of the paper).
"""
import warnings

from eml.verify import verify_library, print_verification_report

warnings.filterwarnings("ignore")

results = verify_library(dps=40, tol=1e-25)
print_verification_report(results)
