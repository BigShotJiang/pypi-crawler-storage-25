# ~/Documents/git/eml/examples/04_vm_bytecode.py 10 May 2026 at 01:28:38 PM
"""Compile an EML expression to a single-instruction bytestream and run
it on the embedded-style VM described in §4.1 of the paper."""

from eml.tree import LN_RPN
from eml.vm import compile_rpn, disassemble, run, trace, to_bytes, from_bytes

prog = compile_rpn(LN_RPN)
print("disassembly:")
print(disassemble(prog))

print("\nbytecode:", to_bytes(prog))
data, table = to_bytes(prog)
prog2 = from_bytes(data, table)
assert prog == prog2

print(f"\nln(2.0) via VM = {run(prog, {'x': 2.0}):.15g}")

print("\nstep-by-step trace at x = 2:")
for instr, stack in trace(prog, {"x": 2.0}):
    print(f"  {instr!r:20s}  stack -> {stack}")
