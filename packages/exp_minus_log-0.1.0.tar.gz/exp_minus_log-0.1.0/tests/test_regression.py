"""Tests for the master-formula symbolic regression."""
import warnings

import numpy as np

from eml.regression import MasterFormula, adam_train, n_params


def test_param_count_formula():
    # Paper: level-n master formula has 5*2^n - 6 params
    for n in (1, 2, 3, 4):
        mf = MasterFormula.random(n)
        flat = mf.flatten()
        assert flat.size == n_params(n) == 5 * 2 ** n - 6


def test_recover_exp_at_level_1():
    # eml(x, 1) = exp(x).  Vertex pattern: left=x (idx 1), right=1 (idx 0).
    mf = MasterFormula.random(1, scale=0.1, rng=np.random.default_rng(0))
    mf.logits[0] = np.array([-3.0, 3.0])  # left -> x
    mf.logits[1] = np.array([3.0, -3.0])  # right -> 1
    tree = mf.snap()
    assert tree.to_rpn() == "x1E"


def test_adam_recovers_exp_from_random_init_majority():
    warnings.filterwarnings("ignore")
    x_data = np.linspace(-1, 1, 30)
    y_data = np.exp(x_data)
    successes = 0
    for seed in range(5):
        mf = MasterFormula.random(2, scale=0.5, rng=np.random.default_rng(seed))
        adam_train(mf, x_data, y_data, lr=0.1, iters=400)
        tree = mf.snap()
        if tree is None:
            continue
        try:
            preds = np.array([complex(tree.evaluate({"x": float(xv)})) for xv in x_data])
            if float(np.mean(np.abs(preds - y_data) ** 2)) < 1e-10:
                successes += 1
        except Exception:
            pass
    # paper claims ~100% at depth 2; we accept >= 3/5 to be robust to FD noise.
    assert successes >= 3, f"only {successes}/5 seeds recovered exp"
