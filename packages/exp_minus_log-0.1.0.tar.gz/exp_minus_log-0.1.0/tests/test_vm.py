import math

import numpy as np

from eml.vm import (
    compile_rpn, run, trace, disassemble, to_bytes, from_bytes, Op, Instr,
)
from eml.tree import LN_RPN
from eml.core import eml_mp


def test_vm_runs_ln_chain():
    prog = compile_rpn(LN_RPN)
    assert math.isclose(run(prog, {"x": 7.5}), math.log(7.5))


def test_vm_bytestream_round_trip():
    prog = compile_rpn(LN_RPN)
    data, table = to_bytes(prog)
    prog2 = from_bytes(data, table)
    assert prog2 == prog


def test_vm_trace_length():
    prog = compile_rpn(LN_RPN)
    log = trace(prog, {"x": 2.0})
    # one entry per instruction
    assert len(log) == len(prog)
    # final stack is one element
    assert len(log[-1][1]) == 1


def test_vm_mpmath_backend():
    import mpmath as mp
    mp.mp.dps = 30
    prog = compile_rpn(LN_RPN)
    v = run(prog, {"x": mp.mpf(2)}, op=eml_mp, one=mp.mpf(1))
    assert mp.almosteq(v.real, mp.log(2), rel_eps=mp.mpf("1e-25"))
