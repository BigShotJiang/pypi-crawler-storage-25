"""Tests for the core EML operator."""
import math

import numpy as np
import pytest

from eml.core import eml, edl, neml, eml_mp, fix_i_sign


def test_eml_canonical_e():
    assert math.isclose(eml(1, 1), math.e)


def test_eml_exp_chain():
    for x in [-2.5, -0.7, 0.0, 0.3, 1.0, 7.5]:
        assert math.isclose(eml(x, 1), math.exp(x))


def test_eml_ln_chain():
    for x in [0.5, 1.0, 2.5, 7.5, 100.0]:
        v = eml(1, eml(eml(1, x), 1))
        assert math.isclose(v, math.log(x))


def test_eml_zero_chain():
    z = eml(1, eml(eml(1, 1), 1))
    assert abs(z) < 1e-12


def test_eml_vectorised():
    xs = np.array([1.0, 2.0, 3.0])
    out = eml(xs, np.ones_like(xs))
    np.testing.assert_allclose(out, np.exp(xs))


def test_eml_complex_branch():
    # eml(0, -1) = exp(0) - log(-1) = 1 - i*pi
    out = eml(0, -1)
    assert math.isclose(out.real, 1.0)
    assert math.isclose(out.imag, -math.pi)


def test_eml_mp_high_precision():
    import mpmath as mp
    mp.mp.dps = 50
    v = eml_mp(1, 1)
    assert mp.almosteq(v.real, mp.e, rel_eps=mp.mpf('1e-49'))
    mp.mp.dps = 15


def test_edl_basic():
    # edl(0, e) = 1 / 1 = 1
    out = edl(0, math.e)
    assert math.isclose(out.real, 1.0)


def test_neml_ln():
    # ln(t) = -eml(t, -inf)  (i.e. neml(t, -inf) = ln t - exp(-inf) = ln t)
    for x in [0.5, 2.0, 10.0]:
        v = neml(x, -math.inf)
        assert math.isclose(v.real, math.log(x))


def test_fix_i_sign():
    z = -1j
    assert fix_i_sign(z, target=1j) == 1j
    assert fix_i_sign(1j, target=1j) == 1j
