"""Tests covering every primitive of Table 1."""
import warnings

import pytest

from eml.library import (
    CONSTANTS, UNARY, BINARY,
    build_constant, build_unary, build_binary, reference,
)
from eml.verify import verify_library


def test_full_library_passes_high_precision_witness():
    # Each EML chain agrees with the reference at the transcendental
    # witness to within the precision floor (~1e-30 with dps=40).
    warnings.filterwarnings("ignore")
    results = verify_library(dps=40, tol=1e-25)
    failed = [r for r in results if not r.passed]
    assert not failed, f"failed: {[(r.name, r.abs_err) for r in failed]}"


@pytest.mark.parametrize("name", CONSTANTS)
def test_constant_value(name):
    tree = build_constant(name)
    got = complex(tree())
    want = complex(reference(name)())
    assert abs(got - want) < 1e-9 * max(1.0, abs(want))


@pytest.mark.parametrize("name", UNARY)
def test_unary(name):
    test_x = {
        "arcsin":  0.3, "arccos": 0.4, "arctan": 0.7,
        "arsinh":  0.5, "arcosh": 1.5, "artanh":  0.4,
    }.get(name, 1.3)
    tree = build_unary(name, "x")
    got = complex(tree(x=test_x))
    want = complex(reference(name)(test_x))
    assert abs(got - want) < 1e-9 * max(1.0, abs(want))


@pytest.mark.parametrize("name", BINARY)
def test_binary(name):
    xy = {"log": (1.5, 2.5), "pow": (1.7, 0.6), "hypot": (3.0, 4.0)}.get(name, (1.4, 2.7))
    tree = build_binary(name, "x", "y")
    got = complex(tree(x=xy[0], y=xy[1]))
    want = complex(reference(name)(*xy))
    assert abs(got - want) < 1e-9 * max(1.0, abs(want))
