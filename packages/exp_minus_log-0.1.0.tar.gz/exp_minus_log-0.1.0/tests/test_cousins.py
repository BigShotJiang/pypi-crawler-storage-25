import math

from eml.cousins import verify_cousins, edl_evaluate, EDL_E, edl_exp, neml_evaluate, neml_ln
from eml.tree import V


def test_verify_cousins_all_pass():
    res = verify_cousins()
    assert all(res.values()), res


def test_edl_exp_e():
    # exp(e) via EDL: edl(e, e) = exp(e)/ln(e) = exp(e)/1
    t = edl_exp(EDL_E)
    assert math.isclose(complex(edl_evaluate(t)).real, math.exp(math.e))


def test_neml_ln_chain():
    t = neml_ln(V("x"))
    for x in [0.5, 2.0, 10.0]:
        v = neml_evaluate(t, {"x": x})
        assert math.isclose(complex(v).real, math.log(x))
