import sympy as sp

from eml.sympy_eml import EmlFn, eml_to_explog, explog_to_eml, tree_to_sympy
from eml.tree import parse_rpn, LN_RPN


def test_emlfn_auto_eval():
    x = sp.Symbol("x")
    assert EmlFn(x, 1) == sp.exp(x)
    assert EmlFn(1, 1) == sp.E
    assert EmlFn(0, x) == 1 - sp.log(x)


def test_emlfn_diff():
    x, y = sp.symbols("x y")
    e = EmlFn(x, y)
    assert sp.diff(e, x) == sp.exp(x)
    assert sp.diff(e, y) == -1 / y


def test_eml_to_explog_round_trip():
    x = sp.Symbol("x", positive=True)
    chain = tree_to_sympy(parse_rpn(LN_RPN), free={"x": x})
    raw = eml_to_explog(chain)
    simplified = sp.logcombine(sp.expand_log(raw, force=True), force=True)
    assert simplified == sp.log(x)


def test_emlfn_evalf():
    v = sp.N(EmlFn(1, 1), 30)
    assert abs(v - sp.E.evalf(30)) < sp.Float("1e-29")
