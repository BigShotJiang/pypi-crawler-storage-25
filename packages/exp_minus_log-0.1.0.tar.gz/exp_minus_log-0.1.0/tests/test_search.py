import math

from eml.search import search_constant, search_function


def test_shortest_zero():
    n = search_constant(0.0, max_K=7)
    assert n is not None
    assert n.rpn_length() == 7


def test_shortest_e():
    n = search_constant(math.e, max_K=3)
    assert n is not None
    assert n.rpn_length() == 3


def test_shortest_ln():
    n = search_function(math.log, vars=("x",), max_K=7)
    assert n is not None
    assert n.rpn_length() == 7


def test_shortest_exp():
    n = search_function(math.exp, vars=("x",), max_K=3)
    assert n is not None
    assert n.rpn_length() == 3
