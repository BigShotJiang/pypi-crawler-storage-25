"""``evalf`` produces bit-exact agreement with the standard math library."""
import math

from eml.core import evalf
from eml.library import build_constant, build_unary, build_binary


def test_evalf_pi_bit_exact():
    assert evalf(build_constant("pi"), real=True) == math.pi


def test_evalf_e_bit_exact():
    assert evalf(build_constant("e"), real=True) == math.e


def test_evalf_sqrt2_bit_exact():
    assert evalf(build_constant("sqrt(2)"), real=True) == math.sqrt(2)


def test_evalf_log_bit_exact():
    for x in (0.5, 1.0, 2.0, math.e, 10.0):
        assert evalf(build_unary("ln", "x"), {"x": x}, real=True) == math.log(x)


# Exact ``x = 0`` is excluded: the natural EML chains for sin/cos/arctan
# pass through ln(0) = -inf in intermediates.  NumPy/IEEE-754 handles
# this via signed zeros and infinities; mpmath returns NaN for some of
# the resulting indeterminate forms.  Numerically the limit is correct,
# but ``evalf`` (mpmath-backed) cannot certify it.
def test_evalf_sin_bit_exact():
    for x in (0.3, 1.0, math.pi / 4):
        assert evalf(build_unary("sin", "x"), {"x": x}, real=True) == math.sin(x)


def test_evalf_cos_bit_exact():
    for x in (0.3, 1.0, math.pi / 4):
        assert evalf(build_unary("cos", "x"), {"x": x}, real=True) == math.cos(x)


def test_evalf_atan_bit_exact():
    for x in (-0.5, 0.3, 0.7):
        assert evalf(build_unary("arctan", "x"), {"x": x}, real=True) == math.atan(x)


def test_evalf_hypot_bit_exact():
    for xy in [(3.0, 4.0), (1.0, 1.0), (5.0, 12.0)]:
        assert evalf(build_binary("hypot", "x", "y"),
                     {"x": xy[0], "y": xy[1]}, real=True) == math.hypot(*xy)
