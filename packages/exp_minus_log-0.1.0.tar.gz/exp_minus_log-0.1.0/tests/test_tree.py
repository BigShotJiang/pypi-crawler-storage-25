"""Tests for the expression tree and RPN compiler."""
import math

import pytest

from eml.tree import (
    parse_rpn, to_rpn, to_sympy, ONE, V, E, LN_RPN, EXP_RPN, E_RPN, ZERO_RPN,
)


def test_rpn_round_trip():
    for code in [LN_RPN, EXP_RPN, E_RPN, ZERO_RPN]:
        assert to_rpn(parse_rpn(code)) == code


def test_leaf_count_and_K():
    ln = parse_rpn(LN_RPN)
    assert ln.leaf_count() == 4
    assert ln.rpn_length() == 7
    assert ln.depth() == 3


def test_evaluate_ln():
    ln = parse_rpn(LN_RPN)
    for x in [0.5, 2.5, 100.0]:
        assert math.isclose(ln(x=x), math.log(x))


def test_evaluate_zero():
    z = parse_rpn(ZERO_RPN)
    assert abs(complex(z())) < 1e-12


def test_parse_rpn_rejects_underflow():
    with pytest.raises(ValueError):
        parse_rpn("1E")


def test_node_equality_and_hash():
    a = E(ONE, V("x"))
    b = E(ONE, V("x"))
    assert a == b
    assert hash(a) == hash(b)
    assert {a, b} == {a}


def test_to_sympy_simplifies_ln():
    import sympy as sp
    ln = parse_rpn(LN_RPN)
    e = to_sympy(ln)
    simplified = sp.logcombine(sp.expand_log(e, force=True), force=True)
    assert simplified == sp.log(sp.Symbol("x"))
