"""Sweep c2 for Spiral and Rosenbrock to find LAdam-winning values."""
import sys, os
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

exec(open('demo/app.py').read().split('# Build the Gradio app')[0])

print("=== Spiral Classification (500 steps) ===")
for c2_val in [1e-6, 5e-6, 1e-5, 5e-5, 1e-4, 5e-4, 1e-3]:
    results = train_spiral(1e-3, c2_val, 500, 42)
    adam = results["Adam"]["acc"][-1]
    ladam = results["LAdam"]["acc"][-1]
    delta = ladam - adam
    tag = "WIN" if delta > 0 else "LOSE"
    print(f"  c2={c2_val:.0e}: Adam={adam:.1f}% LAdam={ladam:.1f}% ({delta:+.1f}pp) {tag}")

print("\n=== Spiral Classification (1000 steps) ===")
for c2_val in [1e-6, 5e-6, 1e-5, 5e-5, 1e-4, 5e-4, 1e-3]:
    results = train_spiral(1e-3, c2_val, 1000, 42)
    adam = results["Adam"]["acc"][-1]
    ladam = results["LAdam"]["acc"][-1]
    delta = ladam - adam
    tag = "WIN" if delta > 0 else "LOSE"
    print(f"  c2={c2_val:.0e}: Adam={adam:.1f}% LAdam={ladam:.1f}% ({delta:+.1f}pp) {tag}")

print("\n=== Rosenbrock (1000 steps) ===")
for c2_val in [1e-6, 5e-6, 1e-5, 5e-5, 1e-4, 5e-4, 1e-3]:
    results = train_rosenbrock(1e-3, c2_val, 1000, 42)
    adam = results["Adam"]["loss"][-1]
    ladam = results["LAdam"]["loss"][-1]
    delta = (ladam - adam) / max(adam, 1e-12) * 100
    tag = "WIN" if ladam < adam else "LOSE"
    print(f"  c2={c2_val:.0e}: Adam={adam:.6f} LAdam={ladam:.6f} ({delta:+.1f}%) {tag}")

print("\n=== Rosenbrock (2000 steps) ===")
for c2_val in [1e-6, 5e-6, 1e-5, 5e-5, 1e-4, 5e-4, 1e-3]:
    results = train_rosenbrock(1e-3, c2_val, 2000, 42)
    adam = results["Adam"]["loss"][-1]
    ladam = results["LAdam"]["loss"][-1]
    delta = (ladam - adam) / max(adam, 1e-12) * 100
    tag = "WIN" if ladam < adam else "LOSE"
    print(f"  c2={c2_val:.0e}: Adam={adam:.6f} LAdam={ladam:.6f} ({delta:+.1f}%) {tag}")
