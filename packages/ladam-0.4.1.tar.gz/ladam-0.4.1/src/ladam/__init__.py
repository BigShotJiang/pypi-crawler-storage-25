"""
LAdamW -- Laplacian AdamW Optimizer
"""

__version__ = "0.4.1"

from .optimizer import LAdamW, LAdaGrad, LRMSProp, suggest_c2
from .normalization import WaveNorm, WaveNormDamped, ChiNorm
from .reorder import compute_neuron_order, reorder_linear_layer
from .scheduler import ChiAnnealScheduler

# Backward compatibility aliases
LAdam = LAdamW
WaveAdam = LAdamW

__all__ = [
    "LAdamW", "LAdam", "LAdaGrad", "LRMSProp", "WaveAdam", "suggest_c2",
    "WaveNorm", "WaveNormDamped", "ChiNorm",
    "compute_neuron_order", "reorder_linear_layer",
    "ChiAnnealScheduler",
]
