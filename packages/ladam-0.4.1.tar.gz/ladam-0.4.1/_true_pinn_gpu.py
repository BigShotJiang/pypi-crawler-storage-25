"""
TRUE PINN GPU: Physics-informed loss with PDE residual on GPU.
PDE: u_tt = u_xx on [0,1]x[0,1]
Exact: u(x,t) = sin(pi*x)*cos(pi*t)

Loss = PDE_residual + lambda*BC + lambda*IC
"""
import torch, torch.nn as nn, torch.nn.functional as F
import numpy as np, time, sys

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Device: {device}", flush=True)

_k2d_cache = {}
def _get_k2d(d, t):
    key = (d, t)
    if key not in _k2d_cache:
        k = torch.tensor([[1/6., 4/6., 1/6.], [4/6., -20/6., 4/6.], [1/6., 4/6., 1/6.]], device=d, dtype=t)
        _k2d_cache[key] = k.reshape(1, 1, 3, 3)
    return _k2d_cache[key]

_k1d_cache = {}
def _get_k1d(d, t):
    key = (d, t)
    if key not in _k1d_cache:
        _k1d_cache[key] = torch.tensor([1., -2., 1.], device=d, dtype=t).reshape(1, 1, 3)
    return _k1d_cache[key]

def _lap(W, k2d, k1d):
    if W.dim() == 1:
        n = W.numel()
        if n < 4: return torch.zeros_like(W)
        x = F.pad(W.reshape(1,1,n), (1,1), mode='circular')
        return F.conv1d(x, k1d).reshape(W.shape)
    shape = W.shape; W2 = W.reshape(shape[0], -1) if W.dim() > 2 else W
    h, w = W2.shape
    if h < 3 or w < 3: return torch.zeros_like(W)
    x = F.pad(W2.reshape(1,1,h,w), (1,1,1,1), mode='circular')
    r = F.conv2d(x, k2d).reshape(W2.shape)
    return r.reshape(shape) if W.dim() > 2 else r

class LAdam(torch.optim.Optimizer):
    def __init__(s, params, lr=1e-3, betas=(0.9,0.999), eps=1e-8, weight_decay=0, c2=1e-4):
        super().__init__(params, dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay, c2=c2))
    @torch.no_grad()
    def step(s, closure=None):
        for g in s.param_groups:
            lr, eps, c2, b1, b2 = g['lr'], g['eps'], g['c2'], g['betas'][0], g['betas'][1]
            k2d = _get_k2d(next(iter(g['params'])).device, next(iter(g['params'])).dtype)
            k1d = _get_k1d(next(iter(g['params'])).device, next(iter(g['params'])).dtype)
            for p in g['params']:
                if p.grad is None: continue
                gr = p.grad
                st = s.state[p]
                if not st: st['step']=0; st['m']=torch.zeros_like(p); st['v']=torch.zeros_like(p); st['use_lap']=(c2>0 and p.numel()>=16)
                st['step'] += 1
                m, v = st['m'], st['v']
                m.mul_(b1).add_(gr, alpha=1-b1); v.mul_(b2).addcmul_(gr, gr, value=1-b2)
                mh = m/(1-b1**st['step']); vh = v/(1-b2**st['step'])
                if st['use_lap']:
                    vh = (vh + c2*_lap(vh, k2d, k1d)).clamp_(min=0)
                p.addcdiv_(mh, vh.sqrt().add_(eps), value=-lr)


def make_model(hidden, n_layers, seed):
    torch.manual_seed(seed)
    layers = [nn.Linear(2, hidden), nn.Tanh()]
    for _ in range(n_layers - 1):
        layers += [nn.Linear(hidden, hidden), nn.Tanh()]
    layers.append(nn.Linear(hidden, 1))
    return nn.Sequential(*layers).to(device)


def train_true_pinn(lr, c2, steps, seed, hidden=128, n_layers=4, lam_bc=10.0, lam_ic=10.0):
    n_int, n_bc, n_ic = 300, 30, 60
    pi = np.pi

    torch.manual_seed(seed)
    # Collocation points
    x_int = torch.rand(n_int, 1, device=device, requires_grad=True)
    t_int = torch.rand(n_int, 1, device=device, requires_grad=True)
    t_bc = torch.rand(n_bc, 1, device=device)
    x_bc0 = torch.zeros(n_bc, 1, device=device)
    x_bc1 = torch.ones(n_bc, 1, device=device)
    x_ic = torch.rand(n_ic, 1, device=device, requires_grad=True)
    t_ic = torch.zeros(n_ic, 1, device=device, requires_grad=True)
    u_ic_true = torch.sin(pi * x_ic.detach())

    # Eval grid
    xg, tg = torch.meshgrid(torch.linspace(0,1,40,device=device), torch.linspace(0,1,40,device=device), indexing='ij')
    x_eval = xg.reshape(-1,1); t_eval = tg.reshape(-1,1)
    u_exact = torch.sin(pi*x_eval)*torch.cos(pi*t_eval)

    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        model = make_model(hidden, n_layers, seed)
        opt = cls(model.parameters(), lr=lr, **kw)
        ones = torch.ones(n_int, 1, device=device)

        for s in range(steps):
            xt = torch.cat([x_int, t_int], dim=1)
            u = model(xt)
            u_x = torch.autograd.grad(u, x_int, ones, create_graph=True)[0]
            u_t = torch.autograd.grad(u, t_int, ones, create_graph=True)[0]
            u_xx = torch.autograd.grad(u_x, x_int, ones, create_graph=True)[0]
            u_tt = torch.autograd.grad(u_t, t_int, ones, create_graph=True)[0]
            loss_pde = F.mse_loss(u_tt - u_xx, torch.zeros_like(u_xx))

            u0 = model(torch.cat([x_bc0, t_bc], 1))
            u1 = model(torch.cat([x_bc1, t_bc], 1))
            loss_bc = F.mse_loss(u0, torch.zeros_like(u0)) + F.mse_loss(u1, torch.zeros_like(u1))

            u_ic = model(torch.cat([x_ic, t_ic], 1))
            loss_ic = F.mse_loss(u_ic, u_ic_true)
            u_t_ic = torch.autograd.grad(u_ic, t_ic, torch.ones(n_ic,1,device=device), create_graph=True)[0]
            loss_ic_t = F.mse_loss(u_t_ic, torch.zeros_like(u_t_ic))

            loss = loss_pde + lam_bc*loss_bc + lam_ic*(loss_ic + loss_ic_t)
            loss.backward()
            opt.step(); opt.zero_grad()

        with torch.no_grad():
            u_pred = model(torch.cat([x_eval, t_eval], 1))
            results[name] = torch.sqrt(F.mse_loss(u_pred, u_exact)).item()
    return results


print("="*70)
print("TRUE PINN: PDE residual (u_tt = u_xx) on GPU")
print("="*70)

N_SEEDS = 20
seeds = list(range(N_SEEDS))

# Quick warmup
_ = train_true_pinn(1e-3, 1e-4, 10, 0, hidden=64, n_layers=3)
print("Warmup done.", flush=True)

# Test matrix
configs = [
    # c2,     steps, hidden, n_layers
    (1e-6,    300,   128,    4),
    (1e-5,    300,   128,    4),
    (5e-5,    300,   128,    4),
    (1e-4,    300,   128,    4),
    (5e-4,    300,   128,    4),
    (1e-3,    300,   128,    4),
    (1e-5,    500,   128,    4),
    (5e-5,    500,   128,    4),
    (1e-4,    500,   128,    4),
    (5e-4,    500,   128,    4),
    (1e-3,    500,   128,    4),
    (1e-4,    1000,  128,    4),
    (5e-4,    1000,  128,    4),
    (1e-3,    1000,  128,    4),
    # Wider
    (1e-4,    500,   256,    4),
    (5e-4,    500,   256,    4),
    (1e-3,    500,   256,    4),
    (1e-4,    1000,  256,    4),
    (5e-4,    1000,  256,    4),
]

print(f"\nTesting {len(configs)} configs x {N_SEEDS} seeds (lr=1e-3)")
print(f"{'c2':>8s} {'steps':>5s} {'hidden':>6s} {'layers':>6s} | {'WR':>6s} {'avg_d':>7s} {'med_d':>7s}")
print("-"*60)

for c2, steps, hidden, n_layers in configs:
    wins, deltas = 0, []
    t0 = time.time()
    for seed in seeds:
        r = train_true_pinn(1e-3, c2, steps, seed, hidden=hidden, n_layers=n_layers)
        d = (r["LAdam"] - r["Adam"]) / max(r["Adam"], 1e-12) * 100
        deltas.append(d)
        if d < -0.1: wins += 1
    wr = wins/N_SEEDS
    dt = time.time()-t0
    tag = " ***" if wr >= 0.80 else (" **" if wr >= 0.70 else (" *" if wr >= 0.60 else ""))
    print(f"  {c2:.0e} {steps:5d} {hidden:6d} {n_layers:6d} | {wr*100:5.1f}% {np.mean(deltas):+7.1f}% {np.median(deltas):+7.1f}%{tag} [{dt:.0f}s]", flush=True)

print("\n" + "="*70)
print("DONE")
