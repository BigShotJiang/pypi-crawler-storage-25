"""Tests for ChiAnnealScheduler."""

import math
import torch
from ladam import ChiAnnealScheduler


def _make_optimizer(lr=1e-3):
    """Create a simple optimizer for testing."""
    param = torch.nn.Parameter(torch.randn(4, 4))
    return torch.optim.SGD([param], lr=lr)


def test_scheduler_warmup():
    """LR should ramp linearly during warmup phase."""
    opt = _make_optimizer(lr=1.0)
    sched = ChiAnnealScheduler(opt, total_steps=100, warmup_frac=0.10, settle_frac=0.30)

    # Step through warmup (10 steps)
    for i in range(1, 11):
        sched.step()
        expected = i / 10
        assert abs(opt.param_groups[0]['lr'] - expected) < 1e-6, \
            f"Step {i}: expected lr={expected}, got {opt.param_groups[0]['lr']}"


def test_scheduler_constant_phase():
    """LR should be constant between warmup and settle."""
    opt = _make_optimizer(lr=0.5)
    sched = ChiAnnealScheduler(opt, total_steps=100, warmup_frac=0.10, settle_frac=0.30)

    # Skip warmup
    for _ in range(10):
        sched.step()

    # Constant phase: steps 11-70
    for i in range(11, 71):
        sched.step()
        assert abs(opt.param_groups[0]['lr'] - 0.5) < 1e-6, \
            f"Step {i}: expected lr=0.5, got {opt.param_groups[0]['lr']}"


def test_scheduler_settle_decay():
    """LR should decay via cosine-squared during settle phase."""
    opt = _make_optimizer(lr=1.0)
    sched = ChiAnnealScheduler(opt, total_steps=100, warmup_frac=0.10, settle_frac=0.30)

    # Skip to settle start
    for _ in range(70):
        sched.step()

    # At settle start, LR should still be ~1.0
    assert abs(opt.param_groups[0]['lr'] - 1.0) < 1e-6

    # Step through settle phase
    sched.step()  # step 71 (first settle step)
    assert opt.param_groups[0]['lr'] < 1.0  # Should have started decaying

    # At the end, LR should be near 0
    for _ in range(72, 101):
        sched.step()
    assert opt.param_groups[0]['lr'] < 0.01


def test_scheduler_end_state():
    """After all steps, LR should be very close to 0."""
    opt = _make_optimizer(lr=1.0)
    sched = ChiAnnealScheduler(opt, total_steps=1000, warmup_frac=0.05, settle_frac=0.30)

    for _ in range(1000):
        sched.step()

    assert opt.param_groups[0]['lr'] < 1e-6


def test_scheduler_get_last_lr():
    """get_last_lr should return current lr values."""
    opt = _make_optimizer(lr=0.1)
    sched = ChiAnnealScheduler(opt, total_steps=100)

    sched.step()
    lrs = sched.get_last_lr()
    assert len(lrs) == 1
    assert lrs[0] == opt.param_groups[0]['lr']


def test_scheduler_state_dict():
    """State dict should allow save/restore."""
    opt = _make_optimizer(lr=1.0)
    sched = ChiAnnealScheduler(opt, total_steps=100)

    for _ in range(50):
        sched.step()

    state = sched.state_dict()
    assert state['step_count'] == 50

    # Restore
    opt2 = _make_optimizer(lr=1.0)
    sched2 = ChiAnnealScheduler(opt2, total_steps=100)
    sched2.load_state_dict(state)
    assert sched2.step_count == 50


def test_scheduler_multi_param_groups():
    """Should handle multiple parameter groups with different base LRs."""
    p1 = torch.nn.Parameter(torch.randn(4))
    p2 = torch.nn.Parameter(torch.randn(4))
    opt = torch.optim.SGD([
        {'params': [p1], 'lr': 1.0},
        {'params': [p2], 'lr': 0.1},
    ])
    sched = ChiAnnealScheduler(opt, total_steps=100, warmup_frac=0.10)

    # After 5 warmup steps (halfway through warmup)
    for _ in range(5):
        sched.step()

    assert abs(opt.param_groups[0]['lr'] - 0.5) < 1e-6   # 1.0 * 5/10
    assert abs(opt.param_groups[1]['lr'] - 0.05) < 1e-6   # 0.1 * 5/10


def test_scheduler_validation():
    """Invalid params should raise ValueError."""
    opt = _make_optimizer()

    try:
        ChiAnnealScheduler(opt, total_steps=-1)
        assert False, "Should have raised ValueError"
    except ValueError:
        pass

    try:
        ChiAnnealScheduler(opt, total_steps=100, warmup_frac=0.8, settle_frac=0.5)
        assert False, "Should have raised ValueError for sum > 1"
    except ValueError:
        pass
