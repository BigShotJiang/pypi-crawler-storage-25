"""Full sales funnel audit for all revenue streams."""
import requests
import json
import time
import sys

PASS = "PASS"
FAIL = "FAIL"

def verdict(expected, actual):
    return PASS if expected == actual else f"FAIL (expected {expected}, got {actual})"

def section(title):
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}")

results = []

def record(stream, test, status_code, expected, latency, note=""):
    ok = status_code == expected
    results.append({
        "stream": stream,
        "test": test,
        "status": status_code,
        "expected": expected,
        "pass": ok,
        "latency_s": round(latency, 2),
        "note": note,
    })
    tag = PASS if ok else FAIL
    print(f"  [{tag}] {test} -> {status_code} ({latency:.2f}s) {note}")

# =====================================================================
section("1. LAdam Optimizer API (Modal)")
# =====================================================================
base = "https://gpartin--ladam-api-fastapi-app.modal.run"

# Health (free)
print("\n  GET /health (free, no auth)")
t0 = time.time()
r = requests.get(f"{base}/health", timeout=30)
record("LAdam API", "Health check", r.status_code, 200, time.time()-t0)

# Pricing (free)
print("\n  GET /pricing (free, no auth)")
t0 = time.time()
r = requests.get(f"{base}/pricing", timeout=30)
record("LAdam API", "Pricing info", r.status_code, 200, time.time()-t0)
if r.status_code == 200:
    endpoints = r.json().get("endpoints", [])
    for ep in endpoints:
        if isinstance(ep, dict):
            print(f"    {ep.get('path','')} -> {ep.get('cost','?')}")

# No auth -> 402
print("\n  POST /v1/analyze WITHOUT auth (expect 402)")
t0 = time.time()
r = requests.post(f"{base}/v1/analyze", json={"model_type": "mlp"}, timeout=30)
record("LAdam API", "No auth -> 402", r.status_code, 402, time.time()-t0)
if r.status_code == 402:
    body = r.json()
    has_wallet = "accepts" in str(body) or "wallet" in str(body).lower() or "usdc" in str(body).lower()
    print(f"    Payment info present: {has_wallet}")
    print(f"    Body preview: {json.dumps(body)[:200]}")

# Bad key -> 403
print("\n  POST /v1/analyze WITH bad key (expect 403)")
t0 = time.time()
r = requests.post(f"{base}/v1/analyze",
    headers={"X-API-Key": "sk-fake-999"},
    json={"model_type": "mlp"}, timeout=30)
record("LAdam API", "Bad key -> 403", r.status_code, 403, time.time()-t0)

# Good key -> 200 (CPU)
print("\n  POST /v1/analyze WITH valid key (expect 200)")
t0 = time.time()
r = requests.post(f"{base}/v1/analyze",
    headers={"X-API-Key": "sk-ladam-test-001", "Content-Type": "application/json"},
    json={"model_type": "cnn", "hidden_size": 128, "num_layers": 3}, timeout=30)
record("LAdam API", "Valid key analyze (CPU)", r.status_code, 200, time.time()-t0)
if r.status_code == 200:
    body = r.json()
    print(f"    Cost: {body.get('cost', 'MISSING')}")
    print(f"    Recommendation: {body.get('recommendation', 'N/A')[:80]}")

# Benchmark with key -> 200 (GPU)
print("\n  POST /v1/benchmark WITH valid key (GPU, may be slow)")
t0 = time.time()
r = requests.post(f"{base}/v1/benchmark",
    headers={"X-API-Key": "sk-ladam-test-001", "Content-Type": "application/json"},
    json={"model_type": "mlp", "hidden_size": 64, "num_layers": 2, "steps": 20},
    timeout=300)
record("LAdam API", "Valid key benchmark (GPU)", r.status_code, 200, time.time()-t0)
if r.status_code == 200:
    body = r.json()
    print(f"    Cost: {body.get('cost', 'MISSING')}")
    res = body.get("results", {})
    for opt in ["adam", "ladam"]:
        if opt in res:
            print(f"    {opt}: loss={res[opt].get('final_loss','?')}, acc={res[opt].get('final_accuracy','?')}")

# =====================================================================
section("2. WaveGuard API (Modal)")
# =====================================================================
wg_base = "https://gpartin--waveguard-api-fastapi-app.modal.run"

# Health
print("\n  GET /health")
try:
    t0 = time.time()
    r = requests.get(f"{wg_base}/health", timeout=30)
    record("WaveGuard", "Health check", r.status_code, 200, time.time()-t0)
except Exception as e:
    record("WaveGuard", "Health check", 0, 200, 0, f"ERROR: {e}")

# Scan without payment -> 402
print("\n  POST /v1/scan WITHOUT payment (expect 402)")
try:
    t0 = time.time()
    r = requests.post(f"{wg_base}/v1/scan",
        json={"audio_url": "https://example.com/test.wav"}, timeout=30)
    record("WaveGuard", "No payment -> 402", r.status_code, 402, time.time()-t0)
    if r.status_code == 402:
        body = r.json()
        has_wallet = "0x" in str(body)
        print(f"    x402 wallet present: {has_wallet}")
        print(f"    Body: {json.dumps(body)[:200]}")
except Exception as e:
    record("WaveGuard", "No payment -> 402", 0, 402, 0, f"ERROR: {e}")

# =====================================================================
section("3. CryptoGuard API (Modal)")
# =====================================================================
cg_base = "https://gpartin--cryptoguard-api-fastapi-app.modal.run"

# Health
print("\n  GET /health")
try:
    t0 = time.time()
    r = requests.get(f"{cg_base}/health", timeout=30)
    record("CryptoGuard", "Health check", r.status_code, 200, time.time()-t0)
except Exception as e:
    record("CryptoGuard", "Health check", 0, 200, 0, f"ERROR: {e}")

# Analyze without payment -> 402
print("\n  POST /v1/analyze WITHOUT payment (expect 402)")
try:
    t0 = time.time()
    r = requests.post(f"{cg_base}/v1/analyze",
        json={"contract_address": "0x1234567890abcdef1234567890abcdef12345678",
              "chain": "ethereum"}, timeout=30)
    record("CryptoGuard", "No payment -> 402", r.status_code, 402, time.time()-t0)
    if r.status_code == 402:
        body = r.json()
        has_wallet = "0x" in str(body)
        print(f"    x402 wallet present: {has_wallet}")
        print(f"    Body: {json.dumps(body)[:200]}")
except Exception as e:
    record("CryptoGuard", "No payment -> 402", 0, 402, 0, f"ERROR: {e}")

# =====================================================================
section("4. Donation/Sponsorship Pages")
# =====================================================================

pages = [
    ("GitHub Sponsors", "https://github.com/sponsors/gpartin"),
    ("Buy Me a Coffee", "https://buymeacoffee.com/emergentphysicslab"),
    ("PayPal Donate", "https://www.paypal.com/donate/?hosted_button_id=TUJRJ9CKTR3BW"),
    ("PyPI Package", "https://pypi.org/project/ladam/"),
    ("HF Demo Space", "https://huggingface.co/spaces/emergentphysicslab/ladam-demo"),
    ("HF Dataset", "https://huggingface.co/datasets/emergentphysicslab/ladam-benchmark-traces"),
    ("HF Collection", "https://huggingface.co/collections/emergentphysicslab/ladam-optimizer-suite-69d5a5918b033a517a6fd157"),
    ("GitHub Repo", "https://github.com/gpartin/ladam"),
]

for name, url in pages:
    print(f"\n  {name}: {url}")
    try:
        t0 = time.time()
        r = requests.get(url, timeout=15, allow_redirects=True,
                        headers={"User-Agent": "Mozilla/5.0"})
        dt = time.time() - t0
        ok = r.status_code in (200, 301, 302)
        record("Donation/Pages", name, r.status_code, 200, dt,
               f"final_url={r.url[:60]}" if r.url != url else "")
    except Exception as e:
        record("Donation/Pages", name, 0, 200, 0, f"ERROR: {str(e)[:60]}")

# Cash App (no web check, just note)
print(f"\n  Cash App: $emergentphysics (app-only, cannot web-test)")
results.append({"stream": "Donation/Pages", "test": "Cash App", "status": "N/A",
                "expected": "N/A", "pass": True, "latency_s": 0, "note": "App-only"})

# ADA wallet (just verify format)
ada = "addr1q9yzzgxt93kdymnkau6ygqwa9qzmjml86pdm73dchj89zech56tdgh2wgu6pdqcf6f0frh84wzerzrwuk836hxfm4x3s03v8tr"
print(f"\n  ADA Wallet: {ada[:20]}...{ada[-10:]}")
ada_ok = ada.startswith("addr1") and len(ada) > 50
results.append({"stream": "Donation/Pages", "test": "ADA Wallet format",
                "status": "valid" if ada_ok else "invalid",
                "expected": "valid", "pass": ada_ok, "latency_s": 0, "note": ""})

# =====================================================================
section("5. REPORT CARD")
# =====================================================================

total = len(results)
passed = sum(1 for r in results if r["pass"])
failed = sum(1 for r in results if not r["pass"])

print(f"\n  Total tests: {total}")
print(f"  Passed: {passed}")
print(f"  Failed: {failed}")
print()

# Group by stream
from collections import defaultdict
by_stream = defaultdict(list)
for r in results:
    by_stream[r["stream"]].append(r)

for stream, tests in by_stream.items():
    p = sum(1 for t in tests if t["pass"])
    f = sum(1 for t in tests if not t["pass"])
    icon = "OK" if f == 0 else "ISSUES"
    print(f"  [{icon}] {stream}: {p}/{len(tests)} passed")
    for t in tests:
        tag = PASS if t["pass"] else FAIL
        print(f"       [{tag}] {t['test']} -> {t['status']} ({t['latency_s']}s) {t.get('note','')}")

print()
if failed > 0:
    print("  FAILURES:")
    for r in results:
        if not r["pass"]:
            print(f"    - {r['stream']}/{r['test']}: got {r['status']}, expected {r['expected']} {r.get('note','')}")

print(f"\n{'='*70}")
print(f"  OVERALL: {passed}/{total} tests passed")
print(f"{'='*70}")
