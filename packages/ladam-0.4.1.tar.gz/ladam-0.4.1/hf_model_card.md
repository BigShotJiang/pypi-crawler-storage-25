---
license: mit
library_name: ladam
tags:
  - optimizer
  - pytorch
  - physics-inspired
  - laplacian
  - adam
  - wave-mechanics
  - normalization
  - pinn
datasets:
  - cifar10
  - fashion_mnist
  - svhn
  - wikitext
metrics:
  - accuracy
  - loss
---

# LAdam Benchmarks: 64-Experiment Validation

**LAdam** (Laplacian Adam) is a physics-inspired optimizer that adds discrete Laplacian regularization to Adam's variance estimate, coupling neighboring weight learning rates through wave mechanics.

## Installation

```bash
pip install ladam
```

## Key Results (80 experiments: 64 original + 16 LAdam battle-test)

| Domain | Best Result | Improvement |
|--------|------------|-------------|
| CNN Denoising (c2=1e-3) | 80% win rate | **Best known LAdam domain** |
| PINN (c2=1e-5) | 70% win rate, -63.3% MSE | **Strong spatial-PDE fit** |
| CNN + ChiAnneal | 73.39% CIFAR-10 | **+5.43%** vs Adam |
| WaveNorm Regression | 0.184 MSE CalHousing | **-13.5%** vs BatchNorm |
| MLP Classification | 90.56% FashionMNIST | **+0.80%** vs Adam |
| Rosenbrock Optimization | 0.0086 loss | **-79.5%** vs Adam |

### Win/Loss/Tie Summary

- **Wins**: CNN denoising, PINNs, super-resolution, segmentation, signal processing
- **Ties**: Classification, regression, time-series (within statistical noise)
- **Losses**: Pure MLP, LLM attention, RL
- **Sweet spot**: Spatially-structured networks (UNet, Conv, PINN) with c2=1e-5 to 1e-3

## When to Use LAdam

**Best for:**
- Physics-Informed Neural Networks (PINNs)
- MLP with neuron reordering + ChiAnnealScheduler
- Regression tasks (especially with WaveNorm)
- Noisy/heterogeneous classification (SVHN, FashionMNIST)

**Not recommended for:**
- LLM fine-tuning (attention weights are unstructured)
- Diffusion models
- Reinforcement learning

## Components

```python
from ladam import LAdam, ChiAnnealScheduler, WaveNorm, WaveNormDamped, ChiNorm
from ladam import compute_neuron_order, reorder_linear_layer

# Optimizer with Laplacian coupling
optimizer = LAdam(model.parameters(), lr=1e-3, c2=1e-4)

# 3-phase schedule: warmup -> constant -> cosine decay
scheduler = ChiAnnealScheduler(optimizer, total_steps=10000)

# Drop-in BatchNorm replacement
norm = WaveNorm(num_features=64)
```

## Benchmark Data

This repository contains:
- `results/` — Raw JSON results from all 55+ experiments
- `checkpoints/` — Model checkpoints from key experiments
- `analysis.md` — Full analysis document with tables and recommendations

## Links

- **PyPI**: [ladam](https://pypi.org/project/ladam/)
- **GitHub**: [gpartin/ladam](https://github.com/gpartin/ladam)
- **Demo**: [emergentphysicslab/ladam-demo](https://huggingface.co/spaces/emergentphysicslab/ladam-demo)

## Citation

```bibtex
@software{partin2026ladam,
  author = {Partin, Greg},
  title = {LAdam: Laplacian Adam Optimizer},
  year = {2026},
  url = {https://github.com/gpartin/ladam}
}
```
