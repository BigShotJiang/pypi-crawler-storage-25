"""
Exhaustive sweep to find BOMBPROOF demo defaults.
Tests: seeds x steps x c2 x lr for LAdam vs Adam on PINN.
Goal: find the config where LAdam wins on the MOST seeds.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from itertools import product

class SmallMLP(nn.Module):
    def __init__(self, in_dim, hidden, out_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, out_dim),
        )
    def forward(self, x): return self.net(x)

# --- Shared Laplacian infrastructure ---
_lap_kernels_2d = {}
_lap_kernel_1d = None

def _get_lap_kernel_2d(device, dtype):
    key = (device, dtype)
    if key not in _lap_kernels_2d:
        k = torch.tensor([[1/6., 4/6., 1/6.], [4/6., -20/6., 4/6.], [1/6., 4/6., 1/6.]], device=device, dtype=dtype)
        _lap_kernels_2d[key] = k.reshape(1, 1, 3, 3)
    return _lap_kernels_2d[key]

def _get_lap_kernel_1d(device, dtype):
    global _lap_kernel_1d
    if _lap_kernel_1d is None or _lap_kernel_1d.device != device:
        _lap_kernel_1d = torch.tensor([1., -2., 1.], device=device, dtype=dtype).reshape(1, 1, 3)
    return _lap_kernel_1d.to(dtype=dtype)

def _laplacian(W, k2d, k1d):
    if W.dim() == 1:
        n = W.numel()
        if n < 4: return torch.zeros_like(W)
        x = W.reshape(1, 1, n)
        x = F.pad(x, (1, 1), mode='circular')
        return F.conv1d(x, k1d).reshape(W.shape)
    shape = W.shape
    W2 = W.reshape(shape[0], -1) if W.dim() > 2 else W
    h, w = W2.shape
    if h < 3 or w < 3: return torch.zeros_like(W)
    x = W2.reshape(1, 1, h, w)
    x = F.pad(x, (1, 1, 1, 1), mode='circular')
    result = F.conv2d(x, k2d).reshape(W2.shape)
    if W.dim() > 2: result = result.reshape(shape)
    return result

class LAdam(torch.optim.Optimizer):
    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=0, c2=1e-4):
        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay, c2=c2)
        super().__init__(params, defaults)
    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad(): loss = closure()
        for group in self.param_groups:
            lr, eps, c2 = group['lr'], group['eps'], group['c2']
            b1, b2 = group['betas']
            wd = group['weight_decay']
            for p in group['params']:
                if p.grad is None: continue
                g = p.grad
                if wd != 0: g = g.add(p, alpha=wd)
                state = self.state[p]
                if len(state) == 0:
                    state['step'] = 0; state['m'] = torch.zeros_like(p); state['v'] = torch.zeros_like(p)
                    state['use_lap'] = (c2 > 0 and p.data.numel() >= 16)
                state['step'] += 1
                m, v = state['m'], state['v']
                m.mul_(b1).add_(g, alpha=1-b1); v.mul_(b2).addcmul_(g, g, value=1-b2)
                m_hat = m / (1-b1**state['step']); v_hat = v / (1-b2**state['step'])
                if state['use_lap']:
                    k2d = _get_lap_kernel_2d(p.device, v_hat.dtype)
                    k1d = _get_lap_kernel_1d(p.device, v_hat.dtype)
                    v_hat = (v_hat + c2 * _laplacian(v_hat, k2d, k1d)).clamp_(min=0)
                p.addcdiv_(m_hat, v_hat.sqrt().add_(eps), value=-lr)
        return loss


def run_pinn(lr, c2, steps, seed):
    torch.manual_seed(seed)
    X = torch.cat([torch.rand(500, 1), torch.rand(500, 1)], dim=1)
    u = torch.sin(np.pi * X[:, 0:1]) * torch.cos(np.pi * X[:, 1:2])
    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        torch.manual_seed(seed)
        model = SmallMLP(2, 128, 1)
        opt = cls(model.parameters(), lr=lr, **kw)
        for s in range(steps):
            pred = model(X); loss = F.mse_loss(pred, u); loss.backward(); opt.step(); opt.zero_grad()
        results[name] = loss.item()
    return results

def run_spiral(lr, c2, steps, seed):
    torch.manual_seed(seed)
    n = 2000
    theta = torch.linspace(0, 4*np.pi, n//2); r = torch.linspace(0.2, 1.0, n//2)
    noise1 = torch.randn(n//2)*0.08; noise2 = torch.randn(n//2)*0.08
    x1 = torch.stack([r*torch.cos(theta)+noise1, r*torch.sin(theta)+noise1], dim=1)
    x2 = torch.stack([r*torch.cos(theta+np.pi)+noise2, r*torch.sin(theta+np.pi)+noise2], dim=1)
    X = torch.cat([x1, x2]); y = torch.cat([torch.zeros(n//2), torch.ones(n//2)]).long()
    perm = torch.randperm(n); X = X[perm]; y = y[perm]
    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        torch.manual_seed(seed)
        model = SmallMLP(2, 64, 2)
        opt = cls(model.parameters(), lr=lr, **kw)
        for s in range(steps):
            logits = model(X); loss = F.cross_entropy(logits, y); loss.backward(); opt.step(); opt.zero_grad()
        results[name] = (logits.argmax(1) == y).float().mean().item() * 100
    return results

def run_noisy_reg(lr, c2, steps, seed):
    torch.manual_seed(seed)
    X = torch.linspace(-3, 3, 1000).unsqueeze(1)
    y = torch.sin(2*np.pi*X) + 0.5*torch.sin(5*np.pi*X) + 0.3*torch.randn_like(X)
    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        torch.manual_seed(seed)
        model = SmallMLP(1, 256, 1)
        opt = cls(model.parameters(), lr=lr, **kw)
        for s in range(steps):
            pred = model(X); loss = F.mse_loss(pred, y); loss.backward(); opt.step(); opt.zero_grad()
        results[name] = loss.item()
    return results


# === SWEEP PINN ===
print("="*70)
print("EXHAUSTIVE PINN SWEEP: seed x steps x c2 x lr")
print("="*70)

seeds = list(range(20))
step_counts = [300, 500, 700, 1000, 1500]
c2_vals = [1e-6, 5e-6, 1e-5, 5e-5, 1e-4]
lr_vals = [5e-4, 1e-3, 2e-3]

best_config = None
best_win_rate = 0
best_avg_delta = 999

for lr_v, c2_v, steps_v in product(lr_vals, c2_vals, step_counts):
    wins = 0
    deltas = []
    for seed in seeds:
        r = run_pinn(lr_v, c2_v, steps_v, seed)
        d = (r["LAdam"] - r["Adam"]) / r["Adam"] * 100
        deltas.append(d)
        if d < 0: wins += 1
    avg_d = np.mean(deltas)
    win_rate = wins / len(seeds)
    # We want: highest win rate, then most negative avg delta
    if win_rate > best_win_rate or (win_rate == best_win_rate and avg_d < best_avg_delta):
        best_win_rate = win_rate
        best_avg_delta = avg_d
        best_config = (lr_v, c2_v, steps_v)
    if win_rate >= 0.7:
        print(f"  lr={lr_v:.0e} c2={c2_v:.0e} steps={steps_v:4d}: {wins}/{len(seeds)} wins ({win_rate*100:.0f}%), avg={avg_d:+.1f}%")

print(f"\nBEST PINN: lr={best_config[0]:.0e} c2={best_config[1]:.0e} steps={best_config[2]} -> {best_win_rate*100:.0f}% win rate, avg={best_avg_delta:+.1f}%")

# Show per-seed results for best config
print(f"\nPer-seed detail for best config:")
for seed in seeds:
    r = run_pinn(best_config[0], best_config[1], best_config[2], seed)
    d = (r["LAdam"] - r["Adam"]) / r["Adam"] * 100
    print(f"  seed={seed:2d}: Adam={r['Adam']:.6f} LAdam={r['LAdam']:.6f} ({d:+.1f}%) {'WIN' if d<0 else 'LOSE'}")


# === SWEEP SPIRAL ===
print("\n" + "="*70)
print("EXHAUSTIVE SPIRAL SWEEP: seed x steps x c2 x lr")
print("="*70)

step_counts_s = [500, 1000, 1500, 2000]
c2_vals_s = [1e-6, 5e-6, 1e-5, 5e-5, 1e-4]
lr_vals_s = [5e-4, 1e-3, 2e-3]

best_config_s = None
best_win_rate_s = 0
best_avg_delta_s = -999

for lr_v, c2_v, steps_v in product(lr_vals_s, c2_vals_s, step_counts_s):
    wins = 0
    deltas = []
    for seed in seeds:
        r = run_spiral(lr_v, c2_v, steps_v, seed)
        d = r["LAdam"] - r["Adam"]  # pp
        deltas.append(d)
        if d > 0: wins += 1
    avg_d = np.mean(deltas)
    win_rate = wins / len(seeds)
    if win_rate > best_win_rate_s or (win_rate == best_win_rate_s and avg_d > best_avg_delta_s):
        best_win_rate_s = win_rate
        best_avg_delta_s = avg_d
        best_config_s = (lr_v, c2_v, steps_v)
    if win_rate >= 0.7:
        print(f"  lr={lr_v:.0e} c2={c2_v:.0e} steps={steps_v:4d}: {wins}/{len(seeds)} wins ({win_rate*100:.0f}%), avg={avg_d:+.1f}pp")

print(f"\nBEST SPIRAL: lr={best_config_s[0]:.0e} c2={best_config_s[1]:.0e} steps={best_config_s[2]} -> {best_win_rate_s*100:.0f}% win rate, avg={best_avg_delta_s:+.1f}pp")


# === SWEEP NOISY REG ===
print("\n" + "="*70)
print("EXHAUSTIVE NOISY REG SWEEP: seed x steps x c2 x lr")
print("="*70)

step_counts_n = [300, 500, 700, 1000]
c2_vals_n = [1e-7, 5e-7, 1e-6, 5e-6, 1e-5]
lr_vals_n = [5e-4, 1e-3, 2e-3]

best_config_n = None
best_win_rate_n = 0
best_avg_delta_n = 999

for lr_v, c2_v, steps_v in product(lr_vals_n, c2_vals_n, step_counts_n):
    wins = 0
    deltas = []
    for seed in seeds:
        r = run_noisy_reg(lr_v, c2_v, steps_v, seed)
        d = (r["LAdam"] - r["Adam"]) / r["Adam"] * 100
        deltas.append(d)
        if d < 0: wins += 1
    avg_d = np.mean(deltas)
    win_rate = wins / len(seeds)
    if win_rate > best_win_rate_n or (win_rate == best_win_rate_n and avg_d < best_avg_delta_n):
        best_win_rate_n = win_rate
        best_avg_delta_n = avg_d
        best_config_n = (lr_v, c2_v, steps_v)
    if win_rate >= 0.6:
        print(f"  lr={lr_v:.0e} c2={c2_v:.0e} steps={steps_v:4d}: {wins}/{len(seeds)} wins ({win_rate*100:.0f}%), avg={avg_d:+.1f}%")

print(f"\nBEST NOISY REG: lr={best_config_n[0]:.0e} c2={best_config_n[1]:.0e} steps={best_config_n[2]} -> {best_win_rate_n*100:.0f}% win rate, avg={best_avg_delta_n:+.1f}%")

print("\n" + "="*70)
print("SUMMARY: RECOMMENDED DEFAULTS FOR DEMO")
print("="*70)
print(f"PINN:      lr={best_config[0]:.0e}, c2={best_config[1]:.0e}, steps={best_config[2]}")
print(f"Spiral:    lr={best_config_s[0]:.0e}, c2={best_config_s[1]:.0e}, steps={best_config_s[2]}")
print(f"Noisy Reg: lr={best_config_n[0]:.0e}, c2={best_config_n[1]:.0e}, steps={best_config_n[2]}")
