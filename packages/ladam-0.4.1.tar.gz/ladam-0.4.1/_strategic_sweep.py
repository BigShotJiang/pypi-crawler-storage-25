"""
STRATEGIC REDESIGN: Find the task+optimizer combo with the LARGEST structural advantage.

Key insight from 50-seed PINN sweep: current PINN task (sin*cos, 128 hidden, 500 steps)
is too EASY -- both optimizers converge well, so LAdam's advantage is noise-level (~50% WR).

Strategy:
1. Try HARDER tasks (higher-frequency target, wider network, more steps)
2. Test ALL 3 optimizer pairs, not just LAdam
3. Find the combo that wins 80%+ of seeds
"""
import torch, torch.nn as nn, torch.nn.functional as F
import numpy as np
import time

class MLP(nn.Module):
    def __init__(self, in_dim, hidden, out_dim, n_layers=3):
        super().__init__()
        layers = [nn.Linear(in_dim, hidden), nn.Tanh()]
        for _ in range(n_layers - 1):
            layers += [nn.Linear(hidden, hidden), nn.Tanh()]
        layers.append(nn.Linear(hidden, out_dim))
        self.net = nn.Sequential(*layers)
    def forward(self, x): return self.net(x)

# --- Laplacian ---
_k2d_cache = {}
_k1d = None
def _get_k2d(dev, dt):
    key = (dev, dt)
    if key not in _k2d_cache:
        k = torch.tensor([[1/6., 4/6., 1/6.], [4/6., -20/6., 4/6.], [1/6., 4/6., 1/6.]], device=dev, dtype=dt)
        _k2d_cache[key] = k.reshape(1, 1, 3, 3)
    return _k2d_cache[key]
def _get_k1d(dev, dt):
    global _k1d
    if _k1d is None or _k1d.device != dev: _k1d = torch.tensor([1., -2., 1.], device=dev, dtype=dt).reshape(1, 1, 3)
    return _k1d.to(dtype=dt)
def _lap(W, k2d, k1d):
    if W.dim() == 1:
        n = W.numel()
        if n < 4: return torch.zeros_like(W)
        x = F.pad(W.reshape(1,1,n), (1,1), mode='circular')
        return F.conv1d(x, k1d).reshape(W.shape)
    shape = W.shape
    W2 = W.reshape(shape[0], -1) if W.dim() > 2 else W
    h, w = W2.shape
    if h < 3 or w < 3: return torch.zeros_like(W)
    x = F.pad(W2.reshape(1,1,h,w), (1,1,1,1), mode='circular')
    r = F.conv2d(x, k2d).reshape(W2.shape)
    return r.reshape(shape) if W.dim() > 2 else r

class LAdam(torch.optim.Optimizer):
    def __init__(s, params, lr=1e-3, betas=(0.9,0.999), eps=1e-8, wd=0, c2=1e-4):
        super().__init__(params, dict(lr=lr, betas=betas, eps=eps, weight_decay=wd, c2=c2))
    @torch.no_grad()
    def step(s, closure=None):
        for g in s.param_groups:
            lr, eps, c2, b1, b2, wd = g['lr'], g['eps'], g['c2'], g['betas'][0], g['betas'][1], g['weight_decay']
            for p in g['params']:
                if p.grad is None: continue
                gr = p.grad if wd == 0 else p.grad.add(p, alpha=wd)
                st = s.state[p]
                if not st: st['step']=0; st['m']=torch.zeros_like(p); st['v']=torch.zeros_like(p); st['use_lap']=(c2>0 and p.numel()>=16)
                st['step'] += 1
                m, v = st['m'], st['v']
                m.mul_(b1).add_(gr, alpha=1-b1); v.mul_(b2).addcmul_(gr, gr, value=1-b2)
                mh = m/(1-b1**st['step']); vh = v/(1-b2**st['step'])
                if st['use_lap']:
                    vh = (vh + c2*_lap(vh, _get_k2d(p.device, vh.dtype), _get_k1d(p.device, vh.dtype))).clamp_(min=0)
                p.addcdiv_(mh, vh.sqrt().add_(eps), value=-lr)

class LRMSProp(torch.optim.Optimizer):
    def __init__(s, params, lr=1e-3, alpha=0.99, eps=1e-8, wd=0, momentum=0, c2=1e-4):
        super().__init__(params, dict(lr=lr, alpha=alpha, eps=eps, weight_decay=wd, momentum=momentum, c2=c2))
    @torch.no_grad()
    def step(s, closure=None):
        for g in s.param_groups:
            lr, al, eps, c2, wd, mom = g['lr'], g['alpha'], g['eps'], g['c2'], g['weight_decay'], g['momentum']
            for p in g['params']:
                if p.grad is None: continue
                gr = p.grad if wd == 0 else p.grad.add(p, alpha=wd)
                st = s.state[p]
                if not st: st['step']=0; st['sq']=torch.zeros_like(p); st['use_lap']=(c2>0 and p.numel()>=16)
                if mom > 0 and 'buf' not in st: st['buf']=torch.zeros_like(p)
                st['step'] += 1
                sq = st['sq']
                sq.mul_(al).addcmul_(gr, gr, value=1-al)
                a = (sq + c2*_lap(sq, _get_k2d(p.device, sq.dtype), _get_k1d(p.device, sq.dtype))).clamp_(min=0) if st['use_lap'] else sq
                if mom > 0:
                    buf = st['buf']; buf.mul_(mom).addcdiv_(gr, a.sqrt().add_(eps)); p.add_(buf, alpha=-lr)
                else:
                    p.addcdiv_(gr, a.sqrt().add_(eps), value=-lr)


def test_config(task_fn, base_cls, enh_cls, base_kw, enh_kw, lr, steps, seeds, higher_better=False):
    """Test one config across seeds. Returns (win_rate, avg_delta, deltas)."""
    wins, deltas = 0, []
    for seed in seeds:
        base_val, enh_val = task_fn(base_cls, enh_cls, base_kw, enh_kw, lr, steps, seed)
        if higher_better:
            d = enh_val - base_val  # positive = win
            if d > 0.1: wins += 1
        else:
            d = (enh_val - base_val) / max(abs(base_val), 1e-12) * 100  # negative = win
            if d < -0.1: wins += 1
        deltas.append(d)
    return wins / len(seeds), np.mean(deltas), deltas


# ============================================================
# Task 1: HARDER PINN (higher frequency, wider net)
# ============================================================
def harder_pinn(base_cls, enh_cls, base_kw, enh_kw, lr, steps, seed):
    torch.manual_seed(seed)
    X = torch.cat([torch.rand(800, 1), torch.rand(800, 1)], dim=1)
    # Harder: sum of multiple frequencies
    u = (torch.sin(2*np.pi*X[:, 0:1]) * torch.cos(2*np.pi*X[:, 1:2])
         + 0.3*torch.sin(4*np.pi*X[:, 0:1]) * torch.cos(4*np.pi*X[:, 1:2]))
    results = []
    for cls, kw in [(base_cls, base_kw), (enh_cls, enh_kw)]:
        torch.manual_seed(seed)
        model = MLP(2, 256, 1, n_layers=4)  # wider + deeper
        opt = cls(model.parameters(), lr=lr, **kw)
        for _ in range(steps):
            pred = model(X); loss = F.mse_loss(pred, u); loss.backward(); opt.step(); opt.zero_grad()
        results.append(loss.item())
    return results[0], results[1]

# Task 2: Original PINN (for comparison)
def original_pinn(base_cls, enh_cls, base_kw, enh_kw, lr, steps, seed):
    torch.manual_seed(seed)
    X = torch.cat([torch.rand(500, 1), torch.rand(500, 1)], dim=1)
    u = torch.sin(np.pi*X[:, 0:1]) * torch.cos(np.pi*X[:, 1:2])
    results = []
    for cls, kw in [(base_cls, base_kw), (enh_cls, enh_kw)]:
        torch.manual_seed(seed)
        model = MLP(2, 128, 1)
        opt = cls(model.parameters(), lr=lr, **kw)
        for _ in range(steps):
            pred = model(X); loss = F.mse_loss(pred, u); loss.backward(); opt.step(); opt.zero_grad()
        results.append(loss.item())
    return results[0], results[1]

# Task 3: Noisy regression with wider net
def noisy_reg(base_cls, enh_cls, base_kw, enh_kw, lr, steps, seed):
    torch.manual_seed(seed)
    x = torch.linspace(-3, 3, 1000).unsqueeze(1)
    y = torch.sin(2*np.pi*x) + 0.5*torch.sin(5*np.pi*x) + 0.3*torch.randn_like(x)
    results = []
    for cls, kw in [(base_cls, base_kw), (enh_cls, enh_kw)]:
        torch.manual_seed(seed)
        model = MLP(1, 256, 1)
        opt = cls(model.parameters(), lr=lr, **kw)
        for _ in range(steps):
            pred = model(x); loss = F.mse_loss(pred, y); loss.backward(); opt.step(); opt.zero_grad()
        results.append(loss.item())
    return results[0], results[1]


seeds = list(range(20))

print("="*70)
print("STRATEGIC SWEEP: Finding best task + optimizer combo")
print(f"Testing across {len(seeds)} seeds each")
print("="*70)

combos = [
    # (name, task_fn, base_cls, enh_cls, enh_kw_key, configs: [(lr, c2, steps)])
    ("LAdam PINN (original)", original_pinn, torch.optim.Adam, LAdam, [
        (1e-3, 1e-6, 500), (1e-3, 1e-5, 500), (1e-3, 1e-6, 1000), (1e-3, 1e-5, 1000),
    ]),
    ("LAdam PINN (HARDER)", harder_pinn, torch.optim.Adam, LAdam, [
        (1e-3, 1e-6, 500), (1e-3, 1e-5, 500), (1e-3, 5e-5, 500),
        (1e-3, 1e-6, 1000), (1e-3, 1e-5, 1000), (1e-3, 5e-5, 1000),
        (5e-4, 1e-5, 1000), (5e-4, 5e-5, 1000),
    ]),
    ("LRMSProp PINN (original)", original_pinn, torch.optim.RMSprop, LRMSProp, [
        (1e-3, 1e-4, 500), (1e-3, 5e-4, 500), (1e-3, 1e-3, 500),
        (1e-3, 1e-4, 1000), (1e-3, 5e-4, 1000), (1e-3, 1e-3, 1000),
    ]),
    ("LRMSProp PINN (HARDER)", harder_pinn, torch.optim.RMSprop, LRMSProp, [
        (1e-3, 1e-4, 500), (1e-3, 5e-4, 500), (1e-3, 1e-3, 500),
        (1e-3, 1e-4, 1000), (1e-3, 5e-4, 1000), (1e-3, 1e-3, 1000),
    ]),
    ("LAdam Noisy Reg", noisy_reg, torch.optim.Adam, LAdam, [
        (1e-3, 1e-6, 500), (1e-3, 5e-6, 500), (1e-3, 1e-5, 500),
        (1e-3, 1e-6, 1000), (1e-3, 5e-6, 1000),
    ]),
    ("LRMSProp Noisy Reg", noisy_reg, torch.optim.RMSprop, LRMSProp, [
        (1e-3, 1e-4, 500), (1e-3, 5e-4, 500),
        (1e-3, 1e-4, 1000), (1e-3, 5e-4, 1000),
    ]),
]

all_results = []
for name, task_fn, base_cls, enh_cls, cfgs in combos:
    print(f"\n--- {name} ---")
    best_wr, best_cfg = 0, None
    for lr, c2, steps in cfgs:
        t0 = time.time()
        wr, avg_d, _ = test_config(task_fn, base_cls, enh_cls, {}, {"c2": c2}, lr, steps, seeds)
        dt = time.time() - t0
        tag = "**" if wr >= 0.7 else ""
        print(f"  lr={lr:.0e} c2={c2:.0e} steps={steps:4d}: {wr*100:5.1f}% WR, avg={avg_d:+6.1f}% {tag} [{dt:.0f}s]")
        if wr > best_wr:
            best_wr = wr
            best_cfg = (lr, c2, steps, avg_d)
    all_results.append((name, best_wr, best_cfg))
    if best_cfg:
        print(f"  >>> Best: lr={best_cfg[0]:.0e} c2={best_cfg[1]:.0e} steps={best_cfg[2]} -> {best_wr*100:.0f}% WR")

print("\n" + "="*70)
print("GLOBAL RANKING (best task+optimizer combo)")
print("="*70)
all_results.sort(key=lambda x: -x[1])
for rank, (name, wr, cfg) in enumerate(all_results):
    if cfg:
        print(f"  #{rank+1}: {name:35s} -> {wr*100:.0f}% WR, lr={cfg[0]:.0e} c2={cfg[1]:.0e} steps={cfg[2]} avg={cfg[3]:+.1f}%")

# Deep test on the #1 combo with 50 seeds
winner = all_results[0]
print(f"\n{'='*70}")
print(f"DEEP TEST: {winner[0]} with {winner[2][0]:.0e}/{winner[2][1]:.0e}/{winner[2][2]}")
print(f"{'='*70}")

# Find which combo this is
for name2, task_fn2, base_cls2, enh_cls2, cfgs2 in combos:
    if name2 == winner[0]:
        lr, c2, steps = winner[2][0], winner[2][1], winner[2][2]
        big_seeds = list(range(50))
        wr, avg_d, deltas = test_config(task_fn2, base_cls2, enh_cls2, {}, {"c2": c2}, lr, steps, big_seeds)
        print(f"  50-seed result: {wr*100:.0f}% WR, avg={avg_d:+.1f}%")
        # List all per-seed results
        for i, d in enumerate(deltas):
            tag = "WIN" if d < -0.1 else "LOSE"
            print(f"    seed={i:2d}: {d:+8.1f}% {tag}")
        break
