---
title: "LAdam: What 64 Experiments Taught Us About Physics-Inspired Optimization"
thumbnail: https://huggingface.co/spaces/emergentphysicslab/ladam-demo/resolve/main/thumbnail.png
authors:
  - user: emergentphysicslab
date: 2026-04-07
tags:
  - optimizer
  - pytorch
  - research
  - physics
  - benchmarks
---

# LAdam: What 64 Experiments Taught Us About Physics-Inspired Optimization

What if your optimizer understood the geometry of your weight space? **LAdam** (Laplacian Adam) couples neighboring learning rates through a discrete Laplacian operator—the same wave-equation physics that governs vibrating membranes. The result: an optimizer that smooths variance estimates across spatially-related parameters, letting nearby weights learn at coordinated rates.

We ran **64 rigorous experiments** across 15+ ML domains to find out when this helps—and when it doesn't. Here's what we learned.

## The Core Idea: One Line of Math

Standard Adam maintains per-parameter variance estimates $v_t$. LAdam adds one term:

$$v_{\text{hat}} \leftarrow v_{\text{hat}} + c_2 \cdot \nabla^2 v_{\text{hat}}$$

where $\nabla^2$ is the discrete Laplacian (a 3×3 convolution with kernel `[[0,1,0],[1,-4,1],[0,1,0]]`) applied to the 2D variance matrix. The coupling strength `c2` (typically 1e-4) controls how much neighboring parameters share learning rate information.

**That's it.** One hyperparameter, three extra lines of code, drop-in replacement for Adam.

```python
pip install ladam

from ladam import LAdam
optimizer = LAdam(model.parameters(), lr=1e-3, c2=1e-4)
```

## The Benchmark: 64 Experiments, 15 Domains

We tested LAdam, WaveNorm (a BatchNorm alternative), ChiAnnealScheduler (a 3-phase LR schedule), and neuron reordering across:

- Image classification (CIFAR-10/100, FashionMNIST, SVHN)
- Regression (CalHousing, WineQuality, Rosenbrock)
- LLM fine-tuning (GPT-2 on WikiText-2)
- Diffusion models (DDPM on CIFAR-10)
- GANs (DCGAN on CIFAR-10)
- Time series (LSTM on ETTm1)
- Audio classification (SpeechCommands)
- Object detection, segmentation, denoising, anomaly detection, RL, recommendations

Every experiment used 3+ random seeds, null hypothesis testing, and LFM-only verification (no external physics injected).

## Where LAdam Wins

| Experiment | Task | Improvement |
|-----------|------|-------------|
| B22 | ResNet-18 + ChiAnneal on CIFAR-10 | **+5.43%** (73.39% vs 67.96%) |
| B10b | MLP + Chi + Reorder on FashionMNIST | **+0.80%** (90.56% vs 89.76%) |
| E2d_v2 | WaveNorm MLP on CalHousing | **-13.5% MSE** (0.184 vs 0.213) |
| E2b | WaveNorm CNN on SVHN | **+0.57%** (92.20% vs 91.63%) |
| E2_E3 | WaveNorm CNN on FashionMNIST | **+0.76%** (91.94% vs 91.18%) |
| A | Rosenbrock optimization | **-79.5% loss** (0.0086 vs 0.042) |

**The pattern**: LAdam excels on problems where weight parameters have spatial structure the Laplacian can exploit—MLP layers (neurons are ordered), channel dimensions (filters are related), and rough loss landscapes (noisy data like SVHN).

## The Secret Weapon: ChiAnnealScheduler

Our best single result came from combining LAdam with a 3-phase chi annealing schedule:

1. **Warmup (5%)**: `c2` ramps from 0 → target (let Adam settle first)
2. **Constant (65%)**: Full wave coupling active (explore)
3. **Cosine decay (30%)**: `c2` decays to 0 (fine-tune with pure Adam)

```python
from ladam import LAdam, ChiAnnealScheduler

optimizer = LAdam(model.parameters(), lr=1e-3, c2=1e-3)
scheduler = ChiAnnealScheduler(optimizer, total_steps=10000)

for step in range(10000):
    loss = train_step()
    scheduler.step()
```

This schedule lets the wave coupling help escape local minima during mid-training, then disabling it lets the optimizer converge cleanly. The result: **+5.43%** on CIFAR-10 with a standard ResNet-18.

## WaveNorm: A Breakout Component

WaveNorm replaces BatchNorm using leapfrog wave-equation dynamics instead of running statistics:

| Dataset | BatchNorm | WaveNorm | Delta |
|---------|-----------|----------|-------|
| FashionMNIST | 91.18% | **91.94%** | +0.76% |
| SVHN | 91.63% | **92.20%** | +0.57% |
| CalHousing MSE | 0.213 | **0.184** | -13.5% |
| CIFAR-10 | **76.81%** | 75.92% | -0.89% |

**Insight**: WaveNorm wins on noisy or non-Gaussian distributed data where BatchNorm's Gaussian assumption breaks down. It loses on clean, well-structured classification where that assumption holds.

```python
from ladam import WaveNorm

# Drop-in replacement for nn.BatchNorm2d
model = nn.Sequential(
    nn.Conv2d(3, 64, 3), WaveNorm(64), nn.ReLU(),
    nn.Conv2d(64, 128, 3), WaveNorm(128), nn.ReLU(),
)
```

## Where LAdam Loses (Honest Assessment)

| Experiment | Task | Result |
|-----------|------|--------|
| B21 | GPT-2 fine-tuning | 1098 ppl vs 152 (catastrophic) |
| B23 | DDPM diffusion | +2.7% worse loss |
| B30 | CartPole RL | -1.7% reward |
| B28 | Object detection | -2.61% mAP |

**Root cause**: The Laplacian assumes spatial locality in weight space. Transformer attention weights, RL policies, and diffusion timestep-conditioned networks violate this assumption. The wave coupling adds noise rather than signal in these architectures.

**Rule of thumb**: If your weights are spatially structured (MLP layers, CNN channels), use LAdam. If they're permutation-invariant (attention, embeddings), stick with Adam.

## Full Toolkit (v0.3.0)

```python
from ladam import (
    LAdam, LAdaGrad, LRMSProp,       # Optimizers
    ChiAnnealScheduler,               # LR scheduling
    WaveNorm, WaveNormDamped, ChiNorm, # Normalization
    compute_neuron_order,              # Neuron reordering
    reorder_linear_layer,
)
```

## Try It Now

- **Interactive demo**: [emergentphysicslab/ladam-demo](https://huggingface.co/spaces/emergentphysicslab/ladam-demo)
- **Benchmark results** (56 JSON files): [emergentphysicslab/ladam-benchmarks](https://huggingface.co/emergentphysicslab/ladam-benchmarks)
- **Install**: `pip install ladam`
- **GitHub**: [gpartin/ladam](https://github.com/gpartin/ladam)
- **PyPI**: [ladam](https://pypi.org/project/ladam/)

## What's Next

- **PDEBench integration**: LAdam as a benchmark optimizer for PDE-solving neural networks ([PR #97](https://github.com/pdebench/PDEBench/pull/97))
- **Auto-tuning**: Automatic `c2` selection based on model architecture analysis
- **Domain-specific schedules**: Noise-conditioned coupling for diffusion, frequency-selective WaveNorm for audio

---

*Built by [Greg Partin](https://github.com/gpartin) at Emergent Physics Lab. LAdam is MIT licensed and free to use.*
