# RapidAPI Listing Guide for LAdam API

## API Base URL
```
https://gpartin--ladam-api-fastapi-app.modal.run
```

## Endpoints to List

### Free Tier
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check |
| `/pricing` | GET | Pricing information |

### Paid Tier ($0.01/call)
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/v1/analyze` | POST | Analyze a model architecture and suggest LAdam c2 values |

### Premium Tier ($0.10/call)
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/v1/benchmark` | POST | Run LAdam vs Adam head-to-head benchmark on GPU |

### Enterprise Tier ($0.25/call)
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/v1/optimize` | POST | Sweep c2 + scheduler configs, return best combination |

## Setup Steps

1. Go to https://rapidapi.com/hub
2. Sign in / Create account
3. Click "My APIs" → "Add New API"
4. Name: `LAdam Optimizer API`
5. Category: `Machine Learning`
6. Description: `Analyze, benchmark, and optimize deep learning models with LAdam — a Laplacian-regularized Adam optimizer. Drop-in replacement for torch.optim.Adam with improved generalization.`
7. Base URL: `https://gpartin--ladam-api-fastapi-app.modal.run`
8. Add endpoints from table above
9. Set pricing plans:
   - **Basic (Free)**: 10 calls/month to /v1/analyze
   - **Pro ($9.99/mo)**: 1000 calls/month to all endpoints
   - **Ultra ($29.99/mo)**: 5000 calls/month, priority GPU

## Authentication
RapidAPI provides its own key management. The Modal API accepts:
- `X-API-Key` header (direct)
- RapidAPI proxy headers (auto-forwarded)

## Test Curl Commands

```bash
# Health check
curl https://gpartin--ladam-api-fastapi-app.modal.run/health

# Analyze (requires API key)
curl -X POST https://gpartin--ladam-api-fastapi-app.modal.run/v1/analyze \
  -H "X-API-Key: YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model_type":"cnn","hidden_size":256,"num_layers":4}'

# Benchmark (requires API key, GPU)
curl -X POST https://gpartin--ladam-api-fastapi-app.modal.run/v1/benchmark \
  -H "X-API-Key: YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model_type":"mlp","hidden_size":128,"num_layers":3,"steps":100}'
```
