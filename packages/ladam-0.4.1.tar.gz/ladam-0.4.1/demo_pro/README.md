---
title: LAdam Pro - Auto-Tuning Optimizer
emoji: ⚡
colorFrom: indigo
colorTo: blue
sdk: gradio
sdk_version: 5.23.0
app_file: app.py
pinned: true
license: mit
short_description: "LAdam optimizer with architecture auto-analysis"
---

# LAdam Pro

Auto-tuning Laplacian Adam optimizer with architecture analysis.

**Features:**
- Architecture analyzer: upload your model or select a built-in one
- Per-layer c2 recommendations based on 64-experiment benchmark
- Live training comparison (PINN, classification, regression)
- Quick start guide with code snippets

`pip install ladam` | [Paper](https://huggingface.co/emergentphysicslab/ladam-benchmarks) | [GitHub](https://github.com/gpartin/ladam)
