"""
LAdam Pro Demo - Hugging Face Spaces
=====================================
Enhanced demo with auto-tuning, architecture analysis, and custom model upload.
Deploy to: https://huggingface.co/spaces/emergentphysicslab/ladam-pro
"""

import gradio as gr
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import io
import traceback

# ---------------------------------------------------------------------------
# Vendor minimal LAdam + auto_configure inline for self-contained Space
# ---------------------------------------------------------------------------

class LAdam(torch.optim.Optimizer):
    """Minimal LAdam for the demo (production version: pip install ladam)."""

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8,
                 weight_decay=0, c2=1e-4):
        defaults = dict(lr=lr, betas=betas, eps=eps,
                        weight_decay=weight_decay, c2=c2)
        super().__init__(params, defaults)
        self._lap_kernels = {}

    def _get_kernel(self, shape, device):
        key = (shape, device)
        if key not in self._lap_kernels:
            k = torch.tensor([[1, 4, 1], [4, -20, 4], [1, 4, 1]],
                             dtype=torch.float32, device=device).reshape(1, 1, 3, 3) / 6.0
            self._lap_kernels[key] = k
        return self._lap_kernels[key]

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()
        for group in self.param_groups:
            lr = group['lr']
            b1, b2 = group['betas']
            eps = group['eps']
            wd = group['weight_decay']
            c2 = group['c2']
            for p in group['params']:
                if p.grad is None:
                    continue
                g = p.grad
                if wd != 0:
                    g = g.add(p, alpha=wd)
                state = self.state[p]
                if len(state) == 0:
                    state['step'] = 0
                    state['m'] = torch.zeros_like(p)
                    state['v'] = torch.zeros_like(p)
                state['step'] += 1
                m, v = state['m'], state['v']
                m.mul_(b1).add_(g, alpha=1 - b1)
                v.mul_(b2).addcmul_(g, g, value=1 - b2)
                bc1 = 1 - b1 ** state['step']
                bc2 = 1 - b2 ** state['step']
                m_hat = m / bc1
                v_hat = v / bc2
                if c2 > 0 and v_hat.dim() >= 2 and v_hat.shape[-1] >= 3 and v_hat.shape[-2] >= 3:
                    orig = v_hat.shape
                    v2d = v_hat.reshape(1, 1, orig[-2], orig[-1])
                    kernel = self._get_kernel(v2d.shape, v2d.device)
                    lap = F.conv2d(F.pad(v2d, (1, 1, 1, 1), mode='circular'), kernel)
                    v_hat = (v_hat + c2 * lap.reshape(orig)).clamp_(min=0)
                p.addcdiv_(m_hat, v_hat.sqrt().add_(eps), value=-lr)
        return loss


# ---------------------------------------------------------------------------
# Architecture analysis (vendored from ladam.auto)
# ---------------------------------------------------------------------------

_ATTENTION_NAMES = frozenset({
    "self_attn", "multihead_attn", "attention", "attn",
    "q_proj", "k_proj", "v_proj", "out_proj",
    "query", "key", "value",
})

_NORM_TYPES = (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d,
               nn.LayerNorm, nn.GroupNorm)

_C2_MAP = {
    "linear": 1e-5, "conv": 0.0, "attention": 0.0,
    "norm": 0.0, "embedding": 0.0, "bias": 0.0, "other": 0.0,
}


def _is_attention_param(name):
    parts = name.lower().split(".")
    return any(p in _ATTENTION_NAMES for p in parts)


def _classify_param(name, param, module_map):
    if param.ndim <= 1:
        return "bias"
    if _is_attention_param(name):
        return "attention"
    prefix = ".".join(name.split(".")[:-1])
    mod = module_map.get(prefix)
    if isinstance(mod, (nn.Conv1d, nn.Conv2d, nn.Conv3d)):
        return "conv"
    if isinstance(mod, _NORM_TYPES):
        return "norm"
    if isinstance(mod, nn.Embedding):
        return "embedding"
    if isinstance(mod, nn.Linear):
        return "linear"
    if param.ndim >= 3:
        return "conv"
    if param.ndim == 2:
        return "linear"
    return "other"


def analyze_model_report(model):
    """Return a formatted markdown report of model analysis."""
    module_map = dict(model.named_modules())
    layer_counts = {}
    layer_params = {}

    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        cat = _classify_param(name, param, module_map)
        layer_counts[cat] = layer_counts.get(cat, 0) + 1
        layer_params[cat] = layer_params.get(cat, 0) + param.numel()

    # Detect architecture
    param_names = {n for n, _ in model.named_parameters()}
    module_types = {type(m).__name__.lower() for m in model.modules()}
    has_attention = any(_is_attention_param(n) for n in param_names) or \
                    any("attention" in t or "transformer" in t for t in module_types)
    has_conv = any(isinstance(m, (nn.Conv1d, nn.Conv2d, nn.Conv3d)) for m in model.modules())
    has_rnn = any(isinstance(m, (nn.RNN, nn.LSTM, nn.GRU)) for m in model.modules())
    arch = "transformer" if has_attention else "rnn" if has_rnn else "cnn" if has_conv else "mlp"

    total = sum(layer_params.values())
    active = [k for k, v in _C2_MAP.items() if v > 0 and k in layer_counts]
    active_p = sum(layer_params.get(k, 0) for k in active)
    pct = (100.0 * active_p / total) if total > 0 else 0.0

    # Build report
    lines = []
    lines.append(f"## Architecture Analysis")
    lines.append(f"")
    lines.append(f"**Detected architecture**: `{arch}`")
    lines.append(f"**Total trainable parameters**: {total:,}")
    lines.append(f"**LAdam-suitable parameters**: {active_p:,} ({pct:.1f}%)")
    lines.append(f"")
    lines.append(f"### Layer Breakdown")
    lines.append(f"")
    lines.append(f"| Layer Type | Count | Parameters | Recommended c2 |")
    lines.append(f"|------------|-------|------------|----------------|")
    for cat in sorted(layer_counts.keys()):
        c2 = _C2_MAP.get(cat, 0.0)
        c2_str = f"`{c2:.0e}`" if c2 > 0 else "0 (skip)"
        lines.append(f"| {cat} | {layer_counts[cat]} | {layer_params[cat]:,} | {c2_str} |")

    lines.append(f"")
    lines.append(f"### Recommendation")
    lines.append(f"")
    if pct >= 50:
        lines.append(f"**Strong candidate for LAdam.** {pct:.0f}% of parameters have spatial "
                      f"structure that benefits from Laplacian coupling.")
        lines.append(f"")
        lines.append(f"```python")
        lines.append(f"from ladam import auto_configure")
        lines.append(f"optimizer, scheduler = auto_configure(model, lr=1e-3, total_steps=N)")
        lines.append(f"```")
    elif pct >= 10:
        lines.append(f"**Mixed candidate.** {pct:.0f}% of parameters suit LAdam. "
                      f"Use `auto_configure()` for per-layer c2 assignment.")
        lines.append(f"")
        lines.append(f"```python")
        lines.append(f"from ladam import auto_configure")
        lines.append(f"optimizer, scheduler = auto_configure(model, lr=1e-3, total_steps=N)")
        lines.append(f"```")
    else:
        lines.append(f"**Not recommended for LAdam.** Only {pct:.0f}% of parameters have "
                      f"suitable structure. Standard Adam is likely better.")
        lines.append(f"")
        lines.append(f"```python")
        lines.append(f"optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)")
        lines.append(f"```")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Training tasks (same as free demo + enhancements)
# ---------------------------------------------------------------------------

class SmallMLP(nn.Module):
    def __init__(self, in_dim, hidden, out_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, out_dim),
        )

    def forward(self, x):
        return self.net(x)


def make_pinn_data(n=500):
    x = torch.rand(n, 1)
    t = torch.rand(n, 1)
    u_true = torch.sin(np.pi * x) * torch.cos(np.pi * t)
    return torch.cat([x, t], dim=1), u_true


def make_classification_data(n=2000):
    theta = torch.linspace(0, 4 * np.pi, n // 2)
    r = torch.linspace(0.2, 1.0, n // 2)
    noise = torch.randn(n // 2) * 0.08
    x1 = torch.stack([r * torch.cos(theta) + noise,
                       r * torch.sin(theta) + noise], dim=1)
    noise = torch.randn(n // 2) * 0.08
    x2 = torch.stack([r * torch.cos(theta + np.pi) + noise,
                       r * torch.sin(theta + np.pi) + noise], dim=1)
    X = torch.cat([x1, x2], dim=0)
    y = torch.cat([torch.zeros(n // 2), torch.ones(n // 2)]).long()
    perm = torch.randperm(n)
    return X[perm], y[perm]


def make_regression_data(n=500):
    """Noisy sine regression (WaveNorm sweet spot)."""
    x = torch.rand(n, 3) * 4 - 2
    y = (torch.sin(x[:, 0] * 2) + torch.cos(x[:, 1] * x[:, 2])
         + torch.randn(n) * 0.3).unsqueeze(1)
    return x, y


def run_training(task, lr, c2, steps, seed):
    """Main training comparison."""
    lr, c2, steps, seed = float(lr), float(c2), int(steps), int(seed)

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    if task == "PINN (Wave Equation)":
        torch.manual_seed(seed)
        X, u_true = make_pinn_data(500)
        results = {}
        for name, opt_cls, kw in [("Adam", torch.optim.Adam, {}),
                                    ("LAdam", LAdam, {"c2": c2})]:
            torch.manual_seed(seed)
            model = SmallMLP(2, 128, 1)
            opt = opt_cls(model.parameters(), lr=lr, **kw)
            losses = []
            for s in range(steps):
                pred = model(X)
                loss = F.mse_loss(pred, u_true)
                loss.backward(); opt.step(); opt.zero_grad()
                if s % max(1, steps // 200) == 0:
                    losses.append(loss.item())
            results[name] = losses

        for name, losses in results.items():
            xs = np.linspace(0, steps, len(losses))
            axes[0].semilogy(xs, losses, label=name, linewidth=2)
        axes[0].set_xlabel("Step"); axes[0].set_ylabel("MSE Loss (log)")
        axes[0].set_title("PINN: Wave Equation"); axes[0].legend()

        # Final comparison
        final_adam = results["Adam"][-1]
        final_ladam = results["LAdam"][-1]
        improvement = (final_adam - final_ladam) / final_adam * 100
        bars = axes[1].bar(["Adam", "LAdam"], [final_adam, final_ladam],
                           color=["#ff7f0e", "#1f77b4"])
        axes[1].set_ylabel("Final MSE Loss")
        axes[1].set_title(f"Final Loss ({improvement:+.1f}% improvement)")
        summary = f"PINN: LAdam final loss {final_ladam:.6f} vs Adam {final_adam:.6f} ({improvement:+.1f}%)"

    elif task == "Spiral Classification":
        torch.manual_seed(seed)
        X, y = make_classification_data(2000)
        results = {}
        for name, opt_cls, kw in [("Adam", torch.optim.Adam, {}),
                                    ("LAdam", LAdam, {"c2": c2})]:
            torch.manual_seed(seed)
            model = SmallMLP(2, 64, 2)
            opt = opt_cls(model.parameters(), lr=lr, **kw)
            losses, accs = [], []
            for s in range(steps):
                logits = model(X)
                loss = F.cross_entropy(logits, y)
                loss.backward(); opt.step(); opt.zero_grad()
                if s % max(1, steps // 200) == 0:
                    losses.append(loss.item())
                    accs.append((logits.argmax(1) == y).float().mean().item() * 100)
            results[name] = {"loss": losses, "acc": accs}

        for name, data in results.items():
            xs = np.linspace(0, steps, len(data["loss"]))
            axes[0].plot(xs, data["loss"], label=name, linewidth=2)
        axes[0].set_xlabel("Step"); axes[0].set_ylabel("Loss")
        axes[0].set_title("Cross-Entropy Loss"); axes[0].legend()
        for name, data in results.items():
            xs = np.linspace(0, steps, len(data["acc"]))
            axes[1].plot(xs, data["acc"], label=name, linewidth=2)
        axes[1].set_xlabel("Step"); axes[1].set_ylabel("Accuracy (%)")
        axes[1].set_title("Accuracy"); axes[1].legend()
        summary = (f"Spiral: Adam {results['Adam']['acc'][-1]:.1f}% vs "
                    f"LAdam {results['LAdam']['acc'][-1]:.1f}%")

    elif task == "Noisy Regression":
        torch.manual_seed(seed)
        X, y = make_regression_data(500)
        results = {}
        for name, opt_cls, kw in [("Adam", torch.optim.Adam, {}),
                                    ("LAdam", LAdam, {"c2": c2})]:
            torch.manual_seed(seed)
            model = SmallMLP(3, 64, 1)
            opt = opt_cls(model.parameters(), lr=lr, **kw)
            losses = []
            for s in range(steps):
                pred = model(X)
                loss = F.mse_loss(pred, y)
                loss.backward(); opt.step(); opt.zero_grad()
                if s % max(1, steps // 200) == 0:
                    losses.append(loss.item())
            results[name] = losses

        for name, losses in results.items():
            xs = np.linspace(0, steps, len(losses))
            axes[0].semilogy(xs, losses, label=name, linewidth=2)
        axes[0].set_xlabel("Step"); axes[0].set_ylabel("MSE (log)")
        axes[0].set_title("Noisy Regression"); axes[0].legend()
        final_adam = results["Adam"][-1]
        final_ladam = results["LAdam"][-1]
        improvement = (final_adam - final_ladam) / final_adam * 100
        axes[1].bar(["Adam", "LAdam"], [final_adam, final_ladam],
                     color=["#ff7f0e", "#1f77b4"])
        axes[1].set_ylabel("Final MSE"); axes[1].set_title(f"{improvement:+.1f}% improvement")
        summary = f"Regression: LAdam {final_ladam:.4f} vs Adam {final_adam:.4f} ({improvement:+.1f}%)"

    else:
        summary = "Unknown task"

    plt.tight_layout()
    return fig, summary


def analyze_uploaded_model(model_file):
    """Analyze an uploaded .pt model file."""
    if model_file is None:
        return "Please upload a PyTorch model file (.pt or .pth)."
    try:
        # Try loading as full model first, then as state_dict
        try:
            model = torch.load(model_file.name, map_location="cpu", weights_only=False)
            if isinstance(model, dict):
                return ("Uploaded file appears to be a state_dict, not a full model.\n"
                        "Please save with `torch.save(model, 'model.pt')` (not `model.state_dict()`).\n\n"
                        f"Keys found: {list(model.keys())[:10]}...")
            if not isinstance(model, nn.Module):
                return f"Loaded object is {type(model).__name__}, not nn.Module."
        except Exception as e:
            return f"Failed to load model: {e}"

        report = analyze_model_report(model)
        return report
    except Exception as e:
        return f"Error analyzing model:\n```\n{traceback.format_exc()}\n```"


def analyze_builtin_model(arch_name):
    """Analyze a built-in architecture."""
    if arch_name == "MLP (784 -> 256 -> 10)":
        model = nn.Sequential(nn.Linear(784, 256), nn.ReLU(),
                              nn.Linear(256, 128), nn.ReLU(),
                              nn.Linear(128, 10))
    elif arch_name == "CNN (CIFAR-10 style)":
        model = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Flatten(),
            nn.Linear(64 * 8 * 8, 256), nn.ReLU(),
            nn.Linear(256, 10))
    elif arch_name == "Transformer (small)":
        model = nn.Transformer(d_model=128, nhead=4, num_encoder_layers=2,
                                num_decoder_layers=2, dim_feedforward=256,
                                batch_first=True)
    elif arch_name == "LSTM (sequence)":
        class LSTMModel(nn.Module):
            def __init__(self):
                super().__init__()
                self.lstm = nn.LSTM(64, 128, num_layers=2, batch_first=True)
                self.fc = nn.Linear(128, 10)
            def forward(self, x):
                out, _ = self.lstm(x)
                return self.fc(out[:, -1])
        model = LSTMModel()
    else:
        return "Unknown architecture."

    return analyze_model_report(model)


# ---------------------------------------------------------------------------
# Gradio app
# ---------------------------------------------------------------------------

with gr.Blocks(
    title="LAdam Pro - Auto-Tuning Optimizer",
    theme=gr.themes.Soft(),
) as demo:
    gr.Markdown("""
    # LAdam Pro: Laplacian-Coupled Adaptive Learning Rates

    **Auto-tuning optimizer with architecture analysis.**
    Analyze your model to get per-layer c2 recommendations, then run live training comparisons.

    `pip install ladam` (v0.4.0) | [Paper](https://huggingface.co/emergentphysicslab/ladam-benchmarks) | [GitHub](https://github.com/gpartin/ladam)
    """)

    with gr.Tabs():
        # Tab 1: Architecture Analyzer
        with gr.TabItem("Architecture Analyzer"):
            gr.Markdown("### Analyze your model architecture for LAdam compatibility")

            with gr.Row():
                with gr.Column(scale=1):
                    gr.Markdown("**Option A: Built-in architectures**")
                    arch_dropdown = gr.Dropdown(
                        choices=["MLP (784 -> 256 -> 10)",
                                 "CNN (CIFAR-10 style)",
                                 "Transformer (small)",
                                 "LSTM (sequence)"],
                        label="Select architecture",
                        value="MLP (784 -> 256 -> 10)")
                    analyze_btn = gr.Button("Analyze", variant="primary")

                with gr.Column(scale=1):
                    gr.Markdown("**Option B: Upload your model**")
                    model_upload = gr.File(label="Upload .pt model file",
                                           file_types=[".pt", ".pth"])
                    upload_btn = gr.Button("Analyze uploaded model")

            analysis_output = gr.Markdown(label="Analysis Report")

            analyze_btn.click(analyze_builtin_model, inputs=[arch_dropdown],
                              outputs=[analysis_output])
            upload_btn.click(analyze_uploaded_model, inputs=[model_upload],
                             outputs=[analysis_output])

        # Tab 2: Live Training
        with gr.TabItem("Live Training Comparison"):
            gr.Markdown("### Compare LAdam vs Adam on training tasks")

            with gr.Row():
                task = gr.Dropdown(
                    choices=["PINN (Wave Equation)",
                             "Spiral Classification",
                             "Noisy Regression"],
                    label="Task", value="PINN (Wave Equation)")
                lr = gr.Number(label="Learning Rate", value=1e-3,
                               minimum=1e-6, maximum=1.0)
                c2 = gr.Number(label="c2 (coupling)", value=1e-4,
                               minimum=0, maximum=0.1)

            with gr.Row():
                steps = gr.Slider(label="Steps", minimum=100, maximum=5000,
                                   value=1000, step=100)
                seed = gr.Number(label="Random Seed", value=42,
                                  minimum=0, maximum=9999)

            train_btn = gr.Button("Run Comparison", variant="primary")
            plot_output = gr.Plot(label="Training Curves")
            summary_output = gr.Textbox(label="Summary", interactive=False)

            train_btn.click(run_training,
                            inputs=[task, lr, c2, steps, seed],
                            outputs=[plot_output, summary_output])

        # Tab 3: Quick Start
        with gr.TabItem("Quick Start Guide"):
            gr.Markdown("""
            ### Installation

            ```bash
            pip install ladam
            ```

            ### Basic Usage (drop-in Adam replacement)

            ```python
            from ladam import LAdam

            optimizer = LAdam(model.parameters(), lr=1e-3, c2=1e-5)
            ```

            ### Auto-Configured (recommended)

            ```python
            from ladam.auto import auto_configure

            optimizer, scheduler = auto_configure(
                model,
                lr=1e-3,
                total_epochs=100,
                steps_per_epoch=len(train_loader),
            )

            for batch in train_loader:
                loss = train_step(model, batch)
                loss.backward()
                optimizer.step()
                optimizer.zero_grad()
                if scheduler:
                    scheduler.step()
            ```

            ### When LAdam Helps Most

            | Domain | Result | Evidence |
            |--------|--------|----------|
            | PINNs | -44.6% L2 error | Physics-informed neural networks |
            | Structured MLPs | +5.43% accuracy | With ChiAnnealScheduler |
            | Regression | -13.5% MSE | With WaveNorm normalization |
            | Image Classification | +0.80% accuracy | FashionMNIST MLP |

            ### When to Use Standard Adam Instead

            - LLM fine-tuning (attention layers lack spatial structure)
            - Diffusion models
            - Reinforcement learning policies
            - Audio classification
            """)

demo.launch()
