"""
KEY HYPOTHESIS: LAdam's advantage is REGULARIZATION.
Current demo evaluates on train data = hides the advantage.
Test: evaluate on CLEAN data (noise-free) to reveal generalization gap.
"""
import torch, torch.nn as nn, torch.nn.functional as F
import numpy as np, time

_k2d_cache = {}
def _get_k2d(d, t):
    key = (d, t)
    if key not in _k2d_cache:
        k = torch.tensor([[1/6., 4/6., 1/6.], [4/6., -20/6., 4/6.], [1/6., 4/6., 1/6.]], dtype=t)
        _k2d_cache[key] = k.reshape(1, 1, 3, 3)
    return _k2d_cache[key]
_k1d_cache = {}
def _get_k1d(d, t):
    key = (d, t)
    if key not in _k1d_cache:
        _k1d_cache[key] = torch.tensor([1., -2., 1.], dtype=t).reshape(1, 1, 3)
    return _k1d_cache[key]
def _lap(W):
    k2d = _get_k2d(W.device, W.dtype)
    k1d = _get_k1d(W.device, W.dtype)
    if W.dim() == 1:
        n = W.numel()
        if n < 4: return torch.zeros_like(W)
        x = F.pad(W.reshape(1,1,n), (1,1), mode='circular')
        return F.conv1d(x, k1d).reshape(W.shape)
    shape = W.shape; W2 = W.reshape(shape[0], -1) if W.dim() > 2 else W
    h, w = W2.shape
    if h < 3 or w < 3: return torch.zeros_like(W)
    x = F.pad(W2.reshape(1,1,h,w), (1,1,1,1), mode='circular')
    r = F.conv2d(x, k2d).reshape(W2.shape)
    return r.reshape(shape) if W.dim() > 2 else r

class LAdam(torch.optim.Optimizer):
    def __init__(s, params, lr=1e-3, betas=(0.9,0.999), eps=1e-8, c2=1e-4):
        super().__init__(params, dict(lr=lr, betas=betas, eps=eps, c2=c2))
    @torch.no_grad()
    def step(s, closure=None):
        for g in s.param_groups:
            lr, eps, c2, b1, b2 = g['lr'], g['eps'], g['c2'], g['betas'][0], g['betas'][1]
            for p in g['params']:
                if p.grad is None: continue
                gr = p.grad
                st = s.state[p]
                if not st: st['step']=0; st['m']=torch.zeros_like(p); st['v']=torch.zeros_like(p); st['use_lap']=(c2>0 and p.numel()>=16)
                st['step'] += 1
                m, v = st['m'], st['v']
                m.mul_(b1).add_(gr, alpha=1-b1); v.mul_(b2).addcmul_(gr, gr, value=1-b2)
                mh = m/(1-b1**st['step']); vh = v/(1-b2**st['step'])
                if st['use_lap']:
                    vh = (vh + c2*_lap(vh)).clamp_(min=0)
                p.addcdiv_(mh, vh.sqrt().add_(eps), value=-lr)

class SmallMLP(nn.Module):
    def __init__(self, d_in, hidden, d_out):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_in, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, d_out))
    def forward(self, x): return self.net(x)


def test_generalization(lr, c2, steps, seed, hidden=256, noise=0.3, n_train=1000, n_test=500):
    """
    Train on noisy data, evaluate on CLEAN data.
    Shows whether LAdam regularizes better = less overfitting.
    """
    # Training data: noisy
    torch.manual_seed(seed)
    x_train = torch.linspace(-3, 3, n_train).unsqueeze(1)
    y_clean_train = torch.sin(2*np.pi*x_train) + 0.5*torch.sin(5*np.pi*x_train)
    y_noisy = y_clean_train + noise * torch.randn_like(x_train)

    # Test data: clean, on different points
    x_test = torch.linspace(-2.99, 2.99, n_test).unsqueeze(1)  # slightly offset
    y_test = torch.sin(2*np.pi*x_test) + 0.5*torch.sin(5*np.pi*x_test)

    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        torch.manual_seed(seed)
        model = SmallMLP(1, hidden, 1)
        opt = cls(model.parameters(), lr=lr, **kw)
        train_losses, test_rmses = [], []
        for step in range(steps):
            pred = model(x_train)
            loss = F.mse_loss(pred, y_noisy)
            loss.backward()
            opt.step()
            opt.zero_grad()
            if step % max(1, steps//100) == 0:
                train_losses.append(loss.item())
                with torch.no_grad():
                    test_pred = model(x_test)
                    test_rmse = torch.sqrt(F.mse_loss(test_pred, y_test)).item()
                    test_rmses.append(test_rmse)
        
        with torch.no_grad():
            final_train_loss = F.mse_loss(model(x_train), y_noisy).item()
            final_test_rmse = torch.sqrt(F.mse_loss(model(x_test), y_test)).item()
            final_clean_rmse = torch.sqrt(F.mse_loss(model(x_train), y_clean_train)).item()
        results[name] = {
            'train_loss': final_train_loss,
            'test_rmse': final_test_rmse,
            'clean_rmse': final_clean_rmse,
            'test_curve': test_rmses,
        }
    return results


def test_train_test_split(lr, c2, steps, seed, hidden=256):
    """Train/test split: train on 80%, eval on 20%."""
    torch.manual_seed(seed)
    n = 1000
    x = torch.linspace(-3, 3, n).unsqueeze(1)
    y = torch.sin(2*np.pi*x) + 0.5*torch.sin(5*np.pi*x) + 0.3*torch.randn_like(x)
    
    # 80/20 split
    idx = torch.randperm(n)
    n_train = 800
    x_train, y_train = x[idx[:n_train]], y[idx[:n_train]]
    x_test, y_test = x[idx[n_train:]], y[idx[n_train:]]

    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        torch.manual_seed(seed)
        model = SmallMLP(1, hidden, 1)
        opt = cls(model.parameters(), lr=lr, **kw)
        for step in range(steps):
            pred = model(x_train)
            loss = F.mse_loss(pred, y_train)
            loss.backward()
            opt.step()
            opt.zero_grad()
        with torch.no_grad():
            train_rmse = torch.sqrt(F.mse_loss(model(x_train), y_train)).item()
            test_rmse = torch.sqrt(F.mse_loss(model(x_test), y_test)).item()
        results[name] = {'train_rmse': train_rmse, 'test_rmse': test_rmse}
    return results


# ===== TEST 1: Clean evaluation (generalization) =====
print("="*70, flush=True)
print("TEST 1: Noisy training, CLEAN evaluation (generalization test)")
print("="*70, flush=True)

N = 20
print(f"\n{'c2':>8s} {'steps':>5s} {'H':>4s} {'noise':>5s} | {'WR_test':>7s} {'avg_test':>8s} | {'WR_train':>8s} {'avg_train':>9s}", flush=True)
print("-"*75, flush=True)

configs = [
    # c2, steps, hidden, noise
    (1e-5,  500, 256, 0.3),
    (5e-5,  500, 256, 0.3),
    (1e-4,  500, 256, 0.3),
    (5e-4,  500, 256, 0.3),
    (1e-3,  500, 256, 0.3),
    (1e-4,  1000, 256, 0.3),
    (5e-4,  1000, 256, 0.3),
    (1e-3,  1000, 256, 0.3),
    # Higher noise
    (1e-4,  500, 256, 0.5),
    (5e-4,  500, 256, 0.5),
    (1e-3,  500, 256, 0.5),
    # Even higher noise
    (1e-4,  500, 256, 1.0),
    (5e-4,  500, 256, 1.0),
    (1e-3,  500, 256, 1.0),
]

best_wr, best_cfg = 0, None
for c2, steps, hidden, noise in configs:
    test_wins, train_wins, test_deltas, train_deltas = 0, 0, [], []
    t0 = time.time()
    for seed in range(N):
        r = test_generalization(1e-3, c2, steps, seed, hidden=hidden, noise=noise)
        # Test: clean RMSE (generalization)
        td = (r['LAdam']['test_rmse'] - r['Adam']['test_rmse']) / max(r['Adam']['test_rmse'], 1e-12) * 100
        test_deltas.append(td)
        if td < -0.1: test_wins += 1
        # Train: training loss (fitting)
        trd = (r['LAdam']['train_loss'] - r['Adam']['train_loss']) / max(r['Adam']['train_loss'], 1e-12) * 100
        train_deltas.append(trd)
        if trd < -0.1: train_wins += 1
    
    test_wr = test_wins / N
    train_wr = train_wins / N
    dt = time.time() - t0
    tag = " ***" if test_wr >= 0.80 else (" **" if test_wr >= 0.70 else (" *" if test_wr >= 0.60 else ""))
    print(f"  {c2:.0e} {steps:5d} {hidden:4d} {noise:5.1f} | {test_wr*100:5.1f}% {np.mean(test_deltas):+7.1f}% | {train_wr*100:6.1f}% {np.mean(train_deltas):+8.1f}%{tag} [{dt:.0f}s]", flush=True)
    if test_wr > best_wr or (test_wr == best_wr and np.mean(test_deltas) < (best_cfg[5] if best_cfg else 0)):
        best_wr = test_wr
        best_cfg = (c2, steps, hidden, noise, test_wr, np.mean(test_deltas))

if best_cfg:
    print(f"\nBest: c2={best_cfg[0]:.0e} steps={best_cfg[1]} h={best_cfg[2]} noise={best_cfg[3]} -> {best_cfg[4]*100:.0f}% WR, avg={best_cfg[5]:+.1f}%", flush=True)

# ===== TEST 2: Train/test split =====
print("\n" + "="*70, flush=True)
print("TEST 2: 80/20 train/test split", flush=True)
print("="*70, flush=True)

print(f"\n{'c2':>8s} {'steps':>5s} | {'WR_test':>7s} {'avg_test':>8s} | {'WR_train':>8s} {'avg_train':>9s}", flush=True)
print("-"*60, flush=True)

for c2 in [1e-5, 1e-4, 5e-4, 1e-3]:
    for steps in [500, 1000]:
        test_wins, train_wins, test_deltas, train_deltas = 0, 0, [], []
        for seed in range(N):
            r = test_train_test_split(1e-3, c2, steps, seed)
            td = (r['LAdam']['test_rmse'] - r['Adam']['test_rmse']) / max(r['Adam']['test_rmse'], 1e-12) * 100
            test_deltas.append(td)
            if td < -0.1: test_wins += 1
            trd = (r['LAdam']['train_rmse'] - r['Adam']['train_rmse']) / max(r['Adam']['train_rmse'], 1e-12) * 100
            train_deltas.append(trd)
            if trd < -0.1: train_wins += 1
        test_wr = test_wins / N
        train_wr = train_wins / N
        tag = " ***" if test_wr >= 0.80 else (" **" if test_wr >= 0.70 else (" *" if test_wr >= 0.60 else ""))
        print(f"  {c2:.0e} {steps:5d} | {test_wr*100:5.1f}% {np.mean(test_deltas):+7.1f}% | {train_wr*100:6.1f}% {np.mean(train_deltas):+8.1f}%{tag}", flush=True)

print("\nDONE", flush=True)
