"""Quick sweep: find best c2 for Noisy Regression at seed=42"""
import torch, torch.nn as nn, torch.nn.functional as F, numpy as np

class SmallMLP(nn.Module):
    def __init__(self, d_in, h, d_out):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_in, h), nn.Tanh(),
            nn.Linear(h, h), nn.Tanh(),
            nn.Linear(h, h), nn.Tanh(),
            nn.Linear(h, d_out))
    def forward(self, x): return self.net(x)

_k2d_cache = {}
def _get_k2d(d, t):
    key = (d, t)
    if key not in _k2d_cache:
        k = torch.tensor([[1/6., 4/6., 1/6.], [4/6., -20/6., 4/6.], [1/6., 4/6., 1/6.]], dtype=t)
        _k2d_cache[key] = k.reshape(1, 1, 3, 3)
    return _k2d_cache[key]

_k1d_cache = {}
def _get_k1d(d, t):
    key = (d, t)
    if key not in _k1d_cache:
        _k1d_cache[key] = torch.tensor([1., -2., 1.], dtype=t).reshape(1, 1, 3)
    return _k1d_cache[key]

def _lap(W):
    k2d = _get_k2d(W.device, W.dtype)
    k1d = _get_k1d(W.device, W.dtype)
    if W.dim() == 1:
        n = W.numel()
        if n < 4:
            return torch.zeros_like(W)
        x = F.pad(W.reshape(1, 1, n), (1, 1), mode='circular')
        return F.conv1d(x, k1d).reshape(W.shape)
    shape = W.shape
    W2 = W.reshape(shape[0], -1) if W.dim() > 2 else W
    h, w = W2.shape
    if h < 3 or w < 3:
        return torch.zeros_like(W)
    x = F.pad(W2.reshape(1, 1, h, w), (1, 1, 1, 1), mode='circular')
    r = F.conv2d(x, k2d).reshape(W2.shape)
    return r.reshape(shape) if W.dim() > 2 else r

class LAdam(torch.optim.Optimizer):
    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, c2=1e-4):
        super().__init__(params, dict(lr=lr, betas=betas, eps=eps, c2=c2))

    @torch.no_grad()
    def step(self, closure=None):
        for g in self.param_groups:
            lr, eps, c2 = g['lr'], g['eps'], g['c2']
            b1, b2 = g['betas']
            for p in g['params']:
                if p.grad is None:
                    continue
                gr = p.grad
                st = self.state[p]
                if not st:
                    st['step'] = 0
                    st['m'] = torch.zeros_like(p)
                    st['v'] = torch.zeros_like(p)
                    st['use_lap'] = (c2 > 0 and p.numel() >= 16)
                st['step'] += 1
                m, v = st['m'], st['v']
                m.mul_(b1).add_(gr, alpha=1 - b1)
                v.mul_(b2).addcmul_(gr, gr, value=1 - b2)
                mh = m / (1 - b1 ** st['step'])
                vh = v / (1 - b2 ** st['step'])
                if st['use_lap']:
                    vh = (vh + c2 * _lap(vh)).clamp_(min=0)
                p.addcdiv_(mh, vh.sqrt().add_(eps), value=-lr)


def run_one(seed, lr, c2, steps, hidden=256):
    torch.manual_seed(seed)
    x = torch.linspace(-3, 3, 1000).unsqueeze(1)
    y_clean = torch.sin(2 * np.pi * x) + 0.5 * torch.sin(5 * np.pi * x)
    rng = torch.Generator().manual_seed(seed + 1000)
    y_noisy = y_clean + 0.3 * torch.randn(x.shape, generator=rng)

    results = {}
    for name, cls, kw in [
        ('Adam', torch.optim.Adam, {}),
        ('LAdam', LAdam, {'c2': c2}),
    ]:
        torch.manual_seed(seed)
        model = SmallMLP(1, hidden, 1)
        opt = cls(model.parameters(), lr=lr, **kw)
        for _ in range(steps):
            loss = F.mse_loss(model(x), y_noisy)
            loss.backward()
            opt.step()
            opt.zero_grad()
        results[name] = F.mse_loss(model(x), y_noisy).item()
    return results


# ---- Main sweep ----
print("=" * 70)
print("NOISY REGRESSION c2 SWEEP -- seed=42, lr=1e-3, 500 steps, h=256")
print("=" * 70)

c2_values = [0, 1e-7, 1e-6, 5e-6, 1e-5, 5e-5, 1e-4, 5e-4, 1e-3]
print(f"{'c2':>10s}  {'Adam':>10s}  {'LAdam':>10s}  {'Delta':>8s}  Winner")
print("-" * 60)

for c2 in c2_values:
    r = run_one(42, 1e-3, c2, 500, 256)
    delta = (r['LAdam'] - r['Adam']) / r['Adam'] * 100
    w = 'LAdam' if delta < -0.1 else ('Adam' if delta > 0.1 else 'TIE')
    print(f"{c2:10.1e}  {r['Adam']:10.6f}  {r['LAdam']:10.6f}  {delta:+7.1f}%  {w}")

# Also try different LR values
print()
print("=" * 70)
print("NOISY REGRESSION LR SWEEP -- seed=42, c2=1e-5, 500 steps, h=256")
print("=" * 70)
lr_values = [3e-4, 5e-4, 7e-4, 1e-3, 2e-3, 3e-3, 5e-3]
print(f"{'lr':>10s}  {'Adam':>10s}  {'LAdam':>10s}  {'Delta':>8s}  Winner")
print("-" * 60)

for lr in lr_values:
    r = run_one(42, lr, 1e-5, 500, 256)
    delta = (r['LAdam'] - r['Adam']) / r['Adam'] * 100
    w = 'LAdam' if delta < -0.1 else ('Adam' if delta > 0.1 else 'TIE')
    print(f"{lr:10.1e}  {r['Adam']:10.6f}  {r['LAdam']:10.6f}  {delta:+7.1f}%  {w}")

# And smaller hidden sizes (like the demo PINN uses h=64)
print()
print("=" * 70)
print("NOISY REGRESSION HIDDEN SIZE SWEEP -- seed=42, c2=1e-5, lr=1e-3, 500 steps")
print("=" * 70)
h_values = [32, 64, 128, 256, 512]
print(f"{'hidden':>10s}  {'Adam':>10s}  {'LAdam':>10s}  {'Delta':>8s}  Winner")
print("-" * 60)

for h in h_values:
    r = run_one(42, 1e-3, 1e-5, 500, h)
    delta = (r['LAdam'] - r['Adam']) / r['Adam'] * 100
    w = 'LAdam' if delta < -0.1 else ('Adam' if delta > 0.1 else 'TIE')
    print(f"{h:10d}  {r['Adam']:10.6f}  {r['LAdam']:10.6f}  {delta:+7.1f}%  {w}")

# Multi-seed check for the best config found
print()
print("=" * 70)
print("MULTI-SEED CHECK -- top NR configs across seeds 0-19")
print("=" * 70)

# We'll test a few promising configs
configs = [
    (1e-3, 1e-5, 500, 256),
    (1e-3, 5e-6, 500, 256),
    (1e-3, 1e-4, 500, 256),
    (5e-4, 1e-5, 500, 256),
    (1e-3, 1e-5, 500, 64),
]

for lr, c2, steps, hidden in configs:
    wins = 0
    total = 20
    deltas = []
    for seed in range(total):
        r = run_one(seed, lr, c2, steps, hidden)
        d = (r['LAdam'] - r['Adam']) / r['Adam'] * 100
        deltas.append(d)
        if d < -0.1:
            wins += 1
    wr = wins / total * 100
    avg_d = np.mean(deltas)
    print(f"lr={lr:.0e} c2={c2:.0e} h={hidden:3d} steps={steps}: WR={wr:.0f}%  avg_delta={avg_d:+.1f}%  seed42={deltas[42] if 42 < total else 'N/A'}")

print("\nDone.")
