"""
TRUE PINN: Physics-informed loss with PDE residual.
Hypothesis: PDE residual creates STRUCTURED gradients that Laplacian should smooth well.

PDE: u_tt = u_xx on [0,1]x[0,1]
BC: u(0,t) = u(1,t) = 0
IC: u(x,0) = sin(pi*x), u_t(x,0) = 0
Exact: u(x,t) = sin(pi*x)*cos(pi*t)

Loss = MSE(PDE_residual, 0) + lambda * MSE(BC_residual, 0) + lambda * MSE(IC, known)
"""
import torch, torch.nn as nn, torch.nn.functional as F
import numpy as np
import time

class SirenLayer(nn.Module):
    """Sinusoidal activation - great for PINNs."""
    def __init__(self, in_f, out_f, w0=30.0, is_first=False):
        super().__init__()
        self.linear = nn.Linear(in_f, out_f)
        self.w0 = w0
        b = 1/in_f if is_first else np.sqrt(6/in_f)/w0
        nn.init.uniform_(self.linear.weight, -b, b)
    def forward(self, x):
        return torch.sin(self.w0 * self.linear(x))

class SIREN(nn.Module):
    def __init__(self, in_dim, hidden, out_dim, n_layers=3, w0=30.0):
        super().__init__()
        layers = [SirenLayer(in_dim, hidden, w0=w0, is_first=True)]
        for _ in range(n_layers - 1):
            layers.append(SirenLayer(hidden, hidden, w0=w0))
        layers.append(nn.Linear(hidden, out_dim))
        # small init for final layer
        nn.init.uniform_(layers[-1].weight, -np.sqrt(6/hidden)/w0, np.sqrt(6/hidden)/w0)
        self.net = nn.Sequential(*layers)
    def forward(self, x):
        return self.net(x)

class MLP(nn.Module):
    def __init__(self, in_dim, hidden, out_dim, n_layers=3):
        super().__init__()
        layers = [nn.Linear(in_dim, hidden), nn.Tanh()]
        for _ in range(n_layers - 1):
            layers += [nn.Linear(hidden, hidden), nn.Tanh()]
        layers.append(nn.Linear(hidden, out_dim))
        self.net = nn.Sequential(*layers)
    def forward(self, x): return self.net(x)

_k2d_cache = {}; _k1d = None
def _get_k2d(d, t):
    key = (d, t)
    if key not in _k2d_cache:
        k = torch.tensor([[1/6., 4/6., 1/6.], [4/6., -20/6., 4/6.], [1/6., 4/6., 1/6.]], device=d, dtype=t)
        _k2d_cache[key] = k.reshape(1, 1, 3, 3)
    return _k2d_cache[key]
def _get_k1d(d, t):
    global _k1d
    if _k1d is None or _k1d.device != d: _k1d = torch.tensor([1., -2., 1.], device=d, dtype=t).reshape(1, 1, 3)
    return _k1d.to(dtype=t)
def _lap(W, k2d, k1d):
    if W.dim() == 1:
        n = W.numel()
        if n < 4: return torch.zeros_like(W)
        x = F.pad(W.reshape(1,1,n), (1,1), mode='circular')
        return F.conv1d(x, k1d).reshape(W.shape)
    shape = W.shape; W2 = W.reshape(shape[0], -1) if W.dim() > 2 else W
    h, w = W2.shape
    if h < 3 or w < 3: return torch.zeros_like(W)
    x = F.pad(W2.reshape(1,1,h,w), (1,1,1,1), mode='circular')
    r = F.conv2d(x, _get_k2d(W.device, W.dtype)).reshape(W2.shape)
    return r.reshape(shape) if W.dim() > 2 else r

class LAdam(torch.optim.Optimizer):
    def __init__(s, params, lr=1e-3, betas=(0.9,0.999), eps=1e-8, weight_decay=0, c2=1e-4):
        super().__init__(params, dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay, c2=c2))
    @torch.no_grad()
    def step(s, closure=None):
        for g in s.param_groups:
            lr, eps, c2, b1, b2 = g['lr'], g['eps'], g['c2'], g['betas'][0], g['betas'][1]
            for p in g['params']:
                if p.grad is None: continue
                gr = p.grad
                st = s.state[p]
                if not st: st['step']=0; st['m']=torch.zeros_like(p); st['v']=torch.zeros_like(p); st['use_lap']=(c2>0 and p.numel()>=16)
                st['step'] += 1
                m, v = st['m'], st['v']
                m.mul_(b1).add_(gr, alpha=1-b1); v.mul_(b2).addcmul_(gr, gr, value=1-b2)
                mh = m/(1-b1**st['step']); vh = v/(1-b2**st['step'])
                if st['use_lap']:
                    vh = (vh + c2*_lap(vh, _get_k2d(p.device, vh.dtype), _get_k1d(p.device, vh.dtype))).clamp_(min=0)
                p.addcdiv_(mh, vh.sqrt().add_(eps), value=-lr)


def train_true_pinn(lr, c2, steps, seed, hidden=128, lam_bc=10.0, lam_ic=10.0):
    """Train a REAL PINN: minimize PDE residual + BC + IC."""
    n_interior = 500
    n_bc = 50
    n_ic = 100

    torch.manual_seed(seed)
    # Interior points
    x_int = torch.rand(n_interior, 1, requires_grad=True)
    t_int = torch.rand(n_interior, 1, requires_grad=True)
    # BC: u(0,t)=0, u(1,t)=0
    t_bc = torch.rand(n_bc, 1)
    x_bc0 = torch.zeros(n_bc, 1)
    x_bc1 = torch.ones(n_bc, 1)
    # IC: u(x,0) = sin(pi*x), u_t(x,0) = 0
    x_ic = torch.rand(n_ic, 1, requires_grad=True)
    t_ic = torch.zeros(n_ic, 1, requires_grad=True)
    u_ic_true = torch.sin(np.pi * x_ic.detach())

    # Evaluation points (to measure actual error)
    x_eval, t_eval = torch.meshgrid(torch.linspace(0, 1, 50), torch.linspace(0, 1, 50), indexing='ij')
    x_eval = x_eval.reshape(-1, 1); t_eval = t_eval.reshape(-1, 1)
    u_exact_eval = torch.sin(np.pi * x_eval) * torch.cos(np.pi * t_eval)

    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        torch.manual_seed(seed)
        model = MLP(2, hidden, 1, n_layers=4)
        opt = cls(model.parameters(), lr=lr, **kw)

        for s in range(steps):
            # PDE residual: u_tt - u_xx = 0
            xt_int = torch.cat([x_int, t_int], dim=1)
            u = model(xt_int)
            
            # First derivatives
            du = torch.autograd.grad(u, [x_int, t_int], grad_outputs=torch.ones_like(u),
                                      create_graph=True)
            u_x, u_t = du[0], du[1]
            # Second derivatives
            u_xx = torch.autograd.grad(u_x, x_int, grad_outputs=torch.ones_like(u_x),
                                        create_graph=True)[0]
            u_tt = torch.autograd.grad(u_t, t_int, grad_outputs=torch.ones_like(u_t),
                                        create_graph=True)[0]
            pde_residual = u_tt - u_xx
            loss_pde = F.mse_loss(pde_residual, torch.zeros_like(pde_residual))

            # BC loss
            u_bc0 = model(torch.cat([x_bc0, t_bc], dim=1))
            u_bc1 = model(torch.cat([x_bc1, t_bc], dim=1))
            loss_bc = F.mse_loss(u_bc0, torch.zeros_like(u_bc0)) + F.mse_loss(u_bc1, torch.zeros_like(u_bc1))

            # IC loss
            xt_ic = torch.cat([x_ic, t_ic], dim=1)
            u_ic = model(xt_ic)
            loss_ic = F.mse_loss(u_ic, u_ic_true)
            # Also u_t(x,0) = 0
            u_t_ic = torch.autograd.grad(u_ic, t_ic, grad_outputs=torch.ones_like(u_ic),
                                          create_graph=True)[0]
            loss_ic_t = F.mse_loss(u_t_ic, torch.zeros_like(u_t_ic))

            loss = loss_pde + lam_bc * loss_bc + lam_ic * (loss_ic + loss_ic_t)
            loss.backward()
            opt.step()
            opt.zero_grad()

        # Evaluate on grid
        with torch.no_grad():
            u_pred = model(torch.cat([x_eval, t_eval], dim=1))
            l2_error = torch.sqrt(F.mse_loss(u_pred, u_exact_eval)).item()
        results[name] = l2_error
    return results


print("="*70)
print("TRUE PINN TEST: PDE residual loss (u_tt = u_xx)")
print("="*70)

seeds = list(range(20))

# Test across c2 values and step counts
print("\n--- MLP (128-hidden, 4-layer), lr=1e-3 ---")
for c2 in [1e-6, 5e-6, 1e-5, 5e-5, 1e-4, 5e-4, 1e-3]:
    for steps in [500, 1000]:
        wins, deltas = 0, []
        t0 = time.time()
        for seed in seeds:
            r = train_true_pinn(1e-3, c2, steps, seed, hidden=128)
            d = (r["LAdam"] - r["Adam"]) / max(r["Adam"], 1e-12) * 100
            deltas.append(d)
            if d < -0.1: wins += 1
        avg_d = np.mean(deltas)
        wr = wins / len(seeds)
        dt = time.time() - t0
        tag = " ***" if wr >= 0.75 else (" **" if wr >= 0.65 else "")
        if wr >= 0.5 or c2 in [1e-5, 1e-4]:
            print(f"  c2={c2:.0e} steps={steps:4d}: {wr*100:5.1f}% WR, avg={avg_d:+6.1f}%{tag} [{dt:.0f}s]")

# Also try 256-hidden
print("\n--- MLP (256-hidden, 4-layer), lr=1e-3 ---")
for c2 in [1e-5, 5e-5, 1e-4, 5e-4]:
    for steps in [500, 1000]:
        wins, deltas = 0, []
        t0 = time.time()
        for seed in seeds:
            r = train_true_pinn(1e-3, c2, steps, seed, hidden=256)
            d = (r["LAdam"] - r["Adam"]) / max(r["Adam"], 1e-12) * 100
            deltas.append(d)
            if d < -0.1: wins += 1
        avg_d = np.mean(deltas)
        wr = wins / len(seeds)
        dt = time.time() - t0
        tag = " ***" if wr >= 0.75 else (" **" if wr >= 0.65 else "")
        if wr >= 0.4:
            print(f"  c2={c2:.0e} steps={steps:4d}: {wr*100:5.1f}% WR, avg={avg_d:+6.1f}%{tag} [{dt:.0f}s]")

print("\n" + "="*70)
print("DONE - True PINN test complete")
print("="*70)
