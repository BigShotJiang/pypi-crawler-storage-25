"""
KEY INSIGHT: Full-batch training = deterministic gradients = no noise for Laplacian to smooth.
Mini-batch training = noisy gradients = Laplacian smoothing HELPS.

This test validates: does mini-batching unlock LAdam's real advantage?
Also tests larger c2 values since mini-batch noise is larger.
"""
import torch, torch.nn as nn, torch.nn.functional as F
import numpy as np
import time

class MLP(nn.Module):
    def __init__(self, in_dim, hidden, out_dim, n_layers=3):
        super().__init__()
        layers = [nn.Linear(in_dim, hidden), nn.Tanh()]
        for _ in range(n_layers - 1):
            layers += [nn.Linear(hidden, hidden), nn.Tanh()]
        layers.append(nn.Linear(hidden, out_dim))
        self.net = nn.Sequential(*layers)
    def forward(self, x): return self.net(x)

_k2d_cache = {}; _k1d = None
def _get_k2d(d, t):
    key = (d, t)
    if key not in _k2d_cache:
        k = torch.tensor([[1/6., 4/6., 1/6.], [4/6., -20/6., 4/6.], [1/6., 4/6., 1/6.]], device=d, dtype=t)
        _k2d_cache[key] = k.reshape(1, 1, 3, 3)
    return _k2d_cache[key]
def _get_k1d(d, t):
    global _k1d
    if _k1d is None or _k1d.device != d: _k1d = torch.tensor([1., -2., 1.], device=d, dtype=t).reshape(1, 1, 3)
    return _k1d.to(dtype=t)
def _lap(W, k2d, k1d):
    if W.dim() == 1:
        n = W.numel()
        if n < 4: return torch.zeros_like(W)
        x = F.pad(W.reshape(1,1,n), (1,1), mode='circular')
        return F.conv1d(x, k1d).reshape(W.shape)
    shape = W.shape; W2 = W.reshape(shape[0], -1) if W.dim() > 2 else W
    h, w = W2.shape
    if h < 3 or w < 3: return torch.zeros_like(W)
    x = F.pad(W2.reshape(1,1,h,w), (1,1,1,1), mode='circular')
    r = F.conv2d(x, _get_k2d(W.device, W.dtype)).reshape(W2.shape)
    return r.reshape(shape) if W.dim() > 2 else r

class LAdam(torch.optim.Optimizer):
    def __init__(s, params, lr=1e-3, betas=(0.9,0.999), eps=1e-8, weight_decay=0, c2=1e-4):
        super().__init__(params, dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay, c2=c2))
    @torch.no_grad()
    def step(s, closure=None):
        for g in s.param_groups:
            lr, eps, c2, b1, b2 = g['lr'], g['eps'], g['c2'], g['betas'][0], g['betas'][1]
            for p in g['params']:
                if p.grad is None: continue
                gr = p.grad
                st = s.state[p]
                if not st: st['step']=0; st['m']=torch.zeros_like(p); st['v']=torch.zeros_like(p); st['use_lap']=(c2>0 and p.numel()>=16)
                st['step'] += 1
                m, v = st['m'], st['v']
                m.mul_(b1).add_(gr, alpha=1-b1); v.mul_(b2).addcmul_(gr, gr, value=1-b2)
                mh = m/(1-b1**st['step']); vh = v/(1-b2**st['step'])
                if st['use_lap']:
                    vh = (vh + c2*_lap(vh, _get_k2d(p.device, vh.dtype), _get_k1d(p.device, vh.dtype))).clamp_(min=0)
                p.addcdiv_(mh, vh.sqrt().add_(eps), value=-lr)


# ============================================================
# Test A: PINN with mini-batching
# ============================================================
def train_pinn_minibatch(lr, c2, steps, seed, batch_size=64):
    n_data = 2000
    torch.manual_seed(seed)
    X_full = torch.cat([torch.rand(n_data, 1), torch.rand(n_data, 1)], dim=1)
    u_full = (torch.sin(2*np.pi*X_full[:, 0:1]) * torch.cos(2*np.pi*X_full[:, 1:2])
              + 0.3*torch.sin(4*np.pi*X_full[:, 0:1]) * torch.cos(4*np.pi*X_full[:, 1:2]))
    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        torch.manual_seed(seed)
        model = MLP(2, 256, 1, n_layers=4)
        opt = cls(model.parameters(), lr=lr, **kw)
        for s in range(steps):
            idx = torch.randint(0, n_data, (batch_size,))
            X, u = X_full[idx], u_full[idx]
            pred = model(X); loss = F.mse_loss(pred, u); loss.backward(); opt.step(); opt.zero_grad()
        # Eval on full dataset
        with torch.no_grad():
            final_loss = F.mse_loss(model(X_full), u_full).item()
        results[name] = final_loss
    return results


# ============================================================
# Test B: Noisy regression with mini-batching
# ============================================================
def train_noisy_minibatch(lr, c2, steps, seed, batch_size=64):
    n_data = 2000
    torch.manual_seed(seed)
    x_full = torch.linspace(-3, 3, n_data).unsqueeze(1)
    y_full = torch.sin(2*np.pi*x_full) + 0.5*torch.sin(5*np.pi*x_full) + 0.3*torch.randn_like(x_full)
    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        torch.manual_seed(seed)
        model = MLP(1, 256, 1, n_layers=3)
        opt = cls(model.parameters(), lr=lr, **kw)
        for s in range(steps):
            idx = torch.randint(0, n_data, (batch_size,))
            pred = model(x_full[idx]); loss = F.mse_loss(pred, y_full[idx])
            loss.backward(); opt.step(); opt.zero_grad()
        with torch.no_grad():
            final_loss = F.mse_loss(model(x_full), y_full).item()
        results[name] = final_loss
    return results


# ============================================================
# Test C: Spiral with mini-batching
# ============================================================
def train_spiral_minibatch(lr, c2, steps, seed, batch_size=128):
    n = 4000
    torch.manual_seed(seed)
    th = torch.linspace(0, 4*np.pi, n//2); r = torch.linspace(0.2, 1.0, n//2)
    n1 = torch.randn(n//2)*0.08; n2 = torch.randn(n//2)*0.08
    x1 = torch.stack([r*torch.cos(th)+n1, r*torch.sin(th)+n1], dim=1)
    x2 = torch.stack([r*torch.cos(th+np.pi)+n2, r*torch.sin(th+np.pi)+n2], dim=1)
    X = torch.cat([x1, x2]); y = torch.cat([torch.zeros(n//2), torch.ones(n//2)]).long()
    perm = torch.randperm(n); X = X[perm]; y = y[perm]
    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        torch.manual_seed(seed)
        model = MLP(2, 128, 2, n_layers=3)
        opt = cls(model.parameters(), lr=lr, **kw)
        for s in range(steps):
            idx = torch.randint(0, n, (batch_size,))
            lo = model(X[idx]); loss = F.cross_entropy(lo, y[idx])
            loss.backward(); opt.step(); opt.zero_grad()
        with torch.no_grad():
            logits = model(X)
            acc = (logits.argmax(1) == y).float().mean().item() * 100
        results[name] = acc
    return results


print("="*70)
print("MINI-BATCH HYPOTHESIS TEST: Does stochastic gradient noise unlock LAdam?")
print("="*70)

seeds = list(range(20))

# Test A: PINN mini-batch
print("\n--- PINN (mini-batch, 256-wide, 4-layer) ---")
for c2 in [1e-5, 5e-5, 1e-4, 5e-4, 1e-3]:
    for steps in [500, 1000]:
        for bs in [32, 64, 128]:
            wins, deltas = 0, []
            t0 = time.time()
            for seed in seeds:
                r = train_pinn_minibatch(1e-3, c2, steps, seed, batch_size=bs)
                d = (r["LAdam"] - r["Adam"]) / max(r["Adam"], 1e-12) * 100
                deltas.append(d)
                if d < -0.1: wins += 1
            avg_d = np.mean(deltas)
            wr = wins / len(seeds)
            dt = time.time() - t0
            tag = " ***" if wr >= 0.75 else (" **" if wr >= 0.65 else "")
            if wr >= 0.5:
                print(f"  c2={c2:.0e} bs={bs:3d} steps={steps:4d}: {wr*100:5.1f}% WR, avg={avg_d:+6.1f}%{tag} [{dt:.0f}s]")

# Test B: Noisy regression mini-batch
print("\n--- Noisy Regression (mini-batch, 256-wide) ---")
for c2 in [1e-5, 5e-5, 1e-4, 5e-4, 1e-3]:
    for steps in [500, 1000]:
        for bs in [32, 64]:
            wins, deltas = 0, []
            t0 = time.time()
            for seed in seeds:
                r = train_noisy_minibatch(1e-3, c2, steps, seed, batch_size=bs)
                d = (r["LAdam"] - r["Adam"]) / max(r["Adam"], 1e-12) * 100
                deltas.append(d)
                if d < -0.1: wins += 1
            avg_d = np.mean(deltas)
            wr = wins / len(seeds)
            dt = time.time() - t0
            tag = " ***" if wr >= 0.75 else (" **" if wr >= 0.65 else "")
            if wr >= 0.5:
                print(f"  c2={c2:.0e} bs={bs:3d} steps={steps:4d}: {wr*100:5.1f}% WR, avg={avg_d:+6.1f}%{tag} [{dt:.0f}s]")

# Test C: Spiral mini-batch
print("\n--- Spiral Classification (mini-batch) ---")
for c2 in [1e-5, 5e-5, 1e-4, 5e-4, 1e-3]:
    for steps in [500, 1000]:
        for bs in [64, 128]:
            wins, deltas = 0, []
            t0 = time.time()
            for seed in seeds:
                r = train_spiral_minibatch(1e-3, c2, steps, seed, batch_size=bs)
                d = r["LAdam"] - r["Adam"]
                deltas.append(d)
                if d > 0.1: wins += 1
            avg_d = np.mean(deltas)
            wr = wins / len(seeds)
            dt = time.time() - t0
            tag = " ***" if wr >= 0.75 else (" **" if wr >= 0.65 else "")
            if wr >= 0.5:
                print(f"  c2={c2:.0e} bs={bs:3d} steps={steps:4d}: {wr*100:5.1f}% WR, avg={avg_d:+6.2f}pp{tag} [{dt:.0f}s]")

print("\n" + "="*70)
print("DONE")
print("="*70)
