"""Upload LAdam benchmark results to HuggingFace Dataset repo."""
import json
import os
import glob
import shutil
from pathlib import Path

EXP6_DIR = r"c:\Papers\lfm_ml_experiments\exp6_validation"
EARLIER_DIRS = [
    r"c:\Papers\lfm_ml_experiments\exp1_optimizer",
    r"c:\Papers\lfm_ml_experiments\exp2_weight_init",
    r"c:\Papers\lfm_ml_experiments\exp3_pinn_reg",
    r"c:\Papers\lfm_ml_experiments\exp4_sparse_attention",
    r"c:\Papers\lfm_ml_experiments\exp5_convergence_paper",
    r"c:\Papers\lfm_ml_experiments\wave_transformer",
]
STAGING = Path(r"c:\Papers\_ladam_repo\_dataset_staging")

def consolidate():
    """Build a consolidated summary + copy raw JSONs."""
    STAGING.mkdir(exist_ok=True)
    raw_dir = STAGING / "raw"
    raw_dir.mkdir(exist_ok=True)

    all_results = []

    # Exp6 (main campaign)
    for f in sorted(glob.glob(os.path.join(EXP6_DIR, "results_*.json"))):
        name = os.path.basename(f)
        shutil.copy2(f, raw_dir / name)
        with open(f) as fh:
            data = json.load(fh)
        exp_id = name.replace("results_", "").replace(".json", "")
        # Handle both dict (optimizer->results) and list (array of run dicts) formats
        if isinstance(data, list):
            for i, item in enumerate(data):
                if isinstance(item, dict):
                    opt_name = item.get("name", item.get("optimizer", f"run_{i}"))
                    row = {"experiment": exp_id, "optimizer": opt_name, "campaign": "exp6_validation"}
                    for k in ["best_acc", "final_loss", "verdict", "winner",
                               "best_test_acc", "final_test_loss", "final_test",
                               "late_avg", "epochs", "epochs_run",
                               "best_metric", "metric_name"]:
                        if k in item:
                            row[k] = item[k]
                    if "test_acc_history" in item and isinstance(item["test_acc_history"], list):
                        row["history_steps"] = len(item["test_acc_history"])
                    all_results.append(row)
        elif isinstance(data, dict):
            for opt_name, opt_data in data.items():
                if isinstance(opt_data, dict):
                    row = {"experiment": exp_id, "optimizer": opt_name, "campaign": "exp6_validation"}
                    for k in ["best_acc", "final_loss", "verdict", "winner",
                               "best_test_acc", "final_test_loss", "epochs",
                               "best_metric", "metric_name"]:
                        if k in opt_data:
                            row[k] = opt_data[k]
                    if "history" in opt_data and isinstance(opt_data["history"], list):
                        row["history_steps"] = len(opt_data["history"])
                    all_results.append(row)

    # Earlier experiments
    for d in EARLIER_DIRS:
        if not os.path.isdir(d):
            continue
        for f in sorted(glob.glob(os.path.join(d, "results_*.json"))):
            name = os.path.basename(f)
            shutil.copy2(f, raw_dir / name)
            with open(f) as fh:
                data = json.load(fh)
            exp_id = name.replace("results_", "").replace(".json", "")
            campaign = os.path.basename(d)
            if isinstance(data, list):
                for i, item in enumerate(data):
                    if isinstance(item, dict):
                        opt_name = item.get("name", item.get("optimizer", f"run_{i}"))
                        row = {"experiment": exp_id, "optimizer": opt_name, "campaign": campaign}
                        for k in ["best_acc", "final_loss", "verdict", "winner",
                                   "best_test_acc", "final_test_loss", "epochs"]:
                            if k in item:
                                row[k] = item[k]
                        all_results.append(row)
            elif isinstance(data, dict):
                for opt_name, opt_data in data.items():
                    if isinstance(opt_data, dict):
                        row = {"experiment": exp_id, "optimizer": opt_name, "campaign": campaign}
                        for k in ["best_acc", "final_loss", "verdict", "winner",
                                   "best_test_acc", "final_test_loss", "epochs"]:
                            if k in opt_data:
                                row[k] = opt_data[k]
                        all_results.append(row)

    # Write consolidated summary
    with open(STAGING / "benchmark_summary.json", "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"Consolidated {len(all_results)} optimizer runs")
    print(f"Raw JSONs copied: {len(list(raw_dir.glob('*.json')))}")
    return all_results


def upload_to_hf():
    """Upload to HuggingFace as a dataset repo."""
    from huggingface_hub import HfApi

    api = HfApi()
    repo_id = "emergentphysicslab/ladam-benchmark-traces"

    # Create dataset repo
    api.create_repo(repo_id, repo_type="dataset", exist_ok=True)

    # Upload everything in staging
    api.upload_folder(
        folder_path=str(STAGING),
        repo_id=repo_id,
        repo_type="dataset",
    )
    print(f"Uploaded to https://huggingface.co/datasets/{repo_id}")


if __name__ == "__main__":
    # Write a README for the dataset
    readme = """---
license: mit
task_categories:
  - tabular-classification
tags:
  - optimizer
  - benchmark
  - pytorch
  - ladam
  - deep-learning
pretty_name: LAdam Optimizer Benchmark Traces
size_categories:
  - 1K<n<10K
---

# LAdam Benchmark Traces

Training curves and metrics from the **64-experiment LAdam validation campaign**.

## Overview

This dataset contains the raw training metrics comparing **LAdam** (Laplacian Adam) against standard Adam
across 8 ML task domains, 3 seeds each, with statistical significance testing.

**LAdam**: A drop-in Adam replacement that applies discrete Laplacian regularization to the
second-moment estimate. `pip install ladam` | [GitHub](https://github.com/gpartin/ladam)

## Dataset Structure

- `benchmark_summary.json` - Consolidated table of all optimizer runs with key metrics
- `raw/results_*.json` - Per-experiment detailed results with full epoch-by-epoch training curves

## Experiments

| Domain | Tasks | Key Finding |
|--------|-------|-------------|
| PINNs / Scientific ML | Wave equation | LAdam -44.6% L2 error |
| Image Classification | FashionMNIST, CIFAR-10, SVHN | LAdam +0.8% to +5.4% accuracy |
| Transformers | FashionMNIST Transformer | LAdam +0.20% accuracy |
| Segmentation | VOC 2012 DeepLabV3 | LAdam +0.21% mIoU |
| Normalization | WaveNorm vs BatchNorm | WaveNorm -13.5% MSE (regression) |
| Detection | Faster R-CNN | Adam wins (-2.6% mAP) |
| Audio | VGGish | Adam wins (-0.86%) |
| Language | GPT-2 | Adam wins |

**Win rate on decisive results: 10/22 = 45%**

## Citation

```bibtex
@software{partin2026ladam,
  author = {Partin, Greg},
  title = {LAdam: Spatially-Aware Adaptive Optimization via Laplacian-Regularized Variance Estimates},
  year = {2026},
  url = {https://github.com/gpartin/ladam}
}
```
"""
    STAGING.mkdir(exist_ok=True)
    with open(STAGING / "README.md", "w", encoding="utf-8") as f:
        f.write(readme)

    results = consolidate()
    upload_to_hf()
