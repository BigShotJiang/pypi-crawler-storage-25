"""
Lean PINN test: small model, CPU (faster for autograd-heavy), progressive output.
PDE: u_tt = u_xx, exact = sin(pi*x)*cos(pi*t)
"""
import torch, torch.nn as nn, torch.nn.functional as F
import numpy as np, time, sys

print("Running on CPU (faster for autograd-heavy small models)", flush=True)

_k2d_cache = {}
def _get_k2d(d, t):
    key = (d, t)
    if key not in _k2d_cache:
        k = torch.tensor([[1/6., 4/6., 1/6.], [4/6., -20/6., 4/6.], [1/6., 4/6., 1/6.]], dtype=t)
        _k2d_cache[key] = k.reshape(1, 1, 3, 3)
    return _k2d_cache[key]

_k1d_cache = {}
def _get_k1d(d, t):
    key = (d, t)
    if key not in _k1d_cache:
        _k1d_cache[key] = torch.tensor([1., -2., 1.], dtype=t).reshape(1, 1, 3)
    return _k1d_cache[key]

def _lap(W):
    k2d = _get_k2d(W.device, W.dtype)
    k1d = _get_k1d(W.device, W.dtype)
    if W.dim() == 1:
        n = W.numel()
        if n < 4: return torch.zeros_like(W)
        x = F.pad(W.reshape(1,1,n), (1,1), mode='circular')
        return F.conv1d(x, k1d).reshape(W.shape)
    shape = W.shape; W2 = W.reshape(shape[0], -1) if W.dim() > 2 else W
    h, w = W2.shape
    if h < 3 or w < 3: return torch.zeros_like(W)
    x = F.pad(W2.reshape(1,1,h,w), (1,1,1,1), mode='circular')
    r = F.conv2d(x, k2d).reshape(W2.shape)
    return r.reshape(shape) if W.dim() > 2 else r

class LAdam(torch.optim.Optimizer):
    def __init__(s, params, lr=1e-3, betas=(0.9,0.999), eps=1e-8, c2=1e-4):
        super().__init__(params, dict(lr=lr, betas=betas, eps=eps, c2=c2))
    @torch.no_grad()
    def step(s, closure=None):
        for g in s.param_groups:
            lr, eps, c2, b1, b2 = g['lr'], g['eps'], g['c2'], g['betas'][0], g['betas'][1]
            for p in g['params']:
                if p.grad is None: continue
                gr = p.grad
                st = s.state[p]
                if not st: st['step']=0; st['m']=torch.zeros_like(p); st['v']=torch.zeros_like(p); st['use_lap']=(c2>0 and p.numel()>=16)
                st['step'] += 1
                m, v = st['m'], st['v']
                m.mul_(b1).add_(gr, alpha=1-b1); v.mul_(b2).addcmul_(gr, gr, value=1-b2)
                mh = m/(1-b1**st['step']); vh = v/(1-b2**st['step'])
                if st['use_lap']:
                    vh = (vh + c2*_lap(vh)).clamp_(min=0)
                p.addcdiv_(mh, vh.sqrt().add_(eps), value=-lr)


def make_mlp(hidden, n_layers, seed):
    torch.manual_seed(seed)
    layers = [nn.Linear(2, hidden), nn.Tanh()]
    for _ in range(n_layers - 1):
        layers += [nn.Linear(hidden, hidden), nn.Tanh()]
    layers.append(nn.Linear(hidden, 1))
    return nn.Sequential(*layers)


def train_pinn(lr, c2, steps, seed, hidden=64, n_layers=3):
    """True PINN with PDE residual on CPU."""
    n_int, n_bc, n_ic = 100, 20, 40
    pi = np.pi

    torch.manual_seed(seed)
    x_int = torch.rand(n_int, 1, requires_grad=True)
    t_int = torch.rand(n_int, 1, requires_grad=True)
    t_bc = torch.rand(n_bc, 1)
    x_bc0 = torch.zeros(n_bc, 1)
    x_bc1 = torch.ones(n_bc, 1)
    x_ic = torch.rand(n_ic, 1, requires_grad=True)
    t_ic = torch.zeros(n_ic, 1, requires_grad=True)
    u_ic_true = torch.sin(pi * x_ic.detach())
    ones_int = torch.ones(n_int, 1)
    ones_ic = torch.ones(n_ic, 1)

    xg, tg = torch.meshgrid(torch.linspace(0,1,30), torch.linspace(0,1,30), indexing='ij')
    x_eval = xg.reshape(-1,1); t_eval = tg.reshape(-1,1)
    u_exact = torch.sin(pi*x_eval)*torch.cos(pi*t_eval)

    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        model = make_mlp(hidden, n_layers, seed)
        opt = cls(model.parameters(), lr=lr, **kw)

        for s in range(steps):
            u = model(torch.cat([x_int, t_int], 1))
            u_x = torch.autograd.grad(u, x_int, ones_int, create_graph=True)[0]
            u_t = torch.autograd.grad(u, t_int, ones_int, create_graph=True)[0]
            u_xx = torch.autograd.grad(u_x, x_int, ones_int, create_graph=True)[0]
            u_tt = torch.autograd.grad(u_t, t_int, ones_int, create_graph=True)[0]
            loss_pde = (u_tt - u_xx).pow(2).mean()

            u0 = model(torch.cat([x_bc0, t_bc], 1))
            u1 = model(torch.cat([x_bc1, t_bc], 1))
            loss_bc = u0.pow(2).mean() + u1.pow(2).mean()

            u_ic_pred = model(torch.cat([x_ic, t_ic], 1))
            loss_ic = (u_ic_pred - u_ic_true).pow(2).mean()
            u_t_ic = torch.autograd.grad(u_ic_pred, t_ic, ones_ic, create_graph=True)[0]
            loss_ic_t = u_t_ic.pow(2).mean()

            loss = loss_pde + 10*loss_bc + 10*(loss_ic + loss_ic_t)
            loss.backward()
            opt.step(); opt.zero_grad()

        with torch.no_grad():
            u_pred = model(torch.cat([x_eval, t_eval], 1))
            results[name] = torch.sqrt(F.mse_loss(u_pred, u_exact)).item()
    return results


# Quick timing first
print("Timing one seed (hidden=64, 3-layer, 200 steps)...", flush=True)
t0 = time.time()
r = train_pinn(1e-3, 1e-4, 200, 0, hidden=64, n_layers=3)
dt = time.time() - t0
print(f"  -> {dt:.1f}s per seed. Adam={r['Adam']:.4f} LAdam={r['LAdam']:.4f}", flush=True)
est = dt * 10 * 12  # 10 seeds x 12 configs
print(f"  -> Est total: {est/60:.1f} min for 10 seeds x 12 configs", flush=True)

N_SEEDS = 10
seeds = list(range(N_SEEDS))

configs = [
    # c2, steps, hidden, n_layers
    (1e-6,  200, 64, 3),
    (1e-5,  200, 64, 3),
    (1e-4,  200, 64, 3),
    (5e-4,  200, 64, 3),
    (1e-3,  200, 64, 3),
    (1e-5,  500, 64, 3),
    (1e-4,  500, 64, 3),
    (5e-4,  500, 64, 3),
    (1e-3,  500, 64, 3),
    (1e-4,  200, 128, 4),
    (5e-4,  200, 128, 4),
    (1e-3,  200, 128, 4),
]

print(f"\n{'c2':>8s} {'steps':>5s} {'H':>3s} {'L':>2s} | {'WR':>5s} {'avg':>7s} {'med':>7s} | {'t':>4s}", flush=True)
print("-"*55, flush=True)

best_wr, best_cfg = 0, None
for c2, steps, hidden, n_layers in configs:
    wins, deltas = 0, []
    t0 = time.time()
    for seed in seeds:
        r = train_pinn(1e-3, c2, steps, seed, hidden=hidden, n_layers=n_layers)
        d = (r["LAdam"] - r["Adam"]) / max(r["Adam"], 1e-12) * 100
        deltas.append(d)
        if d < -0.1: wins += 1
    wr = wins/N_SEEDS
    dt = time.time()-t0
    tag = " ***" if wr >= 0.80 else (" **" if wr >= 0.70 else (" *" if wr >= 0.60 else ""))
    print(f"  {c2:.0e} {steps:5d} {hidden:3d} {n_layers:2d} | {wr*100:4.0f}% {np.mean(deltas):+7.1f}% {np.median(deltas):+7.1f}%{tag} [{dt:.0f}s]", flush=True)
    if wr > best_wr or (wr == best_wr and np.mean(deltas) < (best_cfg[1] if best_cfg else 0)):
        best_wr = wr; best_cfg = (c2, steps, hidden, n_layers, wr, np.mean(deltas))

print(f"\nBest: c2={best_cfg[0]:.0e} steps={best_cfg[1]} h={best_cfg[2]} l={best_cfg[3]} -> {best_cfg[4]*100:.0f}% WR, avg={best_cfg[5]:+.1f}%", flush=True)

# If best >= 70%, expand to 20 seeds on that config
if best_wr >= 0.70:
    print(f"\nExpanding best config to 20 seeds...", flush=True)
    c2, steps, hidden, n_layers = best_cfg[0], best_cfg[1], best_cfg[2], best_cfg[3]
    wins, deltas, per_seed = 0, [], []
    for seed in range(20):
        r = train_pinn(1e-3, c2, steps, seed, hidden=hidden, n_layers=n_layers)
        d = (r["LAdam"] - r["Adam"]) / max(r["Adam"], 1e-12) * 100
        deltas.append(d); per_seed.append((seed, d, r["Adam"], r["LAdam"]))
        if d < -0.1: wins += 1
    print(f"  20-seed WR: {wins/20*100:.0f}%, avg={np.mean(deltas):+.1f}%, med={np.median(deltas):+.1f}%", flush=True)
    print("  Per-seed details (top/bottom 5):", flush=True)
    per_seed.sort(key=lambda x: x[1])
    for s, d, a, l in per_seed[:5]:
        print(f"    seed={s:2d}: {d:+6.1f}% (Adam={a:.5f} LAdam={l:.5f}) {'WIN' if d<-0.1 else 'LOSS'}", flush=True)
    print("    ...")
    for s, d, a, l in per_seed[-5:]:
        print(f"    seed={s:2d}: {d:+6.1f}% (Adam={a:.5f} LAdam={l:.5f}) {'WIN' if d<-0.1 else 'LOSS'}", flush=True)

print("\nDONE", flush=True)
