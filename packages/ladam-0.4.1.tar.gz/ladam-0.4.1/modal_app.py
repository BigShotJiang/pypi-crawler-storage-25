"""
LAdam Optimizer API — Modal serverless deployment.

Architecture: CPU handles all HTTP (cheap), GPU handles benchmarks/sweeps.
Payment: x402 USDC micro-payments, RapidAPI proxy, or API key.

Endpoints:
    POST /v1/analyze    ($0.01)  — Model architecture analysis + LAdam config
    POST /v1/benchmark  ($0.10)  — Train N steps LAdam vs Adam, return comparison
    POST /v1/optimize   ($0.25)  — Sweep c2/scheduler params, return best config
    GET  /health                 — Health check
    GET  /pricing                — Endpoint pricing info

Deploy:
    modal deploy modal_app.py
"""

import os
import sys
import json
import time
import base64
import asyncio
import logging
from typing import Optional, Dict, Any

import modal
from pydantic import BaseModel, Field
from fastapi import Body

logger = logging.getLogger("ladam-api")


# ─── Request Models (module-level for Pydantic type resolution) ─────────

class AnalyzeRequest(BaseModel):
    model_type: str = Field("mlp", description="Architecture: mlp, cnn, transformer")
    hidden_size: int = Field(256, ge=16, le=2048)
    num_layers: int = Field(4, ge=1, le=12)
    lr: float = Field(1e-3, gt=0)
    total_steps: int = Field(10000, ge=100)


class BenchmarkRequest(BaseModel):
    model_type: str = Field("mlp", description="Architecture: mlp, cnn, transformer")
    hidden_size: int = Field(256, ge=16, le=2048)
    num_layers: int = Field(4, ge=1, le=12)
    steps: int = Field(200, ge=10, le=2000)
    lr: float = Field(1e-3, gt=0)
    c2: float = Field(1e-5, ge=0)
    batch_size: int = Field(64, ge=8, le=256)


class OptimizeRequest(BaseModel):
    model_type: str = Field("mlp", description="Architecture: mlp, cnn, transformer")
    hidden_size: int = Field(256, ge=16, le=2048)
    num_layers: int = Field(4, ge=1, le=12)
    steps_per_trial: int = Field(100, ge=10, le=500)
    lr: float = Field(1e-3, gt=0)
    c2_values: list[float] = Field(
        default=[0, 1e-6, 1e-5, 1e-4],
        description="c2 values to sweep"
    )
    use_scheduler: bool = Field(True)
    batch_size: int = Field(64, ge=8, le=256)

# ─── Modal Images ───────────────────────────────────────────────────────

gpu_image = (
    modal.Image.from_registry(
        "nvidia/cuda:12.4.0-runtime-ubuntu22.04", add_python="3.11"
    )
    .pip_install(
        "torch>=2.1",
        "numpy>=1.24",
        "ladam>=0.2.1",
        "pydantic>=2.0",
        "fastapi>=0.100",
    )
)

cpu_image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install(
        "fastapi[standard]>=0.100",
        "uvicorn>=0.20",
        "httpx>=0.25",
        "torch>=2.1",
        "ladam>=0.2.1",
    )
)

app = modal.App("ladam-api")

# ─── GPU Compute: Benchmark ────────────────────────────────────────────


@app.function(image=gpu_image, gpu="T4", scaledown_window=120, timeout=600)
def gpu_benchmark(request_dict: dict) -> dict:
    """Train a model N steps with LAdam vs Adam, return comparison metrics.

    Expected keys in request_dict:
        model_type: str — "mlp", "cnn", "transformer" (built-in toy models)
        hidden_size: int — model width (default 256)
        num_layers: int — model depth (default 4)
        steps: int — training steps (default 200, max 2000)
        lr: float — learning rate (default 1e-3)
        c2: float — LAdam Laplacian coupling (default 1e-5)
        batch_size: int — batch size (default 64)
    """
    import torch
    import torch.nn as nn
    import numpy as np

    model_type = request_dict.get("model_type", "mlp")
    hidden = int(request_dict.get("hidden_size", 256))
    n_layers = min(int(request_dict.get("num_layers", 4)), 12)
    steps = min(int(request_dict.get("steps", 200)), 2000)
    lr = float(request_dict.get("lr", 1e-3))
    c2 = float(request_dict.get("c2", 1e-5))
    batch_size = min(int(request_dict.get("batch_size", 64)), 256)

    device = "cuda" if torch.cuda.is_available() else "cpu"

    # --- Build toy model ---
    def make_model():
        if model_type == "cnn":
            layers = [nn.Conv2d(1, hidden, 3, padding=1), nn.ReLU()]
            for _ in range(n_layers - 1):
                layers += [nn.Conv2d(hidden, hidden, 3, padding=1), nn.ReLU()]
            layers += [nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(hidden, 10)]
            return nn.Sequential(*layers)
        elif model_type == "transformer":
            enc_layer = nn.TransformerEncoderLayer(d_model=hidden, nhead=8, batch_first=True)
            encoder = nn.TransformerEncoder(enc_layer, num_layers=min(n_layers, 6))

            class ToyTransformer(nn.Module):
                def __init__(self):
                    super().__init__()
                    self.embed = nn.Linear(10, hidden)
                    self.encoder = encoder
                    self.head = nn.Linear(hidden, 10)

                def forward(self, x):
                    return self.head(self.encoder(self.embed(x)).mean(dim=1))
            return ToyTransformer()
        else:  # mlp
            layers = [nn.Linear(784, hidden), nn.ReLU()]
            for _ in range(n_layers - 1):
                layers += [nn.Linear(hidden, hidden), nn.ReLU()]
            layers.append(nn.Linear(hidden, 10))
            return nn.Sequential(*layers)

    def make_data():
        if model_type == "cnn":
            x = torch.randn(batch_size, 1, 28, 28, device=device)
        elif model_type == "transformer":
            x = torch.randn(batch_size, 16, 10, device=device)
        else:
            x = torch.randn(batch_size, 784, device=device)
        y = torch.randint(0, 10, (batch_size,), device=device)
        return x, y

    criterion = nn.CrossEntropyLoss()
    results = {}

    for opt_name in ["adam", "ladam"]:
        model = make_model().to(device)
        if opt_name == "adam":
            optimizer = torch.optim.Adam(model.parameters(), lr=lr)
        else:
            from ladam import LAdam
            optimizer = LAdam(model.parameters(), lr=lr, c2=c2)

        losses = []
        t0 = time.time()
        for step in range(steps):
            x, y = make_data()
            optimizer.zero_grad()
            loss = criterion(model(x), y)
            loss.backward()
            optimizer.step()
            if step % max(1, steps // 20) == 0:
                losses.append({"step": step, "loss": float(loss)})
        elapsed = time.time() - t0

        # Final eval
        model.eval()
        with torch.no_grad():
            x, y = make_data()
            logits = model(x)
            final_loss = float(criterion(logits, y))
            acc = float((logits.argmax(1) == y).float().mean())

        results[opt_name] = {
            "final_loss": round(final_loss, 6),
            "final_accuracy": round(acc, 4),
            "loss_curve": losses,
            "elapsed_seconds": round(elapsed, 3),
            "total_params": sum(p.numel() for p in model.parameters()),
        }

    # Compute improvement
    adam_loss = results["adam"]["final_loss"]
    ladam_loss = results["ladam"]["final_loss"]
    improvement_pct = ((adam_loss - ladam_loss) / adam_loss * 100) if adam_loss > 0 else 0.0

    return {
        "model_type": model_type,
        "config": {
            "hidden_size": hidden,
            "num_layers": n_layers,
            "steps": steps,
            "lr": lr,
            "c2": c2,
            "batch_size": batch_size,
        },
        "results": results,
        "ladam_improvement_pct": round(improvement_pct, 2),
        "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
    }


# ─── GPU Compute: Optimize (Sweep) ─────────────────────────────────────


@app.function(image=gpu_image, gpu="T4", scaledown_window=120, timeout=600)
def gpu_optimize(request_dict: dict) -> dict:
    """Sweep c2 values and scheduler configs, return best combination.

    Expected keys:
        model_type: str — "mlp", "cnn", "transformer"
        hidden_size: int — (default 256)
        num_layers: int — (default 4)
        steps_per_trial: int — steps per sweep trial (default 100, max 500)
        lr: float — (default 1e-3)
        c2_values: list[float] — c2 values to sweep (default: [0, 1e-6, 1e-5, 1e-4])
        use_scheduler: bool — whether to also test ChiAnnealScheduler (default True)
    """
    import torch
    import torch.nn as nn

    model_type = request_dict.get("model_type", "mlp")
    hidden = int(request_dict.get("hidden_size", 256))
    n_layers = min(int(request_dict.get("num_layers", 4)), 12)
    steps = min(int(request_dict.get("steps_per_trial", 100)), 500)
    lr = float(request_dict.get("lr", 1e-3))
    c2_values = request_dict.get("c2_values", [0, 1e-6, 1e-5, 1e-4])
    use_scheduler = request_dict.get("use_scheduler", True)
    batch_size = min(int(request_dict.get("batch_size", 64)), 256)

    device = "cuda" if torch.cuda.is_available() else "cpu"

    def make_model():
        if model_type == "cnn":
            layers = [nn.Conv2d(1, hidden, 3, padding=1), nn.ReLU()]
            for _ in range(n_layers - 1):
                layers += [nn.Conv2d(hidden, hidden, 3, padding=1), nn.ReLU()]
            layers += [nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(hidden, 10)]
            return nn.Sequential(*layers)
        elif model_type == "transformer":
            enc_layer = nn.TransformerEncoderLayer(d_model=hidden, nhead=8, batch_first=True)
            encoder = nn.TransformerEncoder(enc_layer, num_layers=min(n_layers, 6))

            class ToyTransformer(nn.Module):
                def __init__(self):
                    super().__init__()
                    self.embed = nn.Linear(10, hidden)
                    self.encoder = encoder
                    self.head = nn.Linear(hidden, 10)

                def forward(self, x):
                    return self.head(self.encoder(self.embed(x)).mean(dim=1))
            return ToyTransformer()
        else:
            layers = [nn.Linear(784, hidden), nn.ReLU()]
            for _ in range(n_layers - 1):
                layers += [nn.Linear(hidden, hidden), nn.ReLU()]
            layers.append(nn.Linear(hidden, 10))
            return nn.Sequential(*layers)

    def make_data():
        if model_type == "cnn":
            return torch.randn(batch_size, 1, 28, 28, device=device), torch.randint(0, 10, (batch_size,), device=device)
        elif model_type == "transformer":
            return torch.randn(batch_size, 16, 10, device=device), torch.randint(0, 10, (batch_size,), device=device)
        else:
            return torch.randn(batch_size, 784, device=device), torch.randint(0, 10, (batch_size,), device=device)

    criterion = nn.CrossEntropyLoss()
    trials = []

    from ladam import LAdam, ChiAnnealScheduler

    scheduler_options = [False, True] if use_scheduler else [False]

    for c2_val in c2_values:
        for sched in scheduler_options:
            torch.manual_seed(42)
            model = make_model().to(device)
            optimizer = LAdam(model.parameters(), lr=lr, c2=float(c2_val))
            scheduler = None
            if sched:
                scheduler = ChiAnnealScheduler(optimizer, total_steps=steps)

            t0 = time.time()
            for step in range(steps):
                x, y = make_data()
                optimizer.zero_grad()
                loss = criterion(model(x), y)
                loss.backward()
                optimizer.step()
                if scheduler:
                    scheduler.step()
            elapsed = time.time() - t0

            model.eval()
            with torch.no_grad():
                x, y = make_data()
                logits = model(x)
                final_loss = float(criterion(logits, y))
                acc = float((logits.argmax(1) == y).float().mean())

            trials.append({
                "c2": float(c2_val),
                "scheduler": sched,
                "final_loss": round(final_loss, 6),
                "final_accuracy": round(acc, 4),
                "elapsed_seconds": round(elapsed, 3),
            })

    # Find best trial
    best = min(trials, key=lambda t: t["final_loss"])

    return {
        "model_type": model_type,
        "config": {
            "hidden_size": hidden,
            "num_layers": n_layers,
            "steps_per_trial": steps,
            "lr": lr,
        },
        "trials": trials,
        "best": best,
        "recommendation": {
            "c2": best["c2"],
            "use_scheduler": best["scheduler"],
            "code_snippet": (
                f"from ladam import LAdam, ChiAnnealScheduler\n"
                f"optimizer = LAdam(model.parameters(), lr={lr}, c2={best['c2']})\n"
                + (f"scheduler = ChiAnnealScheduler(optimizer, total_steps=TOTAL_STEPS)\n"
                   if best["scheduler"] else "")
            ),
        },
        "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
    }


# ─── x402 Payment Helpers ──────────────────────────────────────────────

X402_WALLET = "0x6a8513eF76E90c0F06C93272cBE3A22D02bbFD40"
X402_NETWORK = "eip155:8453"  # Base mainnet
X402_FACILITATOR = "https://x402.org/facilitator"

USDC_CONTRACTS: Dict[str, str] = {
    "eip155:8453": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",  # Base
    "eip155:1":    "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",  # Ethereum
    "eip155:137":  "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359",  # Polygon
}

ENDPOINT_PRICES: Dict[str, str] = {
    "/v1/analyze":   "$0.01",
    "/v1/benchmark": "$0.10",
    "/v1/optimize":  "$0.25",
}


def _price_to_micro(price_str: str) -> str:
    """Convert '$0.01' to USDC smallest unit (6 decimals)."""
    usd = float(price_str.replace("$", ""))
    return str(int(usd * 1_000_000))


def _build_payment_requirements(endpoint: str, base_url: str = "") -> dict:
    price = ENDPOINT_PRICES.get(endpoint, "$0.01")
    asset = USDC_CONTRACTS[X402_NETWORK]
    return {
        "x402Version": 2,
        "accepts": [{
            "scheme": "exact",
            "network": X402_NETWORK,
            "amount": _price_to_micro(price),
            "payTo": X402_WALLET,
            "maxTimeoutSeconds": 300,
            "asset": asset,
            "extra": {},
        }],
        "resource": {
            "url": f"{base_url}{endpoint}",
            "description": f"LAdam API - {endpoint}",
            "mimeType": "application/json",
        },
    }


# ─── CPU Web Server ────────────────────────────────────────────────────


@app.function(
    image=cpu_image,
    # Secret is optional — create via: modal secret create ladam-api-keys X402_ENABLED=true LADAM_API_KEYS='{}'
    secrets=[modal.Secret.from_name("ladam-api-keys", required_keys=[])],
    scaledown_window=300,
    timeout=600,
)
@modal.concurrent(max_inputs=10)
@modal.asgi_app()
def fastapi_app():
    """LAdam API — CPU handles HTTP, dispatches GPU work via Modal .remote()."""
    import httpx
    from fastapi import FastAPI, HTTPException
    from fastapi.middleware.cors import CORSMiddleware
    from starlette.requests import Request
    from starlette.responses import JSONResponse

    api = FastAPI(
        title="LAdam Optimizer API",
        description=(
            "Automatic optimizer configuration, benchmarking, and hyperparameter "
            "sweeps using the LAdam (Laplacian Adam) optimizer. "
            "Pay per call via x402 USDC or API key."
        ),
        version="1.0.0",
    )
    api.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # --- Auth config ---

    API_KEYS: Dict[str, str] = {}
    try:
        raw = os.environ.get("LADAM_API_KEYS", "{}")
        API_KEYS = json.loads(raw) if raw else {}
    except Exception:
        pass

    X402_ENABLED = os.environ.get("X402_ENABLED", "true").lower() in ("true", "1")

    # --- Auth middleware (avoids Request injection issues in nested functions) ---

    @api.middleware("http")
    async def auth_middleware(request: Request, call_next):
        """Check auth for /v1/* endpoints. Sets request.state.auth_source."""
        path = request.url.path
        if not path.startswith("/v1/"):
            return await call_next(request)

        # 1. RapidAPI proxy
        rapid_secret = request.headers.get("x-rapidapi-proxy-secret")
        expected_secret = os.environ.get("RAPIDAPI_PROXY_SECRET", "")
        if rapid_secret and expected_secret and rapid_secret == expected_secret:
            request.state.auth_source = "rapidapi"
            return await call_next(request)

        # 2. API key
        api_key = request.headers.get("x-api-key")
        if api_key:
            if api_key in API_KEYS:
                request.state.auth_source = "api_key"
                return await call_next(request)
            return JSONResponse(
                status_code=403,
                content={"error": "Forbidden", "message": "Invalid API key."},
            )

        # 3. x402 payment
        if X402_ENABLED:
            payment_header = request.headers.get("x-payment") or request.headers.get("payment-signature")
            if payment_header:
                try:
                    payload = json.loads(base64.b64decode(payment_header))
                    requirements = _build_payment_requirements(path)
                    async with httpx.AsyncClient() as client:
                        resp = await client.post(
                            f"{X402_FACILITATOR}/verify",
                            json={"payload": payload, "paymentRequirements": requirements},
                            timeout=15,
                        )
                        if resp.status_code == 200 and resp.json().get("isValid"):
                            await client.post(
                                f"{X402_FACILITATOR}/settle",
                                json={"payload": payload, "paymentRequirements": requirements},
                                timeout=15,
                            )
                            request.state.auth_source = "x402"
                            return await call_next(request)
                except Exception as e:
                    logger.warning("x402 verification failed: %s", e)

        # 4. No auth — return 402 Payment Required
        requirements = _build_payment_requirements(path)
        encoded = base64.b64encode(
            json.dumps(requirements, separators=(",", ":")).encode()
        ).decode("ascii")
        return JSONResponse(
            status_code=402,
            content={
                "error": "Payment required",
                "message": (
                    f"This endpoint costs {ENDPOINT_PRICES.get(path, '$0.01')} per call. "
                    "Send x402 USDC payment or use an API key."
                ),
                "pricing": ENDPOINT_PRICES,
                "x402": requirements,
            },
            headers={"X-Payment-Requirements": encoded},
        )

    # --- Endpoints ---

    @api.get("/health")
    async def health():
        return {"status": "ok", "service": "ladam-api", "version": "1.0.3"}

    @api.get("/pricing")
    async def pricing():
        return {
            "endpoints": {
                "/v1/analyze": {
                    "price": "$0.01",
                    "compute": "CPU",
                    "description": "Analyze model architecture, get LAdam config recommendation",
                },
                "/v1/benchmark": {
                    "price": "$0.10",
                    "compute": "GPU (T4)",
                    "description": "Train LAdam vs Adam head-to-head, get comparison metrics",
                },
                "/v1/optimize": {
                    "price": "$0.25",
                    "compute": "GPU (T4)",
                    "description": "Sweep c2 values and scheduler options, find optimal config",
                },
            },
            "payment_methods": ["x402 USDC", "API key", "RapidAPI"],
            "wallet": X402_WALLET,
            "network": "Base (EIP-155:8453)",
        }

    @api.post("/v1/analyze")
    async def analyze(req: AnalyzeRequest = Body(...)):
        # CPU-local: build model and analyze
        import torch.nn as nn
        from ladam.auto import analyze_model, auto_configure

        # Build the model architecture locally (CPU, no training)
        if req.model_type == "cnn":
            layers = [nn.Conv2d(1, req.hidden_size, 3, padding=1), nn.ReLU()]
            for _ in range(req.num_layers - 1):
                layers += [nn.Conv2d(req.hidden_size, req.hidden_size, 3, padding=1), nn.ReLU()]
            layers += [nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(req.hidden_size, 10)]
            model = nn.Sequential(*layers)
        elif req.model_type == "transformer":
            enc_layer = nn.TransformerEncoderLayer(
                d_model=req.hidden_size, nhead=8, batch_first=True
            )
            encoder = nn.TransformerEncoder(enc_layer, num_layers=min(req.num_layers, 6))

            class ToyTransformer(nn.Module):
                def __init__(self):
                    super().__init__()
                    self.embed = nn.Linear(10, req.hidden_size)
                    self.encoder = encoder
                    self.head = nn.Linear(req.hidden_size, 10)

                def forward(self, x):
                    return self.head(self.encoder(self.embed(x)).mean(dim=1))
            model = ToyTransformer()
        else:
            layers = [nn.Linear(784, req.hidden_size), nn.ReLU()]
            for _ in range(req.num_layers - 1):
                layers += [nn.Linear(req.hidden_size, req.hidden_size), nn.ReLU()]
            layers.append(nn.Linear(req.hidden_size, 10))
            model = nn.Sequential(*layers)

        analysis = analyze_model(model)

        # Generate code snippet
        report = analysis.copy()
        active_c2 = {k: v for k, v in analysis["c2_map"].items() if v > 0}
        if active_c2:
            code = "from ladam import LAdam, ChiAnnealScheduler\n\n"
            code += "param_groups = [\n"
            for layer_type, c2_val in active_c2.items():
                code += f"    {{'params': {layer_type}_params, 'c2': {c2_val}}},\n"
            code += f"    {{'params': other_params, 'c2': 0.0}},\n"
            code += "]\n"
            code += f"optimizer = LAdam(param_groups, lr={req.lr})\n"
            code += f"scheduler = ChiAnnealScheduler(optimizer, total_steps={req.total_steps})\n"
            report["code_snippet"] = code
        else:
            report["code_snippet"] = (
                "# LAdam's Laplacian coupling shows no benefit for this architecture.\n"
                f"optimizer = torch.optim.Adam(model.parameters(), lr={req.lr})\n"
            )

        report["cost"] = "$0.01"
        return report

    @api.post("/v1/benchmark")
    async def benchmark(req: BenchmarkRequest = Body(...)):
        result = gpu_benchmark.remote(req.model_dump())
        result["cost"] = "$0.10"
        return result

    @api.post("/v1/optimize")
    async def optimize(req: OptimizeRequest = Body(...)):
        result = gpu_optimize.remote(req.model_dump())
        result["cost"] = "$0.25"
        return result

    return api
