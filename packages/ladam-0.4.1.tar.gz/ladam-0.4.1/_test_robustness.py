"""Multi-seed robustness test for best LAdaGrad/LRMSProp configs + noisy reg."""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

# --- Laplacian infrastructure (same as before) ---
_lap_kernels_2d = {}
_lap_kernel_1d = None

def _get_lap_kernel_2d(device, dtype, stencil='9point'):
    key = (stencil, device, dtype)
    if key not in _lap_kernels_2d:
        if stencil == '9point':
            k = torch.tensor([[1/6., 4/6., 1/6.], [4/6., -20/6., 4/6.], [1/6., 4/6., 1/6.]], device=device, dtype=dtype)
        else:
            k = torch.tensor([[0., 1., 0.], [1., -4., 1.], [0., 1., 0.]], device=device, dtype=dtype)
        _lap_kernels_2d[key] = k.reshape(1, 1, 3, 3)
    return _lap_kernels_2d[key]

def _get_lap_kernel_1d(device, dtype):
    global _lap_kernel_1d
    if _lap_kernel_1d is None or _lap_kernel_1d.device != device:
        _lap_kernel_1d = torch.tensor([1., -2., 1.], device=device, dtype=dtype).reshape(1, 1, 3)
    return _lap_kernel_1d.to(dtype=dtype)

def _laplacian(W, kernel_2d, kernel_1d):
    if W.dim() == 1:
        n = W.numel()
        if n < 4: return torch.zeros_like(W)
        x = W.reshape(1, 1, n)
        x = F.pad(x, (1, 1), mode='circular')
        return F.conv1d(x, kernel_1d).reshape(W.shape)
    else:
        shape = W.shape
        W2 = W.reshape(shape[0], -1) if W.dim() > 2 else W
        h, w = W2.shape
        if h < 3 or w < 3: return torch.zeros_like(W)
        x = W2.reshape(1, 1, h, w)
        x = F.pad(x, (1, 1, 1, 1), mode='circular')
        result = F.conv2d(x, kernel_2d).reshape(W2.shape)
        if W.dim() > 2: result = result.reshape(shape)
        return result


class LAdaGrad(torch.optim.Optimizer):
    def __init__(self, params, lr=1e-2, lr_decay=0, eps=1e-10, weight_decay=0, c2=1e-4):
        defaults = dict(lr=lr, lr_decay=lr_decay, eps=eps, weight_decay=weight_decay, c2=c2)
        super().__init__(params, defaults)
    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad(): loss = closure()
        for group in self.param_groups:
            lr, eps, c2 = group['lr'], group['eps'], group['c2']
            lr_decay, wd = group['lr_decay'], group['weight_decay']
            for p in group['params']:
                if p.grad is None: continue
                grad = p.grad.data
                if wd: grad = grad.add(p.data, alpha=wd)
                state = self.state[p]
                if len(state) == 0:
                    state['step'] = 0; state['sum'] = torch.zeros_like(p.data)
                    state['use_lap'] = (c2 > 0 and p.data.numel() >= 16)
                state['step'] += 1
                state['sum'].addcmul_(grad, grad, value=1)
                clr = lr / (1 + (state['step'] - 1) * lr_decay)
                acc = state['sum']
                if state['use_lap']:
                    k2d = _get_lap_kernel_2d(p.device, acc.dtype)
                    k1d = _get_lap_kernel_1d(p.device, acc.dtype)
                    acc = (acc + c2 * _laplacian(acc, k2d, k1d)).clamp(min=0)
                p.data.addcdiv_(grad, acc.sqrt().add_(eps), value=-clr)
        return loss


class LRMSProp(torch.optim.Optimizer):
    def __init__(self, params, lr=1e-2, alpha=0.99, eps=1e-8, weight_decay=0, momentum=0, c2=1e-4):
        defaults = dict(lr=lr, alpha=alpha, eps=eps, weight_decay=weight_decay, momentum=momentum, c2=c2)
        super().__init__(params, defaults)
    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad(): loss = closure()
        for group in self.param_groups:
            lr, alpha, eps, c2 = group['lr'], group['alpha'], group['eps'], group['c2']
            wd, mom = group['weight_decay'], group['momentum']
            for p in group['params']:
                if p.grad is None: continue
                grad = p.grad.data
                if wd: grad = grad.add(p.data, alpha=wd)
                state = self.state[p]
                if len(state) == 0:
                    state['step'] = 0; state['square_avg'] = torch.zeros_like(p.data)
                    if mom > 0: state['momentum_buffer'] = torch.zeros_like(p.data)
                    state['use_lap'] = (c2 > 0 and p.data.numel() >= 16)
                state['step'] += 1
                sq_avg = state['square_avg']
                sq_avg.mul_(alpha).addcmul_(grad, grad, value=1 - alpha)
                if state['use_lap']:
                    k2d = _get_lap_kernel_2d(p.device, sq_avg.dtype)
                    k1d = _get_lap_kernel_1d(p.device, sq_avg.dtype)
                    avg_smooth = (sq_avg + c2 * _laplacian(sq_avg, k2d, k1d)).clamp(min=0)
                else:
                    avg_smooth = sq_avg
                if mom > 0:
                    buf = state['momentum_buffer']
                    buf.mul_(mom).addcdiv_(grad, avg_smooth.sqrt().add_(eps))
                    p.data.add_(buf, alpha=-lr)
                else:
                    p.data.addcdiv_(grad, avg_smooth.sqrt().add_(eps), value=-lr)
        return loss


class SmallMLP(nn.Module):
    def __init__(self, in_dim, hidden, out_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, out_dim),
        )
    def forward(self, x): return self.net(x)


def run_pinn(base_cls, l_cls, lr, c2, steps, seed):
    torch.manual_seed(seed)
    X = torch.cat([torch.rand(500, 1), torch.rand(500, 1)], dim=1)
    u = torch.sin(np.pi * X[:, 0:1]) * torch.cos(np.pi * X[:, 1:2])
    results = {}
    for name, cls, kw in [("base", base_cls, {}), ("L", l_cls, {"c2": c2})]:
        torch.manual_seed(seed)
        model = SmallMLP(2, 128, 1)
        opt = cls(model.parameters(), lr=lr, **kw)
        for s in range(steps):
            pred = model(X); loss = F.mse_loss(pred, u); loss.backward(); opt.step(); opt.zero_grad()
        results[name] = loss.item()
    return results


def run_noisy_reg(base_cls, l_cls, lr, c2, steps, seed):
    torch.manual_seed(seed)
    X = torch.linspace(0, 1, 500).unsqueeze(1)
    y = torch.sin(2*np.pi*X) + 0.5*torch.sin(5*np.pi*X) + 0.1*torch.randn_like(X)
    results = {}
    for name, cls, kw in [("base", base_cls, {}), ("L", l_cls, {"c2": c2})]:
        torch.manual_seed(seed)
        model = SmallMLP(1, 256, 1)
        opt = cls(model.parameters(), lr=lr, **kw)
        for s in range(steps):
            pred = model(X); loss = F.mse_loss(pred, y); loss.backward(); opt.step(); opt.zero_grad()
        results[name] = loss.item()
    return results


def multi_seed_test(name, base_cls, l_cls, lr, c2, steps, task_fn, seeds=range(10)):
    wins = 0
    deltas = []
    for seed in seeds:
        r = task_fn(base_cls, l_cls, lr, c2, steps, seed)
        d = (r["L"] - r["base"]) / r["base"] * 100
        deltas.append(d)
        if d < 0: wins += 1
    avg_d = np.mean(deltas)
    print(f"  {name}: {wins}/{len(list(seeds))} seeds win, avg delta={avg_d:+.1f}%")
    return wins, avg_d


print("=" * 60)
print("MULTI-SEED ROBUSTNESS (10 seeds each)")
print("=" * 60)

print("\n--- LRMSProp on PINN (lr=1e-3, 500 steps) ---")
multi_seed_test("c2=1e-4", torch.optim.RMSprop, LRMSProp, 1e-3, 1e-4, 500, run_pinn)
multi_seed_test("c2=5e-4", torch.optim.RMSprop, LRMSProp, 1e-3, 5e-4, 500, run_pinn)
multi_seed_test("c2=1e-3", torch.optim.RMSprop, LRMSProp, 1e-3, 1e-3, 500, run_pinn)

print("\n--- LRMSProp on Noisy Regression (lr=1e-3, 500 steps) ---")
multi_seed_test("c2=1e-5", torch.optim.RMSprop, LRMSProp, 1e-3, 1e-5, 500, run_noisy_reg)
multi_seed_test("c2=1e-4", torch.optim.RMSprop, LRMSProp, 1e-3, 1e-4, 500, run_noisy_reg)
multi_seed_test("c2=1e-3", torch.optim.RMSprop, LRMSProp, 1e-3, 1e-3, 500, run_noisy_reg)

print("\n--- LAdaGrad on PINN (lr=1e-2, 500 steps) ---")
multi_seed_test("c2=1e-5", torch.optim.Adagrad, LAdaGrad, 1e-2, 1e-5, 500, run_pinn)
multi_seed_test("c2=1e-4", torch.optim.Adagrad, LAdaGrad, 1e-2, 1e-4, 500, run_pinn)
multi_seed_test("c2=5e-5", torch.optim.Adagrad, LAdaGrad, 1e-2, 5e-5, 500, run_pinn)

print("\n--- LAdaGrad on Noisy Regression (lr=1e-2, 500 steps) ---")
multi_seed_test("c2=1e-5", torch.optim.Adagrad, LAdaGrad, 1e-2, 1e-5, 500, run_noisy_reg)
multi_seed_test("c2=1e-4", torch.optim.Adagrad, LAdaGrad, 1e-2, 1e-4, 500, run_noisy_reg)
multi_seed_test("c2=5e-5", torch.optim.Adagrad, LAdaGrad, 1e-2, 5e-5, 500, run_noisy_reg)

print("\n--- BEST CONFIGS SUMMARY ---")
print("(will pick configs where wins >= 6/10)")
