"""
HYPOTHESIS: LAdam's Laplacian smoothing on v_hat helps MORE when weights
have inherent spatial structure (CNN conv filters) vs unstructured (MLP).

Test: 1D CNN denoising task. Input = noisy signal, output = clean signal.
Conv filters ARE spatially structured -> Laplacian smoothing is natural.
"""
import torch, torch.nn as nn, torch.nn.functional as F
import numpy as np, time

# ---- Laplacian infrastructure (copied from demo) ----
_k2d_cache = {}
def _get_k2d(d, t):
    key = (d, t)
    if key not in _k2d_cache:
        k = torch.tensor([[1/6., 4/6., 1/6.], [4/6., -20/6., 4/6.], [1/6., 4/6., 1/6.]], dtype=t)
        _k2d_cache[key] = k.reshape(1, 1, 3, 3)
    return _k2d_cache[key]
_k1d_cache = {}
def _get_k1d(d, t):
    key = (d, t)
    if key not in _k1d_cache:
        _k1d_cache[key] = torch.tensor([1., -2., 1.], dtype=t).reshape(1, 1, 3)
    return _k1d_cache[key]
def _lap(W):
    k2d = _get_k2d(W.device, W.dtype)
    k1d = _get_k1d(W.device, W.dtype)
    if W.dim() == 1:
        n = W.numel()
        if n < 4: return torch.zeros_like(W)
        x = F.pad(W.reshape(1,1,n), (1,1), mode='circular')
        return F.conv1d(x, k1d).reshape(W.shape)
    shape = W.shape; W2 = W.reshape(shape[0], -1) if W.dim() > 2 else W
    h, w = W2.shape
    if h < 3 or w < 3: return torch.zeros_like(W)
    x = F.pad(W2.reshape(1,1,h,w), (1,1,1,1), mode='circular')
    r = F.conv2d(x, k2d).reshape(W2.shape)
    return r.reshape(shape) if W.dim() > 2 else r

class LAdam(torch.optim.Optimizer):
    def __init__(s, params, lr=1e-3, betas=(0.9,0.999), eps=1e-8, c2=1e-4):
        super().__init__(params, dict(lr=lr, betas=betas, eps=eps, c2=c2))
    @torch.no_grad()
    def step(s, closure=None):
        for g in s.param_groups:
            lr, eps, c2, b1, b2 = g['lr'], g['eps'], g['c2'], g['betas'][0], g['betas'][1]
            for p in g['params']:
                if p.grad is None: continue
                gr = p.grad
                st = s.state[p]
                if not st: st['step']=0; st['m']=torch.zeros_like(p); st['v']=torch.zeros_like(p); st['use_lap']=(c2>0 and p.numel()>=16)
                st['step'] += 1
                m, v = st['m'], st['v']
                m.mul_(b1).add_(gr, alpha=1-b1); v.mul_(b2).addcmul_(gr, gr, value=1-b2)
                mh = m/(1-b1**st['step']); vh = v/(1-b2**st['step'])
                if st['use_lap']:
                    vh = (vh + c2*_lap(vh)).clamp_(min=0)
                p.addcdiv_(mh, vh.sqrt().add_(eps), value=-lr)

# ---- CNN Denoising Model ----
class DenoiseCNN(nn.Module):
    """Small 1D CNN for signal denoising."""
    def __init__(self, channels=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(1, channels, 7, padding=3),
            nn.ReLU(),
            nn.Conv1d(channels, channels, 5, padding=2),
            nn.ReLU(),
            nn.Conv1d(channels, channels, 5, padding=2),
            nn.ReLU(),
            nn.Conv1d(channels, 1, 3, padding=1),
        )
    def forward(self, x):
        return self.net(x)


def generate_signals(n_samples, length=256, noise_std=0.3, seed=None):
    """Generate clean signals + noisy versions."""
    if seed is not None:
        torch.manual_seed(seed)
    # Random superposition of sinusoids
    t = torch.linspace(0, 2*np.pi, length).unsqueeze(0).expand(n_samples, -1)
    clean = torch.zeros(n_samples, length)
    for _ in range(5):
        freq = torch.randint(1, 10, (n_samples, 1)).float()
        phase = torch.rand(n_samples, 1) * 2 * np.pi
        amp = torch.rand(n_samples, 1) * 0.5 + 0.2
        clean += amp * torch.sin(freq * t + phase)
    noisy = clean + noise_std * torch.randn_like(clean)
    return clean.unsqueeze(1), noisy.unsqueeze(1)  # (N, 1, L)


def run_denoising(lr, c2, steps, seed, channels=32, noise=0.3, n_train=200, n_test=100, batch_size=32):
    """Train CNN denoiser, compare Adam vs LAdam on test data."""
    # Generate data
    clean_train, noisy_train = generate_signals(n_train, noise_std=noise, seed=seed)
    clean_test, noisy_test = generate_signals(n_test, noise_std=noise, seed=seed+10000)

    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        torch.manual_seed(seed)
        model = DenoiseCNN(channels=channels)
        opt = cls(model.parameters(), lr=lr, **kw)
        
        # Mini-batch training
        idx = torch.arange(n_train)
        for step in range(steps):
            batch_idx = idx[torch.randint(0, n_train, (batch_size,))]
            x_batch = noisy_train[batch_idx]
            y_batch = clean_train[batch_idx]
            pred = model(x_batch)
            loss = F.mse_loss(pred, y_batch)
            loss.backward()
            opt.step()
            opt.zero_grad()
        
        with torch.no_grad():
            train_rmse = torch.sqrt(F.mse_loss(model(noisy_train), clean_train)).item()
            test_rmse = torch.sqrt(F.mse_loss(model(noisy_test), clean_test)).item()
        results[name] = {'train_rmse': train_rmse, 'test_rmse': test_rmse}
    return results


# ---- MLP baseline for comparison (same task, different architecture) ----
class DenoiseMLP(nn.Module):
    """MLP for signal denoising (processes each point independently - bad architecture)."""
    def __init__(self, hidden=128, length=256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(length, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, length))
    def forward(self, x):
        # x: (N, 1, L) -> flatten -> (N, L)
        out = self.net(x.squeeze(1))
        return out.unsqueeze(1)

def run_mlp_denoising(lr, c2, steps, seed, hidden=128, noise=0.3, n_train=200, n_test=100, batch_size=32):
    """Same task but with MLP architecture."""
    clean_train, noisy_train = generate_signals(n_train, noise_std=noise, seed=seed)
    clean_test, noisy_test = generate_signals(n_test, noise_std=noise, seed=seed+10000)

    results = {}
    for name, cls, kw in [("Adam", torch.optim.Adam, {}), ("LAdam", LAdam, {"c2": c2})]:
        torch.manual_seed(seed)
        model = DenoiseMLP(hidden=hidden)
        opt = cls(model.parameters(), lr=lr, **kw)
        
        idx = torch.arange(n_train)
        for step in range(steps):
            batch_idx = idx[torch.randint(0, n_train, (batch_size,))]
            x_batch = noisy_train[batch_idx]
            y_batch = clean_train[batch_idx]
            pred = model(x_batch)
            loss = F.mse_loss(pred, y_batch)
            loss.backward()
            opt.step()
            opt.zero_grad()
        
        with torch.no_grad():
            train_rmse = torch.sqrt(F.mse_loss(model(noisy_train), clean_train)).item()
            test_rmse = torch.sqrt(F.mse_loss(model(noisy_test), clean_test)).item()
        results[name] = {'train_rmse': train_rmse, 'test_rmse': test_rmse}
    return results


if __name__ == "__main__":
    N_SEEDS = 20
    
    # ===== CNN DENOISING =====
    print("="*70, flush=True)
    print("CNN DENOISING: Conv filters have spatial structure -> Laplacian helps?")
    print("="*70, flush=True)
    
    print(f"\n{'c2':>8s} {'steps':>5s} {'ch':>4s} {'noise':>5s} | {'WR_test':>7s} {'avg_test':>8s} | {'WR_train':>8s} {'avg_train':>9s}", flush=True)
    print("-"*75, flush=True)
    
    cnn_configs = [
        # c2, steps, channels, noise
        (1e-5, 300, 32, 0.3),
        (1e-4, 300, 32, 0.3),
        (5e-4, 300, 32, 0.3),
        (1e-3, 300, 32, 0.3),
        (5e-3, 300, 32, 0.3),
        # Higher noise
        (1e-4, 300, 32, 0.5),
        (5e-4, 300, 32, 0.5),
        (1e-3, 300, 32, 0.5),
        # Wider CNN
        (1e-4, 300, 64, 0.3),
        (5e-4, 300, 64, 0.3),
        (1e-3, 300, 64, 0.3),
    ]
    
    best_wr, best_cfg = 0, None
    for c2, steps, channels, noise in cnn_configs:
        test_wins, train_wins, test_deltas, train_deltas = 0, 0, [], []
        t0 = time.time()
        for seed in range(N_SEEDS):
            r = run_denoising(1e-3, c2, steps, seed, channels=channels, noise=noise)
            td = (r['LAdam']['test_rmse'] - r['Adam']['test_rmse']) / max(r['Adam']['test_rmse'], 1e-12) * 100
            test_deltas.append(td)
            if td < -0.1: test_wins += 1
            trd = (r['LAdam']['train_rmse'] - r['Adam']['train_rmse']) / max(r['Adam']['train_rmse'], 1e-12) * 100
            train_deltas.append(trd)
            if trd < -0.1: train_wins += 1
        
        test_wr = test_wins / N_SEEDS
        train_wr = train_wins / N_SEEDS
        dt = time.time() - t0
        tag = " ***" if test_wr >= 0.80 else (" **" if test_wr >= 0.70 else (" *" if test_wr >= 0.60 else ""))
        print(f"  {c2:.0e} {steps:5d} {channels:4d} {noise:5.1f} | {test_wr*100:5.1f}% {np.mean(test_deltas):+7.1f}% | {train_wr*100:6.1f}% {np.mean(train_deltas):+8.1f}%{tag} [{dt:.0f}s]", flush=True)
        if test_wr > best_wr:
            best_wr = test_wr
            best_cfg = (c2, steps, channels, noise, test_wr, np.mean(test_deltas))
    
    if best_cfg:
        print(f"\nBest CNN: c2={best_cfg[0]:.0e} steps={best_cfg[1]} ch={best_cfg[2]} noise={best_cfg[3]} -> {best_cfg[4]*100:.0f}% WR, avg={best_cfg[5]:+.1f}%", flush=True)
    
    # ===== MLP DENOISING (same task, no spatial structure) =====
    print("\n" + "="*70, flush=True)
    print("MLP DENOISING: Same task, no spatial structure -> Laplacian hurts?")
    print("="*70, flush=True)
    
    print(f"\n{'c2':>8s} {'steps':>5s} | {'WR_test':>7s} {'avg_test':>8s} | {'WR_train':>8s} {'avg_train':>9s}", flush=True)
    print("-"*60, flush=True)
    
    for c2 in [1e-4, 5e-4, 1e-3]:
        test_wins, train_wins, test_deltas, train_deltas = 0, 0, [], []
        t0 = time.time()
        for seed in range(N_SEEDS):
            r = run_mlp_denoising(1e-3, c2, 300, seed, noise=0.3)
            td = (r['LAdam']['test_rmse'] - r['Adam']['test_rmse']) / max(r['Adam']['test_rmse'], 1e-12) * 100
            test_deltas.append(td)
            if td < -0.1: test_wins += 1
            trd = (r['LAdam']['train_rmse'] - r['Adam']['train_rmse']) / max(r['Adam']['train_rmse'], 1e-12) * 100
            train_deltas.append(trd)
            if trd < -0.1: train_wins += 1
        dt = time.time() - t0
        test_wr = test_wins / N_SEEDS
        train_wr = train_wins / N_SEEDS
        tag = " ***" if test_wr >= 0.80 else (" **" if test_wr >= 0.70 else (" *" if test_wr >= 0.60 else ""))
        print(f"  {c2:.0e}   300 | {test_wr*100:5.1f}% {np.mean(test_deltas):+7.1f}% | {train_wr*100:6.1f}% {np.mean(train_deltas):+8.1f}%{tag} [{dt:.0f}s]", flush=True)
    
    print("\n" + "="*70, flush=True)
    print("CONCLUSION: If CNN >> MLP, the Laplacian helps via spatial structure.")
    print("="*70, flush=True)
