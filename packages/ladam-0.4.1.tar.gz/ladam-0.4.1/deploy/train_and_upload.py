"""
Train a CIFAR-10 model with LAdam + ChiAnnealScheduler, then upload to HuggingFace Hub.

Usage:
    # First authenticate:
    #   huggingface-cli login
    # Then run:
    #   python deploy/train_and_upload.py

Trains a small ResNet-style CNN on CIFAR-10 using LAdam optimizer.
Saves checkpoint + uploads to HF Hub as emergentphysicslab/cifar10-ladam.
"""

import sys
import time
import json
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import datasets, transforms

# Use installed ladam package
from ladam import LAdam, ChiAnnealScheduler

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
EPOCHS = 30
BATCH_SIZE = 128
LR = 1e-3
C2 = 1e-4
REPO_ID = "emergentphysicslab/cifar10-ladam"
SAVE_DIR = Path(__file__).resolve().parent / "models"


# --------------- Model Architecture ---------------

class ResBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(channels)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(channels)

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return F.relu(out + x)


class SmallResNet(nn.Module):
    """Compact ResNet for CIFAR-10. ~1.2M params."""

    def __init__(self, num_classes=10):
        super().__init__()
        self.prep = nn.Sequential(
            nn.Conv2d(3, 64, 3, padding=1, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(),
        )
        self.layer1 = nn.Sequential(
            nn.Conv2d(64, 128, 3, padding=1, stride=2, bias=False),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            ResBlock(128),
        )
        self.layer2 = nn.Sequential(
            nn.Conv2d(128, 256, 3, padding=1, stride=2, bias=False),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            ResBlock(256),
        )
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(256, num_classes)

    def forward(self, x):
        x = self.prep(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.pool(x).flatten(1)
        return self.fc(x)


# --------------- Training ---------------

def get_dataloaders():
    train_tf = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)),
    ])
    test_tf = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)),
    ])
    data_dir = SAVE_DIR.parent.parent / "data"
    train_ds = datasets.CIFAR10(str(data_dir), train=True, download=True, transform=train_tf)
    test_ds = datasets.CIFAR10(str(data_dir), train=False, download=True, transform=test_tf)
    train_dl = torch.utils.data.DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=0, pin_memory=True)
    test_dl = torch.utils.data.DataLoader(test_ds, batch_size=256, shuffle=False, num_workers=0, pin_memory=True)
    return train_dl, test_dl


@torch.no_grad()
def evaluate(model, test_dl):
    model.eval()
    correct = total = 0
    for x, y in test_dl:
        x, y = x.to(DEVICE), y.to(DEVICE)
        pred = model(x).argmax(dim=1)
        correct += (pred == y).sum().item()
        total += y.size(0)
    return correct / total


def train():
    print(f"Device: {DEVICE}")
    train_dl, test_dl = get_dataloaders()
    model = SmallResNet().to(DEVICE)
    param_count = sum(p.numel() for p in model.parameters())
    print(f"Model: SmallResNet ({param_count:,} params)")

    optimizer = LAdam(model.parameters(), lr=LR, c2=C2)
    total_steps = EPOCHS * len(train_dl)
    scheduler = ChiAnnealScheduler(optimizer, total_steps=total_steps)
    print(f"Optimizer: LAdam (lr={LR}, c2={C2})")
    print(f"Scheduler: ChiAnnealScheduler ({total_steps} steps)")
    print(f"Training for {EPOCHS} epochs...")

    best_acc = 0.0
    history = []
    t0 = time.time()

    for epoch in range(EPOCHS):
        model.train()
        epoch_loss = 0.0
        for x, y in train_dl:
            x, y = x.to(DEVICE), y.to(DEVICE)
            optimizer.zero_grad()
            loss = F.cross_entropy(model(x), y)
            loss.backward()
            optimizer.step()
            scheduler.step()
            epoch_loss += loss.item()

        avg_loss = epoch_loss / len(train_dl)
        acc = evaluate(model, test_dl)
        elapsed = time.time() - t0

        history.append({"epoch": epoch + 1, "loss": round(avg_loss, 4), "acc": round(acc, 4)})
        tag = " *BEST*" if acc > best_acc else ""
        print(f"  Epoch {epoch+1:2d}/{EPOCHS}  loss={avg_loss:.4f}  acc={acc:.4f} ({acc*100:.1f}%)  [{elapsed:.0f}s]{tag}", flush=True)

        if acc > best_acc:
            best_acc = acc
            # Save best checkpoint
            SAVE_DIR.mkdir(parents=True, exist_ok=True)
            ckpt_path = SAVE_DIR / "cifar10_ladam_best.pt"
            torch.save({
                "model_state_dict": model.state_dict(),
                "optimizer": "LAdam",
                "c2": C2,
                "lr": LR,
                "epoch": epoch + 1,
                "accuracy": best_acc,
                "param_count": param_count,
            }, ckpt_path)

    print(f"\nTraining complete. Best accuracy: {best_acc:.4f} ({best_acc*100:.1f}%)")
    print(f"Checkpoint saved: {SAVE_DIR / 'cifar10_ladam_best.pt'}")

    # Save training history
    with open(SAVE_DIR / "training_history.json", "w") as f:
        json.dump({"epochs": EPOCHS, "best_acc": best_acc, "history": history,
                    "optimizer": "LAdam", "c2": C2, "lr": LR,
                    "scheduler": "ChiAnnealScheduler", "model": "SmallResNet",
                    "params": param_count, "device": DEVICE}, f, indent=2)

    return best_acc, SAVE_DIR


# --------------- HuggingFace Upload ---------------

def create_model_card(acc, save_dir):
    card = f"""---
license: mit
library_name: pytorch
tags:
  - image-classification
  - cifar10
  - ladam
  - physics-inspired-optimizer
  - resnet
datasets:
  - cifar10
metrics:
  - accuracy
model-index:
  - name: cifar10-ladam
    results:
      - task:
          type: image-classification
          name: Image Classification
        dataset:
          type: cifar10
          name: CIFAR-10
        metrics:
          - type: accuracy
            value: {acc*100:.2f}
            name: Top-1 Accuracy
---

# CIFAR-10 trained with LAdam Optimizer

A compact ResNet (~1.2M params) trained on CIFAR-10 using the **LAdam** (Laplacian Adam) optimizer
with **ChiAnnealScheduler**.

## Model Details

- **Architecture**: SmallResNet (ResBlocks with 64→128→256 channels)
- **Parameters**: ~1.2M
- **Optimizer**: [LAdam](https://pypi.org/project/ladam/) (c2=1e-4, lr=1e-3)
- **Scheduler**: ChiAnnealScheduler (warmup → constant → settle)
- **Epochs**: {EPOCHS}
- **Test Accuracy**: **{acc*100:.2f}%**

## What is LAdam?

LAdam adds discrete Laplacian regularization to Adam's variance estimate, coupling neighboring
weight learning rates through wave mechanics. It's particularly effective for CNN architectures
where spatial structure in weight matrices matters.

```bash
pip install ladam
```

## Usage

```python
import torch
from torchvision import transforms

# Load model
checkpoint = torch.load("cifar10_ladam_best.pt", weights_only=True)
model = SmallResNet()  # See model definition below
model.load_state_dict(checkpoint["model_state_dict"])
model.eval()

# Inference
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)),
])
# img = transform(your_pil_image).unsqueeze(0)
# pred = model(img).argmax(dim=1)
```

## Training with LAdam

```python
from ladam import LAdam, ChiAnnealScheduler

optimizer = LAdam(model.parameters(), lr=1e-3, c2=1e-4)
scheduler = ChiAnnealScheduler(optimizer, total_steps=total_steps)

for epoch in range(30):
    for x, y in train_loader:
        optimizer.zero_grad()
        loss = F.cross_entropy(model(x), y)
        loss.backward()
        optimizer.step()
        scheduler.step()
```

## License

MIT — free for commercial and research use.
"""
    with open(save_dir / "README.md", "w") as f:
        f.write(card)
    print(f"Model card written: {save_dir / 'README.md'}")


def upload_to_hf(save_dir):
    try:
        from huggingface_hub import HfApi
        api = HfApi()
        api.whoami()  # Verify auth
    except Exception as e:
        print(f"\n*** HuggingFace auth required ***")
        print(f"Run: huggingface-cli login")
        print(f"Then re-run this script (model is saved, training won't repeat)")
        return False

    print(f"\nUploading to {REPO_ID}...")
    from huggingface_hub import HfApi
    api = HfApi()
    api.create_repo(REPO_ID, exist_ok=True, repo_type="model")
    api.upload_folder(
        folder_path=str(save_dir),
        repo_id=REPO_ID,
        repo_type="model",
    )
    print(f"Uploaded! View at: https://huggingface.co/{REPO_ID}")
    return True


# --------------- Main ---------------

if __name__ == "__main__":
    # Check if checkpoint already exists (skip training)
    ckpt_path = SAVE_DIR / "cifar10_ladam_best.pt"
    if ckpt_path.exists():
        ckpt = torch.load(ckpt_path, weights_only=True)
        best_acc = ckpt["accuracy"]
        print(f"Found existing checkpoint: {best_acc*100:.1f}% accuracy")
        print("Skipping training. Delete deploy/models/ to retrain.")
    else:
        best_acc, _ = train()

    create_model_card(best_acc, SAVE_DIR)
    upload_to_hf(SAVE_DIR)
