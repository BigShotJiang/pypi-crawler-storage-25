---
license: mit
task_categories:
  - tabular-classification
tags:
  - optimizer
  - benchmark
  - pytorch
  - ladam
  - deep-learning
pretty_name: LAdam Optimizer Benchmark Traces
size_categories:
  - 1K<n<10K
---

# LAdam Benchmark Traces

Training curves and metrics from the **64-experiment LAdam validation campaign**.

## Overview

This dataset contains the raw training metrics comparing **LAdam** (Laplacian Adam) against standard Adam
across 8 ML task domains, 3 seeds each, with statistical significance testing.

**LAdam**: A drop-in Adam replacement that applies discrete Laplacian regularization to the
second-moment estimate. `pip install ladam` | [GitHub](https://github.com/gpartin/ladam)

## Dataset Structure

- `benchmark_summary.json` - Consolidated table of all optimizer runs with key metrics
- `raw/results_*.json` - Per-experiment detailed results with full epoch-by-epoch training curves

## Experiments

| Domain | Tasks | Key Finding |
|--------|-------|-------------|
| PINNs / Scientific ML | Wave equation | LAdam -44.6% L2 error |
| Image Classification | FashionMNIST, CIFAR-10, SVHN | LAdam +0.8% to +5.4% accuracy |
| Transformers | FashionMNIST Transformer | LAdam +0.20% accuracy |
| Segmentation | VOC 2012 DeepLabV3 | LAdam +0.21% mIoU |
| Normalization | WaveNorm vs BatchNorm | WaveNorm -13.5% MSE (regression) |
| Detection | Faster R-CNN | Adam wins (-2.6% mAP) |
| Audio | VGGish | Adam wins (-0.86%) |
| Language | GPT-2 | Adam wins |

**Win rate on decisive results: 10/22 = 45%**

## Citation

```bibtex
@software{partin2026ladam,
  author = {Partin, Greg},
  title = {LAdam: Spatially-Aware Adaptive Optimization via Laplacian-Regularized Variance Estimates},
  year = {2026},
  url = {https://github.com/gpartin/ladam}
}
```
