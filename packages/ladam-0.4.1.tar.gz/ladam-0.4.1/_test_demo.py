"""Quick local test of demo c2 values."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'demo'))

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

# Import just the pieces we need from app.py
exec(open('demo/app.py').read().split('# Build the Gradio app')[0])

# Test all 3 tasks with their optimal c2
for task, c2_val in [("PINN", 1e-5), ("Spiral", 1e-4), ("Rosenbrock", 1e-4)]:
    if task == "PINN":
        results = train_pinn(1e-3, c2_val, 500, 42)
        adam = results["Adam"][-1]
        ladam = results["LAdam"][-1]
    elif task == "Spiral":
        results = train_spiral(1e-3, c2_val, 500, 42)
        adam = results["Adam"]["loss"][-1]
        ladam = results["LAdam"]["loss"][-1]
    else:
        results = train_rosenbrock(1e-3, c2_val, 1000, 42)
        adam = results["Adam"]["loss"][-1]
        ladam = results["LAdam"]["loss"][-1]
    
    delta = (ladam - adam) / adam * 100
    winner = "LAdam WINS" if ladam < adam else "Adam WINS"
    print(f"{task:12s} c2={c2_val:.0e}: Adam={adam:.6f} LAdam={ladam:.6f} ({delta:+.1f}%) -> {winner}")
