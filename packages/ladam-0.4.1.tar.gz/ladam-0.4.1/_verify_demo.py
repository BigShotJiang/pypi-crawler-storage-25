"""Verify ALL demo tasks at seed=42 with the new defaults."""
import sys
sys.path.insert(0, 'demo')
from app import (train_cnn_denoising, train_pinn, train_noisy_regression,
                 train_spiral, OPTIMIZER_PAIRS, DEFAULTS)

print("=" * 70)
print("DEMO VERIFICATION: All tasks at seed=42 with DEFAULTS")
print("=" * 70)

for opt_name in ["LAdam vs Adam", "LAdaGrad vs Adagrad", "LRMSProp vs RMSprop"]:
    base_name, _, enh_name, _ = OPTIMIZER_PAIRS[opt_name]
    print(f"\n--- {opt_name} ---")
    
    for task_name in DEFAULTS[opt_name]:
        d = DEFAULTS[opt_name][task_name]
        lr, c2, steps = d["lr"], d["c2"], d["steps"]
        
        if task_name == "CNN Denoising":
            results = train_cnn_denoising(lr, c2, steps, 42, opt_name)
        elif task_name == "PINN (Wave Equation)":
            results = train_pinn(lr, c2, steps, 42, opt_name)
        elif task_name == "Noisy Regression":
            results = train_noisy_regression(lr, c2, steps, 42, opt_name)
        elif task_name == "Spiral Classification":
            results = train_spiral(lr, c2, steps, 42, opt_name)
            # Extract final loss for spiral
            base_val = results[base_name]["acc"][-1]
            enh_val = results[enh_name]["acc"][-1]
            delta = enh_val - base_val
            winner = "ENHANCED" if delta > 0.1 else ("BASE" if delta < -0.1 else "TIE")
            print(f"  {task_name:25s} lr={lr:.0e} c2={c2:.0e} steps={steps:4d} | "
                  f"{base_name}={base_val:.1f}% {enh_name}={enh_val:.1f}% "
                  f"delta={delta:+.1f}pp -> {winner}")
            continue
        
        base_val = results[base_name][-1]
        enh_val = results[enh_name][-1]
        delta_pct = (enh_val - base_val) / base_val * 100
        winner = "ENHANCED" if delta_pct < -0.1 else ("BASE" if delta_pct > 0.1 else "TIE")
        print(f"  {task_name:25s} lr={lr:.0e} c2={c2:.0e} steps={steps:4d} | "
              f"{base_name}={base_val:.6f} {enh_name}={enh_val:.6f} "
              f"delta={delta_pct:+.1f}% -> {winner}")

print("\nDone.")
