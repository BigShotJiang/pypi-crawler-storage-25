"""Quick verification of LAdam-only demo V4 -- all 3 tasks at seed=42."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'demo'))

# Stub gradio so app.py can be imported without it
import types
gr = types.ModuleType('gradio')
gr.Progress = lambda: lambda *a, **k: None
gr.Blocks = lambda **kw: type('B', (), {'__enter__': lambda s: s, '__exit__': lambda *a: None})()
gr.Markdown = lambda *a, **k: type('W', (), {'change': lambda *a, **k: None})()
gr.Row = lambda: type('R', (), {'__enter__': lambda s: s, '__exit__': lambda *a: None})()
gr.Column = lambda **k: type('C', (), {'__enter__': lambda s: s, '__exit__': lambda *a: None})()
gr.Dropdown = lambda **k: type('D', (), {'change': lambda *a, **k: None, 'value': k.get('value')})()
gr.Number = lambda **k: type('N', (), {'value': k.get('value')})()
gr.Slider = lambda *a, **k: type('S', (), {'value': k.get('value')})()
gr.Button = lambda *a, **k: type('B', (), {'click': lambda *a, **k: None})()
gr.Plot = lambda **k: None
sys.modules['gradio'] = gr

from app import train_pinn, train_cnn_denoising, train_noisy_regression, DEFAULTS

print("=" * 60)
print("LAdam Demo V4 -- Verification at seed=42")
print("=" * 60)

tasks = {
    "CNN Denoising": train_cnn_denoising,
    "PINN (Wave Equation)": train_pinn,
    "Noisy Regression": train_noisy_regression,
}

for task_name, train_fn in tasks.items():
    d = DEFAULTS[task_name]
    lr, c2, steps = d["lr"], d["c2"], d["steps"]
    print(f"\n--- {task_name} (lr={lr}, c2={c2}, steps={steps}) ---")
    results = train_fn(lr, c2, steps, seed=42)
    adam_final = results["Adam"][-1]
    ladam_final = results["LAdam"][-1]
    delta = (ladam_final - adam_final) / adam_final * 100
    winner = "LAdam WINS" if delta < 0 else "Adam wins"
    print(f"  Adam:  {adam_final:.6f}")
    print(f"  LAdam: {ladam_final:.6f}")
    print(f"  Delta: {delta:+.1f}%  --> {winner}")

print("\n" + "=" * 60)
print("DONE")
