from .common import BitgetClient
from .spot import Spot
from .asset import Asset
from .futures.futures import Futures


class BITGET:
    """
    Bitget API 主类
    """

    def __init__(self, api_key, api_secret, passphrase, is_demo=False):
        """
        初始化 Bitget API 客户端
        :param api_key: API Key
        :param api_secret: API Secret
        :param passphrase: API Passphrase
        :param is_demo: 是否使用测试环境
        """
        self.client = BitgetClient(api_key, api_secret, passphrase, is_demo)
        self.spot = Spot(self.client)
        self.asset = Asset(self.client)
        self.futures = Futures(self.client)

    def __repr__(self):
        return f"<BITGET(demo={self.is_demo})>"
