from loguru import logger

from exhub import Common


class SpotTrade:
    """Bitget 现货交易实现"""
    def __init__(self, client):
        self.client = client

    def order(self, coin, side, order_type, amount):
        """
        下单 (TRADE)
        POST /api/v2/spot/trade/place-order
        :param symbol: 交易对名称 (如 BTCUSDT)
        :param side: 交易方向 (buy, sell)
        :param orderType: 订单类型 (limit, market)
        :param size: 委托数量
        :param kwargs: 其他可选参数 (price, clientOid, force, etc.)
        """
        path = "/api/v2/spot/trade/place-order"
        body = {
            "symbol": coin if coin.endswith("USDT") else coin + "USDT",
            "side": side.lower(),
            "orderType": order_type.lower(),
            "size": str(amount)
        }

        res = self.client.post(path, body)
        logger.debug(res)
        if res.get("code") == "00000":
            logger.success(f'下单成功: {res.get("data")["orderId"]}')
            return Common().return_order_struct("BITGET", coin, side, order_type, amount, res.get("data")["orderId"],"",res)
        raise Exception(res.get("msg", "Unknown error"))

    def get_orders_status(self, coin, order_id):
        """
        查询订单状态 (TRADE)
        GET /api/v2/spot/trade/orderInfo
        https://www.bitget.com/zh-CN/api-doc/spot/trade/Get-Order-Info
        :param coin:
        :param order_id:
        :return:
        """
        path = "/api/v2/spot/trade/orderInfo"
        params = {
            "orderId": order_id
        }
        res = self.client.get(path, params)
        logger.debug(res)
        if res.get("code") == "00000":
            data = res.get("data")[0]  # ⚠️ 不知道这里拆不拆分订单
            if data.get("status") == "filled":
                order_status = "FILLED"
            elif data.get("status") in ["partially_filled", "live"]:
                order_status = "PROCESSING"
            else:
                order_status = "FAILED"
            return Common().return_order_status_struct("BITGET", data.get("symbol"), order_id, data.get("side").upper(),data.get("orderType").upper(),order_status,res)
        raise Exception(res.get("msg", "Unknown error"))

    def get_order_info(self, coin, order_id):
        """
        查询订单信息 (TRADE)
        GET /api/v2/spot/trade/fills
        https://www.bitget.com/zh-CN/api-doc/spot/trade/Get-Fills
        :param coin:
        :param order_id:
        :return:
        """
        path = "/api/v2/spot/trade/fills"
        params = {
            "symbol":coin.upper() if coin.upper().endswith("USDT") else coin.upper() + "USDT",
            "orderId": order_id
        }
        res = self.client.get(path, params)
        logger.debug(res)
        if res.get("code") == "00000":
            data = res.get("data")[0]  # ⚠️ 不知道这里拆不拆分订单
            return Common().return_order_info_struct("BITGET", data.get("symbol"), data.get("size"), order_id, data.get("amount"),data.get("priceAvg"),res)
        raise Exception(res.get("msg", "Unknown error"))