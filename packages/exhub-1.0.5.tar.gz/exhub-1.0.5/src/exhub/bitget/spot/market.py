from loguru import logger
from decimal import Decimal
from exhub import Common

class SpotMarket:
    """现货行情 API"""

    def __init__(self, client):
        self.client = client

    def get_coin_network_info(self, coin=None, network=None):
        """
        获取币种信息
        :param coin: 币种名称，如"BTC"（可选，不传返回全部币种信息）
        :param chain: 链名称,如"BASE"(可选，不传返回全部链信息) *自定义*
        限速规则: 3次/1s (IP)
        """
        path = "/api/v2/spot/public/coins"
        params = {}
        if coin:
            params["coin"] = coin
        network_ls = network.strip().split(",") if network else []
        res = self.client.get(path, params=params)
        logger.debug(res)
        
        if network:
            return_data = Common().return_coin_network_info_struct("BITGET", False, False, None, 0)
        else:
            return_data = {"BITGET": []}

        if res.get("code") == "00000":
            data = res.get("data", [])
            logger.info(f'获取到 {len(data)} 个币种信息')
            for coin_info in data:
                coin_name = coin_info.get("coin")
                chains = coin_info.get("chains", [])
                logger.info(f'币种: {coin_name}, 支持链: {len(chains)}个')
                for chain_data in chains:
                    chain_name_val = chain_data.get("chain")
                    if chain_name_val in network_ls:
                        withdraw_status = chain_data.get("withdrawable") == "true"
                        deposit_status = chain_data.get("rechargeable") == "true"
                        ct_addr = chain_data.get("contractAddress") if chain_data.get("contractAddress") else None
                        withdraw_fee = chain_data.get("withdrawFee", 0)
                        
                        return_data = Common().return_coin_network_info_struct("BITGET", withdraw_status, deposit_status, ct_addr, withdraw_fee)
                        
                        logger.info(f'  - 链: {chain_name_val}, '
                                    f'网络状态: {chain_data.get("congestion")}, '
                                    f'提现状态: {chain_data.get("withdrawable")}, '
                                    f'最小提现: {chain_data.get("minWithdrawAmount")}, '
                                    f'提现手续费: {chain_data.get("withdrawFee")}, '
                                    f'充值状态: {chain_data.get("rechargeable")}, '
                                    f'最小充值: {chain_data.get("minDepositAmount")}, '
                                    f'币种合约地址: {chain_data.get("contractAddress")}, '
                                    f'提币数量精度: {chain_data.get("withdrawMinScale")}'
                                    )
                    else:
                        if not network:
                            new_entry = {
                                "dex_chain_name": None,
                                "cex_chain_name": chain_name_val,
                                "withdraw_status": chain_data.get("withdrawable") == "true",
                                "deposit_status": chain_data.get("rechargeable") == "true",
                                "contract_address": chain_data.get("contractAddress") or None,
                                "withdrawFee": chain_data.get("withdrawFee"),
                            }
                            return_data["BITGET"].append(new_entry)
                        logger.debug(f'  - 链: {chain_name_val}, '
                                    f'网络状态: {chain_data.get("congestion")}, '
                                    f'提现状态: {chain_data.get("withdrawable")}, '
                                    f'最小提现: {chain_data.get("minWithdrawAmount")}, '
                                    f'提现手续费: {chain_data.get("withdrawFee")}, '
                                    f'充值状态: {chain_data.get("rechargeable")}, '
                                    f'最小充值: {chain_data.get("minDepositAmount")}, '
                                    f'币种合约地址: {chain_data.get("contractAddress")}, '
                                    f'提币数量精度: {chain_data.get("withdrawMinScale")}'
                                    )
        else:
            raise Exception(f"api error :{res.get('msg')}")
        return return_data

    def get_coin_info(self, coin):
        """
        获取交易对信息
        :param symbol: 交易对名称，如"BTCUSDT"（可选，不传返回全部交易对信息）
        限速规则: 20次/1s (IP)
        """
        path = "/api/v2/spot/public/symbols"
        params = {}
        if coin:
            params["symbol"] = coin + "USDT"

        res = self.client.get(path, params=params)
        logger.debug(res)
        
        swap_status = False
        min_unit = 0
        
        if res.get("code") == "00000":
            data = res.get("data", [])
            logger.info(f'获取到 {len(data)} 个交易对信息')
            for symbol_info in data:
                if symbol_info.get("baseCoin") == coin and symbol_info.get("status") == "online":
                    swap_status = True
                    min_unit = 10**-Decimal(symbol_info.get("quantityPrecision"))
                    
                symbol_name = symbol_info.get("symbol")
                base_coin = symbol_info.get("baseCoin")
                quote_coin = symbol_info.get("quoteCoin")
                status = symbol_info.get("status")
                min_usdt = symbol_info.get("minTradeUSDT")
                logger.info(f'交易对: {symbol_name} ({base_coin}/{quote_coin}), '
                          f'状态: {status}, 最小USDT: {min_usdt}, '
                          f'价格精度: {symbol_info.get("pricePrecision")}, '
                          f'数量精度: {symbol_info.get("quantityPrecision")}, '
                          f'右币精度: {symbol_info.get("quotePrecision")}'  )
        else:
            raise Exception(f"api error :{res.get('msg')}")

        return Common().return_coin_info_struct("BITGET", swap_status, min_unit)

    def get_klines(self, coin, interval, limit=1):
        """
        获取K线数据
        """
        path = "/api/v2/spot/market/candles"
        params = {
            "symbol": coin + "USDT",
            "granularity": interval,
        }
        if limit:
            params["limit"] = limit

        res = self.client.get(path, params=params)
        logger.debug(res)
        
        volume = 0
        if res.get("code") == "00000":
            data = res.get("data", [])
            logger.info(f'K线数据数量: {len(data)}')
            if data:
                latest = data[0]
                logger.info(f'最新K线 - 时间: {latest[0]}, 开: {latest[1]}, 高: {latest[2]}, '
                          f'低: {latest[3]}, 收: {latest[4]}, 量: {latest[5]}, 成交额: {latest[6]}')
                volume = latest[6]
        else:
            raise Exception(f"api error :{res.get('msg')}")

        return Common().return_klines_struct("BITGET", volume)

