import hmac
import base64
import json
import requests
from datetime import datetime, timezone
from loguru import logger

class BitgetClient:
    def __init__(self, api_key, api_secret, passphrase, is_demo=False):
        self.api_key = api_key
        self.api_secret = api_secret
        self.passphrase = passphrase
        self.is_demo = is_demo
        self.base_url = "https://api.bitget.com"

    def _get_timestamp(self):
        return str(int(datetime.now(timezone.utc).timestamp() * 1000))

    def _sign(self, timestamp, method, request_path, query_string='', body=''):
        if isinstance(body, (dict, list)):
            body = json.dumps(body)
        if query_string:
            message = timestamp + method.upper() + request_path + '?' + query_string + body
        else:
            message = timestamp + method.upper() + request_path + body
        mac = hmac.new(
            bytes(self.api_secret, encoding='utf-8'),
            bytes(message, encoding='utf-8'),
            digestmod='sha256'
        )
        return base64.b64encode(mac.digest()).decode()

    def _request(self, method, request_path, body='', params=None):
        url = self.base_url + request_path
        timestamp = self._get_timestamp()
        query_string = ''
        if params:
            filtered_params = {k: v for k, v in params.items() if v is not None}
            query_string = '&'.join([f'{k}={v}' for k, v in filtered_params.items()])
        signature = self._sign(timestamp, method, request_path, query_string, body)
        headers = {
            'Content-Type': 'application/json',
            'ACCESS-KEY': self.api_key,
            'ACCESS-SIGN': signature,
            'ACCESS-TIMESTAMP': timestamp,
            'ACCESS-PASSPHRASE': self.passphrase,
            "locale": "zh-CN"
        }
        try:
            if self.is_demo:
                headers['paptrading'] = '1'
            if method.upper() == 'GET':
                response = requests.get(url, headers=headers, params=params)
            elif method.upper() == 'POST':
                response = requests.post(url, headers=headers, data=json.dumps(body) if body else '')
            else:
                raise ValueError("Unsupported HTTP method")
        except Exception as e:
            logger.error(f"Error making request to {url}: {e}")
            raise Exception(f"Error making request to {url}: {e}")
        return response.json()
    def get(self, path, params=None):
        return self._request('GET', path, params=params)

    def post(self, path, body=None):
        return self._request('POST', path, body=body or {})
