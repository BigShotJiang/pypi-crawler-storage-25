from decimal import Decimal
import time
from loguru import logger
from exhub import Common

class FuturesMarket():
    """Bitget 合约市场"""
    def __init__(self, client):
        self.client = client

    def get_prices_futures(self, coin):
        """
        获取指定代币对价格
        GET /api/v2/mix/market/ticker
        https://www.bitget.com/zh-CN/api-doc/contract/market/Get-Tickers
        """
        path = "/api/v2/mix/market/ticker"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        params = {
            "symbol": symbol,
            "productType": "USDT-FUTURES"
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        if res and res.get("code") == "00000" and res.get("data"):
            data = res["data"][0] if res["data"] else {}
            if not data: return None
            
            coin_res = data.get("symbol", symbol)
            price = data.get("lastPr")
            ts = data.get("ts", int(time.time()*1000))
            return Common().return_futures_price_struct("BITGET", coin_res, price, ts)
        return None

    def get_coin_info_futures(self, coin):
        """
        获取合约交易规范信息
        GET /api/v2/mix/market/contracts
        https://www.bitget.com/zh-CN/api-doc/contract/market/Get-Contracts
        """
        path = "/api/v2/mix/market/contracts"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        params = {
            "productType": "USDT-FUTURES",
            "symbol": symbol
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        
        if res and res.get("code") == "00000" and res.get("data"):
            data = res["data"][0]
            coin_res = data.get("symbol", symbol)
            min_unit = data.get("sizeMultiplier", "0")
            min_size = data.get("minTradeNum", "1")
            price_place = int(data.get("pricePlace", "2"))
            price_unit = 10 ** -price_place
            
            swap_status = data.get("symbolStatus") == "normal"
            min_lever = data.get("minLever", "1")
            max_lever = data.get("maxLever", "10")
            return Common().return_futures_coin_info_struct("BITGET", coin, swap_status, Decimal(str(min_size)), Decimal(str(price_unit)), Decimal('1'), Decimal('125'), Decimal('1.0'))
        else:
            return Common().return_futures_coin_info_struct("BITGET", coin, False, "1", "0.01", 1, 125, Decimal('1.0'))

    def get_coin_config_futures(self, coin):
        """
        获取合约代币的配置-杠杆配置信息
        GET /api/v2/mix/account/account
        https://www.bitget.com/zh-CN/api-doc/contract/account/Get-Single-Account
        :param coin:
        :return:
        """
        path = "/api/v2/mix/account/account"
        params = {
            "productType": "USDT-FUTURES",
            "marginCoin": "USDT",
            "symbol": coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        leverage = 0
        margin_mode = "cross"
        if res and res.get("code") == "00000" and res.get("data"):
            data = res["data"]
            leverage = data.get("shortLeverage", data.get("crossedMarginLeverage", 0))
            margin_mode_raw = data.get("marginMode", "").lower()
            if margin_mode_raw == "crossed":
                margin_mode = "cross"
            else:
                margin_mode = margin_mode_raw
        return Common().return_futures_coin_config_struct("BITGET", coin, leverage, margin_mode)

    def set_margin_type_futures(self, coin, margin_mode="isolated"):
        """
        变换逐全仓模式
        :param margin_mode: cross (全仓), isolated (逐仓)
        """
        path = "/api/v2/mix/account/set-margin-mode"
        # 统一变量转换
        bitget_margin_mode = "crossed" if margin_mode.lower() == "cross" else "isolated"
        
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        body = {
            "symbol": symbol,
            "marginCoin": "USDT",
            "marginMode": bitget_margin_mode,
            "productType": "USDT-FUTURES"
        }
        try:
            res = self.client.post(path, body=body)
            logger.debug(f"BITGET 设置逐全仓模式 {bitget_margin_mode} 结果: {res}")
            return res
        except Exception as e:
            if "already" in str(e).lower() or "40017" in str(e):
                logger.info(f"BITGET {coin} 已经是 {margin_mode} 模式，无需修改。")
                return {"msg": "already in target mode"}
            logger.error(f"BITGET {coin} 设置逐全仓模式异常: {e}")
            return None

    def set_coin_config_futures(self, coin, lever, margin_mode=None):
        """
        设置合约代币的配置-杠杆和仓位模式
        :param coin: 币名
        :param lever: 杠杆倍数
        :param margin_mode: cross (全仓), isolated (逐仓)
        :return:
        """
        # 如果提供了 margin_mode，则执行设置
        if margin_mode:
            self.set_margin_type_futures(coin, margin_mode)

        path = "/api/v2/mix/account/set-leverage"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        body = {
            "symbol": symbol,
            "marginCoin": "USDT",
            "leverage": str(lever),
            "marginMode": margin_mode if margin_mode else "isolated",
            "holdSide": "short",
            "productType": "USDT-FUTURES"
        }
        res = self.client.post(path, body=body)
        logger.debug(res)
        if res and res.get("code") == "00000":
             return self.get_coin_config_futures(coin)
        return Common().return_futures_coin_config_struct("BITGET", coin, lever, margin_mode if margin_mode else "isolated")


