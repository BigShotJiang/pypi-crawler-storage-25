from loguru import logger
from exhub import Config
from exhub import Common
class Account:
    """Bitget 账户 API"""
    def __init__(self, client):
        self.client = client

    def get_balances(self, coin, asset_type):
        """获取账户资产 (聚合)"""
        if asset_type == "spot":
            path = "/api/v2/spot/account/assets"
            params = {}
            if coin:
                params["coin"] = coin

            res = self.client.get(path, params=params)
            logger.debug(res)
            if res.get("code") == "00000":
                data = res["data"][0]
                return Common().return_asset_struct("BITGET", "spot", coin, data["available"])
            raise Exception(f"api error :{res.get('msg')}")
        elif asset_type == "fund":
            path = "/api/v2/account/funding-assets"
            params = {}
            if coin:
                params["coin"] = coin
            res = self.client.get(path, params=params)
            logger.debug(res)
            if res.get("code") == "00000":
                data = res["data"][0]
                return Common().return_asset_struct("BITGET", "fund", coin, data["available"])
            raise Exception(f"api error :{res.get('msg')}")
        elif asset_type == "futures":
            path = "/api/v2/mix/account/accounts"
            params = {}
            if coin:
                params["productType"] = coin+"-FUTURES"
            res = self.client.get(path, params=params)
            logger.debug(res)
            if res.get("code") == "00000":
                data = res["data"][0]
                return Common().return_asset_struct("BITGET", "futures", coin, data["available"])
            raise Exception(f"api error :{res.get('msg')}")
        return None


    def transfer(self, coin, type_from, type_to, amount, symbol=None, clientOid=None):
        """
        账户间资金划转
        :param coin: 划转币种
        :param amount: 划转数量
        :param fromType: 转出账户 - "spot"/"p2p"/"coin_futures"/"usdt_futures"/"usdc_futures"/"crossed_margin"/"isolated_margin"
        :param toType: 转入账户（同上）
        :param symbol: 逐仓杠杆交易对 (逐仓杠杆必填)
        :param clientOid: 客户自定义ID
        """
        path = "/api/v2/spot/wallet/transfer"

        body = {
            "coin": coin,
            "amount": str(amount),
            "fromType": Config().unify_variables_transfer_type("BITGET", f = type_from),
            "toType": Config().unify_variables_transfer_type("BITGET", t = type_to),
        }

        if symbol:
            body["symbol"] = symbol
        if clientOid:
            body["clientOid"] = clientOid

        res = self.client.post(path, body)
        logger.debug(res)

        if res.get("code") == "00000":
            data = res.get("data", {})
            logger.success(f"划转成功 - 划转ID: {data.get('transferId')}, 币种: {coin}, 数量: {amount}")
            return Common().return_transfer_struct("BITGET", type_from, type_to, coin, amount)
        else:
            raise Exception(res.get("msg", "Unknown error"))

