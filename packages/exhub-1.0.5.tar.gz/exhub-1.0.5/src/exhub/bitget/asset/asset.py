from .account import Account

class Asset:
    """Bitget Asset 聚合接口"""
    def __init__(self, client):
        self.client = client
        self.account = Account(client)

    def get_balances(self, coin, asset_type):
        """获取现货账户资产"""
        return self.account.get_balances(coin,asset_type)

    def transfer(self, coin, type_from, type_to, amount, symbol=None, clientOid=None):
        """账户间资金划转"""
        return self.account.transfer(coin, type_from, type_to, amount, symbol, clientOid)
