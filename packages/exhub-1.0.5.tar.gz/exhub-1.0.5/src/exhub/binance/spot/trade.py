from loguru import logger
from exhub import Common
from decimal import Decimal
class SpotTrade:
    """Binance 现货交易实现"""
    def __init__(self, client):
        self.client = client

    def order(self, coin, side, order_type, amount):
        """
        下单 (TRADE)
        POST /api/v3/order
        https://developers.binance.com/docs/zh-CN/binance-spot-api-docs/rest-api/trading-endpoints#%E4%B8%8B%E5%8D%95-trade
        :param quantity:  数量
        :param symbol: 交易对 (如 BTCUSDT)
        :param side: 订单方向 (BUY, SELL)
        :param order_type: 订单类型 (LIMIT, MARKET, STOP_LOSS, STOP_LOSS_LIMIT,TAKE_PROFIT,TAKE_PROFIT_LIMIT,LIMIT_MAKER)
        :param kwargs: 其他可选参数 (timeInForce, price, etc.)
        """
        path = "/api/v3/order"
        params = {
            "symbol":coin.upper() if coin.upper().endswith("USDT") else coin.upper()+"USDT",
            "side": side.upper(),
            "type": order_type.upper(),
            "quantity": amount,
        }
        
        res = self.client.post(path, params=params, signed=True)
        logger.debug(res)
        if res.get("status") == "FILLED":
            logger.success(f'下单成功: {res.get("orderId")}')
            return Common().return_order_struct("BINANCE", coin, side, order_type, amount,res.get("orderId"),"",res)
        raise Exception(res.get("msg", "Unknown error"))

    def get_orders_status(self, coin,order_id):
        """
        查询订单状态 (USER_DATA)
        GET /api/v3/order
        https://developers.binance.com/docs/zh-CN/binance-spot-api-docs/rest-api/account-endpoints#%E6%9F%A5%E8%AF%A2%E8%AE%A2%E5%8D%95-user_data
        :param order_id: 订单ID
        :param coin: 交易对 (如 BTCUSDT)
        """
        path = "/api/v3/order"
        params = {"symbol":coin.upper() if coin.upper().endswith("USDT") else coin.upper()+"USDT", "orderId": order_id}
        res = self.client.get(path, params=params, signed=True)
        logger.debug(res)
        t_status = res.get("status")
        if t_status == "FILLED":
            order_status = "FILLED"
        elif t_status in ["PARTIALLY_FILLED","PENDING_NEW","NEW"]:
            order_status = "PROCESSING"
        else:
            order_status = "FAILED"
        return Common().return_order_status_struct("BINANCE", res.get("symbol"), order_id, res.get("side"), res.get("type"),order_status,res)

    def get_order_info(self, coin,order_id):
        """
        查询订单信息 (USER_DATA)
        GET /api/v3/myTrades
        https://developers.binance.com/docs/zh-CN/binance-spot-api-docs/rest-api/account-endpoints#%E6%9F%A5%E8%AF%A2%E8%AE%A2%E5%8D%95-user_data
        :param order_id: 订单ID
        :param coin: 交易对 (如 BTCUSDT)
        """
        path = "/api/v3/myTrades"
        params = {"symbol": coin.upper() if coin.upper().endswith("USDT") else coin.upper() + "USDT", "orderId": order_id}
        res = self.client.get(path, params=params, signed=True)
        logger.debug(res)
        res_coin = None
        sum_amount = Decimal(0)
        sum_value_usd = Decimal(0)
        for partial_order in res:
            sum_amount += Decimal(partial_order.get("qty"))
            sum_value_usd += Decimal(partial_order.get("quoteQty"))
            res_coin = partial_order.get("symbol")
        return Common().return_order_info_struct("BINANCE", res_coin,sum_amount, order_id, sum_value_usd,sum_value_usd/sum_amount,res)
