from loguru import logger
from decimal import Decimal
from exhub import Common

class SpotMarket:
    """现货行情 API"""
    def __init__(self, client):
        self.client = client


    def get_coin_network_info(self, symbol=None, chain=None):
        """获取所有币种信息"""
        path = "/sapi/v1/capital/config/getall"

        if chain:
            return_data = Common().return_coin_network_info_struct("BINANCE", False, False, None, 0)
        else:
            return_data = {"BINANCE": []}

        res = self.client.get(path, signed=True)

        if res:
            for coin_info in res:
                if coin_info.get("coin") == symbol:
                    network_list = coin_info.get("networkList", [])
                    logger.info(f'币种: {coin_info.get("coin")}, 支持链: {len(network_list)}个')

                    for chain_data in network_list:
                        chain_name = chain_data.get("network")
                        ct_addr = chain_data.get("contractAddress") if chain_data.get("contractAddress") else None
                        can_wd = chain_data.get("withdrawEnable", False)
                        can_dep = chain_data.get("depositEnable", False)

                        if chain_name == chain:
                            return_data = Common().return_coin_network_info_struct("BINANCE", can_wd, can_dep, ct_addr, chain_data.get("withdrawFee", 0))
                            logger.info(f'  - 链: {chain_name}, 提现状态: {can_wd}, 充值状态: {can_dep}, 币种合约地址: {ct_addr}')
                        else:
                            if not chain:
                                new_entry = {
                                    "dex_chain_name": None,
                                    "cex_chain_name": chain_name,
                                    "withdraw_status": can_wd,
                                    "deposit_status": can_dep,
                                    "contract_address": ct_addr,
                                    "withdraw_fee": chain_data.get("withdrawFee"),
                                }
                                return_data["BINANCE"].append(new_entry)
                            logger.debug(f'  - 链: {chain_name}, 提现状态: {can_wd}, 充值状态: {can_dep}, 币种合约地址: {ct_addr}')

        return return_data


    def get_coin_info(self, coin):
        """获取交易规范信息"""
        path = "/api/v3/exchangeInfo"
        params = {"symbol": coin.upper() + "USDT"}
        
        swap_status = False
        min_unit = 0
        
        res = self.client.get(path, params=params, signed=False)
        logger.debug(res)
        if res and "symbols" in res:
            for sym_info in res.get("symbols", []):
                if sym_info.get("baseAsset") == coin and sym_info.get("status") == "TRADING" and sym_info.get("isSpotTradingAllowed") == True:
                    swap_status = True
                    min_qty_filter = next((f for f in sym_info.get("filters", []) if f.get("filterType") == "LOT_SIZE"), {})
                    min_unit = min_qty_filter.get("minQty", 0)
        
        return Common().return_coin_info_struct("BINANCE", swap_status, min_unit)

    def get_klines(self, coin, interval, limit=1):
        """获取K线数据"""
        path = "/api/v3/klines"
        params = {"symbol": coin.upper()+"USDT", "interval": interval, "limit": limit}
        
        volume = 0
        res = self.client.get(path, params=params, signed=False)
        if res and isinstance(res, list) and len(res) > 0:
            data = res[0]
            volume = data[7]
            
        return Common().return_klines_struct("BINANCE", volume)