import hmac
import hashlib
import time
import requests
import urllib.parse
from loguru import logger

class BinanceClient:
    """Binance API 基础客户端"""
    def __init__(self, api_key, api_secret, base_url="https://api.binance.com"):
        self.api_key = api_key
        self.api_secret = api_secret
        self.base_url = base_url
        self.fapi_url = "https://fapi.binance.com"
        self.dapi_url = "https://dapi.binance.com"
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json;charset=utf-8',
            'X-MBX-APIKEY': self.api_key
        })

    def _get_timestamp(self):
        """获取当前时间戳（毫秒）"""
        return int(time.time() * 1000)

    def _sign(self, params):
        """生成签名"""
        query_string = urllib.parse.urlencode(params)
        signature = hmac.new(
            self.api_secret.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        return signature

    def _request(self, method, path, params=None, signed=False):
        """统一请求方法"""
        if path.startswith("http"):
            url = path
        elif path.startswith("/fapi"):
            url = self.fapi_url + path
        elif path.startswith("/dapi"):
            url = self.dapi_url + path
        else:
            url = self.base_url + path

        params = params or {}


        params = {k: v for k, v in params.items() if v is not None}

        if signed:
            params['timestamp'] = self._get_timestamp()

            query_string = urllib.parse.urlencode(params)

            signature = hmac.new(
                self.api_secret.encode('utf-8'),
                query_string.encode('utf-8'),
                hashlib.sha256
            ).hexdigest()

            query_string += f"&signature={signature}"
        else:
            query_string = urllib.parse.urlencode(params)

        if query_string:
            separator = "&" if "?" in url else "?"
            url += separator + query_string

        try:

            if method.upper() == 'GET':
                response = self.session.get(url)
            else:
                response = self.session.request(method, url)

            if response.status_code == 200:
                return response.json()
            else:
                try:
                    err = response.json()
                    err_msg = err.get('msg', response.text)
                    err_code = err.get('code', response.status_code)
                    logger.error(f"Binance Request Error: {err_code} - {err_msg}")
                    raise Exception(f"Binance API Error: {err_code} - {err_msg}")
                except ValueError:
                    logger.error(f"Request failed: {response.text}")
                    raise Exception(f"Request failed: {response.text}")

        except Exception as e:
            logger.error(f"Request failed: {e}")
            raise Exception(e)

    def get(self, path, params=None, signed=False):
        return self._request('GET', path, params=params, signed=signed)

    def post(self, path, params=None, signed=True):
        return self._request('POST', path, params=params, signed=signed)

    def delete(self, path, params=None, signed=True):
        return self._request('DELETE', path, params=params, signed=signed)
