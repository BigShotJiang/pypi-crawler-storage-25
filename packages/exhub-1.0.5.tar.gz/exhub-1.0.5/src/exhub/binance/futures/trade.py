from loguru import logger
from exhub import Common
from decimal import Decimal
class FuturesTrade:
    """Binance 币本位合约交易实现"""
    def __init__(self, client):
        self.client = client

    def order_futures(self, coin, side, order_type, size, stop_loss_price=None):
        """
        开仓下单 (TRADE)
        POST /fapi/v1/order
        :param side: 订单方向 (BUY=做多, SELL=做空)
        :param order_type: 订单类型 (MARKET 等)
        :param stop_loss_price: 仅作接口占位，Binance 不支持开仓预设止损；
                                实际止损单由 hub 层在开仓成功后单独补挂 algoOrder (CONDITIONAL)
        """
        # XXX: positionSide 必须在 side.upper() 之后判断
        pos_side = "LONG" if side.upper() == "BUY" else "SHORT"
        path = "/fapi/v1/order"
        params = {
            "symbol": coin if coin.endswith("USDT") else coin + "USDT",
            "side": side.upper(),
            "type": order_type.upper(),
            "quantity": size,
            "positionSide": pos_side,
        }
        res = self.client.post(path, params=params, signed=True)
        logger.debug(res)
        order_id = res.get("orderId")
        return Common().return_futures_order_struct("BINANCE", coin, side, order_type, size, order_id, res)

    def close_position_futures(self, coin, side, order_type, size):
        """
        平仓 (Close Position)
        POST /fapi/v1/order
        :param coin: 币本位合约 (如 BTCUSDT)
        :param side: 开仓方向 (BUY/SELL) 或持仓方向 (LONG/SHORT)
        :param order_type: 订单类型 (如 MARKET)
        :param size: 数量
        """
        path = "/fapi/v1/order"
        
        order_side, pos_side = self._normalize_pos_side(side)
        
        params = {
            "symbol": coin if coin.endswith("USDT") else coin + "USDT",
            "side": order_side,
            "type": order_type,
            "quantity": size,
            "positionSide": pos_side
        }
        res = self.client.post(path, params=params, signed=True)
        logger.debug(res)
        order_id = res.get("orderId")
        return Common().return_futures_order_struct("BINANCE", coin, side, order_type, size, order_id, res)

    def get_position_futures(self, coin):
        """
        获取仓位信息 (Get Position)
        GET /fapi/v3/positionRisk
        https://developers.binance.com/docs/zh-CN/derivatives/usds-margined-futures/trade/rest-api/Position-Information-V3
        :param coin: 币本位合约 (如 BTCUSDT)
        :return: list of positions [dict] or []
        """
        path = "/fapi/v3/positionRisk"
        symbol = coin if coin.endswith("USDT") else coin + "USDT"
        params = {"symbol": symbol}
        res = self.client.get(path, params=params, signed=True)
        logger.debug(res)
        
        algos = []
        try:
            algos_res = self.client.get("/fapi/v1/openAlgoOrders", params={"symbol": symbol}, signed=True)
            if isinstance(algos_res, list):
                logger.warning(algos_res)
                algos = algos_res
        except Exception as e:
            logger.warning(f"Binance 获取当前挂单(止盈止损)失败: {e}")
            
        positions = []
        if isinstance(res, list):
            for item in res:
                if item.get("symbol") == symbol:
                    size = float(item.get("positionAmt", 0))
                    if size != 0:
                        pos_side = item.get("positionSide")
                        if not pos_side or pos_side == "BOTH":
                            side_str = "LONG" if size > 0 else "SHORT"
                        else:
                            side_str = pos_side.upper()
                        size_abs = abs(size)
                        entry_price = float(item.get("entryPrice", 0))
                        unrealized_profit = item.get("unRealizedProfit", 0)
                        liquidation_price = item.get("liquidationPrice", 0)
                        
                        all_stop_loss_price = ""
                        all_take_profit_price = ""
                        partial_stop_loss = {"size": "0", "price": "0"}
                        partial_take_profit = {"size": "0", "price": "0"}
                        
                        for a in algos:
                            if a.get("positionSide") == side_str:
                                otype = a.get("orderType", "")
                                trigger = a.get("stopPrice", "")
                                if not trigger: trigger = a.get("triggerPrice", "")
                                sz = a.get("quantity", "")
                                
                                is_sl = otype in ("STOP_MARKET", "STOP")
                                is_tp = otype in ("TAKE_PROFIT_MARKET", "TAKE_PROFIT")
                                
                                if a.get("closePosition"):
                                    if is_sl: all_stop_loss_price = trigger
                                    if is_tp: all_take_profit_price = trigger
                                else:
                                    if is_sl: partial_stop_loss = {"size": str(sz), "price": str(trigger)}
                                    if is_tp: partial_take_profit = {"size": str(sz), "price": str(trigger)}
                        
                        pos_info = Common().return_futures_position_struct(
                            coin, size_abs, entry_price, side_str, unrealized_profit, liquidation_price, 
                            all_stop_loss_price, all_take_profit_price, partial_stop_loss, partial_take_profit, item
                        )
                        positions.append(pos_info)
                        
        return {"BINANCE": positions}

    @staticmethod
    def _normalize_pos_side(side: str) -> tuple[str, str]:
        """
        统一 side 参数转换：兼容 BUY/SELL 与 LONG/SHORT 两种传参风格。
        :return: (order_side, pos_side) —— order_side 是下单方向，pos_side 是持仓方向
        """
        s = side.upper()
        # 如果传的是持仓方向 LONG/SHORT
        if s in ("LONG", "SHORT"):
            pos_side = s
            order_side = "SELL" if s == "LONG" else "BUY"  # 平仓方向与持仓相反
        else:
            # 传的是开仓方向 BUY/SELL：止损/止盈是平仓操作，方向必须反转
            # XXX: BUY 开多 → 止损需要 SELL 平多；SELL 开空 → 止损需要 BUY 平空
            pos_side = "LONG" if s == "BUY" else "SHORT"
            order_side = "SELL" if s == "BUY" else "BUY"  # 反转开仓方向得到平仓方向
        return order_side, pos_side

    def set_stop_loss_futures(self, coin, side, size, stop_price):
        """
        设置止损单
        POST /fapi/v1/algoOrder  algoType=CONDITIONAL  type=STOP_MARKET
        :param side: 开仓方向 (BUY/SELL) 或持仓方向 (LONG/SHORT)，内部自动反转为平仓方向
        :param size: 数量，为 0/None 时使用 closePosition=true 全平
        """
        # _normalize_pos_side 内部反转
        order_side, pos_side = self._normalize_pos_side(side)
        symbol = coin if coin.endswith("USDT") else coin + "USDT"

        params = {
            "algoType": "CONDITIONAL",
            "symbol": symbol,
            "side": order_side,
            "positionSide": pos_side,
            "type": "STOP_MARKET",
            "triggerPrice": str(stop_price),
            "workingType": "CONTRACT_PRICE",
            # XXX: GTE_GTC = Good Till Expiry，将条件单与仓位生命周期绑定，仓位关闭时自动取消
            "timeInForce": "GTE_GTC",
        }
        if size:
            params["quantity"] = str(size)
        else:
            params["closePosition"] = "true"

        res = self.client.post("/fapi/v1/algoOrder", params=params, signed=True)
        logger.debug(res)
        status = "algoId" in res or res.get("code") == 200
        return Common().return_set_stop_loss_struct("BINANCE", coin, status, res)

    def set_take_profit_futures(self, coin, side, size, tp_price):
        """
        设置止盈单
        POST /fapi/v1/algoOrder  algoType=CONDITIONAL  type=TAKE_PROFIT_MARKET
        :param side: 开仓方向 (BUY/SELL) 或持仓方向 (LONG/SHORT)，内部自动反转
        :param size: 数量，为 0/None 时使用 closePosition=true 全平
        """
        order_side, pos_side = self._normalize_pos_side(side)
        symbol = coin if coin.endswith("USDT") else coin + "USDT"

        params = {
            "algoType": "CONDITIONAL",
            "symbol": symbol,
            "side": order_side,
            "positionSide": pos_side,
            "type": "TAKE_PROFIT_MARKET",
            "triggerPrice": str(tp_price),
            "workingType": "CONTRACT_PRICE",
            # XXX: GTE_GTC = Good Till Expiry，将条件单与仓位生命周期绑定，仓位关闭时自动取消
            "timeInForce": "GTE_GTC",
        }
        if size:
            params["quantity"] = str(size)
        else:
            params["closePosition"] = "true"

        res = self.client.post("/fapi/v1/algoOrder", params=params, signed=True)
        logger.debug(res)
        status = "algoId" in res or res.get("code") == 200
        return Common().return_set_take_profit_struct("BINANCE", coin, status, res)

    def update_stop_loss_futures(self, coin, side, size, stop_price):
        """
        修改止损：查询 openAlgoOrders 后按 algoId 精准撤止损单，保留止盈单
        GET  /fapi/v1/openAlgoOrders  (仅传 symbol，在返回结果中按 positionSide 过滤)
        DELETE /fapi/v1/algoOrder     (按 algoId 撤单)
        """
        symbol = coin if coin.endswith("USDT") else coin + "USDT"
        _, pos_side = self._normalize_pos_side(side)
        try:
            algos = self.client.get("/fapi/v1/openAlgoOrders", params={"symbol": symbol}, signed=True)
            if isinstance(algos, list):
                for a in algos:
                    if a.get("orderType") in ("STOP_MARKET", "STOP") and a.get("positionSide") == pos_side:
                        if size == 0 and a.get("closePosition"):   # 全部仓位
                            self.client.delete("/fapi/v1/algoOrder",params={"symbol": symbol, "algoId": a["algoId"]},signed=True)
                        if size > 0 and not a.get("closePosition") : # 部分仓位
                            self.client.delete("/fapi/v1/algoOrder",params={"symbol": symbol, "algoId": a["algoId"]},signed=True)
        except Exception as e:
            logger.warning(f"Binance 更新止损撤旧单异常: {e}")

        return self.set_stop_loss_futures(coin, side, size, stop_price)

    def update_take_profit_futures(self, coin, side, size, tp_price):
        """
        修改止盈：查询 openAlgoOrders 后按 algoId 精准撤止盈单，保留止损单
        """
        symbol = coin if coin.endswith("USDT") else coin + "USDT"
        _, pos_side = self._normalize_pos_side(side)
        try:
            algos = self.client.get("/fapi/v1/openAlgoOrders", params={"symbol": symbol}, signed=True)
            if isinstance(algos, list):
                for a in algos:
                    if a.get("orderType") in ("TAKE_PROFIT_MARKET", "TAKE_PROFIT") and a.get("positionSide") == pos_side:
                        if size == 0 and a.get("closePosition"):   # 全部仓位
                            self.client.delete("/fapi/v1/algoOrder",params={"symbol": symbol, "algoId": a["algoId"]},signed=True)
                        if size > 0 and not a.get("closePosition") : # 部分仓位
                            self.client.delete("/fapi/v1/algoOrder",params={"symbol": symbol, "algoId": a["algoId"]},signed=True)
        except Exception as e:
            logger.warning(f"Binance 更新止盈撤旧单异常: {e}")

        return self.set_take_profit_futures(coin, side, size, tp_price)

    def get_recent_pnl(self, coin):
        """
        获取最近一笔平仓的已实现盈亏
        GET /fapi/v1/income
        """
        symbol = coin if coin.endswith("USDT") else coin + "USDT"
        path = "/fapi/v1/income"

        params = {"symbol": symbol, "limit": 30}
        res = self.client.get(path, params=params, signed=True)
        logger.debug(res)
        pnl = 0.0
        if isinstance(res, list) and len(res) > 0:
            latest_time = res[-1].get("time", 0)
            for item in reversed(res):
                if latest_time - item.get("time", 0) < 5000: # 5秒内的收入线(平仓+手续费)合并计算
                    pnl += float(item.get("income", 0))
                else:
                    break
        return Common().return_pnl_struct("BINANCE", coin, pnl)
