from .common import BinanceClient
from .asset import Asset
from .spot import Spot
from .futures import Futures

class BINANCE:
    """Binance API 主类"""
    def __init__(self, api_key, api_secret):
        self.client = BinanceClient(api_key, api_secret)
        self.spot = Spot(self.client)
        self.asset = Asset(self.client)
        self.futures = Futures(self.client)
