from .account import Account

class Asset:
    """Asset 聚合接口"""
    def __init__(self, client):
        self.client = client
        self.account = Account(client)

    def get_balances(self, coin, asset_type):
        """查询用户钱包余额"""
        return self.account.get_balances(coin, asset_type)

    def transfer(self, type_from, type_to, coin, amount, fromSymbol=None, toSymbol=None):
        """用户万向划转"""
        return self.account.transfer(type_from, type_to, coin, amount, fromSymbol, toSymbol)