from .market import SpotMarket
from .trade import SpotTrade

class Spot:
    """OKX Spot 聚合接口"""
    def __init__(self, client):
        self.client = client
        self.market = SpotMarket(client)
        self.trade = SpotTrade(client)

    def get_coin_network_info(self, coin=None, network=None):
        """获取币种信息"""
        return self.market.get_coin_network_info(coin, network)

    def get_coin_info(self, coin):
        """获取所有可交易产品的信息列表"""
        return self.market.get_coin_info(coin)

    def get_klines(self, coin, interval, limit=1):
        """获取K线数据"""
        return self.market.get_klines(coin, interval, limit)

    def order(self,coin, side, order_type, amount):
        """下单"""
        return self.trade.order(coin, side, order_type, amount)

    def get_orders_status(self, coin, order_id):
        """查询订单状态"""
        return self.trade.get_orders_status(coin, order_id)

    def get_order_info(self, coin, order_id):
        """查询订单信息"""
        return self.trade.get_order_info(coin, order_id)
