from decimal import Decimal
import time
from loguru import logger
from exhub import Common

class FuturesMarket():
    """OKX 合约市场"""
    def __init__(self, client):
        self.client = client

    def get_prices_futures(self, coin):
        """
        获取指定代币对价格
        GET /api/v5/market/ticker
        https://www.okx.com/docs-v5/zh/#public-data-rest-api-get-ticker
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        symbol = symbol.replace("USDT", "-USDT") if "USDT" in symbol and "-" not in symbol else symbol
        if symbol.endswith("-USDT"):
            symbol = symbol + "-SWAP"
            
        path = "/api/v5/market/ticker"
        params = {
            "instId": symbol
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        if res and res.get("code") == "0" and res.get("data"):
            data = res["data"][0]
            coin_res = data.get("instId", symbol).replace("-SWAP", "").replace("-", "")
            price = data.get("last")
            ts = data.get("ts", int(time.time()*1000))
            return Common().return_futures_price_struct("OKX", coin_res, price, ts)
        return None

    def get_coin_info_futures(self, coin):
        """
        获取合约交易规范信息
        GET /api/v5/public/instruments
        https://www.okx.com/docs-v5/zh/#public-data-rest-api-get-instruments
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        symbol = symbol.replace("USDT", "-USDT") if "USDT" in symbol and "-" not in symbol else symbol
        if symbol.endswith("-USDT"):
            symbol = symbol + "-SWAP"
            
        path = "/api/v5/public/instruments"
        params = {
            "instType": "SWAP",
            "instId": symbol
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        
        if res and res.get("code") == "0" and res.get("data"):
            data = res["data"][0]
            coin_res = data.get("instId", symbol).replace("-SWAP", "").replace("-", "")
            min_unit = data.get("lotSz", "1")  # OKX 使用 lotSz 作为下单最小单位（张数步进）
            price_unit = data.get("tickSz", "0.01") # 价格步进
            
            ct_val = data.get("ctVal", "1") # 合约面值
            swap_status = data.get("state") == "live"
            max_lever = data.get("lever", "10")
            min_lever = 1
            return Common().return_futures_coin_info_struct("OKX", coin_res, swap_status, Decimal(str(min_unit)), Decimal(str(price_unit)), Decimal(str(min_lever)), Decimal(str(max_lever)), Decimal(str(ct_val)))
        else:
            return Common().return_futures_coin_info_struct("OKX", coin, False, "1", "0.01", 1, 100, Decimal('1.0'))

    def get_coin_config_futures(self, coin):
        """
        获取合约代币的配置-杠杆配置信息
        GET /api/v5/account/leverage-info
        https://www.okx.com/docs-v5/zh/#custom-trading-rest-api-get-leverage
        :param coin:
        :return:
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        symbol = symbol.replace("USDT", "-USDT") if "USDT" in symbol and "-" not in symbol else symbol
        if symbol.endswith("-USDT"):
            symbol = symbol + "-SWAP"
            
        path = "/api/v5/account/leverage-info"
        params = {
            "instId": symbol,
            "mgnMode": "isolated"
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        leverage = 0
        margin_mode = "cross"
        if res and res.get("code") == "0" and res.get("data"):
            for item in res["data"]:
                # OKX 逐仓模式下可能分多空返回杠杆
                if item.get("posSide") == "short" or item.get("posSide") == "net":
                    leverage = item.get("lever", leverage)
                    margin_mode = item.get("mgnMode", "cross")
        return Common().return_futures_coin_config_struct("OKX", coin, leverage, margin_mode)

    def set_margin_type_futures(self, coin, margin_mode="isolated"):
        """
        变换逐全仓模式
        :param margin_mode: cross (全仓), isolated (逐仓)
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        symbol = symbol.replace("USDT", "-USDT") if "USDT" in symbol and "-" not in symbol else symbol
        if symbol.endswith("-USDT"):
            symbol = symbol + "-SWAP"
            
        path = "/api/v5/account/set-margin-mode"
        # OKX 已经使用 cross 和 isolated
        okx_margin_mode = "cross" if margin_mode.lower() == "cross" else "isolated"
        
        body = {
            "instId": symbol,
            "mgnMode": okx_margin_mode
        }
        try:
            res = self.client.post(path, body=body)
            logger.debug(f"OKX 设置逐全仓模式 {okx_margin_mode} 结果: {res}")
            return res
        except Exception as e:
            if "50028" in str(e) or "already" in str(e).lower() or "51025" in str(e):
                logger.info(f"OKX {coin} 已经是 {margin_mode} 模式，无需修改。")
                return {"msg": "already in target mode"}
            logger.error(f"OKX {coin} 设置逐全仓模式异常: {e}")
            return None

    def set_coin_config_futures(self, coin, lever, margin_mode=None):
        """
        设置合约代币的配置-杠杆和仓位模式
        :param coin: 币名
        :param lever: 杠杆倍数
        :param margin_mode: cross (全仓), isolated (逐仓)
        :return:
        """
        # 如果提供了 margin_mode，则执行设置
        if margin_mode:
            self.set_margin_type_futures(coin, margin_mode)

        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        symbol = symbol.replace("USDT", "-USDT") if "USDT" in symbol and "-" not in symbol else symbol
        if symbol.endswith("-USDT"):
            symbol = symbol + "-SWAP"
            
        path = "/api/v5/account/set-leverage"
        # OKX 设置杠杆需要指定 mgnMode
        okx_mgn_mode = margin_mode if margin_mode else "isolated"
        body = {
            "instId": symbol,
            "mgnMode": okx_mgn_mode,
            "posSide": "short",
            "lever": str(lever)
        }
        res = self.client.post(path, body=body)
        logger.debug(res)
        if res and res.get("code") == "0":
            return self.get_coin_config_futures(coin)
        return Common().return_futures_coin_config_struct("OKX", coin, lever, okx_mgn_mode)

