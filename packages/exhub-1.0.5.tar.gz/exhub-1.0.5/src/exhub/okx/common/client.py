import hmac
import base64
import json
import requests
import urllib.parse
from datetime import datetime, timezone
from loguru import logger

class OKXClient:
    """OKX API 基础客户端"""
    def __init__(self, api_key, api_secret, passphrase, is_demo=False):
        self.api_key = api_key
        self.api_secret = api_secret
        self.passphrase = passphrase
        self.base_url = "https://www.okx.com"
        if is_demo:
            self.base_url = "https://www.okx.com/api-test"

    def _get_timestamp(self):
        """获取 ISO 格式时间戳"""
        return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')

    def _sign(self, timestamp, method, request_path, body=''):
        """生成签名"""
        if isinstance(body, (dict, list)):
            body = json.dumps(body)
        message = timestamp + method.upper() + request_path + body
        mac = hmac.new(
            bytes(self.api_secret, encoding='utf-8'),
            bytes(message, encoding='utf-8'),
            digestmod='sha256'
        )
        return base64.b64encode(mac.digest()).decode()

    def _request(self, method, request_path, body='', params=None):
        """统一请求方法"""
        timestamp = self._get_timestamp()
        
        # 处理参数和签名路径
        sign_path = request_path
        if params:
            # 过滤掉 None 值并进行标准 URL 编码
            filtered_params = {k: v for k, v in params.items() if v is not None}
            if filtered_params:
                query_string = urllib.parse.urlencode(filtered_params)
                sign_path += '?' + query_string
        
        # 处理请求 Body
        request_body = ''
        if body:
            request_body = json.dumps(body) if isinstance(body, (dict, list)) else str(body)
        
        # 生成签名
        signature = self._sign(timestamp, method, sign_path, request_body)
        
        headers = {
            'Content-Type': 'application/json',
            'OK-ACCESS-KEY': self.api_key,
            'OK-ACCESS-SIGN': signature,
            'OK-ACCESS-TIMESTAMP': timestamp,
            'OK-ACCESS-PASSPHRASE': self.passphrase,
        }

        # 拼装完整 URL (如果已经有 query_string)
        url = self.base_url + sign_path
        
        try:
            if method.upper() == 'GET':
                response = requests.get(url, headers=headers, timeout=30)
            elif method.upper() == 'POST':
                response = requests.post(url, headers=headers, data=request_body, timeout=30)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            return response.json()
        except Exception as e:
            logger.error(f"OKX API 请求异常 [{method} {request_path}]: {e}")
            return {"code": "-1", "msg": str(e), "data": []}

    def get(self, path, params=None):
        return self._request('GET', path, params=params)

    def post(self, path, body=None):
        return self._request('POST', path, body=body or {})
