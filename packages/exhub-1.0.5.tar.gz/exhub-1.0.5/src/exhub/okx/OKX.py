from .common import OKXClient
from .spot.spot import Spot
from .asset.asset import Asset
from .futures.futures import Futures


class OKX:
    """OKX API 主类"""
    def __init__(self, api_key, api_secret, passphrase, is_demo=False):
        self.is_demo = is_demo
        self.client = OKXClient(api_key, api_secret, passphrase, is_demo)
        self.spot = Spot(self.client)
        self.asset = Asset(self.client)
        self.futures = Futures(self.client)

    def __repr__(self):
        return f"<OKX(demo={self.is_demo})>"
