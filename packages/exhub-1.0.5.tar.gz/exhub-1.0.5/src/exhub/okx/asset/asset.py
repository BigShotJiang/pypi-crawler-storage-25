from .account import Account

class Asset:
    """OKX Asset 聚合接口"""
    def __init__(self, client):
        self.client = client
        self.account = Account(client)

    def get_balances(self, coin, asset_type):
        """获取币种余额"""
        return self.account.get_balances(coin, asset_type)

    def transfer(self, coin, amount, type_from, type_to, tag = None,type="0", **kwargs):
        """资金划转"""
        return self.account.transfer(coin, amount, type_from, type_to, tag, type, **kwargs)
