from decimal import Decimal


class Common:
    """
        资产
    """
    def return_asset_struct(self,exchange:str,assset_type:str,coin:str,balance: float|str):
        """统一返回资产数据结构"""
        return {exchange: {"assset_type":assset_type,"coin":coin,"balance":Decimal(str(balance))}}

    def return_transfer_struct(self,exchange:str,from_type:str,to_type:str,coin:str,amount:float|str,data = None):
        """统一返回划转数据结构"""
        return {exchange: {"status":True,"from_type":from_type,"to_type":to_type,"coin":coin,"amount":Decimal(str(amount)),"original_data":data}}



    """
        合约
    """
    def return_futures_coin_info_struct(self, exchange, coin, swap_status, min_unit, price_unit, min_lever, max_lever, ct_val=Decimal('1.0')):
        """统一返回合约交易规范信息数据结构，所有数值字段统一转换为 Decimal"""
        return {
            exchange: {
                "coin": coin,
                "swap_status": swap_status,
                "min_unit": Decimal(str(min_unit)),
                "price_unit": Decimal(str(price_unit)),
                "min_lever": Decimal(str(min_lever)),
                "max_lever": Decimal(str(max_lever)),
                "ct_val": Decimal(str(ct_val))
            }
        }

    def return_futures_price_struct(self,exchange:str,coin:str,price:float|str,ts:int|str):
        """统一返回合约价格数据结构"""
        return {exchange: {"coin":coin,"price":Decimal(str(price)),"ts": int(ts)}}

    def return_futures_order_struct(self,exchange:str,coin:str,side:str,order_type:str,size:float|str,order_id:str,data = None):
        """统一返回合约下单数据结构"""
        return {exchange: {"status":True,"coin":coin,"side":side,"order_type":order_type,"size":Decimal(str(size)),"order_id":order_id,"original_data":data}}

    def return_futures_coin_config_struct(self, exchange, coin, leverage, margin_mode):
        """统一返回合约配置数据结构"""
        return {
            exchange: {
                "coin": coin,
                "cur_lever": Decimal(str(leverage)),
                "margin_mode": margin_mode  # cross (全仓) 或 isolated (逐仓)
            }
        }
    """
        额外合约结构
    """
    def return_set_stop_loss_struct(self, exchange: str, coin: str, status: bool, data=None):
        """统一返回设置止损结果结构"""
        return {
            exchange: {
                "coin": coin,
                "type": "SL",
                "status": status,
                "original_data": data
            }
        }

    def return_set_take_profit_struct(self, exchange: str, coin: str, status: bool, data=None):
        """统一返回设置止盈结果结构"""
        return {
            exchange: {
                "coin": coin,
                "type": "TP",
                "status": status,
                "original_data": data
            }
        }

    def return_pnl_struct(self, exchange: str, coin: str, pnl: float | str):
        """统一返回盈亏结果结构"""
        return {
            exchange: {
                "coin": coin,
                "pnl": Decimal(str(pnl))
            }
        }




    def return_futures_position_struct(self, coin: str, size: float|str, price: float|str, side: str, unrealized_profit: float|str, liquidation_price: float|str, all_stop_loss_price: str|float="0", all_take_profit_price: str|float="0", partial_stop_loss: dict=None, partial_take_profit: dict=None, data=None):
        """统一返回合约持仓数据结构"""
        if partial_stop_loss is None:
            partial_stop_loss = {"size": Decimal("0"), "price": Decimal("0")}
        else:
            partial_stop_loss = {
                "size": Decimal(str(partial_stop_loss.get("size", "0")) if str(partial_stop_loss.get("size", "0")) else "0"),
                "price": Decimal(str(partial_stop_loss.get("price", "0")) if str(partial_stop_loss.get("price", "0")) else "0")
            }
            
        if partial_take_profit is None:
            partial_take_profit = {"size": Decimal("0"), "price": Decimal("0")}
        else:
            partial_take_profit = {
                "size": Decimal(str(partial_take_profit.get("size", "0")) if str(partial_take_profit.get("size", "0")) else "0"),
                "price": Decimal(str(partial_take_profit.get("price", "0")) if str(partial_take_profit.get("price", "0")) else "0")
            }

        return {
            "coin": coin, 
            "size": Decimal(str(size) if str(size) else "0"), 
            "avg_price": Decimal(str(price) if str(price) else "0"), 
            "side": side, 
            "unrealized_profit": Decimal(str(unrealized_profit) if str(unrealized_profit) else "0"), 
            "liquidation_price": Decimal(str(liquidation_price) if str(liquidation_price) else "0"), 
            "all_stop_loss_price": Decimal(str(all_stop_loss_price) if str(all_stop_loss_price) else "0"), 
            "all_take_profit_price": Decimal(str(all_take_profit_price) if str(all_take_profit_price) else "0"), 
            "partial_stop_loss": partial_stop_loss, 
            "partial_take_profit": partial_take_profit, 
            "original_data": data
        }

    """
        现货 & 通用行情
    """
    def return_coin_network_info_struct(self, exchange: str, withdraw_status: bool, deposit_status: bool, contract_address: str | None, withdraw_fee: float | str):
        """统一返回币种网络/链信息数据结构"""
        return {
            exchange: {
                "withdraw_status": withdraw_status,
                "deposit_status": deposit_status,
                "contract_address": contract_address,
                "withdraw_fee": Decimal(str(withdraw_fee))
            }
        }

    def return_coin_info_struct(self, exchange: str, swap_status: bool, min_unit: float | str):
        """统一返回现货交易规范信息"""
        return {
            exchange: {
                "swap_status": swap_status,
                "min_unit": Decimal(str(min_unit))
            }
        }

    def return_klines_struct(self, exchange: str, volume: float | str):
        """统一返回 K 线数据结构"""
        return {
            exchange: {
                "swap_volume": Decimal(str(volume))
            }
        }

    def return_order_struct(self, exchange: str, coin: str, side: str, order_type: str, amount: float | str, order_id: str, client_order_id: str = "", data=None):
        """统一返回下单数据结构"""
        return {
            exchange: {
                "status": True,
                "coin": coin,
                "side": side,
                "order_type": order_type,
                "amount": Decimal(str(amount)),
                "order_id": str(order_id),
                "client_order_id": client_order_id,
                "original_data": data
            }
        }

    def return_order_status_struct(self, exchange: str, coin: str, order_id: str, side: str, order_type: str, status: str, data=None):
        """统一返回订单状态数据结构 (status: FILLED, PROCESSING, FAILED)"""
        return {
            exchange: {
                "coin": coin,
                "order_id": str(order_id),
                "side": side,
                "order_type": order_type,
                "status": status,
                "original_data": data
            }
        }

    def return_order_info_struct(self, exchange: str, coin: str, amount: float | str, order_id: str, value_usd: float | str, avg_price: float | str, data=None):
        """统一返回订单详细成交信息数据结构"""
        return {
            exchange: {
                "coin": coin,
                "amount": Decimal(str(amount)),
                "order_id": str(order_id),
                "value_usd": Decimal(str(value_usd)),
                "avg_price": Decimal(str(avg_price)),
                "original_data": data
            }
        }

