from pydantic import BaseModel
class Config:
    class WithdrawRequest(BaseModel):
        """提币请求体结构"""
        exchange: str
        coin: str
        network: str
        address: str
        amount: float | str
        tag: str | None = None
        custom_orderid: str | None = None
    class TransferRequest(BaseModel):
        """划转请求体结构"""
        exchange: str
        from_type: str
        to_type: str
        coin: str
        amount: float | str

    class OrderRequest(BaseModel):
        """下单请求体结构"""
        exchange: str
        coin: str
        side: str
        order_type: str
        amount: float | str
        # custom_orderid: str | None = None

    class SetLeverRequest(BaseModel):
        """设置杠杆请求体结构"""
        exchange: str
        coin: str
        lever: int

    def unify_variables_asset_type(self, exchange:str, type:str):
        """统一资产类型"""
        asset_map = {
            "BINANCE":{"内部统一"},
            "BITGET":{"内部统一"},
            "OKX":{"内部统一"},
            "BYBIT":{"spot":"UNIFIED","fund":"FUND","futures":"UNIFIED"},
            "GATE":{"spot":"spot","fund":"fund","futures":"futures"},
            "KUCOIN":{"spot":"SPOT","futures":"FUTURES","fund":"FUNDING","cross":"CROSS","isolated":"ISOLATED"},
            "MEXC": {"spot": "spot", "fund": "fund", "futures": "futures"},
            "COINBASE":{"spot":"spot","fund":"fund","futures":"futures"},
            "KRAKEN":{"spot":"spot","fund":"fund","futures":"futures"},
        }
        return asset_map[exchange][type]
    def unify_variables_transfer_type(self, exchange:str, f:str=None, t:str =None):
        """统一划转类型"""
        transfer_map = {
            "BINANCE":{"spot-fund":"MAIN_FUNDING","fund-spot":"FUNDING_MAIN"},
            "BITGET":{"fund":"p2p","spot":"spot","futures":"usdt_futures"},
            "OKX":{"fund":"6","spot":"18","futures":"18"},
            "BYBIT":{"fund":"FUND","spot":"UNIFIED","futures":"UNIFIED"},
            "KUCOIN":{"fund":"MAIN","spot":"TRADE","futures":"CONTRACT","全仓***":"MARGIN","逐仓杠杆**":"ISOLATED"}
        }

        if exchange== "BINANCE":
            return transfer_map[exchange][f + "-" + t]
        else:
            return transfer_map[exchange][f] if f else transfer_map[exchange][t]
