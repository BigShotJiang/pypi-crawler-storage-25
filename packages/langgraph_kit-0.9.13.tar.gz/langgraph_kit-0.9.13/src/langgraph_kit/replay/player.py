"""Replay LLM mock that serves recorded responses for deterministic testing."""

from __future__ import annotations

from difflib import SequenceMatcher
from typing import TYPE_CHECKING, Any, ClassVar

from langchain_core.language_models import (  # pyright: ignore[reportMissingModuleSource]
    BaseChatModel,
)
from langchain_core.messages import (  # pyright: ignore[reportMissingModuleSource]
    AIMessage,
    BaseMessage,
)
from langchain_core.outputs import (  # pyright: ignore[reportMissingModuleSource]
    ChatGeneration,
    ChatResult,
)

from langgraph_kit.replay.models import ConversationRecording, LLMInteraction

if TYPE_CHECKING:
    from langchain_core.language_models import (  # pyright: ignore[reportMissingModuleSource]
        LanguageModelInput,
    )
    from langchain_core.runnables import (  # pyright: ignore[reportMissingModuleSource]
        Runnable,
    )


class ReplayMismatchError(Exception):
    """Raised when the replay LLM receives input that doesn't match any recording."""


class RecordedChatModel(BaseChatModel):
    """A LangChain chat model that serves recorded responses.

    Matches incoming messages against recorded LLM interactions.
    Uses sequential matching by default, with fuzzy content matching as fallback.

    Usage::

        recording = ConversationRecorder.load(Path("fixture.json"))
        llm = RecordedChatModel(recording=recording)
        # Use llm in place of a real LLM when building the graph
    """

    recording: ConversationRecording
    # When False, disable the fuzzy-content-matching fallback and raise
    # ReplayMismatchError as soon as the recorded sequence is exhausted
    # or an input doesn't line up. Safer for CI assertions but harder on
    # minor prompt edits. Leave True for human-friendly reproduction.
    fuzzy_match: bool = True
    _call_index: int = 0

    model_config: ClassVar[dict[str, Any]] = {"arbitrary_types_allowed": True}

    @property
    def _llm_type(self) -> str:
        return "recorded-chat-model"

    def _generate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,  # noqa: ARG002
        run_manager: Any = None,  # noqa: ARG002
        **kwargs: Any,  # noqa: ARG002
    ) -> ChatResult:
        """Serve the next recorded response."""
        llm_interactions = self.recording.llm_interactions

        # Try sequential match first
        if self._call_index < len(llm_interactions):
            interaction = llm_interactions[self._call_index]
            self._call_index += 1
            return _interaction_to_result(interaction)

        last_content = _extract_content(messages[-1]) if messages else ""

        # Fallback: fuzzy match on last message content. Opt-in so strict
        # CI replays can fail fast on prompt drift instead of silently
        # re-serving an already-consumed interaction.
        if self.fuzzy_match:
            for interaction in llm_interactions:
                if interaction.input_messages and _fuzzy_match(
                    last_content, interaction.input_messages
                ):
                    return _interaction_to_result(interaction)

        msg = (
            f"No recorded response for call #{self._call_index + 1}. "
            f"Recording has {len(llm_interactions)} LLM interactions. "
            f"Last input: {last_content[:100]!r}"
        )
        raise ReplayMismatchError(msg)

    @property
    def _identifying_params(self) -> dict[str, Any]:
        return {
            "recording_id": self.recording.id,
            "agent_id": self.recording.agent_id,
            "total_interactions": len(self.recording.llm_interactions),
        }

    def bind_tools(
        self,
        tools: Any,  # noqa: ARG002
        *,
        tool_choice: Any = None,  # noqa: ARG002
        **kwargs: Any,  # noqa: ARG002
    ) -> Runnable[LanguageModelInput, AIMessage]:
        """Return self unchanged — recorded responses already include tool calls.

        ``create_agent`` (and any LangChain agent flow) calls ``bind_tools``
        on its model during construction so the LLM can see the active
        tool schemas. A recording is served verbatim: whatever
        ``tool_calls`` the recorded LLM decided on are already baked into
        each ``LLMInteraction.output_message``. The bound tool list
        doesn't change what we emit, so binding is a no-op and we hand
        back the same model.

        Without this override, ``BaseChatModel.bind_tools`` raises
        ``NotImplementedError`` and the recorded model cannot drive a
        real compiled graph — defeating the whole point of the replay
        system.
        """
        return self


def _interaction_to_result(interaction: LLMInteraction) -> ChatResult:
    """Convert a recorded LLM interaction to a ChatResult."""
    output = interaction.output_message
    content = output.get("content", "")
    tool_calls = output.get("tool_calls", [])

    message = AIMessage(
        content=content,
        tool_calls=tool_calls if tool_calls else [],
    )

    return ChatResult(
        generations=[ChatGeneration(message=message)],
        llm_output=interaction.token_usage or {},
    )


def _extract_content(msg: BaseMessage) -> str:
    """Extract text content from a LangChain message."""
    if isinstance(msg.content, str):
        return msg.content
    if isinstance(msg.content, list):
        parts = [
            p.get("text", "") if isinstance(p, dict) else str(p) for p in msg.content
        ]
        return " ".join(parts)
    return str(msg.content)


def _fuzzy_match(content: str, recorded_messages: list[dict[str, Any]]) -> bool:
    """Check if content roughly matches any recorded input message."""
    if not content:
        return False
    for msg in recorded_messages:
        recorded_content = msg.get("content", "")
        if isinstance(recorded_content, str) and recorded_content:
            # Check if significant overlap exists (>50% similarity)
            ratio = SequenceMatcher(
                None, content.lower(), recorded_content.lower()
            ).ratio()
            if ratio > 0.5:
                return True
    return False
