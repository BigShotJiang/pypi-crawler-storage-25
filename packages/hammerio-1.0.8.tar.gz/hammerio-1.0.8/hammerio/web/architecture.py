"""Architecture SVG diagram generator for HammerIO.

Generates a compression-focused architecture diagram.
All text stays inside boxes, arrows don't overlap labels.

Copyright 2026 ResilientMind AI | ResilientMindai.com | Joseph C McGinty Jr
"""

from __future__ import annotations

from pathlib import Path


def generate_architecture_svg(output_path: str | Path = "docs/architecture.svg") -> str:
    """Generate the HammerIO architecture SVG diagram."""
    svg = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 820 560" width="820" height="560">
  <defs>
    <linearGradient id="hg" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" style="stop-color:#1a1a2e"/>
      <stop offset="100%" style="stop-color:#16213e"/>
    </linearGradient>
    <linearGradient id="gg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#76b900"/>
      <stop offset="100%" style="stop-color:#4a7a00"/>
    </linearGradient>
    <linearGradient id="cg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#0071c5"/>
      <stop offset="100%" style="stop-color:#004a80"/>
    </linearGradient>
    <linearGradient id="rg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#e94560"/>
      <stop offset="100%" style="stop-color:#b33645"/>
    </linearGradient>
    <linearGradient id="ag" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#a855f7"/>
      <stop offset="100%" style="stop-color:#7c3aed"/>
    </linearGradient>
    <filter id="sh"><feDropShadow dx="1" dy="1" stdDeviation="2" flood-opacity="0.25"/></filter>
    <style>
      text { font-family: 'Segoe UI', system-ui, sans-serif; }
      .t1 { font-size: 20px; font-weight: 700; fill: #e6edf3; }
      .t2 { font-size: 11px; fill: #8b949e; }
      .t3 { font-size: 12px; font-weight: 600; fill: white; }
      .t4 { font-size: 10px; fill: rgba(255,255,255,0.8); }
      .t5 { font-size: 10px; fill: #8b949e; text-transform: uppercase; letter-spacing: 1px; font-weight: 600; }
      .ar { stroke: #58a6ff; stroke-width: 1.5; fill: none; marker-end: url(#ah); }
      .af { stroke: #d29922; stroke-width: 1.2; fill: none; stroke-dasharray: 5,3; marker-end: url(#wh); }
    </style>
    <marker id="ah" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto">
      <polygon points="0 0,8 3,0 6" fill="#58a6ff"/>
    </marker>
    <marker id="wh" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto">
      <polygon points="0 0,8 3,0 6" fill="#d29922"/>
    </marker>
  </defs>

  <!-- Background -->
  <rect width="820" height="560" rx="10" fill="#0d1117"/>

  <!-- Header -->
  <rect width="820" height="50" rx="10" fill="url(#hg)"/>
  <rect y="40" width="820" height="10" fill="url(#hg)"/>
  <text x="24" y="33" class="t1">HammerIO Architecture</text>
  <text x="320" y="33" class="t2">Compression-focused. GPU where it matters.</text>
  <text x="710" y="33" class="t2">v1.0.0</text>

  <!-- ═══ INPUT ROW ═══ -->
  <text x="24" y="78" class="t5">Input</text>

  <rect x="24" y="86" width="115" height="40" rx="6" fill="#1c2333" stroke="#30363d" filter="url(#sh)"/>
  <text x="82" y="103" class="t3" text-anchor="middle">CLI</text>
  <text x="82" y="116" class="t4" text-anchor="middle">hammer</text>

  <rect x="155" y="86" width="115" height="40" rx="6" fill="#1c2333" stroke="#30363d" filter="url(#sh)"/>
  <text x="213" y="103" class="t3" text-anchor="middle">Python API</text>
  <text x="213" y="116" class="t4" text-anchor="middle">import hammerio</text>

  <rect x="286" y="86" width="115" height="40" rx="6" fill="#1c2333" stroke="#30363d" filter="url(#sh)"/>
  <text x="344" y="103" class="t3" text-anchor="middle">Web UI</text>
  <text x="344" y="116" class="t4" text-anchor="middle">Dashboard</text>

  <rect x="417" y="86" width="115" height="40" rx="6" fill="#1c2333" stroke="#30363d" filter="url(#sh)"/>
  <text x="475" y="103" class="t3" text-anchor="middle">Watch</text>
  <text x="475" y="116" class="t4" text-anchor="middle">Drop folder</text>

  <!-- Hardware sidebar -->
  <rect x="580" y="72" width="220" height="138" rx="8" fill="#1c2333" stroke="#30363d" filter="url(#sh)"/>
  <text x="690" y="95" class="t3" text-anchor="middle">Hardware Detection</text>
  <text x="596" y="114" class="t4">CUDA / nvCOMP</text>
  <text x="596" y="128" class="t4">Apple Accelerate / LZFSE</text>
  <text x="596" y="142" class="t4">CPU cores / RAM</text>
  <text x="596" y="156" class="t4">jtop / Thermal sensors</text>
  <text x="596" y="170" class="t4">Jetson power mode</text>
  <text x="596" y="184" class="t4">GStreamer NVENC</text>

  <!-- Arrows: inputs → router -->
  <line x1="82" y1="126" x2="270" y2="170" class="ar"/>
  <line x1="213" y1="126" x2="270" y2="170" class="ar"/>
  <line x1="344" y1="126" x2="310" y2="170" class="ar"/>
  <line x1="475" y1="126" x2="350" y2="170" class="ar"/>

  <!-- ═══ ROUTER ═══ -->
  <text x="24" y="162" class="t5">Smart Router</text>
  <rect x="200" y="168" width="200" height="52" rx="8" fill="url(#rg)" filter="url(#sh)"/>
  <text x="300" y="191" class="t3" text-anchor="middle">File Profiler + Router</text>
  <text x="300" y="206" class="t4" text-anchor="middle">Size, type, entropy → route</text>

  <!-- Arrow: hardware → router -->
  <line x1="580" y1="160" x2="400" y2="190" class="ar"/>

  <!-- ═══ GPU ROW ═══ -->
  <text x="24" y="248" class="t5">GPU Accelerated</text>

  <rect x="24" y="258" width="180" height="50" rx="7" fill="url(#gg)" filter="url(#sh)"/>
  <text x="114" y="279" class="t3" text-anchor="middle">nvCOMP LZ4</text>
  <text x="114" y="294" class="t4" text-anchor="middle">Jetson / CUDA GPU</text>

  <!-- Apple Silicon -->
  <rect x="220" y="258" width="180" height="50" rx="7" fill="url(#ag)" filter="url(#sh)"/>
  <text x="310" y="279" class="t3" text-anchor="middle">Apple LZFSE</text>
  <text x="310" y="294" class="t4" text-anchor="middle">Accelerate framework</text>

  <!-- Router → GPU arrows -->
  <line x1="260" y1="220" x2="114" y2="258" class="ar"/>
  <line x1="300" y1="220" x2="310" y2="258" class="ar"/>

  <!-- ═══ CPU ROW ═══ -->
  <text x="24" y="340" class="t5">CPU Compression</text>

  <rect x="24" y="350" width="140" height="50" rx="7" fill="url(#cg)" filter="url(#sh)"/>
  <text x="94" y="371" class="t3" text-anchor="middle">zstd</text>
  <text x="94" y="386" class="t4" text-anchor="middle">Default (parallel)</text>

  <rect x="180" y="350" width="120" height="50" rx="7" fill="url(#cg)" filter="url(#sh)"/>
  <text x="240" y="371" class="t3" text-anchor="middle">gzip</text>
  <text x="240" y="386" class="t4" text-anchor="middle">Compatibility</text>

  <rect x="316" y="350" width="120" height="50" rx="7" fill="url(#cg)" filter="url(#sh)"/>
  <text x="376" y="371" class="t3" text-anchor="middle">lz4</text>
  <text x="376" y="386" class="t4" text-anchor="middle">Speed priority</text>

  <rect x="452" y="350" width="120" height="50" rx="7" fill="url(#cg)" filter="url(#sh)"/>
  <text x="512" y="371" class="t3" text-anchor="middle">bzip2</text>
  <text x="512" y="386" class="t4" text-anchor="middle">Max ratio</text>

  <!-- Router → CPU arrows -->
  <line x1="300" y1="220" x2="94" y2="350" class="ar"/>
  <line x1="320" y1="220" x2="240" y2="350" class="ar"/>
  <line x1="340" y1="220" x2="376" y2="350" class="ar"/>
  <line x1="360" y1="220" x2="512" y2="350" class="ar"/>

  <!-- GPU → CPU fallback arrows -->
  <line x1="114" y1="308" x2="94" y2="350" class="af"/>
  <line x1="310" y1="308" x2="240" y2="350" class="af"/>

  <!-- Telemetry sidebar -->
  <rect x="610" y="258" width="190" height="80" rx="8" fill="#1c2333" stroke="#d29922" filter="url(#sh)"/>
  <text x="705" y="281" class="t3" text-anchor="middle">Telemetry</text>
  <text x="626" y="299" class="t4">jtop / tegrastats</text>
  <text x="626" y="313" class="t4">Thermal + power alerts</text>
  <text x="626" y="327" class="t4">GPU/CPU/RAM monitoring</text>

  <!-- Passthrough -->
  <rect x="610" y="358" width="190" height="42" rx="7" fill="#1c2333" stroke="#30363d" filter="url(#sh)"/>
  <text x="705" y="378" class="t3" text-anchor="middle">Passthrough</text>
  <text x="705" y="392" class="t4" text-anchor="middle">Already compressed</text>

  <!-- Router → passthrough -->
  <line x1="380" y1="220" x2="705" y2="358" class="ar"/>

  <!-- ═══ OUTPUT ═══ -->
  <text x="24" y="432" class="t5">Output</text>
  <rect x="24" y="440" width="776" height="46" rx="7" fill="#1c2333" stroke="#3fb950" filter="url(#sh)"/>
  <text x="412" y="460" class="t3" text-anchor="middle">Results: input | output | ratio | time | throughput | processor | reason</text>
  <text x="412" y="476" class="t4" text-anchor="middle">JSON / CSV / Rich terminal / WebSocket / Markdown export</text>

  <!-- GPU/CPU → output arrows -->
  <line x1="114" y1="308" x2="114" y2="440" class="ar" style="stroke-dasharray:none"/>
  <line x1="310" y1="308" x2="310" y2="440" class="ar" style="stroke-dasharray:none"/>
  <line x1="94" y1="400" x2="94" y2="440" class="ar"/>
  <line x1="240" y1="400" x2="240" y2="440" class="ar"/>
  <line x1="376" y1="400" x2="376" y2="440" class="ar"/>
  <line x1="512" y1="400" x2="512" y2="440" class="ar"/>
  <line x1="705" y1="400" x2="705" y2="440" class="ar"/>

  <!-- Footer -->
  <text x="412" y="520" class="t2" text-anchor="middle">Copyright 2026 ResilientMind AI | Joseph C McGinty Jr | All Rights Reserved</text>
  <text x="412" y="540" class="t2" text-anchor="middle">GPU where it matters. CPU where it doesn't. Zero configuration.</text>
</svg>"""

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(svg)
    return str(output)


if __name__ == "__main__":
    path = generate_architecture_svg()
    print(f"Architecture SVG generated: {path}")
