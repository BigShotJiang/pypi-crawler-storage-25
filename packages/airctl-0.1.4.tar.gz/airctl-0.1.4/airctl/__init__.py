"""
AirCli - AI-friendly CLI tool for device control via Bluetooth and more.
"""

__version__ = "0.1.4"
