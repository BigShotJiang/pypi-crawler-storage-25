"""
Background task manager for periodic operations.
"""

import asyncio
import uuid as uuid_module
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional

from airctl.common.logging import get_logger
from airctl.common.utils import get_timestamp

logger = get_logger(__name__)


class TaskType(str, Enum):
    """Types of background tasks."""

    PERIODIC_READ = "periodic_read"
    PERIODIC_WRITE = "periodic_write"
    PERIODIC_SCAN = "periodic_scan"


class TaskStatus(str, Enum):
    """Task status."""

    RUNNING = "running"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass
class BackgroundTask:
    """Background task definition."""

    id: str
    task_type: TaskType
    device_address: str
    params: dict[str, Any]
    interval: float
    status: TaskStatus = TaskStatus.RUNNING
    created_at: float = field(default_factory=get_timestamp)
    last_run: Optional[float] = None
    last_error: Optional[str] = None
    run_count: int = 0
    _task: Optional[asyncio.Task] = field(default=None, repr=False)
    _stop_event: asyncio.Event = field(default_factory=asyncio.Event, repr=False)
    _consecutive_errors: int = field(default=0, repr=False)


class TaskManager:
    """
    Manager for background tasks.

    Handles periodic read, write, and scan operations.
    """

    MAX_CONSECUTIVE_ERRORS = 3

    STOP_ON_CONSECUTIVE_ERRORS = True

    def __init__(self, device_manager: Optional["DeviceManager"] = None) -> None:
        self._tasks: dict[str, BackgroundTask] = {}
        self._device_tasks: dict[str, set[str]] = {}
        self._device_manager = device_manager
        self._read_callback: Optional[Callable] = None
        self._write_callback: Optional[Callable] = None
        self._scan_callback: Optional[Callable] = None
        self._event_callback: Optional[Callable] = None

    def set_device_manager(self, device_manager: "DeviceManager") -> None:
        """Set the device manager instance."""
        self._device_manager = device_manager

    def set_read_callback(self, callback: Callable) -> None:
        """Set callback for periodic read results."""
        self._read_callback = callback

    def set_write_callback(self, callback: Callable) -> None:
        """Set callback for periodic write results."""
        self._write_callback = callback

    def set_scan_callback(self, callback: Callable) -> None:
        """Set callback for periodic scan results."""
        self._scan_callback = callback

    def set_event_callback(self, callback: Callable) -> None:
        """Set callback for task events."""
        self._event_callback = callback

    async def start_periodic_read(
        self,
        device_address: str,
        uuid: Optional[str] = None,
        handle: Optional[int] = None,
        interval: float = 5.0,
        format: str = "hex",
    ) -> str:
        """
        Start a periodic read task.

        Args:
            device_address: Device address
            uuid: Characteristic UUID
            handle: Characteristic handle
            interval: Read interval in seconds
            format: Output format

        Returns:
            Task ID
        """
        task_id = str(uuid_module.uuid4())[:8]

        task = BackgroundTask(
            id=task_id,
            task_type=TaskType.PERIODIC_READ,
            device_address=device_address,
            params={
                "uuid": uuid,
                "handle": handle,
                "format": format,
            },
            interval=interval,
        )

        self._tasks[task_id] = task

        if device_address not in self._device_tasks:
            self._device_tasks[device_address] = set()
        self._device_tasks[device_address].add(task_id)

        task._stop_event.clear()
        task._task = asyncio.create_task(self._run_periodic_read(task))

        logger.info(
            f"Started periodic read task {task_id} for {device_address} "
            f"(uuid={uuid}, handle={handle}, interval={interval}s)"
        )

        return task_id

    async def start_periodic_write(
        self,
        device_address: str,
        uuid: Optional[str] = None,
        handle: Optional[int] = None,
        data: str = "",
        interval: float = 5.0,
        response: bool = False,
    ) -> str:
        """
        Start a periodic write task.

        Args:
            device_address: Device address
            uuid: Characteristic UUID
            handle: Characteristic handle
            data: Data to write (hex:/text:/base64: prefix)
            interval: Write interval in seconds
            response: Whether to request write response

        Returns:
            Task ID
        """
        task_id = str(uuid_module.uuid4())[:8]

        task = BackgroundTask(
            id=task_id,
            task_type=TaskType.PERIODIC_WRITE,
            device_address=device_address,
            params={
                "uuid": uuid,
                "handle": handle,
                "data": data,
                "response": response,
            },
            interval=interval,
        )

        self._tasks[task_id] = task

        if device_address not in self._device_tasks:
            self._device_tasks[device_address] = set()
        self._device_tasks[device_address].add(task_id)

        task._stop_event.clear()
        task._task = asyncio.create_task(self._run_periodic_write(task))

        logger.info(
            f"Started periodic write task {task_id} for {device_address} "
            f"(uuid={uuid}, handle={handle}, interval={interval}s)"
        )

        return task_id

    async def start_periodic_scan(
        self,
        interval: float = 10.0,
        scan_timeout: float = 5.0,
        service_uuids: Optional[list[str]] = None,
    ) -> str:
        """
        Start a periodic scan task.

        Args:
            interval: Scan interval in seconds
            scan_timeout: Duration of each scan in seconds
            service_uuids: Optional list of service UUIDs to filter

        Returns:
            Task ID
        """
        task_id = str(uuid_module.uuid4())[:8]

        task = BackgroundTask(
            id=task_id,
            task_type=TaskType.PERIODIC_SCAN,
            device_address="",  # No specific device for scan
            params={
                "scan_timeout": scan_timeout,
                "service_uuids": service_uuids,
            },
            interval=interval,
        )

        self._tasks[task_id] = task

        task._stop_event.clear()
        task._task = asyncio.create_task(self._run_periodic_scan(task))

        logger.info(
            f"Started periodic scan task {task_id} "
            f"(scan_timeout={scan_timeout}s, interval={interval}s)"
        )

        return task_id

    async def stop_task(self, task_id: str) -> bool:
        """
        Stop a background task.

        Args:
            task_id: Task ID to stop

        Returns:
            True if stopped, False if not found
        """
        if task_id not in self._tasks:
            return False

        task = self._tasks[task_id]
        task._stop_event.set()

        if task._task and not task._task.done():
            task._task.cancel()
            try:
                await task._task
            except asyncio.CancelledError:
                pass

        task.status = TaskStatus.STOPPED

        if task.device_address and task.device_address in self._device_tasks:
            self._device_tasks[task.device_address].discard(task_id)

        logger.info(f"Stopped task {task_id}")
        return True

    async def stop_device_tasks(self, device_address: str) -> int:
        """
        Stop all tasks for a device.

        Args:
            device_address: Device address

        Returns:
            Number of tasks stopped
        """
        if device_address not in self._device_tasks:
            return 0

        task_ids = list(self._device_tasks[device_address])
        count = 0
        for task_id in task_ids:
            if await self.stop_task(task_id):
                count += 1

        return count

    async def stop_all_tasks(self) -> int:
        """
        Stop all background tasks.

        Returns:
            Number of tasks stopped
        """
        task_ids = list(self._tasks.keys())
        count = 0
        for task_id in task_ids:
            if await self.stop_task(task_id):
                count += 1
        return count

    def list_tasks(
        self,
        device_address: Optional[str] = None,
        task_type: Optional[TaskType] = None,
    ) -> list[dict[str, Any]]:
        """
        List background tasks.

        Args:
            device_address: Filter by device address
            task_type: Filter by task type

        Returns:
            List of task info dicts
        """
        result = []
        for task in self._tasks.values():
            if device_address and task.device_address != device_address:
                continue
            if task_type and task.task_type != task_type:
                continue

            result.append({
                "id": task.id,
                "type": task.task_type.value,
                "device_address": task.device_address,
                "params": task.params,
                "interval": task.interval,
                "status": task.status.value,
                "created_at": task.created_at,
                "last_run": task.last_run,
                "last_error": task.last_error,
                "run_count": task.run_count,
            })

        return result

    def get_task(self, task_id: str) -> Optional[dict[str, Any]]:
        """
        Get task info by ID.

        Args:
            task_id: Task ID

        Returns:
            Task info dict or None
        """
        if task_id not in self._tasks:
            return None

        task = self._tasks[task_id]
        return {
            "id": task.id,
            "type": task.task_type.value,
            "device_address": task.device_address,
            "params": task.params,
            "interval": task.interval,
            "status": task.status.value,
            "created_at": task.created_at,
            "last_run": task.last_run,
            "last_error": task.last_error,
            "run_count": task.run_count,
        }

    async def _run_periodic_read(self, task: BackgroundTask) -> None:
        """
        Run periodic read task.

        Args:
            task: Background task to run
        """
        from airctl.common.utils import format_data_output

        logger.info(f"Periodic read task {task.id} starting for device {task.device_address}")

        while not task._stop_event.is_set():
            try:
                if self._device_manager is None:
                    raise RuntimeError("Device manager not set")

                logger.debug(f"Task {task.id}: Attempting to read from {task.device_address}")
                data = await self._device_manager.read_characteristic(
                    address=task.device_address,
                    uuid=task.params.get("uuid"),
                    handle=task.params.get("handle"),
                )

                task.last_run = get_timestamp()
                task.run_count += 1
                task.last_error = None
                task._consecutive_errors = 0

                logger.debug(f"Task {task.id}: Read successful, run_count={task.run_count}")

                if self._read_callback:
                    formatted_data = format_data_output(data, task.params.get("format", "hex"))
                    event_data = {
                        "type": "periodic_read",
                        "task_id": task.id,
                        "device_address": task.device_address,
                        "timestamp": task.last_run,
                        "data": formatted_data,
                        "format": task.params.get("format", "hex"),
                        "run_count": task.run_count,
                    }
                    await self._read_callback(event_data)

            except asyncio.CancelledError:
                logger.info(f"Periodic read task {task.id} cancelled")
                break
            except Exception as e:
                task.last_error = str(e)
                task.status = TaskStatus.ERROR
                task._consecutive_errors += 1
                logger.error(f"Periodic read task {task.id} error: {e}")

                if self._check_consecutive_errors(task):
                    logger.warning(
                        f"Task {task.id} stopped after {self.MAX_CONSECUTIVE_ERRORS} consecutive errors"
                    )
                    await self.stop_task(task.id)
                    return

            await asyncio.sleep(task.interval)

        logger.info(f"Periodic read task {task.id} stopped")
        if task.id in self._tasks:
            del self._tasks[task.id]
            if task.device_address in self._device_tasks:
                self._device_tasks[task.device_address].discard(task.id)

    def _check_consecutive_errors(self, task: BackgroundTask) -> bool:
        return task._consecutive_errors >= self.MAX_CONSECUTIVE_ERRORS

    def _increment_consecutive_errors(self, task: BackgroundTask) -> None:
        task._consecutive_errors += 1

    async def _run_periodic_write(self, task: BackgroundTask) -> None:
        """
        Run periodic write task.

        Args:
            task: Background task to run
        """
        while not task._stop_event.is_set():
            try:
                if self._device_manager is None:
                    raise RuntimeError("Device manager not set")

                await self._device_manager.write_characteristic(
                    address=task.device_address,
                    uuid=task.params.get("uuid"),
                    handle=task.params.get("handle"),
                    data=task.params.get("data", ""),
                    response=task.params.get("response", False),
                )

                task.last_run = get_timestamp()
                task.run_count += 1
                task.last_error = None

                if self._write_callback:
                    event_data = {
                        "type": "periodic_write",
                        "task_id": task.id,
                        "device_address": task.device_address,
                        "timestamp": task.last_run,
                        "data": task.params.get("data", ""),
                        "run_count": task.run_count,
                    }
                    await self._write_callback(event_data)

            except asyncio.CancelledError:
                break
            except Exception as e:
                task.last_error = str(e)
                task.status = TaskStatus.ERROR
                logger.error(f"Periodic write task {task.id} error: {e}")

                if self._event_callback:
                    await self._event_callback({
                        "type": "task_error",
                        "task_id": task.id,
                        "device_address": task.device_address,
                        "error": str(e),
                    })

            await asyncio.sleep(task.interval)

        if task.id in self._tasks:
            del self._tasks[task.id]
            if task.device_address in self._device_tasks:
                self._device_tasks[task.device_address].discard(task.id)

    async def _run_periodic_scan(self, task: BackgroundTask) -> None:
        """
        Run periodic scan task.

        Args:
            task: Background task to run
        """
        from airctl.daemon.scanner import ScannerManager

        scanner_manager = ScannerManager()

        while not task._stop_event.is_set():
            try:
                result = await scanner_manager.scan(
                    timeout=task.params.get("scan_timeout", 5.0),
                    service_uuids=task.params.get("service_uuids"),
                )

                task.last_run = get_timestamp()
                task.run_count += 1
                task.last_error = None

                if self._scan_callback:
                    devices_data = []
                    for d in result:
                        dd = d.model_dump()
                        if "manufacturer_data" in dd and isinstance(dd["manufacturer_data"], dict):
                            dd["manufacturer_data"] = {str(k): v for k, v in dd["manufacturer_data"].items()}
                        devices_data.append(dd)
                    event_data = {
                        "type": "periodic_scan",
                        "task_id": task.id,
                        "timestamp": task.last_run,
                        "devices": devices_data,
                        "count": len(result),
                        "run_count": task.run_count,
                    }
                    await self._scan_callback(event_data)

            except asyncio.CancelledError:
                break
            except Exception as e:
                task.last_error = str(e)
                task.status = TaskStatus.ERROR
                logger.error(f"Periodic scan task {task.id} error: {e}")

                if self._event_callback:
                    await self._event_callback({
                        "type": "task_error",
                        "task_id": task.id,
                        "device_address": "",
                        "error": str(e),
                    })

            await asyncio.sleep(task.interval)

        if task.id in self._tasks:
            del self._tasks[task.id]
