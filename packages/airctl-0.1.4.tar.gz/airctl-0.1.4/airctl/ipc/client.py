"""
IPC client for communicating with the BLE daemon.
"""

import asyncio
import os
import signal
import sys
from typing import Any, Iterator, Optional

from airctl.common.logging import get_logger
from airctl.common.platform import is_windows
from airctl.common.utils import generate_request_id
from airctl.ipc.protocol import (
    IPCError,
    IPCErrorCode,
    IPCProtocol,
)
from airctl.ipc.transport import create_transport, get_default_socket_path, get_pid_file_path

logger = get_logger(__name__)


class DaemonClient:
    """
    Client for communicating with the BLE daemon.
    
    Provides high-level methods for BLE operations.
    """

    def __init__(self, socket_path: Optional[str] = None, timeout: float = 30.0):
        """
        Initialize daemon client.

        Args:
            socket_path: Path to IPC socket (default: platform-specific)
            timeout: Default timeout for operations
        """
        self.socket_path = socket_path or get_default_socket_path()
        self.timeout = timeout
        self._transport = create_transport(self.socket_path)
        self._protocol = IPCProtocol()
        self._connected = False

    def is_running(self) -> bool:
        """Check if daemon is running."""
        pid_file = get_pid_file_path()
        if not os.path.exists(pid_file):
            return False

        try:
            with open(pid_file, "r") as f:
                pid = int(f.read().strip())

            if is_windows():
                import win32api
                import win32con
                import win32process

                try:
                    handle = win32api.OpenProcess(
                        win32con.PROCESS_QUERY_INFORMATION | win32con.PROCESS_VM_READ,
                        False,
                        pid,
                    )
                    if not handle:
                        return False
                    
                    try:
                        exit_code = win32process.GetExitCodeProcess(handle)
                        if exit_code == 259:
                            return True
                        return False
                    finally:
                        win32api.CloseHandle(handle)
                except Exception:
                    return False
            else:
                try:
                    os.kill(pid, 0)
                    return True
                except OSError:
                    return False
        except Exception:
            return False

    def get_pid(self) -> Optional[int]:
        """Get daemon PID if running."""
        pid_file = get_pid_file_path()
        if not os.path.exists(pid_file):
            return None

        try:
            with open(pid_file, "r") as f:
                return int(f.read().strip())
        except Exception:
            return None

    async def _connect(self) -> None:
        """Connect to daemon."""
        if self._connected:
            return
        await self._transport.connect()
        self._connected = True

    async def _disconnect(self) -> None:
        """Disconnect from daemon."""
        if not self._connected:
            return
        await self._transport.disconnect()
        self._connected = False

    async def _send_request(
        self, method: str, params: Optional[dict[str, Any]] = None
    ) -> Any:
        """
        Send a request and wait for response.

        Args:
            method: Method name
            params: Method parameters

        Returns:
            Response result

        Raises:
            IPCError: On error response
        """
        try:
            await self._connect()

            request = self._protocol.create_request(method, params)
            data = self._protocol.serialize(request)
            await self._transport.send(data)

            response_data = await asyncio.wait_for(
                self._transport.receive(), timeout=self.timeout
            )
            response = self._protocol.deserialize(response_data)

            if response.error:
                raise IPCError(
                    code=response.error.code,
                    message=response.error.message,
                    data=response.error.data,
                )

            return response.result
        finally:
            await self._disconnect()

    def _call_sync(self, method: str, params: Optional[dict[str, Any]] = None) -> Any:
        """Synchronous wrapper for async request."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            future = asyncio.ensure_future(self._send_request(method, params))
            return asyncio.run_coroutine_threadsafe(future, loop).result(self.timeout)
        else:
            return asyncio.run(self._send_request(method, params))

    def stop_daemon(self) -> bool:
        """Request daemon to stop."""
        try:
            result = self._call_sync("daemon.stop", {})
            return result.get("success", False)
        except Exception:
            return False

    def scan(
        self,
        timeout: float = 10.0,
        service_uuids: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """
        Scan for BLE devices.

        Args:
            timeout: Scan timeout in seconds
            service_uuids: Optional list of service UUIDs to filter

        Returns:
            Dict with 'devices' key containing list of device info
        """
        params = {"timeout": timeout}
        if service_uuids:
            params["service_uuids"] = service_uuids
        return self._call_sync("ble.scan", params)

    def connect(
        self,
        address: str,
        timeout: float = 30.0,
        alias: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Connect to a BLE device.

        Args:
            address: Device address or alias
            timeout: Connection timeout
            alias: Optional alias to assign

        Returns:
            Connection info
        """
        params = {"address": address, "timeout": timeout}
        if alias:
            params["alias"] = alias
        return self._call_sync("ble.connect", params)

    def disconnect(self, address: str) -> None:
        """
        Disconnect from a BLE device.

        Args:
            address: Device address or alias
        """
        self._call_sync("ble.disconnect", {"address": address})

    def list_devices(self) -> dict[str, Any]:
        """
        List connected devices.

        Returns:
            Dict with 'devices' key
        """
        return self._call_sync("ble.list_devices", {})

    def get_services(self, address: str) -> dict[str, Any]:
        """
        Get GATT services of a device.

        Args:
            address: Device address or alias

        Returns:
            Dict with 'services' key
        """
        return self._call_sync("ble.get_services", {"address": address})

    def get_characteristics(
        self, address: str, service_uuid: Optional[str] = None
    ) -> dict[str, Any]:
        """
        Get GATT characteristics of a device.

        Args:
            address: Device address or alias
            service_uuid: Optional service UUID filter

        Returns:
            Dict with 'characteristics' key
        """
        params = {"address": address}
        if service_uuid:
            params["service_uuid"] = service_uuid
        return self._call_sync("ble.get_characteristics", params)

    def read_characteristic(
        self, address: str, uuid: Optional[str] = None, handle: Optional[int] = None, format: str = "hex"
    ) -> dict[str, Any]:
        """
        Read a characteristic value.

        Args:
            address: Device address or alias
            uuid: Characteristic UUID
            handle: Characteristic handle (alternative to UUID)
            format: Output format (hex/base64/text)

        Returns:
            Dict with 'value' key
        """
        params = {"address": address, "format": format}
        if uuid:
            params["uuid"] = uuid
        if handle is not None:
            params["handle"] = handle
        return self._call_sync("ble.read", params)

    def write_characteristic(
        self,
        address: str,
        uuid: Optional[str] = None,
        handle: Optional[int] = None,
        data: str = "",
        response: bool = False,
    ) -> None:
        """
        Write to a characteristic.

        Args:
            address: Device address or alias
            uuid: Characteristic UUID
            handle: Characteristic handle (alternative to UUID)
            data: Data to write (hex:/text:/base64: prefix)
            response: Whether to request write response
        """
        params = {"address": address, "data": data, "response": response}
        if uuid:
            params["uuid"] = uuid
        if handle is not None:
            params["handle"] = handle
        self._call_sync("ble.write", params)

    def subscribe_notification(self, address: str, uuid: str) -> None:
        """
        Subscribe to characteristic notifications.

        Args:
            address: Device address or alias
            uuid: Characteristic UUID
        """
        self._call_sync("ble.notify.subscribe", {"address": address, "uuid": uuid})

    def unsubscribe_notification(self, address: str, uuid: str) -> None:
        """
        Unsubscribe from characteristic notifications.

        Args:
            address: Device address or alias
            uuid: Characteristic UUID
        """
        self._call_sync("ble.notify.unsubscribe", {"address": address, "uuid": uuid})

    def stream_events(
        self,
        address: Optional[str] = None,
        event_type: Optional[str] = None,
    ) -> Iterator[str]:
        """
        Stream events from daemon.

        Args:
            address: Optional device address filter
            event_type: Optional event type filter

        Yields:
            JSON event strings
        """
        params = {}
        if address:
            params["address"] = address
        if event_type:
            params["event_type"] = event_type

        if is_windows():
            yield from self._stream_events_windows(params)
        else:
            yield from self._stream_events_unix(params)

    def _stream_events_unix(self, params: dict[str, Any]) -> Iterator[str]:
        """Stream events on Unix using async transport."""
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        connected = False

        try:
            loop.run_until_complete(self._connect())
            connected = True

            request = self._protocol.create_request("ble.events", params)
            data = self._protocol.serialize(request)
            loop.run_until_complete(self._transport.send(data))

            while True:
                try:
                    event_data = loop.run_until_complete(self._transport.receive())
                    yield event_data.decode("utf-8").strip()
                except KeyboardInterrupt:
                    break
                except Exception:
                    break
        finally:
            if connected:
                try:
                    loop.run_until_complete(self._disconnect())
                except Exception:
                    pass
            loop.close()

    def _stream_events_windows(self, params: dict[str, Any]) -> Iterator[str]:
        """Stream events on Windows using background reader thread."""
        import queue
        import threading
        import time

        import win32file
        import win32pipe

        handle = None
        max_retries = 50
        for retry in range(max_retries):
            try:
                handle = win32file.CreateFile(
                    self.socket_path,
                    win32file.GENERIC_READ | win32file.GENERIC_WRITE,
                    0,
                    None,
                    win32file.OPEN_EXISTING,
                    0,
                    None,
                )
                break
            except Exception as e:
                if retry == max_retries - 1:
                    raise ConnectionError(
                        f"Failed to connect to daemon after {max_retries} retries: {e}"
                    )
                time.sleep(0.1)

        win32pipe.SetNamedPipeHandleState(
            handle, win32pipe.PIPE_READMODE_BYTE, None, None
        )

        try:
            request = self._protocol.create_request("ble.events", params)
            win32file.WriteFile(handle, self._protocol.serialize(request))

            read_queue: queue.Queue[bytes] = queue.Queue()
            stop_reading = threading.Event()

            def _reader():
                while not stop_reading.is_set():
                    try:
                        result, data = win32file.ReadFile(handle, 4096)
                        if result == 0 and data:
                            read_queue.put(data)
                        else:
                            break
                    except Exception:
                        break

            reader_thread = threading.Thread(target=_reader, daemon=True)
            reader_thread.start()

            buffer = b""
            try:
                while True:
                    try:
                        data = read_queue.get(timeout=0.5)
                        buffer += data
                        while b"\n" in buffer:
                            line, buffer = buffer.split(b"\n", 1)
                            text = line.decode("utf-8").strip()
                            if text:
                                yield text
                    except queue.Empty:
                        continue
            except KeyboardInterrupt:
                pass
            finally:
                stop_reading.set()
                try:
                    win32file.CloseHandle(handle)
                    handle = None
                except Exception:
                    pass
                reader_thread.join(timeout=2)
        finally:
            if handle:
                try:
                    win32file.CloseHandle(handle)
                except Exception:
                    pass

    def start_read_task(
        self,
        address: str,
        uuid: Optional[str] = None,
        handle: Optional[int] = None,
        interval: float = 5.0,
        format: str = "hex",
    ) -> dict[str, Any]:
        """
        Start a periodic read task.

        Args:
            address: Device address or alias
            uuid: Characteristic UUID
            handle: Characteristic handle (alternative to UUID)
            interval: Read interval in seconds
            format: Output format (hex/base64/text)

        Returns:
            Dict with 'task_id' and 'type' keys
        """
        params = {
            "task_type": "periodic_read",
            "address": address,
            "interval": interval,
            "format": format,
        }
        if uuid:
            params["uuid"] = uuid
        if handle is not None:
            params["handle"] = handle
        return self._call_sync("ble.task.start", params)

    def start_write_task(
        self,
        address: str,
        uuid: Optional[str] = None,
        handle: Optional[int] = None,
        data: str = "",
        interval: float = 5.0,
        response: bool = False,
    ) -> dict[str, Any]:
        """
        Start a periodic write task.

        Args:
            address: Device address or alias
            uuid: Characteristic UUID
            handle: Characteristic handle (alternative to UUID)
            data: Data to write (hex:/text:/base64: prefix)
            interval: Write interval in seconds
            response: Whether to request write response

        Returns:
            Dict with 'task_id' and 'type' keys
        """
        params = {
            "task_type": "periodic_write",
            "address": address,
            "data": data,
            "interval": interval,
            "response": response,
        }
        if uuid:
            params["uuid"] = uuid
        if handle is not None:
            params["handle"] = handle
        return self._call_sync("ble.task.start", params)

    def start_scan_task(
        self,
        interval: float = 10.0,
        scan_timeout: float = 5.0,
        service_uuids: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """
        Start a periodic scan task.

        Args:
            interval: Scan interval in seconds
            scan_timeout: Duration of each scan in seconds
            service_uuids: Optional list of service UUIDs to filter

        Returns:
            Dict with 'task_id' and 'type' keys
        """
        params = {
            "task_type": "periodic_scan",
            "interval": interval,
            "scan_timeout": scan_timeout,
        }
        if service_uuids:
            params["service_uuids"] = service_uuids
        return self._call_sync("ble.task.start", params)

    def stop_task(self, task_id: str) -> dict[str, Any]:
        """
        Stop a background task.

        Args:
            task_id: Task ID to stop

        Returns:
            Dict with 'success' key
        """
        return self._call_sync("ble.task.stop", {"task_id": task_id})

    def list_tasks(
        self,
        address: Optional[str] = None,
        task_type: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        List background tasks.

        Args:
            address: Filter by device address
            task_type: Filter by task type

        Returns:
            Dict with 'tasks' key containing list of task info
        """
        params = {}
        if address:
            params["address"] = address
        if task_type:
            params["task_type"] = task_type
        return self._call_sync("ble.task.list", params)
