# TAQuant

TAQuant is a high-performance technical indicator library for quantitative research and trading systems.
It uses a layered design:

- `pandas` for user-facing API
- `numpy` arrays for heavy computation
- `numba` kernels for hot loops

TAQuant targets:

- large batch backtests (`100k` to `1M` rows)
- multi-symbol processing
- realtime incremental updates via stateful classes

## Installation

```bash
pip install .
```

Optional extras:

```bash
pip install ".[dev]"
pip install ".[talib]"
pip install ".[benchmark]"
```

## Quickstart

```python
import pandas as pd
import taquant

# df contains: Timestamp, Open, High, Low, Close, Volume
out = taquant.trend.ema(df, window=20)
out = taquant.momentum.rsi(out, window=14)
out = taquant.volatility.bollinger_bands(out, window=20, num_std=2.0)

# Warm-path mode: skip runtime validation overhead
out = taquant.trend.ema(df, window=20, fast_mode=True)
```

## API Examples

```python
from taquant.trend import sma, ema, wma, macd
from taquant.momentum import rsi, stochastic, cci
from taquant.volatility import stddev, atr, bollinger_bands
from taquant.volume import volume_ma, obv, vwap
from taquant.price import typical_price, median_price, weighted_close

sma(df, window=20)
ema(df, window=20, symbol_col="Symbol")
macd(df, fast_window=12, slow_window=26, signal_window=9)
```

Array-native API (`ndarray -> ndarray`, no DataFrame overhead):

```python
from taquant import array_api as fa

ema = fa.ema_array(close, window=20)
rsi = fa.rsi_array(close, window=14)
line, signal, hist = fa.macd_array(close, 12, 26, 9)
```

Stateful realtime usage:

```python
from taquant.stateful import EMAState, RSIState

ema_state = EMAState(window=20)
rsi_state = RSIState(window=14)

ema_value = ema_state.update(price)
rsi_value = rsi_state.update(price)
```

## Benchmark Highlights

From `benchmark/results/speedup_summary.csv` (warm mode, `single_1m`, speedup vs pandas):

- `SMA`: `2.04x`
- `EMA`: `3.45x`
- `MACD`: `6.39x`
- `RSI`: `4.61x`
- `BBANDS`: `5.72x`

Artifacts:

- `benchmark/results/benchmark_summary.csv`
- `benchmark/results/speedup_summary.csv`
- `benchmark/results/runtime_speedup.png`
- `benchmark/results/metadata.json`

## Design Philosophy

- Performance-first compute paths on `ndarray(float64)`
- Deterministic, explicit validation and error messages
- Reusable base abstraction (`apply_indicator`) for consistent APIs
- Dependency-aware caching to avoid redundant recompute
- Maintainable architecture over over-engineering
