"""Tests for momentum indicators."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from taquant.momentum import cci, rsi, stochastic


def _ohlc_df() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "High": [10.0, 10.5, 10.8, 11.0, 11.2, 11.5, 11.7, 11.9],
            "Low": [9.6, 10.0, 10.2, 10.4, 10.7, 10.9, 11.0, 11.3],
            "Close": [9.8, 10.3, 10.5, 10.8, 11.0, 11.2, 11.4, 11.7],
        }
    )


def test_rsi_values_range_and_name() -> None:
    df = _ohlc_df()
    out = rsi(df, window=3)
    col = "rsi_3"
    assert col in out.columns
    vals = out[col].to_numpy()
    finite = vals[np.isfinite(vals)]
    assert finite.size > 0
    assert np.all((finite >= 0.0) & (finite <= 100.0))


def test_stochastic_generates_k_and_d() -> None:
    df = _ohlc_df()
    out = stochastic(df, k_window=3, d_window=3)
    assert "stoch_3_k" in out.columns
    assert "stoch_3_d" in out.columns

    # %D should become finite after enough valid %K points.
    d_vals = out["stoch_3_d"].to_numpy()
    assert np.isfinite(d_vals[-1])


def test_cci_constant_series_is_nan_after_warmup() -> None:
    df = pd.DataFrame(
        {
            "High": [10.0] * 10,
            "Low": [10.0] * 10,
            "Close": [10.0] * 10,
        }
    )
    out = cci(df, window=5)
    vals = out["cci_5"].to_numpy()
    assert np.all(np.isnan(vals[4:]))


def test_momentum_len_less_than_window_returns_nan() -> None:
    df = _ohlc_df().iloc[:3].copy()
    out = rsi(df, window=5)
    assert np.all(np.isnan(out["rsi_5"].to_numpy()))


def test_momentum_invalid_window_raises() -> None:
    df = _ohlc_df()
    with pytest.raises(ValueError):
        rsi(df, window=0)


def test_momentum_extreme_values_stable() -> None:
    df = pd.DataFrame(
        {
            "High": [1e12, 1e12 + 10, 1e12 + 20, 1e12 + 30, 1e12 + 40],
            "Low": [1e12 - 10, 1e12, 1e12 + 10, 1e12 + 20, 1e12 + 30],
            "Close": [1e12 - 5, 1e12 + 5, 1e12 + 15, 1e12 + 25, 1e12 + 35],
        }
    )
    out = stochastic(df, k_window=3, d_window=2)
    assert np.isfinite(out["stoch_3_k"].to_numpy()[-1])
