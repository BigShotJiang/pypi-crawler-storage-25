"""Tests for volume indicators."""

from __future__ import annotations

import numpy as np
import pandas as pd

from taquant.volume import obv, volume_ma, vwap


def test_volume_ma_values_and_name() -> None:
    df = pd.DataFrame({"Volume": [10.0, 20.0, 30.0, 40.0]})
    out = volume_ma(df, window=2)
    expected = np.array([np.nan, 15.0, 25.0, 35.0])
    assert "volume_ma_2" in out.columns
    np.testing.assert_allclose(out["volume_ma_2"].to_numpy(), expected, equal_nan=True)


def test_volume_ma_custom_column() -> None:
    df = pd.DataFrame({"V": [5.0, 15.0, 25.0]})
    out = volume_ma(df, window=2, column="V", output_name="vma")
    assert "vma" in out.columns


def test_obv_and_vwap_values_basic() -> None:
    df = pd.DataFrame(
        {
            "Close": [10.0, 11.0, 10.5, 10.5, 11.5],
            "Volume": [100.0, 120.0, 130.0, 110.0, 140.0],
        }
    )
    out_obv = obv(df)
    out_vwap = vwap(df)

    expected_obv = np.array([100.0, 220.0, 90.0, 90.0, 230.0])
    pv = (df["Close"] * df["Volume"]).to_numpy()
    vv = df["Volume"].to_numpy()
    expected_vwap = np.cumsum(pv) / np.cumsum(vv)

    np.testing.assert_allclose(out_obv["obv"].to_numpy(), expected_obv)
    np.testing.assert_allclose(out_vwap["vwap"].to_numpy(), expected_vwap)


def test_vwap_handles_zero_cumulative_volume() -> None:
    df = pd.DataFrame({"Close": [10.0, 11.0], "Volume": [0.0, 0.0]})
    out = vwap(df)
    assert np.all(np.isnan(out["vwap"].to_numpy()))
