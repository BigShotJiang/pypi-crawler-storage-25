"""Tests for multi-symbol orchestration behavior."""

from __future__ import annotations

import numpy as np
import pandas as pd

from taquant.momentum import rsi
from taquant.trend import ema
from taquant.volume import vwap


def _multi_df() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "Timestamp": pd.date_range("2024-01-01", periods=8, freq="min"),
            "Symbol": ["A", "B", "A", "B", "A", "B", "A", "B"],
            "Close": [10.0, 50.0, 11.0, 49.0, 12.0, 48.0, 13.0, 47.0],
            "High": [10.2, 50.2, 11.2, 49.2, 12.2, 48.2, 13.2, 47.2],
            "Low": [9.8, 49.8, 10.8, 48.8, 11.8, 47.8, 12.8, 46.8],
            "Volume": [100.0, 90.0, 120.0, 80.0, 140.0, 70.0, 160.0, 60.0],
        }
    )


def _per_symbol_concat(df: pd.DataFrame, fn, **kwargs):
    parts = []
    for _, group in df.groupby("Symbol", sort=False):
        parts.append(fn(group.copy(), symbol_col=None, inplace=False, **kwargs))
    return pd.concat(parts).sort_index(kind="stable")


def test_multisymbol_parity_for_ema() -> None:
    df = _multi_df()
    multi = ema(df.copy(), window=3, symbol_col="Symbol")
    expected = _per_symbol_concat(df, ema, window=3)
    np.testing.assert_allclose(multi["ema_3"].to_numpy(), expected["ema_3"].to_numpy(), equal_nan=True)


def test_multisymbol_row_order_preserved() -> None:
    df = _multi_df()
    out = vwap(df.copy(), symbol_col="Symbol")
    assert out.index.equals(df.index)


def test_multisymbol_no_state_leakage() -> None:
    df = _multi_df()
    out = rsi(df.copy(), window=3, symbol_col="Symbol")

    # Compare first valid RSI of symbol A in multisymbol mode vs single-symbol mode.
    a_multi = out[out["Symbol"] == "A"]["rsi_3"].to_numpy()
    a_single = rsi(df[df["Symbol"] == "A"].copy(), window=3)["rsi_3"].to_numpy()
    np.testing.assert_allclose(a_multi, a_single, equal_nan=True)
