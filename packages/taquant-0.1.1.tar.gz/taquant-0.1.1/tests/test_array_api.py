"""Tests for array-native API and fast_mode parity."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from taquant import array_api as fa
from taquant.momentum import rsi
from taquant.trend import ema, macd, sma
from taquant.volatility import atr, bollinger_bands

talib = pytest.importorskip("talib")


def _market_df(n: int = 500) -> pd.DataFrame:
    rng = np.random.default_rng(77)
    close = rng.normal(loc=100.0, scale=2.0, size=n).astype(np.float64)
    high = close + rng.uniform(0.1, 1.0, size=n)
    low = close - rng.uniform(0.1, 1.0, size=n)
    vol = rng.integers(100, 5000, size=n).astype(np.float64)
    return pd.DataFrame({"High": high, "Low": low, "Close": close, "Volume": vol})


def _assert_close(a: np.ndarray, b: np.ndarray, rtol: float = 1e-6, atol: float = 1e-8) -> None:
    m = np.isfinite(a) & np.isfinite(b)
    assert m.any()
    np.testing.assert_allclose(a[m], b[m], rtol=rtol, atol=atol)


def test_array_api_vs_talib_core() -> None:
    df = _market_df()
    c = df["Close"].to_numpy(np.float64)
    h = df["High"].to_numpy(np.float64)
    l = df["Low"].to_numpy(np.float64)
    v = df["Volume"].to_numpy(np.float64)

    _assert_close(fa.sma_array(c, 20), talib.SMA(c, 20))
    tail = slice(120, None)
    _assert_close(fa.ema_array(c, 20)[tail], talib.EMA(c, 20)[tail], rtol=2e-4, atol=2e-4)
    _assert_close(fa.wma_array(c, 20), talib.WMA(c, 20))
    _assert_close(fa.rsi_array(c, 14), talib.RSI(c, 14), rtol=1e-5, atol=1e-6)
    _assert_close(fa.atr_array(h, l, c, 14), talib.ATR(h, l, c, 14), rtol=1e-5, atol=1e-6)
    _assert_close(fa.obv_array(c, v), talib.OBV(c, v))

    mk, md = fa.stochastic_array(h, l, c, 14, 3)
    rk, rd = talib.STOCH(h, l, c, fastk_period=14, slowk_period=3, slowd_period=3)
    _assert_close(mk, rk, rtol=1e-5, atol=1e-6)
    _assert_close(md, rd, rtol=1e-5, atol=1e-6)

    line, sig, hist = fa.macd_array(c, 12, 26, 9)
    rl, rs, rh = talib.MACD(c, fastperiod=12, slowperiod=26, signalperiod=9)
    _assert_close(line[tail], rl[tail], rtol=2e-4, atol=2e-4)
    _assert_close(sig[tail], rs[tail], rtol=2e-4, atol=2e-4)
    _assert_close(hist[tail], rh[tail], rtol=2e-4, atol=2e-4)


def test_fast_mode_parity_dataframe_api() -> None:
    df = _market_df()

    np.testing.assert_allclose(
        sma(df, window=20)["sma_20"].to_numpy(),
        sma(df, window=20, fast_mode=True)["sma_20"].to_numpy(),
        equal_nan=True,
    )
    np.testing.assert_allclose(
        ema(df, window=20)["ema_20"].to_numpy(),
        ema(df, window=20, fast_mode=True)["ema_20"].to_numpy(),
        equal_nan=True,
    )
    np.testing.assert_allclose(
        rsi(df, window=14)["rsi_14"].to_numpy(),
        rsi(df, window=14, fast_mode=True)["rsi_14"].to_numpy(),
        equal_nan=True,
    )

    out1 = macd(df)
    out2 = macd(df, fast_mode=True)
    np.testing.assert_allclose(out1["macd_12_26_9_line"].to_numpy(), out2["macd_12_26_9_line"].to_numpy(), equal_nan=True)
    np.testing.assert_allclose(
        out1["macd_12_26_9_signal"].to_numpy(),
        out2["macd_12_26_9_signal"].to_numpy(),
        equal_nan=True,
    )

    np.testing.assert_allclose(
        atr(df, window=14)["atr_14"].to_numpy(),
        atr(df, window=14, fast_mode=True)["atr_14"].to_numpy(),
        equal_nan=True,
    )
    b1 = bollinger_bands(df, window=20, num_std=2.0)
    b2 = bollinger_bands(df, window=20, num_std=2.0, fast_mode=True)
    np.testing.assert_allclose(b1["bb_20_2_upper"].to_numpy(), b2["bb_20_2_upper"].to_numpy(), equal_nan=True)
