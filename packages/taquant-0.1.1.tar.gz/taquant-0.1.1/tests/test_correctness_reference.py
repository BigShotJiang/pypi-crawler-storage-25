"""Correctness tests against reference numpy fixtures."""

from __future__ import annotations

import numpy as np
import pandas as pd

from taquant.price import median_price, typical_price, weighted_close
from taquant.volume import vwap


def test_non_talib_indicators_match_golden_fixture() -> None:
    df = pd.read_csv("data/fixtures/ohlcv_deterministic.csv")
    golden = pd.read_csv("data/fixtures/golden_non_talib.csv")

    out_tp = typical_price(df)
    out_mp = median_price(df)
    out_wc = weighted_close(df)
    out_vwap = vwap(df)

    np.testing.assert_allclose(out_tp["typical_price"].to_numpy(), golden["typical_price"].to_numpy(), rtol=1e-12, atol=1e-12)
    np.testing.assert_allclose(out_mp["median_price"].to_numpy(), golden["median_price"].to_numpy(), rtol=1e-12, atol=1e-12)
    np.testing.assert_allclose(out_wc["weighted_close"].to_numpy(), golden["weighted_close"].to_numpy(), rtol=1e-12, atol=1e-12)
    np.testing.assert_allclose(out_vwap["vwap"].to_numpy(), golden["vwap"].to_numpy(), rtol=1e-12, atol=1e-12)


def test_reference_edge_case_nan_input_propagation() -> None:
    df = pd.DataFrame(
        {
            "High": [10.0, np.nan, 12.0],
            "Low": [9.0, 10.0, np.nan],
            "Close": [9.5, 10.5, 11.5],
            "Volume": [100.0, 200.0, 300.0],
        }
    )
    out = typical_price(df)
    vals = out["typical_price"].to_numpy()
    assert np.isnan(vals[1])
    assert np.isnan(vals[2])
