"""Tests for stateful realtime modules."""

from __future__ import annotations

import numpy as np
import pandas as pd

from taquant.momentum import rsi
from taquant.stateful import EMAState, RSIState
from taquant.trend import ema


def test_ema_state_matches_batch_ema() -> None:
    prices = np.array([1.0, 2.0, 3.0, 2.0, 5.0, 4.0], dtype=np.float64)
    window = 3

    state = EMAState(window=window)
    state_values = np.array([state.update(float(p)) for p in prices], dtype=np.float64)

    df = pd.DataFrame({"Close": prices})
    batch = ema(df, window=window)["ema_3"].to_numpy()
    np.testing.assert_allclose(state_values, batch)


def test_rsi_state_approximately_matches_batch_rsi_after_warmup() -> None:
    prices = np.array([44, 44.15, 43.9, 44.35, 44.8, 44.6, 45.2, 45.0, 45.4, 45.8, 45.6, 46.0, 46.2, 46.5, 46.4, 46.8], dtype=np.float64)
    window = 14

    state = RSIState(window=window)
    state_values = np.array([state.update(float(p)) for p in prices], dtype=np.float64)

    df = pd.DataFrame({"Close": prices})
    batch = rsi(df, window=window)["rsi_14"].to_numpy()

    # Compare from first finite batch RSI value onward.
    start = np.where(np.isfinite(batch))[0][0]
    np.testing.assert_allclose(state_values[start:], batch[start:], atol=1e-8)
