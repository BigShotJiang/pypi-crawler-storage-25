"""Additional core tests to validate edge branches and contracts."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from taquant.core.base import apply_indicator
from taquant.core.cache import CacheKey, IndicatorCache
from taquant.core.multisymbol import apply_by_symbol
from taquant.core.numba_funcs import cumsum_kernel, ema_kernel, variance_kernel, wma_kernel
from taquant.core.rolling import rolling_max, rolling_mean, rolling_min, rolling_std
from taquant.core.utils import make_output_name, to_float64_array
from taquant.core.validation import (
    TAQuantParameterError,
    TAQuantValidationError,
    validate_column,
    validate_dataframe_schema,
    validate_params,
    validate_window,
)


def test_utils_to_float64_array_and_make_output_name() -> None:
    arr = to_float64_array([1, 2, 3])
    assert arr.dtype == np.float64
    assert arr.flags.c_contiguous
    assert make_output_name("ema", window=20) == "ema_20"
    assert make_output_name("ema", output_name="custom", window=20) == "custom"


def test_utils_to_float64_array_non_1d_raises() -> None:
    with pytest.raises(ValueError):
        to_float64_array(np.ones((2, 2)))


def test_validation_branches() -> None:
    with pytest.raises(TAQuantValidationError):
        validate_dataframe_schema([])

    with pytest.raises(TAQuantValidationError):
        validate_dataframe_schema(pd.DataFrame())

    df = pd.DataFrame({"Close": [1.0]})
    with pytest.raises(TAQuantValidationError):
        validate_dataframe_schema(df, required_columns=["Open", "Close"])

    with pytest.raises(TAQuantParameterError):
        validate_column(df, "")

    with pytest.raises(TAQuantParameterError):
        validate_window(0)

    with pytest.raises(TAQuantParameterError):
        validate_params(bad=object())


def test_rolling_helpers_all_paths() -> None:
    arr = np.array([1.0, np.nan, 3.0, 4.0, 5.0], dtype=np.float64)
    mean = rolling_mean(arr, 2)
    std = rolling_std(np.array([1.0, 2.0, 3.0, 4.0], dtype=np.float64), 2)
    rmin = rolling_min(np.array([3.0, 1.0, 2.0, 0.5], dtype=np.float64), 2)
    rmax = rolling_max(np.array([3.0, 1.0, 2.0, 0.5], dtype=np.float64), 2)

    assert np.isnan(mean[1])
    assert np.isfinite(std[-1])
    assert rmin[-1] == 0.5
    assert rmax[-1] == 2.0

    with pytest.raises(ValueError):
        rolling_std(np.array([1.0, 2.0]), 2, ddof=2)


def test_numba_wrapper_validation_and_outputs() -> None:
    arr = np.array([1.0, 2.0, 3.0], dtype=np.float64)
    with pytest.raises(ValueError):
        ema_kernel(arr, alpha=0.0)

    assert cumsum_kernel(arr)[-1] == 6.0
    assert np.isfinite(wma_kernel(arr, 2)[-1])
    assert np.isfinite(variance_kernel(arr, 2, 0)[-1])


def _dict_compute(arr: np.ndarray) -> dict[str, np.ndarray]:
    return {"a": arr + 1.0, "b": arr + 2.0}


def test_apply_indicator_dict_output_and_type_error() -> None:
    df = pd.DataFrame({"Close": [1.0, 2.0, 3.0], "Symbol": ["A", "A", "A"]})
    out = apply_indicator(df, _dict_compute, column="Close", output_name="x")
    assert "x_a" in out.columns
    assert "x_b" in out.columns

    with pytest.raises(TypeError):
        apply_indicator(df, lambda arr: 1.0, column="Close")


def test_apply_indicator_symbol_col_branch() -> None:
    df = pd.DataFrame({"Close": [1.0, 2.0, 3.0, 4.0], "Symbol": ["A", "B", "A", "B"]})

    def _fn(group_df: pd.DataFrame, **kwargs):
        return apply_indicator(group_df, lambda arr: arr + 1.0, column="Close", output_name="p1", **kwargs)

    out = apply_by_symbol(df, "Symbol", _fn)
    assert out.index.equals(df.index)
    np.testing.assert_allclose(out["p1"].to_numpy(), np.array([2.0, 3.0, 4.0, 5.0]))


def test_multisymbol_invalid_indicator_return_type() -> None:
    df = pd.DataFrame({"Close": [1.0, 2.0], "Symbol": ["A", "B"]})
    with pytest.raises(TAQuantParameterError):
        apply_by_symbol(df, "Symbol", lambda *_args, **_kwargs: 1)


def test_cache_hit_rate_and_invalidate_all() -> None:
    cache = IndicatorCache()
    key = CacheKey(
        indicator="x",
        column="Close",
        window=2,
        params_hash="k=v",
        data_id=1,
        start_idx=0,
        end_idx=2,
        dtype="float64",
        shape=(2,),
    )
    assert cache.hit_rate == 0.0
    cache.get(key)
    cache.set(key, 1)
    cache.get(key)
    assert cache.hits == 1
    assert cache.misses == 1
    assert cache.hit_rate == 0.5
    cache.invalidate()
    assert len(cache) == 0
