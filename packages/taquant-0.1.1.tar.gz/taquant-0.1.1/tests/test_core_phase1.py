"""Phase 1 smoke tests for core infrastructure."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from taquant.core.base import apply_indicator
from taquant.core.numba_funcs import cumsum_kernel, ema_kernel, variance_kernel, wma_kernel
from taquant.core.validation import TAQuantParameterError, TAQuantValidationError


def dummy_add_one(arr: np.ndarray) -> np.ndarray:
    return arr + 1.0


def test_apply_indicator_attaches_output_column() -> None:
    df = pd.DataFrame({"Close": [1.0, 2.0, 3.0]})
    out = apply_indicator(df, dummy_add_one, column="Close")
    assert "dummy_add_one" in out.columns
    np.testing.assert_allclose(out["dummy_add_one"].to_numpy(), np.array([2.0, 3.0, 4.0]))


def test_apply_indicator_missing_column_raises_clear_error() -> None:
    df = pd.DataFrame({"Close": [1.0, 2.0, 3.0]})
    with pytest.raises(TAQuantValidationError, match="does not exist"):
        apply_indicator(df, dummy_add_one, column="Open")


def test_apply_indicator_window_validation_raises_clear_error() -> None:
    df = pd.DataFrame({"Close": [1.0, 2.0, 3.0]})
    with pytest.raises(TAQuantParameterError, match="greater than 0"):
        apply_indicator(df, dummy_add_one, column="Close", window=0)


def test_apply_indicator_dtype_conversion_failure_raises_error() -> None:
    df = pd.DataFrame({"Close": ["a", "b", "c"]})
    with pytest.raises((TypeError, ValueError)):
        apply_indicator(df, dummy_add_one, column="Close")


def test_numba_kernels_compile_and_return_expected_shapes() -> None:
    arr = np.array([1.0, 2.0, 3.0, 4.0, 5.0], dtype=np.float64)
    ema = ema_kernel(arr, alpha=0.5)
    wma = wma_kernel(arr, window=3)
    var = variance_kernel(arr, window=3, ddof=0)
    csum = cumsum_kernel(arr)

    assert ema.shape == arr.shape
    assert wma.shape == arr.shape
    assert var.shape == arr.shape
    assert csum.shape == arr.shape
    assert np.isfinite(ema[-1])
    assert np.isfinite(csum[-1])
