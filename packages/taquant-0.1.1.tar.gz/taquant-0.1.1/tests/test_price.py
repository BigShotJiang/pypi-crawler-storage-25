"""Tests for price transform indicators."""

from __future__ import annotations

import numpy as np
import pandas as pd

from taquant.price import median_price, typical_price, weighted_close


def _sample_df() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "High": [10.0, 12.0, 14.0],
            "Low": [8.0, 9.0, 11.0],
            "Close": [9.0, 10.0, 13.0],
            "Volume": [100.0, 150.0, 120.0],
        }
    )


def test_typical_price_values_and_default_name() -> None:
    df = _sample_df()
    out = typical_price(df)
    expected = (df["High"] + df["Low"] + df["Close"]) / 3.0
    assert "typical_price" in out.columns
    np.testing.assert_allclose(out["typical_price"].to_numpy(), expected.to_numpy())


def test_median_price_values() -> None:
    df = _sample_df()
    out = median_price(df)
    expected = (df["High"] + df["Low"]) / 2.0
    np.testing.assert_allclose(out["median_price"].to_numpy(), expected.to_numpy())


def test_weighted_close_values_custom_output_name() -> None:
    df = _sample_df()
    out = weighted_close(df, output_name="wclose")
    expected = (df["High"] + df["Low"] + 2.0 * df["Close"]) / 4.0
    assert "wclose" in out.columns
    np.testing.assert_allclose(out["wclose"].to_numpy(), expected.to_numpy())


def test_price_indicators_inplace_mode() -> None:
    df = _sample_df()
    out = typical_price(df, inplace=True)
    assert out is df
    assert "typical_price" in df.columns
