"""Tests for volatility indicators."""

from __future__ import annotations

import numpy as np
import pandas as pd

from taquant.volatility import atr, bollinger_bands, stddev


def test_stddev_values_ddof0() -> None:
    df = pd.DataFrame({"Close": [1.0, 2.0, 3.0, 4.0]})
    out = stddev(df, window=3, ddof=0)
    expected = np.array([np.nan, np.nan, np.sqrt(2.0 / 3.0), np.sqrt(2.0 / 3.0)])
    assert "stddev_3" in out.columns
    np.testing.assert_allclose(out["stddev_3"].to_numpy(), expected, atol=1e-12, equal_nan=True)


def test_stddev_inplace_mode() -> None:
    df = pd.DataFrame({"Close": [1.0, 2.0, 3.0]})
    out = stddev(df, window=2, inplace=True)
    assert out is df
    assert "stddev_2" in df.columns


def test_atr_and_bbands_columns_exist() -> None:
    df = pd.DataFrame(
        {
            "High": [10.2, 10.4, 10.8, 11.1, 11.3, 11.7, 11.9],
            "Low": [9.7, 9.9, 10.2, 10.6, 10.9, 11.2, 11.4],
            "Close": [10.0, 10.2, 10.6, 10.8, 11.0, 11.5, 11.6],
        }
    )
    out_atr = atr(df, window=3)
    out_bb = bollinger_bands(df, window=3, num_std=2.0)

    assert "atr_3" in out_atr.columns
    assert "bb_3_2_upper" in out_bb.columns
    assert "bb_3_2_middle" in out_bb.columns
    assert "bb_3_2_lower" in out_bb.columns


def test_volatility_edge_len_less_than_window() -> None:
    df = pd.DataFrame({"Close": [1.0, 2.0]})
    out = stddev(df, window=5)
    assert np.all(np.isnan(out["stddev_5"].to_numpy()))
