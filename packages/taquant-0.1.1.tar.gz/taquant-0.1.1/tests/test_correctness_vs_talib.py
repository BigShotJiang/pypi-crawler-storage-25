"""Correctness tests against TA-Lib for mapped indicators."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from taquant.momentum import rsi, stochastic
from taquant.trend import ema, macd, sma, wma
from taquant.volatility import atr, bollinger_bands, stddev
from taquant.volume import obv

talib = pytest.importorskip("talib")


def _market_df(n: int = 400) -> pd.DataFrame:
    rng = np.random.default_rng(2026)
    close = rng.normal(loc=100.0, scale=2.0, size=n).astype(np.float64)
    high = close + rng.uniform(0.1, 1.0, size=n)
    low = close - rng.uniform(0.1, 1.0, size=n)
    vol = rng.integers(100, 5000, size=n).astype(np.float64)
    return pd.DataFrame({"High": high, "Low": low, "Close": close, "Volume": vol})


def _assert_close_on_finite(a: np.ndarray, b: np.ndarray, rtol: float = 1e-6, atol: float = 1e-8) -> None:
    mask = np.isfinite(a) & np.isfinite(b)
    assert mask.any(), "No overlapping finite values to compare"
    np.testing.assert_allclose(a[mask], b[mask], rtol=rtol, atol=atol)


def test_sma_vs_talib() -> None:
    df = _market_df()
    fast = sma(df, window=20)["sma_20"].to_numpy()
    ref = talib.SMA(df["Close"].to_numpy(), timeperiod=20)
    _assert_close_on_finite(fast, ref)


def test_wma_vs_talib() -> None:
    df = _market_df()
    fast = wma(df, window=20)["wma_20"].to_numpy()
    ref = talib.WMA(df["Close"].to_numpy(), timeperiod=20)
    _assert_close_on_finite(fast, ref)


def test_stddev_vs_talib() -> None:
    df = _market_df()
    fast = stddev(df, window=20, ddof=0)["stddev_20"].to_numpy()
    ref = talib.STDDEV(df["Close"].to_numpy(), timeperiod=20, nbdev=1)
    _assert_close_on_finite(fast, ref)


def test_rsi_vs_talib() -> None:
    df = _market_df()
    fast = rsi(df, window=14)["rsi_14"].to_numpy()
    ref = talib.RSI(df["Close"].to_numpy(), timeperiod=14)
    _assert_close_on_finite(fast, ref, rtol=1e-5, atol=1e-6)


def test_atr_vs_talib() -> None:
    df = _market_df()
    fast = atr(df, window=14)["atr_14"].to_numpy()
    ref = talib.ATR(df["High"].to_numpy(), df["Low"].to_numpy(), df["Close"].to_numpy(), timeperiod=14)
    _assert_close_on_finite(fast, ref, rtol=1e-5, atol=1e-6)


def test_obv_vs_talib() -> None:
    df = _market_df()
    fast = obv(df)["obv"].to_numpy()
    ref = talib.OBV(df["Close"].to_numpy(), df["Volume"].to_numpy())
    _assert_close_on_finite(fast, ref, rtol=1e-8, atol=1e-8)


def test_bbands_vs_talib() -> None:
    df = _market_df()
    out = bollinger_bands(df, window=20, num_std=2.0)
    upper, middle, lower = talib.BBANDS(df["Close"].to_numpy(), timeperiod=20, nbdevup=2.0, nbdevdn=2.0, matype=0)

    _assert_close_on_finite(out["bb_20_2_upper"].to_numpy(), upper, rtol=1e-6, atol=1e-7)
    _assert_close_on_finite(out["bb_20_2_middle"].to_numpy(), middle, rtol=1e-6, atol=1e-7)
    _assert_close_on_finite(out["bb_20_2_lower"].to_numpy(), lower, rtol=1e-6, atol=1e-7)


def test_macd_vs_talib_tail() -> None:
    df = _market_df()
    out = macd(df, fast_window=12, slow_window=26, signal_window=9)
    ref_macd, ref_signal, ref_hist = talib.MACD(df["Close"].to_numpy(), fastperiod=12, slowperiod=26, signalperiod=9)

    # Different seed policies may diverge early; compare stable tail.
    tail = slice(120, None)
    _assert_close_on_finite(out["macd_12_26_9_line"].to_numpy()[tail], ref_macd[tail], rtol=2e-4, atol=2e-4)
    _assert_close_on_finite(out["macd_12_26_9_signal"].to_numpy()[tail], ref_signal[tail], rtol=2e-4, atol=2e-4)
    _assert_close_on_finite(out["macd_12_26_9_hist"].to_numpy()[tail], ref_hist[tail], rtol=2e-4, atol=2e-4)


def test_ema_vs_talib_tail() -> None:
    df = _market_df()
    fast = ema(df, window=20)["ema_20"].to_numpy()
    ref = talib.EMA(df["Close"].to_numpy(), timeperiod=20)

    tail = slice(120, None)
    _assert_close_on_finite(fast[tail], ref[tail], rtol=2e-4, atol=2e-4)


def test_stochastic_vs_talib() -> None:
    df = _market_df()
    out = stochastic(df, k_window=14, d_window=3)
    ref_k, ref_d = talib.STOCH(
        df["High"].to_numpy(),
        df["Low"].to_numpy(),
        df["Close"].to_numpy(),
        fastk_period=14,
        slowk_period=3,
        slowd_period=3,
    )
    _assert_close_on_finite(out["stoch_14_k"].to_numpy(), ref_k, rtol=1e-5, atol=1e-6)
    _assert_close_on_finite(out["stoch_14_d"].to_numpy(), ref_d, rtol=1e-5, atol=1e-6)
