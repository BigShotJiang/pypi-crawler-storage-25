"""Tests for cache behavior and invalidation."""

from __future__ import annotations

import pandas as pd

from taquant.core.cache import CacheKey, IndicatorCache, make_params_hash
from taquant.trend.macd import _CACHE as MACD_CACHE
from taquant.trend.macd import macd


def _key(indicator: str, data_id: int | str = 1, column: str = "Close") -> CacheKey:
    return CacheKey(
        indicator=indicator,
        column=column,
        window=20,
        params_hash=make_params_hash({"window": 20}),
        data_id=data_id,
        start_idx=0,
        end_idx=10,
        dtype="float64",
        shape=(10,),
    )


def test_cache_set_get_and_clear() -> None:
    cache = IndicatorCache()
    key = _key("ema")
    cache.set(key, [1, 2, 3])
    assert cache.get(key) == [1, 2, 3]
    cache.clear()
    assert cache.get(key) is None


def test_cache_invalidate_by_data_id() -> None:
    cache = IndicatorCache()
    k1 = _key("ema", data_id=1)
    k2 = _key("ema", data_id=2)
    cache.set(k1, "a")
    cache.set(k2, "b")

    cache.invalidate(data_id=1)

    assert cache.get(k1) is None
    assert cache.get(k2) == "b"


def test_cache_invalidate_by_indicator_and_column() -> None:
    cache = IndicatorCache()
    k1 = _key("ema", column="Close")
    k2 = _key("ema", column="Open")
    k3 = _key("sma", column="Close")

    cache.set(k1, 1)
    cache.set(k2, 2)
    cache.set(k3, 3)

    cache.invalidate(indicator="ema", column="Close")

    assert cache.get(k1) is None
    assert cache.get(k2) == 2
    assert cache.get(k3) == 3


def test_make_params_hash_is_stable_for_sorted_keys() -> None:
    h1 = make_params_hash({"b": 2, "a": 1})
    h2 = make_params_hash({"a": 1, "b": 2})
    assert h1 == h2


def test_macd_cache_reuse_same_dataframe() -> None:
    MACD_CACHE.clear()
    df = pd.DataFrame({"Close": [1.0, 2.0, 3.0, 4.0, 5.0]})
    macd(df, inplace=False)
    size_after_first = len(MACD_CACHE)
    macd(df, inplace=False)
    size_after_second = len(MACD_CACHE)

    assert size_after_first == 1
    assert size_after_second == 1
