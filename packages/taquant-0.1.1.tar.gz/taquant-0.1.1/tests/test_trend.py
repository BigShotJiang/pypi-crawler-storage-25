"""Tests for trend indicators."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from taquant.trend import ema, macd, sma, wma


def _close_df(values: list[float]) -> pd.DataFrame:
    return pd.DataFrame({"Close": values})


def test_sma_values_and_output_name() -> None:
    df = _close_df([1.0, 2.0, 3.0, 4.0, 5.0])
    out = sma(df, window=3)
    expected = np.array([np.nan, np.nan, 2.0, 3.0, 4.0])
    assert "sma_3" in out.columns
    np.testing.assert_allclose(out["sma_3"].to_numpy(), expected, equal_nan=True)


def test_ema_values_and_output_name() -> None:
    df = _close_df([1.0, 2.0, 3.0, 4.0])
    out = ema(df, window=3)
    alpha = 2.0 / (3.0 + 1.0)
    expected = np.array([1.0, 1.5, 2.25, 3.125])
    # Sanity check alpha used by implementation.
    assert np.isclose(alpha, 0.5)
    assert "ema_3" in out.columns
    np.testing.assert_allclose(out["ema_3"].to_numpy(), expected)


def test_wma_values_and_output_name() -> None:
    df = _close_df([1.0, 2.0, 3.0, 4.0])
    out = wma(df, window=3)
    expected = np.array([np.nan, np.nan, 14.0 / 6.0, 20.0 / 6.0])
    assert "wma_3" in out.columns
    np.testing.assert_allclose(out["wma_3"].to_numpy(), expected, equal_nan=True)


def test_trend_indicators_1000_and_100k_rows_smoke() -> None:
    rng = np.random.default_rng(42)
    for n in (1_000, 100_000):
        df = pd.DataFrame({"Close": rng.normal(size=n).astype(np.float64)})
        out_sma = sma(df, window=20)
        out_ema = ema(df, window=20)
        out_wma = wma(df, window=20)
        assert len(out_sma) == n
        assert len(out_ema) == n
        assert len(out_wma) == n
        assert "sma_20" in out_sma.columns
        assert "ema_20" in out_ema.columns
        assert "wma_20" in out_wma.columns


def test_macd_outputs_and_columns() -> None:
    df = _close_df([1.0, 2.0, 2.5, 3.0, 2.8, 3.4, 3.8, 4.0])
    out = macd(df, fast_window=3, slow_window=5, signal_window=2)
    assert "macd_3_5_2_line" in out.columns
    assert "macd_3_5_2_signal" in out.columns
    assert "macd_3_5_2_hist" in out.columns
    assert np.isfinite(out["macd_3_5_2_line"].to_numpy()[-1])


def test_trend_edge_len_less_than_window() -> None:
    df = _close_df([1.0, 2.0, 3.0])
    out = sma(df, window=5)
    assert np.all(np.isnan(out["sma_5"].to_numpy()))


def test_trend_invalid_windows_raise() -> None:
    df = _close_df([1.0, 2.0, 3.0, 4.0])
    with pytest.raises(ValueError):
        sma(df, window=0)
    with pytest.raises(ValueError):
        macd(df, fast_window=5, slow_window=5, signal_window=3)
