"""Typical Price indicator."""

from __future__ import annotations

from typing import Any

from taquant.core.numba_funcs import typical_price_kernel
from taquant.core.utils import make_output_name, to_float64_array
from taquant.core.validation import validate_column, validate_dataframe_schema


def typical_price(
    df: Any,
    output_name: str | None = None,
    inplace: bool = False,
    fast_mode: bool = False,
) -> Any:
    """Compute Typical Price: (High + Low + Close) / 3."""
    if not fast_mode:
        validate_dataframe_schema(df)
        validate_column(df, "High")
        validate_column(df, "Low")
        validate_column(df, "Close")

    result_df = df if inplace else df.copy(deep=False)
    high = to_float64_array(result_df["High"])
    low = to_float64_array(result_df["Low"])
    close = to_float64_array(result_df["Close"])
    result_df[make_output_name("typical_price", output_name=output_name)] = typical_price_kernel(high, low, close)
    return result_df
