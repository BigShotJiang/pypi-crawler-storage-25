"""Price transform indicators (Series/ndarray-oriented public API)."""

from __future__ import annotations

from typing import Any

import numpy as np
from taquant import array_api as fa

from .median_price import median_price as _median_price_df
from .typical_price import typical_price as _typical_price_df
from .weighted_close import weighted_close as _weighted_close_df


def typical_price(df: Any, fast_mode: bool = False) -> Any:
    if not fast_mode and hasattr(df, "columns") and "Symbol" in getattr(df, "columns"):
        name = "__typical_price__"
        out = _typical_price_df(df, output_name=name, inplace=False, fast_mode=fast_mode)
        return out[name]
    return fa.typical_price_array(df["High"], df["Low"], df["Close"])


def median_price(df: Any, fast_mode: bool = False) -> Any:
    if not fast_mode and hasattr(df, "columns") and "Symbol" in getattr(df, "columns"):
        name = "__median_price__"
        out = _median_price_df(df, output_name=name, inplace=False, fast_mode=fast_mode)
        return out[name]
    high = np.asarray(df["High"], dtype=np.float64)
    low = np.asarray(df["Low"], dtype=np.float64)
    return (high + low) / 2.0


def weighted_close(df: Any, fast_mode: bool = False) -> Any:
    if not fast_mode and hasattr(df, "columns") and "Symbol" in getattr(df, "columns"):
        name = "__weighted_close__"
        out = _weighted_close_df(df, output_name=name, inplace=False, fast_mode=fast_mode)
        return out[name]
    return fa.weighted_close_array(df["High"], df["Low"], df["Close"])


__all__ = ["typical_price", "median_price", "weighted_close"]
