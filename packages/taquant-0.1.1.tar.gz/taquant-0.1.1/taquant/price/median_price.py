"""Median Price indicator."""

from __future__ import annotations

from typing import Any

from taquant.core.numba_funcs import median_price_kernel
from taquant.core.utils import make_output_name, to_float64_array
from taquant.core.validation import validate_column, validate_dataframe_schema


def median_price(
    df: Any,
    output_name: str | None = None,
    inplace: bool = False,
    fast_mode: bool = False,
) -> Any:
    """Compute Median Price: (High + Low) / 2."""
    if not fast_mode:
        validate_dataframe_schema(df)
        validate_column(df, "High")
        validate_column(df, "Low")

    result_df = df if inplace else df.copy(deep=False)
    high = to_float64_array(result_df["High"])
    low = to_float64_array(result_df["Low"])
    result_df[make_output_name("median_price", output_name=output_name)] = median_price_kernel(high, low)
    return result_df
