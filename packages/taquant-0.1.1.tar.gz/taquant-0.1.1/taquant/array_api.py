"""Array-native indicator API (ndarray -> ndarray)."""

from __future__ import annotations

import numpy as np

from taquant.core.numba_funcs import (
    atr_kernel,
    bbands_kernel,
    cci_kernel,
    ema_kernel,
    median_price_kernel,
    obv_kernel,
    rolling_mean_kernel,
    rsi_kernel,
    stochastic_kernel,
    stddev_kernel,
    typical_price_kernel,
    variance_kernel,
    vwap_kernel,
    weighted_close_kernel,
    wma_kernel,
)
from taquant.core.rolling import rolling_mean
from taquant.core.utils import to_float64_array


def _validate_window(window: int, name: str = "window") -> None:
    if isinstance(window, bool) or not isinstance(window, int) or window <= 0:
        raise ValueError(f"{name} must be a positive integer.")


def _as_float64_1d(arr: np.ndarray) -> np.ndarray:
    if isinstance(arr, np.ndarray) and arr.dtype == np.float64 and arr.ndim == 1 and arr.flags.c_contiguous:
        return arr
    return to_float64_array(arr)


def _rolling_mean_auto(arr: np.ndarray, window: int) -> np.ndarray:
    if np.isfinite(arr).all():
        return rolling_mean_kernel(arr, window)
    return rolling_mean(arr, window)


def typical_price_array(high: np.ndarray, low: np.ndarray, close: np.ndarray) -> np.ndarray:
    return typical_price_kernel(_as_float64_1d(high), _as_float64_1d(low), _as_float64_1d(close))


def median_price_array(high: np.ndarray, low: np.ndarray) -> np.ndarray:
    return median_price_kernel(_as_float64_1d(high), _as_float64_1d(low))


def weighted_close_array(high: np.ndarray, low: np.ndarray, close: np.ndarray) -> np.ndarray:
    return weighted_close_kernel(_as_float64_1d(high), _as_float64_1d(low), _as_float64_1d(close))


def sma_array(arr: np.ndarray, window: int) -> np.ndarray:
    _validate_window(window)
    x = _as_float64_1d(arr)
    return _rolling_mean_auto(x, window)


def ema_array(arr: np.ndarray, window: int) -> np.ndarray:
    _validate_window(window)
    x = _as_float64_1d(arr)
    return ema_kernel(x, alpha=(2.0 / (window + 1.0)))


def wma_array(arr: np.ndarray, window: int) -> np.ndarray:
    _validate_window(window)
    return wma_kernel(_as_float64_1d(arr), window)


def macd_array(
    arr: np.ndarray,
    fast_window: int = 12,
    slow_window: int = 26,
    signal_window: int = 9,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    _validate_window(fast_window, "fast_window")
    _validate_window(slow_window, "slow_window")
    _validate_window(signal_window, "signal_window")
    if fast_window >= slow_window:
        raise ValueError("fast_window must be smaller than slow_window.")

    x = _as_float64_1d(arr)
    ema_fast = ema_kernel(x, alpha=(2.0 / (fast_window + 1.0)))
    ema_slow = ema_kernel(x, alpha=(2.0 / (slow_window + 1.0)))
    line = ema_fast - ema_slow
    signal = ema_kernel(line, alpha=(2.0 / (signal_window + 1.0)))
    hist = line - signal
    return line, signal, hist


def rsi_array(arr: np.ndarray, window: int = 14) -> np.ndarray:
    _validate_window(window)
    return rsi_kernel(_as_float64_1d(arr), window)


def stochastic_array(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    k_window: int = 14,
    d_window: int = 3,
) -> tuple[np.ndarray, np.ndarray]:
    _validate_window(k_window, "k_window")
    _validate_window(d_window, "d_window")
    h = _as_float64_1d(high)
    l = _as_float64_1d(low)
    c = _as_float64_1d(close)
    return stochastic_kernel(h, l, c, k_window=k_window, d_window=d_window)


def cci_array(high: np.ndarray, low: np.ndarray, close: np.ndarray, window: int = 20) -> np.ndarray:
    _validate_window(window)
    h = _as_float64_1d(high)
    l = _as_float64_1d(low)
    c = _as_float64_1d(close)
    return cci_kernel(h, l, c, window)


def stddev_array(arr: np.ndarray, window: int, ddof: int = 0) -> np.ndarray:
    _validate_window(window)
    return stddev_kernel(_as_float64_1d(arr), window=window, ddof=ddof)


def atr_array(high: np.ndarray, low: np.ndarray, close: np.ndarray, window: int = 14) -> np.ndarray:
    _validate_window(window)
    h = _as_float64_1d(high)
    l = _as_float64_1d(low)
    c = _as_float64_1d(close)
    return atr_kernel(h, l, c, window)


def bollinger_bands_array(
    arr: np.ndarray,
    window: int = 20,
    num_std: float = 2.0,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    _validate_window(window)
    x = _as_float64_1d(arr)
    if np.isfinite(x).all():
        return bbands_kernel(x, window=window, num_std=num_std)
    mid = _rolling_mean_auto(x, window)
    std = np.sqrt(variance_kernel(x, window=window, ddof=0))
    upper = mid + num_std * std
    lower = mid - num_std * std
    return upper, mid, lower


def volume_ma_array(volume: np.ndarray, window: int) -> np.ndarray:
    _validate_window(window)
    x = _as_float64_1d(volume)
    return _rolling_mean_auto(x, window)


def obv_array(close: np.ndarray, volume: np.ndarray) -> np.ndarray:
    c = _as_float64_1d(close)
    v = _as_float64_1d(volume)
    return obv_kernel(c, v)


def vwap_array(price: np.ndarray, volume: np.ndarray) -> np.ndarray:
    p = _as_float64_1d(price)
    v = _as_float64_1d(volume)
    return vwap_kernel(p, v)
