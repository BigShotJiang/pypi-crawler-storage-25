"""Numba-ready compute kernels."""

from __future__ import annotations

import numpy as np
from numba import njit


@njit(cache=True)
def _ema_kernel_impl(arr: np.ndarray, alpha: float) -> np.ndarray:  # pragma: no cover
    n = arr.shape[0]
    out = np.empty(n, dtype=np.float64)
    if n == 0:
        return out

    out[0] = arr[0]
    for i in range(1, n):
        out[i] = alpha * arr[i] + (1.0 - alpha) * out[i - 1]
    return out


@njit(cache=True)
def _typical_price_kernel_impl(high: np.ndarray, low: np.ndarray, close: np.ndarray) -> np.ndarray:  # pragma: no cover
    n = close.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        out[i] = (high[i] + low[i] + close[i]) / 3.0
    return out


@njit(cache=True)
def _median_price_kernel_impl(high: np.ndarray, low: np.ndarray) -> np.ndarray:  # pragma: no cover
    n = high.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        out[i] = (high[i] + low[i]) / 2.0
    return out


@njit(cache=True)
def _weighted_close_kernel_impl(high: np.ndarray, low: np.ndarray, close: np.ndarray) -> np.ndarray:  # pragma: no cover
    n = close.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        out[i] = (high[i] + low[i] + 2.0 * close[i]) / 4.0
    return out


@njit(cache=True)
def _wma_kernel_impl(arr: np.ndarray, window: int) -> np.ndarray:  # pragma: no cover
    n = arr.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        out[i] = np.nan

    if window <= 0 or n < window:
        return out

    denom = window * (window + 1) / 2.0

    simple_sum = 0.0
    weighted_sum = 0.0
    for j in range(window):
        v = arr[j]
        simple_sum += v
        weighted_sum += (j + 1.0) * v
    out[window - 1] = weighted_sum / denom

    for i in range(window, n):
        new_v = arr[i]
        old_v = arr[i - window]
        weighted_sum = weighted_sum - simple_sum + window * new_v
        simple_sum = simple_sum - old_v + new_v
        out[i] = weighted_sum / denom
    return out


@njit(cache=True, fastmath=True)
def _stddev_kernel_impl(arr: np.ndarray, window: int, ddof: int) -> np.ndarray:  # pragma: no cover
    n = arr.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        out[i] = np.nan
    if window <= 0 or ddof < 0 or ddof >= window or n < window:
        return out

    run_sum = 0.0
    run_sq = 0.0
    for i in range(window):
        v = arr[i]
        run_sum += v
        run_sq += v * v

    denom = window - ddof
    mean = run_sum / window
    var = (run_sq - window * mean * mean) / denom
    if var < 0.0:
        var = 0.0
    out[window - 1] = np.sqrt(var)

    for i in range(window, n):
        add_v = arr[i]
        rem_v = arr[i - window]
        run_sum += add_v - rem_v
        run_sq += add_v * add_v - rem_v * rem_v
        mean = run_sum / window
        var = (run_sq - window * mean * mean) / denom
        if var < 0.0:
            var = 0.0
        out[i] = np.sqrt(var)
    return out


@njit(cache=True)
def _bbands_kernel_impl(arr: np.ndarray, window: int, num_std: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:  # pragma: no cover
    n = arr.shape[0]
    upper = np.empty(n, dtype=np.float64)
    middle = np.empty(n, dtype=np.float64)
    lower = np.empty(n, dtype=np.float64)
    for i in range(n):
        upper[i] = np.nan
        middle[i] = np.nan
        lower[i] = np.nan
    if window <= 0 or n < window:
        return upper, middle, lower

    run_sum = 0.0
    run_sq = 0.0
    for i in range(window):
        v = arr[i]
        run_sum += v
        run_sq += v * v

    mean = run_sum / window
    var = (run_sq - window * mean * mean) / window
    if var < 0.0:
        var = 0.0
    std = np.sqrt(var)
    middle[window - 1] = mean
    upper[window - 1] = mean + num_std * std
    lower[window - 1] = mean - num_std * std

    for i in range(window, n):
        add_v = arr[i]
        rem_v = arr[i - window]
        run_sum += add_v - rem_v
        run_sq += add_v * add_v - rem_v * rem_v
        mean = run_sum / window
        var = (run_sq - window * mean * mean) / window
        if var < 0.0:
            var = 0.0
        std = np.sqrt(var)
        middle[i] = mean
        upper[i] = mean + num_std * std
        lower[i] = mean - num_std * std
    return upper, middle, lower


@njit(cache=True)
def _variance_kernel_impl(arr: np.ndarray, window: int, ddof: int) -> np.ndarray:  # pragma: no cover
    n = arr.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        out[i] = np.nan

    if window <= 0 or ddof < 0 or ddof >= window or n < window:
        return out

    csum = np.empty(n, dtype=np.float64)
    csum2 = np.empty(n, dtype=np.float64)
    run_sum = 0.0
    run_sum2 = 0.0
    for i in range(n):
        run_sum += arr[i]
        run_sum2 += arr[i] * arr[i]
        csum[i] = run_sum
        csum2[i] = run_sum2

    denom = window - ddof
    for i in range(window - 1, n):
        left = i - window
        if left >= 0:
            sum_x = csum[i] - csum[left]
            sum_x2 = csum2[i] - csum2[left]
        else:
            sum_x = csum[i]
            sum_x2 = csum2[i]

        mean = sum_x / window
        var = (sum_x2 - window * mean * mean) / denom
        if var < 0.0:
            var = 0.0
        out[i] = var
    return out


@njit(cache=True)
def _cumsum_kernel_impl(arr: np.ndarray) -> np.ndarray:  # pragma: no cover
    n = arr.shape[0]
    out = np.empty(n, dtype=np.float64)
    run = 0.0
    for i in range(n):
        run += arr[i]
        out[i] = run
    return out


@njit(cache=True)
def _rsi_kernel_impl(arr: np.ndarray, window: int) -> np.ndarray:  # pragma: no cover
    n = arr.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        out[i] = np.nan
    if n <= window:
        return out

    gain_sum = 0.0
    loss_sum = 0.0
    for i in range(1, window + 1):
        d = arr[i] - arr[i - 1]
        if d > 0.0:
            gain_sum += d
        elif d < 0.0:
            loss_sum += -d

    avg_gain = gain_sum / window
    avg_loss = loss_sum / window
    if avg_loss == 0.0:
        out[window] = 100.0
    else:
        rs = avg_gain / avg_loss
        out[window] = 100.0 - (100.0 / (1.0 + rs))

    for i in range(window + 1, n):
        d = arr[i] - arr[i - 1]
        gain = d if d > 0.0 else 0.0
        loss = -d if d < 0.0 else 0.0
        avg_gain = ((avg_gain * (window - 1)) + gain) / window
        avg_loss = ((avg_loss * (window - 1)) + loss) / window
        if avg_loss == 0.0:
            out[i] = 100.0
        else:
            rs = avg_gain / avg_loss
            out[i] = 100.0 - (100.0 / (1.0 + rs))
    return out


@njit(cache=True)
def _rolling_min_kernel_impl(arr: np.ndarray, window: int) -> np.ndarray:  # pragma: no cover
    n = arr.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        out[i] = np.nan
    if window <= 0 or n < window:
        return out

    dq = np.empty(n, dtype=np.int64)
    head = 0
    tail = 0
    for i in range(n):
        while head < tail and dq[head] <= i - window:
            head += 1
        while head < tail and arr[dq[tail - 1]] >= arr[i]:
            tail -= 1
        dq[tail] = i
        tail += 1
        if i >= window - 1:
            out[i] = arr[dq[head]]
    return out


@njit(cache=True)
def _rolling_max_kernel_impl(arr: np.ndarray, window: int) -> np.ndarray:  # pragma: no cover
    n = arr.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        out[i] = np.nan
    if window <= 0 or n < window:
        return out

    dq = np.empty(n, dtype=np.int64)
    head = 0
    tail = 0
    for i in range(n):
        while head < tail and dq[head] <= i - window:
            head += 1
        while head < tail and arr[dq[tail - 1]] <= arr[i]:
            tail -= 1
        dq[tail] = i
        tail += 1
        if i >= window - 1:
            out[i] = arr[dq[head]]
    return out


@njit(cache=True)
def _rolling_mean_kernel_impl(arr: np.ndarray, window: int) -> np.ndarray:  # pragma: no cover
    n = arr.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        out[i] = np.nan
    if window <= 0 or n < window:
        return out

    run = 0.0
    for i in range(window):
        run += arr[i]
    out[window - 1] = run / window

    for i in range(window, n):
        run += arr[i] - arr[i - window]
        out[i] = run / window
    return out


@njit(cache=True)
def _atr_kernel_impl(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    window: int,
) -> np.ndarray:  # pragma: no cover
    n = close.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        out[i] = np.nan
    if window <= 0 or n <= window:
        return out

    tr_sum = 0.0
    for i in range(1, window + 1):
        a = high[i] - low[i]
        b = abs(high[i] - close[i - 1])
        c = abs(low[i] - close[i - 1])
        tr = a
        if b > tr:
            tr = b
        if c > tr:
            tr = c
        tr_sum += tr

    prev = tr_sum / window
    out[window] = prev

    for i in range(window + 1, n):
        a = high[i] - low[i]
        b = abs(high[i] - close[i - 1])
        c = abs(low[i] - close[i - 1])
        tr = a
        if b > tr:
            tr = b
        if c > tr:
            tr = c
        prev = ((prev * (window - 1)) + tr) / window
        out[i] = prev
    return out


@njit(cache=True, fastmath=True)
def _stochastic_kernel_impl(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    k_window: int,
    d_window: int,
) -> tuple[np.ndarray, np.ndarray]:  # pragma: no cover
    n = close.shape[0]
    fast_k = np.empty(n, dtype=np.float64)
    slow_k = np.empty(n, dtype=np.float64)
    slow_d = np.empty(n, dtype=np.float64)
    for i in range(n):
        fast_k[i] = np.nan
        slow_k[i] = np.nan
        slow_d[i] = np.nan

    if k_window <= 0 or d_window <= 0 or n < k_window:
        return slow_k, slow_d

    # rolling min/max with monotonic queues
    min_dq = np.empty(n, dtype=np.int64)
    min_h = 0
    min_t = 0
    max_dq = np.empty(n, dtype=np.int64)
    max_h = 0
    max_t = 0

    for i in range(n):
        while min_h < min_t and min_dq[min_h] <= i - k_window:
            min_h += 1
        while min_h < min_t and low[min_dq[min_t - 1]] >= low[i]:
            min_t -= 1
        min_dq[min_t] = i
        min_t += 1

        while max_h < max_t and max_dq[max_h] <= i - k_window:
            max_h += 1
        while max_h < max_t and high[max_dq[max_t - 1]] <= high[i]:
            max_t -= 1
        max_dq[max_t] = i
        max_t += 1

        if i >= k_window - 1:
            ll = low[min_dq[min_h]]
            hh = high[max_dq[max_h]]
            den = hh - ll
            if den != 0.0:
                fast_k[i] = ((close[i] - ll) / den) * 100.0

    # TA-Lib-like STOCH defaults: slowk = SMA(fastk, d_window), slowd = SMA(slowk, d_window)
    fast_sum = 0.0
    fast_count = 0
    start = k_window - 1
    for i in range(start, n):
        v = fast_k[i]
        if v == v:
            fast_sum += v
            fast_count += 1
        if i >= start + d_window:
            old_v = fast_k[i - d_window]
            if old_v == old_v:
                fast_sum -= old_v
                fast_count -= 1
        if i >= d_window - 1 and fast_count == d_window:
            slow_k[i] = fast_sum / d_window

    slow_sum = 0.0
    slow_count = 0
    start2 = start + d_window - 1
    for i in range(start2, n):
        v = slow_k[i]
        if v == v:
            slow_sum += v
            slow_count += 1
        if i >= start2 + d_window:
            old_v = slow_k[i - d_window]
            if old_v == old_v:
                slow_sum -= old_v
                slow_count -= 1
        if i >= d_window - 1 and slow_count == d_window:
            slow_d[i] = slow_sum / d_window

    return slow_k, slow_d


@njit(cache=True, fastmath=True)
def _stochastic_14_3_kernel_impl(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:  # pragma: no cover
    n = close.shape[0]
    slow_k = np.empty(n, dtype=np.float64)
    slow_d = np.empty(n, dtype=np.float64)
    for i in range(n):
        slow_k[i] = np.nan
        slow_d[i] = np.nan

    if n < 14:
        return slow_k, slow_d

    min_dq = np.empty(n, dtype=np.int64)
    min_h = 0
    min_t = 0
    max_dq = np.empty(n, dtype=np.int64)
    max_h = 0
    max_t = 0

    fk_m1 = np.nan
    fk_m2 = np.nan
    sk_m1 = np.nan
    sk_m2 = np.nan

    for i in range(n):
        while min_h < min_t and min_dq[min_h] <= i - 14:
            min_h += 1
        while min_h < min_t and low[min_dq[min_t - 1]] >= low[i]:
            min_t -= 1
        min_dq[min_t] = i
        min_t += 1

        while max_h < max_t and max_dq[max_h] <= i - 14:
            max_h += 1
        while max_h < max_t and high[max_dq[max_t - 1]] <= high[i]:
            max_t -= 1
        max_dq[max_t] = i
        max_t += 1

        if i >= 13:
            ll = low[min_dq[min_h]]
            hh = high[max_dq[max_h]]
            den = hh - ll
            fk = np.nan
            if den != 0.0:
                fk = ((close[i] - ll) / den) * 100.0

            if i >= 15:
                sk = (fk + fk_m1 + fk_m2) / 3.0
                slow_k[i] = sk
                if i >= 17:
                    slow_d[i] = (sk + sk_m1 + sk_m2) / 3.0
                sk_m2 = sk_m1
                sk_m1 = sk

            fk_m2 = fk_m1
            fk_m1 = fk

    return slow_k, slow_d


@njit(cache=True, fastmath=True)
def _stochastic_14_3_finite_kernel_impl(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:  # pragma: no cover
    n = close.shape[0]
    slow_k = np.empty(n, dtype=np.float64)
    slow_d = np.empty(n, dtype=np.float64)
    for i in range(n):
        slow_k[i] = np.nan
        slow_d[i] = np.nan

    if n < 14:
        return slow_k, slow_d

    min_dq = np.empty(n, dtype=np.int64)
    min_h = 0
    min_t = 0
    max_dq = np.empty(n, dtype=np.int64)
    max_h = 0
    max_t = 0

    fk_m1 = 0.0
    fk_m2 = 0.0
    sk_m1 = 0.0
    sk_m2 = 0.0

    for i in range(n):
        while min_h < min_t and min_dq[min_h] <= i - 14:
            min_h += 1
        while min_h < min_t and low[min_dq[min_t - 1]] >= low[i]:
            min_t -= 1
        min_dq[min_t] = i
        min_t += 1

        while max_h < max_t and max_dq[max_h] <= i - 14:
            max_h += 1
        while max_h < max_t and high[max_dq[max_t - 1]] <= high[i]:
            max_t -= 1
        max_dq[max_t] = i
        max_t += 1

        if i >= 13:
            ll = low[min_dq[min_h]]
            hh = high[max_dq[max_h]]
            den = hh - ll
            fk = 0.0
            if den != 0.0:
                fk = ((close[i] - ll) / den) * 100.0

            if i >= 15:
                sk = (fk + fk_m1 + fk_m2) / 3.0
                slow_k[i] = sk
                if i >= 17:
                    slow_d[i] = (sk + sk_m1 + sk_m2) / 3.0
                sk_m2 = sk_m1
                sk_m1 = sk

            fk_m2 = fk_m1
            fk_m1 = fk

    return slow_k, slow_d


@njit(cache=True)
def _cci_kernel_impl(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    window: int,
) -> np.ndarray:  # pragma: no cover
    n = close.shape[0]
    out = np.empty(n, dtype=np.float64)
    tp = np.empty(n, dtype=np.float64)
    for i in range(n):
        out[i] = np.nan
        tp[i] = (high[i] + low[i] + close[i]) / 3.0

    if window <= 0 or n < window:
        return out

    run = 0.0
    for i in range(window):
        run += tp[i]

    for i in range(window - 1, n):
        if i >= window:
            run += tp[i] - tp[i - window]
        mean = run / window

        mad = 0.0
        start = i - window + 1
        for j in range(start, i + 1):
            d = tp[j] - mean
            mad += abs(d)
        mad /= window

        if mad != 0.0:
            out[i] = (tp[i] - mean) / (0.015 * mad)
    return out


@njit(cache=True)
def _obv_kernel_impl(close: np.ndarray, volume: np.ndarray) -> np.ndarray:  # pragma: no cover
    n = close.shape[0]
    out = np.empty(n, dtype=np.float64)
    if n == 0:
        return out
    out[0] = volume[0]
    for i in range(1, n):
        if close[i] > close[i - 1]:
            out[i] = out[i - 1] + volume[i]
        elif close[i] < close[i - 1]:
            out[i] = out[i - 1] - volume[i]
        else:
            out[i] = out[i - 1]
    return out


@njit(cache=True)
def _vwap_kernel_impl(price: np.ndarray, volume: np.ndarray) -> np.ndarray:  # pragma: no cover
    n = price.shape[0]
    out = np.empty(n, dtype=np.float64)
    run_pv = 0.0
    run_v = 0.0
    for i in range(n):
        run_pv += price[i] * volume[i]
        run_v += volume[i]
        if run_v != 0.0:
            out[i] = run_pv / run_v
        else:
            out[i] = np.nan
    return out


def ema_kernel(arr: np.ndarray, alpha: float) -> np.ndarray:
    """Compute EMA kernel output."""
    if not 0.0 < alpha <= 1.0:
        raise ValueError("alpha must satisfy 0 < alpha <= 1")
    arr64 = np.ascontiguousarray(arr, dtype=np.float64)
    return _ema_kernel_impl(arr64, float(alpha))


def typical_price_kernel(high: np.ndarray, low: np.ndarray, close: np.ndarray) -> np.ndarray:
    """Compute Typical Price kernel output."""
    h64 = np.ascontiguousarray(high, dtype=np.float64)
    l64 = np.ascontiguousarray(low, dtype=np.float64)
    c64 = np.ascontiguousarray(close, dtype=np.float64)
    return _typical_price_kernel_impl(h64, l64, c64)


def median_price_kernel(high: np.ndarray, low: np.ndarray) -> np.ndarray:
    """Compute Median Price kernel output."""
    h64 = np.ascontiguousarray(high, dtype=np.float64)
    l64 = np.ascontiguousarray(low, dtype=np.float64)
    return _median_price_kernel_impl(h64, l64)


def weighted_close_kernel(high: np.ndarray, low: np.ndarray, close: np.ndarray) -> np.ndarray:
    """Compute Weighted Close kernel output."""
    h64 = np.ascontiguousarray(high, dtype=np.float64)
    l64 = np.ascontiguousarray(low, dtype=np.float64)
    c64 = np.ascontiguousarray(close, dtype=np.float64)
    return _weighted_close_kernel_impl(h64, l64, c64)


def wma_kernel(arr: np.ndarray, window: int) -> np.ndarray:
    """Compute WMA kernel output."""
    arr64 = np.ascontiguousarray(arr, dtype=np.float64)
    return _wma_kernel_impl(arr64, int(window))


def stddev_kernel(arr: np.ndarray, window: int, ddof: int = 0) -> np.ndarray:
    """Compute rolling stddev kernel output."""
    arr64 = np.ascontiguousarray(arr, dtype=np.float64)
    return _stddev_kernel_impl(arr64, int(window), int(ddof))


def bbands_kernel(arr: np.ndarray, window: int, num_std: float = 2.0) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute Bollinger Bands kernel output."""
    arr64 = np.ascontiguousarray(arr, dtype=np.float64)
    return _bbands_kernel_impl(arr64, int(window), float(num_std))


def variance_kernel(arr: np.ndarray, window: int, ddof: int = 0) -> np.ndarray:
    """Compute rolling variance kernel output."""
    arr64 = np.ascontiguousarray(arr, dtype=np.float64)
    return _variance_kernel_impl(arr64, int(window), int(ddof))


def cumsum_kernel(arr: np.ndarray) -> np.ndarray:
    """Compute cumulative sum kernel output."""
    arr64 = np.ascontiguousarray(arr, dtype=np.float64)
    return _cumsum_kernel_impl(arr64)


def rsi_kernel(arr: np.ndarray, window: int) -> np.ndarray:
    """Compute RSI kernel output."""
    arr64 = np.ascontiguousarray(arr, dtype=np.float64)
    return _rsi_kernel_impl(arr64, int(window))


def rolling_min_kernel(arr: np.ndarray, window: int) -> np.ndarray:
    """Compute rolling minimum kernel output."""
    arr64 = np.ascontiguousarray(arr, dtype=np.float64)
    return _rolling_min_kernel_impl(arr64, int(window))


def rolling_max_kernel(arr: np.ndarray, window: int) -> np.ndarray:
    """Compute rolling maximum kernel output."""
    arr64 = np.ascontiguousarray(arr, dtype=np.float64)
    return _rolling_max_kernel_impl(arr64, int(window))


def rolling_mean_kernel(arr: np.ndarray, window: int) -> np.ndarray:
    """Compute rolling mean kernel output."""
    arr64 = np.ascontiguousarray(arr, dtype=np.float64)
    return _rolling_mean_kernel_impl(arr64, int(window))


def atr_kernel(high: np.ndarray, low: np.ndarray, close: np.ndarray, window: int) -> np.ndarray:
    """Compute ATR kernel output."""
    h64 = np.ascontiguousarray(high, dtype=np.float64)
    l64 = np.ascontiguousarray(low, dtype=np.float64)
    c64 = np.ascontiguousarray(close, dtype=np.float64)
    return _atr_kernel_impl(h64, l64, c64, int(window))


def stochastic_kernel(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    k_window: int,
    d_window: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute Stochastic (slow K and slow D) kernel output."""
    h64 = np.ascontiguousarray(high, dtype=np.float64)
    l64 = np.ascontiguousarray(low, dtype=np.float64)
    c64 = np.ascontiguousarray(close, dtype=np.float64)
    if int(k_window) == 14 and int(d_window) == 3:
        if np.isfinite(h64).all() and np.isfinite(l64).all() and np.isfinite(c64).all():
            return _stochastic_14_3_finite_kernel_impl(h64, l64, c64)
        return _stochastic_14_3_kernel_impl(h64, l64, c64)
    return _stochastic_kernel_impl(h64, l64, c64, int(k_window), int(d_window))


def cci_kernel(high: np.ndarray, low: np.ndarray, close: np.ndarray, window: int) -> np.ndarray:
    """Compute CCI kernel output."""
    h64 = np.ascontiguousarray(high, dtype=np.float64)
    l64 = np.ascontiguousarray(low, dtype=np.float64)
    c64 = np.ascontiguousarray(close, dtype=np.float64)
    return _cci_kernel_impl(h64, l64, c64, int(window))


def obv_kernel(close: np.ndarray, volume: np.ndarray) -> np.ndarray:
    """Compute OBV kernel output."""
    c64 = np.ascontiguousarray(close, dtype=np.float64)
    v64 = np.ascontiguousarray(volume, dtype=np.float64)
    return _obv_kernel_impl(c64, v64)


def vwap_kernel(price: np.ndarray, volume: np.ndarray) -> np.ndarray:
    """Compute VWAP kernel output."""
    p64 = np.ascontiguousarray(price, dtype=np.float64)
    v64 = np.ascontiguousarray(volume, dtype=np.float64)
    return _vwap_kernel_impl(p64, v64)
