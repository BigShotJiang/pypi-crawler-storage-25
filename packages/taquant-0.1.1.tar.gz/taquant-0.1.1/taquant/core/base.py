"""Base abstraction for indicator execution flow."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import numpy as np

from .multisymbol import apply_by_symbol
from .utils import make_output_name, to_float64_array
from .validation import TAQuantParameterError, TAQuantValidationError, validate_dataframe_schema, validate_params


def apply_indicator(
    df: Any,
    func: Callable[..., Any],
    column: str,
    output_name: str | None = None,
    inplace: bool = False,
    symbol_col: str | None = None,
    **params: Any,
) -> Any:
    """Apply indicator function with shared TAQuant pipeline."""
    validate_dataframe_schema(df)
    if not isinstance(column, str) or not column:
        raise TAQuantParameterError("Column name must be a non-empty string.")
    if column not in df.columns:
        raise TAQuantValidationError(f"Column '{column}' does not exist in DataFrame.")
    validate_params(**params)

    if symbol_col is not None:
        return apply_by_symbol(
            df,
            symbol_col,
            apply_indicator,
            func,
            column,
            output_name,
            inplace,
            None,
            **params,
        )

    arr = to_float64_array(df[column])
    computed = func(arr, **params)

    result_df = df if inplace else df.copy(deep=False)
    out_name = make_output_name(func.__name__, output_name=output_name, **params)

    if isinstance(computed, np.ndarray):
        if computed.shape[0] != len(result_df):
            raise ValueError(
                f"Indicator output length mismatch: expected {len(result_df)}, got {computed.shape[0]}."
            )
        values_arr = computed
        if values_arr.dtype != np.float64 or not values_arr.flags.c_contiguous:
            values_arr = np.ascontiguousarray(values_arr, dtype=np.float64)
        result_df[out_name] = values_arr
        return result_df

    if isinstance(computed, dict):
        for suffix, values in computed.items():
            values_arr = values
            if not isinstance(values_arr, np.ndarray) or values_arr.dtype != np.float64 or not values_arr.flags.c_contiguous:
                values_arr = np.ascontiguousarray(values_arr, dtype=np.float64)
            if values_arr.shape[0] != len(result_df):
                raise ValueError(
                    f"Indicator output length mismatch for '{suffix}': expected {len(result_df)}, got {values_arr.shape[0]}."
                )
            col_name = f"{out_name}_{suffix}" if suffix else out_name
            result_df[col_name] = values_arr
        return result_df

    raise TypeError("Indicator compute function must return np.ndarray or dict[str, np.ndarray].")
