"""Multi-symbol orchestration helpers."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pandas as pd

from .validation import TAQuantParameterError, validate_column, validate_dataframe_schema


def apply_by_symbol(
    df: Any,
    group_col: str,
    indicator_fn: Callable[..., Any],
    *args: Any,
    validate_input: bool = True,
    **kwargs: Any,
) -> Any:
    """Apply an indicator function independently per symbol while preserving row order."""
    if validate_input:
        validate_dataframe_schema(df)
        validate_column(df, group_col)

    if not isinstance(df, pd.DataFrame):
        raise TAQuantParameterError("apply_by_symbol requires a pandas.DataFrame input.")

    pieces: list[pd.DataFrame] = []
    for _, group in df.groupby(group_col, sort=False):
        group_view = group.copy(deep=False)
        out_group = indicator_fn(group_view, *args, **kwargs)
        if not isinstance(out_group, pd.DataFrame):
            raise TAQuantParameterError("indicator_fn must return a pandas.DataFrame.")
        pieces.append(out_group)

    if not pieces:
        return df.copy(deep=False)

    merged = pd.concat(pieces, axis=0).sort_index(kind="stable")
    return merged
