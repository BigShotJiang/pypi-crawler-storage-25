"""Validation utilities for TAQuant inputs and parameters."""

from __future__ import annotations

from collections.abc import Iterable
from numbers import Real
from typing import Any

import numpy as np
import pandas as pd


class TAQuantValidationError(ValueError):
    """Raised when input data does not meet TAQuant requirements."""


class TAQuantParameterError(ValueError):
    """Raised when indicator parameters are invalid."""


def validate_dataframe_schema(df: Any, required_columns: Iterable[str] | None = None) -> None:
    """Validate DataFrame object and optional required columns."""
    if not isinstance(df, pd.DataFrame):
        raise TAQuantValidationError("Input must be a pandas.DataFrame.")

    if df.empty:
        raise TAQuantValidationError("Input DataFrame must not be empty.")

    if required_columns is None:
        return

    missing = [col for col in required_columns if col not in df.columns]
    if missing:
        raise TAQuantValidationError(f"Missing required columns: {missing}")


def validate_column(df: Any, column: str) -> None:
    """Validate that a column exists in DataFrame."""
    if not isinstance(column, str) or not column:
        raise TAQuantParameterError("Column name must be a non-empty string.")

    if not isinstance(df, pd.DataFrame):
        raise TAQuantValidationError("Input must be a pandas.DataFrame.")
    if df.empty:
        raise TAQuantValidationError("Input DataFrame must not be empty.")
    if column not in df.columns:
        raise TAQuantValidationError(f"Column '{column}' does not exist in DataFrame.")


def validate_window(window: int) -> None:
    """Validate moving-window parameter."""
    if isinstance(window, bool) or not isinstance(window, int):
        raise TAQuantParameterError("Window must be an integer greater than 0.")
    if window <= 0:
        raise TAQuantParameterError("Window must be greater than 0.")


def validate_params(**params: Any) -> None:
    """Validate generic scalar params used by indicators."""
    for key, value in params.items():
        if key == "window":
            validate_window(value)
            continue
        if value is None:
            continue
        if isinstance(value, bool):
            continue
        if isinstance(value, Real):
            continue
        if isinstance(value, str):
            continue
        if isinstance(value, np.ndarray):
            continue
        if isinstance(value, (tuple, list)):
            continue
        raise TAQuantParameterError(
            f"Parameter '{key}' has unsupported type {type(value).__name__}."
        )
