"""Rolling helper functions for compute kernels."""

from __future__ import annotations

from collections import deque

import numpy as np


def rolling_mean(arr: np.ndarray, window: int) -> np.ndarray:
    """Compute rolling mean in O(n)."""
    if window <= 0:
        raise ValueError("window must be > 0")
    n = arr.size
    out = np.full(n, np.nan, dtype=np.float64)
    if n < window:
        return out

    if np.isfinite(arr).all():
        csum = np.cumsum(arr, dtype=np.float64)
        out[window - 1] = csum[window - 1] / window
        out[window:] = (csum[window:] - csum[:-window]) / window
        return out

    valid = np.isfinite(arr)
    safe = np.where(valid, arr, 0.0)
    csum = np.cumsum(safe, dtype=np.float64)
    ccount = np.cumsum(valid.astype(np.int64))

    sums = np.empty(n - window + 1, dtype=np.float64)
    counts = np.empty(n - window + 1, dtype=np.int64)
    sums[0] = csum[window - 1]
    counts[0] = ccount[window - 1]
    if n - window >= 1:
        sums[1:] = csum[window:] - csum[:-window]
        counts[1:] = ccount[window:] - ccount[:-window]

    valid_window = counts == window
    out_vals = np.full(n - window + 1, np.nan, dtype=np.float64)
    out_vals[valid_window] = sums[valid_window] / window
    out[window - 1 :] = out_vals
    return out


def rolling_std(arr: np.ndarray, window: int, ddof: int = 0) -> np.ndarray:
    """Compute rolling standard deviation in O(n)."""
    if window <= 0:
        raise ValueError("window must be > 0")
    if ddof < 0 or ddof >= window:
        raise ValueError("ddof must satisfy 0 <= ddof < window")
    n = arr.size
    out = np.full(n, np.nan, dtype=np.float64)
    if n < window:
        return out

    csum = np.cumsum(arr, dtype=np.float64)
    csum2 = np.cumsum(arr * arr, dtype=np.float64)

    sum_x = np.empty(n - window + 1, dtype=np.float64)
    sum_x2 = np.empty(n - window + 1, dtype=np.float64)
    sum_x[0] = csum[window - 1]
    sum_x2[0] = csum2[window - 1]
    if n - window >= 1:
        sum_x[1:] = csum[window:] - csum[:-window]
        sum_x2[1:] = csum2[window:] - csum2[:-window]

    mean = sum_x / window
    var = (sum_x2 - window * mean * mean) / (window - ddof)
    var = np.maximum(var, 0.0)
    out[window - 1 :] = np.sqrt(var)
    return out


def rolling_min(arr: np.ndarray, window: int) -> np.ndarray:
    """Compute rolling minimum in O(n) using a monotonic deque."""
    if window <= 0:
        raise ValueError("window must be > 0")
    n = arr.size
    out = np.full(n, np.nan, dtype=np.float64)
    dq: deque[int] = deque()

    for i in range(n):
        while dq and dq[0] <= i - window:
            dq.popleft()
        while dq and arr[dq[-1]] >= arr[i]:
            dq.pop()
        dq.append(i)
        if i >= window - 1:
            out[i] = arr[dq[0]]
    return out


def rolling_max(arr: np.ndarray, window: int) -> np.ndarray:
    """Compute rolling maximum in O(n) using a monotonic deque."""
    if window <= 0:
        raise ValueError("window must be > 0")
    n = arr.size
    out = np.full(n, np.nan, dtype=np.float64)
    dq: deque[int] = deque()

    for i in range(n):
        while dq and dq[0] <= i - window:
            dq.popleft()
        while dq and arr[dq[-1]] <= arr[i]:
            dq.pop()
        dq.append(i)
        if i >= window - 1:
            out[i] = arr[dq[0]]
    return out
