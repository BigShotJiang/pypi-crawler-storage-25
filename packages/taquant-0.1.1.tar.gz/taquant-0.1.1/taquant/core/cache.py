"""Cache utilities for dependency-aware indicator reuse."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class CacheKey:
    """Cache key contract for indicator intermediate results."""

    indicator: str
    column: str
    window: int | None
    params_hash: str
    data_id: int | str
    start_idx: int
    end_idx: int
    dtype: str
    shape: tuple[int, ...]


class IndicatorCache:
    """In-memory indicator cache with selective invalidation."""

    def __init__(self) -> None:
        self._store: dict[CacheKey, Any] = {}
        self._hits = 0
        self._misses = 0

    def get(self, key: CacheKey) -> Any:
        """Retrieve cached value by key."""
        if key in self._store:
            self._hits += 1
            return self._store[key]
        self._misses += 1
        return None

    def set(self, key: CacheKey, value: Any) -> None:
        """Set cached value by key."""
        self._store[key] = value

    def invalidate(
        self,
        data_id: int | str | None = None,
        indicator: str | None = None,
        column: str | None = None,
    ) -> None:
        """Invalidate cache entries by selector."""
        if data_id is None and indicator is None and column is None:
            self._store.clear()
            return

        to_delete = []
        for key in self._store:
            if data_id is not None and key.data_id != data_id:
                continue
            if indicator is not None and key.indicator != indicator:
                continue
            if column is not None and key.column != column:
                continue
            to_delete.append(key)

        for key in to_delete:
            del self._store[key]

    def clear(self) -> None:
        """Clear all cache entries."""
        self._store.clear()
        self._hits = 0
        self._misses = 0

    def __len__(self) -> int:
        """Return number of cache entries."""
        return len(self._store)

    @property
    def hits(self) -> int:
        """Return cache hit count."""
        return self._hits

    @property
    def misses(self) -> int:
        """Return cache miss count."""
        return self._misses

    @property
    def hit_rate(self) -> float:
        """Return cache hit rate in [0, 1]."""
        total = self._hits + self._misses
        if total == 0:
            return 0.0
        return self._hits / total


def make_params_hash(params: Mapping[str, Any]) -> str:
    """Build deterministic O(1) parameter hash from primitive params.

    The function assumes values are primitive/scalar (or tuples/lists of primitives)
    and intentionally avoids any array content hashing.
    """

    items: list[str] = []
    for key in sorted(params.keys()):
        value = params[key]
        if isinstance(value, list):
            value = tuple(value)
        items.append(f"{key}={value!r}")
    return "|".join(items)
