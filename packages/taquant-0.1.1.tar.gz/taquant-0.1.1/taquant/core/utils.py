"""Utility helpers for data conversion and output naming."""

from __future__ import annotations

from typing import Any

import numpy as np


def to_float64_array(series_like: Any) -> np.ndarray:
    """Convert a series-like object to contiguous float64 ndarray."""
    if isinstance(series_like, np.ndarray):
        arr = series_like
    elif hasattr(series_like, "to_numpy"):
        arr = series_like.to_numpy(copy=False)
    else:
        arr = np.asarray(series_like)

    if arr.ndim != 1:
        raise ValueError("Input series must be one-dimensional.")
    if not np.issubdtype(arr.dtype, np.floating):
        arr = arr.astype(np.float64, copy=False)
    elif arr.dtype != np.float64:
        arr = arr.astype(np.float64, copy=False)
    return np.ascontiguousarray(arr, dtype=np.float64)


def make_output_name(indicator: str, output_name: str | None = None, **params: Any) -> str:
    """Create standardized output column name."""
    if output_name:
        return output_name

    suffix = []
    for key in ("window", "fast_window", "slow_window", "signal_window", "num_std"):
        if key not in params:
            continue
        value = params[key]
        if isinstance(value, float) and value.is_integer():
            value = int(value)
        suffix.append(str(value))

    base = indicator.lower()
    return "_".join([base, *suffix]) if suffix else base
