"""Volume Weighted Average Price indicator."""

from __future__ import annotations

from typing import Any

from taquant.core.numba_funcs import vwap_kernel
from taquant.core.utils import make_output_name, to_float64_array
from taquant.core.validation import validate_column, validate_dataframe_schema


def vwap(
    df: Any,
    price_col: str = "Close",
    volume_col: str = "Volume",
    output_name: str | None = None,
    inplace: bool = False,
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    """Compute VWAP."""
    if not fast_mode:
        validate_dataframe_schema(df)
        validate_column(df, price_col)
        validate_column(df, volume_col)

    result_df = df if inplace else df.copy(deep=False)

    if symbol_col is not None:
        from taquant.core.multisymbol import apply_by_symbol

        return apply_by_symbol(
            result_df,
            symbol_col,
            vwap,
            price_col=price_col,
            volume_col=volume_col,
            output_name=output_name,
            inplace=True,
            symbol_col=None,
            fast_mode=fast_mode,
            validate_input=not fast_mode,
        )

    price = to_float64_array(result_df[price_col])
    volume = to_float64_array(result_df[volume_col])

    out = vwap_kernel(price, volume)

    name = make_output_name("vwap", output_name=output_name)
    result_df[name] = out
    return result_df
