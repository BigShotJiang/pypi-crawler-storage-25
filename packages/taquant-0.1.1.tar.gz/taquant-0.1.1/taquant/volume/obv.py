"""On-Balance Volume indicator."""

from __future__ import annotations

from typing import Any

from taquant.core.numba_funcs import obv_kernel
from taquant.core.utils import make_output_name, to_float64_array
from taquant.core.validation import validate_column, validate_dataframe_schema


def obv(
    df: Any,
    close_col: str = "Close",
    volume_col: str = "Volume",
    output_name: str | None = None,
    inplace: bool = False,
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    """Compute On-Balance Volume."""
    if not fast_mode:
        validate_dataframe_schema(df)
        validate_column(df, close_col)
        validate_column(df, volume_col)

    result_df = df if inplace else df.copy(deep=False)

    if symbol_col is not None:
        from taquant.core.multisymbol import apply_by_symbol

        return apply_by_symbol(
            result_df,
            symbol_col,
            obv,
            close_col=close_col,
            volume_col=volume_col,
            output_name=output_name,
            inplace=True,
            symbol_col=None,
            fast_mode=fast_mode,
            validate_input=not fast_mode,
        )

    close = to_float64_array(result_df[close_col])
    vol = to_float64_array(result_df[volume_col])

    out = obv_kernel(close, vol)

    name = make_output_name("obv", output_name=output_name)
    result_df[name] = out
    return result_df
