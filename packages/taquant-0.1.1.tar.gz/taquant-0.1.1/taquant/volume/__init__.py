"""Volume indicators (Series/ndarray-oriented public API)."""

from __future__ import annotations

from typing import Any

from taquant import array_api as fa

from .obv import obv as _obv_df
from .volume_ma import volume_ma as _volume_ma_df
from .vwap import vwap as _vwap_df


def volume_ma(
    df: Any,
    window: int,
    column: str = "Volume",
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    if symbol_col is not None:
        name = "__volume_ma__"
        out = _volume_ma_df(df, window=window, column=column, output_name=name, inplace=False, symbol_col=symbol_col, fast_mode=fast_mode)
        return out[name]
    return fa.volume_ma_array(df[column], window=window)


def obv(
    df: Any,
    close_col: str = "Close",
    volume_col: str = "Volume",
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    if symbol_col is not None:
        name = "__obv__"
        out = _obv_df(
            df,
            close_col=close_col,
            volume_col=volume_col,
            output_name=name,
            inplace=False,
            symbol_col=symbol_col,
            fast_mode=fast_mode,
        )
        return out[name]
    return fa.obv_array(df[close_col], df[volume_col])


def vwap(
    df: Any,
    price_col: str = "Close",
    volume_col: str = "Volume",
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    if symbol_col is not None:
        name = "__vwap__"
        out = _vwap_df(
            df,
            price_col=price_col,
            volume_col=volume_col,
            output_name=name,
            inplace=False,
            symbol_col=symbol_col,
            fast_mode=fast_mode,
        )
        return out[name]
    return fa.vwap_array(df[price_col], df[volume_col])


__all__ = ["volume_ma", "obv", "vwap"]
