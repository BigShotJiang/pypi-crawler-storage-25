"""Volatility indicators (Series/ndarray-oriented public API)."""

from __future__ import annotations

from typing import Any, Tuple

from taquant import array_api as fa

from .atr import atr as _atr_df
from .bollinger_bands import bollinger_bands as _bb_df
from .stddev import stddev as _stddev_df


def stddev(
    df: Any,
    window: int,
    column: str = "Close",
    ddof: int = 0,
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    if symbol_col is not None:
        name = "__stddev__"
        out = _stddev_df(
            df,
            window=window,
            column=column,
            ddof=ddof,
            output_name=name,
            inplace=False,
            symbol_col=symbol_col,
            fast_mode=fast_mode,
        )
        return out[name]
    return fa.stddev_array(df[column], window=window, ddof=ddof)


def atr(
    df: Any,
    window: int = 14,
    high_col: str = "High",
    low_col: str = "Low",
    close_col: str = "Close",
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    if symbol_col is not None:
        name = "__atr__"
        out = _atr_df(
            df,
            window=window,
            high_col=high_col,
            low_col=low_col,
            close_col=close_col,
            output_name=name,
            inplace=False,
            symbol_col=symbol_col,
            fast_mode=fast_mode,
        )
        return out[name]
    return fa.atr_array(df[high_col], df[low_col], df[close_col], window=window)


def bollinger_bands(
    df: Any,
    window: int = 20,
    num_std: float = 2.0,
    column: str = "Close",
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Tuple[Any, Any, Any]:
    if symbol_col is not None:
        base = "__bb__"
        out = _bb_df(
            df,
            window=window,
            num_std=num_std,
            column=column,
            output_name=base,
            inplace=False,
            symbol_col=symbol_col,
            fast_mode=fast_mode,
        )
        return out[f"{base}_upper"], out[f"{base}_middle"], out[f"{base}_lower"]
    return fa.bollinger_bands_array(df[column], window=window, num_std=num_std)


__all__ = ["stddev", "atr", "bollinger_bands"]
