"""Bollinger Bands indicator."""

from __future__ import annotations

from typing import Any

import numpy as np

from taquant.core.cache import CacheKey, IndicatorCache, make_params_hash
from taquant.core.numba_funcs import bbands_kernel, variance_kernel
from taquant.core.rolling import rolling_mean
from taquant.core.utils import make_output_name, to_float64_array
from taquant.core.validation import validate_column, validate_dataframe_schema, validate_window

_CACHE = IndicatorCache()


def bollinger_bands(
    df: Any,
    window: int = 20,
    num_std: float = 2.0,
    column: str = "Close",
    output_name: str | None = None,
    inplace: bool = False,
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    """Compute Bollinger Bands (upper, middle, lower)."""
    if not fast_mode:
        validate_dataframe_schema(df)
        validate_column(df, column)
        validate_window(window)

    source_df = df
    result_df = df if inplace else df.copy(deep=False)

    if symbol_col is not None:
        from taquant.core.multisymbol import apply_by_symbol

        return apply_by_symbol(
            result_df,
            symbol_col,
            bollinger_bands,
            window=window,
            num_std=num_std,
            column=column,
            output_name=output_name,
            inplace=True,
            symbol_col=None,
            fast_mode=fast_mode,
            validate_input=not fast_mode,
        )

    arr = to_float64_array(result_df[column])
    key = CacheKey(
        indicator="bollinger_bands",
        column=column,
        window=window,
        params_hash=make_params_hash({"window": window, "num_std": num_std}),
        data_id=id(source_df),
        start_idx=0,
        end_idx=arr.shape[0],
        dtype=str(arr.dtype),
        shape=arr.shape,
    )

    cached = _CACHE.get(key)
    if cached is None:
        if np.isfinite(arr).all():
            upper, mid, lower = bbands_kernel(arr, window=window, num_std=num_std)
        else:
            mid = rolling_mean(arr, window)
            std = np.sqrt(variance_kernel(arr, window=window, ddof=0))
            upper = mid + num_std * std
            lower = mid - num_std * std
        cached = (upper, mid, lower)
        _CACHE.set(key, cached)

    upper, mid, lower = cached
    base = make_output_name("bb", output_name=output_name, window=window, num_std=num_std)
    result_df[f"{base}_upper"] = upper
    result_df[f"{base}_middle"] = mid
    result_df[f"{base}_lower"] = lower
    return result_df
