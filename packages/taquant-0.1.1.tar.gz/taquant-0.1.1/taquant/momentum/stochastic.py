"""Stochastic Oscillator indicator."""

from __future__ import annotations

from typing import Any

from taquant.core.numba_funcs import stochastic_kernel
from taquant.core.utils import make_output_name, to_float64_array
from taquant.core.validation import validate_column, validate_dataframe_schema, validate_window


def stochastic(
    df: Any,
    k_window: int = 14,
    d_window: int = 3,
    high_col: str = "High",
    low_col: str = "Low",
    close_col: str = "Close",
    output_name: str | None = None,
    inplace: bool = False,
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    """Compute Stochastic oscillator values."""
    if not fast_mode:
        validate_dataframe_schema(df)
        validate_column(df, high_col)
        validate_column(df, low_col)
        validate_column(df, close_col)
        validate_window(k_window)
        validate_window(d_window)

    result_df = df if inplace else df.copy(deep=False)

    if symbol_col is not None:
        from taquant.core.multisymbol import apply_by_symbol

        return apply_by_symbol(
            result_df,
            symbol_col,
            stochastic,
            k_window=k_window,
            d_window=d_window,
            high_col=high_col,
            low_col=low_col,
            close_col=close_col,
            output_name=output_name,
            inplace=True,
            symbol_col=None,
            fast_mode=fast_mode,
            validate_input=not fast_mode,
        )

    high = to_float64_array(result_df[high_col])
    low = to_float64_array(result_df[low_col])
    close = to_float64_array(result_df[close_col])

    k, d = stochastic_kernel(high, low, close, k_window=k_window, d_window=d_window)

    base = make_output_name("stoch", output_name=output_name, window=k_window)
    result_df[f"{base}_k"] = k
    result_df[f"{base}_d"] = d
    return result_df
