"""Momentum indicators (Series/ndarray-oriented public API)."""

from __future__ import annotations

from typing import Any, Tuple

from taquant import array_api as fa
from taquant.core.numba_funcs import stochastic_kernel
from taquant.core.utils import to_float64_array

from .cci import cci as _cci_df
from .rsi import rsi as _rsi_df
from .stochastic import stochastic as _stoch_df


def rsi(
    df: Any,
    window: int = 14,
    column: str = "Close",
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    if symbol_col is not None:
        name = "__rsi__"
        out = _rsi_df(df, window=window, column=column, output_name=name, inplace=False, symbol_col=symbol_col, fast_mode=fast_mode)
        return out[name]
    return fa.rsi_array(df[column], window=window)


def stochastic(
    df: Any,
    k_window: int = 14,
    d_window: int = 3,
    high_col: str = "High",
    low_col: str = "Low",
    close_col: str = "Close",
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Tuple[Any, Any]:
    if symbol_col is not None:
        base = "__stoch__"
        out = _stoch_df(
            df,
            k_window=k_window,
            d_window=d_window,
            high_col=high_col,
            low_col=low_col,
            close_col=close_col,
            output_name=base,
            inplace=False,
            symbol_col=symbol_col,
            fast_mode=fast_mode,
        )
        return out[f"{base}_k"], out[f"{base}_d"]
    high = to_float64_array(df[high_col])
    low = to_float64_array(df[low_col])
    close = to_float64_array(df[close_col])
    return stochastic_kernel(high, low, close, k_window=int(k_window), d_window=int(d_window))


def cci(
    df: Any,
    window: int = 20,
    high_col: str = "High",
    low_col: str = "Low",
    close_col: str = "Close",
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    if symbol_col is not None:
        name = "__cci__"
        out = _cci_df(
            df,
            window=window,
            high_col=high_col,
            low_col=low_col,
            close_col=close_col,
            output_name=name,
            inplace=False,
            symbol_col=symbol_col,
            fast_mode=fast_mode,
        )
        return out[name]
    return fa.cci_array(df[high_col], df[low_col], df[close_col], window=window)


__all__ = ["rsi", "stochastic", "cci"]
