"""Stateful EMA for realtime updates."""

from __future__ import annotations


class EMAState:
    """Realtime EMA state container."""

    def __init__(self, window: int) -> None:
        if window <= 0:
            raise ValueError("window must be > 0")
        self.window = int(window)
        self.alpha = 2.0 / (self.window + 1.0)
        self.value: float | None = None

    def update(self, price: float) -> float:
        """Update state with a new price tick and return current EMA."""
        p = float(price)
        if self.value is None:
            self.value = p
        else:
            self.value = self.alpha * p + (1.0 - self.alpha) * self.value
        return self.value
