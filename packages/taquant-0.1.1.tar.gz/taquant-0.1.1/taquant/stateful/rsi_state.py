"""Stateful RSI for realtime updates."""

from __future__ import annotations


class RSIState:
    """Realtime RSI state container."""

    def __init__(self, window: int = 14) -> None:
        if window <= 0:
            raise ValueError("window must be > 0")
        self.window = int(window)
        self.prev_price: float | None = None
        self.avg_gain: float = 0.0
        self.avg_loss: float = 0.0
        self.value: float | None = None
        self._seed_count = 0
        self._gain_sum = 0.0
        self._loss_sum = 0.0

    def update(self, price: float) -> float:
        """Update state with a new price tick and return current RSI."""
        p = float(price)
        if self.prev_price is None:
            self.prev_price = p
            self.value = 50.0
            return self.value

        delta = p - self.prev_price
        gain = delta if delta > 0.0 else 0.0
        loss = -delta if delta < 0.0 else 0.0

        if self._seed_count < self.window:
            self._gain_sum += gain
            self._loss_sum += loss
            self._seed_count += 1
            self.avg_gain = self._gain_sum / self.window
            self.avg_loss = self._loss_sum / self.window
        else:
            self.avg_gain = ((self.avg_gain * (self.window - 1)) + gain) / self.window
            self.avg_loss = ((self.avg_loss * (self.window - 1)) + loss) / self.window

        if self.avg_loss == 0.0:
            self.value = 100.0
        else:
            rs = self.avg_gain / self.avg_loss
            self.value = 100.0 - (100.0 / (1.0 + rs))

        self.prev_price = p
        return self.value
