"""Trend indicators (Series/ndarray-oriented public API)."""

from __future__ import annotations

from typing import Any, Tuple

from taquant import array_api as fa

from .ema import ema as _ema_df
from .macd import macd as _macd_df
from .sma import sma as _sma_df
from .wma import wma as _wma_df


def sma(
    df: Any,
    window: int,
    column: str = "Close",
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    if symbol_col is not None:
        name = "__sma__"
        out = _sma_df(df, window=window, column=column, output_name=name, inplace=False, symbol_col=symbol_col, fast_mode=fast_mode)
        return out[name]
    return fa.sma_array(df[column], window=window)


def ema(
    df: Any,
    window: int,
    column: str = "Close",
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    if symbol_col is not None:
        name = "__ema__"
        out = _ema_df(df, window=window, column=column, output_name=name, inplace=False, symbol_col=symbol_col, fast_mode=fast_mode)
        return out[name]
    return fa.ema_array(df[column], window=window)


def wma(
    df: Any,
    window: int,
    column: str = "Close",
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    if symbol_col is not None:
        name = "__wma__"
        out = _wma_df(df, window=window, column=column, output_name=name, inplace=False, symbol_col=symbol_col, fast_mode=fast_mode)
        return out[name]
    return fa.wma_array(df[column], window=window)


def macd(
    df: Any,
    fast_window: int = 12,
    slow_window: int = 26,
    signal_window: int = 9,
    column: str = "Close",
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Tuple[Any, Any, Any]:
    if symbol_col is not None:
        base = "__macd__"
        out = _macd_df(
            df,
            fast_window=fast_window,
            slow_window=slow_window,
            signal_window=signal_window,
            column=column,
            output_name=base,
            inplace=False,
            symbol_col=symbol_col,
            fast_mode=fast_mode,
        )
        return out[f"{base}_line"], out[f"{base}_signal"], out[f"{base}_hist"]
    return fa.macd_array(df[column], fast_window=fast_window, slow_window=slow_window, signal_window=signal_window)


__all__ = ["sma", "ema", "wma", "macd"]
