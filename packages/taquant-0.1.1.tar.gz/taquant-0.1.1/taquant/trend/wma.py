"""Weighted Moving Average indicator."""

from __future__ import annotations

from typing import Any

import numpy as np

from taquant.core.multisymbol import apply_by_symbol
from taquant.core.numba_funcs import wma_kernel
from taquant.core.utils import make_output_name, to_float64_array
from taquant.core.validation import validate_column, validate_dataframe_schema, validate_window


def _wma_compute(arr: np.ndarray, window: int) -> np.ndarray:
    return wma_kernel(arr, window=window)


def wma(
    df: Any,
    window: int,
    column: str = "Close",
    output_name: str | None = None,
    inplace: bool = False,
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    """Compute WMA for a given column and window."""
    if not fast_mode:
        validate_dataframe_schema(df)
        validate_column(df, column)
        validate_window(window)

    result_df = df if inplace else df.copy(deep=False)
    if symbol_col is not None:
        return apply_by_symbol(
            result_df,
            symbol_col,
            wma,
            window=window,
            column=column,
            output_name=output_name,
            inplace=True,
            symbol_col=None,
            fast_mode=fast_mode,
            validate_input=not fast_mode,
        )

    arr = to_float64_array(result_df[column])
    result_df[make_output_name("wma", output_name=output_name, window=window)] = _wma_compute(arr, window)
    return result_df
