"""Simple Moving Average indicator."""

from __future__ import annotations

from typing import Any

import numpy as np

from taquant.core.multisymbol import apply_by_symbol
from taquant.core.rolling import rolling_mean
from taquant.core.utils import make_output_name, to_float64_array
from taquant.core.validation import validate_column, validate_dataframe_schema, validate_window


def _sma_compute(arr: np.ndarray, window: int) -> np.ndarray:
    return rolling_mean(arr, window)


def sma(
    df: Any,
    window: int,
    column: str = "Close",
    output_name: str | None = None,
    inplace: bool = False,
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    """Compute SMA for a given column and window."""
    if not fast_mode:
        validate_dataframe_schema(df)
        validate_column(df, column)
        validate_window(window)

    result_df = df if inplace else df.copy(deep=False)
    if symbol_col is not None:
        return apply_by_symbol(
            result_df,
            symbol_col,
            sma,
            window=window,
            column=column,
            output_name=output_name,
            inplace=True,
            symbol_col=None,
            fast_mode=fast_mode,
            validate_input=not fast_mode,
        )

    arr = to_float64_array(result_df[column])
    result_df[make_output_name("sma", output_name=output_name, window=window)] = _sma_compute(arr, window)
    return result_df
