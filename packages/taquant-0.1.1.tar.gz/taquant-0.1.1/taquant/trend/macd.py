"""MACD indicator."""

from __future__ import annotations

from typing import Any

import numpy as np

from taquant.core.cache import CacheKey, IndicatorCache, make_params_hash
from taquant.core.numba_funcs import ema_kernel
from taquant.core.utils import make_output_name, to_float64_array
from taquant.core.validation import validate_column, validate_dataframe_schema, validate_window

_CACHE = IndicatorCache()


def _macd_arrays(arr: np.ndarray, fast_window: int, slow_window: int, signal_window: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    alpha_fast = 2.0 / (fast_window + 1.0)
    alpha_slow = 2.0 / (slow_window + 1.0)
    alpha_signal = 2.0 / (signal_window + 1.0)

    ema_fast = ema_kernel(arr, alpha=alpha_fast)
    ema_slow = ema_kernel(arr, alpha=alpha_slow)
    macd_line = ema_fast - ema_slow
    signal = ema_kernel(macd_line, alpha=alpha_signal)
    hist = macd_line - signal
    return macd_line, signal, hist


def macd(
    df: Any,
    fast_window: int = 12,
    slow_window: int = 26,
    signal_window: int = 9,
    column: str = "Close",
    output_name: str | None = None,
    inplace: bool = False,
    symbol_col: str | None = None,
    fast_mode: bool = False,
) -> Any:
    """Compute MACD line, signal, and histogram outputs."""
    if not fast_mode:
        validate_dataframe_schema(df)
        validate_column(df, column)
        validate_window(fast_window)
        validate_window(slow_window)
        validate_window(signal_window)
        if fast_window >= slow_window:
            raise ValueError("fast_window must be smaller than slow_window.")

    source_df = df
    result_df = df if inplace else df.copy(deep=False)

    if symbol_col is not None:
        from taquant.core.multisymbol import apply_by_symbol

        return apply_by_symbol(
            result_df,
            symbol_col,
            macd,
            fast_window=fast_window,
            slow_window=slow_window,
            signal_window=signal_window,
            column=column,
            output_name=output_name,
            inplace=True,
            symbol_col=None,
            fast_mode=fast_mode,
            validate_input=not fast_mode,
        )

    arr = to_float64_array(result_df[column])
    params_hash = make_params_hash(
        {
            "fast_window": fast_window,
            "slow_window": slow_window,
            "signal_window": signal_window,
        }
    )
    key = CacheKey(
        indicator="macd",
        column=column,
        window=slow_window,
        params_hash=params_hash,
        data_id=id(source_df),
        start_idx=0,
        end_idx=arr.shape[0],
        dtype=str(arr.dtype),
        shape=arr.shape,
    )

    cached = _CACHE.get(key)
    if cached is None:
        cached = _macd_arrays(arr, fast_window, slow_window, signal_window)
        _CACHE.set(key, cached)

    macd_line, signal, hist = cached
    base = make_output_name(
        "macd",
        output_name=output_name,
        fast_window=fast_window,
        slow_window=slow_window,
        signal_window=signal_window,
    )
    result_df[f"{base}_line"] = macd_line
    result_df[f"{base}_signal"] = signal
    result_df[f"{base}_hist"] = hist
    return result_df
