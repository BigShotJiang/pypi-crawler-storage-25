"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: wait_for_seconds.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
from raccoon.step.wait_for_seconds import WaitForSeconds
import typing
__all__: list = ['WaitForSecondsBuilder', 'wait_for_seconds']
class WaitForSecondsBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for WaitForSeconds. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def seconds(self, value: float | int):
        ...
def wait_for_seconds(seconds: float | int = ...):
    """
    
    Pause execution for a fixed number of seconds.
    
    Suspends the current step sequence for the specified duration using
    an async sleep. No hardware commands are issued during the wait, and
    other concurrent tasks (e.g. odometry updates) continue running
    normally. The wait duration is deterministic and is reflected
    accurately in simulation estimates.
    
    Args:
        seconds: Duration to pause in seconds. Must be non-negative. Passing 0 yields control to the event loop for one tick without any meaningful delay.
    
    Returns:
        A WaitForSecondsBuilder (chainable via ``.seconds()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step import wait
    
        # Pause between two motor commands
        sequence(
            motor_power(robot.motor(0), 100),
            wait(2.5),
            motor_brake(robot.motor(0)),
        )
    
        # Brief yield to let sensors settle
        wait(0.1)
    """
_UNSET: object  # value = <object object>
