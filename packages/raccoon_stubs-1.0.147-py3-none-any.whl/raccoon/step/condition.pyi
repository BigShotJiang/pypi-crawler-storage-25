"""
Composable stop conditions for motion steps.

A StopCondition determines when a motion step should terminate. Conditions
can be combined with ``|`` (any/or), ``&`` (all/and), ``>`` / ``+``
(then/sequence) operators.

Example::

    from raccoon.step.condition import on_black, on_white, after_seconds, after_cm, over_line

    # Stop when sensor sees black OR after 10 seconds
    drive_forward(speed=1.0).until(on_black(sensor) | after_seconds(10))

    # Sequential: first wait for black, then travel 10 more cm
    # Use + instead of > to avoid Python's chained-comparison gotcha
    drive_forward(speed=1.0).until(on_black(sensor) + after_cm(10))

    # Cross a line (black then white) three times
    drive_forward(speed=1.0).until(over_line(sensor) + over_line(sensor) + over_line(sensor))
"""
from __future__ import annotations
import math as math
import time as time
import typing
__all__: list[str] = ['StopCondition', 'after_cm', 'after_degrees', 'after_forward_cm', 'after_lateral_cm', 'after_seconds', 'custom', 'math', 'on_analog_above', 'on_analog_below', 'on_black', 'on_digital', 'on_white', 'over_line', 'stall_detected', 'time']
class StopCondition:
    """
    Base class for composable stop conditions.
    """
    def __add__(self, other: 'StopCondition') -> 'StopCondition':
        """
        Chain conditions (alias for ``>``): ``a + b + c``.
        
        Unlike ``>``, the ``+`` operator does not suffer from Python's
        chained-comparison rewrite, so parentheses are never required.
        """
    def __and__(self, other: 'StopCondition') -> 'StopCondition':
        """
        Combine conditions: stop when BOTH are true.
        """
    def __bool__(self) -> bool:
        ...
    def __gt__(self, other: 'StopCondition') -> 'StopCondition':
        """
        Chain conditions: once *self* triggers, start checking *other*.
        """
    def __or__(self, other: 'StopCondition') -> 'StopCondition':
        """
        Combine conditions: stop when EITHER triggers.
        """
    def check(self, robot: 'GenericRobot') -> bool:
        """
        Return True to stop the motion. Called each update cycle.
        """
    def start(self, robot: 'GenericRobot') -> None:
        """
        Called once when the motion step starts. Override to initialize state.
        """
class _AllOf(StopCondition):
    """
    Stop when all sub-conditions are true (AND).
    """
    def __init__(self, *conditions: StopCondition):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
    def start(self, robot: 'GenericRobot') -> None:
        ...
class _AnyOf(StopCondition):
    """
    Stop when any sub-condition triggers (OR).
    """
    def __init__(self, *conditions: StopCondition):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
    def start(self, robot: 'GenericRobot') -> None:
        ...
class _AxisDisplacementCondition(StopCondition):
    """
    Shared base: signed displacement along an axis fixed at ``start()``.
    
    In **relative** mode (default), ``start()`` snapshots the robot's
    world-frame pose *and* heading. Each ``check()`` then projects the
    displacement-since-snapshot onto that snapshot heading — so
    "forward"/"lateral" always mean forward/lateral *from where and how
    the robot was pointing when this condition began*, regardless of any
    turning that happens afterwards.
    
    In **absolute** mode, the condition reads
    ``get_distance_from_origin().forward / .lateral`` directly — axes
    fixed to the odometry origin heading (last ``reset()``).
    """
    _axis_name: typing.ClassVar[str] = ''
    def __init__(self, cm: float, *, absolute: bool = False):
        ...
    def _absolute_component(self, robot: 'GenericRobot') -> float:
        ...
    def _displacement_m(self, robot: 'GenericRobot') -> float:
        ...
    def _project(self, dx: float, dy: float) -> float:
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
    def start(self, robot: 'GenericRobot') -> None:
        ...
class _Then(StopCondition):
    """
    Sequential chain: once *first* triggers, start and check *second*.
    
    Supports chaining: ``a > b > c`` means wait for *a*, then *b*, then *c*.
    """
    def __init__(self, first: StopCondition, second: StopCondition):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
    def start(self, robot: 'GenericRobot') -> None:
        ...
class after_cm(StopCondition):
    """
    Stop after traveling a distance (uses odometry path length).
    
    By default operates in relative mode: the distance is measured from
    the robot's position when the condition starts.  In absolute mode
    (``absolute=True``) the distance is measured from the odometry origin
    (last ``reset()``), so centimeters traveled *before* the condition
    started also count.
    
    Uses the cumulative path length (odometer) so it works correctly
    regardless of travel direction (forward, strafe, curved paths).
    """
    def __init__(self, cm: float, *, absolute: bool = False):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
    def start(self, robot: 'GenericRobot') -> None:
        ...
class after_degrees(StopCondition):
    """
    Stop after turning a given angle (degrees).
    
    Uses the absolute IMU heading so it is unaffected by odometry resets.
    Tracks total unsigned rotation — works regardless of turn direction.
    """
    def __init__(self, degrees: float):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
    def start(self, robot: 'GenericRobot') -> None:
        ...
class after_forward_cm(_AxisDisplacementCondition):
    """
    Stop after traveling a forward/backward displacement.
    
    Unlike :class:`after_cm` (which uses cumulative path length), this
    measures the *signed forward component* of displacement relative to
    the robot's heading at the moment this condition started. Any
    turning that happens *after* ``start()`` does not rotate the axis —
    it stays pinned to the original heading.
    
    A positive ``cm`` triggers after the robot has moved that far
    forward of its baseline pose; a negative ``cm`` triggers after
    moving that far backward.
    
    In absolute mode (``absolute=True``) the displacement is read
    directly from ``get_distance_from_origin().forward`` — i.e. measured
    from the odometry origin, projected onto the origin heading.
    """
    def _absolute_component(self, robot: 'GenericRobot') -> float:
        ...
    def _project(self, dx: float, dy: float) -> float:
        ...
class after_lateral_cm(_AxisDisplacementCondition):
    """
    Stop after traveling a lateral (sideways) displacement.
    
    Measures the *signed lateral component* of displacement relative to
    the robot's heading at the moment this condition started. Sign
    convention matches ``DistanceFromOrigin.lateral``: positive values
    point along the +lateral axis as defined there.
    
    Only meaningful on drivetrains that support lateral motion (e.g.
    mecanum / omni). On a differential drive this will stay near zero
    unless the robot rotates and then drives forward — in which case
    the world-frame displacement has a component sideways of the
    original heading.
    
    In absolute mode (``absolute=True``) the displacement is read
    directly from ``get_distance_from_origin().lateral``.
    """
    def _absolute_component(self, robot: 'GenericRobot') -> float:
        ...
    def _project(self, dx: float, dy: float) -> float:
        ...
class after_seconds(StopCondition):
    """
    Stop after a fixed duration.
    """
    def __init__(self, seconds: float):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
    def start(self, robot: 'GenericRobot') -> None:
        ...
class custom(StopCondition):
    """
    Stop based on a user-provided callable.
    
    The callable receives the robot and returns True to stop::
    
        custom(lambda robot: robot.et_sensor.value() < 15)
    """
    def __init__(self, fn: typing.Callable[['GenericRobot'], bool]):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
class on_analog_above(StopCondition):
    """
    Stop when an analog sensor reading exceeds a threshold.
    """
    def __init__(self, sensor: 'AnalogSensor', threshold: int):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
class on_analog_below(StopCondition):
    """
    Stop when an analog sensor reading drops below a threshold.
    """
    def __init__(self, sensor: 'AnalogSensor', threshold: int):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
class on_black(StopCondition):
    """
    Stop when an IR sensor detects a black surface.
    """
    def __init__(self, sensor: 'IRSensor', threshold: float = 0.7):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
class on_digital(StopCondition):
    """
    Stop when a digital sensor reads a given state.
    
    By default stops when the sensor reads True (pressed). Set *pressed*
    to False to stop when the sensor is released instead.
    """
    def __init__(self, sensor: 'DigitalSensor', pressed: bool = True):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
class on_white(StopCondition):
    """
    Stop when an IR sensor detects a white surface.
    """
    def __init__(self, sensor: 'IRSensor', threshold: float = 0.7):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
class stall_detected(StopCondition):
    """
    Stop when a motor appears stalled.
    
    A motor is considered stalled when its position changes by fewer than
    *threshold_tps* ticks per second for at least *duration* seconds
    continuously.
    """
    def __init__(self, motor: 'Motor', threshold_tps: int = 10, duration: float = 0.25):
        ...
    def check(self, robot: 'GenericRobot') -> bool:
        ...
    def start(self, robot: 'GenericRobot') -> None:
        ...
def over_line(sensor: 'IRSensor', black_threshold: float = 0.7, white_threshold: float = 0.7) -> StopCondition:
    """
    Stop after crossing a line (black then white).
    
    Equivalent to ``on_black(sensor) > on_white(sensor)`` — waits for
    the sensor to see black, then waits for it to see white again.
    
    Args:
        sensor: IR sensor to monitor.
        black_threshold: Probability threshold for the black phase.
        white_threshold: Probability threshold for the white phase.
    """
