"""
Background step manager — tracks running background tasks and handles preemption.

When a foreground step requires a resource held by a background step, the
background step is cancelled (preempted) with a warning instead of raising
``ResourceConflictError``.  The manager also logs when background steps
complete, fail, or get cancelled.
"""
from __future__ import annotations
import asyncio as asyncio
import dataclasses
from dataclasses import dataclass
import logging as logging
from raccoon.step.resource import _resources_overlap
import typing
__all__: list[str] = ['BackgroundManager', 'asyncio', 'dataclass', 'get_background_manager', 'logger', 'logging']
class BackgroundManager:
    """
    Track background step tasks and handle resource preemption.
    
    Attached to the robot instance as ``robot._background_manager``.
    """
    def __init__(self) -> None:
        ...
    def _on_done(self, task: asyncio.Task[None]) -> None:
        ...
    def cancel_all(self) -> None:
        """
        Cancel all running background tasks and await cleanup.
        
        Called at mission boundaries and during shutdown to prevent
        orphaned tasks from leaking or triggering asyncio warnings.
        """
    def preempt_conflicts(self, resources: frozenset[str], holder_label: str) -> None:
        """
        Cancel background tasks whose resources overlap with *resources*.
        
        After cancellation, awaits cleanup so released resources are
        available for immediate acquisition.
        """
    def register(self, task: asyncio.Task[None], label: str, name: str | None, resources: frozenset[str]) -> None:
        """
        Register a background task for tracking and preemption.
        """
    def wait_all(self) -> None:
        """
        Wait for all running background tasks to complete.
        """
    def wait_for_name(self, name: str) -> None:
        """
        Wait for a specific named background task to complete.
        """
    @property
    def active_count(self) -> int:
        """
        Number of background tasks still running.
        """
class _BGEntry:
    """
    _BGEntry(task: 'asyncio.Task[None]', label: 'str', name: 'Optional[str]', resources: 'frozenset[str]')
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'task': Field(name='task',type='asyncio.Task[None]',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'label': Field(name='label',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'name': Field(name='name',type='Optional[str]',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'resources': Field(name='resources',type='frozenset[str]',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('task', 'label', 'name', 'resources')
    def __eq__(self, other):
        ...
    def __init__(self, task: asyncio.Task[None], label: str, name: str | None, resources: frozenset[str]) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
def get_background_manager(robot: typing.Any) -> BackgroundManager:
    """
    Get or create the ``BackgroundManager`` attached to *robot*.
    """
logger: logging.Logger  # value = <Logger raccoon.step.background_manager (INFO)>
