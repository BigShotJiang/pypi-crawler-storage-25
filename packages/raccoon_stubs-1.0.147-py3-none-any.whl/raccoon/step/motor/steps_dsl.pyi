"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: steps.py
"""
from __future__ import annotations
from raccoon.hal import IMotor
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
from raccoon.step.motor.steps import MotorBrake
from raccoon.step.motor.steps import MotorOff
from raccoon.step.motor.steps import MotorPassiveBrake
from raccoon.step.motor.steps import MoveMotorRelative
from raccoon.step.motor.steps import MoveMotorTo
from raccoon.step.motor.steps import SetMotorDps
from raccoon.step.motor.steps import SetMotorPower
from raccoon.step.motor.steps import SetMotorVelocity
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
import typing
__all__: list = ['SetMotorPowerBuilder', 'set_motor_power', 'SetMotorVelocityBuilder', 'set_motor_velocity', 'SetMotorDpsBuilder', 'set_motor_dps', 'MoveMotorToBuilder', 'move_motor_to', 'MoveMotorRelativeBuilder', 'move_motor_relative', 'MotorOffBuilder', 'motor_off', 'MotorPassiveBrakeBuilder', 'motor_passive_brake', 'MotorBrakeBuilder', 'motor_brake']
class MotorBrakeBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for MotorBrake. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def motor(self, value: IMotor):
        ...
class MotorOffBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for MotorOff. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def motor(self, value: IMotor):
        ...
class MotorPassiveBrakeBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for MotorPassiveBrake. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def motor(self, value: IMotor):
        ...
class MoveMotorRelativeBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for MoveMotorRelative. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def delta(self, value: int):
        ...
    def motor(self, value: IMotor):
        ...
    def timeout(self, value: float | None):
        ...
    def velocity(self, value: int):
        ...
class MoveMotorToBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for MoveMotorTo. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def motor(self, value: IMotor):
        ...
    def position(self, value: int):
        ...
    def timeout(self, value: float | None):
        ...
    def velocity(self, value: int):
        ...
class SetMotorDpsBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for SetMotorDps. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def dps(self, value: float):
        ...
    def motor(self, value: IMotor):
        ...
class SetMotorPowerBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for SetMotorPower. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def motor(self, value: IMotor):
        ...
    def percent(self, value: int):
        ...
class SetMotorVelocityBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for SetMotorVelocity. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def motor(self, value: IMotor):
        ...
    def velocity(self, value: int):
        ...
def motor_brake(motor: IMotor = ...):
    """
    
    Actively brake a motor and hold its current position.
    
    Engages the firmware's active brake (stop latch), which commands the
    motor controller to resist any external force and maintain the
    current shaft position. This is the strongest stop mode and is
    appropriate when the mechanism must not move (e.g. holding an arm
    up against gravity).
    
    Args:
        motor: The motor to brake, obtained from the robot hardware map (e.g. ``robot.motor(2)``).
    
    Returns:
        A MotorBrakeBuilder (chainable via ``.motor()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motor import motor_move_to, motor_brake
    
        # Move the arm to a target, then lock it in place
        sequence(
            motor_move_to(robot.motor(2), position=400),
            motor_brake(robot.motor(2)),
        )
    """
def motor_off(motor: IMotor = ...):
    """
    
    Turn a motor off, allowing it to coast freely.
    
    Removes all power from the motor so it spins down under friction
    alone. The motor shaft is not held in place and can be back-driven.
    Use this when you want the mechanism to move freely (e.g. letting an
    arm fall under gravity).
    
    Args:
        motor: The motor to turn off, obtained from the robot hardware map (e.g. ``robot.motor(0)``).
    
    Returns:
        A MotorOffBuilder (chainable via ``.motor()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motor import motor_power, motor_off
    
        # Run a motor briefly, then let it coast to a stop
        sequence(
            motor_power(robot.motor(3), 80),
            wait(1.5),
            motor_off(robot.motor(3)),
        )
    """
def motor_passive_brake(motor: IMotor = ...):
    """
    
    Passively brake a motor by commanding zero power.
    
    Sets the motor power to zero, which causes the H-bridge to short the
    motor leads. This provides electrical braking that decelerates the
    motor faster than coasting (``motor_off``), but does not actively hold
    position once the motor stops.
    
    Args:
        motor: The motor to brake, obtained from the robot hardware map (e.g. ``robot.motor(0)``).
    
    Returns:
        A MotorPassiveBrakeBuilder (chainable via ``.motor()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motor import motor_velocity, motor_passive_brake
    
        # Drive forward then passively brake
        sequence(
            motor_velocity(robot.motor(0), 600),
            wait(2.0),
            motor_passive_brake(robot.motor(0)),
        )
    """
def move_motor_relative(motor: IMotor = ..., delta: int = ..., velocity: int = 1000, timeout: float | None = None):
    """
    
    Move a motor by a relative encoder delta and wait for completion.
    
    Commands the motor's firmware position controller to move by the given
    number of encoder ticks relative to its current position. The step
    blocks until the firmware reports the move is complete, or until the
    optional timeout expires.
    
    Args:
        motor: The motor to control, obtained from the robot hardware map (e.g. ``robot.motor(2)``).
        delta: Number of encoder ticks to move. Positive values move forward; negative values move in reverse.
        velocity: Movement speed in firmware ticks/s. Must be positive. Defaults to 1000.
        timeout: Maximum seconds to wait for the move to finish. ``None`` (the default) means wait indefinitely. If the timeout fires a warning is logged and the step returns without stopping the motor.
    
    Returns:
        A MoveMotorRelativeBuilder (chainable via ``.motor()``, ``.delta()``, ``.velocity()``, ``.timeout()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motor import motor_move_relative, motor_brake
    
        # Rotate the arm motor 200 ticks forward, then brake
        sequence(
            motor_move_relative(robot.motor(2), delta=200, velocity=600),
            motor_brake(robot.motor(2)),
        )
    """
def move_motor_to(motor: IMotor = ..., position: int = ..., velocity: int = 1000, timeout: float | None = None):
    """
    
    Move a motor to an absolute encoder position and wait for completion.
    
    Commands the motor's firmware position controller to drive to the given
    absolute encoder tick count. The step blocks (yielding to the async
    loop) until the firmware reports the move is complete, or until the
    optional timeout expires.
    
    Args:
        motor: The motor to control, obtained from the robot hardware map (e.g. ``robot.motor(2)``).
        position: Target position in absolute encoder ticks.
        velocity: Movement speed in firmware ticks/s. Must be positive. Defaults to 1000.
        timeout: Maximum seconds to wait for the move to finish. ``None`` (the default) means wait indefinitely. If the timeout fires a warning is logged and the step returns without stopping the motor.
    
    Returns:
        A MoveMotorToBuilder (chainable via ``.motor()``, ``.position()``, ``.velocity()``, ``.timeout()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motor import motor_move_to
    
        # Raise the arm to encoder position 500 at speed 800, with a 3s safety timeout
        motor_move_to(robot.motor(2), position=500, velocity=800, timeout=3.0)
    """
def set_motor_dps(motor: IMotor = ..., dps: float = ...):
    """
    
    Set a motor to closed-loop velocity in degrees per second.
    
    Converts the requested angular velocity from degrees per second into
    firmware BEMF units using the motor's calibration data, then engages
    the firmware's closed-loop velocity controller. The step completes
    immediately; the motor continues at the requested speed until changed.
    
    Prerequisites:
        The motor must have valid calibration data (``ticks_to_rad``) so
        the deg/s to BEMF conversion is accurate. Run the motor
        calibration step first if calibration has not been performed.
    
    Args:
        motor: The motor to control, obtained from the robot hardware map (e.g. ``robot.motor(0)``).
        dps: Target angular velocity in degrees per second. Positive values drive forward; negative values drive in reverse.
    
    Returns:
        A SetMotorDpsBuilder (chainable via ``.motor()``, ``.dps()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motor import motor_dps, motor_brake
    
        # Spin the left wheel at 180 deg/s for 2 seconds
        sequence(
            motor_dps(robot.motor(0), 180.0),
            wait(2.0),
            motor_brake(robot.motor(0)),
        )
    """
def set_motor_power(motor: IMotor = ..., percent: int = ...):
    """
    
    Set a motor to open-loop percent power.
    
    Commands the motor at a raw duty-cycle percentage without any feedback
    control. The command is applied immediately and the step completes
    without waiting -- the motor keeps spinning until another command
    (or a stop step) is issued.
    
    Args:
        motor: The motor to control, obtained from the robot hardware map (e.g. ``robot.motor(0)``).
        percent: Duty-cycle power from -100 (full reverse) to 100 (full forward). Values outside this range raise ``ValueError``.
    
    Returns:
        A SetMotorPowerBuilder (chainable via ``.motor()``, ``.percent()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motor import motor_power, motor_off
    
        # Spin the claw motor forward at half power for 2 seconds
        sequence(
            motor_power(robot.motor(1), 50),
            wait(2.0),
            motor_off(robot.motor(1)),
        )
    """
def set_motor_velocity(motor: IMotor = ..., velocity: int = ...):
    """
    
    Set a motor to closed-loop velocity in firmware BEMF units.
    
    Commands the motor's firmware PID controller to maintain a target
    velocity expressed in raw BEMF tick units. The step completes
    immediately; the motor continues at the requested speed until changed.
    
    For a human-friendly velocity interface, prefer ``motor_dps`` which
    accepts degrees per second.
    
    Args:
        motor: The motor to control, obtained from the robot hardware map (e.g. ``robot.motor(0)``).
        velocity: Target velocity in firmware BEMF units (ticks per BEMF sample period). Positive values drive forward; negative values drive in reverse.
    
    Returns:
        A SetMotorVelocityBuilder (chainable via ``.motor()``, ``.velocity()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motor import motor_velocity, motor_brake
    
        # Drive the left wheel at 800 BEMF units, then brake
        sequence(
            motor_velocity(robot.motor(0), 800),
            wait(3.0),
            motor_brake(robot.motor(0)),
        )
    """
_UNSET: object  # value = <object object>
