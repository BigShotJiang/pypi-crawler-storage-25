"""
Watchdog DSL steps — arm, feed, and disarm named keepalive watchdogs.

Watchdogs are registered with the robot's ``WatchdogManager`` and, on
expiry, cancel the main-mission task. This triggers the normal shutdown
path: background tasks drain, the shutdown mission runs, then the process
exits.

Feeding is between-step only. Long-running steps should not attempt to
feed from inside their own update loop — use ``timeout(...)`` for
per-step stall detection instead.

Example::

    from raccoon.step import seq, start_watchdog, feed_watchdog, stop_watchdog
    from raccoon.step.motion import drive_forward

    seq(
        start_watchdog("scoring", timeout=5.0),
        drive_forward(30),
        feed_watchdog("scoring"),
        drive_forward(30),
        stop_watchdog("scoring"),
    )
"""
from __future__ import annotations
import raccoon.step.annotation
from raccoon.step.annotation import dsl
import raccoon.step.base
from raccoon.step.base import Step
from raccoon.step.watchdog_manager import get_watchdog_manager
import typing
__all__: list[str] = ['DEFAULT_WATCHDOG_NAME', 'FeedWatchdog', 'StartWatchdog', 'Step', 'StopWatchdog', 'dsl', 'feed_watchdog', 'get_watchdog_manager', 'start_watchdog', 'stop_watchdog']
class FeedWatchdog(raccoon.step.base.Step):
    """
    Reset a named watchdog's deadline.
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'FeedWatchdog'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    def __init__(self, name: str) -> None:
        ...
    def _execute_step(self, robot: 'GenericRobot') -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class StartWatchdog(raccoon.step.base.Step):
    """
    Arm a named watchdog with a timeout.
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'StartWatchdog'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    def __init__(self, name: str, timeout: float | int) -> None:
        ...
    def _execute_step(self, robot: 'GenericRobot') -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class StopWatchdog(raccoon.step.base.Step):
    """
    Disarm and remove a named watchdog.
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'StopWatchdog'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    def __init__(self, name: str) -> None:
        ...
    def _execute_step(self, robot: 'GenericRobot') -> None:
        ...
    def _generate_signature(self) -> str:
        ...
def feed_watchdog(name: str = 'default') -> FeedWatchdog:
    """
    Reset a named watchdog's deadline to prevent expiry.
    
    Pushes the watchdog's deadline forward by its full timeout. Feeding an
    unarmed watchdog logs a warning but does not raise.
    
    Args:
        name: Identifier of the watchdog to feed. Defaults to ``"default"``.
    
    Returns:
        A FeedWatchdog step instance.
    
    Example::
    
        from raccoon.step import feed_watchdog
    
        feed_watchdog("scoring")
    """
def start_watchdog(name: str = 'default', timeout: float | int = 5.0) -> StartWatchdog:
    """
    Arm a named watchdog that will kill the robot if not fed in time.
    
    Registers a keepalive watchdog with the robot's ``WatchdogManager``. If
    the watchdog is not fed via ``feed_watchdog`` before ``timeout`` seconds
    elapse, it expires and cancels the main-mission task — the same code
    path used by the global ``shutdown_in`` timer. The shutdown mission
    still runs, so motors are hard-stopped and the robot parks safely.
    
    Multiple watchdogs can run simultaneously by using distinct names. The
    default name covers the common single-watchdog case.
    
    Args:
        name: Unique identifier for this watchdog. Used by ``feed_watchdog``
            and ``stop_watchdog`` to address it. Defaults to ``"default"``.
        timeout: Seconds between feeds before expiry. Must be positive.
    
    Returns:
        A StartWatchdog step instance.
    
    Example::
    
        from raccoon.step import seq, start_watchdog, feed_watchdog, stop_watchdog
        from raccoon.step.motion import drive_forward
    
        seq(
            start_watchdog("scoring", timeout=5.0),
            drive_forward(30),
            feed_watchdog("scoring"),
            drive_forward(30),
            stop_watchdog("scoring"),
        )
    """
def stop_watchdog(name: str = 'default') -> StopWatchdog:
    """
    Disarm a named watchdog so it no longer expires.
    
    Removes the watchdog from the manager. Stopping an unarmed watchdog
    logs a warning but does not raise — intended for cleanup paths where
    the watchdog may or may not still be active.
    
    Args:
        name: Identifier of the watchdog to disarm. Defaults to ``"default"``.
    
    Returns:
        A StopWatchdog step instance.
    
    Example::
    
        from raccoon.step import stop_watchdog
    
        stop_watchdog("scoring")
    """
DEFAULT_WATCHDOG_NAME: str = 'default'
