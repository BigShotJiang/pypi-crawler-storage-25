"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: wait_for_digital.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
from raccoon.step.wait_for_digital import WaitForDigital
__all__: list = ['WaitForDigitalBuilder', 'wait_for_digital']
class WaitForDigitalBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for WaitForDigital. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def pressed(self, value: bool):
        ...
    def sensor(self, value: 'DigitalSensor'):
        ...
def wait_for_digital(sensor: 'DigitalSensor' = ..., pressed: bool = True):
    """
    
    Block until a digital sensor reads the desired state.
    
    Polls the sensor at 50 Hz and resumes execution once the reading
    matches the expected value. Useful for waiting until a bumper is
    pressed, a limit switch is triggered, or an external signal arrives.
    
    Args:
        sensor: The DigitalSensor instance to poll.
        pressed: The target state to wait for. ``True`` (default) waits until the sensor reads high; ``False`` waits until it reads low.
    
    Returns:
        A WaitForDigitalBuilder (chainable via ``.sensor()``, ``.pressed()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step import wait_for_digital
        from raccoon.hal import DigitalSensor
    
        bumper = DigitalSensor(0)
    
        # Wait until bumper is pressed
        wait_for_digital(bumper)
    
        # Wait until bumper is released
        wait_for_digital(bumper, pressed=False)
    """
_UNSET: object  # value = <object object>
