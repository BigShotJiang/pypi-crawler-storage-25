from __future__ import annotations
import asyncio as asyncio
from asyncio.exceptions import CancelledError
import raccoon.step.annotation
from raccoon.step.annotation import dsl_step
import raccoon.step.base
from raccoon.step.base import Step
from raccoon.step.resource import validate_no_overlap
import typing
from typing import Any
__all__: list[str] = ['Any', 'CancelledError', 'DoWhileActive', 'Step', 'asyncio', 'dsl_step', 'validate_no_overlap']
class DoWhileActive(raccoon.step.base.Step):
    """
    Run a task concurrently with a reference step, cancelling the task when the reference finishes.
    
    Both steps start executing at the same time. When ``reference_step``
    completes (either normally or via exception), ``task`` is immediately
    cancelled. This is useful for running a background activity (e.g.
    sensor polling, motor oscillation) only for as long as a primary
    action is running.
    
    If ``task`` finishes before ``reference_step``, the reference step
    continues running until it completes on its own.
    
    Args:
        reference_step: The primary step whose lifetime controls the task.
            When this step finishes, ``task`` is cancelled.
        task: The secondary step that runs concurrently and is cancelled
            once ``reference_step`` completes.
    
    Example::
    
        from raccoon.step.logic import do_while_active, loop_forever
    
        # Flash an LED while the robot drives forward
        flash_led = loop_forever(seq([
            set_digital(0, True),
            wait(0.25),
            set_digital(0, False),
            wait(0.25),
        ]))
        do_while_active(drive_forward(50), flash_led)
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='DoWhileActive', tags=('control', 'concurrent'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'DoWhileActive'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('control', 'concurrent')
    __dsl_tags__: typing.ClassVar[tuple] = ('control', 'concurrent')
    _composite: typing.ClassVar[bool] = True
    def __init__(self, reference_step: raccoon.step.base.Step, task: raccoon.step.base.Step) -> None:
        ...
    def _execute_step(self, robot: GenericRobot) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
    def collected_resources(self) -> frozenset[str]:
        ...
