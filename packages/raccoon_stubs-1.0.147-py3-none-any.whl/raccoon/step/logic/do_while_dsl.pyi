"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: do_while.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.base import Step
from raccoon.step.condition import StopCondition
from raccoon.step.logic.do_while import DoWhileActive
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
__all__: list = ['DoWhileActiveBuilder', 'do_while_active']
class DoWhileActiveBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for DoWhileActive. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def reference_step(self, value: Step):
        ...
    def task(self, value: Step):
        ...
def do_while_active(reference_step: Step = ..., task: Step = ...):
    """
    
    Run a task concurrently with a reference step, cancelling the task when the reference finishes.
    
    Both steps start executing at the same time. When ``reference_step``
    completes (either normally or via exception), ``task`` is immediately
    cancelled. This is useful for running a background activity (e.g.
    sensor polling, motor oscillation) only for as long as a primary
    action is running.
    
    If ``task`` finishes before ``reference_step``, the reference step
    continues running until it completes on its own.
    
    Args:
        reference_step: The primary step whose lifetime controls the task. When this step finishes, ``task`` is cancelled.
        task: The secondary step that runs concurrently and is cancelled once ``reference_step`` completes.
    
    Returns:
        A DoWhileActiveBuilder (chainable via ``.reference_step()``, ``.task()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.logic import do_while_active, loop_forever
    
        # Flash an LED while the robot drives forward
        flash_led = loop_forever(seq([
            set_digital(0, True),
            wait(0.25),
            set_digital(0, False),
            wait(0.25),
        ]))
        do_while_active(drive_forward(50), flash_led)
    """
_UNSET: object  # value = <object object>
