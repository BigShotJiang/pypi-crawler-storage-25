"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: if_then.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
from raccoon.step.logic.if_then import IfThen
from raccoon.step.model import StepProtocol
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
import typing
__all__: list = ['IfThenBuilder', 'if_then']
class IfThenBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for IfThen. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def condition(self, value: typing.Callable[['GenericRobot'], bool]):
        ...
    def else_step(self, value: StepProtocol | None):
        ...
    def then_step(self, value: StepProtocol):
        ...
def if_then(condition: typing.Callable[['GenericRobot'], bool] = ..., then_step: StepProtocol = ..., else_step: StepProtocol | None = None):
    """
    
    Conditionally run one of two steps based on a runtime predicate.
    
    Evaluates ``condition`` once when the step executes and runs
    ``then_step`` if it returns truthy, otherwise runs ``else_step``
    (or nothing, if ``else_step`` is not provided). The branch decision
    is made at runtime, so the predicate can read sensors, odometry, or
    any state computed by earlier steps in the sequence.
    
    Resource usage is reported as the union of both branches because
    either may execute. The condition itself is not allowed to launch
    long-running work — it should return a boolean quickly.
    
    Args:
        condition: A callable taking a ``GenericRobot`` and returning a boolean. Called exactly once when the step runs.
        then_step: The step to execute when ``condition`` returns True.
        else_step: Optional step to execute when ``condition`` returns False. If omitted, the step does nothing on the false branch.
    
    Returns:
        A IfThenBuilder (chainable via ``.condition()``, ``.then_step()``, ``.else_step()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.logic import if_then
    
        # Pick a branch based on a sensor reading at runtime
        if_then(
            lambda robot: robot.front_ir.read() > 500,
            drive_backward(20),
            drive_forward(20),
        )
    """
_UNSET: object  # value = <object object>
