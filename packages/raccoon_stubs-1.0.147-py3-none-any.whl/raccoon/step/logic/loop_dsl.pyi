"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: loop.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
from raccoon.step.logic.loop import LoopFor
from raccoon.step.logic.loop import LoopForever
from raccoon.step.model import StepProtocol
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
__all__: list = ['LoopForeverBuilder', 'loop_forever', 'LoopForBuilder', 'loop_for']
class LoopForBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for LoopFor. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def iterations(self, value: int):
        ...
    def step(self, value: StepProtocol):
        ...
class LoopForeverBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for LoopForever. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def step(self, value: StepProtocol):
        ...
def loop_for(step: StepProtocol = ..., iterations: int = ...):
    """
    
    Repeat a step a fixed number of times.
    
    Wraps the given step in a counted loop. Each iteration awaits the
    child step to completion before starting the next. After all
    iterations complete, the step finishes normally.
    
    Args:
        step: The step to execute repeatedly. Must satisfy ``StepProtocol``.
        iterations: Number of times to run the step. Must be a positive integer.
    
    Returns:
        A LoopForBuilder (chainable via ``.step()``, ``.iterations()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.logic import loop_for
    
        # Drive forward and back 3 times
        loop_for(seq([drive_forward(20), drive_backward(20)]), iterations=3)
    """
def loop_forever(step: StepProtocol = ...):
    """
    
    Repeat a step indefinitely until externally cancelled.
    
    Wraps the given step in an infinite loop. Each iteration awaits the
    child step to completion before starting the next. The loop only
    terminates when the enclosing context cancels it (e.g. via
    ``do_while_active`` or ``do_until_checkpoint``).
    
    Args:
        step: The step to execute repeatedly. Must satisfy ``StepProtocol``.
    
    Returns:
        A LoopForeverBuilder (chainable via ``.step()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.logic import loop_forever
        from raccoon.step.timing import do_until_checkpoint
    
        # Continuously toggle a motor on and off until T=30s
        toggle = seq([
            motor_power(robot.motor(0), 100),
            wait(0.5),
            motor_off(robot.motor(0)),
            wait(0.5),
        ])
        do_until_checkpoint(30.0, loop_forever(toggle))
    """
_UNSET: object  # value = <object object>
