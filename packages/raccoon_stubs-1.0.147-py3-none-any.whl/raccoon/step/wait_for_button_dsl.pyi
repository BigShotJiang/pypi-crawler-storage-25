"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: wait_for_button.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
from raccoon.step.wait_for_button import WaitForButton
__all__: list = ['WaitForButtonBuilder', 'wait_for_button']
class WaitForButtonBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for WaitForButton. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def message(self, value: str):
        ...
def wait_for_button(message: str = 'Waiting for button press...'):
    """
    
    Wait for the operator to press the hardware button before continuing.
    
    Blocks the step sequence until the physical button on the robot
    controller is pressed. A message is displayed on the UI while
    waiting. This is useful for pausing between autonomous phases,
    confirming the robot is correctly positioned before starting, or
    gating destructive actions behind human approval.
    
    Args:
        message: Text displayed on screen while waiting for the button press. Defaults to ``"Waiting for button press..."``.
    
    Returns:
        A WaitForButtonBuilder (chainable via ``.message()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step import wait_for_button
    
        # Wait for the operator to confirm placement before starting
        sequence(
            wait_for_button("Place robot at starting position"),
            motor_power(robot.motor(0), 100),
            wait(3.0),
            motor_brake(robot.motor(0)),
        )
    """
_UNSET: object  # value = <object object>
