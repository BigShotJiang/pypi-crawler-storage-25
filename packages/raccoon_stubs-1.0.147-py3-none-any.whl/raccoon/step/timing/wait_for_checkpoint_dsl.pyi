"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: wait_for_checkpoint.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
from raccoon.step.timing.wait_for_checkpoint import WaitForCheckpoint
import typing
__all__: list = ['WaitForCheckpointBuilder', 'wait_for_checkpoint']
class WaitForCheckpointBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for WaitForCheckpoint. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def checkpoint_seconds(self, value: float | int):
        ...
def wait_for_checkpoint(checkpoint_seconds: float | int = ...):
    """
    
    Wait until a mission-relative time checkpoint is reached.
    
    Pauses execution until the robot's global synchronizer clock reaches
    the specified number of seconds since mission start. If the
    checkpoint time has already passed, the step returns immediately.
    This is useful for synchronizing actions to absolute times within a
    timed Botball run (e.g. "at T=20s, start collecting").
    
    Prerequisites:
        The robot must have a ``synchronizer`` configured. The synchronizer
        clock starts when the mission begins.
    
    Args:
        checkpoint_seconds: The mission-relative time (in seconds) to wait for. Must be non-negative.
    
    Returns:
        A WaitForCheckpointBuilder (chainable via ``.checkpoint_seconds()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.timing import wait_for_checkpoint
    
        seq([
            drive_forward(50),
            # Ensure we don't start the next action before T=10s
            wait_for_checkpoint(10.0),
            pick_up_tribble(),
            # Gate the final action to T=25s
            wait_for_checkpoint(25.0),
            drive_to_bin(),
        ])
    """
_UNSET: object  # value = <object object>
