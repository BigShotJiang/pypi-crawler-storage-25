"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: timeout.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.base import Step
from raccoon.step.condition import StopCondition
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
from raccoon.step.timeout import Timeout
import typing
__all__: list = ['TimeoutBuilder', 'timeout']
class TimeoutBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for Timeout. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def seconds(self, value: float | int):
        ...
    def step(self, value: Step):
        ...
def timeout(step: Step = ..., seconds: float | int = ...):
    """
    
    Wrap a step with a time limit, cancelling it if it runs too long.
    
    Executes the given step normally but enforces a maximum wall-clock
    duration. If the wrapped step completes within the budget, the
    timeout step finishes successfully. If the step exceeds the time
    limit, it is cancelled via ``asyncio.wait_for`` and an error is
    logged. Any exception raised by the wrapped step propagates
    normally.
    
    This is especially useful around blocking steps like
    ``motor_move_to`` or ``wait_for_button`` that could stall
    indefinitely if the hardware misbehaves.
    
    Args:
        step: The step to execute under a time constraint. Must be a valid ``Step`` (or ``StepProtocol``) instance.
        seconds: Maximum allowed execution time in seconds. Must be positive.
    
    Returns:
        A TimeoutBuilder (chainable via ``.step()``, ``.seconds()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step import timeout
        from raccoon.step.motor import motor_move_to
    
        # Give the arm 5 seconds to reach position 300; cancel if stuck
        timeout(
            motor_move_to(robot.motor(2), position=300, velocity=800),
            seconds=5.0,
        )
    
        # Ensure operator presses button within 30 seconds
        timeout(wait_for_button(), seconds=30.0)
    """
_UNSET: object  # value = <object object>
