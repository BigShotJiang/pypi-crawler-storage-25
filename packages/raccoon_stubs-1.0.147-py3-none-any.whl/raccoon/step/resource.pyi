"""
Hardware resource tracking and conflict detection for parallel step execution.

Every step declares which hardware resources it requires exclusive access to via
``required_resources()``.  Composite steps (Parallel, DoWhileActive) validate at
construction time that no two concurrent branches claim the same resource.  A
lightweight runtime ``ResourceManager`` acts as a safety net for dynamically
constructed steps (e.g. ``Defer``) that cannot be checked statically.

Resource identifiers are plain strings with the format ``"<type>"`` or
``"<type>:<qualifier>"``:

    "drive"       — chassis drive system
    "motor:0"     — motor on port 0
    "servo:3"     — servo on port 3
    "servo:*"     — all servo ports (used by FullyDisableServos)
"""
from __future__ import annotations
import typing
__all__: list[str] = ['ResourceConflictError', 'ResourceManager', 'get_resource_manager', 'validate_no_overlap']
class ResourceConflictError(Exception):
    """
    Raised when two concurrent steps require the same hardware resource.
    """
    def __init__(self, resource: str, holder: str, requester: str) -> None:
        ...
class ResourceManager:
    """
    Non-blocking, fail-fast resource lock attached to the robot instance.
    
    Since all steps run in a single asyncio event loop (cooperative
    multitasking), no real lock is needed — a simple dict suffices.
    """
    def __init__(self) -> None:
        ...
    def acquire(self, resources: frozenset[str], holder: str) -> None:
        """
        Claim *resources* for *holder*.  Raises on conflict.
        """
    def release(self, resources: frozenset[str]) -> None:
        """
        Release previously acquired resources.
        """
class _HasResources:
    def collected_resources(self) -> frozenset[str]:
        ...
def _branch_label(step: '_HasResources', index: int) -> str:
    """
    Best-effort human-readable label for an error message.
    """
def _resources_overlap(a: frozenset[str], b: frozenset[str]) -> list[str]:
    """
    Return the list of resource IDs that conflict between *a* and *b*.
    
    Handles wildcard resources (e.g. ``"servo:*"`` conflicts with any
    ``"servo:<n>"``).
    """
def get_resource_manager(robot: typing.Any) -> ResourceManager:
    """
    Get or create the ``ResourceManager`` attached to *robot*.
    """
def validate_no_overlap(branches: typing.Sequence['_HasResources'], context: str = 'Parallel') -> None:
    """
    Check pairwise that no two branches claim the same resource.
    
    Args:
        branches: Sequence of objects with a ``required_resources()`` method.
        context: Name used in the error message (e.g. ``"Parallel"``
            or ``"DoWhileActive"``).
    
    Raises:
        ResourceConflictError: If any two branches share a resource.
    """
