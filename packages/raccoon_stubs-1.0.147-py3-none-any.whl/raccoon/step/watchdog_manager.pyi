"""
Watchdog manager — deadlines that cancel the main-mission task on expiry.

Two usage patterns share one manager:

- **Mission deadlines** — armed automatically by the robot runner from a
  ``Mission.time_budget`` class attribute. Never fed; expiry fires when the
  budget elapses.
- **Keepalive watchdogs** — armed/fed/disarmed imperatively by user code
  via the ``start_watchdog`` / ``feed_watchdog`` / ``stop_watchdog`` steps.
  Must be fed before their timeout or expiry fires.

On expiry, the manager cancels the registered *main-mission task*. This
routes through the existing shutdown path in ``_run_missions``: background
tasks drain, the shutdown mission runs, then the process exits.
"""
from __future__ import annotations
import asyncio as asyncio
import dataclasses
from dataclasses import dataclass
import logging as logging
import typing
__all__: list[str] = ['WatchdogExpiredError', 'WatchdogManager', 'asyncio', 'dataclass', 'get_watchdog_manager', 'logger', 'logging']
class WatchdogExpiredError(Exception):
    """
    Raised on the main-mission task when a watchdog expires.
    """
class WatchdogManager:
    """
    Track armed watchdogs and cancel the main-mission task on expiry.
    
    Attached to the robot instance as ``robot._watchdog_manager``. Wire the
    main-mission task via ``attach_main_task`` before arming anything so the
    manager knows what to cancel.
    """
    def __init__(self) -> None:
        ...
    def _expiry_timer(self, name: str) -> None:
        """
        Sleep until the entry's deadline, then fire expiry.
        """
    def _fire_expiry(self, entry: _WDEntry) -> None:
        """
        Record expiry and cancel the main-mission task.
        """
    def active_names(self, source: str | None = None) -> list[str]:
        """
        Return names of currently armed watchdogs, optionally filtered by source.
        """
    def arm(self, name: str, timeout: float, source: str = 'user') -> None:
        """
        Arm a watchdog. Replaces any existing entry with the same name.
        """
    def attach_main_task(self, task: asyncio.Task[None]) -> None:
        """
        Register the task that should be cancelled when a watchdog fires.
        """
    def cancel_all(self) -> None:
        """
        Cancel every armed watchdog and await cleanup.
        """
    def detach_main_task(self) -> None:
        """
        Clear the main-task reference after main missions finish.
        """
    def disarm(self, name: str, *, missing_ok: bool = False) -> None:
        """
        Cancel and remove the named watchdog.
        """
    def feed(self, name: str) -> None:
        """
        Push the named watchdog's deadline out by its full timeout.
        """
    @property
    def expired_name(self) -> str | None:
        """
        Name of the watchdog that fired, or ``None`` if no expiry occurred.
        """
class _WDEntry:
    """
    _WDEntry(name: 'str', timeout: 'float', deadline: 'float', task: 'asyncio.Task[None]', source: 'str')
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'name': Field(name='name',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'timeout': Field(name='timeout',type='float',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'deadline': Field(name='deadline',type='float',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'task': Field(name='task',type='asyncio.Task[None]',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'source': Field(name='source',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('name', 'timeout', 'deadline', 'task', 'source')
    def __eq__(self, other):
        ...
    def __init__(self, name: str, timeout: float, deadline: float, task: asyncio.Task[None], source: str) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
def get_watchdog_manager(robot: typing.Any) -> WatchdogManager:
    """
    Get or create the ``WatchdogManager`` attached to *robot*.
    """
logger: logging.Logger  # value = <Logger raccoon.step.watchdog_manager (INFO)>
