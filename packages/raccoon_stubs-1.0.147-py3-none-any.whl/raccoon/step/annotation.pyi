from __future__ import annotations
import dataclasses
from dataclasses import dataclass
from dataclasses import field
from functools import wraps
import inspect as inspect
from raccoon.step.base import Step
from raccoon.step.model import StepProtocol
import typing
from typing import Any
from typing import TypeVar
from typing import get_type_hints
from typing import overload
__all__: list[str] = ['Any', 'DslMeta', 'F', 'Step', 'StepProtocol', 'T', 'TypeVar', 'dataclass', 'dsl', 'dsl_step', 'field', 'get_type_hints', 'inspect', 'overload', 'wraps']
class DslMeta:
    """
    Discovery metadata attached by ``@dsl`` to steps and factories.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'hidden': Field(name='hidden',type='bool',default=False,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'name': Field(name='name',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'tags': Field(name='tags',type='tuple[str, ...]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'tuple'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=True,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __match_args__: typing.ClassVar[tuple] = ('hidden', 'name', 'tags')
    hidden: typing.ClassVar[bool] = False
    name = None
    def __delattr__(self, name):
        ...
    def __eq__(self, other):
        ...
    def __hash__(self):
        ...
    def __init__(self, hidden: bool = False, name: str | None = None, tags: tuple[str, ...] = ...) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
    def __setattr__(self, name, value):
        ...
def dsl(_target: T | F | None = None, *, hidden: bool = False, name: str | None = None, tags: list[str] | tuple[str, ...] | None = None) -> typing.Callable[[T | F], T | F] | T | F:
    """
    
    Mark a class or function as part of the DSL.
    
    Usage:
      @dsl
      class X(Step): ...
    
      @dsl(hidden=True, name="TurnLeft", tags=["movement", "rotation"])
      class Y(Step): ...
    
      @dsl(name="Wait", tags=["timing"])
      def wait_seconds(seconds: float) -> WaitStep:
          return WaitStep(seconds)
    
    Args:
        hidden: If True, hide from auto-discovery/UI.
        name: Custom display name (defaults to class/function name).
        tags: List of tags for grouping in web UI.
    """
def dsl_step(cls: T | None = None, *, tags: list[str] | tuple[str, ...] | None = None) -> T | typing.Callable[[T], T]:
    """
    Mark a Step class for builder + DSL function generation.
    
    Codegen scans for classes decorated with ``@dsl_step``,
    introspects their ``__init__`` parameters, and generates:
    
    - A ``<ClassName>Builder(StepBuilder)`` with fluent setter methods
    - A ``snake_case()`` factory function decorated with ``@dsl(tags=...)``
    
    The marker also applies ``@dsl(hidden=True)`` so the raw class is
    hidden from the UI (users interact via the generated DSL function).
    
    Usage::
    
        @dsl_step(tags=["motion", "drive"])
        class DriveForward(MotionStep):
            def __init__(self, cm: float = None, speed: float = 1.0,
                         until: StopCondition = None):
                ...
    
    Codegen produces ``DriveForwardBuilder`` and ``drive_forward()``.
    Tags are propagated to the generated ``@dsl(tags=...)`` factory.
    """
F: typing.TypeVar  # value = ~F
T: typing.TypeVar  # value = ~T
