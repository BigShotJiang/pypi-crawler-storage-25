"""

Deadzone calibration step using the UI library.

BEMF is unreliable at low RPM, so we use human observation via the UI
to find the exact motor percentage where the wheel starts turning.
"""
from __future__ import annotations
import asyncio as asyncio
import dataclasses
from dataclasses import dataclass
import raccoon.step.annotation
from raccoon.step.annotation import dsl_step
from raccoon.step.calibration.deadzone.screens import DeadzoneIntroScreen
from raccoon.step.calibration.deadzone.screens import DeadzoneResultsScreen
from raccoon.step.calibration.deadzone.screens import DeadzoneSummaryScreen
from raccoon.step.calibration.deadzone.screens import DeadzoneTestingScreen
from raccoon.ui.screens.basic import MessageScreen
import raccoon.ui.step
from raccoon.ui.step import UIStep
import typing
__all__: list[str] = ['CalibrateDeadzone', 'DeadzoneCalibrationResult', 'DeadzoneIntroScreen', 'DeadzoneResultsScreen', 'DeadzoneSummaryScreen', 'DeadzoneTestingScreen', 'MessageScreen', 'UIStep', 'asyncio', 'dataclass', 'dsl_step']
class CalibrateDeadzone(raccoon.ui.step.UIStep):
    """
    Calibrate motor deadzone via UI-based human observation.
    
    The deadzone is the minimum power percentage required to overcome
    static friction and start the motor turning. BEMF readings are
    unreliable at low RPM, so this step ramps motor power from
    ``start_percent`` upward and asks the operator to confirm when
    the wheel starts spinning. The result is stored as the motor's
    ``ff.kS`` (static friction) feedforward value.
    
    Args:
        motor_ports: List of motor ports to calibrate. ``None``
            calibrates all drive motors.
        start_percent: Starting power percentage to test.
        max_percent: Maximum power percentage before giving up.
        settle_time: Seconds to wait after setting power before asking
            the operator.
    
    Example::
    
        from raccoon.step.calibration import calibrate_deadzone
    
        # Calibrate all motors with defaults
        calibrate_deadzone()
    
        # Calibrate only motors 0 and 1
        calibrate_deadzone(motor_ports=[0, 1])
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='CalibrateDeadzone', tags=('calibration', 'motor', 'deadzone'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'CalibrateDeadzone'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('calibration', 'motor', 'deadzone')
    __dsl_tags__: typing.ClassVar[tuple] = ('calibration', 'motor', 'deadzone')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    def __init__(self, motor_ports: typing.Optional[typing.List[int]] = None, start_percent: int = 1, max_percent: int = 30, settle_time: float = 0.3):
        ...
    def _calibrate_motor(self, robot: GenericRobot, motor, motor_name: str, motor_port: int) -> typing.Optional[raccoon.step.calibration.deadzone.step.DeadzoneCalibrationResult]:
        """
        Calibrate a single motor's deadzone.
        """
    def _execute_step(self, robot: GenericRobot) -> None:
        """
        
        Execute the deadzone calibration.
        
        Flow for each motor:
        1. Show intro screen with motor info
        2. Incrementally test power levels (FORWARD)
        3. User indicates when wheel starts turning
        4. Repeat for REVERSE direction
        5. Show results, allow retry
        6. After all motors, show summary and apply
        """
    def _find_deadzone_for_direction(self, robot: GenericRobot, motor, motor_name: str, motor_port: int, direction: int, direction_name: str) -> int:
        """
        
        Find the minimum power that makes the motor turn in one direction.
        
        Returns the first percentage where user indicates movement.
        """
    def _generate_signature(self) -> str:
        ...
class DeadzoneCalibrationResult:
    """
    Result of deadzone calibration for a single motor.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'motor_port': Field(name='motor_port',type=<class 'int'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'motor_name': Field(name='motor_name',type=<class 'str'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'start_percent_forward': Field(name='start_percent_forward',type=<class 'int'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'start_percent_reverse': Field(name='start_percent_reverse',type=<class 'int'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'release_percent': Field(name='release_percent',type=<class 'int'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('motor_port', 'motor_name', 'start_percent_forward', 'start_percent_reverse', 'release_percent')
    def __eq__(self, other):
        ...
    def __init__(self, motor_port: int, motor_name: str, start_percent_forward: int, start_percent_reverse: int, release_percent: int) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
    @property
    def start_percent(self) -> int:
        """
        The higher of forward/reverse percentages.
        """
