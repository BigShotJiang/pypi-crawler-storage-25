"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: step.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.calibration.deadzone.step import CalibrateDeadzone
from raccoon.step.condition import StopCondition
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
import typing
__all__: list = ['CalibrateDeadzoneBuilder', 'calibrate_deadzone']
class CalibrateDeadzoneBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for CalibrateDeadzone. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def max_percent(self, value: int):
        ...
    def motor_ports(self, value: list[int] | None):
        ...
    def settle_time(self, value: float):
        ...
    def start_percent(self, value: int):
        ...
def calibrate_deadzone(motor_ports: list[int] | None = None, start_percent: int = 1, max_percent: int = 30, settle_time: float = 0.3):
    """
    
    Calibrate motor deadzone via UI-based human observation.
    
    The deadzone is the minimum power percentage required to overcome
    static friction and start the motor turning. BEMF readings are
    unreliable at low RPM, so this step ramps motor power from
    ``start_percent`` upward and asks the operator to confirm when
    the wheel starts spinning. The result is stored as the motor's
    ``ff.kS`` (static friction) feedforward value.
    
    Args:
        motor_ports: List of motor ports to calibrate. ``None`` calibrates all drive motors.
        start_percent: Starting power percentage to test.
        max_percent: Maximum power percentage before giving up.
        settle_time: Seconds to wait after setting power before asking the operator.
    
    Returns:
        A CalibrateDeadzoneBuilder (chainable via ``.motor_ports()``, ``.start_percent()``, ``.max_percent()``, ``.settle_time()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.calibration import calibrate_deadzone
    
        # Calibrate all motors with defaults
        calibrate_deadzone()
    
        # Calibrate only motors 0 and 1
        calibrate_deadzone(motor_ports=[0, 1])
    """
_UNSET: object  # value = <object object>
