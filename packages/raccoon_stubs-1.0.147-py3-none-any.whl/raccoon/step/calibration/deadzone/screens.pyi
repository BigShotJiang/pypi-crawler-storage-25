"""

Deadzone calibration UI screens.

These screens guide the user through finding the minimum motor power
where the wheel starts turning.
"""
from __future__ import annotations
import dataclasses
from dataclasses import dataclass
from raccoon.ui.events import on_button_press
from raccoon.ui.events import on_click
import raccoon.ui.screen
from raccoon.ui.screen import UIScreen
import raccoon.ui.widgets
from raccoon.ui.widgets import Button
from raccoon.ui.widgets import Card
from raccoon.ui.widgets import Center
from raccoon.ui.widgets import Column
from raccoon.ui.widgets import HintBox
from raccoon.ui.widgets import Icon
from raccoon.ui.widgets import ResultsTable
from raccoon.ui.widgets import Row
from raccoon.ui.widgets import Spacer
from raccoon.ui.widgets import StatusBadge
from raccoon.ui.widgets import StatusIcon
from raccoon.ui.widgets import Text
from raccoon.ui.widgets import Widget
import typing
__all__: list[str] = ['Button', 'Card', 'Center', 'Column', 'DeadzoneConfirmResult', 'DeadzoneIntroScreen', 'DeadzoneResultsScreen', 'DeadzoneSummaryScreen', 'DeadzoneTestResult', 'DeadzoneTestingScreen', 'HintBox', 'Icon', 'ResultsTable', 'Row', 'Spacer', 'StatusBadge', 'StatusIcon', 'Text', 'UIScreen', 'Widget', 'dataclass', 'on_button_press', 'on_click']
class DeadzoneConfirmResult:
    """
    Result from the confirmation screen.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'confirmed': Field(name='confirmed',type=<class 'bool'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'retry_motor': Field(name='retry_motor',type=typing.Optional[str],default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('confirmed', 'retry_motor')
    retry_motor = None
    def __eq__(self, other):
        ...
    def __init__(self, confirmed: bool, retry_motor: typing.Optional[str] = None) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class DeadzoneIntroScreen(raccoon.ui.screen.UIScreen):
    """
    
    Introduction screen for deadzone calibration.
    
    Shows motor info and instructions, waits for button press.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[NoneType])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    title: typing.ClassVar[str] = 'Deadzone Calibration'
    def __init__(self, motor_name: str, motor_port: int, direction: str, start_percent: int = 1, max_percent: int = 30):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_press(self):
        ...
class DeadzoneResultsScreen(raccoon.ui.screen.UIScreen):
    """
    
    Screen showing calibration results for a single motor.
    
    Allows user to confirm or retry the calibration.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[raccoon.step.calibration.deadzone.screens.DeadzoneConfirmResult])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id: typing.ClassVar[str] = 'confirm'
    title: typing.ClassVar[str] = 'Calibration Results'
    def __init__(self, motor_name: str, motor_port: int, forward_percent: int, reverse_percent: int, release_percent: int):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_confirm(self):
        ...
    def on_retry(self):
        ...
    @property
    def is_symmetric(self) -> bool:
        """
        Check if forward and reverse are roughly equal.
        """
    @property
    def kS(self) -> float:
        """
        Normalized static friction coefficient for ff.kS.
        """
    @property
    def start_percent(self) -> int:
        """
        The higher of forward/reverse as the start threshold.
        """
class DeadzoneSummaryScreen(raccoon.ui.screen.UIScreen):
    """
    
    Summary screen showing results for all motors.
    
    Allows user to apply all calibrations or cancel.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[bool])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id: typing.ClassVar[str] = 'apply'
    title: typing.ClassVar[str] = 'ff.kS Calibration Summary'
    def __init__(self, results: list):
        """
        
        Args:
            results: List of dicts with keys: motor_name, port, forward, reverse, kS
        """
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_apply(self):
        ...
    def on_cancel(self):
        ...
class DeadzoneTestResult:
    """
    Result from the testing screen.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'is_turning': Field(name='is_turning',type=<class 'bool'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('is_turning')
    def __eq__(self, other):
        ...
    def __init__(self, is_turning: bool) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class DeadzoneTestingScreen(raccoon.ui.screen.UIScreen):
    """
    
    Screen shown during deadzone testing.
    
    Shows current power percentage and direction, with buttons
    to indicate whether the wheel is turning.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[raccoon.step.calibration.deadzone.screens.DeadzoneTestResult])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    title: typing.ClassVar[str] = 'Is the wheel turning?'
    def __init__(self, motor_name: str, motor_port: int, current_percent: int, direction: str, max_percent: int = 30):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_button(self):
        ...
    def on_not_turning(self):
        ...
    def on_turning(self):
        ...
