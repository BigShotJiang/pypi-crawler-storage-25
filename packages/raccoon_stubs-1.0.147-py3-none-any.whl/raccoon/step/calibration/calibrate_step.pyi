"""
Reusable base class for interactive calibration steps.

Subclasses implement four hooks to define what data is collected, how it is
confirmed, how it is applied to hardware, and how it is serialised for
persistent storage.  The base class takes care of:

* Running optional *setup_steps* before the first attempt and on every retry.
* The collect → confirm → apply/retry loop.
* Persisting confirmed values to ``racoon.calibration.yml``.
* Honouring ``--no-calibrate``: loading stored values instead of running the
  interactive flow.
"""
from __future__ import annotations
from abc import abstractmethod
from raccoon.no_calibrate import is_no_calibrate
from raccoon.step.base import Step
from raccoon.step.calibration.store import CalibrationStore
import raccoon.ui.step
from raccoon.ui.step import UIStep
import typing
from typing import Generic
from typing import TypeVar
__all__: list[str] = ['CalibrateStep', 'CalibrationStore', 'Generic', 'Step', 'T', 'TypeVar', 'UIStep', 'abstractmethod', 'is_no_calibrate']
class CalibrateStep(raccoon.ui.step.UIStep, typing.Generic):
    """
    Template for an interactive calibration step with persistence.
    
    Type parameter *T* is the calibration payload — the domain-specific
    value object that flows through collect → confirm → apply → store.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset({'_confirm', '_deserialize', '_serialize', '_collect', '_apply'})
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.step.UIStep, typing.Generic[~T])
    __parameters__: typing.ClassVar[tuple]  # value = (~T)
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    def __init__(self, store_section: str, store_set: str = 'default', setup_steps: list[Step] | None = None) -> None:
        ...
    def _apply(self, robot: 'GenericRobot', calibration: T) -> None:
        """
        Apply the confirmed calibration to the running hardware.
        """
    def _collect(self, robot: 'GenericRobot') -> T | None:
        """
        Collect sensor data and compute a calibration proposal.
        
        Return *None* to silently retry (e.g. too few samples).
        """
    def _confirm(self, robot: 'GenericRobot', calibration: T) -> tuple[bool, T]:
        """
        Present the calibration to the user for confirmation.
        
        Returns ``(confirmed, calibration)`` — the calibration may have been
        adjusted by the user via the UI.
        """
    def _deserialize(self, data: dict) -> T:
        """
        Reconstruct a calibration object from a stored dict.
        """
    def _execute_step(self, robot: 'GenericRobot') -> None:
        ...
    def _run_setup(self, robot: 'GenericRobot') -> None:
        ...
    def _serialize(self, calibration: T) -> dict:
        """
        Convert *calibration* to a plain dict for YAML storage.
        """
T: typing.TypeVar  # value = ~T
