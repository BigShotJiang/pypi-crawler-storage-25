"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: calibrate_wfl.py
"""
from __future__ import annotations
from raccoon.hal import AnalogSensor
from raccoon.step.annotation import dsl
from raccoon.step.calibration.calibrate_wfl import CalibrateWaitForLight
from raccoon.step.condition import StopCondition
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
__all__: list = ['CalibrateWaitForLightBuilder', 'calibrate_wait_for_light']
class CalibrateWaitForLightBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for CalibrateWaitForLight. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def sensor(self, value: AnalogSensor):
        ...
def calibrate_wait_for_light(sensor: AnalogSensor = ...):
    """
    
    Calibrate a wait-for-light sensor via interactive measurement.
    
    Guides the operator through a two-step measurement flow: first cover
    the sensor (dark reading), then expose it to the start lamp (light
    reading). The midpoint threshold is computed and stored so the
    ``wait_for_light_legacy`` step can detect the lamp signal.
    
    The operator can retry measurements if the values look wrong before
    confirming the calibration.
    
    Args:
        sensor: The AnalogSensor instance to calibrate.
    
    Returns:
        A CalibrateWaitForLightBuilder (chainable via ``.sensor()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.calibration import calibrate_wait_for_light
    
        calibrate_wait_for_light(robot.defs.wait_for_light_sensor)
    """
_UNSET: object  # value = <object object>
