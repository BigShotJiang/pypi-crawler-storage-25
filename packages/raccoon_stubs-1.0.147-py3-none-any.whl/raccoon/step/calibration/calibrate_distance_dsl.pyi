"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: calibrate_distance.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.calibration.calibrate_distance import CalibrateDistance
from raccoon.step.condition import StopCondition
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
import typing
__all__: list = ['CalibrateDistanceBuilder', 'calibrate_distance']
class CalibrateDistanceBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for CalibrateDistance. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def calibrate_light_sensors(self, value: bool):
        ...
    def calibration_sets(self, value: list[str] | None):
        ...
    def distance_cm(self, value: float):
        ...
    def ema_alpha(self, value: float):
        ...
    def exclude_ir_sensors(self, value: list['IRSensor'] | None):
        ...
    def persist_to_yaml(self, value: bool):
        ...
def calibrate_distance(distance_cm: float = 30.0, calibrate_light_sensors: bool = False, persist_to_yaml: bool = True, ema_alpha: float = 0.7, calibration_sets: list[str] | None = None, exclude_ir_sensors: list['IRSensor'] | None = None):
    """
    
    Calibrate per-wheel distance estimation via encoder measurement.
    
    Drives the robot a known distance, then prompts the user to enter the
    actual measured distance. The step computes a corrected ``ticks_to_rad``
    value for each drive motor so that odometry matches real-world distances.
    
    The calibration operates in two modes simultaneously:
    
    - **Runtime**: Applies the measured ``ticks_to_rad`` directly for best
      accuracy during this run.
    - **Persistent**: Updates the YAML baseline using an exponential moving
      average (EMA) so the stored value converges toward the true value over
      multiple calibration runs.
    
    Args:
        distance_cm: Distance (in cm) the robot drives during calibration. Longer distances yield better accuracy.
        calibrate_light_sensors: If ``True``, run IR sensor calibration after the distance calibration is confirmed.
        persist_to_yaml: If ``True``, write the EMA-filtered baseline to ``raccoon.project.yml`` so it persists across program runs.
        ema_alpha: EMA smoothing coefficient between 0.0 and 1.0. Higher values produce slower convergence but a more stable baseline.
        calibration_sets: List of named IR calibration surface sets (e.g. ``["default", "transparent"]``). Only used when ``calibrate_light_sensors`` is ``True``.
        exclude_ir_sensors: List of ``IRSensor`` instances to skip during IR calibration.
    
    Returns:
        A CalibrateDistanceBuilder (chainable via ``.distance_cm()``, ``.calibrate_light_sensors()``, ``.persist_to_yaml()``, ``.ema_alpha()``, ``.calibration_sets()``, ``.exclude_ir_sensors()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.calibration import calibrate_distance
    
        # Distance-only calibration with defaults
        calibrate_distance()
    
        # Distance + IR sensor calibration
        calibrate_distance(
            distance_cm=50.0,
            calibrate_light_sensors=True,
            calibration_sets=["default", "transparent"],
        )
    """
_UNSET: object  # value = <object object>
