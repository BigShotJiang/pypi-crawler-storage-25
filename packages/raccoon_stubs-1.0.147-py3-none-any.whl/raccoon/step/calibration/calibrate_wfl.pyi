"""

Wait-for-light sensor calibration step using the new UI library.
"""
from __future__ import annotations
import dataclasses
from dataclasses import dataclass
import raccoon.hal
from raccoon.hal import AnalogSensor
import raccoon.step.annotation
from raccoon.step.annotation import dsl_step
from raccoon.ui.screens.wfl import WFLConfirmResult
from raccoon.ui.screens.wfl import WFLConfirmScreen
from raccoon.ui.screens.wfl import WFLMeasureScreen
import raccoon.ui.step
from raccoon.ui.step import UIStep
import typing
__all__: list[str] = ['AnalogSensor', 'CalibrateWaitForLight', 'UIStep', 'WFLCalibrationResult', 'WFLConfirmResult', 'WFLConfirmScreen', 'WFLMeasureScreen', 'dataclass', 'dsl_step']
class CalibrateWaitForLight(raccoon.ui.step.UIStep):
    """
    Calibrate a wait-for-light sensor via interactive measurement.
    
    Guides the operator through a two-step measurement flow: first cover
    the sensor (dark reading), then expose it to the start lamp (light
    reading). The midpoint threshold is computed and stored so the
    ``wait_for_light_legacy`` step can detect the lamp signal.
    
    The operator can retry measurements if the values look wrong before
    confirming the calibration.
    
    Args:
        sensor: The AnalogSensor instance to calibrate.
    
    Example::
    
        from raccoon.step.calibration import calibrate_wait_for_light
    
        calibrate_wait_for_light(robot.defs.wait_for_light_sensor)
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='CalibrateWaitForLight', tags=('calibration', 'light'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'CalibrateWaitForLight'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('calibration', 'light')
    __dsl_tags__: typing.ClassVar[tuple] = ('calibration', 'light')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    def __init__(self, sensor: raccoon.hal.AnalogSensor) -> None:
        ...
    def _execute_step(self, robot: GenericRobot) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class WFLCalibrationResult:
    """
    Result of wait-for-light sensor calibration.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'light_off': Field(name='light_off',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'light_on': Field(name='light_on',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'threshold': Field(name='threshold',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('light_off', 'light_on', 'threshold')
    def __eq__(self, other):
        ...
    def __init__(self, light_off: float, light_on: float, threshold: float) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
