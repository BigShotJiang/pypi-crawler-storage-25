"""
YAML-backed calibration store.

Persists arbitrary calibration data to ``racoon.calibration.yml`` alongside
the C++ CalibrationStore (which owns the ``ir-calibration`` section).

Each section/set pair maps to a flat dict of values::

    root:
      range-finder:
        first_pipe:
          t_enter: 1200.0
          t_exit: 800.0
      drum-collector:
        default:
          blocked: 3200.0
          pocket: 900.0
"""
from __future__ import annotations
from pathlib._local import Path
import typing
import yaml as yaml
__all__: list[str] = ['CALIBRATION_FILE', 'CalibrationStore', 'Path', 'yaml']
class CalibrationStore:
    """
    Read and write named calibration sections in the calibration YAML.
    """
    def __init__(self, path: Path | None = None) -> None:
        ...
    def _read_root(self) -> dict:
        ...
    def _write_root(self, root: dict) -> None:
        ...
    def has_data(self, section: str, set_name: str = 'default') -> bool:
        """
        Check whether calibration data exists for the given section/set.
        """
    def load(self, section: str, set_name: str = 'default') -> dict | None:
        """
        Load a calibration dict, or *None* if nothing is stored.
        """
    def store(self, section: str, data: dict, set_name: str = 'default') -> None:
        """
        Persist a calibration dict (merges with existing file).
        """
CALIBRATION_FILE: str = 'racoon.calibration.yml'
