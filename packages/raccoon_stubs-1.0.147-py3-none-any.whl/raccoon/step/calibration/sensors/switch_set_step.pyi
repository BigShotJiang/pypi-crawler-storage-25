from __future__ import annotations
from raccoon import calibration_store as CalibrationStore
from raccoon.calibration_store import CalibrationType
from raccoon.sensor_ir import IRSensor
import raccoon.step.annotation
from raccoon.step.annotation import dsl_step
import raccoon.ui.step
from raccoon.ui.step import UIStep
import typing
__all__: list[str] = ['CalibrationStore', 'CalibrationType', 'IRSensor', 'SwitchCalibrationSet', 'UIStep', 'dsl_step']
class SwitchCalibrationSet(raccoon.ui.step.UIStep):
    """
    Switch IR sensors to a named calibration set.
    
    Loads calibration data for the given set name from the calibration
    store and applies it to all registered IR sensors. Each sensor looks
    up its per-port calibration key (e.g. ``"transparent_port3"``) and
    sets its black/white thresholds accordingly.
    
    Use this to swap between surface-specific calibrations at runtime
    (e.g. switching from the default table surface to transparent objects).
    
    Args:
        set_name: Name of the calibration set to apply
            (e.g. ``"default"``, ``"transparent"``).
    
    Example::
    
        from raccoon.step.calibration import switch_calibration_set
    
        # Switch to transparent calibration before scoring
        switch_calibration_set("transparent")
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='SwitchCalibrationSet', tags=('calibration', 'sensor'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'SwitchCalibrationSet'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('calibration', 'sensor')
    __dsl_tags__: typing.ClassVar[tuple] = ('calibration', 'sensor')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    def __init__(self, set_name: str = 'default') -> None:
        ...
    def _execute_step(self, robot: GenericRobot) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
