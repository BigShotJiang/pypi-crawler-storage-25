from __future__ import annotations
import asyncio as asyncio
from raccoon import calibration_store as CalibrationStore
from raccoon.calibration_store import CalibrationType
from raccoon.sensor_ir import IRSensor
from raccoon.sensor_ir import IRSensorCalibration
import raccoon.step.annotation
from raccoon.step.annotation import dsl_step
from raccoon.step.calibration.sensors.dataclasses import IRSensorCalibrationResult
from raccoon.step.calibration.sensors.dataclasses import SensorCalibrationData
from raccoon.step.calibration.sensors.ir_calibrating_screen import IRCalibratingScreen
from raccoon.step.calibration.sensors.ir_overview_screen import IROverviewScreen
from raccoon.step.calibration.sensors.ir_results_screen import IRResultsDashboardScreen
import raccoon.ui.step
from raccoon.ui.step import UIStep
import typing
__all__: list[str] = ['CalibrateSensors', 'CalibrationStore', 'CalibrationType', 'IRCalibratingScreen', 'IROverviewScreen', 'IRResultsDashboardScreen', 'IRSensor', 'IRSensorCalibration', 'IRSensorCalibrationResult', 'SensorCalibrationData', 'UIStep', 'asyncio', 'dsl_step']
class CalibrateSensors(raccoon.ui.step.UIStep):
    """
    Calibrate IR sensors by sampling black and white surface readings.
    
    Guides the operator through sampling each IR sensor over calibration
    surfaces to establish black/white thresholds. The operator places the
    robot on the calibration surface and the step samples readings for the
    configured duration. Supports multiple named calibration sets (e.g.
    ``"default"`` and ``"transparent"``) for surface-specific thresholds.
    
    Args:
        calibration_time: Duration for calibration sampling in seconds.
        allow_use_existing: If ``True``, offer to reuse existing
            calibration values instead of re-sampling.
        calibration_sets: Named calibration sets to calibrate
            (e.g. ``["default", "transparent"]``). Defaults to
            ``["default"]``.
    
    Example::
    
        from raccoon.step.calibration import calibrate_sensors
    
        # Basic IR calibration
        calibrate_sensors()
    
        # Two surface sets with longer sampling
        calibrate_sensors(
            calibration_time=8.0,
            calibration_sets=["default", "transparent"],
        )
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='CalibrateSensors', tags=('calibration', 'sensor'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'CalibrateSensors'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('calibration', 'sensor')
    __dsl_tags__: typing.ClassVar[tuple] = ('calibration', 'sensor')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    def __init__(self, calibration_time: float = 5.0, allow_use_existing: bool = True, calibration_sets: typing.Optional[typing.List[str]] = None) -> None:
        ...
    def _calibrate_sensors(self, ir_sensors: typing.List[raccoon.sensor_ir.IRSensor], set_name: str = 'default') -> bool:
        """
        Run the blocking calibration in a thread.
        """
    def _calibrate_single_set(self, robot: GenericRobot, ir_sensors: typing.List[raccoon.sensor_ir.IRSensor], ports: typing.List[int], set_name: str) -> bool:
        """
        Run the calibration flow for a single named set. Returns True if completed.
        """
    def _collect_sensor_data(self, ir_sensors: typing.List[raccoon.sensor_ir.IRSensor], ports: typing.List[int]) -> typing.List[raccoon.step.calibration.sensors.dataclasses.SensorCalibrationData]:
        """
        Collect per-sensor calibration data after calibration run.
        """
    def _execute_step(self, robot: GenericRobot) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
