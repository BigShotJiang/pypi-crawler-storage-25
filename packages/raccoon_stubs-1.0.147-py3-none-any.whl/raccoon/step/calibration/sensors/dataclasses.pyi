from __future__ import annotations
import dataclasses
from dataclasses import dataclass
from dataclasses import field
import typing
__all__: list[str] = ['IRCalibrationChoice', 'IRConfirmResult', 'IRDashboardResult', 'IRSensorCalibrationResult', 'SensorCalibrationData', 'dataclass', 'field']
class IRCalibrationChoice:
    """
    Result from IROverviewScreen.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'use_existing': Field(name='use_existing',type=<class 'bool'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('use_existing')
    def __eq__(self, other):
        ...
    def __init__(self, use_existing: bool) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class IRConfirmResult:
    """
    Result from IRConfirmScreen (legacy).
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'confirmed': Field(name='confirmed',type=<class 'bool'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'black_threshold': Field(name='black_threshold',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'white_threshold': Field(name='white_threshold',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('confirmed', 'black_threshold', 'white_threshold')
    def __eq__(self, other):
        ...
    def __init__(self, confirmed: bool, black_threshold: float, white_threshold: float) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class IRDashboardResult:
    """
    Result from IRResultsDashboardScreen.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'confirmed': Field(name='confirmed',type=<class 'bool'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'sensors': Field(name='sensors',type=typing.List[raccoon.step.calibration.sensors.dataclasses.SensorCalibrationData],default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('confirmed', 'sensors')
    def __eq__(self, other):
        ...
    def __init__(self, confirmed: bool, sensors: typing.List[raccoon.step.calibration.sensors.dataclasses.SensorCalibrationData] = ...) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class IRSensorCalibrationResult:
    """
    Result of IR sensor calibration.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'white_threshold': Field(name='white_threshold',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'black_threshold': Field(name='black_threshold',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('white_threshold', 'black_threshold')
    def __eq__(self, other):
        ...
    def __init__(self, white_threshold: float, black_threshold: float) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class SensorCalibrationData:
    """
    Per-sensor calibration data collected during sampling.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'port': Field(name='port',type=<class 'int'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'samples': Field(name='samples',type=typing.List[float],default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'black_threshold': Field(name='black_threshold',type=<class 'float'>,default=0.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'white_threshold': Field(name='white_threshold',type=<class 'float'>,default=0.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'black_mean': Field(name='black_mean',type=<class 'float'>,default=0.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'white_mean': Field(name='white_mean',type=<class 'float'>,default=0.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'black_std': Field(name='black_std',type=<class 'float'>,default=0.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'white_std': Field(name='white_std',type=<class 'float'>,default=0.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('port', 'samples', 'black_threshold', 'white_threshold', 'black_mean', 'white_mean', 'black_std', 'white_std')
    black_mean: typing.ClassVar[float] = 0.0
    black_std: typing.ClassVar[float] = 0.0
    black_threshold: typing.ClassVar[float] = 0.0
    white_mean: typing.ClassVar[float] = 0.0
    white_std: typing.ClassVar[float] = 0.0
    white_threshold: typing.ClassVar[float] = 0.0
    def __eq__(self, other):
        ...
    def __init__(self, port: int, samples: typing.List[float] = ..., black_threshold: float = 0.0, white_threshold: float = 0.0, black_mean: float = 0.0, white_mean: float = 0.0, black_std: float = 0.0, white_std: float = 0.0) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
    @property
    def is_good(self) -> bool:
        ...
    @property
    def separation(self) -> float:
        ...
