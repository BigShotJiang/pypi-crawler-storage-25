"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: switch_set_step.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.calibration.sensors.switch_set_step import SwitchCalibrationSet
from raccoon.step.condition import StopCondition
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
__all__: list = ['SwitchCalibrationSetBuilder', 'switch_calibration_set']
class SwitchCalibrationSetBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for SwitchCalibrationSet. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def set_name(self, value: str):
        ...
def switch_calibration_set(set_name: str = 'default'):
    """
    
    Switch IR sensors to a named calibration set.
    
    Loads calibration data for the given set name from the calibration
    store and applies it to all registered IR sensors. Each sensor looks
    up its per-port calibration key (e.g. ``"transparent_port3"``) and
    sets its black/white thresholds accordingly.
    
    Use this to swap between surface-specific calibrations at runtime
    (e.g. switching from the default table surface to transparent objects).
    
    Args:
        set_name: Name of the calibration set to apply (e.g. ``"default"``, ``"transparent"``).
    
    Returns:
        A SwitchCalibrationSetBuilder (chainable via ``.set_name()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.calibration import switch_calibration_set
    
        # Switch to transparent calibration before scoring
        switch_calibration_set("transparent")
    """
_UNSET: object  # value = <object object>
