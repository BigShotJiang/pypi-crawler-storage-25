"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: step.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.calibration.sensors.step import CalibrateSensors
from raccoon.step.condition import StopCondition
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
import typing
__all__: list = ['CalibrateSensorsBuilder', 'calibrate_sensors']
class CalibrateSensorsBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for CalibrateSensors. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def allow_use_existing(self, value: bool):
        ...
    def calibration_sets(self, value: list[str] | None):
        ...
    def calibration_time(self, value: float):
        ...
def calibrate_sensors(calibration_time: float = 5.0, allow_use_existing: bool = True, calibration_sets: list[str] | None = None):
    """
    
    Calibrate IR sensors by sampling black and white surface readings.
    
    Guides the operator through sampling each IR sensor over calibration
    surfaces to establish black/white thresholds. The operator places the
    robot on the calibration surface and the step samples readings for the
    configured duration. Supports multiple named calibration sets (e.g.
    ``"default"`` and ``"transparent"``) for surface-specific thresholds.
    
    Args:
        calibration_time: Duration for calibration sampling in seconds.
        allow_use_existing: If ``True``, offer to reuse existing calibration values instead of re-sampling.
        calibration_sets: Named calibration sets to calibrate (e.g. ``["default", "transparent"]``). Defaults to ``["default"]``.
    
    Returns:
        A CalibrateSensorsBuilder (chainable via ``.calibration_time()``, ``.allow_use_existing()``, ``.calibration_sets()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.calibration import calibrate_sensors
    
        # Basic IR calibration
        calibrate_sensors()
    
        # Two surface sets with longer sampling
        calibrate_sensors(
            calibration_time=8.0,
            calibration_sets=["default", "transparent"],
        )
    """
_UNSET: object  # value = <object object>
