from __future__ import annotations
from raccoon.step.calibration.sensors.dataclasses import IRCalibrationChoice
from raccoon.ui.events import on_button_press
from raccoon.ui.events import on_change
from raccoon.ui.events import on_click
from raccoon.ui.events import on_keypad
from raccoon.ui.events import on_screen_tap
from raccoon.ui.events import on_slider
from raccoon.ui.events import on_submit
import raccoon.ui.screen
from raccoon.ui.screen import UIScreen
from raccoon.ui.screens.basic import ChoiceScreen
from raccoon.ui.screens.basic import ConfirmScreen
from raccoon.ui.screens.basic import MessageScreen
from raccoon.ui.screens.basic import ProgressScreen
from raccoon.ui.screens.basic import StatusScreen
from raccoon.ui.screens.basic import WaitForButtonScreen
from raccoon.ui.screens.distance import DistanceConfirmResult
from raccoon.ui.screens.distance import DistanceConfirmScreen
from raccoon.ui.screens.distance import DistanceDrivingScreen
from raccoon.ui.screens.distance import DistanceMeasureScreen
from raccoon.ui.screens.distance import DistancePrepareScreen
from raccoon.ui.screens.input import NumberInputResult
from raccoon.ui.screens.input import NumberInputScreen
from raccoon.ui.screens.input import SliderInputResult
from raccoon.ui.screens.input import SliderInputScreen
from raccoon.ui.screens.input import TextInputResult
from raccoon.ui.screens.input import TextInputScreen
from raccoon.ui.screens.wfl import WFLConfirmResult
from raccoon.ui.screens.wfl import WFLConfirmScreen
from raccoon.ui.screens.wfl import WFLMeasureResult
from raccoon.ui.screens.wfl import WFLMeasureScreen
from raccoon.ui.step import UIStep
import raccoon.ui.widgets
from raccoon.ui.widgets import AnimatedRobot
from raccoon.ui.widgets import Button
from raccoon.ui.widgets import CalibrationChart
from raccoon.ui.widgets import Card
from raccoon.ui.widgets import Center
from raccoon.ui.widgets import Checkbox
from raccoon.ui.widgets import CircularSlider
from raccoon.ui.widgets import Column
from raccoon.ui.widgets import DistanceBadge
from raccoon.ui.widgets import Divider
from raccoon.ui.widgets import Dropdown
from raccoon.ui.widgets import Expanded
from raccoon.ui.widgets import HintBox
from raccoon.ui.widgets import Icon
from raccoon.ui.widgets import LightBulb
from raccoon.ui.widgets import MeasuringTape
from raccoon.ui.widgets import NumericInput
from raccoon.ui.widgets import NumericKeypad
from raccoon.ui.widgets import ProgressSpinner
from raccoon.ui.widgets import PulsingArrow
from raccoon.ui.widgets import ResultsTable
from raccoon.ui.widgets import RobotDrivingAnimation
from raccoon.ui.widgets import Row
from raccoon.ui.widgets import SensorGraph
from raccoon.ui.widgets import SensorValue
from raccoon.ui.widgets import Slider
from raccoon.ui.widgets import Spacer
from raccoon.ui.widgets import Split
from raccoon.ui.widgets import StatusBadge
from raccoon.ui.widgets import StatusIcon
from raccoon.ui.widgets import Text
from raccoon.ui.widgets import TextInput
from raccoon.ui.widgets import Widget
import typing
__all__: list[str] = ['AnimatedRobot', 'Button', 'CalibrationChart', 'Card', 'Center', 'Checkbox', 'ChoiceScreen', 'CircularSlider', 'Column', 'ConfirmScreen', 'DistanceBadge', 'DistanceConfirmResult', 'DistanceConfirmScreen', 'DistanceDrivingScreen', 'DistanceMeasureScreen', 'DistancePrepareScreen', 'Divider', 'Dropdown', 'Expanded', 'HintBox', 'IRCalibrationChoice', 'IROverviewScreen', 'Icon', 'LightBulb', 'MeasuringTape', 'MessageScreen', 'NumberInputResult', 'NumberInputScreen', 'NumericInput', 'NumericKeypad', 'ProgressScreen', 'ProgressSpinner', 'PulsingArrow', 'ResultsTable', 'RobotDrivingAnimation', 'Row', 'SensorGraph', 'SensorValue', 'Slider', 'SliderInputResult', 'SliderInputScreen', 'Spacer', 'Split', 'StatusBadge', 'StatusIcon', 'StatusScreen', 'Text', 'TextInput', 'TextInputResult', 'TextInputScreen', 'UIScreen', 'UIStep', 'WFLConfirmResult', 'WFLConfirmScreen', 'WFLMeasureResult', 'WFLMeasureScreen', 'WaitForButtonScreen', 'Widget', 'on_button_press', 'on_change', 'on_click', 'on_keypad', 'on_screen_tap', 'on_slider', 'on_submit']
class IROverviewScreen(raccoon.ui.screen.UIScreen):
    """
    
    Overview screen for IR sensor black/white calibration.
    
    Shows current status and lets user choose to calibrate or use existing values.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[raccoon.step.calibration.sensors.dataclasses.IRCalibrationChoice])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    title: typing.ClassVar[str] = 'IR Sensor Calibration'
    def __init__(self, has_existing: bool = False, set_name: str = 'default'):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_press(self):
        ...
    def on_start(self):
        ...
    def on_use_existing(self):
        ...
