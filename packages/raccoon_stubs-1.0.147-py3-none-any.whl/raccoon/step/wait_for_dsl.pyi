"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: wait_for.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
from raccoon.step.wait_for import WaitFor
__all__: list = ['WaitForBuilder', 'wait_for']
class WaitForBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for WaitFor. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def condition(self, value: StopCondition):
        ...
def wait_for(condition: StopCondition = ...):
    """
    
    Block until a stop condition is satisfied.
    
    Initializes the condition, then polls it at 50 Hz until it returns
    True. This lets you reuse any composable ``StopCondition`` — sensor
    triggers, timers, distance thresholds, or combinations — as a
    standalone wait without an accompanying motion.
    
    Args:
        condition: A ``StopCondition`` instance (or composition) to wait for.  Supports the same ``|``, ``&``, and ``+`` operators as motion ``.until()`` clauses.
    
    Returns:
        A WaitForBuilder (chainable via ``.condition()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step import wait_for
        from raccoon.step.condition import on_black, after_seconds
    
        # Wait until the front-left IR sensor sees black
        wait_for(on_black(Defs.front.left))
    
        # Wait for black OR a 5-second timeout
        wait_for(on_black(sensor) | after_seconds(5))
    """
_UNSET: object  # value = <object object>
