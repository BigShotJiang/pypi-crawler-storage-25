"""
Convenience wrapper that parameterises a drive arc by heading change + arc distance.
"""
from __future__ import annotations
import math as math
from raccoon.step.annotation import dsl
from raccoon.step.motion.arc import DriveArc
import raccoon.step.motion.arc_dsl
from raccoon.step.motion.arc_dsl import DriveArcBuilder
__all__: list[str] = ['DriveArc', 'DriveArcBuilder', 'drive_arc_segment', 'dsl', 'math']
def drive_arc_segment(heading_degrees: float = ..., distance_cm: float = ..., speed: float = 1.0) -> raccoon.step.motion.arc_dsl.DriveArcBuilder:
    """
    Drive along a circular arc specified by heading change and travel distance.
    
    Instead of choosing a radius and arc angle separately, specify the desired
    heading change and how far the robot should travel along the arc.  The
    radius is computed automatically:
    ``radius = distance_cm / radians(|heading_degrees|)``.
    
    Positive heading_degrees = counter-clockwise (left), negative = clockwise
    (right) — same convention as ``drive_arc``.
    
    Args:
        heading_degrees: Desired heading change in degrees.
            Positive = left/CCW, negative = right/CW.
        distance_cm: Distance the robot travels along the arc path in
            centimeters (always positive).
        speed: Fraction of max speed, 0.0 to 1.0 (default 1.0).
    
    Raises:
        ValueError: If heading_degrees is zero (arc would have infinite radius)
            or distance_cm is not positive.
    
    Returns:
        A DriveArcBuilder configured with the computed radius and heading.
    
    Example::
    
        from raccoon.step.motion import drive_arc_segment
    
        # Gently curve left by 10 degrees over 25 cm of travel
        drive_arc_segment(heading_degrees=10, distance_cm=25)
    
        # Curve right by 30 degrees over 40 cm at half speed
        drive_arc_segment(heading_degrees=-30, distance_cm=40, speed=0.5)
    """
_UNSET: object  # value = <object object>
