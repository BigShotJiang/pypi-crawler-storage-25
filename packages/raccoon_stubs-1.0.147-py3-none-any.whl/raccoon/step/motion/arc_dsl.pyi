"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: arc.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
from raccoon.step.motion.arc import DriveArc
from raccoon.step.motion.arc import DriveArcLeft
from raccoon.step.motion.arc import DriveArcRight
from raccoon.step.motion.arc import StrafeArc
from raccoon.step.motion.arc import StrafeArcLeft
from raccoon.step.motion.arc import StrafeArcRight
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
__all__: list = ['DriveArcLeftBuilder', 'drive_arc_left', 'DriveArcRightBuilder', 'drive_arc_right', 'DriveArcBuilder', 'drive_arc', 'StrafeArcLeftBuilder', 'strafe_arc_left', 'StrafeArcRightBuilder', 'strafe_arc_right', 'StrafeArcBuilder', 'strafe_arc']
class DriveArcBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for DriveArc. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def degrees(self, value: float):
        ...
    def radius_cm(self, value: float):
        ...
    def speed(self, value: float):
        ...
class DriveArcLeftBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for DriveArcLeft. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def degrees(self, value: float):
        ...
    def radius_cm(self, value: float):
        ...
    def speed(self, value: float):
        ...
class DriveArcRightBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for DriveArcRight. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def degrees(self, value: float):
        ...
    def radius_cm(self, value: float):
        ...
    def speed(self, value: float):
        ...
class StrafeArcBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for StrafeArc. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def degrees(self, value: float):
        ...
    def radius_cm(self, value: float):
        ...
    def speed(self, value: float):
        ...
class StrafeArcLeftBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for StrafeArcLeft. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def degrees(self, value: float):
        ...
    def radius_cm(self, value: float):
        ...
    def speed(self, value: float):
        ...
class StrafeArcRightBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for StrafeArcRight. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def degrees(self, value: float):
        ...
    def radius_cm(self, value: float):
        ...
    def speed(self, value: float):
        ...
def drive_arc(radius_cm: float = ..., degrees: float = ..., speed: float = 1.0):
    """
    
    Drive along a circular arc with explicit direction.
    
    Positive degrees = counter-clockwise (left), negative = clockwise (right).
    
    Args:
        radius_cm: Turning radius in centimeters (always positive).
        degrees: Arc angle in degrees. Positive = left/CCW, negative = right/CW.
        speed: Fraction of max speed, 0.0 to 1.0 (default 1.0).
    
    Returns:
        A DriveArcBuilder (chainable via ``.radius_cm()``, ``.degrees()``, ``.speed()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motion import drive_arc
    
        # Left arc
        drive_arc(radius_cm=30, degrees=90)
    
        # Right arc
        drive_arc(radius_cm=30, degrees=-90)
    """
def drive_arc_left(radius_cm: float = ..., degrees: float = ..., speed: float = 1.0):
    """
    
    Drive along a circular arc curving to the left.
    
    The robot drives forward while simultaneously turning counter-clockwise,
    tracing a circular arc of the given radius. The motion completes when
    the robot has turned by the specified number of degrees.
    
    Args:
        radius_cm: Turning radius in centimeters (center of arc to robot center).
        degrees: Arc angle in degrees (how much the robot turns).
        speed: Fraction of max speed, 0.0 to 1.0 (default 1.0).
    
    Returns:
        A DriveArcLeftBuilder (chainable via ``.radius_cm()``, ``.degrees()``, ``.speed()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motion import drive_arc_left
    
        # Quarter-circle left with 30 cm radius
        drive_arc_left(radius_cm=30, degrees=90)
    
        # Gentle wide arc at half speed
        drive_arc_left(radius_cm=50, degrees=45, speed=0.5)
    """
def drive_arc_right(radius_cm: float = ..., degrees: float = ..., speed: float = 1.0):
    """
    
    Drive along a circular arc curving to the right.
    
    The robot drives forward while simultaneously turning clockwise,
    tracing a circular arc of the given radius. The motion completes when
    the robot has turned by the specified number of degrees.
    
    Args:
        radius_cm: Turning radius in centimeters (center of arc to robot center).
        degrees: Arc angle in degrees (how much the robot turns).
        speed: Fraction of max speed, 0.0 to 1.0 (default 1.0).
    
    Returns:
        A DriveArcRightBuilder (chainable via ``.radius_cm()``, ``.degrees()``, ``.speed()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motion import drive_arc_right
    
        # Quarter-circle right with 30 cm radius
        drive_arc_right(radius_cm=30, degrees=90)
    """
def strafe_arc(radius_cm: float = ..., degrees: float = ..., speed: float = 1.0):
    """
    
    Strafe along a circular arc with explicit direction.
    
    The robot strafes laterally while simultaneously turning, tracing a
    circular arc of the given radius. Positive degrees = counter-clockwise
    (left), negative = clockwise (right).
    
    Internally uses a profiled PID on heading and derives the lateral velocity
    from the angular velocity command: ``vy = |omega| * radius``. This produces
    coordinated acceleration along the arc.
    
    Prerequisites:
        Requires a mecanum or omni-wheel drivetrain capable of lateral motion.
    
    Args:
        radius_cm: Turning radius in centimeters (always positive).
        degrees: Arc angle in degrees. Positive = left/CCW, negative = right/CW.
        speed: Fraction of max speed, 0.0 to 1.0 (default 1.0).
    
    Returns:
        A StrafeArcBuilder (chainable via ``.radius_cm()``, ``.degrees()``, ``.speed()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motion import strafe_arc
    
        # Left strafe arc
        strafe_arc(radius_cm=30, degrees=90)
    
        # Right strafe arc
        strafe_arc(radius_cm=30, degrees=-90)
    """
def strafe_arc_left(radius_cm: float = ..., degrees: float = ..., speed: float = 1.0):
    """
    
    Strafe along a circular arc curving to the left.
    
    The robot strafes laterally (to the right) while simultaneously turning
    counter-clockwise, tracing a circular arc of the given radius. The motion
    completes when the robot has turned by the specified number of degrees.
    
    Internally uses a profiled PID on heading and derives the lateral velocity
    from the angular velocity command: ``vy = |omega| * radius``. This produces
    coordinated acceleration along the arc.
    
    Prerequisites:
        Requires a mecanum or omni-wheel drivetrain capable of lateral motion.
    
    Args:
        radius_cm: Turning radius in centimeters (center of arc to robot center).
        degrees: Arc angle in degrees (how much the robot turns).
        speed: Fraction of max speed, 0.0 to 1.0 (default 1.0).
    
    Returns:
        A StrafeArcLeftBuilder (chainable via ``.radius_cm()``, ``.degrees()``, ``.speed()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motion import strafe_arc_left
    
        # Quarter-circle strafe arc to the left with 30 cm radius
        strafe_arc_left(radius_cm=30, degrees=90)
    
        # Gentle wide strafe arc at half speed
        strafe_arc_left(radius_cm=50, degrees=45, speed=0.5)
    """
def strafe_arc_right(radius_cm: float = ..., degrees: float = ..., speed: float = 1.0):
    """
    
    Strafe along a circular arc curving to the right.
    
    The robot strafes laterally (to the left) while simultaneously turning
    clockwise, tracing a circular arc of the given radius. The motion
    completes when the robot has turned by the specified number of degrees.
    
    Internally uses a profiled PID on heading and derives the lateral velocity
    from the angular velocity command: ``vy = |omega| * radius``. This produces
    coordinated acceleration along the arc.
    
    Prerequisites:
        Requires a mecanum or omni-wheel drivetrain capable of lateral motion.
    
    Args:
        radius_cm: Turning radius in centimeters (center of arc to robot center).
        degrees: Arc angle in degrees (how much the robot turns).
        speed: Fraction of max speed, 0.0 to 1.0 (default 1.0).
    
    Returns:
        A StrafeArcRightBuilder (chainable via ``.radius_cm()``, ``.degrees()``, ``.speed()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motion import strafe_arc_right
    
        # Quarter-circle strafe arc to the right with 30 cm radius
        strafe_arc_right(radius_cm=30, degrees=90)
    """
_UNSET: object  # value = <object object>
