"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: at_distance.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
from raccoon.step.motion.at_distance import WaitUntilDistance
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
__all__: list = ['WaitUntilDistanceBuilder', 'wait_until_distance']
class WaitUntilDistanceBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for WaitUntilDistance. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def cm(self, value: float):
        ...
def wait_until_distance(cm: float = ...):
    """
    
    Wait until the robot has driven at least the given distance.
    
    Polls odometry straight-line distance from the origin at 100 Hz.
    Designed to run inside a ``parallel()`` branch alongside a drive step,
    enabling actions to trigger at specific distances during a drive.
    
    Args:
        cm: Distance threshold in centimeters.
    
    Returns:
        A WaitUntilDistanceBuilder (chainable via ``.cm()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step import parallel, seq
        from raccoon.step.motion import drive_forward, wait_until_distance
        from raccoon.step.servo import servo
    
        # Open a servo after driving 30 cm into a 50 cm drive
        parallel([
            drive_forward(50),
            seq([wait_until_distance(30), servo(claw, 90)]),
        ])
    """
_UNSET: object  # value = <object object>
