"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: turn.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
from raccoon.step.motion.turn import TurnLeft
from raccoon.step.motion.turn import TurnRight
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
__all__: list = ['TurnLeftBuilder', 'turn_left', 'TurnRightBuilder', 'turn_right']
class TurnLeftBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for TurnLeft. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def degrees(self, value: float):
        ...
    def speed(self, value: float):
        ...
    def until(self, value: StopCondition):
        ...
class TurnRightBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for TurnRight. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def degrees(self, value: float):
        ...
    def speed(self, value: float):
        ...
    def until(self, value: StopCondition):
        ...
def turn_left(degrees: float = None, speed: float = 1.0, until: StopCondition = None):
    """
    
    Turn left (counter-clockwise) with angle or condition-based termination.
    
    Uses a PID controller on the IMU heading to rotate the robot in place.
    The controller saturates output at the configured max angular rate,
    producing an implicit trapezoidal velocity profile.
    
    Args:
        degrees: Angle in degrees. Omit to use condition-only mode.
        speed: Fraction of max speed, 0.0 to 1.0.
        until: Stop condition for early termination (e.g., ``on_black(sensor)``). Can also be chained via the ``.until()`` builder method.
    
    Returns:
        A TurnLeftBuilder (chainable via ``.degrees()``, ``.speed()``, ``.until()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        turn_left(90)
        turn_left(speed=0.5).until(on_black(s))
    """
def turn_right(degrees: float = None, speed: float = 1.0, until: StopCondition = None):
    """
    
    Turn right (clockwise) with angle or condition-based termination.
    
    Uses a PID controller on the IMU heading to rotate the robot in place.
    The controller saturates output at the configured max angular rate,
    producing an implicit trapezoidal velocity profile.
    
    Args:
        degrees: Angle in degrees. Omit to use condition-only mode.
        speed: Fraction of max speed, 0.0 to 1.0.
        until: Stop condition for early termination (e.g., ``on_black(sensor)``). Can also be chained via the ``.until()`` builder method.
    
    Returns:
        A TurnRightBuilder (chainable via ``.degrees()``, ``.speed()``, ``.until()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        turn_right(90)
        turn_right(speed=0.5).until(on_black(s))
    """
_UNSET: object  # value = <object object>
