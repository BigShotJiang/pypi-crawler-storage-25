"""

Base class for motion steps with a unified fixed-rate update loop.

All motion steps share the same async timing pattern: dt calculation, near-zero
dt skip, sleep, and hard_stop cleanup. MotionStep owns this loop and exposes
on_start / on_update / on_stop lifecycle hooks for subclasses.
"""
from __future__ import annotations
import asyncio as asyncio
import dataclasses
from dataclasses import dataclass
import raccoon.step.base
from raccoon.step.base import Step
import typing
__all__: list[str] = ['MotionLoopStats', 'MotionStep', 'Step', 'asyncio', 'dataclass']
class MotionLoopStats:
    """
    Summary of the fixed-rate loop timing observed during one motion step.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'iterations': Field(name='iterations',type=<class 'int'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'elapsed_s': Field(name='elapsed_s',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'avg_hz': Field(name='avg_hz',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'min_dt_ms': Field(name='min_dt_ms',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'max_dt_ms': Field(name='max_dt_ms',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('iterations', 'elapsed_s', 'avg_hz', 'min_dt_ms', 'max_dt_ms')
    def __eq__(self, other):
        ...
    def __init__(self, iterations: int, elapsed_s: float, avg_hz: float, min_dt_ms: float, max_dt_ms: float) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class MotionStep(raccoon.step.base.Step):
    """
    Base class for all motion steps. Handles the fixed-rate update loop.
    """
    hz: typing.ClassVar[int] = 100
    def _execute_step(self, robot: GenericRobot) -> None:
        ...
    def on_start(self, robot: GenericRobot) -> None:
        """
        Called once before the loop. Override to set up motion/velocity.
        """
    def on_stop(self, robot: GenericRobot) -> None:
        """
        Called after loop exits. Default: hard_stop.
        """
    def on_update(self, robot: GenericRobot, dt: float) -> bool:
        """
        Called each cycle with dt in seconds. Return True when motion is complete.
        """
    def required_resources(self) -> frozenset[str]:
        ...
