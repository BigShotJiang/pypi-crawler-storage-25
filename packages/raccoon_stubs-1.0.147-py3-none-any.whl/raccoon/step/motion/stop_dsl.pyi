"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: stop.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
from raccoon.step.motion.stop import Stop
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
__all__: list = ['StopBuilder', 'stop']
class StopBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for Stop. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def hard(self, value: bool):
        ...
def stop(hard: bool = True):
    """
    
    Stop all drive motors immediately.
    
    Use this between motion sequences or at the end of a mission
    to ensure the robot is stationary.
    
    Args:
        hard: If ``True`` (default), immediately zero motor output. If ``False``, decelerate smoothly using the drive controller.
    
    Returns:
        A StopBuilder (chainable via ``.hard()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step.motion import drive_forward, stop
    
        # Drive forward then stop
        seq([drive_forward(50), stop()])
    """
_UNSET: object  # value = <object object>
