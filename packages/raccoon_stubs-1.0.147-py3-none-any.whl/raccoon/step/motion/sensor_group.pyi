"""

SensorGroup: pre-bind IR sensor pairs with default threshold, speed, and
PID gains so mission code doesn't repeat them on every call.

Usage::

    from raccoon.step.motion.sensor_group import SensorGroup

    front = SensorGroup(
        left=front_left_ir,
        right=front_right_ir,
    )

    # In a mission:
    front.lineup_on_black()
    front.drive_until_black()
    front.drive_over_line()
    front.follow_right_edge(cm=125)

    # Override defaults per-call:
    front.lineup_on_black(threshold=0.5)
    front.strafe_left_until_black(speed=0.3, threshold=0.3)

    # Single-sensor access for raw builder calls:
    strafe_left(speed=0.3).until(on_black(front.right))
"""
from __future__ import annotations
from raccoon.step.condition import on_black
from raccoon.step.condition import on_white
__all__: list[str] = ['SensorGroup', 'on_black', 'on_white']
class SensorGroup:
    """
    A named sensor pair with pre-bound defaults for threshold, speed, and PID.
    
    Provides convenience methods for common sensor-triggered operations:
    lineup, drive-until, strafe-until, and line-following. All methods
    return Step builders that can be used directly in ``seq([...])``.
    
    Args:
        left: IR sensor mounted on the left side (or None).
        right: IR sensor mounted on the right side (or None).
        threshold: Default confidence threshold (0.0--1.0) for black/white
            detection. Defaults to 0.7.
        speed: Default motion speed fraction (0.0--1.0). Defaults to 1.0.
        follow_speed: Default speed for line-following. Defaults to 0.8.
        follow_kp: Proportional gain for line-follow PID. Defaults to 0.5.
        follow_ki: Integral gain for line-follow PID. Defaults to 0.02.
        follow_kd: Derivative gain for line-follow PID. Defaults to 0.0.
    """
    def __init__(self, left = None, right = None, threshold: float = 0.7, speed: float = 1.0, follow_speed: float = 0.8, follow_kp: float = 0.5, follow_ki: float = 0.02, follow_kd: float = 0.0):
        ...
    def _s(self, override):
        ...
    def _t(self, override):
        ...
    def backward_lineup_on_black(self):
        ...
    def backward_lineup_on_white(self):
        ...
    def drive_backward_until_black(self, sensor = None, speed = None, threshold = None):
        ...
    def drive_over_line(self, speed = None, threshold = None):
        """
        Drive forward through black then white (crosses one line).
        """
    def drive_until_black(self, speed = None, threshold = None):
        ...
    def drive_until_white(self, speed = None, threshold = None):
        ...
    def follow_right_edge(self, cm, speed = None):
        ...
    def follow_right_until_black(self, speed = None):
        ...
    def lineup(self, target = None, threshold = None):
        ...
    def lineup_on_black(self, threshold = None):
        ...
    def lineup_on_white(self, threshold = None):
        ...
    def strafe_left_until_black(self, sensor = None, speed = None, threshold = None):
        ...
    def strafe_right_until_black(self, sensor = None, speed = None, threshold = None):
        ...
    def strafe_right_until_white(self, sensor = None, speed = None, threshold = None):
        ...
def _any_condition(factory, *sensors, threshold = 0.7):
    """
    Compose stop conditions for multiple sensors with OR.
    """
