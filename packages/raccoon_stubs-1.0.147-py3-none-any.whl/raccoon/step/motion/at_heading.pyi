"""

Wait until the robot has turned a certain number of degrees from its starting heading.

Designed to run inside a parallel() branch alongside a turn step:

    parallel(
        turn_left(90),
        seq([wait_until_degrees(45), servo_open()]),
    )

Multiple heading-triggered actions:

    parallel(
        turn_left(90),
        seq([wait_until_degrees(30), arm_lower()]),
        seq([wait_until_degrees(60), servo_open()]),
        seq([wait_until_degrees(85), servo_close()]),
    )

Polls odometry heading at 100Hz.  Because TurnMotion.start() resets odometry,
the heading is measured from the start of the concurrent turn step.
"""
from __future__ import annotations
import asyncio as asyncio
import math as math
import raccoon.step.annotation
from raccoon.step.annotation import dsl_step
import raccoon.step.base
from raccoon.step.base import Step
import typing
__all__: list[str] = ['Step', 'WaitUntilDegrees', 'asyncio', 'dsl_step', 'math']
class WaitUntilDegrees(raccoon.step.base.Step):
    """
    Wait until the robot has turned at least the given number of degrees.
    
    Polls odometry heading at 100 Hz and compares the absolute heading change
    against the threshold.  Designed to run inside a ``parallel()`` branch
    alongside a turn step, enabling actions to trigger at specific angles
    during a turn.
    
    Args:
        degrees: Heading-change threshold in degrees (always positive).
    
    Example::
    
        from raccoon.step import parallel, seq
        from raccoon.step.motion import turn_left, wait_until_degrees
        from raccoon.step.servo import servo
    
        # Open a servo after turning 45° into a 90° turn
        parallel([
            turn_left(90),
            seq([wait_until_degrees(45), servo(claw, 90)]),
        ])
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='WaitUntilDegrees', tags=('motion', 'wait'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'WaitUntilDegrees'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'wait')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'wait')
    def __init__(self, degrees: float) -> None:
        ...
    def _execute_step(self, robot: GenericRobot) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
