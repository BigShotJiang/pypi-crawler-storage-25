"""

Wall alignment step with IMU-based bump detection.

Drives toward a wall at constant velocity without heading correction.
Uses the IMU's gravity-compensated linear acceleration to detect the
moment of impact, then optionally continues pushing for a short settle
period so the robot can rotate flush against the wall surface.
"""
from __future__ import annotations
import asyncio as asyncio
import dataclasses
from dataclasses import dataclass
import enum
from enum import Enum
import math as math
import raccoon.foundation
from raccoon.foundation import ChassisVelocity
from raccoon.hal import IMU
import raccoon.step.annotation
from raccoon.step.annotation import dsl
from raccoon.step.annotation import dsl_step
import raccoon.step.motion.motion_step
from raccoon.step.motion.motion_step import MotionStep
import typing
__all__: list[str] = ['BumpResult', 'ChassisVelocity', 'Enum', 'IMU', 'MotionStep', 'WallAlign', 'WallAlignBackward', 'WallAlignForward', 'WallAlignStrafeLeft', 'WallAlignStrafeRight', 'WallDirection', 'asyncio', 'dataclass', 'dsl', 'dsl_step', 'math']
class BumpResult:
    """
    Information about a detected wall impact.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'accel_magnitude': Field(name='accel_magnitude',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'impact_angle_deg': Field(name='impact_angle_deg',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'heading_correction_deg': Field(name='heading_correction_deg',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('accel_magnitude', 'impact_angle_deg', 'heading_correction_deg')
    def __eq__(self, other):
        ...
    def __init__(self, accel_magnitude: float, impact_angle_deg: float, heading_correction_deg: float) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class WallAlign(raccoon.step.motion.motion_step.MotionStep):
    """
    
    Drive into a wall using IMU bump detection, then settle flush.
    
    The robot drives at constant velocity without heading correction.
    When the horizontal linear acceleration exceeds a threshold (indicating
    a collision), it records the impact and continues pushing for a settle
    period to let the chassis rotate flush against the wall.
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'WallAlign'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    def __init__(self, direction: WallDirection, speed: float, accel_threshold: float, settle_duration: float, max_duration: float, grace_period: float):
        ...
    def _generate_signature(self) -> str:
        ...
    def _get_velocity(self) -> raccoon.foundation.ChassisVelocity:
        ...
    def on_start(self, robot: GenericRobot) -> None:
        ...
    def on_update(self, robot: GenericRobot, dt: float) -> bool:
        ...
class WallAlignBackward(WallAlign):
    """
    Drive backward into a wall and align the back of the robot.
    
    Apply constant backward velocity without heading correction so the robot
    naturally rotates flush against the wall surface.  Uses IMU bump
    detection to know when the wall has been reached.
    
    Args:
        speed: Drive speed in m/s (default 1.0).
        accel_threshold: Minimum XY linear-acceleration magnitude in m/s²
            to classify as a bump (default 0.5).
        settle_duration: Seconds to keep pushing after impact (default 0.2).
        max_duration: Safety timeout in seconds (default 5.0).
        grace_period: Seconds to ignore acceleration at start (default 0.3).
    
    Returns:
        A WallAlignBackward step driving backward with bump detection.
    
    Example::
    
        from raccoon.step.motion import wall_align_backward, drive_backward
    
        # Drive to the wall in reverse, then align against it
        seq([drive_backward(30), wall_align_backward()])
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='WallAlignBackward', tags=('motion', 'wall'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'WallAlignBackward'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'wall')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'wall')
    def __init__(self, speed: float = 1.0, accel_threshold: float = 0.5, settle_duration: float = 0.2, max_duration: float = 5.0, grace_period: float = 0.3):
        ...
    def _generate_signature(self) -> str:
        ...
class WallAlignForward(WallAlign):
    """
    Drive forward into a wall and align the front of the robot.
    
    Apply constant forward velocity without heading correction so the robot
    naturally rotates flush against the wall surface.  The step monitors
    gravity-compensated linear acceleration from the IMU and stops once a
    collision spike is detected followed by a short settle period.
    
    The grace period prevents false triggers from the initial acceleration
    transient when the robot starts moving.
    
    After the step completes, ``step.bump_result`` contains the impact
    magnitude, estimated wall misalignment angle, and the heading
    correction applied during the settle push.
    
    Args:
        speed: Drive speed in m/s (default 1.0).
        accel_threshold: Minimum XY linear-acceleration magnitude in m/s²
            to classify as a bump (default 0.5).  Lower values are more
            sensitive but may false-trigger on rough surfaces.
        settle_duration: Seconds to keep pushing after the bump is detected,
            letting the chassis rotate flush (default 0.2).
        max_duration: Safety timeout in seconds — the step finishes even if
            no bump is detected (default 5.0).
        grace_period: Seconds to ignore acceleration after starting, so the
            robot's own acceleration doesn't trigger detection (default 0.3).
    
    Returns:
        A WallAlignForward step driving forward with bump detection.
    
    Example::
    
        from raccoon.step.motion import wall_align_forward, drive_forward
    
        # Drive near the wall, then bump-align against it
        seq([drive_forward(30), wall_align_forward()])
    
        # More sensitive detection at slower speed
        wall_align_forward(speed=0.3, accel_threshold=0.3)
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='WallAlignForward', tags=('motion', 'wall'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'WallAlignForward'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'wall')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'wall')
    def __init__(self, speed: float = 1.0, accel_threshold: float = 0.5, settle_duration: float = 0.2, max_duration: float = 5.0, grace_period: float = 0.3):
        ...
    def _generate_signature(self) -> str:
        ...
class WallAlignStrafeLeft(WallAlign):
    """
    Strafe left into a wall and align the left side of the robot.
    
    Apply constant leftward velocity without heading correction so the robot
    naturally rotates flush against the wall surface.  Uses IMU bump
    detection.  Requires a mecanum or omni drivetrain capable of lateral
    movement.
    
    Args:
        speed: Strafe speed in m/s (default 0.5).
        accel_threshold: Minimum XY linear-acceleration magnitude in m/s²
            to classify as a bump (default 0.5).
        settle_duration: Seconds to keep pushing after impact (default 0.2).
        max_duration: Safety timeout in seconds (default 5.0).
        grace_period: Seconds to ignore acceleration at start (default 0.3).
    
    Returns:
        A WallAlignStrafeLeft step strafing left with bump detection.
    
    Example::
    
        from raccoon.step.motion import wall_align_strafe_left
    
        # Strafe-align the left side against a wall
        wall_align_strafe_left(speed=0.4)
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='WallAlignStrafeLeft', tags=('motion', 'wall'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'WallAlignStrafeLeft'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'wall')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'wall')
    def __init__(self, speed: float = 0.5, accel_threshold: float = 0.5, settle_duration: float = 0.2, max_duration: float = 5.0, grace_period: float = 0.3):
        ...
    def _generate_signature(self) -> str:
        ...
class WallAlignStrafeRight(WallAlign):
    """
    Strafe right into a wall and align the right side of the robot.
    
    Apply constant rightward velocity without heading correction so the robot
    naturally rotates flush against the wall surface.  Uses IMU bump
    detection.  Requires a mecanum or omni drivetrain capable of lateral
    movement.
    
    Args:
        speed: Strafe speed in m/s (default 0.5).
        accel_threshold: Minimum XY linear-acceleration magnitude in m/s²
            to classify as a bump (default 0.5).
        settle_duration: Seconds to keep pushing after impact (default 0.2).
        max_duration: Safety timeout in seconds (default 5.0).
        grace_period: Seconds to ignore acceleration at start (default 0.3).
    
    Returns:
        A WallAlignStrafeRight step strafing right with bump detection.
    
    Example::
    
        from raccoon.step.motion import wall_align_strafe_right
    
        # Strafe-align the right side against a wall
        wall_align_strafe_right(speed=0.4)
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='WallAlignStrafeRight', tags=('motion', 'wall'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'WallAlignStrafeRight'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'wall')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'wall')
    def __init__(self, speed: float = 0.5, accel_threshold: float = 0.5, settle_duration: float = 0.2, max_duration: float = 5.0, grace_period: float = 0.3):
        ...
    def _generate_signature(self) -> str:
        ...
class WallDirection(enum.Enum):
    """
    Direction to drive into a wall.
    """
    BACKWARD: typing.ClassVar[WallDirection]  # value = <WallDirection.BACKWARD: 'backward'>
    FORWARD: typing.ClassVar[WallDirection]  # value = <WallDirection.FORWARD: 'forward'>
    STRAFE_LEFT: typing.ClassVar[WallDirection]  # value = <WallDirection.STRAFE_LEFT: 'strafe_left'>
    STRAFE_RIGHT: typing.ClassVar[WallDirection]  # value = <WallDirection.STRAFE_RIGHT: 'strafe_right'>
def _normalize_angle(a: float) -> float:
    """
    Wrap angle to (-180, 180] degrees.
    """
_EXPECTED_DECEL_ANGLE: dict  # value = {<WallDirection.FORWARD: 'forward'>: 3.141592653589793, <WallDirection.BACKWARD: 'backward'>: 0.0, <WallDirection.STRAFE_LEFT: 'strafe_left'>: 1.5707963267948966, <WallDirection.STRAFE_RIGHT: 'strafe_right'>: -1.5707963267948966}
