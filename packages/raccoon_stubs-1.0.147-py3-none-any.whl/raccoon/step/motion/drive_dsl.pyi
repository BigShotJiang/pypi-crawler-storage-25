"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: drive.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
from raccoon.step.motion.drive import DriveBackward
from raccoon.step.motion.drive import DriveForward
from raccoon.step.motion.drive import StrafeLeft
from raccoon.step.motion.drive import StrafeRight
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
__all__: list = ['DriveForwardBuilder', 'drive_forward', 'DriveBackwardBuilder', 'drive_backward', 'StrafeLeftBuilder', 'strafe_left', 'StrafeRightBuilder', 'strafe_right']
class DriveBackwardBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for DriveBackward. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def cm(self, value: float):
        ...
    def speed(self, value: float):
        ...
    def until(self, value: StopCondition):
        ...
class DriveForwardBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for DriveForward. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def cm(self, value: float):
        ...
    def speed(self, value: float):
        ...
    def until(self, value: StopCondition):
        ...
class StrafeLeftBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for StrafeLeft. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def cm(self, value: float):
        ...
    def speed(self, value: float):
        ...
    def until(self, value: StopCondition):
        ...
class StrafeRightBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for StrafeRight. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def cm(self, value: float):
        ...
    def speed(self, value: float):
        ...
    def until(self, value: StopCondition):
        ...
def drive_backward(cm: float = None, speed: float = 1.0, until: StopCondition = None):
    """
    
    Drive backward with distance or condition-based termination.
    
    Identical to ``drive_forward()`` but in reverse. Uses profiled PID
    motion control while maintaining heading via IMU feedback.
    
    Requires ``calibrate_distance()`` for distance-based mode.
    
    Args:
        cm: Distance in centimeters. Omit to use condition-only mode.
        speed: Fraction of max speed, 0.0 to 1.0.
        until: Stop condition for early termination (e.g., ``on_black(sensor)``). Can also be chained via the ``.until()`` builder method.
    
    Returns:
        A DriveBackwardBuilder (chainable via ``.cm()``, ``.speed()``, ``.until()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        drive_backward(20)
        drive_backward(speed=0.5).until(on_white(s))
    """
def drive_forward(cm: float = None, speed: float = 1.0, until: StopCondition = None):
    """
    
    Drive forward with distance or condition-based termination.
    
    Uses profiled PID motion control with a trapezoidal velocity profile.
    The robot accelerates, cruises, and decelerates while maintaining
    heading via IMU feedback. In condition-only mode the robot drives at
    constant speed until the condition triggers.
    
    Requires ``calibrate_distance()`` for distance-based mode.
    
    Args:
        cm: Distance in centimeters. Omit to use condition-only mode.
        speed: Fraction of max speed, 0.0 to 1.0.
        until: Stop condition for early termination (e.g., ``on_black(sensor)``). Can also be chained via the ``.until()`` builder method.
    
    Returns:
        A DriveForwardBuilder (chainable via ``.cm()``, ``.speed()``, ``.until()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        drive_forward(25)                            # 25 cm
        drive_forward(speed=0.8).until(on_black(s))  # until sensor
    """
def strafe_left(cm: float = None, speed: float = 1.0, until: StopCondition = None):
    """
    
    Strafe left with distance or condition-based termination.
    
    Requires a mecanum or omni-wheel drivetrain. The robot moves
    laterally to the left while maintaining heading via IMU feedback.
    
    Args:
        cm: Distance in centimeters. Omit to use condition-only mode.
        speed: Fraction of max speed, 0.0 to 1.0.
        until: Stop condition for early termination (e.g., ``on_black(sensor)``). Can also be chained via the ``.until()`` builder method.
    
    Returns:
        A StrafeLeftBuilder (chainable via ``.cm()``, ``.speed()``, ``.until()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        strafe_left(15)
        strafe_left(speed=0.6).until(on_black(s))
    """
def strafe_right(cm: float = None, speed: float = 1.0, until: StopCondition = None):
    """
    
    Strafe right with distance or condition-based termination.
    
    Requires a mecanum or omni-wheel drivetrain. The robot moves
    laterally to the right while maintaining heading via IMU feedback.
    
    Args:
        cm: Distance in centimeters. Omit to use condition-only mode.
        speed: Fraction of max speed, 0.0 to 1.0.
        until: Stop condition for early termination (e.g., ``on_black(sensor)``). Can also be chained via the ``.until()`` builder method.
    
    Returns:
        A StrafeRightBuilder (chainable via ``.cm()``, ``.speed()``, ``.until()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        strafe_right(15)
        strafe_right(speed=0.6).until(on_black(s))
    """
_UNSET: object  # value = <object object>
