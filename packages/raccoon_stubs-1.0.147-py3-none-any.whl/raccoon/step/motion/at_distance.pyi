"""

Wait until the robot has driven a certain distance from origin.

Designed to run inside a parallel() branch alongside a drive step:

    parallel(
        drive_forward(50),
        seq([wait_until_distance(30), servo_open()]),
    )

Multiple distance-triggered actions:

    parallel(
        drive_forward(50),
        seq([wait_until_distance(20), arm_lower()]),
        seq([wait_until_distance(30), servo_open()]),
        seq([wait_until_distance(45), servo_close()]),
    )

Polls odometry at 100Hz.  Because LinearMotion.start() resets odometry,
the distance is measured from the start of the concurrent drive step.
"""
from __future__ import annotations
import asyncio as asyncio
import raccoon.step.annotation
from raccoon.step.annotation import dsl_step
import raccoon.step.base
from raccoon.step.base import Step
import typing
__all__: list[str] = ['Step', 'WaitUntilDistance', 'asyncio', 'dsl_step']
class WaitUntilDistance(raccoon.step.base.Step):
    """
    Wait until the robot has driven at least the given distance.
    
    Polls odometry straight-line distance from the origin at 100 Hz.
    Designed to run inside a ``parallel()`` branch alongside a drive step,
    enabling actions to trigger at specific distances during a drive.
    
    Args:
        cm: Distance threshold in centimeters.
    
    Example::
    
        from raccoon.step import parallel, seq
        from raccoon.step.motion import drive_forward, wait_until_distance
        from raccoon.step.servo import servo
    
        # Open a servo after driving 30 cm into a 50 cm drive
        parallel([
            drive_forward(50),
            seq([wait_until_distance(30), servo(claw, 90)]),
        ])
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='WaitUntilDistance', tags=('motion', 'wait'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'WaitUntilDistance'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'wait')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'wait')
    def __init__(self, cm: float) -> None:
        ...
    def _execute_step(self, robot: GenericRobot) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
