"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: at_heading.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
from raccoon.step.motion.at_heading import WaitUntilDegrees
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
__all__: list = ['WaitUntilDegreesBuilder', 'wait_until_degrees']
class WaitUntilDegreesBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for WaitUntilDegrees. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def degrees(self, value: float):
        ...
def wait_until_degrees(degrees: float = ...):
    """
    
    Wait until the robot has turned at least the given number of degrees.
    
    Polls odometry heading at 100 Hz and compares the absolute heading change
    against the threshold.  Designed to run inside a ``parallel()`` branch
    alongside a turn step, enabling actions to trigger at specific angles
    during a turn.
    
    Args:
        degrees: Heading-change threshold in degrees (always positive).
    
    Returns:
        A WaitUntilDegreesBuilder (chainable via ``.degrees()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step import parallel, seq
        from raccoon.step.motion import turn_left, wait_until_degrees
        from raccoon.step.servo import servo
    
        # Open a servo after turning 45° into a 90° turn
        parallel([
            turn_left(90),
            seq([wait_until_degrees(45), servo(claw, 90)]),
        ])
    """
_UNSET: object  # value = <object object>
