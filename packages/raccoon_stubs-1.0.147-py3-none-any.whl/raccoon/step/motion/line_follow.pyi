"""

Line following using IR sensors.

This module provides steps for following lines using one or two IR sensors
with PID-based steering control.

Two families of steps are available:

1. **Profiled line follow** (``FollowLine``, ``FollowLineSingle``, etc.) —
   built on ``LinearMotion`` for trapezoidal-profiled distance control along
   a single axis.

2. **Directional line follow** (``DirectionalFollowLine``,
   ``StrafeFollowLine``, etc.) — uses direct ``ChassisVelocity`` control
   with independent heading and strafe speed inputs, allowing line following
   while strafing, driving diagonally, or any combination.

All steps support composable ``StopCondition`` via the ``.until()`` builder
method, enabling patterns like::

    follow_line(left, right, speed=0.5).until(on_black(left) & on_black(right))
    follow_line_single(sensor, speed=0.4).until(on_black(stop_sensor))
"""
from __future__ import annotations
import dataclasses
from dataclasses import dataclass
import enum
from enum import Enum
import math as math
from raccoon.foundation import ChassisVelocity
from raccoon.foundation import PidConfig
from raccoon.foundation import PidController
from raccoon.motion import LinearAxis
from raccoon.motion import LinearMotion
from raccoon.motion import LinearMotionConfig
import raccoon.sensor_ir
from raccoon.sensor_ir import IRSensor
import raccoon.step.annotation
from raccoon.step.annotation import dsl
from raccoon.step.annotation import dsl_step
from raccoon.step.condition import StopCondition
import raccoon.step.model
from raccoon.step.model import SimulationStep
from raccoon.step.model import SimulationStepDelta
import raccoon.step.motion.motion_step
from raccoon.step.motion.motion_step import MotionStep
import typing
__all__: list[str] = ['ChassisVelocity', 'DirectionalFollowLine', 'DirectionalFollowLineSingle', 'DirectionalLineFollow', 'DirectionalLineFollowConfig', 'DirectionalSingleLineFollow', 'DirectionalSingleLineFollowConfig', 'Enum', 'FollowLine', 'FollowLineSingle', 'IRSensor', 'LineFollow', 'LineFollowConfig', 'LineSide', 'LinearAxis', 'LinearMotion', 'LinearMotionConfig', 'MotionStep', 'PidConfig', 'PidController', 'SimulationStep', 'SimulationStepDelta', 'SingleLineFollowConfig', 'SingleSensorLineFollow', 'StopCondition', 'StrafeFollowLine', 'StrafeFollowLineSingle', 'dataclass', 'dsl', 'dsl_step', 'math']
class DirectionalFollowLine(DirectionalLineFollow):
    """
    Follow a line with independent heading and strafe speeds.
    
    Drive along a line using any combination of forward and lateral velocity
    while a PID controller steers the robot via angular velocity.  The error
    signal is the difference between the left and right sensors'
    ``probabilityOfBlack()`` readings.  Distance is tracked via odometry as
    the euclidean distance from the start position.
    
    Unlike ``FollowLine`` which only drives forward, this step accepts both
    ``heading_speed`` (forward/backward) and ``strafe_speed`` (left/right)
    as independent fractions of max velocity, enabling line following while
    strafing or driving diagonally.
    
    Supports distance-based termination, composable ``StopCondition`` via
    ``.until()``, or both (whichever triggers first). At least one of
    ``distance_cm`` or ``until`` must be provided.
    
    Both sensors must be calibrated (white/black thresholds set) before use.
    Requires a mecanum or omni-wheel drivetrain if ``strafe_speed`` is
    nonzero.
    
    Args:
        left_sensor: Left IR sensor instance, positioned to the left of the
            line.
        right_sensor: Right IR sensor instance, positioned to the right of
            the line.
        distance_cm: Distance to follow in centimeters.  The step finishes
            when this euclidean distance has been traveled. Optional if
            ``until`` is provided.
        heading_speed: Forward/backward speed as a fraction of max velocity
            (-1.0 to 1.0).  Positive = forward, negative = backward.
            Default 0.0.
        strafe_speed: Lateral speed as a fraction of max velocity (-1.0 to
            1.0).  Positive = right, negative = left.  Default 0.0.
        kp: Proportional gain for steering PID.  Default 0.75.
        ki: Integral gain for steering PID.  Default 0.0.
        kd: Derivative gain for steering PID.  Default 0.5.
        until: Composable stop condition. Can also be chained via the
            ``.until()`` builder method.
    
    Returns:
        A ``DirectionalFollowLine`` step.
    
    Example::
    
        from raccoon.step.motion import DirectionalFollowLine
        from raccoon.step.condition import on_black
    
        # Strafe right while following a line for 50 cm
        directional_follow_line(left, right, distance_cm=50, strafe_speed=0.5)
    
        # Follow until both sensors see black
        directional_follow_line(left, right, strafe_speed=0.4).until(
            on_black(left) & on_black(right)
        )
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='DirectionalFollowLine', tags=('motion', 'line-follow'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'DirectionalFollowLine'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'line-follow')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'line-follow')
    def __init__(self, left_sensor: raccoon.sensor_ir.IRSensor, right_sensor: raccoon.sensor_ir.IRSensor, distance_cm: float | None = None, heading_speed: float = 0.0, strafe_speed: float = 0.0, kp: float = 0.4, ki: float = 0.0, kd: float = 0.1, until: raccoon.step.condition.StopCondition | None = None) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class DirectionalFollowLineSingle(DirectionalSingleLineFollow):
    """
    Follow a line edge with a single sensor and independent heading/strafe speeds.
    
    The sensor tracks the boundary between the line and the background, where
    ``probabilityOfBlack()`` is approximately 0.5.  The ``side`` parameter
    selects which edge to track.  The PID output controls angular velocity
    while heading and strafe velocities are set independently.
    
    Supports distance-based termination, composable ``StopCondition`` via
    ``.until()``, or both (whichever triggers first). At least one of
    ``distance_cm`` or ``until`` must be provided.
    
    The sensor must be calibrated (white/black thresholds set) before use.
    Requires a mecanum or omni-wheel drivetrain if ``strafe_speed`` is
    nonzero.
    
    Args:
        sensor: IR sensor for edge tracking.
        distance_cm: Distance to follow in centimeters. Optional if
            ``until`` is provided.
        heading_speed: Forward/backward speed fraction (-1.0 to 1.0).
            Default 0.0.
        strafe_speed: Lateral speed fraction (-1.0 to 1.0).  Default 0.0.
        side: Which edge of the line to track.  Default ``LineSide.LEFT``.
        kp: Proportional gain for steering PID.  Default 1.0.
        ki: Integral gain for steering PID.  Default 0.0.
        kd: Derivative gain for steering PID.  Default 0.3.
        until: Composable stop condition. Can also be chained via the
            ``.until()`` builder method.
    
    Returns:
        A ``DirectionalFollowLineSingle`` step.
    
    Example::
    
        from raccoon.step.motion import DirectionalFollowLineSingle, LineSide
        from raccoon.step.condition import on_black
    
        # Strafe right while tracking the left edge for 50 cm
        directional_follow_line_single(front_ir, distance_cm=50, strafe_speed=0.4)
    
        # Follow until stop sensor sees black
        directional_follow_line_single(front_ir, strafe_speed=0.4).until(on_black(stop))
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='DirectionalFollowLineSingle', tags=('motion', 'line-follow'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'DirectionalFollowLineSingle'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'line-follow')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'line-follow')
    def __init__(self, sensor: raccoon.sensor_ir.IRSensor, distance_cm: float | None = None, heading_speed: float = 0.0, strafe_speed: float = 0.0, side: LineSide = ..., kp: float = 0.4, ki: float = 0.0, kd: float = 0.1, until: raccoon.step.condition.StopCondition | None = None) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class DirectionalLineFollow(raccoon.step.motion.motion_step.MotionStep):
    """
    Follow a line with independent heading and strafe velocity components.
    
    Uses direct ``ChassisVelocity`` control instead of ``LinearMotion``,
    enabling line following while strafing, driving diagonally, or any
    combination.  A PID controller computes angular velocity from the
    difference between the left and right sensors' ``probabilityOfBlack()``
    readings.
    
    Distance is tracked via odometry as euclidean distance from the start
    position.  Supports distance-based termination, composable
    ``StopCondition``, or both.
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'DirectionalLineFollow'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    def __init__(self, config: DirectionalLineFollowConfig, until: raccoon.step.condition.StopCondition | None = None):
        ...
    def _generate_signature(self) -> str:
        ...
    def on_start(self, robot: GenericRobot) -> None:
        ...
    def on_update(self, robot: GenericRobot, dt: float) -> bool:
        ...
    def to_simulation_step(self) -> raccoon.step.model.SimulationStep:
        ...
class DirectionalLineFollowConfig:
    """
    Configuration for directional line following with two sensors.
    
    Allows independent heading (forward/backward) and strafe (left/right)
    speed components.  The PID controller steers via angular velocity based
    on the difference between left and right sensor readings.
    
    When ``lateral_correction`` is True, the PID output controls lateral
    velocity (vy) instead of angular velocity (wz), keeping the robot's
    heading constant while correcting position by strafing.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'left_sensor': Field(name='left_sensor',type=<class 'raccoon.sensor_ir.IRSensor'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'right_sensor': Field(name='right_sensor',type=<class 'raccoon.sensor_ir.IRSensor'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'heading_speed': Field(name='heading_speed',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'strafe_speed': Field(name='strafe_speed',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'distance_cm': Field(name='distance_cm',type=float | None,default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'kp': Field(name='kp',type=<class 'float'>,default=0.4,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'ki': Field(name='ki',type=<class 'float'>,default=0.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'kd': Field(name='kd',type=<class 'float'>,default=0.1,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'lateral_correction': Field(name='lateral_correction',type=<class 'bool'>,default=False,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('left_sensor', 'right_sensor', 'heading_speed', 'strafe_speed', 'distance_cm', 'kp', 'ki', 'kd', 'lateral_correction')
    distance_cm = None
    kd: typing.ClassVar[float] = 0.1
    ki: typing.ClassVar[float] = 0.0
    kp: typing.ClassVar[float] = 0.4
    lateral_correction: typing.ClassVar[bool] = False
    def __eq__(self, other):
        ...
    def __init__(self, left_sensor: raccoon.sensor_ir.IRSensor, right_sensor: raccoon.sensor_ir.IRSensor, heading_speed: float, strafe_speed: float, distance_cm: float | None = None, kp: float = 0.4, ki: float = 0.0, kd: float = 0.1, lateral_correction: bool = False) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class DirectionalSingleLineFollow(raccoon.step.motion.motion_step.MotionStep):
    """
    Follow a line edge with independent heading and strafe velocity.
    
    Targets ``probabilityOfBlack() = 0.5`` (the line edge) as the setpoint.
    The ``side`` configuration flips the error sign to select left vs. right
    edge tracking.  The PID output controls angular velocity while heading
    and strafe velocities are set directly via ``ChassisVelocity``.
    
    Supports distance-based and composable ``StopCondition``-based
    termination.
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'DirectionalSingleLineFollow'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    def __init__(self, config: DirectionalSingleLineFollowConfig, until: raccoon.step.condition.StopCondition | None = None):
        ...
    def _generate_signature(self) -> str:
        ...
    def on_start(self, robot: GenericRobot) -> None:
        ...
    def on_update(self, robot: GenericRobot, dt: float) -> bool:
        ...
    def to_simulation_step(self) -> raccoon.step.model.SimulationStep:
        ...
class DirectionalSingleLineFollowConfig:
    """
    Configuration for directional single-sensor line following.
    
    The sensor tracks the edge of a line using PID control while the robot
    moves with the given heading and strafe velocity components.
    
    When ``lateral_correction`` is True, the PID output controls lateral
    velocity (vy) instead of angular velocity (wz), keeping the robot's
    heading constant while correcting position by strafing.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'sensor': Field(name='sensor',type=<class 'raccoon.sensor_ir.IRSensor'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'heading_speed': Field(name='heading_speed',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'strafe_speed': Field(name='strafe_speed',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'distance_cm': Field(name='distance_cm',type=float | None,default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'side': Field(name='side',type=<enum 'LineSide'>,default=<LineSide.LEFT: 'left'>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'kp': Field(name='kp',type=<class 'float'>,default=0.4,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'ki': Field(name='ki',type=<class 'float'>,default=0.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'kd': Field(name='kd',type=<class 'float'>,default=0.1,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'lateral_correction': Field(name='lateral_correction',type=<class 'bool'>,default=False,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('sensor', 'heading_speed', 'strafe_speed', 'distance_cm', 'side', 'kp', 'ki', 'kd', 'lateral_correction')
    distance_cm = None
    kd: typing.ClassVar[float] = 0.1
    ki: typing.ClassVar[float] = 0.0
    kp: typing.ClassVar[float] = 0.4
    lateral_correction: typing.ClassVar[bool] = False
    side: typing.ClassVar[LineSide]  # value = <LineSide.LEFT: 'left'>
    def __eq__(self, other):
        ...
    def __init__(self, sensor: raccoon.sensor_ir.IRSensor, heading_speed: float, strafe_speed: float, distance_cm: float | None = None, side: LineSide = ..., kp: float = 0.4, ki: float = 0.0, kd: float = 0.1, lateral_correction: bool = False) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class FollowLine(LineFollow):
    """
    Follow a line using two IR sensors for steering.
    
    Drives forward while a PID controller steers the robot to keep it centered
    on a line. The error signal is the difference between the left and right
    sensors' ``probabilityOfBlack()`` readings. A positive error (left sees
    more black) steers the robot back toward center. The underlying
    ``LinearMotion`` handles profiled velocity control and odometry-based
    distance tracking, while the PID output overrides the heading command
    as an angular velocity (omega).
    
    Supports distance-based termination, composable ``StopCondition`` via
    ``.until()``, or both (whichever triggers first). At least one of
    ``distance_cm`` or ``until`` must be provided.
    
    Both sensors must be calibrated (white/black thresholds set) before use.
    
    Args:
        left_sensor: Left IR sensor instance, positioned to the left of the
            line.
        right_sensor: Right IR sensor instance, positioned to the right of
            the line.
        distance_cm: Distance to follow in centimeters. The step finishes
            when this distance has been traveled according to odometry.
            Optional if ``until`` is provided.
        speed: Fraction of max velocity (0.0--1.0). Lower speeds give the
            PID more time to correct but are slower overall. Default 0.5.
        kp: Proportional gain for steering PID. Higher values produce
            sharper corrections. Default 0.75.
        ki: Integral gain for steering PID. Typically left at 0.0 unless
            there is a persistent drift. Default 0.0.
        kd: Derivative gain for steering PID. Damps oscillation around the
            line. Default 0.5.
        until: Composable stop condition (e.g., ``on_black(left) &
            on_black(right)``). Can also be chained via the ``.until()``
            builder method.
    
    Returns:
        A ``FollowLine`` step configured for line following.
    
    Example::
    
        from raccoon.step.motion import FollowLine
        from raccoon.step.condition import on_black
    
        # Follow a line for 80 cm at half speed
        follow_line(left_sensor=left, right_sensor=right, distance_cm=80, speed=0.5)
    
        # Follow until both sensors see black (intersection)
        follow_line(left, right, speed=0.5).until(on_black(left) & on_black(right))
    
        # Distance + early termination
        follow_line(left, right, distance_cm=100, speed=0.5).until(on_black(third))
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='FollowLine', tags=('motion', 'line-follow'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'FollowLine'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'line-follow')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'line-follow')
    def __init__(self, left_sensor: raccoon.sensor_ir.IRSensor, right_sensor: raccoon.sensor_ir.IRSensor, distance_cm: float | None = None, speed: float = 0.5, kp: float = 0.4, ki: float = 0.0, kd: float = 0.1, until: raccoon.step.condition.StopCondition | None = None) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class FollowLineSingle(SingleSensorLineFollow):
    """
    Follow a line edge using a single IR sensor.
    
    The sensor tracks the boundary between the line and the background, where
    ``probabilityOfBlack()`` is approximately 0.5. The PID controller drives
    the error ``(reading - 0.5)`` toward zero, keeping the sensor positioned
    right on the edge. The ``side`` parameter controls which edge: ``LEFT``
    means the sensor is to the left of the line (steers right when it sees
    black), and ``RIGHT`` is the opposite.
    
    This variant is useful when only one sensor is available, or when the line
    is too narrow for two sensors. The underlying ``LinearMotion`` handles
    profiled velocity and odometry-based distance tracking.
    
    Supports distance-based termination, composable ``StopCondition`` via
    ``.until()``, or both (whichever triggers first). At least one of
    ``distance_cm`` or ``until`` must be provided.
    
    The sensor must be calibrated (white/black thresholds set) before use.
    
    Args:
        sensor: The IR sensor instance used for edge tracking.
        distance_cm: Distance to follow in centimeters. The step finishes
            when this distance has been traveled. Optional if ``until`` is
            provided.
        speed: Fraction of max velocity (0.0--1.0). Default 0.5.
        side: Which edge of the line to track. ``LineSide.LEFT`` (default)
            or ``LineSide.RIGHT``.
        kp: Proportional gain for steering PID. Default 1.0.
        ki: Integral gain for steering PID. Default 0.0.
        kd: Derivative gain for steering PID. Default 0.3.
        until: Composable stop condition (e.g., ``on_black(stop_sensor)``).
            Can also be chained via the ``.until()`` builder method.
    
    Returns:
        A ``FollowLineSingle`` step.
    
    Example::
    
        from raccoon.step.motion import FollowLineSingle, LineSide
        from raccoon.step.condition import on_black
    
        # Follow left edge for 60 cm
        follow_line_single(sensor=front_ir, distance_cm=60, speed=0.4)
    
        # Follow until stop sensor sees black
        follow_line_single(front_ir, speed=0.4, side=LineSide.LEFT).until(on_black(stop))
    
        # Distance + early termination with timeout
        follow_line_single(front_ir, distance_cm=100).until(on_black(stop) | after_seconds(10))
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='FollowLineSingle', tags=('motion', 'line-follow'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'FollowLineSingle'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'line-follow')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'line-follow')
    def __init__(self, sensor: raccoon.sensor_ir.IRSensor, distance_cm: float | None = None, speed: float = 0.5, side: LineSide = ..., kp: float = 0.4, ki: float = 0.0, kd: float = 0.1, until: raccoon.step.condition.StopCondition | None = None) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class LineFollow(raccoon.step.motion.motion_step.MotionStep):
    """
    Follow a line using two IR sensors with PID steering.
    
    Computes a steering error as the difference between the left and right
    sensors' ``probabilityOfBlack()`` readings and feeds it through a PID
    controller. The PID output is applied as an angular velocity (omega)
    override on the underlying ``LinearMotion``, which handles profiled
    distance control and odometry integration.
    
    Supports distance-based termination, composable ``StopCondition`` via
    ``.until()``, or both (whichever triggers first).
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'LineFollow'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    def __init__(self, config: LineFollowConfig, until: raccoon.step.condition.StopCondition | None = None):
        ...
    def _generate_signature(self) -> str:
        ...
    def on_start(self, robot: GenericRobot) -> None:
        ...
    def on_update(self, robot: GenericRobot, dt: float) -> bool:
        ...
    def to_simulation_step(self) -> raccoon.step.model.SimulationStep:
        ...
class LineFollowConfig:
    """
    Configuration for LineFollow step with two sensors.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'left_sensor': Field(name='left_sensor',type=<class 'raccoon.sensor_ir.IRSensor'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'right_sensor': Field(name='right_sensor',type=<class 'raccoon.sensor_ir.IRSensor'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'speed_scale': Field(name='speed_scale',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'distance_cm': Field(name='distance_cm',type=float | None,default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'kp': Field(name='kp',type=<class 'float'>,default=0.4,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'ki': Field(name='ki',type=<class 'float'>,default=0.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'kd': Field(name='kd',type=<class 'float'>,default=0.1,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('left_sensor', 'right_sensor', 'speed_scale', 'distance_cm', 'kp', 'ki', 'kd')
    distance_cm = None
    kd: typing.ClassVar[float] = 0.1
    ki: typing.ClassVar[float] = 0.0
    kp: typing.ClassVar[float] = 0.4
    def __eq__(self, other):
        ...
    def __init__(self, left_sensor: raccoon.sensor_ir.IRSensor, right_sensor: raccoon.sensor_ir.IRSensor, speed_scale: float, distance_cm: float | None = None, kp: float = 0.4, ki: float = 0.0, kd: float = 0.1) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class LineSide(enum.Enum):
    """
    Which edge of the line to track with a single sensor.
    """
    LEFT: typing.ClassVar[LineSide]  # value = <LineSide.LEFT: 'left'>
    RIGHT: typing.ClassVar[LineSide]  # value = <LineSide.RIGHT: 'right'>
class SingleLineFollowConfig:
    """
    Configuration for single-sensor line following.
    
    The sensor tracks the edge of a line using PID control.
    ``side`` selects which edge: LEFT means the sensor approaches
    from the left (steers right when it sees black), RIGHT is the
    opposite.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'sensor': Field(name='sensor',type=<class 'raccoon.sensor_ir.IRSensor'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'speed_scale': Field(name='speed_scale',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'distance_cm': Field(name='distance_cm',type=float | None,default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'side': Field(name='side',type=<enum 'LineSide'>,default=<LineSide.LEFT: 'left'>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'kp': Field(name='kp',type=<class 'float'>,default=0.4,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'ki': Field(name='ki',type=<class 'float'>,default=0.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'kd': Field(name='kd',type=<class 'float'>,default=0.1,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('sensor', 'speed_scale', 'distance_cm', 'side', 'kp', 'ki', 'kd')
    distance_cm = None
    kd: typing.ClassVar[float] = 0.1
    ki: typing.ClassVar[float] = 0.0
    kp: typing.ClassVar[float] = 0.4
    side: typing.ClassVar[LineSide]  # value = <LineSide.LEFT: 'left'>
    def __eq__(self, other):
        ...
    def __init__(self, sensor: raccoon.sensor_ir.IRSensor, speed_scale: float, distance_cm: float | None = None, side: LineSide = ..., kp: float = 0.4, ki: float = 0.0, kd: float = 0.1) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class SingleSensorLineFollow(raccoon.step.motion.motion_step.MotionStep):
    """
    Follow a line edge using a single IR sensor with PID edge-tracking.
    
    Targets ``probabilityOfBlack() = 0.5`` (the line edge) as the setpoint.
    The ``side`` configuration flips the error sign to select left vs. right
    edge tracking. The PID output overrides the angular velocity on the
    underlying ``LinearMotion``, which handles profiled distance control
    and odometry integration.
    
    Supports distance-based termination, composable ``StopCondition`` via
    ``.until()``, or both (whichever triggers first).
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'SingleSensorLineFollow'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    def __init__(self, config: SingleLineFollowConfig, until: raccoon.step.condition.StopCondition | None = None):
        ...
    def _generate_signature(self) -> str:
        ...
    def on_start(self, robot: GenericRobot) -> None:
        ...
    def on_update(self, robot: GenericRobot, dt: float) -> bool:
        ...
    def to_simulation_step(self) -> raccoon.step.model.SimulationStep:
        ...
class StrafeFollowLine(DirectionalLineFollow):
    """
    Follow a line forward, correcting position by strafing left/right.
    
    The robot drives forward at the given speed while a PID controller
    corrects lateral position using two sensors.  Unlike ``FollowLine``
    which steers by rotating, this step keeps the robot's heading constant
    and corrects by strafing, which is useful when the robot must maintain
    a fixed orientation (e.g. to keep a side-mounted mechanism aligned).
    
    Supports distance-based termination, composable ``StopCondition`` via
    ``.until()``, or both (whichever triggers first). At least one of
    ``distance_cm`` or ``until`` must be provided.
    
    Both sensors must be calibrated.  Requires a mecanum or omni-wheel
    drivetrain.
    
    Args:
        left_sensor: Left IR sensor instance.
        right_sensor: Right IR sensor instance.
        distance_cm: Distance to follow in centimeters. Optional if
            ``until`` is provided.
        speed: Forward speed as fraction of max velocity (0.0 to 1.0).
            Default 0.5.  Use negative values to drive backward.
        kp: Proportional gain for lateral PID.  Default 0.75.
        ki: Integral gain for lateral PID.  Default 0.0.
        kd: Derivative gain for lateral PID.  Default 0.5.
        until: Composable stop condition. Can also be chained via the
            ``.until()`` builder method.
    
    Returns:
        A ``StrafeFollowLine`` step configured for lateral correction.
    
    Example::
    
        from raccoon.step.motion import StrafeFollowLine
        from raccoon.step.condition import on_black
    
        # Follow a line for 40 cm, correcting via strafe
        strafe_follow_line(left, right, distance_cm=40, speed=0.4)
    
        # Follow until both sensors see black
        strafe_follow_line(left, right, speed=0.4).until(
            on_black(left) & on_black(right)
        )
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='StrafeFollowLine', tags=('motion', 'line-follow'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'StrafeFollowLine'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'line-follow')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'line-follow')
    def __init__(self, left_sensor: raccoon.sensor_ir.IRSensor, right_sensor: raccoon.sensor_ir.IRSensor, distance_cm: float | None = None, speed: float = 0.5, kp: float = 0.4, ki: float = 0.0, kd: float = 0.1, until: raccoon.step.condition.StopCondition | None = None) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class StrafeFollowLineSingle(DirectionalSingleLineFollow):
    """
    Follow a line edge forward, correcting position by strafing.
    
    The robot drives forward at the given speed while a PID controller
    corrects lateral position using a single sensor tracking the line edge.
    Unlike ``FollowLineSingle`` which steers by rotating, this step keeps
    the robot's heading constant and corrects by strafing.
    
    Supports distance-based termination, composable ``StopCondition`` via
    ``.until()``, or both (whichever triggers first). At least one of
    ``distance_cm`` or ``until`` must be provided.
    
    The sensor must be calibrated.  Requires a mecanum or omni-wheel
    drivetrain.
    
    Args:
        sensor: IR sensor for edge tracking.
        distance_cm: Distance to follow in centimeters. Optional if
            ``until`` is provided.
        speed: Forward speed as fraction of max velocity (0.0 to 1.0).
            Default 0.5.  Use negative values to drive backward.
        side: Which edge of the line to track.  Default ``LineSide.LEFT``.
        kp: Proportional gain for lateral PID.  Default 1.0.
        ki: Integral gain for lateral PID.  Default 0.0.
        kd: Derivative gain for lateral PID.  Default 0.3.
        until: Composable stop condition. Can also be chained via the
            ``.until()`` builder method.
    
    Returns:
        A ``StrafeFollowLineSingle`` step configured for lateral correction.
    
    Example::
    
        from raccoon.step.motion import StrafeFollowLineSingle, LineSide
        from raccoon.step.condition import on_black
    
        # Follow a line edge for 40 cm, correcting via strafe
        strafe_follow_line_single(front_ir, distance_cm=40, speed=0.4)
    
        # Follow until stop sensor sees black
        strafe_follow_line_single(front_ir, speed=0.4).until(on_black(stop))
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='StrafeFollowLineSingle', tags=('motion', 'line-follow'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'StrafeFollowLineSingle'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'line-follow')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'line-follow')
    def __init__(self, sensor: raccoon.sensor_ir.IRSensor, distance_cm: float | None = None, speed: float = 0.5, side: LineSide = ..., kp: float = 0.4, ki: float = 0.0, kd: float = 0.1, until: raccoon.step.condition.StopCondition | None = None) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
_SENTINEL_DISTANCE_M: float = 100.0
