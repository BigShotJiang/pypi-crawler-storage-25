"""
Python bindings for libstp-kinematics_mecanum
"""
from __future__ import annotations
import raccoon.foundation
import raccoon.hal
import raccoon.kinematics
__all__: list[str] = ['MecanumKinematics']
class MecanumKinematics(raccoon.kinematics.IKinematics):
    def __init__(self, front_left_motor: raccoon.hal.Motor, front_right_motor: raccoon.hal.Motor, back_left_motor: raccoon.hal.Motor, back_right_motor: raccoon.hal.Motor, wheelbase: float, track_width: float, wheel_radius: float) -> None:
        ...
    def apply_command(self, cmd: raccoon.foundation.ChassisVelocity, dt: float) -> ...:
        ...
    def apply_power_command(self, direction: raccoon.foundation.ChassisVelocity, power_percent: int) -> None:
        """
        Command motors at raw open-loop power using kinematics for direction
        """
    def estimate_state(self) -> raccoon.foundation.ChassisVelocity:
        ...
    def get_max_wheel_speed(self) -> float:
        """
        Get the max wheel speed limit (rad/s). 0 = disabled.
        """
    def get_wheel_radius(self) -> float:
        """
        Get the wheel radius in meters
        """
    def hard_stop(self) -> None:
        ...
    def reset_encoders(self) -> None:
        """
        Reset encoder tracking to prevent stale deltas after odometry reset
        """
    def set_max_wheel_speed(self, max_wheel_speed: float) -> None:
        """
        Set max wheel speed (rad/s) for desaturation. 0 = disabled.
        """
    def supports_lateral_motion(self) -> bool:
        """
        Returns True since mecanum drives can strafe
        """
    def wheel_count(self) -> int:
        ...
    @property
    def motors(self) -> list[raccoon.hal.IMotor]:
        """
        List of motors managed by this kinematics model
        """
