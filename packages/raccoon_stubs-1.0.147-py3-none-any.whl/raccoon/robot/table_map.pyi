"""
Table map model for Botball field geometry.

Stores line and wall segments from the .ftmap vector format and provides
spatial queries (point-on-line, point-on-wall, distance-to-nearest-line).

The coordinate system matches the Botball field: origin at bottom-left,
X right, Y up, all values in centimeters.

Example usage::

    from raccoon.robot.table_map import TableMap

    # Load from ftmap dict (as stored in raccoon.project.yml)
    table_map = TableMap.from_ftmap(config["robot"]["physical"]["table_map"])

    # Load from .ftmap file
    table_map = TableMap.load("config/table_map.ftmap")

    # Query
    table_map.is_on_line(50.0, 30.0)       # True/False
    table_map.is_on_wall(0.0, 50.0)        # True/False
    table_map.distance_to_nearest_line(50.0, 30.0)  # cm
"""
from __future__ import annotations
import dataclasses
from dataclasses import dataclass
from dataclasses import field
import json as json
import math as math
from pathlib._local import Path
import typing
from typing import Any
__all__: list[str] = ['Any', 'MapSegment', 'Path', 'TableMap', 'dataclass', 'field', 'json', 'math']
class MapSegment:
    """
    A single line or wall segment on the field, in centimeters.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'start_x': Field(name='start_x',type='float',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'start_y': Field(name='start_y',type='float',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'end_x': Field(name='end_x',type='float',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'end_y': Field(name='end_y',type='float',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'width_cm': Field(name='width_cm',type='float',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'kind': Field(name='kind',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=True,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __match_args__: typing.ClassVar[tuple] = ('start_x', 'start_y', 'end_x', 'end_y', 'width_cm', 'kind')
    def __delattr__(self, name):
        ...
    def __eq__(self, other):
        ...
    def __hash__(self):
        ...
    def __init__(self, start_x: float, start_y: float, end_x: float, end_y: float, width_cm: float, kind: str) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
    def __setattr__(self, name, value):
        ...
    @property
    def length(self) -> float:
        ...
class TableMap:
    """
    Botball field table map with line and wall segments.
    
    All coordinates are in centimeters with origin at bottom-left of the field.
    """
    @classmethod
    def from_ftmap(cls, data: dict[str, typing.Any]) -> 'TableMap':
        """
        Create a TableMap from an ftmap dict (as stored in project config).
        
        Args:
            data: Dict with keys ``format``, ``version``, ``table``, ``lines``.
        
        Returns:
            A populated TableMap instance.
        
        Raises:
            ValueError: If the format or version is unsupported.
        """
    @classmethod
    def load(cls, path: str | Path) -> 'TableMap':
        """
        Load a TableMap from a ``.ftmap`` JSON file.
        
        Args:
            path: Path to the .ftmap file.
        
        Returns:
            A populated TableMap instance.
        """
    def __init__(self, width_cm: float, height_cm: float, segments: typing.Sequence[MapSegment] = tuple()) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def distance_to_nearest_line(self, x_cm: float, y_cm: float) -> float:
        """
        Shortest distance from a point to any line segment centerline.
        
        Args:
            x_cm: X position on field (cm from left).
            y_cm: Y position on field (cm from bottom).
        
        Returns:
            Distance in cm, or ``float('inf')`` if there are no lines.
        """
    def distance_to_nearest_wall(self, x_cm: float, y_cm: float) -> float:
        """
        Shortest distance from a point to any wall segment centerline.
        
        Args:
            x_cm: X position on field (cm from left).
            y_cm: Y position on field (cm from bottom).
        
        Returns:
            Distance in cm, or ``float('inf')`` if there are no walls.
        """
    def is_on_line(self, x_cm: float, y_cm: float) -> bool:
        """
        Check if a point is within any line segment's width.
        
        A point is "on" a line if its perpendicular distance to the segment
        centerline is less than half the line's width.
        
        Args:
            x_cm: X position on field (cm from left).
            y_cm: Y position on field (cm from bottom).
        
        Returns:
            True if the point overlaps a line.
        """
    def is_on_wall(self, x_cm: float, y_cm: float) -> bool:
        """
        Check if a point is within any wall segment's width.
        
        Args:
            x_cm: X position on field (cm from left).
            y_cm: Y position on field (cm from bottom).
        
        Returns:
            True if the point overlaps a wall.
        """
    def sensor_field_position(self, robot_x_cm: float, robot_y_cm: float, robot_heading_rad: float, sensor: 'SensorPosition') -> tuple[float, float]:
        """
        Compute the field position of a sensor given robot pose.
        
        The robot pose is in field coordinates (origin bottom-left, heading 0 = +X, CCW positive).
        The sensor position is in robot-relative coordinates (forward/strafe from geometric center).
        
        Args:
            robot_x_cm: Robot center X on field (cm).
            robot_y_cm: Robot center Y on field (cm).
            robot_heading_rad: Robot heading (radians, 0 = +X, CCW positive).
            sensor: SensorPosition with forward_cm and strafe_cm offsets.
        
        Returns:
            Tuple of (field_x_cm, field_y_cm) for the sensor.
        """
    def sensor_is_on_line(self, robot_x_cm: float, robot_y_cm: float, robot_heading_rad: float, sensor: 'SensorPosition') -> bool:
        """
        Check if a sensor would be over a black line given current robot pose.
        
        Args:
            robot_x_cm: Robot center X on field (cm).
            robot_y_cm: Robot center Y on field (cm).
            robot_heading_rad: Robot heading (radians).
            sensor: SensorPosition offset from robot center.
        
        Returns:
            True if the sensor's field position overlaps a line.
        """
    def sensor_is_on_wall(self, robot_x_cm: float, robot_y_cm: float, robot_heading_rad: float, sensor: 'SensorPosition') -> bool:
        """
        Check if a sensor would be over a wall given current robot pose.
        
        Args:
            robot_x_cm: Robot center X on field (cm).
            robot_y_cm: Robot center Y on field (cm).
            robot_heading_rad: Robot heading (radians).
            sensor: SensorPosition offset from robot center.
        
        Returns:
            True if the sensor's field position overlaps a wall.
        """
    def to_ftmap(self) -> dict[str, typing.Any]:
        """
        Serialize this TableMap back to the ftmap dict format.
        """
    @property
    def all_segments(self) -> list[MapSegment]:
        ...
    @property
    def lines(self) -> list[MapSegment]:
        ...
    @property
    def walls(self) -> list[MapSegment]:
        ...
def _point_to_segment_distance(px: float, py: float, ax: float, ay: float, bx: float, by: float) -> float:
    """
    Shortest distance from point (px, py) to line segment (ax,ay)-(bx,by).
    """
