"""
Robot abstraction layer that ties missions, services, and geometry together.
"""
from __future__ import annotations
from raccoon.robot.api import GenericRobot
from raccoon.robot.api import RobotDefinitionsProtocol
from raccoon.robot.geometry import RobotGeometry
from raccoon.robot.geometry import SensorPosition
from raccoon.robot.geometry import WheelPosition
from raccoon.robot.map_corrected_odometry import MapCorrectedOdometry
from raccoon.robot.service import RobotService
from raccoon.robot.table_map import MapSegment
from raccoon.robot.table_map import TableMap
from . import api
from . import geometry
from . import heading_reference
from . import map_corrected_odometry
from . import service
from . import table_map
__all__: list = ['GenericRobot', 'RobotService', 'RobotDefinitionsProtocol', 'RobotGeometry', 'SensorPosition', 'WheelPosition', 'TableMap', 'MapSegment', 'MapCorrectedOdometry']
