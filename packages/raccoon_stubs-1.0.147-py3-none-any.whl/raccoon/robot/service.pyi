from __future__ import annotations
import raccoon.class_name_logger
from raccoon.class_name_logger import ClassNameLogger
__all__: list[str] = ['ClassNameLogger', 'RobotService']
class RobotService(raccoon.class_name_logger.ClassNameLogger):
    """
    Base class for robot services.
    
    Services encapsulate reusable business logic (e.g. drum navigation,
    arm control) and are lazily instantiated and cached per robot via
    ``robot.get_service(ServiceClass)``.
    
    Subclasses receive the robot instance in ``__init__`` and can access
    hardware through ``self.robot.defs``.
    """
    def __init__(self, robot: GenericRobot) -> None:
        ...
