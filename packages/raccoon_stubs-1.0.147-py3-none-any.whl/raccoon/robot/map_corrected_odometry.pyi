"""
Map-corrected odometry using IR sensor readings and known field geometry.

Wraps an existing odometry source and applies lateral corrections when IR
sensors detect line crossings.  The IMU heading is trusted; only the
translational (x, y) position is nudged.

Correction strategy
-------------------
Each update the wrapper:

1. Reads every registered IR sensor's ``probabilityOfBlack()``.
2. For each sensor whose probability crosses the **on-line threshold**
   (rising edge), it projects the sensor's expected field position using
   the current odometry pose + robot geometry.
3. It finds the **nearest map line** to that projected point.
4. It computes the signed perpendicular error from the projected sensor
   position to the line's centerline.
5. It applies a fraction (``correction_gain``) of that error as a lateral
   nudge to the stored position offset, perpendicular to the line.

Because heading is accurate, the perpendicular correction fixes the dominant
drift mode (sideways slip) without perturbing distance-along-travel.

Coordinate frames
-----------------
* **Odometry frame** — origin at the point of last ``reset()``, meters,
  heading 0 = initial forward direction.
* **Field frame** — origin at bottom-left of the Botball table, centimeters,
  heading 0 = +X (right), positive CCW.

The wrapper converts between them using the configured ``start_pose``
(field position + heading at the moment odometry was last reset).

Example::

    from raccoon.robot.map_corrected_odometry import MapCorrectedOdometry

    mc = MapCorrectedOdometry(
        inner=robot.odometry,
        table_map=robot.table_map,
        start_x_cm=90.0,
        start_y_cm=47.0,
        start_heading_rad=0.0,
    )
    mc.register_sensor(robot.defs.front_ir, robot.sensor_position(robot.defs.front_ir))
    mc.register_sensor(robot.defs.rear_ir, robot.sensor_position(robot.defs.rear_ir))

    # In your update loop (or motion step):
    mc.update(dt)
    pose = mc.get_pose()           # corrected pose in odometry frame
    field_pos = mc.get_field_position()  # (x_cm, y_cm) on the table
"""
from __future__ import annotations
import dataclasses
from dataclasses import dataclass
from dataclasses import field
import logging as logging
import math as math
import typing
from typing import Any
__all__: list[str] = ['Any', 'MapCorrectedOdometry', 'dataclass', 'field', 'logger', 'logging', 'math']
class MapCorrectedOdometry:
    """
    Odometry wrapper that corrects position using IR sensor + map data.
    
    Delegates all standard odometry calls to the *inner* odometry and
    maintains a correction offset that is applied transparently.
    
    Args:
        inner: The underlying odometry instance (FusedOdometry / Stm32Odometry).
        table_map: The loaded TableMap with field line/wall geometry.
        start_x_cm: Robot center X on field at odometry origin (cm).
        start_y_cm: Robot center Y on field at odometry origin (cm).
        start_heading_rad: Robot heading on field at odometry origin (rad, 0 = +X, CCW+).
        correction_gain: Fraction of perpendicular error applied per event (0–1).
            Lower values are more conservative.  Default 0.6.
        on_line_threshold: ``probabilityOfBlack()`` value above which the
            sensor is considered "on a line".  Default 0.7.
        max_correction_cm: Clamp for a single correction step to avoid
            jumps from misidentified lines.  Default 3.0 cm.
    """
    def __init__(self, inner: typing.Any, table_map: 'TableMap', start_x_cm: float, start_y_cm: float, start_heading_rad: float = 0.0, correction_gain: float = 0.6, on_line_threshold: float = 0.7, max_correction_cm: float = 3.0) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def _apply_corrections(self) -> None:
        """
        Check each sensor and apply corrections on rising-edge line detections.
        """
    def _correct_from_sensor(self, robot_x: float, robot_y: float, robot_heading: float, sensor_pos: 'SensorPosition') -> None:
        """
        Apply a single correction based on a sensor that just hit a line.
        """
    def _field_offset_to_odom_m(self, dx_cm: float, dy_cm: float) -> tuple[float, float]:
        """
        Convert a field-frame offset (cm) to odometry-frame offset (m).
        """
    def _odom_to_field(self, pose: typing.Any) -> tuple[float, float, float]:
        """
        Convert an odometry Pose to field coordinates (cm).
        
        Returns (field_x_cm, field_y_cm, field_heading_rad).
        """
    def get_absolute_heading(self) -> float:
        ...
    def get_distance_from_origin(self) -> typing.Any:
        ...
    def get_field_heading(self) -> float:
        """
        Get the robot heading in field coordinates (radians).
        
        Returns:
            Heading in radians (0 = +X, CCW positive).
        """
    def get_field_position(self) -> tuple[float, float]:
        """
        Get the corrected robot position in field coordinates (cm).
        
        Returns:
            (x_cm, y_cm) on the Botball table.
        """
    def get_heading(self) -> float:
        ...
    def get_heading_error(self, target_heading_rad: float) -> float:
        ...
    def get_path_length(self) -> float:
        ...
    def get_pose(self) -> typing.Any:
        """
        Get corrected pose in odometry frame.
        
        The returned Pose has the correction baked into the position.
        Heading is unchanged (trusted from IMU).
        """
    def register_sensor(self, sensor: typing.Any, position: 'SensorPosition') -> None:
        """
        Register an IR sensor for map-based correction.
        
        Args:
            sensor: An IRSensor instance (must have ``probabilityOfBlack()``).
            position: The sensor's ``SensorPosition`` on the robot.
        """
    def reset(self) -> None:
        """
        Reset inner odometry and clear accumulated corrections.
        """
    def reset_with_field_pose(self, x_cm: float, y_cm: float, heading_rad: float = 0.0) -> None:
        """
        Reset odometry and set a new field-frame starting pose.
        
        Use this when you know exactly where the robot is (e.g. after
        aligning against a wall or starting position).
        
        Args:
            x_cm: New field X position (cm from left).
            y_cm: New field Y position (cm from bottom).
            heading_rad: New field heading (radians, 0 = +X, CCW+).
        """
    def update(self, dt: float) -> None:
        """
        Update inner odometry and apply map-based corrections.
        
        Call this at the same rate as the inner odometry's update loop.
        """
    @property
    def correction_offset_cm(self) -> tuple[float, float]:
        """
        Current accumulated correction in field cm (for diagnostics).
        """
class _SensorEntry:
    """
    Internal bookkeeping for one registered IR sensor.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'sensor': Field(name='sensor',type='Any',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'position': Field(name='position',type="'SensorPosition'",default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'was_on_line': Field(name='was_on_line',type='bool',default=False,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('sensor', 'position', 'was_on_line')
    was_on_line: typing.ClassVar[bool] = False
    def __eq__(self, other):
        ...
    def __init__(self, sensor: typing.Any, position: 'SensorPosition', was_on_line: bool = False) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
def _nearest_segment(x: float, y: float, segments: list) -> tuple[typing.Any, float, float, float] | None:
    """
    Find the segment closest to (x, y).
    
    Returns ``(segment, distance, perp_x, perp_y)`` where ``(perp_x, perp_y)``
    is the unit vector perpendicular to the segment (pointing from the segment
    centerline toward the query point), or *None* if *segments* is empty.
    """
logger: logging.Logger  # value = <Logger raccoon.map_odom (INFO)>
