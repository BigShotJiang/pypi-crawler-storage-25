"""
Python bindings for libstp-drive
"""
from __future__ import annotations
import raccoon.foundation
import raccoon.hal
import typing
__all__: list[str] = ['AxisVelocityControlConfig', 'ChassisVelocityControlConfig', 'Drive', 'MotorAdapter', 'VelocityController']
class AxisVelocityControlConfig:
    ff: raccoon.foundation.Feedforward
    pid: raccoon.foundation.PidGains
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, pid: raccoon.foundation.PidGains, ff: raccoon.foundation.Feedforward) -> None:
        ...
class ChassisVelocityControlConfig:
    vx: AxisVelocityControlConfig
    vy: AxisVelocityControlConfig
    wz: AxisVelocityControlConfig
    def __init__(self) -> None:
        ...
class Drive:
    def __init__(self, kinematics: ..., vel_config: ChassisVelocityControlConfig, imu: raccoon.hal.IMU) -> None:
        ...
    def apply_power_command(self, direction: raccoon.foundation.ChassisVelocity, power_percent: int) -> None:
        """
        Command motors at raw open-loop power using kinematics for direction
        """
    def estimate_state(self) -> raccoon.foundation.ChassisVelocity:
        ...
    def get_motors(self) -> list[raccoon.hal.Motor]:
        """
        Get all drive motors managed by the kinematics
        """
    def get_velocity_control_config(self) -> ChassisVelocityControlConfig:
        """
        Get the current velocity control config (copy)
        """
    def get_wheel_radius(self) -> float:
        """
        Get the wheel radius from kinematics in meters
        """
    def hard_stop(self) -> None:
        ...
    def reset_velocity_controllers(self) -> None:
        ...
    def set_velocity(self, v_body: raccoon.foundation.ChassisVelocity) -> None:
        ...
    def set_velocity_control_config(self, config: ChassisVelocityControlConfig) -> None:
        ...
    def soft_stop(self) -> None:
        ...
    def supports_lateral_motion(self) -> bool:
        """
        Query whether the drivetrain can strafe sideways (delegates to kinematics)
        """
    def update(self, dt: float) -> None:
        ...
    def wheel_count(self) -> int:
        ...
class MotorAdapter:
    def __init__(self, motor: raccoon.hal.Motor) -> None:
        ...
    def brake(self) -> None:
        ...
    def get_velocity(self) -> float:
        ...
    def set_velocity(self, w_ref: float, dt: float) -> None:
        ...
    def update_encoder_velocity(self, dt: float) -> None:
        ...
class VelocityController:
    def __init__(self, g: raccoon.foundation.PidGains, ff: raccoon.foundation.Feedforward) -> None:
        ...
    def compute(self, w_ref: float, a_ref: float, w_meas: float, dt: float, u_max: float) -> tuple:
        ...
    def ff(self) -> raccoon.foundation.Feedforward:
        ...
    def gains(self) -> raccoon.foundation.PidGains:
        ...
    def reset(self) -> None:
        ...
    def set_ff(self, ff: raccoon.foundation.Feedforward) -> None:
        ...
    def set_gains(self, g: raccoon.foundation.PidGains) -> None:
        ...
