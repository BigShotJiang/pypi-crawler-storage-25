"""
Python bindings for libstp-kmeans
"""
from __future__ import annotations
__all__: list[str] = ['KMeans', 'KMeansResult']
class KMeans:
    def __init__(self, max_iterations: int = 10) -> None:
        ...
    def fit(self, data: list[float]) -> KMeansResult:
        ...
class KMeansResult:
    centroid1: float
    centroid2: float
    def __init__(self) -> None:
        ...
