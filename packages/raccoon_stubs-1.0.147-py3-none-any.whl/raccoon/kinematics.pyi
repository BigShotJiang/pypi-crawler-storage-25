"""
Python bindings for libstp-kinematics
"""
from __future__ import annotations
import raccoon.foundation
import raccoon.hal
__all__: list[str] = ['IKinematics']
class IKinematics:
    def apply_command(self, cmd: raccoon.foundation.ChassisVelocity, dt: float) -> ...:
        ...
    def apply_power_command(self, direction: raccoon.foundation.ChassisVelocity, power_percent: int) -> None:
        """
        Command motors at raw open-loop power using kinematics for direction
        """
    def estimate_state(self) -> raccoon.foundation.ChassisVelocity:
        ...
    def hard_stop(self) -> None:
        ...
    def supports_lateral_motion(self) -> bool:
        """
        Query whether the drivetrain can strafe sideways (vy motion)
        """
    def wheel_count(self) -> int:
        ...
    @property
    def motors(self) -> list[raccoon.hal.IMotor]:
        """
        List of motors managed by this kinematics model
        """
