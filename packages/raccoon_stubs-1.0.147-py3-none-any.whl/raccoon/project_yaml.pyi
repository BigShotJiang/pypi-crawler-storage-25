"""

Include-aware YAML reader/writer.

Handles ``!include`` and ``!include-merge`` tags at **any nesting depth** so
that callers can read and write values by property path without caring whether
the config is one file or split across dozens.

The resolution is fully recursive: an included file may itself contain further
``!include`` / ``!include-merge`` references.

Core API (works with any YAML file)::

    from pathlib import Path
    from raccoon.project_yaml import yaml_read, yaml_write

    # Read a deeply nested value, following includes automatically
    val = yaml_read(Path("config.yml"), ["robot", "motion_pid", "angular", "max_velocity"])

    # Write — the value lands in whichever split file owns that path
    yaml_write(Path("config.yml"), ["robot", "motion_pid", "angular", "max_velocity"], 1.23)

Convenience wrappers for ``raccoon.project.yml``::

    from raccoon.project_yaml import find_project_root, read_project_value, update_project_value

    root = find_project_root()
    update_project_value(root, ["robot", "motion_pid", "angular", "max_velocity"], 1.23)
"""
from __future__ import annotations
from pathlib._local import Path
import typing
from typing import Any
import yaml as yaml
__all__: list[str] = ['Any', 'Path', 'find_project_root', 'read_project_value', 'update_project_value', 'update_project_values', 'yaml', 'yaml_read', 'yaml_write', 'yaml_write_many']
class _IncludeRef:
    """
    Marker object that records an ``!include`` or ``!include-merge`` tag.
    """
    __slots__: typing.ClassVar[tuple] = ('path', 'merge')
    def __init__(self, path: str, *, merge: bool = False) -> None:
        ...
    def __repr__(self) -> str:
        ...
def _deep_merge_preserving_refs(original: dict, updates: dict) -> dict:
    """
    Deep-merge *updates* into *original*, keeping ``_IncludeRef`` values.
    
    For each key in *original* whose value is an ``_IncludeRef``, the ref is
    preserved (the updated data for that subtree lives in the included file,
    not here).  For nested dicts, the merge recurses so that inner include
    refs are also preserved.
    """
def _load_plain(path: Path) -> dict:
    """
    Load a YAML file, resolving all includes, returning ``{}`` on failure.
    
    Uses the include-aware loader so files containing ``!include`` tags don't
    cause parse errors.  ``!include`` refs are replaced by the loaded content
    and ``!include-merge`` refs merge their keys into the parent dict.
    """
def _load_with_includes(path: Path) -> typing.Any:
    """
    Load a YAML file, preserving ``!include`` / ``!include-merge`` as markers.
    """
def _make_include_dumper():
    """
    Create a YAML dumper that serializes ``_IncludeRef`` back to tags.
    """
def _make_include_loader():
    """
    Create a YAML loader subclass that turns include tags into markers.
    """
def _resolve_includes(data: typing.Any, base_dir: Path, *, _depth: int = 0) -> typing.Any:
    """
    Recursively resolve ``_IncludeRef`` values in a loaded YAML tree.
    
    - ``!include`` refs are replaced by the loaded content of the referenced file.
    - ``!include-merge`` refs merge the referenced file's top-level keys into
      the parent dict (the merge key itself is removed).
    
    Plain (non-include) values are returned as-is.  Recursion is capped at 20
    levels to prevent infinite loops.
    """
def _resolve_path(file_path: Path, key_path: list[str], *, _depth: int = 0) -> tuple[Path, list[str]]:
    """
    Walk *key_path* segment-by-segment, following includes at each level.
    
    Returns ``(owning_file, remaining_key_path)`` where *owning_file* is the
    YAML file that contains the deepest reachable ancestor of the target, and
    *remaining_key_path* is the portion of the path local to that file.
    
    The resolution is recursive (up to 20 levels deep to prevent loops).
    """
def _save_yaml(path: Path, data: dict) -> bool:
    """
    Write *data* to *path*, preserving existing ``!include`` directives.
    
    Loads the original file (with include markers intact), merges the updated
    plain *data* back in, then serializes with a dumper that can write
    ``_IncludeRef`` objects as proper YAML ``!include`` / ``!include-merge``
    tags.
    """
def find_project_root(start: Path | None = None) -> Path | None:
    """
    Search upward from *start* (default: cwd) for ``raccoon.project.yml``.
    """
def read_project_value(project_root: Path, key_path: list[str], default: typing.Any = None) -> typing.Any:
    """
    Read from ``raccoon.project.yml``, following includes. See :func:`yaml_read`.
    """
def update_project_value(project_root: Path, key_path: list[str], value: typing.Any) -> bool:
    """
    Write to ``raccoon.project.yml``, following includes. See :func:`yaml_write`.
    """
def update_project_values(project_root: Path, updates: dict[tuple[str, ...], typing.Any]) -> bool:
    """
    Batch-write to ``raccoon.project.yml``. See :func:`yaml_write_many`.
    """
def yaml_read(file_path: Path, key_path: list[str], default: typing.Any = ...) -> typing.Any:
    """
    Read a value from a YAML file, recursively resolving ``!include`` refs.
    
    Args:
        file_path: Path to the root YAML file.
        key_path: Property path segments, e.g. ``["robot", "motion_pid"]``.
        default: Value to return when the path doesn't exist.
            Raises ``KeyError`` if omitted and the path is missing.
    
    Returns:
        The resolved value, or *default*.
    """
def yaml_write(file_path: Path, key_path: list[str], value: typing.Any) -> bool:
    """
    Write a value to a YAML file, following ``!include`` refs to the correct file.
    
    Parent dicts are created as needed.  Only the resolved target file is
    rewritten — all other files (and their ``!include`` directives) are
    untouched.
    
    Args:
        file_path: Path to the root YAML file.
        key_path: Property path, e.g. ``["robot", "motion_pid", "angular", "max_velocity"]``.
        value: The value to set.
    
    Returns:
        ``True`` on success.
    """
def yaml_write_many(file_path: Path, updates: dict[tuple[str, ...], typing.Any]) -> bool:
    """
    Batch-write multiple values, minimizing file I/O.
    
    Args:
        file_path: Path to the root YAML file.
        updates: Mapping from key-path tuples to values.
    
    Returns:
        ``True`` if all writes succeeded.
    """
_PROJECT_FILENAME: str = 'raccoon.project.yml'
_SENTINEL: object  # value = <object object>
