"""
Python bindings for libstp-kinematics_differential
"""
from __future__ import annotations
import raccoon.foundation
import raccoon.hal
import raccoon.kinematics
__all__: list[str] = ['DifferentialKinematics']
class DifferentialKinematics(raccoon.kinematics.IKinematics):
    def __init__(self, left_motor: raccoon.hal.Motor, right_motor: raccoon.hal.Motor, wheelbase: float, wheel_radius: float) -> None:
        ...
    def apply_command(self, cmd: raccoon.foundation.ChassisVelocity, dt: float) -> ...:
        ...
    def apply_power_command(self, direction: raccoon.foundation.ChassisVelocity, power_percent: int) -> None:
        """
        Command motors at raw open-loop power using kinematics for direction
        """
    def estimate_state(self) -> raccoon.foundation.ChassisVelocity:
        ...
    def get_max_wheel_speed(self) -> float:
        """
        Get the max wheel speed (rad/s) for desaturation. 0 = disabled.
        """
    def get_wheel_radius(self) -> float:
        """
        Get the wheel radius in meters
        """
    def hard_stop(self) -> None:
        ...
    def reset_encoders(self) -> None:
        """
        Reset encoder tracking to prevent stale deltas after odometry reset
        """
    def set_max_wheel_speed(self, max_wheel_speed: float) -> None:
        """
        Set max wheel speed (rad/s) for desaturation. 0 = disabled.
        """
    def supports_lateral_motion(self) -> bool:
        """
        Returns False since differential drives cannot strafe
        """
    def wheel_count(self) -> int:
        ...
    @property
    def motors(self) -> list[raccoon.hal.IMotor]:
        """
        List of motors managed by this kinematics model
        """
