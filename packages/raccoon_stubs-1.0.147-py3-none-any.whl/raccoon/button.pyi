"""
Python bindings for libstp-button
"""
from __future__ import annotations
import raccoon.hal
import typing
__all__: list[str] = ['is_pressed', 'set_digital', 'wait_for_button_press']
def is_pressed() -> bool:
    """
    Check if the button is pressed
    """
@typing.overload
def set_digital(port: int) -> None:
    """
    Set the digital sensor port
    """
@typing.overload
def set_digital(sensor: raccoon.hal.DigitalSensor) -> None:
    """
    Set the digital sensor from existing sensor
    """
def wait_for_button_press() -> None:
    """
    Wait for the button to be pressed
    """
