from __future__ import annotations
import dataclasses
from dataclasses import dataclass
import typing
__all__: list[str] = ['TimingConfig', 'dataclass']
class TimingConfig:
    """
    Runtime knobs for step timing collection and anomaly detection.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'threshold_multiplier': Field(name='threshold_multiplier',type=<class 'float'>,default=3.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'window_size': Field(name='window_size',type=<class 'int'>,default=20,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'db_path': Field(name='db_path',type=<class 'str'>,default='logs/step_timing.db',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'enabled': Field(name='enabled',type=<class 'bool'>,default=True,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('threshold_multiplier', 'window_size', 'db_path', 'enabled')
    db_path: typing.ClassVar[str] = 'logs/step_timing.db'
    enabled: typing.ClassVar[bool] = True
    threshold_multiplier: typing.ClassVar[float] = 3.0
    window_size: typing.ClassVar[int] = 20
    def __eq__(self, other):
        ...
    def __init__(self, threshold_multiplier: float = 3.0, window_size: int = 20, db_path: str = 'logs/step_timing.db', enabled: bool = True) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
