from __future__ import annotations
import asyncio as asyncio
import raccoon.class_name_logger
from raccoon.class_name_logger import ClassNameLogger
import raccoon.timing.config
from raccoon.timing.config import TimingConfig
from raccoon.timing.database import StepTimingDatabase
import raccoon.timing.models
from raccoon.timing.models import AnomalyDetection
from raccoon.timing.models import StepStatistics
import statistics as statistics
import time as time
import typing
__all__: list[str] = ['AnomalyCallback', 'AnomalyDetection', 'ClassNameLogger', 'StepStatistics', 'StepTimingDatabase', 'StepTimingTracker', 'TimingConfig', 'asyncio', 'statistics', 'time']
class StepTimingTracker(raccoon.class_name_logger.ClassNameLogger):
    """
    Singleton tracker that persists step runtimes and reports anomalies.
    """
    _instance = None
    @classmethod
    def get_instance(cls) -> StepTimingTracker:
        """
        Return the process-wide tracker instance used by ``Step.run_step``.
        """
    def __init__(self, config: typing.Optional[raccoon.timing.config.TimingConfig] = None) -> None:
        """
        Initialize tracker state and open the configured timing database lazily.
        """
    def _compute_statistics(self, durations: typing.List[float]) -> typing.Optional[raccoon.timing.models.StepStatistics]:
        """
        Compute rolling statistics from prior samples.
        """
    def _detect_anomaly(self, signature: str, duration: float, stats: typing.Optional[raccoon.timing.models.StepStatistics]) -> typing.Optional[raccoon.timing.models.AnomalyDetection]:
        """
        Return anomaly record if duration exceeds mean +/- threshold * stddev.
        """
    def _fire_callbacks(self, anomaly: raccoon.timing.models.AnomalyDetection) -> None:
        """
        Invoke anomaly callbacks without interrupting mission execution.
        """
    def _log_baseline_progress(self, signature: str, prior_samples: int) -> None:
        """
        Emit cold-start info while collecting the first few samples.
        """
    def configure(self, config: raccoon.timing.config.TimingConfig) -> None:
        """
        Replace configuration at runtime.
        """
    def get_upper_bound(self, signature: str) -> typing.Optional[float]:
        """
        Return the anomaly upper bound for a signature, or ``None`` if no baseline.
        
        This is the duration above which an execution would be flagged as
        SLOWER than expected.  Used by the live watchdog in ``Step.run_step``.
        """
    def record_execution(self, signature: str, duration: float) -> typing.Optional[raccoon.timing.models.AnomalyDetection]:
        """
        Persist execution and evaluate for anomalies.
        
        Returns:
            The detected anomaly, or ``None`` if the execution was normal.
        """
    def register_anomaly_callback(self, callback: typing.Callable[[raccoon.timing.models.AnomalyDetection], typing.Awaitable[NoneType]]) -> None:
        """
        Register an async callback to run when an anomaly is detected.
        """
AnomalyCallback: typing._CallableGenericAlias  # value = typing.Callable[[raccoon.timing.models.AnomalyDetection], typing.Awaitable[NoneType]]
