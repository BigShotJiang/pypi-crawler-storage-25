from __future__ import annotations
import asyncio as asyncio
from raccoon.foundation import initialize_logging
from raccoon.log import debug
from raccoon.log import error
from raccoon.log import info
from raccoon.log import warn
__all__: list[str] = ['Synchronizer', 'asyncio', 'debug', 'error', 'info', 'initialize_logging', 'warn']
class Synchronizer:
    """
    Mission-relative clock used by checkpoint-aware timing steps.
    """
    def __init__(self):
        """
        Create a synchronizer with no active start time.
        """
    def do_until_checkpoint(self, checkpoint_seconds, func, *args, **kwargs):
        """
        
        Execute a function until the specified checkpoint is reached.
        
        Args:
            checkpoint_seconds: The time in seconds to wait until the checkpoint.
            func: The function to execute.
            *args: Positional arguments for the function.
            **kwargs: Keyword arguments for the function.
        """
    def get_time(self):
        """
        Return seconds elapsed since ``start_recording()`` was called.
        """
    def start_recording(self):
        """
        Capture the current event-loop time as checkpoint zero.
        """
    def wait_until_checkpoint(self, checkpoint_seconds):
        """
        Sleep until the mission-relative checkpoint or log that it was missed.
        """
