from __future__ import annotations
import aiosqlite as aiosqlite
import asyncio as asyncio
import logging as logging
from pathlib._local import Path
from raccoon.timing.models import AnomalyDetection
import time as time
__all__: list[str] = ['AnomalyDetection', 'Path', 'StepTimingDatabase', 'aiosqlite', 'asyncio', 'logger', 'logging', 'time']
class StepTimingDatabase:
    """
    Async SQLite store for raw step execution history and anomaly flags.
    """
    def __init__(self, db_path: str) -> None:
        """
        Create a database wrapper for the configured SQLite path.
        """
    def _check_integrity(self) -> bool:
        """
        Return True if the database passes an integrity check.
        """
    def fetch_recent_durations(self, signature: str, limit: int) -> typing.List[float]:
        """
        Return the most recent non-anomalous durations for a signature.
        """
    def initialize(self) -> None:
        """
        Create database and schema if needed.
        
        If the existing database file is corrupted, it is deleted and
        recreated automatically.
        """
    def insert_execution(self, signature: str, duration: float, anomaly: typing.Optional[raccoon.timing.models.AnomalyDetection]) -> None:
        """
        Insert a completed execution into the database.
        """
logger: logging.Logger  # value = <Logger raccoon.timing.database (INFO)>
