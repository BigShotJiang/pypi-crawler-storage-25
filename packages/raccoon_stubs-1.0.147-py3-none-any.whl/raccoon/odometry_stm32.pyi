"""
Python bindings for STM32-sourced odometry
"""
from __future__ import annotations
import raccoon.foundation
import raccoon.hal
import raccoon.kinematics
import raccoon.odometry
import raccoon.odometry_fused
__all__: list[str] = ['Stm32Odometry', 'Stm32OdometryConfig']
class Stm32Odometry(raccoon.odometry.IOdometry):
    """
    Odometry that reads dead-reckoning state from the STM32 coprocessor.
    The kinematics matrix is sent to the STM32 at construction time so it
    can run odometry on-board at full BEMF sample rate (~200Hz per motor).
    All getters return the latest snapshot from the coprocessor.
    """
    def __init__(self, imu: raccoon.hal.IMU, kinematics: raccoon.kinematics.IKinematics, bridge: raccoon.hal.OdometryBridge, config: Stm32OdometryConfig = ...) -> None:
        ...
    def get_absolute_heading(self) -> float:
        ...
    def get_distance_from_origin(self) -> raccoon.odometry_fused.DistanceFromOrigin:
        ...
    def get_heading(self) -> float:
        ...
    def get_heading_error(self, target_heading_rad: float) -> float:
        ...
    def get_path_length(self) -> float:
        ...
    def get_pose(self) -> raccoon.foundation.Pose:
        ...
    def reset(self) -> None:
        ...
    def update(self, dt: float) -> None:
        ...
class Stm32OdometryConfig:
    """
    Configuration for Stm32Odometry.
    """
    imu_ready_timeout_ms: int
    turn_axis: str
    def __init__(self, imu_ready_timeout_ms: int = 1000, turn_axis: str = 'world_z') -> None:
        ...
