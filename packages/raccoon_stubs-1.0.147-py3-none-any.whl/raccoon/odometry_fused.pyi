"""
Python bindings for libstp-odometry_fused
"""
from __future__ import annotations
import raccoon.foundation
import raccoon.hal
import raccoon.kinematics
import raccoon.odometry
__all__: list[str] = ['DistanceFromOrigin', 'FusedOdometry', 'FusedOdometryConfig']
class DistanceFromOrigin:
    """
    Distance measurements from the origin (set by last reset).
    """
    def __repr__(self) -> str:
        ...
    @property
    def forward(self) -> float:
        """
        Distance in initial forward direction (m). Positive=forward, negative=backward.
        """
    @property
    def lateral(self) -> float:
        """
        Lateral drift perpendicular to initial direction (m). Positive=right, negative=left.
        """
    @property
    def straight_line(self) -> float:
        """
        Straight-line Euclidean distance from origin (m).
        """
class FusedOdometry(raccoon.odometry.IOdometry):
    """
    Fused odometry combining IMU orientation with kinematics velocity integration.
    Integrates IMU orientation tracking with auto-calibration.
    Integrates body velocities from kinematics for position estimation.
    Tracks distances from origin in forward/lateral directions.
    Provides all coordinate frame transformations.
    Position will drift over time - use reset() to establish a fresh local origin.
    """
    def __init__(self, imu: raccoon.hal.IMU, kinematics: raccoon.kinematics.IKinematics, config: FusedOdometryConfig = ...) -> None:
        """
        Create fused odometry with IMU and kinematics model.
        
        IMU will be auto-calibrated on first update - the initial orientation
        is captured and all subsequent readings are relative to it.
        
        Args:
            imu: IMU sensor instance (shared_ptr)
            kinematics: Kinematics model (shared_ptr, provides velocity estimates)
            config: Optional configuration (default uses 1000ms IMU timeout)
        """
    def get_absolute_heading(self) -> float:
        """
        Get absolute IMU heading unaffected by reset().
        
        Returns:
            Heading in radians (CCW-positive). Stable across odometry resets.
        """
    def get_distance_from_origin(self) -> DistanceFromOrigin:
        """
        Get distance measurements from origin (set by last reset).
        
        Returns:
            DistanceFromOrigin with forward, lateral, and straight_line distances
        """
    def get_heading(self) -> float:
        """
        Get current heading (yaw) relative to origin orientation.
        
        Returns:
            Heading in radians, range [-π, π].
            0 = facing initial forward direction
            positive = rotated CCW, negative = rotated CW
        """
    def get_heading_error(self, target_heading_rad: float) -> float:
        """
        Get heading error to reach a target heading.
        
        Computes shortest angular path with proper wraparound handling.
        Perfect for use as PID input.
        
        Args:
            target_heading_rad: Target heading in radians
        
        Returns:
            Signed angular error in radians [-π, π].
            Positive = turn CCW, negative = turn CW
        """
    def get_path_length(self) -> float:
        """
        Get cumulative path length (odometer) in meters.
        
        Monotonically increasing — NOT affected by reset().
        
        Returns:
            Total distance traveled in meters since construction.
        """
    def get_pose(self) -> raccoon.foundation.Pose:
        """
        Get current pose estimate (position + orientation).
        """
    def reset(self) -> None:
        """
        Reset odometry to origin (zero position, identity orientation).
        
        IMU will be re-calibrated on next update.
        """
    def update(self, dt: float) -> None:
        """
        Update odometry estimate with time delta.
        
        Args:
            dt: Time delta in seconds
        """
class FusedOdometryConfig:
    """
    Configuration for FusedOdometry.
    """
    def __init__(self, imu_ready_timeout_ms: int = 1000, enable_accel_fusion: bool = True, bemf_trust: float = 0.949999988079071, turn_axis: str = 'world_z') -> None:
        ...
    @property
    def bemf_trust(self) -> float:
        """
        Complementary filter alpha: 1.0 = pure BEMF, 0.0 = pure IMU (default: 0.95)
        """
    @bemf_trust.setter
    def bemf_trust(self, arg0: float) -> None:
        ...
    @property
    def enable_accel_fusion(self) -> bool:
        """
        Enable complementary filter fusing BEMF + IMU accel (default: true)
        """
    @enable_accel_fusion.setter
    def enable_accel_fusion(self, arg0: bool) -> None:
        ...
    @property
    def imu_ready_timeout_ms(self) -> int:
        """
        Timeout waiting for IMU to be ready (milliseconds, default: 1000)
        """
    @imu_ready_timeout_ms.setter
    def imu_ready_timeout_ms(self, arg0: int) -> None:
        ...
    @property
    def turn_axis(self) -> str:
        """
        Yaw rate axis: 'world_z' (default), 'body_x', 'body_y', or 'body_z'. Use a body axis when the robot's up-axis is not body Z.
        """
    @turn_axis.setter
    def turn_axis(self, arg0: str) -> None:
        ...
