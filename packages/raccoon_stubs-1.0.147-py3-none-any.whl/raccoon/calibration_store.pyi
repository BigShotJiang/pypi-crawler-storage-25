"""
Python bindings for libstp-calibration-store
"""
from __future__ import annotations
import typing
__all__: list[str] = ['CalibrationType', 'IR_SENSOR', 'get_readings', 'get_set_names', 'has_readings', 'store_readings']
class CalibrationType:
    """
    Members:
    
      IR_SENSOR
    """
    IR_SENSOR: typing.ClassVar[CalibrationType]  # value = <CalibrationType.IR_SENSOR: 0>
    __members__: typing.ClassVar[dict[str, CalibrationType]]  # value = {'IR_SENSOR': <CalibrationType.IR_SENSOR: 0>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
def get_readings(type: ..., set_name: str = 'default') -> list[float]:
    """
    Get the values of the last reading from the File
    """
def get_set_names(type: ...) -> list[str]:
    """
    Returns the names of all calibration sets for a type
    """
def has_readings(type: ..., set_name: str = 'default') -> bool:
    """
    Checks if values are present for that reading
    """
def store_readings(type: ..., whiteThreshold: float, blackThreshold: float, set_name: str = 'default') -> None:
    """
    Stores the readings in the File
    """
IR_SENSOR: CalibrationType  # value = <CalibrationType.IR_SENSOR: 0>
