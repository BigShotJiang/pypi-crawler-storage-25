"""
Thin wrappers around the C++ logging backend with per-file filtering.

Every call automatically captures the caller's Python filename so that
``set_file_level("my_module.py", Level.debug)`` works the same way it does
for C++ source files.
"""
from __future__ import annotations
from raccoon.foundation import Level
from raccoon.foundation import _log_filtered
import sys as sys
__all__: list[str] = ['Level', 'debug', 'error', 'info', 'sys', 'trace', 'warn']
def _caller_filename(stacklevel: int) -> str:
    ...
def debug(message: str, *, _stacklevel: int = 1) -> None:
    ...
def error(message: str, *, _stacklevel: int = 1) -> None:
    ...
def info(message: str, *, _stacklevel: int = 1) -> None:
    ...
def trace(message: str, *, _stacklevel: int = 1) -> None:
    ...
def warn(message: str, *, _stacklevel: int = 1) -> None:
    ...
