"""
Python bindings for libstp-hal
"""
from __future__ import annotations
import raccoon.foundation
__all__: list[str] = ['AnalogSensor', 'DigitalSensor', 'IMU', 'IMotor', 'IOdometryBridge', 'Motor', 'OdometryBridge', 'Servo']
class AnalogSensor:
    port: int
    def __init__(self, port: int) -> None:
        ...
    def read(self) -> int:
        ...
class DigitalSensor:
    port: int
    def __init__(self, port: int) -> None:
        ...
    def read(self) -> bool:
        ...
class IMU:
    def __init__(self) -> None:
        """
        Create an IMU instance
        """
    def calibrate(self) -> None:
        """
        Calibrate the IMU sensor
        """
    def get_angular_velocity(self) -> tuple:
        """
        Get angular velocity (gyroscope) as (x, y, z) in rad/s
        """
    def get_heading(self) -> float:
        """
        Get firmware-computed heading in radians
        """
    def get_integrated_velocity(self) -> tuple:
        """
        Get firmware-integrated velocity as (x, y, z) in m/s
        """
    def get_linear_acceleration(self) -> tuple:
        """
        Get gravity-compensated linear acceleration as (x, y, z) in m/s²
        """
    def get_yaw_rate(self) -> float:
        """
        Get angular rate along the configured turn axis in rad/s (default mode: world_z)
        """
    def get_yaw_rate_axis_mode(self) -> str:
        """
        Get current turn-rate axis mode string
        """
    def read(self) -> tuple:
        """
        Read acceleration, gyroscope, and magnetometer data
        """
    def reset_integrated_velocity(self) -> None:
        """
        Reset the firmware-integrated velocity accumulator
        """
    def set_yaw_rate_axis_mode(self, mode: str) -> None:
        """
        Set turn-rate axis mode used by get_yaw_rate(): 'world_z' (default), 'body_x', 'body_y', or 'body_z'
        """
class IMotor:
    def brake(self) -> None:
        ...
    def get_bemf(self) -> int:
        """
        Read current BEMF velocity value from firmware
        """
    def get_calibration(self) -> raccoon.foundation.MotorCalibration:
        ...
    def get_position(self) -> int:
        ...
    def is_done(self) -> bool:
        """
        Check if position move is complete
        """
    def move_relative(self, velocity: int, delta_position: int) -> None:
        """
        Move relative position at given velocity
        """
    def move_to_position(self, velocity: int, goal_position: int) -> None:
        """
        Move to absolute position at given velocity
        """
    def off(self) -> None:
        """
        Disable motor completely (no power, no brake — free-spinning)
        """
    def reset_position_counter(self) -> None:
        """
        Reset the position counter to zero
        """
    def set_calibration(self, calibration: raccoon.foundation.MotorCalibration) -> None:
        ...
    def set_speed(self, percent: int) -> None:
        ...
    def set_velocity(self, velocity: int) -> None:
        """
        Set velocity target in BEMF units - firmware handles PID
        """
    @property
    def inverted(self) -> bool:
        ...
    @property
    def port(self) -> int:
        ...
class IOdometryBridge:
    """
    Abstract interface for coprocessor odometry communication.
    """
class Motor(IMotor):
    @staticmethod
    def disable_all() -> None:
        ...
    @staticmethod
    def enable_all() -> None:
        ...
    def __init__(self, port: int, inverted: bool = False, calibration: raccoon.foundation.MotorCalibration = ...) -> None:
        ...
    def brake(self) -> None:
        ...
    def get_bemf(self) -> int:
        ...
    def get_calibration(self) -> raccoon.foundation.MotorCalibration:
        ...
    def get_position(self) -> int:
        ...
    def is_done(self) -> bool:
        ...
    def move_relative(self, velocity: int, delta_position: int) -> None:
        ...
    def move_to_position(self, velocity: int, goal_position: int) -> None:
        ...
    def off(self) -> None:
        """
        Disable motor completely (no power, no brake — free-spinning)
        """
    def reset_position_counter(self) -> None:
        """
        Reset the position counter to zero
        """
    def set_calibration(self, calibration: raccoon.foundation.MotorCalibration) -> None:
        """
        Update motor calibration (including ticks_to_rad)
        """
    def set_speed(self, percent: int) -> None:
        ...
    def set_velocity(self, velocity: int) -> None:
        ...
    @property
    def inverted(self) -> bool:
        ...
    @property
    def port(self) -> int:
        ...
class OdometryBridge(IOdometryBridge):
    """
    Platform-provided odometry bridge for coprocessor communication.
    """
    def __init__(self) -> None:
        ...
class Servo:
    port: int
    @staticmethod
    def fully_disable_all() -> None:
        ...
    def __init__(self, port: int) -> None:
        ...
    def disable(self) -> None:
        ...
    def enable(self) -> None:
        ...
    def get_position(self) -> float:
        ...
    def set_position(self, position: float) -> None:
        ...
