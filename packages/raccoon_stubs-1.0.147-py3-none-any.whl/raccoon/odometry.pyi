"""
Python bindings for libstp-odometry
"""
from __future__ import annotations
import raccoon.foundation
__all__: list[str] = ['IOdometry']
class IOdometry:
    def get_absolute_heading(self) -> float:
        """
        Get absolute IMU heading unaffected by reset().
        
        Returns:
            Heading in radians (CCW-positive). Stable across odometry resets.
        """
    def get_path_length(self) -> float:
        """
        Get cumulative path length (odometer) in meters.
        
        Monotonically increasing — NOT affected by reset().
        Accumulates distance traveled each update cycle regardless of direction.
        
        Returns:
            Total distance traveled in meters since construction.
        """
    def get_pose(self) -> raccoon.foundation.Pose:
        ...
    def reset(self) -> None:
        ...
    def update(self, dt: float) -> None:
        ...
