"""

BotUI - Dynamic UI system for robotics applications.

This module provides a type-safe, event-driven system for creating
UI screens in Python that are rendered by Flutter.

Architecture:
    - UIScreen: Self-contained screens with their own events and state
    - UIStep: Steps that orchestrate which screens to show
    - Widgets: Type-safe dataclasses that serialize to JSON for Flutter

================================================================================
QUICK START - Simple one-liners (recommended for most cases)
================================================================================

    class MyStep(UIStep):
        async def _execute_step(self, robot):
            # Show a message
            await self.message("Calibration complete!")

            # Ask for confirmation
            if await self.confirm("Start calibration?"):
                await self.do_calibration()

            # Get a number
            distance = await self.input_number("Enter distance:", unit="cm")

            # Let user choose
            mode = await self.choose("Select mode:", ["Fast", "Normal", "Precise"])

            # Wait for button press
            await self.wait_for_button("Position robot and press button")

================================================================================
BLOCKING MODE - Show screen, wait for result
================================================================================

    class MyStep(UIStep):
        async def _execute_step(self, robot):
            # Show screen and wait for it to close
            result = await self.show(MyScreen())

================================================================================
NON-BLOCKING MODE - UI + background logic together
================================================================================

    class MyStep(UIStep):
        async def _execute_step(self, robot):
            # Option 1: Context manager (recommended)
            async with self.showing(ProgressScreen()) as ctx:
                for i in range(100):
                    ctx.screen.progress = i
                    await ctx.screen.refresh()
                    await asyncio.sleep(0.1)

            # Option 2: Manual display + pump
            await self.display(StatusScreen("Processing..."))
            for i in range(100):
                await self.pump_events()  # Handle UI events
                await asyncio.sleep(0.1)
            await self.close_ui()

            # Option 3: Run task with UI
            result = await self.run_with_ui(
                LoadingScreen("Calibrating..."),
                self.do_calibration
            )

================================================================================
CUSTOM SCREENS - Full control
================================================================================

    class MyCustomScreen(UIScreen[bool]):
        title = "Custom"

        def __init__(self, message: str):
            super().__init__()
            self.message = message

        def build(self) -> Widget:
            return Center(children=[
                Text(self.message, size="large"),
                Button("ok", "OK", style="success"),
            ])

        @on_click("ok")
        async def on_ok(self):
            self.close(True)
"""
from __future__ import annotations
from raccoon.ui.events import on_button_press
from raccoon.ui.events import on_change
from raccoon.ui.events import on_click
from raccoon.ui.events import on_keypad
from raccoon.ui.events import on_screen_tap
from raccoon.ui.events import on_slider
from raccoon.ui.events import on_submit
from raccoon.ui.screen import UIScreen
from raccoon.ui.screens.basic import ChoiceScreen
from raccoon.ui.screens.basic import ConfirmScreen
from raccoon.ui.screens.basic import MessageScreen
from raccoon.ui.screens.basic import ProgressScreen
from raccoon.ui.screens.basic import StatusScreen
from raccoon.ui.screens.basic import WaitForButtonScreen
from raccoon.ui.screens.distance import DistanceConfirmResult
from raccoon.ui.screens.distance import DistanceConfirmScreen
from raccoon.ui.screens.distance import DistanceDrivingScreen
from raccoon.ui.screens.distance import DistanceMeasureScreen
from raccoon.ui.screens.distance import DistancePrepareScreen
from raccoon.ui.screens.input import NumberInputResult
from raccoon.ui.screens.input import NumberInputScreen
from raccoon.ui.screens.input import SliderInputResult
from raccoon.ui.screens.input import SliderInputScreen
from raccoon.ui.screens.input import TextInputResult
from raccoon.ui.screens.input import TextInputScreen
from raccoon.ui.screens.wfl import WFLConfirmResult
from raccoon.ui.screens.wfl import WFLConfirmScreen
from raccoon.ui.screens.wfl import WFLMeasureResult
from raccoon.ui.screens.wfl import WFLMeasureScreen
from raccoon.ui.step import UIStep
from raccoon.ui.widgets import AnimatedRobot
from raccoon.ui.widgets import Button
from raccoon.ui.widgets import CalibrationChart
from raccoon.ui.widgets import Card
from raccoon.ui.widgets import Center
from raccoon.ui.widgets import Checkbox
from raccoon.ui.widgets import CircularSlider
from raccoon.ui.widgets import Column
from raccoon.ui.widgets import DistanceBadge
from raccoon.ui.widgets import Divider
from raccoon.ui.widgets import Dropdown
from raccoon.ui.widgets import Expanded
from raccoon.ui.widgets import HintBox
from raccoon.ui.widgets import Icon
from raccoon.ui.widgets import LightBulb
from raccoon.ui.widgets import MeasuringTape
from raccoon.ui.widgets import NumericInput
from raccoon.ui.widgets import NumericKeypad
from raccoon.ui.widgets import ProgressSpinner
from raccoon.ui.widgets import PulsingArrow
from raccoon.ui.widgets import ResultsTable
from raccoon.ui.widgets import RobotDrivingAnimation
from raccoon.ui.widgets import Row
from raccoon.ui.widgets import SensorGraph
from raccoon.ui.widgets import SensorValue
from raccoon.ui.widgets import Slider
from raccoon.ui.widgets import Spacer
from raccoon.ui.widgets import Split
from raccoon.ui.widgets import StatusBadge
from raccoon.ui.widgets import StatusIcon
from raccoon.ui.widgets import Text
from raccoon.ui.widgets import TextInput
from raccoon.ui.widgets import Widget
from . import events
from . import raccoon
from . import screen
from . import screens
from . import step
from . import widgets
__all__: list = ['Widget', 'Text', 'Icon', 'Spacer', 'Divider', 'StatusBadge', 'StatusIcon', 'HintBox', 'DistanceBadge', 'ResultsTable', 'Button', 'Slider', 'Checkbox', 'Dropdown', 'NumericKeypad', 'NumericInput', 'TextInput', 'SensorValue', 'SensorGraph', 'CalibrationChart', 'LightBulb', 'AnimatedRobot', 'CircularSlider', 'ProgressSpinner', 'PulsingArrow', 'RobotDrivingAnimation', 'MeasuringTape', 'Row', 'Column', 'Center', 'Card', 'Split', 'Expanded', 'on_click', 'on_change', 'on_submit', 'on_keypad', 'on_button_press', 'on_slider', 'on_screen_tap', 'UIScreen', 'UIStep', 'WaitForButtonScreen', 'ConfirmScreen', 'MessageScreen', 'ChoiceScreen', 'ProgressScreen', 'StatusScreen', 'NumberInputScreen', 'NumberInputResult', 'TextInputScreen', 'TextInputResult', 'SliderInputScreen', 'SliderInputResult', 'WFLMeasureScreen', 'WFLConfirmScreen', 'WFLMeasureResult', 'WFLConfirmResult', 'DistancePrepareScreen', 'DistanceDrivingScreen', 'DistanceMeasureScreen', 'DistanceConfirmScreen', 'DistanceConfirmResult']
