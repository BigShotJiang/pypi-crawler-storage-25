"""

UIStep - Base class for Steps that show UI screens.

The Step orchestrates the flow, screens handle their own UI/events.
"""
from __future__ import annotations
import abc
from abc import ABC
import asyncio as asyncio
from contextlib import asynccontextmanager
import json as json
from raccoon.button import is_pressed
import raccoon.step.base
from raccoon.step.base import Step
from raccoon.ui.raccoon.screen_render_answer_t import screen_render_answer_t
from raccoon.ui.raccoon.screen_render_t import screen_render_t
import raccoon.ui.screen
from raccoon.ui.screen import UIScreen
from raccoon.ui.widgets import Button
from raccoon.ui.widgets import Center
from raccoon.ui.widgets import Column
from raccoon.ui.widgets import Row
from raccoon.ui.widgets import Spacer
from raccoon.ui.widgets import Text
from raccoon_transport.transport import Transport
import time as time
import typing
from typing import Any
from typing import TypeVar
__all__: list[str] = ['ABC', 'Any', 'Button', 'Center', 'Column', 'Row', 'Spacer', 'Step', 'T', 'Text', 'Transport', 'TypeVar', 'UIScreen', 'UIStep', 'asynccontextmanager', 'asyncio', 'is_pressed', 'json', 'screen_render_answer_t', 'screen_render_t', 'time']
class UIStep(raccoon.step.base.Step, abc.ABC):
    """
    
    Base class for Steps that show UI screens.
    
    The Step is responsible for orchestrating the flow by showing
    screens and collecting their results. Each screen handles its
    own events and state.
    
    Example:
        class MyCalibration(UIStep):
            async def _execute_step(self, robot):
                # Show first screen, wait for result
                off_value = await self.show(MeasureScreen(is_on=False))
    
                # Show second screen
                on_value = await self.show(MeasureScreen(is_on=True))
    
                # Show confirmation
                result = await self.show(ConfirmScreen(off_value, on_value))
    
                if not result.confirmed:
                    # Retry
                    return await self._execute_step(robot)
    
                self.result = result
    """
    _SCREEN_NAME: typing.ClassVar[str] = 'dynamic_ui'
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    @staticmethod
    def showing(*args, **kwds):
        """
        
        Context manager for displaying a screen while running code.
        
        Events are automatically pumped. Screen closes when exiting context.
        
        Example:
            async with self.showing(ProgressScreen()) as ctx:
                for i in range(100):
                    ctx.screen.progress = i
                    await ctx.screen.refresh()
                    await asyncio.sleep(0.1)
        """
    def __init__(self):
        ...
    def _button_listener(self, queue: asyncio.Queue) -> None:
        """
        Listen for physical button presses.
        """
    def _force_close_ui(self) -> None:
        """
        Force close any active UI, swallowing errors to ensure cleanup.
        """
    def _render_screen(self, screen: UIScreen) -> None:
        """
        Send screen to Flutter via LCM.
        """
    def _run_screen_events(self, screen: UIScreen) -> None:
        """
        Run event loop until screen closes.
        """
    def _teardown_pump_sub(self) -> None:
        """
        Unsubscribe the persistent pump subscription if active.
        """
    def choose(self, prompt: str, options: list[str], title: str = 'Choose') -> str | None:
        """
        
        Let user choose from a list of options.
        
        Returns None if cancelled.
        
        Example:
            mode = await self.choose("Select mode:", ["Fast", "Normal", "Precise"])
        """
    def close_ui(self) -> None:
        """
        Close any active screen.
        """
    def confirm(self, text: str, title: str = 'Confirm', yes_label: str = 'Yes', no_label: str = 'No') -> bool:
        """
        
        Show a yes/no confirmation dialog.
        
        Example:
            if await self.confirm("Start calibration?"):
                await self.do_calibration()
        """
    def display(self, screen: UIScreen) -> None:
        """
        
        Show a screen without waiting for it to close.
        
        Use this when you want to run background logic while the UI is visible.
        Events will still be dispatched to the screen's handlers.
        
        Example:
            await self.display(StatusScreen("Processing..."))
            for i in range(100):
                await self.update_progress(i)
                await asyncio.sleep(0.1)
            await self.close_ui()
        """
    def input_number(self, prompt: str, title: str = 'Input', default: float = 0, unit: str = '', min_value: float | None = None, max_value: float | None = None) -> float | None:
        """
        
        Get a numeric value from the user.
        
        Returns None if cancelled.
        
        Example:
            distance = await self.input_number("Enter distance:", unit="cm")
            speed = await self.input_number("Speed:", min_value=0, max_value=100)
        """
    def input_slider(self, prompt: str, min: float, max: float, title: str = 'Input', default: float = None) -> float | None:
        """
        
        Get a value using a slider.
        
        Returns None if cancelled.
        
        Example:
            speed = await self.input_slider("Select speed:", min=0, max=100)
        """
    def input_text(self, prompt: str, title: str = 'Input', default: str = '', placeholder: str = '') -> str | None:
        """
        
        Get text input from the user.
        
        Returns None if cancelled.
        
        Example:
            name = await self.input_text("Enter robot name:")
        """
    def message(self, text: str, title: str = 'Info', button_label: str = 'OK') -> None:
        """
        
        Show a simple message and wait for acknowledgment.
        
        Example:
            await self.message("Calibration complete!")
            await self.message("Error occurred", title="Error")
        """
    def pump_events(self, timeout: float = 0) -> None:
        """
        
        Process pending UI events without blocking.
        
        Call this periodically in your background loop to handle user input.
        
        Example:
            await self.display(MyScreen())
            while running:
                await self.pump_events()
                # ... do background work ...
                await asyncio.sleep(0.05)
        """
    def run_step(self, robot: GenericRobot) -> None:
        """
        
        Run the step with automatic UI cleanup.
        
        Ensures the UI is closed even if the step fails or is cancelled.
        """
    def run_with_ui(self, screen: UIScreen, task: typing.Callable[[], Awaitable[typing.Any]] | Awaitable[typing.Any], poll_interval: float = 0.05) -> typing.Any:
        """
        
        Run a background task while showing a screen.
        
        Events are pumped automatically. Returns when task completes.
        
        Args:
            screen: The screen to display while task runs
            task: Either a coroutine or a callable that returns a coroutine
            poll_interval: How often to pump UI events (seconds)
        
        Example:
            # With callable:
            result = await self.run_with_ui(
                LoadingScreen("Calibrating..."),
                self.do_calibration
            )
        
            # With coroutine directly:
            result = await self.run_with_ui(
                LoadingScreen("Calibrating..."),
                self.do_calibration()
            )
        """
    def show(self, screen: UIScreen[T]) -> T:
        """
        
        Show a screen and wait for it to close.
        
        The screen's event handlers will be called as the user interacts.
        When the screen calls close(result), this method returns that result.
        
        Args:
            screen: The UIScreen instance to display
        
        Returns:
            Whatever the screen passed to close()
        """
    def wait_for_button(self, text: str = 'Press button to continue', title: str = 'Ready') -> None:
        """
        
        Wait for physical button press.
        
        Example:
            await self.wait_for_button("Position robot and press button")
        """
class _QuickChoiceScreen(raccoon.ui.screen.UIScreen):
    """
    Choice selection screen.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[typing.Optional[str]])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    def __init__(self, prompt: str, options: list[str], title: str):
        ...
    def _dispatch_event(self, event: dict) -> None:
        ...
    def build(self):
        ...
class _QuickConfirmScreen(raccoon.ui.screen.UIScreen):
    """
    Yes/No confirmation screen.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[bool])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id: typing.ClassVar[str] = 'yes'
    def __init__(self, text: str, title: str, yes_label: str, no_label: str):
        ...
    def _dispatch_event(self, event: dict) -> None:
        ...
    def build(self):
        ...
class _QuickMessageScreen(raccoon.ui.screen.UIScreen):
    """
    Simple message screen.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[NoneType])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id: typing.ClassVar[str] = 'ok'
    def __init__(self, text: str, title: str, button_label: str):
        ...
    def _dispatch_event(self, event: dict) -> None:
        ...
    def build(self):
        ...
class _QuickWaitButtonScreen(raccoon.ui.screen.UIScreen):
    """
    Wait for physical button press.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[NoneType])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    def __init__(self, text: str, title: str):
        ...
    def _dispatch_event(self, event: dict) -> None:
        ...
    def build(self):
        ...
class _ShowingContext:
    """
    Context for `showing()` context manager.
    """
    def __init__(self, screen: UIScreen, step: UIStep):
        ...
    def pump(self) -> None:
        """
        Pump events manually.
        """
T: typing.TypeVar  # value = ~T
