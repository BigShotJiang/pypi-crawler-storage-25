"""

Basic pre-built screens for common UI patterns.
"""
from __future__ import annotations
from raccoon.ui.events import on_button_press
from raccoon.ui.events import on_click
import raccoon.ui.screen
from raccoon.ui.screen import UIScreen
import raccoon.ui.widgets
from raccoon.ui.widgets import Button
from raccoon.ui.widgets import Center
from raccoon.ui.widgets import Column
from raccoon.ui.widgets import HintBox
from raccoon.ui.widgets import Icon
from raccoon.ui.widgets import ProgressSpinner
from raccoon.ui.widgets import Row
from raccoon.ui.widgets import Spacer
from raccoon.ui.widgets import Text
from raccoon.ui.widgets import Widget
import typing
__all__: list[str] = ['Button', 'Center', 'ChoiceScreen', 'Column', 'ConfirmScreen', 'HintBox', 'Icon', 'MessageScreen', 'ProgressScreen', 'ProgressSpinner', 'Row', 'Spacer', 'StatusScreen', 'Text', 'UIScreen', 'WaitForButtonScreen', 'Widget', 'on_button_press', 'on_click']
class ChoiceScreen(raccoon.ui.screen.UIScreen):
    """
    
    Multiple choice selection. Returns the selected option ID.
    
    Example:
        choice = await self.show(ChoiceScreen(
            "Select Mode",
            "Choose a driving mode:",
            [
                ("careful", "Careful", "Slow and precise"),
                ("normal", "Normal", "Balanced speed"),
                ("fast", "Fast", "Maximum speed"),
            ]
        ))
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[str])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    def __init__(self, title: str, message: str, choices: typing.List[tuple], cancel_label: typing.Optional[str] = 'Cancel'):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_cancel(self):
        ...
class ConfirmScreen(raccoon.ui.screen.UIScreen):
    """
    
    Two-button confirmation dialog. Returns True or False.
    
    Example:
        confirmed = await self.show(ConfirmScreen(
            "Warning",
            "Robot will move. Continue?"
        ))
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[bool])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id: typing.ClassVar[str] = 'confirm'
    def __init__(self, title: str, message: str, confirm_label: str = 'Confirm', cancel_label: str = 'Cancel', confirm_style: str = 'success', icon_name: str = 'help_outline', icon_color: str = 'blue'):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_cancel(self):
        ...
    def on_confirm(self):
        ...
class MessageScreen(raccoon.ui.screen.UIScreen):
    """
    
    Shows a message with a single dismiss button.
    
    Example:
        await self.show(MessageScreen(
            "Success",
            "Calibration complete!",
            icon="check",
            icon_color="green"
        ))
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[NoneType])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id: typing.ClassVar[str] = 'ok'
    def __init__(self, title: str, message: str, button_label: str = 'OK', icon_name: typing.Optional[str] = None, icon_color: str = 'blue'):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_ok(self):
        ...
class ProgressScreen(raccoon.ui.screen.UIScreen):
    """
    
    Progress/loading screen for use with non-blocking display.
    
    Use with `display()` or `showing()` while running background tasks.
    
    Example:
        async with self.showing(ProgressScreen("Calibrating...")) as ctx:
            for i in range(100):
                ctx.screen.progress = i
                ctx.screen.status = f"Step {i+1}/100"
                await ctx.screen.refresh()
                await asyncio.sleep(0.1)
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[NoneType])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    title: typing.ClassVar[str] = 'Working'
    def __init__(self, message: str = 'Please wait...', show_spinner: bool = True, show_progress: bool = False):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
class StatusScreen(raccoon.ui.screen.UIScreen):
    """
    
    Simple status display screen for non-blocking use.
    
    Shows an icon, message, and optional status text.
    Good for showing current state during long operations.
    
    Example:
        await self.display(StatusScreen(
            "Connecting...",
            icon="wifi",
            icon_color="blue"
        ))
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[NoneType])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    title: typing.ClassVar[str] = 'Status'
    def __init__(self, message: str, icon_name: str = 'info', icon_color: str = 'blue', status: str = ''):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
class WaitForButtonScreen(raccoon.ui.screen.UIScreen):
    """
    
    Shows a message and waits for physical button press.
    
    Example:
        await self.show(WaitForButtonScreen("Place robot at start"))
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[NoneType])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    title: typing.ClassVar[str] = 'Ready'
    def __init__(self, message: str = 'Press the button to continue', icon_name: str = 'touch_app', icon_color: str = 'amber'):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_press(self):
        ...
