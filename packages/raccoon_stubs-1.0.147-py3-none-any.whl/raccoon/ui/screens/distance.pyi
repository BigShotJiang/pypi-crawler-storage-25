"""

Distance calibration screens.
"""
from __future__ import annotations
import dataclasses
from dataclasses import dataclass
from raccoon.ui.events import on_button_press
from raccoon.ui.events import on_change
from raccoon.ui.events import on_click
from raccoon.ui.events import on_keypad
import raccoon.ui.screen
from raccoon.ui.screen import UIScreen
import raccoon.ui.widgets
from raccoon.ui.widgets import AnimatedRobot
from raccoon.ui.widgets import Button
from raccoon.ui.widgets import Card
from raccoon.ui.widgets import Center
from raccoon.ui.widgets import Column
from raccoon.ui.widgets import HintBox
from raccoon.ui.widgets import NumericInput
from raccoon.ui.widgets import NumericKeypad
from raccoon.ui.widgets import ProgressSpinner
from raccoon.ui.widgets import PulsingArrow
from raccoon.ui.widgets import ResultsTable
from raccoon.ui.widgets import RobotDrivingAnimation
from raccoon.ui.widgets import Row
from raccoon.ui.widgets import Spacer
from raccoon.ui.widgets import Split
from raccoon.ui.widgets import StatusIcon
from raccoon.ui.widgets import Text
from raccoon.ui.widgets import Widget
import typing
__all__: list[str] = ['AnimatedRobot', 'Button', 'Card', 'Center', 'Column', 'DistanceConfirmResult', 'DistanceConfirmScreen', 'DistanceDrivingScreen', 'DistanceMeasureScreen', 'DistancePrepareScreen', 'HintBox', 'NumericInput', 'NumericKeypad', 'ProgressSpinner', 'PulsingArrow', 'ResultsTable', 'RobotDrivingAnimation', 'Row', 'Spacer', 'Split', 'StatusIcon', 'Text', 'UIScreen', 'Widget', 'dataclass', 'on_button_press', 'on_change', 'on_click', 'on_keypad']
class DistanceConfirmResult:
    """
    Result from DistanceConfirmScreen.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'confirmed': Field(name='confirmed',type=<class 'bool'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'scale_factor': Field(name='scale_factor',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('confirmed', 'scale_factor')
    def __eq__(self, other):
        ...
    def __init__(self, confirmed: bool, scale_factor: float) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class DistanceConfirmScreen(raccoon.ui.screen.UIScreen):
    """
    
    Confirm distance calibration results.
    
    Shows requested, measured, scale factor, and adjustment percentage.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[raccoon.ui.screens.distance.DistanceConfirmResult])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id: typing.ClassVar[str] = 'apply'
    title: typing.ClassVar[str] = 'Distance Calibration'
    def __init__(self, requested: float, measured: float):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_apply(self):
        ...
    def on_retry(self):
        ...
    @property
    def adjustment(self) -> float:
        ...
    @property
    def is_good(self) -> bool:
        ...
    @property
    def scale_factor(self) -> float:
        ...
class DistanceDrivingScreen(raccoon.ui.screen.UIScreen):
    """
    
    Driving animation screen shown while robot moves.
    
    This screen should be closed externally when driving completes.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[NoneType])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    title: typing.ClassVar[str] = 'Distance Calibration'
    def __init__(self, requested_distance: float):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
class DistanceMeasureScreen(raccoon.ui.screen.UIScreen):
    """
    
    Measure actual distance traveled.
    
    Shows numeric keypad for entering measured distance.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[float])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id: typing.ClassVar[str] = 'submit'
    title: typing.ClassVar[str] = 'Distance Calibration'
    def __init__(self, requested_distance: float, default_value: float = None):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_adjust(self, value: float):
        ...
    def on_key(self, key: str):
        ...
    def on_submit(self):
        ...
class DistancePrepareScreen(raccoon.ui.screen.UIScreen):
    """
    
    Prepare screen for distance calibration.
    
    Shows robot and target distance. Waits for button press to start.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[NoneType])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    title: typing.ClassVar[str] = 'Distance Calibration'
    def __init__(self, requested_distance: float):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_press(self):
        ...
