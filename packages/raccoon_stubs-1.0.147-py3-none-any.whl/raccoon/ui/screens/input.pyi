"""

Input screens for collecting user data.
"""
from __future__ import annotations
import dataclasses
from dataclasses import dataclass
from raccoon.ui.events import on_change
from raccoon.ui.events import on_click
from raccoon.ui.events import on_keypad
from raccoon.ui.events import on_slider
import raccoon.ui.screen
from raccoon.ui.screen import UIScreen
import raccoon.ui.widgets
from raccoon.ui.widgets import Button
from raccoon.ui.widgets import Center
from raccoon.ui.widgets import Column
from raccoon.ui.widgets import NumericInput
from raccoon.ui.widgets import NumericKeypad
from raccoon.ui.widgets import Row
from raccoon.ui.widgets import Slider
from raccoon.ui.widgets import Spacer
from raccoon.ui.widgets import Split
from raccoon.ui.widgets import Text
from raccoon.ui.widgets import TextInput
from raccoon.ui.widgets import Widget
import typing
__all__: list[str] = ['Button', 'Center', 'Column', 'NumberInputResult', 'NumberInputScreen', 'NumericInput', 'NumericKeypad', 'Row', 'Slider', 'SliderInputResult', 'SliderInputScreen', 'Spacer', 'Split', 'Text', 'TextInput', 'TextInputResult', 'TextInputScreen', 'UIScreen', 'Widget', 'dataclass', 'on_change', 'on_click', 'on_keypad', 'on_slider']
class NumberInputResult:
    """
    Result from NumberInputScreen.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'value': Field(name='value',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'confirmed': Field(name='confirmed',type=<class 'bool'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('value', 'confirmed')
    def __eq__(self, other):
        ...
    def __init__(self, value: float, confirmed: bool) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class NumberInputScreen(raccoon.ui.screen.UIScreen):
    """
    
    Numeric input with touch keypad. Returns NumberInputResult.
    
    Example:
        result = await self.show(NumberInputScreen(
            "Measurement",
            "Enter measured distance:",
            unit="cm",
            default=30.0
        ))
        if result.confirmed:
            distance = result.value
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[raccoon.ui.screens.input.NumberInputResult])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id: typing.ClassVar[str] = 'submit'
    def __init__(self, title: str = 'Input', prompt: str = 'Enter value:', unit: str = '', initial_value: float = 0, min_value: typing.Optional[float] = None, max_value: typing.Optional[float] = None, label: str = None, default: float = None):
        ...
    def _clamp_value(self, v: float) -> float:
        """
        Clamp value to min/max range.
        """
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_adjust(self, value: float):
        ...
    def on_cancel(self):
        ...
    def on_key(self, key: str):
        ...
    def on_submit(self):
        ...
class SliderInputResult:
    """
    Result from SliderInputScreen.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'value': Field(name='value',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'confirmed': Field(name='confirmed',type=<class 'bool'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('value', 'confirmed')
    def __eq__(self, other):
        ...
    def __init__(self, value: float, confirmed: bool) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class SliderInputScreen(raccoon.ui.screen.UIScreen):
    """
    
    Slider input screen. Returns SliderInputResult.
    
    Example:
        result = await self.show(SliderInputScreen(
            "Speed",
            "Select speed:",
            min=0, max=100, default=50
        ))
        if result.confirmed:
            speed = result.value
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[raccoon.ui.screens.input.SliderInputResult])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id: typing.ClassVar[str] = 'submit'
    def __init__(self, title: str = 'Input', prompt: str = 'Select value:', min: float = 0, max: float = 100, default: float = None, label: str = None):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_cancel(self):
        ...
    def on_change_value(self, value: float):
        ...
    def on_slider_change(self, value: float):
        ...
    def on_submit(self):
        ...
class TextInputResult:
    """
    Result from TextInputScreen.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'value': Field(name='value',type=<class 'str'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'confirmed': Field(name='confirmed',type=<class 'bool'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('value', 'confirmed')
    def __eq__(self, other):
        ...
    def __init__(self, value: str, confirmed: bool) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class TextInputScreen(raccoon.ui.screen.UIScreen):
    """
    
    Text input screen. Returns TextInputResult.
    
    Example:
        result = await self.show(TextInputScreen(
            "Name",
            "Enter robot name:",
            default="MyRobot"
        ))
        if result.confirmed:
            name = result.value
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[raccoon.ui.screens.input.TextInputResult])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id: typing.ClassVar[str] = 'submit'
    def __init__(self, title: str = 'Input', prompt: str = 'Enter text:', default: str = '', placeholder: str = '', label: str = None):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_cancel(self):
        ...
    def on_change_value(self, value: str):
        ...
    def on_submit(self):
        ...
