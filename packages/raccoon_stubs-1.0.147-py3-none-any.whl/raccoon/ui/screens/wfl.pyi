"""

Wait-for-light screens: calibration (legacy) and auto-detection.
"""
from __future__ import annotations
import dataclasses
from dataclasses import dataclass
from raccoon.ui.events import on_button_press
from raccoon.ui.events import on_change
from raccoon.ui.events import on_click
import raccoon.ui.screen
from raccoon.ui.screen import UIScreen
import raccoon.ui.widgets
from raccoon.ui.widgets import Button
from raccoon.ui.widgets import Card
from raccoon.ui.widgets import Center
from raccoon.ui.widgets import Column
from raccoon.ui.widgets import Container
from raccoon.ui.widgets import HintBox
from raccoon.ui.widgets import Icon
from raccoon.ui.widgets import LightBulb
from raccoon.ui.widgets import NumericInput
from raccoon.ui.widgets import ResultsTable
from raccoon.ui.widgets import Row
from raccoon.ui.widgets import SensorGraph
from raccoon.ui.widgets import SensorValue
from raccoon.ui.widgets import Spacer
from raccoon.ui.widgets import Split
from raccoon.ui.widgets import StatusBadge
from raccoon.ui.widgets import StatusIcon
from raccoon.ui.widgets import Text
from raccoon.ui.widgets import Widget
import typing
__all__: list[str] = ['Button', 'Card', 'Center', 'Column', 'Container', 'HintBox', 'Icon', 'LightBulb', 'NumericInput', 'ResultsTable', 'Row', 'SensorGraph', 'SensorValue', 'Spacer', 'Split', 'StatusBadge', 'StatusIcon', 'Text', 'UIScreen', 'WFLConfirmResult', 'WFLConfirmScreen', 'WFLDetectScreen', 'WFLMeasureResult', 'WFLMeasureScreen', 'Widget', 'dataclass', 'on_button_press', 'on_change', 'on_click']
class WFLConfirmResult:
    """
    Result from WFLConfirmScreen.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'confirmed': Field(name='confirmed',type=<class 'bool'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'light_off': Field(name='light_off',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'light_on': Field(name='light_on',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('confirmed', 'light_off', 'light_on')
    def __eq__(self, other):
        ...
    def __init__(self, confirmed: bool, light_off: float, light_on: float) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
    @property
    def threshold(self) -> float:
        ...
class WFLConfirmScreen(raccoon.ui.screen.UIScreen):
    """
    
    Confirm wait-for-light calibration values.
    
    Shows measured values (editable), threshold, and difference.
    User can confirm or retry.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[raccoon.ui.screens.wfl.WFLConfirmResult])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id: typing.ClassVar[str] = 'confirm'
    title: typing.ClassVar[str] = 'Wait for Light Calibration'
    def __init__(self, port: int, light_off: float, light_on: float):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_confirm(self):
        ...
    def on_off_change(self, value: float):
        ...
    def on_on_change(self, value: float):
        ...
    def on_retry(self):
        ...
    @property
    def difference(self) -> float:
        ...
    @property
    def is_good(self) -> bool:
        ...
    @property
    def threshold(self) -> float:
        ...
class WFLDetectScreen(raccoon.ui.screen.UIScreen):
    """
    
    Status display for automatic wait-for-light detection.
    
    Shows the current sensor value, Kalman-filtered baseline, trigger
    threshold, and detection status. Supports an interactive test mode
    where the user verifies the lamp would trigger before the system
    is truly armed.
    
    States:
        WARMING UP — collecting baseline samples
        TEST MODE — detects lamp but will NOT start the mission
        TRIGGERED — lamp detected during test (big confirmation)
        ARMED — fully armed, real trigger starts the mission
        GO! — lamp detected for real, mission starting
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[NoneType])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    title: typing.ClassVar[str] = 'Wait for Light'
    def __init__(self) -> None:
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_test(self):
        ...
class WFLMeasureResult:
    """
    Result from WFLMeasureScreen.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'value': Field(name='value',type=<class 'float'>,default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('value')
    def __eq__(self, other):
        ...
    def __init__(self, value: float) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class WFLMeasureScreen(raccoon.ui.screen.UIScreen):
    """
    
    Measure light on or off state for wait-for-light calibration.
    
    Shows light bulb visualization and real-time sensor reading.
    Returns sensor value when button is pressed.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __orig_bases__: typing.ClassVar[tuple]  # value = (raccoon.ui.screen.UIScreen[raccoon.ui.screens.wfl.WFLMeasureResult])
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    title: typing.ClassVar[str] = 'Wait for Light Calibration'
    def __init__(self, port: int, is_on: bool):
        ...
    def build(self) -> raccoon.ui.widgets.Widget:
        ...
    def on_press(self):
        ...
