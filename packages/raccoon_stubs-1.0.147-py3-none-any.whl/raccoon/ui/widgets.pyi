"""

UI Widgets - Type-safe widget definitions for dynamic screens.

These dataclasses serialize to JSON and are rendered by Flutter.
"""
from __future__ import annotations
import abc
from abc import ABC
import dataclasses
from dataclasses import dataclass
from dataclasses import field
import typing
__all__: list[str] = ['ABC', 'AnimatedRobot', 'Button', 'CalibrationChart', 'Card', 'Center', 'Checkbox', 'CircularSlider', 'Column', 'Container', 'DistanceBadge', 'Divider', 'Dropdown', 'Expanded', 'HintBox', 'Icon', 'LightBulb', 'MeasuringTape', 'NumericInput', 'NumericKeypad', 'ProgressSpinner', 'PulsingArrow', 'ResultsTable', 'RobotDrivingAnimation', 'Row', 'SensorGraph', 'SensorValue', 'Slider', 'Spacer', 'Split', 'StatusBadge', 'StatusIcon', 'Text', 'TextInput', 'Widget', 'dataclass', 'field']
class AnimatedRobot(Widget):
    """
    Robot with spinning wheels visualization.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'moving': Field(name='moving',type='bool',default=False,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'size': Field(name='size',type='int',default=120,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('moving', 'size')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    moving: typing.ClassVar[bool] = False
    size: typing.ClassVar[int] = 120
    def __eq__(self, other):
        ...
    def __init__(self, moving: bool = False, size: int = 120) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Button(Widget):
    """
    Clickable button.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'id': Field(name='id',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'label': Field(name='label',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'style': Field(name='style',type='str',default='primary',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'icon': Field(name='icon',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'disabled': Field(name='disabled',type='bool',default=False,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('id', 'label', 'style', 'icon', 'disabled')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    disabled: typing.ClassVar[bool] = False
    icon = None
    style: typing.ClassVar[str] = 'primary'
    def __eq__(self, other):
        ...
    def __init__(self, id: str, label: str, style: str = 'primary', icon: str | None = None, disabled: bool = False) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class CalibrationChart(Widget):
    """
    
    Static scatter/line chart for calibration data.
    
    Shows collected sample points with horizontal threshold lines.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'samples': Field(name='samples',type='List[float]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'thresholds': Field(name='thresholds',type='List[tuple]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'height': Field(name='height',type='int',default=200,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('samples', 'thresholds', 'height')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    height: typing.ClassVar[int] = 200
    def __eq__(self, other):
        ...
    def __init__(self, samples: list[float] = ..., thresholds: list[tuple] = ..., height: int = 200) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Card(Widget):
    """
    Card container with optional title.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'children': Field(name='children',type='List[Widget]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'title': Field(name='title',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'padding': Field(name='padding',type='int',default=16,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('children', 'title', 'padding')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    padding: typing.ClassVar[int] = 16
    title = None
    def __eq__(self, other):
        ...
    def __init__(self, children: list[Widget] = ..., title: str | None = None, padding: int = 16) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Center(Widget):
    """
    Center children vertically and horizontally.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'children': Field(name='children',type='List[Widget]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('children')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    def __eq__(self, other):
        ...
    def __init__(self, children: list[Widget] = ...) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Checkbox(Widget):
    """
    Checkbox toggle.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'id': Field(name='id',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'label': Field(name='label',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'value': Field(name='value',type='bool',default=False,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('id', 'label', 'value')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    value: typing.ClassVar[bool] = False
    def __eq__(self, other):
        ...
    def __init__(self, id: str, label: str, value: bool = False) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class CircularSlider(Widget):
    """
    Circular slider for motor/servo control.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'id': Field(name='id',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'min': Field(name='min',type='float',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'max': Field(name='max',type='float',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'value': Field(name='value',type='float',default=0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'label': Field(name='label',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('id', 'min', 'max', 'value', 'label')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    label = None
    value: typing.ClassVar[int] = 0
    def __eq__(self, other):
        ...
    def __init__(self, id: str, min: float, max: float, value: float = 0, label: str | None = None) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Column(Widget):
    """
    Vertical layout - children stacked.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'children': Field(name='children',type='List[Widget]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'align': Field(name='align',type='str',default='stretch',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'spacing': Field(name='spacing',type='int',default=12,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('children', 'align', 'spacing')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    align: typing.ClassVar[str] = 'stretch'
    spacing: typing.ClassVar[int] = 12
    def __eq__(self, other):
        ...
    def __init__(self, children: list[Widget] = ..., align: str = 'stretch', spacing: int = 12) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Container(Widget):
    """
    Container with optional background color, fills available space.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'children': Field(name='children',type='List[Widget]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'bg_color': Field(name='bg_color',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'padding': Field(name='padding',type='int',default=0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('children', 'bg_color', 'padding')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    bg_color = None
    padding: typing.ClassVar[int] = 0
    def __eq__(self, other):
        ...
    def __init__(self, children: list[Widget] = ..., bg_color: str | None = None, padding: int = 0) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class DistanceBadge(Widget):
    """
    Distance value display badge.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'value': Field(name='value',type='float',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'unit': Field(name='unit',type='str',default='cm',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'color': Field(name='color',type='str',default='blue',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('value', 'unit', 'color')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    color: typing.ClassVar[str] = 'blue'
    unit: typing.ClassVar[str] = 'cm'
    def __eq__(self, other):
        ...
    def __init__(self, value: float, unit: str = 'cm', color: str = 'blue') -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Divider(Widget):
    """
    Horizontal divider line.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'thickness': Field(name='thickness',type='int',default=1,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'color': Field(name='color',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('thickness', 'color')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    color = None
    thickness: typing.ClassVar[int] = 1
    def __eq__(self, other):
        ...
    def __init__(self, thickness: int = 1, color: str | None = None) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Dropdown(Widget):
    """
    Dropdown selection.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'id': Field(name='id',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'options': Field(name='options',type='List[str]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'value': Field(name='value',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'label': Field(name='label',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('id', 'options', 'value', 'label')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    label = None
    value = None
    def __eq__(self, other):
        ...
    def __init__(self, id: str, options: list[str] = ..., value: str | None = None, label: str | None = None) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Expanded(Widget):
    """
    Expand child to fill available space.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'child': Field(name='child',type='Widget',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'flex': Field(name='flex',type='int',default=1,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('child', 'flex')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    child = None
    flex: typing.ClassVar[int] = 1
    def __eq__(self, other):
        ...
    def __init__(self, child: Widget = None, flex: int = 1) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class HintBox(Widget):
    """
    Highlighted hint box (e.g., "Press button when ready").
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'text': Field(name='text',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'icon': Field(name='icon',type='str',default='touch_app',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'style': Field(name='style',type='str',default='normal',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('text', 'icon', 'style')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    icon: typing.ClassVar[str] = 'touch_app'
    style: typing.ClassVar[str] = 'normal'
    def __eq__(self, other):
        ...
    def __init__(self, text: str, icon: str = 'touch_app', style: str = 'normal') -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Icon(Widget):
    """
    Material icon widget.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'name': Field(name='name',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'size': Field(name='size',type='int',default=24,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'color': Field(name='color',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('name', 'size', 'color')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    color = None
    size: typing.ClassVar[int] = 24
    def __eq__(self, other):
        ...
    def __init__(self, name: str, size: int = 24, color: str | None = None) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class LightBulb(Widget):
    """
    Animated light bulb visualization.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'is_on': Field(name='is_on',type='bool',default=False,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('is_on')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    is_on: typing.ClassVar[bool] = False
    def __eq__(self, other):
        ...
    def __init__(self, is_on: bool = False) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class MeasuringTape(Widget):
    """
    Animated measuring tape.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'distance': Field(name='distance',type='float',default=30.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('distance')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    distance: typing.ClassVar[float] = 30.0
    def __eq__(self, other):
        ...
    def __init__(self, distance: float = 30.0) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class NumericInput(Widget):
    """
    Large numeric display with optional +/- buttons.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'id': Field(name='id',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'value': Field(name='value',type='float',default=0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'unit': Field(name='unit',type='str',default='',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'min_value': Field(name='min_value',type='Optional[float]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'max_value': Field(name='max_value',type='Optional[float]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'show_adjust_buttons': Field(name='show_adjust_buttons',type='bool',default=True,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('id', 'value', 'unit', 'min_value', 'max_value', 'show_adjust_buttons')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    max_value = None
    min_value = None
    show_adjust_buttons: typing.ClassVar[bool] = True
    unit: typing.ClassVar[str] = ''
    value: typing.ClassVar[int] = 0
    def __eq__(self, other):
        ...
    def __init__(self, id: str, value: float = 0, unit: str = '', min_value: float | None = None, max_value: float | None = None, show_adjust_buttons: bool = True) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class NumericKeypad(Widget):
    """
    Touch-friendly numeric keypad (0-9, ., backspace).
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict] = {}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    def __eq__(self, other):
        ...
    def __init__(self) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class ProgressSpinner(Widget):
    """
    Circular loading spinner.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'size': Field(name='size',type='int',default=24,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'color': Field(name='color',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('size', 'color')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    color = None
    size: typing.ClassVar[int] = 24
    def __eq__(self, other):
        ...
    def __init__(self, size: int = 24, color: str | None = None) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class PulsingArrow(Widget):
    """
    Animated pulsing arrow.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'direction': Field(name='direction',type='str',default='right',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('direction')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    direction: typing.ClassVar[str] = 'right'
    def __eq__(self, other):
        ...
    def __init__(self, direction: str = 'right') -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class ResultsTable(Widget):
    """
    Key-value results table.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'rows': Field(name='rows',type='List[tuple]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('rows')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    def __eq__(self, other):
        ...
    def __init__(self, rows: list[tuple] = ...) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class RobotDrivingAnimation(Widget):
    """
    Robot driving on track animation.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'target_distance': Field(name='target_distance',type='float',default=30.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('target_distance')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    target_distance: typing.ClassVar[float] = 30.0
    def __eq__(self, other):
        ...
    def __init__(self, target_distance: float = 30.0) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Row(Widget):
    """
    Horizontal layout - children side by side.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'children': Field(name='children',type='List[Widget]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'align': Field(name='align',type='str',default='center',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'spacing': Field(name='spacing',type='int',default=8,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('children', 'align', 'spacing')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    align: typing.ClassVar[str] = 'center'
    spacing: typing.ClassVar[int] = 8
    def __eq__(self, other):
        ...
    def __init__(self, children: list[Widget] = ..., align: str = 'center', spacing: int = 8) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class SensorGraph(Widget):
    """
    Real-time sensor line graph.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'port': Field(name='port',type='int',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'sensor_type': Field(name='sensor_type',type='str',default='analog',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'max_points': Field(name='max_points',type='int',default=50,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('port', 'sensor_type', 'max_points')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    max_points: typing.ClassVar[int] = 50
    sensor_type: typing.ClassVar[str] = 'analog'
    def __eq__(self, other):
        ...
    def __init__(self, port: int, sensor_type: str = 'analog', max_points: int = 50) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class SensorValue(Widget):
    """
    Large sensor value display.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'port': Field(name='port',type='int',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'sensor_type': Field(name='sensor_type',type='str',default='analog',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('port', 'sensor_type')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    sensor_type: typing.ClassVar[str] = 'analog'
    def __eq__(self, other):
        ...
    def __init__(self, port: int, sensor_type: str = 'analog') -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Slider(Widget):
    """
    Slider input for numeric values.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'id': Field(name='id',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'min': Field(name='min',type='float',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'max': Field(name='max',type='float',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'value': Field(name='value',type='float',default=0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'label': Field(name='label',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'show_value': Field(name='show_value',type='bool',default=True,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('id', 'min', 'max', 'value', 'label', 'show_value')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    label = None
    show_value: typing.ClassVar[bool] = True
    value: typing.ClassVar[int] = 0
    def __eq__(self, other):
        ...
    def __init__(self, id: str, min: float, max: float, value: float = 0, label: str | None = None, show_value: bool = True) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Spacer(Widget):
    """
    Vertical spacing widget.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'height': Field(name='height',type='int',default=16,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('height')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    height: typing.ClassVar[int] = 16
    def __eq__(self, other):
        ...
    def __init__(self, height: int = 16) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Split(Widget):
    """
    Left-right split layout.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'left': Field(name='left',type='List[Widget]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'right': Field(name='right',type='List[Widget]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'ratio': Field(name='ratio',type='tuple',default=(1, 1),default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('left', 'right', 'ratio')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    ratio: typing.ClassVar[tuple] = (1, 1)
    def __eq__(self, other):
        ...
    def __init__(self, left: list[Widget] = ..., right: list[Widget] = ..., ratio: tuple = (1, 1)) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class StatusBadge(Widget):
    """
    Colored pill/badge with text (e.g., "LIGHT ON").
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'text': Field(name='text',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'color': Field(name='color',type='str',default='grey',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'glow': Field(name='glow',type='bool',default=False,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('text', 'color', 'glow')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    color: typing.ClassVar[str] = 'grey'
    glow: typing.ClassVar[bool] = False
    def __eq__(self, other):
        ...
    def __init__(self, text: str, color: str = 'grey', glow: bool = False) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class StatusIcon(Widget):
    """
    Animated circle with icon inside.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'icon': Field(name='icon',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'color': Field(name='color',type='str',default='green',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'animated': Field(name='animated',type='bool',default=True,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('icon', 'color', 'animated')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    animated: typing.ClassVar[bool] = True
    color: typing.ClassVar[str] = 'green'
    def __eq__(self, other):
        ...
    def __init__(self, icon: str, color: str = 'green', animated: bool = True) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Text(Widget):
    """
    Text display widget.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'text': Field(name='text',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'size': Field(name='size',type='str',default='medium',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'color': Field(name='color',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'bold': Field(name='bold',type='bool',default=False,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'muted': Field(name='muted',type='bool',default=False,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'align': Field(name='align',type='str',default='left',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('text', 'size', 'color', 'bold', 'muted', 'align')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    align: typing.ClassVar[str] = 'left'
    bold: typing.ClassVar[bool] = False
    color = None
    muted: typing.ClassVar[bool] = False
    size: typing.ClassVar[str] = 'medium'
    def __eq__(self, other):
        ...
    def __init__(self, text: str, size: str = 'medium', color: str | None = None, bold: bool = False, muted: bool = False, align: str = 'left') -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class TextInput(Widget):
    """
    Text input field.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'id': Field(name='id',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'value': Field(name='value',type='str',default='',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'label': Field(name='label',type='Optional[str]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'placeholder': Field(name='placeholder',type='str',default='',default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('id', 'value', 'label', 'placeholder')
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    label = None
    placeholder: typing.ClassVar[str] = ''
    value: typing.ClassVar[str] = ''
    def __eq__(self, other):
        ...
    def __init__(self, id: str, value: str = '', label: str | None = None, placeholder: str = '') -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Widget(abc.ABC):
    """
    Base class for all widgets.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __dataclass_fields__: typing.ClassVar[dict] = {}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    def __eq__(self, other):
        ...
    def __init__(self) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
    def to_dict(self) -> dict:
        """
        Convert to JSON-serializable dict.
        """
