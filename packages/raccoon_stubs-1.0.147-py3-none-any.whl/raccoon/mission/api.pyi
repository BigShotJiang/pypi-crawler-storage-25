from __future__ import annotations
from abc import abstractmethod
import raccoon.class_name_logger
from raccoon.class_name_logger import ClassNameLogger
from raccoon.foundation import initialize_timer
import typing
from typing import Protocol
from typing import runtime_checkable
__all__: list[str] = ['ClassNameLogger', 'Mission', 'MissionProtocol', 'Protocol', 'SetupMission', 'abstractmethod', 'initialize_timer', 'runtime_checkable']
class Mission(raccoon.class_name_logger.ClassNameLogger, MissionProtocol):
    """
    Base mission that delegates execution to a root step sequence.
    
    Subclasses may set ``time_budget`` (seconds) as a class attribute to
    arm a per-mission deadline. If the mission exceeds its budget the
    robot's ``WatchdogManager`` fires, cancels the main-mission task, and
    routes through the normal shutdown path — the shutdown mission still
    runs. Subsequent missions do not run after a budget expiry.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset({'sequence'})
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _is_protocol: typing.ClassVar[bool] = False
    time_budget = None
    @classmethod
    def __subclasshook__(cls, other):
        ...
    def __repr__(self):
        ...
    def __str__(self):
        ...
    def run(self, robot):
        """
        Build the mission sequence and execute it on the provided robot.
        """
    def sequence(self) -> Step:
        """
        Return the root step tree for this mission.
        """
class MissionProtocol(typing.Protocol):
    """
    Protocol for mission objects that can be run on a robot.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __non_callable_proto_members__: typing.ClassVar[set] = set()
    __parameters__: typing.ClassVar[tuple] = tuple()
    __protocol_attrs__: typing.ClassVar[set] = {'run'}
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _is_protocol: typing.ClassVar[bool] = True
    _is_runtime_protocol: typing.ClassVar[bool] = True
    @classmethod
    def __subclasshook__(cls, other):
        ...
    def __init__(self, *args, **kwargs):
        ...
    def run(self, robot: GenericRobot) -> None:
        """
        Execute the mission on the given robot.
        """
class SetupMission(Mission):
    """
    Base class for setup missions with a customizable pre-start gate.
    
    Subclass this instead of ``Mission`` for setup missions. Override
    ``pre_start_gate()`` to customize what happens between the setup
    sequence and the main missions (e.g. skip waiting for light/button).
    
    Example::
    
        class MySetup(SetupMission):
            def sequence(self) -> Step:
                return seq(calibrate_deadzone())
    
            async def pre_start_gate(self, robot) -> None:
                # Skip the wait-for-light — just wait for button
                from raccoon.step import wait_for_button
                await wait_for_button().run_step(robot)
    
        class QuickSetup(SetupMission):
            def sequence(self) -> Step:
                return seq(calibrate_deadzone())
    
            async def pre_start_gate(self, robot) -> None:
                pass  # Skip all waiting — start immediately
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset({'sequence'})
    __parameters__: typing.ClassVar[tuple] = tuple()
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _custom_pre_start_gate: typing.ClassVar[bool] = False
    _is_protocol: typing.ClassVar[bool] = False
    @classmethod
    def __init_subclass__(cls, **kwargs):
        ...
    @classmethod
    def __subclasshook__(cls, other):
        ...
    def pre_start_gate(self, robot) -> None:
        """
        Gate executed after the setup sequence and before main missions.
        
        The default delegates to the robot's built-in wait-for-light /
        wait-for-button logic. Override this to customize or skip the
        gate entirely.
        
        To skip all waiting::
        
            async def pre_start_gate(self, robot) -> None:
                pass  # start immediately
        """
