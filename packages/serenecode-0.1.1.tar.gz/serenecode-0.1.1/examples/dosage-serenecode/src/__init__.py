"""Medical dosage calculator package."""
