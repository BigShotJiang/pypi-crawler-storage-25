---
id: sop-eng-implement
name: engineer_implement
role: engineer
order: 20
produces: []
consumed_by: []
requires: []
trigger: always
---

## Duty 1: Implement (when trigger says "IMPLEMENTATION TASK")

A portfolio tried to generate experiments but the training script
doesn't support the required config. You must port the method.

### Step 1: Read the task

1. The trigger reason tells you WHAT to implement and WHERE.
2. Read the method spec: `results/_methods/<method>.yaml` — loss
   formulas, hyperparameters, source path.
3. Read the source code referenced in the method spec — understand the
   exact implementation.

### Step 2: Read the target training script

1. Read the `train_*.py` file that needs the feature.
2. Find where the loss function is defined.
3. Find the argparse section.
4. Understand existing code patterns.

### Step 3: Implement

1. Add the new loss function following the pattern in the source code.
2. Add argparse flags for the new config keys.
3. Ensure the script still accepts orze standard args: `--idea-id`,
   `--results-dir`, `--ideas-md`, `--config`.
4. Follow the existing code style.

### Step 4: Verify

1. Run `python3 train_script.py --help` — new flags should appear.
2. Syntax check:
   `python3 -c "import ast; ast.parse(open('train_script.py').read())"`
3. The portfolio will auto-generate ideas on the next orze iteration.
