"""
data_utils.py

DataFrame parsing, numeric coercion, date label parsing, and custom float formatting.
Handles both IFRS and GAAP without distinction in code, as all synonyms unify them.
"""

import re
import datetime
import pandas as pd
import numpy as np

from .logging_utils import get_logger

logger = get_logger(__name__)

_YEAR_RE = re.compile(r"(20[0-9]{2}|19[0-9]{2})")
_QUARTER_RE = re.compile(r"Q([1-4])[\s\-_]*((?:20|19)[0-9]{2})", re.IGNORECASE)

_QUARTER_MONTH = {1: 3, 2: 6, 3: 9, 4: 12}
_QUARTER_DAY = {3: 31, 6: 30, 9: 30, 12: 31}


def parse_period_label(col_name: str) -> datetime.date:
    """
    Attempt to parse '2021-12-31', 'FY2023', 'Q1-2023', '2021' into a date.
    Return 1900-01-01 if parse fails. Used for sorting columns by time.
    """
    patterns = ["%Y-%m-%d", "%Y/%m/%d", "%Y-%m", "%Y"]
    if col_name.upper().startswith("FY"):
        try:
            yr = int(col_name[2:])
            return datetime.date(yr, 12, 31)
        except ValueError:
            pass

    qtr_match = _QUARTER_RE.match(col_name)
    if qtr_match:
        q_num = int(qtr_match.group(1))
        yr = int(qtr_match.group(2))
        month = _QUARTER_MONTH[q_num]
        return datetime.date(yr, month, _QUARTER_DAY[month])

    for pat in patterns:
        try:
            if pat == "%Y":
                dt = datetime.datetime.strptime(col_name, "%Y")
                return dt.replace(month=12, day=31).date()
            dt = datetime.datetime.strptime(col_name, pat)
            return dt.date()
        except ValueError:
            continue

    year_match = _YEAR_RE.search(col_name)
    if year_match:
        yr = int(year_match.group(1))
        return datetime.date(yr, 12, 31)

    logger.debug("parse_period_label: Could not parse '%s' -> fallback=1900-01-01", col_name)
    return datetime.date(1900, 1, 1)


def custom_float_format(x):
    """Formats numeric x to a short string with K, M, B, T or .2f if <1000."""
    if isinstance(x, float) and (np.isnan(x) or np.isinf(x)):
        return "N/A"
    if isinstance(x, (int, float)):
        abs_x = abs(x)
        if abs_x >= 1e12:
            return f"{x / 1e12:.2f}T"
        if abs_x >= 1e9:
            return f"{x / 1e9:.2f}B"
        if abs_x >= 1e6:
            return f"{x / 1e6:.2f}M"
        if abs_x >= 1e3:
            return f"{x / 1e3:.2f}K"
        return f"{x:.2f}"
    return x


_STATEMENT_META_COLS = frozenset({
    "concept", "label", "standard_concept", "level", "abstract",
    "dimension", "is_breakdown", "dimension_axis", "dimension_member",
    "dimension_member_label", "dimension_label", "balance", "weight",
    "preferred_sign", "parent_concept", "parent_abstract_concept",
})


def _convert_statement_df(df: pd.DataFrame, debug_label: str) -> pd.DataFrame:
    """Convert an edgartools Statement-style DataFrame to label-indexed format.

    Statement.to_dataframe() returns rows with integer index, a 'label'
    column, metadata columns, and date-keyed value columns.  This function
    drops abstract/dimension rows, sets 'label' as the index, and keeps
    only the value columns so that synonym matching works.

    XBRL concept tags from the 'concept' column are added as duplicate
    rows so that synonym lists containing tags like
    ``us-gaap_PaymentsToAcquirePropertyPlantAndEquipment`` still match.
    """
    if "label" not in df.columns:
        return df

    value_cols = [c for c in df.columns if c not in _STATEMENT_META_COLS]
    if not value_cols:
        return df

    filtered = df
    if "abstract" in df.columns:
        filtered = filtered[~filtered["abstract"].astype(bool)]
    if "dimension" in df.columns:
        filtered = filtered[~filtered["dimension"].astype(bool)]

    label_df = filtered.set_index("label")[value_cols]

    if "concept" in filtered.columns:
        concept_df = filtered.set_index("concept")[value_cols]
        concept_df = concept_df[~concept_df.index.isin(label_df.index)]
        result = pd.concat([label_df, concept_df])
    else:
        result = label_df

    logger.debug(
        "ensure_dataframe(%s): converted Statement DF -> label-indexed shape=%s",
        debug_label, result.shape,
    )
    return result


def ensure_dataframe(possible_df, debug_label="(unknown)") -> pd.DataFrame:
    """Safely convert various object types to a DataFrame or return empty if not feasible."""
    if possible_df is None:
        logger.debug("ensure_dataframe(%s): None -> empty DF", debug_label)
        return pd.DataFrame()

    if isinstance(possible_df, pd.DataFrame):
        if "label" in possible_df.columns and not isinstance(possible_df.index, pd.RangeIndex):
            logger.debug("ensure_dataframe(%s): already DF shape=%s", debug_label, possible_df.shape)
            return possible_df
        if "label" in possible_df.columns:
            return _convert_statement_df(possible_df, debug_label)
        logger.debug("ensure_dataframe(%s): already DF shape=%s", debug_label, possible_df.shape)
        return possible_df

    if hasattr(possible_df, "to_dataframe"):
        try:
            df_ = possible_df.to_dataframe()
            if isinstance(df_, pd.DataFrame):
                if "label" in df_.columns:
                    return _convert_statement_df(df_, debug_label)
                logger.debug("ensure_dataframe(%s): .to_dataframe() shape=%s", debug_label, df_.shape)
                return df_
            if isinstance(df_, np.ndarray):
                return pd.DataFrame(df_)
            logger.warning("ensure_dataframe(%s): .to_dataframe() returned unknown type -> empty", debug_label)
            return pd.DataFrame()
        except Exception as e:
            logger.exception("ensure_dataframe(%s): error calling .to_dataframe(): %s", debug_label, e)
            return pd.DataFrame()

    if isinstance(possible_df, np.ndarray):
        logger.debug("ensure_dataframe(%s): got ndarray shape=%s -> wrapping in DF", debug_label, possible_df.shape)
        return pd.DataFrame(possible_df)

    logger.warning("ensure_dataframe(%s): unrecognized type=%s -> empty DF", debug_label, type(possible_df))
    return pd.DataFrame()


def make_numeric_df(df: pd.DataFrame, debug_label="(unknown)") -> pd.DataFrame:
    """Converts columns to numeric where possible and deduplicates index rows.

    When duplicate index labels exist (common in XBRL filings with multiple
    frames), the row with the largest absolute sum is kept."""
    if not isinstance(df, pd.DataFrame) or df.empty:
        logger.debug("make_numeric_df(%s): invalid or empty DF -> skip", debug_label)
        return df

    pre_non_null = df.notnull().sum().sum()
    numeric_df = df.apply(pd.to_numeric, errors="coerce")
    post_non_null = numeric_df.notnull().sum().sum()

    if numeric_df.index.duplicated().any():
        n_dups = numeric_df.index.duplicated(keep=False).sum()
        numeric_df["_abs_sum"] = numeric_df.abs().sum(axis=1, skipna=True)
        numeric_df = numeric_df.sort_values("_abs_sum", ascending=False)
        numeric_df = numeric_df[~numeric_df.index.duplicated(keep="first")]
        numeric_df = numeric_df.drop(columns=["_abs_sum"])
        logger.debug("make_numeric_df(%s): deduplicated %d rows with duplicate labels", debug_label, n_dups)

    logger.debug(
        "make_numeric_df(%s): coerced to numeric. Non-null before=%d, after=%d. shape=%s",
        debug_label, pre_non_null, post_non_null, numeric_df.shape
    )
    return numeric_df
