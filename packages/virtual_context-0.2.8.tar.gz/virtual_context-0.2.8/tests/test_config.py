"""Tests for configuration loading and validation."""

import tempfile
from pathlib import Path

import pytest
import yaml

from virtual_context.config import load_config, validate_config


class TestLoadConfig:
    def test_load_defaults(self):
        config = load_config(config_dict={})
        assert config.version == "0.2"
        assert config.context_window == 120_000
        assert config.tag_generator.type == "keyword"
        assert config.storage.backend == "sqlite"

    def test_load_from_dict(self):
        config = load_config(config_dict={
            "context_window": 50_000,
            "tag_generator": {
                "type": "llm",
                "provider": "ollama",
                "model": "qwen3:4b-instruct-2507-fp16",
            },
        })
        assert config.context_window == 50_000
        assert config.tag_generator.type == "llm"
        assert config.tag_generator.provider == "ollama"

    def test_load_from_yaml_file(self):
        raw = {
            "version": "0.2",
            "context_window": 80_000,
            "tag_generator": {"type": "keyword"},
        }
        with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
            yaml.dump(raw, f)
            f.flush()
            config = load_config(config_path=f.name)
        assert config.context_window == 80_000

    def test_load_tag_rules(self):
        config = load_config(config_dict={
            "tag_rules": [
                {"match": "architecture*", "priority": 10, "ttl_days": None},
                {"match": "debug*", "priority": 7, "ttl_days": 7},
            ],
        })
        assert len(config.tag_rules) == 2
        assert config.tag_rules[0].match == "architecture*"
        assert config.tag_rules[0].priority == 10
        assert config.tag_rules[1].ttl_days == 7

    def test_load_strategy_config(self):
        config = load_config(config_dict={
            "retrieval": {
                "strategy_config": {
                    "default": {
                        "min_overlap": 2,
                        "max_results": 5,
                        "max_budget_fraction": 0.3,
                    },
                },
            },
        })
        sc = config.retriever.strategy_configs["default"]
        assert sc.min_overlap == 2
        assert sc.max_results == 5
        assert sc.max_budget_fraction == 0.3

    def test_load_keyword_fallback(self):
        config = load_config(config_dict={
            "tag_generator": {
                "type": "keyword",
                "keyword_fallback": {
                    "tag_keywords": {"legal": ["court", "filing"]},
                    "tag_patterns": {"legal": [r"\bcase\b"]},
                },
            },
        })
        fb = config.tag_generator.keyword_fallback
        assert fb is not None
        assert "legal" in fb.tag_keywords
        assert "legal" in fb.tag_patterns

    def test_load_telemetry(self):
        config = load_config(config_dict={
            "telemetry": {
                "enabled": True,
                "models_file": "custom_models.yaml",
            },
        })
        assert config.telemetry.enabled is True
        assert config.telemetry.models_file == "custom_models.yaml"
        # Backward compat alias
        assert config.cost_tracking.enabled is True

    def test_load_telemetry_from_legacy_cost_tracking_key(self):
        """Backward compat: 'cost_tracking' YAML key maps to telemetry."""
        config = load_config(config_dict={
            "cost_tracking": {
                "enabled": True,
            },
        })
        assert config.telemetry.enabled is True

    def test_default_strategy_added(self):
        config = load_config(config_dict={})
        assert "default" in config.retriever.strategy_configs

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            load_config(config_path="/nonexistent/path.yaml")


class TestValidateConfig:
    def test_valid_default_config(self):
        config = load_config(config_dict={})
        errors = validate_config(config)
        assert errors == []

    def test_invalid_tag_generator_type(self):
        config = load_config(config_dict={})
        config.tag_generator.type = "invalid"
        errors = validate_config(config)
        assert any("tag_generator.type" in e for e in errors)

    def test_llm_requires_provider(self):
        config = load_config(config_dict={
            "tag_generator": {"type": "llm"},
        }, validate=False)
        errors = validate_config(config)
        assert any("provider" in e for e in errors)

    def test_max_tags_less_than_min(self):
        config = load_config(config_dict={})
        config.tag_generator.max_tags = 1
        config.tag_generator.min_tags = 5
        errors = validate_config(config)
        assert any("max_tags" in e for e in errors)

    def test_soft_gte_hard(self):
        config = load_config(config_dict={
            "compaction": {"soft_threshold": 0.9, "hard_threshold": 0.85},
        }, validate=False)
        errors = validate_config(config)
        assert any("soft_threshold" in e for e in errors)

    def test_protected_recent_turns_zero(self):
        config = load_config(config_dict={
            "compaction": {"protected_recent_turns": 0},
        }, validate=False)
        errors = validate_config(config)
        assert any("protected_recent_turns" in e for e in errors)

    def test_invalid_strategy_budget_fraction(self):
        config = load_config(config_dict={})
        config.retriever.strategy_configs["default"].max_budget_fraction = 1.5
        errors = validate_config(config)
        assert any("max_budget_fraction" in e for e in errors)

    def test_invalid_storage_backend(self):
        config = load_config(config_dict={})
        config.storage.backend = "redis"
        errors = validate_config(config)
        assert any("storage.backend" in e for e in errors)


class TestMultiInstanceConfig:
    """Phase 5: proxy.instances config parsing and validation."""

    def test_no_instances_default(self):
        config = load_config(config_dict={})
        assert config.proxy.instances == []

    def test_parse_instances(self):
        config = load_config(config_dict={
            "proxy": {
                "instances": [
                    {"port": 5757, "upstream": "https://api.anthropic.com", "label": "anthropic"},
                    {"port": 5758, "upstream": "https://api.openai.com/v1", "label": "openai"},
                    {"port": 5760, "upstream": "https://generativelanguage.googleapis.com", "label": "gemini", "host": "0.0.0.0"},
                ],
            },
        })
        assert len(config.proxy.instances) == 3
        assert config.proxy.instances[0].port == 5757
        assert config.proxy.instances[0].upstream == "https://api.anthropic.com"
        assert config.proxy.instances[0].label == "anthropic"
        assert config.proxy.instances[0].host == "127.0.0.1"  # default
        assert config.proxy.instances[2].host == "0.0.0.0"

    def test_instance_defaults(self):
        config = load_config(config_dict={
            "proxy": {
                "instances": [{"upstream": "https://api.anthropic.com"}],
            },
        })
        inst = config.proxy.instances[0]
        assert inst.port == 5757
        assert inst.label == ""
        assert inst.host == "127.0.0.1"

    def test_validate_missing_upstream(self):
        config = load_config(config_dict={
            "proxy": {
                "instances": [
                    {"port": 5757, "label": "broken"},
                ],
            },
        }, validate=False)
        errors = validate_config(config)
        assert any("upstream is required" in e for e in errors)

    def test_validate_duplicate_ports(self):
        config = load_config(config_dict={
            "proxy": {
                "instances": [
                    {"port": 5757, "upstream": "https://api.anthropic.com"},
                    {"port": 5757, "upstream": "https://api.openai.com/v1"},
                ],
            },
        }, validate=False)
        errors = validate_config(config)
        assert any("duplicates" in e for e in errors)

    def test_validate_same_port_different_host(self):
        """Same port on different hosts is fine."""
        config = load_config(config_dict={
            "proxy": {
                "instances": [
                    {"port": 5757, "upstream": "https://api.anthropic.com", "host": "127.0.0.1"},
                    {"port": 5757, "upstream": "https://api.openai.com/v1", "host": "0.0.0.0"},
                ],
            },
        })
        errors = validate_config(config)
        assert not any("duplicates" in e for e in errors)

    def test_config_field_parsed(self):
        """Per-instance config field is parsed from YAML."""
        config = load_config(config_dict={
            "proxy": {
                "instances": [
                    {
                        "port": 5757,
                        "upstream": "https://api.anthropic.com",
                        "label": "anthropic",
                        "config": "/tmp/vc-anthropic.yaml",
                    },
                ],
            },
        }, validate=False)
        assert config.proxy.instances[0].config == "/tmp/vc-anthropic.yaml"

    def test_config_field_defaults_empty(self):
        """Config field defaults to empty string when absent."""
        config = load_config(config_dict={
            "proxy": {
                "instances": [
                    {"port": 5757, "upstream": "https://api.anthropic.com"},
                ],
            },
        })
        assert config.proxy.instances[0].config == ""

    def test_validate_missing_config_file(self):
        """Validation error when per-instance config file doesn't exist."""
        config = load_config(config_dict={
            "proxy": {
                "instances": [
                    {
                        "port": 5757,
                        "upstream": "https://api.anthropic.com",
                        "label": "anthropic",
                        "config": "/nonexistent/path/vc.yaml",
                    },
                ],
            },
        }, validate=False)
        errors = validate_config(config)
        assert any("config file not found" in e for e in errors)

    def test_validate_existing_config_file(self, tmp_path):
        """No error when per-instance config file exists."""
        cfg_file = tmp_path / "instance.yaml"
        cfg_file.write_text("version: '0.2'\n")
        config = load_config(config_dict={
            "proxy": {
                "instances": [
                    {
                        "port": 5757,
                        "upstream": "https://api.anthropic.com",
                        "label": "anthropic",
                        "config": str(cfg_file),
                    },
                ],
            },
        })
        errors = validate_config(config)
        assert not any("config file not found" in e for e in errors)

    def test_validate_duplicate_labels(self):
        """Duplicate labels across instances produce validation error."""
        config = load_config(config_dict={
            "proxy": {
                "instances": [
                    {"port": 5757, "upstream": "https://api.anthropic.com", "label": "myproxy"},
                    {"port": 5758, "upstream": "https://api.openai.com/v1", "label": "myproxy"},
                ],
            },
        }, validate=False)
        errors = validate_config(config)
        assert any("label 'myproxy' duplicates" in e for e in errors)
