"""Tests for engine state persistence (Phase 1 of session continuity)."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from virtual_context.core.turn_tag_index import TurnTagIndex
from virtual_context.storage.filesystem import FilesystemStore
from virtual_context.storage.sqlite import SQLiteStore
from virtual_context.types import EngineStateSnapshot, TurnTagEntry


def _make_snapshot(
    conversation_id: str = "test-session-abc",
    compacted_through: int = 4,
    turn_count: int = 10,
) -> EngineStateSnapshot:
    """Build a realistic EngineStateSnapshot for testing."""
    entries = [
        TurnTagEntry(
            turn_number=i,
            message_hash=f"hash{i:04d}",
            tags=[f"tag-{i}", "common"],
            primary_tag=f"tag-{i}",
            timestamp=datetime(2026, 1, 15, 10, i, 0, tzinfo=timezone.utc),
        )
        for i in range(turn_count)
    ]
    return EngineStateSnapshot(
        conversation_id=conversation_id,
        compacted_through=compacted_through,
        turn_tag_entries=entries,
        turn_count=turn_count,
        last_compacted_turn=(compacted_through // 2) - 1 if compacted_through > 0 else -1,
        last_completed_turn=turn_count - 1,
        last_indexed_turn=turn_count - 1,
        checkpoint_version=7,
    )


# ---------------------------------------------------------------------------
# SQLiteStore
# ---------------------------------------------------------------------------


class TestEngineStateSQLite:
    def test_save_and_load(self, tmp_path):
        """Round-trip: save state, load it back, verify all fields."""
        db = tmp_path / "test.db"
        store = SQLiteStore(db_path=db)

        snap = _make_snapshot()
        store.save_engine_state(snap)

        loaded = store.load_engine_state("test-session-abc")
        assert loaded is not None
        assert loaded.conversation_id == snap.conversation_id
        assert loaded.compacted_through == snap.compacted_through
        assert loaded.turn_count == snap.turn_count
        assert loaded.last_compacted_turn == snap.last_compacted_turn
        assert loaded.last_completed_turn == snap.last_completed_turn
        assert loaded.last_indexed_turn == snap.last_indexed_turn
        assert loaded.checkpoint_version == snap.checkpoint_version
        assert len(loaded.turn_tag_entries) == len(snap.turn_tag_entries)

        # Verify individual entries
        for orig, restored in zip(snap.turn_tag_entries, loaded.turn_tag_entries):
            assert restored.turn_number == orig.turn_number
            assert restored.message_hash == orig.message_hash
            assert restored.tags == orig.tags
            assert restored.primary_tag == orig.primary_tag
            assert restored.timestamp == orig.timestamp

    def test_load_empty_store(self, tmp_path):
        """Loading from an empty store returns None."""
        db = tmp_path / "test.db"
        store = SQLiteStore(db_path=db)

        result = store.load_engine_state("nonexistent-session")
        assert result is None

    def test_upsert_gets_latest(self, tmp_path):
        """Saving twice with same conversation_id overwrites — load gets latest."""
        db = tmp_path / "test.db"
        store = SQLiteStore(db_path=db)

        snap1 = _make_snapshot(compacted_through=2, turn_count=5)
        store.save_engine_state(snap1)

        snap2 = _make_snapshot(compacted_through=8, turn_count=15)
        store.save_engine_state(snap2)

        loaded = store.load_engine_state("test-session-abc")
        assert loaded is not None
        assert loaded.compacted_through == 8
        assert loaded.turn_count == 15
        assert len(loaded.turn_tag_entries) == 15


# ---------------------------------------------------------------------------
# FilesystemStore
# ---------------------------------------------------------------------------


class TestEngineStateFilesystem:
    def test_save_and_load(self, tmp_path):
        """Round-trip: save state, load it back, verify all fields."""
        store = FilesystemStore(root=tmp_path / "store")

        snap = _make_snapshot()
        store.save_engine_state(snap)

        loaded = store.load_engine_state("test-session-abc")
        assert loaded is not None
        assert loaded.conversation_id == snap.conversation_id
        assert loaded.compacted_through == snap.compacted_through
        assert loaded.turn_count == snap.turn_count
        assert loaded.last_compacted_turn == snap.last_compacted_turn
        assert loaded.last_completed_turn == snap.last_completed_turn
        assert loaded.last_indexed_turn == snap.last_indexed_turn
        assert loaded.checkpoint_version == snap.checkpoint_version
        assert len(loaded.turn_tag_entries) == len(snap.turn_tag_entries)

        for orig, restored in zip(snap.turn_tag_entries, loaded.turn_tag_entries):
            assert restored.turn_number == orig.turn_number
            assert restored.message_hash == orig.message_hash
            assert restored.tags == orig.tags
            assert restored.primary_tag == orig.primary_tag

    def test_load_empty_store(self, tmp_path):
        """Loading from an empty store returns None."""
        store = FilesystemStore(root=tmp_path / "store")

        result = store.load_engine_state("nonexistent")
        assert result is None

    def test_upsert_gets_latest(self, tmp_path):
        """Saving twice overwrites — load gets latest."""
        store = FilesystemStore(root=tmp_path / "store")

        snap1 = _make_snapshot(compacted_through=2, turn_count=5)
        store.save_engine_state(snap1)

        snap2 = _make_snapshot(compacted_through=8, turn_count=15)
        store.save_engine_state(snap2)

        loaded = store.load_engine_state("test-session-abc")
        assert loaded is not None
        assert loaded.compacted_through == 8
        assert loaded.turn_count == 15

    def test_state_file_is_valid_json(self, tmp_path):
        """The state file on disk is valid JSON with expected structure."""
        store = FilesystemStore(root=tmp_path / "store")
        snap = _make_snapshot(turn_count=3)
        store.save_engine_state(snap)

        path = tmp_path / "store" / "_engine_state" / f"{snap.conversation_id}.json"
        assert path.is_file()

        data = json.loads(path.read_text())
        assert data["conversation_id"] == snap.conversation_id
        assert data["compacted_through"] == snap.compacted_through
        assert data["last_completed_turn"] == snap.last_completed_turn
        assert data["last_indexed_turn"] == snap.last_indexed_turn
        assert data["checkpoint_version"] == snap.checkpoint_version
        assert len(data["turn_tag_entries"]) == 3


# ---------------------------------------------------------------------------
# Engine integration: state survives reinit
# ---------------------------------------------------------------------------


class TestEngineStateIntegration:
    def test_state_survives_engine_reinit(self, tmp_path):
        """Save state via one engine, create a new engine with same store, verify restored."""
        from virtual_context.engine import VirtualContextEngine
        from virtual_context.config import load_config

        db_path = str(tmp_path / "store.db")
        config_dict = {
            "context_window": 10000,
            "storage": {"backend": "sqlite", "sqlite": {"path": db_path}},
            "tag_generator": {"type": "keyword"},
        }

        # First engine: populate state and save
        config1 = load_config(config_dict=config_dict)
        engine1 = VirtualContextEngine(config=config1)
        conversation_id = engine1.config.conversation_id

        # Manually add some turns to the index
        for i in range(5):
            engine1._turn_tag_index.append(TurnTagEntry(
                turn_number=i,
                message_hash=f"h{i}",
                tags=[f"tag-{i}"],
                primary_tag=f"tag-{i}",
            ))
        engine1._engine_state.compacted_through = 4

        # Store a segment so watermark validation passes on reload
        from virtual_context.types import Message, StoredSegment, SegmentMetadata
        from datetime import datetime, timezone
        engine1._store.store_segment(StoredSegment(
            ref="seg-0", conversation_id=conversation_id,
            primary_tag="tag-0", tags=["tag-0"],
            summary="Test segment", summary_tokens=5,
            full_text="test", full_tokens=2,
            metadata=SegmentMetadata(),
            created_at=datetime.now(timezone.utc),
            start_timestamp=datetime.now(timezone.utc),
            end_timestamp=datetime.now(timezone.utc),
        ))

        # Save state
        history = [Message(role="user", content="x"), Message(role="assistant", content="y")] * 5
        engine1._save_state(history)
        engine1._store.close()

        # Second engine: same store, same conversation_id
        config2 = load_config(config_dict=config_dict)
        config2.conversation_id = conversation_id
        engine2 = VirtualContextEngine(config=config2)

        # State should be restored
        assert engine2.config.conversation_id == conversation_id
        # Restore now preserves the persisted compaction watermark so the
        # recovered session can resume from the correct suffix.
        assert engine2._engine_state.compacted_through == 4
        assert len(engine2._turn_tag_index.entries) == 5
        assert engine2._turn_tag_index.entries[0].tags == ["tag-0"]
        assert engine2._turn_tag_index.entries[4].tags == ["tag-4"]

    def test_completed_turn_checkpoint_restores_pending_gap(self, tmp_path):
        from virtual_context.engine import VirtualContextEngine
        from virtual_context.config import load_config
        from virtual_context.types import Message

        db_path = str(tmp_path / "store.db")
        config = load_config(config_dict={
            "context_window": 10000,
            "storage": {"backend": "sqlite", "sqlite": {"path": db_path}},
            "tag_generator": {"type": "keyword"},
        })
        engine1 = VirtualContextEngine(config=config)
        conversation_id = engine1.config.conversation_id

        history = [
            Message(role="user", content="hello"),
            Message(role="assistant", content="hi"),
        ]
        engine1.persist_completed_turn(history)
        engine1.close()

        config2 = load_config(config_dict={
            "context_window": 10000,
            "storage": {"backend": "sqlite", "sqlite": {"path": db_path}},
            "tag_generator": {"type": "keyword"},
        })
        config2.conversation_id = conversation_id
        engine2 = VirtualContextEngine(config=config2)

        assert engine2._engine_state.last_completed_turn == 0
        assert engine2._engine_state.last_indexed_turn == -1
        assert len(engine2._restored_pending_turns) == 1
        assert engine2._restored_pending_turns[0][0] == 0

    def test_startup_retries_committed_turn_prune(self, tmp_path):
        from virtual_context.engine import VirtualContextEngine
        from virtual_context.config import load_config
        from virtual_context.types import Message, StoredSegment, SegmentMetadata

        db_path = str(tmp_path / "store.db")
        config1 = load_config(config_dict={
            "context_window": 10000,
            "storage": {"backend": "sqlite", "sqlite": {"path": db_path}},
            "tag_generator": {"type": "keyword"},
        })
        engine1 = VirtualContextEngine(config=config1)
        conversation_id = engine1.config.conversation_id

        engine1._store.store_segment(StoredSegment(
            ref="seg-0",
            conversation_id=conversation_id,
            primary_tag="topic",
            tags=["topic"],
            summary="Compacted summary",
            summary_tokens=5,
            full_text="full text",
            full_tokens=10,
            metadata=SegmentMetadata(turn_count=2),
        ))
        for turn in range(3):
            engine1._store.save_turn_message(
                conversation_id,
                turn,
                f"user-{turn}",
                f"assistant-{turn}",
            )
        engine1._store.save_engine_state(EngineStateSnapshot(
            conversation_id=conversation_id,
            compacted_through=4,
            turn_tag_entries=[],
            turn_count=3,
            last_compacted_turn=1,
            last_completed_turn=2,
            last_indexed_turn=2,
            checkpoint_version=3,
        ))
        engine1.close()

        config2 = load_config(config_dict={
            "context_window": 10000,
            "storage": {"backend": "sqlite", "sqlite": {"path": db_path}},
            "tag_generator": {"type": "keyword"},
        })
        config2.conversation_id = conversation_id
        engine2 = VirtualContextEngine(config=config2)

        remaining = engine2._store.get_turn_messages(conversation_id, [0, 1, 2])
        assert 0 not in remaining
        assert 1 not in remaining
        assert 2 in remaining
        assert engine2._restored_conversation_history == [(2, "user-2", "assistant-2")]


# ---------------------------------------------------------------------------
# Vocabulary bootstrap
# ---------------------------------------------------------------------------


class TestVocabularyBootstrap:
    """Verify that _bootstrap_vocabulary loads historical tags into the tagger."""

    def test_bootstrap_from_store_tags(self, tmp_path):
        """Engine with store containing tag stats should populate tagger vocabulary."""
        from virtual_context.engine import VirtualContextEngine
        from virtual_context.config import load_config

        db_path = str(tmp_path / "store.db")
        config_dict = {
            "context_window": 10000,
            "storage": {"backend": "sqlite", "sqlite": {"path": db_path}},
            "tag_generator": {"type": "keyword"},
        }
        config = load_config(config_dict=config_dict)
        engine = VirtualContextEngine(config=config)

        # KeywordTagGenerator doesn't have load_vocabulary, so bootstrap is a no-op
        assert not hasattr(engine._tag_generator, "load_vocabulary") or \
            not hasattr(engine._tag_generator, "_tag_vocabulary")

    def test_bootstrap_from_turn_tag_index(self, tmp_path):
        """Engine with restored TurnTagIndex should populate LLM tagger vocabulary."""
        from virtual_context.engine import VirtualContextEngine
        from virtual_context.config import load_config
        from virtual_context.types import Message, EngineStateSnapshot

        db_path = str(tmp_path / "store.db")
        config_dict = {
            "context_window": 10000,
            "storage": {"backend": "sqlite", "sqlite": {"path": db_path}},
            "tag_generator": {"type": "keyword"},
        }

        # First engine: populate and save state
        config1 = load_config(config_dict=config_dict)
        engine1 = VirtualContextEngine(config=config1)
        conversation_id = engine1.config.conversation_id
        entries = []
        for i in range(5):
            entry = TurnTagEntry(
                turn_number=i,
                message_hash=f"h{i}",
                tags=["skincare", "retinol"] if i % 2 == 0 else ["fitness"],
                primary_tag="skincare" if i % 2 == 0 else "fitness",
            )
            engine1._turn_tag_index.append(entry)
            entries.append(entry)
        # Save state directly via store to avoid silent failure in _save_state
        engine1._store.save_engine_state(EngineStateSnapshot(
            conversation_id=conversation_id,
            compacted_through=0,
            turn_tag_entries=entries,
            turn_count=5,
        ))
        engine1._store.close()

        # Second engine: same store, LLM tagger (mock provider)
        config2 = load_config(config_dict={
            "context_window": 10000,
            "storage": {"backend": "sqlite", "sqlite": {"path": db_path}},
            "tag_generator": {"type": "llm", "provider": "test-provider"},
            "providers": {"test-provider": {
                "type": "generic_openai",
                "base_url": "http://fake:9999",
                "model": "test-model",
            }},
        }, validate=False)
        config2.conversation_id = conversation_id
        engine2 = VirtualContextEngine(config=config2)

        # LLMTagGenerator should have vocabulary populated
        vocab = engine2._tag_generator._tag_vocabulary
        assert "skincare" in vocab
        assert "retinol" in vocab
        assert "fitness" in vocab
        assert vocab["skincare"] >= 3  # appears in turns 0, 2, 4
        assert vocab["fitness"] >= 2   # appears in turns 1, 3

    def test_bootstrap_no_op_for_keyword_generator(self, tmp_path):
        """KeywordTagGenerator lacks load_vocabulary; bootstrap is silently skipped."""
        from virtual_context.engine import VirtualContextEngine
        from virtual_context.config import load_config

        db_path = str(tmp_path / "store.db")
        config = load_config(config_dict={
            "context_window": 10000,
            "storage": {"backend": "sqlite", "sqlite": {"path": db_path}},
            "tag_generator": {"type": "keyword"},
        })
        # Should not raise
        engine = VirtualContextEngine(config=config)
