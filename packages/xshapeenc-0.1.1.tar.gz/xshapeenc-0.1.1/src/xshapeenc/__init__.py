"""xshapeenc – Training-free Spatially Grounded Geometric Shape Encoding.

Quickstart
----------
>>> import numpy as np
>>> import xshapeenc
>>>
>>> # Geometry-only encoding
>>> mask = np.zeros((300, 300), dtype=np.float64)   # your shape mask
>>> geo_vec = xshapeenc.encode_geometry(mask)
>>>
>>> # Pose-only encoding
>>> pose_vec = [0.2, 0.5, 0.7, 0.9, 0.4]
>>> pose_coeffs = xshapeenc.encode_pose(pose_vec)
>>>
>>> # Joint geometry + pose encoding
>>> joint_vec = xshapeenc.encode_geopose(mask, pose_vec)

The encoder classes are also exposed directly for cases where you want to
reuse a single encoder across many inputs (avoids recomputing the Zernike
basis on every call):

>>> enc = xshapeenc.ShapeGeometryEncoder(n_max=5, res=300, lam=0.6, encode_len=512)
>>> vec = enc.encode(mask)
>>> rec = enc.decode(vec)
"""

from __future__ import annotations

from typing import List, Optional

import numpy as np

from ._geometry_encoder import ShapeGeometryEncoder
from ._geopose_encoder import ShapeGeometryPoseEncoder
from ._pose_encoder import ShapePoseEncoder

__all__: List[str] = [
    # Functional API
    "encode_geometry",
    "encode_pose",
    "encode_geopose",
    # Encoder classes (for reuse across multiple calls)
    "ShapeGeometryEncoder",
    "ShapePoseEncoder",
    "ShapeGeometryPoseEncoder",
]

__version__ = "0.1.1"


# ---------------------------------------------------------------------------
# Functional convenience API
# ---------------------------------------------------------------------------


def encode_geometry(
    shape_mask: np.ndarray,
    *,
    n_max: int = 5,
    res: int = 300,
    lam: float = 0.6,
    encode_len: int = 512,
    mask_in_euclidean: bool = False,
) -> List[float]:
    """Encode a 2-D shape mask using Zernike geometry encoding.

    A new :class:`ShapeGeometryEncoder` is created for every call.  When
    encoding many masks with the same parameters, instantiate the encoder once
    and call :meth:`ShapeGeometryEncoder.encode` directly to avoid recomputing
    the Zernike basis.

    Parameters
    ----------
    shape_mask:
        2-D array representing the shape.  If *mask_in_euclidean* is ``False``
        (default) the mask must be in polar coordinates with shape
        ``(res, res)``; if ``True`` it may be any Euclidean (H × W) image
        centred on the unit disk.
    n_max:
        Maximum Zernike polynomial order.
    res:
        Grid resolution (number of radial and angular samples).
    lam:
        Frequency-propagation regularisation parameter λ.
    encode_len:
        Target length of the output coefficient vector.
    mask_in_euclidean:
        When ``True`` the mask is re-sampled from Euclidean to polar
        coordinates before encoding.

    Returns
    -------
    List[float]
        Real-valued Zernike coefficient vector of length *encode_len*.
    """
    encoder = ShapeGeometryEncoder(n_max=n_max, res=res, lam=lam, encode_len=encode_len)
    return encoder.encode(shape_mask, mask_in_euclidean=mask_in_euclidean)


def encode_pose(
    pose_vec: List[float],
    *,
    res: int = 300,
    encode_len: int = 128,
    m_p: int = 17,
    seed_sigma: float = 0.1,
) -> List[float]:
    """Encode a pose vector using Zernike-based pose encoding.

    Parameters
    ----------
    pose_vec:
        1-D pose vector (e.g. spatial coordinates, scale factors).  The length
        of the vector determines ``K`` (number of radial windows).
    res:
        Grid resolution.
    encode_len:
        Number of Zernike radial coefficients to compute (``L``).
    m_p:
        Angular frequency mode used for the harmonic pose field.
    seed_sigma:
        Standard deviation of the seed Gaussian used to build the orthogonal
        radial window bank.

    Returns
    -------
    List[float]
        Zernike radial coefficient vector of length *encode_len*.
    """
    encoder = ShapePoseEncoder(
        res=res, K=len(pose_vec), L=encode_len, m_p=m_p, seed_sigma=seed_sigma
    )
    _, coeffs, _, _ = encoder.encode(pose_vec)
    return coeffs


def encode_geopose(
    shape_mask: np.ndarray,
    pose_vec: List[float],
    *,
    n_max: int = 20,
    res: int = 300,
    lam: float = 0.6,
    encode_len: int = 512,
    beta: float = 1.0,
    mask_in_euclidean: bool = False,
) -> List[float]:
    """Jointly encode a 2-D shape mask and a pose vector.

    The pose is embedded into the phase of the Zernike coefficients so that
    geometry and pose information are unified in a single fixed-length vector.

    Parameters
    ----------
    shape_mask:
        2-D shape mask (polar or Euclidean, see *mask_in_euclidean*).
    pose_vec:
        1-D pose vector.
    n_max:
        Maximum Zernike polynomial order.
    res:
        Grid resolution.
    lam:
        Frequency-propagation regularisation parameter λ.
    encode_len:
        Target encoding vector length.
    beta:
        Geometry / pose balance.  ``0`` → pure pose, ``1`` → equal weight
        (default), ``2`` → pure geometry.
    mask_in_euclidean:
        Pass ``True`` when *shape_mask* is a Euclidean image rather than a
        polar-coordinate array.

    Returns
    -------
    List[float]
        Joint geometry-pose coefficient vector of length *encode_len*.
    """
    encoder = ShapeGeometryPoseEncoder(
        n_max=n_max,
        res=res,
        lam=lam,
        encode_len=encode_len,
        pose_vec_len=len(pose_vec),
        beta=beta,
    )
    return encoder.encode(shape_mask, pose_vec=pose_vec, mask_in_euclidean=mask_in_euclidean)
