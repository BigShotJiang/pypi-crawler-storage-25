"""Internal canonicalization helpers."""
