"""Internal diffing helpers."""
