"""Internal linting helpers."""
