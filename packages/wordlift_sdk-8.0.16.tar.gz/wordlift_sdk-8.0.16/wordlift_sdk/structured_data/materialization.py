"""Materialization pipeline for YARRRML -> JSON-LD."""

from __future__ import annotations

from pathlib import Path

from wordlift_sdk.structured_data.yarrrml_pipeline import YarrrmlPipeline


class MaterializationPipeline:
    """Normalizes mappings, materializes JSON-LD, and post-processes output."""

    def __init__(self, pipeline: YarrrmlPipeline | None = None) -> None:
        self._pipeline = pipeline or YarrrmlPipeline()

    def normalize(
        self,
        yarrrml: str,
        url: str,
        xhtml_path: Path,
        response: object | None = None,
    ) -> tuple[str, list[dict]]:
        return self._pipeline.normalize_mappings(
            yarrrml,
            url,
            xhtml_path,
            response=response,
        )

    def materialize(
        self,
        normalized_yarrrml: str,
        xhtml_path: Path,
        workdir: Path,
        url: str | None = None,
        response: object | None = None,
        strict_url_token: bool = False,
        materialization_backend: str = "morph",
    ) -> dict:
        return self._pipeline.materialize_jsonld(
            normalized_yarrrml,
            xhtml_path,
            workdir,
            response=response,
            url=url,
            strict_url_token=strict_url_token,
            materialization_backend=materialization_backend,
        )

    def postprocess(
        self,
        jsonld_raw: dict,
        mappings: list[dict],
        cleaned_xhtml: str,
        dataset_uri: str,
        url: str,
    ) -> dict:
        return self._pipeline.postprocess_jsonld(
            jsonld_raw,
            mappings,
            cleaned_xhtml,
            dataset_uri,
            url,
        )

    def run(
        self,
        yarrrml: str,
        url: str,
        cleaned_xhtml: str,
        dataset_uri: str,
        xhtml_path: Path,
        workdir: Path,
        response: object | None = None,
        strict_url_token: bool = False,
        materialization_backend: str = "morph",
    ) -> tuple[dict, list[dict]]:
        normalized_yarrrml, mappings = self.normalize(
            yarrrml,
            url,
            xhtml_path,
            response=response,
        )
        jsonld_raw = self.materialize(
            normalized_yarrrml,
            xhtml_path,
            workdir,
            url=url,
            response=response,
            strict_url_token=strict_url_token,
            materialization_backend=materialization_backend,
        )
        jsonld = self.postprocess(
            jsonld_raw,
            mappings,
            cleaned_xhtml,
            dataset_uri,
            url,
        )
        return jsonld, mappings
