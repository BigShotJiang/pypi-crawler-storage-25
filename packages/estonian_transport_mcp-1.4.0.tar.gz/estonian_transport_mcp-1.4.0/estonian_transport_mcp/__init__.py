"""MCP server for Estonian public transport timetables."""

from importlib.metadata import version

__version__ = version("estonian-transport-mcp")

from estonian_transport_mcp.api import graphql, OTP_GRAPHQL_URL, TALLINN_GPS_URL
from estonian_transport_mcp.formatting import fmt_seconds, fmt_time_of_day
from estonian_transport_mcp.tools import (
    search_stops,
    get_departures,
    plan_trip,
    nearby_stops,
    get_route,
    get_trip_stops,
    tallinn_vehicles,
)
from estonian_transport_mcp.server import mcp, main

__all__ = [
    "graphql",
    "OTP_GRAPHQL_URL",
    "TALLINN_GPS_URL",
    "fmt_seconds",
    "fmt_time_of_day",
    "search_stops",
    "get_departures",
    "plan_trip",
    "nearby_stops",
    "get_route",
    "get_trip_stops",
    "tallinn_vehicles",
    "mcp",
    "main",
]
