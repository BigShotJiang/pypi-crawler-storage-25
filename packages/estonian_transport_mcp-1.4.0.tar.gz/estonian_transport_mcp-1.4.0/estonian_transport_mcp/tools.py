"""MCP tool definitions for Estonian transport."""

from estonian_transport_mcp.api import graphql, fetch_tallinn_gps, VEHICLE_TYPES
from estonian_transport_mcp.formatting import fmt_seconds, fmt_time_of_day
from estonian_transport_mcp.server import mcp


@mcp.tool()
async def server_version() -> str:
    """Return the version of this MCP server."""
    from estonian_transport_mcp import __version__
    return f"estonian-transport-mcp v{__version__}"


@mcp.tool()
async def search_stops(name: str) -> str:
    """Search for Estonian public transport stops by name.

    Args:
        name: Stop name to search for (e.g. 'Viru', 'Balti jaam', 'Tartu')
    """
    data = await graphql(
        """
        query($name: String!) {
            stops(name: $name) {
                gtfsId name code lat lon vehicleMode
                routes { shortName longName mode }
            }
        }
        """,
        {"name": name},
    )
    stops = data["stops"]
    if not stops:
        return f'No stops found matching "{name}".'

    lines = []
    for s in stops[:30]:
        routes = ", ".join(f"{r['mode']} {r['shortName']}" for r in s["routes"])
        lines.append(
            f"**{s['name']}** ({s.get('code') or 'no code'}) — ID: `{s['gtfsId']}`\n"
            f"  Mode: {s.get('vehicleMode') or 'unknown'} | Routes: {routes or 'none'}\n"
            f"  {s['lat']}, {s['lon']}"
        )
    return f'Found {len(stops)} stops matching "{name}":\n\n' + "\n\n".join(lines)


@mcp.tool()
async def get_departures(
    stop_id: str,
    limit: int = 15,
    date: str | None = None,
    time: str | None = None,
) -> str:
    """Get upcoming departures from a specific stop.

    Args:
        stop_id: GTFS stop ID (e.g. '1:4173'). Use search_stops to find IDs.
        limit: Number of departures to return (default 15, max 50)
        date: Date to get departures for, YYYY-MM-DD (default: today)
        time: Time to get departures from, HH:MM (default: now)
    """
    n = min(limit, 50)

    start_time = None
    if date or time:
        from datetime import datetime, timezone, timedelta
        eet = timezone(timedelta(hours=2))
        now = datetime.now(eet)
        d = datetime.strptime(date, "%Y-%m-%d").date() if date else now.date()
        if time:
            parts = time.split(":")
            h, m = int(parts[0]), int(parts[1])
            dt = datetime(d.year, d.month, d.day, h, m, tzinfo=eet)
        else:
            dt = datetime(d.year, d.month, d.day, tzinfo=eet)
        start_time = int(dt.timestamp())

    if start_time is not None:
        data = await graphql(
            """
            query($id: String!, $n: Int!, $startTime: Long!) {
                stop(id: $id) {
                    name code gtfsId
                    stoptimesWithoutPatterns(numberOfDepartures: $n, startTime: $startTime) {
                        scheduledDeparture realtimeDeparture realtime headsign
                        trip { gtfsId route { shortName longName mode agency { name } } }
                    }
                }
            }
            """,
            {"id": stop_id, "n": n, "startTime": start_time},
        )
    else:
        data = await graphql(
            """
            query($id: String!, $n: Int!) {
                stop(id: $id) {
                    name code gtfsId
                    stoptimesWithoutPatterns(numberOfDepartures: $n) {
                        scheduledDeparture realtimeDeparture realtime headsign
                        trip { gtfsId route { shortName longName mode agency { name } } }
                    }
                }
            }
            """,
            {"id": stop_id, "n": n},
        )
    stop = data["stop"]
    if not stop:
        return f"Stop not found: {stop_id}"

    deps = stop["stoptimesWithoutPatterns"]
    if not deps:
        return f"No upcoming departures from {stop['name']}."

    lines = []
    for d in deps:
        time = fmt_time_of_day(d["realtimeDeparture"])
        scheduled = fmt_time_of_day(d["scheduledDeparture"])
        rt = f" (scheduled {scheduled})" if d["realtime"] and d["realtimeDeparture"] != d["scheduledDeparture"] else ""
        r = d["trip"]["route"]
        trip_id = d["trip"]["gtfsId"]
        lines.append(f"{time}{rt} — {r['mode']} **{r['shortName']}** → {d['headsign']} ({r['agency']['name']}) [trip `{trip_id}`]")

    return f"Departures from **{stop['name']}** ({stop.get('code') or stop['gtfsId']}):\n\n" + "\n".join(lines)


async def _resolve_place(name: str) -> tuple[float, float] | str:
    """Resolve a place name to (lat, lon) via stop search.

    Returns (lat, lon) tuple on success, or an error string with candidates.
    Supports:
      - Coordinates: "59.437,24.745" or "59.437 24.745"
      - Stop names: matched against OTP stop database
    """
    # Try parsing as coordinates first
    stripped = name.strip()
    for sep in [",", " "]:
        if sep in stripped:
            parts = stripped.split(sep, 1)
            try:
                lat, lon = float(parts[0].strip()), float(parts[1].strip())
                if 57 <= lat <= 60 and 21 <= lon <= 29:  # roughly Estonia
                    return lat, lon
            except ValueError:
                pass

    data = await graphql(
        'query($name: String!) { stops(name: $name) { name gtfsId lat lon } }',
        {"name": name},
    )
    stops = data["stops"]
    if not stops:
        return f'No stops found matching "{name}". Try a different name or use coordinates (lat,lon).'

    # Deduplicate by name (same stop often has multiple platforms)
    seen = {}
    for s in stops:
        key = s["name"]
        if key not in seen:
            seen[key] = s

    unique = list(seen.values())

    # If the top result name closely matches the query, use it
    if unique[0]["name"].lower().startswith(name.lower()) or name.lower() in unique[0]["name"].lower():
        return unique[0]["lat"], unique[0]["lon"]

    # Multiple ambiguous results — return them for the LLM to pick
    candidates = "\n".join(
        f"  - {s['name']} ({s['lat']:.4f}, {s['lon']:.4f})"
        for s in unique[:8]
    )
    return (
        f'Ambiguous: "{name}" matched multiple stops:\n{candidates}\n'
        f'Please use a more specific name or coordinates (lat,lon).'
    )


@mcp.tool()
async def plan_trip(
    from_place: str,
    to_place: str,
    date: str | None = None,
    time: str | None = None,
    arrive_by: bool = False,
    num_results: int = 3,
    max_walk_distance: float | None = None,
    max_transfers: int | None = None,
    transfer_penalty: int | None = None,
) -> str:
    """Plan a public transport trip between two locations in Estonia.

    Args:
        from_place: Origin — stop name (e.g. 'Viru', 'Balti jaam') or coordinates ('59.437,24.745')
        to_place: Destination — stop name or coordinates
        date: Travel date YYYY-MM-DD (default: today)
        time: Travel time HH:MM (default: now)
        arrive_by: If true, time is desired arrival time
        num_results: Number of itinerary options (default 3)
        max_walk_distance: Maximum walking distance in meters (default: ~2000)
        max_transfers: Maximum number of transfers (default: no limit)
        transfer_penalty: Penalty per transfer in seconds — higher values prefer fewer transfers (default: 0)
    """
    origin = await _resolve_place(from_place)
    if isinstance(origin, str):
        return origin
    destination = await _resolve_place(to_place)
    if isinstance(destination, str):
        return destination

    from_lat, from_lon = origin
    to_lat, to_lon = destination

    # API requires HH:MM:SS format
    if time and len(time) == 5 and time[2] == ":":
        time = time + ":00"
    try:
        data = await graphql(
            """
            query($fromLat: Float!, $fromLon: Float!, $toLat: Float!, $toLon: Float!,
                  $numItineraries: Int!, $arriveBy: Boolean, $date: String, $time: String,
                  $maxWalkDistance: Float, $maxTransfers: Int, $transferPenalty: Int) {
                plan(from: {lat: $fromLat, lon: $fromLon}, to: {lat: $toLat, lon: $toLon},
                     numItineraries: $numItineraries, arriveBy: $arriveBy, date: $date, time: $time,
                     maxWalkDistance: $maxWalkDistance, maxTransfers: $maxTransfers,
                     transferPenalty: $transferPenalty) {
                    itineraries {
                        startTime endTime duration walkDistance
                        legs {
                            mode startTime endTime duration distance
                            from { name stop { code name } }
                            to { name stop { code name } }
                            trip { tripHeadsign }
                            route { shortName longName agency { name } }
                        }
                    }
                }
            }
            """,
            {
                "fromLat": from_lat, "fromLon": from_lon,
                "toLat": to_lat, "toLon": to_lon,
                "numItineraries": num_results, "arriveBy": arrive_by,
                "date": date, "time": time,
                "maxWalkDistance": max_walk_distance,
                "maxTransfers": max_transfers,
                "transferPenalty": transfer_penalty,
            },
        )
    except RuntimeError as e:
        return str(e)
    itineraries = data["plan"]["itineraries"]
    if not itineraries:
        return "No routes found for this trip."

    results = []
    for i, it in enumerate(itineraries, 1):
        dur = fmt_seconds(it["duration"])
        walk_km = it["walkDistance"] / 1000

        legs = []
        for leg in it["legs"]:
            if leg["mode"] == "WALK":
                legs.append(f"  Walk {leg['distance']/1000:.1f}km ({fmt_seconds(leg['duration'])}) to {leg['to']['name']}")
            else:
                route = leg.get("route") or {}
                name = f"{route.get('shortName', '')} ({route.get('agency', {}).get('name', '')})" if route else leg["mode"]
                headsign = (leg.get("trip") or {}).get("tripHeadsign") or leg["to"]["name"]
                legs.append(
                    f"  {leg['mode']} **{name}** → {headsign}\n"
                    f"    {leg['from']['name']} → {leg['to']['name']}"
                )

        results.append(f"**Option {i}**: {dur}, walk {walk_km:.1f}km\n" + "\n".join(legs))

    return "Trip options:\n\n" + "\n\n---\n\n".join(results)


@mcp.tool()
async def nearby_stops(lat: float, lon: float, radius: int = 500) -> str:
    """Find public transport stops near a given location.

    Args:
        lat: Latitude
        lon: Longitude
        radius: Search radius in meters (default 500, max 2000)
    """
    r = min(radius, 2000)
    data = await graphql(
        """
        query($lat: Float!, $lon: Float!, $radius: Int!) {
            stopsByRadius(lat: $lat, lon: $lon, radius: $radius) {
                edges { node { distance stop { gtfsId name code lat lon vehicleMode routes { shortName mode } } } }
            }
        }
        """,
        {"lat": lat, "lon": lon, "radius": r},
    )
    edges = data["stopsByRadius"]["edges"]
    if not edges:
        return f"No stops found within {r}m of {lat}, {lon}."

    lines = []
    for e in edges[:25]:
        s = e["node"]["stop"]
        dist = e["node"]["distance"]
        routes = ", ".join(r["shortName"] for r in s["routes"])
        lines.append(f"**{s['name']}** ({s.get('code') or 'no code'}) — {dist}m — ID: `{s['gtfsId']}`\n  Routes: {routes or 'none'}")

    return f"Stops within {r}m of {lat}, {lon}:\n\n" + "\n\n".join(lines)


@mcp.tool()
async def get_route(route_id: str) -> str:
    """Get details about a transport route including its stops.

    Args:
        route_id: GTFS route ID (e.g. '1:1'). Find these from stop search results.
    """
    data = await graphql(
        """
        query($id: String!) {
            route(id: $id) {
                gtfsId shortName longName mode
                agency { name }
                patterns { name headsign stops { gtfsId name code } }
            }
        }
        """,
        {"id": route_id},
    )
    route = data["route"]
    if not route:
        return f"Route not found: {route_id}"

    patterns = []
    for p in route["patterns"]:
        stops = "\n".join(f"  {s['name']} (`{s['gtfsId']}`)" for s in p["stops"])
        patterns.append(f"**{p.get('headsign') or p['name']}**:\n{stops}")

    return (
        f"**Route {route['shortName']}** — {route['longName']}\n"
        f"Mode: {route['mode']} | Agency: {route['agency']['name']}\n"
        f"ID: `{route['gtfsId']}`\n\n"
        f"Patterns:\n\n" + "\n\n".join(patterns)
    )


@mcp.tool()
async def get_trip_stops(trip_id: str) -> str:
    """Get the full schedule of a specific trip — all stops with arrival/departure times.

    Use this to trace a bus/tram/train along its route and see when it arrives at each stop.
    Trip IDs can be found in get_departures output.

    Args:
        trip_id: GTFS trip ID (e.g. '1:155_20250329_1_1'). Found in get_departures results.
    """
    data = await graphql(
        """
        query($id: String!) {
            trip(id: $id) {
                gtfsId
                tripHeadsign
                route { shortName longName mode agency { name } }
                stoptimes {
                    scheduledArrival scheduledDeparture
                    realtimeArrival realtimeDeparture
                    realtime
                    stop { gtfsId name code }
                }
            }
        }
        """,
        {"id": trip_id},
    )
    trip = data["trip"]
    if not trip:
        return f"Trip not found: {trip_id}"

    route = trip["route"]
    header = (
        f"**{route['mode']} {route['shortName']}** — {route['longName']}\n"
        f"Agency: {route['agency']['name']} | Headsign: {trip['tripHeadsign']}\n"
        f"Trip ID: `{trip['gtfsId']}`\n"
    )

    lines = []
    for i, st in enumerate(trip["stoptimes"]):
        stop = st["stop"]
        arr = fmt_time_of_day(st["realtimeArrival"])
        dep = fmt_time_of_day(st["realtimeDeparture"])

        if st["realtime"]:
            sched_arr = fmt_time_of_day(st["scheduledArrival"])
            sched_dep = fmt_time_of_day(st["scheduledDeparture"])
            rt_note = ""
            if sched_arr != arr or sched_dep != dep:
                rt_note = f" (scheduled {sched_arr}–{sched_dep})"
        else:
            rt_note = ""

        if arr == dep:
            time_str = arr
        else:
            time_str = f"{arr}→{dep}"

        lines.append(
            f"  {i+1}. {time_str}{rt_note} — **{stop['name']}** ({stop.get('code') or stop['gtfsId']})"
        )

    return header + "\nStops:\n" + "\n".join(lines)


@mcp.tool()
async def tallinn_vehicles(
    vehicle_type: str | None = None,
    line: str | None = None,
) -> str:
    """Get real-time GPS positions of Tallinn public transport vehicles.

    Args:
        vehicle_type: Filter by type: 'bus', 'tram', or 'trolleybus' (default: all)
        line: Filter by line/route number (e.g. '2', '17', '42A')
    """
    type_filter = None
    if vehicle_type:
        for code, name in VEHICLE_TYPES.items():
            if name == vehicle_type.lower():
                type_filter = code
                break
        if type_filter is None:
            return f"Unknown vehicle type '{vehicle_type}'. Use 'bus', 'tram', or 'trolleybus'."

    raw = await fetch_tallinn_gps()

    vehicles = []
    for row in raw.strip().splitlines():
        parts = row.split(",")
        if len(parts) < 7:
            continue

        vtype, vline, lng_raw, lat_raw, _, heading, vid = parts[:7]
        destination = parts[9] if len(parts) > 9 else ""

        if lat_raw == "0" or lng_raw == "0":
            continue
        if vline == "0":
            continue

        if type_filter and vtype != type_filter:
            continue
        if line and vline != line:
            continue

        lat = int(lat_raw) / 1_000_000
        lon = int(lng_raw) / 1_000_000
        hdg = int(heading) if heading != "999" else None

        vehicles.append({
            "type": VEHICLE_TYPES.get(vtype, vtype),
            "line": vline,
            "lat": lat,
            "lon": lon,
            "heading": hdg,
            "vehicle_id": vid,
            "destination": destination,
        })

    if not vehicles:
        filters = []
        if vehicle_type:
            filters.append(f"type={vehicle_type}")
        if line:
            filters.append(f"line={line}")
        fstr = f" ({', '.join(filters)})" if filters else ""
        return f"No active vehicles found{fstr}."

    lines_out = []
    for v in vehicles[:50]:
        hdg_str = f" heading {v['heading']}°" if v["heading"] is not None else ""
        dest_str = f" → {v['destination']}" if v["destination"] else ""
        lines_out.append(
            f"**{v['type'].title()} {v['line']}**{dest_str} — vehicle {v['vehicle_id']}\n"
            f"  {v['lat']:.6f}, {v['lon']:.6f}{hdg_str}"
        )

    return f"Active Tallinn vehicles ({len(vehicles)} total, showing up to 50):\n\n" + "\n\n".join(lines_out)
