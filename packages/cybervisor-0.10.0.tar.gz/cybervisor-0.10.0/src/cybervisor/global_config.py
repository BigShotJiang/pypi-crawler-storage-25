from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import yaml

from cybervisor.adapters.registry import supported_agent_names

AgentToolType = Literal["gemini", "claude", "mock", "codex"]
DEFAULT_ENDPOINT = "https://api.openai.com/v1"
DEFAULT_MODEL = "auto"

CONFIG_DIR_NAME = ".cybervisor"
CONFIG_FILE_NAME = "config.yaml"
DEFAULT_AGENT_TOOL: AgentToolType = "claude"


class GlobalConfigError(ValueError):
    """Raised when the global cybervisor config is invalid."""


@dataclass(slots=True)
class GlobalLLMConfig:
    api_key: str = ""
    base_url: str = DEFAULT_ENDPOINT
    model: str = DEFAULT_MODEL


@dataclass(slots=True)
class GlobalServerConfig:
    host: str = "127.0.0.1"
    port: int = 8765
    reconnect_ttl_seconds: float = 300.0
    max_event_buffer: int = 1000


@dataclass(slots=True)
class GlobalConfig:
    agent_tool: AgentToolType = DEFAULT_AGENT_TOOL
    llm: GlobalLLMConfig = field(default_factory=GlobalLLMConfig)
    server: GlobalServerConfig = field(default_factory=GlobalServerConfig)


def global_config_path() -> Path:
    return Path.home() / CONFIG_DIR_NAME / CONFIG_FILE_NAME


def _validate_agent_tool(value: object) -> AgentToolType:
    normalized = str(value).strip().lower()
    supported = supported_agent_names()
    if normalized not in supported:
        raise GlobalConfigError(
            f"Unsupported agent_tool: {value}. Supported values: {', '.join(sorted(supported))}"
        )
    return normalized  # type: ignore[return-value]


def _load_raw_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    loaded = yaml.safe_load(path.read_text(encoding="utf-8"))
    if loaded is None:
        return {}
    if not isinstance(loaded, dict):
        raise GlobalConfigError(f"Global config at {path} must be a YAML mapping")
    if not all(isinstance(key, str) for key in loaded):
        raise GlobalConfigError(f"Global config at {path} must use string keys")
    return dict(loaded)


def load_global_config(path: Path | None = None) -> GlobalConfig:
    config_path = path or global_config_path()
    raw = _load_raw_config(config_path)
    llm_raw = raw.get("llm", {})
    if llm_raw is None:
        llm_raw = {}
    if not isinstance(llm_raw, dict):
        raise GlobalConfigError(f"Global config at {config_path} field 'llm' must be a mapping")

    server_raw = raw.get("server", {})
    if server_raw is None:
        server_raw = {}
    if not isinstance(server_raw, dict):
        raise GlobalConfigError(f"Global config at {config_path} field 'server' must be a mapping")

    agent_tool_raw = raw.get("agent_tool", raw.get("agent", DEFAULT_AGENT_TOOL))
    return GlobalConfig(
        agent_tool=_validate_agent_tool(agent_tool_raw),
        llm=GlobalLLMConfig(
            api_key=str(llm_raw.get("api_key") or ""),
            base_url=str(llm_raw.get("base_url") or DEFAULT_ENDPOINT),
            model=str(llm_raw.get("model") or DEFAULT_MODEL),
        ),
        server=GlobalServerConfig(
            host=str(server_raw.get("host", "127.0.0.1")),
            port=int(server_raw.get("port", 8765)),
            reconnect_ttl_seconds=float(server_raw.get("reconnect_ttl_seconds", 300.0)),
            max_event_buffer=int(server_raw.get("max_event_buffer", 1000)),
        ),
    )


def write_global_config(config: GlobalConfig, path: Path | None = None) -> Path:
    config_path = path or global_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        yaml.safe_dump(
            {
                "agent_tool": config.agent_tool,
                "llm": {
                    "api_key": config.llm.api_key,
                    "base_url": config.llm.base_url,
                    "model": config.llm.model,
                },
                "server": {
                    "host": config.server.host,
                    "port": config.server.port,
                    "reconnect_ttl_seconds": config.server.reconnect_ttl_seconds,
                    "max_event_buffer": config.server.max_event_buffer,
                },
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    try:
        os.chmod(config_path, 0o600)
    except OSError:
        pass
    return config_path


def update_global_agent_tool(agent_tool: str, path: Path | None = None) -> tuple[AgentToolType, Path]:
    config_path = path or global_config_path()
    current = load_global_config(config_path)
    updated = GlobalConfig(agent_tool=_validate_agent_tool(agent_tool), llm=current.llm, server=current.server)
    written_path = write_global_config(updated, config_path)
    return updated.agent_tool, written_path
