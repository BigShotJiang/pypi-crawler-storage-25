from __future__ import annotations

import asyncio
import json
import os
import queue
import subprocess
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from cybervisor.core_hooks.common import continuation_message_for_decision
from cybervisor.stream_logging import CanonicalLogEvent, canonicalize_message_text, render_canonical_event


_HOOK_CONFIG_PATH = Path(".cybervisor/hooks/hook_config.json")
_REQUEST_TIMEOUT_SECONDS = 30
_NOTIFICATION_TIMEOUT_SECONDS = 30
_TURN_IDLE_GRACE_SECONDS = 180


def _json_rpc_message(message_id: int, method: str, params: dict[str, Any]) -> str:
    return json.dumps({"jsonrpc": "2.0", "id": message_id, "method": method, "params": params})


def _json_rpc_notification_method(payload: dict[str, Any]) -> str | None:
    method = payload.get("method")
    return method if isinstance(method, str) and method.strip() else None


def _json_rpc_response_id(payload: dict[str, Any]) -> int | None:
    response_id = payload.get("id")
    return response_id if isinstance(response_id, int) else None


def _text_input(text: str) -> list[dict[str, str]]:
    return [{"type": "text", "text": text}]


def _phase_sort_key(phase: object) -> int:
    if phase == "final_answer":
        return 1
    if phase == "commentary":
        return 0
    return -1


def _extract_reply_text(turn_payload: dict[str, Any]) -> str:
    turn = turn_payload.get("turn")
    if not isinstance(turn, dict):
        return ""
    items = turn.get("items")
    if not isinstance(items, list):
        return ""

    agent_messages: list[tuple[int, str]] = []
    for item in items:
        if not isinstance(item, dict) or item.get("type") != "agentMessage":
            continue
        text = item.get("text")
        if not isinstance(text, str) or not text.strip():
            continue
        agent_messages.append((_phase_sort_key(item.get("phase")), text.strip()))

    if not agent_messages:
        return ""
    agent_messages.sort(key=lambda item: item[0], reverse=True)
    return agent_messages[0][1]


def _string_value(value: object) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None


def _tool_call_payload(item: dict[str, Any]) -> tuple[str, dict[str, Any] | None] | None:
    item_type = _string_value(item.get("type"))
    if item_type in {"functionCall", "function_call", "toolCall", "tool_call", "customToolCall", "custom_tool_call"}:
        name = _string_value(item.get("name")) or _string_value(item.get("toolName")) or "Tool"
        raw_input = item.get("arguments")
        if raw_input is None:
            raw_input = item.get("input")
        if raw_input is None:
            raw_input = item.get("rawInput")
        if raw_input is None:
            raw_input = item.get("parameters")
        if raw_input is None:
            raw_input = item.get("params")
        if raw_input is None:
            raw_input = item.get("payload")
        if isinstance(raw_input, str):
            try:
                decoded = json.loads(raw_input)
            except json.JSONDecodeError:
                decoded = None
            raw_input = decoded if isinstance(decoded, dict) else {"input": raw_input}
        if raw_input is None:
            for key in ("file_path", "path", "command", "pattern"):
                value = item.get(key)
                if value is not None:
                    raw_input = {key: value}
                    break
        if not isinstance(raw_input, dict):
            raw_input = None
        return name, raw_input

    if item_type == "commandExecution":
        command = _string_value(item.get("command"))
        raw_input = {"command": command} if command is not None else None
        return "Bash", raw_input

    return None


def _file_change_event(item: dict[str, Any]) -> CanonicalLogEvent | None:
    if _string_value(item.get("type")) != "fileChange":
        return None

    changes = item.get("changes")
    if not isinstance(changes, list) or not changes:
        return CanonicalLogEvent(kind="tool_call", tool_name="FileChange")

    first_change = changes[0]
    if not isinstance(first_change, dict):
        return CanonicalLogEvent(kind="tool_call", tool_name="FileChange")

    path = _string_value(first_change.get("path"))
    kind = _string_value(first_change.get("kind"))

    tool_name = "FileChange"
    if kind in {"create", "created", "add", "added"}:
        tool_name = "Write"
    elif kind in {"update", "updated", "modify", "modified", "edit", "edited"}:
        tool_name = "Edit"
    elif kind in {"delete", "deleted", "remove", "removed"}:
        tool_name = "Delete"

    tool_input: dict[str, Any] = {}
    if path is not None:
        tool_input["file_path"] = path
    if len(changes) > 1:
        tool_input["count"] = len(changes)
    if kind is not None and tool_name == "FileChange":
        tool_input["kind"] = kind

    if tool_input:
        return CanonicalLogEvent(kind="tool_call", tool_name=tool_name, tool_input=cast(dict[object, object], tool_input))
    return CanonicalLogEvent(kind="tool_call", tool_name=tool_name)


def _special_item_event(item: dict[str, Any]) -> CanonicalLogEvent | None:
    item_type = _string_value(item.get("type"))
    if item_type == "mcpToolCall":
        server = _string_value(item.get("server"))
        tool = _string_value(item.get("tool"))
        tool_input: dict[str, Any] = {}
        if server is not None:
            tool_input["server"] = server
        if tool is not None:
            tool_input["tool"] = tool
        return CanonicalLogEvent(kind="tool_call", tool_name="MCP", tool_input=cast(dict[object, object], tool_input))
    if item_type == "collabToolCall":
        tool = _string_value(item.get("tool"))
        sender_thread_id = _string_value(item.get("senderThreadId"))
        receiver_thread_id = _string_value(item.get("receiverThreadId"))
        new_thread_id = _string_value(item.get("newThreadId"))
        tool_input = {}
        if tool is not None:
            tool_input["tool"] = tool
        if sender_thread_id is not None:
            tool_input["sender_thread_id"] = sender_thread_id
        if receiver_thread_id is not None:
            tool_input["receiver_thread_id"] = receiver_thread_id
        if new_thread_id is not None:
            tool_input["new_thread_id"] = new_thread_id
        return CanonicalLogEvent(kind="tool_call", tool_name="Collab", tool_input=cast(dict[object, object], tool_input))
    if item_type == "webSearch":
        query = _string_value(item.get("query"))
        action = item.get("action")
        tool_input = {}
        if query is not None:
            tool_input["query"] = query
        if isinstance(action, dict):
            action_type = _string_value(action.get("type"))
            if action_type is not None:
                tool_input["action"] = action_type
        return CanonicalLogEvent(kind="tool_call", tool_name="WebSearch", tool_input=cast(dict[object, object], tool_input))
    if item_type == "imageView":
        path = _string_value(item.get("path"))
        tool_input = {"path": path} if path is not None else {}
        return CanonicalLogEvent(kind="tool_call", tool_name="ImageView", tool_input=cast(dict[object, object], tool_input))
    if item_type == "enteredReviewMode":
        review = _string_value(item.get("review"))
        tool_input = {"review": review} if review is not None else {}
        return CanonicalLogEvent(kind="tool_call", tool_name="ReviewStart", tool_input=cast(dict[object, object], tool_input))
    if item_type == "exitedReviewMode":
        review = _string_value(item.get("review"))
        tool_input = {"review": review} if review is not None else {}
        return CanonicalLogEvent(kind="tool_call", tool_name="ReviewEnd", tool_input=cast(dict[object, object], tool_input))
    return None


def _tool_item_id(payload: dict[str, Any]) -> str | None:
    method = _json_rpc_notification_method(payload)
    params = payload.get("params")
    if method not in {"item/started", "item/completed"} or not isinstance(params, dict):
        return None
    item = params.get("item")
    if not isinstance(item, dict):
        return None
    if _tool_call_payload(item) is None and _file_change_event(item) is None and _special_item_event(item) is None:
        return None
    item_id = item.get("id")
    return item_id.strip() if isinstance(item_id, str) and item_id.strip() else None


def notification_to_events(payload: dict[str, Any]) -> list[CanonicalLogEvent]:
    method = _json_rpc_notification_method(payload)
    params = payload.get("params")
    if method is None or not isinstance(params, dict):
        return []

    if method == "thread/started":
        thread = params.get("thread")
        thread_id = thread.get("id") if isinstance(thread, dict) else None
        parts = (f"thread_id={thread_id}",) if isinstance(thread_id, str) and thread_id else ()
        return [CanonicalLogEvent(kind="session_start", summary_parts=parts)]

    if method == "turn/completed":
        reply_text = _extract_reply_text(params)
        if reply_text:
            return [CanonicalLogEvent(kind="completed", summary_parts=(reply_text,), status="success")]
        return [CanonicalLogEvent(kind="completed", summary_parts=("success",), status="success")]

    if method == "error":
        message = params.get("message")
        if isinstance(message, str) and message.strip():
            return [CanonicalLogEvent(kind="plain_text", text=f"error: {message.strip()}")]

    if method not in {"item/started", "item/completed"}:
        return []
    item = params.get("item")
    if not isinstance(item, dict):
        return []
    if item.get("type") == "agentMessage":
        text = item.get("text")
        if isinstance(text, str) and text.strip():
            return canonicalize_message_text(text.strip(), as_hook_feedback=False)
        return []
    tool_call = _tool_call_payload(item)
    if tool_call is not None:
        title, raw_input = tool_call
        if isinstance(raw_input, dict):
            return [CanonicalLogEvent(kind="tool_call", tool_name=title, tool_input=cast(dict[object, object], raw_input))]
        return [CanonicalLogEvent(kind="tool_call", tool_name=title)]
    file_change_event = _file_change_event(item)
    if file_change_event is not None:
        return [file_change_event]
    special_item_event = _special_item_event(item)
    if special_item_event is not None:
        return [special_item_event]
    return []


def _payload_summary(payload: dict[str, Any]) -> str:
    method = _json_rpc_notification_method(payload)
    if method is not None:
        return method
    response_id = _json_rpc_response_id(payload)
    if response_id is not None:
        return f"response id={response_id}"
    return "unknown payload"


class _ReaderThread(threading.Thread):
    def __init__(
        self,
        stdout: Any,
        log_path: Path,
        transcript_parts: list[str],
        notifications: queue.Queue[dict[str, Any]],
        responses: queue.Queue[dict[str, Any]],
    ) -> None:
        super().__init__(name="codex-app-server-reader", daemon=True)
        self._stdout = stdout
        self._log_path = log_path
        self._transcript_parts = transcript_parts
        self._notifications = notifications
        self._responses = responses

    def run(self) -> None:
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        with self._log_path.open("w", encoding="utf-8") as log_handle:
            for raw_line in self._stdout:
                self._transcript_parts.append(raw_line)
                log_handle.write(raw_line)
                log_handle.flush()
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    self._notifications.put({"method": "error", "params": {"message": line}})
                    continue
                if not isinstance(payload, dict):
                    continue
                if _json_rpc_response_id(payload) is not None:
                    self._responses.put(payload)
                    continue
                method = _json_rpc_notification_method(payload)
                if method is not None:
                    self._notifications.put(payload)


class _CodexAppServerTransport:
    def __init__(self, process: subprocess.Popen[str], request: Any) -> None:
        self._process = process
        self._message_id = 0
        self._transcript_parts: list[str] = []
        self._notifications: queue.Queue[dict[str, Any]] = queue.Queue()
        self._responses: queue.Queue[dict[str, Any]] = queue.Queue()
        self._last_notification: dict[str, Any] | None = None
        assert process.stdout is not None
        self._reader = _ReaderThread(
            process.stdout,
            Path(request.log_file),
            self._transcript_parts,
            self._notifications,
            self._responses,
        )
        self._reader.start()

    @property
    def transcript(self) -> str:
        return "".join(self._transcript_parts).rstrip("\n")

    @property
    def process_exit_code(self) -> int | None:
        return self._process.poll()

    def _next_id(self) -> int:
        self._message_id += 1
        return self._message_id

    def request(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        assert self._process.stdin is not None
        message_id = self._next_id()
        self._process.stdin.write(_json_rpc_message(message_id, method, params) + "\n")
        self._process.stdin.flush()

        while True:
            try:
                payload = self._responses.get(timeout=_REQUEST_TIMEOUT_SECONDS)
            except queue.Empty as exc:
                process_state = self._process.poll()
                suffix = f"; process exited with code {process_state}" if process_state is not None else ""
                raise RuntimeError(
                    f"Timed out waiting for Codex app-server response to '{method}' after {_REQUEST_TIMEOUT_SECONDS}s{suffix}"
                ) from exc
            if _json_rpc_response_id(payload) != message_id:
                continue
            if "error" in payload:
                raise RuntimeError(str(payload["error"]))
            result = payload.get("result")
            if not isinstance(result, dict):
                raise RuntimeError(f"Codex app-server request '{method}' returned a non-object result")
            return result

    def wait_for_notification(self) -> dict[str, Any]:
        try:
            payload = self._notifications.get(timeout=_NOTIFICATION_TIMEOUT_SECONDS)
        except queue.Empty as exc:
            process_state = self._process.poll()
            last_seen = _payload_summary(self._last_notification) if self._last_notification is not None else "none"
            suffix = f"; process exited with code {process_state}" if process_state is not None else ""
            raise RuntimeError(
                "Timed out waiting for Codex app-server notification "
                f"after {_NOTIFICATION_TIMEOUT_SECONDS}s; last notification={last_seen}{suffix}"
            ) from exc
        self._last_notification = payload
        return payload

    def close(self) -> int:
        if self._process.stdin is not None and not self._process.stdin.closed:
            self._process.stdin.close()
        return self._process.wait()


@dataclass
class CodexAppServerResult:
    exit_code: int
    output: str
    transport_exit_code: int


class CodexAppServerHandle:
    def __init__(self, process: subprocess.Popen[str], request: Any) -> None:
        self._process = process
        self._request = request
        self._logged_tool_item_ids: set[str] = set()
        self.pid: int | None = process.pid
        self.process_group_id: int | None = (
            os.getpgid(process.pid) if process.pid is not None and hasattr(os, "getpgid") else None
        )

    def _log_notification(self, payload: dict[str, Any]) -> None:
        tool_item_id = _tool_item_id(payload)
        for event in notification_to_events(payload):
            if event.kind == "completed" and event.status == "success":
                continue
            if event.kind == "tool_call" and tool_item_id is not None:
                if tool_item_id in self._logged_tool_item_ids:
                    continue
                self._logged_tool_item_ids.add(tool_item_id)
            rendered = render_canonical_event(event)
            if rendered:
                self._request.logger.log_to_stderr(f"[{self._request.stage_name}][codex] {rendered}")

    async def _await_thread_started(self, transport: _CodexAppServerTransport) -> str:
        while True:
            payload = transport.wait_for_notification()
            self._log_notification(payload)
            method = _json_rpc_notification_method(payload)
            if method != "thread/started":
                continue
            params = payload.get("params")
            thread = params.get("thread") if isinstance(params, dict) else None
            thread_id = thread.get("id") if isinstance(thread, dict) else None
            if isinstance(thread_id, str) and thread_id.strip():
                return thread_id
            raise RuntimeError("Codex app-server emitted thread/started without a thread id")

    async def _run_turn(self, transport: _CodexAppServerTransport, *, session_id: str, prompt: str) -> str:
        active_message_id: str | None = None
        active_message_phase = ""
        streamed_reply_parts: list[str] = []
        completed_reply_text = ""
        idle_deadline = asyncio.get_running_loop().time() + _TURN_IDLE_GRACE_SECONDS
        warned_about_idle = False

        transport.request(
            "turn/start",
            {
                "threadId": session_id,
                "input": _text_input(prompt),
                "cwd": str(Path.cwd().resolve()),
                "approvalPolicy": "never",
            },
        )
        while True:
            try:
                payload = transport.wait_for_notification()
            except RuntimeError as exc:
                if transport.process_exit_code is None and asyncio.get_running_loop().time() < idle_deadline:
                    if not warned_about_idle:
                        self._request.logger.log_to_stderr(
                            f"[{self._request.stage_name}][codex] app-server is still active after {_NOTIFICATION_TIMEOUT_SECONDS}s without notifications; waiting longer before failing",
                            "warning",
                        )
                        warned_about_idle = True
                    continue
                if completed_reply_text and transport.process_exit_code == 0:
                    self._request.logger.log_to_stderr(
                        f"[{self._request.stage_name}][codex] app-server exited after assistant completion without turn/completed; using completed reply",
                        "warning",
                    )
                    return completed_reply_text
                streamed_reply = "".join(streamed_reply_parts).strip()
                if streamed_reply and transport.process_exit_code == 0:
                    self._request.logger.log_to_stderr(
                        f"[{self._request.stage_name}][codex] app-server exited after streaming assistant reply without turn/completed; using streamed reply",
                        "warning",
                    )
                    return streamed_reply
                raise exc
            self._log_notification(payload)
            idle_deadline = asyncio.get_running_loop().time() + _TURN_IDLE_GRACE_SECONDS
            warned_about_idle = False
            method = _json_rpc_notification_method(payload)
            params = payload.get("params")
            if method == "item/started" and isinstance(params, dict):
                item = params.get("item")
                if isinstance(item, dict) and item.get("type") == "agentMessage":
                    item_id = item.get("id")
                    if isinstance(item_id, str) and item_id.strip():
                        active_message_id = item_id
                        phase = item.get("phase")
                        active_message_phase = phase.strip() if isinstance(phase, str) else ""
                        streamed_reply_parts = []
            if method == "item/agentMessage/delta" and isinstance(params, dict):
                item_id = params.get("itemId")
                delta = params.get("delta")
                if (
                    isinstance(item_id, str)
                    and item_id.strip()
                    and isinstance(delta, str)
                    and delta
                ):
                    if active_message_id is None:
                        active_message_id = item_id
                    if item_id != active_message_id:
                        active_message_id = item_id
                        streamed_reply_parts = []
                    streamed_reply_parts.append(delta)
                continue
            if method == "item/completed" and isinstance(params, dict):
                item = params.get("item")
                if isinstance(item, dict) and item.get("type") == "agentMessage":
                    phase = item.get("phase")
                    phase_name = phase.strip() if isinstance(phase, str) else ""
                    item_id = item.get("id")
                    if isinstance(item_id, str) and item_id.strip():
                        active_message_id = item_id
                    if phase_name:
                        active_message_phase = phase_name
                    text = item.get("text")
                    if isinstance(text, str) and text.strip() and phase_name != "commentary":
                        completed_reply_text = text.strip()
                    streamed_reply = "".join(streamed_reply_parts).strip()
                    if (
                        not completed_reply_text
                        and streamed_reply
                        and active_message_phase != "commentary"
                        and transport.process_exit_code == 0
                    ):
                        self._request.logger.log_to_stderr(
                            f"[{self._request.stage_name}][codex] app-server completed assistant message without turn/completed; using streamed reply",
                            "warning",
                        )
                        return streamed_reply
            if method != "turn/completed":
                continue
            if not isinstance(params, dict):
                continue
            if params.get("threadId") != session_id:
                continue
            reply_text = _extract_reply_text(params)
            if not reply_text:
                if completed_reply_text:
                    self._request.logger.log_to_stderr(
                        f"[{self._request.stage_name}][codex] turn completed without embedded reply; using assistant message collected earlier",
                        "warning",
                    )
                    return completed_reply_text
                streamed_reply = "".join(streamed_reply_parts).strip()
                if streamed_reply and active_message_phase != "commentary":
                    self._request.logger.log_to_stderr(
                        f"[{self._request.stage_name}][codex] turn completed without embedded reply; using assistant message collected earlier",
                        "warning",
                    )
                    return streamed_reply
                raise RuntimeError("Codex app-server completed a turn without a final assistant reply")
            return reply_text

    async def _run(self) -> CodexAppServerResult:
        transport = _CodexAppServerTransport(self._process, self._request)
        transport.request(
            "initialize",
            {
                "clientInfo": {
                    "name": "cybervisor",
                    "version": "1",
                }
            },
        )
        thread_response = transport.request(
            "thread/start",
            {
                "cwd": str(Path.cwd().resolve()),
                "approvalPolicy": "never",
                "sandbox": "workspace-write",
            },
        )
        thread = thread_response.get("thread")
        if not isinstance(thread, dict):
            raise RuntimeError("Codex app-server missing thread object from thread/start")
        session_id = thread.get("id")
        if not isinstance(session_id, str) or not session_id.strip():
            raise RuntimeError("Codex app-server missing thread id from thread/start")

        started_thread_id = await self._await_thread_started(transport)
        if started_thread_id != session_id:
            raise RuntimeError("Codex app-server thread/start response did not match thread/started notification")

        final_reply = ""
        next_prompt = self._request.prompt
        attempts = 0

        while True:
            from cybervisor.adapters.registry import get_adapter

            attempts += 1
            final_reply = await self._run_turn(transport, session_id=session_id, prompt=next_prompt)
            decision = get_adapter("codex").evaluate_reply(
                _HOOK_CONFIG_PATH.resolve(),
                reply_text=final_reply,
                session_id=session_id,
            )
            if not decision.is_blocking:
                break
            continuation_reason = decision.reason.strip() if decision.reason.strip() else "Continue autonomously."
            self._request.logger.log_to_stderr(
                f"[{self._request.stage_name}][codex] verifier requested continuation ({continuation_reason})"
            )
            next_prompt = continuation_message_for_decision(decision)
            if attempts >= 25:
                raise RuntimeError("Codex app-server exceeded the maximum continuation loops for one stage attempt")

        transport_exit_code = transport.close()
        if transport_exit_code != 0:
            self._request.logger.log_to_stderr(
                f"[{self._request.stage_name}][codex] app-server exited with code {transport_exit_code} after approval; treating the stage as success",
                "warning",
            )
        output = transport.transcript or final_reply
        return CodexAppServerResult(exit_code=0, output=output, transport_exit_code=transport_exit_code)

    def wait(self) -> tuple[int, str]:
        result = asyncio.run(self._run())
        return result.exit_code, result.output
