from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Iterable

from cybervisor.adapters.base import BaseAdapter
from cybervisor.adapters.types import AgentAdapter
from cybervisor.adapters.types import AdapterDescriptor
from cybervisor.adapters.claude import ClaudeAdapter
from cybervisor.adapters.codex import CodexAdapter
from cybervisor.adapters.gemini import GeminiAdapter
from cybervisor.adapters.mock import MockAdapter

_REGISTERED_ADAPTERS: tuple[BaseAdapter, ...] = (
    GeminiAdapter(),
    ClaudeAdapter(),
    CodexAdapter(),
    MockAdapter(),
)


def iter_adapters() -> Iterable[AgentAdapter]:
    return _REGISTERED_ADAPTERS


def adapter_descriptors() -> tuple[AdapterDescriptor, ...]:
    return tuple(adapter.descriptor for adapter in _REGISTERED_ADAPTERS)


def supported_agent_names() -> tuple[str, ...]:
    return tuple(adapter.descriptor.name for adapter in _REGISTERED_ADAPTERS)


def adapter_discovery_metadata() -> tuple[dict[str, object], ...]:
    return tuple(asdict(descriptor) for descriptor in adapter_descriptors())


def validate_adapter(adapter: AgentAdapter) -> None:
    descriptor = adapter.descriptor
    if not descriptor.name.strip():
        raise ValueError("Adapter descriptor name must be non-empty")
    if not descriptor.display_name.strip():
        raise ValueError(f"Adapter '{descriptor.name}' display_name must be non-empty")
    if not Path(descriptor.directory).exists():
        raise ValueError(f"Adapter '{descriptor.name}' directory does not exist: {descriptor.directory}")
    if descriptor.capabilities.supports_hooks and adapter.requires_native_hook_settings() and adapter.settings_path() is None:
        raise ValueError(f"Adapter '{descriptor.name}' supports hooks but does not declare a settings path")

    expected_lifecycle = BaseAdapter.lifecycle_states()
    actual_lifecycle = (
        adapter.lifecycle_status(),
        adapter.running_status(),
        adapter.completed_status(),
        adapter.failed_status(),
    )
    if actual_lifecycle != expected_lifecycle:
        raise ValueError(
            f"Adapter '{descriptor.name}' returned unsupported lifecycle states: {[status.value for status in actual_lifecycle]}"
        )

    if adapter.status() != adapter.lifecycle_status():
        raise ValueError(f"Adapter '{descriptor.name}' status() must match lifecycle_status()")
    if adapter.run() != adapter.running_status():
        raise ValueError(f"Adapter '{descriptor.name}' run() must match running_status()")
    if adapter.complete_status() != adapter.completed_status():
        raise ValueError(f"Adapter '{descriptor.name}' complete_status() must match completed_status()")
    if adapter.fail_status() != adapter.failed_status():
        raise ValueError(f"Adapter '{descriptor.name}' fail_status() must match failed_status()")

    prepared_result = adapter.prepare()
    running_result = adapter.running()
    complete_result = adapter.complete_result(exit_code=0, output="")
    failed_result = adapter.fail_result(exit_code=1)
    if prepared_result.lifecycle != adapter.lifecycle_status() or prepared_result.outcome != adapter.start_outcome():
        raise ValueError(f"Adapter '{descriptor.name}' prepare() must use the prepared lifecycle and started outcome")
    if running_result.lifecycle != adapter.running_status() or running_result.outcome != adapter.start_outcome():
        raise ValueError(f"Adapter '{descriptor.name}' running() must use the running lifecycle and started outcome")
    if complete_result.lifecycle != adapter.completed_status() or complete_result.outcome != adapter.success_outcome():
        raise ValueError(f"Adapter '{descriptor.name}' complete() must use the completed lifecycle and succeeded outcome")
    if failed_result.lifecycle != adapter.failed_status() or failed_result.outcome != adapter.failure_outcome():
        raise ValueError(f"Adapter '{descriptor.name}' fail() must use the failed lifecycle and failed outcome")

    if adapter.run_result(0, "").lifecycle != adapter.completed_status():
        raise ValueError(f"Adapter '{descriptor.name}' run_result() must map exit code 0 to completed")
    if adapter.run_result(1, "").lifecycle != adapter.failed_status():
        raise ValueError(f"Adapter '{descriptor.name}' run_result() must map non-zero exit codes to failed")

    if adapter.lifecycle_from_exit_code(0) != adapter.completed_status():
        raise ValueError(f"Adapter '{descriptor.name}' lifecycle_from_exit_code() must map 0 to completed")
    if adapter.lifecycle_from_exit_code(1) != adapter.failed_status():
        raise ValueError(f"Adapter '{descriptor.name}' lifecycle_from_exit_code() must map non-zero to failed")
    if adapter.outcome_from_exit_code(0) != adapter.success_outcome():
        raise ValueError(f"Adapter '{descriptor.name}' outcome_from_exit_code() must map 0 to succeeded")
    if adapter.outcome_from_exit_code(1) != adapter.failure_outcome():
        raise ValueError(f"Adapter '{descriptor.name}' outcome_from_exit_code() must map non-zero to failed")

    expected_outcomes = BaseAdapter.normalized_outcomes()
    actual_outcomes = (
        adapter.start_outcome(),
        adapter.success_outcome(),
        adapter.failure_outcome(),
    )
    if actual_outcomes != expected_outcomes:
        raise ValueError(
            f"Adapter '{descriptor.name}' returned unsupported normalized outcomes: {[outcome.value for outcome in actual_outcomes]}"
        )

    required_methods = (
        "start",
        "parse_output_line",
        "flush_pending_events",
        "should_suppress_event",
        "preflight_requirements",
    )
    missing = [name for name in required_methods if getattr(type(adapter), name, None) is getattr(BaseAdapter, name, None)]
    if missing:
        raise ValueError(f"Adapter '{descriptor.name}' is missing required contract overrides: {', '.join(missing)}")
    if descriptor.capabilities.supports_hooks:
        if adapter.requires_native_hook_settings():
            for method_name in ("install_hook_settings", "remove_hook_settings", "settings_path"):
                if getattr(type(adapter), method_name, None) is getattr(BaseAdapter, method_name, None):
                    raise ValueError(f"Adapter '{descriptor.name}' supports hooks but does not override {method_name}")
        else:
            if getattr(type(adapter), "evaluate_reply", None) is getattr(BaseAdapter, "evaluate_reply", None):
                raise ValueError(
                    f"Adapter '{descriptor.name}' supports hooks without native hook settings but does not override evaluate_reply"
                )
    if not isinstance(adapter, AgentAdapter):
        raise ValueError(f"Adapter '{descriptor.name}' does not satisfy the shared adapter contract")

    preflight = adapter.preflight_requirements()
    if preflight is None:
        raise ValueError(f"Adapter '{descriptor.name}' must declare preflight requirements")

    if adapter.descriptor.capabilities.supports_structured_streams and not adapter.parse_output_line("") == []:
        raise ValueError(f"Adapter '{descriptor.name}' must ignore empty output lines")


def get_adapter(name: str) -> AgentAdapter:
    normalized = name.strip().lower()
    for adapter in _REGISTERED_ADAPTERS:
        if adapter.descriptor.name == normalized:
            validate_adapter(adapter)
            return adapter
    supported = ", ".join(sorted(supported_agent_names()))
    raise ValueError(f"Unsupported agent_tool: {name}. Supported values: {supported}")
