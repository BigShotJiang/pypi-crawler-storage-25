from __future__ import annotations

import asyncio
import signal
from typing import Callable

from cybervisor.logging import CybervisorLogger
from cybervisor.signals import SignalHandler


class ServerSignalHandler:
    """Async-aware signal handler that bridges SIGINT delivery to the PipelineRunner."""

    def __init__(self, signal_handler: SignalHandler) -> None:
        self._signal_handler = signal_handler
        self._cancel_event: asyncio.Event | None = None
        self._loop: asyncio.AbstractEventLoop | None = None

    def set_cancel_event(self, event: asyncio.Event) -> None:
        self._cancel_event = event
        self._loop = asyncio.get_running_loop()

    async def deliver_signal(self, signum: int = signal.SIGINT) -> None:
        """Deliver a signal to the active subprocess managed by the underlying SignalHandler.

        Waits up to 2 seconds for subprocess termination before returning.
        For mock cases (no subprocess), _terminate_active_process sets cancel_event
        immediately when it detects pid is None.
        """
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            None,
            self._signal_handler._terminate_active_process,
            signum,
            self._cancel_event,
        )

    async def wait_for_cancel(self) -> None:
        """Wait indefinitely for a cancel request until set."""
        if self._cancel_event is None:
            return
        await self._cancel_event.wait()

    def is_cancelled(self) -> bool:
        return self._cancel_event is not None and self._cancel_event.is_set()
