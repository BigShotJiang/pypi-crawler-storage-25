from __future__ import annotations

# YAML configuration support requires PyYAML.
from dataclasses import dataclass, field
from pathlib import Path
import re
from typing import Any, Literal

import yaml
from cybervisor.adapters.registry import supported_agent_names
from cybervisor.global_config import GlobalConfigError, load_global_config

AgentToolType = Literal["gemini", "claude", "mock"]

DEFAULT_ENDPOINT = "https://api.openai.com/v1"
DEFAULT_MODEL = "auto"
DEFAULT_STAGE_NAMES = ["Spec", "Review Spec", "Implement", "Review Code", "Verify"]
DEFAULT_TEMPLATE = "Execute stage '{stage_name}' for objective: {objective}"
DEFAULT_ALLOWED_STATUSES = ["approved", "changes_requested"]
CONTRACT_ROOT = Path(".cybervisor/contracts")
CONTRACT_ARTIFACTS_DIR = CONTRACT_ROOT / "artifacts"
CONTRACT_PROMPTS_DIR = CONTRACT_ROOT / "prompts"


@dataclass(slots=True)
class StageConfig:
    name: str
    prompt_template: str = DEFAULT_TEMPLATE
    has_authored_prompt_template: bool = False
    max_retries: int = 3
    next_stage: str | None = None
    contract: "StageContractConfig | None" = None
    keep_artifacts: list[str] = field(default_factory=list)
    backup_artifacts: list[str] = field(default_factory=list)


@dataclass(slots=True)
class StageRouteConfig:
    next_stage: str | None = None
    injections: list[str] = field(default_factory=list)
    description: str | None = None


@dataclass(slots=True)
class StageContractConfig:
    allowed_statuses: list[str] = field(default_factory=lambda: list(DEFAULT_ALLOWED_STATUSES))
    routes: dict[str, StageRouteConfig] = field(default_factory=dict)
    field_descriptions: dict[str, str] = field(default_factory=dict)
    field_examples: dict[str, list[str]] = field(default_factory=dict)


@dataclass(slots=True)
class HookConfig:
    api_endpoint: str = DEFAULT_ENDPOINT
    api_key: str = ""
    model: str = DEFAULT_MODEL


@dataclass(slots=True)
class PipelineConfig:
    hook: HookConfig = field(default_factory=HookConfig)
    stages: list[StageConfig] = field(default_factory=lambda: [StageConfig(name=n) for n in DEFAULT_STAGE_NAMES])


@dataclass(frozen=True, slots=True)
class ValidationIssue:
    category: str
    message: str
    remediation: str
    stage_name: str | None = None
    status: str | None = None
    field_name: str | None = None


class StrictValidationError(ValueError):
    def __init__(self, path: Path, issues: list[ValidationIssue]) -> None:
        self.path = path
        self.issues = issues
        super().__init__(self._build_message())

    def _build_message(self) -> str:
        return "\n".join(format_validation_issue(issue) for issue in self.issues)


def contract_artifact_path(stage_name: str) -> Path:
    return CONTRACT_ARTIFACTS_DIR / f"{stage_name}.yaml"


def contract_prompt_path(stage_name: str) -> Path:
    return CONTRACT_PROMPTS_DIR / f"{stage_name}.md"


def _display_field_name(field_name: str) -> str:
    if field_name == "status":
        return "Status"
    return field_name.replace("_", " ").title()


def _contract_field_names_by_status(contract: StageContractConfig) -> dict[str, list[str]]:
    return {status: list(route.injections) for status, route in contract.routes.items()}


def _contract_field_names(contract: StageContractConfig) -> list[str]:
    field_names: list[str] = []
    seen_fields: set[str] = set()
    for route_field_names in _contract_field_names_by_status(contract).values():
        for field_name in route_field_names:
            if field_name in seen_fields:
                continue
            seen_fields.add(field_name)
            field_names.append(field_name)
    return field_names


def _field_example_lines(contract: StageContractConfig, field_name: str) -> list[str]:
    examples = contract.field_examples.get(field_name, [])
    if examples:
        return str(examples[0]).splitlines()
    description = contract.field_descriptions.get(field_name, f"Provide {field_name}.")
    return str(description).splitlines()


def format_validation_issue(issue: ValidationIssue) -> str:
    context_parts: list[str] = []
    if issue.stage_name is not None:
        context_parts.append(f"stage={issue.stage_name}")
    if issue.status is not None:
        context_parts.append(f"status={issue.status}")
    if issue.field_name is not None:
        context_parts.append(f"field={issue.field_name}")
    prefix = f"[{'; '.join(context_parts)}] " if context_parts else ""
    return f"{prefix}{issue.message} Remediation: {issue.remediation}"


def _prompt_allows_direct_canonical_artifact_edits(prompt_template: str) -> bool:
    prompt_text = prompt_template.lower()
    direct_edit_targets = (
        "the canonical artifact",
        "the canonical on-disk artifact",
        "the current artifact",
        "the current canonical artifact",
        "the current canonical on-disk artifact",
        "the canonical spec files",
        "the canonical plan files",
        "the canonical task files",
        ".cybervisor/artifacts/spec.md",
        ".cybervisor/artifacts/plan.md",
        ".cybervisor/artifacts/tasks.md",
    )
    for target in direct_edit_targets:
        escaped_target = re.escape(target)
        if re.search(rf"\bedit\b[\s\S]*?{escaped_target}[\s\S]*?\bdirectly\b", prompt_text):
            return True
        if re.search(rf"\bdirectly\b[\s\S]*?\bedit\b[\s\S]*?{escaped_target}", prompt_text):
            return True
    return False


def _prompt_mentions_route_status(prompt_template: str, status: str) -> bool:
    token_pattern = rf"(?<![A-Za-z0-9_]){re.escape(status)}(?![A-Za-z0-9_])"
    return re.search(token_pattern, prompt_template) is not None


def _is_documented_self_refining_review_route(stage: StageConfig, status: str, route: StageRouteConfig) -> bool:
    if route.next_stage != stage.name:
        return False
    if status != "NEEDS_REFINEMENT":
        return False
    return stage.name in {"Review Spec", "Review Plan", "Review Tasks"}


def render_contract_guidance(stage_name: str, contract: StageContractConfig) -> str:
    artifact_path = contract_artifact_path(stage_name)
    field_names_by_status = _contract_field_names_by_status(contract)
    field_names = _contract_field_names(contract)

    lines = [f"Write `{artifact_path}` as YAML that matches the selected `Status` route exactly."]

    if field_names:
        lines.extend(["", "Field descriptions:"])
        for field_name in field_names:
            description = contract.field_descriptions.get(field_name)
            if description:
                lines.append(f"- `{field_name}`: {description}")

    lines.extend(["", "Full examples:"])
    for status, route in contract.routes.items():
        route_field_names = field_names_by_status[status]
        lines.extend(
            [
                "",
                f"If `Status` is `{status}`, a complete example looks like:",
                "",
                "```yaml",
                f"{_display_field_name('status')}: {status}",
            ]
        )
        if route_field_names:
            for field_name in route_field_names:
                lines.append(f"{_display_field_name(field_name)}: |")
                for line in _field_example_lines(contract, field_name):
                    lines.append(f"  {line}")
        lines.append("```")

    lines.extend(["", "Instructions:"])
    lines.append(f"- `Status` must be one of: {', '.join(contract.allowed_statuses)}")
    for status, route in contract.routes.items():
        route_field_names = field_names_by_status[status]
        if route_field_names:
            rendered_fields = ", ".join(route_field_names)
            lines.append(f"- if `Status` is `{status}`, provide non-empty strings only for: {rendered_fields}")
        else:
            lines.append(f"- if `Status` is `{status}`, do not add any injected fields beyond `Status`")
        if route.description:
            lines.append(f"- `{status}`: {route.description}")
        if route.next_stage is not None:
            lines.append(f"- `{status}` routes to `{route.next_stage}`")
    lines.append("- do not include fields from another route")
    lines.append("- this stage must write valid YAML and keep any required injected fields concise and actionable")
    return "\n".join(lines) + "\n"


def _validate_agent_tool(value: str) -> AgentToolType:
    normalized = value.strip().lower()
    supported = supported_agent_names()
    if normalized not in supported:
        raise ValueError(f"Unsupported agent_tool: {value}. Supported values: {', '.join(sorted(supported))}")
    return normalized  # type: ignore[return-value]


def _validate_injection_name(stage_name: str, status: str, raw_value: object) -> str:
    section = str(raw_value).strip()
    if not section:
        raise ValueError(f"Stage '{stage_name}' contract route '{status}' injections must not contain empty values")
    if section == "status":
        raise ValueError(f"Stage '{stage_name}' contract route '{status}' injections must not include reserved field 'status'")
    return section


def _validate_route_description(stage_name: str, status: str, raw_value: object) -> str:
    description = str(raw_value).strip()
    if not description:
        raise ValueError(f"Stage '{stage_name}' contract route '{status}' description must be a non-empty string")
    return description


def _validate_field_description_name(stage_name: str, raw_name: object, *, context: str) -> str:
    field_name = str(raw_name).strip()
    if not field_name:
        raise ValueError(f"Stage '{stage_name}' {context} must not contain empty field names")
    if field_name == "status":
        raise ValueError(f"Stage '{stage_name}' {context} must not include reserved field 'status'")
    return field_name


def _validate_field_description_text(stage_name: str, field_name: str, raw_description: object) -> str:
    description = str(raw_description).strip()
    if not description:
        raise ValueError(
            f"Stage '{stage_name}' contract field description for '{field_name}' must be a non-empty string"
        )
    return description


def _load_field_descriptions(stage_name: str, raw_mapping: object, *, context: str) -> dict[str, str]:
    if raw_mapping is None:
        return {}
    if not isinstance(raw_mapping, dict):
        raise ValueError(f"Stage '{stage_name}' {context} must be a mapping")
    field_descriptions: dict[str, str] = {}
    for raw_field_name, raw_description in raw_mapping.items():
        field_name = _validate_field_description_name(stage_name, raw_field_name, context=context)
        field_descriptions[field_name] = _validate_field_description_text(stage_name, field_name, raw_description)
    return field_descriptions


def _load_field_definitions(
    stage_name: str,
    raw_mapping: object,
    *,
    context: str,
) -> tuple[dict[str, str], dict[str, list[str]]]:
    if raw_mapping is None:
        return {}, {}
    if not isinstance(raw_mapping, dict):
        raise ValueError(f"Stage '{stage_name}' {context} must be a mapping")

    descriptions: dict[str, str] = {}
    examples: dict[str, list[str]] = {}
    for raw_field_name, raw_definition in raw_mapping.items():
        field_name = _validate_field_description_name(stage_name, raw_field_name, context=context)
        if isinstance(raw_definition, str):
            descriptions[field_name] = _validate_field_description_text(stage_name, field_name, raw_definition)
            continue
        if not isinstance(raw_definition, dict):
            raise ValueError(f"Stage '{stage_name}' {context} entry for '{field_name}' must be a mapping or string")
        description = _validate_field_description_text(stage_name, field_name, raw_definition.get("description", ""))
        descriptions[field_name] = description
        example_values: list[str] = []
        single_example = raw_definition.get("example")
        if single_example is not None:
            rendered = str(single_example).strip()
            if rendered:
                example_values.append(rendered)
        raw_examples = raw_definition.get("examples", [])
        if raw_examples:
            if not isinstance(raw_examples, list):
                raise ValueError(f"Stage '{stage_name}' {context} entry for '{field_name}' examples must be a list")
            for raw_example in raw_examples:
                rendered = str(raw_example).strip()
                if rendered:
                    example_values.append(rendered)
        if example_values:
            examples[field_name] = example_values
    return descriptions, examples


def _load_hook_config_from_global_config() -> HookConfig:
    try:
        global_config = load_global_config()
    except GlobalConfigError as exc:
        raise ValueError(str(exc)) from exc
    return HookConfig(
        api_endpoint=global_config.llm.base_url,
        api_key=global_config.llm.api_key,
        model=global_config.llm.model,
    )


def _validate_hook_config_is_env_only(raw_hook: dict[str, Any]) -> None:
    forbidden = {"api_endpoint", "api_key", "model"}
    present = forbidden.intersection(raw_hook.keys())
    if present:
        keys = ", ".join(sorted(present))
        raise ValueError(f"'hook' must not set {keys}; use ~/.cybervisor/config.yaml instead")


STAGE_KNOWN_FIELDS = frozenset({"name", "prompt_template", "max_retries", "next_stage", "contract", "keep_artifacts", "backup_artifacts"})


def _load_backup_artifacts(stage_name: str, raw_list: object) -> list[str]:
    """Parse and validate backup_artifacts entries from a stage config dict."""
    if raw_list is None:
        return []
    if not isinstance(raw_list, list):
        raise ValueError(f"Stage '{stage_name}' backup_artifacts must be a list")
    seen: set[str] = set()
    result: list[str] = []
    for entry in raw_list:
        if not isinstance(entry, str):
            raise ValueError(f"Stage '{stage_name}' backup_artifacts entries must be strings, got {type(entry).__name__}")
        if not entry:
            raise ValueError(f"Stage '{stage_name}' backup_artifacts entries must not be empty strings")
        if entry not in seen:
            seen.add(entry)
            result.append(entry)
    return result


def _load_stage(stage_raw: dict[str, Any]) -> StageConfig:
    name = str(stage_raw.get("name", "")).strip()
    if not name:
        raise ValueError("Each stage must have a non-empty name")
    unknown_fields = set(stage_raw.keys()) - STAGE_KNOWN_FIELDS
    if unknown_fields:
        raise ValueError(
            f"Stage '{name}' contains unknown field(s): {', '.join(sorted(unknown_fields))}. "
            "Run 'cybervisor docs cybervisor.yaml' for configuration guidelines."
        )
    has_authored_prompt_template = "prompt_template" in stage_raw and stage_raw.get("prompt_template") is not None
    prompt_template = str(stage_raw.get("prompt_template") or DEFAULT_TEMPLATE)
    max_retries = int(stage_raw.get("max_retries", 3))
    if max_retries < 1:
        raise ValueError("max_retries must be >= 1")
    next_stage_raw = stage_raw.get("next_stage")
    next_stage = str(next_stage_raw).strip() if next_stage_raw is not None else None
    if next_stage == "":
        next_stage = None
    contract_raw = stage_raw.get("contract")
    contract: StageContractConfig | None = None
    if contract_raw is not None:
        if next_stage is not None:
            raise ValueError(
                f"Stage '{name}' must not define next_stage when contract routing is enabled; move success routing into contract.routes.approved"
            )
        if not isinstance(contract_raw, dict):
            raise ValueError(f"Stage '{name}' contract must be a mapping")
        contract = _load_stage_contract(name, contract_raw)
    keep_artifacts_raw = stage_raw.get("keep_artifacts")
    keep_artifacts: list[str] = []
    if keep_artifacts_raw is not None:
        if not isinstance(keep_artifacts_raw, list):
            raise ValueError(f"Stage '{name}' keep_artifacts must be a list")
        seen: set[str] = set()
        for entry in keep_artifacts_raw:
            if not isinstance(entry, str):
                raise ValueError(f"Stage '{name}' keep_artifacts entries must be strings, got {type(entry).__name__}")
            if not entry:
                raise ValueError(f"Stage '{name}' keep_artifacts entries must not be empty strings")
            if entry not in seen:
                seen.add(entry)
                keep_artifacts.append(entry)
    backup_artifacts_raw = stage_raw.get("backup_artifacts")
    backup_artifacts: list[str] = _load_backup_artifacts(name, backup_artifacts_raw)
    return StageConfig(
        name=name,
        prompt_template=prompt_template,
        has_authored_prompt_template=has_authored_prompt_template,
        max_retries=max_retries,
        next_stage=next_stage,
        contract=contract,
        keep_artifacts=keep_artifacts,
        backup_artifacts=backup_artifacts,
    )


def _load_stage_contract(stage_name: str, contract_raw: dict[str, Any]) -> StageContractConfig:
    removed_fields = {"allowed_statuses", "artifact_path", "artifact_kind", "input_bindings", "prompt_file"}
    present_removed_fields = sorted(removed_fields.intersection(contract_raw))
    if present_removed_fields:
        keys = ", ".join(present_removed_fields)
        raise ValueError(
            f"Stage '{stage_name}' contract no longer supports {keys}; use fixed .cybervisor/contracts paths instead"
        )

    field_descriptions = _load_field_descriptions(stage_name, contract_raw.get("field_descriptions", {}), context="contract field_descriptions")
    field_examples: dict[str, list[str]] = {}
    contract_fields_descriptions, contract_fields_examples = _load_field_definitions(
        stage_name,
        contract_raw.get("fields", {}),
        context="contract fields",
    )
    field_descriptions.update(contract_fields_descriptions)
    field_examples.update(contract_fields_examples)
    richer_contract_descriptions, richer_contract_examples = _load_field_definitions(
        stage_name,
        contract_raw.get("field_definitions", {}),
        context="contract field_definitions",
    )
    field_descriptions.update(richer_contract_descriptions)
    field_examples.update(richer_contract_examples)

    routes_raw = contract_raw.get("routes", {})
    if not isinstance(routes_raw, dict):
        raise ValueError(f"Stage '{stage_name}' contract routes must be a mapping")
    routes: dict[str, StageRouteConfig] = {}
    for raw_status, raw_route in routes_raw.items():
        status = str(raw_status).strip()
        if not status:
            raise ValueError(f"Stage '{stage_name}' contract routes must use non-empty status keys")
        if raw_route is None:
            raw_route = {}
        if not isinstance(raw_route, dict):
            raise ValueError(
                f"Stage '{stage_name}' contract route '{status}' must be a mapping with next_stage and injections"
            )
        next_stage_raw = raw_route.get("next_stage")
        target = str(next_stage_raw).strip() if next_stage_raw is not None else None
        if target == "":
            target = None
        description_raw = raw_route.get("description")
        description = None
        if description_raw is not None:
            description = _validate_route_description(stage_name, status, description_raw)
        injections_raw = raw_route.get("injections", [])
        if not isinstance(injections_raw, list):
            raise ValueError(f"Stage '{stage_name}' contract route '{status}' injections must be a list")
        injections: list[str] = []
        for raw_section in injections_raw:
            section = _validate_injection_name(stage_name, status, raw_section)
            if section not in injections:
                injections.append(section)
            if section not in field_descriptions:
                raise ValueError(
                    f"Stage '{stage_name}' contract route '{status}' injects '{section}' without a field description"
                )
        routes[status] = StageRouteConfig(
            next_stage=target,
            injections=injections,
            description=description,
        )

    allowed_statuses = list(routes)
    return StageContractConfig(
        allowed_statuses=allowed_statuses,
        routes=routes,
        field_descriptions=field_descriptions,
        field_examples=field_examples,
    )


def _validate_stage_definitions(stages: list[StageConfig]) -> None:
    stage_names: list[str] = [stage.name for stage in stages]
    unique_names = set(stage_names)
    if len(unique_names) != len(stage_names):
        raise ValueError("Stage names must be unique when loading configuration")

    for stage in stages:
        if stage.next_stage is not None and stage.next_stage not in unique_names:
            raise ValueError(
                f"Stage '{stage.name}' next_stage target '{stage.next_stage}' does not match any configured stage"
            )
        contract = stage.contract
        if contract is None:
            continue
        if not contract.routes:
            raise ValueError(
                f"Stage '{stage.name}' contract must define explicit routes; add contract.routes.approved to advance on approval"
            )
        for route in contract.routes.values():
            if route.next_stage is not None and route.next_stage not in unique_names:
                raise ValueError(
                    f"Stage '{stage.name}' contract route target '{route.next_stage}' does not match any configured stage"
                )


def _load_raw_config(config_path: Path) -> dict[str, Any]:
    suffix = config_path.suffix.lower()

    if suffix in {".yaml", ".yml"}:
        loaded = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        if loaded is None:
            return {}
        if not isinstance(loaded, dict):
            raise ValueError("Configuration file root must be a YAML mapping")
        if not all(isinstance(k, str) for k in loaded.keys()):
            raise ValueError("Configuration file mapping keys must be strings")
        return dict(loaded)

    raise ValueError(f"Unsupported config file type: {config_path.suffix} (expected .yaml/.yml)")


def resolve_config_path(path: str | Path) -> Path:
    config_path = Path(path)
    if config_path.exists():
        return config_path
    if config_path.suffix == "":
        for ext in (".yaml", ".yml"):
            candidate = config_path.with_suffix(ext)
            if candidate.exists():
                return candidate
    return config_path


def collect_strict_validation_issues(*, config_path: Path, config: PipelineConfig) -> list[ValidationIssue]:
    del config_path
    issues: list[ValidationIssue] = []
    for stage in config.stages:
        contract = stage.contract
        if contract is None:
            continue

        configured_statuses = set(contract.routes)
        field_names_by_status = _contract_field_names_by_status(contract)
        configured_field_names = set(_contract_field_names(contract))
        if stage.has_authored_prompt_template:
            for status in contract.routes:
                if not _prompt_mentions_route_status(stage.prompt_template, status):
                    issues.append(
                        ValidationIssue(
                            category="guidance_sync",
                            stage_name=stage.name,
                            status=status,
                            message=f"prompt_template must mention route status `{status}`.",
                            remediation="Update the stage prompt so it names every configured route status literally.",
                        )
                    )
                status_line_pattern = rf"^[^\n]*?(?<![A-Za-z0-9_]){re.escape(status)}(?![A-Za-z0-9_])[^\n]*$"
                status_section_match = re.search(status_line_pattern, stage.prompt_template, re.MULTILINE)
                if status_section_match is None:
                    continue
                status_section = status_section_match.group(0)
                for unrelated_field_name in configured_field_names.difference(field_names_by_status[status]):
                    if _prompt_mentions_route_status(status_section, unrelated_field_name):
                        issues.append(
                            ValidationIssue(
                                category="guidance_sync",
                                stage_name=stage.name,
                                status=status,
                                field_name=unrelated_field_name,
                                message=(
                                    f"prompt_template must not imply unrelated field `{unrelated_field_name}` for route `{status}`."
                                ),
                                remediation=(
                                    "Keep prompt guidance synchronized with routed fields so each status only implies the fields its route injects."
                                ),
                            )
                        )
                        break


        for status, route in contract.routes.items():
            for field_name in route.injections:
                if contract.field_examples.get(field_name):
                    continue
                issues.append(
                    ValidationIssue(
                        category="contract_shape",
                        stage_name=stage.name,
                        status=status,
                        field_name=field_name,
                        message=f"Injected field `{field_name}` needs a configured full example for strict validation.",
                        remediation=(
                            f"Add `contract.fields[{field_name!r}].example` or `examples` so guidance can render "
                            "a complete YAML example."
                        ),
                    )
                )

            if route.description is not None:
                for described_status in configured_statuses:
                    if described_status == status:
                        continue
                    if _prompt_mentions_route_status(route.description, described_status):
                        issues.append(
                            ValidationIssue(
                                category="guidance_sync",
                                stage_name=stage.name,
                                status=status,
                                message=(
                                    f"Route description for `{status}` must not mention unrelated status `{described_status}`."
                                ),
                                remediation=(
                                    "Keep each route description focused on its own status and routing outcome only."
                                ),
                            )
                        )
                for unrelated_field_name in configured_field_names.difference(field_names_by_status[status]):
                    if _prompt_mentions_route_status(route.description, unrelated_field_name):
                        issues.append(
                            ValidationIssue(
                                category="guidance_sync",
                                stage_name=stage.name,
                                status=status,
                                field_name=unrelated_field_name,
                                message=(
                                    f"Route description for `{status}` must not imply unrelated field `{unrelated_field_name}`."
                                ),
                                remediation=(
                                    "Keep each route description aligned with only the fields that route injects and the routing decision it represents."
                                ),
                            )
                        )


            if not _is_documented_self_refining_review_route(stage, status, route):
                continue
            if _prompt_allows_direct_canonical_artifact_edits(stage.prompt_template):
                continue
            issues.append(
                ValidationIssue(
                    category="route_safety",
                    stage_name=stage.name,
                    status=status,
                    message="Self-refining review routes must explicitly allow direct edits to the canonical artifact.",
                    remediation=(
                        "Update the stage prompt to say the stage may edit the current canonical artifact directly "
                        "before it emits the contract result."
                    ),
                )
            )
    return issues


def validate_config_file(path: str | Path) -> tuple[Path, PipelineConfig]:
    config_path = resolve_config_path(path)
    config = load_config(config_path)
    for stage in config.stages:
        if stage.contract is None:
            continue
        render_contract_guidance(stage.name, stage.contract)
    issues = collect_strict_validation_issues(config_path=config_path, config=config)
    if issues:
        raise StrictValidationError(config_path, issues)
    return config_path, config


def validate_prompt_templates(config: PipelineConfig) -> list[str]:
    """
    Return stage names that still require an external objective.

    Stages are self-contained only when they have an authored prompt template
    that does not depend on the default objective-driven fallback.
    """
    offending: list[str] = []
    for stage in config.stages:
        if stage.has_authored_prompt_template:
            continue
        if "{objective}" in stage.prompt_template:
            offending.append(stage.name)
    return offending


def config_supports_promptless_run(config: PipelineConfig, *, start_stage_name: str | None = None) -> tuple[bool, list[str]]:
    effective_stages = config.stages
    if start_stage_name is not None:
        start_index = next(index for index, stage in enumerate(config.stages) if stage.name == start_stage_name)
        effective_stages = config.stages[start_index:]
    missing_objective_stages = validate_prompt_templates(PipelineConfig(hook=config.hook, stages=effective_stages))
    return not missing_objective_stages, missing_objective_stages


def load_config(path: str | Path) -> PipelineConfig:
    config_path = resolve_config_path(path)

    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    raw = _load_raw_config(config_path)

    pipeline_raw = raw.get("pipeline", {})
    hook_raw = raw.get("hook", {})
    stages_raw = raw.get("stages", [])
    if not isinstance(pipeline_raw, dict):
        raise ValueError("'pipeline' must be a mapping")
    if not isinstance(hook_raw, dict):
        raise ValueError("'hook' must be a mapping")
    if not isinstance(stages_raw, list):
        raise ValueError("'stages' must be a list")

    if "agent_tool" in pipeline_raw:
        raise ValueError(
            "'pipeline.agent_tool' is no longer supported; select an agent locally with `cybervisor use <agent_tool>`"
        )
    _validate_hook_config_is_env_only(hook_raw)
    hook = _load_hook_config_from_global_config()

    if len(stages_raw) == 0:
        pipeline_stages = pipeline_raw.get("stages")
        if pipeline_stages is not None:
            raise ValueError(
                "Stages must be declared at the top-level `stages` key, not under `pipeline.stages`. "
                "Move your stage definitions to the top-level `stages:` list in your cybervisor.yaml."
            )
        stages = [StageConfig(name=n) for n in DEFAULT_STAGE_NAMES]
    else:
        if not all(isinstance(stage, dict) for stage in stages_raw):
            raise ValueError("Each stage must be a mapping")
        stages = [_load_stage(stage) for stage in stages_raw]
    _validate_stage_definitions(stages)

    return PipelineConfig(hook=hook, stages=stages)
