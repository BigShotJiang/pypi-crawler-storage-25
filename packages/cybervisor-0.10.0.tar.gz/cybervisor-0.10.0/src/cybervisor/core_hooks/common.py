from __future__ import annotations

import json
import os
import re
import socket
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, TypeVar
from urllib.parse import urlsplit, urlunsplit

import httpx
import yaml

DEFAULT_ENDPOINT = "https://api.openai.com/v1"
DEFAULT_MODEL = "auto"
HOOK_USER_AGENT = "cybervisor-hook/1"
HOOK_HTTP_TIMEOUT_SECONDS = 120.0
STRUCTURED_RETRY_ATTEMPTS = 5
VERIFIER_REQUEST_RETRY_ATTEMPTS = 3
AUTONOMY_DENY_MESSAGE = "Do not ask the user for input. Continue autonomously with the next concrete step."
TStructured = TypeVar("TStructured")


class VerifierRequestError(Exception):
    pass


class VerifierResponseShapeError(VerifierRequestError):
    pass


class HookDecision:
    __slots__ = ("action", "reason", "system_message")

    def __init__(self, action: str, reason: str, system_message: str | None = None) -> None:
        self.action = action
        self.reason = reason
        self.system_message = system_message

    def as_payload(self) -> dict[str, Any]:
        return {
            "decision": self.action,
            "reason": self.reason,
        }

    def as_hook_output(self, agent_tool: str | None) -> dict[str, Any]:
        if agent_tool != "claude":
            if self.action == "approve":
                return {
                    "decision": "allow",
                    "reason": self.reason,
                }
            payload = {
                "decision": "deny",
                "reason": self.reason,
            }
            payload["systemMessage"] = self.system_message or self.reason or AUTONOMY_DENY_MESSAGE
            return payload
        if self.action == "block":
            stop_reason = self.system_message or self.reason or AUTONOMY_DENY_MESSAGE
            return {
                "decision": "block",
                "reason": stop_reason,
            }
        return {}

    @property
    def is_blocking(self) -> bool:
        return self.action == "block"


def continuation_message_for_decision(decision: HookDecision) -> str:
    if decision.system_message and decision.system_message.strip():
        return decision.system_message.strip()
    if decision.reason and decision.reason.strip():
        return decision.reason.strip()
    return AUTONOMY_DENY_MESSAGE


def contract_blocking_decision(agent_tool: str | None, message: str) -> HookDecision:
    if agent_tool == "claude":
        return HookDecision(action="block", reason=message)
    return HookDecision(action="block", reason="stage_contract_invalid", system_message=message)


def blocking_decision(agent_tool: str | None, reason: str) -> HookDecision:
    if agent_tool == "claude":
        return HookDecision(action="block", reason=AUTONOMY_DENY_MESSAGE)
    return HookDecision(action="block", reason=reason, system_message=AUTONOMY_DENY_MESSAGE)


def utc_now() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def load_hook_runtime_config(config_path: Path) -> dict[str, Any]:
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    content = config_path.read_text(encoding="utf-8").strip()
    if not content:
        return {}

    raw = json.loads(content)
    if not isinstance(raw, dict):
        raise ValueError("Configuration file root must be a JSON object")
    return raw


def json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def append_hook_event(log_path: Path, payload: dict[str, Any]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(payload, default=json_default) + "\n")


def send_hook_event(socket_path: str | None, payload: dict[str, Any]) -> None:
    if not socket_path:
        return
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.settimeout(0.2)
            client.connect(socket_path)
            client.sendall((json.dumps(payload, default=json_default) + "\n").encode("utf-8"))
    except OSError:
        return


def socket_path_from_config(config_path: Path) -> str | None:
    try:
        raw_socket_path = load_hook_runtime_config(config_path).get("socket_path")
    except FileNotFoundError:
        return None
    return raw_socket_path if isinstance(raw_socket_path, str) and raw_socket_path else None


def log_hook_event(
    log_path: Path,
    event: str,
    message: str,
    *,
    agent_tool: str | None,
    config_path: Path,
    hook_input: str | None = None,
    verifier_output: str | None = None,
    decision: dict[str, Any] | None = None,
    error: str | None = None,
    session_id: str | None = None,
    notify_listener: bool = True,
) -> None:
    payload: dict[str, Any] = {
        "timestamp": utc_now(),
        "event": event,
        "message": message,
        "agent_tool": agent_tool,
        "pid": os.getpid(),
        "config_path": str(config_path.resolve()),
    }
    if hook_input is not None:
        payload["hook_input"] = hook_input
    if verifier_output is not None:
        payload["verifier_output"] = verifier_output
    if decision is not None:
        payload["decision"] = decision
    if error is not None:
        payload["error"] = error
    if session_id is not None:
        payload["session_id"] = session_id
    append_hook_event(log_path, payload)
    if notify_listener:
        send_hook_event(socket_path_from_config(config_path), payload)


def hook_log_path(config_path: Path) -> Path:
    resolved_config = config_path.resolve()
    if resolved_config.parent.name == "hooks" and resolved_config.parent.parent.name == ".cybervisor":
        return resolved_config.parent.parent / "logs" / "hook-events.jsonl"
    return resolved_config.parent / "logs" / "hook-events.jsonl"


def resolve_verifier_settings(config_path: Path) -> tuple[str, str, str]:
    del config_path
    from cybervisor.global_config import GlobalConfigError, load_global_config

    try:
        global_config = load_global_config()
    except GlobalConfigError:
        return DEFAULT_ENDPOINT, "", DEFAULT_MODEL
    return global_config.llm.base_url, global_config.llm.api_key, global_config.llm.model


def active_stage_prompt(config_path: Path) -> str | None:
    try:
        raw_prompt = load_hook_runtime_config(config_path).get("active_stage_prompt")
    except FileNotFoundError:
        return None
    return raw_prompt.strip() if isinstance(raw_prompt, str) and raw_prompt.strip() else None


def active_stage_contract(config_path: Path) -> dict[str, Any] | None:
    try:
        raw = load_hook_runtime_config(config_path).get("active_stage_contract")
    except FileNotFoundError:
        return None
    return raw if isinstance(raw, dict) else None


def is_final_stage_attempt(config_path: Path) -> bool:
    try:
        raw = load_hook_runtime_config(config_path)
    except FileNotFoundError:
        return False
    attempt = raw.get("active_stage_attempt")
    max_retries = raw.get("active_stage_max_retries")
    return isinstance(attempt, int) and isinstance(max_retries, int) and attempt >= max_retries


def resolve_artifact_path(contract: dict[str, Any]) -> Path:
    raw_path = contract.get("artifact_path")
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError("contract artifact_path is missing")
    candidate = Path(raw_path)
    if candidate.is_absolute():
        raise ValueError("contract artifact_path must be relative to the working directory")
    cwd = Path.cwd().resolve()
    resolved = (cwd / candidate).resolve()
    try:
        resolved.relative_to(cwd)
    except ValueError as exc:
        raise ValueError("contract artifact_path must stay within the working directory") from exc
    return resolved


def contract_prompt_guidance(contract: dict[str, Any]) -> str:
    guidance = contract.get("guidance")
    if isinstance(guidance, str) and guidance.strip():
        return guidance.strip()
    prompt_path = contract.get("prompt_path")
    if isinstance(prompt_path, str) and prompt_path.strip():
        return f"Read {prompt_path.strip()} for more information."
    prompt_contents = contract.get("prompt_contents")
    if isinstance(prompt_contents, str) and prompt_contents.strip():
        return "Follow the contract prompt guidance and write the required YAML artifact."
    return "Write the required contract artifact as YAML using the expected top-level structure."


def contract_repair_message(contract: dict[str, Any], validation_message: str) -> str:
    artifact_path = resolve_artifact_path(contract)
    allowed_statuses = contract.get("allowed_statuses", [])
    guidance = contract_prompt_guidance(contract)
    allowed = ", ".join(allowed_statuses) if isinstance(allowed_statuses, list) else ""
    lowered_validation = validation_message.lower()
    include_status_hint = "status" in lowered_validation and bool(allowed)

    parts = [f"Before stopping, repair {artifact_path}.", validation_message.rstrip(".") + "."]
    if include_status_hint:
        parts.append(f"Allowed statuses: {allowed}.")
    prefix = " ".join(parts)
    return f"{prefix}\n\n{guidance.rstrip('.')}."


def validate_stage_contract_artifact(config_path: Path) -> tuple[dict[str, Any] | None, str | None]:
    contract = active_stage_contract(config_path)
    if contract is None:
        return None, None

    try:
        artifact_path = resolve_artifact_path(contract)
    except ValueError as exc:
        return None, str(exc)

    if not artifact_path.exists():
        return None, "write the required stage artifact"

    try:
        payload = yaml.safe_load(artifact_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        return None, f"rewrite {artifact_path} as valid YAML ({exc})"

    if not isinstance(payload, dict):
        return None, f"rewrite {artifact_path} so the top-level value is a YAML mapping"

    allowed_statuses = contract.get("allowed_statuses")
    if not isinstance(allowed_statuses, list) or not all(isinstance(item, str) for item in allowed_statuses):
        return None, "stage contract allowed_statuses is invalid"

    status = payload.get("Status")
    if not isinstance(status, str) or status not in allowed_statuses:
        return None, f"set {artifact_path} Status to one of: {', '.join(allowed_statuses)}"
    routes = contract.get("routes", {})
    route = routes.get(status) if isinstance(routes, dict) else None
    if not isinstance(route, dict):
        return None, f"set {artifact_path} Status to match a configured contract route"
    injections = route.get("injections", [])
    if not isinstance(injections, list) or not all(isinstance(item, str) for item in injections):
        return None, "stage contract route injections are invalid"
    for field_name in injections:
        field_value = payload.get(field_name)
        if not isinstance(field_value, str) or not field_value.strip():
            return None, f"set {artifact_path} {field_name} to a non-empty string"
    allowed_fields = {"Status", *injections}
    unexpected_fields = [
        field_name
        for field_name, field_value in payload.items()
        if field_name not in allowed_fields and isinstance(field_value, str) and field_value.strip()
    ]
    if unexpected_fields:
        rendered_fields = ", ".join(unexpected_fields)
        return None, f"remove unexpected fields from {artifact_path} for Status {status}: {rendered_fields}"

    return payload, None


def strip_fences(text: str) -> str:
    stripped = text.strip()
    if stripped.startswith("```") and stripped.endswith("```"):
        lines = stripped.splitlines()
        if len(lines) >= 3:
            return "\n".join(lines[1:-1]).strip()
    return stripped


def parse_decision(text: str) -> HookDecision:
    payload = json.loads(strip_fences(text))
    if not isinstance(payload, dict):
        raise ValueError("decision output must be a JSON object")
    raw_decision = payload.get("decision")
    reason = payload.get("reason", payload.get("explanation"))
    if not isinstance(raw_decision, str):
        raise ValueError("decision must be a string")
    normalized_decision = raw_decision.strip().lower()
    action_aliases = {
        "approve": "approve",
        "allow": "approve",
        "block": "block",
        "deny": "block",
    }
    action = action_aliases.get(normalized_decision)
    if action is None:
        raise ValueError("decision must be 'approve' or 'block'")
    if not isinstance(reason, str) or not reason.strip():
        raise ValueError("reason must be a non-empty string")
    return HookDecision(action=action, reason=reason.strip())


def parse_hook_payload(output: str) -> dict[str, Any] | None:
    try:
        payload = json.loads(output)
    except json.JSONDecodeError:
        return None
    return payload if isinstance(payload, dict) else None


def collapse_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def extract_json_string_field(output: str, key: str) -> str | None:
    match = re.search(rf'"{re.escape(key)}"\s*:\s*', output)
    if match is None:
        return None
    suffix = output[match.end():].lstrip()
    if not suffix.startswith('"'):
        return None
    try:
        decoded, _ = json.JSONDecoder().raw_decode(suffix)
    except json.JSONDecodeError:
        return None
    return decoded if isinstance(decoded, str) and decoded.strip() else None


def dedupe_subsumed_segments(segments: list[str]) -> list[str]:
    unique: list[str] = []
    normalized_seen: list[str] = []
    for segment in segments:
        normalized = collapse_whitespace(segment)
        if not normalized:
            continue
        if any(
            normalized == seen
            or (len(normalized) >= 24 and normalized in seen)
            or (len(seen) >= 24 and seen in normalized)
            for seen in normalized_seen
        ):
            continue
        unique.append(segment)
        normalized_seen.append(normalized)
    return unique


def strip_prompt_prefix(text: str, stage_prompt: str | None) -> str:
    stripped = text.strip()
    if not stage_prompt:
        return stripped
    prompt = stage_prompt.strip()
    if prompt and stripped.startswith(prompt):
        stripped = stripped[len(prompt):].lstrip()
    return stripped


def clean_gemini_final_response(text: str, stage_prompt: str | None) -> str:
    stripped = strip_prompt_prefix(text, stage_prompt)
    if not stripped:
        return ""

    raw_segments = [
        collapse_whitespace(segment)
        for segment in re.split(r"\n\s*\n+", stripped)
        if collapse_whitespace(segment)
    ]
    cleaned_segments = [segment for segment in dedupe_subsumed_segments(raw_segments)]
    if cleaned_segments:
        return "\n\n".join(cleaned_segments)
    return collapse_whitespace(stripped)


def format_verifier_payload(*, agent_tool: str | None, stage_prompt: str | None, final_response: str) -> str:
    lines = [f"Agent tool: {agent_tool or 'unknown'}"]
    if stage_prompt and stage_prompt.strip():
        lines.extend(["Stage prompt:", stage_prompt.strip()])
    lines.extend(["", "", "Final assistant response:", final_response.strip()])
    return "\n".join(lines)


def format_contract_verifier_payload(
    *,
    agent_tool: str | None,
    stage_prompt: str | None,
    artifact_path: Path,
    artifact_payload: dict[str, Any],
    tool_context: str | None,
) -> str:
    lines = [f"Agent tool: {agent_tool or 'unknown'}"]
    if stage_prompt and stage_prompt.strip():
        lines.extend(["Stage prompt:", stage_prompt.strip()])
    lines.extend(
        [
            "Contract artifact path:",
            str(artifact_path),
            "Contract artifact payload:",
            yaml.safe_dump(artifact_payload, sort_keys=False).rstrip(),
        ]
    )
    if tool_context:
        lines.extend(["Relevant tool activity:", tool_context])
    return "\n".join(lines)


def normalize_hook_verifier_input(output: str, *, agent_tool: str | None, config_path: Path) -> str:
    stage_prompt = active_stage_prompt(config_path)
    payload = parse_hook_payload(output)

    contract = active_stage_contract(config_path)
    if contract is not None:
        artifact_payload, artifact_error = validate_stage_contract_artifact(config_path)
        if artifact_error is None and artifact_payload is not None:
            from cybervisor.adapters.gemini.hook_context import extract_tool_activity_from_transcript_path

            tool_context = extract_tool_activity_from_transcript_path(
                payload.get("transcript_path") if payload is not None else None
            )
            return format_contract_verifier_payload(
                agent_tool=agent_tool,
                stage_prompt=stage_prompt,
                artifact_path=resolve_artifact_path(contract),
                artifact_payload=artifact_payload,
                tool_context=tool_context,
            )

    if agent_tool == "claude":
        final_response = None
        if payload is not None:
            response = payload.get("last_assistant_message")
            if isinstance(response, str) and response.strip():
                final_response = response.strip()
        if final_response is None:
            final_response = collapse_whitespace(output)
        return format_verifier_payload(
            agent_tool=agent_tool,
            stage_prompt=stage_prompt,
            final_response=final_response,
        )

    final_candidates: list[str] = []
    if payload is not None:
        for key in ("prompt_response", "response", "final_response", "assistant_response"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                final_candidates.append(value)
    else:
        for key in ("prompt_response", "response", "final_response", "assistant_response", "last_assistant_message"):
            value = extract_json_string_field(output, key)
            if value is not None:
                final_candidates.append(value)
    if not final_candidates:
        final_candidates.append(output)

    cleaned_candidates = [clean_gemini_final_response(candidate, stage_prompt) for candidate in final_candidates]
    final_response = next((candidate for candidate in cleaned_candidates if candidate.strip()), collapse_whitespace(output))
    return format_verifier_payload(
        agent_tool=agent_tool,
        stage_prompt=stage_prompt,
        final_response=final_response,
    )


def chat_completions_url(base_url: str) -> str:
    stripped = base_url.strip()
    if not stripped:
        raise ValueError("Verifier API endpoint must not be empty")

    parsed = urlsplit(stripped)
    path = parsed.path.rstrip("/")
    if path.endswith("/chat/completions"):
        normalized_path = path
    else:
        normalized_path = f"{path}/chat/completions" if path else "/chat/completions"
    return urlunsplit((parsed.scheme, parsed.netloc, normalized_path, parsed.query, parsed.fragment))


def post(api_endpoint: str, api_key: str, model: str, messages: list[dict[str, str]]) -> str:
    headers = {
        "Content-Type": "application/json",
        "User-Agent": HOOK_USER_AGENT,
    }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    try:
        with httpx.Client(timeout=HOOK_HTTP_TIMEOUT_SECONDS) as client:
            response = client.post(
                chat_completions_url(api_endpoint),
                headers=headers,
                json={"model": model, "messages": messages},
            )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code >= 500:
            raise VerifierRequestError(f"verifier server error ({exc.response.status_code})") from exc
        raise
    except httpx.TimeoutException as exc:
        raise VerifierRequestError("verifier request timed out") from exc
    except httpx.NetworkError as exc:
        raise VerifierRequestError(f"verifier network error: {exc}") from exc

    try:
        payload = response.json()
    except json.JSONDecodeError as exc:
        raise VerifierResponseShapeError("invalid JSON in LLM response") from exc
    choices = payload.get("choices", [])
    if not choices:
        raise VerifierResponseShapeError("missing choices in LLM response")
    message = choices[0].get("message", {})
    content = message.get("content", "")
    if not isinstance(content, str) or not content.strip():
        raise VerifierResponseShapeError("missing content in LLM response")
    return content


def request_verifier_text(
    *,
    api_endpoint: str,
    api_key: str,
    model: str,
    messages: list[dict[str, str]],
    log_path: Path,
    agent_tool: str | None,
    config_path: Path,
    hook_input: str,
    event_name: str,
    notify_listener: bool = True,
    post_fn: Callable[[str, str, str, list[dict[str, str]]], str] = post,
) -> str:
    last_error: Exception | None = None
    for attempt in range(1, VERIFIER_REQUEST_RETRY_ATTEMPTS + 1):
        try:
            text = post_fn(api_endpoint, api_key, model, messages)
        except VerifierRequestError as exc:
            last_error = exc
            if attempt >= VERIFIER_REQUEST_RETRY_ATTEMPTS:
                break
            log_hook_event(
                log_path,
                event_name,
                "Verifier request failed; retrying.",
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=hook_input,
                error=f"attempt={attempt + 1}/{VERIFIER_REQUEST_RETRY_ATTEMPTS}: {exc}",
                notify_listener=notify_listener,
            )
            continue

        log_hook_event(
            log_path,
            "verifier_response_received",
            "Received verifier response.",
            agent_tool=agent_tool,
            config_path=config_path,
            hook_input=hook_input,
            verifier_output=text,
            notify_listener=notify_listener,
        )
        return text

    if last_error is None:
        raise VerifierRequestError("verifier request failed")
    raise VerifierRequestError(
        "Verifier request failed after "
        f"{VERIFIER_REQUEST_RETRY_ATTEMPTS} attempts: {last_error}"
    ) from last_error


def get_stop_verifier_prompt(config_path: Path) -> str:
    del config_path
    prompt_path = Path(__file__).resolve().parent.parent / "assets" / "hooks" / "stop-hook-verifier.md"
    if not prompt_path.exists():
        return "Decide if the agent can stop. Respond in valid JSON only with 'decision' and 'reason'."
    return prompt_path.read_text(encoding="utf-8").strip()


def recover_structured_output(
    *,
    api_endpoint: str,
    api_key: str,
    model: str,
    initial_messages: list[dict[str, str]],
    parser: Callable[[str], TStructured],
    regeneration_system_prompt: str,
    log_path: Path,
    agent_tool: str | None,
    config_path: Path,
    hook_input: str,
    notify_listener: bool = True,
    post_fn: Callable[[str, str, str, list[dict[str, str]]], str] = post,
) -> tuple[TStructured, str]:
    text = request_verifier_text(
        api_endpoint=api_endpoint,
        api_key=api_key,
        model=model,
        messages=initial_messages,
        log_path=log_path,
        agent_tool=agent_tool,
        config_path=config_path,
        hook_input=hook_input,
        event_name="verifier_request_retry",
        notify_listener=notify_listener,
        post_fn=post_fn,
    )

    last_error: Exception | None = None
    for attempt in range(1, STRUCTURED_RETRY_ATTEMPTS + 1):
        try:
            return parser(text), text
        except Exception as exc:
            last_error = exc
            if attempt >= STRUCTURED_RETRY_ATTEMPTS:
                break
            log_hook_event(
                log_path,
                "verifier_regeneration_requested",
                "Verifier response was invalid; requesting JSON regeneration.",
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=hook_input,
                verifier_output=text,
                error=f"attempt={attempt + 1}/{STRUCTURED_RETRY_ATTEMPTS}: {exc}",
                notify_listener=notify_listener,
            )
            text = request_verifier_text(
                api_endpoint=api_endpoint,
                api_key=api_key,
                model=model,
                messages=[
                    {"role": "system", "content": regeneration_system_prompt},
                    {
                        "role": "user",
                        "content": (
                            f"Previous invalid output:\n{text}\n\n"
                            f"Error:\n{exc}\n\n"
                            f"Attempt: {attempt + 1}/{STRUCTURED_RETRY_ATTEMPTS}"
                        ),
                    },
                ],
                log_path=log_path,
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=hook_input,
                event_name="verifier_request_retry",
                notify_listener=notify_listener,
                post_fn=post_fn,
            )

    raise ValueError(
        "Verifier returned invalid structured output after "
        f"{STRUCTURED_RETRY_ATTEMPTS} attempts: {last_error}"
    )
