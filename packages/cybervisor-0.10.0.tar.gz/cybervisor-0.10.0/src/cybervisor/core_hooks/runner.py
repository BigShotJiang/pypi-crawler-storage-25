from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from collections.abc import Callable
from typing import Any, TYPE_CHECKING, TypeVar

import httpx

from cybervisor.core_hooks import common as _common
from cybervisor.core_hooks.common import (
    AUTONOMY_DENY_MESSAGE,
    HookDecision,
)
from cybervisor.global_config import GlobalConfigError, load_global_config

if TYPE_CHECKING:
    from cybervisor.config import StageContractConfig

TStructured = TypeVar("TStructured")

HOOK_USER_AGENT = _common.HOOK_USER_AGENT
HOOK_HTTP_TIMEOUT_SECONDS = _common.HOOK_HTTP_TIMEOUT_SECONDS
STRUCTURED_RETRY_ATTEMPTS = _common.STRUCTURED_RETRY_ATTEMPTS
VERIFIER_REQUEST_RETRY_ATTEMPTS = _common.VERIFIER_REQUEST_RETRY_ATTEMPTS


def _load_hook_runtime_config(config_path: Path) -> dict[str, Any]:
    return _common.load_hook_runtime_config(config_path)


def _socket_path_from_config(config_path: Path) -> str | None:
    return _common.socket_path_from_config(config_path)


def _send_hook_event(socket_path: str | None, payload: dict[str, Any]) -> None:
    _common.send_hook_event(socket_path, payload)


def _log_hook_event(
    log_path: Path,
    event: str,
    message: str,
    *,
    agent_tool: str | None,
    config_path: Path,
    hook_input: str | None = None,
    verifier_output: str | None = None,
    decision: dict[str, Any] | None = None,
    error: str | None = None,
    session_id: str | None = None,
    notify_listener: bool = True,
    missing_artifacts: list[str] | None = None,
) -> None:
    payload: dict[str, Any] = {
        "timestamp": _common.utc_now(),
        "event": event,
        "message": message,
        "agent_tool": agent_tool,
        "pid": __import__("os").getpid(),
        "config_path": str(config_path.resolve()),
    }
    if hook_input is not None:
        payload["hook_input"] = hook_input
    if verifier_output is not None:
        payload["verifier_output"] = verifier_output
    if decision is not None:
        payload["decision"] = decision
    if error is not None:
        payload["error"] = error
    if session_id is not None:
        payload["session_id"] = session_id
    if missing_artifacts is not None:
        payload["missing_artifacts"] = missing_artifacts
    _common.append_hook_event(log_path, payload)
    if notify_listener:
        _send_hook_event(_socket_path_from_config(config_path), payload)


def _resolve_verifier_settings(config_path: Path) -> tuple[str, str, str]:
    del config_path
    try:
        global_config = load_global_config()
    except GlobalConfigError:
        return _common.DEFAULT_ENDPOINT, "", _common.DEFAULT_MODEL
    return global_config.llm.base_url, global_config.llm.api_key, global_config.llm.model


def _normalize_hook_verifier_input(output: str, *, agent_tool: str | None, config_path: Path) -> str:
    return _common.normalize_hook_verifier_input(output, agent_tool=agent_tool, config_path=config_path)


def _parse_decision(text: str) -> HookDecision:
    return _common.parse_decision(text)


def _post(api_endpoint: str, api_key: str, model: str, messages: list[dict[str, str]]) -> str:
    headers = {
        "Content-Type": "application/json",
        "User-Agent": HOOK_USER_AGENT,
    }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    try:
        with httpx.Client(timeout=HOOK_HTTP_TIMEOUT_SECONDS) as client:
            response = client.post(
                _common.chat_completions_url(api_endpoint),
                headers=headers,
                json={"model": model, "messages": messages},
            )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code >= 500:
            raise _common.VerifierRequestError(f"verifier server error ({exc.response.status_code})") from exc
        raise
    except httpx.TimeoutException as exc:
        raise _common.VerifierRequestError("verifier request timed out") from exc
    except httpx.NetworkError as exc:
        raise _common.VerifierRequestError(f"verifier network error: {exc}") from exc

    try:
        payload = response.json()
    except json.JSONDecodeError as exc:
        raise _common.VerifierResponseShapeError("invalid JSON in LLM response") from exc
    choices = payload.get("choices", [])
    if not choices:
        raise _common.VerifierResponseShapeError("missing choices in LLM response")
    message = choices[0].get("message", {})
    content = message.get("content", "")
    if not isinstance(content, str) or not content.strip():
        raise _common.VerifierResponseShapeError("missing content in LLM response")
    return content


def _recover_structured_output(
    *,
    api_endpoint: str,
    api_key: str,
    model: str,
    initial_messages: list[dict[str, str]],
    parser: Callable[[str], TStructured],
    regeneration_system_prompt: str,
    log_path: Path,
    agent_tool: str | None,
    config_path: Path,
    hook_input: str,
    notify_listener: bool = True,
) -> tuple[TStructured, str]:
    return _common.recover_structured_output(
        api_endpoint=api_endpoint,
        api_key=api_key,
        model=model,
        initial_messages=initial_messages,
        parser=parser,
        regeneration_system_prompt=regeneration_system_prompt,
        log_path=log_path,
        agent_tool=agent_tool,
        config_path=config_path,
        hook_input=hook_input,
        notify_listener=notify_listener,
        post_fn=_post,
    )


_blocking_decision = _common.blocking_decision
_contract_blocking_decision = _common.contract_blocking_decision
_contract_repair_message = _common.contract_repair_message
_format_verifier_payload = _common.format_verifier_payload
_get_stop_verifier_prompt = _common.get_stop_verifier_prompt
_hook_log_path = _common.hook_log_path
_is_final_stage_attempt = _common.is_final_stage_attempt
_validate_stage_contract_artifact = _common.validate_stage_contract_artifact
VerifierRequestError = _common.VerifierRequestError
VerifierResponseShapeError = _common.VerifierResponseShapeError


def _hook_state_path(config_path: Path) -> Path:
    resolved_config = config_path.resolve()
    return resolved_config.parent / "hook_state.json"


def _decision_from_payload(payload: dict[str, Any] | None) -> HookDecision | None:
    if not isinstance(payload, dict):
        return None
    raw_decision = payload.get("decision")
    raw_reason = payload.get("reason")
    if not isinstance(raw_decision, str) or not isinstance(raw_reason, str):
        return None
    normalized = raw_decision.strip().lower()
    if normalized not in {"approve", "block"}:
        return None
    return HookDecision(action=normalized, reason=raw_reason.strip())


def _cached_hook_state(config_path: Path) -> dict[str, Any] | None:
    path = _hook_state_path(config_path)
    if not path.exists():
        return None
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return raw if isinstance(raw, dict) else None


def _write_hook_state(config_path: Path, payload: dict[str, Any]) -> None:
    path = _hook_state_path(config_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(".tmp")
    temp_path.write_text(json.dumps(payload, sort_keys=True), encoding="utf-8")
    temp_path.replace(path)


def _hook_input_fingerprint(
    *,
    input_data: str,
    agent_tool: str | None,
    runtime_config: dict[str, Any] | None = None,
) -> str:
    if runtime_config is None:
        runtime_config = {}
    state_payload = {
        "agent_tool": agent_tool,
        "active_stage_name": runtime_config.get("active_stage_name"),
        "active_stage_attempt": runtime_config.get("active_stage_attempt"),
        "active_stage_max_retries": runtime_config.get("active_stage_max_retries"),
        "active_stage_contract": runtime_config.get("active_stage_contract"),
        "keep_artifacts": runtime_config.get("keep_artifacts"),
        "input_data": input_data,
    }
    encoded = json.dumps(state_payload, sort_keys=True, ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _cached_duplicate_decision(
    *,
    config_path: Path,
    input_data: str,
    agent_tool: str | None,
    runtime_config: dict[str, Any] | None = None,
    fingerprint: str | None = None,
) -> HookDecision | None:
    if runtime_config is None:
        runtime_config = {}
    cached_state = _cached_hook_state(config_path)
    if cached_state is None:
        return None
    expected_fingerprint = (
        fingerprint
        if fingerprint is not None
        else _hook_input_fingerprint(
            input_data=input_data,
            agent_tool=agent_tool,
            runtime_config=runtime_config,
        )
    )
    if cached_state.get("fingerprint") != expected_fingerprint:
        return None
    return _decision_from_payload(cached_state.get("decision"))


def _store_hook_decision(
    *,
    config_path: Path,
    input_data: str,
    agent_tool: str | None,
    runtime_config: dict[str, Any] | None = None,
    decision: HookDecision,
    fingerprint: str | None = None,
) -> None:
    if runtime_config is None:
        runtime_config = {}
    resolved_fingerprint = (
        fingerprint
        if fingerprint is not None
        else _hook_input_fingerprint(
            input_data=input_data,
            agent_tool=agent_tool,
            runtime_config=runtime_config,
        )
    )
    _write_hook_state(
        config_path,
        {
            "fingerprint": resolved_fingerprint,
            "decision": decision.as_payload(),
        },
    )


def _active_stage_contract(config_path: Path) -> dict[str, Any] | None:
    try:
        raw = _load_hook_runtime_config(config_path).get("active_stage_contract")
    except FileNotFoundError:
        return None
    return raw if isinstance(raw, dict) else None

def _decide(
    output: str,
    api_endpoint: str,
    api_key: str,
    model: str,
    *,
    log_path: Path,
    agent_tool: str | None,
    config_path: Path,
    runtime_config: dict[str, Any] | None = None,
) -> tuple[HookDecision, str]:
    if runtime_config is None:
        runtime_config = {}
    # Compute fingerprint using the passed runtime_config (which includes keep_artifacts).
    fingerprint = _hook_input_fingerprint(
        input_data=output,
        agent_tool=agent_tool,
        runtime_config=runtime_config,
    )

    # Artifact preservation check — runs at the very top before any contract loading.
    keep_artifacts = runtime_config.get("keep_artifacts")
    if isinstance(keep_artifacts, list):
        missing: list[str] = []
        for artifact_path in keep_artifacts:
            resolved = (Path.cwd() / artifact_path).resolve()
            if not resolved.exists():
                missing.append(artifact_path)
        if missing:
            reason = f"Required artifact(s) missing: {', '.join(missing)}. Recreate each file with its expected content before completing."
            decision = HookDecision(action="block", reason=reason)
            _log_hook_event(
                log_path,
                "artifact_preservation_check_failed",
                "One or more required artifacts are missing.",
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=output,
                decision=decision.as_payload(),
                missing_artifacts=missing,
            )
            return decision, fingerprint
        if keep_artifacts:
            _log_hook_event(
                log_path,
                "artifact_preservation_check_passed",
                "All required artifacts are present.",
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=output,
            )

    contract = _active_stage_contract(config_path)
    if contract is not None:
        artifact_payload, artifact_error = _validate_stage_contract_artifact(config_path)
        if artifact_error is not None:
            artifact_error = _contract_repair_message(contract, artifact_error)
            contract_decision = _contract_blocking_decision(agent_tool, artifact_error)
            _log_hook_event(
                log_path,
                "contract_validation_failed",
                "Required stage artifact was missing or invalid.",
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=output,
                decision=contract_decision.as_payload(),
                error=artifact_error,
            )
            _log_hook_event(
                log_path,
                "decision_emitted",
                "Blocked completion until the required stage artifact is valid.",
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=output,
                decision=contract_decision.as_payload(),
            )
            return contract_decision, fingerprint
        if artifact_payload is not None:
            _log_hook_event(
                log_path,
                "contract_validation_passed",
                "Required stage artifact validated successfully.",
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=output,
            )
            decision = HookDecision(
                action="approve",
                reason="stage_contract_valid",
            )
            _log_hook_event(
                log_path,
                "decision_emitted",
                "Approved completion because the required stage artifact is valid.",
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=output,
                decision=decision.as_payload(),
            )
            return decision, fingerprint

    verifier_input = _normalize_hook_verifier_input(output, agent_tool=agent_tool, config_path=config_path)
    if contract is None and _is_final_stage_attempt(config_path):
        decision = HookDecision(
            action="approve",
            reason="final_attempt_reached_allowing_stop_without_hook_block",
        )
        _log_hook_event(
            log_path,
            "final_attempt_bypass",
            "Final allowed attempt reached; allowing stop without hook blocking.",
            agent_tool=agent_tool,
            config_path=config_path,
            hook_input=output,
            decision=decision.as_payload(),
        )
        return decision, fingerprint

    if not api_key:
        decision = _blocking_decision(agent_tool, "verifier_unavailable_no_api_key")
        _log_hook_event(
            log_path,
            "decision_emitted",
            "Verifier unavailable; emitted safe deny decision.",
            agent_tool=agent_tool,
            config_path=config_path,
            hook_input=output,
            decision=decision.as_payload(),
        )
        return decision, fingerprint

    _log_hook_event(
        log_path,
        "verifier_request_started",
        "Submitting normalized hook payload to verifier.",
        agent_tool=agent_tool,
        config_path=config_path,
        hook_input=output,
    )

    decision, verifier_output = _recover_structured_output(
        api_endpoint=api_endpoint,
        api_key=api_key,
        model=model,
        initial_messages=[
            {
                "role": "system",
                "content": _get_stop_verifier_prompt(config_path),
            },
            {"role": "user", "content": verifier_input},
        ],
        parser=_parse_decision,
        regeneration_system_prompt="Regenerate as VALID JSON only. No prose. Keys: decision ('approve'|'block'), reason (string).",
        log_path=log_path,
        agent_tool=agent_tool,
        config_path=config_path,
        hook_input=output,
    )
    _log_hook_event(
        log_path,
        "decision_emitted",
        "Parsed verifier decision and emitted hook response.",
        agent_tool=agent_tool,
        config_path=config_path,
        hook_input=output,
        verifier_output=verifier_output,
        decision=decision.as_payload(),
    )
    if decision.is_blocking:
        return decision, fingerprint

    return decision, fingerprint

def run_hook(config_path: Path, input_data: str) -> dict[str, Any]:
    runtime_config = _load_hook_runtime_config(config_path)
    agent_tool = runtime_config.get("agent_tool")
    if not isinstance(agent_tool, str):
        agent_tool = None

    log_path = _hook_log_path(config_path)
    # Compute fingerprint upfront so it can be used for both cache lookup and store.
    precomputed_fingerprint = _hook_input_fingerprint(
        input_data=input_data,
        agent_tool=agent_tool,
        runtime_config=runtime_config,
    )
    cached_decision = _cached_duplicate_decision(
        config_path=config_path,
        input_data=input_data,
        agent_tool=agent_tool,
        runtime_config=runtime_config,
        fingerprint=precomputed_fingerprint,
    )
    if cached_decision is not None:
        _log_hook_event(
            log_path,
            "duplicate_invocation_reused",
            "Reused cached decision for duplicate hook input.",
            agent_tool=agent_tool,
            config_path=config_path,
            hook_input=input_data,
            decision=cached_decision.as_payload(),
        )
        return cached_decision.as_hook_output(agent_tool)

    _log_hook_event(
        log_path,
        "hook_invocation_started",
        "Hook invocation started.",
        agent_tool=agent_tool,
        config_path=config_path,
    )
    
    _log_hook_event(
        log_path,
        "hook_input_captured",
        "Captured hook stdin payload.",
        agent_tool=agent_tool,
        config_path=config_path,
        hook_input=input_data,
    )
    
    api_endpoint, api_key, model = _resolve_verifier_settings(config_path)
    
    try:
        decision, fingerprint = _decide(
            output=input_data,
            api_endpoint=api_endpoint,
            api_key=api_key,
            model=model,
            log_path=log_path,
            agent_tool=agent_tool,
            config_path=config_path,
            runtime_config=runtime_config,
        )
        _store_hook_decision(
            config_path=config_path,
            input_data=input_data,
            agent_tool=agent_tool,
            runtime_config=runtime_config,
            decision=decision,
            fingerprint=fingerprint,
        )
        return decision.as_hook_output(agent_tool)
    except Exception as exc:
        fallback = HookDecision(
            action="block",
            reason=f"hook_error:{exc}",
            system_message=AUTONOMY_DENY_MESSAGE,
        )
        _store_hook_decision(
            config_path=config_path,
            input_data=input_data,
            agent_tool=agent_tool,
            runtime_config=runtime_config,
            decision=fallback,
            fingerprint=precomputed_fingerprint,
        )
        _log_hook_event(
            log_path,
            "fallback_error_emitted",
            "Hook failed; emitted safe deny fallback.",
            agent_tool=agent_tool,
            config_path=config_path,
            decision=HookDecision(action="block", reason=AUTONOMY_DENY_MESSAGE).as_payload(),
            error=str(exc),
        )
        return fallback.as_hook_output(agent_tool)
