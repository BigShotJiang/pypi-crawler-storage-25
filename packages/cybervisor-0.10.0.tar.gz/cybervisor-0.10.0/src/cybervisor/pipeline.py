from __future__ import annotations

import json
import os
import re
import signal
import shutil
import string
import time
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping

import psutil
import yaml

from cybervisor.adapters.base import AgentAdapter
from cybervisor.adapters.types import AdapterExecutionResult, AdapterOutcome, AdapterStatus, LaunchRequest
from cybervisor.config import StageConfig, StageContractConfig, StageRouteConfig, _display_field_name, contract_artifact_path
from cybervisor.hooks import set_active_stage_contract
from cybervisor.logging import CybervisorLogger, HookEventListener
from cybervisor.signals import SignalHandler


# Type alias for stage event callback
StageEventCallback = Callable[[dict[str, Any]], None]


class EndStageRef:
    """Thread-safe mutable reference for dynamic end stage updates.

    Allows the daemon to update the end stage mid-pipeline via set_stop_stage,
    which the PipelineRunner checks at each stage boundary.
    """

    def __init__(self, initial_value: str | None = None) -> None:
        self._value = initial_value
        self._lock = threading.Lock()

    def get(self) -> str | None:
        with self._lock:
            return self._value

    def set(self, value: str | None) -> None:
        with self._lock:
            self._value = value


class PipelineInterrupted(Exception):
    def __init__(self, stage_name: str, attempt: int, exit_code: int | None = None) -> None:
        self.stage_name = stage_name
        self.attempt = attempt
        self.exit_code = exit_code
        detail = f" during attempt {attempt}" if attempt > 0 else ""
        status = f" (exit_code={exit_code})" if exit_code is not None else ""
        super().__init__(f"Pipeline interrupted in stage '{stage_name}'{detail}{status}")


def _is_interrupt_exit_code(exit_code: int | None) -> bool:
    if exit_code is None:
        return False
    if exit_code == 130:
        return True
    return exit_code in (-signal.SIGINT, -signal.SIGTERM)


def _get_child_pids(parent_pid: int) -> list[int]:
    try:
        parent = psutil.Process(parent_pid)
        return [child.pid for child in parent.children(recursive=True)]
    except (ProcessLookupError, psutil.NoSuchProcess, psutil.AccessDenied):
        return []


def _render_prompt(template: str, context: Mapping[str, str]) -> tuple[str, set[str]]:
    formatter = string.Formatter()
    missing_keys: set[str] = set()
    for _literal_text, field_name, _format_spec, _conversion in formatter.parse(template):
        if field_name and field_name not in context:
            missing_keys.add(field_name)

    safe_context: dict[str, str] = dict(context)
    for key in missing_keys:
        safe_context[key] = ""
    return template.format_map(safe_context), missing_keys


def _artifact_file_path(stage_name: str) -> Path:
    return (Path.cwd() / contract_artifact_path(stage_name)).resolve()


def _artifact_runtime_root() -> Path:
    return (Path.cwd() / ".cybervisor/artifacts").resolve()


def _backup_stage_artifacts(
    stage_name: str,
    backup_artifacts: list[str],
    logger: CybervisorLogger,
    log_file: str,
    cwd: Path | None = None,
    timestamp: str | None = None,
) -> None:
    """Backup stage artifacts to .cybervisor/backups/<stage_name>/<timestamp>/.

    Args:
        stage_name: Name of the stage being backed up.
        backup_artifacts: List of artifact paths to backup.
        logger: Logger instance for structured logging.
        log_file: Path to the JSON log file.
        cwd: Working directory for resolving relative paths. Defaults to Path.cwd().
        timestamp: Timestamp string for versioned backup subdirectory.
                   Format: YYYY-MM-DDTHH-MM-SS (ISO-inspired, filesystem-safe).
    """
    if not backup_artifacts:
        return

    work_dir = cwd if cwd is not None else Path.cwd()
    backup_root = (work_dir / ".cybervisor/backups" / stage_name / (timestamp or "")).resolve()

    for artifact_path in backup_artifacts:
        source = Path(artifact_path)
        # Absolute paths are used as-is; relative paths resolved against work_dir
        if not source.is_absolute():
            source = (work_dir / source).resolve()

        dest = backup_root / source.name

        if not source.exists():
            logger.log_to_stderr(f"[{stage_name}] Backup: source not found, skipping: {artifact_path}", "warning")
            continue

        try:
            backup_root.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            logger.log_to_stderr(f"[{stage_name}] Backup: failed to create directory {backup_root}: {exc}", "error")
            continue

        try:
            shutil.copy2(source, dest)
            logger.log_to_json(
                {
                    "timestamp": logger.make_entry(stage_name, "Backup", "Artifact backed up").timestamp,
                    "stage_name": stage_name,
                    "backup_source": str(source),
                    "backup_dest": str(dest),
                    "backup_timestamp": timestamp,
                },
                log_file,
            )
        except OSError as exc:
            logger.log_to_stderr(f"[{stage_name}] Backup: failed to copy {artifact_path} to {dest}: {exc}", "error")


def _cleanup_artifact_dir(root: Path) -> None:
    if not root.exists():
        return
    for path in sorted(root.rglob("*"), reverse=True):
        try:
            if path.is_file() or path.is_symlink():
                path.unlink(missing_ok=True)
            elif path.is_dir():
                path.rmdir()
        except OSError as exc:
            # Best-effort cleanup: warn and continue with remaining items
            print(f"Warning: failed to remove {path}: {exc}", file=__import__("sys").stderr)
    try:
        root.rmdir()
    except OSError as exc:
        print(f"Warning: failed to remove directory {root}: {exc}", file=__import__("sys").stderr)


def reset_run_artifacts() -> None:
    _cleanup_artifact_dir(_artifact_runtime_root())
    _cleanup_artifact_dir(_artifact_file_path("").parent)


def _normalized_artifact_payload(payload: dict[str, object]) -> dict[str, object]:
    normalized = dict(payload)
    if "Status" in normalized and "status" not in normalized:
        normalized["status"] = normalized["Status"]
    return normalized


def _artifact_status_value(payload: dict[str, object]) -> str | None:
    normalized = _normalized_artifact_payload(payload)
    status = normalized.get("status")
    return status if isinstance(status, str) else None


def _resolve_contract_status(contract: StageContractConfig, payload_status: str) -> str | None:
    if payload_status in contract.routes:
        return payload_status

    normalized_status = payload_status.strip().casefold()
    for allowed_status in contract.allowed_statuses:
        if allowed_status.strip().casefold() == normalized_status:
            return allowed_status
    return None


def _validate_stage_artifact(stage_name: str, contract: StageContractConfig) -> tuple[dict[str, object] | None, str | None]:
    artifact_path = _artifact_file_path(stage_name)
    try:
        artifact_path.relative_to(Path.cwd().resolve())
    except ValueError:
        return None, "artifact_path must stay within the working directory"

    if not artifact_path.exists():
        return None, f"required artifact missing at {artifact_path}"

    try:
        payload = yaml.safe_load(artifact_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        return None, f"artifact at {artifact_path} is not valid YAML ({exc})"

    if not isinstance(payload, dict):
        return None, f"artifact at {artifact_path} must contain a YAML mapping"

    status = _artifact_status_value(payload)
    if not isinstance(status, str):
        return None, f"artifact Status must be one of {', '.join(contract.allowed_statuses)}"
    resolved_status = _resolve_contract_status(contract, status)
    if resolved_status is None:
        return None, f"artifact Status must be one of {', '.join(contract.allowed_statuses)}"
    route = contract.routes.get(resolved_status)
    if route is not None:
        for field_name in route.injections:
            field_value = payload.get(field_name)
            if not isinstance(field_value, str) or not field_value.strip():
                return None, f"artifact field '{field_name}' must be a non-empty string"
        allowed_fields = {"Status", "status", *route.injections}
        unexpected_fields = [
            field_name
            for field_name, field_value in payload.items()
            if field_name not in allowed_fields and isinstance(field_value, str) and field_value.strip()
        ]
        if unexpected_fields:
            rendered_fields = ", ".join(unexpected_fields)
            return None, f"artifact has unexpected fields for status '{resolved_status}': {rendered_fields}"

    return payload, None


def _stringify_context_value(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return yaml.safe_dump(value, sort_keys=False).rstrip()


def _stage_context_key(stage_name: str) -> str:
    return stage_name.lower().replace(" ", "_")


def _artifact_field_context_key(field_name: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "_", field_name.strip().lower()).strip("_")
    return normalized or "field"


def _format_injected_contract_value(field_name: str, value: str) -> str:
    stripped = value.strip()
    if not stripped:
        return ""
    heading = f"**{_display_field_name(field_name)}**"
    if stripped.startswith(heading):
        return stripped
    return f"{heading}\n{stripped}"


def _stage_log_path(stage_name: str) -> str:
    return f".cybervisor/logs/stages/{stage_name}.jsonl"


def _artifact_output_sections(
    artifact_payload: dict[str, object],
    route: StageRouteConfig | None,
) -> list[tuple[str, str]]:
    seen: set[str] = {"status", "Status"}
    ordered_fields: list[str] = []
    if route is not None:
        for field_name in route.injections:
            if field_name in artifact_payload and field_name not in seen:
                ordered_fields.append(field_name)
                seen.add(field_name)

    for field_name in sorted(artifact_payload):
        if field_name in seen:
            continue
        value = artifact_payload[field_name]
        if isinstance(value, str) and value.strip():
            ordered_fields.append(field_name)
            seen.add(field_name)

    rendered: list[tuple[str, str]] = []
    for field_name in ordered_fields:
        value = artifact_payload.get(field_name)
        if not isinstance(value, str) or not value.strip():
            continue
        rendered.append((field_name, value.strip()))
    return rendered


def _format_contract_artifact_output(
    stage_name: str,
    artifact_payload: dict[str, object],
    route: StageRouteConfig | None = None,
) -> str:
    def _append_indented(lines: list[str], value: str) -> None:
        for line in value.splitlines():
            lines.append(f"  {line}")

    lines = [f"[{stage_name}] Contract artifact output: {contract_artifact_path(stage_name)}", ""]
    status = artifact_payload.get("Status")
    if not isinstance(status, str) or not status.strip():
        status = artifact_payload.get("status")
    if isinstance(status, str) and status.strip():
        lines.append(f"  Status: {status.strip()}")
        lines.append("")

    for field_name, value in _artifact_output_sections(artifact_payload, route):
        _append_indented(lines, _format_injected_contract_value(field_name, value))
        lines.append("")

    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + "\n"


class PipelineRunner:
    def __init__(self, log_file: str = ".cybervisor/logs/cybervisor.log.jsonl") -> None:
        self.log_file = log_file

    def _emit_stage_event(self, callback: StageEventCallback | None, event: dict[str, Any]) -> None:
        """Invoke the stage event callback if it's set."""
        if callback is not None:
            callback(event)

    def _pop_hook_block(
        self,
        hook_listener: HookEventListener | None,
        agent_tool: str | None,
        *,
        wait_for_pending: bool = False,
    ) -> dict[str, object] | None:
        if hook_listener is None:
            return None

        hook_block = hook_listener.pop_blocking_decision(agent_tool)
        if hook_block is not None or not wait_for_pending:
            return hook_block

        deadline = time.monotonic() + 0.25
        while time.monotonic() < deadline:
            time.sleep(0.01)
            hook_block = hook_listener.pop_blocking_decision(agent_tool)
            if hook_block is not None:
                return hook_block
        return None

    def _build_prompt_context(
        self,
        prompt: str | None,
        stage_name: str,
        stage_context: Mapping[str, str],
    ) -> dict[str, str]:
        context = {
            "objective": prompt if prompt is not None else "",
            "stage_name": stage_name,
        }
        context.update(stage_context)
        return context

    def _build_injection_appendix(
        self,
        artifact_payload: dict[str, object],
        inject_sections: list[str],
    ) -> str:
        if not inject_sections:
            return ""

        parts: list[str] = []
        for section in inject_sections:
            value = _stringify_context_value(artifact_payload.get(section))
            if not value:
                continue
            formatted = _format_injected_contract_value(section, value)
            if formatted:
                parts.append(formatted)

        if not parts:
            return ""

        return "Latest routed contract context:\n\n" + "\n\n".join(parts)

    def _update_stage_context_from_artifact(
        self,
        stage: StageConfig,
        artifact_payload: dict[str, object],
        stage_context: dict[str, str],
        inject_sections: list[str],
    ) -> None:
        stage_key = _stage_context_key(stage.name)
        normalized_payload = _normalized_artifact_payload(artifact_payload)

        for section, raw_value in normalized_payload.items():
            if section in {"status", "Status"}:
                continue
            context_key = _artifact_field_context_key(section)
            rendered_value = _stringify_context_value(raw_value)
            stage_context[f"{stage_key}_contract_{context_key}"] = rendered_value
            if section in inject_sections:
                stage_context[f"latest_contract_{context_key}"] = rendered_value

    def _next_stage_index(
        self,
        stages: list[StageConfig],
        stage_lookup: Mapping[str, int],
        current_index: int,
        artifact_payload: dict[str, object] | None,
    ) -> tuple[int | None, str | None, str, list[str]]:
        stage = stages[current_index]
        status: str | None = None
        decision_source = "linear_fallback"

        if artifact_payload is not None:
            status = _artifact_status_value(artifact_payload)
            if status is None:
                return None, None, "contract_missing_status", []
            if stage.contract is not None:
                resolved_status = _resolve_contract_status(stage.contract, status)
                route = stage.contract.routes.get(resolved_status) if resolved_status is not None else None
                if route is None:
                    return None, status, "contract_missing_route", []
                if route.next_stage is None:
                    return None, resolved_status, "contract_terminal", list(route.injections)
                return stage_lookup[route.next_stage], resolved_status, "contract_route", list(route.injections)

        if stage.next_stage is not None:
            return stage_lookup[stage.next_stage], status, "success_route", []

        return current_index + 1, status, decision_source, []

    def run(
        self,
        prompt: str | None,
        stages: list[StageConfig],
        agent: AgentAdapter,
        logger: CybervisorLogger,
        signal_handler: SignalHandler | None = None,
        hook_listener: HookEventListener | None = None,
        start_stage_name: str | None = None,
        end_stage_name: str | None = None,
        end_before_stage_name: str | None = None,
        end_stage_ref: EndStageRef | None = None,
        stage_event_callback: StageEventCallback | None = None,
    ) -> bool:
        stage_lookup = {stage.name: index for index, stage in enumerate(stages)}

        if end_stage_name is not None and end_stage_name not in stage_lookup:
            raise ValueError(f"Unknown end_stage_name '{end_stage_name}'. Valid stages are: {', '.join(stage_lookup.keys())}")
        if end_before_stage_name is not None and end_before_stage_name not in stage_lookup:
            raise ValueError(
                f"Unknown end_before_stage_name '{end_before_stage_name}'. Valid stages are: {', '.join(stage_lookup.keys())}"
            )
        if end_stage_name is not None and end_before_stage_name is not None:
            raise ValueError("--end-stage and --end-before cannot be used together.")

        retry_counts = [0 for _ in stages]
        current_index = 0

        if start_stage_name is not None:
            current_index = stage_lookup[start_stage_name]
        if current_index == 0:
            reset_run_artifacts()

        if end_stage_name is not None:
            end_index = stage_lookup[end_stage_name]
            # Since linear pipelines can have loops, this is a coarse check for default sequences.
            if current_index > end_index:
                raise ValueError(f"Invalid sequence: start stage '{start_stage_name}' occurs after end stage '{end_stage_name}', so pipeline cannot realistically reach the end stage.")
            logger.log_to_json(
                {
                    "timestamp": logger.make_entry("Startup", "TargetedStart", "").timestamp,
                    "stage_name": "Startup",
                    "status": "TargetedStart",
                    "message": "Starting pipeline at requested stage",
                    "requested_stage_name": start_stage_name,
                    "effective_stage_name": stages[current_index].name,
                    "total_stage_count": len(stages),
                },
                self.log_file,
            )
        elif end_before_stage_name is not None:
            end_before_index = stage_lookup[end_before_stage_name]
            if current_index > end_before_index:
                raise ValueError(
                    f"Invalid sequence: start stage '{start_stage_name}' occurs after exclusive end stage '{end_before_stage_name}', so pipeline cannot stop before that stage."
                )
            if current_index == end_before_index:
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry("Startup", "TargetedEndBefore", "").timestamp,
                        "stage_name": "Startup",
                        "status": "TargetedEndBefore",
                        "message": "Skipping pipeline execution because start stage matches exclusive end boundary",
                        "requested_stage_name": end_before_stage_name,
                        "effective_stage_name": stages[current_index].name,
                        "total_stage_count": len(stages),
                    },
                    self.log_file,
                )
                return True

        stage_context: dict[str, str] = {}
        stage_appendices: dict[str, str] = {}

        while current_index < len(stages):
            if end_before_stage_name is not None and stages[current_index].name == end_before_stage_name:
                break
            stage = stages[current_index]
            attempt = retry_counts[current_index] + 1
            if signal_handler is not None and signal_handler.interrupted:
                raise PipelineInterrupted(stage.name, attempt - 1)
            if attempt > stage.max_retries:
                logger.log_to_stderr(f"[{stage.name}] Exhausted retries", "error")
                logger.log_to_json(
                    logger.make_entry(stage.name, "Failed", "Retries exhausted"),
                    self.log_file,
                )
                self._emit_stage_event(
                    stage_event_callback,
                    {
                        "event_type": "stage_failed",
                        "stage_name": stage.name,
                        "attempt": attempt,
                        "error": "Retries exhausted",
                    },
                )
                return False

            logger.log_to_stderr(f"[{stage.name}] Running attempt {attempt}")
            prepared_result = (
                agent.prepare()
                if hasattr(agent, "prepare")
                else AdapterExecutionResult(
                    lifecycle=AdapterStatus.PREPARED,
                    outcome=AdapterOutcome.STARTED,
                )
            )
            running_result = (
                agent.running()
                if hasattr(agent, "running")
                else AdapterExecutionResult(
                    lifecycle=AdapterStatus.RUNNING,
                    outcome=AdapterOutcome.STARTED,
                )
            )
            logger.log_to_json(
                {
                    "timestamp": logger.make_entry(stage.name, "Running", "").timestamp,
                    "stage_name": stage.name,
                    "status": "Running",
                    "message": f"attempt={attempt}",
                    "adapter_lifecycle": prepared_result.lifecycle.value,
                    "adapter_outcome": prepared_result.outcome.value,
                },
                self.log_file,
            )
            self._emit_stage_event(
                stage_event_callback,
                {
                    "event_type": "stage_start",
                    "stage_name": stage.name,
                    "attempt": attempt,
                },
            )
            if hasattr(agent, "log_execution_result"):
                agent.log_execution_result(logger, stage.name, prepared_result)
                agent.log_execution_result(logger, stage.name, running_result)
            else:
                logger.log_to_stderr(
                    f"[{stage.name}][{agent.descriptor.name}] Adapter result: lifecycle={prepared_result.lifecycle.value}, outcome={prepared_result.outcome.value}"
                )
                logger.log_to_stderr(
                    f"[{stage.name}][{agent.descriptor.name}] Adapter result: lifecycle={running_result.lifecycle.value}, outcome={running_result.outcome.value}"
                )

            context = self._build_prompt_context(prompt, stage.name, stage_context)
            stage_prompt, missing_keys = _render_prompt(stage.prompt_template, context)
            appended_context = stage_appendices.get(stage.name, "")
            if appended_context:
                stage_prompt = f"{stage_prompt.rstrip()}\n\n{appended_context}"
            if missing_keys:
                missing = ", ".join(sorted(missing_keys))
                logger.log_to_stderr(
                    f"[{stage.name}] Missing template placeholders defaulted to empty: {missing}",
                    "warning",
                )
            stage_output_log = _stage_log_path(stage.name)
            passed = False
            failure_error: str | None = None
            artifact_payload: dict[str, object] | None = None
            exit_code: int | None = None
            default_hook_listener_usage = bool(agent.descriptor.capabilities.supports_hooks)
            uses_hook_listener = bool(
                getattr(agent, "uses_hook_listener", lambda: default_hook_listener_usage)()
            )
            try:
                if hook_listener is not None and uses_hook_listener:
                    hook_listener.clear_pending_blocks(agent.descriptor.name)
                if stage.contract is not None:
                    artifact_path = _artifact_file_path(stage.name)
                    artifact_path.unlink(missing_ok=True)
                if agent.descriptor.capabilities.supports_hooks:
                    set_active_stage_contract(
                        agent.descriptor.name,
                        stage.name,
                        stage_prompt,
                        stage.contract,
                        attempt=attempt,
                        max_retries=stage.max_retries,
                        keep_artifacts=stage.keep_artifacts,
                    )
                running_process = agent.start(
                    LaunchRequest(
                        prompt=stage_prompt,
                        stage_name=stage.name,
                        log_file=stage_output_log,
                        logger=logger,
                    )
                )
                if signal_handler is not None:
                    signal_handler.set_pid(running_process.pid, running_process.process_group_id)
                    if running_process.pid is not None:
                        child_pids = _get_child_pids(running_process.pid)
                        if child_pids:
                            signal_handler.register_child_pids(child_pids)
                exit_code, output = running_process.wait()
                if signal_handler is not None and signal_handler.interrupted:
                    raise PipelineInterrupted(stage.name, attempt, exit_code)
                if _is_interrupt_exit_code(exit_code):
                    raise PipelineInterrupted(stage.name, attempt, exit_code)
            except PipelineInterrupted:
                logger.log_to_stderr(f"[{stage.name}] Interrupted during attempt {attempt}", "warning")
                logger.log_to_json(
                    logger.make_entry(
                        stage.name,
                        "Interrupted",
                        "Stage interrupted by user",
                        agent_tool=agent.descriptor.name,
                        attempt=attempt,
                        exit_status=exit_code,
                        log_path=stage_output_log,
                    ),
                    self.log_file,
                )
                raise
            except Exception as exc:
                if signal_handler is not None and signal_handler.interrupted:
                    raise PipelineInterrupted(stage.name, attempt, exit_code) from exc
                failure_error = f"Stage execution failed: {exc}"
            else:
                execution_result = (
                    agent.run_result(exit_code, output)
                    if hasattr(agent, "run_result")
                    else AdapterExecutionResult(
                        lifecycle=AdapterStatus.COMPLETED if exit_code == 0 else AdapterStatus.FAILED,
                        outcome=AdapterOutcome.SUCCEEDED if exit_code == 0 else AdapterOutcome.FAILED,
                        exit_code=exit_code,
                        output=output,
                    )
                )
                passed = execution_result.lifecycle == (
                    agent.completed_status() if hasattr(agent, "completed_status") else AdapterStatus.COMPLETED
                )
                if hasattr(agent, "log_execution_result"):
                    agent.log_execution_result(logger, stage.name, execution_result)
                hook_block = (
                    self._pop_hook_block(
                        hook_listener,
                        agent.descriptor.name,
                        wait_for_pending=passed or stage.contract is not None,
                    )
                    if uses_hook_listener
                    else None
                )
                if hook_block is not None:
                    passed = False
                    reason = hook_block.get("reason")
                    details = "Hook blocked agent completion"
                    if isinstance(reason, str) and reason:
                        details = f"{details}: {reason}"
                    failure_error = details
                elif stage.contract is not None:
                    artifact_payload, artifact_error = _validate_stage_artifact(stage.name, stage.contract)
                    if artifact_error is not None:
                        passed = False
                        failure_error = f"Stage artifact validation failed: {artifact_error}"
                    elif artifact_payload is not None:
                        passed = True
                        failure_error = None
                        artifact_status = _artifact_status_value(artifact_payload)
                        route = stage.contract.routes.get(artifact_status) if artifact_status is not None else None
                        logger.log_to_stderr(_format_contract_artifact_output(stage.name, artifact_payload, route))
                        logger.log_to_json(
                            {
                                "timestamp": logger.make_entry(stage.name, "Execution", "").timestamp,
                                "stage_name": stage.name,
                                "status": "ArtifactValidated",
                                "message": "Validated stage artifact",
                                "artifact_path": str(contract_artifact_path(stage.name)),
                                "artifact_status": artifact_status,
                                "artifact_payload": artifact_payload,
                            },
                            self.log_file,
                        )
                        self._emit_stage_event(
                            stage_event_callback,
                            {
                                "event_type": "artifact_validated",
                                "stage_name": stage.name,
                                "artifact_status": artifact_status or "",
                            },
                        )
                elif not passed and failure_error is None and exit_code != 0:
                    failure_error = f"Agent exited with code {exit_code}"
            finally:
                if signal_handler is not None:
                    signal_handler.set_pid(None)
                    signal_handler._child_pids.clear()
                if agent.descriptor.capabilities.supports_hooks:
                    set_active_stage_contract(agent.descriptor.name, None, None, None, keep_artifacts=[])

            if signal_handler is not None and signal_handler.interrupted:
                raise PipelineInterrupted(stage.name, attempt, exit_code)

            if not passed:
                retry_counts[current_index] += 1
                logger.log_to_stderr(f"[{stage.name}] Failed on attempt {attempt}", "warning")
                logger.log_to_json(
                    logger.make_entry(
                        stage.name,
                        "Failed",
                        "Stage failed, retrying",
                        error=failure_error,
                        agent_tool=agent.descriptor.name,
                        attempt=attempt,
                        exit_status=exit_code,
                        log_path=stage_output_log,
                    ),
                    self.log_file,
                )
                logger.log_to_json(
                    logger.make_entry(
                        stage.name,
                        "Execution",
                        "Stage attempt finished",
                        error=failure_error,
                        agent_tool=agent.descriptor.name,
                        attempt=attempt,
                        exit_status=exit_code,
                        log_path=stage_output_log,
                    ),
                    self.log_file,
                )
                self._emit_stage_event(
                    stage_event_callback,
                    {
                        "event_type": "stage_retry",
                        "stage_name": stage.name,
                        "attempt": attempt,
                        "max_retries": stage.max_retries,
                        "error": failure_error or "Stage failed",
                    },
                )
                continue

            # Backup stage artifacts on success (best-effort)
            _backup_stage_artifacts(
                stage_name=stage.name,
                backup_artifacts=stage.backup_artifacts,
                logger=logger,
                log_file=self.log_file,
                timestamp=datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H-%M-%S"),
            )

            next_index, status, decision_source, inject_sections = self._next_stage_index(
                stages,
                stage_lookup,
                current_index,
                artifact_payload,
            )
            if decision_source == "contract_missing_route":
                logger.log_to_stderr(
                    f"[{stage.name}] Artifact status '{status}' has no matching contract route. Add an explicit route such as contract.routes.approved.",
                    "error",
                )
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry(stage.name, "Failed", "").timestamp,
                        "stage_name": stage.name,
                        "status": "Failed",
                        "message": "Contract artifact status has no matching route",
                        "artifact_status": status,
                    },
                    self.log_file,
                )
                return False
            if artifact_payload is not None:
                self._update_stage_context_from_artifact(stage, artifact_payload, stage_context, inject_sections)
            stage_appendices.pop(stage.name, None)

            if decision_source == "contract_route" and artifact_payload is not None and next_index is not None:
                stage_appendices[stages[next_index].name] = self._build_injection_appendix(
                    artifact_payload,
                    inject_sections,
                )
            elif next_index is not None and next_index < len(stages):
                stage_appendices.pop(stages[next_index].name, None)

            retry_counts[current_index] = 0

            logger.log_to_stderr(f"[{stage.name}] Success")
            logger.log_to_json(
                logger.make_entry(
                    stage.name,
                    "Success",
                    "Stage completed",
                    agent_tool=agent.descriptor.name,
                ),
                self.log_file,
            )
            logger.log_to_json(
                logger.make_entry(
                    stage.name,
                    "Execution",
                    "Stage attempt finished",
                    agent_tool=agent.descriptor.name,
                    attempt=attempt,
                    exit_status=exit_code,
                    log_path=stage_output_log,
                ),
                self.log_file,
            )
            self._emit_stage_event(
                stage_event_callback,
                {
                    "event_type": "stage_complete",
                    "stage_name": stage.name,
                    "success": True,
                    "attempt": attempt,
                },
            )
            if artifact_payload is not None and status is not None:
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry(stage.name, "Routing", "").timestamp,
                        "stage_name": stage.name,
                        "status": "Routing",
                        "message": "Resolved next stage from contract status",
                        "artifact_status": status,
                        "next_stage": stages[next_index].name if next_index is not None and next_index < len(stages) else None,
                        "decision_source": decision_source,
                    },
                    self.log_file,
                )
                self._emit_stage_event(
                    stage_event_callback,
                    {
                        "event_type": "routing_decision",
                        "stage_name": stage.name,
                        "next_stage": stages[next_index].name if next_index is not None and next_index < len(stages) else None,
                        "decision_source": decision_source,
                    },
                )
            if decision_source == "contract_terminal":
                return True

            current_end_stage = end_stage_ref.get() if end_stage_ref is not None else end_stage_name
            if current_end_stage is not None and current_end_stage == stage.name:
                logger.log_to_stderr(f"[{stage.name}] Reached requested end_stage, stopping pipeline.")
                logger.log_to_json(
                    logger.make_entry(stage.name, "Execution", "Reached requested end_stage, stopping pipeline."),
                    self.log_file,
                )
                break

            if next_index is None:
                return True
            current_index = next_index

        return True
