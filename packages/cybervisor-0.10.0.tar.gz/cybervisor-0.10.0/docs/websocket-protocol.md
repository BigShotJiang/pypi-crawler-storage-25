# WebSocket Protocol — Cybervisor Daemon Mode

**Protocol Version:** 1.0 (pong `tasks` extension: v2)
**Transport:** WebSocket (text frames carrying JSON)
**Default Endpoint:** `ws://127.0.0.1:8765`

All messages are JSON objects. The server never sends messages to a client that has no active task. Each message carries a `type` field that determines its structure.

---

## Common Fields

Every message includes:

| Field | Type | Description |
|-------|------|-------------|
| `type` | `string` | Message type identifier |
| `task_id` | `string` | UUID of the task this message pertains to (present on server→client events; required on client→server requests) |
| `timestamp` | `string` | ISO 8601 UTC timestamp when the server generated the message |

---

## Client → Server Messages

### `run` — Start a New Task

```json
{
  "type": "run",
  "prompt": "Implement feature X for the auth module",
  "config": "cybervisor.yaml",
  "start_stage": null,
  "task_id": "550e8400-e29b-41d4-a716-446655440000"
}
```

| Field | Required | Description |
|-------|----------|-------------|
| `prompt` | Yes | Non-empty task description / objective |
| `config` | No | Non-empty workspace-relative path to cybervisor.yaml (default: `cybervisor.yaml`); absolute paths and `..` segments are rejected |
| `start_stage` | No | Non-empty stage name to begin at (default: first stage) |
| `task_id` | Yes | Non-empty client-generated UUID for this task |

Malformed `run` messages are rejected with an `error` event using code `invalid_message`; the daemon does not synthesize missing required fields. Config selection is limited to files inside the current workspace so the daemon stays aligned with the documented local workflow.

**Server response:** `run_accepted` on success, `error` if a task is already in progress or the message is invalid.

---

### `set_stop_stage` — Update End Stage Mid-Task

```json
{
  "type": "set_stop_stage",
  "stage": "Verify",
  "task_id": "550e8400-e29b-41d4-a716-446655440000"
}
```

| Field | Required | Description |
|-------|----------|-------------|
| `stage` | Yes | Name of the stage to stop after |
| `task_id` | Yes | The active task to modify |

**Server response:** `stop_stage_updated` or `error`.

---

### `cancel` — Abort Active Task

```json
{
  "type": "cancel",
  "task_id": "550e8400-e29b-41d4-a716-446655440000"
}
```

Sends SIGINT to the active subprocess group. The pipeline aborts gracefully via the existing `PipelineInterrupted` mechanism.

**Server response:** `pipeline_abort` followed by `run_complete`.

---

### `resume` — Reconnect and Replay Events

```json
{
  "type": "resume",
  "task_id": "550e8400-e29b-41d4-a716-446655440000"
}
```

Sent by a client that disconnected mid-task. The server replies with an `event_replay` batch of all buffered events for that task. If the replay payload exceeds the protocol size limit, the daemon sends ordered `event_replay_chunk` frames from `chunk_index: 0` through `chunk_index: chunk_count - 1`. If the task is still running, the resumed socket becomes the live event target for all subsequent updates. If the task already completed, the replay remains available until reconnect TTL cleanup with `live_resume: false`.

**Server response:** `event_replay` (if task found and still active/complete), `error` (if task not found or TTL expired).

---

### `ping` — Keepalive

```json
{
  "type": "ping"
}
```

Client may send `ping` at any time. Server responds with `pong`.

---

## Server → Client Messages

### `run_accepted` — Task Queued

```json
{
  "type": "run_accepted",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "timestamp": "2026-04-02T12:00:00.000Z"
}
```

### `stage_start` — Stage Execution Began

```json
{
  "type": "stage_start",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "stage_name": "Spec",
  "attempt": 1,
  "timestamp": "2026-04-02T12:00:01.000Z"
}
```

### `stage_complete` — Stage Finished

```json
{
  "type": "stage_complete",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "stage_name": "Spec",
  "success": true,
  "attempt": 1,
  "timestamp": "2026-04-02T12:00:05.000Z"
}
```

### `stage_retry` — Stage Failed, Retrying

```json
{
  "type": "stage_retry",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "stage_name": "Spec",
  "attempt": 2,
  "max_retries": 3,
  "error": "Agent exited with code 1",
  "timestamp": "2026-04-02T12:00:05.000Z"
}
```

### `stage_failed` — Stage Exhausted Retries

```json
{
  "type": "stage_failed",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "stage_name": "Spec",
  "attempt": 3,
  "error": "Retries exhausted",
  "timestamp": "2026-04-02T12:00:10.000Z"
}
```

### `artifact_validated` — Contract Artifact Validated

```json
{
  "type": "artifact_validated",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "stage_name": "Review Code",
  "artifact_status": "approved",
  "timestamp": "2026-04-02T12:00:05.000Z"
}
```

### `routing_decision` — Next Stage Resolved

```json
{
  "type": "routing_decision",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "stage_name": "Review Code",
  "next_stage": "Verify",
  "decision_source": "contract_route",
  "timestamp": "2026-04-02T12:00:05.000Z"
}
```

### `pipeline_abort` — Pipeline Aborted

```json
{
  "type": "pipeline_abort",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "reason": "cancelled_by_client",
  "stage_name": "Implement",
  "timestamp": "2026-04-02T12:00:08.000Z"
}
```

### `run_complete` — Task Finished

```json
{
  "type": "run_complete",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "success": true,
  "timestamp": "2026-04-02T12:05:00.000Z"
}
```

### `event_replay` — Historical Events on Resume

```json
{
  "type": "event_replay",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "events": [
    { ... },
    { ... }
  ],
  "live_resume": true,
  "timestamp": "2026-04-02T12:00:10.000Z"
}
```

| Field | Type | Description |
|-------|------|-------------|
| `events` | `array` | Array of server event objects (all types above) |
| `live_resume` | `boolean` | `true` if task is still running; `false` if already complete |

### `stop_stage_updated` — Confirm Stop Stage Change

```json
{
  "type": "stop_stage_updated",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "stage": "Verify",
  "timestamp": "2026-04-02T12:00:06.000Z"
}
```

### `pong` — Keepalive Response

```json
{
  "type": "pong",
  "task_id": "",
  "timestamp": "2026-04-02T12:00:00.000Z"
}
```

Extended pong (protocol v2 — when active tasks are present):
```json
{
  "type": "pong",
  "task_id": "",
  "timestamp": "2026-04-02T12:00:00.000Z",
  "tasks": [
    {
      "task_id": "550e8400-e29b-41d4-a716-446655440000",
      "active_stage": "Spec",
      "attempt": 1,
      "status": "running"
    }
  ]
}
```

Note: `pong` is a connection-level keepalive response, not tied to any specific task. The `task_id` field is included for protocol consistency but is always empty for pong events. The optional `tasks` field contains a snapshot of all active (non-abandoned) tasks in the registry. When no tasks are active, `tasks` is an empty array `[]`. When the daemon predates this extension, `tasks` is absent entirely. The `active_stage` field may be `null` during the window between task registration and first stage execution (displayed as `"initializing"` by status clients). The `status` field values are `"running"` (active, neither completed nor cancelled), `"completed"`, or `"cancelled"`.

### `error` — Protocol or Execution Error

```json
{
  "type": "error",
  "task_id": "550e8400-e29b-41d4-a716-446655440000",
  "code": "task_in_progress",
  "message": "A task is already in progress",
  "timestamp": "2026-04-02T12:00:00.000Z"
}
```

| Error Code | Description |
|------------|-------------|
| `task_in_progress` | Rejected because another task is currently executing |
| `unknown_task` | `task_id` not found (e.g., TTL expired) |
| `not_cancellable` | Task is not in a cancellable state |
| `invalid_message` | Message failed validation, including requests that are no longer valid for the task's current lifecycle state |
| `server_error` | Internal server error |

---

## Connection Lifecycle

1. Client opens WebSocket connection to `ws://host:port`
2. Server accepts connection; no authentication in v1
3. Client sends a message (typically `run` or `resume`)
4. Server and client exchange messages as described above
5. Client disconnects at any time; server continues task execution
6. If client reconnects and sends `resume` with the same `task_id`, server replays buffered history then continues live streaming
7. Task eventually completes; server sends `run_complete`
8. Client may send a new `run` on the same connection after `run_complete`

---

## Large Payload Chunking

Only oversized `event_replay` responses are chunked. Normal live events such as `artifact_validated` are always sent as their native event type.

When replay history exceeds 64 KB, the server emits ordered `event_replay_chunk` frames:

```json
{
  "type": "event_replay_chunk",
  "task_id": "...",
  "chunk_id": "ch-0",
  "chunk_index": 0,
  "chunk_count": 3,
  "events": [ ... ],
  "live_resume": true,
  "timestamp": "2026-04-02T12:00:10.000Z"
}
```

Client reassembles by `chunk_index` ascending until `chunk_count` frames have been received.

---

## Running the Integration Suite

Run the daemon integration suite with:

```bash
uv run pytest --run-integration tests/integration/test_server_ws.py
```

This suite is intended to run in local development and CI/review. It exercises the required daemon acceptance coverage for ping/pong, `set_stop_stage`, cancellation ordering, resume replay, replay chunking, and error handling.

## Example Session

```
Client → Server:
{ "type": "run", "prompt": "build auth feature", "config": "cybervisor.yaml", "task_id": "abc" }

Server → Client:
{ "type": "run_accepted", "task_id": "abc", "timestamp": "..." }

Server → Client:
{ "type": "stage_start", "task_id": "abc", "stage_name": "Spec", "attempt": 1, "timestamp": "..." }

... (client reconnects here) ...

Client → Server:
{ "type": "resume", "task_id": "abc" }

Server → Client:
{ "type": "event_replay", "task_id": "abc", "events": [{ "type": "run_accepted", ... }, { "type": "stage_start", ... }], "live_resume": true, "timestamp": "..." }

Server → Client:
{ "type": "stage_complete", "task_id": "abc", "stage_name": "Spec", "success": true, "attempt": 1, "timestamp": "..." }
...
```
