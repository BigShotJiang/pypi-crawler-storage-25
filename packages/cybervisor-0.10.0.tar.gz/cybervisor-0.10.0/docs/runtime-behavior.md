# Runtime Behavior

For `gemini` and `claude` runs, `cybervisor` performs the following lifecycle:

1. Performs preflight checks.
2. Writes shared hook runtime metadata into `.cybervisor/hooks/`.
3. Persists an exact settings snapshot in `.cybervisor/hooks/`.
4. Patches the active tool settings file so the selected agent invokes the packaged `cybervisor-agent-hook` entry point.
5. Starts the agent in a dedicated process group when supported.
6. Uses the runtime hook to classify autonomy decisions as `approve` or `block`, then adapts those into the selected tool's native hook output so the agent continues autonomously.
7. If the active stage declares a contract, uses the same hook runtime to block completion until the required artifact exists and is structurally valid.
8. Streams agent output into stderr and the stage log file.
9. Re-validates contract artifacts after agent exit, then routes by contract status or explicit `next_stage` when configured.
10. Restores settings and removes runtime files on success, failure, or interrupt.

## Daemon Mode

`cybervisor serve` starts a long-running WebSocket daemon that accepts pipeline runs over a WebSocket connection. The daemon is primarily controlled via the [WebSocket Protocol](websocket-protocol.md).

### Instance Lock

The daemon acquires an exclusive lock via `.cybervisor/daemon.lock` at startup. The lock file stores the PID, working directory, start time, and version. If the lock is held by a live process in the same directory, a new `cybervisor serve` invocation exits with an error. Stale locks (crashed processes) are detected and automatically replaced.

### Run-Daemon Coordination

When `cybervisor run` is invoked (both bare-prompt and explicit `run` subcommand), it checks whether the daemon is reachable before acquiring the local `.cybervisor/instance.lock`. If the daemon is reachable and has any active task (status: `"running"`), `run` exits `1` with a message showing the running task ID and stage, directing the user to `attach` or `cancel`. This prevents `run` instances from executing concurrently with daemon-submitted tasks in the same directory. When the daemon is unreachable, `run` falls back to the standard `.cybervisor/instance.lock` mechanism.

**CWD normalization:** Task matching uses `os.path.realpath()` to resolve symlinks and normalize paths. This means `/workspace`, `/workspace/`, and symlinked paths to the same directory all resolve to the same canonical path, ensuring nested task detection is not bypassed by symlinks or trailing slashes.

### Client Disconnect Behavior

When a WebSocket client disconnects mid-task, the daemon continues executing the pipeline. The task remains in the registry and all events continue to be buffered in the per-task ring buffer.

### Reconnect and Resume

A disconnected client can reconnect and send a `resume` message with the original `task_id`. The daemon replies with an `event_replay` of all buffered history and, if the task is still running, re-registers the socket as the live event target. Reconnect is gated by the `reconnect_ttl_seconds` setting — after that window closes, the task is cleaned up as abandoned.

### Background Daemonization

`cybervisor serve --background` uses double-fork to fully detach from the terminal, redirects stdin/stdout/stderr to `/dev/null`, and releases the controlling terminal. The daemon runs until it receives `SIGINT` or `SIGTERM`, or until the process is otherwise terminated.

### WebSocket Keepalive

The daemon sends WebSocket pings every 30 seconds and expects a pong within 10 seconds. The client can also send `ping` messages at any time and receive `pong` responses.

### Abandoned Task Cleanup

A background task runs a cleanup loop every `reconnect_ttl_seconds / 2` seconds. Tasks with no activity for longer than the TTL are removed from the registry and logged as abandoned.

## Generated Artifacts

- `.cybervisor/logs/cybervisor.log.jsonl`: structured run log
- `.cybervisor/logs/stages/<stage_name>.jsonl`: captured transcript per stage
- `.cybervisor/backups/<stage_name>/<timestamp>/`: versioned backups of stage artifacts after successful completion; each timestamped directory preserves one run's artifacts; never wiped by `reset_run_artifacts()`
- `.cybervisor/contracts/artifacts/*.yaml`: optional stage-result artifacts for contract-enabled stages
- generated contract guidance is derived from each stage's `contract.routes` and contract field definitions in `cybervisor.yaml`

## Client Interaction

The daemon is controlled by client subcommands over the WebSocket connection:

- **`cybervisor status`** — sends a `ping` message; exits `0` if the daemon is reachable, `1` otherwise. When the daemon is reachable, it also reads the extended `pong` response containing active task snapshots (protocol v2) and prints running task IDs and stages. Tasks with status `"completed"` or `"cancelled"` are excluded from the display. For tasks registered but not yet started (active_stage is `null`), the output renders `"initializing"`. Example output when a task is active: `Running task: {task_id} (stage: {stage})`; when no tasks are active: `No active tasks.`; when the daemon is down: `Daemon not reachable at ws://{host}:{port}`. This command is strictly read-only — it never creates or modifies any task.
- **`cybervisor submit`** — sends a `run` message; streams all pipeline events and returns the pipeline exit code on `run_complete`. Accepts a positional prompt argument or reads the task description from stdin when no argument is given (e.g., `printf "task" | cybervisor submit`). If both a positional argument and piped stdin are present, the positional argument takes precedence. Empty or whitespace-only stdin with no positional argument produces a non-zero exit with the message "No prompt provided via argument or stdin."
- **`cybervisor attach`** — sends a `resume` message; replays buffered events (handling chunked payloads automatically), then subscribes to live events until the task reaches a terminal state.
- **`cybervisor cancel`** — sends a `cancel` message; the daemon responds with `pipeline_abort` followed by `run_complete` on the canceler's own connection. The client exits `0` on `pipeline_abort`, `1` on error.
- **`cybervisor logs`** — sends a `resume` message; drains all buffered events and outputs each as a JSON line to stdout.
- **`cybervisor stop-stage`** — sends a `set_stop_stage` message; exits `0` immediately upon receiving `stop_stage_updated` (the daemon does not send `run_complete` after this event).

All client commands accept `--host` and `--port` to override the daemon address. Defaults come from `~/.cybervisor/config.yaml` (`server.host`, `server.port`). The connection timeout is 5 seconds; commands exit `1` with a "daemon not reachable" message on timeout or connection failure.

The full protocol is documented in [WebSocket Protocol](websocket-protocol.md).

## Signals And Cleanup

- `cybervisor` exits with status code `130` on `SIGINT` or `SIGTERM`
- Non-mock runs restore the exact pre-run `.gemini/settings.json` or `.claude/settings.json` content during cleanup
- Hook runtime metadata under `.cybervisor/hooks/` is non-secret; verifier credentials remain in `~/.cybervisor/config.yaml`
