# Demo And Docker

## Manual Demo Workflow

The repository includes a demo bootstrap helper:

```bash
scripts/e2e-demo-project.sh
```

For the standalone `cybervisor init` scaffold in a repo without `.specify/`, use:

```bash
scripts/e2e-demo-simple-project.sh
```

That script:

- creates a fresh temporary standalone workspace instead of reusing the `cybervisor` repo root
- runs `cybervisor init` inside that new workspace so simple-scaffold verification uses an isolated environment
- is the preferred bootstrap for `cybervisor` self-hosted verify-stage smoke tests that should not inherit repo-root state
- supports `--dir` to choose the target workspace path and otherwise defaults to `.tmp/e2e-demo-simple`
- initializes a fresh git repository when `git` is available
- prints the exact `cd` and `cybervisor` command to run manually
- reminds you to install the CLI first if `cybervisor` is not yet on your `PATH`

The prepared demo config includes a contract-enforced `Specify -> Review Spec -> Refine Spec` spec loop, followed by `Plan`, `Refine Plan`, `Tasks`, `Refine Tasks`, `Implement`, and contract-enforced `Review Code` and `Verify E2E` stages. Every demo stage explicitly uses `max_retries: 5`.

Useful demo paths:

- Demo workspace: `.tmp/e2e-demo/`
- Contract artifacts: `.tmp/e2e-demo/.cybervisor/contracts/artifacts/`
- Runtime logs: `.tmp/e2e-demo/.cybervisor/logs/`

## Docker Test Environment

For clean-environment testing, the repository includes `Dockerfile`, `Dockerfile.base`, `Dockerfile.pypi`, and `docker-compose.yaml`.

Run the local-source Docker flow:

```bash
./scripts/run-docker-tests.sh
```

To verify the published PyPI package instead of the local source:

```bash
./scripts/run-docker-tests.sh --pypi
```

The script:

1. Builds the base Docker image.
2. Builds either the local-source or PyPI test image.
3. Prepares a demo workspace on the host with `scripts/e2e-demo-project.sh --agent-tool gemini`.
4. Runs `cybervisor` inside Docker against that mounted workspace, stopping before `Plan` for a shorter smoke test.

## Manual Docker Compose Usage

Build the image:

```bash
docker compose build
```

Prepare a demo project on the host:

```bash
./scripts/e2e-demo-project.sh --agent-tool gemini
```

Run `cybervisor` in the container:

```bash
export CURRENT_UID=$(id -u)
export CURRENT_GID=$(id -g)
export HOST_HOME=$HOME
docker compose run --rm cybervisor \
  cybervisor "Your prompt" --config cybervisor.yaml --end-before "Plan"
```

The `docker-compose.yaml` mounts the host `.tmp/e2e-demo` directory to `/workspace` and mounts agent settings (`~/.gemini` and `~/.claude`) into the matching home path inside the container.
