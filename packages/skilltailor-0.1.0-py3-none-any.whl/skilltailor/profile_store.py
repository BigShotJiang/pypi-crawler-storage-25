from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .errors import ProfileNotFoundError

SCHEMA_VERSION = 1


def _now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def _normalize_interests(interests: Any) -> list[str]:
    if interests is None:
        return []
    if isinstance(interests, str):
        return [part.strip() for part in interests.split(",") if part.strip()]
    if isinstance(interests, list):
        return [str(part).strip() for part in interests if str(part).strip()]
    return []


class LocalProfileStore:
    def __init__(self, config_dir: str | Path | None = None) -> None:
        self.config_dir = Path(config_dir) if config_dir else self.get_default_config_dir()
        self.profiles_path = self.config_dir / "profiles.json"
        self.state_path = self.config_dir / "state.json"
        self._ensure_files()

    @staticmethod
    def get_default_config_dir() -> Path:
        xdg = os.getenv("XDG_CONFIG_HOME")
        if xdg:
            return Path(xdg) / "skilltailor"
        return Path.home() / ".config" / "skilltailor"

    def _ensure_files(self) -> None:
        self.config_dir.mkdir(parents=True, exist_ok=True)
        if not self.profiles_path.exists():
            self._write_json(self.profiles_path, {"schema_version": SCHEMA_VERSION, "profiles": {}})
        if not self.state_path.exists():
            self._write_json(self.state_path, {"schema_version": SCHEMA_VERSION, "active_profile": None})

    def _read_json(self, path: Path) -> dict[str, Any]:
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            if path == self.profiles_path:
                return {"schema_version": SCHEMA_VERSION, "profiles": {}}
            return {"schema_version": SCHEMA_VERSION, "active_profile": None}

    def _write_json(self, path: Path, payload: dict[str, Any]) -> None:
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def list_profiles(self) -> list[dict[str, Any]]:
        data = self._read_json(self.profiles_path)
        profiles = data.get("profiles", {})
        items = [{"profile_id": key, **value} for key, value in profiles.items()]
        return sorted(items, key=lambda item: item.get("updated_at", ""), reverse=True)

    def get_profile(self, profile_id: str) -> dict[str, Any]:
        data = self._read_json(self.profiles_path)
        profiles = data.get("profiles", {})
        if profile_id not in profiles:
            raise ProfileNotFoundError(f"Profile '{profile_id}' was not found.")
        return {"profile_id": profile_id, **profiles[profile_id]}

    def save_profile(self, profile_id: str, profile: dict[str, Any], set_active: bool = False) -> dict[str, Any]:
        if not profile_id or not profile_id.strip():
            raise ValueError("profile_id is required")

        normalized_id = profile_id.strip()
        data = self._read_json(self.profiles_path)
        profiles = data.setdefault("profiles", {})
        existing = profiles.get(normalized_id, {})
        created_at = existing.get("created_at", _now_iso())
        updated_at = _now_iso()

        user_id = str(profile.get("user_id") or existing.get("user_id") or normalized_id).strip()
        record = {
            "user_id": user_id,
            "age": profile.get("age", existing.get("age")),
            "occupation": str(profile.get("occupation", existing.get("occupation", "")) or ""),
            "interests": _normalize_interests(profile.get("interests", existing.get("interests", []))),
            "experience_level": str(profile.get("experience_level", existing.get("experience_level", "")) or ""),
            "created_at": created_at,
            "updated_at": updated_at,
        }
        profiles[normalized_id] = record
        data["schema_version"] = SCHEMA_VERSION
        self._write_json(self.profiles_path, data)

        if set_active:
            self.set_active_profile(normalized_id)

        return {"profile_id": normalized_id, **record}

    def remove_profile(self, profile_id: str) -> None:
        data = self._read_json(self.profiles_path)
        profiles = data.get("profiles", {})
        profiles.pop(profile_id, None)
        self._write_json(self.profiles_path, data)

        state = self._read_json(self.state_path)
        if state.get("active_profile") == profile_id:
            state["active_profile"] = None
            self._write_json(self.state_path, state)

    def reset_profiles(self, clear_all: bool = False) -> None:
        if clear_all:
            self._write_json(self.profiles_path, {"schema_version": SCHEMA_VERSION, "profiles": {}})
        self._write_json(self.state_path, {"schema_version": SCHEMA_VERSION, "active_profile": None})

    def set_active_profile(self, profile_id: str) -> dict[str, Any]:
        profile = self.get_profile(profile_id)
        state = self._read_json(self.state_path)
        state["schema_version"] = SCHEMA_VERSION
        state["active_profile"] = profile_id
        self._write_json(self.state_path, state)
        return profile

    def get_active_profile_id(self) -> str | None:
        state = self._read_json(self.state_path)
        value = state.get("active_profile")
        if not value:
            return None
        return str(value)

    def get_active_profile(self) -> dict[str, Any] | None:
        profile_id = self.get_active_profile_id()
        if not profile_id:
            return None
        try:
            return self.get_profile(profile_id)
        except ProfileNotFoundError:
            return None
