class SkillTailorError(Exception):
    """Base exception for SDK failures."""


class ApiError(SkillTailorError):
    """Raised when remote API calls fail."""


class ProfileNotFoundError(SkillTailorError):
    """Raised when a local profile cannot be resolved."""


class ConfigurationError(SkillTailorError):
    """Raised when SDK configuration is invalid."""
