from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class SkillResult:
    skill_id: str
    skill_name: str
    skill_description: str
    author: str
    category: str
    stars: int
    skill_url: str
    score: float
    score_breakdown: dict[str, Any] = field(default_factory=dict)
    retrieval_sources: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "SkillResult":
        return cls(
            skill_id=str(payload.get("skill_id", "")),
            skill_name=str(payload.get("skill_name", "")),
            skill_description=str(payload.get("skill_description", "")),
            author=str(payload.get("author", "")),
            category=str(payload.get("category", "")),
            stars=int(payload.get("stars", 0) or 0),
            skill_url=str(payload.get("skill_url", "")),
            score=float(payload.get("score", 0.0) or 0.0),
            score_breakdown=dict(payload.get("score_breakdown", {}) or {}),
            retrieval_sources=list(payload.get("retrieval_sources", []) or []),
            tags=list(payload.get("tags", []) or []),
            raw=payload,
        )


@dataclass(slots=True)
class RecommendationDebug:
    artifact_version: str = "unknown"
    semantic_candidates: int = 0
    keyword_candidates: int = 0
    fused_candidates: int = 0
    latency_ms: float = 0.0
    profile_used: bool = False
    profile_completeness: float = 0.0

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "RecommendationDebug":
        return cls(
            artifact_version=str(payload.get("artifact_version", "unknown")),
            semantic_candidates=int(payload.get("semantic_candidates", 0) or 0),
            keyword_candidates=int(payload.get("keyword_candidates", 0) or 0),
            fused_candidates=int(payload.get("fused_candidates", 0) or 0),
            latency_ms=float(payload.get("latency_ms", 0.0) or 0.0),
            profile_used=bool(payload.get("profile_used", False)),
            profile_completeness=float(payload.get("profile_completeness", 0.0) or 0.0),
        )


@dataclass(slots=True)
class RecommendationResponse:
    query: str
    top_k: int
    results: list[SkillResult]
    debug: RecommendationDebug
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "RecommendationResponse":
        results = [SkillResult.from_dict(item) for item in payload.get("results", [])]
        debug = RecommendationDebug.from_dict(dict(payload.get("debug", {}) or {}))
        return cls(
            query=str(payload.get("query", "")),
            top_k=int(payload.get("top_k", 0) or 0),
            results=results,
            debug=debug,
            raw=payload,
        )
