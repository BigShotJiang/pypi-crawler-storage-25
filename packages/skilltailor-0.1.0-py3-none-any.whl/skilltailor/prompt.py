from __future__ import annotations

from typing import Any


def _ask(prompt: str, default: str = "") -> str:
    rendered = f"{prompt}"
    if default:
        rendered += f" [{default}]"
    rendered += ": "
    value = input(rendered).strip()
    return value or default


def _parse_interests(raw: str) -> list[str]:
    return [item.strip() for item in raw.split(",") if item.strip()]


def collect_profile_interactive(profile_id: str | None = None) -> tuple[str, dict[str, Any]]:
    chosen_profile_id = _ask("Profile name", profile_id or "default")
    user_id = _ask("User id", chosen_profile_id)
    occupation = _ask("Occupation", "")
    interests = _parse_interests(_ask("Interests (comma separated)", ""))
    experience_level = _ask("Experience level", "")
    age_raw = _ask("Age (optional)", "")

    age: int | None = None
    if age_raw:
        try:
            age = int(age_raw)
        except ValueError:
            age = None

    payload = {
        "user_id": user_id,
        "occupation": occupation,
        "interests": interests,
        "experience_level": experience_level,
        "age": age,
    }
    return chosen_profile_id, payload
