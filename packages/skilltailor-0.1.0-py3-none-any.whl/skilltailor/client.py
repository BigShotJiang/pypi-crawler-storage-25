from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen

from .errors import ApiError, ConfigurationError, ProfileNotFoundError
from .models import RecommendationResponse
from .profile_store import LocalProfileStore
from .prompt import collect_profile_interactive


class SkillTailorClient:
    def __init__(
        self,
        base_url: str | None = None,
        timeout: int = 30,
        profile_store: LocalProfileStore | None = None,
    ) -> None:
        self.base_url = (base_url or os.getenv("SKILLTAILOR_BASE_URL") or "http://10.201.186.15/api").rstrip("/")
        self.timeout = timeout
        self.profile_store = profile_store or LocalProfileStore()
        self.no_prompt = os.getenv("SKILLTAILOR_NO_PROMPT", "false").lower() == "true"

    def _request_json(self, path: str, payload: dict[str, Any], method: str = "POST") -> dict[str, Any]:
        body = json.dumps(payload).encode("utf-8")
        request = Request(
            urljoin(f"{self.base_url}/", path.lstrip("/")),
            data=body,
            headers={"Content-Type": "application/json", "User-Agent": "skilltailor-python-sdk/0.1"},
            method=method,
        )
        try:
            with urlopen(request, timeout=self.timeout) as response:
                raw = response.read().decode("utf-8")
        except HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace") if hasattr(exc, "read") else str(exc)
            raise ApiError(f"HTTP {exc.code} from {path}: {detail}") from exc
        except URLError as exc:
            raise ApiError(f"Network error calling {path}: {exc.reason}") from exc

        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ApiError(f"Invalid JSON from {path}: {raw[:200]}") from exc

    def upsert_profile(
        self,
        profile: dict[str, Any],
        profile_id: str | None = None,
        set_active: bool = True,
    ) -> dict[str, Any]:
        resolved_profile_id = profile_id or str(profile.get("profile_id") or profile.get("user_id") or "").strip()
        if not resolved_profile_id:
            raise ConfigurationError("profile_id or user_id is required to store a profile.")

        local = self.profile_store.save_profile(resolved_profile_id, profile, set_active=set_active)
        payload = {
            "user_id": local["user_id"],
            "age": local.get("age"),
            "occupation": local.get("occupation", ""),
            "interests": local.get("interests", []),
            "experience_level": local.get("experience_level", ""),
        }
        remote = self._request_json("/user/profile", payload=payload, method="POST")
        return {"local_profile": local, "remote": remote}

    def init_profile_interactive(self, profile_id: str | None = None, set_active: bool = True) -> dict[str, Any]:
        chosen_profile_id, profile = collect_profile_interactive(profile_id=profile_id)
        result = self.upsert_profile(profile=profile, profile_id=chosen_profile_id, set_active=set_active)
        return result["local_profile"]

    def list_profiles(self) -> list[dict[str, Any]]:
        return self.profile_store.list_profiles()

    def get_profile(self, profile_id: str) -> dict[str, Any]:
        return self.profile_store.get_profile(profile_id)

    def use_profile(self, profile_id: str) -> dict[str, Any]:
        return self.profile_store.set_active_profile(profile_id)

    def remove_profile(self, profile_id: str) -> None:
        self.profile_store.remove_profile(profile_id)

    def reset_profiles(self, clear_all: bool = False) -> None:
        self.profile_store.reset_profiles(clear_all=clear_all)

    def recommend(
        self,
        query: str,
        top_k: int = 10,
        user_id: str | None = None,
        profile_id: str | None = None,
        category: str | list[str] | None = None,
        tags: list[str] | None = None,
        prompt_if_missing: bool = False,
    ) -> RecommendationResponse:
        if not query or not query.strip():
            raise ConfigurationError("query is required.")

        resolved_user_id = user_id
        if not resolved_user_id and profile_id:
            profile = self.profile_store.get_profile(profile_id)
            resolved_user_id = str(profile.get("user_id") or "") or None

        if not resolved_user_id:
            active = self.profile_store.get_active_profile()
            if active:
                resolved_user_id = str(active.get("user_id") or "") or None

        if not resolved_user_id and prompt_if_missing and not self.no_prompt:
            local_profile = self.init_profile_interactive()
            resolved_user_id = str(local_profile.get("user_id") or "") or None

        payload: dict[str, Any] = {
            "query": query,
            "top_k": top_k,
            "filters": {
                "category": [category] if isinstance(category, str) else category or [],
                "tags": tags or [],
            },
        }
        if resolved_user_id:
            payload["user_id"] = resolved_user_id

        response = self._request_json("/agent/recommend", payload=payload, method="POST")
        return RecommendationResponse.from_dict(response)

    def download(
        self,
        skill_url: str,
        target_dir: str | Path = "./my_skills",
        skill_name: str | None = None,
    ) -> Path:
        if not skill_url or not skill_url.strip():
            raise ConfigurationError("skill_url is required.")

        response = self._request_json(
            "/agent/download-skill",
            payload={
                "skill_url": skill_url,
                "skill_name": skill_name,
            },
            method="POST",
        )
        download_url = str(response.get("download_url") or "")
        if not download_url:
            raise ApiError("Download response did not include download_url.")

        file_bytes = self._download_bytes(download_url)
        target_path = Path(target_dir)
        target_path.mkdir(parents=True, exist_ok=True)
        local_file = target_path / Path(download_url).name
        local_file.write_bytes(file_bytes)
        return local_file

    def _download_bytes(self, path: str) -> bytes:
        request = Request(
            urljoin(f"{self.base_url}/", path.lstrip("/")),
            headers={"User-Agent": "skilltailor-python-sdk/0.1"},
        )
        try:
            with urlopen(request, timeout=self.timeout) as response:
                return response.read()
        except HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace") if hasattr(exc, "read") else str(exc)
            raise ApiError(f"HTTP {exc.code} downloading {path}: {detail}") from exc
        except URLError as exc:
            raise ApiError(f"Network error downloading {path}: {exc.reason}") from exc

    def recommend_with_profile(
        self,
        query: str,
        profile: dict[str, Any] | None = None,
        profile_id: str | None = None,
        top_k: int = 10,
        category: list[str] | None = None,
        tags: list[str] | None = None,
    ) -> RecommendationResponse:
        resolved_user_id: str | None = None

        if profile is not None:
            saved = self.upsert_profile(profile=profile, profile_id=profile_id)
            resolved_user_id = str(saved["local_profile"].get("user_id") or "") or None
        elif profile_id is not None:
            local_profile = self.profile_store.get_profile(profile_id)
            resolved_user_id = str(local_profile.get("user_id") or "") or None
        else:
            active = self.profile_store.get_active_profile()
            if active:
                resolved_user_id = str(active.get("user_id") or "") or None

        if not resolved_user_id:
            raise ProfileNotFoundError(
                "No profile was provided and no active local profile exists. "
                "Create one with init_profile_interactive() or upsert_profile()."
            )

        return self.recommend(
            query=query,
            top_k=top_k,
            user_id=resolved_user_id,
            category=category,
            tags=tags,
        )
