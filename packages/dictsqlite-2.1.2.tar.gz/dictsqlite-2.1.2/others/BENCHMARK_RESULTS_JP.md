# DictSQLite v4.1 包括的ベンチマーク結果

**測定日**: 2025年  
**バージョン**: DictSQLite v4.1 (Rust実装)  
**測定回数**: 各ベンチマーク5回実行（ウォームアップ1回）

---

## サマリー

**総ベンチマーク数**: 27  
**平均スループット**: 1,192,722 ops/sec  
**中央値**: 743,225 ops/sec  
**最大**: 4,612,142 ops/sec  
**最小**: 2 ops/sec

---

## Top 5 最速操作

1. **Delete操作** (5K items): **4,612,142 ops/sec**
2. **Contains Check** (10K items): **3,769,566 ops/sec**
3. **LRU読み込み** (エビクション後、5K items): **2,913,405 ops/sec**
4. **バッチGet** (10K items): **2,563,548 ops/sec**
5. **Single Get** (10K items): **2,358,022 ops/sec**

---

## 詳細ベンチマーク結果

### 1. 基本操作 (Basic Operations)

| 操作 | Ops/sec | 時間 (ms) | 標準偏差 |
|:-----|--------:|----------:|---------:|
| Single Set (10K items) | 1,168,501 | 8.56 | 0.11 |
| Single Get (10K items) | 2,358,022 | 4.24 | 0.28 |
| Contains Check (10K items) | 3,769,566 | 2.65 | 0.03 |
| Delete (5K items) | 4,612,142 | 1.08 | 0.02 |
| keys() (1K items) | 11,756 | 0.09 | 0.01 |
| items() (1K items) | 6,429 | 0.16 | 0.01 |

**分析**: 
- 読み取り操作が書き込みより約2倍高速
- Contains checkは最も高速な操作の1つ
- Deleteも非常に高速（4.6M ops/sec）

### 2. バルク操作 (Bulk Operations)

| 操作 | Ops/sec | 時間 (ms) | 標準偏差 |
|:-----|--------:|----------:|---------:|
| update() Bulk Insert (50K items) | 2,345,680 | 21.32 | 0.16 |
| Batch Get (10K items) | 2,563,548 | 3.90 | 0.11 |
| pop() (5K items) | 334,046 | 14.97 | 0.30 |
| setdefault() (5K items) | 1,268,622 | 3.94 | 0.35 |

**分析**:
- バルクインサートは50,000アイテムを21.32msで処理（2.3M ops/sec）
- バッチGetも高速（2.5M ops/sec）
- pop()はやや遅いが許容範囲（334K ops/sec）

### 3. Pickle操作 (Pickle Serialization)

| 操作 | Ops/sec | 時間 (ms) | 標準偏差 |
|:-----|--------:|----------:|---------:|
| Simple Dict Write (5K items) | 518,200 | 9.65 | 0.06 |
| Simple Dict Read (5K items) | 1,055,519 | 4.74 | 0.10 |
| Complex Nested Write (1K items) | 189,609 | 5.27 | 0.09 |
| Complex Nested Read (1K items) | 494,238 | 2.02 | 0.03 |
| Large Binary Write (500 x 10KB) | 7,436 | 67.24 | 0.04 |
| Large Binary Read (500 x 10KB) | 687,249 | 0.73 | 0.04 |

**分析**:
- シンプルなオブジェクトは高速（読み込み1M ops/sec）
- 複雑なネストオブジェクトでも十分な速度（読み込み494K ops/sec）
- 大きなバイナリデータ（10KB）の書き込みはやや遅い（7.4K ops/sec）が、読み込みは高速（687K ops/sec）

### 4. 暗号化操作 (AES-256-GCM Encryption)

| 操作 | Ops/sec | 時間 (ms) | 標準偏差 |
|:-----|--------:|----------:|---------:|
| Encrypted Set (10K items) | 600,636 | 16.65 | 0.05 |
| Encrypted Get (10K items) | 1,706,806 | 5.86 | 0.28 |
| Encrypted Bulk Insert (20K items) | 1,789,830 | 11.17 | 0.17 |
| Encrypted Pickle Write (2K objects) | 323,309 | 6.19 | 0.05 |
| Encrypted Pickle Read (2K objects) | 743,225 | 2.69 | 0.05 |

**暗号化オーバーヘッド分析**:
- Set: 1,168,501 → 600,636 ops/sec (**48.6%減少**)
- Get: 2,358,022 → 1,706,806 ops/sec (**27.6%減少**)
- Bulk: 2,345,680 → 1,789,830 ops/sec (**23.7%減少**)

**分析**:
- 暗号化ありでも60万ops/sec以上の書き込み性能
- 読み込みは170万ops/secと高速
- 暗号化オーバーヘッドは20-50%程度で許容範囲

### 5. 永続化モード (Persistence Modes)

| モード | 操作 | Ops/sec | 時間 (ms) |
|:-------|:-----|--------:|----------:|
| Memory | Write (10K) | 1,378,988 | 7.25 |
| Lazy | Write (10K) | 1,316,355 | 7.60 |
| Lazy | Flush | 2 | 452.16 |
| WriteThrough | Write (1K) | 20,400 | 49.02 |

**分析**:
- **Memory** と **Lazy** モードはほぼ同等の高速性能（1.3M ops/sec）
- **WriteThrough** は即座にディスク書き込みするため遅い（20K ops/sec）
- Lazy Flushは10,000アイテムを452msで永続化

**モード選択ガイド**:
- 高速性重視 → **Memory** または **Lazy**
- データ安全性重視 → **WriteThrough**
- バランス重視 → **Lazy** + 定期flush

### 6. LRUエビクション (LRU Eviction)

| 操作 | Ops/sec | 時間 (ms) | 標準偏差 |
|:-----|--------:|----------:|---------:|
| Write with Eviction (cap=1000, writes=5000) | 19,975 | 250.32 | 16.33 |
| Read After Eviction (5K items) | 2,913,405 | 1.72 | 0.13 |

**分析**:
- エビクション発生時も約20K ops/sec維持
- エビクション後の読み込みは高速（2.9M ops/sec）
- ストレージフォールバックが正常に機能

---

## パフォーマンス特性まとめ

### 🚀 高速な操作（1M ops/sec以上）

1. Delete操作: **4.6M ops/sec**
2. Contains check: **3.8M ops/sec**
3. LRU読み込み: **2.9M ops/sec**
4. バッチGet: **2.6M ops/sec**
5. 単一Get: **2.4M ops/sec**
6. バルクインサート: **2.3M ops/sec**
7. 暗号化Bulk: **1.8M ops/sec**
8. 暗号化Get: **1.7M ops/sec**
9. Memory Write: **1.4M ops/sec**
10. Lazy Write: **1.3M ops/sec**

### ⚡ 中速の操作（100K - 1M ops/sec）

- setdefault(): **1.3M ops/sec**
- 単一Set: **1.2M ops/sec**
- Pickle Simple Read: **1.1M ops/sec**
- Large Binary Read: **687K ops/sec**
- 暗号化Pickle Read: **743K ops/sec**
- 暗号化Set: **601K ops/sec**
- Pickle Simple Write: **518K ops/sec**
- Pickle Complex Read: **494K ops/sec**
- pop(): **334K ops/sec**
- 暗号化Pickle Write: **323K ops/sec**

### 🐌 低速の操作（100K ops/sec未満）

- Pickle Complex Write: **190K ops/sec**
- WriteThrough Write: **20K ops/sec**
- LRU Eviction Write: **20K ops/sec**
- keys(): **12K ops/sec**
- Large Binary Write: **7.4K ops/sec**
- items(): **6.4K ops/sec**
- Lazy Flush: **2 ops/sec** (10,000アイテム一括処理のため)

---

## 最適化のポイント

### 1. モード選択

**高速性が最優先の場合:**
```python
db = DictSQLiteV4(path, persist_mode="lazy")
# 1.3M ops/sec
```

**データ損失を絶対に避けたい場合:**
```python
db = DictSQLiteV4(path, persist_mode="writethrough")
# 20K ops/sec だが即座に永続化
```

### 2. バルク操作の活用

単一操作ではなくバルク操作を使用:
```python
# 遅い: 1.2M ops/sec
for item in items:
    db[key] = value

# 高速: 2.3M ops/sec
db.update(items)
```

### 3. 暗号化の使用判断

暗号化が不要なら無効化して性能向上:
- 暗号化なし: 1.2M ops/sec (Set)
- 暗号化あり: 600K ops/sec (Set)
- **約2倍の性能差**

### 4. Pickle最適化

- シンプルなオブジェクトを使用（複雑なネストを避ける）
- 大きなバイナリは分割して保存
- 読み込みは書き込みの約2倍高速

---

## 結論

DictSQLite v4.1は以下の優れた性能特性を示しています:

✅ **読み取り性能**: 最大4.6M ops/sec（Delete）、平均2-3M ops/sec  
✅ **書き込み性能**: 最大2.3M ops/sec（Bulk）、平均1-1.5M ops/sec  
✅ **暗号化**: オーバーヘッド20-50%で高セキュリティ  
✅ **LRUエビクション**: 透過的で高速（読み込み2.9M ops/sec）  
✅ **永続化**: 柔軟なモード選択（Memory/Lazy/WriteThrough）

**推奨用途**:
- 高速キャッシュ: Memory/Lazyモード
- トランザクション処理: WriteThroughモード
- セキュアストレージ: 暗号化有効化
- 大規模データ: LRUエビクションで自動管理

---

**ベンチマーク環境**: Ubuntu, Python 3.12, Rust 1.x (release build)  
**測定ツール**: tests/benchmark_comprehensive.py
