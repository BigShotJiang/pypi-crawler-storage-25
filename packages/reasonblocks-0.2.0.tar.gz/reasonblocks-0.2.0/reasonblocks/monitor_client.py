"""HTTP client for the rb-api monitor-telemetry surface.

This is the long-term replacement for the legacy ``SQLiteMonitorSink``.
All scoring and persistence live on the server now (rb-api's
``/monitor/...`` endpoints); the SDK just ships one step at a time and
receives the computed score bundle in the response.

Same method surface as the legacy sink so call-sites can migrate with a
single import change:

    # before
    from reasonblocks import SQLiteMonitorSink
    sink = SQLiteMonitorSink("monitor_data.db")

    # after
    from reasonblocks import MonitorClient
    sink = MonitorClient(api_key="rb_live_...")
    # base_url defaults to https://rb-api.reasonblocks.com; pass an
    # explicit base_url only for local dev or self-hosted deployments.

``start_run`` / ``finish_run`` / ``log_step`` are no-ops on transport
error so a dropped connection to rb-api doesn't break the agent loop.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

import httpx

from reasonblocks._settings import DEFAULT_BASE_URL, DEFAULT_TIMEOUT

logger = logging.getLogger("reasonblocks.monitor_client")


class MonitorClient:
    """Thin HTTP client over ``rb-api``'s ``/monitor/...`` routes."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        from reasonblocks.client import _mask_api_key, _validate_api_key
        self._api_key = _validate_api_key(api_key)
        self._mask_api_key = _mask_api_key
        self._base = base_url.rstrip("/")
        self._headers = {"Authorization": f"Bearer {self._api_key}"}
        self._timeout = timeout
        # Persistent client -- every step logs through here, so keep the
        # TCP connection warm instead of reconnecting per call.
        # base_url is set at the client level so httpx refuses to follow
        # cross-origin redirects (would otherwise leak the bearer token).
        self._client = httpx.Client(
            base_url=self._base,
            headers=self._headers,
            timeout=timeout,
        )

    def __repr__(self) -> str:
        return f"MonitorClient(api_key={self._mask_api_key(self._api_key)})"

    def __getstate__(self) -> dict[str, Any]:
        state = dict(self.__dict__)
        state["_api_key"] = None
        state["_headers"] = None
        state["_client"] = None
        return state

    def __setstate__(self, state: dict[str, Any]) -> None:
        raise NotImplementedError(
            "MonitorClient instances are not pickle-safe; construct a new "
            "instance with a fresh api_key instead."
        )

    # ------------------------------------------------------------------
    # Run lifecycle
    # ------------------------------------------------------------------

    def start_run(
        self,
        *,
        run_id: str,
        agent_name: str = "",
        task: str = "",
        model: str = "",
        framework: str = "",
        codebase_id: str = "",
        org_id: str = "default",
        project_id: str = "default",
        task_profile: str = "coding",
        metadata: Optional[dict[str, Any]] = None,
    ) -> Optional[dict[str, Any]]:
        """Register the run. Returns the server response dict, or ``None``
        if the call failed (so callers / emitters can retry).

        ``org_id`` + ``project_id`` are the multi-tenant scope. Both default
        to ``"default"`` so existing SDKs that don't pass them continue to
        land in the default scope; rb-api seeds matching directory rows.
        """
        return self._post("/monitor/runs", {
            "run_id": run_id,
            "agent_name": agent_name,
            "task": task,
            "model": model,
            "framework": framework,
            "codebase_id": codebase_id,
            "org_id": org_id,
            "project_id": project_id,
            "task_profile": task_profile,
            "metadata": metadata or {},
        })

    def finish_run(self, *, run_id: str, outcome: str = "") -> Optional[dict[str, Any]]:
        """Mark the run complete. Returns the server response, or ``None``
        on transport failure."""
        return self._post(f"/monitor/runs/{run_id}/finish", {"outcome": outcome})

    # ------------------------------------------------------------------
    # Step logging — server computes the score bundle for us
    # ------------------------------------------------------------------

    def log_step(
        self,
        *,
        run_id: str,
        step_index: int,
        action: Optional[str] = None,
        action_input: Optional[str] = None,
        thought: Optional[str] = None,
        observation: Optional[str] = None,
        is_error: bool = False,
        tokens: int = 0,
        input_tokens: int = 0,
        output_tokens: int = 0,
        cache_read_tokens: int = 0,
        step_model: str = "",
        injections: Optional[list[str]] = None,
        injection_sources: Optional[list[str]] = None,
        intervention_texts: Optional[list[str]] = None,
        monitors_fired: Optional[list[str]] = None,
        failure_type: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
        # Accepted for backward-compat with the legacy ``SQLiteMonitorSink``
        # signature — the server computes fresh scores so these are ignored.
        scores: Optional[dict[str, float]] = None,
        total_score: Optional[float] = None,
        fired: Optional[list[str]] = None,
    ) -> Optional[dict[str, Any]]:
        """Log one step. Returns the server-computed ``{scores, total_score,
        fired}`` bundle, or ``None`` if the call failed."""
        del scores, total_score, fired  # server recomputes authoritatively
        body: dict[str, Any] = {
            "step_index": step_index,
            "action": action,
            "action_input": action_input,
            "thought": thought,
            "observation": observation,
            "is_error": bool(is_error),
            "tokens": int(tokens or 0),
            "input_tokens": int(input_tokens or 0),
            "output_tokens": int(output_tokens or 0),
            "cache_read_tokens": int(cache_read_tokens or 0),
            "step_model": step_model or "",
            "injections":         list(injections or []),
            "injection_sources":  list(injection_sources or []),
            "intervention_texts": list(intervention_texts or []),
            "monitors_fired":     list(monitors_fired or []),
            "failure_type": failure_type,
            "metadata": metadata or {},
        }
        return self._post(f"/monitor/runs/{run_id}/steps", body)

    # ------------------------------------------------------------------
    # Read helpers (same shape the dashboard uses, handy for scripts)
    # ------------------------------------------------------------------

    def list_runs(self, *, limit: int = 200) -> list[dict[str, Any]]:
        return self._get(f"/monitor/runs?limit={limit}") or []

    def get_run(self, run_id: str) -> Optional[dict[str, Any]]:
        return self._get(f"/monitor/runs/{run_id}")

    def health_summary(self) -> Optional[dict[str, Any]]:
        return self._get("/monitor/health-summary")

    def close(self) -> None:
        """Release the underlying HTTP client."""
        self._client.close()

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    def _post(self, path: str, json_body: dict[str, Any]) -> Optional[dict[str, Any]]:
        try:
            r = self._client.post(path, json=json_body)
            r.raise_for_status()
            if r.status_code == 204 or not r.content:
                return {}
            return r.json()
        except Exception as exc:
            logger.warning("POST %s failed: %s", path, exc)
            return None

    def _get(self, path: str) -> Any:
        try:
            r = self._client.get(path)
            r.raise_for_status()
            return r.json()
        except Exception as exc:
            logger.warning("GET %s failed: %s", path, exc)
            return None
