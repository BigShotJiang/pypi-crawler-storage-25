"""Convenience helpers promoted from /entelligence/harness.py into the SDK.

These were duplicated across our internal benchmarks for months -- moving
them here so all framework integrations (LangChain, OpenAI Agents,
Claude, AI SDK) can use the same shapes:

  - structural_summary(path, content)        -- default file summarizer
  - prewarm_repo(memory, files)              -- bulk-store summaries
  - extract_findings(review, *, source_pr)   -- parse a JSON review into
                                                store_many-ready records
  - auto_store_pr_findings(memory, pr, ...)  -- extract + store in one step

Same defaults / dedupe rules / 400-char cap as the TS port at
`/ai-sdk/src/helpers.ts`. Cross-language parity guaranteed by mirroring
the same caps and dedupe key.
"""

from __future__ import annotations

import json
import re
from typing import Any, Callable, Iterable, Optional

from reasonblocks.codebase_memory import CodebaseMemory


# ---------------------------------------------------------------------------
# structural_summary
# ---------------------------------------------------------------------------

_DOC_RE     = re.compile(r'"""(.*?)"""', re.S)
_CLASS_RE   = re.compile(r"^\s*class\s+(\w+)", re.M)
_DEF_RE     = re.compile(r"^\s*def\s+(\w+)", re.M)
_WS_RE      = re.compile(r"\s+")


def structural_summary(path: str, source: str) -> str:
    """Default file summarizer: extract module docstring + class names +
    function names. Caps output at 400 chars to match what we store in
    memory for prewarmed file summaries."""
    lines = source.split("\n")
    n = len(lines)
    head = "\n".join(lines[:15])
    doc_match = _DOC_RE.search(head)
    doc = _WS_RE.sub(" ", doc_match.group(1)).strip()[:120] if doc_match else ""
    classes = _CLASS_RE.findall(source)
    funcs   = _DEF_RE.findall(source)
    parts: list[str] = [f"{path} ({n} lines)"]
    if doc:
        parts.append(f"doc: {doc}")
    if classes:
        parts.append(f"classes: {', '.join(classes[:8])}")
    if funcs:
        parts.append(f"funcs: {', '.join(funcs[:12])}")
    return " | ".join(parts)[:400]


# ---------------------------------------------------------------------------
# prewarm_repo
# ---------------------------------------------------------------------------

FileLike = tuple[str, str]  # (path, content)


def prewarm_repo(
    memory: CodebaseMemory,
    files: Iterable[FileLike],
    *,
    summarize: Optional[Callable[[str, str], str]] = None,
) -> int:
    """Bulk-store structural summaries of `files` into `memory`. Returns
    the count actually persisted.

    The caller decides which files to pass -- scan logic (git tree, fs
    walk, gh API, etc.) is intentionally out of scope. Pair with the
    caller's existing repo-discovery code.
    """
    summarizer = summarize or structural_summary
    findings: list[dict[str, Any]] = []
    for path, content in files:
        findings.append({
            "content":      summarizer(path, content),
            "file_path":    path,
            "finding_type": "file_summary",
        })
    if not findings:
        return 0
    return memory.store_many(findings)


# ---------------------------------------------------------------------------
# extract_findings
# ---------------------------------------------------------------------------

def _parse_review(review: Any) -> Optional[dict]:
    """Normalize the JSON review (string OR dict) into a dict. Strips
    [FINISHED] prefix and ```json ...``` fences if present."""
    if review is None:
        return None
    if isinstance(review, dict):
        return review
    if not isinstance(review, str):
        return None
    # Cap input before regex — a hostile / runaway LLM response could
    # otherwise feed gigabytes of text into the ``\{.*\}`` greedy
    # multiline match below and stall the parser.
    s = review[:1_000_000].strip()
    if s.startswith("[FINISHED]"):
        s = s[len("[FINISHED]"):].strip()
    if s.startswith("```"):
        s = re.sub(r"^```(?:json)?\s*", "", s)
        s = re.sub(r"\s*```\s*$", "", s)
    m = re.search(r"\{.*\}", s, re.S)
    if not m:
        return None
    try:
        obj = json.loads(m.group(0))
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None


def extract_findings(
    review: Any,
    *,
    source_pr: Any = None,
    source_pr_title: Optional[str] = None,
    max_findings: int = 10,
) -> list[dict[str, Any]]:
    """Parse the agent's final JSON review and shape its `findings` array
    into records that `memory.store_many` accepts.

    Same rules as the TS port (`ai-sdk/src/helpers.ts:extractFindings`):
      - skip findings with no `file` or fewer than 10 chars of content
      - dedupe by `file:line:title-prefix` key
      - cap stored content at 400 chars
      - cap findings at `max_findings` (default 10) so one verbose review
        doesn't flood memory
    """
    parsed = _parse_review(review)
    if not parsed or not isinstance(parsed.get("findings"), list):
        return []

    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for raw in parsed["findings"]:
        if not isinstance(raw, dict):
            continue
        fp = (raw.get("file") or "").strip()
        if not fp:
            continue
        title = (raw.get("title") or "").strip()
        desc  = (raw.get("description") or "").strip()
        sev   = (raw.get("severity") or "").strip()
        line  = raw.get("line")
        line_str = "-" if line is None else str(line)
        key = f"{fp}:{line_str}:{title[:40]}"
        if key in seen:
            continue
        seen.add(key)

        parts: list[str] = []
        if sev:   parts.append(f"[{sev}]")
        if title: parts.append(title)
        if desc:  parts.extend(["--", desc])
        content = " ".join(parts)[:400]
        if len(content) < 10:
            continue

        meta: dict[str, Any] = {"auto_extracted": True}
        if source_pr is not None:
            meta["source_pr"] = source_pr
        if source_pr_title:
            meta["source_pr_title"] = source_pr_title[:100]
        if line is not None:
            # Coerce to a bounded int — review JSON sometimes ships
            # ``"line"`` as a stringy "23" or as a wildly large number;
            # silently drop the field rather than carry junk metadata
            # downstream. Cap at 1_000_000 to protect any consumer that
            # pre-allocates by line number.
            #
            # ``OverflowError`` is in the except set because
            # ``int(float("inf"))`` raises that, not ValueError.
            try:
                line_int = int(line)
            except (TypeError, ValueError, OverflowError):
                line_int = None
            if line_int is not None and 0 <= line_int <= 1_000_000:
                meta["line"] = line_int

        out.append({
            "content":      content,
            "file_path":    fp,
            "finding_type": "review_note",
            "metadata":     meta,
        })
        if len(out) >= max_findings:
            break
    return out


# ---------------------------------------------------------------------------
# auto_store_pr_findings -- one-call wrapper around extract + store_many
# ---------------------------------------------------------------------------

def auto_store_pr_findings(
    memory: CodebaseMemory,
    pr: dict[str, Any],
    review: Any,
    *,
    max_findings: int = 10,
) -> int:
    """Extract findings from `review` (a JSON string or dict), tag them
    with the PR id + title, and persist via `memory.store_many`. Returns
    the count stored. Used by our entelligence harness; promoted here so
    customer code can reuse the same shape.

    `pr` must have at least `number` and (optionally) `title` keys --
    matches the GitHub PR shape used by /entelligence.
    """
    notes = extract_findings(
        review,
        source_pr=pr.get("number"),
        source_pr_title=pr.get("title", ""),
        max_findings=max_findings,
    )
    if not notes:
        return 0
    return memory.store_many(notes)
