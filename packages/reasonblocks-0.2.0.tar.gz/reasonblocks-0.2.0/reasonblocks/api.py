from __future__ import annotations

import logging
from typing import Any, Optional

import httpx

from dataclasses import dataclass

from reasonblocks._settings import DEFAULT_BASE_URL as _DEFAULT_BASE_URL, DEFAULT_TIMEOUT as _TIMEOUT
from reasonblocks.types import ETrace, StepRecord, TraceState

logger = logging.getLogger("reasonblocks.api")


class ReasonBlocksAPI:
    """HTTP client for the ReasonBlocks backend."""

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
    ) -> None:
        from reasonblocks.client import _mask_api_key, _validate_api_key
        self._api_key = _validate_api_key(api_key)
        self._mask_api_key = _mask_api_key
        self._client = httpx.Client(
            base_url=base_url,
            headers={"Authorization": f"Bearer {self._api_key}"},
            timeout=_TIMEOUT,
        )

    def __repr__(self) -> str:
        return f"ReasonBlocksAPI(api_key={self._mask_api_key(self._api_key)})"

    def __getstate__(self) -> dict[str, Any]:
        state = dict(self.__dict__)
        state["_api_key"] = None
        # The httpx client carries the Authorization header; drop it.
        state["_client"] = None
        return state

    def __setstate__(self, state: dict[str, Any]) -> None:
        raise NotImplementedError(
            "ReasonBlocksAPI instances are not pickle-safe; construct a "
            "new instance with a fresh api_key instead."
        )

    def retrieve_traces(
        self,
        context: str,
        level: str,
        top_k: int = 5,
        *,
        model: str = "",
        failure_type: Optional[str] = None,
    ) -> list[ETrace]:
        """Retrieve raw pattern payloads for a tier.

        The rb-api returns raw fields from the Qdrant payload. Format
        rendering happens client-side in the middleware via
        :func:`reasonblocks.format_routing.render_pattern`, after model
        routing pins the final model id. Tenant scope is derived
        server-side from the API key principal — the SDK does not
        send a customer_id.
        """

        tier = (level or "").lower().strip()
        payload: dict[str, Any] = {
            "context": context,
            "tier": tier,
            "level": tier,  # legacy alias — rb-api accepts either
            "top_k": top_k,
            "model": model,
        }
        if failure_type:
            payload["failure_type"] = failure_type

        try:
            resp = self._client.post("/traces/retrieve", json=payload)
            resp.raise_for_status()
            data = resp.json()
            out: list[ETrace] = []
            for item in data.get("traces", []):
                out.append(
                    ETrace(
                        tier=(item.get("tier") or item.get("level") or tier).lower(),
                        similarity=float(item.get("similarity", 0.0) or 0.0),
                        pattern_id=str(item.get("pattern_id", "") or ""),
                        fields=item.get("fields") or {},
                        failure_type=item.get("failure_type"),
                        model_family=item.get("model_family", "") or "",
                        level=(item.get("level") or tier).lower(),
                        source_trace_id=item.get("source_trace_id"),
                    ),
                )
            return out
        except Exception:
            logger.warning("Failed to retrieve %s traces", tier, exc_info=True)
            return []

    # store_trace + ingest_trace removed when the JSONL trace archive was
    # retired. Run-level history is captured live via MonitorClient (per-step
    # POSTs to /monitor/runs); pattern memory persists in /traces/retrieve
    # (Qdrant) and /findings.

    def evaluate_monitors(
        self,
        state: TraceState,
        *,
        model: str = "",
        task_profile: str = "coding",
        weights: Optional[dict[str, float]] = None,
    ) -> Optional["MonitorEvaluation"]:
        """Run server-side trajectory monitors against the current trace.

        ``task_profile`` picks the server-side weight preset.
        ``coding`` is the default; pass ``"pr_review"`` for read-only
        reviewer agents — the server uses a different preset that
        omits monitors that are inapplicable to read-only work.

        ``weights`` is an optional explicit per-monitor weight override
        applied on top of the profile. Partial overrides are fine:
        unspecified monitor names fall through to the profile, then to
        the server defaults. Unknown monitor names are dropped server-
        side; negative weights are clamped to 0.

        Returns ``None`` on transport error so the middleware can degrade
        gracefully — a failing monitor call must never break the agent
        loop.
        """

        try:
            payload: dict[str, Any] = {
                "model": model,
                "task_profile": task_profile,
                "steps": [_step_to_monitor_dict(s) for s in state.steps],
            }
            if weights:
                payload["weights"] = {k: float(v) for k, v in weights.items()}
            resp = self._client.post("/monitors/evaluate", json=payload)
            resp.raise_for_status()
            data = resp.json()
            return MonitorEvaluation(
                inject=bool(data.get("inject")),
                intervention_text=data.get("intervention_text") or None,
                failure_type=data.get("failure_type"),
                injection_path=data.get("injection_path"),
                intervention_source=data.get("intervention_source"),
                fired=list(data.get("fired") or []),
                pattern_id=data.get("pattern_id"),
                scores=dict(data.get("scores") or {}),
                composite=float(data.get("composite") or 0.0),
            )
        except Exception:
            logger.warning("Failed to evaluate monitors via API", exc_info=True)
            return None

    def score_step(self, text: str, context: str) -> Optional[float]:
        """Server-side difficulty scoring (optional, returns None on failure)."""
        try:
            resp = self._client.post(
                "/score",
                json={"text": text, "context": context},
            )
            resp.raise_for_status()
            return float(resp.json().get("difficulty", 0.5))
        except Exception:
            logger.warning("Failed to score step via API", exc_info=True)
            return None

    def close(self) -> None:
        self._client.close()


def _step_to_monitor_dict(step: StepRecord) -> dict[str, Any]:
    """Flatten a StepRecord into the wire shape /monitors/evaluate expects."""

    obs = step.observation or ""
    is_error = any(
        ind in obs.lower() for ind in ("error", "exception", "traceback", "failed")
    )
    return {
        "thought": step.thought or "",
        "action": step.action,
        "action_input": step.action_input,
        "observation": obs,
        "observation_is_error": is_error,
    }


@dataclass
class MonitorEvaluation:
    """Server-side monitor evaluation result.

    Only ``inject`` and ``intervention_text`` are part of the user-visible
    contract. The other fields are audit metadata for benchmarks and for
    the SDK trace collector, which records them per-call.
    """

    inject: bool
    intervention_text: Optional[str] = None
    failure_type: Optional[str] = None
    injection_path: Optional[str] = None
    intervention_source: Optional[str] = None
    fired: list[str] = None  # type: ignore[assignment]
    pattern_id: Optional[str] = None
    scores: dict[str, float] = None  # type: ignore[assignment]
    composite: float = 0.0

    def __post_init__(self) -> None:
        if self.fired is None:
            self.fired = []
        if self.scores is None:
            self.scores = {}
