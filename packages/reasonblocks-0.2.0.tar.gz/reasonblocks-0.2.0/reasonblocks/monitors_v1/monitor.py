"""v1 general-monitor pack — semantic + structural detectors.

Six detectors, each grounded in a failure mode the v0 jaccard pack
demonstrably misses on the HLE failure taxonomy. Same priority+cooldown
engine as v0 so :class:`reasonblocks.GeneralMonitorMiddleware` can
swap between packs via a feature flag.

  201 ``semantic_loop`` — voyage-cosine retry-after-error (≥0.85).
  202 ``late_sprawl``  — late-phase semantic-cluster fanout.
  203 ``verification_skip`` — submit-class tool with no verify-class
                              tool in the trailing window.
  204 ``claim_contradiction`` — assistant text contradicts an earlier
                              turn's claim about the same entity.
  205 ``silent_topic_drift`` — assistant text cosine drops sharply
                              with no intervening tool call.
  206 ``cyclic_compression`` — LZ77 ratio over cluster-id sequence
                              indicates multi-step cycle.

The v1 pack is built so that v0's jaccard heuristics stay reachable
behind a flag — the SDK ships both, customers pick.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Iterable

from reasonblocks.monitors_v1.primitives import (
    Claim,
    claim_contradicts,
    cluster_actions,
    cosine,
    cycle_redundancy,
    embed_action,
    embed_text,
    extract_claims,
)

logger = logging.getLogger("reasonblocks.monitors_v1")


# ---------------------------------------------------------------------------
# Rule catalog
# ---------------------------------------------------------------------------

RULES: dict[int, tuple[str, str]] = {
    201: (
        "semantic_loop",
        "You just retried the same action after an error result. The "
        "two calls are semantically equivalent, so the same failure is "
        "likely to recur. Pause and read the error before trying again.",
    ),
    202: (
        "late_sprawl",
        "Late in your action budget, the recent calls have opened many "
        "distinct lines of inquiry. Stop branching and synthesize what "
        "you already know.",
    ),
    203: (
        "verification_skip",
        "You are about to submit / finalize without having verified the "
        "result. Run a check against an oracle (tests, simulation, "
        "look-up) before committing to an answer.",
    ),
    204: (
        "claim_contradiction",
        "Your latest reasoning asserts a value that contradicts what "
        "you stated earlier in this trajectory. Reconcile the two — "
        "one of them is wrong, and continuing without resolving it "
        "will likely produce an inconsistent answer.",
    ),
    205: (
        "silent_topic_drift",
        "Your latest reasoning has shifted to a new topic without an "
        "intervening tool call to motivate the change. Either name the "
        "trigger or return to the previous line.",
    ),
    206: (
        "cyclic_compression",
        "Your recent actions show a cyclic pattern — the same small "
        "set of behaviours is repeating. Break the cycle: take a "
        "structurally different action or stop and finalize.",
    ),
}

# Priority: most specific / highest-urgency first. claim_contradiction
# leads because it's the only detector that actually examines what the
# agent has *concluded* about the world; if it fires, the trajectory
# has a real reasoning bug that overrides any superficial action-pattern
# signal.
PRIORITY = [204, 201, 203, 206, 202, 205]


# ---------------------------------------------------------------------------
# Firing record (matches v0's shape so callers don't care which pack)
# ---------------------------------------------------------------------------

@dataclass
class Firing:
    step: int
    rule_id: int
    rule_name: str
    trigger: str
    injection_text: str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ERROR_RE = re.compile(
    r"(?i)(\b(error|exception|traceback|failed|failure|denied|"
    r"unauthorized|invalid|cannot|could\s+not|unable|timeout|refused|"
    r"rejected)\b|\w+Error\b|\w+Exception\b)"
)


def _has_error_signal(text: str) -> bool:
    return bool(_ERROR_RE.search(text or ""))


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

@dataclass
class GeneralMonitorV1:
    """Semantic + structural monitor pack.

    ``check(history, call_index)`` mirrors :class:`GeneralMonitor` (v0)
    so the middleware can dispatch to either engine based on a flag.

    Configurable knobs:
      * ``max_tool_calls`` — soft budget (used as the late-sprawl gate).
      * ``cooldown`` — per-rule fire suppression in steps.
      * ``verify_tools`` / ``submit_tools`` — per-agent tool name sets
        for the verification_skip detector. Customers register their
        own; sensible defaults included for our demo agents.
      * ``cycle_window`` — number of trailing actions to compress for
        the cycle detector (default 8).
      * ``cycle_ratio_threshold`` — fire below this LZ ratio.
      * ``loop_cosine_threshold`` — cosine ≥ this is "same intent".
      * ``cluster_threshold`` — single-link clustering similarity.
    """

    max_tool_calls: int = 12
    cooldown: int = 3
    verify_tools: frozenset[str] = field(
        default_factory=lambda: frozenset({
            "verify_patch", "run_tests", "compute", "scratchpad",
            "simulate", "validate", "check",
        })
    )
    submit_tools: frozenset[str] = field(
        default_factory=lambda: frozenset({
            "submit_patch", "submit_brief", "submit_answer",
            "submit_review_comment", "submit_recommendation", "finalize",
        })
    )
    cycle_window: int = 8
    # Bigram-redundancy threshold (size-independent). 0.50 means at
    # least half the consecutive transitions in the trailing window
    # repeat — strong cyclic signature.
    cycle_redundancy_threshold: float = 0.50
    loop_cosine_threshold: float = 0.85
    cluster_threshold: float = 0.85
    drift_cosine_threshold: float = 0.30
    sprawl_late_fraction: float = 0.6

    _last_fired: dict[int, int] = field(
        default_factory=lambda: {i: -1000 for i in RULES}
    )
    firings: list[Firing] = field(default_factory=list)
    _opportunity_count: int = 0
    _claims: list[Claim] = field(default_factory=list)

    # ------------------------------------------------------------------
    # Public API — same shape as v0's GeneralMonitor
    # ------------------------------------------------------------------

    def check(self, history: list[dict], call_index: int) -> Firing | None:
        tool_calls = self._collect_tool_calls(history)
        tool_results = self._collect_tool_results(history)
        ai_texts = self._collect_assistant_texts(history)

        if any(call_index - self._last_fired[r] >= self.cooldown for r in RULES):
            self._opportunity_count += 1

        for rule_id in PRIORITY:
            if call_index - self._last_fired[rule_id] < self.cooldown:
                continue
            trig = self._dispatch(
                rule_id, tool_calls, tool_results, ai_texts, call_index,
            )
            if trig is None:
                continue
            self._last_fired[rule_id] = call_index
            name, text = RULES[rule_id]
            fired = Firing(
                step=call_index, rule_id=rule_id, rule_name=name,
                trigger=trig, injection_text=text,
            )
            self.firings.append(fired)
            return fired
        return None

    def reset(self) -> None:
        self._last_fired = {i: -1000 for i in RULES}
        self.firings = []
        self._opportunity_count = 0
        self._claims = []

    @property
    def firing_opportunity_count(self) -> int:
        return self._opportunity_count

    # ------------------------------------------------------------------
    # Dispatcher
    # ------------------------------------------------------------------

    def _dispatch(
        self,
        rule_id: int,
        tool_calls: list[dict],
        tool_results: list[dict],
        ai_texts: list[dict],
        call_index: int,
    ) -> str | None:
        if rule_id == 201:
            return self._detect_semantic_loop(tool_calls, tool_results)
        if rule_id == 202:
            return self._detect_late_sprawl(tool_calls, call_index)
        if rule_id == 203:
            return self._detect_verification_skip(tool_calls)
        if rule_id == 204:
            return self._detect_claim_contradiction(ai_texts)
        if rule_id == 205:
            return self._detect_silent_topic_drift(ai_texts, tool_calls)
        if rule_id == 206:
            return self._detect_cyclic_compression(tool_calls)
        return None

    # ------------------------------------------------------------------
    # Detectors
    # ------------------------------------------------------------------

    def _detect_semantic_loop(
        self, tool_calls: list[dict], tool_results: list[dict],
    ) -> str | None:
        """Fire when last call is a same-tool retry of the previous call
        AND there's an error result in the recent window AND the two
        calls' embeddings are cosine ≥ threshold."""
        if len(tool_calls) < 2:
            return None
        prev, curr = tool_calls[-2], tool_calls[-1]
        if prev.get("name") != curr.get("name"):
            return None
        # Need an error in the recent window (last result or two before).
        recent_results = tool_results[-3:]
        if not any(_has_error_signal(r.get("content", "")) for r in recent_results):
            return None
        emb_prev = embed_action(prev["name"], prev.get("args", {}))
        emb_curr = embed_action(curr["name"], curr.get("args", {}))
        sim = cosine(emb_prev, emb_curr)
        if sim < self.loop_cosine_threshold:
            return None
        return f"same-tool retry after error, cosine={sim:.2f} ≥ {self.loop_cosine_threshold:.2f}"

    def _detect_late_sprawl(
        self, tool_calls: list[dict], call_index: int,
    ) -> str | None:
        """Past 60% of budget, if the last 5 calls fan into ≥4 distinct
        clusters (single-link, threshold 0.85), the agent is branching
        instead of synthesizing."""
        if call_index < self.sprawl_late_fraction * self.max_tool_calls:
            return None
        if len(tool_calls) < 5:
            return None
        last5 = tool_calls[-5:]
        actions = [(c.get("name", ""), c.get("args", {})) for c in last5]
        cluster_ids = cluster_actions(actions, threshold=self.cluster_threshold)
        n_clusters = len(set(cluster_ids))
        if n_clusters < 4:
            return None
        return (
            f"call {call_index}/{self.max_tool_calls}, last 5 actions "
            f"in {n_clusters} distinct semantic clusters"
        )

    def _detect_verification_skip(
        self, tool_calls: list[dict],
    ) -> str | None:
        """Fire when the most recent call is a submit-class tool AND no
        verify-class tool was called in the previous 4 steps."""
        if not tool_calls:
            return None
        curr = tool_calls[-1]
        if curr.get("name") not in self.submit_tools:
            return None
        window = tool_calls[-5:-1]  # 4 immediately before submit
        if any(c.get("name") in self.verify_tools for c in window):
            return None
        return (
            f"submit '{curr['name']}' with no verify-class tool in "
            f"the trailing window of {len(window)} steps"
        )

    def _detect_claim_contradiction(
        self, ai_texts: list[dict],
    ) -> str | None:
        """Re-extract claims from the latest AI turn and compare against
        the per-trajectory ledger. Fire on the first contradicting pair.

        We rebuild the ledger from scratch on each check rather than
        maintain it incrementally — costs little (dozens of regex matches)
        and keeps the engine stateless w.r.t. caller's history mutation.
        """
        # Rebuild ledger
        ledger: list[Claim] = []
        for i, t in enumerate(ai_texts):
            ledger.extend(extract_claims(t.get("content", ""), step=i))
        if not ledger:
            return None
        latest_step = max(c.step for c in ledger)
        latest = [c for c in ledger if c.step == latest_step]
        prior = [c for c in ledger if c.step < latest_step]
        for new in latest:
            for old in prior:
                if claim_contradicts(old, new):
                    return (
                        f"claim '{new.entity}' = {new.value!r} "
                        f"(step {new.step}) contradicts earlier "
                        f"= {old.value!r} (step {old.step})"
                    )
        return None

    def _detect_silent_topic_drift(
        self, ai_texts: list[dict], tool_calls: list[dict],
    ) -> str | None:
        """Cosine on consecutive assistant texts < threshold AND no tool
        call between the two turns. Catches the agent silently switching
        subject without doing anything to motivate the switch."""
        if len(ai_texts) < 3:
            return None
        a = ai_texts[-3]; c = ai_texts[-1]
        # No tool call in between (i.e. between a.step and c.step)
        a_step = a.get("step", -2); c_step = c.get("step", -1)
        intervening_tool = any(
            a_step < tc.get("step", -1) < c_step for tc in tool_calls
        )
        if intervening_tool:
            return None
        emb_a = embed_text(a.get("content", ""))
        emb_c = embed_text(c.get("content", ""))
        sim = cosine(emb_a, emb_c)
        if sim >= self.drift_cosine_threshold:
            return None
        # Avoid false-positives on near-empty thoughts
        if len((a.get("content") or "").split()) < 8 or \
           len((c.get("content") or "").split()) < 8:
            return None
        return (
            f"cosine(text[{a_step}], text[{c_step}])={sim:.2f} < "
            f"{self.drift_cosine_threshold:.2f}, no intervening tool call"
        )

    def _detect_cyclic_compression(
        self, tool_calls: list[dict],
    ) -> str | None:
        """Bigram-redundancy over the cluster-id sequence of the trailing
        window. Catches A→B→C→A→B→C cycles that consecutive-streak rules
        cannot see (because no two adjacent calls are identical)."""
        if len(tool_calls) < self.cycle_window:
            return None
        window = tool_calls[-self.cycle_window:]
        actions = [(c.get("name", ""), c.get("args", {})) for c in window]
        cluster_ids = cluster_actions(actions, threshold=self.cluster_threshold)
        # Need at least two distinct clusters for a cycle to be meaningful.
        if len(set(cluster_ids)) < 2:
            return None
        score = cycle_redundancy(cluster_ids)
        if score < self.cycle_redundancy_threshold:
            return None
        return (
            f"trailing {self.cycle_window}-call sequence has "
            f"bigram-redundancy {score:.2f} (≥ {self.cycle_redundancy_threshold:.2f}); "
            f"{len(set(cluster_ids))} distinct clusters"
        )

    # ------------------------------------------------------------------
    # History extractors (mirror v0 wiring)
    # ------------------------------------------------------------------

    @staticmethod
    def _collect_tool_calls(history: list[dict]) -> list[dict]:
        out: list[dict] = []
        for entry in history:
            if entry.get("role") != "ai":
                continue
            for tc in entry.get("tool_calls", []) or []:
                out.append({
                    "step": entry.get("step", 0),
                    "name": str(tc.get("name", "")),
                    "args": tc.get("args") or {},
                })
        return out

    @staticmethod
    def _collect_tool_results(history: list[dict]) -> list[dict]:
        out: list[dict] = []
        for entry in history:
            if entry.get("role") == "tool":
                out.append({
                    "step": entry.get("step", 0),
                    "content": entry.get("content", ""),
                })
        return out

    @staticmethod
    def _collect_assistant_texts(history: list[dict]) -> list[dict]:
        out: list[dict] = []
        for entry in history:
            if entry.get("role") != "ai":
                continue
            content = entry.get("content", "") or ""
            had_tc = bool(entry.get("tool_calls"))
            out.append({
                "step": entry.get("step", 0),
                "content": content,
                "had_tool_call": had_tc,
            })
        return out


__all__ = ["GeneralMonitorV1", "Firing", "RULES", "PRIORITY"]
