"""Primitives shared by the v1 general-monitor pack.

The v1 pack moves past v0's word-token jaccard heuristics. It uses:

  * voyage-3 embeddings (cosine similarity in semantic space) for
    cross-call action and text similarity, with a sha256-keyed LRU
    cache so repeated identical actions cost zero API time.
  * Single-link greedy clustering for "how many distinct lines of
    inquiry" detection.
  * LZ77 compression-ratio over a cluster-id sequence as a multi-step
    cycle detector (catches A→B→C→A→B→C patterns that streak rules
    cannot see).
  * Pure-Python regex claim extraction over assistant text turns —
    numeric values, bold-marked answers, and explicit
    "the answer is X" patterns — for the contradiction monitor.

If ``VOYAGE_API_KEY`` is unset, ``embed_action`` and ``embed_text``
fall back to a deterministic char-trigram TF-IDF embedding so the
pack still runs (and unit tests don't need network). Char trigrams
are a weaker substitute, but they at least handle punctuation /
case variants better than word-token jaccard.
"""
from __future__ import annotations

import hashlib
import logging
import math
import os
import re
import zlib
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional

logger = logging.getLogger("reasonblocks.monitors_v1")


# ---------------------------------------------------------------------------
# Embedding cache + voyage backend
# ---------------------------------------------------------------------------


class _LRU(OrderedDict):
    """Tiny FIFO-eviction LRU over sha256 keys."""

    def __init__(self, maxsize: int = 4096) -> None:
        super().__init__()
        self.maxsize = maxsize

    def get_or_set(self, key: str, fn):
        if key in self:
            self.move_to_end(key)
            return self[key]
        v = fn()
        self[key] = v
        if len(self) > self.maxsize:
            self.popitem(last=False)
        return v


_EMB_CACHE = _LRU(maxsize=4096)
_VOYAGE_CLIENT: Any = None
_VOYAGE_MODEL = os.environ.get("REASONBLOCKS_VOYAGE_MODEL", "voyage-3")


def _voyage_client():
    global _VOYAGE_CLIENT
    if _VOYAGE_CLIENT is not None:
        return _VOYAGE_CLIENT
    if not os.environ.get("VOYAGE_API_KEY"):
        return None
    try:
        import voyageai  # type: ignore
        _VOYAGE_CLIENT = voyageai.Client()
        return _VOYAGE_CLIENT
    except Exception as exc:
        logger.warning("voyageai unavailable, falling back to char-trigram: %s", exc)
        return None


def _key(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest()


def _char_trigram_vec(text: str) -> dict[str, float]:
    """Deterministic char-trigram TF-IDF-ish vector. No IDF (corpus-free),
    just normalized term frequencies. Cheap and dependency-free; serves as
    a fallback when voyage is unavailable."""
    text = (text or "").lower().strip()
    if not text:
        return {}
    grams: dict[str, int] = {}
    padded = f"  {text}  "
    for i in range(len(padded) - 2):
        g = padded[i:i + 3]
        grams[g] = grams.get(g, 0) + 1
    norm = math.sqrt(sum(v * v for v in grams.values())) or 1.0
    return {k: v / norm for k, v in grams.items()}


def _embed_voyage(texts: list[str], input_type: str) -> list[list[float]]:
    """Batched voyage embedding. ``input_type`` is "query" or "document"."""
    client = _voyage_client()
    if client is None:
        return [list(_char_trigram_vec(t).values()) or [0.0] for t in texts]
    try:
        resp = client.embed(texts, model=_VOYAGE_MODEL, input_type=input_type)
        return list(resp.embeddings)
    except Exception as exc:
        logger.warning("voyage embed failed (%s); using trigram fallback", exc)
        return [list(_char_trigram_vec(t).values()) or [0.0] for t in texts]


def embed_action(tool_name: str, args: dict | str) -> list[float] | dict[str, float]:
    """Embed a (tool, args) action signature. Cached by sha256 of canonical
    string. Returns a real voyage vector when available, else a sparse
    char-trigram dict (cosine helper handles both)."""
    canonical = _canonicalize_action(tool_name, args)
    key = _key(canonical)
    if key in _EMB_CACHE:
        return _EMB_CACHE[key]
    if _voyage_client() is not None:
        v = _embed_voyage([canonical], input_type="document")[0]
    else:
        v = _char_trigram_vec(canonical)
    _EMB_CACHE[key] = v
    if len(_EMB_CACHE) > _EMB_CACHE.maxsize:
        _EMB_CACHE.popitem(last=False)
    return v


def embed_text(text: str) -> list[float] | dict[str, float]:
    """Embed an assistant text turn. Same caching/fallback as embed_action."""
    text = (text or "").strip()
    key = _key("text::" + text)
    if key in _EMB_CACHE:
        return _EMB_CACHE[key]
    if _voyage_client() is not None and text:
        v = _embed_voyage([text], input_type="document")[0]
    else:
        v = _char_trigram_vec(text)
    _EMB_CACHE[key] = v
    if len(_EMB_CACHE) > _EMB_CACHE.maxsize:
        _EMB_CACHE.popitem(last=False)
    return v


def _canonicalize_action(tool_name: str, args: dict | str) -> str:
    """Stable serialization for cache keys + cluster ids.

    Trims long string args to 500 chars (matches AgentTrove canonical
    form). Sorts dict keys. Coerces non-str values via str().
    """
    name = str(tool_name or "")
    if isinstance(args, str):
        body = args[:500]
    else:
        try:
            parts = []
            for k in sorted((args or {}).keys()):
                v = str(args[k])
                if len(v) > 500:
                    v = v[:500]
                parts.append(f"{k}={v}")
            body = "|".join(parts)
        except Exception:
            body = str(args)[:500]
    return f"{name}::{body}"


def cosine(a: Any, b: Any) -> float:
    """Cosine similarity that handles both dense lists (voyage) and sparse
    dicts (trigram). Returns 0.0 on mismatched types or empty inputs."""
    if isinstance(a, dict) and isinstance(b, dict):
        if not a or not b:
            return 0.0
        keys = set(a) & set(b)
        if not keys:
            return 0.0
        dot = sum(a[k] * b[k] for k in keys)
        # normalized dicts already
        return max(0.0, min(1.0, dot))
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        if not a or not b or len(a) != len(b):
            return 0.0
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a)) or 1.0
        nb = math.sqrt(sum(y * y for y in b)) or 1.0
        return max(-1.0, min(1.0, dot / (na * nb)))
    return 0.0


# ---------------------------------------------------------------------------
# Greedy single-link clustering on action embeddings
# ---------------------------------------------------------------------------


def cluster_actions(
    actions: list[tuple[str, dict | str]],
    *,
    threshold: float = 0.85,
) -> list[int]:
    """Assign each action to a cluster id (0-indexed). Greedy single-link:
    each new action joins the existing cluster whose representative has
    cosine ≥ threshold; otherwise it spawns a new cluster.

    Returns a list of cluster ids parallel to ``actions``.
    """
    embeddings = [embed_action(n, a) for n, a in actions]
    cluster_reps: list[Any] = []
    cluster_ids: list[int] = []
    for emb in embeddings:
        joined = -1
        for i, rep in enumerate(cluster_reps):
            if cosine(emb, rep) >= threshold:
                joined = i
                break
        if joined < 0:
            cluster_reps.append(emb)
            cluster_ids.append(len(cluster_reps) - 1)
        else:
            cluster_ids.append(joined)
    return cluster_ids


# ---------------------------------------------------------------------------
# Cycle detection over a cluster-id sequence
# ---------------------------------------------------------------------------


def cycle_redundancy(symbols: list[Any]) -> float:
    """Bigram-redundancy score for a cluster-id sequence. Returns
    ``1 - distinct_bigrams / num_bigrams`` ∈ [0, 1].

    High score ⇒ many bigrams repeat ⇒ cyclic pattern.
    Low score ⇒ each transition is unique ⇒ exploration.

    Examples (cluster-id sequences):
      [0,1,0,1,0,1,0,1]  →  bigrams = [(0,1),(1,0)] × 3.5 → 6 of 7 repeat
                            distinct=2, num=7 → score 5/7 ≈ 0.71
      [0,1,2,3,4,5,6,7]  →  every bigram unique → score 0.00
      [0,0,0,0,0,0,0,0]  →  distinct=1, num=7 → score 6/7 ≈ 0.86

    Size-independent (unlike zlib, which has fixed header overhead).
    """
    if len(symbols) < 2:
        return 0.0
    bigrams = [(symbols[i], symbols[i + 1]) for i in range(len(symbols) - 1)]
    distinct = len(set(bigrams))
    return max(0.0, 1.0 - distinct / len(bigrams))


def lz_ratio(symbols: list[Any]) -> float:
    """zlib-compressed-len / raw-len for a sequence of cluster ids. Useful
    on long windows (≥30 symbols); on short windows zlib's ~12-byte
    header dominates and the ratio is uninformative — prefer
    :func:`cycle_redundancy` there.
    """
    if not symbols:
        return 1.0
    table = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    raw = "".join(table[i % len(table)] for i in symbols).encode("utf-8")
    if not raw:
        return 1.0
    try:
        compressed = zlib.compress(raw, level=6)
    except Exception:
        return 1.0
    return len(compressed) / max(len(raw), 1)


# ---------------------------------------------------------------------------
# Claim extraction for the contradiction detector
# ---------------------------------------------------------------------------


@dataclass
class Claim:
    """A single concrete claim parsed out of an assistant turn."""
    kind: str          # "answer" | "numeric" | "bold"
    entity: str        # normalized noun phrase the claim is about
    value: str         # the asserted value, normalized
    raw: str           # the matched text for traceability
    step: int = 0


# Patterns ordered by specificity. Each yields one or more Claim objects.
_NUMBER = r"-?\d+(?:\.\d+)?(?:[eE]-?\d+)?"
# Captures the next non-whitespace token after the trigger phrase. Internal
# periods (e.g. "0.3") are preserved; trailing punctuation is stripped in
# _normalize_value.
_PAT_ANSWER = re.compile(
    rf"\b(?:the\s+answer\s+is|final\s+answer\s*[:=]?|result\s*(?:is|=))"
    rf"\s+(\S{{1,80}})", re.I,
)
# Single-word entity (no internal spaces) so "So velocity = 9.8" captures
# entity="velocity", not "So velocity". Multi-word entities can be added
# later if needed.
_PAT_EQUALS = re.compile(
    rf"\b([A-Za-z_][A-Za-z0-9_]{{0,40}})\s*(?:=|equals|is)\s*({_NUMBER})\b"
)
_PAT_BOLD = re.compile(r"\*\*([^*\n]{1,80})\*\*")
_PAT_NUMERIC_ATOM = re.compile(rf"\b({_NUMBER})\b")
_PAT_HEDGE = re.compile(
    r"\b(maybe|perhaps|possibly|might|could|not\s+sure|i\s+think|"
    r"probably|wait|hmm|reconsider|let\s+me\s+think|on\s+second\s+thought)\b",
    re.I,
)


def _normalize_value(s: str) -> str:
    """Trim, collapse whitespace, drop trailing punctuation. Keep numeric
    representation (so '0.30' and '0.3' collapse)."""
    s = re.sub(r"\s+", " ", s).strip(" \t\r\n.,;:!?\"'`")
    if not s:
        return ""
    # Numeric collapse
    m = re.fullmatch(rf"-?({_NUMBER})", s)
    if m:
        try:
            return repr(float(s))
        except Exception:
            return s
    return s.lower()


def _normalize_entity(s: str) -> str:
    s = re.sub(r"\s+", " ", s).strip(" \t\r\n.,;:!?\"'`*")
    return s.lower()[:80]


def extract_claims(text: str, step: int = 0) -> list[Claim]:
    """Parse claims out of an assistant text turn.

    Strategies (specific → generic):

      * "the answer is X" / "final answer: X" / "result is X" → answer claim
        keyed on the entity "answer".
      * "X = N" / "X equals N" / "X is N" → numeric claim keyed on entity X.
      * "**X**" markdown bold → bold claim keyed on first 5 words preceding
        the bold span (best-effort topic), value is the bold text itself.

    Returns possibly-empty list. Hedged claims (within ~6 words of a hedge
    word) are suppressed so retractions don't show up as contradictions.
    """
    if not text:
        return []
    out: list[Claim] = []
    hedge_spans = [m.span() for m in _PAT_HEDGE.finditer(text)]

    def _is_hedged(start: int) -> bool:
        for hs, he in hedge_spans:
            # within 60 chars of a hedge
            if abs(start - he) <= 60 or abs(start - hs) <= 60:
                return True
        return False

    for m in _PAT_ANSWER.finditer(text):
        if _is_hedged(m.start()):
            continue
        v = _normalize_value(m.group(1))
        if v:
            out.append(Claim(kind="answer", entity="answer", value=v, raw=m.group(0)[:120], step=step))
    for m in _PAT_EQUALS.finditer(text):
        if _is_hedged(m.start()):
            continue
        ent = _normalize_entity(m.group(1))
        val = _normalize_value(m.group(2))
        if ent and val:
            out.append(Claim(kind="numeric", entity=ent, value=val, raw=m.group(0)[:120], step=step))
    for m in _PAT_BOLD.finditer(text):
        if _is_hedged(m.start()):
            continue
        body = m.group(1).strip()
        # Skip headings / very short bold (single words are usually emphasis)
        if len(body.split()) < 2:
            continue
        # Use the bold body itself as both entity-context and value.
        ent = _normalize_entity(body[:40])
        val = _normalize_value(body)
        if ent and val and ent != val:
            out.append(Claim(kind="bold", entity=ent, value=val, raw=m.group(0)[:120], step=step))
    return out


def claim_contradicts(prev: Claim, curr: Claim) -> bool:
    """Two claims contradict iff they're about the same entity but have
    different normalized values. For numeric claims a sign flip alone is a
    contradiction. For 'answer' claims we additionally treat any value
    change as contradiction."""
    if prev.entity != curr.entity:
        return False
    if prev.value == curr.value:
        return False
    # Numeric sign flip is the canonical case (cnv_score: −0.3 → 0.3).
    try:
        a = float(prev.value); b = float(curr.value)
        return a != b
    except Exception:
        pass
    return prev.value != curr.value


__all__ = [
    "Claim",
    "embed_action", "embed_text", "cosine",
    "cluster_actions", "cycle_redundancy", "lz_ratio",
    "extract_claims", "claim_contradicts",
]
