"""v1 general-monitor pack — semantic + structural detectors.

Public surface mirrors the v0 :mod:`reasonblocks.general_monitor` so
callers can swap packs via the ``monitor_pack_version`` flag on
:class:`reasonblocks.GeneralMonitorMiddleware`.
"""
from reasonblocks.monitors_v1.monitor import (
    Firing,
    GeneralMonitorV1,
    PRIORITY,
    RULES,
)
from reasonblocks.monitors_v1.primitives import (
    Claim,
    claim_contradicts,
    cluster_actions,
    cosine,
    embed_action,
    embed_text,
    extract_claims,
    lz_ratio,
)

__all__ = [
    "GeneralMonitorV1", "Firing", "RULES", "PRIORITY",
    "Claim", "claim_contradicts", "cluster_actions", "cosine",
    "embed_action", "embed_text", "extract_claims", "lz_ratio",
]
