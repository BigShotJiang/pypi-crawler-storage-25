"""Shared runtime settings for the ReasonBlocks SDK HTTP clients.

One source of truth for the backend base URL and request timeout so every
client (``ReasonBlocksAPI``, ``CodebaseMemory``, ``MonitorClient``) talks
to the same host by default. The default points at the hosted production
rb-api so ``pip install reasonblocks`` works out of the box without any
configuration. Override per-deployment with env vars:

- ``REASONBLOCKS_BASE_URL`` — rb-api origin (no trailing slash). Set to
  ``http://localhost:9000`` when running rb-api locally for dev.
- ``REASONBLOCKS_API_TIMEOUT`` — HTTP timeout in seconds.
- ``REASONBLOCKS_ALLOW_INSECURE`` — set to ``true`` to allow plain
  ``http://`` to non-localhost hosts. Off by default; enabling it
  defeats transport security and should only be used for testing.
"""

from __future__ import annotations

import logging
import os
from urllib.parse import urlparse

logger = logging.getLogger("reasonblocks._settings")

_SECURE_DEFAULT = "https://rb-api.reasonblocks.com"
_LOCALHOST_HOSTS = frozenset({"localhost", "127.0.0.1", "::1"})


def _validate_base_url(raw: str) -> str:
    """Reject plain-HTTP downgrade attempts via ``REASONBLOCKS_BASE_URL``.

    Allow ``http://`` only when:
      - the host is localhost / 127.0.0.1 (with a loud warning), OR
      - ``REASONBLOCKS_ALLOW_INSECURE=true`` is set (also warned).

    Otherwise log an error and fall back to the secure default — never
    silently downgrade a customer's API key to plaintext.
    """
    if not raw:
        return _SECURE_DEFAULT
    try:
        parsed = urlparse(raw)
    except Exception:
        logger.error(
            "REASONBLOCKS_BASE_URL %r is unparseable; falling back to %s",
            raw, _SECURE_DEFAULT,
        )
        return _SECURE_DEFAULT
    scheme = (parsed.scheme or "").lower()
    host = (parsed.hostname or "").lower()

    if scheme == "https":
        return raw
    if scheme == "http":
        if host in _LOCALHOST_HOSTS:
            logger.warning(
                "REASONBLOCKS_BASE_URL using plain http to localhost (%s) — "
                "fine for dev, never for production.",
                raw,
            )
            return raw
        allow_insecure = os.getenv("REASONBLOCKS_ALLOW_INSECURE", "").strip().lower() in {
            "1", "true", "yes", "on",
        }
        if allow_insecure:
            logger.warning(
                "REASONBLOCKS_ALLOW_INSECURE=true — sending API key over "
                "plaintext http to %s. This is a transport-security hole; "
                "only use for testing.",
                raw,
            )
            return raw
        logger.error(
            "Refusing to use plaintext http base url %r (would leak the "
            "API key). Falling back to %s. Set "
            "REASONBLOCKS_ALLOW_INSECURE=true to override.",
            raw, _SECURE_DEFAULT,
        )
        return _SECURE_DEFAULT
    logger.error(
        "REASONBLOCKS_BASE_URL %r has unsupported scheme %r; falling back to %s",
        raw, scheme, _SECURE_DEFAULT,
    )
    return _SECURE_DEFAULT


DEFAULT_BASE_URL = _validate_base_url(
    os.getenv("REASONBLOCKS_BASE_URL", _SECURE_DEFAULT),
)
DEFAULT_TIMEOUT = float(os.getenv("REASONBLOCKS_API_TIMEOUT", "10.0"))
