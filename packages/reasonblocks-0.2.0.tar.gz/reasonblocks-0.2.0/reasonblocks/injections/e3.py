from __future__ import annotations

import logging

from reasonblocks.api import ReasonBlocksAPI
from reasonblocks.injections.base import BaseInjection
from reasonblocks.types import PendingInjection, TraceState

logger = logging.getLogger("reasonblocks.injections.e3")


class E3Injection(BaseInjection):
    """Universal standing-rule injection -- scroll-all, fires once per run.

    Every session's first LLM call gets every E3 pattern. No similarity
    query, no gate. The middleware renders each pattern via
    ``format_routing.render_pattern("E3", final_model, fields)`` after
    model routing pins the final model.
    """

    def __init__(self, api: ReasonBlocksAPI) -> None:
        self._api = api
        self._fired = False

    def reset(self) -> None:
        """Clear the once-per-run latch so the next call retries retrieval.

        Useful when a session is reused across runs, or when a transient
        rb-api failure flipped the latch on a call that returned no
        usable patterns — without this, a single network blip would
        permanently disable E3 for the lifetime of the process.
        """
        self._fired = False

    def retrieve(self, state: TraceState) -> list[PendingInjection]:
        if self._fired:
            return []

        # Don't latch ``_fired`` until we've actually completed retrieval
        # successfully. The previous behavior set the flag before the
        # network call, which meant any transient rb-api failure
        # (timeout, 5xx) would permanently disable E3 for the process —
        # cache poisoning that survived even a fully recovered backend.
        try:
            traces = self._api.retrieve_traces(
                context="", level="e3", top_k=32,
            )
        except Exception:
            logger.warning("E3 injection failed", exc_info=True)
            return []

        self._fired = True
        return [
            PendingInjection(
                source="E3Injection",
                tier="e3",
                fields=t.fields,
            )
            for t in traces
            if t.fields
        ]
