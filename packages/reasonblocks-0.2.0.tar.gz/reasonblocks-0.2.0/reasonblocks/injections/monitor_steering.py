"""Remote monitor steering injection.

The SDK delegates trajectory monitoring to rb-api's ``/monitors/evaluate``.
Each call sends the current trace; the server runs its trained monitor
models, decides whether any have crossed their fire threshold, picks
the right intervention text, and returns a single rendered string when
it should fire.

SDK users do not see monitor weights, gate thresholds, or intervention
templates — only the final rendered intervention text.
"""

from __future__ import annotations

import logging
from typing import Optional

from reasonblocks.api import MonitorEvaluation, ReasonBlocksAPI
from reasonblocks.format_routing import _safe_render_server_text
from reasonblocks.injections.base import BaseInjection
from reasonblocks.types import PendingInjection, StepRecord, TraceState

logger = logging.getLogger("reasonblocks.injections.monitor_steering")


class MonitorSteeringInjection(BaseInjection):
    """Posts the current trace to rb-api and queues any returned intervention.

    The middleware still owns its own per-run guardrails (cooldowns,
    per-run cap on monitor injections) — those gates run after this
    injection returns and stay client-side because they govern user-
    visible cadence. The actual *decision* about whether the trajectory
    is broken belongs to the server.
    """

    SOURCE = "RemoteMonitorSteering"

    def __init__(
        self,
        api: ReasonBlocksAPI,
        *,
        model: str = "",
        task_profile: str = "coding",
        weights: Optional[dict[str, float]] = None,
    ) -> None:
        self._api = api
        self._model = model
        self._task_profile = task_profile
        self._weights = dict(weights) if weights else None
        self._current_step: Optional[StepRecord] = None
        self._last_signature: Optional[str] = None
        self._last_evaluation: Optional[MonitorEvaluation] = None

    def reset(self) -> None:
        self._current_step = None
        self._last_signature = None
        self._last_evaluation = None

    def last_evaluation(self) -> Optional[MonitorEvaluation]:
        """Return the most recent server-side evaluation for trace collection.

        The middleware reads this after ``retrieve`` runs so it can
        attach monitor scores, composite, and injection metadata to the
        pending per-call record. Resets to ``None`` via :meth:`reset`.
        """
        return self._last_evaluation

    def set_current_step(self, step: StepRecord) -> None:
        """Set the step the injection should evaluate against. Called by the
        middleware before ``retrieve``."""

        self._current_step = step

    def set_model(self, model: str) -> None:
        """Update the model id the server uses for format routing."""

        if model:
            self._model = model

    def retrieve(self, state: TraceState) -> list[PendingInjection]:
        if not state.steps:
            return []

        result = self._api.evaluate_monitors(
            state,
            model=self._model,
            task_profile=self._task_profile,
            weights=self._weights,
        )
        # Stash the evaluation regardless of injection decision so the
        # trace collector can still record monitor scores on calls that
        # did not trip the gate.
        self._last_evaluation = result
        if result is None or not result.inject or not result.intervention_text:
            return []

        signature = result.intervention_text.strip()
        if signature == self._last_signature:
            return []
        self._last_signature = signature

        # Sanitize the server-supplied intervention text before queueing —
        # it ends up spliced into the agent's system prompt downstream
        # and the server's content stores can be populated by user-edited
        # patterns. Defense in depth: strip control bytes, neutralize
        # structural markers, wrap in advisory framing.
        safe_text = _safe_render_server_text(result.intervention_text)
        return [
            PendingInjection(
                source=self.SOURCE,
                text=safe_text,
                monitors_fired=list(result.fired or []),
                failure_type=result.failure_type,
                intervention_source=result.intervention_source,
            )
        ]


