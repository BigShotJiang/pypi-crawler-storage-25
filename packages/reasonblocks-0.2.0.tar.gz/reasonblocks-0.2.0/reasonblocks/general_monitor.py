"""General cross-domain reactive monitor pack (v1) + LangChain middleware.

A small, opt-in rule pack that runs locally inside the agent loop —
distinct from the server-side trained monitors. Each rule targets a
transferable failure shape; firing is priority-ordered and cooldown-gated
so at most one rule injects per LLM call.

- **+10.7pp SWE-bench Pro** with this pack enabled.
- **+4.0pp HLE** (46.0% → 50.0% on Sonnet 4.6, n=150).

Injection framing: all rule text names the trajectory pattern and
invites reflection — no directives, no tool names, no task verbs. The
earlier directive-style framing regressed on multi-step-agent
clusters by pushing models toward unsafe confident commitments.

Typical wiring::

    from reasonblocks import (
        GeneralMonitorMiddleware,
        TokenSavingMiddleware,
    )

    agent = create_agent(
        model=..., tools=...,
        middleware=[
            GeneralMonitorMiddleware(max_tool_calls=30),
            TokenSavingMiddleware(),
        ],
    )

The combined stack (``GeneralMonitorMiddleware + TokenSavingMiddleware``)
ships +2.0pp with −24% input tokens and 5.3% paired regression rate on HLE.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

from langchain.agents.middleware import AgentMiddleware
from langchain.messages import AIMessage, HumanMessage, ToolMessage

logger = logging.getLogger("reasonblocks.general_monitor")


# v0 monitor pack (RULES, PRIORITY, _detect_*, GeneralMonitor) removed.
# All firing logic now lives in reasonblocks.monitors_v1; this module
# keeps only the middleware shell that dispatches to it.


@dataclass
class GeneralMonitorStats:
    """Running counters on the middleware."""

    firings: int = 0
    by_rule: dict[str, int] = field(default_factory=dict)
    opportunities: int = 0


# ---------------------------------------------------------------------------
# LangChain middleware wrapper
# ---------------------------------------------------------------------------

def _langchain_messages_to_history(messages: list[Any]) -> list[dict]:
    """Translate a LangChain message list into the monitor's history format."""
    out: list[dict] = []
    id_to_name: dict[str, str] = {}
    step = 0
    for m in messages:
        if isinstance(m, AIMessage):
            text = ""
            content = getattr(m, "content", "")
            if isinstance(content, str):
                text = content
            elif isinstance(content, list):
                text = "\n".join(
                    blk.get("text", "") for blk in content
                    if isinstance(blk, dict) and blk.get("type") == "text"
                )
            tool_calls_raw = getattr(m, "tool_calls", []) or []
            tool_calls = []
            for tc in tool_calls_raw:
                name = tc.get("name") if isinstance(tc, dict) else getattr(tc, "name", "")
                args = tc.get("args") if isinstance(tc, dict) else getattr(tc, "args", {})
                tcid = tc.get("id") if isinstance(tc, dict) else getattr(tc, "id", None)
                tool_calls.append({"name": name, "args": args or {}, "id": tcid})
                if tcid:
                    id_to_name[tcid] = name or ""
            out.append({
                "role": "ai", "step": step, "content": text,
                "tool_calls": tool_calls,
            })
            step += 1
        elif isinstance(m, ToolMessage):
            tcid = getattr(m, "tool_call_id", None)
            content = getattr(m, "content", "")
            if isinstance(content, list):
                content = "".join(
                    (blk.get("text", "") if isinstance(blk, dict) else "")
                    for blk in content
                )
            out.append({
                "role": "tool", "step": step,
                "tool_call_id": tcid,
                "name": id_to_name.get(tcid or "", ""),
                "content": str(content),
            })
            step += 1
        elif isinstance(m, HumanMessage):
            content = getattr(m, "content", "")
            if isinstance(content, list):
                content = "".join(
                    (blk.get("text", "") if isinstance(blk, dict) else "")
                    for blk in content
                )
            out.append({
                "role": "user", "step": step,
                "content": str(content), "tool_calls": [],
            })
            step += 1
    return out


class GeneralMonitorMiddleware(AgentMiddleware):
    """LangChain middleware wrapping :class:`GeneralMonitor`.

    Inspects history before each model call; injects a single
    :class:`HumanMessage` with the firing's text when a rule fires.
    One firing per model call, priority-ordered, per-rule cooldown=8.

    Failures in the hook are logged and swallowed — the middleware
    never breaks the agent loop.
    """

    def __init__(
        self,
        *,
        max_tool_calls: int = 30,
        cooldown: int = 8,
        pack: str = "v1",
        verify_tools: frozenset[str] | None = None,
        submit_tools: frozenset[str] | None = None,
    ) -> None:
        """Default and only supported monitor pack is ``v1`` — the
        semantic + structural detectors in :mod:`reasonblocks.monitors_v1`.

        The legacy ``v0`` jaccard pack has been retired; the ``pack``
        kwarg accepts ``"v1"`` (the default) or the legacy alias
        ``"v0"`` which silently dispatches to v1 with a deprecation
        warning so existing wiring continues to work.

        ``verify_tools`` / ``submit_tools`` are forwarded to the v1
        ``verification_skip`` detector. Customers register their
        per-agent tool name sets here.
        """
        super().__init__()
        if pack not in ("v1", "v0"):
            raise ValueError(f"unknown monitor pack {pack!r}; only 'v1' is supported")
        if pack == "v0":
            logger.warning(
                "monitor pack='v0' is deprecated; dispatching to v1. "
                "Update callers to pack='v1'."
            )
        from reasonblocks.monitors_v1 import GeneralMonitorV1
        kw: dict[str, object] = {
            "max_tool_calls": max_tool_calls,
            "cooldown": cooldown,
        }
        if verify_tools is not None:
            kw["verify_tools"] = verify_tools
        if submit_tools is not None:
            kw["submit_tools"] = submit_tools
        self.monitor = GeneralMonitorV1(**kw)
        self.pack = "v1"
        self.stats = GeneralMonitorStats()
        self._call_index = 0

    def before_model(self, state, runtime=None):
        try:
            return self._before_impl(state)
        except Exception as exc:
            logger.warning("general_monitor before_model failed: %s", exc)
            return None

    def _before_impl(self, state):
        messages = list(state.get("messages", []) or [])
        if not messages:
            return None
        # New-run heuristic: when the message list shrinks back to a
        # single seed message, treat it as a fresh run and clear all
        # accumulated state. Without this, a long-lived middleware
        # instance reused across runs would carry firings / cooldowns
        # from a prior run into the new one.
        if len(messages) <= 1:
            self.monitor.reset()
            self.stats = GeneralMonitorStats()
            self._call_index = 0
        self._call_index += 1
        history = _langchain_messages_to_history(messages)
        fire = self.monitor.check(history, self._call_index)
        self.stats.opportunities = self.monitor.firing_opportunity_count
        if fire is None:
            return None
        self.stats.firings += 1
        self.stats.by_rule[fire.rule_name] = (
            self.stats.by_rule.get(fire.rule_name, 0) + 1
        )
        return {"messages": [HumanMessage(content=fire.injection_text)]}


__all__ = [
    "GeneralMonitor",
    "GeneralMonitorMiddleware",
    "GeneralMonitorStats",
    "Firing",
    "RULES",
    "PRIORITY",
]
