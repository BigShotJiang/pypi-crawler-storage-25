"""Client-side A/B arm assignment for the ReasonBlocks sales/eval pipeline.

The split is decided here, in the SDK, so a customer's harness owns the
randomization. ``ReasonBlocks.ab_middleware(...)`` calls :func:`assign_arm`
and builds either the full pipeline ("on") or a telemetry-only vanilla
middleware ("off"), stamping the arm onto the run row for the rb-api report.
"""

from __future__ import annotations

import hashlib


def assign_arm(experiment_id: str, unit_id: str, *, on_fraction: float = 0.5) -> str:
    """Deterministically assign an experiment unit to ``"on"`` or ``"off"``.

    Uses a SHA-256 hash of ``(experiment_id, unit_id)`` mapped uniformly to
    [0, 1); ``"on"`` when the draw is below ``on_fraction``. Properties that
    matter for a clean A/B:

    * **Stable.** The same ``(experiment_id, unit_id)`` always lands in the
      same arm, so a retried task can't flip arms and contaminate the
      comparison. Pass a *stable task id* as ``unit_id`` (not a fresh
      per-attempt run id) when you want retries to stay in their arm.
    * **Stratum-balanced for free.** Uniform hashing keeps any
      sub-population (e.g. one ``task_profile`` or repo) split at roughly
      ``on_fraction`` without special handling, which is what lets the
      report pool accuracy across strata.
    * **No shared state.** Two processes assign identically without
      coordinating, because the draw is a pure function of the inputs.
    """
    if not 0.0 <= on_fraction <= 1.0:
        raise ValueError("on_fraction must be in [0, 1]")
    digest = hashlib.sha256(f"{experiment_id}:{unit_id}".encode("utf-8")).digest()
    draw = int.from_bytes(digest[:8], "big") / 2 ** 64
    return "on" if draw < on_fraction else "off"


def sdk_version() -> str:
    """Best-effort installed ``reasonblocks`` version, stamped on each run so
    a mid-experiment SDK change is visible in the data. ``"unknown"`` when
    the package metadata isn't resolvable (e.g. an editable checkout)."""
    try:
        from importlib.metadata import PackageNotFoundError, version
        try:
            return version("reasonblocks")
        except PackageNotFoundError:
            return "unknown"
    except Exception:
        return "unknown"
