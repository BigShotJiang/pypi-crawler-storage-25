from __future__ import annotations

import math
import re
from typing import Any, Optional

# Validation regex for API keys (shared with api / monitor_client / codebase_memory).
_API_KEY_RE = re.compile(r"^[A-Za-z0-9_\-\.]+$")
_API_KEY_MAX_LEN = 1024


def _validate_api_key(key: str) -> str:
    """Reject empty / whitespace-laden / oversized api keys with a
    consistent ValueError. Allowed characters: A-Z a-z 0-9 _ - . —
    matches the dashboard's emitted ``rb_live_*`` key shape and rules
    out smuggled control bytes / newlines / spaces.
    """
    if not isinstance(key, str) or not key:
        raise ValueError("api_key is required")
    if len(key) > _API_KEY_MAX_LEN:
        raise ValueError(f"api_key exceeds max length of {_API_KEY_MAX_LEN}")
    if not _API_KEY_RE.match(key):
        raise ValueError(
            "api_key contains illegal characters (allowed: alnum, _-.)",
        )
    return key


def _mask_api_key(key: Optional[str]) -> str:
    """Mask an api key for safe logging / repr. Reveals only length and
    the last 4 characters — enough to disambiguate which key is in use
    without leaking the secret."""
    if not key:
        return "<token len=0 tail=----->"
    tail = key[-4:] if len(key) >= 4 else key
    return f"<token len={len(key)} tail=...{tail}>"

from reasonblocks.api import ReasonBlocksAPI
from reasonblocks.fsm import DifficultyFSM
from reasonblocks.injections import create_injections
from reasonblocks.middleware import ReasonBlocksMiddleware
from reasonblocks.monitor_client import MonitorClient
from reasonblocks.monitors import create_monitors
from reasonblocks.state import TraceStateManager
from reasonblocks.streaming_emitter import StreamingEmitter
from reasonblocks.types import FSMState

_HEDGING_WORDS = frozenset({
    "maybe", "perhaps", "possibly", "might", "could",
    "not sure", "uncertain", "i think", "probably",
    "actually", "wait", "hmm", "reconsider",
})

_ERROR_WORDS = frozenset({
    "error", "exception", "traceback", "fail", "failed",
    "crash", "bug", "broken", "issue", "problem",
})

_ENTITY_RE = re.compile(
    r"(?:[A-Za-z]:)?(?:[/\\][\w.\-]+){2,}"
    r"|\b[a-zA-Z_]\w*(?:\.\w+)+\b"
    r"|[\"'`]([^\"'`]{3,})[\"'`]"
)


class ReasonBlocks:
    """Main SDK entry point. One import, one init, one middleware addition."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: Optional[str] = None,
        token_budget: Optional[int] = None,
        monitor_names: Optional[list[str]] = None,
        fsm_thresholds: Optional[dict[str, float]] = None,
        model_routing: Optional[dict[str, str]] = None,
        e_traces_enabled: bool = True,
        live_streaming_enabled: bool = True,
        task_profile: str = "coding",
    ) -> None:
        self._api_key = _validate_api_key(api_key)
        self._base_url = base_url
        self._token_budget = token_budget
        self._monitor_names = monitor_names
        self._fsm_thresholds = fsm_thresholds or {}
        self._e_traces_enabled = e_traces_enabled
        # Live streaming ships a per-step telemetry event to rb-api as
        # each agent step completes. On by default so the dashboard
        # reflects in-progress runs. Disable for agents that want a
        # purely local / offline mode.
        self._live_streaming_enabled = live_streaming_enabled
        # ``task_profile`` picks the monitor weight preset on the
        # server. ``coding`` is the default; ``pr_review`` swaps to a
        # preset tuned for read-only reviewer agents. Built-in profiles
        # are managed server-side; users can also create custom profiles
        # via the dashboard.
        self._task_profile = task_profile

        # model_routing maps FSMState names ("FAST", "SLOW") to model identifiers
        self._model_routing: dict[FSMState, str] = {}
        if model_routing:
            for state_name, model_id in model_routing.items():
                self._model_routing[FSMState(state_name)] = model_id

    def middleware(
        self,
        *,
        run_id: Optional[str] = None,
        agent_name: str = "",
        task: str = "",
        framework: str = "langchain",
        model: str = "",
        codebase_id: str = "",
        org_id: str = "default",
        project_id: str = "default",
        metadata: Optional[dict[str, Any]] = None,
    ) -> ReasonBlocksMiddleware:
        """Create a fresh middleware instance for one agent run.

        Optional parameters set identifying metadata for the live
        telemetry stream -- they land on the ``monitor_runs`` row and
        surface in the dashboard. All default to empty strings if the
        caller doesn't care.

        ``org_id`` and ``project_id`` are the multi-tenant scope; both
        default to ``"default"`` so callers that don't know about
        multi-tenancy land in the seeded default org/project. When the
        api_key is a per-customer ``rb_live_*`` key bound to an org,
        rb-api overrides these with the key's authoritative scope --
        most callers can just leave them at the defaults.

        ``metadata`` is a free-form dict attached to the run row and
        surfaced as JSON in the dashboard. Use it for whatever
        identifying tags don't fit the named fields above (PR number,
        experiment variant, A/B group, ...).
        """
        api_kwargs: dict[str, str] = {"api_key": self._api_key}
        if self._base_url:
            api_kwargs["base_url"] = self._base_url
        api = ReasonBlocksAPI(**api_kwargs)

        fsm = DifficultyFSM(**self._fsm_thresholds)
        state_manager = TraceStateManager(token_budget=self._token_budget)
        monitors = create_monitors(self._monitor_names)
        injections = create_injections(
            api, monitors,
            e_traces_enabled=self._e_traces_enabled,
            task_profile=self._task_profile,
        )

        resolved_run_id = run_id or state_manager.trace_id

        emitter: Optional[StreamingEmitter] = None
        if self._live_streaming_enabled:
            monitor_client = MonitorClient(
                api_key=self._api_key,
                **({"base_url": self._base_url} if self._base_url else {}),
            )
            emitter = StreamingEmitter(monitor_client)

        run_metadata: dict[str, Any] = {
            "agent_name": agent_name,
            "task": task,
            "framework": framework,
            "model": model,
            "codebase_id": codebase_id,
            "org_id": org_id,
            "project_id": project_id,
            "task_profile": self._task_profile,
        }
        # Caller-provided tags ride alongside the named fields. Anything
        # not consumed by emit_run_start's pop()'d slots ends up in the
        # ``metadata`` JSON column on monitor_runs.
        if metadata:
            run_metadata.update(metadata)

        return ReasonBlocksMiddleware(
            score_fn=self.score_step,
            fsm=fsm,
            state_manager=state_manager,
            injections=injections,
            model_routing=self._model_routing or None,
            emitter=emitter,
            run_id=resolved_run_id,
            run_metadata=run_metadata,
            api=api,
        )

    def ab_middleware(
        self,
        *,
        experiment_id: str,
        unit_id: Optional[str] = None,
        on_fraction: float = 0.5,
        run_id: Optional[str] = None,
        agent_name: str = "",
        task: str = "",
        framework: str = "langchain",
        model: str = "",
        codebase_id: str = "",
        org_id: str = "default",
        project_id: str = "default",
        metadata: Optional[dict[str, Any]] = None,
    ) -> ReasonBlocksMiddleware:
        """Build a middleware for one run of an A/B experiment.

        Flips a deterministic coin (:func:`reasonblocks.experiments.assign_arm`)
        and returns either:

        * **on** — the full ReasonBlocks pipeline, identical to
          :meth:`middleware` (E1/E2/E3 + monitor steering + model routing +
          live telemetry).
        * **off** — a *vanilla* agent: no retrieval, no steering, no model
          routing, and no system-prompt rewrite (passthrough), but with live
          telemetry still on so the run is scored, recorded, and finished.

        Both arms force live streaming on (the experiment needs data and a
        ``run_finish`` from each arm regardless of this client's
        ``live_streaming_enabled`` default) and stamp ``experiment_id`` /
        ``arm`` / ``assignment_unit`` / ``rb_version`` onto the run row.
        rb-api treats ``experiment_id`` + ``arm`` as immutable once set, so a
        retry can't relabel a run.

        ``unit_id`` is the randomization unit; it defaults to the run id.
        Pass a *stable task id* if you want retried tasks to stay in their
        original arm instead of being re-drawn per attempt.

        Note: token-saving compression is part of the separate
        ``build_middleware`` config path, not this telemetry-carrying path,
        so it is not included in the ON bundle here. The comparison is
        "full retrieval+steering vs vanilla" as delivered by ``middleware``.
        """
        from reasonblocks.experiments import assign_arm, sdk_version

        api_kwargs: dict[str, str] = {"api_key": self._api_key}
        if self._base_url:
            api_kwargs["base_url"] = self._base_url
        api = ReasonBlocksAPI(**api_kwargs)

        fsm = DifficultyFSM(**self._fsm_thresholds)
        state_manager = TraceStateManager(token_budget=self._token_budget)
        resolved_run_id = run_id or state_manager.trace_id
        # Randomization unit: caller's stable id if given, else this run.
        unit = unit_id or resolved_run_id
        arm = assign_arm(experiment_id, unit, on_fraction=on_fraction)

        if arm == "on":
            monitors = create_monitors(self._monitor_names)
            injections = create_injections(
                api, monitors,
                e_traces_enabled=True,
                task_profile=self._task_profile,
            )
            model_routing = self._model_routing or None
            passthrough = False
        else:
            # Vanilla control: nothing injected, model untouched.
            injections = []
            model_routing = None
            passthrough = True

        # Telemetry is forced on for BOTH arms -- without it the control arm
        # produces no data and never emits run_finish.
        monitor_client = MonitorClient(
            api_key=self._api_key,
            **({"base_url": self._base_url} if self._base_url else {}),
        )
        emitter = StreamingEmitter(monitor_client)

        run_metadata: dict[str, Any] = {
            "agent_name": agent_name,
            "task": task,
            "framework": framework,
            "model": model,
            "codebase_id": codebase_id,
            "org_id": org_id,
            "project_id": project_id,
            "task_profile": self._task_profile,
        }
        if metadata:
            run_metadata.update(metadata)
        # Experiment tags stamped last so a caller's ``metadata`` can't
        # accidentally override the arm assignment.
        run_metadata["experiment_id"] = experiment_id
        run_metadata["arm"] = arm
        run_metadata["assignment_unit"] = unit
        run_metadata["rb_version"] = sdk_version()

        return ReasonBlocksMiddleware(
            score_fn=self.score_step,
            fsm=fsm,
            state_manager=state_manager,
            injections=injections,
            model_routing=model_routing,
            emitter=emitter,
            run_id=resolved_run_id,
            run_metadata=run_metadata,
            passthrough=passthrough,
            api=api,
        )

    def claude_messages_session(
        self,
        *,
        run_id: Optional[str] = None,
        agent_name: str = "",
        task: str = "",
        framework: str = "claude-messages",
        model: str = "",
        codebase_id: str = "",
        org_id: str = "default",
        project_id: str = "default",
        metadata: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Build a :class:`~reasonblocks.steering.SteeringSession` wired
        for the Anthropic Messages API agent loop.

        Pair with :func:`reasonblocks.integrations.claude_tools.run_messages_agent_loop`
        by passing ``session=`` to drive the full ReasonBlocks pipeline
        (FSM scoring, server-side monitor evaluation, E1/E2/E3 injection,
        model routing, live telemetry) on every turn.

        Example::

            from anthropic import Anthropic
            from reasonblocks import ReasonBlocks
            from reasonblocks.integrations.claude_tools import (
                make_claude_tools, run_messages_agent_loop,
            )

            rb = ReasonBlocks(api_key="rb_live_...")
            client = Anthropic()
            tool_specs, dispatch = make_claude_tools(memory)

            with rb.claude_messages_session(
                agent_name="reviewer",
                task="review PR #42",
                model="claude-haiku-4-5-20251001",
            ) as session:
                outcome = run_messages_agent_loop(
                    client,
                    model="claude-haiku-4-5-20251001",
                    messages=[{"role": "user", "content": "..."}],
                    tool_specs=tool_specs,
                    dispatch=dispatch,
                    session=session,
                )
        """
        from reasonblocks.injections import create_injections
        from reasonblocks.monitors import create_monitors
        from reasonblocks.steering import SteeringSession

        api_kwargs: dict[str, str] = {"api_key": self._api_key}
        if self._base_url:
            api_kwargs["base_url"] = self._base_url
        api = ReasonBlocksAPI(**api_kwargs)

        fsm = DifficultyFSM(**self._fsm_thresholds)
        state_manager = TraceStateManager(token_budget=self._token_budget)
        monitors = create_monitors(self._monitor_names)
        injections = create_injections(
            api, monitors,
            e_traces_enabled=self._e_traces_enabled,
            task_profile=self._task_profile,
        )

        resolved_run_id = run_id or state_manager.trace_id

        emitter: Optional[StreamingEmitter] = None
        if self._live_streaming_enabled:
            monitor_client = MonitorClient(
                api_key=self._api_key,
                **({"base_url": self._base_url} if self._base_url else {}),
            )
            emitter = StreamingEmitter(monitor_client)

        run_metadata: dict[str, Any] = {
            "agent_name": agent_name,
            "task": task,
            "framework": framework,
            "model": model,
            "codebase_id": codebase_id,
            "org_id": org_id,
            "project_id": project_id,
            "task_profile": self._task_profile,
        }
        if metadata:
            run_metadata.update(metadata)

        return SteeringSession(
            score_fn=self.score_step,
            fsm=fsm,
            state_manager=state_manager,
            injections=injections,
            model_routing=self._model_routing or None,
            emitter=emitter,
            run_id=resolved_run_id,
            run_metadata=run_metadata,
        )

    def openai_hooks(
        self,
        *,
        run_id: Optional[str] = None,
        agent_name: str = "",
        task: str = "",
        framework: str = "openai-agents",
        model: str = "",
        codebase_id: str = "",
        org_id: str = "default",
        project_id: str = "default",
        metadata: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Build a ``RunHooks`` adapter for the openai-agents SDK.

        Mirrors :meth:`middleware` but for the ``openai-agents``
        package's ``Runner.run(agent, input, hooks=...)`` shape.
        Drop-in replacement -- same telemetry, same dashboard rows.

        Example::

            from agents import Agent, Runner
            rb = ReasonBlocks(api_key="rb_live_...")
            hooks = rb.openai_hooks(
                run_id="my-run-1",
                agent_name="reviewer",
                task="review PR #42",
            )
            agent = Agent(name="reviewer", instructions="...", tools=[...])

            with hooks:
                result = Runner.run_sync(agent, input="...", hooks=hooks)

        Like ``rb.middleware()``, the returned object is a context
        manager (sync + async). The context manager flushes the
        emitter on exit and records the failure outcome if an
        exception escapes.
        """
        import uuid as _uuid
        from reasonblocks.integrations.openai_agents import build_hooks

        emitter: Optional[StreamingEmitter] = None
        if self._live_streaming_enabled:
            monitor_client = MonitorClient(
                api_key=self._api_key,
                **({"base_url": self._base_url} if self._base_url else {}),
            )
            emitter = StreamingEmitter(monitor_client)

        run_metadata: dict[str, Any] = {
            "agent_name": agent_name,
            "task": task,
            "framework": framework,
            "model": model,
            "codebase_id": codebase_id,
            "org_id": org_id,
            "project_id": project_id,
            "task_profile": self._task_profile,
        }
        if metadata:
            run_metadata.update(metadata)

        return build_hooks(
            emitter=emitter,
            run_id=run_id or _uuid.uuid4().hex,
            run_metadata=run_metadata,
        )

    def claude_agent_telemetry(
        self,
        *,
        run_id: Optional[str] = None,
        agent_name: str = "",
        task: str = "",
        framework: str = "claude-agent-sdk",
        model: str = "",
        codebase_id: str = "",
        org_id: str = "default",
        project_id: str = "default",
        metadata: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Build a telemetry-only adapter for the ``claude-agent-sdk``
        :func:`query` stream.

        The Claude Agent SDK runs the agent loop inside the Claude Code
        CLI process, so per-step middleware hooks aren't available —
        this adapter only emits ``run_start`` / ``step`` /
        ``run_finish`` telemetry by parsing the message stream for
        ``tool_use`` / ``tool_result`` blocks. No FSM scoring, monitor
        evaluation, E-trace injection, or model routing happens on
        this path; for the full pipeline against Claude, use
        :meth:`claude_messages_session` with the Anthropic Messages
        API loop.

        Returns a :class:`~reasonblocks.integrations.claude_tools.ClaudeAgentTelemetry`
        which is a sync + async context manager. Wrap your
        ``query(...)`` call with ``tele.wrap(...)``::

            from claude_agent_sdk import query
            from reasonblocks import ReasonBlocks

            rb = ReasonBlocks(api_key="rb_live_...")

            async with rb.claude_agent_telemetry(
                agent_name="reviewer", task="...",
                model="claude-haiku-4-5",
            ) as tele:
                async for msg in tele.wrap(
                    query(prompt="...", options={"tools": tools}),
                ):
                    ...
        """
        import uuid as _uuid
        from reasonblocks.integrations.claude_tools import (
            build_claude_agent_telemetry,
        )

        emitter: Optional[StreamingEmitter] = None
        if self._live_streaming_enabled:
            monitor_client = MonitorClient(
                api_key=self._api_key,
                **({"base_url": self._base_url} if self._base_url else {}),
            )
            emitter = StreamingEmitter(monitor_client)

        run_metadata: dict[str, Any] = {
            "agent_name": agent_name,
            "task": task,
            "framework": framework,
            "model": model,
            "codebase_id": codebase_id,
            "org_id": org_id,
            "project_id": project_id,
            "task_profile": self._task_profile,
        }
        if metadata:
            run_metadata.update(metadata)

        return build_claude_agent_telemetry(
            emitter=emitter,
            run_id=run_id or _uuid.uuid4().hex,
            run_metadata=run_metadata,
        )

    def openai_model(
        self,
        default_model: Any,
        *,
        model_factory: Optional[Any] = None,
        run_id: Optional[str] = None,
        agent_name: str = "",
        task: str = "",
        framework: str = "openai-agents",
        model: str = "",
        codebase_id: str = "",
        org_id: str = "default",
        project_id: str = "default",
        metadata: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Wrap an openai-agents ``Model`` with the full ReasonBlocks
        steering pipeline.

        ``default_model`` is any object satisfying the openai-agents
        ``Model`` protocol — typically an instance of
        ``OpenAIChatCompletionsModel`` or ``OpenAIResponsesModel``.

        ``model_factory`` is an optional callable ``(model_id: str) -> Model``
        that builds alternate Model instances when ``model_routing`` on
        this client maps the current FSM state to a different identifier.
        Without a factory, routing overrides log to the step entry but
        the wrapped default model is still used.

        Use the returned object as the ``model`` field on an
        ``Agent``. It is also a sync + async context manager that
        flushes the live-telemetry emitter on exit.

        Example::

            from agents import Agent, Runner, OpenAIChatCompletionsModel
            from reasonblocks import ReasonBlocks

            rb = ReasonBlocks(api_key="rb_live_...", model_routing={
                "FAST": "gpt-4o-mini",
                "SLOW": "gpt-4o",
            })

            wrapped = rb.openai_model(
                default_model=OpenAIChatCompletionsModel("gpt-4o"),
                model_factory=lambda mid: OpenAIChatCompletionsModel(mid),
                agent_name="reviewer",
                task="describe what this run is doing",
            )

            agent = Agent(
                name="reviewer", instructions="...",
                model=wrapped, tools=[...],
            )

            with wrapped:
                await Runner.run(agent, input="...")
        """
        from reasonblocks.injections import create_injections
        from reasonblocks.integrations.openai_agents import build_model
        from reasonblocks.monitors import create_monitors
        from reasonblocks.steering import SteeringSession

        api_kwargs: dict[str, str] = {"api_key": self._api_key}
        if self._base_url:
            api_kwargs["base_url"] = self._base_url
        api = ReasonBlocksAPI(**api_kwargs)

        fsm = DifficultyFSM(**self._fsm_thresholds)
        state_manager = TraceStateManager(token_budget=self._token_budget)
        monitors = create_monitors(self._monitor_names)
        injections = create_injections(
            api, monitors,
            e_traces_enabled=self._e_traces_enabled,
            task_profile=self._task_profile,
        )

        resolved_run_id = run_id or state_manager.trace_id

        emitter: Optional[StreamingEmitter] = None
        if self._live_streaming_enabled:
            monitor_client = MonitorClient(
                api_key=self._api_key,
                **({"base_url": self._base_url} if self._base_url else {}),
            )
            emitter = StreamingEmitter(monitor_client)

        run_metadata: dict[str, Any] = {
            "agent_name": agent_name,
            "task": task,
            "framework": framework,
            "model": model,
            "codebase_id": codebase_id,
            "org_id": org_id,
            "project_id": project_id,
            "task_profile": self._task_profile,
        }
        if metadata:
            run_metadata.update(metadata)

        session = SteeringSession(
            score_fn=self.score_step,
            fsm=fsm,
            state_manager=state_manager,
            injections=injections,
            model_routing=self._model_routing or None,
            emitter=emitter,
            run_id=resolved_run_id,
            run_metadata=run_metadata,
        )

        return build_model(
            default_model=default_model,
            session=session,
            model_factory=model_factory,
        )

    def __repr__(self) -> str:
        return f"ReasonBlocks(api_key={_mask_api_key(self._api_key)})"

    def __getstate__(self) -> dict[str, Any]:
        """Strip the API key from pickled state so ``pickle.dumps(rb)``
        doesn't ship the secret. Pair with ``__setstate__`` which refuses
        to round-trip — unpickling a ``ReasonBlocks`` is intentionally
        broken; construct a new instance with a fresh key instead.
        """
        state = dict(self.__dict__)
        state["_api_key"] = None
        return state

    def __setstate__(self, state: dict[str, Any]) -> None:
        raise NotImplementedError(
            "ReasonBlocks instances are not pickle-safe; construct a new "
            "ReasonBlocks(api_key=...) with a fresh key instead."
        )

    @staticmethod
    def score_step(text: str) -> float:
        """Heuristic difficulty scoring (0-1). Replaced by Pilot model later."""
        if not text:
            return 0.5

        words = text.lower().split()
        word_count = max(len(words), 1)

        # 1. Hedging density
        hedge_count = sum(1 for w in _HEDGING_WORDS if w in text.lower())
        hedge_score = min(hedge_count / (word_count * 0.05 + 1), 1.0)

        # 2. Length signal -- very long steps tend to indicate harder reasoning
        length_score = min(word_count / 500, 1.0)

        # 3. Error/exception language
        error_count = sum(1 for w in _ERROR_WORDS if w in text.lower())
        error_score = min(error_count / 3, 1.0)

        # 4. Entity density -- more entities = more complex
        entities = _ENTITY_RE.findall(text)
        entity_score = min(len(entities) / 10, 1.0)

        # Weighted combination
        raw = (
            0.30 * hedge_score
            + 0.25 * length_score
            + 0.25 * error_score
            + 0.20 * entity_score
        )

        # Sigmoid-ish squash to keep output in a usable range
        return 1.0 / (1.0 + math.exp(-6 * (raw - 0.5)))
