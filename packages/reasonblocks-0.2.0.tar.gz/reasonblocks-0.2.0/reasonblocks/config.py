"""Single config + factory for assembling the SDK middleware stack.

Lets a caller turn each capability on or off and tune per-feature
parameters from one place, instead of hand-wiring middleware lists.

Typical use::

    from reasonblocks import (
        ReasonBlocksAPI, ReasonBlocksConfig, build_middleware,
    )

    api = ReasonBlocksAPI(api_key="rbk_...", base_url="https://api.example")
    config = ReasonBlocksConfig(
        # Toggles
        enable_e1=True,
        enable_e2=True,
        enable_e3=True,
        enable_monitor_steering=True,
        enable_general_monitor=False,    # opt-in v1 rule-firing pack
        enable_token_saving=True,
        enable_distillation=True,        # POST /traces at session end

        # Token-saving levers
        ts_compress_threshold_chars=1800,
        ts_keep_recent_tool_messages=2,
        ts_enable_early_exit=True,

        # General monitor pack levers (when enable_general_monitor=True)
        gm_max_tool_calls=30,
        gm_cooldown=8,

    )
    middleware = build_middleware(
        config, api,
        score_fn=score_fn, fsm=fsm, state_manager=state_manager,
    )
    agent = create_agent(model=..., tools=..., middleware=middleware)

**Server-side gates** (``RB_E1_SIM_GATE``, ``RB_E2_SIM_GATE``, etc.)
remain configured via env vars on the rb-api process — they are not
client-side knobs in this config. The defaults documented here are
the values rb-api is configured with as of 2026-04 (E1=0.8, E2=0.7,
E3=scroll-all). Override on the server, not in the SDK.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional


@dataclass
class ReasonBlocksConfig:
    """Single source of truth for which capabilities to enable + their tunables."""

    # ------------------------------------------------------------------
    # Tier toggles
    # ------------------------------------------------------------------
    enable_e1: bool = True
    """Customer-scoped instance-level pattern injection (top-1 at gate)."""

    enable_e2: bool = True
    """Commons-pattern injection keyed on monitor state description."""

    enable_e3: bool = True
    """Universal standing-rule injection — scroll-all on first call."""

    enable_monitor_steering: bool = True
    """Server-side trajectory monitors via /monitors/evaluate."""

    enable_general_monitor: bool = False
    """v1 rule-firing pack (5 detectors + cooldown). Opt-in; pairs cleanly
    with token-saving when enabled."""

    enable_token_saving: bool = True
    """Tool-output compression + early-exit nudge."""

    enable_distillation: bool = True
    """POST /traces at session end so rb-api can mine E1 patterns. Pure
    client-side flag — when False the SDK does not ingest traces, so no
    new E1 entries get distilled from this customer's runs."""

    # ------------------------------------------------------------------
    # Tier thresholds (server-side; documented for reference only)
    # ------------------------------------------------------------------
    e1_top_k: int = 1
    e2_top_k: int = 2
    e3_max_patterns: int = 32

    # Documented but not enforced client-side. The SDK can request a
    # per-call sim-gate override via the API only if rb-api supports
    # it. As of 2026-04 the gates are env-globals on the server.
    e1_sim_gate_doc: float = 0.80
    e2_sim_gate_doc: float = 0.70

    # ------------------------------------------------------------------
    # Token-saving levers
    # ------------------------------------------------------------------
    ts_compress_threshold_chars: int = 1800
    ts_head_keep_chars: int = 900
    ts_tail_keep_chars: int = 700
    ts_keep_recent_tool_messages: int = 2
    ts_enable_compression: bool = True
    ts_enable_early_exit: bool = True
    ts_early_exit_min_call_index: int = 40

    ts_signals_fn: Optional[Callable[[list[dict[str, Any]]], dict[str, float]]] = None
    """Optional caller-supplied trajectory scorer for early-exit. The
    built-in monitor suite runs server-side (rb-api ``/monitors/evaluate``)
    and its scores arrive via :class:`ReasonBlocksMiddleware` — this hook
    is purely an escape hatch for callers that want a *separate* local
    detector to additionally trigger early-exit. Leave None for the
    default behavior."""

    # ------------------------------------------------------------------
    # Perplexity-based stale-message compression — opt-in
    # ------------------------------------------------------------------
    ts_enable_perplexity_compression: bool = False
    """LLMLingua-2 style word-level keep/drop on stale messages. Requires
    a classifier callable in ``ts_perplexity_classifier`` (use
    ``reasonblocks.token_saving.make_anthropic_classifier`` for the
    Haiku-as-classifier production wiring). Defaults OFF — flip ON
    per-customer to opt in."""

    ts_perplexity_classifier: Optional[Any] = None
    """A ``WordClassifier`` callable (list[str] -> list[bool]). When
    None, perplexity compression is silently skipped even if enabled."""

    ts_perplexity_recent_cutoff: int = 3
    """Messages within the last N calls keep full fidelity."""

    ts_perplexity_mid_cutoff: int = 10
    """Messages between recent_cutoff and mid_cutoff use mid keep ratio."""

    ts_perplexity_keep_ratio_mid: float = 0.55
    """Target word-keep ratio for mid-tier stale messages."""

    ts_perplexity_keep_ratio_old: float = 0.30
    """Target word-keep ratio for old-tier stale messages."""

    ts_perplexity_window_words: int = 50
    """Words per classifier window. Smaller = more API calls, finer
    decisions; larger = fewer calls, coarser decisions."""

    # ------------------------------------------------------------------
    # General monitor (v1 rule-firing pack) levers
    # ------------------------------------------------------------------
    gm_max_tool_calls: int = 30
    gm_cooldown: int = 8

    # ------------------------------------------------------------------
    # Routing / scoping
    # ------------------------------------------------------------------
    monitor_task_profile: str = "coding"
    """Server-side monitor weight profile. ``coding`` (default),
    ``pr_review``, ``qa``. Built-in presets and any custom profiles
    your org has created are listed by ``GET /monitor/profiles``."""

    monitor_weights: Optional[dict[str, float]] = None
    """Optional explicit per-monitor weight override applied on top of
    the profile preset. Partial dicts are fine — unspecified monitor
    names fall through to the profile, then to server defaults.
    Unknown monitor names are silently dropped server-side. Negative
    weights are clamped to 0. The set of monitor names is returned by
    ``GET /monitor/scorers``."""

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """One-line summary of which capabilities are on. Useful for logs."""
        return {
            "e1": self.enable_e1,
            "e2": self.enable_e2,
            "e3": self.enable_e3,
            "monitor_steering": self.enable_monitor_steering,
            "general_monitor": self.enable_general_monitor,
            "token_saving": self.enable_token_saving,
            "distillation": self.enable_distillation,
        }


def build_middleware(
    config: ReasonBlocksConfig,
    api: Any,
    *,
    score_fn: Optional[Callable[[str], float]] = None,
    fsm: Optional[Any] = None,
    state_manager: Optional[Any] = None,
    model_routing: Optional[dict] = None,
    run_id: str = "",
    run_metadata: Optional[dict] = None,
) -> list:
    """Assemble the LangChain middleware list from a config.

    Returns a list ready to pass as ``middleware=`` to
    ``langchain.create_agent``. The list is ordered:

    1. ``ReasonBlocksMiddleware`` (E1 / E2 / E3 / monitor steering)
       — only included when at least one of those four is enabled.
    2. ``GeneralMonitorMiddleware`` — opt-in.
    3. ``TokenSavingMiddleware`` — last so it can compress what
       earlier middleware injected, before the LLM call goes out.

    ``score_fn``, ``fsm``, ``state_manager`` are required when
    ``ReasonBlocksMiddleware`` is included. They're optional here so
    callers using only ``GeneralMonitor`` + ``TokenSaving`` don't
    have to construct them.
    """

    middleware: list[Any] = []
    cfg = config

    use_rb_mw = (
        cfg.enable_e1 or cfg.enable_e2 or cfg.enable_e3
        or cfg.enable_monitor_steering
    )

    if use_rb_mw:
        if score_fn is None or fsm is None or state_manager is None:
            raise ValueError(
                "score_fn, fsm, and state_manager are required when any of "
                "enable_e1 / e2 / e3 / monitor_steering is True"
            )
        from reasonblocks.injections.e1 import E1Injection
        from reasonblocks.injections.e2 import E2Injection
        from reasonblocks.injections.e3 import E3Injection
        from reasonblocks.injections.monitor_steering import (
            MonitorSteeringInjection,
        )
        from reasonblocks.middleware import ReasonBlocksMiddleware

        injections = []
        if cfg.enable_monitor_steering:
            injections.append(MonitorSteeringInjection(
                api,
                task_profile=cfg.monitor_task_profile,
                weights=cfg.monitor_weights,
            ))
        if cfg.enable_e3:
            injections.append(E3Injection(api))
        if cfg.enable_e1:
            injections.append(E1Injection(api))
        if cfg.enable_e2:
            injections.append(E2Injection(api, top_k=cfg.e2_top_k))

        middleware.append(ReasonBlocksMiddleware(
            score_fn=score_fn,
            fsm=fsm,
            state_manager=state_manager,
            injections=injections,
            model_routing=model_routing,
            run_id=run_id,
            run_metadata=run_metadata,
        ))

    if cfg.enable_general_monitor:
        from reasonblocks.general_monitor import GeneralMonitorMiddleware

        middleware.append(GeneralMonitorMiddleware(
            max_tool_calls=cfg.gm_max_tool_calls,
            cooldown=cfg.gm_cooldown,
        ))

    if cfg.enable_token_saving:
        from reasonblocks.token_saving import TokenSavingMiddleware

        middleware.append(TokenSavingMiddleware(
            compress_threshold_chars=cfg.ts_compress_threshold_chars,
            head_keep_chars=cfg.ts_head_keep_chars,
            tail_keep_chars=cfg.ts_tail_keep_chars,
            keep_recent_tool_messages=cfg.ts_keep_recent_tool_messages,
            early_exit_min_call_index=cfg.ts_early_exit_min_call_index,
            enable_compression=cfg.ts_enable_compression,
            enable_early_exit=cfg.ts_enable_early_exit,
            signals_fn=cfg.ts_signals_fn,
            enable_perplexity_compression=cfg.ts_enable_perplexity_compression,
            perplexity_classifier=cfg.ts_perplexity_classifier,
            perplexity_recent_cutoff=cfg.ts_perplexity_recent_cutoff,
            perplexity_mid_cutoff=cfg.ts_perplexity_mid_cutoff,
            perplexity_keep_ratio_mid=cfg.ts_perplexity_keep_ratio_mid,
            perplexity_keep_ratio_old=cfg.ts_perplexity_keep_ratio_old,
            perplexity_window_words=cfg.ts_perplexity_window_words,
        ))

    return middleware


__all__ = ["ReasonBlocksConfig", "build_middleware"]
