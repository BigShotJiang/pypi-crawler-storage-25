"""Python import-graph knowledge graph with blast-radius queries.

The idea: before asking an agent to re-review a file, expand the set of
files affected by the change -- a one-line edit to a core module may
invalidate assumptions about every file that imports it. This module
gives you the graph, the expansion, and an ergonomic ``blast_radius``
helper.

Usage::

    graph = ImportGraph()
    graph.build_from_files(
        {path: source_code for path, source_code in all_py_files},
    )

    affected = graph.blast_radius(
        changed_files=["pydantic/main.py"],
        depth=1,
    )
    memory.invalidate(list(affected))

Requires ``networkx``. If it's not installed, calling ``build_from_files``
raises a helpful ImportError. Consumers that only want to construct a
``CodebaseMemory`` don't need networkx at all.
"""

from __future__ import annotations

import ast
import logging
from typing import Any, Iterable, Optional

logger = logging.getLogger("reasonblocks.import_graph")

_MAX_SOURCE_BYTES = 1_000_000   # per-file cap (1 MB)
_MAX_TOTAL_BYTES = 64 * 1024 * 1024  # corpus cap (64 MB)


def _require_networkx() -> Any:
    try:
        import networkx as nx  # type: ignore
    except ImportError as exc:  # pragma: no cover - tested implicitly
        raise ImportError(
            "reasonblocks.import_graph requires networkx. "
            "Install it with: pip install networkx"
        ) from exc
    return nx


class ImportGraph:
    """Directed import dependency graph (A -> B means A imports B)."""

    def __init__(self) -> None:
        self._nx = None
        self._graph: Any = None
        # Index mapping basename ("main.py") to a list of full node
        # paths ending in that basename. Built once during
        # ``build_from_files`` so :meth:`resolve` doesn't have to
        # iterate the entire graph on every fuzzy lookup.
        self._basename_index: dict[str, list[str]] = {}

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def build_from_files(self, files: dict[str, str]) -> "ImportGraph":
        """Parse each file's imports with :mod:`ast` and wire up edges.

        ``files`` is ``{path: source_code}``. Paths that can't be parsed
        are skipped silently; callers can log the count difference from
        :meth:`stats` if they care.

        Files larger than ``_MAX_SOURCE_BYTES`` (1 MB) are skipped, and
        once total parsed bytes crosses ``_MAX_TOTAL_BYTES`` (64 MB) we
        stop parsing further files entirely. ast.parse on a generated
        / minified / hostile Python file can chew gigabytes of RAM and
        seconds of CPU, and import_graph is opportunistic best-effort
        analysis, never the critical path — bail rather than melt.

        Returns ``self`` for chaining.
        """
        nx = _require_networkx()
        g = nx.DiGraph()
        all_paths = set(files.keys())
        g.add_nodes_from(all_paths)

        total_bytes = 0
        for fp, source in files.items():
            if not fp.endswith(".py") and not fp.endswith(".pyi"):
                continue
            src = source or ""
            if len(src) > _MAX_SOURCE_BYTES:
                logger.warning(
                    "import_graph: skipping %s (%d bytes > %d cap)",
                    fp, len(src), _MAX_SOURCE_BYTES,
                )
                continue
            if total_bytes + len(src) > _MAX_TOTAL_BYTES:
                logger.warning(
                    "import_graph: total parsed bytes would exceed %d; "
                    "stopping after %d files",
                    _MAX_TOTAL_BYTES, total_bytes,
                )
                break
            total_bytes += len(src)
            try:
                tree = ast.parse(src, filename=fp)
            except Exception:
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        resolved = _resolve_import(alias.name, fp, all_paths)
                        if resolved and resolved != fp:
                            g.add_edge(fp, resolved)
                elif isinstance(node, ast.ImportFrom):
                    mod = ("." * (node.level or 0)) + (node.module or "")
                    # Resolve the module itself (``from pkg.validators import X``
                    # resolves ``pkg.validators`` to pkg/validators.py).
                    resolved = _resolve_import(mod, fp, all_paths)
                    if resolved and resolved != fp:
                        g.add_edge(fp, resolved)
                    # Also try each imported name as a submodule -- e.g.
                    # ``from pkg import types`` may actually be pulling in
                    # pkg/types.py.
                    for alias in node.names:
                        if alias.name == "*":
                            continue
                        dots = len(mod) - len(mod.lstrip("."))
                        tail = mod.lstrip(".")
                        sub = alias.name if not tail else f"{tail}.{alias.name}"
                        submod = ("." * dots) + sub
                        sub_resolved = _resolve_import(submod, fp, all_paths)
                        if sub_resolved and sub_resolved != fp:
                            g.add_edge(fp, sub_resolved)

        self._nx = nx
        self._graph = g
        # Build the basename -> [full path] index for O(1) suffix lookup
        # in :meth:`resolve` (instead of iterating every node every call).
        index: dict[str, list[str]] = {}
        for path in g.nodes:
            base = path.replace("\\", "/").rsplit("/", 1)[-1]
            index.setdefault(base, []).append(path)
        self._basename_index = index
        return self

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def blast_radius(
        self,
        changed_files: Iterable[str],
        *,
        depth: int = 1,
    ) -> set[str]:
        """Return every file affected by changes in ``changed_files``.

        Includes the changed files themselves plus their transitive
        **dependents** (files that import them) up to ``depth`` hops.

        depth=0 returns only the changed files.
        depth=1 adds direct importers (default; usually what you want).
        depth=2 adds importers-of-importers. Each hop widens the set; at
        high depth the whole repo tends to be "affected" so blast radius
        loses signal -- keep depth small.
        """
        if self._graph is None:
            return set(changed_files)
        if depth < 0:
            return set(changed_files)

        affected: set[str] = set(f for f in changed_files if f in self._graph)
        current = set(affected)
        for _ in range(depth):
            frontier: set[str] = set()
            for node in current:
                for pred in self._graph.predecessors(node):
                    if pred not in affected:
                        frontier.add(pred)
            if not frontier:
                break
            affected.update(frontier)
            current = frontier

        # Always include the raw changed files, even if not in graph.
        affected.update(changed_files)
        return affected

    def importers(self, file_path: str) -> list[str]:
        """Files that import ``file_path`` (direct dependents)."""
        if self._graph is None or file_path not in self._graph:
            return []
        return list(self._graph.predecessors(file_path))

    def dependencies(self, file_path: str) -> list[str]:
        """Files that ``file_path`` imports."""
        if self._graph is None or file_path not in self._graph:
            return []
        return list(self._graph.successors(file_path))

    def contains(self, file_path: str) -> bool:
        return self._graph is not None and file_path in self._graph

    def resolve(self, file_path: str) -> Optional[str]:
        """Fuzzy-resolve ``file_path`` to a node (exact match, then suffix
        match like ``main.py`` -> ``pydantic/main.py``).

        Uses :attr:`_basename_index` for the suffix match so the lookup
        is O(matches-with-same-basename) instead of O(|graph|).
        """
        if self._graph is None:
            return None
        if file_path in self._graph:
            return file_path
        normalized = file_path.replace("\\", "/")
        base = normalized.rsplit("/", 1)[-1]
        candidates = self._basename_index.get(base, [])
        for node in candidates:
            if node == file_path or node.endswith("/" + file_path):
                return node
        return None

    def stats(self) -> dict[str, int]:
        """Summary counters. Handy for logging after :meth:`build_from_files`."""
        if self._graph is None:
            return {"nodes": 0, "edges": 0}
        return {
            "nodes": self._graph.number_of_nodes(),
            "edges": self._graph.number_of_edges(),
        }

    # ------------------------------------------------------------------
    # Rendering for tool observations
    # ------------------------------------------------------------------

    def format_impact(self, file_path: str, *, limit: int = 15) -> str:
        """Human-readable blast-radius summary suitable for an LLM tool
        observation. Falls back cleanly when the file isn't in the graph."""
        resolved = self.resolve(file_path)
        if resolved is None:
            return f"(file not in import graph: {file_path})"

        importers = self.importers(resolved)
        deps = self.dependencies(resolved)
        lines = [f"Impact analysis for {resolved}:"]
        lines.append(
            f"  Imported by {len(importers)} files (dependents -- affected if this file breaks):"
        )
        for p in importers[:limit]:
            lines.append(f"    <- {p}")
        if len(importers) > limit:
            lines.append(f"    ... (+{len(importers) - limit} more)")
        lines.append(f"  Imports {len(deps)} files (dependencies -- this file relies on):")
        for p in deps[:limit]:
            lines.append(f"    -> {p}")
        if len(deps) > limit:
            lines.append(f"    ... (+{len(deps) - limit} more)")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Import resolution
# ---------------------------------------------------------------------------

def _resolve_import(
    module: str,
    current_file: str,
    all_files: set[str],
) -> Optional[str]:
    """Map ``import module`` back to a file in ``all_files``.

    Handles both ``pydantic.main`` (absolute) and ``.validators`` (relative
    within a package).
    """
    if not module:
        return None

    if module.startswith("."):
        # Relative import: walk up from current_file's package.
        parts = current_file.replace("\\", "/").split("/")
        if len(parts) < 2:
            return None
        pkg_parts = parts[:-1]
        n_up = 0
        while module.startswith("."):
            n_up += 1
            module = module[1:]
        for _ in range(max(n_up - 1, 0)):
            if not pkg_parts:
                return None
            pkg_parts = pkg_parts[:-1]
        base = "/".join(pkg_parts)
        if module:
            for cand in _module_paths(module, base):
                if cand in all_files:
                    return cand
        return None

    # Absolute import. Try all prefixes of the module path.
    for cand in _module_paths(module, ""):
        if cand in all_files:
            return cand
    return None


def _module_paths(module: str, base: str) -> list[str]:
    """Generate candidate file paths for ``module`` rooted under ``base``."""
    rel = module.replace(".", "/")
    out: list[str] = []
    if base:
        out.append(f"{base}/{rel}.py")
        out.append(f"{base}/{rel}/__init__.py")
    out.append(f"{rel}.py")
    out.append(f"{rel}/__init__.py")
    return out
