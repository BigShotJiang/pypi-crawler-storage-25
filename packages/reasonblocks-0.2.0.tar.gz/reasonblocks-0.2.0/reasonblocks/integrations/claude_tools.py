"""Anthropic / Claude Agent SDK tool factories over CodebaseMemory + ImportGraph.

Supports two surfaces:

1. **Anthropic Messages API (``anthropic`` package):** returns a list of
   JSONSchema tool specs suitable for ``client.messages.create(tools=...)``
   plus a ``dispatch`` callable that executes a tool-use block.

2. **Claude Agent SDK (``claude-agent-sdk`` package):** ``@tool``-decorated
   functions ready to pass into ``ClaudeSDKClient`` / ``query(...)`` as the
   ``tools`` argument, same shape as LangChain's integration.

Pick whichever matches your deployment; the underlying memory contract is
identical.
"""

from __future__ import annotations

import json
import time
from typing import Any, Callable, Optional, TYPE_CHECKING

from reasonblocks.codebase_memory import CodebaseMemory
from reasonblocks.general_monitor import GeneralMonitor
from reasonblocks.import_graph import ImportGraph

if TYPE_CHECKING:
    from reasonblocks.steering import SteeringSession


# ---------------------------------------------------------------------------
# 1. Anthropic Messages API — tool specs + dispatcher
# ---------------------------------------------------------------------------

def make_claude_tools(
    memory: CodebaseMemory,
    graph: Optional[ImportGraph] = None,
    *,
    recall_top_k: int = 5,
    recall_threshold: float = 0.25,
    enable_store: bool = True,
    enable_impact: bool = True,
) -> tuple[list[dict[str, Any]], Callable[[str, dict[str, Any]], str]]:
    """Return ``(tool_specs, dispatch)`` for the Anthropic Messages API.

    ``tool_specs`` is a list of ``{name, description, input_schema}`` dicts
    suitable for ``client.messages.create(tools=tool_specs, ...)``.

    ``dispatch(tool_name, tool_input)`` runs the named tool and returns its
    string result (the ``content`` to send back in a ``tool_result`` block).
    Unknown tool names raise :class:`KeyError` so callers can surface the
    model's error cleanly.

    Example::

        tool_specs, dispatch = make_claude_tools(memory, graph)
        resp = client.messages.create(tools=tool_specs, messages=..., model=...)
        for block in resp.content:
            if block.type == "tool_use":
                result = dispatch(block.name, block.input)
                # ... append tool_result with result ...
    """
    tool_specs: list[dict[str, Any]] = []
    handlers: dict[str, Callable[[dict[str, Any]], str]] = {}

    tool_specs.append({
        "name": "recall_findings",
        "description": (
            "Search the ReasonBlocks memory for prior findings relevant to the "
            "query. Call this BEFORE reading files. If it returns findings about "
            "a file, trust them and skip re-reading that file."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural-language description of what you're looking for.",
                },
            },
            "required": ["query"],
        },
    })
    handlers["recall_findings"] = lambda inp: memory.format_recall(
        str(inp.get("query", "")),
        top_k=recall_top_k,
        score_threshold=recall_threshold,
    )

    if enable_store:
        tool_specs.append({
            "name": "store_finding",
            "description": (
                "Persist a finding to ReasonBlocks memory so future agent runs "
                "can recall it. Store small, self-contained facts; keep each "
                "entry tight and factual."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "content": {"type": "string", "description": "The finding (<8000 chars)."},
                    "file_path": {"type": "string", "description": "Repo-relative path."},
                    "finding_type": {
                        "type": "string",
                        "description": "Short tag: bug | behavior | pattern | note.",
                    },
                },
                "required": ["content"],
            },
        })
        handlers["store_finding"] = lambda inp: _dispatch_store(memory, inp)

    if graph is not None and enable_impact:
        tool_specs.append({
            "name": "impact_analysis",
            "description": (
                "Use the repo's import graph to see what depends on a file and "
                "what it depends on. Helps judge the blast radius of a change."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Repo-relative path (e.g. 'pydantic/main.py').",
                    },
                },
                "required": ["file_path"],
            },
        })
        handlers["impact_analysis"] = lambda inp: graph.format_impact(
            str(inp.get("file_path", "")),
        )

    def dispatch(tool_name: str, tool_input: dict[str, Any]) -> str:
        if tool_name not in handlers:
            raise KeyError(f"unknown tool: {tool_name}")
        try:
            return handlers[tool_name](tool_input)
        except Exception as exc:
            return f"(tool '{tool_name}' raised: {type(exc).__name__}: {exc})"

    return tool_specs, dispatch


def _dispatch_store(memory: CodebaseMemory, inp: dict[str, Any]) -> str:
    content = str(inp.get("content", "") or "")
    if not content:
        return "store skipped: empty content"
    fid = memory.store(
        content=content,
        file_path=str(inp.get("file_path", "") or ""),
        finding_type=str(inp.get("finding_type", "note") or "note"),
    )
    return f"stored (id={fid})" if fid else "store failed"


# ---------------------------------------------------------------------------
# 2. claude-agent-sdk — @tool-decorated functions
# ---------------------------------------------------------------------------

def make_claude_agent_sdk_tools(
    memory: CodebaseMemory,
    graph: Optional[ImportGraph] = None,
    *,
    recall_top_k: int = 5,
    recall_threshold: float = 0.25,
    enable_store: bool = True,
    enable_impact: bool = True,
) -> list[Any]:
    """Return a list of ``@tool``-decorated functions for the
    ``claude-agent-sdk`` package.

    The decorator returns SDK-specific tool descriptors, so this import is
    deferred; callers without the package installed never pay for it.
    """
    try:
        from claude_agent_sdk import tool  # type: ignore
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "make_claude_agent_sdk_tools requires the claude-agent-sdk "
            "package. Install with: pip install claude-agent-sdk"
        ) from exc

    tools: list[Any] = []

    @tool(
        "recall_findings",
        "Search ReasonBlocks memory for prior findings relevant to a query.",
        {"query": str},
    )
    async def recall_findings(args: dict) -> dict:
        text = memory.format_recall(
            str(args.get("query", "")),
            top_k=recall_top_k,
            score_threshold=recall_threshold,
        )
        return {"content": [{"type": "text", "text": text}]}

    tools.append(recall_findings)

    if enable_store:

        @tool(
            "store_finding",
            "Persist a finding to ReasonBlocks memory.",
            {"content": str, "file_path": str, "finding_type": str},
        )
        async def store_finding(args: dict) -> dict:
            text = _dispatch_store(memory, args)
            return {"content": [{"type": "text", "text": text}]}

        tools.append(store_finding)

    if graph is not None and enable_impact:

        @tool(
            "impact_analysis",
            "Use the repo's import graph to see what depends on a file.",
            {"file_path": str},
        )
        async def impact_analysis(args: dict) -> dict:
            text = graph.format_impact(str(args.get("file_path", "")))
            return {"content": [{"type": "text", "text": text}]}

        tools.append(impact_analysis)

    return tools


# ---------------------------------------------------------------------------
# Helper: run a full Messages API agent loop with these tools
# ---------------------------------------------------------------------------

def run_messages_agent_loop(
    client: Any,
    *,
    model: str,
    messages: list[dict[str, Any]],
    tool_specs: list[dict[str, Any]],
    dispatch: Callable[[str, dict[str, Any]], str],
    system: str = "",
    max_steps: int = 40,
    max_tokens: int = 4096,
    session: Optional["SteeringSession"] = None,
    general_monitor: Optional[GeneralMonitor] = None,
) -> dict[str, Any]:
    """Run the Anthropic Messages tool-use loop to completion.

    Useful when you want the batteries-included behavior without wiring
    the tool_use / tool_result turns by hand. Returns::

        {
            "final_text": "<agent's last assistant turn, text only>",
            "messages": [...],       # full message history
            "stop_reason": "end_turn" | "max_steps" | "...",
            "tool_calls": [(name, input, result), ...],
        }

    The ``client`` is expected to be an ``anthropic.Anthropic`` (or
    AsyncAnthropic) instance. This helper uses the synchronous API.

    Pass ``session=`` (a :class:`~reasonblocks.steering.SteeringSession`
    obtained from :meth:`reasonblocks.ReasonBlocks.claude_messages_session`)
    to enable the full ReasonBlocks steering pipeline: per-turn FSM
    scoring, server-side monitor evaluation, E1/E2/E3 injection, model
    routing, and live telemetry. With ``session=None`` the loop runs
    plain Messages API calls — same behavior as before this kwarg
    existed.

    Pass ``general_monitor=`` (a :class:`~reasonblocks.general_monitor.GeneralMonitor`)
    to add the rule-based observation/pause monitor in parallel to the
    SteeringSession. Firings append a ``[GENERAL-MONITOR]`` block to the
    next call's system prompt. Same wiring shape as the LangChain
    ``GeneralMonitorMiddleware`` and the OpenAI Agents ``ReasonBlocksModel``
    -- one rule fires per call, priority-ordered, per-rule cooldown.
    """
    history = list(messages)
    tool_calls: list[tuple[str, dict[str, Any], str]] = []
    final_text = ""
    stop_reason = "max_steps"
    gm_call_index = 0

    for _ in range(max_steps):
        # Steering pipeline (begin_step): score the last assistant
        # thought, run monitors, retrieve E-traces. None on the first
        # iteration runs the first-call path (E3-only).
        decision = None
        effective_model = model
        effective_system = system
        if session is not None:
            thought, action, action_input, observation = (
                _extract_last_signals(history)
            )
            decision = session.begin_step(
                thought=thought,
                action=action,
                action_input=action_input,
                observation=observation,
            )
            effective_system = decision.compose_system_prompt(system)
            if decision.model_override:
                effective_model = _strip_provider_prefix(
                    decision.model_override,
                )

        # Optional GeneralMonitor pass over the assembled history. Firings
        # append a [GENERAL-MONITOR] block to the system prompt parallel
        # to SteeringSession's [REASONBLOCKS] block. Failures swallowed
        # so the loop never breaks because the monitor is unhappy.
        if general_monitor is not None:
            try:
                gm_call_index += 1
                gm_history = _anthropic_messages_to_general_monitor_history(history)
                fire = general_monitor.check(gm_history, gm_call_index)
                if fire is not None:
                    effective_system = _append_general_monitor_block(
                        effective_system, fire.injection_text,
                    )
            except Exception:
                import logging
                logging.getLogger("reasonblocks.claude_tools").warning(
                    "general_monitor pass failed", exc_info=True,
                )

        kwargs: dict[str, Any] = {
            "model": effective_model,
            "messages": history,
            "tools": tool_specs,
            "max_tokens": max_tokens,
        }
        if effective_system:
            kwargs["system"] = effective_system

        t0 = time.perf_counter()
        resp = client.messages.create(**kwargs)
        elapsed_ms = (time.perf_counter() - t0) * 1000.0

        # Persist the assistant turn.
        history.append({"role": "assistant", "content": _content_to_list(resp.content)})

        # Accumulate any text, then collect tool_use blocks.
        text_parts: list[str] = []
        tool_uses: list[tuple[str, str, dict[str, Any]]] = []
        for block in resp.content:
            btype = getattr(block, "type", None)
            if btype == "text":
                text_parts.append(block.text)
            elif btype == "tool_use":
                tool_uses.append((block.id, block.name, dict(block.input or {})))
        if text_parts:
            final_text = "\n".join(text_parts)

        # Steering pipeline (end_step): stamp tokens, tool calls, and
        # latency onto the session log + emit live telemetry.
        if session is not None and decision is not None:
            session.end_step(
                decision,
                model_id=effective_model,
                tokens=_extract_anthropic_tokens(resp),
                tool_calls=[name for _id, name, _inp in tool_uses],
                latency_ms=elapsed_ms,
            )

        if resp.stop_reason != "tool_use":
            stop_reason = resp.stop_reason
            break

        # Dispatch every tool_use and send back a single user turn with
        # all the tool_result blocks.
        results_blocks: list[dict[str, Any]] = []
        for tool_id, name, inp in tool_uses:
            try:
                result_text = dispatch(name, inp)
            except Exception as exc:
                result_text = f"(dispatch error: {type(exc).__name__}: {exc})"
            tool_calls.append((name, inp, result_text))
            results_blocks.append({
                "type": "tool_result",
                "tool_use_id": tool_id,
                "content": result_text,
            })
        history.append({"role": "user", "content": results_blocks})

    return {
        "final_text": final_text,
        "messages": history,
        "stop_reason": stop_reason,
        "tool_calls": tool_calls,
    }


# ---------------------------------------------------------------------------
# Helpers used by run_messages_agent_loop when a SteeringSession is wired in
# ---------------------------------------------------------------------------

def _strip_provider_prefix(model_id: str) -> str:
    """Strip a ``provider:`` prefix (e.g. ``anthropic:``) from a model id.

    The model_routing dict accepts LangChain-style identifiers like
    ``"anthropic:claude-haiku-4-5-20251001"`` for parity with the
    middleware path; the bare Anthropic Messages API expects just the
    model slug. Pass-through if there's no recognized prefix.
    """
    if ":" in model_id:
        return model_id.split(":", 1)[1]
    return model_id


def _extract_anthropic_tokens(resp: Any) -> int:
    """Sum input + output tokens from an Anthropic Messages response.

    Falls back to 0 if usage isn't present (e.g. mocked responses in tests).
    """
    usage = getattr(resp, "usage", None)
    if usage is None:
        return 0
    try:
        in_t = int(getattr(usage, "input_tokens", 0) or 0)
        out_t = int(getattr(usage, "output_tokens", 0) or 0)
        return in_t + out_t
    except (TypeError, ValueError):
        return 0


def _extract_last_signals(
    history: list[dict[str, Any]],
) -> tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    """Extract (thought, action, action_input, observation) from the
    Anthropic Messages history for the most recent agent step.

    ``thought`` is the text content of the last assistant turn.
    ``action`` / ``action_input`` come from the last ``tool_use`` block
    in the assistant turn (if any). ``observation`` is the most recent
    ``tool_result`` content.

    All four return ``None`` on the first iteration when no assistant
    turn has happened yet — that triggers the SteeringSession's
    first-call path.
    """
    thought: Optional[str] = None
    action: Optional[str] = None
    action_input: Optional[str] = None
    observation: Optional[str] = None

    # Walk backwards looking for the most recent assistant turn for
    # thought + action; pick up the most recent tool_result for
    # observation along the way.
    for msg in reversed(history):
        if observation is None and msg.get("role") == "user":
            for block in msg.get("content", []) or []:
                if isinstance(block, dict) and block.get("type") == "tool_result":
                    obs = block.get("content")
                    if isinstance(obs, str):
                        observation = obs[:400]
                    elif isinstance(obs, list):
                        # tool_result content can be a list of blocks
                        text_parts = [
                            b.get("text", "") if isinstance(b, dict) else str(b)
                            for b in obs
                        ]
                        joined = " ".join(t for t in text_parts if t).strip()
                        if joined:
                            observation = joined[:400]
                    break
            continue

        if msg.get("role") != "assistant":
            continue

        text_parts: list[str] = []
        last_tool_use: Optional[dict[str, Any]] = None
        for block in msg.get("content", []) or []:
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "text":
                t = block.get("text")
                if isinstance(t, str) and t.strip():
                    text_parts.append(t)
            elif btype == "tool_use":
                last_tool_use = block
        if text_parts:
            thought = " ".join(text_parts).strip()
        if last_tool_use is not None:
            action = last_tool_use.get("name")
            inp = last_tool_use.get("input")
            action_input = json.dumps(inp) if inp is not None else None
        # Stop after the first (most recent) assistant turn we see.
        break

    return thought, action, action_input, observation


# ---------------------------------------------------------------------------
# 4. Claude Agent SDK — telemetry-only stream wrapper
#
# The Claude Agent SDK runs the agent loop inside the Claude Code CLI, so
# we have no per-step injection hook. What we CAN do is observe the stream
# of messages and emit run_start / step / run_finish telemetry to rb-api so
# the run shows up on the dashboard with per-tool timing and counts.
# ---------------------------------------------------------------------------


class ClaudeAgentTelemetry:
    """Telemetry-only adapter for the ``claude-agent-sdk`` query() stream.

    Wrap an async iterator returned from
    :func:`claude_agent_sdk.query` to emit ``run_start``, per-tool
    ``step``, and ``run_finish`` events to rb-api as messages flow
    through. No steering injection happens on this path — the Claude
    Agent SDK loop is owned by the Claude Code CLI process.

    Use as a sync/async context manager::

        from claude_agent_sdk import query
        from reasonblocks import ReasonBlocks

        rb = ReasonBlocks(api_key="rb_live_...")

        async with rb.claude_agent_telemetry(
            agent_name="reviewer",
            task="investigate MarkerWidget",
            model="claude-haiku-4-5",
        ) as tele:
            async for message in tele.wrap(
                query(prompt="...", options={"tools": tools}),
            ):
                # process message yourself; telemetry was already
                # emitted as a side effect of wrap()
                ...
    """

    def __init__(
        self,
        *,
        emitter: Any,
        run_id: str,
        run_metadata: dict[str, Any],
    ) -> None:
        self._emitter = emitter
        self._run_id = run_id
        self._run_metadata = dict(run_metadata)
        self._step_index = 0
        self._run_started_emitted = False
        self._run_finished_emitted = False
        self._explicit_outcome: Optional[str] = None
        # Buffer assistant text blocks so the next tool_use we see can
        # carry the most recent thought as context on the step event.
        self._buffered_thought: str = ""
        # Map tool_use_id -> (name, input, started_at) so we can pair
        # tool_use with its tool_result and compute per-step latency.
        self._inflight: dict[str, dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def mark_failure(self, *, reason: str = "failure") -> None:
        self._explicit_outcome = reason

    def close(self, *, timeout: float = 5.0) -> None:
        if self._emitter is not None:
            self._emitter.close(timeout=timeout)

    def __enter__(self) -> "ClaudeAgentTelemetry":
        self._maybe_emit_run_start()
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        if self._explicit_outcome is not None:
            outcome = self._explicit_outcome
        elif exc_type is not None:
            outcome = f"failure: {exc_type.__name__}"
        else:
            outcome = "success"
        self._maybe_emit_run_finish(outcome_status=outcome)
        self.close()

    async def __aenter__(self) -> "ClaudeAgentTelemetry":
        return self.__enter__()

    async def __aexit__(self, exc_type, exc_value, traceback) -> None:
        self.__exit__(exc_type, exc_value, traceback)

    # ------------------------------------------------------------------
    # Stream wrapping
    # ------------------------------------------------------------------

    async def wrap(self, async_iter: Any):
        """Iterate ``async_iter`` (the result of ``claude_agent_sdk.query(...)``),
        emit telemetry as a side effect, and yield each message back to
        the caller unchanged."""
        self._maybe_emit_run_start()
        try:
            async for message in async_iter:
                try:
                    self._observe(message)
                except Exception:  # pragma: no cover — telemetry must never crash the run
                    pass
                yield message
        except BaseException:
            self._explicit_outcome = self._explicit_outcome or "failure"
            raise

    def _observe(self, message: Any) -> None:
        content = getattr(message, "content", None)
        if not content:
            return
        for block in content:
            btype = getattr(block, "type", None)
            if btype == "text":
                text = getattr(block, "text", "") or ""
                if text.strip():
                    if self._buffered_thought:
                        self._buffered_thought = (
                            self._buffered_thought + " " + text
                        ).strip()
                    else:
                        self._buffered_thought = text.strip()
            elif btype == "tool_use":
                tool_id = getattr(block, "id", "") or ""
                name = getattr(block, "name", "") or ""
                inp = getattr(block, "input", None) or {}
                self._inflight[tool_id] = {
                    "name": name,
                    "input": inp,
                    "started_at": time.perf_counter(),
                    "thought": self._buffered_thought,
                }
                # Reset buffer so the next text accumulates fresh for
                # the next tool call.
                self._buffered_thought = ""
            elif btype == "tool_result":
                tool_use_id = (
                    getattr(block, "tool_use_id", "")
                    or getattr(block, "id", "")
                    or ""
                )
                state = self._inflight.pop(tool_use_id, None)
                latency_ms = 0.0
                name: Optional[str] = None
                action_input: Optional[str] = None
                thought: Optional[str] = None
                if state is not None:
                    name = state["name"] or None
                    inp = state["input"]
                    action_input = (
                        json.dumps(inp) if inp is not None else None
                    )
                    thought = state["thought"] or None
                    latency_ms = (
                        time.perf_counter() - float(state["started_at"])
                    ) * 1000.0
                observation = self._observation_text(block)
                is_error = False
                if observation:
                    obs_lower = observation.lower()
                    is_error = any(
                        w in obs_lower
                        for w in ("error", "exception", "traceback", "failed")
                    )
                self._emit_step(
                    thought=thought,
                    action=name,
                    action_input=action_input,
                    observation=observation,
                    is_error=is_error,
                    tool_calls=[name] if name else [],
                    latency_ms=latency_ms,
                )

    @staticmethod
    def _observation_text(block: Any) -> Optional[str]:
        content = getattr(block, "content", None)
        if isinstance(content, str):
            return content[:400]
        if isinstance(content, list):
            parts: list[str] = []
            for b in content:
                t = getattr(b, "text", None)
                if t is None and isinstance(b, dict):
                    t = b.get("text")
                if isinstance(t, str) and t:
                    parts.append(t)
            joined = " ".join(parts).strip()
            return joined[:400] if joined else None
        return None

    # ------------------------------------------------------------------
    # Emit helpers
    # ------------------------------------------------------------------

    def _maybe_emit_run_start(self) -> None:
        if self._emitter is None or self._run_started_emitted:
            return
        self._run_started_emitted = True
        meta = dict(self._run_metadata)
        self._emitter.emit_run_start({
            "run_id":       self._run_id,
            "agent_name":   meta.pop("agent_name", "") or "",
            "task":         meta.pop("task", "") or "",
            "model":        meta.pop("model", "") or "",
            "framework":    meta.pop("framework", "claude-agent-sdk") or "claude-agent-sdk",
            "codebase_id":  meta.pop("codebase_id", "") or "",
            "org_id":       meta.pop("org_id", "default") or "default",
            "project_id":   meta.pop("project_id", "default") or "default",
            "task_profile": meta.pop("task_profile", "coding") or "coding",
            "metadata":     meta,
        })

    def _emit_step(
        self,
        *,
        thought: Optional[str],
        action: Optional[str],
        action_input: Optional[str],
        observation: Optional[str],
        is_error: bool,
        tool_calls: list[str],
        latency_ms: float,
    ) -> None:
        if self._emitter is None:
            return
        idx = self._step_index
        self._step_index += 1
        self._emitter.emit_step({
            "run_id": self._run_id,
            "step_index": idx,
            "action": action,
            "action_input": action_input,
            "thought": thought or "",
            "observation": observation,
            "is_error": is_error,
            "tokens": 0,  # not available on this path
            "injections": [],
            "injection_sources": [],
            "intervention_texts": [],
            "monitors_fired": [],
            "failure_type": None,
            "metadata": {
                "fsm_state": "",
                "difficulty": None,
                "latency_ms": round(latency_ms, 2),
            },
        })

    def _maybe_emit_run_finish(self, *, outcome_status: str) -> None:
        if self._emitter is None or self._run_finished_emitted:
            return
        self._run_finished_emitted = True
        self._emitter.emit_run_finish({
            "run_id": self._run_id,
            "outcome": outcome_status,
        })


def build_claude_agent_telemetry(
    *,
    emitter: Any,
    run_id: str,
    run_metadata: dict[str, Any],
) -> ClaudeAgentTelemetry:
    """Internal: construct a ClaudeAgentTelemetry. Symmetric with
    :func:`reasonblocks.integrations.openai_agents.build_hooks`."""
    return ClaudeAgentTelemetry(
        emitter=emitter, run_id=run_id, run_metadata=run_metadata,
    )


def _content_to_list(content: Any) -> list[dict[str, Any]]:
    """Normalize an assistant message's ``content`` into the list-of-dicts
    shape the next API call expects."""
    out: list[dict[str, Any]] = []
    for block in content or []:
        btype = getattr(block, "type", None)
        if btype == "text":
            out.append({"type": "text", "text": block.text})
        elif btype == "tool_use":
            out.append({
                "type": "tool_use",
                "id": block.id,
                "name": block.name,
                "input": json.loads(json.dumps(block.input or {})),
            })
    return out


# ---------------------------------------------------------------------------
# General-monitor adapters (parallel to the OpenAI Agents integration)
# ---------------------------------------------------------------------------

_GENERAL_MONITOR_MARKER = "[GENERAL-MONITOR]"


def _append_general_monitor_block(system: Optional[str], text: str) -> str:
    """Append a [GENERAL-MONITOR] block to ``system``. Mirrors the
    [REASONBLOCKS] block convention used by SteeringSession, so the two
    parallel injection channels coexist in the same system prompt."""
    base = (system or "").rstrip()
    if base:
        return f"{base}\n\n{_GENERAL_MONITOR_MARKER}\n{text}"
    return f"{_GENERAL_MONITOR_MARKER}\n{text}"


def _anthropic_messages_to_general_monitor_history(
    messages: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Convert an Anthropic Messages API ``history`` (list of {role, content}
    dicts where assistant content is a list of text/tool_use blocks and
    user content is either a string or a list of text/tool_result blocks)
    into the normalized HistoryEntry shape ``GeneralMonitor.check`` consumes.

    Mirrors the OpenAI Agents adapter at
    ``openai_agents._oa_input_to_general_monitor_history`` and the LangChain
    adapter at ``general_monitor._langchain_messages_to_history``.
    """
    out: list[dict[str, Any]] = []
    step = 0
    for m in messages:
        if not isinstance(m, dict):
            continue
        role = m.get("role")
        content = m.get("content")

        if role == "assistant":
            text_parts: list[str] = []
            tool_calls: list[dict[str, Any]] = []
            if isinstance(content, list):
                for block in content:
                    if not isinstance(block, dict):
                        continue
                    btype = block.get("type")
                    if btype == "text":
                        t = block.get("text", "")
                        if t:
                            text_parts.append(str(t))
                    elif btype == "tool_use":
                        tool_calls.append({
                            "name": str(block.get("name") or ""),
                            "args": dict(block.get("input") or {}),
                            "id":   str(block.get("id") or ""),
                        })
            elif isinstance(content, str):
                text_parts.append(content)
            out.append({
                "role": "ai", "step": step,
                "content": "\n".join(text_parts),
                "tool_calls": tool_calls,
            })
            step += 1
            continue

        if role == "user":
            # User messages may carry tool_result blocks (the loop appends
            # one user turn after each batch of tool_use), or plain text.
            if isinstance(content, list):
                # Each tool_result becomes one tool entry.
                emitted_any_tool = False
                for block in content:
                    if not isinstance(block, dict):
                        continue
                    if block.get("type") == "tool_result":
                        tcid = str(block.get("tool_use_id") or "")
                        c = block.get("content")
                        if isinstance(c, list):
                            c = "".join(
                                (b.get("text", "") if isinstance(b, dict) else "")
                                for b in c
                            )
                        out.append({
                            "role": "tool", "step": step,
                            "tool_call_id": tcid, "name": "",
                            "content": str(c or ""),
                        })
                        emitted_any_tool = True
                if emitted_any_tool:
                    step += 1
                    continue
                # Otherwise treat as a plain user text message.
                text = " ".join(
                    (b.get("text", "") if isinstance(b, dict) else "")
                    for b in content
                    if isinstance(b, dict) and b.get("type") == "text"
                )
                out.append({
                    "role": "user", "step": step,
                    "content": text, "tool_calls": [],
                })
                step += 1
            elif isinstance(content, str):
                out.append({
                    "role": "user", "step": step,
                    "content": content, "tool_calls": [],
                })
                step += 1
    return out
