"""OpenAI Agents SDK integration: tool factory + RunHooks.

The ``openai-agents`` package (``from agents import Agent, Runner, ...``)
uses a different lifecycle than LangChain -- there's no middleware
chain, just a ``RunHooks`` callback object passed to ``Runner.run``.
This module provides the equivalent of ``rb.middleware()`` for that
shape: a hooks object that emits the same ``run_start / step /
run_finish`` telemetry the LangChain middleware does, plus a tool
factory for ``CodebaseMemory`` + ``ImportGraph``.

Usage::

    from agents import Agent, Runner
    from reasonblocks import ReasonBlocks
    from reasonblocks.integrations import make_openai_tools

    rb = ReasonBlocks(api_key="rb_live_...")
    hooks = rb.openai_hooks(
        run_id="my-run-1",
        agent_name="bugfixer",
        task="describe what this run is doing",
    )

    agent = Agent(
        name="reviewer",
        instructions="...",
        tools=[*make_openai_tools(memory, graph), *your_tools],
    )

    result = await Runner.run(agent, input="...", hooks=hooks)
    # hooks.on_agent_end auto-fires run_finish; nothing else to call.

The hooks object is also a context manager (``async with hooks:`` /
``with hooks:``) so an exception path still flushes the failure
outcome -- mirrors the ``with mw:`` pattern from the LangChain
middleware.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable, Optional, TYPE_CHECKING

from reasonblocks.codebase_memory import CodebaseMemory
from reasonblocks.general_monitor import GeneralMonitor
from reasonblocks.import_graph import ImportGraph
from reasonblocks.streaming_emitter import StreamingEmitter

if TYPE_CHECKING:
    from reasonblocks.steering import SteeringSession

logger = logging.getLogger("reasonblocks.openai_agents")


# ---------------------------------------------------------------------------
# 1. Tools -- function_tool wrappers over CodebaseMemory + ImportGraph
# ---------------------------------------------------------------------------

def make_openai_tools(
    memory: Optional[CodebaseMemory] = None,
    graph: Optional[ImportGraph] = None,
    *,
    recall_top_k: int = 5,
    recall_threshold: float = 0.25,
    enable_recall: bool = True,
    enable_store: bool = True,
    enable_impact: bool = True,
) -> list[Any]:
    """Return ``function_tool``-decorated callables ready for
    ``Agent(tools=[...])``.

    Mirrors the langchain_tools / claude_tools factories. The
    underlying CodebaseMemory + ImportGraph contracts are identical;
    only the framework decoration differs.
    """
    try:
        from agents import function_tool
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "reasonblocks.integrations.openai_agents requires the "
            "openai-agents package. Install with: pip install openai-agents"
        ) from exc

    tools: list[Any] = []

    if enable_recall and memory is not None:

        @function_tool
        def recall_findings(query: str) -> str:
            """Search ReasonBlocks memory for prior findings.

            Call this BEFORE reading files. If it returns findings
            about a file, trust them and skip re-reading that file.

            Args:
                query: Natural-language description of what you're
                    looking for.
            """
            return memory.format_recall(
                query, top_k=recall_top_k, score_threshold=recall_threshold,
            )

        tools.append(recall_findings)

    if enable_store and memory is not None:

        @function_tool
        def store_finding(
            content: str,
            file_path: str = "",
            finding_type: str = "note",
        ) -> str:
            """Persist a finding for future agent runs.

            Store small, self-contained facts. Don't store long
            paragraphs; keep each finding tight and factual.

            Args:
                content: The finding (<8000 chars).
                file_path: Repo-relative path the finding is about.
                finding_type: Short tag (bug | behavior | pattern | note).
            """
            fid = memory.store(
                content=content,
                file_path=file_path,
                finding_type=finding_type,
            )
            return f"stored (id={fid})" if fid else "store failed"

        tools.append(store_finding)

    if graph is not None and enable_impact:

        @function_tool
        def impact_analysis(file_path: str) -> str:
            """Look up dependents and dependencies for a file via the
            repo's import graph. Helps judge the blast radius of a
            change.

            Args:
                file_path: Repo-relative path (e.g. 'pydantic/main.py').
            """
            return graph.format_impact(file_path)

        tools.append(impact_analysis)

    return tools


# ---------------------------------------------------------------------------
# 2. RunHooks -- telemetry emission via the same StreamingEmitter
# ---------------------------------------------------------------------------

def _make_run_hooks_class():
    """Build the RunHooks subclass lazily so importing this module
    doesn't force the openai-agents dependency on callers who only
    want the tool factory."""
    try:
        from agents import RunHooks
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "ReasonBlocksHooks requires the openai-agents package. "
            "Install with: pip install openai-agents"
        ) from exc

    class ReasonBlocksHooks(RunHooks):
        """RunHooks adapter that pushes telemetry through a
        :class:`StreamingEmitter`.

        Fires ``run_start`` on the first ``on_agent_start`` callback,
        a ``step`` event on every ``on_tool_end``, and ``run_finish``
        on ``on_agent_end`` (or via the context manager's __exit__ if
        the run raised).

        Don't construct this directly -- use ``rb.openai_hooks(...)``
        from a configured :class:`~reasonblocks.client.ReasonBlocks`
        instance, which wires the emitter and run metadata.
        """

        def __init__(
            self,
            *,
            emitter: Optional[StreamingEmitter],
            run_id: str,
            run_metadata: dict[str, Any],
        ) -> None:
            super().__init__()
            self._emitter = emitter
            self._run_id = run_id
            self._run_metadata = dict(run_metadata)
            self._step_index = 0
            self._run_started_emitted = False
            self._run_finished_emitted = False
            self._explicit_outcome: Optional[str] = None
            # Track per-tool start times so on_tool_end can emit a
            # latency_ms metadata field.
            self._tool_started_at: dict[int, float] = {}
            # Token attribution: on_llm_end accumulates each LLM
            # response's usage. on_tool_end drains it onto the step
            # event it's about to emit. One LLM response can produce
            # several tool calls; we attribute all the tokens to the
            # FIRST tool call after that response (subsequent tools
            # from the same response stamp 0). The sum is correct;
            # per-step is approximate -- which matches how a step
            # is conceptually defined here ("one tool turn").
            self._pending_tokens: int = 0
            self._total_tokens: int = 0

        # ----- emit helpers (mirror middleware's _maybe_emit_*) ---

        def _maybe_emit_run_start(self) -> None:
            if self._emitter is None or self._run_started_emitted:
                return
            self._run_started_emitted = True
            meta = dict(self._run_metadata)
            self._emitter.emit_run_start({
                "run_id":       self._run_id,
                "agent_name":   meta.pop("agent_name", "") or "",
                "task":         meta.pop("task", "") or "",
                "model":        meta.pop("model", "") or "",
                "framework":    meta.pop("framework", "openai-agents") or "openai-agents",
                "codebase_id":  meta.pop("codebase_id", "") or "",
                "org_id":       meta.pop("org_id", "default") or "default",
                "project_id":   meta.pop("project_id", "default") or "default",
                "task_profile": meta.pop("task_profile", "coding") or "coding",
                "metadata":     meta,
            })

        def _maybe_emit_run_finish(self, *, outcome_status: str) -> None:
            if self._emitter is None:
                return
            self._emitter.emit_run_finish({
                "run_id": self._run_id,
                "outcome": outcome_status,
            })
            self._run_finished_emitted = True

        # ----- public override hook ------------------------------

        def mark_failure(self, *, reason: str = "failure") -> None:
            """Override the default "success" outcome with the given
            reason. Same semantics as
            :meth:`ReasonBlocksMiddleware.mark_failure`."""
            self._explicit_outcome = reason

        def close(self, timeout: float = 5.0) -> None:
            """Drain the emitter queue and stop the worker. Idempotent."""
            if self._emitter is not None:
                self._emitter.close(timeout=timeout)

        # ----- RunHooks lifecycle --------------------------------

        async def on_agent_start(self, context, agent) -> None:
            del context, agent
            try:
                self._maybe_emit_run_start()
            except Exception:
                logger.warning("on_agent_start emit failed", exc_info=True)

        async def on_llm_end(self, context, agent, response) -> None:
            """Capture token usage from each LLM response. Tokens get
            drained onto the next on_tool_end step event."""
            del context, agent
            try:
                usage = getattr(response, "usage", None)
                if usage is None:
                    return
                # Different openai-agents versions expose Usage with
                # input_tokens/output_tokens (current) or just
                # total_tokens (older). Cover both.
                in_t = int(getattr(usage, "input_tokens", 0) or 0)
                out_t = int(getattr(usage, "output_tokens", 0) or 0)
                tot = in_t + out_t
                if tot == 0:
                    tot = int(getattr(usage, "total_tokens", 0) or 0)
                self._pending_tokens += tot
                self._total_tokens   += tot
            except Exception:
                logger.warning("on_llm_end token capture failed", exc_info=True)

        async def on_tool_start(self, context, agent, tool) -> None:
            del context, agent
            tool_id = id(tool)
            self._tool_started_at[tool_id] = time.perf_counter()

        async def on_tool_end(self, context, agent, tool, result) -> None:
            del context, agent
            tool_id = id(tool)
            start = self._tool_started_at.pop(tool_id, None)
            latency_ms = (time.perf_counter() - start) * 1000.0 if start else 0.0
            # Drain accumulated LLM tokens onto this step. First tool
            # call after an LLM response gets the full count;
            # subsequent calls from the same response get 0 (already
            # attributed). Sum across the run is exact.
            step_tokens = self._pending_tokens
            self._pending_tokens = 0
            try:
                action = getattr(tool, "name", None) or getattr(tool, "__name__", None) or "unknown"
                # tool input/args aren't directly exposed on the Tool
                # object across openai-agents versions; we just record
                # the result. Customers can attach extra detail via
                # the metadata kwarg if they need it.
                self._emitter.emit_step({
                    "run_id":     self._run_id,
                    "step_index": self._step_index,
                    "action":     action,
                    "action_input": "",
                    "thought":    None,
                    "observation": str(result)[:8000] if result is not None else None,
                    "is_error":   False,
                    "tokens":     step_tokens,
                    "injections": [],
                    "injection_sources": [],
                    "intervention_texts": [],
                    "monitors_fired": [],
                    "failure_type": None,
                    "metadata": {"latency_ms": round(latency_ms, 2)},
                }) if self._emitter else None
                self._step_index += 1
            except Exception:
                logger.warning("on_tool_end emit failed", exc_info=True)

        async def on_agent_end(self, context, agent, output) -> None:
            del context, agent, output
            try:
                outcome = self._explicit_outcome or "success"
                self._maybe_emit_run_finish(outcome_status=outcome)
            except Exception:
                logger.warning("on_agent_end emit failed", exc_info=True)

        # ----- context-manager support (sync + async) ------------

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback) -> None:
            self._exit_common(exc_type)

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc_value, traceback) -> None:
            self._exit_common(exc_type)

        def _exit_common(self, exc_type) -> None:
            if self._explicit_outcome is not None:
                outcome = self._explicit_outcome
            elif exc_type is not None:
                outcome = f"failure: {exc_type.__name__}"
            else:
                outcome = "success"
            try:
                # Emit again to override the on_agent_end default if
                # the caller set mark_failure() after the agent
                # returned, or to record an exception that escaped.
                if not self._run_finished_emitted or outcome != "success":
                    self._maybe_emit_run_finish(outcome_status=outcome)
                self.close()
            except Exception:
                logger.warning("hooks __exit__ flush failed", exc_info=True)

    return ReasonBlocksHooks


def build_hooks(
    *,
    emitter: Optional[StreamingEmitter],
    run_id: str,
    run_metadata: dict[str, Any],
) -> Any:
    """Internal: construct a ReasonBlocksHooks. The class itself is
    built lazily so importing this module doesn't drag the
    openai-agents package in for callers who only want the tools."""
    cls = _make_run_hooks_class()
    return cls(emitter=emitter, run_id=run_id, run_metadata=run_metadata)


# ---------------------------------------------------------------------------
# 3. ReasonBlocksModel — Model adapter that drives the steering pipeline
#    inside `get_response` so OpenAI Agents users get the same FSM /
#    monitor / E-trace / model-routing behavior as the LangChain middleware.
# ---------------------------------------------------------------------------


class ReasonBlocksModel:
    """OpenAI Agents ``Model`` adapter that runs the ReasonBlocks
    steering pipeline inside :meth:`get_response`.

    Wraps a user-supplied default Model and (optionally) a
    ``model_factory`` callable that builds alternate Models on demand.
    On every ``get_response`` call:

    1. Extracts the last assistant ``thought``, last tool call, and
       last tool result from ``input``.
    2. Calls ``session.begin_step(...)`` to score, run monitors, and
       retrieve E-traces.
    3. Appends the ``[REASONBLOCKS]`` steering block to
       ``system_instructions`` if anything fired.
    4. Resolves the wrapped Model — overridden via ``model_factory`` if
       the FSM state mapped to a different model id.
    5. Forwards to the wrapped model's ``get_response``.
    6. Calls ``session.end_step(...)`` with token usage, tool-call
       names, and latency.

    Use as the ``model`` field on an ``Agent``::

        from agents import Agent, OpenAIChatCompletionsModel
        from reasonblocks import ReasonBlocks

        rb = ReasonBlocks(api_key="rb_live_...", model_routing={
            "FAST": "gpt-4o-mini",
            "SLOW": "gpt-4o",
        })
        wrapped = rb.openai_model(
            default_model=OpenAIChatCompletionsModel("gpt-4o"),
            model_factory=lambda mid: OpenAIChatCompletionsModel(mid),
            agent_name="reviewer",
            task="describe what this run is doing",
        )

        agent = Agent(
            name="reviewer",
            instructions="...",
            model=wrapped,
            tools=[...],
        )

        with wrapped:
            await Runner.run(agent, input="...")

    Streaming via ``stream_response`` is currently a pass-through to
    the wrapped model — no steering is applied to streamed responses
    (the partial-message shape doesn't carry a stable ``thought`` for
    the scorer to read). Telemetry still emits run_start / run_finish
    around the run because ``ReasonBlocksHooks`` covers that.
    """

    def __init__(
        self,
        default_model: Any,
        *,
        session: "SteeringSession",
        model_factory: Optional[Callable[[str], Any]] = None,
        general_monitor: Optional[GeneralMonitor] = None,
    ) -> None:
        self._default_model = default_model
        self._session = session
        self._model_factory = model_factory
        self._model_cache: dict[str, Any] = {}
        # Optional rule-based observation/pause monitor. When set, runs
        # on the converted message history before each model call; firings
        # append a ``[GENERAL-MONITOR]`` block to the system prompt
        # parallel to how SteeringSession injects E-traces. Mirrors the
        # LangChain ``GeneralMonitorMiddleware`` -- same rules, same
        # priority dispatch, same per-rule cooldown.
        self._general_monitor = general_monitor
        self._gm_call_index = 0

    @property
    def session(self) -> "SteeringSession":
        return self._session

    def __enter__(self) -> "ReasonBlocksModel":
        self._session.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self._session.__exit__(exc_type, exc_value, traceback)

    async def __aenter__(self) -> "ReasonBlocksModel":
        return self.__enter__()

    async def __aexit__(self, exc_type, exc_value, traceback) -> None:
        self.__exit__(exc_type, exc_value, traceback)

    def _resolve_model(self, model_id: str) -> Any:
        """Return the Model instance to forward to. Builds and caches
        alternates via ``model_factory`` when a routing override fires."""
        if not model_id:
            return self._default_model
        cached = self._model_cache.get(model_id)
        if cached is not None:
            return cached
        if self._model_factory is None:
            # No factory means we can't build the override — fall back
            # to the default model and log it on the entry via model_id.
            logger.debug(
                "model_routing override %r requested but no model_factory "
                "configured; falling back to default", model_id,
            )
            return self._default_model
        instance = self._model_factory(model_id)
        self._model_cache[model_id] = instance
        return instance

    async def get_response(
        self,
        system_instructions: Optional[str],
        input: Any,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        thought, action, action_input, observation = (
            _extract_oa_input_signals(input)
        )
        decision = self._session.begin_step(
            thought=thought,
            action=action,
            action_input=action_input,
            observation=observation,
        )
        new_system = decision.compose_system_prompt(system_instructions)

        # Optional rule-based monitor pass. Runs over a normalized history
        # extracted from ``input``; if a rule fires, append the injection
        # text to the system prompt as a [GENERAL-MONITOR] block. One
        # firing per call (priority-ordered, per-rule cooldown). Failures
        # in the monitor are swallowed -- it never breaks the agent loop.
        if self._general_monitor is not None:
            try:
                self._gm_call_index += 1
                history = _oa_input_to_general_monitor_history(input)
                fire = self._general_monitor.check(history, self._gm_call_index)
                if fire is not None:
                    new_system = _append_general_monitor_block(new_system, fire.injection_text)
            except Exception:
                logger.warning("general_monitor pass failed", exc_info=True)

        wrapped = self._resolve_model(decision.model_override or "")

        t0 = time.perf_counter()
        try:
            response = await wrapped.get_response(
                new_system, input, *args, **kwargs,
            )
        except Exception:
            # Even on failure we want the step entry to land so
            # `step_log` reflects the attempt.
            self._session.end_step(
                decision,
                model_id=decision.model_override or "",
                tokens=0,
                tool_calls=[],
                latency_ms=(time.perf_counter() - t0) * 1000.0,
            )
            raise
        elapsed_ms = (time.perf_counter() - t0) * 1000.0

        tokens, tool_calls = _extract_oa_response_metrics(response)
        self._session.end_step(
            decision,
            model_id=decision.model_override or "",
            tokens=tokens,
            tool_calls=tool_calls,
            latency_ms=elapsed_ms,
        )
        return response

    def stream_response(self, *args: Any, **kwargs: Any) -> Any:
        """Pass-through to the wrapped model. No steering is applied to
        streamed responses in the first cut."""
        return self._default_model.stream_response(*args, **kwargs)


def _extract_oa_input_signals(
    inp: Any,
) -> tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    """Extract (thought, action, action_input, observation) from the
    OpenAI Agents ``input`` argument shape.

    ``input`` is either:

    * a plain string — initial user prompt; returns all-None so the
      session takes the first-call path.
    * a list of ``TResponseInputItem`` dicts (Responses API shape) —
      walks backwards for the most recent assistant message + tool
      call + tool result.

    All four return ``None`` when no assistant turn has happened yet.
    """
    if isinstance(inp, str) or inp is None:
        return None, None, None, None
    if not isinstance(inp, list):
        return None, None, None, None

    thought: Optional[str] = None
    action: Optional[str] = None
    action_input: Optional[str] = None
    observation: Optional[str] = None

    for item in reversed(inp):
        if not isinstance(item, dict):
            continue
        itype = item.get("type")

        if observation is None and itype == "function_call_output":
            output = item.get("output")
            if isinstance(output, str) and output:
                observation = output[:400]
            continue

        if action is None and itype == "function_call":
            action = item.get("name")
            args = item.get("arguments")
            action_input = str(args) if args is not None else None
            continue

        # Assistant message — content may be a list of output_text /
        # output_audio blocks (Responses API) or a plain string (Chat
        # Completions adaptation).
        if (itype == "message" and item.get("role") == "assistant") or item.get("role") == "assistant":
            content = item.get("content")
            if isinstance(content, str) and content.strip():
                thought = content.strip()
            elif isinstance(content, list):
                texts = [
                    b.get("text", "") if isinstance(b, dict) else str(b)
                    for b in content
                    if isinstance(b, dict) and b.get("type") in ("output_text", "text")
                ]
                joined = " ".join(t for t in texts if t).strip()
                if joined:
                    thought = joined
            if thought:
                break

    return thought, action, action_input, observation


def _extract_oa_response_metrics(
    response: Any,
) -> tuple[int, list[str]]:
    """Pull (total_tokens, tool_call_names) off an OpenAI Agents
    ``ModelResponse``.

    ``response.usage`` is an ``Usage`` object with ``input_tokens`` /
    ``output_tokens``. ``response.output`` is a list of items; each
    ``function_call`` item carries the tool name.
    """
    tokens = 0
    tool_calls: list[str] = []

    usage = getattr(response, "usage", None)
    if usage is not None:
        try:
            in_t = int(getattr(usage, "input_tokens", 0) or 0)
            out_t = int(getattr(usage, "output_tokens", 0) or 0)
            tokens = in_t + out_t
        except (TypeError, ValueError):
            pass

    output = getattr(response, "output", None)
    if isinstance(output, list):
        for item in output:
            t = getattr(item, "type", None)
            if t is None and isinstance(item, dict):
                t = item.get("type")
            if t == "function_call":
                name = getattr(item, "name", None)
                if name is None and isinstance(item, dict):
                    name = item.get("name")
                if name:
                    tool_calls.append(name)

    return tokens, tool_calls


def build_model(
    *,
    default_model: Any,
    session: "SteeringSession",
    model_factory: Optional[Callable[[str], Any]] = None,
    general_monitor: Optional[GeneralMonitor] = None,
) -> ReasonBlocksModel:
    """Internal: construct a ReasonBlocksModel wrapper. Kept symmetric
    with :func:`build_hooks`. ``general_monitor`` lets callers wire the
    rule-based observation/pause monitor into the OpenAI Agents loop --
    same firings as the LangChain ``GeneralMonitorMiddleware``, applied
    via the system-prompt-append path that's native to OpenAI Agents."""
    return ReasonBlocksModel(
        default_model, session=session, model_factory=model_factory,
        general_monitor=general_monitor,
    )


# ---------------------------------------------------------------------------
# General-monitor helpers
# ---------------------------------------------------------------------------

def _oa_input_to_general_monitor_history(inp: Any) -> list[dict[str, Any]]:
    """Convert OpenAI Agents ``input`` (a list of TResponseInputItem dicts
    or a plain user-prompt string) into the normalized HistoryEntry shape
    the framework-agnostic ``GeneralMonitor.check`` consumes.

    Same shape the LangChain integration's ``_langchain_messages_to_history``
    produces: each entry has ``role`` (ai|tool|user), ``step``, ``content``,
    plus tool_calls / tool_call_id where relevant.
    """
    if isinstance(inp, str):
        return [{"role": "user", "step": 0, "content": inp, "tool_calls": []}]
    if not isinstance(inp, list):
        return []

    out: list[dict[str, Any]] = []
    step = 0
    pending_assistant: Optional[dict[str, Any]] = None

    def _flush():
        nonlocal pending_assistant, step
        if pending_assistant is not None:
            out.append(pending_assistant)
            step += 1
            pending_assistant = None

    for item in inp:
        if not isinstance(item, dict):
            continue
        itype = item.get("type")

        if itype == "function_call":
            name = item.get("name") or ""
            args = item.get("arguments")
            try:
                if isinstance(args, str):
                    import json as _json
                    args_dict = _json.loads(args) if args else {}
                else:
                    args_dict = dict(args or {})
            except Exception:
                args_dict = {}
            tcid = item.get("call_id") or item.get("id") or ""
            # Accumulate tool calls onto the most recent assistant turn
            # so a single LLM response with multiple tool calls counts
            # as one ai entry with N tool_calls (matches LangChain shape).
            if pending_assistant is None:
                pending_assistant = {"role": "ai", "step": step, "content": "", "tool_calls": []}
            pending_assistant["tool_calls"].append({"name": name, "args": args_dict, "id": tcid})
            continue

        if itype == "function_call_output":
            _flush()
            output = item.get("output")
            content = output if isinstance(output, str) else str(output or "")
            tcid = item.get("call_id") or item.get("id") or ""
            out.append({
                "role": "tool", "step": step,
                "tool_call_id": tcid, "name": "",
                "content": content,
            })
            step += 1
            continue

        # Plain message (assistant or user).
        role = item.get("role") or ""
        if (itype == "message" and role == "assistant") or role == "assistant":
            _flush()
            content = item.get("content")
            if isinstance(content, list):
                text = " ".join(
                    (b.get("text", "") if isinstance(b, dict) else "")
                    for b in content
                    if isinstance(b, dict) and b.get("type") in ("output_text", "text")
                )
            else:
                text = str(content or "")
            pending_assistant = {"role": "ai", "step": step, "content": text, "tool_calls": []}
            continue

        if (itype == "message" and role == "user") or role == "user":
            _flush()
            content = item.get("content")
            if isinstance(content, list):
                text = " ".join(
                    (b.get("text", "") if isinstance(b, dict) else "")
                    for b in content
                    if isinstance(b, dict) and b.get("type") in ("input_text", "text")
                )
            else:
                text = str(content or "")
            out.append({"role": "user", "step": step, "content": text, "tool_calls": []})
            step += 1
            continue

    _flush()
    return out


_GENERAL_MONITOR_MARKER = "[GENERAL-MONITOR]"


def _append_general_monitor_block(system: Optional[str], text: str) -> str:
    """Append a [GENERAL-MONITOR] block to ``system``. Mirrors the
    [REASONBLOCKS] block convention used by SteeringSession.compose_system_prompt
    -- two parallel injection channels coexist in the same system prompt."""
    base = (system or "").rstrip()
    if base:
        return f"{base}\n\n{_GENERAL_MONITOR_MARKER}\n{text}"
    return f"{_GENERAL_MONITOR_MARKER}\n{text}"
