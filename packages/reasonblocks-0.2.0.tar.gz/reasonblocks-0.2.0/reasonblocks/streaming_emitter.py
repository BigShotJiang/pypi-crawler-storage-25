"""Live per-step telemetry emitter.

Middleware calls :meth:`StreamingEmitter.emit_step` inside the agent's
hot path, but the network POST never happens there. Events are enqueued
on a bounded in-memory queue and a background daemon worker drains them
to rb-api's ``/monitor/runs/...`` endpoints.

Design principles:

* **The agent hot path never blocks on network.** ``emit_*`` is a
  non-blocking enqueue. If the queue is full we drop the oldest event
  rather than stall the caller -- losing telemetry beats stalling the
  customer's agent.
* **Fire-and-forget with best effort retry.** The worker retries
  transient failures with exponential backoff, then gives up and drops.
  Counters track what was sent / dropped / failed so the caller can
  surface drops if they care.
* **Graceful shutdown.** :meth:`flush` waits up to ``timeout`` seconds
  for the queue to drain; :meth:`close` stops the worker thread.

Shape of an enqueued event::

    {"kind": "run_start",  "payload": {...}}
    {"kind": "step",       "payload": {...}}
    {"kind": "run_finish", "payload": {...}}

The emitter is agnostic to what ``payload`` contains -- it just hands
the dict off to :class:`~reasonblocks.monitor_client.MonitorClient`.
"""

from __future__ import annotations

import atexit
import logging
import queue
import random
import threading
import time
import weakref
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from reasonblocks.monitor_client import MonitorClient

logger = logging.getLogger("reasonblocks.streaming_emitter")


DEFAULT_QUEUE_SIZE = 1000
DEFAULT_RETRY_ATTEMPTS = 3
DEFAULT_RETRY_BASE_DELAY = 0.2  # seconds — doubles each attempt
DEFAULT_SHUTDOWN_TIMEOUT = 5.0


@dataclass
class EmitterStats:
    """Counters so callers can surface delivery health."""

    enqueued: int = 0
    sent: int = 0
    dropped_full: int = 0       # enqueue hit a full queue
    dropped_failed: int = 0     # worker exhausted retries
    retry_count: int = 0

    def snapshot(self) -> dict[str, int]:
        return {
            "enqueued": self.enqueued,
            "sent": self.sent,
            "dropped_full": self.dropped_full,
            "dropped_failed": self.dropped_failed,
            "retry_count": self.retry_count,
        }


@dataclass
class _Event:
    kind: str               # "run_start" | "step" | "run_finish"
    payload: dict[str, Any] = field(default_factory=dict)


class StreamingEmitter:
    """Non-blocking per-step telemetry emitter.

    Parameters
    ----------
    client:
        HTTP client that actually performs the POST. Any object with
        ``start_run``, ``log_step``, ``finish_run`` methods matching
        :class:`~reasonblocks.monitor_client.MonitorClient` works -- tests
        pass a fake implementation to verify behavior without a server.
    queue_size:
        Max events buffered in memory before ``emit_*`` starts dropping
        the oldest. 1000 is plenty for a single agent run; raise for
        long-running multi-agent processes.
    retry_attempts:
        How many times the worker retries a failed POST before giving up
        and dropping the event.
    retry_base_delay:
        Seconds between the first retry pair. Doubles each subsequent
        attempt (``0.2s, 0.4s, 0.8s, ...``).
    """

    def __init__(
        self,
        client: MonitorClient,
        *,
        queue_size: int = DEFAULT_QUEUE_SIZE,
        retry_attempts: int = DEFAULT_RETRY_ATTEMPTS,
        retry_base_delay: float = DEFAULT_RETRY_BASE_DELAY,
        # Injected for tests to avoid real sleeps.
        sleep_fn: Callable[[float], None] = time.sleep,
    ) -> None:
        if queue_size < 1:
            raise ValueError("queue_size must be >= 1")
        if retry_attempts < 0:
            raise ValueError("retry_attempts must be >= 0")

        self._client = client
        self._retry_attempts = retry_attempts
        self._retry_base_delay = retry_base_delay
        self._sleep = sleep_fn

        self._queue: queue.Queue[_Event | None] = queue.Queue(maxsize=queue_size)
        self._stats = EmitterStats()
        self._stats_lock = threading.Lock()
        self._closed = threading.Event()
        self._worker = threading.Thread(
            target=self._run_worker,
            name="rb-streaming-emitter",
            daemon=True,
        )
        self._worker.start()

        # Register an atexit hook so a script that ends without
        # ``with mw:`` (or an explicit ``mw.close()``) still gets the
        # final run_finish event delivered before the daemon worker
        # gets killed by interpreter shutdown. Without this, runs
        # show up "stuck in progress" in the dashboard because
        # finished_at / outcome are never set.
        #
        # weakref keeps the atexit registration from holding the
        # emitter alive; if the user explicitly closes + drops the
        # reference, the hook is a no-op.
        ref = weakref.ref(self)
        def _drain_on_exit() -> None:
            inst = ref()
            if inst is None or inst._closed.is_set():
                return
            # If the worker is already dead (interpreter teardown,
            # SIGINT, fatal exception inside the worker), don't bother
            # flushing -- the queue can't drain without a live consumer
            # and any sleep-based wait would just hang on Ctrl-C.
            if not inst._worker.is_alive():
                inst._closed.set()
                return
            try:
                # Short timeout so a lost-server condition doesn't block
                # interpreter shutdown for the full default 5s.
                inst.close(timeout=0.5)
            except Exception:
                pass
        atexit.register(_drain_on_exit)

    # ------------------------------------------------------------------
    # Public emit API -- called from the middleware hot path
    # ------------------------------------------------------------------

    def emit_run_start(self, payload: dict[str, Any]) -> None:
        """Enqueue a run-start event. Non-blocking.

        ``payload`` must include ``run_id``. Other fields are forwarded
        to :meth:`MonitorClient.start_run` as keyword arguments.
        """
        if "run_id" not in payload:
            logger.warning("emit_run_start dropped: no run_id in payload")
            return
        self._enqueue(_Event(kind="run_start", payload=dict(payload)))

    def emit_step(self, payload: dict[str, Any]) -> None:
        """Enqueue a per-step event. Non-blocking.

        ``payload`` must include ``run_id`` and ``step_index``. Other
        fields are forwarded to :meth:`MonitorClient.log_step`.
        """
        if "run_id" not in payload or "step_index" not in payload:
            logger.warning("emit_step dropped: missing run_id or step_index")
            return
        self._enqueue(_Event(kind="step", payload=dict(payload)))

    def emit_run_finish(self, payload: dict[str, Any]) -> None:
        """Enqueue a run-finish event. Non-blocking."""
        if "run_id" not in payload:
            logger.warning("emit_run_finish dropped: no run_id in payload")
            return
        self._enqueue(_Event(kind="run_finish", payload=dict(payload)))

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def flush(self, timeout: float = DEFAULT_SHUTDOWN_TIMEOUT) -> bool:
        """Block until the queue drains or ``timeout`` elapses.

        Returns ``True`` if the queue fully drained, ``False`` if the
        timeout expired with events still pending. Does not stop the
        worker -- use :meth:`close` for that.
        """
        if timeout <= 0:
            return self._queue.unfinished_tasks == 0
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self._queue.unfinished_tasks == 0:
                return True
            self._sleep(0.01)
        return self._queue.unfinished_tasks == 0

    def close(self, timeout: float = DEFAULT_SHUTDOWN_TIMEOUT) -> None:
        """Drain (up to ``timeout``) then stop the worker thread.

        Safe to call multiple times. After close, further emit_* calls
        are silently dropped.
        """
        if self._closed.is_set():
            return
        self._closed.set()
        self.flush(timeout=timeout)
        # Sentinel tells the worker to exit.
        try:
            self._queue.put_nowait(None)
        except queue.Full:
            # Drop an event to make room for the sentinel -- shutting
            # down anyway, so letting the worker out cleanly matters more.
            try:
                self._queue.get_nowait()
                self._queue.task_done()
            except queue.Empty:
                pass
            try:
                self._queue.put_nowait(None)
            except queue.Full:
                pass  # worker will eventually time out on the join below
        self._worker.join(timeout=timeout)

    @property
    def stats(self) -> EmitterStats:
        """Snapshot of delivery counters. Reads are thread-safe."""
        with self._stats_lock:
            return EmitterStats(
                enqueued=self._stats.enqueued,
                sent=self._stats.sent,
                dropped_full=self._stats.dropped_full,
                dropped_failed=self._stats.dropped_failed,
                retry_count=self._stats.retry_count,
            )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _enqueue(self, event: _Event) -> None:
        if self._closed.is_set():
            return
        try:
            self._queue.put_nowait(event)
            with self._stats_lock:
                self._stats.enqueued += 1
            return
        except queue.Full:
            # Drop oldest to make room for newest — most recent telemetry
            # is more useful than stale backlog.
            try:
                self._queue.get_nowait()
                self._queue.task_done()
                with self._stats_lock:
                    self._stats.dropped_full += 1
            except queue.Empty:
                pass
            try:
                self._queue.put_nowait(event)
                with self._stats_lock:
                    self._stats.enqueued += 1
            except queue.Full:
                # Queue emptied and refilled between get/put -- very rare;
                # count as dropped and move on.
                with self._stats_lock:
                    self._stats.dropped_full += 1

    def _run_worker(self) -> None:
        while True:
            try:
                event = self._queue.get()
            except Exception:
                # Queue closed or interrupted.
                return
            if event is None:
                # Sentinel -- drain done, exit.
                self._queue.task_done()
                return
            try:
                self._deliver_with_retry(event)
            finally:
                self._queue.task_done()

    def _deliver_with_retry(self, event: _Event) -> None:
        attempts = self._retry_attempts + 1  # initial + retries
        delay = self._retry_base_delay
        for attempt in range(attempts):
            try:
                ok = self._deliver(event)
            except Exception as exc:
                logger.warning(
                    "streaming emit %s failed (attempt %d/%d): %s",
                    event.kind, attempt + 1, attempts, exc,
                )
                ok = False
            if ok:
                with self._stats_lock:
                    self._stats.sent += 1
                return
            if attempt < attempts - 1:
                with self._stats_lock:
                    self._stats.retry_count += 1
                # Jitter so a thundering herd of emitters retrying in
                # lockstep against a flaky rb-api scatter their traffic
                # instead of slamming the server at the same instants.
                jittered = delay * random.uniform(0.5, 1.5)
                self._sleep(jittered)
                delay *= 2.0
        # Exhausted retries.
        with self._stats_lock:
            self._stats.dropped_failed += 1
        logger.warning(
            "streaming emit %s dropped after %d attempts (run_id=%s)",
            event.kind, attempts, event.payload.get("run_id"),
        )

    def _deliver(self, event: _Event) -> bool:
        """Hand one event off to the HTTP client.

        Returns ``True`` if delivered, ``False`` to retry. The underlying
        MonitorClient swallows transport errors and returns ``None`` on
        failure -- we use that as the retry signal for all three event
        kinds.
        """
        if event.kind == "run_start":
            return self._client.start_run(**event.payload) is not None
        if event.kind == "step":
            return self._client.log_step(**event.payload) is not None
        if event.kind == "run_finish":
            return self._client.finish_run(**event.payload) is not None
        logger.warning("unknown event kind: %s", event.kind)
        return True  # don't retry unknown events forever
