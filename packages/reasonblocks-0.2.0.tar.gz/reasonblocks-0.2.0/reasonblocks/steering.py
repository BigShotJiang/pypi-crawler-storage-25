"""Framework-agnostic steering pipeline.

Mirrors what ``ReasonBlocksMiddleware`` (LangChain) does inside its
``before_model`` + ``wrap_model_call`` hooks, but factored out so the
Anthropic Messages API loop and the OpenAI Agents ``Model`` adapter
can use the same step-by-step orchestration without dragging LangChain
into either one.

Lifecycle (per agent run)::

    session = SteeringSession(...)
    session.start()                     # emits run_start telemetry once

    for turn in agent_loop():
        decision = session.begin_step(
            thought=last_assistant_text,
            action=last_action,
            action_input=last_action_input,
            observation=last_observation,
        )
        system_prompt = decision.compose_system_prompt(base_system_prompt)
        model_id      = decision.model_override or default_model_id

        # caller invokes the LLM with system_prompt + model_id
        response = call_llm(system_prompt, model_id, ...)

        session.end_step(
            decision,
            model_id=model_id,
            tokens=response.tokens_used,
            tool_calls=[tc.name for tc in response.tool_calls],
            latency_ms=elapsed_ms,
        )

    session.finish(outcome_status="success")
    session.close()

Or use it as a context manager::

    with SteeringSession(...) as session:
        ...

The first ``begin_step(thought=None)`` call (when no assistant turn has
happened yet) follows the "first-call" path and only fires E3
injections; subsequent calls run the full score → FSM → monitors →
E-traces pipeline.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from reasonblocks.format_routing import render_pattern
from reasonblocks.fsm import DifficultyFSM
from reasonblocks.injections.base import BaseInjection
from reasonblocks.injections.e1 import E1Injection
from reasonblocks.injections.e2 import E2Injection
from reasonblocks.injections.e3 import E3Injection
from reasonblocks.injections.monitor_steering import MonitorSteeringInjection
from reasonblocks.state import TraceStateManager
from reasonblocks.streaming_emitter import StreamingEmitter
from reasonblocks.types import FSMState, PendingInjection, StepRecord

logger = logging.getLogger("reasonblocks.steering")


@dataclass
class StepLogEntry:
    """One entry in the steering session's step-by-step trace log.

    Identical surface area to the LangChain middleware's StepLogEntry —
    callers inspecting ``session.step_log`` see the same fields.
    """

    step: int
    timestamp: float
    difficulty: Optional[float] = None
    fsm_state: str = ""
    model_id: str = ""
    injections: list[str] = field(default_factory=list)
    injection_sources: list[str] = field(default_factory=list)
    intervention_texts: list[str] = field(default_factory=list)
    monitors_fired: list[str] = field(default_factory=list)
    failure_type: Optional[str] = None
    skipped_reason: Optional[str] = None
    thought_preview: str = ""
    tool_calls: list[str] = field(default_factory=list)
    tokens: int = 0
    latency_ms: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "step": self.step,
            "timestamp": self.timestamp,
            "fsm_state": self.fsm_state,
            "thought_preview": self.thought_preview,
            "injections": list(self.injections),
            "injection_sources": list(self.injection_sources),
            "intervention_texts": list(self.intervention_texts),
            "monitors_fired": list(self.monitors_fired),
            "tool_calls": list(self.tool_calls),
            "tokens": self.tokens,
            "latency_ms": round(self.latency_ms, 2),
        }
        if self.difficulty is not None:
            d["difficulty"] = round(self.difficulty, 4)
        if self.model_id:
            d["model_id"] = self.model_id
        if self.skipped_reason:
            d["skipped_reason"] = self.skipped_reason
        if self.failure_type:
            d["failure_type"] = self.failure_type
        return d


@dataclass
class StepDecision:
    """Returned by ``begin_step``; carries everything the caller needs to
    compose the system prompt and route the model for this turn."""

    state: FSMState
    pending: list[PendingInjection]
    model_override: Optional[str]
    entry: StepLogEntry
    rendered_injection_text: str  # may be empty string when nothing fired

    def compose_system_prompt(self, base_system: str | None) -> str:
        """Return ``base_system`` with the ``[REASONBLOCKS]`` block
        appended when steering text is present; otherwise the base
        unchanged. Useful for plain-string system prompts (Claude
        Messages, OpenAI Agents).

        ``rendered_injection_text`` is already sanitized upstream:
        - server-supplied pattern fields run through
          ``format_routing._safe_render_server_text`` inside
          ``render_pattern`` before f-string composition.
        - ``MonitorSteeringInjection`` runs the same helper on its
          ``intervention_text`` before queuing the PendingInjection.
        We deliberately do not re-sanitize here so we do not double-wrap
        content that already carries advisory-frame markers.
        """
        base = (base_system or "").rstrip()
        if not self.rendered_injection_text:
            return base
        if base:
            return f"{base}\n\n[REASONBLOCKS]\n{self.rendered_injection_text}"
        return f"[REASONBLOCKS]\n{self.rendered_injection_text}"


class SteeringSession:
    """Framework-agnostic steering pipeline.

    Construct with the same primitives the LangChain middleware uses
    (``DifficultyFSM``, ``TraceStateManager``, a list of
    ``BaseInjection``s, an optional ``StreamingEmitter``, and a
    ``score_fn``) and drive one ``begin_step`` / ``end_step`` pair per
    agent turn.

    Not thread-safe: one session per concurrent agent run.
    """

    def __init__(
        self,
        *,
        score_fn: Callable[[str], float],
        fsm: DifficultyFSM,
        state_manager: TraceStateManager,
        injections: list[BaseInjection],
        model_routing: Optional[dict[FSMState, str]] = None,
        emitter: Optional[StreamingEmitter] = None,
        run_id: str = "",
        run_metadata: Optional[dict[str, Any]] = None,
    ) -> None:
        self._score_fn = score_fn
        self._fsm = fsm
        self._state = state_manager
        self._injections = injections
        self._model_routing = model_routing or {}
        self._emitter = emitter
        self._run_id = run_id or state_manager.trace_id
        self._run_metadata = dict(run_metadata or {})
        self._step_index = 0
        self.step_log: list[StepLogEntry] = []

        # Lifecycle flags.
        self._run_started_emitted = False
        self._run_finished_emitted = False
        self._explicit_outcome: Optional[str] = None

        # Monitor steering guardrails (mirror the LangChain middleware).
        self._monitor_injection_count = 0
        self._monitor_last_step = -999
        self._monitor_last_signature: Optional[str] = None
        self._monitor_max_per_run = 5
        self._monitor_eval_history: list[dict[str, Any]] = []
        self._e1_gate_composite_threshold: float = 0.15
        self._e1_gate_lookback: int = 2

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Emit the ``run_start`` telemetry event. Idempotent — safe to
        call from multiple entry points (e.g. begin_step + an explicit
        ``start()`` from the caller)."""
        self._maybe_emit_run_start()

    def finish(self, *, outcome_status: str = "success") -> None:
        """Emit the ``run_finish`` event. Idempotent.

        ``mark_failure(reason=...)`` and a propagating exception in
        ``__exit__`` both override the default ``"success"``.
        """
        outcome = self._explicit_outcome or outcome_status
        self._maybe_emit_run_finish(outcome_status=outcome)

    def close(self, *, timeout: float = 5.0) -> None:
        """Stop the live telemetry worker and drain pending events."""
        if self._emitter is not None:
            self._emitter.close(timeout=timeout)

    def mark_failure(self, *, reason: str = "failure") -> None:
        """Override the default ``"success"`` outcome for this run."""
        self._explicit_outcome = reason

    def __enter__(self) -> "SteeringSession":
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        if self._explicit_outcome is not None:
            outcome = self._explicit_outcome
        elif exc_type is not None:
            outcome = f"failure: {exc_type.__name__}"
        else:
            outcome = "success"
        try:
            self._maybe_emit_run_finish(outcome_status=outcome)
            self.close()
        except Exception:
            logger.warning("__exit__ flush failed", exc_info=True)

    # ------------------------------------------------------------------
    # Per-step orchestration
    # ------------------------------------------------------------------

    def begin_step(
        self,
        *,
        thought: Optional[str],
        action: Optional[str] = None,
        action_input: Optional[str] = None,
        observation: Optional[str] = None,
    ) -> StepDecision:
        """Run scoring + FSM transition + monitor evaluation + E-trace
        retrieval for this turn. Returns a ``StepDecision`` with the
        pending injections, the resolved FSM state, and an optional
        model-routing override.

        ``thought`` is the agent's last assistant-message text. Pass
        ``None`` on the very first call (when no assistant turn has
        happened yet) — the session will run the first-call path which
        only fires E3 universal injections.
        """
        self._maybe_emit_run_start()
        entry = StepLogEntry(step=self._step_index, timestamp=time.time())

        if thought is None:
            entry.fsm_state = "INIT"
            entry.thought_preview = "(first call)"
            self._reset_monitor_runtime()
            pending = self._run_first_call_injections()
            current_state = self._state.current_state
        else:
            entry.thought_preview = thought[:120]
            pending = self._score_and_inject(
                thought, entry,
                action=action,
                action_input=action_input,
                observation=observation,
            )
            current_state = self._state.current_state

        self._populate_entry_from_pending(entry, pending)

        # Resolve model override BEFORE rendering so format_routing can
        # key on the post-routing model family.
        model_override = self._model_routing.get(current_state)
        rendered = self._render_pending(
            pending,
            model_override or "",
        )

        self._step_index += 1
        return StepDecision(
            state=current_state,
            pending=pending,
            model_override=model_override,
            entry=entry,
            rendered_injection_text=rendered,
        )

    def end_step(
        self,
        decision: StepDecision,
        *,
        model_id: str = "",
        tokens: int = 0,
        tool_calls: Optional[list[str]] = None,
        latency_ms: float = 0.0,
        observation: Optional[str] = None,
    ) -> None:
        """Finalize the step: stamp the resolved model id + token count
        + tool calls onto the entry, append to ``step_log``, and emit
        the live ``step`` telemetry event.

        ``observation`` is optional; if you have it (e.g. a tool result
        that came back inside this same turn), pass it so it lands on
        the most recent ``StepRecord`` for downstream consumers.
        """
        entry = decision.entry
        if model_id:
            entry.model_id = model_id
        if tokens:
            entry.tokens = int(tokens)
            if self._state._steps:
                self._state._steps[-1].tokens_used = int(tokens)
            self._state.add_tokens(int(tokens))
        if tool_calls:
            entry.tool_calls = list(tool_calls)
        if latency_ms:
            entry.latency_ms = float(latency_ms)
        if observation is not None and self._state._steps:
            self._state._steps[-1].observation = observation

        self.step_log.append(entry)
        self._maybe_emit_step(entry)

    # ------------------------------------------------------------------
    # Internal: scoring + FSM + injections
    # ------------------------------------------------------------------

    def _score_and_inject(
        self,
        thought: str,
        entry: StepLogEntry,
        *,
        action: Optional[str],
        action_input: Optional[str],
        observation: Optional[str],
    ) -> list[PendingInjection]:
        step_index = self._step_index
        difficulty = self._score_fn(thought)
        entry.difficulty = difficulty

        history = self._state.get_difficulty_history()
        history.append(difficulty)
        new_state = self._fsm.transition(
            self._state.current_state, difficulty, history,
        )
        self._state.current_state = new_state
        entry.fsm_state = new_state.value

        step = StepRecord(
            step_index=step_index,
            thought=thought,
            action=action,
            action_input=action_input,
            observation=observation,
            difficulty=difficulty,
            state=new_state,
        )
        self._state.record_step(step)

        skip_e_traces = new_state == FSMState.FAST
        if skip_e_traces:
            entry.skipped_reason = "FSM=FAST, e-traces skipped"

        trace = self._state.get_trace()
        results: list[PendingInjection] = []

        monitor_inj: Optional[MonitorSteeringInjection] = next(
            (i for i in self._injections if isinstance(i, MonitorSteeringInjection)),
            None,
        )

        # Step 1: always evaluate monitors (when present) so the E1 gate
        # has a current signal, even when we throttle the monitor's own
        # injection text.
        current_eval = None
        if monitor_inj is not None:
            monitor_inj.set_current_step(step)
            monitor_items = monitor_inj.retrieve(trace)
            current_eval = monitor_inj.last_evaluation()
            if self._should_run_monitor_injection(
                step_index=step_index, state=new_state,
            ):
                results.extend(
                    self._filter_monitor_items(
                        items=monitor_items, step_index=step_index,
                    ),
                )

        # Step 2: update gate history and decide whether E1 may retrieve.
        self._record_monitor_eval(step_index, current_eval)
        e1_allowed = self._e1_gate_allows(current_eval)

        # Step 2b: thread monitor failure_type into E2's metadata filter.
        if current_eval is not None:
            for inj in self._injections:
                if isinstance(inj, E2Injection):
                    inj.set_failure_type(current_eval.failure_type)

        # Step 3: run the remaining injections (E1/E2/E3).
        for inj in self._injections:
            if isinstance(inj, MonitorSteeringInjection):
                continue
            if skip_e_traces:
                continue
            if isinstance(inj, E1Injection) and not e1_allowed:
                continue
            try:
                results.extend(inj.retrieve(trace))
            except Exception:
                logger.warning(
                    "%s.retrieve failed, skipping", type(inj).__name__,
                    exc_info=True,
                )
        return results

    def _run_first_call_injections(self) -> list[PendingInjection]:
        """Only fire E3 (universal standing-rule) injections on the first
        call — same first-call shape as the LangChain middleware."""
        trace = self._state.get_trace()
        results: list[PendingInjection] = []
        for inj in self._injections:
            if isinstance(inj, E3Injection):
                try:
                    results.extend(inj.retrieve(trace))
                except Exception:
                    logger.warning(
                        "E3 retrieve failed on first call, skipping",
                        exc_info=True,
                    )
        return results

    def _populate_entry_from_pending(
        self, entry: StepLogEntry, pending: list[PendingInjection],
    ) -> None:
        if not pending:
            return
        entry.injections = [_preview(i) for i in pending]
        entry.injection_sources = [i.source for i in pending]
        entry.intervention_texts = [i.text for i in pending if i.text]
        fired_set: list[str] = []
        ftype: Optional[str] = None
        for inj in pending:
            for m in (inj.monitors_fired or []):
                if m and m not in fired_set:
                    fired_set.append(m)
            if inj.failure_type and ftype is None:
                ftype = inj.failure_type
        entry.monitors_fired = fired_set
        entry.failure_type = ftype

    def _render_pending(
        self, items: list[PendingInjection], model_id: str,
    ) -> str:
        if not items:
            return ""
        rendered: list[str] = []
        for item in items:
            if item.text is not None:
                rendered.append(item.text)
                continue
            if not item.tier or not item.fields:
                continue
            try:
                rendered.append(
                    render_pattern(item.tier, model_id, item.fields),
                )
            except Exception:
                logger.warning(
                    "render_pattern failed tier=%s source=%s",
                    item.tier, item.source, exc_info=True,
                )
        return "\n\n".join(r for r in rendered if r)

    # ------------------------------------------------------------------
    # Monitor cap / cooldown / E1 gate
    # ------------------------------------------------------------------

    def _record_monitor_eval(
        self, step_index: int, current_eval: Any,
    ) -> None:
        fired = (
            list(current_eval.fired)
            if current_eval is not None and current_eval.fired
            else []
        )
        composite = float(current_eval.composite) if current_eval is not None else 0.0
        self._monitor_eval_history.append(
            {"step": step_index, "fired": fired, "composite": composite},
        )
        if len(self._monitor_eval_history) > 10:
            self._monitor_eval_history = self._monitor_eval_history[-10:]

    def _e1_gate_allows(self, current_eval: Any) -> bool:
        history = self._monitor_eval_history
        ever_ran = bool(history) or current_eval is not None
        if not ever_ran:
            return True
        if current_eval is not None:
            if current_eval.fired:
                return True
            if float(current_eval.composite or 0.0) > self._e1_gate_composite_threshold:
                return True
        start = max(0, len(history) - 1 - self._e1_gate_lookback)
        end = len(history) - 1
        for entry in history[start:end]:
            if entry.get("fired"):
                return True
        return False

    def _should_run_monitor_injection(
        self, *, step_index: int, state: FSMState,
    ) -> bool:
        if self._monitor_injection_count >= self._monitor_max_per_run:
            return False
        if state in (FSMState.SLOW, FSMState.SKIP):
            cooldown = 2
        elif state == FSMState.FAST:
            cooldown = 5
        else:
            cooldown = 3
        if step_index - self._monitor_last_step < cooldown:
            return False
        return True

    def _filter_monitor_items(
        self, *, items: list[PendingInjection], step_index: int,
    ) -> list[PendingInjection]:
        if not items:
            return []
        signature = "||".join((i.text or "") for i in items)
        if signature == self._monitor_last_signature:
            return []
        self._monitor_last_signature = signature
        self._monitor_last_step = step_index
        self._monitor_injection_count += 1
        return items

    def _reset_monitor_runtime(self) -> None:
        self._monitor_injection_count = 0
        self._monitor_last_step = -999
        self._monitor_last_signature = None
        for inj in self._injections:
            if isinstance(inj, MonitorSteeringInjection):
                inj.reset()

    # ------------------------------------------------------------------
    # Telemetry
    # ------------------------------------------------------------------

    def _maybe_emit_run_start(self) -> None:
        if self._emitter is None or self._run_started_emitted:
            return
        self._run_started_emitted = True
        meta = dict(self._run_metadata or {})
        self._emitter.emit_run_start({
            "run_id":       self._run_id,
            "agent_name":   meta.pop("agent_name", "") or "",
            "task":         meta.pop("task", "") or "",
            "model":        meta.pop("model", "") or "",
            "framework":    meta.pop("framework", "") or "",
            "codebase_id":  meta.pop("codebase_id", "") or "",
            "org_id":       meta.pop("org_id", "default") or "default",
            "project_id":   meta.pop("project_id", "default") or "default",
            "task_profile": meta.pop("task_profile", "coding") or "coding",
            "metadata":     meta,
        })

    def _maybe_emit_step(self, entry: StepLogEntry) -> None:
        if self._emitter is None:
            return

        action: Optional[str] = None
        action_input: Optional[str] = None
        thought: Optional[str] = None
        observation: Optional[str] = None
        is_error = False
        try:
            if self._state._steps:
                last_step = self._state._steps[-1]
                action = last_step.action
                action_input = last_step.action_input
                thought = last_step.thought
                observation = last_step.observation
                obs_lower = (observation or "").lower()
                is_error = any(
                    word in obs_lower
                    for word in ("error", "exception", "traceback", "failed")
                )
        except Exception:
            pass

        if thought is None:
            thought = entry.thought_preview or ""

        metadata: dict[str, Any] = {
            "fsm_state": entry.fsm_state,
            "difficulty": entry.difficulty,
            "latency_ms": round(entry.latency_ms, 2),
        }
        if entry.model_id:
            metadata["model_id"] = entry.model_id
        if entry.skipped_reason:
            metadata["skipped_reason"] = entry.skipped_reason

        self._emitter.emit_step({
            "run_id": self._run_id,
            "step_index": entry.step,
            "action": action,
            "action_input": action_input,
            "thought": thought,
            "observation": observation,
            "is_error": is_error,
            "tokens": int(entry.tokens or 0),
            "injections": list(entry.injections),
            "injection_sources": list(entry.injection_sources),
            "intervention_texts": list(entry.intervention_texts),
            "monitors_fired": list(entry.monitors_fired),
            "failure_type": entry.failure_type,
            "metadata": metadata,
        })

    def _maybe_emit_run_finish(self, *, outcome_status: str) -> None:
        if self._emitter is None or self._run_finished_emitted:
            return
        self._run_finished_emitted = True
        self._emitter.emit_run_finish({
            "run_id": self._run_id,
            "outcome": outcome_status,
        })


def _preview(inj: PendingInjection) -> str:
    if inj.text is not None:
        return inj.text[:150]
    if inj.tier and inj.fields:
        pid = inj.fields.get("pattern_id", "")
        return f"[{inj.tier}:{pid}]"[:150]
    return ""
