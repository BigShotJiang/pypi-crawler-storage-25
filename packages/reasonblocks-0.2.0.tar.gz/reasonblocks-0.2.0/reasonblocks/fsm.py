from __future__ import annotations

import math

from reasonblocks.types import FSMState


class DifficultyFSM:
    """SAT-paper state machine that maps difficulty trajectories to states."""

    def __init__(
        self,
        fast_threshold: float = 0.2,
        slow_threshold: float = 0.6,
        skip_threshold: float = 0.85,
        hysteresis_margin: float = 0.1,
        fast_window: int = 6,
        slow_window: int = 5,
        skip_window: int = 35,
    ) -> None:
        self.fast_threshold = fast_threshold
        self.slow_threshold = slow_threshold
        self.skip_threshold = skip_threshold
        self.hysteresis_margin = hysteresis_margin
        self.fast_window = fast_window
        self.slow_window = slow_window
        self.skip_window = skip_window

    def transition(
        self,
        current: FSMState,
        score: float,
        history: list[float],
    ) -> FSMState:
        """Compute the next FSM state given current state, new score, and history."""
        # NaN scores would slip through every threshold comparison
        # (NaN < x and NaN > x both return False), pinning the state
        # to whatever it currently is forever. Bail early if the
        # score isn't a real number.
        if isinstance(score, float) and math.isnan(score):
            return current

        if current == FSMState.INIT:
            return FSMState.NORMAL

        if current == FSMState.END:
            return FSMState.END

        if current == FSMState.NORMAL:
            return self._from_normal(score, history)

        if current == FSMState.FAST:
            return self._from_fast(score)

        if current in (FSMState.SLOW, FSMState.SKIP):
            return self._from_slow(score, history)

        return current

    def _from_normal(self, score: float, history: list[float]) -> FSMState:
        fast_window = history[-self.fast_window :]
        if (
            len(fast_window) >= self.fast_window
            and all(s < self.fast_threshold for s in fast_window)
        ):
            return FSMState.FAST

        slow_window = history[-self.slow_window :]
        if (
            len(slow_window) >= self.slow_window
            and all(s > self.slow_threshold for s in slow_window)
        ):
            return FSMState.SLOW

        return FSMState.NORMAL

    def _from_fast(self, score: float) -> FSMState:
        if score > self.fast_threshold + self.hysteresis_margin:
            return FSMState.NORMAL
        return FSMState.FAST

    def _from_slow(self, score: float, history: list[float]) -> FSMState:
        if score < self.slow_threshold - self.hysteresis_margin:
            return FSMState.NORMAL

        skip_window = history[-self.skip_window :]
        if (
            len(skip_window) >= self.skip_window
            and all(s > self.skip_threshold for s in skip_window)
        ):
            return FSMState.SKIP

        return FSMState.SLOW
