"""
st_agent_chat.component — Drop-in Streamlit agentic chat widget.

Usage:
    from st_agent_chat import agent_chat
    agent_chat(workspace=".", provider="anthropic")
"""
from __future__ import annotations

import html as html_mod
import os
from pathlib import Path

import streamlit as st

from .engine import AgentEngine, SubagentConfig, list_sessions
from .llm import (
    ALL_ANTHROPIC_MODELS,
    ALL_OPENAI_MODELS,
    ALL_REPLICATE_MODELS,
    ALL_OPENROUTER_MODELS,
    PROVIDER_ENV_KEYS,
    LLMConfig,
    resolve_provider,
)
from .tools import summarize_args


# ── CSS (scoped with .sac- prefix so it doesn't leak) ────────────────

_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600&family=Inter:wght@300;400;500;600;700&display=swap');

:root {
    --sac-bg: #090d12;
    --sac-surface: #0f1318;
    --sac-surface2: #151b23;
    --sac-surface3: #1c232e;
    --sac-border: #1e2733;
    --sac-border-bright: #2d3a4a;
    --sac-text: #e2e8f0;
    --sac-text-dim: #7a8696;
    --sac-text-muted: #4a5568;
    --sac-accent: #60a5fa;
    --sac-accent-dim: #60a5fa20;
    --sac-green: #34d399;
    --sac-green-dim: #34d39920;
    --sac-orange: #fbbf24;
    --sac-red: #f87171;
    --sac-cyan: #22d3ee;
    --sac-radius: 12px;
}

.sac-header {
    background: rgba(9, 13, 18, 0.85);
    backdrop-filter: blur(16px) saturate(180%);
    border: 1px solid var(--sac-border);
    border-radius: var(--sac-radius);
    padding: 6px 14px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-family: 'Inter', sans-serif;
    margin-bottom: 8px;
}
.sac-header .sac-brand {
    display: flex; align-items: center; gap: 5px;
    font-size: 13px; font-weight: 600; color: var(--sac-text);
}
.sac-header .sac-brand .sac-icon { font-size: 14px; }
.sac-header .sac-chip {
    background: transparent;
    border: 1px solid var(--sac-border);
    border-radius: 100px;
    padding: 2px 7px;
    font-size: 9px;
    font-weight: 500;
    color: var(--sac-text-muted);
    font-family: 'JetBrains Mono', monospace;
    display: inline-flex;
    align-items: center;
    gap: 3px;
}
.sac-header .sac-chip.active { color: var(--sac-green); border-color: var(--sac-green-dim); }
.sac-header .sac-dot {
    width: 5px; height: 5px; border-radius: 50%; display: inline-block;
}
.sac-header .sac-dot.green { background: var(--sac-green); }
.sac-header .sac-dot.orange { background: var(--sac-orange); }
.sac-header .sac-spacer { flex: 1; }

.sac-tool-card {
    background: var(--sac-surface2);
    border: 1px solid var(--sac-border);
    border-radius: 10px;
    padding: 10px 14px;
    margin: 6px 0;
    font-size: 12px;
    font-family: 'JetBrains Mono', monospace;
}
.sac-tool-card .sac-tool-name { font-weight: 600; color: var(--sac-cyan); font-size: 11px; }
.sac-tool-card .sac-tool-status { font-size: 10px; color: var(--sac-text-muted); margin-top: 3px; }
.sac-tool-card .sac-tool-output {
    background: var(--sac-bg);
    border-radius: 6px;
    padding: 8px 10px;
    margin-top: 6px;
    font-size: 10.5px;
    color: var(--sac-text-dim);
    max-height: 120px;
    overflow-y: auto;
    white-space: pre-wrap;
    word-break: break-all;
}
.sac-tool-card.success { border-left: 2px solid var(--sac-green); }
.sac-tool-card.error { border-left: 2px solid var(--sac-red); }

.sac-thinking {
    background: linear-gradient(135deg, var(--sac-surface2), var(--sac-surface3));
    border: 1px solid var(--sac-border);
    border-left: 2px solid var(--sac-orange);
    border-radius: 10px;
    padding: 10px 14px;
    margin: 6px 0;
    font-size: 11px;
    font-family: 'JetBrains Mono', monospace;
    color: var(--sac-text-dim);
    max-height: 150px;
    overflow-y: auto;
    white-space: pre-wrap;
}
.sac-thinking .sac-thinking-label {
    font-size: 10px;
    font-weight: 600;
    color: var(--sac-orange);
    margin-bottom: 4px;
    display: flex;
    align-items: center;
    gap: 4px;
}
.sac-session-badge {
    background: var(--sac-surface2);
    border: 1px solid var(--sac-border);
    border-radius: 6px;
    padding: 2px 6px;
    font-size: 9px;
    font-family: 'JetBrains Mono', monospace;
    color: var(--sac-text-muted);
    cursor: pointer;
}
</style>
"""


def _format_tool_card(name: str, args_summary: str, output: str, success: bool) -> str:
    cls = "success" if success else "error"
    icon = "✅" if success else "❌"
    safe_output = html_mod.escape((output or "")[:500])
    safe_args = html_mod.escape(args_summary or "")
    return (
        f'<div class="sac-tool-card {cls}">'
        f'<div class="sac-tool-name">{name}</div>'
        f'<div class="sac-tool-status">{safe_args} {icon}</div>'
        f'<div class="sac-tool-output">{safe_output}</div>'
        f'</div>'
    )


def _format_thinking_card(thinking: str) -> str:
    safe = html_mod.escape((thinking or "")[:500])
    return (
        '<div class="sac-thinking">'
        '<div class="sac-thinking-label">🧠 Extended Thinking</div>'
        f'{safe}'
        '</div>'
    )


_ALL_PROVIDERS = {
    "anthropic": ("Anthropic", ALL_ANTHROPIC_MODELS),
    "openai": ("OpenAI", ALL_OPENAI_MODELS),
    "replicate": ("Replicate", ALL_REPLICATE_MODELS),
    "openrouter": ("OpenRouter", ALL_OPENROUTER_MODELS),
}


def agent_chat(
    workspace: str = ".",
    provider: str = "",
    model: str = "",
    api_key: str = "",
    max_turns: int = 25,
    max_tokens: int = 8192,
    temperature: float = 0.7,
    system_prompt: str = "",
    extended_thinking: bool = False,
    thinking_budget: int = 10000,
    computer_use: bool = False,
    show_config: bool = True,
    show_cost: bool = True,
    key: str | None = None,
) -> None:
    """Render a self-contained agentic AI chat interface.

    This is a drop-in Streamlit component. Everything renders inline —
    no sidebar usage. Place it in any column, tab, or container.
    """
    widget_key = key or "sac"

    # ── Inject CSS (once per page) ──
    st.markdown(_CSS, unsafe_allow_html=True)

    # ── Session state init ──
    state_key = f"{widget_key}_state"
    if state_key not in st.session_state:
        detected_provider = provider
        if not detected_provider:
            detected_provider, _ = resolve_provider("")

        engine = AgentEngine(
            workspace=workspace,
            provider=detected_provider,
            model=model,
            api_key=api_key,
            max_turns=max_turns,
            max_tokens=max_tokens,
            temperature=temperature,
            system_prompt=system_prompt,
            extended_thinking=extended_thinking,
            thinking_budget=thinking_budget,
            computer_use=computer_use,
        )
        st.session_state[state_key] = {
            "engine": engine,
            "messages": [],
            "turn_count": 0,
            "tool_calls": 0,
            "tool_log": [],
        }

    state = st.session_state[state_key]
    engine: AgentEngine = state["engine"]

    # ── Header bar with inline config ──
    llm_on = engine.is_configured
    model_display = LLMConfig(provider=engine.provider, model=engine.model).resolved_model if llm_on else "offline"
    u = engine.usage
    total_tok = u.input_tokens + u.output_tokens + u.thinking_tokens
    dot_cls = "green" if llm_on else "orange"
    chip_cls = "active" if llm_on else ""
    think_chip = f' · 🧠{u.thinking_tokens:,}' if u.thinking_tokens else ""

    st.markdown(f"""
    <div class="sac-header">
        <div class="sac-brand"><span class="sac-icon">🤖</span>Agent<span style="color:var(--sac-accent)">Chat</span></div>
        <span style="color:var(--sac-border)">│</span>
        <span class="sac-chip {chip_cls}"><span class="sac-dot {dot_cls}"></span>{model_display}</span>
        <span class="sac-spacer"></span>
        <span class="sac-chip">{total_tok:,} tok{think_chip} · T{state['turn_count']}</span>
        <span class="sac-session-badge">{engine.session_id}</span>
    </div>
    """, unsafe_allow_html=True)

    # ── Inline config (compact popover) ──
    if show_config:
        with st.popover("⚙️ Settings", use_container_width=False):
            prov_labels = list(_ALL_PROVIDERS.keys())
            cur_idx = prov_labels.index(engine.provider) if engine.provider in prov_labels else 0
            sel_provider = st.selectbox(
                "Provider", prov_labels, index=cur_idx,
                format_func=lambda x: _ALL_PROVIDERS[x][0],
                key=f"{widget_key}_prov",
            )
            model_opts = _ALL_PROVIDERS[sel_provider][1]
            cur_model_idx = model_opts.index(engine.model) if engine.model in model_opts else 0
            sel_model = st.selectbox("Model", model_opts, index=cur_model_idx, key=f"{widget_key}_model")

            c1, c2 = st.columns(2)
            with c1:
                if st.button("⚡ Connect", use_container_width=True, key=f"{widget_key}_connect"):
                    engine.set_provider(sel_provider, sel_model)
                    st.rerun()
            with c2:
                if st.button("🔄 New Chat", use_container_width=True, key=f"{widget_key}_new"):
                    engine.reset()
                    state["messages"] = []
                    state["turn_count"] = 0
                    state["tool_calls"] = 0
                    state["tool_log"] = []
                    st.rerun()

            # Advanced features
            st.divider()
            st.caption("Advanced")
            t1, t2 = st.columns(2)
            with t1:
                think_on = st.toggle("🧠 Thinking", value=engine.extended_thinking, key=f"{widget_key}_think")
                if think_on != engine.extended_thinking:
                    engine.extended_thinking = think_on
                    engine._client = None
            with t2:
                comp_on = st.toggle("🖥️ Computer", value=engine.computer_use, key=f"{widget_key}_comp")
                if comp_on != engine.computer_use:
                    engine.computer_use = comp_on
                    engine._client = None
            if think_on:
                budget = st.slider("Thinking budget", 1000, 50000, engine.thinking_budget, 1000, key=f"{widget_key}_budget")
                if budget != engine.thinking_budget:
                    engine.thinking_budget = budget
                    engine._client = None

            # Session management
            st.divider()
            st.caption("Sessions")
            sc1, sc2 = st.columns(2)
            with sc1:
                if st.button("💾 Save", use_container_width=True, key=f"{widget_key}_save"):
                    engine.save()
                    st.toast(f"Session saved: {engine.session_id}")
            with sc2:
                sessions = list_sessions(engine.workspace)
                if sessions:
                    selected = st.selectbox(
                        "Load session", [s["session_id"] for s in sessions],
                        key=f"{widget_key}_load_sel", label_visibility="collapsed",
                    )
                    if st.button("📂 Load", use_container_width=True, key=f"{widget_key}_load"):
                        if engine.load(selected):
                            state["messages"] = []
                            state["turn_count"] = 0
                            state["tool_calls"] = 0
                            state["tool_log"] = []
                            st.toast(f"Loaded: {selected}")
                            st.rerun()

    # ── Render messages ──
    for msg in state["messages"]:
        role = msg["role"]
        if role == "user":
            with st.chat_message("user", avatar="👤"):
                st.markdown(msg["content"])
        elif role == "assistant":
            with st.chat_message("assistant", avatar="🤖"):
                st.markdown(msg["content"], unsafe_allow_html=True)

    # ── Chat input ──
    if prompt := st.chat_input("Ask anything…", key=f"{widget_key}_input"):
        state["messages"].append({"role": "user", "content": prompt})
        with st.chat_message("user", avatar="👤"):
            st.markdown(prompt)

        if not engine.is_configured:
            response = "⚠️ No LLM configured. Click ⚙️ Settings to connect a provider."
            state["messages"].append({"role": "assistant", "content": response})
            with st.chat_message("assistant", avatar="🤖"):
                st.markdown(response)
        else:
            with st.chat_message("assistant", avatar="🤖"):
                with st.spinner("Working…"):
                    result = engine.submit(prompt)

                state["turn_count"] += 1

                display_parts = []

                # Show thinking if available
                if result.thinking:
                    display_parts.append(_format_thinking_card(result.thinking))

                if result.tool_calls:
                    for tc in result.tool_calls:
                        summary = summarize_args(tc["arguments"])
                        state["tool_calls"] += 1
                        state["tool_log"].append({
                            "name": tc["name"],
                            "summary": summary,
                            "success": True,
                        })

                display_parts.append(result.output)

                if show_cost:
                    think_info = f" · 🧠{result.usage.thinking_tokens:,}" if result.usage.thinking_tokens else ""
                    display_parts.append(
                        f"\n\n<div style='text-align:right;font-size:10px;color:var(--sac-text-muted);"
                        f"font-family:JetBrains Mono,monospace;margin-top:6px;'>"
                        f"{result.usage.input_tokens:,}↓ {result.usage.output_tokens:,}↑{think_info} · "
                        f"T{state['turn_count']} · {state['tool_calls']} calls</div>"
                    )

                full_response = "\n".join(display_parts)
                st.markdown(full_response, unsafe_allow_html=True)
                state["messages"].append({"role": "assistant", "content": full_response})
