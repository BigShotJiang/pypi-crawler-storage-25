# Claude Code Settings

Claude Code configuration for `CLI`.

Contains `settings.local.json` with permission rules. Most branches are denied raw git commands and must use `drone @git` instead.
