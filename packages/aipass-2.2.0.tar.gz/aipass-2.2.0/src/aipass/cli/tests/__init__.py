# Tests package for cli
