# DRONE Branch-Local Context
<!-- Auto-generated local prompt -->

> Auto-created by aipass init. Customize for your branch.

## Status: NEEDS CONFIGURATION

This file is injected into every AI conversation when working from this branch directory. Configure it with:

- Who this branch is (role, purpose)
- Key commands and workflows
- Architecture overview
- Critical files and operational rules
- Integration points with other branches
