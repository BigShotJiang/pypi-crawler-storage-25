# Branch Prompt

AI context for `FLOW`. The `aipass_local_prompt.md` file is injected every turn, telling the AI who you are and how to work in your branch.
