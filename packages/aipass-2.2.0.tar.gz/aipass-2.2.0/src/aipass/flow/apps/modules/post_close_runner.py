# =================== AIPass ====================
# Name: post_close_runner.py
# Description: Background post-close processing
# Version: 1.2.0
# Created: 2026-02-14
# Modified: 2026-02-14
# =============================================

"""
Post-Close Background Runner

Runs @memory archival as a background process.
Called by close_plan.py via subprocess.Popen so the close command returns fast.

Uses a lock file to prevent concurrent execution - if another instance is
already running, this one exits silently (the running instance will pick up
all unprocessed plans since it scans ALL of them).

This script lives inside the flow branch so handler import guards allow it.
"""

import sys
from pathlib import Path

from aipass.cli.apps.modules import console, error, warning
from aipass.flow.apps.handlers.json import json_handler
from aipass.flow.apps.handlers.mbank.process import process_closed_plans
from aipass.flow.apps.handlers.runner.lock_ops import acquire_lock, release_lock
from aipass.prax.apps.modules.logger import system_logger as logger

_PKG_ROOT = Path(__file__).resolve().parents[3]
FLOW_ROOT = _PKG_ROOT / "flow"
MODULE_NAME = "post_close_runner"
LOCK_FILE = FLOW_ROOT / ".post_close_runner.lock"


def handle_command(command: str, args: list) -> bool:
    """Handle commands routed by the entry point.

    This module is a background utility runner, not a user-facing command.
    It responds to 'post_close' for drone routing compatibility
    and supports --help / -h for introspection.

    Args:
        command: Command name
        args: Command arguments

    Returns:
        True if command was handled, False otherwise
    """
    if command not in ("post", "post_close_runner"):
        return False

    if not args:
        print_introspection()
        return True

    # Handle help flag
    if args[0] in ["--help", "-h", "help"]:
        print_help()
        return True

    # Log the operation
    json_handler.log_operation("post_close_processed", {"command": command, "args": args})

    # Run the post-close processing directly (foreground)
    if not acquire_lock(LOCK_FILE):
        warning("Another instance is already running")
        return True

    try:
        process_closed_plans()
        console.print("[green]Processing complete[/green]")
    except Exception as e:
        logger.error(f"[{MODULE_NAME}] Background processing failed: {e}")
        error(f"Processing failed: {e}")
    finally:
        release_lock(LOCK_FILE)

    return True


def print_introspection():
    """Display module introspection info."""
    console.print()
    console.print("[bold cyan]post_close_runner Module[/bold cyan]")
    console.print()

    console.print("[yellow]Connected Handlers:[/yellow]")
    console.print()
    console.print("  [cyan]handlers/mbank/[/cyan]")
    console.print("    [dim]- process.py (process_closed_plans — scan and archive closed plans)[/dim]")
    console.print()

    console.print("[dim]Run 'drone @flow post --help' for usage[/dim]")
    console.print()


def print_help():
    """Print help information for post_close_runner module"""
    console.print()
    console.print("[bold cyan]post_close_runner[/bold cyan] — Background post-close processing")
    console.print()
    console.print("[yellow]USAGE:[/yellow]")
    console.print("  drone @flow post")
    console.print()
    console.print("[yellow]NOTES:[/yellow]")
    console.print("  Background utility — called by close_plan.py via subprocess.")
    console.print("  Not typically invoked directly.")
    console.print()


if __name__ == "__main__":
    if "--help" in sys.argv or "-h" in sys.argv:
        print_help()
        sys.exit(0)

    if not acquire_lock(LOCK_FILE):
        sys.exit(0)

    try:
        process_closed_plans()
    except Exception as e:
        logger.error(f"[{MODULE_NAME}] Background processing failed: {e}")
    finally:
        release_lock(LOCK_FILE)
