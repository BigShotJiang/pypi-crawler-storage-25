# =================== AIPass ====================
# Name: chroma_client.py
# Description: Symbolic ChromaDB Client
# Version: 0.1.0
# Created: 2026-03-17
# Modified: 2026-03-17
# =============================================

"""
Shared ChromaDB Client Handler - THE canonical singleton for all of memory

Provides a singleton ChromaDB PersistentClient per database path to prevent
write contention from multiple competing PersistentClient instances against
the same .chroma/ directory.

ALL handlers that need ChromaDB access MUST import from here:
    from aipass.memory.apps.handlers.symbolic.chroma_client import get_client

Key Functions:
    - get_client(db_path) - get singleton PersistentClient (preferred)
    - get_chroma_client(db_path) - alias for get_client (backward compat)
    - get_collection() - get or create a collection with correct settings
"""

from typing import Dict, Any
from pathlib import Path

from aipass.prax import logger
from aipass.memory.apps.handlers.json import json_handler


# =============================================================================
# CONSTANTS
# =============================================================================

# memory/ root resolved from symbolic/chroma_client.py
_MEMORY_ROOT = Path(__file__).resolve().parent.parent.parent.parent
DEFAULT_DB_PATH = _MEMORY_ROOT / ".chroma"

# Singleton client cache - keyed by resolved path string
_clients: Dict[str, Any] = {}


# =============================================================================
# CLIENT MANAGEMENT
# =============================================================================


def get_client(db_path: Path | str | None = None):
    """
    Get or create a shared ChromaDB PersistentClient (singleton per path)

    This is THE canonical way to get a ChromaDB client in memory.
    All handlers must use this function instead of creating their own
    PersistentClient instances to avoid write contention on .chroma/.

    Args:
        db_path: Optional path to ChromaDB (default: memory/.chroma)
                 Accepts Path or str.

    Returns:
        ChromaDB PersistentClient instance
    """
    import chromadb

    if db_path is None:
        db_path = DEFAULT_DB_PATH

    if isinstance(db_path, str):
        db_path = Path(db_path)

    # Resolve to absolute path for consistent cache keys
    path_str = str(db_path.resolve())

    if path_str not in _clients:
        db_path.mkdir(parents=True, exist_ok=True)
        # Use simple PersistentClient without Settings to avoid pydantic compatibility issues
        _clients[path_str] = chromadb.PersistentClient(path=path_str)

    return _clients[path_str]


# Backward-compatible alias
def get_chroma_client(db_path: Path | str | None = None):
    """Alias for get_client() - backward compatibility"""
    return get_client(db_path)


def get_collection(
    collection_name: str, db_path: Path | None = None, create: bool = True, metadata: Dict[str, Any] | None = None
):
    """
    Get a collection from the shared ChromaDB client

    Args:
        collection_name: Name of the collection
        db_path: Optional path to ChromaDB
        create: If True, create collection if it doesn't exist
        metadata: Optional collection metadata (default adds cosine distance)

    Returns:
        Dict with 'success', 'collection' or 'error'
    """
    try:
        client = get_client(db_path)

        if create:
            # Default metadata includes cosine distance for similarity search
            if metadata is None:
                metadata = {"hnsw:space": "cosine"}

            collection = client.get_or_create_collection(
                name=collection_name, metadata=metadata, embedding_function=None
            )
        else:
            collection = client.get_collection(collection_name, embedding_function=None)

        json_handler.log_operation(
            "chroma_get_collection", {"collection": collection_name, "create": create, "success": True}
        )
        return {"success": True, "collection": collection}

    except Exception as e:
        logger.error(f"[chroma_client] Failed to get collection '{collection_name}': {e}")
        return {"success": False, "error": str(e)}
