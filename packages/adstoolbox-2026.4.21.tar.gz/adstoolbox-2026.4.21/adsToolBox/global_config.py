"""
Module global_config pour la configuration globale d'adsToolBox.

Fournit des fonctions utilitaires pour:
- Activer/désactiver le timer
- Récupérer l'état du timer
- Obtenir l'adresse IP publique de la machine
- Décorateur retry_on_failure paramétrable
"""
from __future__ import annotations

import functools
import inspect
import time
from dataclasses import dataclass, field
from typing import Callable, TypeVar

import requests
from requests import Response

try:
    from typing import ParamSpec  # Python ≥ 3.10
except ImportError:
    from typing_extensions import ParamSpec  # Python 3.9

HTTP_OK = 200

P = ParamSpec("P")
R = TypeVar("R")


@dataclass
class _ReconnectContext:
    method: Callable | None
    name: str | None  # uniquement pour le log
    args: list = field(default_factory=list)


@dataclass
class _RetryConfig:
    count: int
    delay: float
    inf: bool
    max_att: float


class TimerConfig:
    """Singleton pour stocker l'état du timer."""

    _enabled: bool = False

    @classmethod
    def set(cls, *, state: bool) -> None:
        """
        Active ou désactive le timer.

        :param state: détermine l'état du timer
        """
        cls._enabled = state

    @classmethod
    def get(cls) -> bool:
        """
        Récupère l'état du timer.

        :return: l'état du timer
        """
        return cls._enabled


def set_timer(*, state: bool) -> None:
    """Wrapper pour activer ou désactiver le timer."""  # noqa: D401
    TimerConfig.set(state=state)


def get_timer() -> bool:
    """Wrapper pour récupérer l'état du timer."""  # noqa: D401
    return TimerConfig.get()


def _resolve_retry_params(
        self_: object,
        f: Callable,
        retry_count: int | None,
        retry_delay: float | None,
        logger: object,
) -> _RetryConfig:
    """Résout les paramètres de retry depuis l'instance ou le décorateur."""
    count = retry_count if retry_count is not None else getattr(self_, "retry_count", None)
    delay = retry_delay if retry_delay is not None else getattr(self_, "retry_delay", None)
    if count is None or delay is None:
        msg = (
            f"retry_on_failure sur '{f.__name__}': retry_count et retry_delay sont requis. "
            f"Définissez-les sur l'instance ou passez-les au décorateur."
        )
        if logger:
            logger.error(msg)
        raise ValueError(msg)
    inf = count == 0
    return _RetryConfig(count=count, delay=delay, inf=inf, max_att=float("inf") if inf else count)


def _resolve_reconnect(
        self_: object,
        f: Callable,
        retry_method: str | None,
        logger: object,
) -> _ReconnectContext:
    """Résout la méthode de reconnexion et ses arguments."""
    is_self_retry = retry_method is not None and retry_method == f.__name__
    if retry_method is None or is_self_retry or self_ is None:
        return _ReconnectContext(method=None, name=None)
    reconnect_method = getattr(self_, retry_method, None)
    if reconnect_method is None:
        msg = f"retry_method '{retry_method}' introuvable sur {type(self_).__name__}."
        if logger:
            logger.error(msg)
        raise AttributeError(msg)
    sig = inspect.signature(reconnect_method)
    reconnect_args = [p for p in sig.parameters if p not in ("self", "args", "kwargs")]
    return _ReconnectContext(method=reconnect_method, name=retry_method, args=reconnect_args)


def _attempt(
        f: Callable,
        args: tuple,
        kwargs: dict,
        att: int,
        cfg: _RetryConfig,
        reconnect: _ReconnectContext,
        logger: object,
) -> object:
    """Tente un appel avec reconnexion préalable si nécessaire."""
    if att > 1 and reconnect.method is not None:
        if logger:
            logger.debug(f"Reconnexion via '{reconnect.name}' (tentative {att}/{cfg.max_att})...")
        reconnect.method(*reconnect.args)
        if logger:
            logger.debug("Reconnexion réussie.")
    return f(*args, **kwargs)


def _handle_exception(
        e: Exception,
        f: Callable,
        att: int,
        cfg: _RetryConfig,
        retryable_exceptions: tuple[type[Exception], ...] | None,
        logger: object,
) -> None:
    """Gère une exception dans la boucle de retry, lève si non retriable ou épuisé."""
    if retryable_exceptions is not None and not isinstance(e, retryable_exceptions):
        if logger:
            logger.error(f"Erreur non-retriable dans '{f.__name__}' ({type(e).__name__}): {e}")
        raise e
    if logger:
        logger.warning(f"Tentative {att}/{cfg.max_att} échouée pour '{f.__name__}': {e}")
    if not cfg.inf and att >= cfg.count:
        final_msg = f"Échec définitif de '{f.__name__}' après {cfg.count} tentative(s) ({cfg.count * cfg.delay}s)."
        if logger:
            logger.error(final_msg)
        raise e
    time.sleep(cfg.delay)


def retry_on_failure(
        func: Callable[P, R] | None = None,
        *,
        retry_method: str | None = None,
        retry_count: int | None = None,
        retry_delay: float | None = None,
        retryable_exceptions: tuple[type[Exception], ...] | None = None,
) -> Callable:
    """
    Décorateur paramétrable qui réessaie une fonction ou méthode en cas d'erreur.

    :param func: La méthode à décorer
    :param retry_method: Nom de la méthode à appeler sur self avant chaque retry
    :param retry_count: Surcharge self.retry_count si fourni. Obligatoire pour les fonctions standalone (0 = infini).
    :param retry_delay: Surcharge self.retry_delay si fourni. Obligatoire pour les fonctions standalone.
    :param retryable_exceptions: Si fourni, seules ces exceptions déclenchent un retry. Toute autre exception est levée immédiatement sans retry.
    """
    def decorator(f: Callable[P, R]) -> Callable[P, R]:
        @functools.wraps(f)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            self_ = args[0] if args and hasattr(args[0], "logger") else None
            logger = getattr(self_, "logger", None)
            cfg = _resolve_retry_params(self_, f, retry_count, retry_delay, logger)
            reconnect = _resolve_reconnect(self_, f, retry_method, logger)
            att = 0
            while att < cfg.max_att:
                att += 1
                try:
                    return _attempt(f, args, kwargs, att, cfg, reconnect, logger)
                except Exception as e: # noqa: BLE001
                    _handle_exception(e, f, att, cfg, retryable_exceptions, logger)
            msg = "Erreur interne de retry_on_failure."
            raise RuntimeError(msg)
        return wrapper
    if func is not None:
        return decorator(func)
    return decorator


def _safe_get(url: str, timeout: int) -> Response | None:
    """Effectue une requête GET et capture l'exception."""
    try:
        return requests.get(url, timeout=timeout)
    except requests.RequestException:
        return None


def get_public_ip(timeout: int = 5) -> str:
    """
    Récupère l'adresse IP publique de la machine.

    :param timeout: Délai max de la requête http en secondes
    """
    urls = [
        "https://api.ipify.org",
        "https://ifconfig.me/ip",
        "https://checkup.amazonaws.com",
    ]
    e_msg = "Impossible de récupérer l'adresse IP publique"
    for url in urls:
        response = _safe_get(url, timeout=timeout)
        if response is not None and response.status_code == HTTP_OK:
            return response.text.strip()
    raise RuntimeError(e_msg)
