from httpx import Response

from httpx_sse import SSEError


class ITDError(Exception):
    messages = {
        'Session not found': 'Такого refresh токена не существует.',
        'Refresh token not found': 'Refresh токен не указан или равен пустой строке',
        'Session revoked': 'Refresh токен отозван',
        'Password requirement not met': "Пароль не соответствует требованиям",
        'New password must be different from current password': "Новый пароль должен отличать от предыдущего",
        'Incorrect old password': 'Старый пароль указан неверно',
        'Недопустимый тип файла': 'Недопустимый тип файла',
        'File not found': "Файл не найден",
        'File not found or access denied': 'Файл не надйне или нет прав на изменение',
        'Post not found': "Пост не существует (или удалён)",
        'Not allowed to delete this post': "Нет прав для удаления поста",
        'Not allowed to restore this post': "Нет прав для восстановления поста",
        'Can only pin your own posts or posts on your wall': 'Можно прикреплять посты только на своей стене',
        'This post is not pinned': 'Пост не прикреплён',
        'Already reposted this post': 'Нельзя репостнуть пост два раза',
        'Cannot repost your own post': "Нельзя репостить свои посты",
        'User not found': 'Пользователь не найден',
        'Content or attachments required': 'Необходимы content или attachments, нельзя создать пустой комментарий',
        'Not allowed to restore this comment': 'Нет прав для восстановления этого комментария',
        'Maximum 10 attachments allowed per post': 'К посту можно прикрепить максимум 10 файлов',
        'Not allowed to edit this post': "Нет прав для редактирования этого поста",
        'Comment not found': 'Комментарий не найден',
        'Not allowed to delete this comment': 'нет прав на удаление комментария',
        'Not allowed to edit this comment': 'нет прав на редактирование этого комментария',
        'Rate limit exceeded': 'Слишком много запросов',
        'Content, attachments or poll required': "Нельзя создать пустой пост",
        'Already following this user': 'Уже подписаны на этого пользователя',
        'Session expired': 'Токен истёк',
        'You do not own this pin': 'Вы не обладаете этим пином',
        'User already blocked': 'Пользователь уже заблокирован',
        'Cannot block yourself': "Нельзя заблокировать себя",
        'User is not blocked': 'Пользователь не заблокирован',
        'Cannot follow yourself': "Нельзя подписать на себя",
        'You can only use your own files as banner': 'На баннер можно поставить только свой файл',
        'Banner file not found': 'Файл для баннера не найден',
        'Username is already taken': 'Имя пользователя уже занято',
        "Wall recipient not found": 'Пользователь не найден',
        'Account is already deleted': 'Аккаунт уже удалён',
        'Your account has been deleted. You can restore it within 30 days.': "Ваш аккаунт удалён, вы может восстановить его в течении 30 денй",
        'Account is not deleted': 'Аккаунт удалён',
        'Your account has been deactivated': "Аккаунт забанен",
        'Username is required': "Необходимо передать имя пользователя"
    }
    code = "UNCNOWN"

    def __init__(self, code: str | None = None, message: str = "", response: Response | None = None):
        if len(message) == 0 and hasattr(self, 'message'):
            self.message = message
        else:
            self.message = message
        if code is not None:
            self.code = code
        self.response = response

    def __str__(self):
        return f"code='{self.code}', message='{self.messages.get(self.message, self.message)}'"


class UnauthorizedError(ITDError):
    code = "UNAUTHORIZED"
    message = "Ошибка авторизации"


class ServerError(ITDError):
    code = "SERVER_ERROR"
    message = "Сервер временно недоступен"


class GatewayTimeOutError(ITDError):
    code = "GET_WAY"


class UnknowError(ITDError):
    code = "UNKNOWN_ERROR"


class RateLimitError(ITDError):
    code = "RATE_LIMIT_EXCEEDED"

    def __init__(self, code: str, message: str, retry_after: int, response: Response | None = None):
        super().__init__(code, message)
        self.retry_after = retry_after
        self.response = response

    def __str__(self):
        return super().__str__() + f", retry_after={self.retry_after}"


class TokenNotFoundError(ITDError):
    code = "SESSION_NOT_FOUND"


class TokenRevokedError(ITDError):
    code = "SESSION_REVOKED"


class TokenExpiredError(ITDError):
    code = "SESSION_EXPIRED"


class TokenMissingError(ITDError):
    code = "REFRESH_TOKEN_MISSING"


class SomePasswordError(ITDError):
    code = "SAME_PASSWORD"


class InvalidPasswordError(ITDError):
    code = "INVALID_PASSWORD"


class InvalidOldPasswordError(ITDError):
    code = "INVALID_OLD_PASSWORD"


class UploadError(ITDError):
    code = "UPLOAD_ERROR"


class ParamsValidationError(ITDError):
    def __init__(self, type: str, on: str, found: dict[str, str], response: Response | None = None):
        self.type = type
        self.on = on
        self.found = found
        self.response = response

    def __str__(self):
        return f"type: {self.type}, on: {self.on}, found: {self.found}"


class ValidationError(ITDError):
    code = "VALIDATION_ERROR"


class TooLargeError(ITDError):
    code = "413"


class NotAllowedError(ITDError):
    code = "403"


class NotFoundError(ITDError):
    code = "NOT_FOUND"


class ForbiddenError(ITDError):
    code = "FORBIDDEN"


class NotPinedError(ITDError):
    code = "NOT_PINNED"


class ConflictError(ITDError):
    code = "CONFLICT"


class UserBlockedError(ITDError):
    code = "USER_BLOCKED"


class PinNotOwnedError(ITDError):
    code = "PIN_NOT_OWNED"


class ContentModerationError(ITDError):
    code = "CONTENT_MODERATION_ERROR"


class UsernameTakenError(ITDError):
    code = "USERNAME_TAKEN"


class VideoRequiresVerificationError(ITDError):
    code = "VIDEO_REQUIRES_VERIFICATION"


class WallClosedError(ITDError):
    code = "WALL_CLOSED"


class EditWindowExpiredError(ITDError):
    code = "EDIT_WINDOW_EXPIRED"


class AlreadyDeletedError(ITDError):
    code = "ALREADY_DELETED"


class AccountDeletedError(ITDError):
    code = "ACCOUNT_DELETED"


class NotDeletedError(ITDError):
    code = "NOT_DELETED"


class AccountBannedError(ITDError):
    code = "ACCOUNT_BANNED"


class ProfileNotFoundError(ITDError):
    code = "PROFILE_NOT_FOUND"


class InvalidInputError(ITDError):
    code = "INVALID_INPUT"


class InvalidAAvatarError(ITDError):
    code = "INVALID_AVATAR"


class GIFRequiresVerificationError(ITDError):
    code = "GIF_REQUIRES_VERIFICATION"

itd_exceptions = [
    TokenNotFoundError,
    TokenRevokedError,
    TokenMissingError,
    UnauthorizedError,
    NotFoundError,
    InvalidPasswordError,
    InvalidOldPasswordError,
    InvalidOldPasswordError,
    SomePasswordError,
    ForbiddenError,
    ValidationError,
    NotPinedError,
    ConflictError,
    RateLimitError,
    UnknowError,
    ServerError,
    UploadError,
    UserBlockedError,
    TokenExpiredError,
    PinNotOwnedError,
    ContentModerationError,
    UsernameTakenError,
    VideoRequiresVerificationError,
    WallClosedError,
    EditWindowExpiredError,
    AlreadyDeletedError,
    AccountDeletedError,
    NotDeletedError,
    AccountBannedError,
    ProfileNotFoundError,
    InvalidInputError,
    InvalidAAvatarError,
    GIFRequiresVerificationError
]

itd_codes = {}
for exception in itd_exceptions:
    itd_codes[exception.code] = exception

__all__ = [
    "ITDError",
    "UnauthorizedError",
    "ServerError",
    "GatewayTimeOutError",
    "UnknowError",
    "RateLimitError",
    "TokenNotFoundError",
    "TokenRevokedError",
    "TokenExpiredError",
    "TokenMissingError",
    "SomePasswordError",
    "InvalidPasswordError",
    "InvalidOldPasswordError",
    "UploadError",
    "ParamsValidationError",
    "ValidationError",
    "TooLargeError",
    "NotAllowedError",
    "NotFoundError",
    "ForbiddenError",
    "NotPinedError",
    "ConflictError",
    "UserBlockedError",
    "PinNotOwnedError",
    "ContentModerationError",
    "UsernameTakenError",
    "VideoRequiresVerificationError",
    "WallClosedError",
    "EditWindowExpiredError",
    "AlreadyDeletedError",
    "AccountDeletedError",
    "NotDeletedError",
    "AccountBannedError",
    "ProfileNotFoundError",
    "itd_codes",
    "SSEError",
    "InvalidInputError",
    "InvalidAAvatarError",
    "GIFRequiresVerificationError"
]
