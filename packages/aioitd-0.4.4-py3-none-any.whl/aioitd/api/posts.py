from enum import Enum
from typing import Literal
from uuid import UUID

import httpx

from aioitd.fetch import add_bearer, delete, get, post, put, decode_jwt_payload
from aioitd.models.comments import Comment
from aioitd.models.posts import Post, Poll, UpdatePostResponse, Monospace, Strike, Underline, Bold, Italic, Spoiler, \
    Link
from aioitd.models.base import Pagination, TotalPagination


async def get_post(
        client: httpx.AsyncClient,
        access_token: str,
        post_id: UUID,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> tuple[list[Comment], Post]:
    """Получить пост.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        post_id: UUID поста
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        NotFoundError:
            пост не существует, удалён, владелец поста забанил, пост принадлежит пользователю с is_private=True,
            на которого вы не подписаны
    """
    response = await get(
        client,
        f"https://{domain}/api/posts/{post_id}",
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()['data']
    comments = list(map(Comment.model_validate, data['comments']))
    del data['comments']
    post = Post(**data)
    return comments, post


async def delete_post(
        client: httpx.AsyncClient,
        access_token: str,
        post_id: UUID,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> None:
    """Удалить пост.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        post_id: UUID поста
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        ForbiddenError: Нет прав для удаления поста
        NotFoundError: Пост не найден

    """
    await delete(
        client,
        f"https://{domain}/api/posts/{post_id}",
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )


async def restore_post(
        client: httpx.AsyncClient,
        access_token: str,
        post_id: UUID,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> None:
    """Восстановить пост.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        post_id: UUID поста
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        ForbiddenError: Нет прав для восстановления поста
        NotFoundError: Пост не найден
    """
    await post(
        client,
        f"https://{domain}/api/posts/{post_id}/restore",
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )


async def like_post(
        client: httpx.AsyncClient,
        access_token: str,
        post_id: UUID,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> int:
    """Лайкнуть пост.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        post_id: UUID поста
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        NotFoundError: Пост не найден

    """
    response = await post(
        client,
        f"https://{domain}/api/posts/{post_id}/like",
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()

    return data["likesCount"]


async def unlike_post(
        client: httpx.AsyncClient,
        access_token: str,
        post_id: UUID,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> int:
    """Убрать лайк с пост.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        post_id: UUID поста
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        NotFoundError: Пост не найден

    """
    response = await delete(
        client,
        f"https://{domain}/api/posts/{post_id}/like",
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()

    return data["likesCount"]


async def view_post(
        client: httpx.AsyncClient,
        access_token: str,
        post_id: UUID,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> None:
    """Просмотр на пост.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        post_id: UUID поста
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
    """
    await post(
        client,
        f"https://{domain}/api/posts/{post_id}/view",
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )


async def pin_post(
        client: httpx.AsyncClient,
        access_token: str,
        post_id: UUID | str,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> bool:
    """Закрепить пост.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        post_id: UUID поста
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        NotFoundError: Пост не найден
        ForbiddenError: Можно прикреплять посты только на своей стене

    """
    response = await post(
        client,
        f"https://{domain}/api/posts/{post_id}/pin",
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()
    return data["success"]


async def unpin_post(
        client: httpx.AsyncClient,
        access_token: str,
        post_id: UUID,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> bool:
    """Открепить пост.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        post_id: UUID поста
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        NotPinedError: Пост не прикреплён

    """
    response = await delete(
        client,
        f"https://{domain}/api/posts/{post_id}/pin",
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()
    return data["success"]


class PostSort(str, Enum):
    NEW = "new"
    POPULAR = "popular"

    def __str__(self):
        return self.value


async def get_posts_by_user(
        client: httpx.AsyncClient,
        access_token: str,
        username_or_id: str | UUID,
        cursor: str | None = None,
        limit: int = 20,
        sort: PostSort | Literal["new", "popular"] = PostSort.NEW,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> tuple[Pagination, list[Post]]:
    """Посты на стене пользователя.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        username_or_id: имя пользователя или его UUID
        cursor: next_cursor на предыдущей странице
        limit: максимальное количество выданных постов
        sort: сортировка
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        NotFoundError: пользователь не найден
        ValidationError: 1 <= limit <= 50
        UserBlockedError: пользователь заблокирован

    """

    response = await get(
        client,
        f"https://{domain}/api/posts/user/{username_or_id}",
        params={"sort": sort, "limit": limit} | (
            {} if cursor is None else {"cursor": cursor}),
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()["data"]
    pagination = Pagination(**data["pagination"])
    posts = list(map(Post.model_validate, data["posts"]))

    return pagination, posts


async def get_posts_by_user_liked(
        client: httpx.AsyncClient,
        access_token: str,
        username_or_id: str | UUID,
        cursor: str | None = None,
        limit: int = 20,
        sort: PostSort | Literal["new", "popular"] = PostSort.NEW,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> tuple[Pagination, list[Post]]:
    """Посты на которые пользователей поставил лайк.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        username_or_id: имя пользователя или его UUID
        cursor: next_cursor на предыдущей странице
        limit: максимальное количество выданных постов
        sort: сортировка
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        NotFoundError: пользователь не найден
        ValidationError: 1 <= limit <= 50
        UserBlockedError: пользователь заблокирован
    """
    response = await get(
        client,
        f"https://{domain}/api/posts/user/{username_or_id}/liked/",
        params={"sort": sort, "limit": limit} | (
            {} if cursor is None else {"cursor": cursor}),
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()["data"]
    pagination = Pagination(**data["pagination"])
    for post in data['posts']:
        post['wallRecipient'] = None

    posts = list(map(Post.model_validate, data["posts"]))

    return pagination, posts


async def get_posts_by_user_wall(
        client: httpx.AsyncClient,
        access_token: str,
        username_or_id: str | UUID,
        cursor: None = None,
        limit: int = 20,
        sort: PostSort | Literal["new", "popular"] = PostSort.NEW,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> tuple[Pagination, list[Post]]:
    """Посты на стене пользователя, сделанные не пользователем.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        username_or_id: имя пользователя или его UUID
        cursor: next_cursor на предыдущей странице
        limit: максимальное количество выданных постов
        sort: сортировка
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        NotFoundError: пользователь не найден
        ValidationError: 1 <= limit <= 50
        UserBlockedError: пользователь заблокирован
    """
    response = await get(
        client,
        f"https://{domain}/api/posts/user/{username_or_id}/wall",
        params={"sort": sort, "limit": limit} | (
            {} if cursor is None else {"cursor": cursor}),
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()["data"]
    pagination = Pagination(**data["pagination"])
    posts = list(map(Post.model_validate, data["posts"]))

    return pagination, posts


class Tab(str, Enum):
    POPULAR = 'popular'
    FOLLOWING = 'following'
    CLAN = 'clan'

    def __str__(self):
        return self.value


async def get_posts(
        client: httpx.AsyncClient,
        access_token: str,
        cursor: None = None,
        limit: int = 20,
        tab: Tab | Literal['popular', 'following', 'clan'] = Tab.POPULAR,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> tuple[Pagination, list[Post]]:
    """Лента.

    Args:
        client: httpx.AsyncClient
        access_token: access токен
        cursor: next_cursor на предыдущей странице
        limit: максимальное количество выданных постов
        tab: популярные, подписка, кланы
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        ValidationError: 1 <= limit <= 50
    """
    response = await get(
        client,
        f"https://{domain}/api/posts?limit=20&tab=popular",
        params={"tab": tab, "limit": limit} | (
            {} if cursor is None else {"cursor": cursor}),
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()["data"]
    pagination = Pagination(**data["pagination"])

    for post in data['posts']:
        if 'authorId' in post:
            del post['authorId']
        if 'wallRecipient' not in post:
            post['wallRecipient'] = None

    posts = list(map(Post.model_validate, data["posts"]))

    return pagination, posts


class CommentSort(str, Enum):
    POPULAR = 'popular'
    NEWEST = 'newest'
    OLDEST = 'oldest'

    def __str__(self):
        return self.value


async def get_post_comments(
        client: httpx.AsyncClient,
        access_token: str,
        post_id: UUID,
        cursor: str | None = None,
        limit: int = 20,
        sort: CommentSort | Literal["popular", "newest", "oldest"] = CommentSort.NEWEST,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> tuple[TotalPagination, list[Comment]]:
    """Получить комментарии под постом.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        post_id: UUID поста
        cursor: next_cursor с предыдущей страницы
        limit: максимальное количество комментариев на странице
        sort: сортировать по
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        NotFoundError: Пост не найден
        ParamsValidationError: 1 <= limit <= 500
    """
    response = await get(
        client,
        f"https://{domain}/api/posts/{post_id}/comments",
        params={"sort": sort, "limit": limit} | ({} if cursor is None else {"cursor": cursor}),
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()["data"]
    pagination = TotalPagination(total=data["total"], nextCursor=data["nextCursor"], hasMore=data["hasMore"])
    posts = list(map(Comment.model_validate, data["comments"]))

    return pagination, posts


async def vote(
        client: httpx.AsyncClient,
        access_token: str,
        post_id: UUID,
        option_ids: list[UUID],
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> Poll:
    """Проголосовать в опросе

    Args:
        client: httpx.AsyncClient
        access_token: access токен
        post_id: UUID поста
        option_ids: список UUID выбранных вариантов
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        NotFoundError: пост не найден
        ValidationError: Один или несколько вариантов не принадлежат этому опросу
        ValidationError: В этом опросе можно выбрать только один вариант
        ValidationError: len(option_ids) > 0

    """
    response = await post(
        client,
        f"https://{domain}/api/posts/{post_id}/poll/vote",
        json={"optionIds": list(map(str, option_ids))},
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()

    return Poll(**data)


async def create_post(
        client: httpx.AsyncClient,
        access_token: str,
        content: str = '',
        attachment_ids: list[UUID] | None = None,
        wall_recipient_id: UUID = None,
        multiple_choice: bool = False,
        question: str | None = None,
        options: list[str] | None = None,
        spans: list[Monospace | Strike | Underline | Bold | Italic | Spoiler | Link] | None = None,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> Post:
    """Создать пост.
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        content: Текст поста
        attachment_ids: Прикреплённые файлы
        wall_recipient_id: id пользователя
        multiple_choice: возможен ли множественный выбор в опросе
        question: заголовок опроса
        options: варианты ответов
        spans: форматирование текста
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        ValidationError: Нельзя создать пост content="", attachment_ids = [], question = None
        ParamsValidationError: len(content) <= 1_000
        VideoRequiresVerificationError: Загрузка видео доступна только верифицированным пользователям
        ValidationError: len(attachments_ids) <= 10
        ForbiddenError: Некоторые файлы из attachment_ids не существуют
        ParamsValidationError: len(spans) <= 100
        ValidationError: 1 <= len(question) <= 128
        ValidationError: 2 <= len(options) <= 10
        ValidationError: 1 <= len(options[i]) <= 32
        ParamsValidationError: span[i].offset >= 0
        ParamsValidationError: span[i].length > 0
        ParamsValidationError: len(span[i].url) <= 2048
    """
    if attachment_ids is None:
        attachment_ids = []

    if options is None:
        options = []

    json = {
        "content": content,
        "attachmentIds": list(map(str, attachment_ids))
    }
    if wall_recipient_id is not None:
        json["wallRecipientId"] = str(wall_recipient_id)

    if question is not None:
        poll = {
            'question': question,
            'multipleChoice': multiple_choice,
            'options': []
        }
        for option in options:
            poll["options"].append({"text": option})
        json['poll'] = poll

    if spans is not None:
        json['spans'] = [span.model_dump() for span in spans]

    response = await post(
        client,
        f"https://{domain}/api/posts",
        json=json,
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()

    data['author']['id'] = decode_jwt_payload(access_token)['sub']
    data['isViewed'] = False
    data['dominantEmoji'] = None
    data['editedAt'] = None
    data['originalPost'] = None

    return Post(**data)


async def update_post(
        client: httpx.AsyncClient,
        access_token: str,
        post_id: UUID,
        content: str,
        spans: list[Monospace | Strike | Underline | Bold | Italic | Spoiler | Link] | None = None,
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> UpdatePostResponse:
    """Изменить пост
    
    Args:
        client: httpx.AsyncClient
        access_token: access токен
        post_id: UUID поста
        content: Новый текст поста
        spans: форматированние текста
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        NotFoundError: Пост не найден
        ValidationError: 1 <= len(content) <= 1_000
        ForbiddenError: Нет прав для редактирования этого поста
        EditWindowExpiredError: пост нельзя изменять спустя несколько дней
        ParamsValidationError: span[i].offset >= 0
        ParamsValidationError: span[i].length > 0
        ParamsValidationError: len(span[i].url) <= 2048
    """
    if spans is None:
        spans = []
    response = await put(
        client,
        f"https://{domain}/api/posts/{post_id}",
        json={"content": content, 'spans': [span.model_dump() for span in spans]},
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()

    return UpdatePostResponse(**data)


async def repost(
        client: httpx.AsyncClient,
        access_token: str,
        post_id: UUID,
        content: str = "",
        domain: str = "xn--d1ah4a.com",
        **kwargs
) -> Post:
    """Репост.

    Args:
        client: httpx.AsyncClient
        access_token: access токен
        post_id: UUID поста
        content: текст репоста
        domain: домен

    Raises:
        UnauthorizedError: ошибка авторизации
        NotFoundError: Пост не найден
        ConflictError: Нельзя репостнуть два раза
        ValidationError: Нельзя репостить свои посты
        ValidationError: len(content) <= 1_000
    """
    response = await post(
        client,
        f"https://{domain}/api/posts/{post_id}/repost",
        json={"content": content},
        headers={"authorization": add_bearer(access_token)},
        **kwargs
    )
    data = response.json()
    data['author']['id'] = decode_jwt_payload(access_token)['sub']
    data['isViewed'] = False
    data['poll'] = None
    data['dominantEmoji'] = None
    data['editedAt'] = None
    data['wallRecipient'] = None

    return Post(**data)


__all__ = [
    'get_post', 'delete_post', 'restore_post', 'like_post', 'unlike_post', 'view_post', 'pin_post', 'unpin_post',
    'get_posts_by_user', 'get_posts_by_user_liked', 'get_posts_by_user_wall', 'get_posts', 'get_post_comments', 'vote',
    'create_post', 'update_post', 'repost', 'Tab', 'PostSort', 'CommentSort'
]
