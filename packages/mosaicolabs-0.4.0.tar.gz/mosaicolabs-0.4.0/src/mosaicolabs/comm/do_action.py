"""
Flight Action Dispatcher.

This module provides a type-safe wrapper (`_do_action`) for executing
PyArrow Flight `do_action` commands.

It employs a Registry Pattern (`_DoActionResponse` and subclasses) to map
specific `FlightAction` enums to concrete Data Classes. This ensures that
server responses are automatically deserialized into the correct Python objects,
providing stronger typing and validation than raw dictionaries.
"""

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, ClassVar, Dict, Optional, Type, TypeVar

import pyarrow.flight as fl

from mosaicolabs.comm.notifications import Notification

from ..enum import FlightAction
from ..logging_config import get_logger
from ..models.query import QueryResponse, QueryResponseItem

# Set the hierarchical logger
logger = get_logger(__name__)

# Generic TypeVar allowing _do_action to return the specific subclass requested
T_DoActionResponse = TypeVar("T_DoActionResponse", bound="_DoActionResponse")


class _DoActionResponse(ABC):
    """
    Abstract base class for Flight Action responses.

    This class handles the automatic registration of subclasses. When a subclass
    is defined with a list of `actions`, it is automatically added to the `_registry`.
    """

    # Registry mapping FlightAction -> Subclass Type
    _registry: ClassVar[Dict[FlightAction, Type["_DoActionResponse"]]] = {}

    # Subclasses must define which actions they handle
    actions: ClassVar[list[FlightAction]] = []

    def __init_subclass__(cls, **kwargs):
        """
        Metaclass hook to register subclasses automatically.
        """
        super().__init_subclass__(**kwargs)
        for action in getattr(cls, "actions", []):
            _DoActionResponse._registry[action] = cls

    @classmethod
    def get_class_for_action(cls, action: FlightAction) -> Type["_DoActionResponse"]:
        """
        Retrieves the registered response class for a given action.

        Args:
            action (FlightAction): The action being performed.

        Returns:
            Type[_DoActionResponse]: The class responsible for handling the response.

        Raises:
            KeyError: If no class is registered for the action.
        """
        if action not in cls._registry:
            raise KeyError(f"No subclass registered for action '{action}'")
        return cls._registry[action]

    @classmethod
    @abstractmethod
    def from_dict(
        cls: Type[T_DoActionResponse], data: Dict[str, Any]
    ) -> T_DoActionResponse:
        """
        Abstract method to deserialize a dictionary into an instance.

        Args:
            data (Dict[str, Any]): The raw dictionary from the server response.

        Returns:
            T_DoActionResponse: An instance of the class.
        """
        pass


def _do_action(
    client: fl.FlightClient,
    action: FlightAction,
    payload: dict[str, Any],
    expected_type: Optional[Type[T_DoActionResponse]],
) -> Optional[T_DoActionResponse]:
    """
    Executes a Flight `do_action` command and deserializes the response.

    Args:
        client (fl.FlightClient): The connected Flight client.
        action (FlightAction): The specific action to execute.
        payload (dict[str, Any]): The parameters for the action (serialized to JSON).
        expected_type (Optional[Type]): The expected response class. If provided,
                                        the result is checked against this type.

    Returns:
        Optional[T_DoActionResponse]: The deserialized response object, or None
                                      if the server returned no body.

    Raises:
        TypeError: If the registered response class does not match `expected_type`.
        Exception: For Flight errors or JSON decoding failures.
    """
    action_name = action.value
    logger.debug(f"Sending Flight action: '{action_name}'")

    try:
        # Serialize payload
        body = json.dumps(payload).encode("utf-8")
        logger.debug(f"Action request body: '{body}'")

        # Execute Flight call
        action_results = client.do_action(fl.Action(action_name, body))

        # Process the result stream (usually contains 0 or 1 item)
        # Accumulate bytes in a list
        # (much faster than repeatedly concatenating immutable bytes objects)
        chunks: list[bytes] = []

        for result in action_results:
            if result.body:
                # result.body is a PyArrow Buffer; to_pybytes() is zero-copy or low-overhead
                chunks.append(result.body.to_pybytes())

        # If no data was received
        if not chunks:
            return None

        # Join all chunks into one contiguous byte sequence
        full_response_bytes = b"".join(chunks)

        # Decode and Parse exactly once
        result_str = full_response_bytes.decode("utf-8")
        result_dict: dict[str, Any] = json.loads(result_str)

        # --- Validation ---
        # Verify the server is responding to the correct action
        returned_action = result_dict.get("action")
        if returned_action is None or returned_action == "empty":
            logger.debug(f"Action '{action_name}' response had no 'action' field.")
            return None

        if returned_action != action_name:
            logger.warning(
                f"Unexpected action in response: got '{result_dict.get('action')}', expected '{action_name}'"
            )
            return None

        response_data = result_dict.get("response")
        if response_data is None:
            logger.debug(f"Action '{action_name}' response had no 'response' field.")
            return None

        # --- Deserialization ---
        if expected_type is not None:
            # Ensure the registered class matches what the caller expects
            response_cls = _DoActionResponse.get_class_for_action(action)
            if response_cls is not expected_type:
                raise TypeError(
                    f"Action '{action_name}' returned an unexpected type. "
                    f"Got '{response_cls.__name__}', but expected '{expected_type.__name__}'"
                )
            # Parse data
            return expected_type.from_dict(response_data)
        else:
            # Caller didn't ask for a specific type (or return value might be raw)
            return response_data

    except Exception as e:
        logger.exception(f"Flight action '{action_name}' failed: '{e}'")
        raise e


# --- Concrete Response Dataclasses ---


@dataclass
class _DoActionResponseUUID(_DoActionResponse):
    """Response containing a generated resource key (e.g., after creation)."""

    actions: ClassVar[list[FlightAction]] = [
        FlightAction.SESSION_CREATE,
        FlightAction.TOPIC_CREATE,
    ]
    uuid: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "_DoActionResponseUUID":
        return cls(**data)


@dataclass
class _DoActionQueryResponse(_DoActionResponse):
    """Response containing the result of a query to data platform"""

    actions: ClassVar[list[FlightAction]] = [FlightAction.QUERY]
    query_response: QueryResponse

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "_DoActionQueryResponse":
        items = data.get("items")
        if items is None:
            raise KeyError("Unable to find 'items' key in data dict.")
        qresp = QueryResponse(
            items=[QueryResponseItem._from_dict(ditem) for ditem in data["items"]]
        )
        return _DoActionQueryResponse(query_response=qresp)


@dataclass
class _DoActionNotificationList(_DoActionResponse):
    """Response containing a list."""

    actions: ClassVar[list[FlightAction]] = [
        FlightAction.SEQUENCE_NOTIFICATION_LIST,
        FlightAction.TOPIC_NOTIFICATION_LIST,
    ]
    notifications: list[Notification]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "_DoActionNotificationList":
        notifications: Optional[list] = data.get("notifications")
        if notifications is None:
            raise KeyError("Unable to find 'notifications' key in data dict.")
        return _DoActionNotificationList(
            notifications=[
                Notification._from_dict(notification) for notification in notifications
            ]
        )


@dataclass
class _DoActionResponseAPIKeyCreate(_DoActionResponse):
    """Response returned after creating a new API key.

    This action generates a new API key token with the requested permissions.

    Attributes:
        api_key_token (str): The plaintext API key returned by the server.
    """

    actions: ClassVar[list[FlightAction]] = [FlightAction.API_KEY_CREATE]
    api_key_token: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "_DoActionResponseAPIKeyCreate":
        return cls(api_key_token=data["api_key_token"])


@dataclass
class _DoActionResponseAPIKeyStatus(_DoActionResponse):
    """Response containing the status and metadata of an existing API key.

    Attributes:
        api_key_fingerprint (str): Unique identifier of the key.
        created_at_ns (int): Creation timestamp in nanoseconds since epoch.
        expires_at_ns (int): Expiration timestamp in nanoseconds since epoch.
        description (str): Optional description provided at key creation.
    """

    actions: ClassVar[list[FlightAction]] = [FlightAction.API_KEY_STATUS]
    api_key_fingerprint: str
    created_at_ns: int
    expires_at_ns: Optional[int]
    description: Optional[str]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "_DoActionResponseAPIKeyStatus":
        return cls(
            api_key_fingerprint=data["api_key_fingerprint"],
            created_at_ns=data["created_at_ns"],
            expires_at_ns=data.get("expires_at_ns"),
            description=data.get("description"),
        )
