from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.agent_version_state import AgentVersionState
from ..types import UNSET, Unset

T = TypeVar("T", bound="AgentVersionHistoryEntry")


@_attrs_define
class AgentVersionHistoryEntry:
    """
    Attributes:
        agent_version_id (UUID): Version ID
        version_number (int): Version number (v1, v2, etc.)
        submitted_at (datetime.datetime): Submission timestamp
        state (AgentVersionState): State of an agent version evaluation.
        final_score (float | None | Unset): Final score if eligible
    """

    agent_version_id: UUID
    version_number: int
    submitted_at: datetime.datetime
    state: AgentVersionState
    final_score: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version_id = str(self.agent_version_id)

        version_number = self.version_number

        submitted_at = self.submitted_at.isoformat()

        state = self.state.value

        final_score: float | None | Unset
        if isinstance(self.final_score, Unset):
            final_score = UNSET
        else:
            final_score = self.final_score

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "version_number": version_number,
                "submitted_at": submitted_at,
                "state": state,
            }
        )
        if final_score is not UNSET:
            field_dict["final_score"] = final_score

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        version_number = d.pop("version_number")

        submitted_at = isoparse(d.pop("submitted_at"))

        state = AgentVersionState(d.pop("state"))

        def _parse_final_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        final_score = _parse_final_score(d.pop("final_score", UNSET))

        agent_version_history_entry = cls(
            agent_version_id=agent_version_id,
            version_number=version_number,
            submitted_at=submitted_at,
            state=state,
            final_score=final_score,
        )

        agent_version_history_entry.additional_properties = d
        return agent_version_history_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
