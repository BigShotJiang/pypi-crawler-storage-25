from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_version_score_entry import AgentVersionScoreEntry


T = TypeVar("T", bound="AgentVersionVariance")


@_attrs_define
class AgentVersionVariance:
    """
    Attributes:
        agent_version_id (UUID): Agent version ID
        agent_name (str): Agent name
        miner_hotkey (str): Owner's hotkey
        validator_count (int): Number of validators that scored this version
        avg_score (float): Average score across validators
        min_score (float): Minimum validator score
        max_score (float): Maximum validator score
        spread (float): Spread between min and max scores
        is_high_variance (bool): Whether the variance exceeds the threshold
        per_validator (list[AgentVersionScoreEntry] | Unset): Per-validator score breakdown
    """

    agent_version_id: UUID
    agent_name: str
    miner_hotkey: str
    validator_count: int
    avg_score: float
    min_score: float
    max_score: float
    spread: float
    is_high_variance: bool
    per_validator: list[AgentVersionScoreEntry] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version_id = str(self.agent_version_id)

        agent_name = self.agent_name

        miner_hotkey = self.miner_hotkey

        validator_count = self.validator_count

        avg_score = self.avg_score

        min_score = self.min_score

        max_score = self.max_score

        spread = self.spread

        is_high_variance = self.is_high_variance

        per_validator: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.per_validator, Unset):
            per_validator = []
            for per_validator_item_data in self.per_validator:
                per_validator_item = per_validator_item_data.to_dict()
                per_validator.append(per_validator_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "agent_name": agent_name,
                "miner_hotkey": miner_hotkey,
                "validator_count": validator_count,
                "avg_score": avg_score,
                "min_score": min_score,
                "max_score": max_score,
                "spread": spread,
                "is_high_variance": is_high_variance,
            }
        )
        if per_validator is not UNSET:
            field_dict["per_validator"] = per_validator

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_version_score_entry import AgentVersionScoreEntry

        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        agent_name = d.pop("agent_name")

        miner_hotkey = d.pop("miner_hotkey")

        validator_count = d.pop("validator_count")

        avg_score = d.pop("avg_score")

        min_score = d.pop("min_score")

        max_score = d.pop("max_score")

        spread = d.pop("spread")

        is_high_variance = d.pop("is_high_variance")

        _per_validator = d.pop("per_validator", UNSET)
        per_validator: list[AgentVersionScoreEntry] | Unset = UNSET
        if _per_validator is not UNSET:
            per_validator = []
            for per_validator_item_data in _per_validator:
                per_validator_item = AgentVersionScoreEntry.from_dict(per_validator_item_data)

                per_validator.append(per_validator_item)

        agent_version_variance = cls(
            agent_version_id=agent_version_id,
            agent_name=agent_name,
            miner_hotkey=miner_hotkey,
            validator_count=validator_count,
            avg_score=avg_score,
            min_score=min_score,
            max_score=max_score,
            spread=spread,
            is_high_variance=is_high_variance,
            per_validator=per_validator,
        )

        agent_version_variance.additional_properties = d
        return agent_version_variance

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
