from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.problem_status import ProblemStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.validator_problem_result_score_components_type_0 import ValidatorProblemResultScoreComponentsType0


T = TypeVar("T", bound="ValidatorProblemResult")


@_attrs_define
class ValidatorProblemResult:
    """
    Attributes:
        eval_run_id (UUID): Evaluation run ID this result belongs to
        validator_hotkey (str): Validator hotkey
        status (ProblemStatus):
        score (float | None | Unset): Problem score from this validator
        score_components (None | Unset | ValidatorProblemResultScoreComponentsType0): Score breakdown from this
            validator
        reasoning_score (float | None | Unset): Reasoning quality score from LLM judge
        updated_at (datetime.datetime | None | Unset): Last update from this validator
        inference_failure_count (int | None | Unset): Number of failed inference calls for this problem
        inference_total (int | None | Unset): Total number of inference calls for this problem
    """

    eval_run_id: UUID
    validator_hotkey: str
    status: ProblemStatus
    score: float | None | Unset = UNSET
    score_components: None | Unset | ValidatorProblemResultScoreComponentsType0 = UNSET
    reasoning_score: float | None | Unset = UNSET
    updated_at: datetime.datetime | None | Unset = UNSET
    inference_failure_count: int | None | Unset = UNSET
    inference_total: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.validator_problem_result_score_components_type_0 import ValidatorProblemResultScoreComponentsType0

        eval_run_id = str(self.eval_run_id)

        validator_hotkey = self.validator_hotkey

        status = self.status.value

        score: float | None | Unset
        if isinstance(self.score, Unset):
            score = UNSET
        else:
            score = self.score

        score_components: dict[str, Any] | None | Unset
        if isinstance(self.score_components, Unset):
            score_components = UNSET
        elif isinstance(self.score_components, ValidatorProblemResultScoreComponentsType0):
            score_components = self.score_components.to_dict()
        else:
            score_components = self.score_components

        reasoning_score: float | None | Unset
        if isinstance(self.reasoning_score, Unset):
            reasoning_score = UNSET
        else:
            reasoning_score = self.reasoning_score

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        elif isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        inference_failure_count: int | None | Unset
        if isinstance(self.inference_failure_count, Unset):
            inference_failure_count = UNSET
        else:
            inference_failure_count = self.inference_failure_count

        inference_total: int | None | Unset
        if isinstance(self.inference_total, Unset):
            inference_total = UNSET
        else:
            inference_total = self.inference_total

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "eval_run_id": eval_run_id,
                "validator_hotkey": validator_hotkey,
                "status": status,
            }
        )
        if score is not UNSET:
            field_dict["score"] = score
        if score_components is not UNSET:
            field_dict["score_components"] = score_components
        if reasoning_score is not UNSET:
            field_dict["reasoning_score"] = reasoning_score
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at
        if inference_failure_count is not UNSET:
            field_dict["inference_failure_count"] = inference_failure_count
        if inference_total is not UNSET:
            field_dict["inference_total"] = inference_total

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.validator_problem_result_score_components_type_0 import ValidatorProblemResultScoreComponentsType0

        d = dict(src_dict)
        eval_run_id = UUID(d.pop("eval_run_id"))

        validator_hotkey = d.pop("validator_hotkey")

        status = ProblemStatus(d.pop("status"))

        def _parse_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        score = _parse_score(d.pop("score", UNSET))

        def _parse_score_components(data: object) -> None | Unset | ValidatorProblemResultScoreComponentsType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                score_components_type_0 = ValidatorProblemResultScoreComponentsType0.from_dict(data)

                return score_components_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | ValidatorProblemResultScoreComponentsType0, data)

        score_components = _parse_score_components(d.pop("score_components", UNSET))

        def _parse_reasoning_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        reasoning_score = _parse_reasoning_score(d.pop("reasoning_score", UNSET))

        def _parse_updated_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = isoparse(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        updated_at = _parse_updated_at(d.pop("updated_at", UNSET))

        def _parse_inference_failure_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        inference_failure_count = _parse_inference_failure_count(d.pop("inference_failure_count", UNSET))

        def _parse_inference_total(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        inference_total = _parse_inference_total(d.pop("inference_total", UNSET))

        validator_problem_result = cls(
            eval_run_id=eval_run_id,
            validator_hotkey=validator_hotkey,
            status=status,
            score=score,
            score_components=score_components,
            reasoning_score=reasoning_score,
            updated_at=updated_at,
            inference_failure_count=inference_failure_count,
            inference_total=inference_total,
        )

        validator_problem_result.additional_properties = d
        return validator_problem_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
