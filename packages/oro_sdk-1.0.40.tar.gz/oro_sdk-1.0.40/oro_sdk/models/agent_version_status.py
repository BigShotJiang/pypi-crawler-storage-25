from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.agent_version_state import AgentVersionState
from ..models.artifact_release_state import ArtifactReleaseState
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_version_status_per_validator_success_scores_type_0 import (
        AgentVersionStatusPerValidatorSuccessScoresType0,
    )


T = TypeVar("T", bound="AgentVersionStatus")


@_attrs_define
class AgentVersionStatus:
    """
    Attributes:
        agent_version_id (UUID): Unique identifier for this version
        agent_name (str): Agent name
        miner_hotkey (str): Owner's hotkey
        version_number (int): Version number within this agent (v1, v2, etc.)
        submitted_at (datetime.datetime): Submission timestamp
        state (AgentVersionState): State of an agent version evaluation.
        suite_id (int | None | Unset): Suite ID
        required_successes (int | Unset): Required successful evaluations Default: 1.
        success_count (int | Unset): Number of successful evaluations Default: 0.
        active_count (int | Unset): Number of active evaluations Default: 0.
        is_closed (bool | Unset): Whether evaluation is closed Default: False.
        final_score (float | None | Unset): Qualifying score if eligible
        race_score (float | None | Unset): Race score
        reasoning_coefficient (float | None | Unset): Average reasoning coefficient from included successful runs
        release_state (ArtifactReleaseState | Unset): Release state of agent version artifacts.
        code_available_at (datetime.datetime | None | Unset): When agent code becomes available for download
            (eligible_at + 24h)
        per_validator_success_scores (AgentVersionStatusPerValidatorSuccessScoresType0 | None | Unset): Per-validator
            scores on success
    """

    agent_version_id: UUID
    agent_name: str
    miner_hotkey: str
    version_number: int
    submitted_at: datetime.datetime
    state: AgentVersionState
    suite_id: int | None | Unset = UNSET
    required_successes: int | Unset = 1
    success_count: int | Unset = 0
    active_count: int | Unset = 0
    is_closed: bool | Unset = False
    final_score: float | None | Unset = UNSET
    race_score: float | None | Unset = UNSET
    reasoning_coefficient: float | None | Unset = UNSET
    release_state: ArtifactReleaseState | Unset = UNSET
    code_available_at: datetime.datetime | None | Unset = UNSET
    per_validator_success_scores: AgentVersionStatusPerValidatorSuccessScoresType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.agent_version_status_per_validator_success_scores_type_0 import (
            AgentVersionStatusPerValidatorSuccessScoresType0,
        )

        agent_version_id = str(self.agent_version_id)

        agent_name = self.agent_name

        miner_hotkey = self.miner_hotkey

        version_number = self.version_number

        submitted_at = self.submitted_at.isoformat()

        state = self.state.value

        suite_id: int | None | Unset
        if isinstance(self.suite_id, Unset):
            suite_id = UNSET
        else:
            suite_id = self.suite_id

        required_successes = self.required_successes

        success_count = self.success_count

        active_count = self.active_count

        is_closed = self.is_closed

        final_score: float | None | Unset
        if isinstance(self.final_score, Unset):
            final_score = UNSET
        else:
            final_score = self.final_score

        race_score: float | None | Unset
        if isinstance(self.race_score, Unset):
            race_score = UNSET
        else:
            race_score = self.race_score

        reasoning_coefficient: float | None | Unset
        if isinstance(self.reasoning_coefficient, Unset):
            reasoning_coefficient = UNSET
        else:
            reasoning_coefficient = self.reasoning_coefficient

        release_state: str | Unset = UNSET
        if not isinstance(self.release_state, Unset):
            release_state = self.release_state.value

        code_available_at: None | str | Unset
        if isinstance(self.code_available_at, Unset):
            code_available_at = UNSET
        elif isinstance(self.code_available_at, datetime.datetime):
            code_available_at = self.code_available_at.isoformat()
        else:
            code_available_at = self.code_available_at

        per_validator_success_scores: dict[str, Any] | None | Unset
        if isinstance(self.per_validator_success_scores, Unset):
            per_validator_success_scores = UNSET
        elif isinstance(self.per_validator_success_scores, AgentVersionStatusPerValidatorSuccessScoresType0):
            per_validator_success_scores = self.per_validator_success_scores.to_dict()
        else:
            per_validator_success_scores = self.per_validator_success_scores

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "agent_name": agent_name,
                "miner_hotkey": miner_hotkey,
                "version_number": version_number,
                "submitted_at": submitted_at,
                "state": state,
            }
        )
        if suite_id is not UNSET:
            field_dict["suite_id"] = suite_id
        if required_successes is not UNSET:
            field_dict["required_successes"] = required_successes
        if success_count is not UNSET:
            field_dict["success_count"] = success_count
        if active_count is not UNSET:
            field_dict["active_count"] = active_count
        if is_closed is not UNSET:
            field_dict["is_closed"] = is_closed
        if final_score is not UNSET:
            field_dict["final_score"] = final_score
        if race_score is not UNSET:
            field_dict["race_score"] = race_score
        if reasoning_coefficient is not UNSET:
            field_dict["reasoning_coefficient"] = reasoning_coefficient
        if release_state is not UNSET:
            field_dict["release_state"] = release_state
        if code_available_at is not UNSET:
            field_dict["code_available_at"] = code_available_at
        if per_validator_success_scores is not UNSET:
            field_dict["per_validator_success_scores"] = per_validator_success_scores

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_version_status_per_validator_success_scores_type_0 import (
            AgentVersionStatusPerValidatorSuccessScoresType0,
        )

        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        agent_name = d.pop("agent_name")

        miner_hotkey = d.pop("miner_hotkey")

        version_number = d.pop("version_number")

        submitted_at = isoparse(d.pop("submitted_at"))

        state = AgentVersionState(d.pop("state"))

        def _parse_suite_id(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        suite_id = _parse_suite_id(d.pop("suite_id", UNSET))

        required_successes = d.pop("required_successes", UNSET)

        success_count = d.pop("success_count", UNSET)

        active_count = d.pop("active_count", UNSET)

        is_closed = d.pop("is_closed", UNSET)

        def _parse_final_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        final_score = _parse_final_score(d.pop("final_score", UNSET))

        def _parse_race_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        race_score = _parse_race_score(d.pop("race_score", UNSET))

        def _parse_reasoning_coefficient(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        reasoning_coefficient = _parse_reasoning_coefficient(d.pop("reasoning_coefficient", UNSET))

        _release_state = d.pop("release_state", UNSET)
        release_state: ArtifactReleaseState | Unset
        if isinstance(_release_state, Unset):
            release_state = UNSET
        else:
            release_state = ArtifactReleaseState(_release_state)

        def _parse_code_available_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                code_available_at_type_0 = isoparse(data)

                return code_available_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        code_available_at = _parse_code_available_at(d.pop("code_available_at", UNSET))

        def _parse_per_validator_success_scores(
            data: object,
        ) -> AgentVersionStatusPerValidatorSuccessScoresType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                per_validator_success_scores_type_0 = AgentVersionStatusPerValidatorSuccessScoresType0.from_dict(data)

                return per_validator_success_scores_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AgentVersionStatusPerValidatorSuccessScoresType0 | None | Unset, data)

        per_validator_success_scores = _parse_per_validator_success_scores(d.pop("per_validator_success_scores", UNSET))

        agent_version_status = cls(
            agent_version_id=agent_version_id,
            agent_name=agent_name,
            miner_hotkey=miner_hotkey,
            version_number=version_number,
            submitted_at=submitted_at,
            state=state,
            suite_id=suite_id,
            required_successes=required_successes,
            success_count=success_count,
            active_count=active_count,
            is_closed=is_closed,
            final_score=final_score,
            race_score=race_score,
            reasoning_coefficient=reasoning_coefficient,
            release_state=release_state,
            code_available_at=code_available_at,
            per_validator_success_scores=per_validator_success_scores,
        )

        agent_version_status.additional_properties = d
        return agent_version_status

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
