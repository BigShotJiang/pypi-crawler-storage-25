"""Managing app functionality."""
