"""The root package of Eventum SDK."""

__version__ = '2.4.0'
