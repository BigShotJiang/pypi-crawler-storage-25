import{o}from"./index-Bf7U3MlX.js";/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M7 6a7.75 7.75 0 1 0 10 0",key:"svg-0"}],["path",{d:"M12 4l0 8",key:"svg-1"}]],a=o("outline","power","Power",e);export{a as I};
