
from litellm.router import Router
from litellm import ModelResponse, Choices, Message
from llm.prompt import SYSTEM_PROMPT
class llm:

    def __init__(self,model_param: list):
        model_list = [
            {
                "model_name": "a",
                "litellm_params": param
            } for param in model_param
        ]

        self.router = Router(model_list)

    async def explain(self, content):
        res = await self.router.acompletion(
            model="a",
            messages=[
                {
                    "role":"system",
                    "content": SYSTEM_PROMPT
                },
                {
                    "role": "user",
                    "content": content
                }
            ],
            temperature = 0.3,
            max_tokens = 12000  # 增加 token 限制
        )

        result_str = "No valid response from AI"
        if isinstance(res, ModelResponse):
            if isinstance(res.choices, list) and res.choices:
                fc = res.choices[0]

                if (
                    isinstance(fc, Choices)
                    and isinstance(fc.message, Message)
                    and isinstance(fc.message.content, str)
                ):
                    result_str = fc.message.content

        return result_str