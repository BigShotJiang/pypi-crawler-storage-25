# langchain-agent-trust-stack

LangChain and CrewAI tools for the [Agent Trust Stack](https://vibeagentmaking.com) — cryptographic provenance logging and decentralized reputation scoring for autonomous AI agents.

## Install

```bash
pip install langchain-agent-trust-stack
```

## Quick Start — LangChain

```python
from langchain_agent_trust_stack import all_tools
from langchain_openai import ChatOpenAI
from langchain.agents import initialize_agent, AgentType

llm = ChatOpenAI(model="gpt-4")
agent = initialize_agent(all_tools, llm, agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION)

# Agent can now create provenance chains and rate other agents
agent.run("Initialize a new chain of consciousness for agent 'my-bot'")
agent.run("Log a learning event: discovered new API endpoint for weather data")
agent.run("Rate agent 'helper-bot' with score 0.8 for reliable data retrieval")
agent.run("Check the reputation of agent 'helper-bot'")
```

## Quick Start — CrewAI

```python
from langchain_agent_trust_stack import coc_tools, arp_tools
from crewai import Agent, Task, Crew

researcher = Agent(
    role="Research Agent",
    goal="Research and log findings with provenance",
    tools=coc_tools + arp_tools,
)
```

## Available Tools

### Chain of Consciousness (CoC)
| Tool | Description |
|------|-------------|
| `coc_init` | Initialize a new hash chain with a genesis block |
| `coc_add` | Add a cryptographically linked entry to the chain |
| `coc_verify` | Verify chain integrity (hash linkage, sequences) |
| `coc_status` | Get chain statistics (length, agents, event types) |
| `coc_tail` | Get the last N entries |

### Agent Rating Protocol (ARP)
| Tool | Description |
|------|-------------|
| `arp_rate` | Submit a blind rating for another agent (-1.0 to 1.0) |
| `arp_check` | Check an agent's reputation score |

### Info
| Tool | Description |
|------|-------------|
| `trust_stack_info` | Get info about all 7 Agent Trust Stack protocols |

## Configuration

Set environment variables to customize storage locations:

```bash
export COC_CHAIN_DIR=/path/to/chain    # default: ./chain
export ARP_RATINGS_DIR=/path/to/ratings # default: ./ratings
```

## Part of the Agent Trust Stack

7-protocol infrastructure for autonomous AI agent trust:

1. **Chain of Consciousness (CoC)** — Tamper-evident provenance logging with Bitcoin OpenTimestamps
2. **Agent Rating Protocol (ARP)** — Bilateral blind reputation scoring
3. **Agent Justice Protocol (AJP)** — Dispute resolution
4. **Agent Service Agreements (ASA)** — Machine-readable contracts
5. **Agent Lifecycle Protocol (ALP)** — Identity management
6. **Agent Matchmaking Protocol (AMP)** — Discovery and matching
7. **Context Window Economics (CWE)** — Token-cost accounting

## Links

- [Website](https://vibeagentmaking.com)
- [MCP Server](https://smithery.ai/server/@alexfleetcommander/agent-trust-stack-mcp)
- [GitHub](https://github.com/alexfleetcommander/agent-trust-stack-mcp)
- [PyPI](https://pypi.org/project/agent-trust-stack-mcp/)

## License

Apache-2.0
