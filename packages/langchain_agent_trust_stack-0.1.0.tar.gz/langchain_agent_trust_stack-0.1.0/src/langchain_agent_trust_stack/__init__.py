"""LangChain + CrewAI tools for the Agent Trust Stack.

Provides Chain of Consciousness (CoC) provenance logging and Agent Rating
Protocol (ARP) reputation scoring as LangChain-compatible tools that any
LangChain or CrewAI agent can use natively.

Install:
    pip install langchain-agent-trust-stack

Quick start:
    from langchain_agent_trust_stack import coc_tools, arp_tools
    agent = initialize_agent(coc_tools + arp_tools, llm)
"""

from langchain_agent_trust_stack.tools import (
    CocInitTool,
    CocAddTool,
    CocVerifyTool,
    CocStatusTool,
    CocTailTool,
    ArpRateTool,
    ArpCheckTool,
    TrustStackInfoTool,
    coc_tools,
    arp_tools,
    all_tools,
)

__version__ = "0.1.0"
__all__ = [
    "CocInitTool",
    "CocAddTool",
    "CocVerifyTool",
    "CocStatusTool",
    "CocTailTool",
    "ArpRateTool",
    "ArpCheckTool",
    "TrustStackInfoTool",
    "coc_tools",
    "arp_tools",
    "all_tools",
]
