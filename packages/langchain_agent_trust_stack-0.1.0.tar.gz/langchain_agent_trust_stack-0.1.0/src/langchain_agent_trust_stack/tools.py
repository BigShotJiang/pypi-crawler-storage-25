"""LangChain tool wrappers for Chain of Consciousness and Agent Rating Protocol.

Each tool wraps the corresponding function from the agent-trust-stack-mcp
package, making them available to any LangChain or CrewAI agent.

Works with both local chains (pip install chain-of-consciousness) and the
hosted MCP server (pip install agent-trust-stack-mcp).
"""

import hashlib
import json
import os
from datetime import datetime, timezone
from typing import Optional

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

# ── Configuration ──

CHAIN_DIR = os.environ.get("COC_CHAIN_DIR", os.path.join(os.getcwd(), "chain"))
CHAIN_FILE = os.path.join(CHAIN_DIR, "chain.jsonl")
RATINGS_DIR = os.environ.get("ARP_RATINGS_DIR", os.path.join(os.getcwd(), "ratings"))
SCHEMA_VERSION = "1.1"

VALID_EVENT_TYPES = [
    "genesis", "boot", "learn", "decide", "create",
    "milestone", "rotate", "anchor", "error", "note",
    "session_start", "session_end", "compaction", "governance",
]

# ── Helpers ──


def _sha256(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _read_chain() -> list:
    if not os.path.exists(CHAIN_FILE):
        return []
    entries = []
    with open(CHAIN_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                entries.append(json.loads(line))
    return entries


def _append_entry(entry: dict) -> None:
    os.makedirs(CHAIN_DIR, exist_ok=True)
    with open(CHAIN_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, separators=(",", ":")) + "\n")


def _make_entry(seq, event_type, data, prev_hash, agent="anonymous"):
    ts = datetime.now(timezone.utc).isoformat()
    data_hash = _sha256(data)
    payload = f"{seq}|{ts}|{event_type}|{agent}|{data_hash}|{prev_hash}"
    entry_hash = _sha256(payload)
    return {
        "seq": seq, "ts": ts, "type": event_type, "agent": agent,
        "data": data, "data_hash": data_hash, "prev_hash": prev_hash,
        "entry_hash": entry_hash, "schema_version": SCHEMA_VERSION,
    }


def _ratings_file(agent_id: str) -> str:
    safe = "".join(c if c.isalnum() or c in "-_." else "_" for c in agent_id)
    return os.path.join(RATINGS_DIR, f"{safe}.jsonl")


# ── Input Schemas ──


class CocInitInput(BaseModel):
    agent: str = Field(default="anonymous", description="Name/ID of the agent initializing the chain")


class CocAddInput(BaseModel):
    event_type: str = Field(description="Event type: learn, decide, create, error, note, milestone, boot, session_start, session_end, rotate, anchor, compaction, governance")
    data: str = Field(description="Description of what happened")
    agent: str = Field(default="anonymous", description="Name/ID of the agent")


class CocTailInput(BaseModel):
    n: int = Field(default=5, description="Number of entries to return")


class ArpRateInput(BaseModel):
    rater: str = Field(description="ID of the rating agent")
    ratee: str = Field(description="ID of the agent being rated")
    score: float = Field(description="Score from -1.0 (harmful) to 1.0 (excellent)")
    context: str = Field(description="Brief context for the rating")


class ArpCheckInput(BaseModel):
    agent_id: str = Field(description="ID of the agent to look up")


# ── Tools ──


class CocInitTool(BaseTool):
    name: str = "coc_init"
    description: str = "Initialize a new Chain of Consciousness hash chain. Creates a genesis block — the first entry in a tamper-evident, append-only provenance log proving agent existence."
    args_schema: type[BaseModel] = CocInitInput

    def _run(self, agent: str = "anonymous") -> str:
        chain = _read_chain()
        if chain:
            return json.dumps({"error": f"Chain exists with {len(chain)} entries. Use coc_add."})
        data = f"GENESIS BLOCK — Agent: {agent}. Initialized: {datetime.now(timezone.utc).isoformat()}."
        entry = _make_entry(0, "genesis", data, "0" * 64, agent)
        _append_entry(entry)
        return json.dumps({"status": "chain_initialized", "sequence": 0, "entry_hash": entry["entry_hash"]})


class CocAddTool(BaseTool):
    name: str = "coc_add"
    description: str = "Add an entry to the Chain of Consciousness. Each entry is cryptographically linked to the previous via SHA-256, creating a tamper-evident log."
    args_schema: type[BaseModel] = CocAddInput

    def _run(self, event_type: str, data: str, agent: str = "anonymous") -> str:
        if event_type not in VALID_EVENT_TYPES:
            return json.dumps({"error": f"Invalid event_type '{event_type}'", "valid_types": VALID_EVENT_TYPES})
        chain = _read_chain()
        if not chain:
            return json.dumps({"error": "Chain not initialized. Call coc_init first."})
        prev = chain[-1]
        entry = _make_entry(prev["seq"] + 1, event_type, data, prev["entry_hash"], agent)
        _append_entry(entry)
        return json.dumps({"status": "entry_added", "sequence": entry["seq"], "entry_hash": entry["entry_hash"], "chain_length": len(chain) + 1})


class CocVerifyTool(BaseTool):
    name: str = "coc_verify"
    description: str = "Verify the integrity of a Chain of Consciousness chain. Checks hash linkage, sequence numbering, and data integrity."

    def _run(self) -> str:
        chain = _read_chain()
        if not chain:
            return json.dumps({"error": "Chain is empty"})
        for i, e in enumerate(chain):
            if e["seq"] != i:
                return json.dumps({"is_valid": False, "error": f"Entry {i}: sequence mismatch"})
            if e["data_hash"] != _sha256(e["data"]):
                return json.dumps({"is_valid": False, "error": f"Entry {i}: data_hash mismatch"})
            if i > 0 and e["prev_hash"] != chain[i - 1]["entry_hash"]:
                return json.dumps({"is_valid": False, "error": f"Entry {i}: prev_hash broken"})
            payload = f"{e['seq']}|{e['ts']}|{e['type']}|{e['agent']}|{e['data_hash']}|{e['prev_hash']}"
            if e["entry_hash"] != _sha256(payload):
                return json.dumps({"is_valid": False, "error": f"Entry {i}: entry_hash mismatch"})
        types = {}
        agents = {}
        for e in chain:
            types[e["type"]] = types.get(e["type"], 0) + 1
            agents[e["agent"]] = agents.get(e["agent"], 0) + 1
        return json.dumps({"is_valid": True, "entry_count": len(chain), "genesis_ts": chain[0]["ts"], "latest_ts": chain[-1]["ts"], "types": types, "agents": agents})


class CocStatusTool(BaseTool):
    name: str = "coc_status"
    description: str = "Get statistics about the current chain: length, agents, time span, event types."

    def _run(self) -> str:
        chain = _read_chain()
        if not chain:
            return json.dumps({"error": "No chain. Call coc_init first."})
        types = {}
        agents = {}
        for e in chain:
            types[e["type"]] = types.get(e["type"], 0) + 1
            agents[e["agent"]] = agents.get(e["agent"], 0) + 1
        return json.dumps({"chain_length": len(chain), "genesis_ts": chain[0]["ts"], "latest_ts": chain[-1]["ts"], "latest_hash": chain[-1]["entry_hash"], "types": types, "agents": agents})


class CocTailTool(BaseTool):
    name: str = "coc_tail"
    description: str = "Get the last N entries from the chain."
    args_schema: type[BaseModel] = CocTailInput

    def _run(self, n: int = 5) -> str:
        chain = _read_chain()
        if not chain:
            return json.dumps({"error": "No chain. Call coc_init first."})
        tail = chain[-n:]
        entries = [{"seq": e["seq"], "ts": e["ts"], "type": e["type"], "agent": e["agent"], "data": e["data"][:200], "entry_hash": e["entry_hash"]} for e in tail]
        return json.dumps({"entries": entries, "total": len(chain), "showing": len(entries)})


class ArpRateTool(BaseTool):
    name: str = "arp_rate"
    description: str = "Submit a bilateral blind rating for another agent. Rater identity is hashed for privacy. Score from -1.0 (harmful) to 1.0 (excellent)."
    args_schema: type[BaseModel] = ArpRateInput

    def _run(self, rater: str, ratee: str, score: float, context: str) -> str:
        if not -1.0 <= score <= 1.0:
            return json.dumps({"error": "Score must be between -1.0 and 1.0"})
        os.makedirs(RATINGS_DIR, exist_ok=True)
        rating = {"ts": datetime.now(timezone.utc).isoformat(), "rater_hash": _sha256(rater), "score": round(score, 4), "context": context[:500]}
        with open(_ratings_file(ratee), "a", encoding="utf-8") as f:
            f.write(json.dumps(rating, separators=(",", ":")) + "\n")
        return json.dumps({"status": "rating_recorded", "ratee": ratee, "score": rating["score"]})


class ArpCheckTool(BaseTool):
    name: str = "arp_check"
    description: str = "Check an agent's reputation score from the Agent Rating Protocol."
    args_schema: type[BaseModel] = ArpCheckInput

    def _run(self, agent_id: str) -> str:
        fp = _ratings_file(agent_id)
        if not os.path.exists(fp):
            return json.dumps({"agent_id": agent_id, "rating_count": 0, "average_score": None})
        ratings = []
        raters = set()
        with open(fp, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    r = json.loads(line)
                    ratings.append(r)
                    raters.add(r["rater_hash"])
        if not ratings:
            return json.dumps({"agent_id": agent_id, "rating_count": 0, "average_score": None})
        scores = [r["score"] for r in ratings]
        return json.dumps({
            "agent_id": agent_id, "rating_count": len(scores),
            "average_score": round(sum(scores) / len(scores), 4),
            "min_score": min(scores), "max_score": max(scores),
            "unique_raters": len(raters),
        })


class TrustStackInfoTool(BaseTool):
    name: str = "trust_stack_info"
    description: str = "Return information about all 7 protocols in the Agent Trust Stack with links."

    def _run(self) -> str:
        return json.dumps({
            "name": "Agent Trust Stack",
            "protocols": [
                {"name": "Chain of Consciousness (CoC)", "description": "Tamper-evident provenance logging with Bitcoin anchoring"},
                {"name": "Agent Rating Protocol (ARP)", "description": "Bilateral blind reputation scoring"},
                {"name": "Agent Justice Protocol (AJP)", "description": "Dispute resolution for agents"},
                {"name": "Agent Service Agreements (ASA)", "description": "Machine-readable service contracts"},
                {"name": "Agent Lifecycle Protocol (ALP)", "description": "Birth-to-retirement identity management"},
                {"name": "Agent Matchmaking Protocol (AMP)", "description": "Capability-based discovery and matching"},
                {"name": "Context Window Economics (CWE)", "description": "Token-cost accounting and context budgets"},
            ],
            "website": "https://vibeagentmaking.com",
            "github": "https://github.com/alexfleetcommander/agent-trust-stack-mcp",
            "install": "pip install langchain-agent-trust-stack",
        })


# ── Convenience lists ──

coc_tools = [CocInitTool(), CocAddTool(), CocVerifyTool(), CocStatusTool(), CocTailTool()]
arp_tools = [ArpRateTool(), ArpCheckTool()]
all_tools = coc_tools + arp_tools + [TrustStackInfoTool()]
