from fastmcp import FastMCP
from datetime import datetime

mcp = FastMCP("quisy-mcp-system-tools")

@mcp.tool()
def get_system_time() -> str:
    """Returns the current system time."""
    return datetime.now().isoformat()


def main():
    mcp.run()
