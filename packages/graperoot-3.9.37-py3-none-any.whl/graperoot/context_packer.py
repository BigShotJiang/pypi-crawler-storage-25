#!/Users/krishnakant/.dual-graph/venv/bin/python3
"""Core context packing module for DGC pre-injection mode (v3.8.37).

Generates compact, token-efficient context blocks from the dual-graph
retrieval results.  Output is markdown suitable for injection into
Claude's system prompt before the first user turn.

v3.8.33 changes:
  - Budget default 3000 → 5000
  - Full structured summaries (params, returns, calls) instead of 200-char truncation
  - Code-first priority: inline code gets budget before edges
  - More functions inlined (top 3 per file instead of 2)

v3.8.34 changes:
  - Bulletproof Python venv setup (5-level fallback chain)
"""

from __future__ import annotations

import json
import sys
from math import ceil
from pathlib import Path
from typing import Any

from graperoot.dg import retrieve as _dg_retrieve, load_graph as _dg_load_graph, classify_intent as _classify_intent


# ---------------------------------------------------------------------------
# 1. load_summaries
# ---------------------------------------------------------------------------

def load_summaries(project_root: Path) -> dict:
    """Load structured_summaries.json from the project's .dual-graph/ dir."""
    path = project_root / ".dual-graph" / "structured_summaries.json"
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
        return {}
    except (json.JSONDecodeError, OSError):
        return {}


# ---------------------------------------------------------------------------
# 2. expand_summary  (replaces condense_summary)
# ---------------------------------------------------------------------------

def expand_summary(summary: dict) -> str:
    """Convert a structured summary into a rich multi-line block.

    Includes function signatures with params/returns, internal call graph,
    class hierarchies, and key variables.  No arbitrary truncation.

    Output example:
        Order management API endpoints.
        Functions:
          get_orders(db: Session, status: str = None) -> list[OrderResponse]
            calls: order_to_response, db.query | decorators: @router.get
          create_order(db: Session, data: OrderCreate) -> Order
            calls: validate_menu_items
        Classes: OrderResponse(BaseModel), OrderCreate(BaseModel)
        Vars: router (used by: get_orders, create_order)
    """
    if not summary or not isinstance(summary, dict):
        return ""

    lines: list[str] = []

    # Description
    desc = summary.get("description", "").strip()
    if desc:
        if not desc.endswith("."):
            desc += "."
        lines.append(desc)

    # Functions — full detail
    funcs = summary.get("functions") or {}
    if isinstance(funcs, dict) and funcs:
        lines.append("Functions:")
        for fname, finfo in list(funcs.items())[:8]:
            if not fname:
                continue
            params = finfo.get("params", "")
            if isinstance(params, list):
                params = ", ".join(params)
            ret = finfo.get("returns", "")
            sig = f"  {fname}({params})"
            if ret:
                sig += f" -> {ret}"
            # Add async marker
            if finfo.get("async"):
                sig = f"  async {fname}({params})"
                if ret:
                    sig += f" -> {ret}"
            lines.append(sig)

            # Sub-details: calls, decorators
            details: list[str] = []
            calls_int = finfo.get("calls_internal", [])
            calls_ext = finfo.get("calls_external", [])
            all_calls = (calls_int or []) + (calls_ext or [])
            if all_calls:
                details.append("calls: " + ", ".join(all_calls[:6]))
            decorators = finfo.get("decorators", [])
            if decorators:
                details.append("decorators: " + ", ".join(decorators[:3]))
            if details:
                lines.append("    " + " | ".join(details))

    # Classes — with bases and methods
    classes = summary.get("classes") or {}
    if isinstance(classes, dict) and classes:
        cls_parts: list[str] = []
        for cname, cinfo in list(classes.items())[:5]:
            bases = cinfo.get("bases", "")
            if isinstance(bases, list):
                bases = ", ".join(bases)
            label = f"{cname}({bases})" if bases else cname
            methods = cinfo.get("methods", [])
            if methods and isinstance(methods, list):
                label += f" [{', '.join(methods[:4])}]"
            cls_parts.append(label)
        lines.append("Classes: " + ", ".join(cls_parts))

    # Variables — with usage info
    variables = summary.get("variables", [])
    if variables:
        var_parts: list[str] = []
        for v in variables[:6]:
            if isinstance(v, dict):
                name = v.get("name", "")
                used_by = v.get("used_by", [])
                if name:
                    if used_by:
                        var_parts.append(f"{name} (used by: {', '.join(used_by[:3])})")
                    else:
                        var_parts.append(name)
            elif isinstance(v, str):
                var_parts.append(v)
        if var_parts:
            lines.append("Vars: " + ", ".join(var_parts))

    # Internal call graph
    internal_graph = summary.get("internal_graph", [])
    if internal_graph and isinstance(internal_graph, list):
        graph_strs: list[str] = []
        for edge in internal_graph[:6]:
            if isinstance(edge, dict):
                frm = edge.get("from", "")
                to = edge.get("to", "")
                rel = edge.get("rel", "calls")
                if frm and to:
                    graph_strs.append(f"{frm}->{to}")
        if graph_strs:
            lines.append("Call graph: " + ", ".join(graph_strs))

    # Imports
    imports = summary.get("imports", [])
    if imports and isinstance(imports, list):
        imp_strs: list[str] = []
        for imp in imports[:5]:
            if isinstance(imp, dict):
                mod = imp.get("module", "")
                names = imp.get("names", [])
                if mod:
                    if names:
                        imp_strs.append(f"{mod}({', '.join(names[:4])})")
                    else:
                        imp_strs.append(mod)
        if imp_strs:
            lines.append("Imports: " + ", ".join(imp_strs))

    return "\n".join(lines)


def condense_summary(summary: dict) -> str:
    """Backward-compatible one-liner summary (used as fallback)."""
    if not summary or not isinstance(summary, dict):
        return ""
    parts: list[str] = []
    desc = summary.get("description", "").strip()
    if desc:
        if not desc.endswith("."):
            desc += "."
        parts.append(desc)
    funcs = summary.get("functions") or {}
    if isinstance(funcs, dict) and funcs:
        sigs = []
        for fname, finfo in list(funcs.items())[:5]:
            if not fname:
                continue
            params = finfo.get("params", "")
            if isinstance(params, list):
                params = ", ".join(params)
            ret = finfo.get("returns", "")
            sig = f"{fname}({params})"
            if ret:
                sig += f" -> {ret}"
            sigs.append(sig)
        if sigs:
            parts.append("Functions: " + ", ".join(sigs))
    text = " | ".join(parts) if len(parts) > 1 else (parts[0] if parts else "")
    return text[:300]


# ---------------------------------------------------------------------------
# 3. estimate_tokens
# ---------------------------------------------------------------------------

def estimate_tokens(text: str) -> int:
    """Rough token estimate: ceil(len / 3.2)."""
    if not text:
        return 0
    return ceil(len(text) / 3.2)


# ---------------------------------------------------------------------------
# 4. read_symbol_content
# ---------------------------------------------------------------------------

def read_symbol_content(
    project_root: Path,
    file_id: str,
    functions: dict,
    max_lines: int = 80,
) -> str:
    """Read function bodies from a file for inline inclusion.

    v3.8.33: bumped max_lines 60→80, reads top 3 functions instead of 2.
    """
    file_path = project_root / file_id
    if not file_path.exists():
        return ""
    try:
        all_lines = file_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    except OSError:
        return ""

    if not functions:
        return ""

    sorted_fns = sorted(
        functions.items(),
        key=lambda kv: kv[1].get("line_start", 0),
    )

    chunks: list[str] = []
    total_lines = 0

    for fn_name, fn_info in sorted_fns[:3]:  # was [:2]
        start = fn_info.get("line_start", 0)
        end = fn_info.get("line_end", start + 20)
        start = max(0, start)
        end = min(len(all_lines) - 1, end)
        span = end - start + 1

        if total_lines + span > max_lines:
            end = start + (max_lines - total_lines) - 1
            if end < start:
                break
            span = end - start + 1

        header = f"# {file_id}::{fn_name} (lines {start + 1}-{end + 1})"
        body = "\n".join(all_lines[start : end + 1])
        chunks.append(f"{header}\n{body}")
        total_lines += span

        if total_lines >= max_lines:
            break

    return "\n\n".join(chunks)


# ---------------------------------------------------------------------------
# 5. pack  (v3.8.33 — reordered priorities)
# ---------------------------------------------------------------------------

def _file_id(entry: Any) -> str:
    if isinstance(entry, dict):
        return str(entry.get("id", ""))
    return str(entry)


def _basename(path: str) -> str:
    return path.rsplit("/", 1)[-1] if "/" in path else path


def pack(
    retrieve_result: Any,
    summaries: dict,
    graph: dict,
    project_root: Path,
    token_budget: int = 5000,
    max_files: int = 8,
    max_read_targets: int = 8,
) -> str:
    """Build a compact markdown context block from retrieval results.

    v3.8.33 priority order (code-first):
        1. Relevant Files — file path + FULL structured summary
        2. Key Code — inline function bodies (gets priority over edges)
        3. Recommended Reads — function locations with line numbers
        4. Key Relationships — import/call/extends edges (lowest priority)
    """
    files_list = getattr(retrieve_result, "files", []) if not isinstance(retrieve_result, dict) else retrieve_result.get("files", [])
    edges_list = getattr(retrieve_result, "edges", []) if not isinstance(retrieve_result, dict) else retrieve_result.get("edges", [])

    file_ids: list[str] = []
    for entry in files_list[:max_files]:
        fid = _file_id(entry)
        if fid:
            file_ids.append(fid)

    chosen_set = set(file_ids)

    # ── Section 1: Relevant Files (full structured summaries) ────────────
    sec1_lines: list[str] = ["### Relevant Files"]
    for fid in file_ids:
        base_file = fid.split("::")[0] if "::" in fid else fid
        summary_obj = summaries.get(base_file, {})

        # Try full expanded summary first, fall back to condensed
        expanded = expand_summary(summary_obj) if summary_obj else ""
        if expanded:
            # Indent multi-line summaries under the file path
            summary_lines = expanded.split("\n")
            sec1_lines.append(f"- **`{fid}`**")
            for sl in summary_lines:
                sec1_lines.append(f"  {sl}")
        else:
            # Fall back to graph node summary
            fallback = ""
            for node in graph.get("nodes", []):
                if node.get("id") == fid or node.get("id") == base_file:
                    fallback = (node.get("summary", "") or "")[:300]
                    break
            if fallback:
                sec1_lines.append(f"- **`{fid}`**: {fallback}")
            else:
                sec1_lines.append(f"- **`{fid}`**")

    sec1 = "\n".join(sec1_lines)
    sec1_tokens = estimate_tokens(sec1)

    # ── Header ───────────────────────────────────────────────────────────
    header = "## Project Context (auto-generated by DGC v3.8.37)\n"
    header_tokens = estimate_tokens(header)

    remaining = token_budget - header_tokens - sec1_tokens

    # ── Section 2 (was 4): Key Code — PRIORITY over edges ───────────────
    sec_code = ""
    if remaining > 400:
        code_budget = min(remaining, int(token_budget * 0.45))  # up to 45% for code
        sec_code_parts: list[str] = ["### Key Code (pre-loaded)"]
        code_tokens_used = estimate_tokens(sec_code_parts[0])

        for fid in file_ids[:4]:  # was [:3]
            if code_budget - code_tokens_used < 200:
                break
            base_file = fid.split("::")[0] if "::" in fid else fid
            summary_obj = summaries.get(base_file, {})
            funcs_map = summary_obj.get("functions") or {}

            fn_dict: dict[str, dict] = {}
            if isinstance(funcs_map, dict) and funcs_map:
                for fn_name, fn_info in list(funcs_map.items())[:3]:  # was [:2]
                    if not fn_name:
                        continue
                    lines_arr = fn_info.get("lines", [])
                    if isinstance(lines_arr, list) and len(lines_arr) == 2:
                        fn_dict[fn_name] = {
                            "line_start": lines_arr[0],
                            "line_end": lines_arr[1],
                            "description": fn_info.get("description", ""),
                        }
            else:
                for node in graph.get("nodes", []):
                    if node.get("kind") == "symbol" and node.get("path") == base_file:
                        fn_dict[node.get("name", "")] = {
                            "line_start": node.get("line_start", 0),
                            "line_end": node.get("line_end", 20),
                        }
                        if len(fn_dict) >= 3:
                            break

            if not fn_dict:
                continue

            code = read_symbol_content(project_root, base_file, fn_dict, max_lines=80)
            if not code:
                continue

            ext = base_file.rsplit(".", 1)[-1] if "." in base_file else ""
            lang_map = {"py": "python", "ts": "typescript", "tsx": "tsx", "js": "javascript", "jsx": "jsx", "go": "go"}
            lang = lang_map.get(ext, ext)

            block = f"```{lang}\n{code}\n```"
            block_tokens = estimate_tokens(block)

            if code_tokens_used + block_tokens > code_budget:
                char_budget = int((code_budget - code_tokens_used) * 3.2)
                if char_budget > 100:
                    truncated = code[:char_budget].rsplit("\n", 1)[0]
                    block = f"```{lang}\n{truncated}\n# ... truncated\n```"
                    sec_code_parts.append(block)
                break

            sec_code_parts.append(block)
            code_tokens_used += block_tokens

        if len(sec_code_parts) > 1:
            sec_code = "\n".join(sec_code_parts)
            remaining -= estimate_tokens(sec_code)

    # ── Section 3: Recommended Reads ─────────────────────────────────────
    sec_reads = ""
    if remaining > 200:
        sec3_lines: list[str] = ["### Recommended Reads"]
        read_targets_added = 0

        for fid in file_ids:
            if read_targets_added >= max_read_targets:
                break
            base_file = fid.split("::")[0] if "::" in fid else fid
            summary_obj = summaries.get(base_file, {})
            funcs = summary_obj.get("functions", [])
            if not funcs:
                for node in graph.get("nodes", []):
                    if node.get("kind") == "symbol" and node.get("path") == base_file:
                        line_s = node.get("line_start", 0) + 1
                        line_e = node.get("line_end", line_s) + 1
                        name = node.get("name", "unknown")
                        sec3_lines.append(f"- `{base_file}` lines {line_s}-{line_e}: `{name}()`")
                        read_targets_added += 1
                        if read_targets_added >= max_read_targets:
                            break
                continue

            funcs_iter = funcs.items() if isinstance(funcs, dict) else []
            for fn_name, fn_info in list(funcs_iter)[:3]:
                if read_targets_added >= max_read_targets:
                    break
                if not fn_name:
                    continue
                lines_arr = fn_info.get("lines", [])
                if isinstance(lines_arr, list) and len(lines_arr) == 2:
                    line_s, line_e = lines_arr
                else:
                    continue
                if line_s == 0 and line_e == 0:
                    continue
                display_start = line_s + 1 if line_s >= 0 else line_s
                display_end = line_e + 1 if line_e >= 0 else line_e
                desc = fn_info.get("description", "")
                desc_part = f" -- {desc}" if desc else ""
                sec3_lines.append(
                    f"- `{base_file}` lines {display_start}-{display_end}: `{fn_name}()`{desc_part}"
                )
                read_targets_added += 1

        if read_targets_added > 0:
            sec_reads = "\n".join(sec3_lines)
            remaining -= estimate_tokens(sec_reads)

    # ── Section 4: Key Relationships (lowest priority) ───────────────────
    sec_edges = ""
    if remaining > 150:
        sec4_lines: list[str] = ["### Key Relationships"]
        relevant_rels = {"imports", "calls", "extends", "implements", "requires", "contains", "references"}
        edge_count = 0
        for edge in edges_list:
            if edge_count >= 10:
                break
            frm = str(edge.get("from", ""))
            to = str(edge.get("to", ""))
            rel = str(edge.get("rel", ""))
            if frm not in chosen_set and to not in chosen_set:
                continue
            if rel not in relevant_rels:
                continue
            sec4_lines.append(f"- `{_basename(frm)}` --{rel}--> `{_basename(to)}`")
            edge_count += 1

        if edge_count > 0:
            sec_edges = "\n".join(sec4_lines)

    # ── Assemble final output ────────────────────────────────────────────
    sections = [header, sec1]
    if sec_code:
        sections.append(sec_code)
    if sec_reads:
        sections.append(sec_reads)
    if sec_edges:
        sections.append(sec_edges)

    return "\n\n".join(sections)


# ---------------------------------------------------------------------------
# 6. pack_for_query
# ---------------------------------------------------------------------------

def pack_for_query(
    query: str,
    project_root: Path,
    token_budget: int = 5000,
) -> str:
    """Convenience function: full retrieval + packing pipeline."""
    graph = _dg_load_graph()
    result = _dg_retrieve(graph, query, top_files=8, top_edges=40)
    summaries = load_summaries(project_root)
    return pack(
        retrieve_result=result,
        summaries=summaries,
        graph=graph,
        project_root=project_root,
        token_budget=token_budget,
    )


# ---------------------------------------------------------------------------
# __main__
# ---------------------------------------------------------------------------

def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: context-packer \"your query\" [project_root]", file=sys.stderr)
        raise SystemExit(1)
    query = sys.argv[1]
    root = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(".")
    print(pack_for_query(query, root.resolve()))


if __name__ == "__main__":
    main()
