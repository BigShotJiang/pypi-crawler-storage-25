from ch07_person_logic.person_main import personunit_shop
from ch08_person_atom.atom_main import personatom_shop
from ch09_person_lesson.delta import persondelta_shop
from ch09_person_lesson.legible import create_legible_list
from ref.keywords import Ch09Keywords as kw


def test_create_legible_list_ReturnsObj_plan_healerunit_INSERT():
    # ESTABLISH
    sue_person = personunit_shop("Sue")
    dimen = kw.person_plan_healerunit
    casa_rope = sue_person.make_l1_rope("casa")
    rope_value = sue_person.make_rope(casa_rope, "clean fridge")
    healer_name_value = f"{sue_person.knot}bowlers"
    bowl_personatom = personatom_shop(dimen, kw.INSERT)
    bowl_personatom.set_arg(kw.plan_rope, rope_value)
    bowl_personatom.set_arg(kw.healer_name, healer_name_value)
    # print(f"{bowl_personatom=}")
    x_persondelta = persondelta_shop()
    x_persondelta.set_personatom(bowl_personatom)

    # WHEN
    legible_list = create_legible_list(x_persondelta, sue_person)

    # THEN
    x_str = f"HealerUnit '{healer_name_value}' created for plan '{rope_value}'."
    print(f"{x_str=}")
    assert legible_list[0] == x_str


def test_create_legible_list_ReturnsObj_plan_healerunit_DELETE():
    # ESTABLISH
    sue_person = personunit_shop("Sue")
    dimen = kw.person_plan_healerunit
    casa_rope = sue_person.make_l1_rope("casa")
    rope_value = sue_person.make_rope(casa_rope, "clean fridge")
    healer_name_value = f"{sue_person.knot}bowlers"
    bowl_personatom = personatom_shop(dimen, kw.DELETE)
    bowl_personatom.set_arg(kw.plan_rope, rope_value)
    bowl_personatom.set_arg(kw.healer_name, healer_name_value)
    # print(f"{bowl_personatom=}")
    x_persondelta = persondelta_shop()
    x_persondelta.set_personatom(bowl_personatom)

    # WHEN
    legible_list = create_legible_list(x_persondelta, sue_person)

    # THEN
    x_str = f"HealerUnit '{healer_name_value}' deleted for plan '{rope_value}'."
    print(f"{x_str=}")
    assert legible_list[0] == x_str
