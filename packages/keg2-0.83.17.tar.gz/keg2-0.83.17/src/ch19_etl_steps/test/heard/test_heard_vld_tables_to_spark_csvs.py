from ch00_py.db_toolbox import get_table_columns
from ch00_py.file_toolbox import create_path, open_file
from ch04_rope.rope import create_rope
from ch09_person_lesson.lasso import lassounit_shop
from ch11_bud._ref.ch11_path import create_person_spark_dir_path
from ch18_etl_config.etl_sqlstr import (
    create_prime_tablename,
    create_sound_and_heard_tables,
)
from ch19_etl_steps.etl_main import etl_heard_vld_to_spark_person_csvs
from os.path import exists as os_path_exists
from ref.keywords import Ch19Keywords as kw, ExampleStrs as exx
from sqlite3 import Cursor


def test_etl_heard_vld_to_spark_person_csvs_CreatesCSVs_Scenario0_person_contactunit(
    temp3_fs, cursor0: Cursor
):
    # ESTABLISH
    sue_inx = "Suzy"
    bob_inx = "Bobby"
    yao_inx = "Bobby"
    spark3 = 3
    spark7 = 7
    yao_contact_cred_lumen5 = 5
    sue_contact_cred_lumen7 = 7
    put_agg_tablename = create_prime_tablename(kw.person_contactunit, kw.h_vld, "put")
    put_agg_csv = f"{put_agg_tablename}.csv"
    x_dir = str(temp3_fs)
    a23_lasso = lassounit_shop(exx.a23_dash, exx.dash)
    a23_bob_e3_dir = create_person_spark_dir_path(x_dir, a23_lasso, bob_inx, spark3)
    a23_bob_e7_dir = create_person_spark_dir_path(x_dir, a23_lasso, bob_inx, spark7)
    a23_e3_prncont_put_path = create_path(a23_bob_e3_dir, put_agg_csv)
    a23_e7_prncont_put_path = create_path(a23_bob_e7_dir, put_agg_csv)

    create_sound_and_heard_tables(cursor0)
    insert_raw_sqlstr = f"""
INSERT INTO {put_agg_tablename} ({kw.spark_num},{kw.spark_face},{kw.moment_rope},{kw.person_name},{kw.contact_name},{kw.contact_cred_lumen},{kw.knot})
VALUES
  ({spark3},'{sue_inx}','{exx.a23_dash}','{bob_inx}','{yao_inx}',{yao_contact_cred_lumen5},'{exx.dash}')
, ({spark7},'{sue_inx}','{exx.a23_dash}','{bob_inx}','{yao_inx}',{yao_contact_cred_lumen5},'{exx.dash}')
, ({spark7},'{sue_inx}','{exx.a23_dash}','{bob_inx}','{sue_inx}',{sue_contact_cred_lumen7},'{exx.dash}')
;
"""
    print(insert_raw_sqlstr)
    cursor0.execute(insert_raw_sqlstr)
    print(f"{a23_e3_prncont_put_path=}")
    print(f"{a23_e7_prncont_put_path=}")
    assert os_path_exists(a23_e3_prncont_put_path) is False
    assert os_path_exists(a23_e7_prncont_put_path) is False

    # WHEN
    etl_heard_vld_to_spark_person_csvs(cursor0, x_dir)

    # THEN
    assert os_path_exists(a23_e3_prncont_put_path)
    assert os_path_exists(a23_e7_prncont_put_path)
    e3_put_csv = open_file(a23_e3_prncont_put_path)
    e7_put_csv = open_file(a23_e7_prncont_put_path)
    print(f"{e3_put_csv=}")
    print(f"{e7_put_csv=}")
    expected_e3_put_csv = f"""spark_num,spark_face,moment_rope,person_name,contact_name,contact_cred_lumen,contact_debt_lumen,knot
3,Suzy,{exx.a23_dash},Bobby,Bobby,5.0,,{exx.dash}
"""
    expected_e7_put_csv = f"""spark_num,spark_face,moment_rope,person_name,contact_name,contact_cred_lumen,contact_debt_lumen,knot
7,Suzy,{exx.a23_dash},Bobby,Bobby,5.0,,{exx.dash}
7,Suzy,{exx.a23_dash},Bobby,Suzy,7.0,,{exx.dash}
"""
    assert e3_put_csv == expected_e3_put_csv
    assert e7_put_csv == expected_e7_put_csv


def test_etl_heard_vld_to_spark_person_csvs_CreatesCSVs_Scenario1_person_plan_reasonunit(
    temp3_fs, cursor0: Cursor
):
    # ESTABLISH
    sue_inx = "Suzy"
    bob_inx = "Bobby"
    spark3 = 3
    spark7 = 7
    put_agg_tablename = create_prime_tablename(kw.prnreas, kw.h_vld, "put")
    put_agg_csv = f"{put_agg_tablename}.csv"
    x_dir = str(temp3_fs)
    a23_lasso = lassounit_shop(exx.a23)
    a23_bob_e3_dir = create_person_spark_dir_path(x_dir, a23_lasso, bob_inx, spark3)
    a23_bob_e7_dir = create_person_spark_dir_path(x_dir, a23_lasso, bob_inx, spark7)
    a23_e3_prncont_put_path = create_path(a23_bob_e3_dir, put_agg_csv)
    a23_e7_prncont_put_path = create_path(a23_bob_e7_dir, put_agg_csv)

    create_sound_and_heard_tables(cursor0)
    # print(f"{get_table_columns(cursor0, put_agg_tablename)=}")
    x_knot = ";"
    casa_rope = create_rope(exx.a23, exx.casa)
    clean_rope = create_rope(casa_rope, exx.clean)
    mop_rope = create_rope(clean_rope, exx.mop)
    dirty_rope = create_rope(exx.a23, exx.dirtyness)
    insert_raw_sqlstr = f"""
INSERT INTO {put_agg_tablename} (
{kw.spark_num},{kw.spark_face},{kw.person_name},{kw.plan_rope},{kw.reason_context},{kw.active_requisite},{kw.knot})
VALUES
  ({spark3},'{sue_inx}','{bob_inx}','{mop_rope}','{dirty_rope}',NULL,'{x_knot}')
, ({spark7},'{sue_inx}','{bob_inx}','{mop_rope}','{dirty_rope}',NULL,'{x_knot}')
, ({spark7},'{sue_inx}','{bob_inx}','{mop_rope}','{dirty_rope}',NULL,'{x_knot}')
;
"""
    # print(insert_raw_sqlstr)
    cursor0.execute(insert_raw_sqlstr)
    print(f"0{x_dir=}")
    print(f"{a23_e3_prncont_put_path=}")
    print(f"{a23_e7_prncont_put_path=}")
    assert os_path_exists(a23_e3_prncont_put_path) is False
    assert os_path_exists(a23_e7_prncont_put_path) is False

    # WHEN
    etl_heard_vld_to_spark_person_csvs(cursor0, x_dir)

    # THEN
    assert os_path_exists(a23_e3_prncont_put_path)
    assert os_path_exists(a23_e7_prncont_put_path)
    e3_put_csv = open_file(a23_e3_prncont_put_path)
    e7_put_csv = open_file(a23_e7_prncont_put_path)
    # print(f"{e3_put_csv=}")
    print(f"{e7_put_csv=}")
    expected_e3_put_csv = f"""{kw.spark_num},{kw.spark_face},{kw.person_name},{kw.plan_rope},{kw.reason_context},{kw.active_requisite},{kw.knot}
3,Suzy,{bob_inx},{mop_rope},{dirty_rope},,;
"""
    expected_e7_put_csv = f"""{kw.spark_num},{kw.spark_face},{kw.person_name},{kw.plan_rope},{kw.reason_context},{kw.active_requisite},{kw.knot}
7,Suzy,{bob_inx},{mop_rope},{dirty_rope},,;
7,Suzy,{bob_inx},{mop_rope},{dirty_rope},,;
"""
    assert e3_put_csv == expected_e3_put_csv
    assert e7_put_csv == expected_e7_put_csv


# Once this test passes add integration test to
def test_etl_heard_vld_to_spark_person_csvs_CreatesCSVs_Scenario2_person_planunit(
    temp3_fs, cursor0: Cursor
):
    # ESTABLISH
    spark3 = 3
    music_rope = f"{exx.a23}enjoy music;"
    home_rope = f"{exx.a23}clean home;"
    ask_rope = f"{exx.a23}clean home;ask neighbor to use baking soda;"
    clothes_rope = f"{exx.a23}clean home;clean clothes with baking soda;"
    dishes_rope = f"{exx.a23}clean home;clean dishes with baking soda;"
    counters_rope = f"{exx.a23}clean home;clean kitchen counters with baking soda;"
    neighbor_rope = f"{exx.a23}clean home;give neighbor any baking soda they want;"

    put_agg_tablename = create_prime_tablename(kw.prnplan, kw.h_vld, "put")
    put_agg_csv = f"{put_agg_tablename}.csv"
    x_dir = str(temp3_fs)
    a23_lasso = lassounit_shop(exx.a23)
    a23_bob_e3_dir = create_person_spark_dir_path(x_dir, a23_lasso, exx.bob, spark3)
    a23_e3_prnplan_put_path = create_path(a23_bob_e3_dir, put_agg_csv)

    create_sound_and_heard_tables(cursor0)
    insert_raw_sqlstr = f"""
INSERT INTO {put_agg_tablename} ({kw.spark_num},{kw.spark_face},{kw.person_name},{kw.plan_rope},{kw.star},{kw.pledge})
VALUES
  ({spark3}, '{exx.sue}', '{exx.sue}', '{music_rope}', 10, 1)
, ({spark3}, '{exx.sue}', '{exx.bob}', '{home_rope}', 1, 0)
, ({spark3}, '{exx.sue}', '{exx.bob}', '{ask_rope}', 3, 1)
, ({spark3}, '{exx.sue}', '{exx.bob}', '{clothes_rope}', 12, 1)
, ({spark3}, '{exx.sue}', '{exx.bob}', '{dishes_rope}', 10, 1)
, ({spark3}, '{exx.sue}', '{exx.bob}', '{counters_rope}', 5, 1)
, ({spark3}, '{exx.sue}', '{exx.bob}', '{neighbor_rope}', 20, 1)
, ({spark3}, '{exx.sue}', '{exx.bob}', '{music_rope}', 1, 1)
;
"""
    # print(insert_raw_sqlstr)
    cursor0.execute(insert_raw_sqlstr)
    print(f"file_path {a23_e3_prnplan_put_path.replace(x_dir, '')}")
    # print(f"{a23_e7_prnplan_put_path=}")
    assert os_path_exists(a23_e3_prnplan_put_path) is False

    # WHEN
    etl_heard_vld_to_spark_person_csvs(cursor0, x_dir)

    # THEN
    assert os_path_exists(a23_e3_prnplan_put_path)
    e3_put_csv = open_file(a23_e3_prnplan_put_path)
    # print(f"{e3_put_csv=}")
    print(f"{e3_put_csv=}")
    assert music_rope in e3_put_csv
    assert home_rope in e3_put_csv
    assert ask_rope in e3_put_csv
    assert clothes_rope in e3_put_csv
    assert dishes_rope in e3_put_csv
    assert counters_rope in e3_put_csv
    assert neighbor_rope in e3_put_csv
    assert music_rope in e3_put_csv

    expected_e3_put_csv = f"""{kw.spark_num},{kw.spark_face},{kw.person_name},{kw.plan_rope},{kw.begin},{kw.close},{kw.addin},{kw.numor},{kw.denom},{kw.morph},{kw.gogo_want},{kw.stop_want},{kw.star},{kw.pledge},{kw.problem_bool},{kw.knot}
{spark3},{exx.sue},{exx.bob},;Amy23;clean home;,,,,,,,,,1,0,,
{spark3},{exx.sue},{exx.bob},;Amy23;clean home;ask neighbor to use baking soda;,,,,,,,,,3,1,,
{spark3},{exx.sue},{exx.bob},;Amy23;clean home;clean clothes with baking soda;,,,,,,,,,12,1,,
{spark3},{exx.sue},{exx.bob},;Amy23;clean home;clean dishes with baking soda;,,,,,,,,,10,1,,
{spark3},{exx.sue},{exx.bob},;Amy23;clean home;clean kitchen counters with baking soda;,,,,,,,,,5,1,,
{spark3},{exx.sue},{exx.bob},;Amy23;clean home;give neighbor any baking soda they want;,,,,,,,,,20,1,,
{spark3},{exx.sue},{exx.bob},;Amy23;enjoy music;,,,,,,,,,1,1,,
"""
    assert e3_put_csv == expected_e3_put_csv
