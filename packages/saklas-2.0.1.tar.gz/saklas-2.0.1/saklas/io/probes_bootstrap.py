"""Bootstrap default probe vectors from the ~/.saklas/ concept-folder layout."""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

import torch

from saklas.core.errors import StaleSidecarError
from saklas.io.packs import (
    ConceptFolder, PackFormatError, Sidecar,
    hash_file, materialize_bundled,
)
from saklas.io.paths import (
    concept_dir, model_dir, neutral_statements_path, safe_model_id, vectors_dir,
)
from saklas.core.vectors import (
    compute_layer_means, extract_contrastive, load_contrastive_pairs,
    load_profile, save_profile,
)

log = logging.getLogger(__name__)

_LAYER_MEANS_NAME = "layer_means"


def load_defaults() -> dict[str, list[str]]:
    """Return {tag: [concept_name, ...]} for the default/ namespace.

    Triggers first-run materialization of bundled data into ~/.saklas/.
    """
    materialize_bundled()
    root = vectors_dir() / "default"
    if not root.is_dir():
        return {}
    by_tag: dict[str, list[str]] = {}
    for cdir in sorted(root.iterdir()):
        if not cdir.is_dir() or not (cdir / "pack.json").is_file():
            continue
        try:
            cf = ConceptFolder.load(cdir)
        except PackFormatError as e:
            log.warning("skipping %s: %s", cdir.name, e)
            continue
        for tag in cf.metadata.tags or ["uncategorized"]:
            by_tag.setdefault(tag, []).append(cf.metadata.name)
    return by_tag


def bootstrap_layer_means(
    model: Any, tokenizer: Any, layers: list[Any], model_info: dict[str, Any],
) -> dict[int, torch.Tensor]:
    """Load or compute per-layer mean activations for probe centering.

    Stored at ~/.saklas/models/<safe_id>/layer_means.safetensors with a slim
    sidecar. Stale if neutral_statements.json has changed since extraction.
    """
    model_id = model_info.get("model_id", "unknown")
    md = model_dir(model_id)
    md.mkdir(parents=True, exist_ok=True)
    ts_path = md / f"{_LAYER_MEANS_NAME}.safetensors"
    sc_path = md / f"{_LAYER_MEANS_NAME}.json"

    current_ns_hash: str | None = None
    if neutral_statements_path().exists():
        current_ns_hash = hash_file(neutral_statements_path())

    if ts_path.exists() and sc_path.exists():
        try:
            sc = Sidecar.load(sc_path)
            if current_ns_hash is None or sc.statements_sha256 == current_ns_hash:
                profile, _ = load_profile(str(ts_path))
                log.debug("Loaded cached layer means")
                return profile
            log.info("Layer means stale (neutral_statements changed); recomputing")
        except Exception as e:
            log.warning("Corrupt layer means cache, recomputing: %s", e)

    log.info("Computing layer means (one-time per model)...")
    means = compute_layer_means(model, tokenizer, layers)
    save_profile(means, str(ts_path), {
        "method": "layer_means",
        "statements_sha256": current_ns_hash or "",
    })
    return means


def bootstrap_probes(
    model: Any, tokenizer: Any, layers: list[Any], model_info: dict[str, Any], categories: list[str],
) -> dict[str, dict[int, torch.Tensor]]:
    """Load or extract probe vector profiles for the given categories."""
    from saklas import __version__ as _saklas_version

    defaults = load_defaults()
    model_id = model_info.get("model_id", "unknown")
    sid = safe_model_id(model_id)

    probes: dict[str, dict[int, torch.Tensor]] = {}
    to_extract: list[tuple[str, Path, Path]] = []

    allow_stale = os.environ.get("SAKLAS_ALLOW_STALE") == "1"

    for cat in categories:
        for probe_name in defaults.get(cat, []):
            cdir = concept_dir("default", probe_name)
            ts = cdir / f"{sid}.safetensors"
            sc_path = cdir / f"{sid}.json"
            if ts.exists() and sc_path.exists():
                try:
                    profile, meta = load_profile(str(ts))
                    stmts = cdir / "statements.json"
                    recorded_sha = meta.get("statements_sha256")
                    if stmts.exists() and recorded_sha:
                        current = hash_file(stmts)
                        if current != recorded_sha and not allow_stale:
                            raise StaleSidecarError(
                                f"default/{probe_name}: statements.json has changed "
                                f"since this tensor was extracted (model={model_id}). "
                                f"The baked PCA no longer matches the on-disk pairs. "
                                f"Re-extract: `saklas pack refresh default/{probe_name} -m {model_id}` "
                                f"— or set SAKLAS_ALLOW_STALE=1 to load the stale tensor anyway."
                            )
                    probes[probe_name] = profile
                    sidecar_version = meta.get("saklas_version", "")
                    try:
                        sv = tuple(int(p) for p in sidecar_version.split(".")[:2])
                        cv = tuple(int(p) for p in _saklas_version.split(".")[:2])
                        if sv != cv:
                            log.warning("%s: extracted with older saklas version", probe_name)
                    except (ValueError, IndexError):
                        log.warning("%s: extracted with older saklas version", probe_name)
                    continue
                except StaleSidecarError:
                    raise
                except Exception as e:
                    log.warning("Corrupt cache for %s, re-extracting: %s", probe_name, e)
            to_extract.append((probe_name, cdir, ts))

    if not to_extract:
        return probes

    log.info("Extracting %d probes...", len(to_extract))
    try:
        from tqdm import tqdm as _tqdm
        progress: Any = _tqdm
    except ImportError:
        def _no_tqdm(x: Any, **kw: Any) -> Any:
            return x
        progress = _no_tqdm

    datasets_to_extract = []
    for name, cdir, ts in to_extract:
        stmts_path = cdir / "statements.json"
        if not stmts_path.exists():
            log.warning("statements.json missing for %s; skipping", name)
            continue
        pairs_data = load_contrastive_pairs(str(stmts_path))
        datasets_to_extract.append((name, cdir, ts, pairs_data, stmts_path))

    model_device = next(model.parameters()).device
    for name, cdir, ts, ds, stmts_path in progress(datasets_to_extract, desc="Extracting probes", unit="probe"):
        try:
            profile, diagnostics = extract_contrastive(
                model, tokenizer, ds["pairs"], layers=layers,
                concept_label=f"default/{name}",
            )
            probes[name] = profile
            save_meta: dict[str, Any] = {
                "method": "contrastive_pca",
                "statements_sha256": hash_file(stmts_path),
            }
            if diagnostics:
                save_meta["diagnostics"] = diagnostics
            save_profile(profile, str(ts), save_meta)
        except Exception as e:
            log.warning("Contrastive extraction failed for %s: %s", name, e)
        if model_device.type == "mps":
            torch.mps.empty_cache()
    return probes
