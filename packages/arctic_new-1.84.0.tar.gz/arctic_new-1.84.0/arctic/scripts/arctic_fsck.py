import argparse
import logging

from .utils import setup_logging
from ..arctic import Arctic, ArcticLibraryBinding
from ..hooks import get_mongodb_uri

logger = logging.getLogger(__name__)


def main():
    usage = """
    Check a Arctic Library for inconsistencies.
    """
    setup_logging()

    parser = argparse.ArgumentParser(usage=usage)
    parser.add_argument("--host", default='localhost', help="Hostname, or clustername. Default: localhost")
    parser.add_argument("--library", nargs='+', required=True, help="The name of the library. e.g. 'arctic_jblackburn.lib'")
    parser.add_argument("-v", action='store_true', help="Verbose mode")
    parser.add_argument("-f", action='store_true', help="Force ; Cleanup any problems found. (Default is dry-run.)")
    parser.add_argument("-n", action='store_true', help="No FSCK ; just print stats.)")

    opts = parser.parse_args()

    if opts.v:
        logger.setLevel(logging.DEBUG)

    if not opts.f:
        logger.info("DRY-RUN: No changes will be made.")

    logger.info(f"FSCK'ing: {opts.library} on mongo {opts.host}")
    store = Arctic(get_mongodb_uri(opts.host))

    for lib in opts.library:
        # Auth to the DB for making changes
        if opts.f:
            database_name, _ = ArcticLibraryBinding._parse_db_lib(lib)

        orig_stats = store[lib].stats()

        logger.info('----------------------------')
        if not opts.n:
            store[lib]._fsck(not opts.f)
        logger.info('----------------------------')

        final_stats = store[lib].stats()
        logger.info('Stats:')
        logger.info(f'Sharded:        {final_stats['chunks'].get('sharded', False)}')
        logger.info(f'Symbols:  {len(store[lib].list_symbols()):10d}')
        logger.info(f"Versions: {final_stats['versions']['count']:10d}   Change(+/-) {final_stats['versions']['count'] - orig_stats['versions']['count']:6d}  (av: {final_stats['versions'].get('avgObjSize', 0) / 1024. / 1024.:.2f}MB)")
        logger.info(f"Versions: {final_stats['versions']['size'] / 1024. / 1024.:10.2f}MB Change(+/-) {(final_stats['versions']['size'] - orig_stats['versions']['size']) / 1024. / 1024.:.2f}MB")
        logger.info(f"Chunk Count: {final_stats['chunks']['count']:7d}   Change(+/-) {final_stats['chunks']['count'] - orig_stats['chunks']['count']:6d}  (av: {final_stats['chunks'].get('avgObjSize', 0) / 1024. / 1024.:.2f}MB)")
        logger.info(f"Chunks: {final_stats['chunks']['size'] / 1024. / 1024.:12.2f}MB Change(+/-) {(final_stats['chunks']['size'] - orig_stats['chunks']['size']) / 1024. / 1024.:6.2f}MB")
        logger.info('----------------------------')

    if not opts.f:
        logger.info("Done: DRY-RUN: No changes made. (Use -f to fix any problems)")
    else:
        logger.info("Done.")


if __name__ == '__main__':
    main()
