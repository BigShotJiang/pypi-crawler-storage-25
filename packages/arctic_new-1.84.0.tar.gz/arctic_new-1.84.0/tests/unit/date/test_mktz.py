from datetime import datetime as dt
import sys
import tzlocal
from unittest.mock import patch
from pytest import raises

from arctic.date import mktz, TimezoneError

try:
    DEFAULT_TIME_ZONE_NAME = tzlocal.get_localzone_name()
except Exception:
    local_tz = tzlocal.get_localzone()
    DEFAULT_TIME_ZONE_NAME = getattr(local_tz, 'zone', None) or getattr(local_tz, 'key', None) or str(local_tz)


def test_mktz():
    tz = mktz("Europe/London")
    d = dt(2012, 2, 2, tzinfo=tz)
    assert d.tzname() == 'GMT'
    d = dt(2012, 7, 2, tzinfo=tz)
    assert d.tzname() == 'BST'

    tz = mktz('UTC')
    d = dt(2012, 2, 2, tzinfo=tz)
    assert d.tzname() == 'UTC'
    d = dt(2012, 7, 2, tzinfo=tz)
    assert d.tzname() == 'UTC'  # --------replace_empty_timezones_with_default -----------------


def test_mktz_noarg():
    tz = mktz()
    assert DEFAULT_TIME_ZONE_NAME in str(tz)


def test_mktz_zone():
    tz = mktz('UTC')
    assert str(tz) == "UTC"
    if sys.platform.startswith("linux"):
        tz = mktz('/usr/share/zoneinfo/UTC')
        assert str(tz) == "UTC"


def test_mktz_fails_if_invalid_timezone():
    with patch('os.path.exists') as file_exists:
        file_exists.return_value = False
        with raises(TimezoneError):
            mktz('junk')
