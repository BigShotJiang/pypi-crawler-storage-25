from typing import Any, Optional

from pydantic import BaseModel, HttpUrl

from .client import SDKClient, SDKResponse


class SignRequest(BaseModel):
    thumbprint: str
    xml_file: Any
    pin: Optional[str]


class SignResponse(BaseModel):
    signedContent: str
    filename: str


class CryptoProService:
    def __init__(self, client: SDKClient):
        self._client = client

    def sign(
        self, query: SignRequest, token: str, url: HttpUrl, timeout=3
    ) -> SDKResponse[SignResponse]:
        params = {"thumbprint": query.thumbprint, "api-key": token}
        if query.pin:
            params["pin"] = query.pin
        return self._client.post(
            url + "signer",
            SignResponse,
            params=params,
            files={"file": query.xml_file},
            timeout=timeout,
        )
