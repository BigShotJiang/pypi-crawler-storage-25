__version__ = "0.5.0"
APP_TITLE = "Adbnik"
