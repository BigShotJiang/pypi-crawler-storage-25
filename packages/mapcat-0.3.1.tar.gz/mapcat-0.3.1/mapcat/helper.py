"""
Helper for mapcat database.
"""

import os
from pathlib import Path
from typing import Literal

from pydantic import PrivateAttr
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import Engine
from sqlalchemy.orm import sessionmaker
from sqlmodel import create_engine


class Settings(BaseSettings):  # pragma: no cover
    database_name: str = "mapcat.db"
    database_type: Literal["sqlite", "postgresql"] = "sqlite"

    depth_one_coadd_parent: Path = Path(os.environ.get("DEPTH_ONE_COADD_PARENT", "./"))
    depth_one_parent: Path = Path(os.environ.get("DEPTH_ONE_PARENT", "./"))
    atomic_coadd_parent: Path = Path(os.environ.get("ATOMIC_COADD_PARENT", "./"))
    atomic_parent: Path = Path(os.environ.get("ATOMIC_PARENT", "./"))

    echo: bool = False

    model_config: SettingsConfigDict = {
        "env_prefix": "mapcat_",
    }

    _engine: Engine | None = PrivateAttr(default=None)
    _sessionmaker: sessionmaker | None = PrivateAttr(default=None)

    @property
    def async_database_url(self) -> str:
        if self.database_type == "sqlite":
            return f"sqlite+aiosqlite:///{self.database_name}"
        if self.database_type == "postgresql":
            return f"postgresql+asyncpg://{self.database_name}"

    @property
    def sync_database_url(self) -> str:
        if self.database_type == "sqlite":
            return f"sqlite:///{self.database_name}"
        if self.database_type == "postgresql":
            return f"postgresql://{self.database_name}"

    @property
    def engine(self) -> Engine:
        """Create a synchronous engine."""
        if self._engine is not None:
            return self._engine
        self._engine = create_engine(self.sync_database_url, echo=self.echo)
        return self._engine

    @property
    def session(self) -> sessionmaker:
        """Create a synchronous session maker."""
        if self._sessionmaker is not None:
            return self._sessionmaker

        self._sessionmaker = sessionmaker(self.engine, expire_on_commit=False)
        return self._sessionmaker


settings = Settings()


def migrate():  # pragma: no cover
    """
    CLI script to run 'alembic upgrade head' with the correct location.
    """
    import subprocess

    from mapcat import alembic_location

    location = alembic_location

    subprocess.call(["alembic", "-c", location, "upgrade", "head"])
