"""Module for livestock farmers agent-based simulation."""

import calendar
import datetime
from typing import TYPE_CHECKING, Literal

import numpy as np
import xarray as xr

from geb.geb_types import ArrayFloat32
from geb.hydrology.HRUs import load_water_demand_xr
from geb.store import Bucket

from .general import AgentBaseClass

if TYPE_CHECKING:
    from geb.agents import Agents
    from geb.model import GEBModel


class LiveStockFarmersVariables(Bucket):
    """Variables for the LivestockFarmers agent."""

    current_water_demand: ArrayFloat32
    current_return_flow: ArrayFloat32
    last_water_demand_update: datetime.datetime


class LiveStockFarmers(AgentBaseClass):
    """This class is used to simulate livestock farmers.

    Note:
        Currently, this module is not actually agent-based but rather
        uses aggregated pre-defined water demand data.

    Args:
        model: The GEB model.
        agents: The class that includes all agent types (allowing easier communication between agents).
    """

    var: LiveStockFarmersVariables

    def __init__(
        self, model: GEBModel, agents: Agents, reduncancy: float | None
    ) -> None:
        """Initialize the LivestockFarmers agent module.

        Note that currently, this module is not actually agent-based but rather
        uses aggregated pre-defined water demand data.

        Args:
            model: The GEB model.
            agents: The class that includes all agent types (allowing easier communication between agents).
            reduncancy: Number of extra agents to use. Not used here.
        """
        super().__init__(model)

        if self.model.simulate_hydrology:
            self.HRU = model.hydrology.HRU
            self.grid = model.hydrology.grid

        self.agents = agents
        self.config = (
            self.model.config["agent_settings"]["livestock_farmers"]
            if "livestock_farmers" in self.model.config["agent_settings"]
            else {}
        )

        self.livestock_water_consumption_ds: xr.Dataset = load_water_demand_xr(
            self.model.files["other"]["water_demand/livestock_water_consumption"]
        )
        self.hydrological_year_start_month = self.model.config["general"][
            "hydrological_year_start_month"
        ]
        if self.model.in_spinup:
            self.spinup()

    @property
    def name(self) -> str:
        """The name of the module.

        Used to save data to disk.

        Returns:
            The name of the module.
        """
        return "agents.livestock_farmers"

    def spinup(self) -> None:
        """Set initial water demand values during spinup."""
        self.var.current_water_demand, self.var.current_return_flow = (
            self.update_water_demand()
        )

    def update_water_demand(self) -> tuple[ArrayFloat32, ArrayFloat32]:
        """Update the water demand for livestock farmers at the grid level.

        Returns:
            A tuple containing:
            - The current water demand as a numpy array (m/day).
            - The current return flow as a numpy array (m/day).
        """
        days_in_year: Literal[366, 365] = (
            366 if calendar.isleap(self.model.current_time.year) else 365
        )

        # transform from mio m3 per year to m3/day
        water_consumption = (
            self.livestock_water_consumption_ds.sel(
                time=self.model.current_time,
                method="ffill",
                tolerance="366D",  # ty:ignore[invalid-argument-type]
            ).livestock_water_consumption
            * 1_000_000
            / days_in_year
        )
        water_consumption = (
            water_consumption.rio.write_crs(4326).rio.reproject(
                4326,
                shape=self.model.hydrology.grid.shape,
                transform=self.model.hydrology.grid.transform,
            )
            / (
                water_consumption.rio.transform().a
                / self.model.hydrology.grid.transform.a
            )
            ** 2
        )
        water_consumption: ArrayFloat32 = self.grid.compress(water_consumption.values)

        water_demand: ArrayFloat32 = water_consumption
        water_return_flow: ArrayFloat32 = self.grid.full_compressed(0, dtype=np.float32)

        self.var.last_water_demand_update = self.model.current_time
        return water_demand, water_return_flow

    def water_demand(self) -> tuple[ArrayFloat32, ArrayFloat32]:
        """Get the current water demand for livestock farmers at the grid level.

        Updates the water demand at the start of each hydrological year.
        Otherwise, assumes the last known water demand.

        Returns:
            A tuple containing:
            - The current water demand as a numpy array (m3/day).
            - The current return flow as a numpy array (m3/day).
        """
        if (
            self.model.current_time.day == 1
            and self.model.current_time.month == self.hydrological_year_start_month
        ):
            self.var.current_water_demand, self.var.current_return_flow = (
                self.update_water_demand()
            )

        assert (
            self.model.current_time - self.var.last_water_demand_update
        ).days < 366, (
            "Water demand has not been updated for over a year. "
            "Please check the livestock water demand datasets."
        )
        return self.var.current_water_demand, self.var.current_return_flow

    def step(self) -> None:
        """This function is run each timestep."""
        self.report(locals())
