"""Allow `python -m contdoctor`."""

from contdoctor.cli import main

if __name__ == "__main__":
    main()
