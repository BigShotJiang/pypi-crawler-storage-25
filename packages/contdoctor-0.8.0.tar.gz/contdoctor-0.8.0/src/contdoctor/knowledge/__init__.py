"""Hybrid YAML knowledge: dataclass schema + loader + matcher.

Use :func:`default_symptoms` to load the catalogue shipped with the package.
"""

from importlib import resources
from pathlib import Path
from typing import List

from contdoctor.knowledge.loader import (
    KnowledgeError,
    load_symptoms,
    load_symptoms_from_string,
)
from contdoctor.knowledge.matcher import apply_symptoms
from contdoctor.knowledge.schema import Match, Op, Symptom


def default_symptoms() -> List[Symptom]:
    """Load the package-shipped ``data/symptoms.yaml`` via ``importlib.resources``."""
    pkg_files = resources.files(__package__).joinpath("data/symptoms.yaml")
    text = pkg_files.read_text(encoding="utf-8")
    return load_symptoms_from_string(text, source=str(pkg_files))


def default_symptoms_path() -> Path:
    """Filesystem path to the bundled ``symptoms.yaml`` (best-effort)."""
    pkg_files = resources.files(__package__).joinpath("data/symptoms.yaml")
    # ``files`` is a Traversable; for a regular package it is a Path on disk.
    return Path(str(pkg_files))


__all__ = [
    "Match",
    "Op",
    "Symptom",
    "KnowledgeError",
    "load_symptoms",
    "load_symptoms_from_string",
    "apply_symptoms",
    "default_symptoms",
    "default_symptoms_path",
]
