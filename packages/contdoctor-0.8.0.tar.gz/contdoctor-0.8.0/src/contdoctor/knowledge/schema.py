"""Dataclasses backing a single ``symptoms.yaml`` rule."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional, Tuple


class Op(str, Enum):
    EQUALS = "equals"
    IN_LIST = "in_list"
    CONTAINS_SUBSTRING = "contains_substring"
    MATCHES_REGEX = "matches_regex"
    GT = "gt"
    LT = "lt"
    IS_EMPTY = "is_empty"
    IS_PRESENT = "is_present"
    IS_ABSENT = "is_absent"


ALLOWED_OPS = {op.value for op in Op}
ALLOWED_SEVERITIES = {"ok", "warn", "fail"}


@dataclass(frozen=True)
class Match:
    field: str
    op: Op
    value: Any = None  # not required for is_empty / is_present / is_absent


# Fix actions that consume a ``fix.steps`` list. The loader requires steps
# for these and rejects them for every other action. The shape of each step
# differs by action:
#   * ``print_remediation`` → list[str]  (lines of copy-paste instructions)
#   * ``run_shell``         → list[ShellStep] (allowlisted exec, no shell=True)
STEPS_REQUIRED_ACTIONS = {"print_remediation", "run_shell"}


@dataclass(frozen=True)
class ShellStep:
    cmd: Tuple[str, ...]  # argv list-form; never `shell=True`
    stdout_to: Optional[str] = None
    stderr_to: Optional[str] = None
    timeout: int = 60  # capped at RUN_SHELL_MAX_TIMEOUT in fixes.shell


@dataclass(frozen=True)
class Fix:
    action: Optional[str] = None
    label: Optional[str] = None
    # ``tuple[str, ...]`` for print_remediation, ``tuple[ShellStep, ...]``
    # for run_shell. Validated at load time.
    steps: Optional[tuple] = None


@dataclass(frozen=True)
class Symptom:
    id: str
    category: str
    severity: str  # one of ALLOWED_SEVERITIES
    check: str  # CHECKS-dict key (validated at load time)
    match: Match
    diagnosis: str
    fix: Fix = field(default_factory=Fix)
    date_added: Optional[str] = None
    references: tuple = ()
    superseded_by: Optional[str] = None


__all__ = [
    "Op",
    "ALLOWED_OPS",
    "ALLOWED_SEVERITIES",
    "STEPS_REQUIRED_ACTIONS",
    "Match",
    "Fix",
    "ShellStep",
    "Symptom",
]
