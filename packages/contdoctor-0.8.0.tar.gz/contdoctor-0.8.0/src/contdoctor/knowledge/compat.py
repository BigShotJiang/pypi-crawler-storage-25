"""Codent ↔ contdoctor compatibility matrix loader and matcher.

The matrix lives in :mod:`contdoctor.data.compat` (YAML, not code) so a new
codent release adds one row, no Python edits needed. This module loads the
matrix and answers the single question: *is the codent currently installed
on this machine compatible with the contdoctor we're running?*

No external dependencies — version comparison uses a simple tuple-of-ints
parse. Pre-release / post-release / local segments are dropped (they don't
appear in the deployment matrix anyway).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from importlib import resources
from typing import List, Optional, Tuple

import yaml

CURRENT_COMPAT_SCHEMA_VERSION = 1


class CompatError(ValueError):
    """Raised when the compat matrix is malformed."""


@dataclass(frozen=True)
class CompatEntry:
    codent_min: str
    contdoctor_compatible_with: str  # PEP 440-like comma-list: ">=0.1.0,<0.2.0"
    note: Optional[str] = None


def _parse_version(v: str) -> Tuple[int, ...]:
    """Strip pre/post/local tags and return a tuple of ints.

    Examples:
        "1.2.3"       -> (1, 2, 3)
        "0.4.2"       -> (0, 4, 2)
        "1.0a1"       -> (1, 0)
        "0.4.1.post1" -> (0, 4, 1)
    """
    # Pull leading dotted-numbers segment only.
    m = re.match(r"^(\d+(?:\.\d+)*)", v.strip())
    if not m:
        raise CompatError(f"unparseable version: {v!r}")
    return tuple(int(p) for p in m.group(1).split("."))


_RANGE_RE = re.compile(r"\s*(>=|<=|>|<|==|!=)\s*([0-9][0-9a-zA-Z.+\-]*)\s*")


def _check_range(version: str, spec: str) -> bool:
    """True iff ``version`` satisfies the comma-separated range ``spec``.

    Supported operators: ``>=``, ``<=``, ``>``, ``<``, ``==``, ``!=``.
    """
    target = _parse_version(version)
    parts = [p for p in spec.split(",") if p.strip()]
    if not parts:
        raise CompatError(f"empty range spec: {spec!r}")
    for part in parts:
        m = _RANGE_RE.fullmatch(part)
        if not m:
            raise CompatError(f"invalid range clause: {part!r}")
        op, raw = m.group(1), m.group(2)
        bound = _parse_version(raw)
        if op == ">=" and not target >= bound:
            return False
        if op == "<=" and not target <= bound:
            return False
        if op == ">" and not target > bound:
            return False
        if op == "<" and not target < bound:
            return False
        if op == "==" and not target == bound:
            return False
        if op == "!=" and not target != bound:
            return False
    return True


def load_compat(text: Optional[str] = None) -> List[CompatEntry]:
    """Parse compat YAML. ``text=None`` loads the package-shipped file."""
    if text is None:
        text = resources.files("contdoctor.data").joinpath("compat.yaml").read_text(
            encoding="utf-8"
        )
    try:
        doc = yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise CompatError(f"compat.yaml: parse error: {e}") from e
    if not isinstance(doc, dict):
        raise CompatError("compat.yaml: top-level must be a mapping")
    if doc.get("version") != CURRENT_COMPAT_SCHEMA_VERSION:
        raise CompatError(
            f"compat.yaml: unsupported version {doc.get('version')!r} "
            f"(expected {CURRENT_COMPAT_SCHEMA_VERSION})"
        )
    rows = doc.get("codent_compat")
    if not isinstance(rows, list):
        raise CompatError("compat.yaml: 'codent_compat' must be a list")
    out: List[CompatEntry] = []
    for idx, raw in enumerate(rows):
        if not isinstance(raw, dict):
            raise CompatError(f"compat.yaml: row {idx} must be a mapping")
        try:
            entry = CompatEntry(
                codent_min=str(raw["codent_min"]),
                contdoctor_compatible_with=str(raw["contdoctor_compatible_with"]),
                note=raw.get("note"),
            )
        except KeyError as e:
            raise CompatError(f"compat.yaml: row {idx}: missing field {e}") from e
        # Validate fields parse cleanly so we fail at load, not at lookup.
        _parse_version(entry.codent_min)
        _check_range(entry.codent_min, entry.contdoctor_compatible_with)
        out.append(entry)
    return out


def is_codent_compatible(
    codent_version: str,
    contdoctor_version: str,
    entries: Optional[List[CompatEntry]] = None,
) -> Tuple[bool, Optional[str]]:
    """Return ``(compatible, note_or_reason)``.

    Multi-match: every entry whose ``codent_min`` ≤ ``codent_version`` is
    eligible. If *any* eligible entry's ``contdoctor_compatible_with``
    accepts ``contdoctor_version``, the install is compatible. This lets
    the matrix express "codent X works with contdoctor 0.1.x AND 0.2.x"
    by adding a second row at the same ``codent_min``.

    If no eligible entry accepts the contdoctor version, the failure
    reason is built from the highest-``codent_min`` eligible row (most
    specific guidance). If no row is eligible at all, codent is older
    than the earliest tracked release.
    """
    if entries is None:
        entries = load_compat()
    if not entries:
        return False, "compat matrix is empty"
    target = _parse_version(codent_version)
    eligible: List[CompatEntry] = [
        e for e in entries if target >= _parse_version(e.codent_min)
    ]
    if not eligible:
        return False, (
            f"codent {codent_version} is older than the earliest tracked "
            f"release ({entries[0].codent_min})"
        )
    for entry in eligible:
        if _check_range(contdoctor_version, entry.contdoctor_compatible_with):
            return True, entry.note
    eligible.sort(key=lambda e: _parse_version(e.codent_min), reverse=True)
    best = eligible[0]
    return False, (
        f"codent {codent_version} expects contdoctor "
        f"{best.contdoctor_compatible_with}, "
        f"but {contdoctor_version} is installed"
        + (f" — {best.note}" if best.note else "")
    )


def min_codent_for(
    contdoctor_version: str,
    entries: Optional[List[CompatEntry]] = None,
) -> Optional[str]:
    """Smallest ``codent_min`` whose range accepts ``contdoctor_version``.

    Used when reporting drift: tells the user the minimum codent they need
    to upgrade to in order to satisfy the contdoctor they have installed.
    """
    if entries is None:
        entries = load_compat()
    candidates: List[Tuple[Tuple[int, ...], str]] = []
    for entry in entries:
        try:
            if _check_range(contdoctor_version, entry.contdoctor_compatible_with):
                candidates.append((_parse_version(entry.codent_min), entry.codent_min))
        except CompatError:
            continue
    if not candidates:
        return None
    candidates.sort()
    return candidates[0][1]


__all__ = [
    "CompatError",
    "CompatEntry",
    "CURRENT_COMPAT_SCHEMA_VERSION",
    "load_compat",
    "is_codent_compatible",
    "min_codent_for",
]
