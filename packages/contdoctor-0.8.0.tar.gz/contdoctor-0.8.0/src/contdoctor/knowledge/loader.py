"""YAML → ``list[Symptom]``. Strict validation; any breakage raises.

The doctor must fail loud on a broken catalogue: silent skipping turns a
single broken rule into invisible rot.
"""

import re
from pathlib import Path
from typing import List, Optional, Set

import yaml

from contdoctor.knowledge.schema import (
    ALLOWED_OPS,
    ALLOWED_SEVERITIES,
    STEPS_REQUIRED_ACTIONS,
    Fix,
    Match,
    Op,
    ShellStep,
    Symptom,
)

CURRENT_SCHEMA_VERSION = 1
_ID_RE = re.compile(r"^[a-z0-9_]+$")
_MAX_ID_LEN = 64


class KnowledgeError(ValueError):
    """Raised whenever the catalogue is malformed or references unknowns."""


def load_symptoms(
    path: Path,
    *,
    valid_check_keys: Optional[Set[str]] = None,
    valid_fix_actions: Optional[Set[str]] = None,
) -> List[Symptom]:
    """Read and validate ``path``. See :func:`load_symptoms_from_string`."""
    text = Path(path).read_text(encoding="utf-8")
    return load_symptoms_from_string(
        text,
        source=str(path),
        valid_check_keys=valid_check_keys,
        valid_fix_actions=valid_fix_actions,
    )


def load_symptoms_from_string(
    text: str,
    *,
    source: str = "<string>",
    valid_check_keys: Optional[Set[str]] = None,
    valid_fix_actions: Optional[Set[str]] = None,
) -> List[Symptom]:
    """Parse YAML ``text`` into Symptom objects with strict validation.

    ``valid_check_keys`` and ``valid_fix_actions`` are looked up lazily from
    the runner / fixes registries when not provided so this function is
    usable both at runtime and in unit tests with custom registries.
    """
    if valid_check_keys is None:
        from contdoctor.core.runner import CHECKS

        valid_check_keys = set(CHECKS.keys())
    if valid_fix_actions is None:
        from contdoctor.fixes import FIX_ACTIONS

        valid_fix_actions = set(FIX_ACTIONS.keys())

    try:
        doc = yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise KnowledgeError(f"{source}: YAML parse error: {e}") from e

    if not isinstance(doc, dict):
        raise KnowledgeError(f"{source}: top-level must be a mapping, got {type(doc).__name__}")

    version = doc.get("version")
    if version != CURRENT_SCHEMA_VERSION:
        raise KnowledgeError(
            f"{source}: unsupported schema version {version!r} "
            f"(expected {CURRENT_SCHEMA_VERSION})"
        )

    raw_symptoms = doc.get("symptoms")
    if not isinstance(raw_symptoms, list):
        raise KnowledgeError(f"{source}: 'symptoms' must be a list")

    seen: Set[str] = set()
    symptoms: List[Symptom] = []

    for idx, raw in enumerate(raw_symptoms):
        loc = f"{source}#symptoms[{idx}]"
        if not isinstance(raw, dict):
            raise KnowledgeError(f"{loc}: must be a mapping")
        sym = _parse_symptom(raw, loc, valid_check_keys, valid_fix_actions)
        if sym.id in seen:
            raise KnowledgeError(f"{loc}: duplicate id {sym.id!r}")
        seen.add(sym.id)
        symptoms.append(sym)

    return symptoms


# ─── Internal helpers ──────────────────────────────────────────────────────


def _parse_symptom(
    raw: dict,
    loc: str,
    valid_check_keys: Set[str],
    valid_fix_actions: Set[str],
) -> Symptom:
    sid = _require(raw, "id", str, loc)
    if not _ID_RE.match(sid):
        raise KnowledgeError(f"{loc}: id must be snake_case (got {sid!r})")
    if len(sid) > _MAX_ID_LEN:
        raise KnowledgeError(f"{loc}: id exceeds {_MAX_ID_LEN} chars")

    severity = _require(raw, "severity", str, loc)
    if severity not in ALLOWED_SEVERITIES:
        raise KnowledgeError(
            f"{loc}: severity must be one of {sorted(ALLOWED_SEVERITIES)}, got {severity!r}"
        )

    category = _require(raw, "category", str, loc)
    diagnosis = _require(raw, "diagnosis", str, loc)

    triggered_by = _require(raw, "triggered_by", dict, loc)
    check_key = _require(triggered_by, "check", str, f"{loc}.triggered_by")
    if check_key not in valid_check_keys:
        raise KnowledgeError(
            f"{loc}.triggered_by.check: unknown check key {check_key!r} "
            f"(allowed: {sorted(valid_check_keys)})"
        )

    raw_match = _require(triggered_by, "match", dict, f"{loc}.triggered_by")
    match = _parse_match(raw_match, f"{loc}.triggered_by.match")

    raw_fix = raw.get("fix")
    fix = Fix()
    if raw_fix is not None:
        if not isinstance(raw_fix, dict):
            raise KnowledgeError(f"{loc}.fix: must be a mapping")
        action = raw_fix.get("action")
        if action is not None:
            if not isinstance(action, str):
                raise KnowledgeError(f"{loc}.fix.action: must be a string")
            if action not in valid_fix_actions:
                raise KnowledgeError(
                    f"{loc}.fix.action: unknown action {action!r} "
                    f"(allowed: {sorted(valid_fix_actions)})"
                )
        label = raw_fix.get("label")
        if label is not None and not isinstance(label, str):
            raise KnowledgeError(f"{loc}.fix.label: must be a string")
        steps_raw = raw_fix.get("steps")
        steps_tuple: Optional[tuple] = None
        if steps_raw is not None:
            if not isinstance(steps_raw, list) or not steps_raw:
                raise KnowledgeError(
                    f"{loc}.fix.steps: must be a non-empty list"
                )
            steps_tuple = _parse_steps_for_action(steps_raw, action, f"{loc}.fix.steps")
        if action in STEPS_REQUIRED_ACTIONS and steps_tuple is None:
            raise KnowledgeError(
                f"{loc}.fix: action {action!r} requires 'steps' field"
            )
        if action not in STEPS_REQUIRED_ACTIONS and steps_tuple is not None:
            raise KnowledgeError(
                f"{loc}.fix: action {action!r} does not accept 'steps' field "
                f"(only {sorted(STEPS_REQUIRED_ACTIONS)} do)"
            )
        fix = Fix(action=action, label=label, steps=steps_tuple)

    refs_raw = raw.get("references", [])
    if refs_raw is None:
        refs: tuple = ()
    elif isinstance(refs_raw, list) and all(isinstance(x, str) for x in refs_raw):
        refs = tuple(refs_raw)
    else:
        raise KnowledgeError(f"{loc}.references: must be a list of strings")

    superseded_by = raw.get("superseded_by")
    if superseded_by is not None and not isinstance(superseded_by, str):
        raise KnowledgeError(f"{loc}.superseded_by: must be a string")

    date_added = raw.get("date_added")
    if date_added is not None and not isinstance(date_added, str):
        raise KnowledgeError(f"{loc}.date_added: must be a string")

    return Symptom(
        id=sid,
        category=category,
        severity=severity,
        check=check_key,
        match=match,
        diagnosis=diagnosis,
        fix=fix,
        date_added=date_added,
        references=refs,
        superseded_by=superseded_by,
    )


def _parse_steps_for_action(
    raw_steps: list, action: Optional[str], loc: str
) -> tuple:
    """Validate ``raw_steps`` against the shape expected for ``action``.

      * ``print_remediation`` → ``list[str]``
      * ``run_shell``         → ``list[dict]`` with ``cmd: list[str]`` plus
                                 optional ``stdout_to``/``stderr_to``/``timeout``
    """
    if action == "run_shell":
        if not all(isinstance(s, dict) for s in raw_steps):
            raise KnowledgeError(
                f"{loc}: run_shell steps must be mappings (with 'cmd' list)"
            )
        parsed: list[ShellStep] = []
        for idx, raw in enumerate(raw_steps):
            step_loc = f"{loc}[{idx}]"
            if "cmd" not in raw:
                raise KnowledgeError(f"{step_loc}: 'cmd' is required")
            cmd_raw = raw["cmd"]
            if (
                not isinstance(cmd_raw, list)
                or not cmd_raw
                or not all(isinstance(c, str) for c in cmd_raw)
            ):
                raise KnowledgeError(
                    f"{step_loc}.cmd: must be a non-empty list of strings"
                )
            stdout_to = raw.get("stdout_to")
            if stdout_to is not None and not isinstance(stdout_to, str):
                raise KnowledgeError(f"{step_loc}.stdout_to: must be a string")
            stderr_to = raw.get("stderr_to")
            if stderr_to is not None and not isinstance(stderr_to, str):
                raise KnowledgeError(f"{step_loc}.stderr_to: must be a string")
            timeout_raw = raw.get("timeout", 60)
            if not isinstance(timeout_raw, int) or timeout_raw <= 0:
                raise KnowledgeError(
                    f"{step_loc}.timeout: must be a positive integer (got {timeout_raw!r})"
                )
            allowed_keys = {"cmd", "stdout_to", "stderr_to", "timeout"}
            extras = set(raw) - allowed_keys
            if extras:
                raise KnowledgeError(
                    f"{step_loc}: unknown fields {sorted(extras)} "
                    f"(allowed: {sorted(allowed_keys)})"
                )
            parsed.append(
                ShellStep(
                    cmd=tuple(cmd_raw),
                    stdout_to=stdout_to,
                    stderr_to=stderr_to,
                    timeout=timeout_raw,
                )
            )
        return tuple(parsed)

    # Default (print_remediation and any future string-list action).
    if not all(isinstance(s, str) for s in raw_steps):
        raise KnowledgeError(
            f"{loc}: must be a non-empty list of strings for action {action!r}"
        )
    return tuple(raw_steps)


def _parse_match(raw: dict, loc: str) -> Match:
    field = _require(raw, "field", str, loc)
    if "[" in field or "]" in field:
        raise KnowledgeError(
            f"{loc}.field: index syntax (e.g. 'foo[0]') is not supported, got {field!r}"
        )
    op_str = _require(raw, "op", str, loc)
    if op_str not in ALLOWED_OPS:
        raise KnowledgeError(
            f"{loc}.op: unknown op {op_str!r} (allowed: {sorted(ALLOWED_OPS)})"
        )
    op = Op(op_str)

    if op in {Op.IS_EMPTY, Op.IS_PRESENT, Op.IS_ABSENT}:
        # Value is ignored; we still allow but normalise to None.
        value = None
    else:
        if "value" not in raw:
            raise KnowledgeError(f"{loc}: 'value' is required for op {op_str!r}")
        value = raw["value"]
        if op == Op.IN_LIST and not isinstance(value, list):
            raise KnowledgeError(f"{loc}.value: in_list requires a list, got {type(value).__name__}")
        if op in {Op.GT, Op.LT} and not isinstance(value, (int, float)):
            raise KnowledgeError(f"{loc}.value: {op_str} requires a number")
        if op == Op.MATCHES_REGEX:
            if not isinstance(value, str):
                raise KnowledgeError(f"{loc}.value: matches_regex requires a string pattern")
            try:
                re.compile(value)
            except re.error as e:
                raise KnowledgeError(f"{loc}.value: invalid regex: {e}") from e

    return Match(field=field, op=op, value=value)


def _require(d: dict, key: str, expected_type: type, loc: str):
    if key not in d:
        raise KnowledgeError(f"{loc}: missing required field {key!r}")
    v = d[key]
    if not isinstance(v, expected_type):
        raise KnowledgeError(
            f"{loc}.{key}: expected {expected_type.__name__}, got {type(v).__name__}"
        )
    return v


__all__ = [
    "CURRENT_SCHEMA_VERSION",
    "KnowledgeError",
    "load_symptoms",
    "load_symptoms_from_string",
]
