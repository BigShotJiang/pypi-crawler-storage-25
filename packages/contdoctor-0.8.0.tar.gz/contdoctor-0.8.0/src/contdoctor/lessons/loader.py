"""YAML → ``list[Lesson]``. Strict severity, yumuşak field kabul."""

from __future__ import annotations

from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import List, Optional

import yaml

DEFAULT_LESSONS_PATH = "~/.contdoctor/lessons.yaml"
EXAMPLE_LESSONS_RESOURCE = "lessons.example.yaml"

ALLOWED_SEVERITIES = ("critical", "high", "medium")
_SEVERITY_RANK = {sev: i for i, sev in enumerate(ALLOWED_SEVERITIES)}


class LessonsError(ValueError):
    """Raised when the lessons YAML is malformed."""


@dataclass(frozen=True)
class Lesson:
    id: str
    severity: str
    title: str
    next_action: str = ""
    evidence: str = ""
    diagnostic_pattern: str = ""
    date_added: Optional[str] = None


def _parse_lesson(raw: dict, idx: int) -> Lesson:
    if not isinstance(raw, dict):
        raise LessonsError(f"lessons[{idx}]: must be a mapping")
    sid = raw.get("id")
    if not isinstance(sid, str) or not sid:
        raise LessonsError(f"lessons[{idx}].id required")
    severity = raw.get("severity")
    if severity not in ALLOWED_SEVERITIES:
        raise LessonsError(
            f"lessons[{idx}].severity must be one of {ALLOWED_SEVERITIES}, "
            f"got {severity!r}"
        )
    title = raw.get("title")
    if not isinstance(title, str) or not title:
        raise LessonsError(f"lessons[{idx}].title required")
    return Lesson(
        id=sid,
        severity=severity,
        title=title,
        next_action=str(raw.get("next_action", "") or ""),
        evidence=str(raw.get("evidence", "") or ""),
        diagnostic_pattern=str(raw.get("diagnostic_pattern", "") or ""),
        date_added=raw.get("date_added") if raw.get("date_added") else None,
    )


def _parse_lessons_doc(doc) -> List[Lesson]:
    if not isinstance(doc, dict):
        raise LessonsError("lessons top-level must be a mapping")
    version = doc.get("version", 1)
    if version != 1:
        raise LessonsError(f"unsupported lessons version {version!r} (expected 1)")
    raw_list = doc.get("lessons", [])
    if not isinstance(raw_list, list):
        raise LessonsError("'lessons' must be a list")
    out: List[Lesson] = []
    seen: set = set()
    for idx, raw in enumerate(raw_list):
        lesson = _parse_lesson(raw, idx)
        if lesson.id in seen:
            raise LessonsError(f"duplicate lesson id {lesson.id!r}")
        seen.add(lesson.id)
        out.append(lesson)
    return out


def _sort_by_severity(lessons: List[Lesson]) -> List[Lesson]:
    return sorted(lessons, key=lambda l: (_SEVERITY_RANK[l.severity], l.id))


def load_lessons(path: Optional[str] = None) -> List[Lesson]:
    """Load lessons from ``path`` (default ``~/.contdoctor/lessons.yaml``).

    Raises ``FileNotFoundError`` if the file does not exist; the CLI
    layer catches this and shows the example path hint.
    """
    p = Path(path or DEFAULT_LESSONS_PATH).expanduser()
    if not p.is_file():
        raise FileNotFoundError(p)
    try:
        text = p.read_text(encoding="utf-8")
    except OSError as e:
        raise LessonsError(f"lessons read error: {e}") from e
    try:
        doc = yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise LessonsError(f"lessons YAML parse error: {e}") from e
    return _sort_by_severity(_parse_lessons_doc(doc))


def load_example_lessons() -> List[Lesson]:
    """Load the package-shipped example lessons (for ``--lessons``
    fallback when the user hasn't created their own file)."""
    pkg = resources.files("contdoctor.data").joinpath(EXAMPLE_LESSONS_RESOURCE)
    text = pkg.read_text(encoding="utf-8")
    doc = yaml.safe_load(text)
    return _sort_by_severity(_parse_lessons_doc(doc))


def example_lessons_path() -> str:
    """Filesystem path for the example resource (for hint messages)."""
    pkg = resources.files("contdoctor.data").joinpath(EXAMPLE_LESSONS_RESOURCE)
    return str(pkg)


__all__ = [
    "ALLOWED_SEVERITIES",
    "DEFAULT_LESSONS_PATH",
    "EXAMPLE_LESSONS_RESOURCE",
    "Lesson",
    "LessonsError",
    "load_lessons",
    "load_example_lessons",
    "example_lessons_path",
]
