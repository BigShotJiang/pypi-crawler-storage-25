"""Lessons — proje boyunca kazanılmış kalıcı öğretiler.

Sprint 8 (revised): doctor lessons.yaml'ı **veri** olarak okur, **mantık**
olarak kullanmaz. Auto-fix mekanizması symptoms.yaml + matcher'da; lessons
sadece insan-okur narrative + drift check çıktısında id referansı.

Default path: ``~/.contdoctor/lessons.yaml``. Yoksa
``contdoctor.data.lessons.example.yaml`` paket içinden gösterilir.
"""

from contdoctor.lessons.loader import (
    DEFAULT_LESSONS_PATH,
    EXAMPLE_LESSONS_RESOURCE,
    Lesson,
    LessonsError,
    load_example_lessons,
    load_lessons,
)

__all__ = [
    "DEFAULT_LESSONS_PATH",
    "EXAMPLE_LESSONS_RESOURCE",
    "Lesson",
    "LessonsError",
    "load_lessons",
    "load_example_lessons",
]
