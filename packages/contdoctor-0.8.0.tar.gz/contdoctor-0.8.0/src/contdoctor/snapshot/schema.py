"""Dataclass schema for the environment snapshot YAML."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

CURRENT_SNAPSHOT_VERSION = 1


@dataclass
class WorkloadBaseline:
    """Sprint 9.2: sağlıklı state'te realistic workload metric'leri.

    Drift detection için baseline; ``check_realistic_workload`` çıktısı
    bu değerlerle karşılaştırılabilir. ``measured_at`` ISO timestamp.
    """
    eval_tokens_per_sec: float = 0.0
    prompt_eval_tokens_per_sec: float = 0.0
    measured_at: str = ""


@dataclass
class OllamaSnapshot:
    binary_path: str = ""
    version: str = ""
    size_bytes: int = 0
    # Sprint 9: snapshot çalışan process'ten alındıysa True. Custom-launched
    # setup'ı tespit etmek için kanıt.
    is_running: bool = False
    detected_via: str = ""  # "pgrep+/proc" | "PATH" | ""
    # Sprint 9.2: realistic workload baseline (sağlıklı state'te kaydedildi).
    workload_baseline: Optional[WorkloadBaseline] = None


@dataclass
class GpuSnapshot:
    driver_version: Optional[str] = None


@dataclass
class ModelSnapshot:
    name: str
    digest: str = ""
    size: int = 0


@dataclass
class RunnerLibSnapshot:
    path: str
    files: List[str] = field(default_factory=list)


@dataclass
class Snapshot:
    version: int = CURRENT_SNAPSHOT_VERSION
    created_at: str = ""
    created_by_contdoctor: str = ""
    label: Optional[str] = None
    # Sprint 8 (revised) — environment fingerprint + role hint. Snapshot
    # hangi makineden alındı? Drift check başka makinenin snapshot'ını
    # reddetmek için bunu kullanır.
    fingerprint: Optional["EnvironmentFingerprint"] = None
    role_hint: str = "unknown"
    ollama: OllamaSnapshot = field(default_factory=OllamaSnapshot)
    gpu: GpuSnapshot = field(default_factory=GpuSnapshot)
    models: List[ModelSnapshot] = field(default_factory=list)
    env: dict = field(default_factory=dict)
    runner_libraries: List[RunnerLibSnapshot] = field(default_factory=list)


# Late-import resolution for the EnvironmentFingerprint forward reference.
from contdoctor.snapshot.fingerprint import EnvironmentFingerprint  # noqa: E402,F401


__all__ = [
    "CURRENT_SNAPSHOT_VERSION",
    "OllamaSnapshot",
    "GpuSnapshot",
    "ModelSnapshot",
    "RunnerLibSnapshot",
    "Snapshot",
    "WorkloadBaseline",
]
