"""Environment fingerprint — Sprint 8 (revised) host kimliği.

Snapshot'ın hangi makineden alındığını bağlamak için tek bir kompakt
deşifrelenebilir kayıt. Hash'lemiyoruz; her field açıkça karşılaştırılabilir
olsun (drift mesajı hangi alanın değiştiğini söyleyebilsin).

Banka kuralı: hostname insan-okur, başka kimlik bilgisi (IP, MAC, vb.)
toplanmaz. ``role.txt`` override insan kararı.
"""

from __future__ import annotations

import os
import platform
import re
import socket
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from contdoctor.core.proc import run as _run

ROLE_OVERRIDE_PATH = "~/.contdoctor/role.txt"

VALID_ROLES = frozenset({"dev", "prod-shared", "prod", "unknown"})


@dataclass
class EnvironmentFingerprint:
    hostname: str = ""
    user: str = ""
    os_release: str = ""
    kernel: str = ""
    is_wsl: bool = False
    cuda_driver: Optional[str] = None
    gpu_name: Optional[str] = None
    cwd_mount: str = "/"
    python_executable: str = ""


def _read_os_release() -> str:
    """``/etc/os-release`` ``PRETTY_NAME`` veya boş."""
    try:
        text = Path("/etc/os-release").read_text(errors="replace")
    except OSError:
        return ""
    for line in text.splitlines():
        if line.startswith("PRETTY_NAME="):
            value = line.split("=", 1)[1].strip().strip('"').strip("'")
            return value
    return ""


def _detect_wsl() -> bool:
    """WSL detection via ``/proc/version``."""
    try:
        text = Path("/proc/version").read_text(errors="replace")
    except OSError:
        return False
    return "microsoft" in text.lower()


def _cwd_mount_root() -> str:
    """Return the closest mount point ancestor of CWD.

    Heuristic: walk parents until a Path's ``stat().st_dev`` differs
    from CWD — but ``stat`` may need permission. Fall back to "/" when
    we can't decide. ``/mnt/<x>`` shared mounts are detected explicitly.
    """
    try:
        cwd = Path.cwd().resolve()
    except OSError:
        return "/"
    parts = cwd.parts
    if len(parts) >= 3 and parts[1] == "mnt":
        return "/" + "/".join(parts[1:3])  # /mnt/<x>
    try:
        cwd_dev = cwd.stat().st_dev
    except OSError:
        return "/"
    current = cwd
    while current != current.parent:
        parent = current.parent
        try:
            if parent.stat().st_dev != cwd_dev:
                return str(current)
        except OSError:
            break
        current = parent
    return "/"


def _gpu_info() -> tuple[Optional[str], Optional[str]]:
    """``(driver_version, first_gpu_name)`` from ``nvidia-smi`` (None if unavailable)."""
    rc, out, _ = _run(
        ["nvidia-smi", "--query-gpu=driver_version,name", "--format=csv,noheader"],
        timeout=10,
    )
    if rc != 0 or not out.strip():
        return None, None
    line = out.strip().splitlines()[0]
    parts = [p.strip() for p in line.split(",")]
    if len(parts) < 2:
        return None, None
    return parts[0] or None, parts[1] or None


def compute_fingerprint() -> EnvironmentFingerprint:
    """Materialise current host fingerprint. Read-only."""
    import sys

    cuda, gpu = _gpu_info()
    return EnvironmentFingerprint(
        hostname=socket.gethostname(),
        user=os.environ.get("USER", os.environ.get("USERNAME", "")),
        os_release=_read_os_release(),
        kernel=platform.release(),
        is_wsl=_detect_wsl(),
        cuda_driver=cuda,
        gpu_name=gpu,
        cwd_mount=_cwd_mount_root(),
        python_executable=sys.executable,
    )


def _read_role_override() -> Optional[str]:
    p = Path(ROLE_OVERRIDE_PATH).expanduser()
    try:
        if not p.is_file():
            return None
        text = p.read_text(errors="replace").strip().splitlines()[0].strip()
    except (OSError, IndexError):
        return None
    if text in VALID_ROLES:
        return text
    return None


def guess_role(fp: EnvironmentFingerprint) -> str:
    """Heuristic role hint. ``role.txt`` override önceliklidir.

    Heuristics:
      * ``role.txt`` mevcut + valid → o değer
      * ``is_wsl=True`` → ``dev``
      * ``cwd_mount.startswith("/mnt/")`` ve WSL değil → ``prod-shared``
      * else ``unknown``
    """
    override = _read_role_override()
    if override is not None:
        return override
    if fp.is_wsl:
        return "dev"
    if fp.cwd_mount.startswith("/mnt/"):
        return "prod-shared"
    return "unknown"


__all__ = [
    "EnvironmentFingerprint",
    "ROLE_OVERRIDE_PATH",
    "VALID_ROLES",
    "compute_fingerprint",
    "guess_role",
]
