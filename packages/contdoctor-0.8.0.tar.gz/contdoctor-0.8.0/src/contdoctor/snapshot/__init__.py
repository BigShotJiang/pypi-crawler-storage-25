"""Environment snapshot — Sprint 8 read-only drift detection layer.

The snapshot is a YAML dump of the *known-good* environment state
(ollama version + binary size, GPU driver, model digests, env vars,
runner library paths). It is created **manually** with
``contdoctor --save-snapshot`` while the system is healthy; ``check_
environment_drift`` later compares it against current state.

Banka kuralı: doctor environment'ı **değiştirmez**. Drift bulgusu
information; restore Sertan'ın elinde.
"""

from contdoctor.snapshot.builder import build_snapshot, save_snapshot
from contdoctor.snapshot.fingerprint import (
    EnvironmentFingerprint,
    compute_fingerprint,
    guess_role,
)
from contdoctor.snapshot.loader import (
    SnapshotError,
    load_snapshot,
    parse_snapshot_dict,
)
from contdoctor.snapshot.schema import (
    GpuSnapshot,
    ModelSnapshot,
    OllamaSnapshot,
    Snapshot,
)

__all__ = [
    "Snapshot",
    "OllamaSnapshot",
    "GpuSnapshot",
    "ModelSnapshot",
    "EnvironmentFingerprint",
    "compute_fingerprint",
    "guess_role",
    "build_snapshot",
    "save_snapshot",
    "load_snapshot",
    "parse_snapshot_dict",
    "SnapshotError",
]
