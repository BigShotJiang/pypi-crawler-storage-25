"""YAML → :class:`Snapshot`. Strict-but-tolerant: unknown keys ignored,
missing keys default; obviously wrong types raise ``SnapshotError``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from contdoctor.snapshot.fingerprint import EnvironmentFingerprint
from contdoctor.snapshot.schema import (
    CURRENT_SNAPSHOT_VERSION,
    GpuSnapshot,
    ModelSnapshot,
    OllamaSnapshot,
    RunnerLibSnapshot,
    Snapshot,
    WorkloadBaseline,
)


class SnapshotError(ValueError):
    """Raised when the snapshot YAML is malformed or wrong-type."""


def _require_dict(v: Any, where: str) -> dict:
    if v is None:
        return {}
    if not isinstance(v, dict):
        raise SnapshotError(f"{where}: expected mapping, got {type(v).__name__}")
    return v


def _parse_workload_baseline(raw: Any) -> WorkloadBaseline | None:
    if raw is None:
        return None
    if not isinstance(raw, dict):
        raise SnapshotError("ollama.workload_baseline must be a mapping")
    return WorkloadBaseline(
        eval_tokens_per_sec=float(raw.get("eval_tokens_per_sec", 0.0) or 0.0),
        prompt_eval_tokens_per_sec=float(
            raw.get("prompt_eval_tokens_per_sec", 0.0) or 0.0
        ),
        measured_at=str(raw.get("measured_at", "")),
    )


def parse_snapshot_dict(raw: Any) -> Snapshot:
    if not isinstance(raw, dict):
        raise SnapshotError("snapshot top-level must be a mapping")

    version = raw.get("version", 1)
    if not isinstance(version, int):
        raise SnapshotError(f"version must be int, got {type(version).__name__}")
    if version != CURRENT_SNAPSHOT_VERSION:
        raise SnapshotError(
            f"unsupported snapshot version {version} (expected {CURRENT_SNAPSHOT_VERSION})"
        )

    ollama_raw = _require_dict(raw.get("ollama"), "ollama")
    gpu_raw = _require_dict(raw.get("gpu"), "gpu")
    env_raw = _require_dict(raw.get("env"), "env")

    models_raw = raw.get("models", [])
    if not isinstance(models_raw, list):
        raise SnapshotError("models must be a list")
    models = []
    for idx, m in enumerate(models_raw):
        m = _require_dict(m, f"models[{idx}]")
        name = m.get("name")
        if not isinstance(name, str) or not name:
            raise SnapshotError(f"models[{idx}].name required")
        models.append(
            ModelSnapshot(
                name=name,
                digest=str(m.get("digest", "")),
                size=int(m.get("size", 0) or 0),
            )
        )

    runners_raw = raw.get("runner_libraries", [])
    if not isinstance(runners_raw, list):
        raise SnapshotError("runner_libraries must be a list")
    runners = []
    for idx, r in enumerate(runners_raw):
        r = _require_dict(r, f"runner_libraries[{idx}]")
        path = r.get("path")
        if not isinstance(path, str) or not path:
            raise SnapshotError(f"runner_libraries[{idx}].path required")
        files = r.get("files", [])
        if not isinstance(files, list) or not all(isinstance(f, str) for f in files):
            raise SnapshotError(f"runner_libraries[{idx}].files must be list[str]")
        runners.append(RunnerLibSnapshot(path=path, files=list(files)))

    fp_raw = raw.get("fingerprint")
    fingerprint: Any = None
    if fp_raw is not None:
        fp_dict = _require_dict(fp_raw, "fingerprint")
        fingerprint = EnvironmentFingerprint(
            hostname=str(fp_dict.get("hostname", "")),
            user=str(fp_dict.get("user", "")),
            os_release=str(fp_dict.get("os_release", "")),
            kernel=str(fp_dict.get("kernel", "")),
            is_wsl=bool(fp_dict.get("is_wsl", False)),
            cuda_driver=(
                str(fp_dict["cuda_driver"])
                if fp_dict.get("cuda_driver") is not None
                else None
            ),
            gpu_name=(
                str(fp_dict["gpu_name"])
                if fp_dict.get("gpu_name") is not None
                else None
            ),
            cwd_mount=str(fp_dict.get("cwd_mount", "/")),
            python_executable=str(fp_dict.get("python_executable", "")),
        )

    role_hint = str(raw.get("role_hint", "unknown"))

    return Snapshot(
        version=version,
        created_at=str(raw.get("created_at", "")),
        created_by_contdoctor=str(raw.get("created_by_contdoctor", "")),
        label=raw.get("label") if raw.get("label") is not None else None,
        fingerprint=fingerprint,
        role_hint=role_hint,
        ollama=OllamaSnapshot(
            binary_path=str(ollama_raw.get("binary_path", "")),
            version=str(ollama_raw.get("version", "")),
            size_bytes=int(ollama_raw.get("size_bytes", 0) or 0),
            is_running=bool(ollama_raw.get("is_running", False)),
            detected_via=str(ollama_raw.get("detected_via", "")),
            workload_baseline=_parse_workload_baseline(
                ollama_raw.get("workload_baseline")
            ),
        ),
        gpu=GpuSnapshot(
            driver_version=(
                str(gpu_raw["driver_version"])
                if gpu_raw.get("driver_version") is not None
                else None
            ),
        ),
        models=models,
        env={str(k): str(v) for k, v in env_raw.items()},
        runner_libraries=runners,
    )


def load_snapshot(path: str | Path) -> Snapshot:
    p = Path(path).expanduser()
    try:
        text = p.read_text(encoding="utf-8")
    except OSError as e:
        raise SnapshotError(f"snapshot read error: {e}") from e
    try:
        doc = yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise SnapshotError(f"snapshot YAML parse error: {e}") from e
    return parse_snapshot_dict(doc)


__all__ = [
    "SnapshotError",
    "load_snapshot",
    "parse_snapshot_dict",
]
