"""Known environment profile registry — Sprint 9.

Paket-içi ``data/known_environments.yaml`` + opsiyonel kullanıcı dosyası
(``~/.contdoctor/environments.yaml``) merge edilir. Aynı ``id``'li
profilde user kazanır (override). ``match_profile`` fingerprint'e
fnmatch ile eşleştirir.
"""

from __future__ import annotations

import fnmatch
from importlib import resources
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from contdoctor.snapshot.fingerprint import EnvironmentFingerprint

DEFAULT_USER_ENVIRONMENTS_PATH = "~/.contdoctor/environments.yaml"


def _load_yaml_envs(text: str) -> List[Dict[str, Any]]:
    try:
        doc = yaml.safe_load(text)
    except yaml.YAMLError:
        return []
    if not isinstance(doc, dict):
        return []
    raw = doc.get("environments", [])
    if not isinstance(raw, list):
        return []
    return [e for e in raw if isinstance(e, dict) and isinstance(e.get("id"), str)]


def load_known_environments() -> List[Dict[str, Any]]:
    """Paket data + user merge. Aynı id için user override önceliklidir."""
    pkg_text = resources.files("contdoctor.data").joinpath(
        "known_environments.yaml"
    ).read_text(encoding="utf-8")
    pkg_envs = _load_yaml_envs(pkg_text)

    user_envs: List[Dict[str, Any]] = []
    user_path = Path(DEFAULT_USER_ENVIRONMENTS_PATH).expanduser()
    if user_path.is_file():
        try:
            user_envs = _load_yaml_envs(user_path.read_text(encoding="utf-8"))
        except OSError:
            user_envs = []

    user_ids = {e["id"] for e in user_envs}
    merged = [e for e in pkg_envs if e["id"] not in user_ids] + user_envs
    return merged


def _criterion_matches(fp: EnvironmentFingerprint, key: str, expected: Any) -> bool:
    if key.endswith("_pattern"):
        base_key = key[: -len("_pattern")]
        value = getattr(fp, base_key, None)
        if value is None:
            return False
        return fnmatch.fnmatch(str(value), str(expected))
    return getattr(fp, key, None) == expected


def match_profile(
    fp: EnvironmentFingerprint, envs: Optional[List[Dict[str, Any]]] = None
) -> Optional[Dict[str, Any]]:
    """İlk uyan profil. None → bilinmeyen."""
    if envs is None:
        envs = load_known_environments()
    for env in envs:
        criteria = env.get("fingerprint", {})
        if not isinstance(criteria, dict) or not criteria:
            continue
        if all(_criterion_matches(fp, k, v) for k, v in criteria.items()):
            return env
    return None


__all__ = [
    "DEFAULT_USER_ENVIRONMENTS_PATH",
    "load_known_environments",
    "match_profile",
]
