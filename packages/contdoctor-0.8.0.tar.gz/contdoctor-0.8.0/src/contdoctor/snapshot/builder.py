"""Build a Snapshot from current environment state and write it to disk.

This is the *read* side of Sprint 8: every call here is non-mutating —
``ollama --version``, ``nvidia-smi`` query, ``/api/tags`` GET,
``os.environ`` reads, ``Path.iterdir``. Nothing here writes env vars,
spawns long processes, or touches the model store.
"""

from __future__ import annotations

import json
import os
import re
import shutil
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

import yaml

from contdoctor import __version__ as _CONTDOCTOR_VERSION
from contdoctor.checks.ollama_proc import detect_running_ollama
from contdoctor.core.http import http_get
from contdoctor.core.proc import run as _run
from contdoctor.snapshot.fingerprint import compute_fingerprint, guess_role
from contdoctor.snapshot.schema import (
    GpuSnapshot,
    ModelSnapshot,
    OllamaSnapshot,
    RunnerLibSnapshot,
    Snapshot,
)

# Sadece doctor için anlamlı env var'lar — rastgele user env'i snapshot'a
# yazmıyoruz (privacy + bazı banka secret'larını kaçıramamak için).
INTERESTING_ENV_VARS: tuple = (
    "OLLAMA_LLM_LIBRARY",
    "OLLAMA_NUM_GPU",
    "OLLAMA_RUNNERS_DIR",
    "OLLAMA_HOST",
    "CONT_OFFLINE",
    "LD_LIBRARY_PATH",
)

# Runner library tarama path'leri (Sprint 7'deki defaults ile aynı; bilerek
# duplicate çünkü snapshot bağımsız bir alt-sistem).
_RUNNER_SCAN_PATHS = (
    "/usr/local/lib/ollama/cuda_v12",
    "/usr/local/lib/ollama",
)


def _measure_workload_baseline(model: str | None):
    """Sprint 9.2: snapshot oluştururken realistic workload metric'lerini
    yakala. Hata olursa None — snapshot save asla bu yüzden fail etmesin.
    """
    from datetime import datetime, timezone

    from contdoctor.checks.workload import check_realistic_workload
    from contdoctor.snapshot.schema import WorkloadBaseline

    if not model:
        return None
    try:
        result = check_realistic_workload(model)
    except Exception:  # noqa: BLE001 — baseline opsiyonel
        return None
    if result.status not in {"ok", "warn"}:
        # fail durumunda kayıt yapmıyoruz (yanıltıcı baseline olur).
        return None
    eval_tps = float(result.details.get("eval_tokens_per_sec", 0.0) or 0.0)
    prompt_tps = float(result.details.get("prompt_eval_tokens_per_sec", 0.0) or 0.0)
    if eval_tps <= 0.0:
        return None
    return WorkloadBaseline(
        eval_tokens_per_sec=eval_tps,
        prompt_eval_tokens_per_sec=prompt_tps,
        measured_at=datetime.now(timezone.utc)
        .astimezone()
        .isoformat(timespec="seconds"),
    )


def _ollama_snapshot() -> tuple:
    """Sprint 9: çalışan process kanonik. Yoksa PATH fallback. Returns
    ``(OllamaSnapshot, process_env_or_none)`` so the env_snapshot logic
    can reuse the running process env."""
    running = detect_running_ollama()
    if running and running.binary_path:
        binary_path = running.binary_path
        is_running = True
        detected_via = running.detected_via or "pgrep+/proc"
        process_env: dict | None = running.env
    else:
        binary_path = shutil.which("ollama") or ""
        is_running = False
        detected_via = "PATH" if binary_path else ""
        process_env = None

    size_bytes = 0
    try:
        if binary_path:
            size_bytes = Path(binary_path).stat().st_size
    except OSError:
        size_bytes = 0

    version = ""
    if binary_path:
        rc, out, _ = _run([binary_path, "--version"], timeout=5)
        if rc == 0:
            m = re.search(r"(\d+\.\d+\.\d+)", out)
            if m:
                version = m.group(1)

    snap = OllamaSnapshot(
        binary_path=binary_path,
        version=version,
        size_bytes=size_bytes,
        is_running=is_running,
        detected_via=detected_via,
    )
    return snap, process_env


def _gpu_snapshot() -> GpuSnapshot:
    rc, out, _ = _run(
        ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
        timeout=10,
    )
    if rc != 0:
        return GpuSnapshot(driver_version=None)
    line = out.strip().splitlines()[0].strip() if out.strip() else ""
    return GpuSnapshot(driver_version=line or None)


def _model_snapshots() -> List[ModelSnapshot]:
    status, body = http_get("/api/tags", timeout=3)
    if status != 200 or not body:
        return []
    try:
        data = json.loads(body)
    except (json.JSONDecodeError, TypeError):
        return []
    out: List[ModelSnapshot] = []
    for m in data.get("models", []):
        if not isinstance(m, dict) or "name" not in m:
            continue
        out.append(
            ModelSnapshot(
                name=m["name"],
                digest=str(m.get("digest", "")),
                size=int(m.get("size", 0) or 0),
            )
        )
    return out


def _env_snapshot(process_env: dict | None = None) -> dict:
    """Çalışan process env'i varsa onu, yoksa shell'i kullan.

    Sprint 9: custom-launched ollama farklı LD_LIBRARY_PATH/OLLAMA_RUNNERS_DIR
    ile çalışırken shell'den okumak yanıltıcı.
    """
    source = process_env if process_env else os.environ
    return {k: source.get(k, "") for k in INTERESTING_ENV_VARS}


def _runner_libraries() -> List[RunnerLibSnapshot]:
    home_paths = [
        Path.home() / "ollama-full" / "lib" / "ollama" / "cuda_v12",
        Path.home() / "ollama-full" / "lib" / "ollama",
    ]
    candidates = [Path(p) for p in _RUNNER_SCAN_PATHS] + home_paths
    out: List[RunnerLibSnapshot] = []
    seen: set = set()
    for p in candidates:
        try:
            if not p.is_dir():
                continue
        except OSError:
            continue
        if str(p) in seen:
            continue
        seen.add(str(p))
        files: List[str] = []
        try:
            files = sorted(f.name for f in p.iterdir() if f.is_file())
        except OSError:
            continue
        if files:
            out.append(RunnerLibSnapshot(path=str(p), files=files))
    return out


def build_snapshot(
    label: Optional[str] = None,
    *,
    workload_model: Optional[str] = None,
) -> Snapshot:
    """Materialise current env state into a Snapshot. Pure reads (workload
    baseline opsiyonel; workload_model verilirse 90s'lik bir HTTP çağrısı
    eklenir).

    ``label`` is preserved verbatim for the operator's later identification
    ("9 Nisan working" etc). Fingerprint + role hint Sprint 8 (revised)
    eklendi. Sprint 9.2: ``workload_baseline`` opsiyonel realistic workload
    metric kaydı.
    """
    fp = compute_fingerprint()
    ollama, process_env = _ollama_snapshot()
    if workload_model and ollama.is_running:
        ollama.workload_baseline = _measure_workload_baseline(workload_model)
    return Snapshot(
        version=1,
        created_at=datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        created_by_contdoctor=_CONTDOCTOR_VERSION,
        label=label,
        fingerprint=fp,
        role_hint=guess_role(fp),
        ollama=ollama,
        gpu=_gpu_snapshot(),
        models=_model_snapshots(),
        env=_env_snapshot(process_env),
        runner_libraries=_runner_libraries(),
    )


def save_snapshot(snapshot: Snapshot, path: str) -> Path:
    """Write the snapshot to ``path`` (``~`` expanded, parents created).
    Returns the resolved Path."""
    p = Path(path).expanduser()
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = asdict(snapshot)
    p.write_text(
        yaml.safe_dump(payload, sort_keys=False, allow_unicode=True),
        encoding="utf-8",
    )
    return p


__all__ = [
    "INTERESTING_ENV_VARS",
    "build_snapshot",
    "save_snapshot",
]
