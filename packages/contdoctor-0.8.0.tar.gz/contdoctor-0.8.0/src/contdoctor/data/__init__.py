"""Static reference data shipped with contdoctor (e.g. compat matrix).

Knowledge rules live in :mod:`contdoctor.knowledge.data`; this directory
is for non-rule reference tables that the runtime consults.
"""
