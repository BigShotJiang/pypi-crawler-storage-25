"""ANSI status symbols. Falls back to ASCII when stdout is not a TTY or NO_COLOR is set."""

import os
import sys


def _supports_color() -> bool:
    return sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


if _supports_color():
    S_OK = "\033[32m✓\033[0m"
    S_WARN = "\033[33m!\033[0m"
    S_FAIL = "\033[31m✗\033[0m"
    S_FIX = "\033[36m⚙\033[0m"
    S_INFO = "\033[34mi\033[0m"
    BOLD = "\033[1m"
    RESET = "\033[0m"
else:
    S_OK, S_WARN, S_FAIL, S_FIX, S_INFO = "[OK]", "[!]", "[X]", "[FIX]", "[i]"
    BOLD = RESET = ""


__all__ = ["S_OK", "S_WARN", "S_FAIL", "S_FIX", "S_INFO", "BOLD", "RESET"]
