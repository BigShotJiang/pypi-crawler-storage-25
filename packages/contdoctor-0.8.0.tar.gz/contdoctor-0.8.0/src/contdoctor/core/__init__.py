"""Core building blocks: result type, helpers, runner, report.

This package's ``__init__`` is intentionally light to avoid circular imports
between ``core.runner`` (which imports the ``checks`` package) and the
individual check modules (which import ``core.proc`` / ``core.http``).
Import the leaf modules directly, e.g.::

    from contdoctor.core.result import CheckResult
    from contdoctor.core.runner import CHECKS, GATES, run_checks
"""
