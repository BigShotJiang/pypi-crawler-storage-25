"""Tiny urllib wrapper that talks only to ``OLLAMA_HOST``.

The doctor must not contact arbitrary hosts, so the wrappers below build
URLs from a single configurable base. Anything else is rejected.
"""

import json as _json
import os
import socket
from typing import Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")

_USER_AGENT = "cont-doctor/v100"


def _build_url(path: str) -> str:
    if not path.startswith("/"):
        raise ValueError(f"path must start with '/': {path!r}")
    return f"{OLLAMA_HOST.rstrip('/')}{path}"


def http_get(path: str, timeout: int = 3) -> Tuple[Optional[int], Optional[str]]:
    """GET against ``OLLAMA_HOST + path``. Returns ``(status, body_or_err)``."""
    url = _build_url(path)
    try:
        req = Request(url, headers={"User-Agent": _USER_AGENT})
        with urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", errors="replace")
    except HTTPError as e:
        return e.code, None
    except (URLError, socket.timeout, OSError) as e:
        return None, str(e)


def http_post_json(
    path: str, body: dict, timeout: int = 10
) -> Tuple[Optional[int], Optional[str]]:
    """POST a JSON body against ``OLLAMA_HOST + path``."""
    url = _build_url(path)
    try:
        data = _json.dumps(body).encode("utf-8")
        req = Request(
            url,
            data=data,
            headers={"Content-Type": "application/json", "User-Agent": _USER_AGENT},
        )
        with urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", errors="replace")
    except HTTPError as e:
        return e.code, None
    except (URLError, socket.timeout, OSError) as e:
        return None, str(e)


__all__ = ["OLLAMA_HOST", "http_get", "http_post_json"]
