"""Tiny stdlib helpers for subprocess / pgrep / port-open checks."""

import socket
import subprocess
from typing import List, Tuple


def run(cmd: List[str], timeout: int = 5) -> Tuple[int, str, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout, r.stderr
    except FileNotFoundError:
        return 127, "", f"komut bulunamadı: {cmd[0]}"
    except subprocess.TimeoutExpired:
        return 124, "", f"timeout ({timeout}s): {' '.join(cmd)}"
    except Exception as e:  # noqa: BLE001 — surface any runtime error cleanly
        return 1, "", f"{type(e).__name__}: {e}"


def pgrep(pattern: str) -> List[int]:
    rc, out, _ = run(["pgrep", "-f", pattern], timeout=3)
    if rc != 0:
        return []
    return [int(p) for p in out.strip().splitlines() if p.strip().isdigit()]


def port_open(host: str, port: int, timeout: float = 1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, socket.timeout):
        return False


__all__ = ["run", "pgrep", "port_open"]
