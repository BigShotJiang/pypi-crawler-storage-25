"""argparse entry point — preserves the prototype's flags and exit codes."""

import argparse
import json
import sys
from typing import List

from contdoctor import __version__ as _CONTDOCTOR_VERSION
from contdoctor.checks.model import DEFAULT_MODEL
from contdoctor.checks.snapshot_drift import DEFAULT_SNAPSHOT_PATH
from contdoctor.lessons import (
    DEFAULT_LESSONS_PATH,
    Lesson,
    LessonsError,
    load_example_lessons,
    load_lessons,
)
from contdoctor.lessons.loader import example_lessons_path
from contdoctor.snapshot import build_snapshot, save_snapshot
from contdoctor.core.report import print_human_report, results_to_json
from contdoctor.core.result import CheckResult
from contdoctor.core.runner import CHECKS, run_checks
from contdoctor.core.symbols import BOLD, RESET, S_FAIL, S_FIX, S_INFO, S_OK, S_WARN
from contdoctor.knowledge import KnowledgeError, default_symptoms


MAX_FIX_ITERATIONS = 5


def _apply_fixes(results: List[CheckResult]) -> None:
    """Run each result's ``fix_action``. The Sprint 5.1 fallback chain
    was removed in 0.4.0 — Python fixes are now responsible for self-
    healing in their own logic (see ``fix_reload_model``). YAML
    ``print_remediation`` / ``run_shell`` symptoms remain for *standalone*
    diagnostics whose check has no Python-side fix at all.
    """
    for r in results:
        if not r.fix_action:
            continue
        print(f"\n{S_FIX} {BOLD}[{r.name}]{RESET} {r.fix_label or ''}")
        try:
            ok = bool(r.fix_action())
            print(f"  → {S_OK if ok else S_FAIL} "
                  f"{'düzeltildi' if ok else 'başarısız'}")
        except Exception as e:  # noqa: BLE001
            print(f"  {S_FAIL} fix exception: {type(e).__name__}: {e}")


def _fixable_set(results: List[CheckResult]) -> frozenset:
    """Identifier set of currently auto-fixable check names."""
    return frozenset(r.name for r in results if r.fix_action)


def _progress_signature(results: List[CheckResult]) -> tuple:
    """Per-iteration signature: ``(fixable_set, ((name, status), ...))``.

    Two iterations producing the *same* signature mean the fix didn't
    change anything observable (Sprint 7.1) — only then is no-progress
    a real stop condition. If status changed but the fix list happens to
    be identical, we keep looping.
    """
    status_tuple = tuple((r.name, r.status) for r in results)
    return (_fixable_set(results), status_tuple)


def _recursive_fix_loop(
    args, names: List[str], symptoms, initial_results: List[CheckResult]
):
    """Apply fixes until convergence (no fixable results) or a stop
    condition kicks in. Returns ``(final_results, exit_code)``.

    Stop conditions:
      * fixed-point: nothing left to fix → exit 0/1/2 by status.
      * no progress: same ``(fixable_set, status_signature)`` two turns
        in a row → break, stderr.
      * max iterations: ``MAX_FIX_ITERATIONS`` reached → break, stderr.
    """
    results = initial_results
    prev_signature: tuple | None = None

    for iteration in range(1, MAX_FIX_ITERATIONS + 1):
        fix_set = _fixable_set(results)
        if not fix_set:
            if iteration == 1:
                print(f"\n{S_INFO} otomatik düzeltilebilir bir şey yok")
            else:
                print(f"\n{S_OK} {BOLD}fixed-point — tüm fix'ler uygulandı{RESET}")
            print_human_report(results, verbose=args.verbose)
            return results, _exit_code_from_results(results)

        current_signature = _progress_signature(results)
        if current_signature == prev_signature:
            print_human_report(results, verbose=args.verbose)
            _print_no_progress_summary(results, fix_set)
            return results, 2

        if iteration > 1:
            print_human_report(results, verbose=args.verbose)
        print(
            f"\n{BOLD}{S_FIX} iterasyon {iteration}/{MAX_FIX_ITERATIONS}: "
            f"{len(fix_set)} fix uygulanıyor…{RESET}"
        )
        _apply_fixes(results)
        prev_signature = current_signature
        print(f"\n{S_INFO} yeniden tarama…")
        results = run_checks(args, names, symptoms=symptoms)

    # MAX_FIX_ITERATIONS aşıldı.
    print_human_report(results, verbose=args.verbose)
    sys.stderr.write(
        f"\n{S_WARN} {MAX_FIX_ITERATIONS} iterasyondan sonra fixed-point'e "
        f"ulaşılamadı.\n"
    )
    return results, 2


def _print_no_progress_summary(
    results: List[CheckResult], fix_set: frozenset
) -> None:
    """Operatöre yönelik özet kutu + check'e özel kopyala-yapıştır komut
    bloğu. Sertan'ın kuralı: "yukarıdaki raporda" referansı yok.
    """
    cyan = "\033[36m" if sys.stderr.isatty() else ""
    reset = "\033[0m" if sys.stderr.isatty() else ""

    by_name = {r.name: r for r in results}
    sys.stderr.write("\n")
    sys.stderr.write(
        f"{cyan}╭─ Doctor self-healing tamamlandı, fix edilemeyen "
        f"sorun ────╮{reset}\n"
    )
    for name in sorted(fix_set):
        r = by_name.get(name)
        if r is None:
            continue
        status_glyph = {"fail": S_FAIL, "warn": S_WARN, "ok": S_OK}.get(
            r.status, "?"
        )
        sys.stderr.write(
            f"{cyan}│{reset} {status_glyph} {r.name:<22s} — {r.message}\n"
        )
    sys.stderr.write(
        f"{cyan}╰─────────────────────────────────────────────────────"
        f"────────╯{reset}\n"
    )

    # check-specific copy-paste instructions
    network_ok = _network_isolated(results)
    for name in sorted(fix_set):
        r = by_name.get(name)
        if r is None:
            continue
        block = _command_block_for(r, network_isolated=network_ok)
        if block:
            sys.stderr.write("\n" + block + "\n")


def _network_isolated(results: List[CheckResult]) -> bool:
    """True iff the ``network`` check reports external hosts unreachable
    — i.e. we're in a bank-grade isolated environment."""
    for r in results:
        if r.name == "Network izolasyonu":
            return r.status == "ok"
    return False


def _command_block_for(r: CheckResult, *, network_isolated: bool) -> str:
    """Return a short shell command block tailored to ``r.name`` so the
    operator can fix it without going back to the report."""
    if r.name == "Ollama versiyon":
        if network_isolated:
            return (
                "# Ollama versiyon — banka ortamı (network izole)\n"
                "# 0.20.3 GPU regression varsa downgrade için manuel\n"
                "# wheel/binary transferi gerekli. Yöneticinizle iletişime geçin.\n"
                "# Mevcut versiyon:\n"
                "ollama --version"
            )
        return (
            "# Ollama versiyon downgrade (0.20.3 GPU regression):\n"
            "curl -fsSL https://ollama.com/install.sh | OLLAMA_VERSION=0.19.5 sh\n"
            "# Sonra: contdoctor --fix"
        )
    if r.name == "Model yüklü":
        # fix_reload_model already printed the manual debug block.
        return (
            "# Model yüklü — manuel debug bloğu yukarıda fix_reload_model\n"
            "# tarafından basıldı. Adımları sırasıyla çalıştırın."
        )
    return ""


def _print_lessons() -> None:
    """``--lessons`` çıktısı: severity-sorted list. Sertan dosyası yoksa
    paket içi example'ı göster + kopyalama hint'i."""
    using_example = False
    try:
        lessons = load_lessons()
    except FileNotFoundError:
        try:
            lessons = load_example_lessons()
        except (LessonsError, OSError) as e:
            print(
                f"contdoctor: lessons example yüklenemedi: {e}",
                file=sys.stderr,
            )
            return
        using_example = True
    except LessonsError as e:
        print(f"contdoctor: lessons load error: {e}", file=sys.stderr)
        return

    print()
    print(f"{BOLD}📚 Lessons — cont projesi{RESET}")
    print("═" * 60)
    if using_example:
        print(
            f"{S_INFO} {DEFAULT_LESSONS_PATH} yok — paket içi example "
            f"gösteriliyor.\n"
            f"  Kalıcı kullanmak için:\n"
            f"  cp {example_lessons_path()} {DEFAULT_LESSONS_PATH}\n"
        )
    for l in lessons:
        sev = l.severity.upper()
        print(f"[{sev}] {l.id}")
        print(f"  {l.title}")
        if l.next_action:
            print(f"  → next: {l.next_action}")
        print()


def _exit_code_from_results(results: List[CheckResult]) -> int:
    if any(r.status == "fail" for r in results):
        return 2
    if any(r.status == "warn" for r in results):
        return 1
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="contdoctor",
        description="Cont Doctor — banka için lokal teşhis ve fix.",
        epilog="Check key'leri: " + ", ".join(CHECKS.keys()),
    )
    parser.add_argument(
        "--fix", action="store_true", help="otomatik düzeltilebilen sorunları düzelt"
    )
    parser.add_argument(
        "--json", action="store_true", help="makine-okunur çıktı (CI/parse)"
    )
    parser.add_argument(
        "--only", default="", help="virgülle ayrılmış check key'leri"
    )
    parser.add_argument(
        "--skip", default="", help="atlanacak check key'leri"
    )
    parser.add_argument(
        "--model", default=DEFAULT_MODEL, help=f"hedef model (default: {DEFAULT_MODEL})"
    )
    parser.add_argument("-v", "--verbose", action="store_true")
    parser.add_argument(
        "--version",
        action="version",
        version=f"contdoctor {_CONTDOCTOR_VERSION}",
    )
    # Sprint 8 — read-only environment snapshot drift detection.
    parser.add_argument(
        "--save-snapshot",
        nargs="?",
        const=DEFAULT_SNAPSHOT_PATH,
        metavar="PATH",
        help=(
            "Mevcut environment state'ini snapshot YAML olarak diske yaz "
            f"(default: {DEFAULT_SNAPSHOT_PATH}) ve çık. Health check çalıştırmaz."
        ),
    )
    parser.add_argument(
        "--snapshot-label",
        default=None,
        metavar="TEXT",
        help="Snapshot için isteğe bağlı kullanıcı etiketi (örn. '9 Nisan working')",
    )
    parser.add_argument(
        "--snapshot-path",
        default=None,
        metavar="PATH",
        help=(
            "Drift check için snapshot dosyasının yolu (env: CONTDOCTOR_SNAPSHOT, "
            f"default: {DEFAULT_SNAPSHOT_PATH})"
        ),
    )
    # Sprint 8 (revised) — kalıcı proje öğretileri (lessons store).
    parser.add_argument(
        "--lessons",
        action="store_true",
        help=(
            f"Kayıtlı dersleri (default {DEFAULT_LESSONS_PATH}) severity'e göre "
            "listele ve çık. Yoksa paket içi example göster."
        ),
    )
    args = parser.parse_args()

    if args.lessons:
        _print_lessons()
        sys.exit(0)

    # Sprint 8 — --save-snapshot mutually exclusive with health checks.
    if args.save_snapshot is not None:
        # Sprint 9.2: snapshot oluştururken realistic workload baseline'ı
        # da yakala (model parametresi geçersizse builder None bırakır).
        snap = build_snapshot(
            label=args.snapshot_label, workload_model=args.model
        )
        out_path = save_snapshot(snap, args.save_snapshot)
        print(
            f"{S_OK} Snapshot yazıldı: {out_path}\n"
            f"{S_INFO} Drift detection için bu dosya kullanılır "
            f"(--snapshot-path={out_path} veya CONTDOCTOR_SNAPSHOT env)."
        )
        sys.exit(0)

    try:
        symptoms = default_symptoms()
    except KnowledgeError as e:
        print(f"contdoctor: knowledge load error: {e}", file=sys.stderr)
        sys.exit(3)

    if args.only:
        names = [x.strip() for x in args.only.split(",") if x.strip()]
    else:
        names = list(CHECKS.keys())
    if args.skip:
        skip = {x.strip() for x in args.skip.split(",")}
        names = [n for n in names if n not in skip]

    results = run_checks(args, names, symptoms=symptoms)

    if args.json:
        print(json.dumps(results_to_json(results), indent=2, ensure_ascii=False))
        sys.exit(2 if any(r.status == "fail" for r in results) else 0)

    print_human_report(results, verbose=args.verbose)

    exit_code = 0
    if any(r.status == "fail" for r in results):
        exit_code = 2
    elif any(r.status == "warn" for r in results):
        exit_code = 1

    if args.fix:
        results, exit_code = _recursive_fix_loop(args, names, symptoms, results)

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
