"""Read-only drift detection — Sprint 8.

Snapshot var ise mevcut state ile karşılaştırır. **Hiçbir şey
değiştirmez**: ``fix_action=None`` her durumda. Sertan'ın açık talebi:
"environment'ı değiştirmeyin, sadece tespit edin." Drift bulgusunu
operatöre raporlamak; restore Sertan'ın elinde.

Severity:
  * ``ollama.version`` mismatch → fail (bilinen GPU regression yolu)
  * ``ollama.size_bytes`` mismatch → warn (version drift'in indirekt kanıtı)
  * ``gpu.driver_version`` mismatch → warn (host güncellendi)
  * ``models[*].digest`` mismatch → warn (model yeniden create edilmiş)
  * Snapshot yok / okunamadı → warn + hint
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from contdoctor.core.result import CheckResult
from contdoctor.snapshot.builder import build_snapshot
from contdoctor.snapshot.loader import SnapshotError, load_snapshot
from contdoctor.snapshot.schema import Snapshot

# Sprint 8 (revised) — fingerprint mismatches that invalidate the snapshot.
# When these differ, comparing other fields would just produce noise, so the
# drift check refuses early.
_FINGERPRINT_HARD_MISMATCH_FIELDS = ("hostname", "is_wsl")
# Soft fingerprint mismatches — same machine but environment moved a bit.
_FINGERPRINT_SOFT_MISMATCH_FIELDS = ("cuda_driver", "gpu_name")

DEFAULT_SNAPSHOT_PATH = "~/.contdoctor/snapshot.yaml"


def _resolve_snapshot_path(snapshot_path: Optional[str]) -> str:
    if snapshot_path:
        return snapshot_path
    return os.environ.get("CONTDOCTOR_SNAPSHOT", DEFAULT_SNAPSHOT_PATH)


def _diff_snapshots(
    snapshot: Snapshot, current: Snapshot
) -> List[Tuple[str, str, Any, Any]]:
    """``[(field, severity, snapshot_value, current_value), ...]``."""
    drifts: List[Tuple[str, str, Any, Any]] = []

    if snapshot.ollama.version and snapshot.ollama.version != current.ollama.version:
        drifts.append(
            ("ollama.version", "fail", snapshot.ollama.version, current.ollama.version)
        )
    if (
        snapshot.ollama.size_bytes
        and snapshot.ollama.size_bytes != current.ollama.size_bytes
    ):
        drifts.append(
            (
                "ollama.size_bytes",
                "warn",
                snapshot.ollama.size_bytes,
                current.ollama.size_bytes,
            )
        )
    if (
        snapshot.gpu.driver_version
        and current.gpu.driver_version
        and snapshot.gpu.driver_version != current.gpu.driver_version
    ):
        drifts.append(
            (
                "gpu.driver_version",
                "warn",
                snapshot.gpu.driver_version,
                current.gpu.driver_version,
            )
        )

    snap_models = {m.name: m for m in snapshot.models}
    cur_models = {m.name: m for m in current.models}
    for name, snap_m in snap_models.items():
        cur_m = cur_models.get(name)
        if cur_m is None:
            drifts.append((f"models[{name}]", "warn", "kayıtlı", "yok"))
            continue
        if snap_m.digest and cur_m.digest and snap_m.digest != cur_m.digest:
            drifts.append(
                (
                    f"models[{name}].digest",
                    "warn",
                    snap_m.digest[:12],
                    cur_m.digest[:12],
                )
            )

    return drifts


def _fingerprint_field_pairs(snapshot: Snapshot, current: Snapshot):
    """Yield ``(field_name, snap_value, cur_value)`` from both fingerprints."""
    if snapshot.fingerprint is None or current.fingerprint is None:
        return
    snap_fp = snapshot.fingerprint
    cur_fp = current.fingerprint
    for name in _FINGERPRINT_HARD_MISMATCH_FIELDS + _FINGERPRINT_SOFT_MISMATCH_FIELDS:
        yield name, getattr(snap_fp, name, None), getattr(cur_fp, name, None)


def _hard_fingerprint_reject(
    snapshot: Snapshot, current: Snapshot, snapshot_path: Path
) -> Optional[CheckResult]:
    """If hostname or is_wsl differ, refuse the snapshot outright.

    Returns ``CheckResult`` (rejection) or ``None`` (no reject — proceed).
    """
    if snapshot.fingerprint is None or current.fingerprint is None:
        return None
    snap_fp = snapshot.fingerprint
    cur_fp = current.fingerprint
    rejections = []
    for name in _FINGERPRINT_HARD_MISMATCH_FIELDS:
        snap_val = getattr(snap_fp, name)
        cur_val = getattr(cur_fp, name)
        if snap_val != cur_val:
            rejections.append((name, snap_val, cur_val))
    if not rejections:
        return None
    summary = "; ".join(f"{n}: {s} → {c}" for n, s, c in rejections)
    return CheckResult(
        "Environment snapshot drift",
        "fail",
        f"Snapshot başka makineden ({summary})",
        details={
            "snapshot_path": str(snapshot_path),
            "snapshot_created_at": snapshot.created_at,
            "label": snapshot.label,
            "rejected_due_to_fingerprint": [
                {"field": n, "snapshot": s, "current": c} for n, s, c in rejections
            ],
            "hint": "Snapshot doğru makineden alınmamış. "
                    "contdoctor --save-snapshot ile yenile.",
        },
        # fix_action None — read-only.
    )


def check_environment_drift(snapshot_path: Optional[str] = None) -> CheckResult:
    """Snapshot ile current state diff. ``fix_action=None`` (read-only)."""
    resolved = _resolve_snapshot_path(snapshot_path)
    p = Path(resolved).expanduser()

    if not p.is_file():
        return CheckResult(
            "Environment snapshot drift",
            "warn",
            f"Snapshot dosyası yok: {p}",
            details={
                "snapshot_path": str(p),
                "hint": "Sistem çalışırken: contdoctor --save-snapshot",
            },
            # NOT: fix_action None — hiçbir auto-fix yok. Sertan kuralı.
        )

    try:
        snapshot = load_snapshot(p)
    except SnapshotError as e:
        return CheckResult(
            "Environment snapshot drift",
            "warn",
            f"Snapshot okunamadı: {e}",
            details={"snapshot_path": str(p), "error": str(e)},
        )

    current = build_snapshot(label=None)

    # Sprint 8 (revised): hostname / is_wsl mismatch → snapshot başka makineden,
    # diğer drift'lere bakmıyoruz (gürültü).
    rejection = _hard_fingerprint_reject(snapshot, current, p)
    if rejection is not None:
        return rejection

    drifts = _diff_snapshots(snapshot, current)
    # Soft fingerprint drifts (cuda driver, gpu name) → warn rows in the
    # same drift list.
    if snapshot.fingerprint is not None and current.fingerprint is not None:
        for name in _FINGERPRINT_SOFT_MISMATCH_FIELDS:
            snap_val = getattr(snapshot.fingerprint, name)
            cur_val = getattr(current.fingerprint, name)
            if snap_val and cur_val and snap_val != cur_val:
                drifts.append(
                    (f"fingerprint.{name}", "warn", snap_val, cur_val)
                )

    base_details: Dict[str, Any] = {
        "snapshot_path": str(p),
        "snapshot_created_at": snapshot.created_at,
        "label": snapshot.label,
    }

    if not drifts:
        return CheckResult(
            "Environment snapshot drift",
            "ok",
            f"Snapshot {p} ile uyumlu (label: {snapshot.label or '-'})",
            details=base_details,
        )

    max_sev = "fail" if any(d[1] == "fail" for d in drifts) else "warn"
    summary_parts = [f"{len(drifts)} drift (label: {snapshot.label or '-'})"]
    for field, _sev, snap_val, cur_val in drifts:
        summary_parts.append(f"{field}: {snap_val} → {cur_val}")

    related = _related_lesson_ids()
    return CheckResult(
        "Environment snapshot drift",
        max_sev,
        "; ".join(summary_parts),
        details={
            **base_details,
            "drifts": [
                {"field": f, "severity": s, "snapshot": sv, "current": cv}
                for f, s, sv, cv in drifts
            ],
            **({"related_lessons": related} if related else {}),
        },
        # fix_action explicitly None — read-only, no remediation fired by --fix.
    )


def _related_lesson_ids() -> list:
    """Mevcut lessons.yaml (varsa) veya example'dan kritik+high lesson
    id'lerini döner. Doctor lessons içeriklerini logic'te kullanmaz —
    sadece "ilgili dersler şunlar, --lessons ile detay" diyebilsin diye."""
    try:
        from contdoctor.lessons import load_example_lessons, load_lessons

        try:
            items = load_lessons()
        except FileNotFoundError:
            items = load_example_lessons()
        return [
            l.id for l in items if l.severity in {"critical", "high"}
        ]
    except Exception:  # noqa: BLE001 — drift check'in canına dokunmasın
        return []


__all__ = [
    "DEFAULT_SNAPSHOT_PATH",
    "check_environment_drift",
]
