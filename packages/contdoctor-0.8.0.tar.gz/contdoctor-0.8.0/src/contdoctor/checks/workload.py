"""``check_realistic_workload`` — Sprint 9.2.

Cont'un kendi sistem prompt'u ~3000 char + 30 token üretim. CPU'da 30B
model bu workload'ı 90s'de tamamlayamaz; GPU'da 5-15s. Sprint 1'in
``check_model_responds`` (4 token, 30s) prod gerçekliğinden uzaktı —
doctor "model yanıt veriyor" derken Cont gerçek prompt akışında 90s
timeout'a düşebiliyordu.

eval_tokens_per_sec eşikleri (RTX 5000 Ada / RTX 5090 üzerinde 30B MoE
benchmark'ları):
  * ≥ 30 tps → ``ok`` (GPU çalışıyor)
  * ≥ 10 tps → ``warn`` (kısmi GPU offload)
  * <  10 tps → ``fail`` (CPU inference; Cont 90s timeout'a düşer)
"""

from __future__ import annotations

import json
import time
from typing import Tuple

from contdoctor.core.http import http_post_json
from contdoctor.core.result import CheckResult

# Cont'a benzer kalıcı prompt — gerçek sistem prompt'unu yansıtmadığı için
# gizli/türetilebilir bir bilgi yok, generic AI coding assistant tonunda.
REALISTIC_SYSTEM_PROMPT = """\
You are a local AI coding assistant operating in a sandboxed environment.
Workspace context: a Python project with source files, tests, and documentation.
You have access to tools for file reading, command execution, and code search.
Tool budget: 12 calls per phase, phase budgets reset between turns.

Current working directory contains source code under src/, tests under tests/,
and configuration in pyproject.toml. The project follows PEP 621 packaging.

Your responses should be concise and direct. When you need to call tools,
declare your intent first, then execute. Avoid speculation; if information
is missing, request it explicitly.

Coding conventions:
- Type hints required for all function signatures
- Tests must accompany new functionality
- Logging via the standard logging module, not print statements
- Path operations via pathlib.Path, not string manipulation
- Subprocess calls must specify timeout and capture_output

Memory and context:
- Previous conversation history is available via memory_search tool
- Long-term project context lives in CLAUDE.md or AGENTS.md
- Workspace inventory is available via filesystem tools

If asked a question with insufficient context, ask one clarifying question
rather than making assumptions. If asked to modify code, first read the
relevant files, then propose changes, then apply only after confirmation.
"""

WORKLOAD_TIMEOUT_S = 90
WORKLOAD_NUM_PREDICT = 30
WORKLOAD_USER_MESSAGE = "User: selam"

# Karar eşikleri (eval_tokens_per_sec).
EVAL_TPS_OK_THRESHOLD = 30.0
EVAL_TPS_WARN_THRESHOLD = 10.0


def _measure_workload(model: str) -> Tuple[int | None, str | None, dict, float]:
    """``(http_status, body, parsed_metrics, elapsed_s)``."""
    prompt = REALISTIC_SYSTEM_PROMPT.strip() + "\n\n" + WORKLOAD_USER_MESSAGE
    t0 = time.monotonic()
    status, body = http_post_json(
        "/api/generate",
        {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "num_predict": WORKLOAD_NUM_PREDICT,
                "temperature": 0.7,
            },
        },
        timeout=WORKLOAD_TIMEOUT_S,
    )
    elapsed = time.monotonic() - t0
    metrics: dict = {}
    if status == 200 and body:
        try:
            data = json.loads(body)
            metrics = {
                "response": (data.get("response") or "").strip(),
                "eval_count": int(data.get("eval_count", 0) or 0),
                "eval_duration_ns": int(data.get("eval_duration", 0) or 0),
                "prompt_eval_count": int(data.get("prompt_eval_count", 0) or 0),
                "prompt_eval_duration_ns": int(
                    data.get("prompt_eval_duration", 0) or 0
                ),
            }
        except (json.JSONDecodeError, TypeError, ValueError):
            metrics = {}
    return status, body, metrics, elapsed


def _eval_tokens_per_sec(metrics: dict) -> float:
    eval_count = metrics.get("eval_count", 0)
    eval_duration_ns = metrics.get("eval_duration_ns", 0)
    if not eval_duration_ns:
        return 0.0
    return eval_count / (eval_duration_ns / 1e9)


def _prompt_tokens_per_sec(metrics: dict) -> float:
    prompt_eval_count = metrics.get("prompt_eval_count", 0)
    prompt_eval_duration_ns = metrics.get("prompt_eval_duration_ns", 0)
    if not prompt_eval_duration_ns:
        return 0.0
    return prompt_eval_count / (prompt_eval_duration_ns / 1e9)


def check_realistic_workload(model: str) -> CheckResult:
    status, body, metrics, elapsed = _measure_workload(model)
    base_details = {
        "elapsed_s": round(elapsed, 1),
        "prompt_chars": len(REALISTIC_SYSTEM_PROMPT.strip())
        + len(WORKLOAD_USER_MESSAGE)
        + 2,
        "num_predict": WORKLOAD_NUM_PREDICT,
    }

    if status is None:
        return CheckResult(
            "Realistic workload",
            "fail",
            f"{elapsed:.1f}s sonra hata: {body}",
            details=base_details,
        )
    if status != 200:
        return CheckResult(
            "Realistic workload",
            "fail",
            f"HTTP {status} ({elapsed:.1f}s)",
            details=base_details,
        )
    if not metrics:
        return CheckResult(
            "Realistic workload",
            "warn",
            "yanıt parse edilemedi",
            details=base_details,
        )

    eval_tps = _eval_tokens_per_sec(metrics)
    prompt_tps = _prompt_tokens_per_sec(metrics)
    details = {
        **base_details,
        "response_chars": len(metrics.get("response", "")),
        "eval_count": metrics.get("eval_count", 0),
        "eval_tokens_per_sec": round(eval_tps, 1),
        "prompt_eval_tokens_per_sec": round(prompt_tps, 1),
    }

    if eval_tps == 0.0 and metrics.get("eval_count", 0) == 0:
        return CheckResult(
            "Realistic workload",
            "fail",
            "eval süresi parse edilemedi veya 0 — GPU durumu belirsiz",
            details=details,
        )

    if eval_tps >= EVAL_TPS_OK_THRESHOLD:
        return CheckResult(
            "Realistic workload",
            "ok",
            f"{elapsed:.1f}s, eval {eval_tps:.0f} tok/s — GPU çalışıyor",
            details=details,
        )
    if eval_tps >= EVAL_TPS_WARN_THRESHOLD:
        return CheckResult(
            "Realistic workload",
            "warn",
            f"{elapsed:.1f}s, eval {eval_tps:.0f} tok/s — kısmi GPU offload",
            details=details,
        )
    return CheckResult(
        "Realistic workload",
        "fail",
        f"{elapsed:.1f}s, eval {eval_tps:.1f} tok/s — CPU inference "
        f"(Cont'u 90s timeout'a düşürür)",
        details=details,
    )


__all__ = [
    "REALISTIC_SYSTEM_PROMPT",
    "WORKLOAD_TIMEOUT_S",
    "WORKLOAD_NUM_PREDICT",
    "EVAL_TPS_OK_THRESHOLD",
    "EVAL_TPS_WARN_THRESHOLD",
    "check_realistic_workload",
]
