"""Deployment-level checks: own version, codent compat, binary path sanity.

These run independently of the runtime checks (no GATES wiring) — a broken
deployment shouldn't be hidden behind a failed Ollama process check.
"""

from __future__ import annotations

import os
import shutil
import sys
from importlib import metadata as _metadata

from contdoctor import __version__ as _CONTDOCTOR_VERSION
from contdoctor.core.result import CheckResult
from contdoctor.knowledge.compat import (
    CompatError,
    is_codent_compatible,
    load_compat,
    min_codent_for,
)

# Versions known to ship a behaviour-affecting bug. Pure data: extending this
# is a YAML-symptom job, not a code edit.
KNOWN_BAD_CONTDOCTOR: dict[str, str] = {}


def check_contdoctor_version() -> CheckResult:
    """Report our own version. Baseline for drift detection in symptoms."""
    details = {"version": _CONTDOCTOR_VERSION}
    msg = f"contdoctor v{_CONTDOCTOR_VERSION}"
    if _CONTDOCTOR_VERSION in KNOWN_BAD_CONTDOCTOR:
        return CheckResult(
            "contdoctor versiyon",
            "warn",
            f"v{_CONTDOCTOR_VERSION} — {KNOWN_BAD_CONTDOCTOR[_CONTDOCTOR_VERSION]}",
            details=details,
        )
    return CheckResult("contdoctor versiyon", "ok", msg, details=details)


def check_codent_version() -> CheckResult:
    """Codent compat against ``contdoctor/data/compat.yaml``.

    - codent yüklü değil → ``warn`` (contdoctor standalone'da da çalışır)
    - matrix yüklenemedi → ``fail`` (loud failure, not silent)
    - uyumsuz → ``fail`` (drift senaryosu — bir symptom bunu yakalar)
    - uyumlu → ``ok``
    """
    try:
        codent_version = _metadata.version("codent")
    except _metadata.PackageNotFoundError:
        return CheckResult(
            "Codent versiyon",
            "warn",
            "codent yüklü değil (contdoctor standalone modda çalışıyor)",
            details={
                "codent_installed": False,
                "contdoctor_version": _CONTDOCTOR_VERSION,
            },
        )

    try:
        ok, note = is_codent_compatible(codent_version, _CONTDOCTOR_VERSION)
    except CompatError as e:
        return CheckResult(
            "Codent versiyon",
            "fail",
            f"compat matrix okunamadı: {e}",
            details={
                "codent_installed": True,
                "codent_version": codent_version,
                "contdoctor_version": _CONTDOCTOR_VERSION,
                "compat_load_error": str(e),
            },
        )

    min_codent = min_codent_for(_CONTDOCTOR_VERSION) or ""
    details = {
        "codent_installed": True,
        "codent_version": codent_version,
        "contdoctor_version": _CONTDOCTOR_VERSION,
        "compatible": ok,
        "compat_note": note or "",
        "min_codent_version": min_codent,
    }
    if ok:
        return CheckResult(
            "Codent versiyon",
            "ok",
            f"codent v{codent_version} ↔ contdoctor v{_CONTDOCTOR_VERSION} (uyumlu)",
            details=details,
        )
    return CheckResult(
        "Codent versiyon",
        "fail",
        f"codent v{codent_version} ile contdoctor v{_CONTDOCTOR_VERSION} uyumsuz",
        details=details,
    )


def _all_in_path(name: str) -> list[str]:
    """Every executable named ``name`` reachable through PATH (in order)."""
    path = os.environ.get("PATH", "")
    seen: list[str] = []
    for d in path.split(os.pathsep):
        if not d:
            continue
        candidate = os.path.join(d, name)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            if candidate not in seen:
                seen.append(candidate)
    return seen


def check_binary_path() -> CheckResult:
    """``which cont`` consistency + PATH shadow detection.

    Shadow = more than one ``cont`` reachable through PATH; the first
    one wins, but the user may not know which.
    """
    shadows = _all_in_path("cont")
    primary = shutil.which("cont")
    expected_dir = os.path.dirname(sys.executable) if sys.executable else ""
    expected_path = os.path.join(expected_dir, "cont") if expected_dir else ""
    same_venv = bool(primary) and bool(expected_dir) and primary.startswith(
        expected_dir + os.sep
    )

    details = {
        "primary": primary,
        "shadow_count": len(shadows),
        "shadow_paths": shadows,
        "expected_path": expected_path,
        "same_venv_as_python": same_venv,
        "python_executable": sys.executable,
    }

    if primary is None:
        return CheckResult(
            "cont binary path",
            "warn",
            "PATH'te 'cont' yok (codent yüklü ama console script kayıtlı değil mi?)",
            details=details,
        )
    if len(shadows) > 1:
        return CheckResult(
            "cont binary path",
            "warn",
            f"PATH'te {len(shadows)} adet 'cont' var → {primary} öncelikli",
            details=details,
        )
    if not same_venv:
        return CheckResult(
            "cont binary path",
            "warn",
            f"cont {primary} farklı bir virtualenv'de "
            f"(Python: {sys.executable})",
            details=details,
        )
    return CheckResult(
        "cont binary path",
        "ok",
        f"{primary} (Python ile aynı venv)",
        details=details,
    )


__all__ = [
    "KNOWN_BAD_CONTDOCTOR",
    "check_contdoctor_version",
    "check_codent_version",
    "check_binary_path",
]
