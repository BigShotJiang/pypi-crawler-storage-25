"""Model-level checks: registered (catalogue), loaded (RAM/VRAM), responds (ping)."""

import json
import os
import time

from contdoctor.checks.ollama_proc import detect_running_ollama
from contdoctor.core.http import http_get, http_post_json
from contdoctor.core.result import CheckResult
from contdoctor.fixes.model import fix_reload_model, fix_warmup_model

DEFAULT_MODEL = os.environ.get("CONT_MODEL", "cont-local:latest")


def check_model_registered(model: str) -> CheckResult:
    status, body = http_get("/api/tags", timeout=3)
    if status != 200 or not body:
        return CheckResult(f"Model kayıtlı ({model})", "fail", "API erişimi yok")
    try:
        data = json.loads(body)
    except json.JSONDecodeError:
        return CheckResult(f"Model kayıtlı ({model})", "warn", "yanıt parse edilemedi")
    info = next((m for m in data.get("models", []) if m.get("name") == model), None)
    if not info:
        names = sorted(m.get("name", "?") for m in data.get("models", []))
        return CheckResult(
            f"Model kayıtlı ({model})",
            "fail",
            f"yok. Mevcut: {', '.join(names) or '(boş)'}",
        )
    size_gb = info.get("size", 0) / (1024 ** 3)
    return CheckResult(
        f"Model kayıtlı ({model})",
        "ok",
        f"{size_gb:.1f} GB",
        details={"size_bytes": info.get("size"), "modified": info.get("modified_at")},
    )


def check_model_loaded(model: str) -> CheckResult:
    status, body = http_get("/api/ps", timeout=3)
    if status != 200 or not body:
        return CheckResult("Model yüklü", "warn", "API erişimi yok")
    try:
        data = json.loads(body)
    except json.JSONDecodeError:
        return CheckResult("Model yüklü", "warn", "yanıt parse edilemedi")

    running = detect_running_ollama()
    custom = bool(running and running.has_custom_runtime)

    target = next((m for m in data.get("models", []) if m.get("name") == model), None)
    if not target:
        # Sprint 9.1: cold-start fix custom runtime'ı kullanır (HTTP /api/generate)
        # ama o tehlikesiz — yine de kullanıcı domain'inde olduğu için tutarlılık
        # adına fix önermeyelim. Custom runtime → operatör kendi başlatır.
        if custom:
            return CheckResult(
                "Model yüklü",
                "warn",
                f"{model} RAM/VRAM'de yok — custom runtime aktif, fix kullanıcı domain'inde",
                details={"model_name": model, "custom_runtime": True},
            )
        return CheckResult(
            "Model yüklü",
            "warn",
            f"{model} RAM/VRAM'de yok (cold start lazım)",
            fix_label=f"{model} warmup",
            fix_action=lambda: fix_warmup_model(model),
            details={"model_name": model, "custom_runtime": False},
        )
    size = target.get("size", 0)
    size_vram = target.get("size_vram", 0)
    gpu_pct = int(round(100 * size_vram / size)) if size else 0
    details = {
        "gpu_pct": gpu_pct,
        "size_vram": size_vram,
        "size": size,
        "context": target.get("context_length"),
        "model_name": model,
        "custom_runtime": custom,
    }
    msg = f"{model} yüklü, %{gpu_pct} GPU"
    if gpu_pct < 95:
        # Sprint 9.1: custom runtime'da fix_reload_model unload+warmup ile
        # custom env'i koruyamaz, sebep kullanıcı domain'inde — warn döner,
        # fix önerme.
        if custom:
            return CheckResult(
                "Model yüklü",
                "warn",
                msg + " — custom runtime aktif, sebep kullanıcı domain'inde",
                details=details,
            )
        return CheckResult(
            "Model yüklü",
            "fail",
            msg + " — CPU'ya kaymış (yavaş inference)",
            fix_label="unload + GPU'ya yeniden yükle",
            fix_action=lambda: fix_reload_model(model),
            details=details,
        )
    return CheckResult("Model yüklü", "ok", msg, details=details)


def check_model_responds(model: str, hard_timeout: int = 30) -> CheckResult:
    """Model ping testi: 1-token üretim. Yavaşsa CPU fallback sinyali."""
    t0 = time.monotonic()
    status, body = http_post_json(
        "/api/generate",
        {
            "model": model,
            "prompt": "ping",
            "stream": False,
            "options": {"num_predict": 4},
        },
        timeout=hard_timeout,
    )
    elapsed = time.monotonic() - t0
    if status is None:
        return CheckResult(
            "Model yanıt verir",
            "fail",
            f"{elapsed:.1f}s sonra hata: {body}",
            details={"elapsed_s": round(elapsed, 2)},
        )
    if status != 200:
        return CheckResult(
            "Model yanıt verir",
            "fail",
            f"HTTP {status} ({elapsed:.1f}s)",
            details={"elapsed_s": round(elapsed, 2)},
        )
    try:
        data = json.loads(body or "{}")
        resp = data.get("response", "").strip()
    except json.JSONDecodeError:
        return CheckResult("Model yanıt verir", "warn", "yanıt parse edilemedi")
    details = {"elapsed_s": round(elapsed, 2), "response_len": len(resp)}
    if elapsed > 15:
        return CheckResult(
            "Model yanıt verir",
            "warn",
            f"{elapsed:.1f}s — yavaş, model CPU'da olabilir",
            details=details,
        )
    return CheckResult(
        "Model yanıt verir",
        "ok",
        f"{elapsed:.1f}s ({len(resp)} char)",
        details=details,
    )


__all__ = [
    "DEFAULT_MODEL",
    "check_model_registered",
    "check_model_loaded",
    "check_model_responds",
]
