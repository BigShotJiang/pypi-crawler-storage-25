"""Built-in deterministic checks (13 of them)."""

from contdoctor.checks.deployment import (
    check_binary_path,
    check_codent_version,
    check_contdoctor_version,
)
from contdoctor.checks.environment import check_known_environment
from contdoctor.checks.gpu import check_gpu
from contdoctor.checks.model import (
    check_model_loaded,
    check_model_registered,
    check_model_responds,
)
from contdoctor.checks.network import check_network_isolation
from contdoctor.checks.ollama import (
    check_ollama_api,
    check_ollama_env,
    check_ollama_installed,
    check_ollama_process,
    check_ollama_version,
)
from contdoctor.checks.ollama_log import check_ollama_gpu_offload_log
from contdoctor.checks.ollama_runners import check_ollama_gpu_runners
from contdoctor.checks.ollama_snapshot_match import check_ollama_proc_matches_snapshot
from contdoctor.checks.snapshot_drift import check_environment_drift
from contdoctor.checks.system import check_disk_space, check_glibc, check_python_env
from contdoctor.checks.workload import check_realistic_workload

__all__ = [
    "check_gpu",
    "check_ollama_installed",
    "check_ollama_version",
    "check_ollama_process",
    "check_ollama_env",
    "check_ollama_api",
    "check_ollama_gpu_runners",
    "check_ollama_gpu_offload_log",
    "check_model_registered",
    "check_model_loaded",
    "check_model_responds",
    "check_disk_space",
    "check_glibc",
    "check_network_isolation",
    "check_python_env",
    "check_contdoctor_version",
    "check_codent_version",
    "check_binary_path",
    "check_environment_drift",
    "check_known_environment",
    "check_ollama_proc_matches_snapshot",
    "check_realistic_workload",
]
