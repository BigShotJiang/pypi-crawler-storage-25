"""``check_known_environment`` — fingerprint'e uyan profil var mı?

Tüm runtime check'lerin ÖNÜNDE çalışır. Bağlam: doctor "ben hangi
makineyim" sorusunu kendi cevaplar; Sertan'ın sonraki çıktıları profile
referansıyla okuyabilir.
"""

from __future__ import annotations

from dataclasses import asdict

from contdoctor.core.result import CheckResult
from contdoctor.snapshot.fingerprint import compute_fingerprint, guess_role
from contdoctor.snapshot.profiles import load_known_environments, match_profile


def check_known_environment() -> CheckResult:
    fp = compute_fingerprint()
    envs = load_known_environments()
    profile = match_profile(fp, envs)

    if profile is not None:
        return CheckResult(
            "Environment profili",
            "ok",
            f"Tanınan profil: {profile['id']} ({profile.get('label', '-')})",
            details={
                "profile_id": profile["id"],
                "role": profile.get("role"),
                "notes": profile.get("notes", ""),
                "fingerprint": asdict(fp),
                "expected": profile.get("expected", {}),
            },
        )

    return CheckResult(
        "Environment profili",
        "warn",
        f"Bilinmeyen profil (hostname={fp.hostname}, role_hint={guess_role(fp)})",
        details={
            "fingerprint": asdict(fp),
            "known_count": len(envs),
            "hint": (
                "User override: ~/.contdoctor/environments.yaml içinde "
                "fingerprint pattern'leri tanımlayabilirsiniz."
            ),
        },
    )


__all__ = ["check_known_environment"]
