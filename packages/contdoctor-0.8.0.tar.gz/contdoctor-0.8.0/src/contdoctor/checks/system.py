"""System-level checks: disk space, glibc version, Python env."""

import os
import re
import shutil
import sys
from pathlib import Path

from contdoctor.core.proc import run
from contdoctor.core.result import CheckResult


def check_disk_space() -> CheckResult:
    candidates = [Path.home() / ".ollama", Path("/var/lib/ollama"), Path("/tmp")]
    found = next((p for p in candidates if p.exists()), None)
    if not found:
        return CheckResult("Disk", "warn", "ollama veri dizini bulunamadı")
    u = shutil.disk_usage(found)
    free_gb = u.free / (1024 ** 3)
    total_gb = u.total / (1024 ** 3)
    pct = 100 * u.free / u.total
    msg = f"{found}: {free_gb:.1f}/{total_gb:.1f} GB boş ({pct:.0f}%)"
    details = {
        "path": str(found),
        "free_gb": round(free_gb, 2),
        "total_gb": round(total_gb, 2),
    }
    if free_gb < 5:
        return CheckResult("Disk", "fail", msg + " — kritik", details=details)
    if free_gb < 20:
        return CheckResult("Disk", "warn", msg, details=details)
    return CheckResult("Disk", "ok", msg, details=details)


def check_glibc() -> CheckResult:
    rc, out, _ = run(["ldd", "--version"], timeout=3)
    if rc != 0:
        return CheckResult("GLIBC", "warn", "ldd çalıştırılamadı")
    m = re.search(r"(\d+\.\d+)", out)
    if not m:
        return CheckResult("GLIBC", "warn", f"parse edilemedi: {out.splitlines()[0]}")
    return CheckResult("GLIBC", "ok", f"v{m.group(1)}", details={"version": m.group(1)})


def check_python_env() -> CheckResult:
    py = sys.version.split()[0]
    conda = os.environ.get("CONDA_DEFAULT_ENV", "")
    details = {"python": py, "conda_env": conda}
    parts = [f"Python {py}"]
    if conda:
        parts.append(f"env={conda}")
    try:
        import codent  # type: ignore  # noqa: F401

        details["codent_version"] = getattr(__import__("codent"), "__version__", "?")
        parts.append(f"codent={details['codent_version']}")
        status = "ok"
    except ImportError:
        parts.append("codent: import yok")
        status = "warn"
    return CheckResult("Python env", status, " | ".join(parts), details=details)


__all__ = ["check_disk_space", "check_glibc", "check_python_env"]
