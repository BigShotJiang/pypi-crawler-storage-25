"""GPU runner library presence + env-path consistency check.

Sprint 7'nin temel iddiası: ``OLLAMA_NUM_GPU=999`` veya Modelfile
``num_gpu 999`` library yoksa anlamsız. Doctor'un işi env var'a güvenmek
değil, library'lerin gerçekten var olduğunu doğrulamak.

Sprint 7.1 düzeltmeleri:
  * Eğer log "offloaded N/N layers (full GPU)" diyorsa env'in ne
    işaret ettiği fark etmez — observable kanıt config kuralından
    önceliklidir. Runner ok döner.
  * Library Ollama'nın *default* arama path'inde
    (``/usr/local/lib/ollama[/cuda_v12]``) bulunduysa env zorunlu
    değil — Ollama oraya kendiliğinden bakar.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Set

from contdoctor.checks.ollama_log import model_full_gpu_in_log
from contdoctor.core.result import CheckResult
from contdoctor.fixes.runners import (
    fix_print_runner_transfer_block,
    fix_set_ollama_runners_path,
)

REQUIRED_LIBS = frozenset(
    {
        "libggml-cuda.so",
        "libcublas.so.12",
        "libcublasLt.so.12",
        "libcudart.so.12",
    }
)

# Ollama'nın native default arama path'leri — env set edilmezse buralarda
# library bulunursa Ollama oraya bakar. Bu path'lerde lib bulunduysa env
# warn'ı üretmek gereksiz gürültüdür.
_OLLAMA_DEFAULT_PATHS = frozenset(
    {
        "/usr/local/lib/ollama",
        "/usr/local/lib/ollama/cuda_v12",
    }
)

_OFFLOAD_RE = re.compile(
    r"offloaded\s+(\d+)/(\d+)\s+layers\s+to\s+GPU", re.IGNORECASE
)

# Default arama path'leri — env override'a göre öncelikli, sonra sistem.
def _default_paths() -> List[Path]:
    return [
        Path("/usr/local/lib/ollama/cuda_v12"),
        Path.home() / "ollama-full/lib/ollama/cuda_v12",
        Path.home() / "ollama-full/lib/ollama",
        Path.home() / "ollama-full/usr/local/lib/ollama/cuda_v12",
        Path.home() / "ollama-full/usr/local/lib/ollama",
    ]


def _env_paths() -> List[tuple[str, Path]]:
    out: List[tuple[str, Path]] = []
    for var in ("OLLAMA_LLM_LIBRARY", "OLLAMA_RUNNERS_DIR"):
        v = os.environ.get(var)
        if v:
            out.append((var, Path(v)))
    return out


def _scan(path: Path) -> Set[str]:
    """``path`` veya ``path/cuda_v12`` altında REQUIRED_LIBS'in hangileri var."""
    present: Set[str] = set()
    for sub in (path, path / "cuda_v12"):
        try:
            if not sub.is_dir():
                continue
        except OSError:
            continue
        for lib in REQUIRED_LIBS:
            try:
                if (sub / lib).exists():
                    present.add(lib)
            except OSError:
                continue
    return present


def _resolve_eq(a: str, b: str) -> bool:
    """Path eşitliği — trailing slash farkını yutar, resolve()'e ihtiyaç yok."""
    return a.rstrip("/") == b.rstrip("/")


def _model_specific_full_gpu(target_model: Optional[str]) -> bool:
    """Sprint 7.2: log evidence override **artık target_model için**.

    ``target_model=None`` ise None döner (eski "herhangi bir 49/49"
    davranışı yanıltıcıydı; başka model için tam offload doğru modelin
    %0'da olduğunu maskeleyebilir). None çağrısı log evidence override
    devre dışı kalır.
    """
    if not target_model:
        return False
    return model_full_gpu_in_log(target_model)


def _is_default_path(path: str) -> bool:
    return path.rstrip("/") in _OLLAMA_DEFAULT_PATHS


def check_ollama_gpu_runners(target_model: Optional[str] = None) -> CheckResult:
    """4 statü:

    * **ok**   — bir path tüm 4 library'i barındırıyor + env doğru gösteriyor
    * **warn** — library'ler doğru path'te ama env yanlış (otomatik düzeltilebilir)
    * **fail** — bir path eksik library içeriyor *veya* hiçbir path'te library yok
    """
    env_paths = _env_paths()
    defaults = _default_paths()
    candidates = [p for _, p in env_paths] + defaults

    found_in: Dict[str, Set[str]] = {}
    for p in candidates:
        present = _scan(p)
        if present:
            found_in[str(p)] = present

    details = {
        "env_paths": [str(p) for _, p in env_paths],
        "default_paths_checked": [str(p) for p in defaults],
        "found_in": {k: sorted(v) for k, v in found_in.items()},
        "required": sorted(REQUIRED_LIBS),
    }

    if not found_in:
        return CheckResult(
            "GPU runner library",
            "fail",
            "GPU runner library'leri hiçbir path'te bulunamadı — manual transfer gerek",
            fix_label="Manual transfer talimatı bas",
            fix_action=fix_print_runner_transfer_block,
            details=details,
        )

    # En zengin path (en çok lib barındıran) → "best" candidate.
    best_path, best_libs = max(found_in.items(), key=lambda kv: len(kv[1]))
    missing = REQUIRED_LIBS - best_libs

    if missing:
        return CheckResult(
            "GPU runner library",
            "fail",
            f"{best_path}: eksik library: {sorted(missing)}",
            fix_label="Manual transfer talimatı bas (eksik library'ler)",
            fix_action=fix_print_runner_transfer_block,
            details=details,
        )

    # Sprint 7.2 — observable evidence wins over config heuristic, BUT
    # log offload satırının target model için olduğu doğrulanmalı.
    # target_model=None çağrılırsa override devre dışı (Sprint 7.1'in
    # model-bağımsız helper'ı yanıltıcıydı; başka model için 49/49
    # gerçek hedef modelin %0'da olduğunu maskeleyebilir).
    if _model_specific_full_gpu(target_model):
        return CheckResult(
            "GPU runner library",
            "ok",
            f"{best_path}: {len(best_libs)} library; "
            f"log {target_model} için full GPU doğruluyor",
            details={**details, "evidence": f"log: {target_model} full GPU"},
        )

    # Sprint 7.1 — default path muafiyeti. Ollama /usr/local/lib/ollama'ya
    # kendiliğinden bakar; env set etmek zorunlu değil.
    if _is_default_path(best_path):
        return CheckResult(
            "GPU runner library",
            "ok",
            f"{best_path}: {len(best_libs)} library (Ollama default path, env zorunlu değil)",
            details={**details, "evidence": "default ollama search path"},
        )

    env_correct = any(
        _resolve_eq(str(p), best_path)
        or _resolve_eq(str(p / "cuda_v12"), best_path)
        for _, p in env_paths
    )

    if not env_correct:
        best_path_obj = Path(best_path)
        return CheckResult(
            "GPU runner library",
            "warn",
            f"Library'ler {best_path} altında — non-default path, env set edilmeli",
            fix_label=f"OLLAMA_LLM_LIBRARY={best_path} ile ollama serve restart",
            fix_action=lambda p=best_path_obj: fix_set_ollama_runners_path(p),
            details=details,
        )

    return CheckResult(
        "GPU runner library",
        "ok",
        f"{best_path}: {len(best_libs)} library mevcut, env doğru",
        details=details,
    )


__all__ = ["REQUIRED_LIBS", "check_ollama_gpu_runners"]
