"""Inverse network check: external host reachability is a leak in bank prod."""

from contdoctor.core.proc import port_open
from contdoctor.core.result import CheckResult


def check_network_isolation() -> CheckResult:
    """Banka için: dışarı çıkış olmamalı. Ulaşılabilir external host = leak."""
    leak_targets = [
        ("api.openai.com", 443),
        ("api.anthropic.com", 443),
        ("github.com", 443),
        ("8.8.8.8", 53),
    ]
    leaked = [f"{h}:{p}" for h, p in leak_targets if port_open(h, p, timeout=1.0)]
    if leaked:
        return CheckResult(
            "Network izolasyonu",
            "warn",
            f"DIŞARI ÇIKIŞ TESPİT: {', '.join(leaked)}",
            details={"leaks": leaked},
        )
    return CheckResult(
        "Network izolasyonu",
        "ok",
        "external host'lara erişim yok (banka için doğru)",
    )


__all__ = ["check_network_isolation"]
