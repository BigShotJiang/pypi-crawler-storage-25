"""Ollama-related checks: binary, version, process, env, API.

Sprint 9: ``shutil.which("ollama")`` PATH'i gösterir, ama Sertan
``~/ollama-full/bin/ollama`` ile özel env'lerde çalıştırıyor. Doctor
artık önce ``detect_running_ollama()`` ile gerçekten çalışan binary'i
buluyor (``/proc/<pid>/exe``). PATH ikincil — sadece process yoksa
fallback. Custom-launched setup tespit edilirse ``check_ollama_env``
fix önermez (kanıt: lessons #6).
"""

import json
import os
import re
import shutil
from pathlib import Path

from contdoctor.checks.ollama_proc import detect_running_ollama
from contdoctor.core.http import OLLAMA_HOST, http_get
from contdoctor.core.proc import pgrep, port_open
from contdoctor.core.result import CheckResult
from contdoctor.fixes.ollama import fix_restart_ollama, fix_set_ollama_num_gpu, fix_start_ollama
from contdoctor.fixes.snapshot_restore import fix_restore_ollama_from_snapshot

# Bilinen problemli Ollama versiyonları (regression olanlar)
KNOWN_BAD_OLLAMA = {
    "0.20.3": "GPU layer auto-detection regressed — OLLAMA_NUM_GPU=999 zorla gerekli",
}

# GPU discovery'yi zehirleyen env var'lar
POISON_ENV_VARS = {
    "OLLAMA_LLM_LIBRARY": "GPU discovery'yi bozar; unset edilmeli",
    "CUDA_VISIBLE_DEVICES": "boş set edilmişse GPU gizlenir",  # özel kontrol var
}


def check_ollama_installed() -> CheckResult:
    """Çalışan ollama binary'i raporla (PATH değil). PATH'tekiyle farklıysa
    "shadowed" details ekle — operatör hangi binary'nin gerçekten
    kullanıldığını görsün.
    """
    running = detect_running_ollama()
    which_path = shutil.which("ollama") or ""

    if running and running.binary_path:
        differs = bool(which_path) and which_path != running.binary_path
        suffix = (
            f" (PATH'te farklı: {which_path} — bu kullanılmıyor)" if differs else ""
        )
        return CheckResult(
            "Ollama binary",
            "ok",
            f"{running.binary_path}{suffix}",
            details={
                "running_binary": running.binary_path,
                "path_binary": which_path,
                "shadowed": differs,
                "running_pid": running.pid,
            },
        )

    if not which_path:
        return CheckResult("Ollama binary", "fail", "ollama PATH'te yok")
    return CheckResult(
        "Ollama binary",
        "ok",
        which_path,
        details={"path_binary": which_path, "running": False},
    )


def check_ollama_version() -> CheckResult:
    """Çalışan binary'den ``--version``. Yoksa PATH fallback.

    0.20.3 gibi bilinen-bozuk versiyonlar warning olarak raporlanır ama
    **fix_action önerilmez** — Sertan kanıtı (Sprint 9): otomatik fix
    custom-launched setup'ı bozuyordu.
    """
    from contdoctor.core.proc import run

    running = detect_running_ollama()
    binary = (
        running.binary_path
        if running and running.binary_path
        else shutil.which("ollama")
    )
    if not binary:
        return CheckResult("Ollama versiyon", "fail", "ollama binary yok")

    rc, out, _ = run([binary, "--version"], timeout=5)
    if rc != 0:
        return CheckResult("Ollama versiyon", "fail", "ollama --version başarısız")
    m = re.search(r"(\d+\.\d+\.\d+)", out)
    if not m:
        return CheckResult(
            "Ollama versiyon", "warn", f"parse edilemedi: {out.strip()}"
        )
    version = m.group(1)
    details = {"version": version, "binary": binary, "from_running_process": bool(running)}
    if version in KNOWN_BAD_OLLAMA:
        # Sprint 9: warning kalır, fix YOK (custom setup'ı korumak için).
        return CheckResult(
            "Ollama versiyon",
            "warn",
            f"v{version} — {KNOWN_BAD_OLLAMA[version]}",
            details=details,
        )
    return CheckResult("Ollama versiyon", "ok", f"v{version}", details=details)


def check_ollama_process() -> CheckResult:
    pids = pgrep("ollama serve")
    p_open = port_open("127.0.0.1", 11434)
    running = detect_running_ollama()
    custom = bool(running and running.has_custom_runtime)

    if not pids and not p_open:
        # Sprint 9.2: snapshot varsa kanonik komutla restore öner; yoksa
        # eski default fix_start_ollama'ya düş.
        snapshot_path = Path(
            os.environ.get("CONTDOCTOR_SNAPSHOT", "~/.contdoctor/snapshot.yaml")
        ).expanduser()
        if snapshot_path.is_file():
            return CheckResult(
                "Ollama process",
                "fail",
                "ollama serve çalışmıyor — snapshot'tan restore edilecek",
                fix_label="snapshot'tan kanonik komutla başlat",
                fix_action=fix_restore_ollama_from_snapshot,
                details={"snapshot_path": str(snapshot_path)},
            )
        return CheckResult(
            "Ollama process",
            "fail",
            "ollama serve çalışmıyor, port 11434 kapalı (snapshot yok, default ile başlatılacak)",
            fix_label="ollama serve başlat (default)",
            fix_action=fix_start_ollama,
        )
    if not pids and p_open:
        return CheckResult(
            "Ollama process",
            "warn",
            "port 11434 açık ama 'ollama serve' process yok (farklı bir process mi dinliyor?)",
            details={"port_open": True, "pids": []},
        )
    if pids and not p_open:
        # Sprint 9.1: custom runtime'da zombie restart'ı kullanıcı setup'ını
        # bozar. Sadece raporla, fix önerme.
        if custom:
            return CheckResult(
                "Ollama process",
                "warn",
                f"PID {pids} var, port 11434 dinlemiyor — custom runtime aktif, fix kullanıcı domain'inde",
                details={"pids": pids, "port_open": False, "custom_runtime": True},
            )
        return CheckResult(
            "Ollama process",
            "fail",
            f"ollama serve var (PID {pids}) ama port 11434 dinlemiyor",
            fix_label="zombie ollama'yı kill et ve yeniden başlat",
            fix_action=lambda p=pids: fix_restart_ollama(p),
            details={"pids": pids, "port_open": False},
        )
    extra = f" (+{len(pids)-1} ek process)" if len(pids) > 1 else ""
    suffix = " (custom runtime)" if custom else ""
    return CheckResult(
        "Ollama process",
        "ok",
        f"PID {pids[0]}, port 11434 açık{extra}{suffix}",
        details={"pids": pids, "port_open": True, "custom_runtime": custom},
    )


def check_ollama_env() -> CheckResult:
    """OLLAMA_NUM_GPU + poison env vars.

    Sprint 9 davranışı:
      * Çalışan process varsa onun env'i kanonik (shell değil).
      * ``LD_LIBRARY_PATH`` veya ``OLLAMA_RUNNERS_DIR`` set ise:
        custom-launched setup → "kullanıcı kendi başlatmış" → fix önerilmez.
        Auto-fix bu setup'ı bozar (kanıt: lessons #6).
    """
    running = detect_running_ollama()
    proc_env = running.env if running else {}
    shell_val = os.environ.get("OLLAMA_NUM_GPU")
    proc_val = proc_env.get("OLLAMA_NUM_GPU")

    issues: list = []
    fixable = False

    if not shell_val and not proc_val:
        issues.append(
            "OLLAMA_NUM_GPU set değil (Ollama 0.20.3'te model GPU'ya yüklenmeyebilir)"
        )
        fixable = True

    poison_found: list = []
    # Poison check'leri shell + process env birleştirip bak (her iki taraf
    # da tehlike kaynağı olabilir).
    combined = {**os.environ, **proc_env}
    for var, why in POISON_ENV_VARS.items():
        v = combined.get(var)
        if var == "CUDA_VISIBLE_DEVICES":
            if v == "":
                poison_found.append(f"{var} (boş — GPU gizleniyor)")
        elif v is not None:
            poison_found.append(f"{var}={v} ({why})")

    if poison_found:
        issues.append("zehirli env var: " + "; ".join(poison_found))

    custom_runtime = bool(running and running.has_custom_runtime)

    details = {
        "OLLAMA_NUM_GPU_shell": shell_val,
        "OLLAMA_NUM_GPU_process": proc_val,
        "poison": poison_found,
        "custom_runtime": custom_runtime,
        "LD_LIBRARY_PATH": proc_env.get("LD_LIBRARY_PATH"),
        "OLLAMA_RUNNERS_DIR": proc_env.get("OLLAMA_RUNNERS_DIR"),
        "OLLAMA_HOST": proc_env.get("OLLAMA_HOST"),
    }

    if not issues:
        if custom_runtime:
            extras = []
            if proc_env.get("LD_LIBRARY_PATH"):
                extras.append("LD_LIBRARY_PATH özel")
            if proc_env.get("OLLAMA_RUNNERS_DIR"):
                extras.append("OLLAMA_RUNNERS_DIR özel")
            extras_msg = ", " + ", ".join(extras) if extras else ""
            return CheckResult(
                "Env değişkenleri",
                "ok",
                f"OLLAMA_NUM_GPU={shell_val or proc_val}{extras_msg} — kanıt: çalışan process",
                details=details,
            )
        src = "process" if proc_val and not shell_val else "shell"
        return CheckResult(
            "Env değişkenleri",
            "ok",
            f"OLLAMA_NUM_GPU={shell_val or proc_val} ({src}), zehirli var yok",
            details=details,
        )

    # Custom-launched setup: doctor karışmasın (Sprint 9 critical lesson +
    # Sprint 9.1 hard guard — fix HİÇ önerilmez, label ve action kesinlikle
    # None).
    if custom_runtime:
        return CheckResult(
            "Env değişkenleri",
            "warn",
            " | ".join(issues)
            + " — custom-launched setup tespit edildi, otomatik fix devre dışı",
            details=details,
        )

    return CheckResult(
        "Env değişkenleri",
        "warn",
        " | ".join(issues),
        fix_label=(
            "OLLAMA_NUM_GPU=999 ile ollama serve'i yeniden başlat" if fixable else None
        ),
        fix_action=fix_set_ollama_num_gpu if fixable else None,
        details={**details, "custom_runtime": False},
    )


def check_ollama_api() -> CheckResult:
    status, body = http_get("/api/tags", timeout=3)
    if status is None:
        return CheckResult("Ollama API", "fail", f"{OLLAMA_HOST}/api/tags ulaşılamıyor: {body}")
    if status != 200:
        return CheckResult("Ollama API", "fail", f"HTTP {status}")
    try:
        data = json.loads(body or "{}")
        models = [m.get("name") for m in data.get("models", [])]
    except (json.JSONDecodeError, AttributeError):
        return CheckResult("Ollama API", "warn", f"yanıt parse edilemedi: {(body or '')[:80]}")
    return CheckResult(
        "Ollama API",
        "ok",
        f"{len(models)} model kayıtlı",
        details={"models": models},
    )


__all__ = [
    "KNOWN_BAD_OLLAMA",
    "POISON_ENV_VARS",
    "check_ollama_installed",
    "check_ollama_version",
    "check_ollama_process",
    "check_ollama_env",
    "check_ollama_api",
]
