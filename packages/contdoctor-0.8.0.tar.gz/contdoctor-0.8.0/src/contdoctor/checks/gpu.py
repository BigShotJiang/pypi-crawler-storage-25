"""GPU presence + driver/temperature check (uses nvidia-smi)."""

import shutil

from contdoctor.core.proc import run
from contdoctor.core.result import CheckResult


def check_gpu() -> CheckResult:
    if not shutil.which("nvidia-smi"):
        return CheckResult("GPU", "fail", "nvidia-smi bulunamadı (driver yüklü mü?)")
    rc, out, err = run(
        [
            "nvidia-smi",
            "--query-gpu=name,driver_version,memory.total,memory.used,temperature.gpu",
            "--format=csv,noheader,nounits",
        ],
        timeout=10,
    )
    if rc != 0:
        return CheckResult("GPU", "fail", f"nvidia-smi başarısız: {err.strip() or out.strip()}")
    line = (out.strip().splitlines() or [""])[0]
    parts = [p.strip() for p in line.split(",")]
    if len(parts) < 5:
        return CheckResult("GPU", "warn", f"beklenmedik çıktı: {line}")
    try:
        name, driver = parts[0], parts[1]
        total, used, temp = int(parts[2]), int(parts[3]), int(parts[4])
    except ValueError:
        return CheckResult("GPU", "warn", f"sayı parse edilemedi: {line}")
    details = {
        "name": name,
        "driver": driver,
        "vram_total_mb": total,
        "vram_used_mb": used,
        "temp_c": temp,
    }
    msg = f"{name} | driver {driver} | VRAM {used}/{total} MB | {temp}°C"
    if temp > 85:
        return CheckResult("GPU", "warn", msg + " (sıcak — termal throttle)", details=details)
    return CheckResult("GPU", "ok", msg, details=details)


__all__ = ["check_gpu"]
