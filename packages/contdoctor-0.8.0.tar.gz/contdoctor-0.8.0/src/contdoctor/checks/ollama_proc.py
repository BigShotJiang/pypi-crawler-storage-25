"""Detect the *actually running* ``ollama serve`` process.

Sertan kanıtı (Sprint 9): ``shutil.which("ollama")`` PATH'teki binary'i
gösterir, ama Sertan ``~/ollama-full/bin/ollama`` ile özel env'lerde
ollama serve çalıştırıyor. Doctor PATH'e güvenince yanlış versiyon
raporluyor + bilinen-iyi setup'ı bozan fix öneriyor.

Kanonik bilgi kaynağı: ``pgrep ollama serve`` → ``/proc/<pid>/exe``
(symlink ile gerçek binary), ``/proc/<pid>/cmdline`` (argv null-sep),
``/proc/<pid>/environ`` (env null-sep). Linux standardı, banka için OK.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from contdoctor.core.proc import pgrep


@dataclass
class RunningOllama:
    pid: int
    binary_path: str
    cmdline: List[str] = field(default_factory=list)
    env: Dict[str, str] = field(default_factory=dict)
    detected_via: str = "pgrep+/proc"

    @property
    def has_custom_runtime(self) -> bool:
        """Custom-launched setup tespiti. Üç sinyalden biri:
          * ``LD_LIBRARY_PATH`` set
          * ``OLLAMA_RUNNERS_DIR`` set
          * binary path system path'leri (``/usr/`` öneki) dışında

        Sprint 9.1 (canlı prod kanıtı): Sertan ``~/ollama-full/bin/ollama``
        kullanıyor; LD_LIBRARY_PATH/OLLAMA_RUNNERS_DIR dolu. Üç sinyalden
        herhangi biri True ise doctor fix önermez.
        """
        if self.env.get("LD_LIBRARY_PATH"):
            return True
        if self.env.get("OLLAMA_RUNNERS_DIR"):
            return True
        if self.binary_path and not self.binary_path.startswith("/usr/"):
            return True
        return False


def detect_running_ollama() -> Optional[RunningOllama]:
    """``ollama serve`` process'ini bul, gerçek binary path + env + cmdline al.

    Birden fazla varsa en eskisi (PID listesinin ilki — ``pgrep``'in
    chrono sırası) seçilir. Hiçbiri yoksa None.
    """
    pids = pgrep("ollama serve")
    if not pids:
        return None
    pid = pids[0]
    proc_dir = Path(f"/proc/{pid}")

    binary_path = ""
    try:
        binary_path = str((proc_dir / "exe").resolve())
    except (OSError, PermissionError):
        binary_path = ""

    cmdline: List[str] = []
    try:
        cmdline_raw = (proc_dir / "cmdline").read_bytes()
        cmdline = [
            a for a in cmdline_raw.decode(errors="replace").split("\x00") if a
        ]
    except (OSError, PermissionError):
        cmdline = []

    env: Dict[str, str] = {}
    try:
        environ_raw = (proc_dir / "environ").read_bytes()
        for kv in environ_raw.decode(errors="replace").split("\x00"):
            if "=" in kv:
                k, v = kv.split("=", 1)
                env[k] = v
    except (OSError, PermissionError):
        env = {}

    return RunningOllama(
        pid=pid,
        binary_path=binary_path,
        cmdline=cmdline,
        env=env,
        detected_via="pgrep+/proc",
    )


__all__ = ["RunningOllama", "detect_running_ollama"]
