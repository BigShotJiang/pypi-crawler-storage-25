"""Ollama log analysis — "offloaded X/Y layers to GPU" + critical errors.

Sprint 7.2: ``check_ollama_gpu_offload_log`` artık model-aware. ``target_model``
verilmişse (default Sprint runtime ``args.model``) önce o modelin son load
event'i bulunur, sonra o noktadan **sonraki** ilk offload satırı okunur.
Aynı pencerede kritik error pattern'leri (``library not found``, vb.) de
yakalanır. ``target_model=None`` çağrısı eski "herhangi bir offload
satırı" davranışını korur — geriye uyumlu.

Log path öncelik:
  1. ``~/.cache/cont/ollama_serve.log``
  2. ``~/.ollama/logs/server.log``
  3. ``journalctl -u ollama --no-pager -n 500`` fallback
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import List, Optional, Tuple

from contdoctor.core.proc import run as _run
from contdoctor.core.result import CheckResult

_OFFLOAD_RE = re.compile(
    r"offloaded\s+(\d+)/(\d+)\s+layers\s+to\s+GPU", re.IGNORECASE
)

# 50-satır pencere — load event'inden sonra ne kadar bakacağız.
_LOAD_EVENT_WINDOW = 50

_ERROR_PATTERNS: Tuple[Tuple[str, str], ...] = (
    ("library not found", "GPU runner library bulunamadı"),
    ("no compatible gpus", "Uyumsuz GPU"),
    ("cuda error", "CUDA runtime hatası"),
    ("compute capability", "Compute capability uyumsuz"),
    ("total vram=0", "VRAM 0 byte (GPU detect edilmedi)"),
    ("insufficient memory", "Yetersiz bellek"),
)


def _read_log() -> Tuple[Optional[str], Optional[str]]:
    """``(text, source)`` — ya dosyadan ya journalctl'dan; ya da ``(None, None)``."""
    log_paths: List[Path] = [
        Path.home() / ".cache/cont/ollama_serve.log",
        Path.home() / ".ollama/logs/server.log",
    ]
    for p in log_paths:
        try:
            if not p.is_file():
                continue
            text = p.read_text(errors="replace")
        except OSError:
            continue
        return text[-100_000:], str(p)

    rc, out, _ = _run(["journalctl", "-u", "ollama", "--no-pager", "-n", "500"], timeout=5)
    if rc == 0 and out.strip():
        return out, "journalctl -u ollama"
    return None, None


def _detected_errors(log_text: str) -> List[str]:
    lower = log_text.lower()
    return [desc for needle, desc in _ERROR_PATTERNS if needle in lower]


def _load_event_patterns(model: str) -> List[re.Pattern]:
    """Model load event marker'ları — Ollama versiyon farkları için
    birden fazla pattern. ``model`` regex.escape edildiği için ``:``
    gibi karakterler literal eşleşir."""
    escaped = re.escape(model)
    return [
        # `loading model <X>` (whitespace separator zorunlu)
        re.compile(rf"loading\s+model\s+{escaped}", re.IGNORECASE),
        # `model=<X>` veya `model: <X>` (separator opsiyonel boşluk)
        re.compile(rf"model\s*[=:]\s*{escaped}\b", re.IGNORECASE),
        # `starting llama server ... <X>`
        re.compile(rf"starting\s+llama\s+server\b.*\b{escaped}", re.IGNORECASE),
    ]


def model_full_gpu_in_log(model: str) -> bool:
    """Quick boolean — used by ``check_ollama_gpu_runners`` to override
    env warn'ı when the *target model* is provably running on GPU."""
    log_text, _ = _read_log()
    if not log_text:
        return False
    last_load_idx = _find_last_load_event(log_text.splitlines(), model)
    if last_load_idx == -1:
        return False
    window = log_text.splitlines()[last_load_idx : last_load_idx + _LOAD_EVENT_WINDOW]
    for line in window:
        m = _OFFLOAD_RE.search(line)
        if m:
            x, y = int(m.group(1)), int(m.group(2))
            return x > 0 and x == y
    return False


def _find_last_load_event(lines: List[str], model: str) -> int:
    patterns = _load_event_patterns(model)
    last = -1
    for i, line in enumerate(lines):
        if any(p.search(line) for p in patterns):
            last = i
    return last


def _check_any_offload(log_text: str, source: str) -> CheckResult:
    """Eski (model-bağımsız) davranış — herhangi bir offload satırı."""
    matches = list(_OFFLOAD_RE.finditer(log_text))
    errors = _detected_errors(log_text)
    details = {"log_source": source, "errors": errors}

    if not matches:
        msg = "Log'da 'offloaded X/Y layers' satırı yok (model henüz yüklenmedi olabilir)"
        if errors:
            return CheckResult(
                "Ollama GPU offload log",
                "fail",
                f"{msg} | Hatalar: {', '.join(errors)}",
                details=details,
            )
        return CheckResult("Ollama GPU offload log", "warn", msg, details=details)

    last = matches[-1]
    x, y = int(last.group(1)), int(last.group(2))
    details["offloaded_layers"] = f"{x}/{y}"

    if x == 0 and y > 0:
        msg = f"offloaded 0/{y} layers — model TAMAMEN CPU'da"
        if errors:
            msg += f" | Sebep: {', '.join(errors)}"
        return CheckResult("Ollama GPU offload log", "fail", msg, details=details)

    if x < y:
        msg = f"offloaded {x}/{y} layers — kısmi GPU offload"
        if errors:
            return CheckResult(
                "Ollama GPU offload log",
                "fail",
                f"{msg} | Hatalar: {', '.join(errors)}",
                details=details,
            )
        return CheckResult("Ollama GPU offload log", "warn", msg, details=details)

    return CheckResult(
        "Ollama GPU offload log",
        "ok",
        f"offloaded {x}/{y} layers (full GPU)",
        details=details,
    )


def _check_model_specific_offload(
    log_text: str, source: str, model: str
) -> CheckResult:
    """target model'in son load event'i + sonraki offload + aynı penceredeki
    error pattern'leri."""
    lines = log_text.splitlines()
    last_load_idx = _find_last_load_event(lines, model)

    any_offload: Optional[str] = None
    all_matches = list(_OFFLOAD_RE.finditer(log_text))
    if all_matches:
        m = all_matches[-1]
        any_offload = f"{m.group(1)}/{m.group(2)}"

    if last_load_idx == -1:
        return CheckResult(
            "Ollama GPU offload log",
            "warn",
            f"Log'da {model} için load event yok (henüz yüklenmedi)",
            details={
                "log_source": source,
                "target_model": model,
                "any_offload": any_offload,
            },
        )

    window = lines[last_load_idx : last_load_idx + _LOAD_EVENT_WINDOW]
    window_text = "\n".join(window)
    offload_match = _OFFLOAD_RE.search(window_text)
    errors = _detected_errors(window_text)

    details = {
        "log_source": source,
        "target_model": model,
        "load_event_line": last_load_idx,
        "errors": errors,
    }

    if not offload_match:
        msg = f"{model} load event sonrası offload satırı yok"
        if errors:
            return CheckResult(
                "Ollama GPU offload log",
                "fail",
                f"{msg} | Hatalar: {', '.join(errors)}",
                details=details,
            )
        return CheckResult("Ollama GPU offload log", "warn", msg, details=details)

    x, y = int(offload_match.group(1)), int(offload_match.group(2))
    details["offloaded_layers"] = f"{x}/{y}"

    if x == 0 and y > 0:
        msg = f"{model}: offloaded 0/{y} layers — CPU'da"
        if errors:
            msg += f" | Sebep: {', '.join(errors)}"
        return CheckResult("Ollama GPU offload log", "fail", msg, details=details)

    if x < y:
        return CheckResult(
            "Ollama GPU offload log",
            "warn",
            f"{model}: {x}/{y} layers — kısmi GPU offload",
            details=details,
        )

    return CheckResult(
        "Ollama GPU offload log",
        "ok",
        f"{model}: {x}/{y} layers (full GPU)",
        details=details,
    )


def check_ollama_gpu_offload_log(target_model: Optional[str] = None) -> CheckResult:
    log_text, source = _read_log()
    if log_text is None:
        return CheckResult(
            "Ollama GPU offload log",
            "warn",
            "Ollama log bulunamadı (server.log yok, journalctl boş)",
        )
    if target_model is None:
        return _check_any_offload(log_text, source)
    return _check_model_specific_offload(log_text, source, target_model)


__all__ = [
    "check_ollama_gpu_offload_log",
    "model_full_gpu_in_log",
]
