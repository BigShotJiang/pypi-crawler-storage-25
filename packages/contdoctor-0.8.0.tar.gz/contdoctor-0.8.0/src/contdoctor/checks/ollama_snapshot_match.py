"""``check_ollama_proc_matches_snapshot`` — Sprint 9.2.

Çalışan ollama process'i, snapshot'taki kanonik binary + env'lerle
uyuşmazsa raporlar ve ``fix_restore_ollama_from_snapshot`` önerir.
Tipik senaryo: doctor önceki sürümde setup'ı bozmuştu, mevcut process
default env'lerle koşuyor → snapshot'taki kanonik state'e dön.

``fix_action`` her durumda restore (custom runtime'a karışmıyoruz —
çünkü "snapshot'taki tam o custom runtime"a dönmek isteniyor).
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import List, Optional

from contdoctor.checks.ollama_proc import detect_running_ollama
from contdoctor.checks.snapshot_drift import DEFAULT_SNAPSHOT_PATH
from contdoctor.core.result import CheckResult
from contdoctor.fixes.snapshot_restore import fix_restore_ollama_from_snapshot
from contdoctor.snapshot import SnapshotError, load_snapshot

_CRITICAL_ENV_KEYS = ("LD_LIBRARY_PATH", "OLLAMA_RUNNERS_DIR", "OLLAMA_NUM_GPU")


def _resolve_snapshot_path() -> Path:
    raw = os.environ.get("CONTDOCTOR_SNAPSHOT", DEFAULT_SNAPSHOT_PATH)
    return Path(raw).expanduser()


def check_ollama_proc_matches_snapshot() -> CheckResult:
    running = detect_running_ollama()
    p = _resolve_snapshot_path()

    if running is None:
        return CheckResult(
            "Ollama snapshot uyumu",
            "warn",
            "ollama serve çalışmıyor (snapshot uyum kontrolü atlandı)",
            details={"running": False, "snapshot_path": str(p)},
        )
    if not p.is_file():
        return CheckResult(
            "Ollama snapshot uyumu",
            "warn",
            f"snapshot dosyası yok: {p}",
            details={
                "snapshot_path": str(p),
                "hint": "Sistem çalışırken: contdoctor --save-snapshot",
            },
        )

    try:
        snapshot = load_snapshot(p)
    except SnapshotError as e:
        return CheckResult(
            "Ollama snapshot uyumu",
            "warn",
            f"snapshot okunamadı: {e}",
            details={"snapshot_path": str(p)},
        )

    if not snapshot.ollama.binary_path:
        return CheckResult(
            "Ollama snapshot uyumu",
            "warn",
            "snapshot.ollama.binary_path boş — uyum kontrolü yapılamaz",
            details={"snapshot_path": str(p)},
        )

    mismatches: List[str] = []

    if snapshot.ollama.binary_path != running.binary_path:
        mismatches.append(
            f"binary: snapshot={snapshot.ollama.binary_path} "
            f"running={running.binary_path}"
        )

    snap_env = snapshot.env or {}
    run_env = running.env or {}
    for key in _CRITICAL_ENV_KEYS:
        snap_val = snap_env.get(key, "")
        run_val = run_env.get(key, "")
        if snap_val and snap_val != run_val:
            mismatches.append(
                f"{key}: snapshot={snap_val[:60]} running={run_val[:60] or 'BOŞ'}"
            )

    details = {
        "snapshot_path": str(p),
        "snapshot_binary": snapshot.ollama.binary_path,
        "running_binary": running.binary_path,
        "mismatches": mismatches,
    }

    if not mismatches:
        return CheckResult(
            "Ollama snapshot uyumu",
            "ok",
            f"çalışan setup snapshot ({snapshot.label or '-'}) ile uyumlu",
            details=details,
        )

    return CheckResult(
        "Ollama snapshot uyumu",
        "warn",
        f"{len(mismatches)} mismatch (snapshot'taki kanonik setup'a dönülmesi öneriliyor)",
        fix_label="snapshot'taki kanonik komutla yeniden başlat",
        fix_action=fix_restore_ollama_from_snapshot,
        details=details,
    )


__all__ = ["check_ollama_proc_matches_snapshot"]
