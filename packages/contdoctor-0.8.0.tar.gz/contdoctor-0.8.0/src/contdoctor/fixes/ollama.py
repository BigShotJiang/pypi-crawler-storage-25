"""Ollama-related auto-fixes: start, restart, force OLLAMA_NUM_GPU."""

import os
import subprocess
import time
from pathlib import Path
from typing import List

from contdoctor.core.proc import pgrep, port_open
from contdoctor.core.symbols import S_FAIL, S_FIX, S_OK, S_WARN

# Path to the launcher script. Default is empty — banka rule: no private
# paths in source. Set ``CONT_OLLAMA_LAUNCHER`` at runtime to enable the
# launcher branch in ``fix_start_ollama``.
START_OLLAMA_SCRIPT = os.environ.get("CONT_OLLAMA_LAUNCHER", "")


def fix_start_ollama() -> bool:
    if Path(START_OLLAMA_SCRIPT).is_file():
        print(f"  {S_FIX} {START_OLLAMA_SCRIPT} çalıştırılıyor (background)…")
        try:
            subprocess.Popen(
                ["bash", START_OLLAMA_SCRIPT],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        except Exception as e:  # noqa: BLE001
            print(f"  {S_FAIL} başlatılamadı: {e}")
            return False
    else:
        print(f"  {S_FIX} ollama serve başlatılıyor (OLLAMA_NUM_GPU=999, background)…")
        env = os.environ.copy()
        env["OLLAMA_NUM_GPU"] = "999"
        env.pop("OLLAMA_LLM_LIBRARY", None)  # poison temizle
        try:
            subprocess.Popen(
                ["ollama", "serve"],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        except Exception as e:  # noqa: BLE001
            print(f"  {S_FAIL} başlatılamadı: {e}")
            return False
    for i in range(15):
        time.sleep(1)
        if port_open("127.0.0.1", 11434):
            print(f"  {S_OK} {i+1}s sonra hazır")
            return True
    print(f"  {S_FAIL} 15s'de port açılmadı")
    return False


def fix_restart_ollama(stale_pids: List[int]) -> bool:
    print(f"  {S_FIX} stale PID kapatılıyor: {stale_pids}")
    for pid in stale_pids:
        try:
            os.kill(pid, 15)  # SIGTERM
        except ProcessLookupError:
            pass
        except PermissionError:
            print(f"  {S_FAIL} PID {pid} için yetki yok")
            return False
    for _ in range(5):
        time.sleep(1)
        if not pgrep("ollama serve"):
            break
    return fix_start_ollama()


def fix_set_ollama_num_gpu() -> bool:
    pids = pgrep("ollama serve")
    if pids:
        print(f"  {S_FIX} mevcut ollama serve kapatılıyor (PID {pids})…")
        for pid in pids:
            try:
                os.kill(pid, 15)
            except (ProcessLookupError, PermissionError) as e:
                print(f"  {S_WARN} PID {pid}: {e}")
        for _ in range(5):
            time.sleep(1)
            if not pgrep("ollama serve"):
                break
    os.environ["OLLAMA_NUM_GPU"] = "999"
    os.environ.pop("OLLAMA_LLM_LIBRARY", None)
    return fix_start_ollama()


__all__ = [
    "START_OLLAMA_SCRIPT",
    "fix_start_ollama",
    "fix_restart_ollama",
    "fix_set_ollama_num_gpu",
]
