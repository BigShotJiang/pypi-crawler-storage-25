"""``print_remediation`` — manual remediation instructions, no auto-execute.

Banka kuralı: doctor kendi sandbox'ı dışına müdahale etmez. Drift / version
mismatch / shadow tespit edildiğinde kullanıcıya kopyala-yapıştır komutu
basılır, gerisi kullanıcının (veya yöneticinin) sorumluluğu.

Always returns ``True`` — "fix succeeded" semantics here means *the user
was informed*, which is the only thing this action promises.
"""

from __future__ import annotations

from typing import Optional, Sequence

from contdoctor.core.symbols import BOLD, RESET, S_INFO


def _safe_format(template: str, context: dict) -> str:
    """Substitute ``{key}`` placeholders without raising on missing keys.

    Missing keys → empty string. Format errors (e.g. unbalanced braces)
    fall back to the literal template, never raise. We only use simple
    field references; no eval, no attribute access.
    """
    if not isinstance(template, str):
        return str(template)
    try:
        # Defaultdict-style behaviour without bringing in collections:
        # supply a tiny mapping that returns "" for any missing key.
        class _Defaulting(dict):
            def __missing__(self, key):  # type: ignore[override]
                return ""
        return template.format_map(_Defaulting(context))
    except (IndexError, ValueError):
        return template


def print_remediation(
    steps: Sequence[str],
    context: Optional[dict] = None,
    *,
    label: Optional[str] = None,
) -> bool:
    """Print a ``label`` and ``steps`` to stdout. Returns True.

    Each step gets a ``  $ `` prefix and ``{placeholder}`` fields are
    substituted from ``context``.
    """
    ctx = dict(context or {})
    print()
    if label:
        print(f"{S_INFO} {BOLD}{_safe_format(label, ctx)}{RESET}")
    for step in steps:
        print(f"  $ {_safe_format(step, ctx)}")
    return True


__all__ = ["print_remediation"]
