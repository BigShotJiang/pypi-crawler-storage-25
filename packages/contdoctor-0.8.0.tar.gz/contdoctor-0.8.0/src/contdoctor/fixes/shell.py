"""``run_shell`` — execute allowlisted shell commands with no ``shell=True``.

Banka kuralı: doctor sandbox dışına müdahale etmez. ``run_shell`` bu kuralı
katı bir allowlist + path validation ile hayata geçirir:

  * Yalnız ``RUN_SHELL_ALLOWED_BINARIES`` setindeki binary'ler çalıştırılır
  * Komut argv list-form'unda; ``shell=True`` asla kullanılmaz (injection safe)
  * Path argümanları (`stdout_to`, `stderr_to`, mutlak path argv elemanları)
    yalnız ``/tmp/`` ve ``$HOME/`` altına izinli
  * Timeout adım başına ``RUN_SHELL_MAX_TIMEOUT`` ile cap'lenir

Modelfile patch (Sprint 5.2'nin asıl motivasyonu) bu allowlist'in altına
düşüyor — yerel Ollama state'i, paket yükleme yok, ağ yok.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Iterable, Optional, Sequence

from contdoctor.core.symbols import BOLD, RESET, S_FAIL, S_FIX, S_INFO, S_OK
from contdoctor.knowledge.schema import ShellStep

# Sabit allowlist — YAML'dan değiştirilemez. Genişletmek istersen
# explicit code review gerekiyor.
RUN_SHELL_ALLOWED_BINARIES = frozenset(
    {
        "ollama",  # local model state
        "bash",    # echo/append'ler için, sadece argv list-form
        "sh",
        "echo",
        "cat",
        "tee",
        "rm",      # path validation altında
        "cp",
        "mv",
    }
)

RUN_SHELL_MAX_TIMEOUT = 300  # saniye

# Path izin verilen prefix'ler — runtime'da expand'lı.
def _allowed_path_prefixes() -> Iterable[str]:
    home = str(Path.home())
    return ("/tmp/", home + "/", home + os.sep if os.sep != "/" else home + "/")


def _is_path_arg(arg: str) -> bool:
    """`/...` veya `~/...` veya `$HOME/...` — bunlar path argümanı sayılır.

    Pure flag'ler (-f, --modelfile) ve göreceli isimler (`cont-local:latest`)
    path değildir, validate edilmez.
    """
    if not arg:
        return False
    if arg.startswith("/"):
        return True
    if arg.startswith("~"):
        return True
    if arg.startswith("$HOME"):
        return True
    return False


def _validate_path(path: str) -> bool:
    """``path`` izinli prefix altında mı (sembolik link / .. kötüye-kullanım
    önlemek için ``resolve()`` ile normalize ediliyor)."""
    try:
        if path.startswith("$HOME"):
            path = str(Path.home()) + path[len("$HOME"):]
        resolved = str(Path(path).expanduser().resolve())
    except (OSError, ValueError):
        return False
    return any(resolved.startswith(p.rstrip("/") + "/") or resolved == p.rstrip("/")
               for p in _allowed_path_prefixes())


class _SafeDict(dict):
    """``str.format_map`` mapping that returns ``""`` for missing keys."""
    def __missing__(self, key):  # type: ignore[override]
        return ""


def _interpolate(template: str, context: dict) -> str:
    if not isinstance(template, str):
        return str(template)
    try:
        return template.format_map(_SafeDict(context))
    except (IndexError, ValueError):
        return template


def run_shell(steps: Sequence[ShellStep], context: Optional[dict] = None) -> bool:
    """Run ``steps`` in order. Stops at the first failure.

    Returns True iff every step exits 0 and passes validation.
    Prints each command before running it (operator visibility).
    """
    ctx = dict(context or {})
    for idx, step in enumerate(steps, start=1):
        cmd = [_interpolate(c, ctx) for c in step.cmd]
        if not cmd:
            print(f"  {S_FAIL} step {idx}: empty cmd")
            return False
        binary = cmd[0]
        if binary not in RUN_SHELL_ALLOWED_BINARIES:
            print(f"  {S_FAIL} step {idx}: binary not allowed: {binary}")
            return False

        # Validate every absolute / home-relative path arg.
        for arg in cmd[1:]:
            if _is_path_arg(arg) and not _validate_path(arg):
                print(f"  {S_FAIL} step {idx}: arg path not allowed: {arg}")
                return False

        stdout_to = _interpolate(step.stdout_to, ctx) if step.stdout_to else None
        stderr_to = _interpolate(step.stderr_to, ctx) if step.stderr_to else None
        for path, slot in ((stdout_to, "stdout_to"), (stderr_to, "stderr_to")):
            if path and not _validate_path(path):
                print(f"  {S_FAIL} step {idx}: {slot} path not allowed: {path}")
                return False

        timeout = min(int(step.timeout or 60), RUN_SHELL_MAX_TIMEOUT)
        printable = " ".join(cmd)
        if stdout_to:
            printable += f" > {stdout_to}"
        print(f"  {S_FIX} $ {printable}")

        out_handle = open(stdout_to, "w") if stdout_to else None
        err_handle = open(stderr_to, "w") if stderr_to else None
        try:
            r = subprocess.run(
                cmd,
                stdout=out_handle,
                stderr=err_handle,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            print(f"  {S_FAIL} step {idx}: timeout ({timeout}s)")
            return False
        except FileNotFoundError:
            print(f"  {S_FAIL} step {idx}: komut bulunamadı: {binary}")
            return False
        except Exception as e:  # noqa: BLE001
            print(f"  {S_FAIL} step {idx}: {type(e).__name__}: {e}")
            return False
        finally:
            if out_handle is not None:
                out_handle.close()
            if err_handle is not None:
                err_handle.close()

        if r.returncode != 0:
            print(f"  {S_FAIL} step {idx} exit {r.returncode}")
            return False
    print(f"  {S_OK} {len(steps)} step başarıyla tamamlandı")
    return True


__all__ = [
    "RUN_SHELL_ALLOWED_BINARIES",
    "RUN_SHELL_MAX_TIMEOUT",
    "run_shell",
]
