"""Model-related auto-fixes: warmup + reload (unload + warmup).

Sprint 7'de Sprint 6'nın Modelfile patch zinciri kaldırıldı. Sebep:
yanlış katman. ``num_gpu`` parametresi GPU runner library'leri yüklü
değilken anlamsız — root cause ``check_ollama_gpu_runners`` ve
``check_ollama_gpu_offload_log``'da yakalanır, gerçek fix orada yapılır.

Bu modül artık sadece "warmup + verify" sade kontratını sunuyor:
``gpu_pct < 95`` ise False döner; üst katman teşhise yönlendirir.
"""

from __future__ import annotations

import json
import time

from contdoctor.core.http import http_get, http_post_json
from contdoctor.core.symbols import S_FAIL, S_FIX, S_OK, S_WARN

GPU_PCT_OK_THRESHOLD = 95


def _gpu_pct(model: str) -> int | None:
    """Read ``gpu_pct`` for ``model`` from ``/api/ps``. None on any failure."""
    status, body = http_get("/api/ps", timeout=3)
    if status != 200 or not body:
        return None
    try:
        data = json.loads(body)
    except json.JSONDecodeError:
        return None
    target = next((m for m in data.get("models", []) if m.get("name") == model), None)
    if not target:
        return None
    size = target.get("size", 0)
    size_vram = target.get("size_vram", 0)
    if not size:
        return 0
    return int(round(100 * size_vram / size))


def _warmup_and_verify(model: str) -> bool:
    """Warmup HTTP + ``/api/ps`` verify.

    Returns True iff warmup HTTP 200 *and* ``gpu_pct >= 95`` (or
    ``/api/ps`` couldn't be introspected — be optimistic in that case
    since the warmup itself succeeded).

    Sprint 7.2: ``gpu_pct < 95`` durumunda log'a model-spesifik bakıp
    spesifik sebebi (library not found / total vram=0 / vb.) operatöre
    yazdırıyor — "üst check'lere bak" yerine somut teşhis.
    """
    print(f"  {S_FIX} {model} warmup (60s timeout)…")
    status, body = http_post_json(
        "/api/generate",
        {"model": model, "prompt": "ok", "stream": False,
         "options": {"num_predict": 1}},
        timeout=60,
    )
    if status != 200:
        print(f"  {S_FAIL} warmup HTTP {status} ({body})")
        return False

    pct = _gpu_pct(model)
    if pct is None:
        print(f"  {S_OK} model yüklendi (gpu_pct doğrulanamadı)")
        return True
    if pct >= GPU_PCT_OK_THRESHOLD:
        print(f"  {S_OK} model yüklendi, %{pct} GPU")
        return True

    # Sprint 7.2 — model-spesifik log peek
    from contdoctor.checks.ollama_log import check_ollama_gpu_offload_log

    try:
        log_check = check_ollama_gpu_offload_log(model)
    except Exception as e:  # noqa: BLE001
        log_check = None
        log_err = f"{type(e).__name__}: {e}"
    else:
        log_err = None

    if log_check is None:
        print(
            f"  {S_WARN} {model} %{pct} GPU — log peek başarısız ({log_err})"
        )
    elif log_check.details.get("errors"):
        errors = ", ".join(log_check.details["errors"])
        print(
            f"  {S_WARN} {model} %{pct} GPU — log sebepleri: {errors}"
        )
    elif log_check.status in {"fail", "warn"}:
        print(
            f"  {S_WARN} {model} %{pct} GPU — log: {log_check.message}"
        )
    else:
        print(
            f"  {S_WARN} {model} %{pct} GPU — log net sebep vermiyor "
            f"(üst check'lere bak)"
        )
    return False


def fix_warmup_model(model: str) -> bool:
    """Warmup + verify. ``gpu_pct < 95`` → False."""
    return _warmup_and_verify(model)


def fix_reload_model(model: str) -> bool:
    """Unload + warmup + verify. ``gpu_pct < 95`` → False."""
    print(f"  {S_FIX} {model} unload ediliyor…")
    http_post_json(
        "/api/generate",
        {"model": model, "prompt": "", "stream": False, "keep_alive": 0},
        timeout=10,
    )
    time.sleep(2)
    return _warmup_and_verify(model)


__all__ = [
    "GPU_PCT_OK_THRESHOLD",
    "fix_warmup_model",
    "fix_reload_model",
]
