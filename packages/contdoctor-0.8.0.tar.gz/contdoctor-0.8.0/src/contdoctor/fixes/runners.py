"""GPU runner library fixes — env düzeltme + manual tar transfer talimatı.

Ollama'nın GPU runner'ları (libggml-cuda.so + cuBLAS + cuDART) library
bulunamadan ``OLLAMA_NUM_GPU=999`` veya Modelfile ``num_gpu 999``
hiçbir şey değiştirmez. Doctor'un root cause çözümü:

  * env değişkeni doğru path'i göstermiyorsa ``fix_set_ollama_runners_path``
    ile düzelt + restart
  * library hiçbir path'te yoksa ``fix_print_runner_transfer_block`` ile
    dev → prod tar transferi talimatı bas (banka kuralı: doctor sandbox
    dışına çıkmaz)
"""

from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path

from contdoctor.core.proc import pgrep, port_open
from contdoctor.core.symbols import S_FAIL, S_FIX, S_OK


def fix_set_ollama_runners_path(library_path: Path) -> bool:
    """``OLLAMA_LLM_LIBRARY`` doğru path'i gösterecek şekilde restart.

    Sprint 7.1: doctor'ın **kendi** ``os.environ``'ını da günceller —
    yoksa yeniden tarama (``run_checks`` içinde ``os.environ.get``)
    eski/eksik değeri okur ve fix'i görmez.
    """
    library_path = Path(library_path)
    print(f"  {S_FIX} OLLAMA_LLM_LIBRARY={library_path}")

    # Doctor'ın kendi process env'ini güncelle (yeniden tarama görsün).
    os.environ["OLLAMA_LLM_LIBRARY"] = str(library_path)
    os.environ.setdefault("OLLAMA_NUM_GPU", "999")

    pids = pgrep("ollama serve")
    if pids:
        print(f"  {S_FIX} mevcut ollama serve kapatılıyor (PID {pids})…")
        for pid in pids:
            try:
                os.kill(pid, 15)
            except (ProcessLookupError, PermissionError):
                pass
        for _ in range(5):
            time.sleep(1)
            if not pgrep("ollama serve"):
                break

    # subprocess.Popen env=None default → os.environ inherit edilir.
    try:
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except Exception as e:  # noqa: BLE001
        print(f"  {S_FAIL} başlatılamadı: {e}")
        return False

    for i in range(15):
        time.sleep(1)
        if port_open("127.0.0.1", 11434):
            print(f"  {S_OK} ollama serve hazır (port 11434, {i+1}s)")
            return True
    print(f"  {S_FAIL} 15s'de port açılmadı")
    return False


def fix_print_runner_transfer_block() -> bool:
    """Manual transfer talimatı bas (dev → prod tar). Banka kuralı:
    doctor sandbox dışına çıkmaz, manuel transfer kullanıcı sorumluluğu.
    Always returns True ("fix succeeded" = kullanıcı bilgilendirildi).
    """
    cyan = "\033[36m" if sys.stdout.isatty() else ""
    reset = "\033[0m" if sys.stdout.isatty() else ""
    bar = f"{cyan}│{reset}"
    top = f"{cyan}╭─ GPU runner transferi — kopyala/yapıştır ─────────────╮{reset}"
    bot = f"{cyan}╰────────────────────────────────────────────────────────╯{reset}"
    print()
    print(top)
    print(f"  {bar} # DEV makinesinde — tar paketi hazırla:")
    print(f"  {bar} tar czf /tmp/ollama_gpu.tar.gz \\")
    print(f"  {bar}     /usr/local/bin/ollama \\")
    print(f"  {bar}     /usr/local/lib/ollama/cuda_v12 \\")
    print(f"  {bar}     /usr/local/lib/ollama/libggml-base.so \\")
    print(f"  {bar}     /usr/local/lib/ollama/libggml-cpu-*.so")
    print(f"  {bar}")
    print(f"  {bar} # Mount üzerinden prod'a kopyala:")
    print(f"  {bar} cp /tmp/ollama_gpu.tar.gz <shared-mount>/")
    print(f"  {bar}")
    print(f"  {bar} # PROD makinesinde — extract:")
    print(f"  {bar} mkdir -p ~/ollama-full")
    print(f"  {bar} tar xzf <shared-mount>/ollama_gpu.tar.gz -C ~/ollama-full")
    print(f"  {bar}")
    print(f"  {bar} # Env set + restart:")
    print(f"  {bar} export OLLAMA_LLM_LIBRARY=~/ollama-full/usr/local/lib/ollama")
    print(f"  {bar} export OLLAMA_NUM_GPU=999")
    print(f"  {bar} pkill ollama; ollama serve &")
    print(f"  {bar}")
    print(f"  {bar} # Doğrula:")
    print(f"  {bar} contdoctor")
    print(bot)
    return True


__all__ = [
    "fix_set_ollama_runners_path",
    "fix_print_runner_transfer_block",
]
