"""``fix_restore_ollama_from_snapshot`` — Sprint 9.2.

Sertan'ın custom-launched setup'ı (``~/ollama-full/bin/ollama serve`` +
``LD_LIBRARY_PATH``/``OLLAMA_RUNNERS_DIR``) snapshot'a kaydedildi.
Setup down olduğunda doctor o kanonik komutu reconstruct edip çalıştırır
— Sertan elle pkill + manuel başlatma yapmaz.

Banka kuralı: doctor environment'ı keyfi değiştirmez. Restore = aynı
binary, aynı env'ler. Snapshot zaten Sertan'ın bilinen-iyi state'i.

Hostname / is_wsl mismatch → restore reddedilir (Sprint 8 (revised)
hard-fingerprint kuralı). Başka makinenin snapshot'ı yanlış process
başlatmasın.
"""

from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path
from typing import Optional

from contdoctor.checks.snapshot_drift import DEFAULT_SNAPSHOT_PATH
from contdoctor.core.proc import pgrep, port_open
from contdoctor.core.symbols import S_FAIL, S_FIX, S_OK
from contdoctor.snapshot import SnapshotError, load_snapshot
from contdoctor.snapshot.fingerprint import compute_fingerprint


def fix_restore_ollama_from_snapshot(
    snapshot_path: Optional[str] = None,
) -> bool:
    """Snapshot'tan ``ollama serve`` komutunu reconstruct edip başlat.

    Returns True iff:
      * snapshot dosyası okunabilir,
      * fingerprint hostname + is_wsl mevcut makineyle uyuyor,
      * snapshot binary path filesystem'da var,
      * mevcut ollama (varsa) kapatıldı,
      * yeni process başladı ve port 11434 15s içinde açıldı.
    """
    raw_path = snapshot_path or os.environ.get("CONTDOCTOR_SNAPSHOT") or DEFAULT_SNAPSHOT_PATH
    p = Path(raw_path).expanduser()
    if not p.is_file():
        print(f"  {S_FAIL} snapshot dosyası yok: {p}")
        return False

    try:
        snapshot = load_snapshot(p)
    except SnapshotError as e:
        print(f"  {S_FAIL} snapshot okunamadı: {e}")
        return False

    if snapshot.fingerprint is None:
        print(f"  {S_FAIL} snapshot fingerprint taşımıyor (eski format)")
        return False

    current_fp = compute_fingerprint()
    snap_fp = snapshot.fingerprint
    if snap_fp.hostname != current_fp.hostname:
        print(
            f"  {S_FAIL} snapshot başka makineden: "
            f"hostname snapshot={snap_fp.hostname} current={current_fp.hostname}"
        )
        return False
    if snap_fp.is_wsl != current_fp.is_wsl:
        print(
            f"  {S_FAIL} snapshot WSL/non-WSL uyuşmazlığı "
            f"(snapshot.is_wsl={snap_fp.is_wsl} current.is_wsl={current_fp.is_wsl})"
        )
        return False

    binary = snapshot.ollama.binary_path
    if not binary:
        print(f"  {S_FAIL} snapshot.ollama.binary_path boş")
        return False
    if not Path(binary).is_file():
        print(f"  {S_FAIL} snapshot binary path'i mevcut değil: {binary}")
        return False

    # Mevcut ollama serve'i kapat (snapshot env'leriyle çakışmasın).
    pids = pgrep("ollama serve")
    if pids:
        print(f"  {S_FIX} mevcut ollama serve kapatılıyor (PID {pids})…")
        for pid in pids:
            try:
                os.kill(pid, 15)
            except (ProcessLookupError, PermissionError):
                pass
        for _ in range(5):
            time.sleep(1)
            if not pgrep("ollama serve"):
                break

    # Snapshot env'lerini reconstruct et.
    env = os.environ.copy()
    for key, value in (snapshot.env or {}).items():
        if value:
            env[key] = value

    # Doctor process env'ine de yansıt (Sprint 7.1 lesson — kendi env
    # propagation), bir sonraki tarama doğru görsün.
    for key, value in (snapshot.env or {}).items():
        if value:
            os.environ[key] = value

    log_path = Path.home() / ".cache" / "cont" / "ollama_serve.log"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        log_path = None  # type: ignore[assignment]

    print(
        f"  {S_FIX} {binary} serve başlatılıyor "
        f"(snapshot label: {snapshot.label or '-'})"
    )
    summary = (
        f"OLLAMA_NUM_GPU={env.get('OLLAMA_NUM_GPU') or '-'}, "
        f"LD_LIBRARY_PATH={'set' if env.get('LD_LIBRARY_PATH') else '-'}, "
        f"OLLAMA_RUNNERS_DIR={'set' if env.get('OLLAMA_RUNNERS_DIR') else '-'}"
    )
    print(f"     env: {summary}")

    try:
        if log_path is not None:
            log_handle = open(log_path, "ab")
        else:
            log_handle = subprocess.DEVNULL  # type: ignore[assignment]
        try:
            subprocess.Popen(
                [binary, "serve"],
                env=env,
                stdout=log_handle,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        finally:
            if log_path is not None and log_handle is not subprocess.DEVNULL:
                # Popen child kendi fd'sini tutar; close güvenli.
                log_handle.close()  # type: ignore[union-attr]
    except Exception as e:  # noqa: BLE001
        print(f"  {S_FAIL} başlatılamadı: {e}")
        return False

    for i in range(15):
        time.sleep(1)
        if port_open("127.0.0.1", 11434):
            print(f"  {S_OK} {i + 1}s sonra hazır")
            return True
    print(f"  {S_FAIL} 15s'de port açılmadı")
    return False


__all__ = ["fix_restore_ollama_from_snapshot"]
