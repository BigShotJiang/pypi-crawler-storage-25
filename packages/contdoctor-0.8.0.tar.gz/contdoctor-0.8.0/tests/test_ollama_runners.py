"""Sprint 7 — check_ollama_gpu_runners + fix_set_ollama_runners_path +
fix_print_runner_transfer_block."""

from __future__ import annotations

from pathlib import Path

import pytest

from contdoctor.checks.ollama_runners import (
    REQUIRED_LIBS,
    check_ollama_gpu_runners,
)
from contdoctor.fixes import runners as runners_fix


def _populate_libs(dir: Path, libs):
    dir.mkdir(parents=True, exist_ok=True)
    for lib in libs:
        (dir / lib).write_bytes(b"")


# ── check_ollama_gpu_runners — 4 senaryo ────────────────────────────


def test_runners_all_libs_present_env_correct(tmp_path, monkeypatch):
    from contdoctor.checks import ollama_runners as runners_check

    runners_dir = tmp_path / "runners"
    _populate_libs(runners_dir, REQUIRED_LIBS)
    monkeypatch.setenv("OLLAMA_LLM_LIBRARY", str(runners_dir))
    monkeypatch.delenv("OLLAMA_RUNNERS_DIR", raising=False)
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path / "home"))
    monkeypatch.setattr(runners_check, "_default_paths", lambda: [])
    r = check_ollama_gpu_runners()
    assert r.status == "ok", r.message
    assert str(runners_dir) in r.message
    assert set(r.details["found_in"][str(runners_dir)]) == set(REQUIRED_LIBS)


def test_runners_libs_present_env_wrong_path(tmp_path, monkeypatch):
    """Library'ler /usr/local/... benzeri default path'te ama env yanlış
    yere işaret ediyor → warn + fix_set_ollama_runners_path callable."""
    from contdoctor.checks import ollama_runners as runners_check

    real_dir = tmp_path / "ollama-full" / "lib" / "ollama" / "cuda_v12"
    _populate_libs(real_dir, REQUIRED_LIBS)
    monkeypatch.setenv("OLLAMA_LLM_LIBRARY", str(tmp_path / "wrong"))
    monkeypatch.delenv("OLLAMA_RUNNERS_DIR", raising=False)
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    monkeypatch.setattr(
        runners_check, "_default_paths",
        lambda: [tmp_path / "ollama-full" / "lib" / "ollama" / "cuda_v12"],
    )
    r = check_ollama_gpu_runners()
    assert r.status == "warn", r.message
    assert "non-default path" in r.message
    assert "env set edilmeli" in r.message
    assert callable(r.fix_action)


def test_runners_libs_completely_missing(tmp_path, monkeypatch):
    from contdoctor.checks import ollama_runners as runners_check

    monkeypatch.delenv("OLLAMA_LLM_LIBRARY", raising=False)
    monkeypatch.delenv("OLLAMA_RUNNERS_DIR", raising=False)
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    # Boş default path listesi — sistem /usr/local/lib/ollama'sı kirletmesin.
    monkeypatch.setattr(runners_check, "_default_paths", lambda: [])
    r = check_ollama_gpu_runners()
    assert r.status == "fail"
    assert "hiçbir path'te bulunamadı" in r.message
    assert r.fix_action is runners_fix.fix_print_runner_transfer_block


def test_runners_partial_libs_present(tmp_path, monkeypatch):
    """Bir path eksik library içeriyor → fail."""
    from contdoctor.checks import ollama_runners as runners_check

    runners_dir = tmp_path / "ollama-full" / "lib" / "ollama"
    # libggml-cuda.so yok, diğerleri var.
    _populate_libs(runners_dir, REQUIRED_LIBS - {"libggml-cuda.so"})
    monkeypatch.delenv("OLLAMA_LLM_LIBRARY", raising=False)
    monkeypatch.delenv("OLLAMA_RUNNERS_DIR", raising=False)
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    # Sadece $HOME altındaki yolları gör — sistem path'i kirletmesin.
    monkeypatch.setattr(
        runners_check, "_default_paths",
        lambda: [
            tmp_path / "ollama-full" / "lib" / "ollama" / "cuda_v12",
            tmp_path / "ollama-full" / "lib" / "ollama",
        ],
    )
    r = check_ollama_gpu_runners()
    assert r.status == "fail"
    assert "eksik library" in r.message
    assert "libggml-cuda.so" in r.message


# ── fix_set_ollama_runners_path mock subprocess ─────────────────────


def test_set_runners_path_kills_existing_then_starts_new(monkeypatch, tmp_path):
    killed = []
    started = []
    sleep_calls = []

    monkeypatch.setattr(runners_fix, "pgrep", lambda pat: [12345])
    monkeypatch.setattr(runners_fix.os, "kill", lambda pid, sig: killed.append((pid, sig)))

    def fake_popen(cmd, **kw):
        started.append(cmd)
        return object()

    monkeypatch.setattr(runners_fix.subprocess, "Popen", fake_popen)
    monkeypatch.setattr(runners_fix.time, "sleep", lambda s: sleep_calls.append(s))
    # First port_open call returns False (kill loop), then True (start loop).
    port_calls = iter([False] * 5 + [True])
    monkeypatch.setattr(
        runners_fix, "port_open", lambda host, port: next(port_calls, True)
    )

    library_path = tmp_path / "lib" / "ollama"
    rc = runners_fix.fix_set_ollama_runners_path(library_path)
    assert rc is True
    assert killed == [(12345, 15)]
    assert started == [["ollama", "serve"]]


# ── fix_print_runner_transfer_block ─────────────────────────────────


def test_print_transfer_block_returns_true(capsys):
    rc = runners_fix.fix_print_runner_transfer_block()
    assert rc is True
    out = capsys.readouterr().out
    assert "tar czf /tmp/ollama_gpu.tar.gz" in out
    assert "OLLAMA_LLM_LIBRARY" in out
    assert "contdoctor" in out


def test_print_transfer_block_called_on_fail(tmp_path, monkeypatch, capsys):
    """End-to-end: ``check_ollama_gpu_runners`` fail döner, ``fix_action``
    transfer bloğunu basar."""
    from contdoctor.checks import ollama_runners as runners_check

    monkeypatch.delenv("OLLAMA_LLM_LIBRARY", raising=False)
    monkeypatch.delenv("OLLAMA_RUNNERS_DIR", raising=False)
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    monkeypatch.setattr(runners_check, "_default_paths", lambda: [])
    r = check_ollama_gpu_runners()
    assert r.status == "fail"
    rc = r.fix_action()
    assert rc is True
    assert "tar czf" in capsys.readouterr().out


# ── GATES integration ──────────────────────────────────────────────


def test_model_loaded_blocked_when_runners_fail(monkeypatch):
    """Sprint 7: model_loaded artık ollama_gpu_runners önkoşuluna bağlı.
    Runners fail ise model_loaded atlanır."""
    from types import SimpleNamespace

    from contdoctor.core import runner as runner_mod
    from contdoctor.core.result import CheckResult

    fake = {
        "ollama_proc": lambda a: CheckResult("ollama_proc", "ok", "ok"),
        "ollama_api": lambda a: CheckResult("ollama_api", "ok", "ok"),
        "ollama_gpu_runners": lambda a: CheckResult(
            "ollama_gpu_runners", "fail", "no libs"
        ),
        "model_reg": lambda a: CheckResult("model_reg", "ok", "ok"),
        "model_loaded": lambda a: CheckResult("model_loaded", "ok", "should not run"),
    }
    monkeypatch.setattr(runner_mod, "CHECKS", fake)
    args = SimpleNamespace(model="m")
    results = runner_mod.run_checks(args, list(fake.keys()))
    by_name = {r.name: r for r in results}
    assert by_name["model_loaded"].status == "warn"
    assert "atlandı" in by_name["model_loaded"].message
    assert "ollama_gpu_runners" in by_name["model_loaded"].message
