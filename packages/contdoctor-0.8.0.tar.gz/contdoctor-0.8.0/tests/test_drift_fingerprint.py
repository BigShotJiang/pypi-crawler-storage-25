"""Sprint 8 (revised) — fingerprint-based drift handling.

Hostname or is_wsl mismatch → snapshot reject (other drifts ignored).
cuda_driver / gpu_name mismatch → soft warn drift entries.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from contdoctor.checks.snapshot_drift import check_environment_drift
from contdoctor.snapshot import builder as builder_mod
from contdoctor.snapshot import save_snapshot
from contdoctor.snapshot.fingerprint import EnvironmentFingerprint
from contdoctor.snapshot.schema import (
    GpuSnapshot,
    OllamaSnapshot,
    Snapshot,
)


def _isolate(monkeypatch, tmp_path):
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    for v in builder_mod.INTERESTING_ENV_VARS:
        monkeypatch.delenv(v, raising=False)


def _stub_builder(monkeypatch):
    """Replace expensive subprocess + http calls so build_snapshot()
    doesn't depend on the live system."""
    monkeypatch.setattr(builder_mod, "_run", lambda *a, **k: (1, "", ""))
    monkeypatch.setattr(builder_mod, "http_get", lambda *a, **k: (None, ""))
    monkeypatch.setattr(builder_mod.shutil, "which", lambda name: None)


def _force_current_fingerprint(monkeypatch, **fields):
    """Pin the fingerprint that build_snapshot sees as 'current'."""
    base = dict(
        hostname="prod-host",
        user="prod-user",
        os_release="Ubuntu 20.04 LTS",
        kernel="5.15.0-prod",
        is_wsl=False,
        cuda_driver="552.74",
        gpu_name="RTX 5000 Ada",
        cwd_mount="/mnt/shared",
        python_executable="/opt/python",
    )
    base.update(fields)
    monkeypatch.setattr(
        builder_mod, "compute_fingerprint",
        lambda: EnvironmentFingerprint(**base),
    )
    monkeypatch.setattr(builder_mod, "guess_role", lambda fp: "prod-shared")


def _snapshot_with_fingerprint(**fp_kwargs) -> Snapshot:
    base = dict(
        hostname="prod-host",
        user="prod-user",
        os_release="Ubuntu 20.04 LTS",
        kernel="5.15.0-prod",
        is_wsl=False,
        cuda_driver="552.74",
        gpu_name="RTX 5000 Ada",
        cwd_mount="/mnt/shared",
        python_executable="/opt/python",
    )
    base.update(fp_kwargs)
    return Snapshot(
        version=1, created_at="t", created_by_contdoctor="x", label="L",
        fingerprint=EnvironmentFingerprint(**base), role_hint="prod-shared",
        ollama=OllamaSnapshot(binary_path="b", version="0.13.5", size_bytes=10),
        gpu=GpuSnapshot(driver_version="552.74"),
    )


# ── Hard reject: hostname / is_wsl ─────────────────────────────────


def test_drift_hostname_mismatch_rejects_snapshot(tmp_path, monkeypatch):
    _isolate(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    _force_current_fingerprint(monkeypatch, hostname="prod-host")

    snap = _snapshot_with_fingerprint(hostname="dev-laptop")
    p = save_snapshot(snap, str(tmp_path / "s.yaml"))
    r = check_environment_drift(str(p))
    assert r.status == "fail"
    assert "başka makineden" in r.message
    assert "hostname" in r.message
    rejected = r.details["rejected_due_to_fingerprint"]
    assert any(x["field"] == "hostname" for x in rejected)
    # Other drifts (ollama version 0.13.5 vs absent) should NOT appear.
    assert "drifts" not in r.details
    assert r.fix_action is None


def test_drift_wsl_mismatch_rejects_snapshot(tmp_path, monkeypatch):
    _isolate(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    _force_current_fingerprint(monkeypatch, is_wsl=False)

    snap = _snapshot_with_fingerprint(is_wsl=True)
    p = save_snapshot(snap, str(tmp_path / "s.yaml"))
    r = check_environment_drift(str(p))
    assert r.status == "fail"
    assert "is_wsl" in r.message
    assert r.fix_action is None


def test_drift_hostname_match_proceeds_to_other_diffs(tmp_path, monkeypatch):
    """Hostname aynıysa diğer drift'ler beklendiği gibi rapor edilsin."""
    _isolate(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    _force_current_fingerprint(
        monkeypatch, hostname="prod-host", is_wsl=False, cuda_driver="552.74"
    )
    monkeypatch.setattr(
        builder_mod, "_run",
        lambda cmd, timeout=5: (
            (0, "ollama version is 0.20.3\n", "")
            if cmd[:2] == ["ollama", "--version"]
            else (1, "", "")
        ),
    )

    snap = _snapshot_with_fingerprint(hostname="prod-host", is_wsl=False)
    p = save_snapshot(snap, str(tmp_path / "s.yaml"))
    r = check_environment_drift(str(p))
    # Snapshot has ollama 0.13.5; current returns 0.20.3 → fail.
    assert r.status == "fail"
    fields = [d["field"] for d in r.details["drifts"]]
    assert "ollama.version" in fields


# ── Soft drift: cuda_driver, gpu_name ───────────────────────────────


def test_drift_cuda_driver_mismatch_returns_warn(tmp_path, monkeypatch):
    _isolate(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    _force_current_fingerprint(
        monkeypatch, hostname="prod-host", is_wsl=False, cuda_driver="553.21"
    )
    # Snapshot'ı boş ollama+gpu ile kur ki sadece cuda_driver drift'i çıksın.
    snap = Snapshot(
        version=1, created_at="t", created_by_contdoctor="x", label="L",
        fingerprint=EnvironmentFingerprint(
            hostname="prod-host", user="u", os_release="O", kernel="k",
            is_wsl=False, cuda_driver="552.74", gpu_name="RTX 5000 Ada",
            cwd_mount="/mnt/shared", python_executable="/p",
        ),
        role_hint="prod-shared",
        ollama=OllamaSnapshot(),
        gpu=GpuSnapshot(),
    )
    p = save_snapshot(snap, str(tmp_path / "s.yaml"))
    r = check_environment_drift(str(p))
    assert r.status == "warn"
    fields = [d["field"] for d in r.details["drifts"]]
    assert "fingerprint.cuda_driver" in fields


def test_drift_gpu_name_mismatch_returns_warn(tmp_path, monkeypatch):
    _isolate(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    _force_current_fingerprint(
        monkeypatch, hostname="prod-host", is_wsl=False, gpu_name="A100"
    )
    snap = Snapshot(
        version=1, created_at="t", created_by_contdoctor="x", label="L",
        fingerprint=EnvironmentFingerprint(
            hostname="prod-host", user="u", os_release="O", kernel="k",
            is_wsl=False, cuda_driver="552.74", gpu_name="RTX 5000 Ada",
            cwd_mount="/mnt/shared", python_executable="/p",
        ),
        role_hint="prod-shared",
        ollama=OllamaSnapshot(),
        gpu=GpuSnapshot(),
    )
    p = save_snapshot(snap, str(tmp_path / "s.yaml"))
    r = check_environment_drift(str(p))
    assert r.status == "warn"
    fields = [d["field"] for d in r.details["drifts"]]
    assert "fingerprint.gpu_name" in fields


# ── Reporter integration: related_lessons ──────────────────────────


def test_drift_result_carries_related_lesson_ids(tmp_path, monkeypatch):
    _isolate(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    _force_current_fingerprint(monkeypatch, hostname="prod-host", is_wsl=False)
    monkeypatch.setattr(
        builder_mod, "_run",
        lambda cmd, timeout=5: (
            (0, "ollama version is 0.20.3\n", "")
            if cmd[:2] == ["ollama", "--version"]
            else (1, "", "")
        ),
    )
    snap = _snapshot_with_fingerprint(hostname="prod-host", is_wsl=False)
    p = save_snapshot(snap, str(tmp_path / "s.yaml"))
    r = check_environment_drift(str(p))
    assert "related_lessons" in r.details
    assert "ollama_version_drift_breaks_gpu" in r.details["related_lessons"]


# ── Snapshot YAML round-trip carries fingerprint ────────────────────


def test_snapshot_yaml_roundtrip_preserves_fingerprint(tmp_path, monkeypatch):
    _isolate(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    _force_current_fingerprint(monkeypatch, hostname="prod-host")
    from contdoctor.snapshot import build_snapshot, load_snapshot

    snap = build_snapshot(label="round")
    p = save_snapshot(snap, str(tmp_path / "rt.yaml"))
    loaded = load_snapshot(p)
    assert loaded.fingerprint is not None
    assert loaded.fingerprint.hostname == "prod-host"
    assert loaded.role_hint == "prod-shared"
