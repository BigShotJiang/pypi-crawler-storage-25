"""Sprint 5.2 — ``run_shell`` fix action and YAML schema/loader/matcher
support for it.

The runner is exercised with ``subprocess.run`` mocked so no real
process is spawned.
"""

from __future__ import annotations

import textwrap
from unittest.mock import MagicMock

import pytest

from contdoctor.core.result import CheckResult
from contdoctor.fixes import FIX_ACTIONS, run_shell
from contdoctor.fixes import shell as shell_mod
from contdoctor.knowledge import load_symptoms_from_string
from contdoctor.knowledge.loader import KnowledgeError
from contdoctor.knowledge.matcher import apply_symptoms
from contdoctor.knowledge.schema import ShellStep


# ── Allowlist + path validation ──────────────────────────────────────


def test_run_shell_blocks_disallowed_binary(capsys, monkeypatch):
    monkeypatch.setattr(shell_mod.subprocess, "run", lambda *a, **k: MagicMock(returncode=0))
    rc = run_shell([ShellStep(cmd=("pip", "install", "evil"))])
    assert rc is False
    out = capsys.readouterr().out
    assert "binary not allowed" in out
    assert "pip" in out


def test_run_shell_allows_listed_binary(capsys, monkeypatch):
    """Sanity: an allowlisted binary passes the gate."""
    monkeypatch.setattr(shell_mod.subprocess, "run", lambda *a, **k: MagicMock(returncode=0))
    rc = run_shell([ShellStep(cmd=("echo", "hello"))])
    assert rc is True
    out = capsys.readouterr().out
    assert "echo hello" in out


def test_run_shell_blocks_path_outside_allowlist(capsys, monkeypatch):
    monkeypatch.setattr(shell_mod.subprocess, "run", lambda *a, **k: MagicMock(returncode=0))
    rc = run_shell([ShellStep(cmd=("cat", "/tmp/x"), stdout_to="/etc/passwd")])
    assert rc is False
    out = capsys.readouterr().out
    assert "stdout_to path not allowed" in out


def test_run_shell_blocks_path_arg_outside_allowlist(capsys, monkeypatch):
    """A `/etc/...` path argument is rejected before subprocess fires."""
    runs = []
    monkeypatch.setattr(
        shell_mod.subprocess, "run",
        lambda *a, **k: runs.append(a) or MagicMock(returncode=0),
    )
    rc = run_shell([ShellStep(cmd=("cat", "/etc/passwd"))])
    assert rc is False
    assert runs == [], "subprocess must not be invoked when path validation fails"
    out = capsys.readouterr().out
    assert "arg path not allowed" in out


def test_run_shell_accepts_tmp_and_home(monkeypatch, tmp_path):
    """`/tmp/...` and `$HOME/...` are accepted."""
    monkeypatch.setattr(shell_mod.subprocess, "run", lambda *a, **k: MagicMock(returncode=0))
    monkeypatch.setattr(shell_mod.Path, "home", classmethod(lambda cls: tmp_path))
    rc = run_shell([
        ShellStep(cmd=("cat", "/tmp/x.txt")),
        ShellStep(cmd=("cat", str(tmp_path / "y.txt"))),
    ])
    assert rc is True


# ── Chain semantics ──────────────────────────────────────────────────


def test_run_shell_executes_chain_in_order(monkeypatch, capsys):
    calls = []

    def fake_run(cmd, **kw):
        calls.append(tuple(cmd))
        return MagicMock(returncode=0)

    monkeypatch.setattr(shell_mod.subprocess, "run", fake_run)
    rc = run_shell([
        ShellStep(cmd=("echo", "one")),
        ShellStep(cmd=("echo", "two")),
        ShellStep(cmd=("echo", "three")),
    ])
    assert rc is True
    assert calls == [("echo", "one"), ("echo", "two"), ("echo", "three")]


def test_run_shell_stops_on_first_failure(monkeypatch, capsys):
    calls = []

    def fake_run(cmd, **kw):
        calls.append(tuple(cmd))
        rc = 0 if tuple(cmd) != ("echo", "boom") else 1
        return MagicMock(returncode=rc)

    monkeypatch.setattr(shell_mod.subprocess, "run", fake_run)
    rc = run_shell([
        ShellStep(cmd=("echo", "first")),
        ShellStep(cmd=("echo", "boom")),
        ShellStep(cmd=("echo", "never")),
    ])
    assert rc is False
    assert ("echo", "never") not in calls
    out = capsys.readouterr().out
    assert "exit 1" in out


def test_run_shell_timeout_capped(monkeypatch):
    captured = {}

    def fake_run(cmd, **kw):
        captured["timeout"] = kw["timeout"]
        return MagicMock(returncode=0)

    monkeypatch.setattr(shell_mod.subprocess, "run", fake_run)
    # Step asks for 9999s; cap is RUN_SHELL_MAX_TIMEOUT=300.
    run_shell([ShellStep(cmd=("echo", "hi"), timeout=9999)])
    assert captured["timeout"] == shell_mod.RUN_SHELL_MAX_TIMEOUT


def test_run_shell_timeout_expired_returns_false(monkeypatch, capsys):
    import subprocess

    def fake_run(cmd, **kw):
        raise subprocess.TimeoutExpired(cmd=cmd, timeout=kw["timeout"])

    monkeypatch.setattr(shell_mod.subprocess, "run", fake_run)
    rc = run_shell([ShellStep(cmd=("echo", "hi"), timeout=1)])
    assert rc is False
    assert "timeout" in capsys.readouterr().out


def test_run_shell_placeholder_substitution(monkeypatch):
    captured = []

    def fake_run(cmd, **kw):
        captured.append(tuple(cmd))
        return MagicMock(returncode=0)

    monkeypatch.setattr(shell_mod.subprocess, "run", fake_run)
    rc = run_shell(
        [ShellStep(cmd=("ollama", "show", "{model_name}"))],
        context={"model_name": "qwen:32b"},
    )
    assert rc is True
    assert captured == [("ollama", "show", "qwen:32b")]


def test_run_shell_registered_in_fix_actions():
    assert FIX_ACTIONS["run_shell"] is run_shell


# ── Loader: per-action steps shape ───────────────────────────────────


def test_loader_accepts_run_shell_action():
    yaml_text = textwrap.dedent(
        """\
        version: 1
        symptoms:
          - id: shellable
            category: x
            severity: warn
            triggered_by:
              check: model_loaded
              match: { field: details.gpu_pct, op: lt, value: 95 }
            diagnosis: x
            fix:
              action: run_shell
              label: ok
              steps:
                - cmd: ["ollama", "show", "{model_name}"]
                - cmd: ["bash", "-c", "echo done"]
                  timeout: 10
        """
    )
    syms = load_symptoms_from_string(yaml_text)
    assert syms[0].fix.action == "run_shell"
    assert len(syms[0].fix.steps) == 2
    assert syms[0].fix.steps[0].cmd == ("ollama", "show", "{model_name}")
    assert syms[0].fix.steps[1].timeout == 10


def test_loader_rejects_run_shell_without_cmd():
    bad = textwrap.dedent(
        """\
        version: 1
        symptoms:
          - id: bad
            category: x
            severity: warn
            triggered_by:
              check: model_loaded
              match: { field: details.gpu_pct, op: lt, value: 95 }
            diagnosis: x
            fix:
              action: run_shell
              steps:
                - stdout_to: "/tmp/x"
        """
    )
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(bad)
    assert "'cmd' is required" in str(exc.value)


def test_loader_rejects_run_shell_with_string_steps():
    """run_shell expects dict steps; string list is rejected (it would
    silently accept a print_remediation-formatted symptom otherwise)."""
    bad = textwrap.dedent(
        """\
        version: 1
        symptoms:
          - id: bad
            category: x
            severity: warn
            triggered_by:
              check: model_loaded
              match: { field: details.gpu_pct, op: lt, value: 95 }
            diagnosis: x
            fix:
              action: run_shell
              steps:
                - "this is a string"
        """
    )
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(bad)
    assert "must be mappings" in str(exc.value)


def test_loader_rejects_print_remediation_with_dict_steps():
    """Cross-rejection: print_remediation expects strings, not dicts."""
    bad = textwrap.dedent(
        """\
        version: 1
        symptoms:
          - id: bad
            category: x
            severity: warn
            triggered_by:
              check: codent_version
              match: { field: details.compatible, op: equals, value: false }
            diagnosis: x
            fix:
              action: print_remediation
              steps:
                - cmd: ["ollama", "show"]
        """
    )
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(bad)
    assert "list of strings" in str(exc.value)


def test_loader_rejects_unknown_step_field():
    bad = textwrap.dedent(
        """\
        version: 1
        symptoms:
          - id: bad
            category: x
            severity: warn
            triggered_by:
              check: model_loaded
              match: { field: details.gpu_pct, op: lt, value: 95 }
            diagnosis: x
            fix:
              action: run_shell
              steps:
                - cmd: ["echo", "hi"]
                  not_a_field: nope
        """
    )
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(bad)
    assert "unknown fields" in str(exc.value)


# ── End-to-end via matcher: custom symptom drives Modelfile patch ──


def test_custom_run_shell_symptom_invokes_chain(monkeypatch, capsys):
    """Custom YAML symptom with run_shell action must produce a fix_action
    that, when invoked, calls subprocess in order with placeholders
    substituted. Sprint 6'da default ollama_num_gpu_insufficient symptom'u
    kaldırıldı — bu test artık run_shell mekanizmasının kendisini denetliyor,
    Modelfile patch logic'i fix_reload_model'da yaşıyor."""
    yaml_text = textwrap.dedent(
        """\
        version: 1
        symptoms:
          - id: shellable_demo
            category: x
            severity: warn
            triggered_by:
              check: model_loaded
              match: { field: details.gpu_pct, op: lt, value: 95 }
            diagnosis: x
            fix:
              action: run_shell
              label: "demo chain"
              steps:
                - cmd: ["ollama", "show", "{model_name}", "--modelfile"]
                - cmd: ["ollama", "create", "{model_name}"]
        """
    )
    syms = load_symptoms_from_string(yaml_text)

    captured_calls = []

    def fake_run(cmd, **kw):
        captured_calls.append(tuple(cmd))
        return MagicMock(returncode=0)

    monkeypatch.setattr(shell_mod.subprocess, "run", fake_run)

    r = CheckResult(
        name="Model yüklü",
        status="fail",
        message="…",
        details={
            "gpu_pct": 0,
            "size": 1, "size_vram": 0,
            "model_name": "cont-local:latest",
        },
    )
    apply_symptoms(r, syms, "model_loaded")
    assert "shellable_demo" in r.matched_symptoms
    rc = r.fix_action()
    assert rc is True
    assert ("ollama", "show", "cont-local:latest", "--modelfile") in captured_calls
    assert ("ollama", "create", "cont-local:latest") in captured_calls
