"""Triage gate cascade: a failing prerequisite causes downstream skip."""

from types import SimpleNamespace

from contdoctor.core import runner as runner_mod
from contdoctor.core.result import CheckResult
from contdoctor.core.runner import run_checks


def _stub(check_map):
    """Replace the runner's CHECKS dict for the duration of one call."""
    return check_map


def test_all_ok_runs_every_check(monkeypatch):
    calls = []
    def make(name, status="ok"):
        def fn(_args):
            calls.append(name)
            return CheckResult(name, status, "ok")
        return fn

    fake = {
        "ollama_proc": make("ollama_proc"),
        "ollama_api": make("ollama_api"),
        "model_reg": make("model_reg"),
    }
    monkeypatch.setattr(runner_mod, "CHECKS", fake)
    args = SimpleNamespace(model="m")
    results = run_checks(args, ["ollama_proc", "ollama_api", "model_reg"])
    assert calls == ["ollama_proc", "ollama_api", "model_reg"]
    assert all(r.status == "ok" for r in results)


def test_failing_prerequisite_skips_downstream(monkeypatch):
    ran = []
    def proc_fail(_a):
        ran.append("ollama_proc")
        return CheckResult("ollama_proc", "fail", "down")
    def api_run(_a):
        ran.append("ollama_api")
        return CheckResult("ollama_api", "ok", "should not run")

    fake = {"ollama_proc": proc_fail, "ollama_api": api_run}
    monkeypatch.setattr(runner_mod, "CHECKS", fake)
    args = SimpleNamespace(model="m")
    results = run_checks(args, ["ollama_proc", "ollama_api"])
    assert ran == ["ollama_proc"]
    assert results[1].status == "warn"
    assert "atlandı" in results[1].message
    assert "ollama_proc" in results[1].message


def test_warn_prerequisite_blocks_downstream(monkeypatch):
    """Spec: gate triggers when prerequisite is *not ok* — warn counts as not-ok."""
    fake = {
        "ollama_proc": lambda a: CheckResult("ollama_proc", "warn", "iffy"),
        "ollama_api": lambda a: CheckResult("ollama_api", "ok", "ran"),
    }
    monkeypatch.setattr(runner_mod, "CHECKS", fake)
    results = run_checks(SimpleNamespace(model="m"), ["ollama_proc", "ollama_api"])
    assert results[1].status == "warn"
    assert "atlandı" in results[1].message


def test_unknown_check_key_is_ignored(monkeypatch, capsys):
    fake = {"ollama_proc": lambda a: CheckResult("ollama_proc", "ok", "")}
    monkeypatch.setattr(runner_mod, "CHECKS", fake)
    results = run_checks(SimpleNamespace(model="m"), ["ollama_proc", "not_a_check"])
    captured = capsys.readouterr()
    assert "bilinmeyen check key" in captured.out
    assert len(results) == 1


def test_check_exception_becomes_fail(monkeypatch):
    def boom(_a):
        raise RuntimeError("kaboom")
    fake = {"gpu": boom}
    monkeypatch.setattr(runner_mod, "CHECKS", fake)
    results = run_checks(SimpleNamespace(model="m"), ["gpu"])
    assert results[0].status == "fail"
    assert "RuntimeError" in results[0].message
    assert "kaboom" in results[0].message


def test_default_check_keys_count_and_order():
    """The built-in checks must be present in the documented order.

    Sprint 1: 13 runtime checks. Sprint 3: + 3 deployment checks.
    Sprint 7: + 2 GPU runtime layer checks (ollama_gpu_runners,
    ollama_gpu_offload_log) inserted between ollama_env and ollama_api.
    """
    expected = [
        # Sprint 9 — environment profile, en başta.
        "known_environment",
        "gpu", "ollama_bin", "ollama_ver", "ollama_proc",
        # Sprint 9.2 — snapshot uyumu, ollama_proc'tan sonra.
        "ollama_proc_snapshot",
        "ollama_env",
        "ollama_gpu_runners", "ollama_gpu_offload_log",
        "ollama_api", "model_reg", "model_loaded", "model_responds",
        # Sprint 9.2 — realistic workload, model_responds'tan sonra.
        "realistic_workload",
        "disk", "glibc", "network", "python",
        "contdoctor_version", "codent_version", "binary_path",
        # Sprint 8 — read-only drift detection, runs last.
        "snapshot_drift",
    ]
    assert list(runner_mod.CHECKS.keys()) == expected
    assert len(runner_mod.CHECKS) == 22
