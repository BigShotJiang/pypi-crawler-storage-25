"""Sprint 7.2 — model-aware Ollama log offload check."""

from __future__ import annotations

from pathlib import Path

import pytest

from contdoctor.checks import ollama_log as log_mod
from contdoctor.checks.ollama_log import (
    check_ollama_gpu_offload_log,
    model_full_gpu_in_log,
)


def _write_log(tmp_path: Path, text: str) -> None:
    p = tmp_path / ".cache" / "cont" / "ollama_serve.log"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text)


def _isolate_home(monkeypatch, tmp_path: Path):
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))


# ── target model load event + offload pencere ───────────────────────


def test_log_target_model_full_offload(monkeypatch, tmp_path):
    _isolate_home(monkeypatch, tmp_path)
    _write_log(
        tmp_path,
        "INFO loading model cont-local:latest\n"
        "DEBUG msg=\"offloaded 49/49 layers to GPU\"\n",
    )
    r = check_ollama_gpu_offload_log("cont-local:latest")
    assert r.status == "ok", r.message
    assert "cont-local:latest: 49/49" in r.message
    assert r.details["target_model"] == "cont-local:latest"


def test_log_target_model_zero_offload_with_error(monkeypatch, tmp_path):
    _isolate_home(monkeypatch, tmp_path)
    _write_log(
        tmp_path,
        "INFO model=cont-local:latest loading\n"
        "ERROR library not found: libggml-cuda.so\n"
        "DEBUG offloaded 0/49 layers to GPU\n",
    )
    r = check_ollama_gpu_offload_log("cont-local:latest")
    assert r.status == "fail", r.message
    assert "0/49" in r.message
    assert "GPU runner library bulunamadı" in r.details["errors"]


def test_log_other_model_offload_does_not_count(monkeypatch, tmp_path):
    """Log'da qwen2.5-coder için 49/49 var, cont-local:latest için load
    event yok → warn (target için kanıt yok)."""
    _isolate_home(monkeypatch, tmp_path)
    _write_log(
        tmp_path,
        "INFO loading model qwen2.5-coder:7b\n"
        "DEBUG offloaded 49/49 layers to GPU\n",
    )
    r = check_ollama_gpu_offload_log("cont-local:latest")
    assert r.status == "warn", r.message
    assert "load event yok" in r.message
    # Target dışı offload bilgisi any_offload field'ına düşer.
    assert r.details["any_offload"] == "49/49"


def test_log_target_model_with_load_event_window_50_lines(monkeypatch, tmp_path):
    """Load event ile offload arasında >50 satır → target için match yok
    (warn). 50 satır sonrasındaki offload, load event'in penceresi dışında."""
    _isolate_home(monkeypatch, tmp_path)
    far_lines = "\n".join(f"INFO filler line {i}" for i in range(60))
    _write_log(
        tmp_path,
        "INFO loading model cont-local:latest\n"
        + far_lines
        + "\nDEBUG offloaded 49/49 layers to GPU\n",
    )
    r = check_ollama_gpu_offload_log("cont-local:latest")
    assert r.status == "warn", r.message
    assert "offload satırı yok" in r.message


def test_log_no_target_falls_back_to_any_offload(monkeypatch, tmp_path):
    """target_model=None → eski 'any offload' davranışı (geriye uyumlu)."""
    _isolate_home(monkeypatch, tmp_path)
    _write_log(tmp_path, "DEBUG offloaded 49/49 layers to GPU\n")
    r = check_ollama_gpu_offload_log(target_model=None)
    assert r.status == "ok"
    assert "49/49" in r.message
    # Model-spesifik field'lar None-mode'da yok.
    assert "target_model" not in r.details


# ── model_full_gpu_in_log boolean helper ─────────────────────────────


def test_model_full_gpu_in_log_only_target(monkeypatch, tmp_path):
    _isolate_home(monkeypatch, tmp_path)
    _write_log(
        tmp_path,
        "INFO loading model qwen:7b\n"
        "DEBUG offloaded 49/49 layers to GPU\n"
        "INFO loading model cont-local:latest\n"
        "DEBUG offloaded 0/49 layers to GPU\n",
    )
    # qwen full GPU evidence → True; cont-local 0/49 → False.
    assert model_full_gpu_in_log("qwen:7b") is True
    assert model_full_gpu_in_log("cont-local:latest") is False


def test_model_full_gpu_in_log_returns_false_without_load_event(monkeypatch, tmp_path):
    _isolate_home(monkeypatch, tmp_path)
    _write_log(
        tmp_path,
        "DEBUG offloaded 49/49 layers to GPU\n",  # no load event line
    )
    assert model_full_gpu_in_log("cont-local:latest") is False


# ── runner check + model parameter end-to-end ───────────────────────


def test_runner_check_uses_model_specific_log_evidence(monkeypatch, tmp_path):
    """Custom path + env wrong + log target model 49/49 → ok."""
    from contdoctor.checks import ollama_runners as runners_check
    from contdoctor.checks.ollama_runners import REQUIRED_LIBS, check_ollama_gpu_runners

    real_dir = tmp_path / "ollama-full" / "lib" / "ollama" / "cuda_v12"
    real_dir.mkdir(parents=True, exist_ok=True)
    for lib in REQUIRED_LIBS:
        (real_dir / lib).write_bytes(b"")

    monkeypatch.setenv("OLLAMA_LLM_LIBRARY", str(tmp_path / "wrong"))
    monkeypatch.delenv("OLLAMA_RUNNERS_DIR", raising=False)
    _isolate_home(monkeypatch, tmp_path)
    monkeypatch.setattr(runners_check, "_default_paths", lambda: [real_dir])
    monkeypatch.setattr(runners_check, "_OLLAMA_DEFAULT_PATHS", frozenset())

    _write_log(
        tmp_path,
        "INFO loading model cont-local:latest\n"
        "DEBUG offloaded 49/49 layers to GPU\n",
    )

    r = check_ollama_gpu_runners(target_model="cont-local:latest")
    assert r.status == "ok", r.message
    assert "cont-local:latest için full GPU doğruluyor" in r.message


def test_runner_check_other_model_offload_does_not_override(monkeypatch, tmp_path):
    """Sertan'ın bug'ı: log'da farklı model 49/49 var, target için load
    event yok → log evidence override TETİKLENMEMELİ → env-mismatch warn."""
    from contdoctor.checks import ollama_runners as runners_check
    from contdoctor.checks.ollama_runners import REQUIRED_LIBS, check_ollama_gpu_runners

    real_dir = tmp_path / "ollama-full" / "lib" / "ollama" / "cuda_v12"
    real_dir.mkdir(parents=True, exist_ok=True)
    for lib in REQUIRED_LIBS:
        (real_dir / lib).write_bytes(b"")

    monkeypatch.setenv("OLLAMA_LLM_LIBRARY", str(tmp_path / "wrong"))
    monkeypatch.delenv("OLLAMA_RUNNERS_DIR", raising=False)
    _isolate_home(monkeypatch, tmp_path)
    monkeypatch.setattr(runners_check, "_default_paths", lambda: [real_dir])
    monkeypatch.setattr(runners_check, "_OLLAMA_DEFAULT_PATHS", frozenset())

    _write_log(
        tmp_path,
        "INFO loading model qwen2.5-coder:7b\n"
        "DEBUG offloaded 49/49 layers to GPU\n",
    )

    r = check_ollama_gpu_runners(target_model="cont-local:latest")
    assert r.status == "warn", r.message
    assert "non-default path" in r.message
