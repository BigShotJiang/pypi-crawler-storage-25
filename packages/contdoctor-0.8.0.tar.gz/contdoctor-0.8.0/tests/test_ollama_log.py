"""Sprint 7 — check_ollama_gpu_offload_log.

Log path'leri ``Path.home()``'a göre türetildiği için ``Path.home``'u
``monkeypatch`` ile ``tmp_path``'e yönlendirip log dosyasını orada kuruyoruz.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from contdoctor.checks import ollama_log as log_mod
from contdoctor.checks.ollama_log import check_ollama_gpu_offload_log


def _write_log(tmp_path: Path, text: str) -> Path:
    p = tmp_path / ".cache" / "cont" / "ollama_serve.log"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text)
    return p


def _isolate_home(monkeypatch, tmp_path: Path):
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))


# ── offload pattern parsing ─────────────────────────────────────────


def test_log_offloaded_full(monkeypatch, tmp_path):
    _isolate_home(monkeypatch, tmp_path)
    _write_log(tmp_path, "INFO ... offloaded 49/49 layers to GPU\n")
    r = check_ollama_gpu_offload_log()
    assert r.status == "ok"
    assert r.details["offloaded_layers"] == "49/49"


def test_log_offloaded_partial(monkeypatch, tmp_path):
    _isolate_home(monkeypatch, tmp_path)
    _write_log(tmp_path, "msg=offloaded 24/49 layers to GPU\n")
    r = check_ollama_gpu_offload_log()
    assert r.status == "warn"
    assert "24/49" in r.message
    assert r.details["offloaded_layers"] == "24/49"


def test_log_offloaded_zero(monkeypatch, tmp_path):
    _isolate_home(monkeypatch, tmp_path)
    _write_log(tmp_path, "msg=offloaded 0/49 layers to GPU\n")
    r = check_ollama_gpu_offload_log()
    assert r.status == "fail"
    assert "TAMAMEN CPU'da" in r.message


def test_log_uses_last_offload_match(monkeypatch, tmp_path):
    """If the log has multiple matches, the most recent one wins."""
    _isolate_home(monkeypatch, tmp_path)
    _write_log(
        tmp_path,
        "offloaded 0/49 layers to GPU\n"
        "...some recovery...\n"
        "offloaded 49/49 layers to GPU\n",
    )
    r = check_ollama_gpu_offload_log()
    assert r.status == "ok"
    assert r.details["offloaded_layers"] == "49/49"


# ── critical error patterns ─────────────────────────────────────────


def test_log_library_not_found_pattern(monkeypatch, tmp_path):
    _isolate_home(monkeypatch, tmp_path)
    _write_log(
        tmp_path,
        "msg=offloaded 0/49 layers to GPU\n"
        "ERROR: library not found: libggml-cuda.so\n",
    )
    r = check_ollama_gpu_offload_log()
    assert r.status == "fail"
    assert "library bulunamadı" in r.message.lower() or "library bulunamadı" in r.message
    assert "GPU runner library bulunamadı" in r.details["errors"]


def test_log_total_vram_zero_pattern(monkeypatch, tmp_path):
    _isolate_home(monkeypatch, tmp_path)
    _write_log(
        tmp_path,
        "msg=offloaded 0/49 layers to GPU\n"
        "INFO ... total vram=0 MiB free=0 MiB\n",
    )
    r = check_ollama_gpu_offload_log()
    assert r.status == "fail"
    assert "VRAM 0 byte (GPU detect edilmedi)" in r.details["errors"]


def test_log_no_compatible_gpus_with_no_offload(monkeypatch, tmp_path):
    """No offload line + critical error → fail."""
    _isolate_home(monkeypatch, tmp_path)
    _write_log(
        tmp_path,
        "INFO starting…\nERROR: no compatible GPUs detected\n",
    )
    r = check_ollama_gpu_offload_log()
    assert r.status == "fail"
    assert "Uyumsuz GPU" in r.details["errors"]


def test_log_no_offload_line_without_errors(monkeypatch, tmp_path):
    _isolate_home(monkeypatch, tmp_path)
    _write_log(tmp_path, "INFO starting…\n")
    r = check_ollama_gpu_offload_log()
    assert r.status == "warn"
    assert "model henüz yüklenmedi" in r.message


# ── log absence + journalctl fallback ───────────────────────────────


def test_log_absent_returns_warn(monkeypatch, tmp_path):
    _isolate_home(monkeypatch, tmp_path)
    monkeypatch.setattr(log_mod, "_run", lambda cmd, timeout=5: (1, "", ""))
    r = check_ollama_gpu_offload_log()
    assert r.status == "warn"
    assert "log bulunamadı" in r.message.lower()


def test_log_journalctl_fallback(monkeypatch, tmp_path):
    """Dosya yok ama journalctl çıktısı var → analiz yapılır."""
    _isolate_home(monkeypatch, tmp_path)
    journal = "msg=offloaded 49/49 layers to GPU\n"
    monkeypatch.setattr(log_mod, "_run", lambda cmd, timeout=5: (0, journal, ""))
    r = check_ollama_gpu_offload_log()
    assert r.status == "ok"
    assert r.details["log_source"] == "journalctl -u ollama"
