"""Sprint 8 (revised) — environment fingerprint + role guess + override."""

from __future__ import annotations

from pathlib import Path

import pytest

from contdoctor.snapshot import fingerprint as fp_mod
from contdoctor.snapshot.fingerprint import (
    EnvironmentFingerprint,
    compute_fingerprint,
    guess_role,
)


def test_fingerprint_hostname_user_filled(monkeypatch):
    monkeypatch.setenv("USER", "tester")
    monkeypatch.setattr(fp_mod.socket, "gethostname", lambda: "machine-x")
    monkeypatch.setattr(fp_mod, "_run", lambda *a, **k: (1, "", ""))
    fp = compute_fingerprint()
    assert fp.hostname == "machine-x"
    assert fp.user == "tester"


def test_fingerprint_wsl_detection_via_proc_version(monkeypatch, tmp_path):
    fake = tmp_path / "version"
    fake.write_text("Linux ... Microsoft ... WSL2\n")

    real_read_text = Path.read_text

    def fake_read_text(self, *args, **kwargs):
        if str(self) == "/proc/version":
            return fake.read_text()
        return real_read_text(self, *args, **kwargs)

    monkeypatch.setattr(Path, "read_text", fake_read_text)
    monkeypatch.setattr(fp_mod, "_run", lambda *a, **k: (1, "", ""))
    fp = compute_fingerprint()
    assert fp.is_wsl is True


def test_guess_role_wsl_returns_dev(monkeypatch, tmp_path):
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    fp = EnvironmentFingerprint(is_wsl=True, cwd_mount="/")
    assert guess_role(fp) == "dev"


def test_guess_role_mnt_mount_no_wsl_returns_prod_shared(monkeypatch, tmp_path):
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    fp = EnvironmentFingerprint(is_wsl=False, cwd_mount="/mnt/shared/cont")
    assert guess_role(fp) == "prod-shared"


def test_guess_role_default_unknown(monkeypatch, tmp_path):
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    fp = EnvironmentFingerprint(is_wsl=False, cwd_mount="/home/user/work")
    assert guess_role(fp) == "unknown"


def test_role_override_file_takes_precedence(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    role_file = tmp_path / ".contdoctor" / "role.txt"
    role_file.parent.mkdir(parents=True, exist_ok=True)
    role_file.write_text("prod\n")
    # Heuristic would say "dev" (WSL) but override wins.
    fp = EnvironmentFingerprint(is_wsl=True, cwd_mount="/")
    assert guess_role(fp) == "prod"


def test_role_override_invalid_value_falls_back_to_heuristic(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    role_file = tmp_path / ".contdoctor" / "role.txt"
    role_file.parent.mkdir(parents=True, exist_ok=True)
    role_file.write_text("garbage\n")
    fp = EnvironmentFingerprint(is_wsl=True, cwd_mount="/")
    assert guess_role(fp) == "dev"
