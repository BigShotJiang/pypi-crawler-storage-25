"""Sprint 8+9 — running ollama detection + check revisions + known
environments + snapshot is_running."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from contdoctor.checks import ollama as ollama_check
from contdoctor.checks import ollama_proc as proc_mod
from contdoctor.checks.environment import check_known_environment
from contdoctor.checks.ollama import (
    check_ollama_env,
    check_ollama_installed,
    check_ollama_version,
)
from contdoctor.checks.ollama_proc import RunningOllama, detect_running_ollama
from contdoctor.snapshot.fingerprint import EnvironmentFingerprint
from contdoctor.snapshot.profiles import (
    load_known_environments,
    match_profile,
)


# ── detect_running_ollama ────────────────────────────────────────────


def test_detect_running_ollama_returns_none_when_no_process(monkeypatch):
    monkeypatch.setattr(proc_mod, "pgrep", lambda pat: [])
    assert detect_running_ollama() is None


def test_detect_running_ollama_reads_proc_files(monkeypatch, tmp_path):
    """``/proc/<pid>/{exe,cmdline,environ}`` üçü birden okunur."""
    monkeypatch.setattr(proc_mod, "pgrep", lambda pat: [4242])
    fake_proc = tmp_path / "proc" / "4242"
    fake_proc.mkdir(parents=True, exist_ok=True)
    real_binary = tmp_path / "ollama-full" / "bin" / "ollama"
    real_binary.parent.mkdir(parents=True, exist_ok=True)
    real_binary.write_text("#!/bin/sh\n")
    (fake_proc / "exe").symlink_to(real_binary)
    (fake_proc / "cmdline").write_bytes(b"ollama\x00serve\x00--verbose\x00")
    env_text = "OLLAMA_NUM_GPU=999\x00LD_LIBRARY_PATH=/opt/cuda\x00OLLAMA_RUNNERS_DIR=/opt/runners\x00"
    (fake_proc / "environ").write_bytes(env_text.encode())

    real_path = Path
    monkeypatch.setattr(
        proc_mod, "Path",
        lambda p: tmp_path / p.lstrip("/") if str(p).startswith("/proc/") else real_path(p),
    )
    r = detect_running_ollama()
    assert r is not None
    assert r.pid == 4242
    assert r.binary_path == str(real_binary.resolve())
    assert r.cmdline == ["ollama", "serve", "--verbose"]
    assert r.env["OLLAMA_NUM_GPU"] == "999"
    assert r.env["LD_LIBRARY_PATH"] == "/opt/cuda"
    assert r.has_custom_runtime is True


def test_running_ollama_no_custom_runtime_when_system_path_and_minimal_env():
    """Sprint 9.1: has_custom_runtime üç sinyalden biri True ise True;
    binary system path'te (/usr/...) + LD_LIBRARY_PATH/RUNNERS_DIR yoksa False."""
    r = RunningOllama(
        pid=1,
        binary_path="/usr/local/bin/ollama",
        env={"OLLAMA_NUM_GPU": "999"},
    )
    assert r.has_custom_runtime is False


def test_running_ollama_custom_when_binary_outside_usr():
    """Sprint 9.1: binary /usr/ dışında → custom (Sertan'ın ~/ollama-full senaryosu)."""
    r = RunningOllama(
        pid=1,
        binary_path="/home/sertan/ollama-full/bin/ollama",
        env={"OLLAMA_NUM_GPU": "999"},  # env minimal
    )
    assert r.has_custom_runtime is True


# ── check_ollama_installed shadow detection ─────────────────────────


def test_check_ollama_installed_shadow_detection(monkeypatch):
    fake_running = RunningOllama(
        pid=42,
        binary_path="/home/u/ollama-full/bin/ollama",
        env={"OLLAMA_NUM_GPU": "999"},
    )
    monkeypatch.setattr(ollama_check, "detect_running_ollama", lambda: fake_running)
    monkeypatch.setattr(
        ollama_check.shutil, "which",
        lambda name: "/usr/local/bin/ollama" if name == "ollama" else None,
    )
    r = check_ollama_installed()
    assert r.status == "ok"
    assert r.details["shadowed"] is True
    assert r.details["running_binary"] == "/home/u/ollama-full/bin/ollama"
    assert r.details["path_binary"] == "/usr/local/bin/ollama"
    assert "PATH'te farklı" in r.message


def test_check_ollama_installed_no_shadow_when_paths_match(monkeypatch):
    fake_running = RunningOllama(
        pid=42,
        binary_path="/usr/local/bin/ollama",
        env={"OLLAMA_NUM_GPU": "999"},
    )
    monkeypatch.setattr(ollama_check, "detect_running_ollama", lambda: fake_running)
    monkeypatch.setattr(
        ollama_check.shutil, "which",
        lambda name: "/usr/local/bin/ollama" if name == "ollama" else None,
    )
    r = check_ollama_installed()
    assert r.status == "ok"
    assert r.details["shadowed"] is False


def test_check_ollama_installed_path_fallback_when_not_running(monkeypatch):
    monkeypatch.setattr(ollama_check, "detect_running_ollama", lambda: None)
    monkeypatch.setattr(
        ollama_check.shutil, "which",
        lambda name: "/usr/local/bin/ollama" if name == "ollama" else None,
    )
    r = check_ollama_installed()
    assert r.status == "ok"
    assert r.details["path_binary"] == "/usr/local/bin/ollama"
    assert r.details.get("running") is False


# ── check_ollama_version uses running binary ────────────────────────


def test_check_ollama_version_uses_running_binary(monkeypatch):
    fake_running = RunningOllama(
        pid=42, binary_path="/home/u/ollama-full/bin/ollama", env={}
    )
    monkeypatch.setattr(ollama_check, "detect_running_ollama", lambda: fake_running)
    captured = {}

    def fake_run(cmd, timeout=5):
        captured["cmd"] = cmd
        return (0, "ollama version is 0.13.5\n", "")

    from contdoctor.core import proc as core_proc
    monkeypatch.setattr(core_proc, "run", fake_run)
    r = check_ollama_version()
    assert r.status == "ok"
    assert r.details["version"] == "0.13.5"
    assert r.details["binary"] == "/home/u/ollama-full/bin/ollama"
    assert captured["cmd"] == ["/home/u/ollama-full/bin/ollama", "--version"]


def test_check_ollama_version_known_bad_no_fix_action(monkeypatch):
    """Sprint 9: 0.20.3 warn ama fix_action YOK."""
    fake_running = RunningOllama(pid=1, binary_path="/usr/local/bin/ollama", env={})
    monkeypatch.setattr(ollama_check, "detect_running_ollama", lambda: fake_running)

    def fake_run(cmd, timeout=5):
        return (0, "ollama version is 0.20.3\n", "")

    from contdoctor.core import proc as core_proc
    monkeypatch.setattr(core_proc, "run", fake_run)
    r = check_ollama_version()
    assert r.status == "warn"
    assert "0.20.3" in r.message
    assert r.fix_action is None  # critical: doctor karışmasın


# ── check_ollama_env custom-runtime no-fix ──────────────────────────


def test_check_ollama_env_custom_runtime_returns_ok_no_fix(monkeypatch):
    fake_running = RunningOllama(
        pid=42,
        binary_path="/home/u/ollama-full/bin/ollama",
        env={
            "OLLAMA_NUM_GPU": "999",
            "LD_LIBRARY_PATH": "/opt/cuda",
            "OLLAMA_RUNNERS_DIR": "/opt/runners",
        },
    )
    monkeypatch.setattr(ollama_check, "detect_running_ollama", lambda: fake_running)
    monkeypatch.delenv("OLLAMA_NUM_GPU", raising=False)
    for var in ("OLLAMA_LLM_LIBRARY", "CUDA_VISIBLE_DEVICES"):
        monkeypatch.delenv(var, raising=False)

    r = check_ollama_env()
    assert r.status == "ok"
    assert r.fix_action is None
    assert r.details["custom_runtime"] is True
    assert "kanıt: çalışan process" in r.message


def test_check_ollama_env_no_num_gpu_with_custom_runtime_no_fix(monkeypatch):
    """Custom runtime tespit edilmişse, OLLAMA_NUM_GPU eksik olsa bile
    fix_action önerilmez (Sprint 9 critical lesson)."""
    fake_running = RunningOllama(
        pid=42,
        binary_path="/home/u/ollama-full/bin/ollama",
        env={"LD_LIBRARY_PATH": "/opt/cuda"},  # OLLAMA_NUM_GPU yok
    )
    monkeypatch.setattr(ollama_check, "detect_running_ollama", lambda: fake_running)
    monkeypatch.delenv("OLLAMA_NUM_GPU", raising=False)
    for var in ("OLLAMA_LLM_LIBRARY", "CUDA_VISIBLE_DEVICES"):
        monkeypatch.delenv(var, raising=False)

    r = check_ollama_env()
    assert r.status == "warn"
    assert r.fix_action is None
    assert "custom-launched" in r.message
    assert r.details["custom_runtime"] is True


def test_check_ollama_env_no_running_falls_back_to_shell(monkeypatch):
    """Çalışan process yoksa shell env davranışı (geriye uyumlu)."""
    monkeypatch.setattr(ollama_check, "detect_running_ollama", lambda: None)
    monkeypatch.setenv("OLLAMA_NUM_GPU", "999")
    for var in ("OLLAMA_LLM_LIBRARY", "CUDA_VISIBLE_DEVICES"):
        monkeypatch.delenv(var, raising=False)
    r = check_ollama_env()
    assert r.status == "ok"
    # Custom runtime yok → "(shell)" suffix var (Sprint 1 davranış).
    assert "shell" in r.message


# ── known_environments.yaml + profile match ─────────────────────────


def test_known_environments_yaml_has_at_least_two_profiles():
    envs = load_known_environments()
    ids = {e["id"] for e in envs}
    assert "cont-dev-wsl-laptop" in ids
    assert "cont-prod-bank" in ids
    assert len(envs) >= 2


def test_match_profile_dev_wsl():
    """Sertan'ın laptop fingerprint'ine cont-dev-wsl-laptop match etmeli."""
    fp = EnvironmentFingerprint(
        hostname="DESKTOP-VU802C6",
        is_wsl=True,
        os_release="Ubuntu 24.04.3 LTS",
        kernel="6.6.87.2-microsoft-standard-WSL2",
        gpu_name="NVIDIA GeForce RTX 5090 Laptop GPU",
    )
    profile = match_profile(fp)
    assert profile is not None
    assert profile["id"] == "cont-dev-wsl-laptop"


def test_match_profile_unknown_fingerprint_returns_none():
    fp = EnvironmentFingerprint(
        hostname="random-server",
        is_wsl=False,
        os_release="Alpine Linux 3.18",
        kernel="6.1.0",
        gpu_name=None,
    )
    profile = match_profile(fp)
    assert profile is None


def test_match_profile_prod_template():
    """is_wsl=false + Ubuntu → prod template'i match etmeli."""
    fp = EnvironmentFingerprint(
        hostname="prod-x",
        is_wsl=False,
        os_release="Ubuntu 20.04.6 LTS",
        kernel="5.15.0",
    )
    profile = match_profile(fp)
    assert profile is not None
    assert profile["id"] == "cont-prod-bank"


def test_user_environments_override_merges(monkeypatch, tmp_path):
    """User dosyası aynı id ile override eder."""
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    user_yaml = tmp_path / ".contdoctor" / "environments.yaml"
    user_yaml.parent.mkdir(parents=True, exist_ok=True)
    user_yaml.write_text(
        "version: 1\n"
        "environments:\n"
        "  - id: cont-dev-wsl-laptop\n"
        "    label: 'overridden by user'\n"
        "    role: dev\n"
        "    fingerprint:\n"
        "      hostname_pattern: 'CUSTOM-*'\n"
    )
    envs = load_known_environments()
    by_id = {e["id"]: e for e in envs}
    assert by_id["cont-dev-wsl-laptop"]["label"] == "overridden by user"
    # Other package profiles still present.
    assert "cont-prod-bank" in by_id


def test_check_known_environment_ok_when_match(monkeypatch):
    monkeypatch.setattr(
        "contdoctor.checks.environment.compute_fingerprint",
        lambda: EnvironmentFingerprint(
            hostname="laptop", is_wsl=True,
            os_release="Ubuntu 24.04.3 LTS",
            kernel="6.6.87.2-microsoft-standard-WSL2",
            gpu_name="NVIDIA RTX 5090",
        ),
    )
    r = check_known_environment()
    assert r.status == "ok"
    assert r.details["profile_id"] == "cont-dev-wsl-laptop"


def test_check_known_environment_warn_when_unknown(monkeypatch):
    monkeypatch.setattr(
        "contdoctor.checks.environment.compute_fingerprint",
        lambda: EnvironmentFingerprint(
            hostname="weird", is_wsl=False, os_release="Alpine 3.18", kernel="6.1.0",
        ),
    )
    monkeypatch.setattr(
        "contdoctor.checks.environment.load_known_environments", lambda: [],
    )
    r = check_known_environment()
    assert r.status == "warn"
    assert "Bilinmeyen profil" in r.message


# ── snapshot ollama.is_running + detected_via ───────────────────────


def test_snapshot_ollama_records_running_binary(monkeypatch, tmp_path):
    """build_snapshot çalışan process varsa onun binary'i + env'i kullanır."""
    from contdoctor.snapshot import builder as builder_mod
    from contdoctor.snapshot import build_snapshot

    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    real_binary = tmp_path / "ollama-full" / "bin" / "ollama"
    real_binary.parent.mkdir(parents=True, exist_ok=True)
    real_binary.write_text("#!/bin/sh\n")

    fake_running = RunningOllama(
        pid=99,
        binary_path=str(real_binary),
        env={"OLLAMA_NUM_GPU": "999", "LD_LIBRARY_PATH": "/opt/cuda"},
        detected_via="pgrep+/proc",
    )
    monkeypatch.setattr(builder_mod, "detect_running_ollama", lambda: fake_running)
    monkeypatch.setattr(
        builder_mod, "_run",
        lambda cmd, timeout=5: (
            (0, "ollama version is 0.13.5\n", "")
            if cmd[-1:] == ["--version"] else (1, "", "")
        ),
    )
    monkeypatch.setattr(builder_mod, "http_get", lambda *a, **k: (None, ""))

    snap = build_snapshot()
    assert snap.ollama.is_running is True
    assert snap.ollama.detected_via == "pgrep+/proc"
    assert snap.ollama.binary_path == str(real_binary)
    assert snap.ollama.version == "0.13.5"
    # Env çalışan process'ten okundu.
    assert snap.env["OLLAMA_NUM_GPU"] == "999"
    assert snap.env["LD_LIBRARY_PATH"] == "/opt/cuda"


def test_snapshot_ollama_falls_back_to_path_when_not_running(monkeypatch, tmp_path):
    from contdoctor.snapshot import builder as builder_mod
    from contdoctor.snapshot import build_snapshot

    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    monkeypatch.setattr(builder_mod, "detect_running_ollama", lambda: None)
    fake_path = tmp_path / "fake-ollama"
    fake_path.write_bytes(b"x" * 10)
    monkeypatch.setattr(
        builder_mod.shutil, "which",
        lambda name: str(fake_path) if name == "ollama" else None,
    )
    monkeypatch.setattr(
        builder_mod, "_run",
        lambda cmd, timeout=5: (
            (0, "ollama version is 0.20.3\n", "")
            if cmd[-1:] == ["--version"] else (1, "", "")
        ),
    )
    monkeypatch.setattr(builder_mod, "http_get", lambda *a, **k: (None, ""))

    snap = build_snapshot()
    assert snap.ollama.is_running is False
    assert snap.ollama.detected_via == "PATH"
    assert snap.ollama.version == "0.20.3"


# ── Lessons updated ─────────────────────────────────────────────────


def test_lessons_example_includes_sprint_9_lessons():
    from contdoctor.lessons import load_example_lessons

    lessons = load_example_lessons()
    ids = {l.id for l in lessons}
    assert "doctor_must_not_restart_running_ollama" in ids
    assert "which_ollama_lies_when_custom_binary_running" in ids
    assert len(lessons) >= 7
