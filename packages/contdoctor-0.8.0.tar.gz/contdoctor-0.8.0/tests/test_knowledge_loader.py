"""YAML loader: happy path + every documented validation failure."""

import pytest

from contdoctor.knowledge import default_symptoms, load_symptoms_from_string
from contdoctor.knowledge.loader import KnowledgeError
from contdoctor.knowledge.schema import Op


def test_valid_yaml_parses_two_rules(valid_yaml):
    syms = load_symptoms_from_string(valid_yaml)
    assert [s.id for s in syms] == [
        "ollama_0_20_3_gpu_regression",
        "ollama_llm_library_poison",
    ]
    s0 = syms[0]
    assert s0.match.field == "details.version"
    assert s0.match.op is Op.EQUALS
    assert s0.match.value == "0.20.3"
    assert s0.fix.action == "fix_set_ollama_num_gpu"
    assert s0.severity == "warn"


def test_default_symptoms_loads_packaged_yaml():
    """Sprint 9.1: ollama_0_20_3 ve ollama_llm_library_poison symptom'ları
    silindi (custom-launched setup'ı bozan fix_action injection yapıyorlardı).
    Default YAML hâlâ deployment symptom'larını taşıyor."""
    syms = default_symptoms()
    ids = {s.id for s in syms}
    assert "codent_version_drift" in ids
    assert "cont_binary_shadowing" in ids
    assert "ollama_0_20_3_gpu_regression" not in ids
    assert "ollama_llm_library_poison" not in ids


def test_unknown_check_key_rejected(yaml_unknown_check):
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(yaml_unknown_check)
    assert "unknown check key" in str(exc.value)


def test_unknown_op_rejected(yaml_unknown_op):
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(yaml_unknown_op)
    assert "unknown op" in str(exc.value)


def test_duplicate_id_rejected(yaml_duplicate_id):
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(yaml_duplicate_id)
    assert "duplicate id" in str(exc.value)


def test_missing_required_field_rejected(yaml_missing_field):
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(yaml_missing_field)
    assert "missing required field" in str(exc.value)
    assert "diagnosis" in str(exc.value)


def test_version_mismatch_rejected(yaml_version_mismatch):
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(yaml_version_mismatch)
    assert "schema version" in str(exc.value)


def test_unknown_fix_action_rejected(yaml_unknown_fix_action):
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(yaml_unknown_fix_action)
    assert "unknown action" in str(exc.value)


def test_index_syntax_in_field_rejected():
    bad = """\
version: 1
symptoms:
  - id: bad_field
    category: misc
    severity: warn
    triggered_by:
      check: ollama_ver
      match:
        field: details.poison[0]
        op: equals
        value: x
    diagnosis: nope
"""
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(bad)
    assert "index syntax" in str(exc.value)


def test_in_list_requires_list_value():
    bad = """\
version: 1
symptoms:
  - id: bad_in_list
    category: misc
    severity: warn
    triggered_by:
      check: ollama_ver
      match:
        field: status
        op: in_list
        value: "not_a_list"
    diagnosis: nope
"""
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(bad)
    assert "in_list requires a list" in str(exc.value)
