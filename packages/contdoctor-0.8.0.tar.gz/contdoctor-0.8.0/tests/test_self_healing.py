"""Sprint 7 — simplified fix_reload_model / fix_warmup_model + --version
+ no-progress block.

Sprint 6'nın self-healing zinciri (Modelfile patch + manuel debug
bloğu) Sprint 7'de yanlış katman olduğu için silindi; root cause
``ollama_gpu_runners`` ve ``ollama_gpu_offload_log`` check'lerinde.
Bu modül artık fix_*_model'in sade kontratını ve CLI bileşenlerini
test ediyor.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from contdoctor.fixes import model as fix_mod
from contdoctor.fixes.model import (
    GPU_PCT_OK_THRESHOLD,
    fix_reload_model,
    fix_warmup_model,
)


# ── fix_warmup_model — sade warmup + verify ─────────────────────────


def test_warmup_returns_true_when_gpu_ok(monkeypatch, capsys):
    monkeypatch.setattr(fix_mod, "http_post_json", lambda *a, **k: (200, '{"r":""}'))
    monkeypatch.setattr(fix_mod, "_gpu_pct", lambda model: 100)
    assert fix_warmup_model("cont-local:latest") is True
    out = capsys.readouterr().out
    assert "%100 GPU" in out


def test_warmup_returns_false_when_gpu_low(monkeypatch, capsys):
    monkeypatch.setattr(fix_mod, "http_post_json", lambda *a, **k: (200, '{"r":""}'))
    monkeypatch.setattr(fix_mod, "_gpu_pct", lambda model: 40)
    assert fix_warmup_model("cont-local:latest") is False
    out = capsys.readouterr().out
    assert "%40 GPU" in out
    # Sprint 7.2: log peek output replaces the generic "üst check'lere bak"
    # message — operator gets a model-specific log diagnosis.
    assert "log" in out


def test_warmup_returns_false_when_http_fails(monkeypatch):
    monkeypatch.setattr(fix_mod, "http_post_json", lambda *a, **k: (500, "boom"))
    assert fix_warmup_model("cont-local:latest") is False


def test_warmup_optimistic_when_gpu_pct_unreadable(monkeypatch):
    """``/api/ps`` introspect başarısızsa warmup HTTP 200'a güven."""
    monkeypatch.setattr(fix_mod, "http_post_json", lambda *a, **k: (200, '{"r":""}'))
    monkeypatch.setattr(fix_mod, "_gpu_pct", lambda model: None)
    assert fix_warmup_model("cont-local:latest") is True


# ── fix_reload_model — unload + warmup + verify (no Modelfile chain) ─


def test_reload_unloads_then_warms_up(monkeypatch):
    calls = []
    monkeypatch.setattr(
        fix_mod, "http_post_json",
        lambda path, body, timeout: calls.append((path, body)) or (200, '{"r":""}'),
    )
    monkeypatch.setattr(fix_mod, "_gpu_pct", lambda model: 100)
    monkeypatch.setattr(fix_mod.time, "sleep", lambda *a, **k: None)
    assert fix_reload_model("cont-local:latest") is True
    # First call is unload (keep_alive=0), second is warmup (num_predict).
    assert any(b.get("keep_alive") == 0 for _, b in calls)
    assert any(b.get("options", {}).get("num_predict") == 1 for _, b in calls)


def test_reload_does_not_attempt_modelfile_patch(monkeypatch):
    """Sprint 6 chain removed: gpu_pct < 95 must NOT spawn ``ollama show``
    or ``ollama create`` subprocesses."""
    monkeypatch.setattr(fix_mod, "http_post_json", lambda *a, **k: (200, '{"r":""}'))
    monkeypatch.setattr(fix_mod, "_gpu_pct", lambda model: 40)
    monkeypatch.setattr(fix_mod.time, "sleep", lambda *a, **k: None)
    # If the dead chain were still alive it would touch subprocess.
    assert not hasattr(fix_mod, "subprocess"), (
        "fixes.model must no longer import subprocess (Sprint 7 cleanup)"
    )
    assert fix_reload_model("cont-local:latest") is False


# ── --version flag ──────────────────────────────────────────────────


def test_version_flag_prints_version_and_exits_zero(capsys, monkeypatch):
    from contdoctor import __version__
    from contdoctor.cli import main

    monkeypatch.setattr("sys.argv", ["contdoctor", "--version"])
    with pytest.raises(SystemExit) as exc:
        main()
    assert exc.value.code == 0
    captured = capsys.readouterr()
    assert __version__ in (captured.out + captured.err)


# ── No-progress block ────────────────────────────────────────────────


def test_no_progress_summary_includes_command_block(monkeypatch, capsys):
    """When the loop bails on no-progress, the stderr summary lists
    each unfixable check and the per-check command block."""
    from types import SimpleNamespace

    from contdoctor import cli as cli_mod
    from contdoctor.core.result import CheckResult

    stuck = [
        CheckResult(
            name="Ollama versiyon",
            status="warn",
            message="v0.20.3 — GPU regression",
            fix_label="dummy",
            fix_action=lambda: False,
        ),
        CheckResult(
            name="Network izolasyonu",
            status="ok",
            message="external host yok",
        ),
    ]
    monkeypatch.setattr(cli_mod, "run_checks", lambda *a, **k: stuck)
    args = SimpleNamespace(model="m", verbose=False)
    final, code = cli_mod._recursive_fix_loop(args, ["x"], [], stuck)
    assert code == 2
    err = capsys.readouterr().err
    assert "fix edilemeyen sorun" in err
    assert "Ollama versiyon" in err
    # network isolated → bank-mode wheel-transfer hint
    assert "wheel/binary transferi gerekli" in err
