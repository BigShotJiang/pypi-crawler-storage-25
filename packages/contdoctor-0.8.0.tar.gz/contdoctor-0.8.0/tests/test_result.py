"""CheckResult dataclass behaviour and JSON serialisation."""

import json

from contdoctor.core.report import results_to_json
from contdoctor.core.result import CheckResult


def test_check_result_defaults():
    r = CheckResult(name="x", status="ok", message="all good")
    assert r.fix_label is None
    assert r.fix_action is None
    assert r.details == {}
    assert r.diagnosis is None
    assert r.matched_symptoms == []


def test_check_result_symbol_property():
    assert "OK" in CheckResult("a", "ok", "").symbol or "✓" in CheckResult("a", "ok", "").symbol
    assert "!" in CheckResult("a", "warn", "").symbol
    assert "X" in CheckResult("a", "fail", "").symbol or "✗" in CheckResult("a", "fail", "").symbol


def test_check_result_json_serialisation_round_trip():
    r = CheckResult(
        name="t", status="warn", message="hi",
        details={"k": 1, "nested": {"a": 2}},
        diagnosis="Some diagnosis",
        matched_symptoms=["s1"],
    )
    payload = results_to_json([r])
    text = json.dumps(payload)
    back = json.loads(text)
    assert back[0]["name"] == "t"
    assert back[0]["status"] == "warn"
    assert back[0]["details"] == {"k": 1, "nested": {"a": 2}}
    assert back[0]["diagnosis"] == "Some diagnosis"
    assert back[0]["matched_symptoms"] == ["s1"]
    # Required fields are present even when null:
    for key in ("name", "status", "message", "details", "diagnosis", "matched_symptoms"):
        assert key in back[0]


def test_check_result_independent_details_per_instance():
    a = CheckResult("a", "ok", "")
    b = CheckResult("b", "ok", "")
    a.details["x"] = 1
    assert b.details == {}, "details must not be shared between instances"
