"""Sprint 8 (revised) — lessons subsystem + --lessons flag."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from contdoctor.lessons import LessonsError, load_example_lessons, load_lessons


def test_example_lessons_has_at_least_5_lessons():
    lessons = load_example_lessons()
    assert len(lessons) >= 5


def test_example_lessons_severity_sort_order():
    """critical → high → medium order, ties broken by id."""
    lessons = load_example_lessons()
    severity_seq = [l.severity for l in lessons]
    rank = {"critical": 0, "high": 1, "medium": 2}
    sorted_seq = sorted(severity_seq, key=lambda s: rank[s])
    assert severity_seq == sorted_seq


def _isolate_home(monkeypatch, tmp_path):
    """Hem Path.home() hem ``~`` expanduser tmp_path'e baksın."""
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))


def test_load_lessons_invalid_yaml_returns_clear_error(tmp_path, monkeypatch):
    _isolate_home(monkeypatch, tmp_path)
    p = tmp_path / ".contdoctor" / "lessons.yaml"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(": : :\n  - bad\n")
    with pytest.raises(LessonsError):
        load_lessons()


def test_load_lessons_missing_file_raises_filenotfound(tmp_path, monkeypatch):
    _isolate_home(monkeypatch, tmp_path)
    with pytest.raises(FileNotFoundError):
        load_lessons()


def test_load_lessons_user_file_loaded_when_present(tmp_path, monkeypatch):
    _isolate_home(monkeypatch, tmp_path)
    p = tmp_path / ".contdoctor" / "lessons.yaml"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        textwrap.dedent(
            """\
            version: 1
            project: cont
            lessons:
              - id: my_custom
                severity: medium
                title: my custom title
                next_action: do this
            """
        )
    )
    lessons = load_lessons()
    assert len(lessons) == 1
    assert lessons[0].id == "my_custom"


def test_load_lessons_rejects_unknown_severity(tmp_path, monkeypatch):
    _isolate_home(monkeypatch, tmp_path)
    p = tmp_path / ".contdoctor" / "lessons.yaml"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        textwrap.dedent(
            """\
            version: 1
            lessons:
              - id: bad
                severity: catastrophic
                title: x
            """
        )
    )
    with pytest.raises(LessonsError) as e:
        load_lessons()
    assert "severity" in str(e.value)


def test_cli_lessons_flag_lists_severity_sorted_and_exits_zero(
    capsys, monkeypatch, tmp_path
):
    """--lessons → exit 0; CRITICAL → HIGH → MEDIUM order."""
    _isolate_home(monkeypatch, tmp_path)
    monkeypatch.setattr("sys.argv", ["contdoctor", "--lessons"])
    from contdoctor.cli import main

    with pytest.raises(SystemExit) as exc:
        main()
    assert exc.value.code == 0
    out = capsys.readouterr().out
    crit = out.find("[CRITICAL]")
    high = out.find("[HIGH]")
    medium = out.find("[MEDIUM]")
    assert 0 <= crit < high < medium


def test_cli_lessons_missing_file_falls_back_to_example(
    capsys, monkeypatch, tmp_path
):
    """User dosyası yoksa example göster + cp hint'i."""
    _isolate_home(monkeypatch, tmp_path)
    monkeypatch.setattr("sys.argv", ["contdoctor", "--lessons"])
    from contdoctor.cli import main

    with pytest.raises(SystemExit):
        main()
    out = capsys.readouterr().out
    assert "yok — paket içi example" in out
    assert "cp " in out  # hint'te kopyalama komutu
