"""Sprint 9.2 — snapshot-based restore + realistic workload."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from contdoctor.checks.ollama_snapshot_match import check_ollama_proc_matches_snapshot
from contdoctor.checks.workload import (
    EVAL_TPS_OK_THRESHOLD,
    EVAL_TPS_WARN_THRESHOLD,
    WORKLOAD_NUM_PREDICT,
    check_realistic_workload,
)
from contdoctor.fixes import snapshot_restore as restore_mod
from contdoctor.fixes.snapshot_restore import fix_restore_ollama_from_snapshot
from contdoctor.snapshot import build_snapshot, save_snapshot
from contdoctor.snapshot.fingerprint import EnvironmentFingerprint
from contdoctor.snapshot.schema import (
    GpuSnapshot,
    OllamaSnapshot,
    Snapshot,
    WorkloadBaseline,
)


def _isolate(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))


def _snapshot_with_binary(tmp_path: Path, *, hostname="prod-host", is_wsl=False):
    binary = tmp_path / "ollama-full" / "bin" / "ollama"
    binary.parent.mkdir(parents=True, exist_ok=True)
    binary.write_text("#!/bin/sh\n")
    return Snapshot(
        version=1,
        created_at="t",
        created_by_contdoctor="x",
        label="working",
        fingerprint=EnvironmentFingerprint(
            hostname=hostname, user="u", os_release="O", kernel="k",
            is_wsl=is_wsl, cuda_driver="552.74", gpu_name="RTX 5000",
            cwd_mount="/", python_executable="/p",
        ),
        role_hint="prod-shared" if not is_wsl else "dev",
        ollama=OllamaSnapshot(
            binary_path=str(binary),
            version="0.13.5",
            size_bytes=42,
            is_running=True,
            detected_via="pgrep+/proc",
        ),
        gpu=GpuSnapshot(driver_version="552.74"),
        env={
            "OLLAMA_NUM_GPU": "999",
            "LD_LIBRARY_PATH": "/opt/cuda",
            "OLLAMA_RUNNERS_DIR": "/opt/runners",
        },
    )


# ── fix_restore_ollama_from_snapshot ────────────────────────────────


def test_restore_starts_ollama_with_snapshot_binary_and_env(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    snap = _snapshot_with_binary(tmp_path, hostname="prod-host", is_wsl=False)
    p = save_snapshot(snap, str(tmp_path / "snap.yaml"))

    monkeypatch.setattr(
        restore_mod, "compute_fingerprint",
        lambda: snap.fingerprint,
    )
    monkeypatch.setattr(restore_mod, "pgrep", lambda pat: [])
    captured = {}

    def fake_popen(cmd, env=None, **kwargs):
        captured["cmd"] = cmd
        captured["env"] = env
        return MagicMock()

    monkeypatch.setattr(restore_mod.subprocess, "Popen", fake_popen)
    monkeypatch.setattr(restore_mod.time, "sleep", lambda s: None)
    monkeypatch.setattr(restore_mod, "port_open", lambda h, p_: True)

    rc = fix_restore_ollama_from_snapshot(str(p))
    assert rc is True
    assert captured["cmd"][0] == snap.ollama.binary_path
    assert captured["cmd"][1] == "serve"
    assert captured["env"]["OLLAMA_NUM_GPU"] == "999"
    assert captured["env"]["LD_LIBRARY_PATH"] == "/opt/cuda"
    assert captured["env"]["OLLAMA_RUNNERS_DIR"] == "/opt/runners"


def test_restore_rejected_when_hostname_differs(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    snap = _snapshot_with_binary(tmp_path, hostname="dev-laptop", is_wsl=True)
    p = save_snapshot(snap, str(tmp_path / "snap.yaml"))

    # Current makinada hostname "prod-host" görünsün.
    monkeypatch.setattr(
        restore_mod, "compute_fingerprint",
        lambda: EnvironmentFingerprint(
            hostname="prod-host", user="u", os_release="O", kernel="k",
            is_wsl=False, cuda_driver=None, gpu_name=None,
            cwd_mount="/", python_executable="/p",
        ),
    )
    runs = []
    monkeypatch.setattr(
        restore_mod.subprocess, "Popen",
        lambda *a, **k: runs.append(a) or MagicMock(),
    )
    rc = fix_restore_ollama_from_snapshot(str(p))
    assert rc is False
    assert runs == []  # subprocess çağrılmadı


def test_restore_rejected_when_wsl_mismatch(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    snap = _snapshot_with_binary(tmp_path, hostname="machine", is_wsl=True)
    p = save_snapshot(snap, str(tmp_path / "snap.yaml"))
    monkeypatch.setattr(
        restore_mod, "compute_fingerprint",
        lambda: EnvironmentFingerprint(
            hostname="machine", user="u", os_release="O", kernel="k",
            is_wsl=False,
            cuda_driver=None, gpu_name=None, cwd_mount="/", python_executable="/p",
        ),
    )
    rc = fix_restore_ollama_from_snapshot(str(p))
    assert rc is False


def test_restore_returns_false_when_snapshot_missing(tmp_path):
    rc = fix_restore_ollama_from_snapshot(str(tmp_path / "missing.yaml"))
    assert rc is False


def test_restore_returns_false_when_binary_missing(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    snap = _snapshot_with_binary(tmp_path, hostname="m", is_wsl=False)
    # Binary'i sil (snapshot'ta path var ama dosya yok)
    Path(snap.ollama.binary_path).unlink()
    p = save_snapshot(snap, str(tmp_path / "snap.yaml"))
    monkeypatch.setattr(
        restore_mod, "compute_fingerprint", lambda: snap.fingerprint
    )
    rc = fix_restore_ollama_from_snapshot(str(p))
    assert rc is False


# ── check_ollama_proc_matches_snapshot ──────────────────────────────


def test_proc_matches_snapshot_returns_warn_no_running(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    monkeypatch.setattr(
        "contdoctor.checks.ollama_snapshot_match.detect_running_ollama",
        lambda: None,
    )
    r = check_ollama_proc_matches_snapshot()
    assert r.status == "warn"
    assert r.fix_action is None


def test_proc_matches_snapshot_warn_when_no_snapshot(monkeypatch, tmp_path):
    from contdoctor.checks.ollama_proc import RunningOllama

    _isolate(monkeypatch, tmp_path)
    monkeypatch.setattr(
        "contdoctor.checks.ollama_snapshot_match.detect_running_ollama",
        lambda: RunningOllama(pid=1, binary_path="/x", env={}),
    )
    # No snapshot file
    r = check_ollama_proc_matches_snapshot()
    assert r.status == "warn"
    assert "snapshot dosyası yok" in r.message


def test_proc_matches_snapshot_ok_when_aligned(monkeypatch, tmp_path):
    from contdoctor.checks.ollama_proc import RunningOllama

    _isolate(monkeypatch, tmp_path)
    snap = _snapshot_with_binary(tmp_path, hostname="m", is_wsl=False)
    snap_path = tmp_path / ".contdoctor" / "snapshot.yaml"
    snap_path.parent.mkdir(parents=True, exist_ok=True)
    save_snapshot(snap, str(snap_path))
    # Çalışan process snapshot binary'siyle aynı + aynı kritik env'ler.
    monkeypatch.setattr(
        "contdoctor.checks.ollama_snapshot_match.detect_running_ollama",
        lambda: RunningOllama(
            pid=42,
            binary_path=snap.ollama.binary_path,
            env={
                "OLLAMA_NUM_GPU": "999",
                "LD_LIBRARY_PATH": "/opt/cuda",
                "OLLAMA_RUNNERS_DIR": "/opt/runners",
            },
        ),
    )
    r = check_ollama_proc_matches_snapshot()
    assert r.status == "ok"
    assert r.fix_action is None


def test_proc_matches_snapshot_warn_binary_mismatch_offers_restore(
    monkeypatch, tmp_path
):
    from contdoctor.checks.ollama_proc import RunningOllama

    _isolate(monkeypatch, tmp_path)
    snap = _snapshot_with_binary(tmp_path, hostname="m", is_wsl=False)
    snap_path = tmp_path / ".contdoctor" / "snapshot.yaml"
    snap_path.parent.mkdir(parents=True, exist_ok=True)
    save_snapshot(snap, str(snap_path))
    # Çalışan process FARKLI binary (sistem default).
    monkeypatch.setattr(
        "contdoctor.checks.ollama_snapshot_match.detect_running_ollama",
        lambda: RunningOllama(
            pid=42,
            binary_path="/usr/local/bin/ollama",
            env={"OLLAMA_NUM_GPU": "999"},
        ),
    )
    r = check_ollama_proc_matches_snapshot()
    assert r.status == "warn"
    assert r.fix_action is fix_restore_ollama_from_snapshot
    mismatch_fields = " ".join(r.details.get("mismatches", []))
    assert "binary" in mismatch_fields


def test_proc_matches_snapshot_warn_env_mismatch_offers_restore(
    monkeypatch, tmp_path
):
    from contdoctor.checks.ollama_proc import RunningOllama

    _isolate(monkeypatch, tmp_path)
    snap = _snapshot_with_binary(tmp_path, hostname="m", is_wsl=False)
    snap_path = tmp_path / ".contdoctor" / "snapshot.yaml"
    snap_path.parent.mkdir(parents=True, exist_ok=True)
    save_snapshot(snap, str(snap_path))
    # Aynı binary ama LD_LIBRARY_PATH eksik.
    monkeypatch.setattr(
        "contdoctor.checks.ollama_snapshot_match.detect_running_ollama",
        lambda: RunningOllama(
            pid=42,
            binary_path=snap.ollama.binary_path,
            env={"OLLAMA_NUM_GPU": "999"},  # LD_LIBRARY_PATH yok
        ),
    )
    r = check_ollama_proc_matches_snapshot()
    assert r.status == "warn"
    assert r.fix_action is fix_restore_ollama_from_snapshot
    mismatches = r.details.get("mismatches", [])
    assert any("LD_LIBRARY_PATH" in m for m in mismatches)


# ── check_realistic_workload ────────────────────────────────────────


def _mock_workload_response(monkeypatch, *, eval_count, eval_duration_ns,
                             prompt_eval_count=10, prompt_eval_duration_ns=int(1e7)):
    body = json.dumps({
        "response": "ok",
        "eval_count": eval_count,
        "eval_duration": eval_duration_ns,
        "prompt_eval_count": prompt_eval_count,
        "prompt_eval_duration": prompt_eval_duration_ns,
    })
    monkeypatch.setattr(
        "contdoctor.checks.workload.http_post_json",
        lambda *a, **k: (200, body),
    )
    monkeypatch.setattr("contdoctor.checks.workload.time.monotonic", lambda: 0)


def test_workload_ok_when_eval_tps_high(monkeypatch):
    """eval_tps=87 → ok."""
    # 87 tok/s → eval_count=87 in 1e9 ns
    _mock_workload_response(monkeypatch, eval_count=87, eval_duration_ns=int(1e9))
    r = check_realistic_workload("cont-local:latest")
    assert r.status == "ok"
    assert r.details["eval_tokens_per_sec"] >= EVAL_TPS_OK_THRESHOLD


def test_workload_warn_when_eval_tps_partial(monkeypatch):
    """eval_tps=20 → warn (partial GPU)."""
    _mock_workload_response(monkeypatch, eval_count=20, eval_duration_ns=int(1e9))
    r = check_realistic_workload("cont-local:latest")
    assert r.status == "warn"
    assert "kısmi" in r.message


def test_workload_fail_when_eval_tps_cpu(monkeypatch):
    """eval_tps=5 → fail (CPU inference, Cont 90s timeout'a düşer)."""
    _mock_workload_response(monkeypatch, eval_count=5, eval_duration_ns=int(1e9))
    r = check_realistic_workload("cont-local:latest")
    assert r.status == "fail"
    assert "CPU inference" in r.message


def test_workload_fail_on_http_failure(monkeypatch):
    monkeypatch.setattr(
        "contdoctor.checks.workload.http_post_json",
        lambda *a, **k: (None, "connection refused"),
    )
    r = check_realistic_workload("cont-local:latest")
    assert r.status == "fail"
    assert "connection refused" in r.message


def test_workload_fail_when_eval_metrics_missing(monkeypatch):
    """eval_count=0 → GPU durumu belirsiz, fail."""
    _mock_workload_response(monkeypatch, eval_count=0, eval_duration_ns=0)
    r = check_realistic_workload("cont-local:latest")
    assert r.status == "fail"
    assert "GPU durumu belirsiz" in r.message


def test_workload_check_uses_realistic_prompt_size(monkeypatch):
    """Prompt boyutu Cont'un sistem prompt'una yakın (~1KB+)."""
    captured = {}

    def fake_post(path, body, timeout):
        captured["body"] = body
        return 200, json.dumps({
            "response": "ok",
            "eval_count": 87, "eval_duration": int(1e9),
            "prompt_eval_count": 10, "prompt_eval_duration": int(1e7),
        })

    monkeypatch.setattr("contdoctor.checks.workload.http_post_json", fake_post)
    monkeypatch.setattr("contdoctor.checks.workload.time.monotonic", lambda: 0)
    check_realistic_workload("cont-local:latest")
    prompt = captured["body"]["prompt"]
    # ~1KB+ prompt (Cont sistem prompt'u kadar olmasa da kısa endpoint
    # ping'inden çok daha gerçekçi).
    assert len(prompt) > 1000, f"Prompt çok kısa: {len(prompt)}"
    assert captured["body"]["options"]["num_predict"] == WORKLOAD_NUM_PREDICT


# ── workload baseline in build_snapshot ────────────────────────────


def test_build_snapshot_records_workload_baseline_when_model_given(
    monkeypatch, tmp_path
):
    _isolate(monkeypatch, tmp_path)
    from contdoctor.snapshot import builder as builder_mod

    # Stub out everything else.
    monkeypatch.setattr(builder_mod, "_run", lambda *a, **k: (1, "", ""))
    monkeypatch.setattr(builder_mod, "http_get", lambda *a, **k: (None, ""))
    monkeypatch.setattr(builder_mod.shutil, "which", lambda name: None)
    # detect_running_ollama returns a fake running so is_running=True
    from contdoctor.checks.ollama_proc import RunningOllama

    fake_binary = tmp_path / "fake-ollama"
    fake_binary.write_bytes(b"x")
    monkeypatch.setattr(
        builder_mod, "detect_running_ollama",
        lambda: RunningOllama(
            pid=1, binary_path=str(fake_binary),
            env={"OLLAMA_NUM_GPU": "999"},
            detected_via="pgrep+/proc",
        ),
    )
    # Mock realistic workload to return eval_tps=87 (ok).
    _mock_workload_response(monkeypatch, eval_count=87, eval_duration_ns=int(1e9))

    snap = build_snapshot(label="L", workload_model="cont-local:latest")
    assert snap.ollama.workload_baseline is not None
    assert snap.ollama.workload_baseline.eval_tokens_per_sec >= EVAL_TPS_OK_THRESHOLD


def test_build_snapshot_no_baseline_when_model_omitted(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    from contdoctor.snapshot import builder as builder_mod

    monkeypatch.setattr(builder_mod, "_run", lambda *a, **k: (1, "", ""))
    monkeypatch.setattr(builder_mod, "http_get", lambda *a, **k: (None, ""))
    monkeypatch.setattr(builder_mod.shutil, "which", lambda name: None)
    monkeypatch.setattr(builder_mod, "detect_running_ollama", lambda: None)

    snap = build_snapshot(label="L")  # workload_model parametresi yok
    assert snap.ollama.workload_baseline is None


def test_workload_baseline_yaml_round_trip(monkeypatch, tmp_path):
    """Snapshot YAML round-trip workload_baseline'ı koruyor."""
    _isolate(monkeypatch, tmp_path)
    from contdoctor.snapshot import load_snapshot

    snap = _snapshot_with_binary(tmp_path, hostname="m", is_wsl=False)
    snap.ollama.workload_baseline = WorkloadBaseline(
        eval_tokens_per_sec=87.3,
        prompt_eval_tokens_per_sec=1240.5,
        measured_at="2026-04-28T10:00:00+03:00",
    )
    p = save_snapshot(snap, str(tmp_path / "rt.yaml"))
    loaded = load_snapshot(p)
    assert loaded.ollama.workload_baseline is not None
    assert loaded.ollama.workload_baseline.eval_tokens_per_sec == 87.3
    assert loaded.ollama.workload_baseline.measured_at.startswith("2026-04-28")


# ── check_ollama_process snapshot-aware ─────────────────────────────


def test_ollama_process_down_with_snapshot_offers_restore(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    snap_path = tmp_path / ".contdoctor" / "snapshot.yaml"
    snap_path.parent.mkdir(parents=True, exist_ok=True)
    snap_path.write_text("version: 1\nollama: {}\nfingerprint: {hostname: m}\n")
    from contdoctor.checks import ollama as ollama_check

    monkeypatch.setattr(ollama_check, "pgrep", lambda pat: [])
    monkeypatch.setattr(ollama_check, "port_open", lambda h, p, **kw: False)
    monkeypatch.setattr(ollama_check, "detect_running_ollama", lambda: None)
    r = ollama_check.check_ollama_process()
    assert r.status == "fail"
    assert r.fix_action is fix_restore_ollama_from_snapshot
    assert "snapshot'tan restore" in r.message


def test_ollama_process_down_without_snapshot_falls_back_to_default(
    monkeypatch, tmp_path
):
    _isolate(monkeypatch, tmp_path)
    from contdoctor.checks import ollama as ollama_check
    from contdoctor.fixes.ollama import fix_start_ollama

    monkeypatch.setattr(ollama_check, "pgrep", lambda pat: [])
    monkeypatch.setattr(ollama_check, "port_open", lambda h, p, **kw: False)
    monkeypatch.setattr(ollama_check, "detect_running_ollama", lambda: None)
    r = ollama_check.check_ollama_process()
    assert r.status == "fail"
    assert r.fix_action is fix_start_ollama
