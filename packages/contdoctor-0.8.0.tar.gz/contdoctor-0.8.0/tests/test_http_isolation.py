"""HTTP wrapper must only ever build URLs against ``OLLAMA_HOST``."""

import pytest

from contdoctor.core import http as http_mod


def test_path_must_start_with_slash():
    with pytest.raises(ValueError):
        http_mod._build_url("api/tags")


def test_built_url_uses_ollama_host_prefix():
    url = http_mod._build_url("/api/tags")
    assert url.startswith(http_mod.OLLAMA_HOST)
    assert url.endswith("/api/tags")


def test_http_get_returns_none_status_for_unreachable_host(monkeypatch):
    """Point the wrapper at a closed port; it must return (None, err) without raising."""
    monkeypatch.setattr(http_mod, "OLLAMA_HOST", "http://127.0.0.1:1")
    status, body = http_mod.http_get("/api/tags", timeout=1)
    assert status is None
    assert isinstance(body, str)


def test_http_post_json_returns_none_status_for_unreachable_host(monkeypatch):
    monkeypatch.setattr(http_mod, "OLLAMA_HOST", "http://127.0.0.1:1")
    status, body = http_mod.http_post_json("/api/generate", {"x": 1}, timeout=1)
    assert status is None
    assert isinstance(body, str)


def test_external_url_cannot_be_smuggled_via_path():
    """A path argument cannot escape the OLLAMA_HOST prefix."""
    url = http_mod._build_url("/foo")
    # urllib will treat the result as <OLLAMA_HOST>/foo, no protocol injection possible.
    assert "://" not in url[len(http_mod.OLLAMA_HOST):]
