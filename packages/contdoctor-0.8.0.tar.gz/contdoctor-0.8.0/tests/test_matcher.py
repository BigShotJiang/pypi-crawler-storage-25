"""Matcher behaviour: equals / regex / no-match / additive (Python fix priority)."""

from contdoctor.core.result import CheckResult
from contdoctor.knowledge import load_symptoms_from_string
from contdoctor.knowledge.matcher import apply_symptoms


def _result(**kw):
    base = {"name": "ollama_ver", "status": "warn", "message": "v0.20.3", "details": {"version": "0.20.3"}}
    base.update(kw)
    return CheckResult(**base)


def test_equals_match_injects_diagnosis_and_fix(valid_yaml):
    syms = load_symptoms_from_string(valid_yaml)
    r = _result()
    out = apply_symptoms(r, syms, "ollama_ver")
    assert "ollama_0_20_3_gpu_regression" in out.matched_symptoms
    assert out.diagnosis is not None and "0.20.3" in out.diagnosis
    assert out.fix_label == "OLLAMA_NUM_GPU=999 + restart"
    assert callable(out.fix_action)


def test_no_match_when_value_differs(valid_yaml):
    syms = load_symptoms_from_string(valid_yaml)
    r = _result(message="v0.21.0", details={"version": "0.21.0"})
    out = apply_symptoms(r, syms, "ollama_ver")
    assert out.matched_symptoms == []
    assert out.diagnosis is None
    assert out.fix_label is None
    assert out.fix_action is None


def test_python_fix_takes_priority_over_yaml(valid_yaml):
    """Additive: an existing Python-side fix must NOT be overwritten by YAML."""
    syms = load_symptoms_from_string(valid_yaml)
    sentinel = lambda: True
    r = _result(fix_label="python-side-fix", fix_action=sentinel)
    out = apply_symptoms(r, syms, "ollama_ver")
    assert "ollama_0_20_3_gpu_regression" in out.matched_symptoms  # still recorded
    assert out.fix_label == "python-side-fix"
    assert out.fix_action is sentinel


def test_existing_diagnosis_not_overwritten(valid_yaml):
    syms = load_symptoms_from_string(valid_yaml)
    r = _result(diagnosis="pre-existing diagnosis")
    out = apply_symptoms(r, syms, "ollama_ver")
    assert out.diagnosis == "pre-existing diagnosis"
    assert "ollama_0_20_3_gpu_regression" in out.matched_symptoms


def test_regex_match():
    yaml_text = """\
version: 1
symptoms:
  - id: regex_rule
    category: test
    severity: warn
    triggered_by:
      check: ollama_ver
      match:
        field: message
        op: matches_regex
        value: "^v0\\\\.[12][0-9]"
    diagnosis: matched
"""
    syms = load_symptoms_from_string(yaml_text)
    r = _result(message="v0.20.3")
    out = apply_symptoms(r, syms, "ollama_ver")
    assert "regex_rule" in out.matched_symptoms


def test_contains_substring_against_list_field():
    """The poison rule looks at details.poison which is a list of strings."""
    yaml_text = """\
version: 1
symptoms:
  - id: env_poison
    category: env_var
    severity: warn
    triggered_by:
      check: ollama_env
      match:
        field: details.poison
        op: contains_substring
        value: "OLLAMA_LLM_LIBRARY"
    diagnosis: poison
"""
    syms = load_symptoms_from_string(yaml_text)
    r = CheckResult(
        name="ollama_env", status="warn", message="bad",
        details={"poison": ["OLLAMA_LLM_LIBRARY=cuda (GPU discovery'yi bozar)"]},
    )
    out = apply_symptoms(r, syms, "ollama_env")
    assert "env_poison" in out.matched_symptoms


def test_missing_field_only_matches_is_absent():
    yaml_text = """\
version: 1
symptoms:
  - id: requires_absent
    category: test
    severity: warn
    triggered_by:
      check: ollama_ver
      match:
        field: details.does_not_exist
        op: is_absent
    diagnosis: yep
  - id: requires_equals
    category: test
    severity: warn
    triggered_by:
      check: ollama_ver
      match:
        field: details.does_not_exist
        op: equals
        value: anything
    diagnosis: nope
"""
    syms = load_symptoms_from_string(yaml_text)
    r = _result()
    out = apply_symptoms(r, syms, "ollama_ver")
    assert "requires_absent" in out.matched_symptoms
    assert "requires_equals" not in out.matched_symptoms


def test_check_key_filter():
    """A symptom triggered_by 'ollama_ver' must not match results for another check."""
    yaml_text = """\
version: 1
symptoms:
  - id: ver_rule
    category: test
    severity: warn
    triggered_by:
      check: ollama_ver
      match:
        field: status
        op: equals
        value: "warn"
    diagnosis: ver
"""
    syms = load_symptoms_from_string(yaml_text)
    r = CheckResult(name="other", status="warn", message="x")
    out = apply_symptoms(r, syms, "gpu")
    assert out.matched_symptoms == []
