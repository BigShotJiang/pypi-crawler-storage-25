"""Sprint 9.1 hotfix — custom runtime hard-protect (entegrasyon).

Sprint 9'un unit testleri "fix_action=None" iddiasında pass etti ama
prod'da `[Ollama versiyon] OLLAMA_NUM_GPU=999...` fix yine basıldı.
Sebep: YAML matcher symptom (``ollama_0_20_3_gpu_regression``)
``check_ollama_version`` çıktısına fix_set_ollama_num_gpu enjekte
ediyordu.

Bu modül **end-to-end** test eder: ``run_checks`` üzerinden gidip
``CheckResult.fix_action``'ları kontrol eder. Mock sadece dış sınırlarda
(http, subprocess, /proc).
"""

from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from contdoctor.checks import ollama as ollama_check
from contdoctor.checks import ollama_proc as ollama_proc_mod
from contdoctor.checks import model as model_check
from contdoctor.checks.ollama_proc import RunningOllama
from contdoctor.core.runner import CHECKS, run_checks
from contdoctor.knowledge import default_symptoms


# ── 1) symptoms.yaml temizlendi ─────────────────────────────────────


def test_default_symptoms_no_fix_set_ollama_num_gpu_action():
    """Sprint 9.1 critical: knowledge matcher hiçbir symptom üzerinden
    fix_set_ollama_num_gpu enjekte etmemeli."""
    syms = default_symptoms()
    actions = {s.fix.action for s in syms if s.fix.action}
    assert "fix_set_ollama_num_gpu" not in actions


# ── 2) Entegrasyon: custom runtime'da hiçbir fix_action yok ────────


def _wire_custom_running(monkeypatch, version="0.20.3"):
    """Sertan'ın prod senaryosu: custom binary (~/ollama-full) +
    LD_LIBRARY_PATH/OLLAMA_RUNNERS_DIR + 0.20.3 system PATH'i."""
    fake_running = RunningOllama(
        pid=22625,
        binary_path="/home/sertan/ollama-full/bin/ollama",
        cmdline=["/home/sertan/ollama-full/bin/ollama", "serve"],
        env={
            "OLLAMA_NUM_GPU": "999",
            "LD_LIBRARY_PATH": "/home/sertan/ollama-full/lib/ollama",
            "OLLAMA_RUNNERS_DIR": "/home/sertan/ollama-full/lib/ollama",
        },
        detected_via="pgrep+/proc",
    )
    monkeypatch.setattr(ollama_check, "detect_running_ollama", lambda: fake_running)
    monkeypatch.setattr(model_check, "detect_running_ollama", lambda: fake_running)
    monkeypatch.setattr(ollama_proc_mod, "pgrep", lambda pat: [22625])
    # check_ollama_process direkt `pgrep`'i ollama.py'a import etmiş.
    monkeypatch.setattr(ollama_check, "pgrep", lambda pat: [22625])
    # PATH'teki binary 0.20.3, ama check_ollama_version çalışan binary'i
    # kullanacak — yine 0.20.3 versiyonu varsayalım.
    monkeypatch.setattr(
        "contdoctor.core.proc.run",
        lambda cmd, timeout=5: (
            (0, f"ollama version is {version}\n", "")
            if cmd[-1:] == ["--version"]
            else (1, "", "")
        ),
    )
    monkeypatch.setattr(
        ollama_check.shutil, "which",
        lambda name: "/usr/local/bin/ollama" if name == "ollama" else None,
    )


def test_custom_runtime_no_fix_action_in_any_result(monkeypatch):
    """End-to-end run_checks: custom runtime + KNOWN_BAD ollama version
    olsa bile HİÇBİR result.fix_action != None değil."""
    _wire_custom_running(monkeypatch, version="0.20.3")

    # /api/ps + /api/tags ile model %0 GPU senaryosu (Sertan'ın çıktısı).
    def fake_http_get(path, timeout=3):
        if path == "/api/tags":
            return 200, json.dumps(
                {"models": [{"name": "cont-local:latest", "digest": "abc", "size": 100}]}
            )
        if path == "/api/ps":
            return 200, json.dumps(
                {"models": [{"name": "cont-local:latest", "size": 100, "size_vram": 0}]}
            )
        return None, ""

    monkeypatch.setattr("contdoctor.core.http.http_get", fake_http_get)
    monkeypatch.setattr(
        "contdoctor.checks.ollama.http_get", fake_http_get
    )
    monkeypatch.setattr("contdoctor.checks.model.http_get", fake_http_get)
    # port_open: custom runtime'da port açık varsay.
    monkeypatch.setattr(ollama_check, "port_open", lambda h, p, **kw: True)

    args = SimpleNamespace(model="cont-local:latest", verbose=False, snapshot_path=None)
    # Yalnız ollama + model katmanı — diğer check'lerin gerçek sistemi
    # tetiklemesi engellensin.
    target_keys = [
        "ollama_bin", "ollama_ver", "ollama_proc", "ollama_env",
        "model_loaded",
    ]
    results = run_checks(args, target_keys, symptoms=default_symptoms())

    # KRITIK: hiçbir fix_action set olmamalı.
    fixable = [(r.name, r.fix_label) for r in results if r.fix_action is not None]
    assert fixable == [], (
        f"Custom runtime'da fix önerildi: {fixable}"
    )

    # Custom runtime detail'ı en az bir result'ta True olmalı.
    custom_seen = [
        r.name for r in results
        if isinstance(r.details, dict) and r.details.get("custom_runtime")
    ]
    assert custom_seen, "Hiçbir result custom_runtime detail'ı taşımıyor"


def test_custom_runtime_model_loaded_warn_not_fail(monkeypatch):
    """Sprint 9.1: model gpu_pct<95 + custom runtime → warn (fail değil),
    fix_action=None."""
    _wire_custom_running(monkeypatch)
    monkeypatch.setattr(
        "contdoctor.checks.model.http_get",
        lambda path, timeout=3: (200, json.dumps(
            {"models": [{"name": "cont-local:latest", "size": 100, "size_vram": 0}]}
        )),
    )
    r = model_check.check_model_loaded("cont-local:latest")
    assert r.status == "warn"
    assert r.fix_action is None
    assert r.details["custom_runtime"] is True


def test_custom_runtime_ollama_proc_zombie_no_restart(monkeypatch):
    """Sprint 9.1: çalışan process custom + port kapalı → warn ama
    fix_restart_ollama önerilmez."""
    _wire_custom_running(monkeypatch)
    monkeypatch.setattr(ollama_check, "port_open", lambda h, p, **kw: False)
    r = ollama_check.check_ollama_process()
    assert r.status == "warn"
    assert r.fix_action is None
    assert r.details["custom_runtime"] is True


# ── 3) Non-custom: geriye uyumluluk ────────────────────────────────


def test_non_custom_environment_keeps_existing_fixes(monkeypatch):
    """Custom runtime YOK: process /usr/local/bin/ollama + minimal env →
    Sprint 1 fix'leri çalışır (geriye uyumluluk)."""
    fake_running = RunningOllama(
        pid=1234,
        binary_path="/usr/local/bin/ollama",
        cmdline=["/usr/local/bin/ollama", "serve"],
        env={},  # Boş env → OLLAMA_NUM_GPU set değil → fixable=True branch
        detected_via="pgrep+/proc",
    )
    monkeypatch.setattr(ollama_check, "detect_running_ollama", lambda: fake_running)
    # Shell de boş.
    for var in ("OLLAMA_NUM_GPU", "OLLAMA_LLM_LIBRARY", "CUDA_VISIBLE_DEVICES"):
        monkeypatch.delenv(var, raising=False)
    r = ollama_check.check_ollama_env()
    assert r.status == "warn"
    assert r.fix_action is not None  # Geriye uyumlu — non-custom branch çalışıyor
    assert "OLLAMA_NUM_GPU=999" in (r.fix_label or "")


# ── 4) Reporter: custom runtime aktif mesajı ────────────────────────


def test_reporter_shows_custom_runtime_message_when_no_fixes(capsys):
    """Tüm fixable boş + en az bir result custom_runtime detail'ı varsa
    'Custom runtime aktif — doctor müdahale etmiyor' mesajı basılır."""
    from contdoctor.core.report import print_human_report
    from contdoctor.core.result import CheckResult

    results = [
        CheckResult(
            name="Env değişkenleri",
            status="warn",
            message="custom-launched setup",
            details={"custom_runtime": True},
        ),
    ]
    print_human_report(results)
    out = capsys.readouterr().out
    assert "Custom runtime aktif" in out
    assert "doctor müdahale etmiyor" in out
    assert "Otomatik düzeltilebilir" not in out


def test_reporter_no_custom_message_when_fixes_exist(capsys):
    """Custom runtime detail'ı olsa bile bir fix_action varsa "Otomatik
    düzeltilebilir" başlığı basılır, custom mesajı değil."""
    from contdoctor.core.report import print_human_report
    from contdoctor.core.result import CheckResult

    results = [
        CheckResult(
            name="X", status="fail", message="m",
            fix_label="dummy", fix_action=lambda: True,
            details={"custom_runtime": True},
        ),
    ]
    print_human_report(results)
    out = capsys.readouterr().out
    assert "Otomatik düzeltilebilir" in out
    assert "Custom runtime aktif" not in out
