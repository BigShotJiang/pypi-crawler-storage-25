"""Sprint 7.1 — log evidence priority + default-path exemption + env propagation
+ status-aware no-progress detection."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from contdoctor.checks import ollama_runners as runners_check
from contdoctor.checks.ollama_runners import REQUIRED_LIBS, check_ollama_gpu_runners
from contdoctor.fixes import runners as runners_fix


def _populate_libs(d: Path, libs):
    d.mkdir(parents=True, exist_ok=True)
    for lib in libs:
        (d / lib).write_bytes(b"")


# ── Bug 1a — default Ollama path muafiyeti ──────────────────────────


def test_runners_default_path_no_env_returns_ok(tmp_path, monkeypatch):
    """Library Ollama default path'inde + env set yok → ok (env zorunlu değil)."""
    monkeypatch.delenv("OLLAMA_LLM_LIBRARY", raising=False)
    monkeypatch.delenv("OLLAMA_RUNNERS_DIR", raising=False)
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))

    fake_default = tmp_path / "fake-usr-local-cuda"
    _populate_libs(fake_default, REQUIRED_LIBS)

    monkeypatch.setattr(runners_check, "_default_paths", lambda: [fake_default])
    monkeypatch.setattr(
        runners_check, "_OLLAMA_DEFAULT_PATHS", frozenset({str(fake_default)})
    )
    # Sprint 7.2: log evidence helper'ı artık model-aware; default-path
    # branch zaten önceliklendiği için log'a ihtiyaç yok.
    monkeypatch.setattr(runners_check, "_model_specific_full_gpu", lambda m: False)

    r = check_ollama_gpu_runners()
    assert r.status == "ok", r.message
    assert "default path" in r.message
    assert r.details["evidence"] == "default ollama search path"


# ── Bug 1b — log full-GPU evidence overrides env mismatch ───────────


def test_runners_log_full_gpu_overrides_env_check(tmp_path, monkeypatch):
    """Custom path + env wrong but log says target model 'offloaded 49/49' → ok."""
    monkeypatch.setenv("OLLAMA_LLM_LIBRARY", str(tmp_path / "wrong"))
    monkeypatch.delenv("OLLAMA_RUNNERS_DIR", raising=False)
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))

    real_dir = tmp_path / "ollama-full" / "lib" / "ollama" / "cuda_v12"
    _populate_libs(real_dir, REQUIRED_LIBS)
    monkeypatch.setattr(runners_check, "_default_paths", lambda: [real_dir])
    monkeypatch.setattr(runners_check, "_OLLAMA_DEFAULT_PATHS", frozenset())
    # Sprint 7.2: log helper now takes target_model — return True only
    # when the target model matches.
    monkeypatch.setattr(
        runners_check, "_model_specific_full_gpu",
        lambda m: m == "cont-local:latest",
    )

    r = check_ollama_gpu_runners(target_model="cont-local:latest")
    assert r.status == "ok", r.message
    assert "cont-local:latest için full GPU doğruluyor" in r.message
    assert r.details["evidence"] == "log: cont-local:latest full GPU"


def test_runners_log_partial_does_not_override(tmp_path, monkeypatch):
    """Log helper False döndüğünde mevcut env warn'ı kalır."""
    monkeypatch.setenv("OLLAMA_LLM_LIBRARY", str(tmp_path / "wrong"))
    monkeypatch.delenv("OLLAMA_RUNNERS_DIR", raising=False)
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    real_dir = tmp_path / "ollama-full" / "lib" / "ollama" / "cuda_v12"
    _populate_libs(real_dir, REQUIRED_LIBS)
    monkeypatch.setattr(runners_check, "_default_paths", lambda: [real_dir])
    monkeypatch.setattr(runners_check, "_OLLAMA_DEFAULT_PATHS", frozenset())
    monkeypatch.setattr(runners_check, "_model_specific_full_gpu", lambda m: False)

    r = check_ollama_gpu_runners(target_model="cont-local:latest")
    assert r.status == "warn"
    assert "non-default path" in r.message


def test_model_specific_full_gpu_target_required(monkeypatch):
    """Sprint 7.2: target_model=None ise log evidence override devre dışı."""
    # Even with a fake "always True" model_full_gpu_in_log, no target_model
    # → no override.
    monkeypatch.setattr(
        "contdoctor.checks.ollama_runners.model_full_gpu_in_log",
        lambda m: True,
    )
    assert runners_check._model_specific_full_gpu(None) is False
    assert runners_check._model_specific_full_gpu("") is False
    assert runners_check._model_specific_full_gpu("cont-local:latest") is True


# ── Bug 2 — fix updates os.environ so the rescan sees it ────────────


def test_fix_set_runners_updates_os_environ(monkeypatch, tmp_path):
    """fix_set_ollama_runners_path must mutate os.environ so the next
    scan inside the same process sees the new value."""
    monkeypatch.delenv("OLLAMA_LLM_LIBRARY", raising=False)
    monkeypatch.delenv("OLLAMA_NUM_GPU", raising=False)

    monkeypatch.setattr(runners_fix, "pgrep", lambda pat: [])
    monkeypatch.setattr(runners_fix.subprocess, "Popen", lambda *a, **k: object())
    monkeypatch.setattr(runners_fix.time, "sleep", lambda s: None)
    port_calls = iter([True])
    monkeypatch.setattr(
        runners_fix, "port_open", lambda host, port: next(port_calls, True)
    )

    library_path = tmp_path / "lib" / "ollama" / "cuda_v12"
    rc = runners_fix.fix_set_ollama_runners_path(library_path)
    assert rc is True
    import os

    assert os.environ["OLLAMA_LLM_LIBRARY"] == str(library_path)
    assert os.environ.get("OLLAMA_NUM_GPU") == "999"


def test_fix_set_runners_popen_inherits_env(monkeypatch, tmp_path):
    """Popen artık env=None ile çağrılıyor → os.environ inherit ediliyor."""
    captured = {}

    def fake_popen(cmd, **kwargs):
        captured["cmd"] = cmd
        captured["kwargs"] = kwargs
        return object()

    monkeypatch.setattr(runners_fix, "pgrep", lambda pat: [])
    monkeypatch.setattr(runners_fix.subprocess, "Popen", fake_popen)
    monkeypatch.setattr(runners_fix.time, "sleep", lambda s: None)
    monkeypatch.setattr(runners_fix, "port_open", lambda h, p: True)

    runners_fix.fix_set_ollama_runners_path(tmp_path / "lib")
    # Sprint 7.1: explicit env= geçilmiyor, default None → child inherits parent.
    assert "env" not in captured["kwargs"]


# ── Bug 3 — recursive loop status_signature comparison ──────────────


def test_recursive_loop_continues_when_status_changes_same_fix_set(monkeypatch, capsys):
    """Aynı fixable_set ama status değişti → no-progress tetiklenmemeli."""
    from contdoctor import cli as cli_mod
    from contdoctor.core.result import CheckResult

    # Turn 1 (initial): "X" warn, fixable.
    # Turn 2 (after fix): "X" still fixable but status flipped to fail
    #                     → loop must continue (status changed).
    # Turn 3 (after second fix): "X" ok → fixed-point.
    sequence = iter([
        [CheckResult("X", "fail", "still bad", fix_label="f", fix_action=lambda: True)],
        [CheckResult("X", "ok", "fine")],
    ])
    monkeypatch.setattr(cli_mod, "run_checks", lambda *a, **k: next(sequence))

    initial = [CheckResult("X", "warn", "first", fix_label="f", fix_action=lambda: True)]
    args = SimpleNamespace(model="m", verbose=False)
    final, code = cli_mod._recursive_fix_loop(args, ["X"], [], initial)
    assert code == 0
    assert any(r.status == "ok" for r in final)


def test_recursive_loop_breaks_when_signature_unchanged(monkeypatch, capsys):
    """Hem fix_set hem status aynı kaldıysa no-progress tetiklenir."""
    from contdoctor import cli as cli_mod
    from contdoctor.core.result import CheckResult

    stuck = [CheckResult("X", "fail", "boom", fix_label="f", fix_action=lambda: False)]
    monkeypatch.setattr(cli_mod, "run_checks", lambda *a, **k: stuck)
    args = SimpleNamespace(model="m", verbose=False)
    final, code = cli_mod._recursive_fix_loop(args, ["X"], [], stuck)
    assert code == 2
    err = capsys.readouterr().err
    assert "fix edilemeyen sorun" in err
