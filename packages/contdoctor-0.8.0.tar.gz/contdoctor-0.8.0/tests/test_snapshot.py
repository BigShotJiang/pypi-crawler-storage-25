"""Sprint 8 — environment snapshot subsystem (build/save/load + drift check)."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import MagicMock

import pytest
import yaml

from contdoctor.checks.snapshot_drift import (
    DEFAULT_SNAPSHOT_PATH,
    check_environment_drift,
)
from contdoctor.snapshot import (
    SnapshotError,
    build_snapshot,
    load_snapshot,
    save_snapshot,
)
from contdoctor.snapshot import builder as builder_mod
from contdoctor.snapshot.schema import (
    GpuSnapshot,
    ModelSnapshot,
    OllamaSnapshot,
    RunnerLibSnapshot,
    Snapshot,
)


def _isolate_environment(monkeypatch, tmp_path):
    """Builder'ın gerçek sistem state'ini görmesini engelle."""
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    # Empty interesting env vars by default.
    for v in builder_mod.INTERESTING_ENV_VARS:
        monkeypatch.delenv(v, raising=False)


def _stub_builder(monkeypatch):
    """Replace expensive subprocess + http calls in builder with mocks
    so build_snapshot() tests don't depend on the real system."""
    monkeypatch.setattr(
        builder_mod, "_run",
        lambda cmd, timeout=5: (1, "", ""),  # default: command not found
    )
    monkeypatch.setattr(
        builder_mod, "http_get",
        lambda path, timeout=3: (None, "no api"),
    )
    monkeypatch.setattr(builder_mod.shutil, "which", lambda name: None)


# ── build_snapshot ──────────────────────────────────────────────────


def test_build_snapshot_collects_ollama_version(monkeypatch, tmp_path):
    _isolate_environment(monkeypatch, tmp_path)
    binary = tmp_path / "fake-ollama"
    binary.write_bytes(b"x" * 42)
    monkeypatch.setattr(builder_mod.shutil, "which", lambda name: str(binary) if name == "ollama" else None)
    # No running process — builder falls back to PATH binary.
    monkeypatch.setattr(
        "contdoctor.snapshot.builder.detect_running_ollama", lambda: None
    )
    monkeypatch.setattr(
        builder_mod, "_run",
        lambda cmd, timeout=5: (
            (0, "ollama version is 0.13.5\n", "")
            if cmd[-1:] == ["--version"]
            else (1, "", "")
        ),
    )
    monkeypatch.setattr(builder_mod, "http_get", lambda *a, **k: (None, ""))

    snap = build_snapshot()
    assert snap.ollama.version == "0.13.5"
    assert snap.ollama.binary_path == str(binary)
    assert snap.ollama.size_bytes == 42


def test_build_snapshot_collects_models(monkeypatch, tmp_path):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    monkeypatch.setattr(
        builder_mod, "http_get",
        lambda path, timeout=3: (
            200,
            '{"models": [{"name": "cont-local:latest", "digest": "sha256:abc", "size": 1234}]}',
        ) if path == "/api/tags" else (None, ""),
    )
    snap = build_snapshot()
    assert len(snap.models) == 1
    assert snap.models[0].name == "cont-local:latest"
    assert snap.models[0].digest == "sha256:abc"
    assert snap.models[0].size == 1234


def test_build_snapshot_label_optional(monkeypatch, tmp_path):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    snap_no = build_snapshot()
    snap_lbl = build_snapshot(label="9 Nisan working")
    assert snap_no.label is None
    assert snap_lbl.label == "9 Nisan working"


def test_build_snapshot_records_interesting_env(monkeypatch, tmp_path):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    monkeypatch.setenv("OLLAMA_NUM_GPU", "999")
    snap = build_snapshot()
    assert snap.env["OLLAMA_NUM_GPU"] == "999"
    # Unset interesting var → empty string, not absent.
    assert "OLLAMA_LLM_LIBRARY" in snap.env


# ── save / load YAML round-trip ─────────────────────────────────────


def test_save_snapshot_writes_yaml(tmp_path, monkeypatch):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    snap = build_snapshot(label="t1")
    out = save_snapshot(snap, str(tmp_path / "out.yaml"))
    assert out.is_file()
    text = out.read_text()
    parsed = yaml.safe_load(text)
    assert parsed["version"] == 1
    assert parsed["label"] == "t1"
    assert "ollama" in parsed
    assert "gpu" in parsed
    assert "models" in parsed
    assert "env" in parsed
    assert "runner_libraries" in parsed


def test_save_snapshot_creates_parent_dirs(tmp_path, monkeypatch):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    snap = build_snapshot()
    nested = tmp_path / "a" / "b" / "snap.yaml"
    save_snapshot(snap, str(nested))
    assert nested.is_file()


def test_load_snapshot_round_trip(tmp_path, monkeypatch):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    snap = build_snapshot(label="round")
    p = save_snapshot(snap, str(tmp_path / "rt.yaml"))
    loaded = load_snapshot(p)
    assert loaded.label == "round"
    assert loaded.version == 1


def test_load_snapshot_rejects_wrong_version(tmp_path):
    p = tmp_path / "bad.yaml"
    p.write_text("version: 99\nollama: {}\ngpu: {}\nmodels: []\nenv: {}\nrunner_libraries: []\n")
    with pytest.raises(SnapshotError) as e:
        load_snapshot(p)
    assert "unsupported snapshot version" in str(e.value)


# ── check_environment_drift ─────────────────────────────────────────


def test_drift_no_snapshot_returns_warn(tmp_path):
    p = tmp_path / "missing.yaml"
    r = check_environment_drift(str(p))
    assert r.status == "warn"
    assert "Snapshot dosyası yok" in r.message
    assert r.fix_action is None
    assert "contdoctor --save-snapshot" in r.details["hint"]


def test_drift_invalid_yaml_returns_warn(tmp_path):
    p = tmp_path / "bad.yaml"
    p.write_text(": : not yaml :\n  - bad\n")
    r = check_environment_drift(str(p))
    assert r.status == "warn"
    assert r.fix_action is None


def test_drift_no_changes_returns_ok(tmp_path, monkeypatch):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    snap = build_snapshot(label="L")
    p = save_snapshot(snap, str(tmp_path / "s.yaml"))
    r = check_environment_drift(str(p))
    assert r.status == "ok"
    assert "uyumlu" in r.message
    assert r.fix_action is None


def test_drift_ollama_version_mismatch_returns_fail(tmp_path, monkeypatch):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    # Snapshot reflects old ollama 0.13.5
    snap = Snapshot(
        version=1, created_at="t", created_by_contdoctor="x", label="9 Nisan",
        ollama=OllamaSnapshot(binary_path="/usr/local/bin/ollama", version="0.13.5", size_bytes=100),
    )
    p = save_snapshot(snap, str(tmp_path / "s.yaml"))
    # Current sees 0.20.3
    monkeypatch.setattr(
        builder_mod, "_run",
        lambda cmd, timeout=5: (
            (0, "ollama version is 0.20.3\n", "")
            if cmd[:2] == ["ollama", "--version"]
            else (1, "", "")
        ),
    )
    r = check_environment_drift(str(p))
    assert r.status == "fail"
    assert "ollama.version" in r.message
    fields = [d["field"] for d in r.details["drifts"]]
    assert "ollama.version" in fields
    assert r.fix_action is None


def test_drift_binary_size_mismatch_returns_warn(tmp_path, monkeypatch):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    snap = Snapshot(
        version=1, created_at="t", created_by_contdoctor="x", label=None,
        ollama=OllamaSnapshot(binary_path="b", version="0.20.3", size_bytes=100),
    )
    p = save_snapshot(snap, str(tmp_path / "s.yaml"))
    binary = tmp_path / "fake-ollama"
    binary.write_bytes(b"x" * 200)
    monkeypatch.setattr(builder_mod.shutil, "which", lambda name: str(binary) if name == "ollama" else None)
    monkeypatch.setattr(
        "contdoctor.snapshot.builder.detect_running_ollama", lambda: None
    )
    monkeypatch.setattr(
        builder_mod, "_run",
        lambda cmd, timeout=5: (
            (0, "ollama version is 0.20.3\n", "")
            if cmd[-1:] == ["--version"]
            else (1, "", "")
        ),
    )
    r = check_environment_drift(str(p))
    assert r.status == "warn"
    fields = [d["field"] for d in r.details["drifts"]]
    assert "ollama.size_bytes" in fields


def test_drift_model_digest_mismatch_returns_warn_per_model(tmp_path, monkeypatch):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    snap = Snapshot(
        version=1, created_at="t", created_by_contdoctor="x", label=None,
        ollama=OllamaSnapshot(binary_path="", version="", size_bytes=0),
        models=[ModelSnapshot(name="cont-local:latest", digest="sha256:OLD", size=1)],
    )
    p = save_snapshot(snap, str(tmp_path / "s.yaml"))
    monkeypatch.setattr(
        builder_mod, "http_get",
        lambda path, timeout=3: (
            200,
            '{"models": [{"name": "cont-local:latest", "digest": "sha256:NEW", "size": 1}]}',
        ) if path == "/api/tags" else (None, ""),
    )
    r = check_environment_drift(str(p))
    assert r.status == "warn"
    drift_fields = [d["field"] for d in r.details["drifts"]]
    assert "models[cont-local:latest].digest" in drift_fields


def test_drift_check_has_no_fix_action(tmp_path):
    """Sertan kuralı: doctor environment değiştirmesin → fix_action her
    durumda None."""
    # No snapshot
    r1 = check_environment_drift(str(tmp_path / "x.yaml"))
    assert r1.fix_action is None
    # Bad YAML
    p = tmp_path / "bad.yaml"
    p.write_text(": : :")
    r2 = check_environment_drift(str(p))
    assert r2.fix_action is None


def test_drift_check_does_not_modify_environment(tmp_path, monkeypatch):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    snap = Snapshot(
        version=1, created_at="t", created_by_contdoctor="x", label=None,
        ollama=OllamaSnapshot(binary_path="", version="0.20.3", size_bytes=0),
    )
    p = save_snapshot(snap, str(tmp_path / "s.yaml"))

    pre_env = dict(os.environ)
    monkeypatch.setattr(
        builder_mod, "_run",
        lambda cmd, timeout=5: (
            (0, "ollama version is 0.13.5\n", "")
            if cmd[:2] == ["ollama", "--version"]
            else (1, "", "")
        ),
    )
    check_environment_drift(str(p))
    post_env = dict(os.environ)
    # No env mutation.
    assert pre_env == post_env


# ── CLI --save-snapshot ─────────────────────────────────────────────


def test_cli_save_snapshot_writes_file_and_exits_zero(monkeypatch, tmp_path):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    out = tmp_path / "snap.yaml"
    monkeypatch.setattr("sys.argv", ["contdoctor", "--save-snapshot", str(out)])

    from contdoctor.cli import main
    with pytest.raises(SystemExit) as exc:
        main()
    assert exc.value.code == 0
    assert out.is_file()
    parsed = yaml.safe_load(out.read_text())
    assert parsed["version"] == 1


def test_cli_save_snapshot_label_persisted(monkeypatch, tmp_path):
    _isolate_environment(monkeypatch, tmp_path)
    _stub_builder(monkeypatch)
    out = tmp_path / "snap.yaml"
    monkeypatch.setattr(
        "sys.argv",
        ["contdoctor", "--save-snapshot", str(out), "--snapshot-label", "9 Nisan working"],
    )
    from contdoctor.cli import main
    with pytest.raises(SystemExit):
        main()
    parsed = yaml.safe_load(out.read_text())
    assert parsed["label"] == "9 Nisan working"


# ── runner integration ─────────────────────────────────────────────


def test_runner_includes_snapshot_drift_check_last():
    from contdoctor.core.runner import CHECKS

    assert "snapshot_drift" in CHECKS
    keys = list(CHECKS.keys())
    assert keys[-1] == "snapshot_drift", "snapshot_drift should run last"


def test_default_snapshot_path_constant():
    """Banka path leak yok: default '~' altında, mutlak prod path
    hardcode edilmemiş."""
    assert DEFAULT_SNAPSHOT_PATH.startswith("~"), DEFAULT_SNAPSHOT_PATH
    assert "/mnt/" not in DEFAULT_SNAPSHOT_PATH
