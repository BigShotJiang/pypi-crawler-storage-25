"""Read or update keys in an AWS Secrets Manager secret.

Usage:
    # Read a key
    pysae-ai-tools env secret get <secret-id> <key>

    # Read all keys
    pysae-ai-tools env secret get <secret-id>

    # Write key=value pairs
    pysae-ai-tools env secret set <secret-id> <key1>=<value1> [key2=$ENV_VAR] ...

Values prefixed with $ are resolved from environment variables.
"""

import json
import os
import subprocess
import sys
from typing import Annotated

import typer

app = typer.Typer(help="Read or write secrets in AWS Secrets Manager")


def _fetch_secret(secret_id: str) -> dict[str, str]:
    """Fetch and parse a secret from AWS Secrets Manager."""
    result = subprocess.run(
        [
            "aws",
            "secretsmanager",
            "get-secret-value",
            "--secret-id",
            secret_id,
            "--query",
            "SecretString",
            "--output",
            "text",
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=True,
    )
    return dict(json.loads(result.stdout))


@app.command()
def get(
    secret_id: Annotated[str, typer.Argument(help="AWS Secrets Manager secret ID (e.g. pysae/dev/secrets)")],
    key: Annotated[str | None, typer.Argument(help="Key to read (omit to list all keys)")] = None,
    show_value: Annotated[
        bool,
        typer.Option("--show-value", help="Print the actual value (default: masked)"),
    ] = False,
) -> None:
    """Read a key (or list all keys) from an AWS secret."""
    try:
        secrets = _fetch_secret(secret_id)
    except FileNotFoundError:
        print("FAILED: aws CLI not found — install it with `pysae-ai-tools tools install aws`", file=sys.stderr)
        raise typer.Exit(code=1) from None
    except subprocess.CalledProcessError as e:
        detail = (e.stderr or "").strip().splitlines()
        last = detail[-1] if detail else f"exit code {e.returncode}"
        print(f"FAILED: aws cli error — {last}", file=sys.stderr)
        raise typer.Exit(code=1) from None
    except json.JSONDecodeError:
        print("FAILED: could not parse secret as JSON", file=sys.stderr)
        raise typer.Exit(code=1) from None

    if key:
        if key not in secrets:
            print(f"FAILED: key '{key}' not found in {secret_id}", file=sys.stderr)
            print(f"Available keys: {', '.join(sorted(secrets))}", file=sys.stderr)
            raise typer.Exit(code=1)
        if show_value:
            print(secrets[key])
        else:
            value = secrets[key]
            masked = value[:4] + "****" + value[-4:] if len(value) > 12 else "****"
            print(f"{key}={masked}")
    else:
        # List all keys with masked values
        for k in sorted(secrets):
            if show_value:
                print(f"{k}={secrets[k]}")
            else:
                v = secrets[k]
                masked = v[:4] + "****" + v[-4:] if len(v) > 12 else "****"
                print(f"{k}={masked}")


@app.command(name="set")
def set_secret(
    secret_id: Annotated[str, typer.Argument(help="AWS Secrets Manager secret ID")],
    pairs: Annotated[list[str], typer.Argument(help="key=value (or key=$ENV_VAR) pairs")],
) -> None:
    """Update keys in an AWS secret."""
    if not pairs:
        print("FAILED: at least one key=value pair is required", file=sys.stderr)
        raise typer.Exit(code=1)

    updates: dict[str, str] = {}
    for pair in pairs:
        if "=" not in pair:
            print(f"FAILED: invalid pair '{pair}', expected key=value", file=sys.stderr)
            raise typer.Exit(code=1)
        key, value = pair.split("=", 1)
        if value.startswith("$"):
            env_var = value[1:]
            resolved = os.environ.get(env_var, "")
            if not resolved:
                print(f"FAILED: env var {env_var} is not set or empty", file=sys.stderr)
                raise typer.Exit(code=1)
            updates[key] = resolved
        else:
            updates[key] = value

    tmp = "/tmp/aws_secret_payload.json"
    try:
        secrets = _fetch_secret(secret_id)
        secrets.update(updates)

        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(secrets, f)

        subprocess.run(
            [
                "aws",
                "secretsmanager",
                "update-secret",
                "--secret-id",
                secret_id,
                "--secret-string",
                f"file://{tmp}",
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=True,
        )
        print("OK")
    except FileNotFoundError:
        print("FAILED: aws CLI not found — install it with `pysae-ai-tools tools install aws`", file=sys.stderr)
        raise typer.Exit(code=1) from None
    except subprocess.CalledProcessError as e:
        detail = (e.stderr or "").strip().splitlines()
        last = detail[-1] if detail else f"exit code {e.returncode}"
        print(f"FAILED: aws cli error — {last}", file=sys.stderr)
        raise typer.Exit(code=1) from None
    except json.JSONDecodeError:
        print("FAILED: could not parse current secret as JSON", file=sys.stderr)
        raise typer.Exit(code=1) from None
    finally:
        try:
            os.remove(tmp)
        except FileNotFoundError:
            pass
