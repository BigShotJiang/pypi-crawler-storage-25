---
name: env-resolve
description: >
  Resolve environment variables from MCP config or AWS Secrets Manager, then
  export them into the current shell. Use when the user says /env-resolve,
  'résous cette variable', 'exporte DD_API_KEY', 'charge les variables',
  'resolve env', 'load env vars', 'exporte mes secrets', or a downstream
  skill needs a var (ex. `DD_API_KEY`, `POSTMAN_API_KEY`, `MONGO_URI_DEV`,
  `MONGO_URI_PROD`) resolved before running.
argument-hint: "<VAR> [VAR2 ...] | --all  [--json|--set|--shell posix|powershell|cmd]"
allowed-tools:
  - Bash
---

Thin gateway over `pysae-ai-tools env resolve`. The CLI handles the resolution chain (shell → AWS Secrets Manager → MCP config), shell-format detection, and exit codes.

## Required tools

- `aws`

Run `pysae-ai-tools tools require <tools>` before starting; if it exits non-zero, abort and report the install command from stderr to the user.

## Usage

```bash
# Export into the current shell
eval "$(pysae-ai-tools env resolve --set DD_API_KEY DD_APP_KEY)" || exit 1
```

For full options: `pysae-ai-tools env resolve --help`.

$ARGUMENTS
