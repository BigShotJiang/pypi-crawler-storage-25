"""Install or update the MongoDB Atlas CLI.

The Atlas CLI is published by MongoDB as a single ``atlas`` binary. Releases
live on GitHub at ``mongodb/mongodb-atlas-cli`` under tags shaped like
``atlascli/v1.54.0`` (the repo also ships a sibling ``mongocli`` binary that
has its own tag stream). We pull the matching tar/zip from the release page
and drop ``atlas`` (or ``atlas.exe``) on the user's PATH.

Native package managers are skipped on purpose:

- The brew formula lives in the third-party ``mongodb/brew`` tap, which would
  force every macOS user to add the tap before install.
- Past experience with ``MongoDB.*`` winget packages (see ``mongo_tools.py``)
  shows silent no-op installs. The archive route gives predictable behaviour
  on every OS.

After the binary install succeeds, the ``dev`` and ``prod`` profiles are
written to ``atlas``'s config file via ``atlas config set`` using API keys
resolved through :mod:`pysae_ai_tools.env.resolve` (env → AWS Secrets
Manager via ``ai-tools/<env>/secrets`` → MCP config). Other profiles in the
config are preserved — only ``pysae-dev`` and ``pysae-prod`` are upserted.
Missing keys are reported but never fail the install. Users select a context
at runtime with ``atlas --profile pysae-dev …`` (or ``atlas -P pysae-prod …``).
"""

import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

import httpx
import tomlkit
import typer

from .common import binary, platform
from .common.base import ArchiveBinaryTool, InstallReport, ToolState

# GitHub uses a per-product tag stream ``atlascli/v<version>`` to share the
# repo with ``mongocli``. ``releases/latest`` returns whichever stream was
# tagged last — so we instead list ``releases`` and pick the newest tag
# matching the ``atlascli/`` prefix.
RELEASES_API = "https://api.github.com/repos/mongodb/mongodb-atlas-cli/releases"
TAG_PREFIX = "atlascli/v"

# Pysae environments materialised as Atlas CLI profiles. Mirrors the
# argocd dev/prod context split — same source secrets, same selection
# semantics at runtime (``atlas -P pysae-dev`` vs ``atlas -P pysae-prod``).
#
# The ``pysae-`` prefix avoids a regression in atlascli v1.54.0 where
# a profile literally named ``dev`` (case-insensitive) silently routes
# auth to a different — internal — MongoDB endpoint and returns 401 on
# every real API call, even though the keys are perfectly valid. Any
# other profile name with the same keys works. We picked the
# unambiguous ``pysae-<env>`` form so the bug stays buried regardless
# of how atlas chooses to interpret short names in future versions.
PROFILES: tuple[tuple[str, str], ...] = (
    ("pysae-dev", "DEV"),  # (profile name written to atlascli/config.toml, env-var suffix)
    ("pysae-prod", "PROD"),
)


def _key_var(env_suffix: str, kind: str) -> str:
    """Resolver-side name for an Atlas API key, e.g. ``MONGODB_ATLAS_PUBLIC_API_KEY_DEV``."""
    return f"MONGODB_ATLAS_{kind.upper()}_API_KEY_{env_suffix}"


def _project_id_var(env_suffix: str) -> str:
    """Resolver-side name for an Atlas project id, e.g. ``MONGODB_ATLAS_PROJECT_ID_DEV``."""
    return f"MONGODB_ATLAS_PROJECT_ID_{env_suffix}"


class AtlasCliTool(ArchiveBinaryTool):
    name = "atlas"
    binary_name = "atlas"
    cli_help = "Install/update the MongoDB Atlas CLI and authenticate dev/prod profiles"

    def fetch_latest_version(self) -> str:
        r = httpx.get(RELEASES_API, timeout=10.0, follow_redirects=True, params={"per_page": 30})
        r.raise_for_status()
        data = r.json()
        if not isinstance(data, list):
            return ""
        for release in data:
            tag = release.get("tag_name", "") if isinstance(release, dict) else ""
            if isinstance(tag, str) and tag.startswith(TAG_PREFIX) and not release.get("prerelease"):
                return tag[len(TAG_PREFIX) :]
        return ""

    def archive_info(self, version: str, plat: platform.Platform) -> tuple[str, str | None]:
        ver = version.lstrip("v")
        arch = "arm64" if plat.arch.value == "arm64" else "x86_64"
        # Tag in URL must keep its ``/`` percent-encoded.
        tag = f"atlascli%2Fv{ver}"

        if plat.is_linux:
            asset = f"mongodb-atlas-cli_{ver}_linux_{arch}.tar.gz"
            member = "bin/atlas"
        elif plat.is_macos:
            asset = f"mongodb-atlas-cli_{ver}_macos_{arch}.zip"
            member = "bin/atlas"
        elif plat.is_windows:
            # MongoDB ships an .msi too, but the .zip drops the binary
            # straight into ~/.local/bin via the shared archive path —
            # no admin prompt, no PATH surgery.
            asset = f"mongodb-atlas-cli_{ver}_windows_{arch}.zip"
            member = "bin/atlas.exe"
        else:
            raise ValueError(f"unsupported OS: {plat.os}")

        url = f"https://github.com/mongodb/mongodb-atlas-cli/releases/download/{tag}/{asset}"
        return url, member

    # ------------------------------------------------------------------
    # Profile authentication (post-install)
    # ------------------------------------------------------------------

    @staticmethod
    def _config_path() -> Path:
        """Return the Atlas CLI's TOML config path for the current OS.

        Mirrors Go's ``os.UserConfigDir()`` semantics, which is what the
        atlas binary uses internally:

        - Linux: ``$XDG_CONFIG_HOME/atlascli/config.toml`` (default
          ``~/.config``)
        - macOS: ``~/Library/Application Support/atlascli/config.toml``
        - Windows: ``%AppData%\\atlascli\\config.toml``
        """
        if sys.platform == "darwin":
            base = Path.home() / "Library" / "Application Support"
        elif sys.platform == "win32":
            appdata = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
            base = Path(appdata)
        else:
            xdg = os.environ.get("XDG_CONFIG_HOME")
            base = Path(xdg) if xdg else Path.home() / ".config"
        return base / "atlascli" / "config.toml"

    def _upsert_profiles(self, profile_data: dict[str, dict[str, str]]) -> None:
        """Upsert ``profile_data`` (``{name: {prop: value}}``) into config.toml.

        Each inner dict carries whatever properties resolved this round —
        typically ``public_api_key`` / ``private_api_key`` (always) and
        ``project_id`` (when AWS Secrets Manager has it). Properties not
        present in the dict are left untouched, so partial rotations of a
        single property don't wipe the rest of the profile.

        Other profiles and the top-level ``version`` marker are preserved.
        Writes with restricted permissions — the file holds secrets.

        Why we write the TOML ourselves rather than calling ``atlas config
        set``: the binary's ``config set`` command reports "Updated
        property '<key>'" but does not persist anything to disk in
        ``atlascli v1.54.0`` (likely a regression — read it back and the
        keys are gone). Writing the TOML directly is what we know works:
        ``atlas auth whoami -P <profile>`` succeeds against a profile we
        seeded by hand.
        """
        path = self._config_path()
        path.parent.mkdir(parents=True, exist_ok=True)

        doc: tomlkit.TOMLDocument
        if path.exists():
            try:
                doc = tomlkit.parse(path.read_text(encoding="utf-8"))
            except tomlkit.exceptions.TOMLKitError:
                doc = tomlkit.document()
        else:
            doc = tomlkit.document()
        if "version" not in doc:
            doc["version"] = 2

        for profile, props in profile_data.items():
            section = doc.get(profile)
            if not isinstance(section, dict):
                section = tomlkit.table()
                doc[profile] = section
            for key, value in props.items():
                section[key] = value

        # 0600 — keys are secrets; mirror the argocd config approach.
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(tomlkit.dumps(doc))

    def _authenticate_profiles(self) -> dict[str, str]:
        """Upsert each Atlas profile with keys + project id resolved from env / AWS Secrets.

        Keys are required (missing → profile skipped). The project id is
        a "nice to have": when resolved, it's written so that
        project-scoped commands (``atlas clusters list``, etc.) work
        without ``--projectId``; when unavailable the profile is still
        written with just the keys.
        """
        from ..env.resolve import try_auto_resolve

        results: dict[str, str] = {}
        to_write: dict[str, dict[str, str]] = {}

        for profile, env_suffix in PROFILES:
            pub_var = _key_var(env_suffix, "public")
            priv_var = _key_var(env_suffix, "private")
            project_var = _project_id_var(env_suffix)
            pub = os.environ.get(pub_var) or try_auto_resolve(pub_var) or ""
            priv = os.environ.get(priv_var) or try_auto_resolve(priv_var) or ""
            project_id = os.environ.get(project_var) or try_auto_resolve(project_var) or ""
            if not pub or not priv:
                missing = [v for v, val in [(pub_var, pub), (priv_var, priv)] if not val]
                results[profile] = f"skipped — {', '.join(missing)} unavailable"
                continue
            props: dict[str, str] = {"public_api_key": pub, "private_api_key": priv}
            if project_id:
                props["project_id"] = project_id
            to_write[profile] = props

        if to_write:
            try:
                self._upsert_profiles(to_write)
            except OSError as exc:
                for profile in to_write:
                    results[profile] = f"failed — {exc}"
                return results
            for profile in to_write:
                ok, err = self._profile_status(profile)
                results[profile] = "ok" if ok else f"failed — {err}"
        return results

    def _profile_status(self, profile: str) -> tuple[bool, str]:
        """Return ``(authenticated, error)`` for ``atlas --profile <name>``."""
        if not binary.which(self.binary_name):
            return False, "binary not installed"
        try:
            r = subprocess.run(
                [self.binary_name, "auth", "whoami", "--profile", profile],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False,
                timeout=10,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            return False, f"atlas auth whoami failed: {exc}"
        if r.returncode != 0:
            stderr = (r.stderr or r.stdout or "").strip().splitlines()
            return False, stderr[-1] if stderr else f"exit code {r.returncode}"
        return True, (r.stdout + r.stderr).strip()

    def do_install(self) -> InstallReport:
        # When the only reason we're being re-run is unauthenticated profiles
        # (``needs_reconfigure_profiles`` flag), skip the binary download —
        # re-pulling the tarball adds latency without changing anything.
        binary_current = False
        installed_version = ""
        if binary.which(self.binary_name):
            installed_version = binary.get_version(self.binary_name, version_arg=self.version_arg) or ""
            try:
                latest = self.fetch_latest_version().lstrip("v")
            except Exception:  # noqa: BLE001
                latest = ""
            if installed_version and (not latest or not binary.needs_update(installed_version, latest)):
                binary_current = True

        if binary_current:
            report = InstallReport(version=installed_version, method="already up-to-date")
        else:
            report = super().do_install()
            if report.error:
                return report

        auth = self._authenticate_profiles()
        if auth:
            report.extra["auth"] = auth
        return report

    # ------------------------------------------------------------------
    # State / display
    # ------------------------------------------------------------------

    def _profile_props(self, profile: str) -> dict[str, str]:
        """Return the property keys present in ``config.toml`` for ``profile``."""
        path = self._config_path()
        if not path.exists():
            return {}
        try:
            doc = tomlkit.parse(path.read_text(encoding="utf-8"))
        except tomlkit.exceptions.TOMLKitError:
            return {}
        section = doc.get(profile)
        if not isinstance(section, dict):
            return {}
        return {k: str(v) for k, v in section.items() if isinstance(v, str)}

    def get_state(self) -> ToolState:
        state = super().get_state()
        profiles: dict[str, dict[str, Any]] = {}
        any_unauthenticated = False
        any_incomplete = False
        for profile, _env_suffix in PROFILES:
            if state.needs_install:
                profiles[profile] = {"ok": False, "error": "binary not installed", "message": ""}
                continue
            ok, msg = self._profile_status(profile)
            entry: dict[str, Any] = {"ok": ok, "error": "" if ok else msg, "message": msg if ok else ""}
            if ok and "project_id" not in self._profile_props(profile):
                # Auth works but the profile would force users to type
                # ``--projectId`` for every project-scoped command — flag
                # so ``tools install`` re-runs and writes the id if AWS
                # Secrets Manager has it.
                entry["missing_project_id"] = True
                any_incomplete = True
            profiles[profile] = entry
            if not ok:
                any_unauthenticated = True
        state.extra["profiles"] = profiles
        if not state.needs_install:
            # ``auth_ok`` drives the ⚠ icon in ``tools status``;
            # ``needs_reconfigure_profiles`` makes ``tools install`` re-run
            # the auth step (matched by ``_state_needs_work``'s
            # ``needs_reconfigure*`` prefix check).
            state.extra["auth_ok"] = not any_unauthenticated
            if any_unauthenticated:
                state.extra["auth_message"] = "one or more Atlas profiles need authentication"
                state.extra["needs_reconfigure_profiles"] = True
            elif any_incomplete:
                state.extra["needs_reconfigure_profiles"] = True
        return state

    def extract_identity(self, state: dict[str, Any]) -> list[tuple[str, str | None]]:
        lines: list[tuple[str, str | None]] = []
        profiles = state.get("profiles", {})
        for name, data in profiles.items():
            if not isinstance(data, dict):
                continue
            ok = bool(data.get("ok"))
            icon = "✓" if ok else "✗"
            if ok:
                msg = str(data.get("message", ""))
                email = re.search(r"logged in as ([^\s.]+)", msg, re.IGNORECASE)
                api = re.search(r"API Key:\s*(\S+)", msg)
                identity = email.group(1) if email else (f"API key {api.group(1)}" if api else "")
                suffix = f" — {identity}" if identity else ""
            else:
                err = str(data.get("error", "")).strip()
                suffix = f" — {err}" if err else ""
            lines.append((f"{icon} {name}{suffix}", typer.colors.GREEN if ok else typer.colors.RED))
        return lines


_tool = AtlasCliTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()

if __name__ == "__main__":
    cli()
