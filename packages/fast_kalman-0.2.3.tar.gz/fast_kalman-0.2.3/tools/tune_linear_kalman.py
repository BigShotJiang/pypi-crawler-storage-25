#!/usr/bin/env python3
"""Estimate starting parameters for small linear Kalman filters.

The estimates are intentionally conservative. They are meant to produce a
reasonable first filter, not replace validation against held-out data.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path
from typing import Any


NUMBER_RE = re.compile(
    r"[-+]?(?:(?:\d+(?:\.\d*)?)|(?:\.\d+))(?:[eE][-+]?\d+)?"
)


def median(values: list[float]) -> float:
    if not values:
        return 0.0
    xs = sorted(values)
    mid = len(xs) // 2
    if len(xs) % 2:
        return xs[mid]
    return 0.5 * (xs[mid - 1] + xs[mid])


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def sample_variance(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    mu = mean(values)
    return sum((x - mu) * (x - mu) for x in values) / (len(values) - 1)


def robust_variance(values: list[float]) -> float:
    """MAD-based variance with sample variance as a fallback."""
    if len(values) < 2:
        return 0.0
    center = median(values)
    mad = median([abs(x - center) for x in values])
    sigma = 1.4826 * mad
    if sigma > 0.0 and math.isfinite(sigma):
        return sigma * sigma
    return sample_variance(values)


def difference(values: list[float], order: int = 1) -> list[float]:
    out = values[:]
    for _ in range(order):
        out = [b - a for a, b in zip(out, out[1:])]
    return out


def matrix_diagonal(values: list[float], rows: int, cols: int) -> list[float]:
    out = [0.0] * (rows * cols)
    for i, value in enumerate(values[: min(rows, cols)]):
        out[i * cols + i] = value
    return out


def identity(n: int) -> list[float]:
    return matrix_diagonal([1.0] * n, n, n)


def floor_variance(value: float, floor: float) -> float:
    if not math.isfinite(value) or value < floor:
        return floor
    return value


def parse_samples(path: Path, nz: int, comment: str) -> list[list[float]]:
    values: list[float] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if comment:
                line = line.split(comment, 1)[0]
            values.extend(float(match.group(0)) for match in NUMBER_RE.finditer(line))

    if not values:
        raise ValueError(f"{path} did not contain any numeric values")
    if len(values) % nz != 0:
        raise ValueError(
            f"found {len(values)} numeric values, which is not divisible by nz={nz}"
        )
    return [values[i : i + nz] for i in range(0, len(values), nz)]


def columns(samples: list[list[float]], nz: int) -> list[list[float]]:
    return [[row[j] for row in samples] for j in range(nz)]


def choose_model(model: str, nx: int, nz: int) -> str:
    if model != "auto":
        return model
    if nx == nz:
        return "random-walk"
    if nx == 2 * nz:
        return "constant-velocity"
    if nx == 3 * nz:
        return "constant-acceleration"
    return "generic"


def estimate_measurement_variances(
    series: list[list[float]], model: str, floor: float
) -> list[float]:
    if model == "constant-acceleration":
        order = 3
    elif model == "constant-velocity":
        order = 2
    else:
        order = 1

    variances: list[float] = []
    for values in series:
        coeff_energy = {1: 2.0, 2: 6.0, 3: 20.0}[order]
        diffed = difference(values, order)
        if len(diffed) < 2:
            diffed = difference(values, 1)
            coeff_energy = 2.0
        estimate = robust_variance(diffed) / coeff_energy if diffed else 0.0
        total = robust_variance(values)
        upper = max(total * 0.5, floor)
        variances.append(floor_variance(min(estimate, upper), floor))
    return variances


def one_dimensional_recommendation(
    values: list[float], nx: int, model: str, dt: float, floor: float
) -> dict[str, Any]:
    r = estimate_measurement_variances([values], model, floor)[0]
    signal_var = floor_variance(robust_variance(values), floor)
    x0 = values[0]

    if model == "random-walk":
        diff1 = difference(values, 1)
        q = floor_variance(robust_variance(diff1) - 2.0 * r, max(r * 0.01, floor))
        return {
            "model": "random-walk",
            "x0": [x0],
            "P_diag": [max(signal_var, r * 10.0)],
            "Q_diag": [q],
            "R_diag": [r],
            "F": [1.0],
            "H": [1.0],
            "constructor": {
                "name": "make_scalar_random_walk",
                "args": [x0, max(signal_var, r * 10.0), q, r],
            },
        }

    velocity = difference(values, 1)
    velocity = [x / dt for x in velocity]
    v0 = median(velocity[: min(8, len(velocity))]) if velocity else 0.0
    velocity_var = floor_variance(robust_variance(velocity), max(r / (dt * dt), floor))

    if model == "constant-velocity":
        second = difference(values, 2)
        accel = [x / (dt * dt) for x in second]
        accel_var = robust_variance(accel)
        measurement_accel_var = 6.0 * r / (dt**4)
        drive_var = floor_variance(accel_var - measurement_accel_var, floor)
        q_pos = floor_variance(0.25 * drive_var * (dt**4), max(r * 0.01, floor))
        q_vel = floor_variance(drive_var * (dt**2), max(velocity_var * 0.001, floor))
        return {
            "model": "constant-velocity",
            "x0": [x0, v0],
            "P_diag": [max(signal_var, r * 10.0), velocity_var],
            "Q_diag": [q_pos, q_vel],
            "R_diag": [r],
            "F": [1.0, dt, 0.0, 1.0],
            "H": [1.0, 0.0],
            "constructor": {
                "name": "make_constant_velocity_1d",
                "args": [
                    x0,
                    v0,
                    dt,
                    max(signal_var, r * 10.0),
                    velocity_var,
                    q_pos,
                    q_vel,
                    r,
                ],
            },
        }

    if model == "constant-acceleration":
        second = difference(values, 2)
        accel = [x / (dt * dt) for x in second]
        a0 = median(accel[: min(8, len(accel))]) if accel else 0.0
        accel_var = floor_variance(robust_variance(accel), floor)
        third = difference(values, 3)
        jerk = [x / (dt**3) for x in third]
        jerk_var = robust_variance(jerk)
        measurement_jerk_var = 20.0 * r / (dt**6)
        drive_var = floor_variance(jerk_var - measurement_jerk_var, floor)
        q_pos = floor_variance((drive_var * dt**6) / 36.0, max(r * 0.01, floor))
        q_vel = floor_variance(0.25 * drive_var * dt**4, max(velocity_var * 0.001, floor))
        q_acc = floor_variance(drive_var * dt**2, max(accel_var * 0.001, floor))
        return {
            "model": "constant-acceleration",
            "x0": [x0, v0, a0],
            "P_diag": [max(signal_var, r * 10.0), velocity_var, accel_var],
            "Q_diag": [q_pos, q_vel, q_acc],
            "R_diag": [r],
            "F": [1.0, dt, 0.5 * dt * dt, 0.0, 1.0, dt, 0.0, 0.0, 1.0],
            "H": [1.0, 0.0, 0.0],
            "constructor": {
                "name": "make_constant_acceleration_1d",
                "args": [
                    x0,
                    v0,
                    a0,
                    dt,
                    max(signal_var, r * 10.0),
                    velocity_var,
                    accel_var,
                    q_pos,
                    q_vel,
                    q_acc,
                    r,
                ],
            },
        }

    raise ValueError(f"model {model!r} is not a 1D convenience model")


def vector_motion_recommendation(
    samples: list[list[float]], nx: int, nz: int, model: str, dt: float, floor: float
) -> dict[str, Any]:
    series = columns(samples, nz)
    r_diag = estimate_measurement_variances(series, model, floor)
    signal_vars = [floor_variance(robust_variance(values), floor) for values in series]

    x0 = [0.0] * nx
    p_diag: list[float] = []
    q_diag: list[float] = []

    for i, values in enumerate(series):
        x0[i] = values[0]
        p_diag.append(max(signal_vars[i], r_diag[i] * 10.0))

    if model == "random-walk":
        for values, r in zip(series, r_diag):
            q = floor_variance(
                robust_variance(difference(values, 1)) - 2.0 * r,
                max(r * 0.01, floor),
            )
            q_diag.append(q)
        f = identity(nx)

    elif model == "constant-velocity":
        for i, values in enumerate(series):
            velocity = [x / dt for x in difference(values, 1)]
            v0 = median(velocity[: min(8, len(velocity))]) if velocity else 0.0
            velocity_var = floor_variance(
                robust_variance(velocity), max(r_diag[i] / (dt * dt), floor)
            )
            x0[nz + i] = v0
            p_diag.append(velocity_var)

        for i, values in enumerate(series):
            accel = [x / (dt * dt) for x in difference(values, 2)]
            accel_var = robust_variance(accel)
            measurement_accel_var = 6.0 * r_diag[i] / (dt**4)
            drive_var = floor_variance(accel_var - measurement_accel_var, floor)
            q_diag.append(floor_variance(0.25 * drive_var * (dt**4), max(r_diag[i] * 0.01, floor)))
        for i, values in enumerate(series):
            velocity = [x / dt for x in difference(values, 1)]
            velocity_var = floor_variance(robust_variance(velocity), floor)
            accel = [x / (dt * dt) for x in difference(values, 2)]
            drive_var = floor_variance(robust_variance(accel) - 6.0 * r_diag[i] / (dt**4), floor)
            q_diag.append(floor_variance(drive_var * (dt**2), max(velocity_var * 0.001, floor)))

        f = identity(nx)
        for i in range(nz):
            f[i * nx + nz + i] = dt

    elif model == "constant-acceleration":
        velocity_vars: list[float] = []
        accel_vars: list[float] = []

        for i, values in enumerate(series):
            velocity = [x / dt for x in difference(values, 1)]
            accel = [x / (dt * dt) for x in difference(values, 2)]
            v0 = median(velocity[: min(8, len(velocity))]) if velocity else 0.0
            a0 = median(accel[: min(8, len(accel))]) if accel else 0.0
            velocity_var = floor_variance(
                robust_variance(velocity), max(r_diag[i] / (dt * dt), floor)
            )
            accel_var = floor_variance(robust_variance(accel), floor)
            x0[nz + i] = v0
            x0[2 * nz + i] = a0
            velocity_vars.append(velocity_var)
            accel_vars.append(accel_var)
            p_diag.append(velocity_var)
        p_diag.extend(accel_vars)

        q_pos: list[float] = []
        q_vel: list[float] = []
        q_acc: list[float] = []
        for i, values in enumerate(series):
            jerk = [x / (dt**3) for x in difference(values, 3)]
            drive_var = floor_variance(robust_variance(jerk) - 20.0 * r_diag[i] / (dt**6), floor)
            q_pos.append(floor_variance((drive_var * dt**6) / 36.0, max(r_diag[i] * 0.01, floor)))
            q_vel.append(floor_variance(0.25 * drive_var * dt**4, max(velocity_vars[i] * 0.001, floor)))
            q_acc.append(floor_variance(drive_var * dt**2, max(accel_vars[i] * 0.001, floor)))
        q_diag = q_pos + q_vel + q_acc

        f = identity(nx)
        for i in range(nz):
            f[i * nx + nz + i] = dt
            f[i * nx + 2 * nz + i] = 0.5 * dt * dt
            f[(nz + i) * nx + 2 * nz + i] = dt

    else:
        raise ValueError(f"unsupported vector model {model!r}")

    h = [0.0] * (nz * nx)
    for i in range(nz):
        h[i * nx + i] = 1.0

    constructor = None
    if nz == 1:
        if model == "random-walk":
            constructor = {
                "name": "make_scalar_random_walk",
                "args": [x0[0], p_diag[0], q_diag[0], r_diag[0]],
            }
        elif model == "constant-velocity":
            constructor = {
                "name": "make_constant_velocity_1d",
                "args": [x0[0], x0[1], dt, p_diag[0], p_diag[1], q_diag[0], q_diag[1], r_diag[0]],
            }
        elif model == "constant-acceleration":
            constructor = {
                "name": "make_constant_acceleration_1d",
                "args": [
                    x0[0], x0[1], x0[2], dt,
                    p_diag[0], p_diag[1], p_diag[2],
                    q_diag[0], q_diag[1], q_diag[2],
                    r_diag[0],
                ],
            }

    return {
        "model": model,
        "x0": x0,
        "P_diag": p_diag,
        "Q_diag": q_diag,
        "R_diag": r_diag,
        "F": f,
        "H": h,
        "constructor": constructor,
    }


def generic_recommendation(
    samples: list[list[float]], nx: int, nz: int, dt: float, floor: float
) -> dict[str, Any]:
    del dt
    series = columns(samples, nz)
    r_diag = estimate_measurement_variances(series, "generic", floor)
    signal_vars = [floor_variance(robust_variance(values), floor) for values in series]
    diff_vars = [
        floor_variance(robust_variance(difference(values, 1)) - 2.0 * r, max(r * 0.01, floor))
        for values, r in zip(series, r_diag)
    ]

    x0 = [0.0] * nx
    for i in range(min(nx, nz)):
        x0[i] = samples[0][i]

    p_diag = [floor] * nx
    q_diag = [floor] * nx
    for i in range(nx):
        source = min(i, nz - 1)
        p_diag[i] = max(signal_vars[source], r_diag[source] * 10.0, floor)
        q_diag[i] = max(diff_vars[source], r_diag[source] * 0.01, floor)

    h = [0.0] * (nz * nx)
    for i in range(min(nx, nz)):
        h[i * nx + i] = 1.0

    return {
        "model": "generic",
        "x0": x0,
        "P_diag": p_diag,
        "Q_diag": q_diag,
        "R_diag": r_diag,
        "F": identity(nx),
        "H": h,
        "constructor": None,
    }


def estimate(
    samples: list[list[float]], nx: int, nz: int, dt: float, model: str, floor: float
) -> dict[str, Any]:
    chosen = choose_model(model, nx, nz)
    if chosen == "random-walk" and nx == nz:
        rec = vector_motion_recommendation(samples, nx, nz, chosen, dt, floor)
    elif chosen == "constant-velocity" and nx == 2 * nz:
        rec = vector_motion_recommendation(samples, nx, nz, chosen, dt, floor)
    elif chosen == "constant-acceleration" and nx == 3 * nz:
        rec = vector_motion_recommendation(samples, nx, nz, chosen, dt, floor)
    elif nz == 1 and chosen in {"random-walk", "constant-velocity", "constant-acceleration"}:
        rec = one_dimensional_recommendation([sample[0] for sample in samples], nx, chosen, dt, floor)
    else:
        rec = generic_recommendation(samples, nx, nz, dt, floor)

    rec["nx"] = nx
    rec["nz"] = nz
    rec["dt"] = dt
    rec["samples"] = len(samples)
    rec["P"] = matrix_diagonal(rec["P_diag"], nx, nx)
    rec["Q"] = matrix_diagonal(rec["Q_diag"], nx, nx)
    rec["R"] = matrix_diagonal(rec["R_diag"], nz, nz)
    rec["notes"] = [
        "R is estimated from high-order differences, so strong real dynamics can inflate measurement noise.",
        "Q is a conservative starting point; increase Q for faster tracking and decrease Q for smoother estimates.",
        "Validate against held-out data and inspect innovations/NIS before shipping these values.",
    ]
    return rec


def format_float(value: float) -> str:
    if value == 0.0:
        return "0.0"
    return f"{value:.12g}"


def format_list(values: list[float]) -> str:
    return "[" + ", ".join(format_float(x) for x in values) + "]"


def print_text(rec: dict[str, Any]) -> None:
    print(f"samples: {rec['samples']}")
    print(f"model: {rec['model']}")
    print(f"nx: {rec['nx']}")
    print(f"nz: {rec['nz']}")
    print(f"dt: {format_float(rec['dt'])}")
    print()
    print("recommended state and covariance")
    print(f"x0: {format_list(rec['x0'])}")
    print(f"P_diag: {format_list(rec['P_diag'])}")
    print(f"Q_diag: {format_list(rec['Q_diag'])}")
    print(f"R_diag: {format_list(rec['R_diag'])}")
    print()
    print("row-major matrices")
    print(f"F: {format_list(rec['F'])}")
    print(f"H: {format_list(rec['H'])}")
    print(f"P: {format_list(rec['P'])}")
    print(f"Q: {format_list(rec['Q'])}")
    print(f"R: {format_list(rec['R'])}")

    constructor = rec.get("constructor")
    if constructor:
        args = ", ".join(format_float(x) for x in constructor["args"])
        print()
        print("C++ convenience constructor")
        print(f"auto kf = kalman::{constructor['name']}({args});")

    print()
    print("Python setup")
    print(f"kf = kalman.LinearKalmanFilter({rec['nx']}, {rec['nz']})")
    print(f"kf.x = {format_list(rec['x0'])}")
    print(f"kf.P = {format_list(rec['P'])}")
    print(f"kf.F = {format_list(rec['F'])}")
    print(f"kf.Q = {format_list(rec['Q'])}")
    print(f"kf.H = {format_list(rec['H'])}")
    print(f"kf.R = {format_list(rec['R'])}")

    print()
    print("notes")
    for note in rec["notes"]:
        print(f"- {note}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Estimate starting LinearKalmanFilter tuning parameters from a numeric text stream."
    )
    parser.add_argument("file", type=Path, help="Text file containing numeric measurements")
    parser.add_argument("--nx", type=int, required=True, help="State dimension")
    parser.add_argument("--nz", type=int, default=1, help="Measurement dimension")
    parser.add_argument("--dt", type=float, default=1.0, help="Sample interval")
    parser.add_argument(
        "--model",
        choices=["auto", "random-walk", "constant-velocity", "constant-acceleration", "generic"],
        default="auto",
        help="Model family to tune; auto chooses common layouts from nx/nz",
    )
    parser.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format",
    )
    parser.add_argument(
        "--min-variance",
        type=float,
        default=1.0e-12,
        help="Positive floor for estimated variances",
    )
    parser.add_argument(
        "--comment",
        default="#",
        help="Line comment prefix to ignore; use an empty string to disable",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.nx <= 0 or args.nz <= 0:
        print("error: --nx and --nz must be positive", file=sys.stderr)
        return 2
    if args.dt <= 0.0:
        print("error: --dt must be positive", file=sys.stderr)
        return 2
    if args.min_variance <= 0.0:
        print("error: --min-variance must be positive", file=sys.stderr)
        return 2

    try:
        samples = parse_samples(args.file, args.nz, args.comment)
        rec = estimate(samples, args.nx, args.nz, args.dt, args.model, args.min_variance)
    except (OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    if args.format == "json":
        print(json.dumps(rec, indent=2, sort_keys=True))
    else:
        print_text(rec)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
