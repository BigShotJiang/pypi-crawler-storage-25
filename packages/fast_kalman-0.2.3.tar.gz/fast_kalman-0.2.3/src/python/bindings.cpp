#include <kalman/kalman.hpp>

#include <nanobind/nanobind.h>
#include <nanobind/ndarray.h>
#include <nanobind/stl/string.h>
#include <nanobind/stl/vector.h>

#include <array>
#include <cstddef>
#include <cmath>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace nb = nanobind;
using namespace nb::literals;
namespace rk = kalman;

namespace {

constexpr std::size_t kMaxPythonDimension = 8;

template <std::size_t N>
std::vector<double> to_vector(const rk::Vec<N>& value) {
    std::vector<double> out(N);
    for (std::size_t i = 0; i < N; ++i) out[i] = value[i];
    return out;
}

template <std::size_t R, std::size_t C>
std::vector<double> to_vector(const rk::Mat<R, C>& value) {
    std::vector<double> out(R * C);
    for (std::size_t i = 0; i < R * C; ++i) out[i] = value.a[i];
    return out;
}

template <std::size_t N>
rk::Vec<N> to_vec(const std::vector<double>& value, const char* name) {
    if (value.size() != N) {
        throw nb::value_error((std::string(name) + " must have length " + std::to_string(N)).c_str());
    }
    rk::Vec<N> out{};
    for (std::size_t i = 0; i < N; ++i) out[i] = value[i];
    return out;
}

template <std::size_t R, std::size_t C>
rk::Mat<R, C> to_mat(const std::vector<double>& value, const char* name) {
    if (value.size() != R * C) {
        throw nb::value_error((std::string(name) + " must have length " + std::to_string(R * C)).c_str());
    }
    rk::Mat<R, C> out{};
    for (std::size_t i = 0; i < R * C; ++i) out.a[i] = value[i];
    return out;
}

std::vector<double> object_to_flat_vector(nb::handle value, std::size_t expected, const char* name) {
    std::vector<double> out;

    if (nb::ndarray_check(value)) {
        auto array = nb::cast<nb::ndarray<nb::numpy, const double, nb::c_contig>>(value);
        if (array.size() != expected) {
            throw nb::value_error((std::string(name) + " must have " + std::to_string(expected) + " values").c_str());
        }
        out.resize(expected);
        const double* data = array.data();
        for (std::size_t i = 0; i < expected; ++i) out[i] = data[i];
        return out;
    }

    nb::sequence seq = nb::cast<nb::sequence>(value);
    if (nb::len(seq) != expected) {
        throw nb::value_error((std::string(name) + " must have " + std::to_string(expected) + " values").c_str());
    }
    out.reserve(expected);
    for (std::size_t i = 0; i < expected; ++i) out.push_back(nb::cast<double>(seq[i]));
    return out;
}

std::vector<double> object_to_flat_vector(nb::handle value, const char* name) {
    std::vector<double> out;

    if (nb::ndarray_check(value)) {
        auto array = nb::cast<nb::ndarray<nb::numpy, const double, nb::c_contig>>(value);
        out.resize(array.size());
        const double* data = array.data();
        for (std::size_t i = 0; i < out.size(); ++i) out[i] = data[i];
        return out;
    }

    nb::sequence seq = nb::cast<nb::sequence>(value);
    const std::size_t size = nb::len(seq);
    out.reserve(size);
    for (std::size_t i = 0; i < size; ++i) out.push_back(nb::cast<double>(seq[i]));
    if (out.empty()) throw nb::value_error((std::string(name) + " must not be empty").c_str());
    return out;
}

bool is_row_like(nb::handle value) {
    if (nb::ndarray_check(value)) return true;
    if (PyUnicode_Check(value.ptr()) || PyBytes_Check(value.ptr())) return false;
    if (PyNumber_Check(value.ptr())) return false;
    return PySequence_Check(value.ptr()) != 0;
}

std::pair<std::vector<double>, std::size_t> object_to_samples(nb::handle value, std::size_t nz) {
    if (nz == 0) throw nb::value_error("nz must be positive");

    if (nb::ndarray_check(value)) {
        auto flat = object_to_flat_vector(value, "data_points");
        if (flat.empty()) throw nb::value_error("data_points must not be empty");
        if (flat.size() % nz != 0) {
            throw nb::value_error(("flat data length must be divisible by nz=" + std::to_string(nz)).c_str());
        }
        const std::size_t count = flat.size() / nz;
        return {std::move(flat), count};
    }

    nb::sequence seq = nb::cast<nb::sequence>(value);
    const std::size_t size = nb::len(seq);
    if (size == 0) throw nb::value_error("data_points must not be empty");

    if (is_row_like(seq[0])) {
        std::vector<double> out;
        out.reserve(size * nz);
        for (std::size_t i = 0; i < size; ++i) {
            auto row = object_to_flat_vector(seq[i], nz, "data point");
            out.insert(out.end(), row.begin(), row.end());
        }
        return {std::move(out), size};
    }

    std::vector<double> out;
    out.reserve(size);
    for (std::size_t i = 0; i < size; ++i) out.push_back(nb::cast<double>(seq[i]));
    if (out.size() % nz != 0) {
        throw nb::value_error(("flat data length must be divisible by nz=" + std::to_string(nz)).c_str());
    }
    const std::size_t count = out.size() / nz;
    return {std::move(out), count};
}

nb::dict linear_recommendation_to_dict(const rk::LinearTuningRecommendation& value) {
    nb::dict out;
    out["model"] = value.model;
    out["x"] = value.x;
    out["P"] = value.P;
    out["F"] = value.F;
    out["Q"] = value.Q;
    out["H"] = value.H;
    out["R"] = value.R;
    out["P_diag"] = value.P_diag;
    out["Q_diag"] = value.Q_diag;
    out["R_diag"] = value.R_diag;
    return out;
}

template <std::size_t N>
rk::Vec<N> object_to_vec(nb::handle value, const char* name) {
    return to_vec<N>(object_to_flat_vector(value, N, name), name);
}

template <std::size_t R, std::size_t C>
rk::Mat<R, C> object_to_mat(nb::handle value, const char* name) {
    return to_mat<R, C>(object_to_flat_vector(value, R * C, name), name);
}

template <std::size_t N>
auto numpy_view(const rk::Vec<N>& value) {
    return nb::ndarray<nb::numpy, const double, nb::shape<N>, nb::c_contig>(
        value.data(), {N});
}

template <std::size_t R, std::size_t C>
auto numpy_view(const rk::Mat<R, C>& value) {
    return nb::ndarray<nb::numpy, const double, nb::shape<R, C>, nb::c_contig>(
        value.data(), {R, C});
}

template <std::size_t R, std::size_t C>
auto numpy_view(const std::array<rk::Vec<C>, R>& values) {
    thread_local std::array<double, R * C> scratch{};
    for (std::size_t r = 0; r < R; ++r) {
        for (std::size_t c = 0; c < C; ++c) scratch[r * C + c] = values[r][c];
    }
    return nb::ndarray<nb::numpy, const double, nb::shape<R, C>, nb::c_contig>(
        scratch.data(), {R, C});
}

template <std::size_t NX, std::size_t NZ>
nb::dict stats_to_dict(const rk::UpdateStats<NX, NZ>& stats) {
    nb::dict out;
    out["innovation"] = to_vector(stats.innovation);
    out["S"] = to_vector(stats.S);
    out["K"] = to_vector(stats.K);
    out["nis"] = stats.nis;
    out["ok"] = stats.ok;
    return out;
}

template <std::size_t NX, std::size_t NZ, class Fn>
nb::dict run_many(const std::vector<double>& measurements, bool return_stats, Fn&& fn) {
    if (measurements.size() % NZ != 0) {
        throw nb::value_error(("measurements length must be a multiple of " + std::to_string(NZ)).c_str());
    }

    nb::dict out;
    nb::list all_stats;
    bool ok = true;
    const std::size_t count = measurements.size() / NZ;

    for (std::size_t i = 0; i < count; ++i) {
        rk::Vec<NZ> z{};
        for (std::size_t j = 0; j < NZ; ++j) z[j] = measurements[i * NZ + j];
        auto stats = fn(z);
        ok = ok && stats.ok;
        if (return_stats) all_stats.append(stats_to_dict(stats));
    }

    out["count"] = count;
    out["ok"] = ok;
    if (return_stats) out["stats"] = std::move(all_stats);
    return out;
}

template <std::size_t NX, std::size_t NZ, class Fn>
nb::dict run_many(nb::handle measurements, bool return_stats, Fn&& fn) {
    const auto flat_measurements = object_to_flat_vector(measurements, "measurements");
    return run_many<NX, NZ>(flat_measurements, return_stats, std::forward<Fn>(fn));
}

void ensure_supported(std::size_t nx, std::size_t nz) {
    if (nx == 0 || nx > kMaxPythonDimension || nz == 0 || nz > kMaxPythonDimension) {
        throw nb::value_error("nx and nz must be in the range [1, 8]");
    }
}

template <std::size_t NX, std::size_t NZ>
void bind_linear(nb::module_& m) {
    using T = rk::LinearKalmanFilter<NX, NZ>;
    const std::string name = "_LinearKalmanFilter_" + std::to_string(NX) + "_" + std::to_string(NZ);
    auto cls = nb::class_<T>(m, name.c_str())
        .def(nb::init<>())
        .def_prop_rw("x", [](const T& self) { return to_vector(self.x); },
                     [](T& self, const std::vector<double>& value) { self.x = to_vec<NX>(value, "x"); })
        .def_prop_rw("P", [](const T& self) { return to_vector(self.P); },
                     [](T& self, const std::vector<double>& value) { self.P = to_mat<NX, NX>(value, "P"); })
        .def_prop_rw("F", [](const T& self) { return to_vector(self.F); },
                     [](T& self, const std::vector<double>& value) { self.F = to_mat<NX, NX>(value, "F"); })
        .def_prop_rw("Q", [](const T& self) { return to_vector(self.Q); },
                     [](T& self, const std::vector<double>& value) { self.Q = to_mat<NX, NX>(value, "Q"); })
        .def_prop_rw("H", [](const T& self) { return to_vector(self.H); },
                     [](T& self, const std::vector<double>& value) { self.H = to_mat<NZ, NX>(value, "H"); })
        .def_prop_rw("R", [](const T& self) { return to_vector(self.R); },
                     [](T& self, const std::vector<double>& value) { self.R = to_mat<NZ, NZ>(value, "R"); })
        .def_prop_ro("last", [](const T& self) { return stats_to_dict(self.last); })
        .def("predict", [](T& self) { self.predict(); })
        .def("correct", [](T& self, nb::object z, double eps) {
            return stats_to_dict(self.correct(object_to_vec<NZ>(z, "z"), eps));
        }, "z"_a, "eps"_a = rk::kDefaultEps)
        .def("update", [](T& self, nb::object z, double eps) {
            return stats_to_dict(self.update(object_to_vec<NZ>(z, "z"), eps));
        }, "z"_a, "eps"_a = rk::kDefaultEps)
        .def("correct_many", [](T& self, nb::object measurements, bool return_stats, double eps) {
            auto out = run_many<NX, NZ>(measurements, return_stats, [&](const rk::Vec<NZ>& z) {
                return self.correct(z, eps);
            });
            out["x"] = to_vector(self.x);
            out["P"] = to_vector(self.P);
            out["last"] = stats_to_dict(self.last);
            return out;
        }, "measurements"_a, "return_stats"_a = false, "eps"_a = rk::kDefaultEps)
        .def("update_many", [](T& self, nb::object measurements, bool return_stats, double eps) {
            auto out = run_many<NX, NZ>(measurements, return_stats, [&](const rk::Vec<NZ>& z) {
                return self.update(z, eps);
            });
            out["x"] = to_vector(self.x);
            out["P"] = to_vector(self.P);
            out["last"] = stats_to_dict(self.last);
            return out;
        }, "measurements"_a, "return_stats"_a = false, "eps"_a = rk::kDefaultEps);

    if constexpr (NZ == 1) {
        cls.def("correct_scalar", [](T& self, double z, nb::object h, double r, double eps) {
            return stats_to_dict(self.correct_scalar(z, object_to_vec<NX>(h, "h"), r, eps));
        }, "z"_a, "h"_a, "r"_a, "eps"_a = rk::kDefaultEps);
    }
}

template <std::size_t NX, std::size_t NZ>
void bind_ekf(nb::module_& m) {
    using T = rk::ExtendedKalmanFilter<NX, NZ>;
    const std::string name = "_ExtendedKalmanFilter_" + std::to_string(NX) + "_" + std::to_string(NZ);
    nb::class_<T>(m, name.c_str())
        .def(nb::init<>())
        .def_prop_rw("x", [](const T& self) { return to_vector(self.x); },
                     [](T& self, const std::vector<double>& value) { self.x = to_vec<NX>(value, "x"); })
        .def_prop_rw("P", [](const T& self) { return to_vector(self.P); },
                     [](T& self, const std::vector<double>& value) { self.P = to_mat<NX, NX>(value, "P"); })
        .def_prop_rw("Q", [](const T& self) { return to_vector(self.Q); },
                     [](T& self, const std::vector<double>& value) { self.Q = to_mat<NX, NX>(value, "Q"); })
        .def_prop_rw("R", [](const T& self) { return to_vector(self.R); },
                     [](T& self, const std::vector<double>& value) { self.R = to_mat<NZ, NZ>(value, "R"); })
        .def_prop_ro("last", [](const T& self) { return stats_to_dict(self.last); })
        .def("predict", [](T& self, nb::callable transition, nb::callable jacobian) {
            self.predict(
                [&](const rk::Vec<NX>& x) { return object_to_vec<NX>(transition(numpy_view(x)), "transition result"); },
                [&](const rk::Vec<NX>& x) { return object_to_mat<NX, NX>(jacobian(numpy_view(x)), "transition jacobian result"); });
        }, "transition"_a, "jacobian"_a)
        .def("correct", [](T& self, nb::object z, nb::callable measurement, nb::callable jacobian, double eps) {
            auto stats = self.correct(
                object_to_vec<NZ>(z, "z"),
                [&](const rk::Vec<NX>& x) { return object_to_vec<NZ>(measurement(numpy_view(x)), "measurement result"); },
                [&](const rk::Vec<NX>& x) { return object_to_mat<NZ, NX>(jacobian(numpy_view(x)), "measurement jacobian result"); },
                eps);
            return stats_to_dict(stats);
        }, "z"_a, "measurement"_a, "jacobian"_a, "eps"_a = rk::kDefaultEps)
        .def("update_many", [](T& self, nb::object measurements, nb::callable transition, nb::callable transition_jacobian,
                               nb::callable measurement, nb::callable measurement_jacobian, bool return_stats, double eps) {
            auto out = run_many<NX, NZ>(measurements, return_stats, [&](const rk::Vec<NZ>& z) {
                self.predict(
                    [&](const rk::Vec<NX>& x) { return object_to_vec<NX>(transition(numpy_view(x)), "transition result"); },
                    [&](const rk::Vec<NX>& x) { return object_to_mat<NX, NX>(transition_jacobian(numpy_view(x)), "transition jacobian result"); });
                return self.correct(
                    z,
                    [&](const rk::Vec<NX>& x) { return object_to_vec<NZ>(measurement(numpy_view(x)), "measurement result"); },
                    [&](const rk::Vec<NX>& x) { return object_to_mat<NZ, NX>(measurement_jacobian(numpy_view(x)), "measurement jacobian result"); },
                    eps);
            });
            out["x"] = to_vector(self.x);
            out["P"] = to_vector(self.P);
            out["last"] = stats_to_dict(self.last);
            return out;
        }, "measurements"_a, "transition"_a, "transition_jacobian"_a, "measurement"_a, "measurement_jacobian"_a,
           "return_stats"_a = false, "eps"_a = rk::kDefaultEps);
}

template <std::size_t NX, std::size_t NZ>
void bind_iterated_ekf(nb::module_& m) {
    using T = rk::IteratedExtendedKalmanFilter<NX, NZ>;
    const std::string name = "_IteratedExtendedKalmanFilter_" + std::to_string(NX) + "_" + std::to_string(NZ);
    nb::class_<T>(m, name.c_str())
        .def(nb::init<>())
        .def_prop_rw("x", [](const T& self) { return to_vector(self.x); },
                     [](T& self, const std::vector<double>& value) { self.x = to_vec<NX>(value, "x"); })
        .def_prop_rw("P", [](const T& self) { return to_vector(self.P); },
                     [](T& self, const std::vector<double>& value) { self.P = to_mat<NX, NX>(value, "P"); })
        .def_prop_rw("Q", [](const T& self) { return to_vector(self.Q); },
                     [](T& self, const std::vector<double>& value) { self.Q = to_mat<NX, NX>(value, "Q"); })
        .def_prop_rw("R", [](const T& self) { return to_vector(self.R); },
                     [](T& self, const std::vector<double>& value) { self.R = to_mat<NZ, NZ>(value, "R"); })
        .def_prop_ro("last", [](const T& self) { return stats_to_dict(self.last); })
        .def("predict", [](T& self, nb::callable transition, nb::callable jacobian) {
            self.predict(
                [&](const rk::Vec<NX>& x) { return object_to_vec<NX>(transition(numpy_view(x)), "transition result"); },
                [&](const rk::Vec<NX>& x) { return object_to_mat<NX, NX>(jacobian(numpy_view(x)), "transition jacobian result"); });
        }, "transition"_a, "jacobian"_a)
        .def("correct", [](T& self, nb::object z, nb::callable measurement, nb::callable jacobian,
                           std::size_t max_iterations, double tolerance, double eps) {
            auto stats = self.correct(
                object_to_vec<NZ>(z, "z"),
                [&](const rk::Vec<NX>& x) { return object_to_vec<NZ>(measurement(numpy_view(x)), "measurement result"); },
                [&](const rk::Vec<NX>& x) { return object_to_mat<NZ, NX>(jacobian(numpy_view(x)), "measurement jacobian result"); },
                max_iterations, tolerance, eps);
            return stats_to_dict(stats);
        }, "z"_a, "measurement"_a, "jacobian"_a, "max_iterations"_a = 5, "tolerance"_a = 1.0e-10, "eps"_a = rk::kDefaultEps)
        .def("update_many", [](T& self, nb::object measurements, nb::callable transition, nb::callable transition_jacobian,
                               nb::callable measurement, nb::callable measurement_jacobian,
                               std::size_t max_iterations, double tolerance, bool return_stats, double eps) {
            auto out = run_many<NX, NZ>(measurements, return_stats, [&](const rk::Vec<NZ>& z) {
                self.predict(
                    [&](const rk::Vec<NX>& x) { return object_to_vec<NX>(transition(numpy_view(x)), "transition result"); },
                    [&](const rk::Vec<NX>& x) { return object_to_mat<NX, NX>(transition_jacobian(numpy_view(x)), "transition jacobian result"); });
                return self.correct(
                    z,
                    [&](const rk::Vec<NX>& x) { return object_to_vec<NZ>(measurement(numpy_view(x)), "measurement result"); },
                    [&](const rk::Vec<NX>& x) { return object_to_mat<NZ, NX>(measurement_jacobian(numpy_view(x)), "measurement jacobian result"); },
                    max_iterations, tolerance, eps);
            });
            out["x"] = to_vector(self.x);
            out["P"] = to_vector(self.P);
            out["last"] = stats_to_dict(self.last);
            return out;
        }, "measurements"_a, "transition"_a, "transition_jacobian"_a, "measurement"_a, "measurement_jacobian"_a,
           "max_iterations"_a = 5, "tolerance"_a = 1.0e-10, "return_stats"_a = false, "eps"_a = rk::kDefaultEps);
}

template <std::size_t NX, std::size_t NZ>
bool ukf_predict_batch(rk::UnscentedKalmanFilter<NX, NZ>& self, nb::callable transition_batch, double jitter) {
    using T = rk::UnscentedKalmanFilter<NX, NZ>;
    std::array<rk::Vec<NX>, T::SigmaCount> sigma{};
    if (!self.sigma_points(sigma, jitter)) return false;
    auto flat = object_to_flat_vector(transition_batch(numpy_view<T::SigmaCount, NX>(sigma)), T::SigmaCount * NX, "transition_batch result");

    std::array<rk::Vec<NX>, T::SigmaCount> propagated{};
    rk::Vec<NX> mean{};
    for (std::size_t i = 0; i < T::SigmaCount; ++i) {
        for (std::size_t j = 0; j < NX; ++j) propagated[i][j] = flat[i * NX + j];
        mean += propagated[i] * self.wm(i);
    }

    rk::Mat<NX, NX> cov = self.Q;
    for (std::size_t i = 0; i < T::SigmaCount; ++i) {
        const rk::Vec<NX> dx = propagated[i] - mean;
        cov += rk::outer(dx, dx) * self.wc(i);
    }
    self.x = mean;
    self.P = cov;
    rk::symmetrize(self.P);
    rk::floor_diagonal(self.P);
    return true;
}

template <std::size_t NX, std::size_t NZ>
rk::UpdateStats<NX, NZ> ukf_correct_batch(rk::UnscentedKalmanFilter<NX, NZ>& self,
                                           const rk::Vec<NZ>& z,
                                           nb::callable measurement_batch,
                                           double jitter,
                                           double eps) {
    using T = rk::UnscentedKalmanFilter<NX, NZ>;
    rk::UpdateStats<NX, NZ> stats{};
    std::array<rk::Vec<NX>, T::SigmaCount> sigma{};
    if (!self.sigma_points(sigma, jitter)) { stats.ok = false; return stats; }

    auto flat = object_to_flat_vector(measurement_batch(numpy_view<T::SigmaCount, NX>(sigma)), T::SigmaCount * NZ, "measurement_batch result");
    std::array<rk::Vec<NZ>, T::SigmaCount> zsigma{};
    rk::Vec<NZ> zmean{};
    for (std::size_t i = 0; i < T::SigmaCount; ++i) {
        for (std::size_t j = 0; j < NZ; ++j) zsigma[i][j] = flat[i * NZ + j];
        zmean += zsigma[i] * self.wm(i);
    }

    rk::Mat<NZ, NZ> S = self.R;
    rk::Mat<NX, NZ> Pxz{};
    for (std::size_t i = 0; i < T::SigmaCount; ++i) {
        const rk::Vec<NX> dx = sigma[i] - self.x;
        const rk::Vec<NZ> dz = zsigma[i] - zmean;
        S += rk::outer(dz, dz) * self.wc(i);
        Pxz += rk::outer(dx, dz) * self.wc(i);
    }
    rk::symmetrize(S);

    rk::Mat<NZ, NZ> Sinv{};
    if (!rk::inverse(S, Sinv, eps)) { stats.ok = false; return stats; }
    stats.K = Pxz * Sinv;
    stats.innovation = z - zmean;
    stats.S = S;
    self.x += stats.K * stats.innovation;
    self.P -= stats.K * S * rk::transpose(stats.K);
    rk::symmetrize(self.P);
    rk::floor_diagonal(self.P);
    stats.nis = rk::dot(stats.innovation, Sinv * stats.innovation);
    stats.ok = true;
    self.last = stats;
    return stats;
}

template <std::size_t NX, std::size_t NZ>
void bind_ukf(nb::module_& m) {
    using T = rk::UnscentedKalmanFilter<NX, NZ>;
    const std::string name = "_UnscentedKalmanFilter_" + std::to_string(NX) + "_" + std::to_string(NZ);
    nb::class_<T>(m, name.c_str())
        .def(nb::init<>())
        .def_prop_rw("x", [](const T& self) { return to_vector(self.x); },
                     [](T& self, const std::vector<double>& value) { self.x = to_vec<NX>(value, "x"); })
        .def_prop_rw("P", [](const T& self) { return to_vector(self.P); },
                     [](T& self, const std::vector<double>& value) { self.P = to_mat<NX, NX>(value, "P"); })
        .def_prop_rw("Q", [](const T& self) { return to_vector(self.Q); },
                     [](T& self, const std::vector<double>& value) { self.Q = to_mat<NX, NX>(value, "Q"); })
        .def_prop_rw("R", [](const T& self) { return to_vector(self.R); },
                     [](T& self, const std::vector<double>& value) { self.R = to_mat<NZ, NZ>(value, "R"); })
        .def_prop_rw("alpha", [](const T& self) { return self.params.alpha; }, [](T& self, double value) { self.params.alpha = value; })
        .def_prop_rw("beta", [](const T& self) { return self.params.beta; }, [](T& self, double value) { self.params.beta = value; })
        .def_prop_rw("kappa", [](const T& self) { return self.params.kappa; }, [](T& self, double value) { self.params.kappa = value; })
        .def_prop_ro("last", [](const T& self) { return stats_to_dict(self.last); })
        .def("predict", [](T& self, nb::callable transition, double jitter) {
            return self.predict(
                [&](const rk::Vec<NX>& x) { return object_to_vec<NX>(transition(numpy_view(x)), "transition result"); },
                jitter);
        }, "transition"_a, "jitter"_a = rk::kDefaultJitter)
        .def("correct", [](T& self, nb::object z, nb::callable measurement, double jitter, double eps) {
            auto stats = self.correct(
                object_to_vec<NZ>(z, "z"),
                [&](const rk::Vec<NX>& x) { return object_to_vec<NZ>(measurement(numpy_view(x)), "measurement result"); },
                jitter, eps);
            return stats_to_dict(stats);
        }, "z"_a, "measurement"_a, "jitter"_a = rk::kDefaultJitter, "eps"_a = rk::kDefaultEps)
        .def("update_many", [](T& self, nb::object measurements, nb::callable transition, nb::callable measurement,
                               bool return_stats, double jitter, double eps) {
            auto out = run_many<NX, NZ>(measurements, return_stats, [&](const rk::Vec<NZ>& z) {
                const bool predicted = self.predict(
                    [&](const rk::Vec<NX>& x) { return object_to_vec<NX>(transition(numpy_view(x)), "transition result"); },
                    jitter);
                auto stats = self.correct(
                    z,
                    [&](const rk::Vec<NX>& x) { return object_to_vec<NZ>(measurement(numpy_view(x)), "measurement result"); },
                    jitter, eps);
                stats.ok = stats.ok && predicted;
                self.last = stats;
                return stats;
            });
            out["x"] = to_vector(self.x);
            out["P"] = to_vector(self.P);
            out["last"] = stats_to_dict(self.last);
            return out;
        }, "measurements"_a, "transition"_a, "measurement"_a, "return_stats"_a = false,
           "jitter"_a = rk::kDefaultJitter, "eps"_a = rk::kDefaultEps)
        .def("predict_batch", [](T& self, nb::callable transition_batch, double jitter) {
            return ukf_predict_batch(self, transition_batch, jitter);
        }, "transition_batch"_a, "jitter"_a = rk::kDefaultJitter)
        .def("correct_batch", [](T& self, nb::object z, nb::callable measurement_batch, double jitter, double eps) {
            return stats_to_dict(ukf_correct_batch(self, object_to_vec<NZ>(z, "z"), measurement_batch, jitter, eps));
        }, "z"_a, "measurement_batch"_a, "jitter"_a = rk::kDefaultJitter, "eps"_a = rk::kDefaultEps)
        .def("update_many_batch", [](T& self, nb::object measurements, nb::callable transition_batch, nb::callable measurement_batch,
                                     bool return_stats, double jitter, double eps) {
            auto out = run_many<NX, NZ>(measurements, return_stats, [&](const rk::Vec<NZ>& z) {
                const bool predicted = ukf_predict_batch(self, transition_batch, jitter);
                auto stats = ukf_correct_batch(self, z, measurement_batch, jitter, eps);
                stats.ok = stats.ok && predicted;
                self.last = stats;
                return stats;
            });
            out["x"] = to_vector(self.x);
            out["P"] = to_vector(self.P);
            out["last"] = stats_to_dict(self.last);
            return out;
        }, "measurements"_a, "transition_batch"_a, "measurement_batch"_a, "return_stats"_a = false,
           "jitter"_a = rk::kDefaultJitter, "eps"_a = rk::kDefaultEps);
}

template <std::size_t NX, std::size_t NZ>
void bind_adaptive(nb::module_& m) {
    using T = rk::AdaptiveKalmanFilter<NX, NZ>;
    const std::string name = "_AdaptiveKalmanFilter_" + std::to_string(NX) + "_" + std::to_string(NZ);
    nb::class_<T>(m, name.c_str())
        .def(nb::init<>())
        .def_prop_rw("x", [](const T& self) { return to_vector(self.kf.x); },
                     [](T& self, const std::vector<double>& value) { self.kf.x = to_vec<NX>(value, "x"); })
        .def_prop_rw("P", [](const T& self) { return to_vector(self.kf.P); },
                     [](T& self, const std::vector<double>& value) { self.kf.P = to_mat<NX, NX>(value, "P"); })
        .def_prop_rw("F", [](const T& self) { return to_vector(self.kf.F); },
                     [](T& self, const std::vector<double>& value) { self.kf.F = to_mat<NX, NX>(value, "F"); })
        .def_prop_rw("Q", [](const T& self) { return to_vector(self.kf.Q); },
                     [](T& self, const std::vector<double>& value) { self.kf.Q = to_mat<NX, NX>(value, "Q"); })
        .def_prop_rw("H", [](const T& self) { return to_vector(self.kf.H); },
                     [](T& self, const std::vector<double>& value) { self.kf.H = to_mat<NZ, NX>(value, "H"); })
        .def_prop_rw("R", [](const T& self) { return to_vector(self.kf.R); },
                     [](T& self, const std::vector<double>& value) { self.kf.R = to_mat<NZ, NZ>(value, "R"); })
        .def_prop_rw("forgetting", [](const T& self) { return self.options.forgetting; }, [](T& self, double value) { self.options.forgetting = value; })
        .def_prop_rw("min_variance", [](const T& self) { return self.options.min_variance; }, [](T& self, double value) { self.options.min_variance = value; })
        .def_prop_rw("adapt_R", [](const T& self) { return self.options.adapt_R; }, [](T& self, bool value) { self.options.adapt_R = value; })
        .def_prop_rw("diagonal_R_only", [](const T& self) { return self.options.diagonal_R_only; }, [](T& self, bool value) { self.options.diagonal_R_only = value; })
        .def_prop_rw("adapt_Q_from_state_correction", [](const T& self) { return self.options.adapt_Q_from_state_correction; }, [](T& self, bool value) { self.options.adapt_Q_from_state_correction = value; })
        .def("predict", [](T& self) { self.predict(); })
        .def("correct", [](T& self, nb::object z, double eps) {
            return stats_to_dict(self.correct(object_to_vec<NZ>(z, "z"), eps));
        }, "z"_a, "eps"_a = rk::kDefaultEps)
        .def("update", [](T& self, nb::object z, double eps) {
            return stats_to_dict(self.update(object_to_vec<NZ>(z, "z"), eps));
        }, "z"_a, "eps"_a = rk::kDefaultEps)
        .def("correct_many", [](T& self, nb::object measurements, bool return_stats, double eps) {
            auto out = run_many<NX, NZ>(measurements, return_stats, [&](const rk::Vec<NZ>& z) {
                return self.correct(z, eps);
            });
            out["x"] = to_vector(self.kf.x);
            out["P"] = to_vector(self.kf.P);
            return out;
        }, "measurements"_a, "return_stats"_a = false, "eps"_a = rk::kDefaultEps)
        .def("update_many", [](T& self, nb::object measurements, bool return_stats, double eps) {
            auto out = run_many<NX, NZ>(measurements, return_stats, [&](const rk::Vec<NZ>& z) {
                return self.update(z, eps);
            });
            out["x"] = to_vector(self.kf.x);
            out["P"] = to_vector(self.kf.P);
            return out;
        }, "measurements"_a, "return_stats"_a = false, "eps"_a = rk::kDefaultEps);
}

template <std::size_t NX, std::size_t NZ>
rk::UpdateStats<NX, NZ> enkf_correct_deterministic_batch(rk::EnsembleKalmanFilter<NX, NZ, 8>& self,
                                                          const rk::Vec<NZ>& z,
                                                          nb::callable measurement_batch,
                                                          double eps) {
    rk::UpdateStats<NX, NZ> stats{};
    auto flat = object_to_flat_vector(measurement_batch(numpy_view<8, NX>(self.members)), 8 * NZ, "measurement_batch result");
    std::array<rk::Vec<NZ>, 8> y_members{};
    rk::Vec<NZ> y_mean{};
    constexpr double inv_n = 1.0 / 8.0;
    constexpr double inv_nm1 = 1.0 / 7.0;

    for (std::size_t i = 0; i < 8; ++i) {
        for (std::size_t j = 0; j < NZ; ++j) y_members[i][j] = flat[i * NZ + j];
        y_mean += y_members[i] * inv_n;
    }

    rk::Mat<NX, NZ> Pxy{};
    rk::Mat<NZ, NZ> Pyy = self.R;
    for (std::size_t i = 0; i < 8; ++i) {
        const rk::Vec<NX> dx = self.members[i] - self.x;
        const rk::Vec<NZ> dy = y_members[i] - y_mean;
        Pxy += rk::outer(dx, dy) * inv_nm1;
        Pyy += rk::outer(dy, dy) * inv_nm1;
    }
    rk::symmetrize(Pyy);

    rk::Mat<NZ, NZ> PyyInv{};
    if (!rk::inverse(Pyy, PyyInv, eps)) { stats.ok = false; return stats; }
    stats.K = Pxy * PyyInv;
    stats.innovation = z - y_mean;
    stats.S = Pyy;

    for (std::size_t i = 0; i < 8; ++i) {
        self.members[i] += stats.K * (z - y_members[i]);
    }

    self.recompute_mean_covariance();
    stats.nis = rk::dot(stats.innovation, PyyInv * stats.innovation);
    stats.ok = true;
    self.last = stats;
    return stats;
}

template <std::size_t NX, std::size_t NZ>
void bind_enkf8(nb::module_& m) {
    using T = rk::EnsembleKalmanFilter<NX, NZ, 8>;
    const std::string name = "_EnsembleKalmanFilter_" + std::to_string(NX) + "_" + std::to_string(NZ) + "_8";
    nb::class_<T>(m, name.c_str())
        .def(nb::init<>())
        .def_prop_rw("members", [](const T& self) {
            std::vector<std::vector<double>> out;
            out.reserve(8);
            for (const auto& member : self.members) out.push_back(to_vector(member));
            return out;
        }, [](T& self, const std::vector<std::vector<double>>& value) {
            if (value.size() != 8) throw nb::value_error("members must contain exactly 8 vectors");
            for (std::size_t i = 0; i < 8; ++i) self.members[i] = to_vec<NX>(value[i], "member");
        })
        .def_prop_ro("x", [](const T& self) { return to_vector(self.x); })
        .def_prop_ro("P", [](const T& self) { return to_vector(self.P); })
        .def_prop_rw("R", [](const T& self) { return to_vector(self.R); },
                     [](T& self, const std::vector<double>& value) { self.R = to_mat<NZ, NZ>(value, "R"); })
        .def_prop_ro("last", [](const T& self) { return stats_to_dict(self.last); })
        .def("recompute_mean_covariance", &T::recompute_mean_covariance)
        .def("predict", [](T& self, nb::callable transition) {
            self.predict([&](const rk::Vec<NX>& x) { return object_to_vec<NX>(transition(numpy_view(x)), "transition result"); });
        }, "transition"_a)
        .def("correct_deterministic", [](T& self, nb::object z, nb::callable measurement, double eps) {
            auto stats = self.correct_deterministic(
                object_to_vec<NZ>(z, "z"),
                [&](const rk::Vec<NX>& x) { return object_to_vec<NZ>(measurement(numpy_view(x)), "measurement result"); },
                eps);
            return stats_to_dict(stats);
        }, "z"_a, "measurement"_a, "eps"_a = rk::kDefaultEps)
        .def("update_many", [](T& self, nb::object measurements, nb::callable transition, nb::callable measurement,
                               bool return_stats, double eps) {
            auto out = run_many<NX, NZ>(measurements, return_stats, [&](const rk::Vec<NZ>& z) {
                self.predict([&](const rk::Vec<NX>& x) { return object_to_vec<NX>(transition(numpy_view(x)), "transition result"); });
                return self.correct_deterministic(
                    z,
                    [&](const rk::Vec<NX>& x) { return object_to_vec<NZ>(measurement(numpy_view(x)), "measurement result"); },
                    eps);
            });
            out["x"] = to_vector(self.x);
            out["P"] = to_vector(self.P);
            out["last"] = stats_to_dict(self.last);
            return out;
        }, "measurements"_a, "transition"_a, "measurement"_a, "return_stats"_a = false, "eps"_a = rk::kDefaultEps)
        .def("predict_batch", [](T& self, nb::callable transition_batch) {
            auto flat = object_to_flat_vector(transition_batch(numpy_view<8, NX>(self.members)), 8 * NX, "transition_batch result");
            for (std::size_t i = 0; i < 8; ++i) {
                for (std::size_t j = 0; j < NX; ++j) self.members[i][j] = flat[i * NX + j];
            }
            self.recompute_mean_covariance();
        }, "transition_batch"_a)
        .def("correct_deterministic_batch", [](T& self, nb::object z, nb::callable measurement_batch, double eps) {
            return stats_to_dict(enkf_correct_deterministic_batch(self, object_to_vec<NZ>(z, "z"), measurement_batch, eps));
        }, "z"_a, "measurement_batch"_a, "eps"_a = rk::kDefaultEps)
        .def("update_many_batch", [](T& self, nb::object measurements, nb::callable transition_batch, nb::callable measurement_batch,
                                     bool return_stats, double eps) {
            auto out = run_many<NX, NZ>(measurements, return_stats, [&](const rk::Vec<NZ>& z) {
                auto flat = object_to_flat_vector(transition_batch(numpy_view<8, NX>(self.members)), 8 * NX, "transition_batch result");
                for (std::size_t i = 0; i < 8; ++i) {
                    for (std::size_t j = 0; j < NX; ++j) self.members[i][j] = flat[i * NX + j];
                }
                self.recompute_mean_covariance();
                return enkf_correct_deterministic_batch(self, z, measurement_batch, eps);
            });
            out["x"] = to_vector(self.x);
            out["P"] = to_vector(self.P);
            out["last"] = stats_to_dict(self.last);
            return out;
        }, "measurements"_a, "transition_batch"_a, "measurement_batch"_a, "return_stats"_a = false, "eps"_a = rk::kDefaultEps);
}

double wrap_angle(double x) noexcept {
    constexpr double pi = 3.141592653589793238462643383279502884;
    while (x > pi) x -= 2.0 * pi;
    while (x < -pi) x += 2.0 * pi;
    return x;
}

class RangeBearingEKF2D {
public:
    rk::ExtendedKalmanFilter<4, 2> ekf{};
    double dt = 1.0;
    double landmark_x = 0.0;
    double landmark_y = 0.0;

    void predict() {
        ekf.predict(
            [&](const rk::Vec<4>& x) {
                return rk::Vec<4>{x[0] + dt * x[2], x[1] + dt * x[3], x[2], x[3]};
            },
            [&](const rk::Vec<4>&) {
                return rk::Mat<4, 4>{1.0, 0.0, dt, 0.0,
                                     0.0, 1.0, 0.0, dt,
                                     0.0, 0.0, 1.0, 0.0,
                                     0.0, 0.0, 0.0, 1.0};
            });
    }

    rk::Vec<2> measurement(const rk::Vec<4>& x) const {
        const double dx = x[0] - landmark_x;
        const double dy = x[1] - landmark_y;
        const double r = std::sqrt(dx * dx + dy * dy);
        return rk::Vec<2>{r, std::atan2(dy, dx)};
    }

    rk::Mat<2, 4> measurement_jacobian(const rk::Vec<4>& x) const {
        const double dx = x[0] - landmark_x;
        const double dy = x[1] - landmark_y;
        const double r2 = std::max(dx * dx + dy * dy, 1.0e-24);
        const double r = std::sqrt(r2);
        return rk::Mat<2, 4>{dx / r, dy / r, 0.0, 0.0,
                             -dy / r2, dx / r2, 0.0, 0.0};
    }

    rk::UpdateStats<4, 2> correct(const rk::Vec<2>& z, double eps = rk::kDefaultEps) {
        const rk::Vec<2> zhat = measurement(ekf.x);
        const rk::Mat<2, 4> H = measurement_jacobian(ekf.x);
        rk::Vec<2> innovation = z - zhat;
        innovation[1] = wrap_angle(innovation[1]);
        ekf.last = rk::linear_correct_with_innovation(ekf.x, ekf.P, innovation, H, ekf.R, eps);
        return ekf.last;
    }

    rk::UpdateStats<4, 2> update(const rk::Vec<2>& z, double eps = rk::kDefaultEps) {
        predict();
        return correct(z, eps);
    }
};

void bind_range_bearing_ekf2d(nb::module_& m) {
    nb::class_<RangeBearingEKF2D>(m, "RangeBearingEKF2D")
        .def(nb::init<>())
        .def_rw("dt", &RangeBearingEKF2D::dt)
        .def_rw("landmark_x", &RangeBearingEKF2D::landmark_x)
        .def_rw("landmark_y", &RangeBearingEKF2D::landmark_y)
        .def_prop_rw("x", [](const RangeBearingEKF2D& self) { return to_vector(self.ekf.x); },
                     [](RangeBearingEKF2D& self, nb::object value) { self.ekf.x = object_to_vec<4>(value, "x"); })
        .def_prop_rw("P", [](const RangeBearingEKF2D& self) { return to_vector(self.ekf.P); },
                     [](RangeBearingEKF2D& self, nb::object value) { self.ekf.P = object_to_mat<4, 4>(value, "P"); })
        .def_prop_rw("Q", [](const RangeBearingEKF2D& self) { return to_vector(self.ekf.Q); },
                     [](RangeBearingEKF2D& self, nb::object value) { self.ekf.Q = object_to_mat<4, 4>(value, "Q"); })
        .def_prop_rw("R", [](const RangeBearingEKF2D& self) { return to_vector(self.ekf.R); },
                     [](RangeBearingEKF2D& self, nb::object value) { self.ekf.R = object_to_mat<2, 2>(value, "R"); })
        .def_prop_ro("last", [](const RangeBearingEKF2D& self) { return stats_to_dict(self.ekf.last); })
        .def("predict", &RangeBearingEKF2D::predict)
        .def("measurement", [](const RangeBearingEKF2D& self, nb::object x) {
            return to_vector(self.measurement(object_to_vec<4>(x, "x")));
        }, "x"_a)
        .def("measurement_jacobian", [](const RangeBearingEKF2D& self, nb::object x) {
            return to_vector(self.measurement_jacobian(object_to_vec<4>(x, "x")));
        }, "x"_a)
        .def("correct", [](RangeBearingEKF2D& self, nb::object z, double eps) {
            return stats_to_dict(self.correct(object_to_vec<2>(z, "z"), eps));
        }, "z"_a, "eps"_a = rk::kDefaultEps)
        .def("update", [](RangeBearingEKF2D& self, nb::object z, double eps) {
            return stats_to_dict(self.update(object_to_vec<2>(z, "z"), eps));
        }, "z"_a, "eps"_a = rk::kDefaultEps)
        .def("update_many", [](RangeBearingEKF2D& self, nb::object measurements, bool return_stats, double eps) {
            auto out = run_many<4, 2>(measurements, return_stats, [&](const rk::Vec<2>& z) {
                return self.update(z, eps);
            });
            out["x"] = to_vector(self.ekf.x);
            out["P"] = to_vector(self.ekf.P);
            out["last"] = stats_to_dict(self.ekf.last);
            return out;
        }, "measurements"_a, "return_stats"_a = false, "eps"_a = rk::kDefaultEps);
}

#define FOR_EACH_PAIR(M) \
    M(1, 1) M(1, 2) M(1, 3) M(1, 4) M(1, 5) M(1, 6) M(1, 7) M(1, 8) \
    M(2, 1) M(2, 2) M(2, 3) M(2, 4) M(2, 5) M(2, 6) M(2, 7) M(2, 8) \
    M(3, 1) M(3, 2) M(3, 3) M(3, 4) M(3, 5) M(3, 6) M(3, 7) M(3, 8) \
    M(4, 1) M(4, 2) M(4, 3) M(4, 4) M(4, 5) M(4, 6) M(4, 7) M(4, 8) \
    M(5, 1) M(5, 2) M(5, 3) M(5, 4) M(5, 5) M(5, 6) M(5, 7) M(5, 8) \
    M(6, 1) M(6, 2) M(6, 3) M(6, 4) M(6, 5) M(6, 6) M(6, 7) M(6, 8) \
    M(7, 1) M(7, 2) M(7, 3) M(7, 4) M(7, 5) M(7, 6) M(7, 7) M(7, 8) \
    M(8, 1) M(8, 2) M(8, 3) M(8, 4) M(8, 5) M(8, 6) M(8, 7) M(8, 8)

#define BIND_ALL(NX, NZ) \
    bind_linear<NX, NZ>(m); \
    bind_ekf<NX, NZ>(m); \
    bind_iterated_ekf<NX, NZ>(m); \
    bind_ukf<NX, NZ>(m); \
    bind_adaptive<NX, NZ>(m); \
    bind_enkf8<NX, NZ>(m);

template <template <std::size_t, std::size_t> class T>
nb::object construct_pair(std::size_t nx, std::size_t nz) {
    ensure_supported(nx, nz);
#define CASE_NZ(NX, NZ) case NZ: return nb::cast(T<NX, NZ>{});
#define CASE_NX(NX) case NX: switch (nz) { \
    CASE_NZ(NX, 1) CASE_NZ(NX, 2) CASE_NZ(NX, 3) CASE_NZ(NX, 4) \
    CASE_NZ(NX, 5) CASE_NZ(NX, 6) CASE_NZ(NX, 7) CASE_NZ(NX, 8) }
    switch (nx) {
        CASE_NX(1)
        CASE_NX(2)
        CASE_NX(3)
        CASE_NX(4)
        CASE_NX(5)
        CASE_NX(6)
        CASE_NX(7)
        CASE_NX(8)
    }
#undef CASE_NX
#undef CASE_NZ
    throw nb::value_error("unsupported dimensions");
}

nb::object construct_enkf(std::size_t nx, std::size_t nz, std::size_t ensemble_size) {
    if (ensemble_size != 8) throw nb::value_error("the Python EnKF binding currently supports ensemble_size=8");
    ensure_supported(nx, nz);
#define CASE_NZ(NX, NZ) case NZ: return nb::cast(rk::EnsembleKalmanFilter<NX, NZ, 8>{});
#define CASE_NX(NX) case NX: switch (nz) { \
    CASE_NZ(NX, 1) CASE_NZ(NX, 2) CASE_NZ(NX, 3) CASE_NZ(NX, 4) \
    CASE_NZ(NX, 5) CASE_NZ(NX, 6) CASE_NZ(NX, 7) CASE_NZ(NX, 8) }
    switch (nx) {
        CASE_NX(1)
        CASE_NX(2)
        CASE_NX(3)
        CASE_NX(4)
        CASE_NX(5)
        CASE_NX(6)
        CASE_NX(7)
        CASE_NX(8)
    }
#undef CASE_NX
#undef CASE_NZ
    throw nb::value_error("unsupported dimensions");
}

} // namespace

NB_MODULE(_core, m) {
    m.doc() = "Fixed-size C++23 Kalman filters";
    m.attr("MAX_DIMENSION") = kMaxPythonDimension;
    m.def("version", &rk::version);
    m.def("supported_dimensions", [] { return std::vector<std::size_t>{1, 2, 3, 4, 5, 6, 7, 8}; });
    m.def("_linear_recommendation", [](nb::object data_points, std::size_t nx, std::size_t nz,
                                       double dt, const std::string& model, double minimum_variance) {
        auto [flat_samples, sample_count] = object_to_samples(data_points, nz);
        return linear_recommendation_to_dict(rk::linear_recommendation(
            flat_samples, sample_count, nx, nz, dt, model, minimum_variance));
    }, "data_points"_a, "nx"_a, "nz"_a, "dt"_a = 1.0, "model"_a = "auto", "minimum_variance"_a = 1.0e-12);

    FOR_EACH_PAIR(BIND_ALL)
    bind_range_bearing_ekf2d(m);

    m.def("LinearKalmanFilter", &construct_pair<rk::LinearKalmanFilter>, "nx"_a, "nz"_a);
    m.def("ExtendedKalmanFilter", &construct_pair<rk::ExtendedKalmanFilter>, "nx"_a, "nz"_a);
    m.def("IteratedExtendedKalmanFilter", &construct_pair<rk::IteratedExtendedKalmanFilter>, "nx"_a, "nz"_a);
    m.def("UnscentedKalmanFilter", &construct_pair<rk::UnscentedKalmanFilter>, "nx"_a, "nz"_a);
    m.def("AdaptiveKalmanFilter", &construct_pair<rk::AdaptiveKalmanFilter>, "nx"_a, "nz"_a);
    m.def("EnsembleKalmanFilter", &construct_enkf, "nx"_a, "nz"_a, "ensemble_size"_a = 8);

    m.def("make_scalar_random_walk", [](
        double initial_value,
        double initial_variance,
        double process_variance,
        double measurement_variance) {
        return rk::make_scalar_random_walk(initial_value, initial_variance, process_variance, measurement_variance);
    }, "initial_value"_a, "initial_variance"_a, "process_variance"_a, "measurement_variance"_a);

    m.def("make_constant_velocity_1d", [](
        double initial_position,
        double initial_velocity,
        double dt,
        double position_variance,
        double velocity_variance,
        double process_position_variance,
        double process_velocity_variance,
        double measurement_variance) {
        return rk::make_constant_velocity_1d(
            initial_position, initial_velocity, dt, position_variance, velocity_variance,
            process_position_variance, process_velocity_variance, measurement_variance);
    }, "initial_position"_a, "initial_velocity"_a, "dt"_a, "position_variance"_a, "velocity_variance"_a,
       "process_position_variance"_a, "process_velocity_variance"_a, "measurement_variance"_a);

    m.def("make_constant_acceleration_1d", [](
        double initial_position,
        double initial_velocity,
        double initial_acceleration,
        double dt,
        double position_variance,
        double velocity_variance,
        double acceleration_variance,
        double process_position_variance,
        double process_velocity_variance,
        double process_acceleration_variance,
        double measurement_variance) {
        return rk::make_constant_acceleration_1d(
            initial_position, initial_velocity, initial_acceleration, dt,
            position_variance, velocity_variance, acceleration_variance,
            process_position_variance, process_velocity_variance,
            process_acceleration_variance, measurement_variance);
    }, "initial_position"_a, "initial_velocity"_a, "initial_acceleration"_a, "dt"_a,
       "position_variance"_a, "velocity_variance"_a, "acceleration_variance"_a,
       "process_position_variance"_a, "process_velocity_variance"_a,
       "process_acceleration_variance"_a, "measurement_variance"_a);
}
