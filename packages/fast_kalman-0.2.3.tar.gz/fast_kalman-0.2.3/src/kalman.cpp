#include <kalman/kalman.hpp>

#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace kalman {

namespace {

Scalar median(std::vector<Scalar> values) {
    if (values.empty()) return 0.0;
    std::sort(values.begin(), values.end());
    const std::size_t mid = values.size() / 2;
    if (values.size() % 2 != 0) return values[mid];
    return 0.5 * (values[mid - 1] + values[mid]);
}

Scalar mean(std::span<const Scalar> values) {
    if (values.empty()) return 0.0;
    Scalar total = 0.0;
    for (const Scalar value : values) total += value;
    return total / static_cast<Scalar>(values.size());
}

Scalar sample_variance(std::span<const Scalar> values) {
    if (values.size() < 2) return 0.0;
    const Scalar mu = mean(values);
    Scalar total = 0.0;
    for (const Scalar value : values) {
        const Scalar centered = value - mu;
        total += centered * centered;
    }
    return total / static_cast<Scalar>(values.size() - 1);
}

Scalar robust_variance(std::span<const Scalar> values) {
    if (values.size() < 2) return 0.0;
    std::vector<Scalar> copy(values.begin(), values.end());
    const Scalar center = median(copy);
    std::vector<Scalar> deviations;
    deviations.reserve(values.size());
    for (const Scalar value : values) deviations.push_back(std::abs(value - center));
    const Scalar mad = median(std::move(deviations));
    const Scalar sigma = 1.4826 * mad;
    if (sigma > 0.0 && std::isfinite(sigma)) return sigma * sigma;
    return sample_variance(values);
}

std::vector<Scalar> difference(std::span<const Scalar> values, std::size_t order = 1) {
    std::vector<Scalar> out(values.begin(), values.end());
    for (std::size_t step = 0; step < order; ++step) {
        std::vector<Scalar> next;
        if (out.size() > 1) next.reserve(out.size() - 1);
        for (std::size_t i = 1; i < out.size(); ++i) next.push_back(out[i] - out[i - 1]);
        out = std::move(next);
    }
    return out;
}

std::vector<Scalar> diagonal(std::span<const Scalar> values, std::size_t rows, std::size_t cols) {
    std::vector<Scalar> out(rows * cols, 0.0);
    const std::size_t n = std::min({values.size(), rows, cols});
    for (std::size_t i = 0; i < n; ++i) out[i * cols + i] = values[i];
    return out;
}

std::vector<Scalar> identity(std::size_t n) {
    std::vector<Scalar> diag(n, 1.0);
    return diagonal(diag, n, n);
}

Scalar floor_variance(Scalar value, Scalar minimum) {
    if (!std::isfinite(value) || value < minimum) return minimum;
    return value;
}

std::vector<std::vector<Scalar>> columns(
    std::span<const Scalar> samples,
    std::size_t sample_count,
    std::size_t nz) {
    std::vector<std::vector<Scalar>> out(nz);
    for (auto& column : out) column.reserve(sample_count);
    for (std::size_t row = 0; row < sample_count; ++row) {
        for (std::size_t col = 0; col < nz; ++col) out[col].push_back(samples[row * nz + col]);
    }
    return out;
}

std::string choose_model(std::string_view model, std::size_t nx, std::size_t nz) {
    if (model != "auto") return std::string(model);
    if (nx == nz) return "random-walk";
    if (nx == 2 * nz) return "constant-velocity";
    if (nx == 3 * nz) return "constant-acceleration";
    return "generic";
}

std::vector<Scalar> measurement_variances(
    const std::vector<std::vector<Scalar>>& series,
    const std::string& model,
    Scalar minimum) {
    std::size_t order = 1;
    if (model == "constant-velocity") {
        order = 2;
    } else if (model == "constant-acceleration") {
        order = 3;
    }

    std::vector<Scalar> variances;
    variances.reserve(series.size());
    for (const auto& values : series) {
        Scalar coeff_energy = order == 1 ? 2.0 : (order == 2 ? 6.0 : 20.0);
        std::vector<Scalar> diffed = difference(values, order);
        if (diffed.size() < 2) {
            diffed = difference(values, 1);
            coeff_energy = 2.0;
        }
        const Scalar estimate = diffed.empty() ? 0.0 : robust_variance(diffed) / coeff_energy;
        const Scalar total = robust_variance(values);
        const Scalar upper = std::max(total * 0.5, minimum);
        variances.push_back(floor_variance(std::min(estimate, upper), minimum));
    }
    return variances;
}

} // namespace

const char* version() noexcept {
    return "kalman/0.2-cpp23";
}

LinearTuningRecommendation linear_recommendation(
    std::span<const Scalar> samples,
    std::size_t sample_count,
    std::size_t nx,
    std::size_t nz,
    Scalar dt,
    std::string_view model,
    Scalar minimum_variance) {
    if (nx == 0 || nz == 0) throw std::invalid_argument("nx and nz must be positive");
    if (sample_count == 0) throw std::invalid_argument("samples must not be empty");
    if (samples.size() != sample_count * nz) {
        throw std::invalid_argument("samples size must equal sample_count * nz");
    }
    if (!(dt > 0.0)) throw std::invalid_argument("dt must be positive");
    if (!(minimum_variance > 0.0)) throw std::invalid_argument("minimum_variance must be positive");

    std::string chosen = choose_model(model, nx, nz);
    const auto series = columns(samples, sample_count, nz);
    const auto r_diag = measurement_variances(series, chosen, minimum_variance);

    std::vector<Scalar> signal_vars;
    signal_vars.reserve(nz);
    for (const auto& values : series) {
        signal_vars.push_back(floor_variance(robust_variance(values), minimum_variance));
    }

    std::vector<Scalar> x0(nx, 0.0);
    std::vector<Scalar> p_diag;
    std::vector<Scalar> q_diag;
    p_diag.reserve(nx);
    q_diag.reserve(nx);

    for (std::size_t i = 0; i < nz; ++i) {
        if (i < nx) x0[i] = series[i][0];
        p_diag.push_back(std::max({signal_vars[i], r_diag[i] * 10.0, minimum_variance}));
    }

    std::vector<Scalar> f;
    if (chosen == "random-walk" && nx == nz) {
        for (std::size_t i = 0; i < nz; ++i) {
            const auto diffed = difference(series[i], 1);
            q_diag.push_back(floor_variance(
                robust_variance(diffed) - 2.0 * r_diag[i],
                std::max(r_diag[i] * 0.01, minimum_variance)));
        }
        f = identity(nx);
    } else if (chosen == "constant-velocity" && nx == 2 * nz) {
        std::vector<Scalar> velocity_vars;
        velocity_vars.reserve(nz);
        for (std::size_t i = 0; i < nz; ++i) {
            auto velocity = difference(series[i], 1);
            for (auto& value : velocity) value /= dt;
            if (!velocity.empty()) {
                velocity.resize(std::min<std::size_t>(8, velocity.size()));
                x0[nz + i] = median(velocity);
            }
            const Scalar velocity_var = floor_variance(
                robust_variance(difference(series[i], 1)) / (dt * dt),
                std::max(r_diag[i] / (dt * dt), minimum_variance));
            velocity_vars.push_back(velocity_var);
            p_diag.push_back(velocity_var);
        }

        std::vector<Scalar> q_pos;
        std::vector<Scalar> q_vel;
        q_pos.reserve(nz);
        q_vel.reserve(nz);
        for (std::size_t i = 0; i < nz; ++i) {
            auto accel = difference(series[i], 2);
            for (auto& value : accel) value /= dt * dt;
            const Scalar drive_var = floor_variance(
                robust_variance(accel) - 6.0 * r_diag[i] / (dt * dt * dt * dt),
                minimum_variance);
            q_pos.push_back(floor_variance(
                0.25 * drive_var * (dt * dt * dt * dt),
                std::max(r_diag[i] * 0.01, minimum_variance)));
            q_vel.push_back(floor_variance(
                drive_var * (dt * dt),
                std::max(velocity_vars[i] * 0.001, minimum_variance)));
        }
        q_diag = q_pos;
        q_diag.insert(q_diag.end(), q_vel.begin(), q_vel.end());

        f = identity(nx);
        for (std::size_t i = 0; i < nz; ++i) f[i * nx + nz + i] = dt;
    } else if (chosen == "constant-acceleration" && nx == 3 * nz) {
        std::vector<Scalar> velocity_vars;
        std::vector<Scalar> accel_vars;
        velocity_vars.reserve(nz);
        accel_vars.reserve(nz);
        for (std::size_t i = 0; i < nz; ++i) {
            auto velocity = difference(series[i], 1);
            for (auto& value : velocity) value /= dt;
            if (!velocity.empty()) {
                velocity.resize(std::min<std::size_t>(8, velocity.size()));
                x0[nz + i] = median(velocity);
            }

            auto accel = difference(series[i], 2);
            for (auto& value : accel) value /= dt * dt;
            if (!accel.empty()) {
                accel.resize(std::min<std::size_t>(8, accel.size()));
                x0[2 * nz + i] = median(accel);
            }

            auto full_velocity = difference(series[i], 1);
            for (auto& value : full_velocity) value /= dt;
            auto full_accel = difference(series[i], 2);
            for (auto& value : full_accel) value /= dt * dt;
            const Scalar velocity_var = floor_variance(
                robust_variance(full_velocity),
                std::max(r_diag[i] / (dt * dt), minimum_variance));
            const Scalar accel_var = floor_variance(robust_variance(full_accel), minimum_variance);
            velocity_vars.push_back(velocity_var);
            accel_vars.push_back(accel_var);
            p_diag.push_back(velocity_var);
        }
        p_diag.insert(p_diag.end(), accel_vars.begin(), accel_vars.end());

        std::vector<Scalar> q_pos;
        std::vector<Scalar> q_vel;
        std::vector<Scalar> q_acc;
        q_pos.reserve(nz);
        q_vel.reserve(nz);
        q_acc.reserve(nz);
        for (std::size_t i = 0; i < nz; ++i) {
            auto jerk = difference(series[i], 3);
            for (auto& value : jerk) value /= dt * dt * dt;
            const Scalar drive_var = floor_variance(
                robust_variance(jerk) - 20.0 * r_diag[i] / (dt * dt * dt * dt * dt * dt),
                minimum_variance);
            q_pos.push_back(floor_variance(
                drive_var * dt * dt * dt * dt * dt * dt / 36.0,
                std::max(r_diag[i] * 0.01, minimum_variance)));
            q_vel.push_back(floor_variance(
                0.25 * drive_var * dt * dt * dt * dt,
                std::max(velocity_vars[i] * 0.001, minimum_variance)));
            q_acc.push_back(floor_variance(
                drive_var * dt * dt,
                std::max(accel_vars[i] * 0.001, minimum_variance)));
        }
        q_diag = q_pos;
        q_diag.insert(q_diag.end(), q_vel.begin(), q_vel.end());
        q_diag.insert(q_diag.end(), q_acc.begin(), q_acc.end());

        f = identity(nx);
        for (std::size_t i = 0; i < nz; ++i) {
            f[i * nx + nz + i] = dt;
            f[i * nx + 2 * nz + i] = 0.5 * dt * dt;
            f[(nz + i) * nx + 2 * nz + i] = dt;
        }
    } else {
        chosen = "generic";
        std::vector<Scalar> diff_vars;
        diff_vars.reserve(nz);
        for (std::size_t i = 0; i < nz; ++i) {
            const auto diffed = difference(series[i], 1);
            diff_vars.push_back(floor_variance(
                robust_variance(diffed) - 2.0 * r_diag[i],
                std::max(r_diag[i] * 0.01, minimum_variance)));
        }

        p_diag.clear();
        q_diag.clear();
        for (std::size_t i = 0; i < nx; ++i) {
            const std::size_t source = std::min(i, nz - 1);
            if (i < nz) x0[i] = samples[i];
            p_diag.push_back(std::max({signal_vars[source], r_diag[source] * 10.0, minimum_variance}));
            q_diag.push_back(std::max(diff_vars[source], r_diag[source] * 0.01));
        }
        f = identity(nx);
    }

    std::vector<Scalar> h(nz * nx, 0.0);
    for (std::size_t i = 0; i < std::min(nx, nz); ++i) h[i * nx + i] = 1.0;

    LinearTuningRecommendation out;
    out.model = std::move(chosen);
    out.x = std::move(x0);
    out.P = diagonal(p_diag, nx, nx);
    out.F = std::move(f);
    out.Q = diagonal(q_diag, nx, nx);
    out.H = std::move(h);
    out.R = diagonal(r_diag, nz, nz);
    out.P_diag = std::move(p_diag);
    out.Q_diag = std::move(q_diag);
    out.R_diag = r_diag;
    return out;
}

} // namespace kalman
