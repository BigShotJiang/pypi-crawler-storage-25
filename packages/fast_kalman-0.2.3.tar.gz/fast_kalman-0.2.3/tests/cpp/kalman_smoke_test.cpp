#include <kalman/kalman.hpp>
#include <iostream>

int main() {
    using namespace kalman;

    auto kf = make_constant_velocity_1d(100.0, 0.0, 1.0, 10.0, 10.0, 1e-4, 1e-3, 0.25);
    for (int i = 0; i < 64; ++i) {
        auto s = kf.update(Vec<1>{100.0 + 0.5 * static_cast<double>(i)});
        if (!s.ok) return 1;
    }

    ExtendedKalmanFilter<2, 1> ekf{};
    ekf.x = Vec<2>{1.0, 0.0};
    ekf.P = Mat<2,2>{1.0, 0.0, 0.0, 1.0};
    ekf.Q = Mat<2,2>{1e-6, 0.0, 0.0, 1e-6};
    ekf.R = Mat<1,1>{0.1};
    auto f = [](const Vec<2>& x) { return Vec<2>{x[0] + x[1], x[1]}; };
    auto fj = [](const Vec<2>&) { return Mat<2,2>{1.0, 1.0, 0.0, 1.0}; };
    auto h = [](const Vec<2>& x) { return Vec<1>{x[0]}; };
    auto hj = [](const Vec<2>&) { return Mat<1,2>{1.0, 0.0}; };
    ekf.predict(f, fj);
    if (!ekf.correct(Vec<1>{1.2}, h, hj).ok) return 2;

    IteratedExtendedKalmanFilter<2,1> iekf{};
    iekf.x = Vec<2>{1.0, 0.0};
    iekf.P = Mat<2,2>{1.0, 0.0, 0.0, 1.0};
    iekf.Q = Mat<2,2>{1e-6, 0.0, 0.0, 1e-6};
    iekf.R = Mat<1,1>{0.1};
    iekf.predict(f, fj);
    if (!iekf.correct(Vec<1>{1.2}, h, hj).ok) return 3;

    UnscentedKalmanFilter<2,1> ukf{};
    ukf.x = Vec<2>{1.0, 0.0};
    ukf.P = Mat<2,2>{1.0, 0.0, 0.0, 1.0};
    ukf.Q = Mat<2,2>{1e-6, 0.0, 0.0, 1e-6};
    ukf.R = Mat<1,1>{0.1};
    if (!ukf.predict(f)) return 4;
    if (!ukf.correct(Vec<1>{1.2}, h).ok) return 5;

    EnsembleKalmanFilter<2,1,8> enkf{};
    for (std::size_t i = 0; i < enkf.members.size(); ++i) {
        enkf.members[i] = Vec<2>{1.0 + 0.01 * static_cast<double>(i), 0.0};
    }
    enkf.recompute_mean_covariance();
    enkf.predict(f);
    if (!enkf.correct_deterministic(Vec<1>{1.2}, h).ok) return 6;

    AdaptiveKalmanFilter<2,1> akf{};
    akf.kf = make_constant_velocity_1d(100.0, 0.0, 1.0, 10.0, 10.0, 1e-4, 1e-3, 0.25);
    if (!akf.update(Vec<1>{101.0}).ok) return 7;

    const std::array<double, 6> samples{10.0, 10.4, 10.9, 11.3, 11.9, 12.4};
    auto tuning = linear_recommendation(samples, samples.size(), 2, 1);
    if (tuning.model != "constant-velocity" || tuning.x.size() != 2 || tuning.P.size() != 4) return 8;

    std::cout << version() << " ok " << kf.x[0] << ' ' << kf.x[1] << '\n';
}
// invariant smoke is intentionally in a separate function to instantiate the template.
int invariant_smoke() {
    using namespace kalman;
    InvariantExtendedKalmanFilter<2,1,Vec<2>> iekf{};
    iekf.state = Vec<2>{1.0, 0.0};
    iekf.P = Mat<2,2>{1.0, 0.0, 0.0, 1.0};
    iekf.Q = Mat<2,2>{1e-6, 0.0, 0.0, 1e-6};
    iekf.R = Mat<1,1>{0.1};
    auto prop = [](const Vec<2>& s) { return Vec<2>{s[0] + s[1], s[1]}; };
    auto err = [](const Vec<2>&, const Vec<2>&) { return Mat<2,2>{1.0, 1.0, 0.0, 1.0}; };
    auto meas = [](const Vec<2>& s) { return Vec<1>{s[0]}; };
    auto hj = [](const Vec<2>&) { return Mat<1,2>{1.0, 0.0}; };
    auto innov = [](const Vec<1>& z, const Vec<1>& zhat) { return z - zhat; };
    auto retract = [](const Vec<2>& s, const Vec<2>& delta) { return s + delta; };
    iekf.predict(prop, err);
    return iekf.correct(Vec<1>{1.1}, meas, hj, innov, retract).ok ? 0 : 1;
}
