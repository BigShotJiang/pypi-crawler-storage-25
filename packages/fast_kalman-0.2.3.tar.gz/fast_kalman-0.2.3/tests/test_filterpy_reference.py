from __future__ import annotations

import math

import numpy as np
import pytest


@pytest.fixture(scope="module")
def filterpy_kalman():
    return pytest.importorskip("filterpy.kalman")


@pytest.fixture(scope="module")
def kalman_module():
    return pytest.importorskip("kalman")


def _make_filterpy(filterpy_kalman, dim_x: int, dim_z: int, x, p, f, q, h, r):
    ref = filterpy_kalman.KalmanFilter(dim_x=dim_x, dim_z=dim_z)
    ref.x = np.asarray(x, dtype=float).reshape(dim_x, 1)
    ref.P = np.asarray(p, dtype=float).reshape(dim_x, dim_x)
    ref.F = np.asarray(f, dtype=float).reshape(dim_x, dim_x)
    ref.Q = np.asarray(q, dtype=float).reshape(dim_x, dim_x)
    ref.H = np.asarray(h, dtype=float).reshape(dim_z, dim_x)
    ref.R = np.asarray(r, dtype=float).reshape(dim_z, dim_z)
    return ref


def _assert_filter_matches(kf, ref, *, atol: float = 1.0e-10) -> None:
    np.testing.assert_allclose(np.asarray(kf.x), ref.x.ravel(), rtol=0.0, atol=atol)
    np.testing.assert_allclose(
        np.asarray(kf.P).reshape(ref.P.shape), ref.P, rtol=0.0, atol=atol
    )


def test_scalar_random_walk_matches_filterpy_step_by_step(kalman_module, filterpy_kalman):
    kf = kalman_module.make_scalar_random_walk(
        initial_value=100.0,
        initial_variance=9.0,
        process_variance=0.03,
        measurement_variance=0.25,
    )
    ref = _make_filterpy(
        filterpy_kalman,
        dim_x=1,
        dim_z=1,
        x=[100.0],
        p=[9.0],
        f=[1.0],
        q=[0.03],
        h=[1.0],
        r=[0.25],
    )

    for measurement in [100.4, 100.1, 99.8, 100.8, 101.2, 100.9]:
        ours = kf.update([measurement])
        ref.predict()
        ref.update(np.asarray([[measurement]], dtype=float))

        assert ours["ok"]
        _assert_filter_matches(kf, ref)
        assert math.isfinite(ours["nis"])


def test_constant_velocity_1d_matches_filterpy_step_by_step(kalman_module, filterpy_kalman):
    kf = kalman_module.make_constant_velocity_1d(
        initial_position=10.0,
        initial_velocity=0.5,
        dt=0.25,
        position_variance=4.0,
        velocity_variance=1.5,
        process_position_variance=0.002,
        process_velocity_variance=0.01,
        measurement_variance=0.09,
    )
    ref = _make_filterpy(
        filterpy_kalman,
        dim_x=2,
        dim_z=1,
        x=[10.0, 0.5],
        p=[4.0, 0.0, 0.0, 1.5],
        f=[1.0, 0.25, 0.0, 1.0],
        q=[0.002, 0.0, 0.0, 0.01],
        h=[1.0, 0.0],
        r=[0.09],
    )

    for measurement in [10.1, 10.4, 10.8, 11.0, 11.3, 11.8, 12.0]:
        ours = kf.update([measurement])
        ref.predict()
        ref.update(np.asarray([[measurement]], dtype=float))

        assert ours["ok"]
        _assert_filter_matches(kf, ref)


def test_linear_filter_with_2d_measurement_matches_filterpy(kalman_module, filterpy_kalman):
    kf = kalman_module.LinearKalmanFilter(4, 2)
    kf.x = [100.0, -20.0, 0.4, 0.1]
    kf.P = [
        5.0, 0.1, 0.0, 0.0,
        0.1, 4.0, 0.0, 0.0,
        0.0, 0.0, 0.5, 0.02,
        0.0, 0.0, 0.02, 0.4,
    ]
    kf.F = [
        1.0, 0.0, 1.0, 0.0,
        0.0, 1.0, 0.0, 1.0,
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0,
    ]
    kf.Q = [
        0.01, 0.0, 0.0, 0.0,
        0.0, 0.02, 0.0, 0.0,
        0.0, 0.0, 0.001, 0.0,
        0.0, 0.0, 0.0, 0.002,
    ]
    kf.H = [
        1.0, 0.0, 0.0, 0.0,
        0.0, 1.0, 0.0, 0.0,
    ]
    kf.R = [0.25, 0.03, 0.03, 0.16]

    ref = _make_filterpy(
        filterpy_kalman,
        dim_x=4,
        dim_z=2,
        x=kf.x,
        p=kf.P,
        f=kf.F,
        q=kf.Q,
        h=kf.H,
        r=kf.R,
    )

    measurements = [
        [100.3, -19.8],
        [100.9, -19.7],
        [101.2, -19.5],
        [101.7, -19.4],
        [102.1, -19.0],
    ]

    for measurement in measurements:
        ours = kf.update(measurement)
        ref.predict()
        ref.update(np.asarray(measurement, dtype=float).reshape(2, 1))

        assert ours["ok"]
        _assert_filter_matches(kf, ref)


def test_update_many_matches_filterpy_repeated_updates(kalman_module, filterpy_kalman):
    kf = kalman_module.LinearKalmanFilter(2, 1)
    kf.x = [2.0, 0.0]
    kf.P = [2.0, 0.0, 0.0, 1.0]
    kf.F = [1.0, 1.0, 0.0, 1.0]
    kf.Q = [0.01, 0.0, 0.0, 0.02]
    kf.H = [1.0, 0.0]
    kf.R = [0.2]

    ref = _make_filterpy(
        filterpy_kalman,
        dim_x=2,
        dim_z=1,
        x=kf.x,
        p=kf.P,
        f=kf.F,
        q=kf.Q,
        h=kf.H,
        r=kf.R,
    )

    measurements = [2.2, 2.7, 3.0, 3.6, 4.1, 4.8]
    result = kf.update_many(measurements)
    for measurement in measurements:
        ref.predict()
        ref.update(np.asarray([[measurement]], dtype=float))

    assert result["ok"]
    assert result["count"] == len(measurements)
    _assert_filter_matches(kf, ref)
    np.testing.assert_allclose(np.asarray(result["x"]), ref.x.ravel(), rtol=0.0, atol=1.0e-10)
