from __future__ import annotations

import math

import pytest


@pytest.fixture(scope="module")
def kalman_module():
    return pytest.importorskip("kalman")


def _series(offset: float = 0.0):
    return [offset + 10.0, offset + 10.4, offset + 10.9, offset + 11.3, offset + 11.9, offset + 12.4]


def _linear_transition(x):
    return x


def _linear_jacobian(_x):
    return [1.0, 0.0, 0.0, 1.0]


def _linear_measurement(x):
    return [x[0]]


def _linear_measurement_jacobian(_x):
    return [1.0, 0.0]


def test_linear_tuner_returns_constructor_ordered_namedtuple(kalman_module):
    tuner = kalman_module.LinearKalmanTuner(2, 1, dt=1.0)

    first = tuner.update(_series())
    first.x[0] = -999.0
    second = tuner.update(_series(20.0))

    assert first._fields == ("nx", "nz", "x", "P", "F", "Q", "H", "R")
    assert tuner.count == 2
    assert second.x[0] > 0.0
    assert second.x[0] != first.x[0]

    kf = kalman_module.LinearKalmanFilter(*second)
    assert list(kf.x) == pytest.approx(second.x)
    assert list(kf.F) == pytest.approx(second.F)
    assert kf.update([second.x[0] + 0.25])["ok"]


def test_nonlinear_tuners_splat_into_python_filter_wrappers(kalman_module):
    data = _series()

    ekf_params = kalman_module.ExtendedKalmanTuner(2, 1).update(data)
    ekf = kalman_module.ExtendedKalmanFilter(*ekf_params)
    ekf.predict(_linear_transition, _linear_jacobian)
    assert ekf.correct([data[-1]], _linear_measurement, _linear_measurement_jacobian)["ok"]

    iterated_params = kalman_module.IteratedExtendedKalmanTuner(2, 1).update(data)
    iterated = kalman_module.IteratedExtendedKalmanFilter(*iterated_params)
    iterated.predict(_linear_transition, _linear_jacobian)
    assert iterated.correct([data[-1]], _linear_measurement, _linear_measurement_jacobian)["ok"]

    ukf_params = kalman_module.UnscentedKalmanTuner(2, 1).update(data)
    ukf = kalman_module.UnscentedKalmanFilter(*ukf_params)
    assert math.isclose(ukf.alpha, ukf_params.alpha)
    assert ukf.update_many([data[-2], data[-1]], _linear_transition, _linear_measurement)["ok"]


def test_ensemble_tuner_initializes_members_and_measurement_noise(kalman_module):
    params = kalman_module.EnsembleKalmanTuner(2, 1, ensemble_size=8).update(_series())

    assert params._fields == ("nx", "nz", "ensemble_size", "members", "R")
    assert len(params.members) == 8
    assert all(len(member) == 2 for member in params.members)

    enkf = kalman_module.EnsembleKalmanFilter(*params)
    assert len(enkf.members) == 8
    assert list(enkf.R) == pytest.approx(params.R)


def test_range_bearing_tuner_splat_initializes_compiled_model(kalman_module):
    measurements = [
        [5.0, 0.20],
        [5.2, 0.22],
        [5.3, 0.24],
        [5.5, 0.25],
    ]
    params = kalman_module.RangeBearingEKF2DTuner(4, 2, dt=0.5, landmark_x=1.0, landmark_y=-2.0).update(measurements)

    assert params._fields == ("dt", "landmark_x", "landmark_y", "x", "P", "Q", "R")
    rb = kalman_module.RangeBearingEKF2D(*params)
    assert rb.dt == pytest.approx(0.5)
    assert rb.landmark_x == pytest.approx(1.0)
    assert rb.landmark_y == pytest.approx(-2.0)
    assert rb.update(measurements[-1])["ok"]


def test_adaptive_filter_is_not_given_an_external_tuner(kalman_module):
    assert not hasattr(kalman_module, "AdaptiveKalmanTuner")
