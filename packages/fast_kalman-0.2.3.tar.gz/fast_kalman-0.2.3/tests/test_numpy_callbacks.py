from __future__ import annotations

import pytest


@pytest.fixture(scope="module")
def np():
    return pytest.importorskip("numpy")


@pytest.fixture(scope="module")
def kalman_module():
    return pytest.importorskip("kalman")


def test_ekf_numpy_callback_abi_and_update_many(kalman_module, np):
    f = np.asarray([[1.0, 1.0], [0.0, 1.0]], dtype=np.float64)
    h = np.asarray([[1.0, 0.0]], dtype=np.float64)
    seen = []

    def transition(x):
        assert isinstance(x, np.ndarray)
        seen.append(x.shape)
        return f @ x

    def transition_jacobian(x):
        assert isinstance(x, np.ndarray)
        return f

    def measurement(x):
        assert isinstance(x, np.ndarray)
        return h @ x

    def measurement_jacobian(x):
        assert isinstance(x, np.ndarray)
        return h

    ekf = kalman_module.ExtendedKalmanFilter(2, 1)
    ekf.x = np.asarray([1.0, 0.0], dtype=np.float64)
    ekf.P = np.eye(2, dtype=np.float64).reshape(-1)
    ekf.Q = (np.eye(2, dtype=np.float64) * 1e-6).reshape(-1)
    ekf.R = np.asarray([0.1], dtype=np.float64)

    result = ekf.update_many(
        np.asarray([[1.2], [1.3], [1.4]], dtype=np.float64),
        transition,
        transition_jacobian,
        measurement,
        measurement_jacobian,
    )

    assert result["ok"]
    assert result["count"] == 3
    assert seen


def test_ukf_batched_sigma_callbacks(kalman_module, np):
    f = np.asarray([[1.0, 1.0], [0.0, 1.0]], dtype=np.float64)
    h = np.asarray([[1.0, 0.0]], dtype=np.float64)

    def transition_batch(sigma):
        assert isinstance(sigma, np.ndarray)
        assert sigma.ndim == 2
        return sigma @ f.T

    def measurement_batch(sigma):
        assert isinstance(sigma, np.ndarray)
        assert sigma.ndim == 2
        return sigma @ h.T

    ukf = kalman_module.UnscentedKalmanFilter(2, 1)
    ukf.x = np.asarray([1.0, 0.0], dtype=np.float64)
    ukf.P = np.eye(2, dtype=np.float64).reshape(-1)
    ukf.R = np.asarray([0.1], dtype=np.float64)

    result = ukf.update_many_batch(
        np.asarray([[1.2], [1.3]], dtype=np.float64),
        transition_batch,
        measurement_batch,
    )

    assert result["ok"]
    assert result["count"] == 2


def test_enkf_batched_member_callbacks(kalman_module, np):
    f = np.asarray([[1.0, 1.0], [0.0, 1.0]], dtype=np.float64)
    h = np.asarray([[1.0, 0.0]], dtype=np.float64)

    def transition_batch(members):
        assert isinstance(members, np.ndarray)
        assert members.shape == (8, 2)
        return members @ f.T

    def measurement_batch(members):
        assert isinstance(members, np.ndarray)
        assert members.shape == (8, 2)
        return members @ h.T

    enkf = kalman_module.EnsembleKalmanFilter(2, 1)
    enkf.members = np.asarray([[1.0 + i * 0.01, 0.0] for i in range(8)], dtype=np.float64)
    enkf.recompute_mean_covariance()

    result = enkf.update_many_batch(
        np.asarray([[1.2], [1.3]], dtype=np.float64),
        transition_batch,
        measurement_batch,
    )

    assert result["ok"]
    assert result["count"] == 2


def test_range_bearing_ekf2d_compiled_model(kalman_module, np):
    rb = kalman_module.RangeBearingEKF2D()
    rb.x = np.asarray([1.0, 1.0, 0.1, 0.0], dtype=np.float64)
    rb.P = np.eye(4, dtype=np.float64).reshape(-1)
    rb.Q = (np.eye(4, dtype=np.float64) * 1e-3).reshape(-1)
    rb.R = (np.eye(2, dtype=np.float64) * 0.1).reshape(-1)

    result = rb.update_many(np.asarray([[1.5, 0.8], [1.6, 0.75]], dtype=np.float64))

    assert result["ok"]
    assert result["count"] == 2
