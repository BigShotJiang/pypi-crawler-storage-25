#!/usr/bin/env python3
"""Generate, build, and run C++ core benchmarks.

This measures the direct C++ template API, including InvariantExtendedKalmanFilter
which is intentionally not exposed through the Python module.
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path


CPP_SOURCE = r"""
#include <kalman/kalman.hpp>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <utility>
#include <vector>

#ifdef KALMAN_BENCH_HAVE_OPENCV
#include <opencv2/video/tracking.hpp>
#endif

using Clock = std::chrono::steady_clock;
volatile double g_sink = 0.0;

struct Result {
    std::string name;
    std::string implementation;
    std::size_t iterations;
    double best_ms;
    double median_ms;
    double ns_per_update;
};

template <std::size_t NX>
kalman::Mat<NX, NX> make_transition() {
    auto f = kalman::Mat<NX, NX>::identity();
    for (std::size_t i = 0; i + 1 < NX; ++i) f(i, i + 1) = 0.05;
    return f;
}

template <std::size_t NX, std::size_t NZ>
kalman::Mat<NZ, NX> make_measurement() {
    kalman::Mat<NZ, NX> h{};
    for (std::size_t i = 0; i < std::min(NX, NZ); ++i) h(i, i) = 1.0;
    return h;
}

template <std::size_t N>
kalman::Mat<N, N> make_diag(double base, double step) {
    kalman::Mat<N, N> out{};
    for (std::size_t i = 0; i < N; ++i) out(i, i) = base + step * static_cast<double>(i);
    return out;
}

template <std::size_t NZ>
std::vector<kalman::Vec<NZ>> make_measurements(std::size_t count) {
    std::vector<kalman::Vec<NZ>> out;
    out.reserve(count);
    for (std::size_t i = 0; i < count; ++i) {
        kalman::Vec<NZ> z{};
        for (std::size_t j = 0; j < NZ; ++j) {
            z[j] = 1.0 + 0.03 * static_cast<double>(i) + 0.2 * static_cast<double>(j)
                 + 0.01 * std::sin(0.17 * static_cast<double>(i) + static_cast<double>(j));
        }
        out.push_back(z);
    }
    return out;
}

template <std::size_t NX, std::size_t NZ>
kalman::LinearKalmanFilter<NX, NZ> make_linear_filter() {
    kalman::LinearKalmanFilter<NX, NZ> kf{};
    for (std::size_t i = 0; i < NX; ++i) kf.x[i] = 0.25 * static_cast<double>(i + 1);
    kf.P = make_diag<NX>(2.0, 0.2);
    kf.F = make_transition<NX>();
    kf.Q = make_diag<NX>(0.01, 0.001);
    kf.H = make_measurement<NX, NZ>();
    kf.R = make_diag<NZ>(0.25, 0.02);
    return kf;
}

template <class Setup>
Result run_benchmark(const std::string& name,
                     const std::string& implementation,
                     Setup&& setup,
                     std::size_t iterations,
                     std::size_t warmup,
                     std::size_t repeats) {
    std::vector<double> timings_ms;
    timings_ms.reserve(repeats);
    for (std::size_t repeat = 0; repeat < repeats; ++repeat) {
        auto step = setup();
        for (std::size_t i = 0; i < warmup; ++i) g_sink += step() * 1.0e-300;

        const auto start = Clock::now();
        for (std::size_t i = 0; i < iterations; ++i) g_sink += step() * 1.0e-300;
        const auto stop = Clock::now();
        const double ms = std::chrono::duration<double, std::milli>(stop - start).count();
        timings_ms.push_back(ms);
    }

    std::sort(timings_ms.begin(), timings_ms.end());
    const double best_ms = timings_ms.front();
    const double median_ms = timings_ms[timings_ms.size() / 2];
    return Result{
        name,
        implementation,
        iterations,
        best_ms,
        median_ms,
        best_ms * 1.0e6 / static_cast<double>(iterations),
    };
}

template <std::size_t NX, std::size_t NZ>
std::vector<Result> run_all(std::size_t iterations,
                            std::size_t warmup,
                            std::size_t repeats,
                            std::size_t measurement_count,
                            std::size_t iekf_iterations) {
    const auto zs = make_measurements<NZ>(measurement_count);
    const auto F = make_transition<NX>();
    const auto H = make_measurement<NX, NZ>();

    auto transition = [F](const kalman::Vec<NX>& x) { return F * x; };
    auto transition_jacobian = [F](const kalman::Vec<NX>&) { return F; };
    auto measurement = [H](const kalman::Vec<NX>& x) { return H * x; };
    auto measurement_jacobian = [H](const kalman::Vec<NX>&) { return H; };

    std::vector<Result> results;

    results.push_back(run_benchmark(
        "linear_update", "kalman::LinearKalmanFilter",
        [&] {
            auto kf = make_linear_filter<NX, NZ>();
            std::size_t i = 0;
            return [kf, i, &zs]() mutable {
                auto stats = kf.update(zs[i % zs.size()]);
                ++i;
                return stats.ok ? kf.x[0] : -1.0;
            };
        },
        iterations, warmup, repeats));

#ifdef KALMAN_BENCH_HAVE_OPENCV
    results.push_back(run_benchmark(
        "linear_update", "cv::KalmanFilter",
        [&] {
            cv::KalmanFilter kf(static_cast<int>(NX), static_cast<int>(NZ), 0, CV_64F);
            const auto P = make_diag<NX>(2.0, 0.2);
            const auto Fm = make_transition<NX>();
            const auto Q = make_diag<NX>(0.01, 0.001);
            const auto Hm = make_measurement<NX, NZ>();
            const auto R = make_diag<NZ>(0.25, 0.02);
            for (std::size_t r = 0; r < NX; ++r) {
                kf.statePost.at<double>(static_cast<int>(r), 0) = 0.25 * static_cast<double>(r + 1);
                for (std::size_t c = 0; c < NX; ++c) {
                    kf.errorCovPost.at<double>(static_cast<int>(r), static_cast<int>(c)) = P(r, c);
                    kf.transitionMatrix.at<double>(static_cast<int>(r), static_cast<int>(c)) = Fm(r, c);
                    kf.processNoiseCov.at<double>(static_cast<int>(r), static_cast<int>(c)) = Q(r, c);
                }
            }
            for (std::size_t r = 0; r < NZ; ++r) {
                for (std::size_t c = 0; c < NX; ++c) {
                    kf.measurementMatrix.at<double>(static_cast<int>(r), static_cast<int>(c)) = Hm(r, c);
                }
                for (std::size_t c = 0; c < NZ; ++c) {
                    kf.measurementNoiseCov.at<double>(static_cast<int>(r), static_cast<int>(c)) = R(r, c);
                }
            }
            cv::Mat z(static_cast<int>(NZ), 1, CV_64F);
            std::size_t i = 0;
            return [kf, z, i, &zs]() mutable {
                const auto& src = zs[i % zs.size()];
                for (std::size_t r = 0; r < NZ; ++r) z.at<double>(static_cast<int>(r), 0) = src[r];
                kf.predict();
                const auto corrected = kf.correct(z);
                ++i;
                return corrected.at<double>(0, 0);
            };
        },
        iterations, warmup, repeats));
#endif

    if constexpr (NZ == 1) {
        results.push_back(run_benchmark(
            "linear_correct_scalar", "kalman::LinearKalmanFilter",
            [&] {
                auto kf = make_linear_filter<NX, NZ>();
                kalman::Vec<NX> h{};
                h[0] = 1.0;
                std::size_t i = 0;
                return [kf, h, i, &zs]() mutable {
                    kf.predict();
                    auto stats = kf.correct_scalar(zs[i % zs.size()][0], h, 0.25);
                    ++i;
                    return stats.ok ? kf.x[0] : -1.0;
                };
            },
            iterations, warmup, repeats));
    }

    results.push_back(run_benchmark(
        "ekf_predict_correct", "kalman::ExtendedKalmanFilter",
        [&] {
            kalman::ExtendedKalmanFilter<NX, NZ> kf{};
            for (std::size_t i = 0; i < NX; ++i) kf.x[i] = 0.25 * static_cast<double>(i + 1);
            kf.P = make_diag<NX>(2.0, 0.2);
            kf.Q = make_diag<NX>(0.01, 0.001);
            kf.R = make_diag<NZ>(0.25, 0.02);
            std::size_t i = 0;
            return [kf, i, &zs, transition, transition_jacobian, measurement, measurement_jacobian]() mutable {
                kf.predict(transition, transition_jacobian);
                auto stats = kf.correct(zs[i % zs.size()], measurement, measurement_jacobian);
                ++i;
                return stats.ok ? kf.x[0] : -1.0;
            };
        },
        iterations, warmup, repeats));

    results.push_back(run_benchmark(
        "iterated_ekf_predict_correct", "kalman::IteratedExtendedKalmanFilter",
        [&] {
            kalman::IteratedExtendedKalmanFilter<NX, NZ> kf{};
            for (std::size_t i = 0; i < NX; ++i) kf.x[i] = 0.25 * static_cast<double>(i + 1);
            kf.P = make_diag<NX>(2.0, 0.2);
            kf.Q = make_diag<NX>(0.01, 0.001);
            kf.R = make_diag<NZ>(0.25, 0.02);
            std::size_t i = 0;
            return [kf, i, &zs, transition, transition_jacobian, measurement, measurement_jacobian, iekf_iterations]() mutable {
                kf.predict(transition, transition_jacobian);
                auto stats = kf.correct(zs[i % zs.size()], measurement, measurement_jacobian, iekf_iterations);
                ++i;
                return stats.ok ? kf.x[0] : -1.0;
            };
        },
        iterations, warmup, repeats));

    results.push_back(run_benchmark(
        "ukf_predict_correct", "kalman::UnscentedKalmanFilter",
        [&] {
            kalman::UnscentedKalmanFilter<NX, NZ> kf{};
            for (std::size_t i = 0; i < NX; ++i) kf.x[i] = 0.25 * static_cast<double>(i + 1);
            kf.P = make_diag<NX>(2.0, 0.2);
            kf.Q = make_diag<NX>(0.01, 0.001);
            kf.R = make_diag<NZ>(0.25, 0.02);
            kf.params.alpha = 0.5;
            std::size_t i = 0;
            return [kf, i, &zs, transition, measurement]() mutable {
                const bool predicted = kf.predict(transition);
                auto stats = kf.correct(zs[i % zs.size()], measurement);
                ++i;
                return (predicted && stats.ok) ? kf.x[0] : -1.0;
            };
        },
        iterations, warmup, repeats));

    results.push_back(run_benchmark(
        "invariant_ekf_predict_correct", "kalman::InvariantExtendedKalmanFilter",
        [&] {
            kalman::InvariantExtendedKalmanFilter<NX, NZ, kalman::Vec<NX>> kf{};
            for (std::size_t i = 0; i < NX; ++i) kf.state[i] = 0.25 * static_cast<double>(i + 1);
            kf.P = make_diag<NX>(2.0, 0.2);
            kf.Q = make_diag<NX>(0.01, 0.001);
            kf.R = make_diag<NZ>(0.25, 0.02);
            auto propagate = [F](const kalman::Vec<NX>& state) { return F * state; };
            auto error_transition = [F](const kalman::Vec<NX>&, const kalman::Vec<NX>&) { return F; };
            auto innovation = [](const kalman::Vec<NZ>& z, const kalman::Vec<NZ>& zhat) { return z - zhat; };
            auto retract = [](const kalman::Vec<NX>& state, const kalman::Vec<NX>& delta) { return state + delta; };
            std::size_t i = 0;
            return [kf, i, &zs, propagate, error_transition, measurement, measurement_jacobian, innovation, retract]() mutable {
                kf.predict(propagate, error_transition);
                auto stats = kf.correct(zs[i % zs.size()], measurement, measurement_jacobian, innovation, retract);
                ++i;
                return stats.ok ? kf.state[0] : -1.0;
            };
        },
        iterations, warmup, repeats));

    results.push_back(run_benchmark(
        "enkf_predict_correct", "kalman::EnsembleKalmanFilter<...,8>",
        [&] {
            kalman::EnsembleKalmanFilter<NX, NZ, 8> kf{};
            for (std::size_t member = 0; member < kf.members.size(); ++member) {
                for (std::size_t i = 0; i < NX; ++i) {
                    kf.members[member][i] = 0.25 * static_cast<double>(i + 1) + 0.01 * static_cast<double>(member);
                }
            }
            kf.R = make_diag<NZ>(0.25, 0.02);
            kf.recompute_mean_covariance();
            std::size_t i = 0;
            return [kf, i, &zs, transition, measurement]() mutable {
                kf.predict(transition);
                auto stats = kf.correct_deterministic(zs[i % zs.size()], measurement);
                ++i;
                return stats.ok ? kf.x[0] : -1.0;
            };
        },
        iterations, warmup, repeats));

    results.push_back(run_benchmark(
        "adaptive_update", "kalman::AdaptiveKalmanFilter",
        [&] {
            kalman::AdaptiveKalmanFilter<NX, NZ> kf{};
            kf.kf = make_linear_filter<NX, NZ>();
            kf.options.forgetting = 0.98;
            std::size_t i = 0;
            return [kf, i, &zs]() mutable {
                auto stats = kf.update(zs[i % zs.size()]);
                ++i;
                return stats.ok ? kf.kf.x[0] : -1.0;
            };
        },
        iterations, warmup, repeats));

    return results;
}

int main() {
    constexpr std::size_t NX = @NX@;
    constexpr std::size_t NZ = @NZ@;
    const std::size_t iterations = @ITERATIONS@;
    const std::size_t warmup = @WARMUP@;
    const std::size_t repeats = @REPEATS@;
    const std::size_t measurement_count = @MEASUREMENTS@;
    const std::size_t iekf_iterations = @IEKF_ITERATIONS@;

    auto results = run_all<NX, NZ>(iterations, warmup, repeats, measurement_count, iekf_iterations);
    std::cout << "name,implementation,best_ms,median_ms,ns_per_update,iterations\n";
    std::cout << std::fixed << std::setprecision(3);
    for (const auto& result : results) {
        std::cout << result.name << ','
                  << result.implementation << ','
                  << result.best_ms << ','
                  << result.median_ms << ','
                  << result.ns_per_update << ','
                  << result.iterations << '\n';
    }
#ifndef KALMAN_BENCH_HAVE_OPENCV
    std::cout << "linear_update,cv::KalmanFilter,SKIPPED,SKIPPED,SKIPPED,0\n";
#endif
    if (g_sink == std::numeric_limits<double>::infinity()) std::cerr << g_sink << '\n';
    return 0;
}
"""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build and run direct C++ kalman core benchmarks.")
    parser.add_argument("--nx", type=int, default=2, help="State dimension")
    parser.add_argument("--nz", type=int, default=1, help="Measurement dimension")
    parser.add_argument("--iterations", type=int, default=200_000)
    parser.add_argument("--warmup", type=int, default=5_000)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--measurements", type=int, default=256)
    parser.add_argument("--iekf-iterations", type=int, default=3)
    parser.add_argument("--build-dir", type=Path, default=None)
    parser.add_argument("--cxx", default=os.environ.get("CXX", "c++"))
    parser.add_argument(
        "--opencv",
        choices=["auto", "always", "never"],
        default="auto",
        help="Use native C++ OpenCV cv::KalmanFilter competitor when pkg-config opencv4 is available",
    )
    parser.add_argument("--keep", action="store_true", help="Keep generated source and binary")
    return parser


def render_source(args: argparse.Namespace) -> str:
    if args.nx <= 0 or args.nz <= 0:
        raise SystemExit("error: --nx and --nz must be positive")
    replacements = {
        "@NX@": str(args.nx),
        "@NZ@": str(args.nz),
        "@ITERATIONS@": str(args.iterations),
        "@WARMUP@": str(args.warmup),
        "@REPEATS@": str(args.repeats),
        "@MEASUREMENTS@": str(args.measurements),
        "@IEKF_ITERATIONS@": str(args.iekf_iterations),
    }
    source = CPP_SOURCE
    for key, value in replacements.items():
        source = source.replace(key, value)
    return textwrap.dedent(source)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    repo_root = Path(__file__).resolve().parents[1]
    temp_dir: Path | None = None
    if args.build_dir is None:
        temp_dir = Path(tempfile.mkdtemp(prefix="kalman-cpp-bench-"))
        build_dir = temp_dir
    else:
        build_dir = args.build_dir
        build_dir.mkdir(parents=True, exist_ok=True)

    source_path = build_dir / "benchmark_cpp_core.cpp"
    binary_path = build_dir / "benchmark_cpp_core"
    source_path.write_text(render_source(args), encoding="utf-8")

    compile_cmd = [
        args.cxx,
        "-std=c++23",
        "-O3",
        "-DNDEBUG",
        "-I",
        str(repo_root / "include"),
    ]
    link_flags: list[str] = []
    if args.opencv != "never":
        pkg_config = shutil.which("pkg-config")
        opencv_cflags: list[str] = []
        opencv_libs: list[str] = []
        if pkg_config is not None:
            probe = subprocess.run(
                [pkg_config, "--exists", "opencv4"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            if probe.returncode == 0:
                opencv_cflags = subprocess.check_output([pkg_config, "--cflags", "opencv4"], text=True).split()
                opencv_libs = subprocess.check_output([pkg_config, "--libs", "opencv4"], text=True).split()
        if args.opencv == "always" and not opencv_cflags and not opencv_libs:
            raise SystemExit("error: --opencv always requested, but pkg-config opencv4 was not found")
        if opencv_cflags or opencv_libs:
            compile_cmd.extend(["-DKALMAN_BENCH_HAVE_OPENCV", "-Wno-deprecated-enum-enum-conversion", *opencv_cflags])
            link_flags.extend(opencv_libs)
    compile_cmd.extend([str(source_path), "-o", str(binary_path), *link_flags])
    subprocess.run(compile_cmd, check=True)
    subprocess.run([str(binary_path)], check=True)

    if temp_dir is not None and not args.keep:
        shutil.rmtree(temp_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
