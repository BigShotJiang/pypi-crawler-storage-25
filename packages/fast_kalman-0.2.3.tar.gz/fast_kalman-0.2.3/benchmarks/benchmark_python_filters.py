#!/usr/bin/env python3
"""Benchmark the nanobind Python API.

OpenCV's cv2.KalmanFilter is used as the C++-backed competitor for matching
linear Kalman predict/correct workloads. The nonlinear, adaptive, and ensemble
benchmarks run this package in isolation because OpenCV does not provide those
algorithms through a comparable Python API.
"""

from __future__ import annotations

import argparse
import gc
import importlib
import json
import math
import statistics
import sys
import time
from dataclasses import asdict, dataclass
from typing import Callable


@dataclass
class BenchmarkResult:
    name: str
    implementation: str
    compared_with: str | None
    iterations: int
    logical_updates: int
    best_ms: float
    median_ms: float
    ns_per_update: float
    updates_per_second: float
    notes: str


@dataclass
class SkippedResult:
    name: str
    implementation: str
    compared_with: str | None
    skipped: str


def identity(n: int) -> list[float]:
    out = [0.0] * (n * n)
    for i in range(n):
        out[i * n + i] = 1.0
    return out


def diag(values: list[float], rows: int, cols: int) -> list[float]:
    out = [0.0] * (rows * cols)
    for i, value in enumerate(values[: min(rows, cols)]):
        out[i * cols + i] = value
    return out


def transition_matrix(nx: int) -> list[float]:
    f = identity(nx)
    for i in range(nx - 1):
        f[i * nx + i + 1] = 0.05
    return f


def measurement_matrix(nx: int, nz: int) -> list[float]:
    h = [0.0] * (nz * nx)
    for i in range(min(nx, nz)):
        h[i * nx + i] = 1.0
    return h


def measurements(nz: int, count: int) -> list[list[float]]:
    out: list[list[float]] = []
    for i in range(count):
        row = []
        for j in range(nz):
            row.append(1.0 + 0.03 * i + 0.2 * j + 0.01 * math.sin(i * 0.17 + j))
        out.append(row)
    return out


def flattened(rows: list[list[float]]) -> list[float]:
    return [value for row in rows for value in row]


def configure_linear(kalman, nx: int, nz: int):
    kf = kalman.LinearKalmanFilter(nx, nz)
    kf.x = [0.25 * (i + 1) for i in range(nx)]
    kf.P = diag([2.0 + 0.2 * i for i in range(nx)], nx, nx)
    kf.F = transition_matrix(nx)
    kf.Q = diag([0.01 + 0.001 * i for i in range(nx)], nx, nx)
    kf.H = measurement_matrix(nx, nz)
    kf.R = diag([0.25 + 0.02 * i for i in range(nz)], nz, nz)
    return kf


def configure_adaptive(kalman, nx: int, nz: int):
    kf = kalman.AdaptiveKalmanFilter(nx, nz)
    kf.x = [0.25 * (i + 1) for i in range(nx)]
    kf.P = diag([2.0 + 0.2 * i for i in range(nx)], nx, nx)
    kf.F = transition_matrix(nx)
    kf.Q = diag([0.01 + 0.001 * i for i in range(nx)], nx, nx)
    kf.H = measurement_matrix(nx, nz)
    kf.R = diag([0.25 + 0.02 * i for i in range(nz)], nz, nz)
    kf.forgetting = 0.98
    return kf


def configure_ekf_like(kalman, cls_name: str, nx: int, nz: int):
    kf = getattr(kalman, cls_name)(nx, nz)
    kf.x = [0.25 * (i + 1) for i in range(nx)]
    kf.P = diag([2.0 + 0.2 * i for i in range(nx)], nx, nx)
    kf.Q = diag([0.01 + 0.001 * i for i in range(nx)], nx, nx)
    kf.R = diag([0.25 + 0.02 * i for i in range(nz)], nz, nz)
    return kf


def configure_enkf(kalman, nx: int, nz: int):
    kf = kalman.EnsembleKalmanFilter(nx, nz, 8)
    kf.members = [
        [0.25 * (j + 1) + 0.01 * i for j in range(nx)]
        for i in range(8)
    ]
    kf.R = diag([0.25 + 0.02 * i for i in range(nz)], nz, nz)
    kf.recompute_mean_covariance()
    return kf


def make_callbacks(np, nx: int, nz: int):
    f = np.asarray(transition_matrix(nx), dtype=np.float64).reshape(nx, nx)
    h = np.asarray(measurement_matrix(nx, nz), dtype=np.float64).reshape(nz, nx)

    def transition(x):
        return f @ x

    def transition_jacobian(_x):
        return f

    def measurement_fn(x):
        return h @ x

    def measurement_jacobian(_x):
        return h

    def transition_batch(x):
        return x @ f.T

    def measurement_batch(x):
        return x @ h.T

    return transition, transition_jacobian, measurement_fn, measurement_jacobian, transition_batch, measurement_batch


def time_workload(
    name: str,
    implementation: str,
    compared_with: str | None,
    setup: Callable[[], Callable[[], None]],
    iterations: int,
    logical_updates_per_iteration: int,
    warmup: int,
    repeats: int,
    notes: str,
) -> BenchmarkResult:
    timings: list[float] = []
    for _ in range(repeats):
        step = setup()
        for _ in range(warmup):
            step()

        gc_was_enabled = gc.isenabled()
        gc.disable()
        start = time.perf_counter_ns()
        for _ in range(iterations):
            step()
        elapsed_ns = time.perf_counter_ns() - start
        if gc_was_enabled:
            gc.enable()
        timings.append(elapsed_ns / 1.0e6)

    best_ms = min(timings)
    median_ms = statistics.median(timings)
    logical_updates = iterations * logical_updates_per_iteration
    ns_per_update = (best_ms * 1.0e6) / logical_updates
    return BenchmarkResult(
        name=name,
        implementation=implementation,
        compared_with=compared_with,
        iterations=iterations,
        logical_updates=logical_updates,
        best_ms=best_ms,
        median_ms=median_ms,
        ns_per_update=ns_per_update,
        updates_per_second=1.0e9 / ns_per_update,
        notes=notes,
    )


def open_cv_setup(nx: int, nz: int, zs: list[list[float]]):
    try:
        cv2 = importlib.import_module("cv2")
        np = importlib.import_module("numpy")
    except ImportError as exc:
        return None, f"OpenCV competitor skipped: {exc}"

    def setup():
        try:
            cv_kf = cv2.KalmanFilter(nx, nz, 0, cv2.CV_64F)
        except TypeError:
            cv_kf = cv2.KalmanFilter(nx, nz)

        cv_kf.statePost = np.asarray([0.25 * (i + 1) for i in range(nx)], dtype=np.float64).reshape(nx, 1)
        cv_kf.errorCovPost = np.asarray(diag([2.0 + 0.2 * i for i in range(nx)], nx, nx), dtype=np.float64).reshape(nx, nx)
        cv_kf.transitionMatrix = np.asarray(transition_matrix(nx), dtype=np.float64).reshape(nx, nx)
        cv_kf.processNoiseCov = np.asarray(diag([0.01 + 0.001 * i for i in range(nx)], nx, nx), dtype=np.float64).reshape(nx, nx)
        cv_kf.measurementMatrix = np.asarray(measurement_matrix(nx, nz), dtype=np.float64).reshape(nz, nx)
        cv_kf.measurementNoiseCov = np.asarray(diag([0.25 + 0.02 * i for i in range(nz)], nz, nz), dtype=np.float64).reshape(nz, nz)
        measurements_np = [np.asarray(z, dtype=np.float64).reshape(nz, 1) for z in zs]
        index = 0

        def step() -> None:
            nonlocal index
            cv_kf.predict()
            cv_kf.correct(measurements_np[index % len(measurements_np)])
            index += 1

        return step

    return setup, ""


def build_results(args) -> list[BenchmarkResult | SkippedResult]:
    try:
        kalman = importlib.import_module("kalman")
    except ImportError as exc:
        raise SystemExit(f"error: import kalman failed; install the wheel or set PYTHONPATH: {exc}") from exc
    try:
        np = importlib.import_module("numpy")
    except ImportError as exc:
        raise SystemExit(f"error: import numpy failed; install the benchmark extra: {exc}") from exc

    if args.nx < 1 or args.nx > 8 or args.nz < 1 or args.nz > 8:
        raise SystemExit("error: --nx and --nz must be in [1, 8]")

    zs = measurements(args.nz, max(args.measurements, 8))
    zs_np = np.asarray(zs, dtype=np.float64)
    transition, transition_jacobian, measurement_fn, measurement_jacobian, transition_batch, measurement_batch = make_callbacks(np, args.nx, args.nz)
    results: list[BenchmarkResult | SkippedResult] = []

    def linear_update_setup():
        kf = configure_linear(kalman, args.nx, args.nz)
        index = 0

        def step() -> None:
            nonlocal index
            kf.update(zs_np[index % len(zs_np)])
            index += 1

        return step

    results.append(time_workload(
        "linear_update",
        "kalman.LinearKalmanFilter",
        "cv2.KalmanFilter",
        linear_update_setup,
        args.iterations,
        1,
        args.warmup,
        args.repeats,
        "Python API single predict+correct call.",
    ))

    batch_size = len(zs)

    def linear_update_many_setup():
        kf = configure_linear(kalman, args.nx, args.nz)

        def step() -> None:
            kf.update_many(zs_np)

        return step

    results.append(time_workload(
        "linear_update_many",
        "kalman.LinearKalmanFilter",
        None,
        linear_update_many_setup,
        max(1, args.batch_iterations),
        batch_size,
        max(1, args.warmup // batch_size),
        args.repeats,
        "Batch path runs many updates inside C++ per Python call.",
    ))

    cv_setup, cv_skip = open_cv_setup(args.nx, args.nz, zs)
    if cv_setup is None:
        results.append(SkippedResult("linear_update", "cv2.KalmanFilter", "kalman.LinearKalmanFilter", cv_skip))
    else:
        results.append(time_workload(
            "linear_update",
            "cv2.KalmanFilter",
            "kalman.LinearKalmanFilter",
            cv_setup,
            args.iterations,
            1,
            args.warmup,
            args.repeats,
            "OpenCV C++-backed linear KalmanFilter.",
        ))

    def adaptive_update_setup():
        kf = configure_adaptive(kalman, args.nx, args.nz)
        index = 0

        def step() -> None:
            nonlocal index
            kf.update(zs_np[index % len(zs_np)])
            index += 1

        return step

    results.append(time_workload(
        "adaptive_update",
        "kalman.AdaptiveKalmanFilter",
        None,
        adaptive_update_setup,
        args.iterations,
        1,
        args.warmup,
        args.repeats,
        "No matching OpenCV adaptive KF.",
    ))

    def adaptive_update_many_setup():
        kf = configure_adaptive(kalman, args.nx, args.nz)

        def step() -> None:
            kf.update_many(zs_np)

        return step

    results.append(time_workload(
        "adaptive_update_many",
        "kalman.AdaptiveKalmanFilter",
        None,
        adaptive_update_many_setup,
        max(1, args.batch_iterations),
        batch_size,
        max(1, args.warmup // batch_size),
        args.repeats,
        "Batch path runs many adaptive updates inside C++ per Python call.",
    ))

    def ekf_setup():
        kf = configure_ekf_like(kalman, "ExtendedKalmanFilter", args.nx, args.nz)
        index = 0

        def step() -> None:
            nonlocal index
            kf.predict(transition, transition_jacobian)
            kf.correct(zs_np[index % len(zs_np)], measurement_fn, measurement_jacobian)
            index += 1

        return step

    results.append(time_workload(
        "ekf_predict_correct",
        "kalman.ExtendedKalmanFilter",
        None,
        ekf_setup,
        args.iterations,
        1,
        args.warmup,
        args.repeats,
        "Uses Python callbacks; C++ core template callables are benchmarked by benchmark_cpp_core.py.",
    ))

    def ekf_update_many_setup():
        kf = configure_ekf_like(kalman, "ExtendedKalmanFilter", args.nx, args.nz)

        def step() -> None:
            kf.update_many(zs_np, transition, transition_jacobian, measurement_fn, measurement_jacobian)

        return step

    results.append(time_workload(
        "ekf_update_many",
        "kalman.ExtendedKalmanFilter",
        None,
        ekf_update_many_setup,
        max(1, args.batch_iterations),
        batch_size,
        max(1, args.warmup // batch_size),
        args.repeats,
        "Many API loops inside C++, but still calls Python model callbacks for each step.",
    ))

    def iterated_ekf_setup():
        kf = configure_ekf_like(kalman, "IteratedExtendedKalmanFilter", args.nx, args.nz)
        index = 0

        def step() -> None:
            nonlocal index
            kf.predict(transition, transition_jacobian)
            kf.correct(zs_np[index % len(zs_np)], measurement_fn, measurement_jacobian, max_iterations=args.iekf_iterations)
            index += 1

        return step

    results.append(time_workload(
        "iterated_ekf_predict_correct",
        "kalman.IteratedExtendedKalmanFilter",
        None,
        iterated_ekf_setup,
        args.iterations,
        1,
        args.warmup,
        args.repeats,
        "Uses Python callbacks and configured IEKF inner iterations.",
    ))

    def iterated_ekf_update_many_setup():
        kf = configure_ekf_like(kalman, "IteratedExtendedKalmanFilter", args.nx, args.nz)

        def step() -> None:
            kf.update_many(
                zs_np, transition, transition_jacobian, measurement_fn, measurement_jacobian,
                max_iterations=args.iekf_iterations,
            )

        return step

    results.append(time_workload(
        "iterated_ekf_update_many",
        "kalman.IteratedExtendedKalmanFilter",
        None,
        iterated_ekf_update_many_setup,
        max(1, args.batch_iterations),
        batch_size,
        max(1, args.warmup // batch_size),
        args.repeats,
        "Many API loops inside C++; Python model callbacks remain per step/iteration.",
    ))

    def ukf_setup():
        kf = configure_ekf_like(kalman, "UnscentedKalmanFilter", args.nx, args.nz)
        index = 0

        def step() -> None:
            nonlocal index
            kf.predict(transition)
            kf.correct(zs_np[index % len(zs_np)], measurement_fn)
            index += 1

        return step

    results.append(time_workload(
        "ukf_predict_correct",
        "kalman.UnscentedKalmanFilter",
        None,
        ukf_setup,
        args.iterations,
        1,
        args.warmup,
        args.repeats,
        "No matching OpenCV UKF; Python callback overhead included.",
    ))

    def ukf_batch_setup():
        kf = configure_ekf_like(kalman, "UnscentedKalmanFilter", args.nx, args.nz)
        index = 0

        def step() -> None:
            nonlocal index
            kf.predict_batch(transition_batch)
            kf.correct_batch(zs_np[index % len(zs_np)], measurement_batch)
            index += 1

        return step

    results.append(time_workload(
        "ukf_predict_correct_batch_callbacks",
        "kalman.UnscentedKalmanFilter",
        None,
        ukf_batch_setup,
        args.iterations,
        1,
        args.warmup,
        args.repeats,
        "Batch callbacks receive all sigma points as one 2D NumPy array.",
    ))

    def ukf_update_many_batch_setup():
        kf = configure_ekf_like(kalman, "UnscentedKalmanFilter", args.nx, args.nz)

        def step() -> None:
            kf.update_many_batch(zs_np, transition_batch, measurement_batch)

        return step

    results.append(time_workload(
        "ukf_update_many_batch_callbacks",
        "kalman.UnscentedKalmanFilter",
        None,
        ukf_update_many_batch_setup,
        max(1, args.batch_iterations),
        batch_size,
        max(1, args.warmup // batch_size),
        args.repeats,
        "Many API plus batched sigma-point callbacks.",
    ))

    def enkf_setup():
        kf = configure_enkf(kalman, args.nx, args.nz)
        index = 0

        def step() -> None:
            nonlocal index
            kf.predict(transition)
            kf.correct_deterministic(zs_np[index % len(zs_np)], measurement_fn)
            index += 1

        return step

    results.append(time_workload(
        "enkf_predict_correct",
        "kalman.EnsembleKalmanFilter",
        None,
        enkf_setup,
        args.iterations,
        1,
        args.warmup,
        args.repeats,
        "Ensemble size is 8 in the current Python binding.",
    ))

    def enkf_batch_setup():
        kf = configure_enkf(kalman, args.nx, args.nz)
        index = 0

        def step() -> None:
            nonlocal index
            kf.predict_batch(transition_batch)
            kf.correct_deterministic_batch(zs_np[index % len(zs_np)], measurement_batch)
            index += 1

        return step

    results.append(time_workload(
        "enkf_predict_correct_batch_callbacks",
        "kalman.EnsembleKalmanFilter",
        None,
        enkf_batch_setup,
        args.iterations,
        1,
        args.warmup,
        args.repeats,
        "Batch callbacks receive all ensemble members as one 2D NumPy array.",
    ))

    def enkf_update_many_batch_setup():
        kf = configure_enkf(kalman, args.nx, args.nz)

        def step() -> None:
            kf.update_many_batch(zs_np, transition_batch, measurement_batch)

        return step

    results.append(time_workload(
        "enkf_update_many_batch_callbacks",
        "kalman.EnsembleKalmanFilter",
        None,
        enkf_update_many_batch_setup,
        max(1, args.batch_iterations),
        batch_size,
        max(1, args.warmup // batch_size),
        args.repeats,
        "Many API plus batched ensemble-member callbacks.",
    ))

    if hasattr(kalman, "RangeBearingEKF2D"):
        rb_measurements = np.asarray([
            [1.0 + 0.01 * i, 0.4 + 0.001 * math.sin(i * 0.2)]
            for i in range(max(args.measurements, 8))
        ], dtype=np.float64)

        def range_bearing_update_many_setup():
            kf = kalman.RangeBearingEKF2D()
            kf.x = np.asarray([1.0, 0.5, 0.01, 0.0], dtype=np.float64)
            kf.P = np.eye(4, dtype=np.float64).reshape(-1)
            kf.Q = (np.eye(4, dtype=np.float64) * 1e-4).reshape(-1)
            kf.R = (np.eye(2, dtype=np.float64) * 1e-2).reshape(-1)

            def step() -> None:
                kf.update_many(rb_measurements)

            return step

        results.append(time_workload(
            "range_bearing_ekf2d_update_many",
            "kalman.RangeBearingEKF2D",
            None,
            range_bearing_update_many_setup,
            max(1, args.batch_iterations),
            len(rb_measurements),
            max(1, args.warmup // len(rb_measurements)),
            args.repeats,
            "Compiled C++ nonlinear range/bearing EKF model; no Python model callbacks.",
        ))

    results.append(SkippedResult(
        "invariant_ekf_predict_correct",
        "kalman.InvariantExtendedKalmanFilter",
        None,
        "not exposed through the Python module; covered by benchmark_cpp_core.py",
    ))

    return results


def print_table(results: list[BenchmarkResult | SkippedResult]) -> None:
    print("name,implementation,competitor,best_ms,median_ms,ns_per_update,updates_per_second,notes")
    baseline_by_name = {
        r.name: r for r in results
        if isinstance(r, BenchmarkResult) and r.implementation.startswith("kalman.")
    }
    for result in results:
        if isinstance(result, SkippedResult):
            print(f"{result.name},{result.implementation},{result.compared_with or ''},SKIPPED,SKIPPED,SKIPPED,SKIPPED,{result.skipped}")
            continue
        ratio = ""
        baseline = baseline_by_name.get(result.name)
        if baseline is not None and baseline is not result:
            ratio = f"; competitor/ours_ns={result.ns_per_update / baseline.ns_per_update:.3g}"
        print(
            f"{result.name},{result.implementation},{result.compared_with or ''},"
            f"{result.best_ms:.3f},{result.median_ms:.3f},"
            f"{result.ns_per_update:.3f},{result.updates_per_second:.3f},"
            f"{result.notes}{ratio}"
        )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Benchmark the kalman nanobind Python API.")
    parser.add_argument("--nx", type=int, default=2, help="State dimension, 1 through 8")
    parser.add_argument("--nz", type=int, default=1, help="Measurement dimension, 1 through 8")
    parser.add_argument("--iterations", type=int, default=20_000, help="Single-step iterations")
    parser.add_argument("--batch-iterations", type=int, default=500, help="Batch benchmark iterations")
    parser.add_argument("--measurements", type=int, default=256, help="Measurements per reusable batch")
    parser.add_argument("--warmup", type=int, default=500, help="Warmup iterations")
    parser.add_argument("--repeats", type=int, default=5, help="Timed repeats")
    parser.add_argument("--iekf-iterations", type=int, default=3, help="Inner iterations for IEKF correct")
    parser.add_argument("--format", choices=["table", "json"], default="table")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    results = build_results(args)
    if args.format == "json":
        print(json.dumps([asdict(result) for result in results], indent=2, sort_keys=True))
    else:
        print_table(results)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
