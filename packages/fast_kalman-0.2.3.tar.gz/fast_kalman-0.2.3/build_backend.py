from __future__ import annotations

import sys

from scikit_build_core import build as _scikit_build


_BUILD_NOTICE = (
    "fast-kalman is compiling its C++/nanobind extension from source. "
    "This can take a few minutes."
)


def _print_build_notice() -> None:
    print(_BUILD_NOTICE, file=sys.stderr, flush=True)
    if not sys.stderr.isatty():
        try:
            with open("/dev/tty", "w", encoding="utf-8") as tty:
                print(_BUILD_NOTICE, file=tty, flush=True)
        except OSError:
            pass


def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    _print_build_notice()
    return _scikit_build.build_wheel(wheel_directory, config_settings, metadata_directory)


def build_editable(wheel_directory, config_settings=None, metadata_directory=None):
    _print_build_notice()
    return _scikit_build.build_editable(wheel_directory, config_settings, metadata_directory)


def build_sdist(sdist_directory, config_settings=None):
    return _scikit_build.build_sdist(sdist_directory, config_settings)


def get_requires_for_build_wheel(config_settings=None):
    return _scikit_build.get_requires_for_build_wheel(config_settings)


def get_requires_for_build_editable(config_settings=None):
    return _scikit_build.get_requires_for_build_editable(config_settings)


def get_requires_for_build_sdist(config_settings=None):
    return _scikit_build.get_requires_for_build_sdist(config_settings)


def prepare_metadata_for_build_wheel(metadata_directory, config_settings=None):
    return _scikit_build.prepare_metadata_for_build_wheel(metadata_directory, config_settings)


def prepare_metadata_for_build_editable(metadata_directory, config_settings=None):
    return _scikit_build.prepare_metadata_for_build_editable(metadata_directory, config_settings)
