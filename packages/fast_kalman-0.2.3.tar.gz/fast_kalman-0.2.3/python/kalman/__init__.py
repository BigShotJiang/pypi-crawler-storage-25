from ._core import (
    AdaptiveKalmanFilter as _AdaptiveKalmanFilter,
    EnsembleKalmanFilter as _EnsembleKalmanFilter,
    ExtendedKalmanFilter as _ExtendedKalmanFilter,
    IteratedExtendedKalmanFilter as _IteratedExtendedKalmanFilter,
    LinearKalmanFilter as _LinearKalmanFilter,
    RangeBearingEKF2D as _RangeBearingEKF2D,
    UnscentedKalmanFilter as _UnscentedKalmanFilter,
    make_constant_acceleration_1d,
    make_constant_velocity_1d,
    make_scalar_random_walk,
    supported_dimensions,
    version,
)
from .tuning import (
    EnsembleKalmanTuner,
    EnsembleKalmanTuning,
    ExtendedKalmanTuner,
    ExtendedKalmanTuning,
    IteratedExtendedKalmanTuner,
    IteratedExtendedKalmanTuning,
    LinearKalmanTuner,
    LinearKalmanTuning,
    RangeBearingEKF2DTuner,
    RangeBearingEKF2DTuning,
    UnscentedKalmanTuner,
    UnscentedKalmanTuning,
)


def _assign(filter_object, **values):
    for name, value in values.items():
        if value is not None:
            setattr(filter_object, name, value)
    return filter_object


def LinearKalmanFilter(nx, nz, x=None, P=None, F=None, Q=None, H=None, R=None):
    return _assign(_LinearKalmanFilter(nx, nz), x=x, P=P, F=F, Q=Q, H=H, R=R)


def ExtendedKalmanFilter(nx, nz, x=None, P=None, Q=None, R=None):
    return _assign(_ExtendedKalmanFilter(nx, nz), x=x, P=P, Q=Q, R=R)


def IteratedExtendedKalmanFilter(nx, nz, x=None, P=None, Q=None, R=None):
    return _assign(_IteratedExtendedKalmanFilter(nx, nz), x=x, P=P, Q=Q, R=R)


def UnscentedKalmanFilter(
    nx,
    nz,
    x=None,
    P=None,
    Q=None,
    R=None,
    alpha=1.0e-3,
    beta=2.0,
    kappa=0.0,
):
    filter_object = _assign(_UnscentedKalmanFilter(nx, nz), x=x, P=P, Q=Q, R=R)
    filter_object.alpha = alpha
    filter_object.beta = beta
    filter_object.kappa = kappa
    return filter_object


def AdaptiveKalmanFilter(
    nx,
    nz,
    x=None,
    P=None,
    F=None,
    Q=None,
    H=None,
    R=None,
    forgetting=None,
    min_variance=None,
):
    filter_object = _assign(_AdaptiveKalmanFilter(nx, nz), x=x, P=P, F=F, Q=Q, H=H, R=R)
    if forgetting is not None:
        filter_object.forgetting = forgetting
    if min_variance is not None:
        filter_object.min_variance = min_variance
    return filter_object


def EnsembleKalmanFilter(nx, nz, ensemble_size=8, members=None, R=None):
    filter_object = _EnsembleKalmanFilter(nx, nz, ensemble_size)
    if members is not None:
        filter_object.members = members
        filter_object.recompute_mean_covariance()
    if R is not None:
        filter_object.R = R
    return filter_object


def RangeBearingEKF2D(
    dt=1.0,
    landmark_x=0.0,
    landmark_y=0.0,
    x=None,
    P=None,
    Q=None,
    R=None,
):
    filter_object = _RangeBearingEKF2D()
    filter_object.dt = dt
    filter_object.landmark_x = landmark_x
    filter_object.landmark_y = landmark_y
    return _assign(filter_object, x=x, P=P, Q=Q, R=R)

__all__ = [
    "AdaptiveKalmanFilter",
    "EnsembleKalmanTuner",
    "EnsembleKalmanTuning",
    "EnsembleKalmanFilter",
    "ExtendedKalmanTuner",
    "ExtendedKalmanTuning",
    "ExtendedKalmanFilter",
    "IteratedExtendedKalmanTuner",
    "IteratedExtendedKalmanTuning",
    "IteratedExtendedKalmanFilter",
    "LinearKalmanTuner",
    "LinearKalmanTuning",
    "LinearKalmanFilter",
    "RangeBearingEKF2DTuner",
    "RangeBearingEKF2DTuning",
    "RangeBearingEKF2D",
    "UnscentedKalmanTuner",
    "UnscentedKalmanTuning",
    "UnscentedKalmanFilter",
    "make_constant_acceleration_1d",
    "make_constant_velocity_1d",
    "make_scalar_random_walk",
    "supported_dimensions",
    "version",
]
