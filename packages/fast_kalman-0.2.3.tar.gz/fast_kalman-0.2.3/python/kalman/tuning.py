from __future__ import annotations

import math
from collections import namedtuple
from numbers import Real
from typing import Iterable, Optional, Sequence

from ._core import _linear_recommendation as _cpp_linear_recommendation


LinearKalmanTuning = namedtuple("LinearKalmanTuning", "nx nz x P F Q H R")
ExtendedKalmanTuning = namedtuple("ExtendedKalmanTuning", "nx nz x P Q R")
IteratedExtendedKalmanTuning = namedtuple("IteratedExtendedKalmanTuning", "nx nz x P Q R")
UnscentedKalmanTuning = namedtuple("UnscentedKalmanTuning", "nx nz x P Q R alpha beta kappa")
EnsembleKalmanTuning = namedtuple("EnsembleKalmanTuning", "nx nz ensemble_size members R")
RangeBearingEKF2DTuning = namedtuple("RangeBearingEKF2DTuning", "dt landmark_x landmark_y x P Q R")


def _median(values: Sequence[float]) -> float:
    if not values:
        return 0.0
    xs = sorted(float(x) for x in values)
    mid = len(xs) // 2
    if len(xs) % 2:
        return xs[mid]
    return 0.5 * (xs[mid - 1] + xs[mid])


def _mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _sample_variance(values: Sequence[float]) -> float:
    if len(values) < 2:
        return 0.0
    mu = _mean(values)
    return sum((x - mu) * (x - mu) for x in values) / (len(values) - 1)


def _robust_variance(values: Sequence[float]) -> float:
    if len(values) < 2:
        return 0.0
    center = _median(values)
    mad = _median([abs(x - center) for x in values])
    sigma = 1.4826 * mad
    if sigma > 0.0 and math.isfinite(sigma):
        return sigma * sigma
    return _sample_variance(values)


def _difference(values: Sequence[float], order: int = 1) -> list[float]:
    out = [float(x) for x in values]
    for _ in range(order):
        out = [b - a for a, b in zip(out, out[1:])]
    return out


def _wrap_angle(value: float) -> float:
    return (float(value) + math.pi) % (2.0 * math.pi) - math.pi


def _angle_difference(values: Sequence[float]) -> list[float]:
    return [_wrap_angle(b - a) for a, b in zip(values, values[1:])]


def _diag(values: Sequence[float], rows: int, cols: int) -> list[float]:
    out = [0.0] * (rows * cols)
    for i, value in enumerate(values[: min(rows, cols)]):
        out[i * cols + i] = float(value)
    return out


def _identity(n: int) -> list[float]:
    return _diag([1.0] * n, n, n)


def _floor(value: float, minimum: float) -> float:
    if not math.isfinite(value) or value < minimum:
        return minimum
    return value


def _copy(values: Sequence[float]) -> list[float]:
    return [float(x) for x in values]


def _as_samples(data_points: Iterable, nz: int) -> list[list[float]]:
    values = list(data_points)
    if not values:
        raise ValueError("data_points must not be empty")

    first = values[0]
    if isinstance(first, Real):
        if nz != 1:
            if len(values) % nz != 0:
                raise ValueError(f"flat data length must be divisible by nz={nz}")
            return [
                [float(x) for x in values[i : i + nz]]
                for i in range(0, len(values), nz)
            ]
        return [[float(x)] for x in values]

    samples: list[list[float]] = []
    for row in values:
        sample = [float(x) for x in row]
        if len(sample) != nz:
            raise ValueError(f"each data point must have nz={nz} values")
        samples.append(sample)
    return samples


def _columns(samples: Sequence[Sequence[float]], nz: int) -> list[list[float]]:
    return [[float(row[j]) for row in samples] for j in range(nz)]


def _choose_model(model: str, nx: int, nz: int) -> str:
    if model != "auto":
        return model
    if nx == nz:
        return "random-walk"
    if nx == 2 * nz:
        return "constant-velocity"
    if nx == 3 * nz:
        return "constant-acceleration"
    return "generic"


def _measurement_variances(series: Sequence[Sequence[float]], model: str, minimum: float) -> list[float]:
    order = 1
    if model == "constant-velocity":
        order = 2
    elif model == "constant-acceleration":
        order = 3

    variances: list[float] = []
    for values in series:
        coeff_energy = {1: 2.0, 2: 6.0, 3: 20.0}[order]
        diffed = _difference(values, order)
        if len(diffed) < 2:
            diffed = _difference(values, 1)
            coeff_energy = 2.0
        estimate = _robust_variance(diffed) / coeff_energy if diffed else 0.0
        total = _robust_variance(values)
        upper = max(total * 0.5, minimum)
        variances.append(_floor(min(estimate, upper), minimum))
    return variances


def _linear_recommendation(samples: Sequence[Sequence[float]], nx: int, nz: int, dt: float, model: str, minimum: float) -> dict:
    if not hasattr(samples, "__len__"):
        samples = list(samples)
    return _cpp_linear_recommendation(samples, nx, nz, dt, model, minimum)


class _StatefulTuner:
    def __init__(self, nx: int, nz: int, *, dt: float = 1.0, model: str = "auto", min_variance: float = 1e-12, forgetting: float = 0.75):
        if nx <= 0 or nz <= 0:
            raise ValueError("nx and nz must be positive")
        if dt <= 0.0:
            raise ValueError("dt must be positive")
        if min_variance <= 0.0:
            raise ValueError("min_variance must be positive")
        if not 0.0 <= forgetting < 1.0:
            raise ValueError("forgetting must be in [0, 1)")
        self.nx = int(nx)
        self.nz = int(nz)
        self.dt = float(dt)
        self.model = model
        self.min_variance = float(min_variance)
        self.forgetting = float(forgetting)
        self.count = 0
        self._estimate: Optional[dict] = None

    def _batch_estimate(self, data_points: Iterable) -> dict:
        return _linear_recommendation(data_points, self.nx, self.nz, self.dt, self.model, self.min_variance)

    def _merge(self, batch: dict) -> dict:
        if self._estimate is None:
            self._estimate = {k: (v[:] if isinstance(v, list) else v) for k, v in batch.items()}
        else:
            f = self.forgetting
            merged = dict(batch)
            for key in ("x", "P", "F", "Q", "H", "R", "P_diag", "Q_diag", "R_diag"):
                merged[key] = [
                    f * old + (1.0 - f) * new
                    for old, new in zip(self._estimate[key], batch[key])
                ]
            merged["model"] = batch["model"]
            self._estimate = merged
        self.count += 1
        return self._estimate

    def _update_estimate(self, data_points: Iterable) -> dict:
        return self._merge(self._batch_estimate(data_points))


class LinearKalmanTuner(_StatefulTuner):
    def update(self, data_points: Iterable) -> LinearKalmanTuning:
        estimate = self._update_estimate(data_points)
        return LinearKalmanTuning(
            self.nx,
            self.nz,
            _copy(estimate["x"]),
            _copy(estimate["P"]),
            _copy(estimate["F"]),
            _copy(estimate["Q"]),
            _copy(estimate["H"]),
            _copy(estimate["R"]),
        )


class ExtendedKalmanTuner(_StatefulTuner):
    def update(self, data_points: Iterable) -> ExtendedKalmanTuning:
        estimate = self._update_estimate(data_points)
        return ExtendedKalmanTuning(
            self.nx,
            self.nz,
            _copy(estimate["x"]),
            _copy(estimate["P"]),
            _copy(estimate["Q"]),
            _copy(estimate["R"]),
        )


class IteratedExtendedKalmanTuner(_StatefulTuner):
    def update(self, data_points: Iterable) -> IteratedExtendedKalmanTuning:
        estimate = self._update_estimate(data_points)
        return IteratedExtendedKalmanTuning(
            self.nx,
            self.nz,
            _copy(estimate["x"]),
            _copy(estimate["P"]),
            _copy(estimate["Q"]),
            _copy(estimate["R"]),
        )


class UnscentedKalmanTuner(_StatefulTuner):
    def __init__(self, nx: int, nz: int, *, alpha: float = 1e-3, beta: float = 2.0, kappa: float = 0.0, **kwargs):
        super().__init__(nx, nz, **kwargs)
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.kappa = float(kappa)

    def update(self, data_points: Iterable) -> UnscentedKalmanTuning:
        estimate = self._update_estimate(data_points)
        return UnscentedKalmanTuning(
            self.nx,
            self.nz,
            _copy(estimate["x"]),
            _copy(estimate["P"]),
            _copy(estimate["Q"]),
            _copy(estimate["R"]),
            self.alpha,
            self.beta,
            self.kappa,
        )


class EnsembleKalmanTuner(_StatefulTuner):
    def __init__(self, nx: int, nz: int, *, ensemble_size: int = 8, **kwargs):
        super().__init__(nx, nz, **kwargs)
        if ensemble_size != 8:
            raise ValueError("the Python EnKF binding currently supports ensemble_size=8")
        self.ensemble_size = int(ensemble_size)

    def update(self, data_points: Iterable) -> EnsembleKalmanTuning:
        estimate = self._update_estimate(data_points)
        x = estimate["x"]
        p_diag = [estimate["P"][i * self.nx + i] for i in range(self.nx)]
        center = (self.ensemble_size - 1) / 2.0
        members: list[list[float]] = []
        for member in range(self.ensemble_size):
            scale = (member - center) / max(center, 1.0)
            members.append([
                x[i] + scale * math.sqrt(max(p_diag[i], self.min_variance)) * 0.1
                for i in range(self.nx)
            ])
        return EnsembleKalmanTuning(self.nx, self.nz, self.ensemble_size, members, _copy(estimate["R"]))


class RangeBearingEKF2DTuner:
    def __init__(self, nx: int = 4, nz: int = 2, *, dt: float = 1.0, landmark_x: float = 0.0, landmark_y: float = 0.0, min_variance: float = 1e-12, forgetting: float = 0.75):
        if nx != 4 or nz != 2:
            raise ValueError("RangeBearingEKF2DTuner only supports nx=4, nz=2")
        if dt <= 0.0:
            raise ValueError("dt must be positive")
        if min_variance <= 0.0:
            raise ValueError("min_variance must be positive")
        if not 0.0 <= forgetting < 1.0:
            raise ValueError("forgetting must be in [0, 1)")
        self.dt = float(dt)
        self.nx = int(nx)
        self.nz = int(nz)
        self.landmark_x = float(landmark_x)
        self.landmark_y = float(landmark_y)
        self.min_variance = float(min_variance)
        self.forgetting = float(forgetting)
        self.count = 0
        self._estimate: Optional[RangeBearingEKF2DTuning] = None

    def update(self, data_points: Iterable) -> RangeBearingEKF2DTuning:
        samples = _as_samples(data_points, 2)
        ranges = [row[0] for row in samples]
        bearings = [row[1] for row in samples]
        r0 = ranges[0]
        b0 = bearings[0]
        x0 = self.landmark_x + r0 * math.cos(b0)
        y0 = self.landmark_y + r0 * math.sin(b0)

        if len(samples) >= 2:
            r1, b1 = samples[min(1, len(samples) - 1)]
            x1 = self.landmark_x + r1 * math.cos(b1)
            y1 = self.landmark_y + r1 * math.sin(b1)
            vx0 = (x1 - x0) / self.dt
            vy0 = (y1 - y0) / self.dt
        else:
            vx0 = 0.0
            vy0 = 0.0

        range_var = _floor(_robust_variance(_difference(ranges, 1)) / 2.0, self.min_variance)
        bearing_var = _floor(_robust_variance(_angle_difference(bearings)) / 2.0, self.min_variance)
        position_var = max(_robust_variance(ranges), range_var * 10.0, self.min_variance)
        velocity_var = max(position_var / max(self.dt * self.dt, self.min_variance), self.min_variance)
        process_pos = max(range_var * 0.01, self.min_variance)
        process_vel = max(velocity_var * 0.001, self.min_variance)
        candidate = RangeBearingEKF2DTuning(
            self.dt,
            self.landmark_x,
            self.landmark_y,
            [x0, y0, vx0, vy0],
            _diag([position_var, position_var, velocity_var, velocity_var], 4, 4),
            _diag([process_pos, process_pos, process_vel, process_vel], 4, 4),
            _diag([range_var, bearing_var], 2, 2),
        )

        if self._estimate is None:
            self._estimate = candidate
        else:
            f = self.forgetting
            self._estimate = RangeBearingEKF2DTuning(
                candidate.dt,
                candidate.landmark_x,
                candidate.landmark_y,
                [f * old + (1.0 - f) * new for old, new in zip(self._estimate.x, candidate.x)],
                [f * old + (1.0 - f) * new for old, new in zip(self._estimate.P, candidate.P)],
                [f * old + (1.0 - f) * new for old, new in zip(self._estimate.Q, candidate.Q)],
                [f * old + (1.0 - f) * new for old, new in zip(self._estimate.R, candidate.R)],
            )
        self.count += 1
        return RangeBearingEKF2DTuning(
            self._estimate.dt,
            self._estimate.landmark_x,
            self._estimate.landmark_y,
            _copy(self._estimate.x),
            _copy(self._estimate.P),
            _copy(self._estimate.Q),
            _copy(self._estimate.R),
        )
