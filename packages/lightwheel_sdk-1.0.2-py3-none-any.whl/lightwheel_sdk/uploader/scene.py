from ..client.client import LightwheelClient


class SceneUploader:
    """
    Uploader for scene yaml files.

    Args:
        client (LightwheelClient): The client to use for the uploader
    """

    def __init__(self, client: LightwheelClient):
        self.client = client

    def create_scene(
        self,
        scene_type: str,
        index: int,
        local_path: str,
        name: str,
        *,
        backend: str = "robocasa",
        split: str = None,
        free: bool = False,
    ):
        """
        Create a scene from a local YAML file.

        Args:
            scene_type (str): layout or style
            index (int): index of the scene
            local_path (str): path to the local YAML file
            name (str): name of the scene
            backend (str, optional): backend of the scene. Defaults to "robocasa".
            split (str, optional): split of the scene. Defaults to None.
            free (bool, optional): whether the scene is free. Defaults to False.
        """
        if not local_path.endswith("yaml"):
            raise Exception(f"File {local_path} is not a yaml file")
        with open(local_path, "r", encoding="utf-8") as f:
            yaml_txt = f.read()
        data = {
            "index": index,
            "value": yaml_txt,
            "type": scene_type,
            "name": name,
            "backend": backend,
            "free": free,
        }
        if split:
            data["split"] = split
        self.client.post("/floorplan/v1/scene/create", data=data)
