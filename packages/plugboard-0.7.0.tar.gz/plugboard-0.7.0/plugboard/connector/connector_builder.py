"""Provides `ConnectorBuilder` to build `Connector` objects."""

from __future__ import annotations

import typing as _t


if _t.TYPE_CHECKING:  # pragma: no cover
    from plugboard.connector.connector import Connector

from plugboard.connector.event_connector_spec_builder import EventConnectorSpecBuilder
from plugboard.schemas import ConnectorSpec


class ConnectorBuilder:
    """`ConnectorBuilder` facilitates building `Connector`s with a preset configuration."""

    def __init__(self, connector_cls: type[Connector], *args: _t.Any, **kwargs: _t.Any) -> None:
        self._connector_cls: type[Connector] = connector_cls
        self._args: _t.Any = args
        self._kwargs: _t.Any = kwargs

    def build(self, spec: ConnectorSpec) -> Connector:
        """Builds a `Connector` object."""
        return self._connector_cls(spec, *self._args, **self._kwargs)

    def build_event_connectors(self, components: _t.Iterable[_t.Any]) -> list[Connector]:
        """Builds event connectors for the given components."""
        evt_conn_map = EventConnectorSpecBuilder.build(components)
        return [self.build(spec=spec) for spec in evt_conn_map.values()]
