
# exordos_compute

Compute group in the Exordos installation

## Usage

```console
                                                                                                                                                                                                                                                                                                           
 Usage: exordos compute [OPTIONS] COMMAND [ARGS]...                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                           
```

## Options

* `help`:
    * Type: boolean
    * Default: `false`
    * Usage: `--help`

  Show this message and exit.

## CLI Help

```console
                                                                                                                                                                                                                                                                                                           
 Usage: exordos compute [OPTIONS] COMMAND [ARGS]...                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                           
```
