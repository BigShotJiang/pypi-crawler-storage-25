#    Copyright 2025 Genesis Corporation.
#
#    All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import typing as tp
import uuid as sys_uuid

from bazooka import exceptions as bazooka_exc
from requests.exceptions import RequestException
import rich_click as click

from exordos.cmd.aliases import ClickAliasedGroup
from exordos.cmd.builds import commands as builds_commands
from exordos.cmd.compute import compute_group
from exordos.cmd.compute.hypervisors import commands as hypervisors_commands
from exordos.cmd.compute.nodes import commands as nodes_commands
from exordos.cmd.configs import commands as configs_commands
from exordos.cmd.em import em_group
from exordos.cmd.em.elements import commands as elements_commands
from exordos.cmd.iam import iam_group
from exordos.cmd.iam.auth import commands as auth_commands
from exordos.cmd.initialization import commands as initialization_commands
from exordos.cmd.realms.commands import realms_group
from exordos.cmd.repo import commands as repo_commands
from exordos.cmd.secret import secret_group
from exordos.cmd.settings import commands as settings_commands
from exordos.cmd.settings import config as settings_config
from exordos.cmd.stand import commands as stand_commands
from exordos.cmd.stand import utils_commands
from exordos.cmd.version import commands as version_commands
from exordos.cmd.vs import vs_group
from exordos.cmd.vs.vars import commands as vars_commands
from exordos.common.cmd_context import ContextObject
import exordos.constants as c

COMMANDS_WITHOUT_CONFIG = {
    auth_commands.auth_group.name,
    builds_commands.build_cmd.name,
    initialization_commands.init_cmd.name,
    version_commands.version_cmd.name,
    version_commands.latest_cmd.name,
    version_commands.get_project_version_cmd.name,
    stand_commands.bootstrap_cmd.name,
    stand_commands.backup_cmd.name,
    stand_commands.backup_decrypt_cmd.name,
    utils_commands.autocomplete.name,
    utils_commands.autocomplete_help.name,
    utils_commands.hello.name,
    utils_commands.introduction.name,
    hypervisors_commands.init_cmd.name,
    settings_commands.settings_group.name,
    repo_commands.push_cmd.name,
}


@click.group(
    cls=ClickAliasedGroup,
    invoke_without_command=True,
    help="Provides all the necessary tools for work with Exordos Platform",
)
@click.option(
    "--config",
    default=c.CONFIG_FILE,
    show_default=True,
    type=click.Path(exists=False, dir_okay=False),
    help="Path to YAML config file",
)
@click.option(
    "-e",
    "--endpoint",
    default="http://localhost:11010",
    show_default=True,
    help="Exordos API endpoint",
)
@click.option(
    "-u",
    "--user",
    default=None,
    help="Client user name",
)
@click.option(
    "-p",
    "--password",
    default=None,
    help="Password for the client user",
)
@click.option(
    "-a",
    "--access_token",
    default=None,
    help="access token for the client user",
)
@click.option(
    "--refresh_token",
    default=None,
    help="refresh token for the client user",
)
@click.option(
    "-r",
    "--realm",
    type=str,
    help="Name of the realm",
)
@click.option(
    "-c",
    "--context",
    type=str,
    help="Name of the context",
)
@click.option(
    "-P",
    "--project-id",
    default=None,
    type=click.UUID,
    help="Project ID for the client user",
)
@click.option(
    "-vvv",
    "--verbose",
    show_default=True,
    is_flag=True,
    help="Verbose logs",
)
@click.option(
    "-i",
    "--developer-key-path",
    default=None,
    help="Path to developer public key",
)
@click.option(
    "-s",
    "--silent",
    show_default=True,
    is_flag=True,
    help="Do not print messages, warnings or errors",
)
@click.pass_context
def exordos(
    ctx: click.Context,
    config: str,
    endpoint: str,
    user: str | None,
    password: str | None,
    access_token: str | None,
    refresh_token: str | None,
    realm: str | None,
    context: str | None,
    project_id: sys_uuid.UUID | None,
    verbose: bool | None,
    developer_key_path: str | None,
    silent: bool | None,
) -> None:
    if not ctx.invoked_subcommand:
        click.echo(ctx.get_help())
        return
    if verbose:
        import logging

        logging.basicConfig(level=logging.DEBUG)
    # Load configuration from file (if exists)
    cfg_path = config if config else None
    cfg = settings_config.load_config(
        ctx,
        cfg_path,
        silent
        or any(
            [ctx.invoked_subcommand.startswith(cmd) for cmd in COMMANDS_WITHOUT_CONFIG]
        ),
    )

    realm_conf = settings_config.get_realm(cfg, realm)
    context_conf = settings_config.get_context(realm_conf, context)

    def _get_final_value(
        param_name: str, cli_value: tp.Any, base_conf: dict, direct_conf: dict
    ) -> tp.Any:
        if (
            ctx.get_parameter_source(param_name)
            == click.core.ParameterSource.COMMANDLINE
        ):
            return cli_value
        return direct_conf.get(param_name, base_conf.get(param_name, cli_value))

    final_endpoint = _get_final_value("endpoint", endpoint, cfg, realm_conf)
    final_check_updates = _get_final_value("check_updates", False, cfg, realm_conf)
    final_user = _get_final_value("user", user, cfg, context_conf)
    final_password = _get_final_value("password", password, cfg, context_conf)
    final_access_token = _get_final_value(
        "access_token", access_token, cfg, context_conf
    )
    final_refresh_token = _get_final_value(
        "refresh_token", refresh_token, cfg, context_conf
    )
    final_developer_key_path = _get_final_value(
        "developer_key_path", developer_key_path, cfg, {}
    )
    need_update = None
    if final_check_updates and version_commands.should_check_version():
        need_update = not version_commands.check_latest_version()
        version_commands.save_last_check_time()

    final_project_id = _get_final_value("project_id", project_id, cfg, context_conf)
    scope = f"project:{final_project_id}" if final_project_id else None

    auth_data = dict(
        endpoint=final_endpoint,
        username=final_user,
        password=final_password,
        access_token=final_access_token,
        refresh_token=final_refresh_token,
        scope=scope,
    )
    ctx.obj = ContextObject(
        auth_data, config, final_developer_key_path, cfg, need_update
    )


@exordos.command(help="tool for creating docs files for cli commands", hidden=True)
def dumphelp() -> None:
    from exordos.common.md_click import dump_helper  # type: ignore

    dump_helper(exordos)
    return None


exordos.add_command(auth_commands.auth_group)  # noqa

exordos.add_command(iam_group)  # noqa
exordos.add_command(secret_group, aliases=["s"])  # noqa
exordos.add_command(realms_group)  # noqa

exordos.add_command(vs_group)  # noqa
exordos.add_command(vars_commands.vv_group)  # noqa

exordos.add_command(compute_group, aliases=["c"])  # noqa
exordos.add_command(nodes_commands.cn_group)  # noqa

exordos.add_command(em_group, aliases=["e"])  # noqa
exordos.add_command(elements_commands.ee_group)  # noqa
exordos.add_command(builds_commands.build_cmd)  # noqa

exordos.add_command(configs_commands.configs_group)  # noqa
exordos.add_command(settings_commands.settings_group)  # noqa
exordos.add_command(repo_commands.repository_group)  # noqa
exordos.add_command(repo_commands.push_cmd)  # noqa

exordos.add_command(initialization_commands.init_cmd)  # noqa

exordos.add_command(version_commands.version_cmd)  # noqa
exordos.add_command(version_commands.latest_cmd)  # noqa
exordos.add_command(version_commands.get_project_version_cmd)  # noqa

exordos.add_command(stand_commands.bootstrap_cmd)  # noqa
exordos.add_command(stand_commands.backup_cmd)  # noqa
exordos.add_command(stand_commands.backup_decrypt_cmd)  # noqa

exordos.add_command(utils_commands.openapi_spec)  # noqa
exordos.add_command(utils_commands.hello)  # noqa
exordos.add_command(utils_commands.autocomplete_help)  # noqa
exordos.add_command(utils_commands.autocomplete)  # noqa
exordos.add_command(utils_commands.sync)  # noqa
exordos.add_command(utils_commands.introduction)  # noqa
exordos.add_command(utils_commands.ready_api)  # noqa


if __name__ == "__main__":
    try:
        exordos()
    except bazooka_exc.BaseHTTPException as e:
        click.secho(f"Error: [{e.code}] {e.cause.response.text}", fg="red")
    except RequestException as e:
        if e.response is not None:
            click.secho(
                f"Error: [{e.response.status_code}] {e.response.text}", fg="red"
            )
        click.secho(f"Error: {e}", fg="red")
    except (ValueError, FileNotFoundError) as e:
        click.secho(f"Error: {e}", fg="red")
