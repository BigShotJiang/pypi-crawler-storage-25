#    Copyright 2025 Genesis Corporation.
#
#    All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import json
import pathlib
import typing as tp
from unittest.mock import MagicMock

from exordos.builder import base
from exordos.builder.builder import SimpleBuilder
from exordos.logger import DummyLogger


class TestBuilder:
    def test_fetch_dependency(self, simple_builder: SimpleBuilder) -> None:
        deps_dir = "/tmp/deps_dir"
        simple_builder.fetch_dependency(deps_dir)
        for dep in simple_builder._deps:
            dep.fetch.assert_called_once_with(deps_dir)

        assert len(simple_builder._deps) > 1

    def test_from_config(self, build_config: tp.Dict[str, tp.Any]) -> None:
        work_dir = "/tmp/work_dir"

        builder = SimpleBuilder.from_config(
            work_dir,
            build_config,
            MagicMock(),
            DummyLogger(),
        )

        assert len(builder._deps) == 2
        assert len(builder._elements) == 1
        assert builder._work_dir == work_dir

    def test_manifest_rendering_jinja2_variables(self, tmp_path) -> None:
        """Ensure Jinja2 variables render correctly."""
        # Arrange: temp work dir and output dir
        work_dir = tmp_path / "work"
        out_dir = tmp_path / "out"
        work_dir.mkdir()
        out_dir.mkdir()

        # Create a Jinja2 manifest template that is also valid YAML before rendering
        # so that the pre-parse with yaml.safe_load succeeds.
        manifest_rel = "myapp.yaml.j2"
        manifest_path = work_dir / manifest_rel
        manifest_content = (
            "name: my-element\n"
            'version: "{{ version }}"\n'
            "images: \"{{ images | join(',') }}\"\n"
            "metadata:\n"
            '  title: "{{ name }} v{{ version }}"\n'
            '  meta_foo: "{{ foo }}"\n'
            '  meta_bar: "{{ bar }}"\n'
        )
        manifest_path.write_text(manifest_content)

        # Prepare builder with no images to focus on manifest rendering
        builder = SimpleBuilder(
            work_dir=str(work_dir),
            deps=[],
            elements=[],
            image_builder=MagicMock(spec=base.AbstractImageBuilder),
            logger=DummyLogger(),
            elements_output_dir=str(out_dir),
        )

        element = base.Element(manifest=manifest_rel, images=[])

        # Act
        inventory = builder.build_element(
            element=element,
            build_dir=None,
            developer_keys=None,
            build_suffix="1.2.3",
            inventory_mode=True,
            manifest_vars={"foo": "FOO", "bar": "BAR"},
        )

        # Assert: rendered manifest exists without the .j2 extension
        manifests_dir = out_dir / "manifests"
        rendered_manifest = manifests_dir / "myapp.yaml"
        assert rendered_manifest.exists(), "Rendered manifest file not found"

        content = rendered_manifest.read_text()
        # Variables should be interpolated
        assert 'version: "1.2.3"' in content
        assert 'title: "my-element v1.2.3"' in content
        assert 'meta_foo: "FOO"' in content
        assert 'meta_bar: "BAR"' in content
        # images list is empty -> joined string should be empty quotes
        assert 'images: ""' in content

        assert inventory is not None
        assert inventory.manifests
        assert pathlib.Path(inventory.manifests[0]).name == "myapp.yaml"

    def test_manifest_rendering_preserves_filename_without_template_ext(
        self, tmp_path
    ) -> None:
        """Ensure the rendered manifest file drops the template extension (.j2/.jinja2)."""
        work_dir = tmp_path / "work"
        out_dir = tmp_path / "out"
        work_dir.mkdir()
        out_dir.mkdir()

        manifest_rel = "service.yaml.jinja2"
        manifest_path = work_dir / manifest_rel
        manifest_path.write_text('name: svc\nversion: "{{ version }}"\n')

        builder = SimpleBuilder(
            work_dir=str(work_dir),
            deps=[],
            elements=[],
            image_builder=MagicMock(spec=base.AbstractImageBuilder),
            logger=DummyLogger(),
            elements_output_dir=str(out_dir),
        )

        element = base.Element(manifest=manifest_rel, images=[])

        builder.build_element(
            element=element,
            build_dir=None,
            developer_keys=None,
            build_suffix="0.0.1",
            inventory_mode=True,
        )

        # The output manifest should be saved without the .jinja2 extension
        assert (out_dir / "manifests" / "service.yaml").exists()

    def test_build_multiple_manifests_writes_inventory_json(self, tmp_path) -> None:
        work_dir = tmp_path / "work"
        out_dir = tmp_path / "out"
        work_dir.mkdir()
        out_dir.mkdir()

        manifest_1 = "app1.yaml"
        manifest_2 = "app2.yaml"
        (work_dir / manifest_1).write_text("name: app1\nversion: 0\n")
        (work_dir / manifest_2).write_text("name: app2\nversion: 0\n")

        builder = SimpleBuilder(
            work_dir=str(work_dir),
            deps=[],
            elements=[
                base.Element(manifest=manifest_1, images=[]),
                base.Element(manifest=manifest_2, images=[]),
            ],
            image_builder=MagicMock(spec=base.AbstractImageBuilder),
            logger=DummyLogger(),
            elements_output_dir=str(out_dir),
        )

        builder.build(
            build_dir=None,
            developer_keys=None,
            build_suffix="9.9.9",
            inventory_mode=True,
            manifest_vars=None,
        )

        inventory_json = out_dir / "inventory.json"
        assert inventory_json.exists()

        data = json.loads(inventory_json.read_text())
        assert isinstance(data, list)
        assert len(data) == 2

        names = {item["name"] for item in data}
        assert names == {"app1", "app2"}

        versions = {item["version"] for item in data}
        assert versions == {"9.9.9"}

        manifest_names = {
            pathlib.Path(item["manifests"][0]).name
            for item in data
            if item["manifests"]
        }
        assert manifest_names == {"app1.yaml", "app2.yaml"}

        assert (out_dir / "manifests" / "app1.yaml").exists()
        assert (out_dir / "manifests" / "app2.yaml").exists()

    def test_image_from_config_single_format(self) -> None:
        """Image.from_config parses a single format string into a one-element list."""
        img = base.Image.from_config(
            {"script": "/tmp/install.sh", "format": "qcow2", "name": "my-img"},
            work_dir="/tmp",
        )
        assert img.formats == ["qcow2"]
        assert img.format == "qcow2"

    def test_image_from_config_multi_format(self) -> None:
        """Image.from_config parses a comma-separated format string correctly."""
        img = base.Image.from_config(
            {"script": "/tmp/install.sh", "format": "raw, qcow2", "name": "my-img"},
            work_dir="/tmp",
        )
        assert img.formats == ["raw", "qcow2"]
        assert img.format == "raw"

    def test_image_from_config_gz_qcow2(self) -> None:
        """Image.from_config parses gz,qcow2 multi-format correctly."""
        img = base.Image.from_config(
            {"script": "/tmp/install.sh", "format": "gz,qcow2", "name": "my-img"},
            work_dir="/tmp",
        )
        assert img.formats == ["gz", "qcow2"]

    def test_convert_image_raw(self, tmp_path) -> None:
        """_convert_image copies a raw image to the output dir."""
        images_dir = tmp_path / "images"
        images_dir.mkdir()
        raw_src = tmp_path / "my-img.raw"
        raw_src.write_bytes(b"rawdata")

        builder = SimpleBuilder(
            work_dir=str(tmp_path),
            deps=[],
            elements=[],
            image_builder=MagicMock(spec=base.AbstractImageBuilder),
            logger=DummyLogger(),
            elements_output_dir=str(tmp_path / "out"),
        )
        result = builder._convert_image(str(raw_src), "my-img", "raw", str(images_dir))
        assert pathlib.Path(result).name == "my-img.raw"
        assert pathlib.Path(result).exists()

    def test_build_element_multi_format_inventory(self, tmp_path) -> None:
        """build_element lists all requested format variants in inventory images."""
        work_dir = tmp_path / "work"
        out_dir = tmp_path / "out"
        work_dir.mkdir()
        out_dir.mkdir()

        manifest_rel = "app.yaml"
        (work_dir / manifest_rel).write_text("name: myapp\nversion: 0\n")

        raw_file = tmp_path / "packer_out" / "myapp.raw"
        raw_file.parent.mkdir(parents=True)
        raw_file.write_bytes(b"fake-raw-image-data")

        img = base.Image(
            script=str(work_dir / "install.sh"),
            formats=["raw", "gz"],
            name="myapp",
        )

        mock_builder = MagicMock(spec=base.AbstractImageBuilder)

        def fake_run(image_dir, image, deps, developer_keys, output_dir):
            out = pathlib.Path(output_dir)
            out.mkdir(parents=True, exist_ok=True)
            (out / f"{image.name}.raw").write_bytes(b"fake-raw-image-data")

        mock_builder.run.side_effect = fake_run

        builder = SimpleBuilder(
            work_dir=str(work_dir),
            deps=[],
            elements=[base.Element(manifest=manifest_rel, images=[img])],
            image_builder=mock_builder,
            logger=DummyLogger(),
            elements_output_dir=str(out_dir),
        )

        builder.build(
            build_dir=None,
            developer_keys=None,
            build_suffix="1.0.0",
            inventory_mode=True,
            manifest_vars=None,
        )

        inventory_json = out_dir / "inventory.json"
        assert inventory_json.exists()
        data = json.loads(inventory_json.read_text())
        assert isinstance(data, list)
        images = data[0]["images"]
        image_names = [pathlib.Path(p).name for p in images]
        assert any(n.endswith(".raw") for n in image_names)
        assert any(n.endswith(".raw.gz") for n in image_names)
