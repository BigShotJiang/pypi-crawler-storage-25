#    Copyright 2025 Genesis Corporation.
#
#    All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
from __future__ import annotations

from importlib.metadata import entry_points
import io
import itertools
import json
import os
import shutil
import socket
import subprocess
import time
import typing as tp
import urllib.parse
import uuid

from cryptography.hazmat import backends as crypto_back
from cryptography.hazmat.primitives import ciphers
from cryptography.hazmat.primitives.ciphers import algorithms
from cryptography.hazmat.primitives.ciphers import modes as cipher_models
import git
import rich_click as click
import ruamel.yaml

import exordos.constants as c

yaml = ruamel.yaml.YAML()


def load_yaml(file_path: str) -> tp.Any:
    """Load YAML file."""
    with open(file_path, "r") as f:
        return yaml.load(f)


def dump_yaml(data, tf) -> tp.Any:
    yaml.dump(data, tf)


def load_from_entry_point(group: str, name: str) -> tp.Any:
    """Load class from entry points."""
    for ep in entry_points():
        if ep.group == group and ep.name == name:
            return ep.load()

    raise RuntimeError(f"No class '{name}' found in entry points {group}")


def load_driver(config_file: str, group: str = c.EP_BACKUP_DRIVERS) -> tp.Any:
    """Load driver from configuration file."""
    if not os.path.exists(config_file):
        raise FileNotFoundError(f"Configuration file {config_file} not found")

    config = load_yaml(config_file)

    driver = config.get("driver")
    if driver is None:
        raise ValueError("Driver not specified in the configuration file")
    driver_name = tuple(driver.keys())[0]
    driver_class = load_from_entry_point(group, driver_name)

    params = driver.get(driver_name, {})
    return driver_class(**params)


def get_exordos_config(
    project_dir: str,
    exordos_cfg_file: str = c.DEF_GEN_CFG_FILE_NAME,
    exordosctl_cfg_file: str = c.CONFIG_FILE,
) -> tp.Tuple[tp.Dict[str, tp.Any], str]:
    """Find the project configuration file."""
    alternatives = [
        os.path.join(project_dir, exordos_cfg_file),
        os.path.join(project_dir, c.DEF_GEN_WORK_DIR_NAME, exordos_cfg_file),
        os.path.join(project_dir, "genesis", "genesis.yaml"),
        exordosctl_cfg_file,
    ]

    for alt in alternatives:
        if os.path.exists(alt):
            return load_yaml(alt), alt

    raise FileNotFoundError("exordos configuration file not found")


def get_keys_by_path_or_env(
    cmd_path: tp.Optional[str], cli_path: tp.Optional[str]
) -> tp.Optional[str]:
    # Keys by path has the first priority
    if cmd_path is not None:
        cmd_path = os.path.expanduser(cmd_path)
        if not os.path.exists(cmd_path) or not os.path.isfile(cmd_path):
            raise ValueError(f"Invalid path to the developer keys: {cmd_path}")

        with open(cmd_path) as f:
            return f.read()
    # The second priority is the developer key by env
    elif developer_keys := os.environ.get(c.ENV_GEN_DEV_KEYS):
        return developer_keys
    elif cli_path is not None:
        cli_path = os.path.expanduser(cli_path)
        if not os.path.exists(cli_path) or not os.path.isfile(cli_path):
            raise ValueError(f"Invalid path to the developer keys: {cli_path}")

        with open(cli_path) as f:
            return f.read()
    return None


def installation_net_name(name: str) -> str:
    return f"{name}-net"


def installation_boot_net_name(name: str) -> str:
    return f"{name}-boot-net"


def installation_bootstrap_name(name: str) -> str:
    return f"{name}-bootstrap"


def installation_name_from_bootstrap(bootstrap_name: str) -> str:
    return bootstrap_name.replace("-bootstrap", "")


def get_repo(path: str) -> git.Repo:
    repo = git.Repo(path)
    return repo


def get_project_version(
    path: str, rc_branches=c.RC_BRANCHES, start_version=(0, 0, 0)
) -> str:
    if not os.path.exists(path):
        raise FileNotFoundError(f"File {path} not found")

    if not os.path.isdir(path):
        raise ValueError(f"Path {path} is not a directory")

    # Open the git repo
    repo = git.Repo(path)

    # If a tag is set, return it as version
    for tag in repo.tags:
        if tag.commit == repo.head.commit:
            return tag.name

    # Find the nearest tag
    nearest_tag = None
    for commit in repo.iter_commits(max_count=100):
        for tag in repo.tags:
            if tag.commit == commit:
                nearest_tag = tag
                break

        if nearest_tag:
            break

    # Get the current version
    if nearest_tag:
        try:
            major, minor, patch = (int(i) for i in nearest_tag.name.split("."))
        except ValueError:
            raise ValueError(
                f"Invalid format for tag {nearest_tag.name}, "
                "expected major.minor.patch version format"
            )
    # Empty repo, start from 0.0.0
    else:
        major, minor, patch = start_version

    # Increment the version
    patch += 1

    hexsha = repo.head.commit.hexsha

    try:
        branch = repo.active_branch.name
    except Exception:
        # Detached head
        branch = None

    date = repo.head.commit.committed_date
    date_repr = "{}{:02}{:02}{:02}{:02}{:02}".format(
        time.gmtime(date).tm_year,
        time.gmtime(date).tm_mon,
        time.gmtime(date).tm_mday,
        time.gmtime(date).tm_hour,
        time.gmtime(date).tm_min,
        time.gmtime(date).tm_sec,
    )

    # Determine the prefix
    if branch in rc_branches:
        prefix = "rc"
    else:
        prefix = "dev"

    return f"{major}.{minor}.{patch}-{prefix}+{date_repr}.{hexsha[:8]}"


def wait_for(
    predicate: tp.Callable,
    timeout: float = 120.0,
    step: float = 0.5,
    title: str | None = None,
) -> None:
    spinner = itertools.cycle(("-", "\\", "|", "/"))
    start = time.monotonic()
    print(f"{title} ... ", end="")
    while not predicate():
        # Print the title and interactive spinner
        if title:
            print(f"\r{title} ... {next(spinner)}", end="")

        if time.monotonic() - start > timeout:
            raise TimeoutError(f"Timeout after {timeout} seconds")
        time.sleep(step)

    print(f"\r{title} ... ok")


def get_version_suffix(version_type: c.VersionSuffixType, **kwargs) -> str:
    if version_type == "latest":
        return "latest"
    elif version_type == "none":
        return ""
    elif version_type == "element":
        if "project_dir" not in kwargs:
            raise ValueError("project_dir is required for element version type")
        project_dir = kwargs["project_dir"]
        return get_project_version(project_dir)

    raise ValueError(f"Invalid version type {version_type}")


def get_directory_size(directory: str) -> int:
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(directory):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)

        for d in dirnames:
            total_size += get_directory_size(os.path.join(dirpath, d))

    return total_size


def human_readable_size(size: int, decimal_places: int = 2):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024.0:
            break
        size /= 1024.0
    return f"{size:.{decimal_places}f} {unit}"


def backup_path(backup_dir: str) -> str:
    backup_relative_path = time.strftime("%Y-%m-%d-%H-%M-%S")
    return os.path.join(backup_dir, backup_relative_path)


def compress_dir(
    directory: str, output_dir: str, compression_format: str = "gztar"
) -> None:
    """
    Compresses the specified directory and places the archive in the
    output directory.

    :param directory: The path to the directory to be compressed.
    :param output_dir: The path to the directory where the compressed
                       archive will be placed.
    :param compression_format: The compression format to use. Defaults
                              to gztar.
    """
    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Define the base name for the archive (without extension)
    archive_base_name = os.path.join(output_dir, os.path.basename(directory))

    # Create a zip archive of the directory
    shutil.make_archive(archive_base_name, compression_format, directory)


def encrypt_file(
    path: str,
    key: bytes,
    iv: bytes,
    chunk_size_kb: int = 128,
    extension: str = c.ENCRYPTED_EXTENSION,
) -> None:
    # Ensure that the key and iv are the correct lengths
    # for AES (16 bytes for AES-128)
    if len(key) != 16 or len(iv) != 16:
        raise ValueError("Key and IV must be 16 bytes long")

    # Create a cipher object
    cipher = ciphers.Cipher(
        algorithms.AES(key),
        cipher_models.CFB(iv),
        backend=crypto_back.default_backend(),
    )
    chunk_size = chunk_size_kb << 10
    encrypted_path = path + extension

    # Open the input file and the temporary output file
    try:
        with open(path, "rb") as infile, open(encrypted_path, "wb") as outfile:
            # Create an encryptor object
            encryptor = cipher.encryptor()

            # Read the file in chunks and write the encrypted
            # data to the temp file
            while True:
                chunk = infile.read(chunk_size)
                if len(chunk) == 0:
                    break
                outfile.write(encryptor.update(chunk))
            outfile.write(encryptor.finalize())
    except Exception as e:
        os.remove(encrypted_path)
        raise e


def decrypt_file(
    path: str,
    key: bytes,
    iv: bytes,
    chunk_size_kb: int = 128,
    extension: str = c.ENCRYPTED_EXTENSION,
) -> None:
    # Ensure that the key and iv are the correct lengths
    # for AES (16 bytes for AES-128)
    if len(key) != 16 or len(iv) != 16:
        raise ValueError("Key and IV must be 16 bytes long")

    # Create a cipher object
    cipher = ciphers.Cipher(
        algorithms.AES(key),
        cipher_models.CFB(iv),
        backend=crypto_back.default_backend(),
    )
    chunk_size = chunk_size_kb << 10
    plain_path = path[: -len(extension)] if path.endswith(extension) else path
    tmp_path = plain_path + ".tmp"

    # Open the encrypted file and the temporary output file
    try:
        with open(path, "rb") as infile, open(tmp_path, "wb") as outfile:
            # Create a decryptor object
            decryptor = cipher.decryptor()

            # Read the file in chunks and write the decrypted data to the temp file
            while True:
                chunk = infile.read(chunk_size)
                if len(chunk) == 0:
                    break
                outfile.write(decryptor.update(chunk))
            outfile.write(decryptor.finalize())
    except Exception as e:
        os.remove(tmp_path)
        raise e

    # Replace the encrypted file with the decrypted temp file
    if plain_path == path:
        os.replace(tmp_path, plain_path)
    else:
        shutil.move(tmp_path, plain_path)


class ReaderEncryptorIO(io.BytesIO):
    def __init__(
        self,
        file: tp.IO[bytes],
        key: bytes,
        iv: bytes,
        chunk_size_kb: int = 128,
    ) -> None:
        # Ensure that the key and iv are the correct lengths
        # for AES (16 bytes for AES-128)
        if len(key) != 16 or len(iv) != 16:
            raise ValueError("Key and IV must be 16 bytes long")

        self._file = file
        self._cipher = ciphers.Cipher(
            algorithms.AES(key),
            cipher_models.CFB(iv),
            backend=crypto_back.default_backend(),
        )

        self._encryptor = self._cipher.encryptor()
        self._chunk_size = chunk_size_kb << 10

    def tell(self) -> int:
        return self._file.tell()

    def read(self, size: int = -1) -> bytes:
        if size == 0:
            return b""

        if size < 0:
            return (
                self._encryptor.update(self._file.read()) + self._encryptor.finalize()
            )

        data = self._file.read(size)
        if len(data) < size:
            return self._encryptor.update(data) + self._encryptor.finalize()

        return self._encryptor.update(data)

    def seek(self, offset: int, whence: int = 0) -> int:
        if offset == 0 and whence == 0:
            self._encryptor = self._cipher.encryptor()

        return self._file.seek(offset, whence)

    def close(self) -> None:
        self._file.close()

    def __enter__(self) -> tp.IO[bytes]:
        return self

    def __exit__(
        self,
        exc_type: tp.Type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: tp.Any,
    ) -> None:
        self.close()


def make_iso(src_dir: str, iso_path: str, label: str = "config-drive") -> None:
    if not os.path.isdir(src_dir):
        raise ValueError(f"src_dir is not a directory: {src_dir}")

    out_dir = os.path.dirname(iso_path) or "."
    os.makedirs(out_dir, exist_ok=True)

    tool = shutil.which("genisoimage") or shutil.which("mkisofs")
    if tool is None:
        raise RuntimeError("genisoimage/mkisofs not found in PATH")

    proc = subprocess.run(
        [tool, "-J", "-r", "-V", label, "-o", iso_path, src_dir],
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"ISO build failed (rc={proc.returncode}): {proc.stderr.strip()}"
        )


def current_dir_name() -> str:
    """Returns the name of the current working directory."""
    return os.path.basename(os.getcwd())


def is_valid_uuid(uuid_to_test: tp.Any, version: int = 4) -> bool:
    try:
        if isinstance(uuid_to_test, uuid.UUID):
            return True
        uuid.UUID(uuid_to_test, version=version)
        return True
    except (ValueError, AttributeError):
        return False


def get_project_path() -> str:
    # Repository path
    return os.sep.join(__file__.split(os.sep)[:-2])


def convert_to_nearest_type(value: str) -> bool | int | float | list | dict | str:
    lower_value = value.lower()
    if lower_value in ("true", "false"):
        return lower_value == "true"

    try:
        return int(value)
    except ValueError:
        pass

    try:
        return float(value)
    except ValueError:
        pass

    if (value.startswith("[") and value.endswith("]")) or (
        value.startswith("{") and value.endswith("}")
    ):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, (list, dict)):
                return parsed
        except (ValueError, TypeError):
            pass

    return value


PROJECT_PATH = get_project_path()


def validate_config(data: dict, schema: tp.Optional[dict]) -> None:
    try:
        from jsonschema.exceptions import ValidationError
        import openapi_schema_validator

        if data and schema:
            try:
                openapi_schema_validator.validate(
                    data, schema, cls=openapi_schema_validator.OAS30Validator
                )
            except ValidationError as err:
                raise ValueError(f"{err.message} in {err.json_path}")
    except ModuleNotFoundError:
        pass
    return None


def load_spec() -> dict:
    spec_path = os.path.join(PROJECT_PATH, c.PKG_NAME, "spec", "exordos_spec.yaml")
    return load_yaml(spec_path)


def convert_input_multiply(params: tuple[str, ...]) -> dict[str, str]:
    result = {}
    for param in params:
        if "=" not in param:
            raise click.UsageError(
                f"Invalid variable format: '{param}'. Expected 'key=value'."
            )
        key, value = param.split("=", 1)
        result[key] = value
    return result


def get_ip_from_url(url: str) -> str:
    parsed_url = urllib.parse.urlparse(url)
    hostname = parsed_url.hostname
    if not hostname:
        raise ValueError("Invalid URL: no hostname found")
    try:
        ip_info = socket.getaddrinfo(hostname, None)
        return ip_info[0][4][0]
    except socket.gaierror as e:
        raise RuntimeError(f"Failed to resolve hostname {hostname}: {e}")
