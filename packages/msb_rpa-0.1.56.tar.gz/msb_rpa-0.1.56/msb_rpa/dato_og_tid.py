"""
Module for handling date and time related operations.
"""
from datetime import datetime


def month_conversion(month_name):
    """
    Converts a Danish month name to its corresponding numeric value.

    Args:
        month_name (str): The name of the month in Danish (e.g., 'januar', 'februar').

    Returns:
        int: The numeric value of the month (1-12).

    Raises:
        ValueError: If the month name is not valid.
    """
    months = {
        'januar': 1, 'februar': 2, 'marts': 3, 'april': 4, 'maj': 5, 'juni': 6,
        'juli': 7, 'august': 8, 'september': 9, 'oktober': 10, 'november': 11, 'december': 12
    }

    month_name = month_name.lower().strip()

    if month_name not in months:
        raise ValueError(f"Invalid month name: {month_name}")

    return months[month_name]


def get_last_day_of_month(year, month):
    """
    Finds the last day of a given month for a given year.

    Args:
        year (int): The year (e.g., 2024).
        month (int): The numeric month (1-12).

    Returns:
        int: The last day of the month (28-31).

    Raises:
        ValueError: If the month is out of range (not between 1 and 12).
    """
    if not 1 <= month <= 12:
        raise ValueError(f"Invalid month: {month}. Month must be between 1 and 12.")

    num_days_in_month = [31, 29 if _is_leap_year(year) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

    return num_days_in_month[month - 1]


def _is_leap_year(year):
    """
    Determines if a given year is a leap year.

    Args:
        year (int): The year to check.

    Returns:
        bool: True if the year is a leap year, False otherwise.
    """
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)


def convert_to_danish_date(date_string, med_navn=False):
    """
    Convert a date string from the format "YYYY-MM-DD" to a Danish date format.
    If med_navn is True, the format is "Weekday d. DD. MonthName YYYY".
    If med_navn is False (default), the format is "DD. MonthName YYYY".

    Parameters:
    date_string (str): A string representing the date in the format "YYYY-MM-DD".
    med_navn (bool): If True, include the weekday name in the output.

    Returns:
    str: A string representing the date in the specified Danish format.

    Example:
    >>> convert_to_danish_date("2026-04-29")
    '29. april 2026'
    >>> convert_to_danish_date("2026-04-29", med_navn=True)
    'Onsdag d. 29. april 2026'
    """
    # Parse the input date string into a datetime object
    date_obj = datetime.strptime(date_string, "%Y-%m-%d")

    # List of Danish month and weekday names
    danish_months = [
        "januar", "februar", "marts", "april", "maj", "juni",
        "juli", "august", "september", "oktober", "november", "december"
    ]
    danish_weekdays = [
        "mandag", "tirsdag", "onsdag", "torsdag", "fredag", "lørdag", "søndag"
    ]

    # Get the day, month, year, and weekday from the datetime object
    day = date_obj.day
    month = danish_months[date_obj.month - 1]
    year = date_obj.year
    weekday = danish_weekdays[date_obj.weekday()]

    if med_navn:
        return f"{weekday} d. {day}. {month} {year}"
    else:
        return f"{day}. {month} {year}"
