"""
Module for managing Windows related tasks
"""
import time
import psutil
import pygetwindow as gw


def kill_process_by_name(process_name):
    """
    Lukker job fra joblisten med det givne navn (f.eks. 'BogV.exe', 'KMDLOGON.EXE' etc.)
    """
    for process in psutil.process_iter(['pid', 'name']):
        if process.info['name'] == process_name:
            # Get the process ID (PID) for the matching process
            pid = process.info['pid']
            try:
                # Create a Process object for the specified PID
                process = psutil.Process(pid)
                process.terminate()
                print(f"Process {process_name} with PID {pid} terminated.")
            except psutil.NoSuchProcess as e:
                print(f"Error: {e}")
            break


def close_window_by_title(window_titles, target_edge_windows=False):
    """Closes any open window(s) with a title that contains the specified string(s).
    Accepts a single window title string or a list of window title strings.
    Ignores Edge windows if target_edge_windows is set to False."""

    # Normalize input to always be a list
    if isinstance(window_titles, str):
        window_titles = [window_titles]

    # Lowercase all search titles for case-insensitive matching
    window_titles_lower = [t.lower() for t in window_titles]

    time.sleep(3)  # Pause to ensure any recently opened windows are fully loaded

    # Lowercase all open window titles for case-insensitive matching
    all_titles = gw.getAllTitles()
    matching_windows = [
        window for window in all_titles
        if any(search_title in window.lower() for search_title in window_titles_lower)
    ]

    if matching_windows:
        for title in matching_windows:
            # Check if the window is an Edge window and if it should be ignored
            if "Microsoft\u200b Edge" in title and target_edge_windows is False:
                print(f"Skipping Edge window with title '{title}'.")
                continue  # Skip closing this Edge window

            # Close each window with a matching title
            gw.getWindowsWithTitle(title)[0].close()
            print(f"Window with title '{title}' closed successfully.")
    else:
        print("No open windows with the specified title found.")
