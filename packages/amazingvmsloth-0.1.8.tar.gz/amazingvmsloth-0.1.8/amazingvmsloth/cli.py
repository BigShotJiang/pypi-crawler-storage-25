import argparse
import sys
import json
import os

# Suppress transformers loading progress bars that can crash on Windows terminal
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")

def main():
    parser = argparse.ArgumentParser(
        prog="amazingvmsloth",
        description="Blazing-fast LLM fine-tuning with minimal VRAM",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    train_parser = subparsers.add_parser("train", help="Fine-tune a model")
    train_parser.add_argument("--model", required=True, help="Model name or path")
    train_parser.add_argument("--dataset", required=True, nargs='+', help="Dataset path(s) or HuggingFace dataset name(s). Can specify multiple: --dataset ds1 ds2 ds3")
    train_parser.add_argument("--output-dir", default="./output", help="Output directory")
    train_parser.add_argument("--epochs", type=int, default=3, help="Number of training epochs")
    train_parser.add_argument("--batch-size", type=int, default=2, help="Per-device batch size")
    train_parser.add_argument("--grad-accum", type=int, default=4, help="Gradient accumulation steps")
    train_parser.add_argument("--lr", type=float, default=2e-4, help="Learning rate")
    train_parser.add_argument("--lora-r", type=int, default=16, help="LoRA rank")
    train_parser.add_argument("--lora-alpha", type=int, default=16, help="LoRA alpha")
    train_parser.add_argument("--max-seq-length", type=int, default=2048, help="Max sequence length")
    train_parser.add_argument("--quant", choices=["4bit", "8bit", "none"], default="4bit", help="Quantization")
    train_parser.add_argument("--multi-gpu", choices=["ddp", "fsdp", "deepspeed", "none"], default="none")
    train_parser.add_argument("--optimizer", default="paged_adamw_8bit", help="Optimizer (paged_adamw_8bit, cpu_offloaded_adamw, adamw)")
    train_parser.add_argument("--bf16", action="store_true", default=True, help="Use bfloat16")
    train_parser.add_argument("--no-bf16", action="store_false", dest="bf16")
    train_parser.add_argument("--gradient-checkpointing", action="store_true", default=True)
    train_parser.add_argument("--packing", action="store_true", default=True, help="Pack sequences for efficiency")
    train_parser.add_argument("--no-packing", action="store_false", dest="packing")
    train_parser.add_argument("--compile", action="store_true", default=False, help="Use torch.compile for speed")
    train_parser.add_argument("--max-samples", type=int, default=0, help="Limit dataset size (0=all)")
    train_parser.add_argument("--low-vram", action="store_true", default=False, help="Auto-tune for 4-6GB GPUs")
    train_parser.add_argument("--offload-layers", type=int, default=0, help="GPU layers to keep (2-4 for 4GB, 0=disabled)")
    train_parser.add_argument("--cpu", action="store_true", default=False, help="CPU-only training (experimental)")
    train_parser.add_argument("--low-ram", action="store_true", default=False, help="Auto-tune for low RAM (16GB or less, forces bf16 + no compile)")
    train_parser.add_argument("--dataset-format", choices=["auto", "text", "chat", "alpaca"], default="auto", help="Dataset column format")
    train_parser.add_argument("--steps-equals-samples", action="store_true", default=False, help="1 step per sample (batch=1, accum=1, no packing)")
    train_parser.add_argument("--resume", type=str, default=None, help="Resume from checkpoint directory")
    train_parser.add_argument("--seed", type=int, default=42)

    info_parser = subparsers.add_parser("info", help="Show model info and memory estimates")
    info_parser.add_argument("--model", required=True, help="Model name or path")
    info_parser.add_argument("--quant", choices=["4bit", "8bit", "16bit"], default="4bit")
    info_parser.add_argument("--lora-r", type=int, default=16)
    info_parser.add_argument("--num-gpus", type=int, default=1)
    info_parser.add_argument("--seq-length", type=int, default=2048)
    info_parser.add_argument("--batch-size", type=int, default=2)

    merge_parser = subparsers.add_parser("merge", help="Merge LoRA weights into base model")
    merge_parser.add_argument("--model", required=True, help="Base model path")
    merge_parser.add_argument("--lora", required=True, help="LoRA weights path")
    merge_parser.add_argument("--output", required=True, help="Output path")

    convert_parser = subparsers.add_parser("convert", help="Merge LoRA and convert to GGUF")
    convert_parser.add_argument("--model", required=True, help="Base model name or path")
    convert_parser.add_argument("--lora", required=True, help="LoRA adapter path")
    convert_parser.add_argument("--output", default="./model.gguf", help="Output GGUF path")
    convert_parser.add_argument("--quant", choices=["q4_0", "q4_k_m", "q5_k_m", "q6_k", "q8_0", "f16"], default="q4_k_m", help="GGUF quantization type")
    convert_parser.add_argument("--keep-merged", action="store_true", help="Keep merged HF model after conversion")

    bench_parser = subparsers.add_parser("bench", help="Benchmark vs unsloth")
    bench_parser.add_argument("--model", default="unsloth/Qwen2.5-1.5B-bnb-4bit")
    bench_parser.add_argument("--dataset", default="tatsu-lab/alpaca")
    bench_parser.add_argument("--max-samples", type=int, default=500)
    bench_parser.add_argument("--max-seq-length", type=int, default=512)
    bench_parser.add_argument("--skip-unsloth", action="store_true", help="Skip unsloth (run amazingvmsloth only)")

    wizard_parser = subparsers.add_parser("wizard", help="Interactive config generator based on your hardware")
    wizard_parser.add_argument("--model", default=None, help="Model name (skip interactive selection)")
    wizard_parser.add_argument("--aggressive", action="store_true", help="Push hardware harder (larger batch/seq)")
    wizard_parser.add_argument("--json", default=None, help="Save config to JSON file")
    wizard_parser.add_argument("--non-interactive", action="store_true", help="Skip prompts, just print config")

    args = parser.parse_args()

    if args.command == "train":
        _cmd_train(args)
    elif args.command == "info":
        _cmd_info(args)
    elif args.command == "merge":
        _cmd_merge(args)
    elif args.command == "convert":
        _cmd_convert(args)
    elif args.command == "bench":
        from amazingvmsloth.bench import run_amazingvmsloth, run_unsloth
        import sys

        model_name = args.model
        dataset_name = args.dataset
        max_samples = args.max_samples
        max_seq_length = args.max_seq_length

        print(f"\n{'='*60}")
        print(f"  Benchmark: amazingvmsloth vs unsloth")
        print(f"{'='*60}")
        print(f"  Model:      {model_name}")
        print(f"  Dataset:    {dataset_name}")
        print(f"  Samples:    {max_samples}")
        print(f"  Seq length: {max_seq_length}")
        print(f"{'='*60}\n")

        print("[bench] Running amazingvmsloth...")
        av_result = run_amazingvmsloth(model_name, dataset_name, max_samples, max_seq_length)
        print(f"[bench] amazingvmsloth done: {av_result['time_s']}s, {av_result['vram_peak_gb']}GB peak VRAM\n")

        us_result = None
        if not args.skip_unsloth:
            print("[bench] Running unsloth...")
            us_result = run_unsloth(model_name, dataset_name, max_samples, max_seq_length)
            if us_result.get("error"):
                print(f"[bench] unsloth skipped: {us_result['error']}\n")
                us_result = None
            else:
                print(f"[bench] unsloth done: {us_result['time_s']}s, {us_result['vram_peak_gb']}GB peak VRAM\n")

        print(f"\n{'='*60}")
        print(f"  Results")
        print(f"{'='*60}")
        print(f"  {'Metric':<20} {'amazingvmsloth':>15} {'unsloth':>15}")
        print(f"  {'-'*20} {'-'*15} {'-'*15}")
        print(f"  {'Time (s)':<20} {av_result['time_s']:>15} {us_result['time_s'] if us_result else 'N/A':>15}")
        print(f"  {'Peak VRAM (GB)':<20} {av_result['vram_peak_gb']:>15} {us_result['vram_peak_gb'] if us_result else 'N/A':>15}")
        print(f"  {'Final Loss':<20} {av_result['loss']:>15} {us_result['loss'] if us_result else 'N/A':>15}")
        print(f"  {'Steps':<20} {av_result['steps']:>15} {us_result['steps'] if us_result else 'N/A':>15}")

        if us_result and us_result["time_s"] > 0 and av_result["time_s"] > 0:
            speedup = us_result["time_s"] / av_result["time_s"]
            vram_saved = us_result["vram_peak_gb"] - av_result["vram_peak_gb"]
            print(f"\n  Speedup:    {speedup:.2f}x")
            print(f"  VRAM saved: {vram_saved:.2f} GB")
            if speedup > 1:
                print(f"  amazingvmsloth is {speedup:.2f}x faster!")
            else:
                print(f"  unsloth is {1/speedup:.2f}x faster")
        print(f"{'='*60}\n")
    elif args.command == "wizard":
        from amazingvmsloth.wizard import run_wizard_interactive, run_wizard_quick
        if args.non_interactive or args.model:
            run_wizard_quick(args.model or "unsloth/Qwen2.5-1.5B-bnb-4bit", args.aggressive, args.json)
        else:
            run_wizard_interactive(args.model, args.aggressive, args.json)
    else:
        parser.print_help()


def _cmd_train(args):
    import torch
    from transformers import AutoTokenizer
    from datasets import load_dataset
    from amazingvmsloth import (
        quantize_model_4bit,
        apply_lora,
        LoRAConfig,
        AmazingTrainer,
        TrainingConfig,
        auto_patch_model,
    )
    from amazingvmsloth.utils.banner import print_banner, print_model_loading, print_training_start, get_system_info
    from amazingvmsloth.utils.memory import estimate_memory_requirements

    info = get_system_info()
    print_banner(info, args.model)

    # VRAM auto-tune
    if args.low_vram or (info.get("gpu_memory_gb", 16) < 6):
        print("  [auto-tune] Low VRAM detected. Optimizing settings...")
        if args.max_seq_length > 512:
            print(f"  [auto-tune] Reducing max_seq_length: {args.max_seq_length} -> 512")
            args.max_seq_length = 512
        if args.batch_size > 1:
            print(f"  [auto-tune] Reducing batch_size: {args.batch_size} -> 1")
            args.batch_size = 1
        if not args.gradient_checkpointing:
            print("  [auto-tune] Enabling gradient checkpointing")
            args.gradient_checkpointing = True
        if args.lora_r > 16:
            print(f"  [auto-tune] Reducing LoRA rank: {args.lora_r} -> 16")
            args.lora_r = 16
        if args.compile:
            print("  [auto-tune] Disabling torch.compile (overhead on small runs)")
            args.compile = False

    print(f"[amazingvmsloth] Loading tokenizer: {args.model}")
    tokenizer = AutoTokenizer.from_pretrained(args.model)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # CPU mode: no quantization, load in fp32 or bf16
    if args.cpu:
        print_model_loading(args.model, "fp32/bf16 (CPU)")
        from transformers import AutoModelForCausalLM
        # Always try bf16 on CPU: PyTorch handles emulation gracefully.
        # bf16 halves memory bandwidth (the CPU bottleneck) and most
        # modern CPUs support it natively or via AMX.
        dtype = torch.bfloat16
        print(f"[amazingvmsloth] Loading model in {dtype} for CPU...")
        try:
            model = AutoModelForCausalLM.from_pretrained(
                args.model,
                dtype=dtype,
                device_map="cpu",
                low_cpu_mem_usage=True,
            )
        except Exception:
            print("[amazingvmsloth] bf16 load failed, falling back to fp32")
            dtype = torch.float32
            model = AutoModelForCausalLM.from_pretrained(
                args.model,
                dtype=dtype,
                device_map="cpu",
                low_cpu_mem_usage=True,
            )
    else:
        print_model_loading(args.model, args.quant)
        if args.quant == "4bit":
            model = quantize_model_4bit(args.model)
        elif args.quant == "8bit":
            from amazingvmsloth.quantization import quantize_model_8bit
            model = quantize_model_8bit(args.model)
        else:
            from transformers import AutoModelForCausalLM
            model = AutoModelForCausalLM.from_pretrained(
                args.model,
                torch_dtype=torch.bfloat16 if args.bf16 else torch.float32,
                device_map="auto",
            )

    print("[amazingvmsloth] Applying patches and LoRA...")
    lora_config = LoRAConfig(
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        use_rslora=True,
        use_manual_gradients=False,
    )
    model = auto_patch_model(model, apply_lora_patch=True, lora_config=lora_config)

    # Load and concatenate multiple datasets
    datasets_to_load = args.dataset if isinstance(args.dataset, list) else [args.dataset]
    print(f"[amazingvmsloth] Loading {len(datasets_to_load)} dataset(s): {', '.join(datasets_to_load)}")

    loaded_datasets = []
    for ds_name in datasets_to_load:
        if os.path.isfile(ds_name):
            # Local file (jsonl, json, csv, etc.)
            ext = os.path.splitext(ds_name)[1].lower()
            if ext in ('.json', '.jsonl'):
                ds = load_dataset("json", data_files=ds_name, split="train")
            elif ext == '.csv':
                ds = load_dataset("csv", data_files=ds_name, split="train")
            elif ext == '.parquet':
                ds = load_dataset("parquet", data_files=ds_name, split="train")
            else:
                ds = load_dataset("text", data_files=ds_name, split="train")
        else:
            # HuggingFace dataset name
            ds = load_dataset(ds_name, split="train")
        loaded_datasets.append(ds)
        print(f"  - {ds_name}: {len(ds)} samples")

    if len(loaded_datasets) == 1:
        dataset = loaded_datasets[0]
    else:
        from datasets import concatenate_datasets
        dataset = concatenate_datasets(loaded_datasets)
        print(f"[amazingvmsloth] Combined dataset: {len(dataset)} total samples")

    if args.max_samples > 0:
        dataset = dataset.select(range(min(args.max_samples, len(dataset))))
        print(f"[amazingvmsloth] Limited to {len(dataset)} samples")

    # Determine dataset format (use first dataset's columns for auto-detect)
    dataset_format = args.dataset_format
    if dataset_format == "auto":
        if "messages" in dataset.column_names:
            dataset_format = "chat"
        elif "instruction" in dataset.column_names and "output" in dataset.column_names:
            dataset_format = "alpaca"
        else:
            dataset_format = "text"

    if dataset_format == "chat":
        print("[amazingvmsloth] Formatting chat dataset with apply_chat_template...")
        has_template = hasattr(tokenizer, "apply_chat_template") and tokenizer.chat_template is not None
        def chat_format_fn(examples):
            if has_template:
                texts = [
                    tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=False)
                    for msgs in examples["messages"]
                ]
            else:
                # Fallback for models without chat template
                texts = []
                for msgs in examples["messages"]:
                    parts = []
                    for msg in msgs:
                        role = msg.get("role", "user")
                        content = msg.get("content", "")
                        parts.append(f"<{role}>\n{content}")
                    texts.append("\n".join(parts))
            return tokenizer(texts, truncation=True, max_length=args.max_seq_length)
        tokenized = dataset.map(chat_format_fn, batched=True, remove_columns=dataset.column_names)

    elif dataset_format == "alpaca":
        print("[amazingvmsloth] Formatting alpaca dataset...")
        inst_col = "instruction" if "instruction" in dataset.column_names else "prompt"
        out_col = None
        for c in ["output", "response", "answer"]:
            if c in dataset.column_names:
                out_col = c
                break
        ctx_col = "context" if "context" in dataset.column_names else None

        def alpaca_format_fn(examples):
            texts = []
            for i in range(len(examples[inst_col])):
                inst = examples[inst_col][i]
                out = examples[out_col][i] if out_col else ""
                ctx = examples[ctx_col][i] if ctx_col and examples[ctx_col][i] else ""
                if ctx:
                    texts.append(f"### Instruction:\n{inst}\n\n### Input:\n{ctx}\n\n### Response:\n{out}")
                else:
                    texts.append(f"### Instruction:\n{inst}\n\n### Response:\n{out}")
            return tokenizer(texts, truncation=True, max_length=args.max_seq_length)
        tokenized = dataset.map(alpaca_format_fn, batched=True, remove_columns=dataset.column_names)

    else:  # text
        text_column = None
        for col in ["text", "input", "content", "prompt"]:
            if col in dataset.column_names:
                text_column = col
                break
        if text_column is None:
            text_column = dataset.column_names[0]
            print(f"[amazingvmsloth] Warning: using first column '{text_column}' as text")
        def tokenize_fn(examples):
            texts = examples[text_column]
            return tokenizer(texts, truncation=True, max_length=args.max_seq_length)
        tokenized = dataset.map(tokenize_fn, batched=True, remove_columns=dataset.column_names)

    tokenized = tokenized.map(lambda x: {"labels": x["input_ids"]}, batched=True)
    # Don't set_format("torch") — datasets' torch formatter crashes on Windows
    # because it tries to import torchvision.io.VideoReader which isn't available.
    # Our collator handles list->tensor conversion manually.

    if args.cpu:
        return _cmd_train_cpu(args, tokenizer, model, dataset, tokenized)

    if args.low_vram:
        if args.max_seq_length > 512:
            print(f"[amazingvmsloth] --low-vram: reducing max_seq_length {args.max_seq_length} -> 512")
            args.max_seq_length = 512
        if args.optimizer == "cpu_offloaded_adamw":
            print("[amazingvmsloth] --low-vram: switching to paged_adamw_8bit (faster, fits 4GB)")
            args.optimizer = "paged_adamw_8bit"
        if args.lora_r > 8:
            print(f"[amazingvmsloth] --low-vram: reducing lora_r {args.lora_r} -> 8")
            args.lora_r = 8
        if args.offload_layers == 0 and torch.cuda.is_available():
            from amazingvmsloth.offload import estimate_model_size_gb
            model_gb_4bit = estimate_model_size_gb(args.model) * 0.5
            vram_gb = torch.cuda.get_device_properties(0).total_memory / 1024**3
            if model_gb_4bit > vram_gb * 0.6:
                args.offload_layers = 2
                print(f"[amazingvmsloth] --low-vram: model ~{model_gb_4bit:.1f}GB 4-bit > {vram_gb:.0f}GB VRAM, enabling offload_layers=2")

    if args.steps_equals_samples:
        print("[amazingvmsloth] --steps-equals-samples: setting batch_size=1, grad_accum=1, no packing")
        args.batch_size = 1
        args.grad_accum = 1
        args.packing = False

    config = TrainingConfig(
        output_dir=args.output_dir,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        gradient_accumulation_steps=args.grad_accum,
        learning_rate=args.lr,
        bf16=args.bf16,
        optim=args.optimizer,
        max_seq_length=args.max_seq_length,
        seed=args.seed,
        packing=args.packing,
        compile_model=args.compile,
        max_samples=args.max_samples,
        offload_layers=args.offload_layers,
        multi_gpu_strategy=args.multi_gpu if args.multi_gpu != "none" else None,
    )

    trainer = AmazingTrainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=tokenized,
        config=config,
    )

    if args.resume:
        trainer.resume_from_checkpoint(args.resume)

    print_training_start(config)
    result = trainer.train()
    print(f"\n[amazingvmsloth] Training result: {json.dumps({k: v for k, v in result.items() if k != 'log_history'}, indent=2)}")


def _cmd_train_cpu(args, tokenizer, model, dataset, tokenized):
    from amazingvmsloth.cpu_trainer import CpuTrainer, CpuTrainingConfig
    from amazingvmsloth.utils.banner import print_banner, get_system_info
    import torch

    info = get_system_info()
    print_banner(info, args.model)
    print("[amazingvmsloth] CPU training mode activated")

    # Calculate model size
    model_size_gb = sum(p.numel() * p.element_size() for p in model.parameters()) / 1024**3
    ram_gb = info.get("ram_gb", 16)
    
    # Auto-tune for CPU: sequence length is the #1 speed factor for transformers
    # Attention is O(n^2). 128 is ~16x faster than 512, ~64x faster than 1024.
    if args.max_seq_length > 512:
        print(f"[amazingvmsloth] CPU mode: reducing max_seq_length {args.max_seq_length} -> 256")
        args.max_seq_length = 256

    # Low-RAM mode: aggressive memory optimization for large models
    low_ram = args.low_ram or (model_size_gb > 1.5 and ram_gb < 24)
    if low_ram:
        print(f"[amazingvmsloth] Low RAM mode: model={model_size_gb:.1f}GB, RAM={ram_gb:.1f}GB")
        print(f"[amazingvmsloth] Using bf16 + gradient checkpointing + no compile to save memory")
        if args.max_seq_length > 128:
            print(f"[amazingvmsloth] Reducing seq length: {args.max_seq_length} -> 128")
            args.max_seq_length = 128
        compile_model = False
        use_prepacking = False
        dtype = "bf16"
        gradient_checkpointing = True
    else:
        # Windows: torch.compile requires MSVC (cl.exe) which most users don't have.
        # Even with fallback, it's EXTREMELY slow on Windows CPU. NEVER enable by default.
        is_windows = sys.platform.startswith("win")
        compile_model = args.compile if hasattr(args, 'compile') and args.compile else False
        if is_windows and compile_model:
            print("[amazingvmsloth] WARNING: torch.compile on Windows CPU is extremely slow. Use --compile at your own risk.")
        use_prepacking = True
        dtype = "auto"
        gradient_checkpointing = False
        # For small models on CPU with plenty of RAM, use 128 for speed
        if model_size_gb < 2.0 and args.max_seq_length > 128:
            print(f"[amazingvmsloth] CPU speed mode: reducing seq length {args.max_seq_length} -> 128")
            args.max_seq_length = 128

    # For small models (0.5B), larger batch amortizes model-load overhead per step
    if model_size_gb < 2.0 and args.batch_size == 1 and not low_ram:
        new_bs = min(4, max(2, int(2.0 / max(model_size_gb, 0.1))))
        print(f"[amazingvmsloth] Small model ({model_size_gb:.1f}GB), increasing batch size: 1 -> {new_bs}")
        args.batch_size = new_bs

    # CPU: force no quantization. 4/8-bit via bitsandbytes on CPU is
    # excruciatingly slow (dequantization has no optimized CPU kernels).
    quant = "none"
    if args.quant in ("8bit", "4bit"):
        print(f"[amazingvmsloth] WARNING: Ignoring --quant {args.quant} on CPU (bnb quantization is extremely slow on CPU).")

    config = CpuTrainingConfig(
        output_dir=args.output_dir,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        gradient_accumulation_steps=max(1, args.grad_accum * 2),
        learning_rate=args.lr,
        max_seq_length=args.max_seq_length,
        seed=args.seed,
        optim="adamw",
        quant=quant,
        compile_model=compile_model,
        use_prepacking=use_prepacking,
        dtype=dtype,
        gradient_checkpointing=gradient_checkpointing,
        low_ram=low_ram,
    )

    trainer = CpuTrainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=tokenized,
        config=config,
    )

    result = trainer.train()
    print(f"\n[amazingvmsloth] CPU Training result: {json.dumps(result, indent=2)}")


def _cmd_info(args):
    from amazingvmsloth.utils.memory import estimate_memory_requirements
    from amazingvmsloth.utils.banner import print_banner, get_system_info
    import torch

    print_banner(get_system_info(), args.model)

    bits = {"4bit": 4, "8bit": 8, "16bit": 16}[args.quant]

    try:
        from transformers import AutoConfig
        config = AutoConfig.from_pretrained(args.model)
        vocab = getattr(config, "vocab_size", 32000)
        n_layers = getattr(config, "num_hidden_layers", 32)
        h_size = getattr(config, "hidden_size", 4096)
        i_size = getattr(config, "intermediate_size", 11008)
        mlp_size = getattr(config, "mlp_ratio", 3.5) * h_size
        params_b = n_layers * (mlp_size * h_size + 4 * h_size * h_size) + vocab * h_size
        params_b = params_b / 1e9
        model_type = getattr(config, "model_type", "unknown")
    except Exception:
        print("[amazingvmsloth] Could not auto-detect model size, using 7B estimate")
        params_b = 7.0
        model_type = "unknown"

    mem = estimate_memory_requirements(
        model_params_b=params_b,
        seq_length=args.seq_length,
        batch_size=args.batch_size,
        lora_r=args.lora_r,
        bits=bits,
        num_gpus=args.num_gpus,
    )

    print(f"\n  Model Info")
    print(f"  {'-'*40}")
    print(f"  Model:        {args.model}")
    print(f"  Type:         {model_type}")
    print(f"  Parameters:   ~{params_b:.1f}B")
    print(f"  Quantization: {args.quant}")
    print(f"  Seq length:   {args.seq_length}")
    print(f"  Batch size:   {args.batch_size}")
    print(f"  LoRA rank:    {args.lora_r}")
    print()
    print(f"  Memory Estimates")
    print(f"  {'-'*40}")
    for k, v in mem.items():
        print(f"  {k:.<20} {v:.2f} GB")
    print()

    vram_gb = torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else 0
    if vram_gb > 0:
        print(f"  Your GPU VRAM: {vram_gb:.1f} GB")
        required = mem['per_gpu_gb'] * 1.3
        if required <= vram_gb:
            print(f"  Status:        OK (needs ~{required:.1f} GB)")
        else:
            print(f"  Status:        WARNING (needs ~{required:.1f} GB, you have {vram_gb:.1f} GB)")
            print(f"  Recommendation: Use --low-vram or reduce --max-seq-length / --batch-size")
    print()


def _cmd_merge(args):
    import torch
    from transformers import AutoModelForCausalLM
    from amazingvmsloth.lora import apply_lora, LoRAConfig
    from amazingvmsloth.utils.save_load import save_model

    print(f"[amazingvmsloth] Loading base model: {args.model}")
    model = AutoModelForCausalLM.from_pretrained(args.model, torch_dtype=torch.bfloat16, device_map="cpu")

    print(f"[amazingvmsloth] Applying LoRA from: {args.lora}")
    model = apply_lora(model, LoRAConfig(r=16))
    from amazingvmsloth.utils.patching import load_lora_weights
    model = load_lora_weights(model, args.lora)

    print(f"[amazingvmsloth] Merging and saving to: {args.output}")
    save_model(model, None, args.output, merge_lora=True)


def _cmd_convert(args):
    """Merge LoRA adapter and convert to GGUF format."""
    import os
    import tempfile
    import shutil
    import subprocess
    import sys

    # Step 1: Merge LoRA into base model
    merged_dir = os.path.join(tempfile.gettempdir(), "amazingvmsloth_merged_" + os.path.basename(args.lora).replace(".", "_"))
    os.makedirs(merged_dir, exist_ok=True)

    print(f"[amazingvmsloth] Step 1: Merging LoRA into base model...")
    print(f"  Base model: {args.model}")
    print(f"  LoRA:       {args.lora}")
    print(f"  Merged HF:  {merged_dir}")

    # Reuse merge logic
    merge_args = type('Args', (), {
        'model': args.model,
        'lora': args.lora,
        'output': merged_dir,
    })()
    _cmd_merge(merge_args)

    # Step 2: Convert to GGUF
    print(f"\n[amazingvmsloth] Step 2: Converting to GGUF ({args.quant})...")

    # Check for llama.cpp converter
    converter_paths = [
        "convert_hf_to_gguf.py",
        os.path.expanduser("~/llama.cpp/convert_hf_to_gguf.py"),
        os.path.expanduser("~/.local/llama.cpp/convert_hf_to_gguf.py"),
        "/usr/local/bin/convert_hf_to_gguf.py",
    ]

    converter = None
    for path in converter_paths:
        if shutil.which(path) or os.path.isfile(path):
            converter = path if os.path.isfile(path) else shutil.which(path)
            break

    if converter is None:
        # Try pip-installed version
        try:
            result = subprocess.run([sys.executable, "-m", "gguf.scripts.convert_hf_to_gguf", "--help"],
                                    capture_output=True, text=True, timeout=10)
            if result.returncode == 0 or "usage:" in (result.stdout + result.stderr).lower():
                converter = [sys.executable, "-m", "gguf.scripts.convert_hf_to_gguf"]
        except Exception:
            pass

    if converter is None:
        print("\n  ERROR: llama.cpp converter not found.")
        print()
        print("  To convert to GGUF, install llama.cpp:")
        print()
        print("  Option 1 - pip (easiest):")
        print('    pip install "gguf>=0.1.0"')
        print("    python -m gguf.scripts.convert_hf_to_gguf --help")
        print()
        print("  Option 2 - clone llama.cpp:")
        print("    git clone https://github.com/ggerganov/llama.cpp")
        print("    cd llama.cpp && pip install -r requirements.txt")
        print("    python convert_hf_to_gguf.py <path>")
        print()
        print("  The merged HF model is saved here:")
        print(f"    {merged_dir}")
        print()
        print("  Manual conversion command:")
        print(f"    python convert_hf_to_gguf.py {merged_dir} --outfile {args.output} --outtype {args.quant}")
        print()
        if not args.keep_merged:
            print("  Run with --keep-merged to keep the merged model, or delete it manually.")
        return

    # Run conversion
    outdir = os.path.dirname(os.path.abspath(args.output)) or "."
    os.makedirs(outdir, exist_ok=True)

    cmd = [sys.executable, converter] if isinstance(converter, str) and converter.endswith(".py") else ([sys.executable] + converter if isinstance(converter, list) else [converter])
    cmd += [merged_dir, "--outfile", args.output, "--outtype", args.quant]

    print(f"  Running: {' '.join(cmd)}\n")
    try:
        result = subprocess.run(cmd, check=True)
        print(f"\n  SUCCESS: GGUF saved to {args.output}")
    except subprocess.CalledProcessError as e:
        print(f"\n  ERROR: Conversion failed (exit code {e.returncode})")
        print(f"  Merged model is at: {merged_dir}")
        print(f"  Try manually: python convert_hf_to_gguf.py {merged_dir} --outfile {args.output} --outtype {args.quant}")
        return

    # Cleanup
    if not args.keep_merged:
        print(f"  Cleaning up merged HF model: {merged_dir}")
        shutil.rmtree(merged_dir, ignore_errors=True)
    else:
        print(f"  Kept merged HF model: {merged_dir}")

    print()
    print("  Usage with llama.cpp / ollama:")
    print(f"    llama-cli -m {args.output} -p \"Your prompt here\"")
    print(f"    ollama create mymodel -f Modelfile  # point to {args.output}")
    print()


if __name__ == "__main__":
    main()
