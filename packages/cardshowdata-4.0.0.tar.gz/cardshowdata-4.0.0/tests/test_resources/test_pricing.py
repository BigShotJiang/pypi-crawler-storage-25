"""Tests for the Pricing resource — v4 response shape."""

import httpx
import pytest

from cardshowdata import AsyncCardShowData


# v4 PricingResponse: variants is a list of v4 VariantBlock entries
# (raw[] keyed by (condition,currency); per-vertical recommended_sell + recent_sales).
def _variant_block(name: str, market_cents: int) -> dict:
    return {
        "name": name,
        "image": None,
        "raw": [
            {
                "condition": "NM",
                "currency": "USD",
                "snapshot_date": "2026-04-12",
                "reference_prices": {
                    "market_cents": market_cents,
                    "low_cents": int(market_cents * 0.8),
                    "mid_cents": int(market_cents * 0.95),
                    "high_cents": int(market_cents * 1.2),
                    "sources": ["tcgplayer"],
                },
                "recommended_sell": {
                    "online": {
                        "price_cents": market_cents,
                        "approach": "fair_value_spread",
                        "confidence": 0.9,
                        "sales_count": 0,
                        "lifecycle_state": "stable",
                        "adjustment_pct": 0.0,
                    },
                    "show": {
                        "price_cents": market_cents,
                        "approach": "fair_value_spread",
                        "confidence": 0.9,
                        "sales_count": 0,
                        "lifecycle_state": "stable",
                        "adjustment_pct": 0.0,
                    },
                    "lcs": {
                        "price_cents": market_cents,
                        "approach": "fair_value_spread",
                        "confidence": 0.9,
                        "sales_count": 0,
                        "lifecycle_state": "stable",
                        "adjustment_pct": 0.0,
                    },
                },
                "recent_sales": {"online": [], "show": [], "lcs": []},
            }
        ],
        "graded": {},
    }


PRICING_RESPONSE = {
    "product_id": "aaaa-bbbb-cccc",
    "as_of_date": "2026-04-12",
    "variants": [
        _variant_block("normal", 4500),
        _variant_block("holofoil", 12500),
    ],
}

# v4 PricingHistoryResponse: per-(variant, condition) history.
HISTORY_RESPONSE = {
    "product_id": "abc",
    "variants": [
        {
            "subtype": "normal",
            "condition": "NM",
            "history": [
                {"as_of_date": "2026-04-12", "condition": "NM", "market_cents": 4500,
                 "low_cents": 3800, "mid_cents": 4400, "high_cents": 5200,
                 "lifecycle_state": "stable", "confidence": 0.9},
                {"as_of_date": "2026-04-11", "condition": "NM", "market_cents": 4400,
                 "low_cents": 3700, "mid_cents": 4300, "high_cents": 5100,
                 "lifecycle_state": "stable", "confidence": 0.9},
            ],
        },
        {
            "subtype": "holofoil",
            "condition": "NM",
            "history": [
                {"as_of_date": "2026-04-12", "condition": "NM", "market_cents": 12500,
                 "low_cents": 11000, "mid_cents": 12000, "high_cents": 14000,
                 "lifecycle_state": "declining", "confidence": 0.95},
            ],
        },
    ],
}


class TestPricing:
    def test_get(self, mock_api, client):
        mock_api.get("/v1/pricing/aaaa-bbbb-cccc").mock(
            return_value=httpx.Response(200, json=PRICING_RESPONSE)
        )
        price = client.pricing.get("aaaa-bbbb-cccc")
        assert price.product_id == "aaaa-bbbb-cccc"
        assert len(price.variants) == 2
        assert [v.name for v in price.variants] == ["normal", "holofoil"]
        holo = price.variants[1]
        # v4: read market via raw[].reference_prices
        assert holo.raw[0].reference_prices.market_cents == 12500
        assert holo.raw[0].recommended_sell.online.confidence == 0.9
        assert holo.raw[0].recommended_sell.online.lifecycle_state == "stable"

    def test_bulk(self, mock_api, client):
        route = mock_api.post("/v1/pricing/bulk").mock(
            return_value=httpx.Response(200, json=[PRICING_RESPONSE, PRICING_RESPONSE])
        )
        results = client.pricing.bulk(["uuid1", "uuid2"])
        assert len(results) == 2
        assert all(len(r.variants) == 2 for r in results)
        body = route.calls[0].request.read()
        assert b'"product_ids"' in body

    def test_bulk_with_date(self, mock_api, client):
        route = mock_api.post("/v1/pricing/bulk").mock(
            return_value=httpx.Response(200, json=[PRICING_RESPONSE])
        )
        client.pricing.bulk(["uuid1"], date="2026-01-01")
        body = route.calls[0].request.read()
        assert b'"date"' in body
        assert b'"2026-01-01"' in body

    def test_history(self, mock_api, client):
        route = mock_api.get("/v1/pricing/history/abc").mock(
            return_value=httpx.Response(200, json=HISTORY_RESPONSE)
        )
        result = client.pricing.history("abc", days=90)
        assert result.product_id == "abc"
        assert len(result.variants) == 2
        normal = result.variants[0]
        assert normal.subtype == "normal"
        assert normal.condition == "NM"
        assert len(normal.history) == 2
        assert normal.history[0].market_cents == 4500
        assert normal.history[0].condition == "NM"
        assert "days=90" in str(route.calls[0].request.url)

    def test_history_with_condition(self, mock_api, client):
        route = mock_api.get("/v1/pricing/history/abc").mock(
            return_value=httpx.Response(200, json=HISTORY_RESPONSE)
        )
        client.pricing.history("abc", days=90, condition="LP")
        url = str(route.calls[0].request.url)
        assert "condition=LP" in url

    def test_changes(self, mock_api, client):
        mock_api.get("/v1/pricing/changes").mock(
            return_value=httpx.Response(200, json={
                "items": [{
                    "csd_product_id": "abc",
                    "subtype": "holofoil",
                    "condition": "NM",
                    "vertical": "online",
                    "pretty_id": "pk_bs_004_holofoil",
                    "tcg_slug": "pk",
                    "old_price_cents": 100,
                    "new_price_cents": 200,
                    "pct_change": 100.0,
                    "snapshot_date": "2026-04-12",
                }],
                "next_cursor": "cursor_xyz",
                "count": 1,
            })
        )
        page = client.pricing.changes(since="2026-04-07T00:00:00Z")
        assert page.has_next() is True
        assert page.items[0].pct_change == 100.0
        assert page.items[0].subtype == "holofoil"
        assert page.items[0].condition == "NM"
        assert page.items[0].vertical == "online"

    def test_changes_all_auto_pages(self, mock_api, client):
        route = mock_api.get("/v1/pricing/changes")
        route.side_effect = [
            httpx.Response(200, json={
                "items": [{"csd_product_id": "a", "subtype": "normal", "pct_change": 10}],
                "next_cursor": "c1", "count": 2,
            }),
            httpx.Response(200, json={
                "items": [{"csd_product_id": "b", "subtype": "holofoil", "pct_change": 20}],
                "next_cursor": None, "count": 2,
            }),
        ]
        ids = [(c.csd_product_id, c.subtype) for c in client.pricing.changes_all(since="2026-04-07T00:00:00Z")]
        assert ids == [("a", "normal"), ("b", "holofoil")]
        assert route.call_count == 2

    @pytest.mark.asyncio
    async def test_async_get(self, mock_api):
        mock_api.get("/v1/pricing/abc").mock(
            return_value=httpx.Response(200, json=PRICING_RESPONSE)
        )
        async with AsyncCardShowData(api_key="test_key_123") as c:
            price = await c.pricing.get("abc")
            assert len(price.variants) == 2
            assert price.variants[1].raw[0].reference_prices.market_cents == 12500
