"""
This package has been renamed to kanbaroo-core.

Install kanbaroo-core instead: pip install kanbaroo-core
"""

import warnings

warnings.warn(
    "The 'kanberoo-core' package has been renamed to 'kanbaroo-core'. "
    "Please update your installation: pip install kanbaroo-core",
    DeprecationWarning,
    stacklevel=2,
)

__version__ = "0.2.2"
