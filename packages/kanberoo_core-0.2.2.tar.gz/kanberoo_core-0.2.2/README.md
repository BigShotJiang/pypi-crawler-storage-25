# `kanberoo-core` has been renamed

This package has been renamed to [`kanbaroo-core`](https://pypi.org/project/kanbaroo-core/). The name is a portmanteau of `kangaroo` + `kanban`; the middle letter should have been `a` from the start.

## What to install

```
pip install kanbaroo-core
```

## Compatibility

This `kanberoo-core` package remains on PyPI as a version-`0.2.2` compatibility stub that transitively installs `kanbaroo-core==0.2.2`. `pip install kanberoo-core` still works; the canonical name going forward is `kanbaroo-core`. Please update your requirements files and scripts.

## Links

- New package: https://pypi.org/project/kanbaroo-core/
- GitHub: https://github.com/areese801/kanbaroo
