"""读取配置文件"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from dotenv import load_dotenv

APP_ENV = (os.getenv("APP_ENV") or "prod").strip().lower()
VALID_ENVS = {"dev", "test", "prod"}

def _candidate_env_dirs() -> list[Path]:
    dirs: list[Path] = []

    app_env_dir = os.getenv("APP_ENV_DIR")
    if app_env_dir:
        dirs.append(Path(app_env_dir).expanduser().resolve())

    if getattr(sys, "frozen", False):
        dirs.append(Path(sys.executable).resolve().parent)

    dirs.append(Path(__file__).resolve().parent.parent)
    return dirs


def _resolve_env_file() -> Path:
    if APP_ENV not in VALID_ENVS:
        raise ValueError(
            f"Unsupported APP_ENV={APP_ENV!r}. Expected one of: dev, test, prod"
        )

    env_name = f"..env.{APP_ENV}"
    for env_dir in _candidate_env_dirs():
        env_file = env_dir / env_name
        if env_file.exists():
            return env_file

    searched_paths = [str(env_dir / env_name) for env_dir in _candidate_env_dirs()]
    raise FileNotFoundError(
        f"Env file not found for APP_ENV={APP_ENV!r}. Searched: {', '.join(searched_paths)}"
    )


ENV_FILE = _resolve_env_file()
_ENV_LOADED = False


def ensure_env_loaded() -> Path:
    """Load the selected .env file once so import-time config is available."""
    global _ENV_LOADED
    if not _ENV_LOADED:
        load_dotenv(ENV_FILE, override=True)
        _ENV_LOADED = True
    return ENV_FILE
