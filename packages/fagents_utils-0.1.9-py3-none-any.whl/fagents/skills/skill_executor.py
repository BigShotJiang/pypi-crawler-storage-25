import os
import subprocess
import json
import asyncio
import shutil
import shlex
import sys
python_bin = os.environ.get("PYTHON_BIN", "python")

def _shell_path_status(path: str):
    quoted = shlex.quote(path)
    exists = subprocess.run(
        ["sh", "-lc", f"test -e {quoted}"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    ).returncode == 0
    executable = subprocess.run(
        ["sh", "-lc", f"test -x {quoted}"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    ).returncode == 0
    ls_res = subprocess.run(
        ["sh", "-lc", f"ls -l {quoted}"],
        capture_output=True,
        text=True,
        check=False,
    )
    ls_line = (ls_res.stdout or ls_res.stderr).strip()
    return exists, executable, ls_line


class SkillExecutor:
    def __init__(self, base_dir="skills"):
        self.base_dir = base_dir

    def run(self, skill_name, params):
        bin_path = os.path.join(
            self.base_dir,
            skill_name,
            "scripts",
            skill_name
        )
        script_path = os.path.join(
            self.base_dir,
            skill_name,
            "scripts",
            f"{skill_name}.py"
        )
        bin_exists, bin_executable, bin_ls_line = _shell_path_status(bin_path)
        exists, executable, ls_line = _shell_path_status(script_path)

        child_env = os.environ.copy()
        child_env["PYTHONFAULTHANDLER"] = "1"

        if bin_exists and bin_executable:
            proc = subprocess.Popen(
                [bin_path],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=child_env
            )
            out, err = proc.communicate(json.dumps(params).encode())
            if proc.returncode == 0:
                return json.loads(out.decode())

        proc = subprocess.Popen(
            [python_bin, script_path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=child_env
        )

        out, err = proc.communicate(json.dumps(params).encode())

        if proc.returncode != 0:
            raise RuntimeError(err.decode() or "skill script exited with non-zero code")

        return json.loads(out.decode())

class AsyncSkillExecutor:

    def __init__(self, base_dir="skills"):
        self.base_dir = base_dir

    async def run(self, skill_name, params):
        bin_path = os.path.join(
            self.base_dir,
            skill_name,
            "scripts",
            skill_name
        )
        script_path = os.path.join(
            self.base_dir,
            skill_name,
            "scripts",
            f"{skill_name}.py"
        )
        bin_exists, bin_executable, bin_ls_line = _shell_path_status(bin_path)
        exists, executable, ls_line = _shell_path_status(script_path)
        child_env = os.environ.copy()
        child_env["PYTHONFAULTHANDLER"] = "1"

        if bin_exists and bin_executable:
            proc = await asyncio.create_subprocess_exec(
                bin_path,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=child_env
            )
            out, err = await proc.communicate(json.dumps(params).encode())

            if proc.returncode == 0:
                return json.loads(out.decode())

        proc = await asyncio.create_subprocess_exec(
            python_bin, script_path,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=child_env
        )

        out, err = await proc.communicate(json.dumps(params).encode())


        if proc.returncode != 0:
            raise RuntimeError(err.decode() or "skill script exited with non-zero code")

        return json.loads(out.decode())