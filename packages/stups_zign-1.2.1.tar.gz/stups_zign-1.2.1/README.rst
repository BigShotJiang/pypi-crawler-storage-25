====
Zign
====

.. image:: https://travis-ci.org/zalando-stups/zign.svg?branch=master
   :target: https://travis-ci.org/zalando-stups/zign
   :alt: Build Status

.. image:: https://coveralls.io/repos/zalando-stups/zign/badge.svg
   :target: https://coveralls.io/r/zalando-stups/zign
   :alt: Code Coverage

.. image:: https://img.shields.io/pypi/dw/stups-zign.svg
   :target: https://pypi.python.org/pypi/stups-zign/
   :alt: PyPI Downloads

.. image:: https://img.shields.io/pypi/v/stups-zign.svg
   :target: https://pypi.python.org/pypi/stups-zign/
   :alt: Latest PyPI version

.. image:: https://img.shields.io/pypi/l/stups-zign.svg
   :target: https://pypi.python.org/pypi/stups-zign/
   :alt: License

OAuth2 token management command line utility.

Installation
============

Using uv
--------

.. code-block:: bash

    $ uv tool install git+https://github.com/zalando-build/zign.git

Or from a local clone:

.. code-block:: bash

    $ uv tool install .

To uninstall:

.. code-block:: bash

    $ uv tool uninstall stups-zign

Usage
=====

.. code-block:: bash

    $ ztoken

See the `STUPS documentation on zign`_ for details.

Running Unit Tests
==================

.. code-block:: bash

    $ uv run pytest tests/ -v

.. _STUPS documentation on zign: http://stups.readthedocs.org/en/latest/components/zign.html

Releasing
=========

.. code-block:: bash

    $ ./release.sh <NEW-VERSION>
