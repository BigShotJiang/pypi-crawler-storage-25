## Overview

Zign is Zalando’s OAuth2 token management Python module.
It provides the `ztoken` CLI tool and can also be used as a library.

It supports the OAuth2 implicit flow with browser-based authentication and token caching/refresh mechanisms.

## Development Commands

### Setup
```bash
uv sync --locked    # Install dependencies
```

### Running Tests
```bash
uv run pytest tests/ -v                        # Run all tests
uv run pytest tests/test_api.py -s             # Run specific test file
uv run pytest tests/test_api.py::test_is_valid -s  # Run specific test
```

### Code Style
```bash
uv run ruff check   # Run linter
uv run ruff format  # Run formatter
```

## Architecture

### Core Modules

**`zign/api.py`** - Core token management logic
- `get_token_implicit_flow()` - Main entry point for browser-based OAuth2 flow
- `get_token()` - High-level API that tries existing tokens, service tokens (via tokens lib), then falls back to implicit flow
- `get_existing_token()` / `store_token()` - Token persistence in YAML format with file locking to prevent race conditions
- `store_config_ztoken()` - Atomic write using temp-file-and-rename pattern to prevent corruption
- `with file_lock(path)` - Context manager preventing multiple threads/processes from accessing the same file concurrently.
- `perform_implicit_flow()` - Launches local HTTP server (ports 8081-8181) and opens browser for OAuth2 authorization
- Token validation: Tokens must be valid for at least 5 more minutes (`TOKEN_MINIMUM_VALIDITY_SECONDS`)

**`zign/oauth2.py`** - OAuth2 redirect handling
- `ClientRedirectServer` - Local HTTP server that captures OAuth2 redirect
- Serves HTML/JavaScript to extract tokens from URL fragment and redirect to query string
- Listens on localhost:8081-8181

**`zign/cli.py`** - Main CLI interface (ztoken command)
- `token` command - Get or create tokens with optional caching by name
- `list` command - Show all stored tokens with expiration times
- `delete` command - Remove named tokens
- Uses Click framework with `AliasedGroup` for command shortcuts

**`zign/config.py`** - Configuration management
- Config dir: `~/.config/zalando-token-cli/` (via `click.get_app_dir()`)
- `tokens.yaml` - Stores named access tokens with creation time and expiration
- `refresh-token.yaml` - Stores refresh token separately

### Token Flow

1. **Check existing token** - `get_existing_token()` looks up token by name in `tokens.yaml`
2. **Try service token** - `get_service_token()` attempts to use the `tokens` library for machine credentials
3. **Browser flow** - `perform_implicit_flow()` launches local server and opens browser
4. **Capture redirect** - JavaScript extracts token from URL fragment, redirects to localhost with query params
5. **Store token** - Token saved to `tokens.yaml` with creation timestamp using file locking and atomic writes
6. **Refresh token** - If available and no explicit URLs provided, uses refresh token instead of browser flow

### Concurrency Safety

Token storage uses two mechanisms to prevent race conditions when multiple threads/processes store tokens concurrently:
- **File locking** (`file_lock()`): Uses `fcntl.flock()` and a `threading.Lock` for exclusive access during read-modify-write operations
- **Atomic writes** (`store_config_ztoken()`): Writes to temporary file, then atomically renames to target to prevent partial reads

### Python Version

Requires Python 3.12+, as we use modern Python 3 features like type hints.

## Testing

Tests use pytest with unittest.mock for mocking. Key test patterns:
- Monkeypatching for dependency injection (`monkeypatch.setattr()`)
- MagicMock for HTTP responses and external dependencies
- Coverage reporting enabled by default
