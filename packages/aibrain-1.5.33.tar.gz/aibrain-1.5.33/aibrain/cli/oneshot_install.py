"""aibrain/cli/oneshot_install.py — single-command install for agent-driven setup.

Called via:
  python -c "$(curl -fsSL https://myaibrain.org/install.py)"
or after pip install:
  aibrain install --yes

Unlike `aibrain setup`, this:
  - Handles its own pip install of aibrain itself (if not already installed)
  - Validates Python version before anything else
  - Runs in --yes mode by default (agent-friendly)
  - Prints ONE URL at the end: the demo viewer

The entire intent is that an agent — or a user telling their agent "install
aibrain" — can paste a single command, walk away for 60 seconds, and come
back to a working install.
"""
from __future__ import annotations
import os
import sys
import subprocess
from pathlib import Path

PYTHON_MIN = (3, 10)
PYTHON_MAX = (3, 13)


def _c(code, text):
    return f"\033[{code}m{text}\033[0m" if sys.stdout.isatty() else text
def _green(t): return _c("32", t)
def _red(t): return _c("31", t)
def _yellow(t): return _c("33", t)
def _dim(t): return _c("2", t)
def _bold(t): return _c("1", t)


def _check_python() -> bool:
    cur = sys.version_info[:2]
    if cur < PYTHON_MIN:
        print(_red(f"✗ Python {cur[0]}.{cur[1]} is too old. Need >= {PYTHON_MIN[0]}.{PYTHON_MIN[1]}"))
        print("  Install from: https://www.python.org/downloads/")
        return False
    if cur > PYTHON_MAX:
        print(_red(f"✗ Python {cur[0]}.{cur[1]} is too new. Need <= {PYTHON_MAX[0]}.{PYTHON_MAX[1]}"))
        print(_dim(f"  Python {cur[0]}.{cur[1]} lacks stable wheels for dependencies."))
        print(f"  Install Python {PYTHON_MAX[0]}.{PYTHON_MAX[1]} from: https://www.python.org/downloads/")
        return False
    return True


def _pip_install(packages: list) -> bool:
    """Install via sys.executable -m pip — avoids PATH issues."""
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", *packages]
    print(_dim(f"  $ {' '.join(cmd)}"))
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if r.returncode == 0:
            return True
        # Show last 5 lines of error on failure
        print(_red("  pip install failed:"))
        for line in r.stderr.splitlines()[-5:]:
            print(_dim(f"    {line}"))
        return False
    except Exception as exc:
        print(_red(f"  pip errored: {exc}"))
        return False


def _is_installed(pkg: str) -> bool:
    try:
        __import__(pkg.replace("-", "_"))
        return True
    except ImportError:
        return False


def main() -> int:
    print()
    print(_bold("  AIBrain One-Shot Install"))
    print(_dim("  " + "─" * 40))
    print()

    # ── Gate 1: Python version ─────────────────────────────
    if not _check_python():
        return 1
    print(_green(f"  ✓ Python {sys.version_info.major}.{sys.version_info.minor}"))

    # ── Gate 2: Install aibrain if not present ─────────────
    if not _is_installed("aibrain"):
        print(_dim("  Installing aibrain from PyPI..."))
        if not _pip_install(["aibrain"]):
            return 1
        print(_green("  ✓ aibrain installed"))
    else:
        print(_green("  ✓ aibrain already installed"))

    # ── Gate 3: Delegate to setup wizard in --yes mode ────
    print()
    print(_dim("  Running setup in batch mode..."))
    print()

    try:
        from aibrain.cli.setup_wizard import run_setup
    except ImportError as exc:
        print(_red(f"  ✗ Could not import aibrain.cli.setup_wizard: {exc}"))
        print(_dim("    This means the PyPI install is corrupt or stale."))
        print(_dim(f"    Try: {sys.executable} -m pip install --upgrade --force-reinstall aibrain"))
        return 1

    root = Path.home() / "aibrain"
    root.mkdir(parents=True, exist_ok=True)

    # Detect a reasonable agent name from the environment
    agent_name = (
        os.environ.get("AIBRAIN_AGENT_NAME")
        or os.environ.get("USER")
        or os.environ.get("USERNAME")
        or "Agent"
    ).capitalize()

    report = run_setup(
        root=root,
        agent_name=agent_name,
        location=None,
        auto_yes=True,
        skip_demo=False,  # always show demo on one-shot install — that's the wow
    )

    if not report.success:
        print(_red("  ✗ Setup did not complete. See errors above."))
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
