"""
aibrain.cli.utils — Shared CLI utilities.

Provides cross-platform keyboard input and other terminal helpers used by
multiple interactive menus (settings, compress config, etc.).
"""
from __future__ import annotations

import sys


def _getch() -> str:
    """Read a single keypress without echo. Cross-platform (Windows + Unix)."""
    try:
        import msvcrt  # Windows
        return msvcrt.getwch()
    except ImportError:
        import tty
        import termios
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            return sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
