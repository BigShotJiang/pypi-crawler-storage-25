"""
aibrain chat — Interactive conversational mode with the brain.

Loop: read user input -> search brain memory -> display results -> follow-up.
Special commands:
    remember: <text>  — store a new memory
    quit / exit       — leave chat
    Ctrl+C            — leave chat
"""

import sys


def run_chat(db_path: str = None):
    """Run interactive chat loop with the brain.

    Args:
        db_path: Optional path to brain database.
    """
    try:
        from aibrain.core.memory_api import Brain
    except ImportError:
        print("Error: aibrain core not available", file=sys.stderr)
        return 1

    brain = Brain(db_path=db_path)
    count = brain.count()

    print("\n  AIBrain Chat")
    print("  ────────────────────────")
    print(f"  Brain has {count} memories")
    print("  Type a question to search, or:")
    print("    remember: <text>  — store a memory")
    print("    quit / exit       — leave chat")
    print()

    while True:
        try:
            user_input = input("you> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Goodbye.")
            return 0

        if not user_input:
            continue

        if user_input.lower() in ("quit", "exit", "q"):
            print("  Goodbye.")
            return 0

        # Store memory
        if user_input.lower().startswith("remember:"):
            content = user_input[len("remember:"):].strip()
            if not content:
                print("  Usage: remember: <what to remember>")
                continue
            results = brain.add(content, infer=False)
            for r in results:
                print(f"  Stored: {r['event']} (id={r['id']})")
            continue

        # Search memory
        results = brain.search(user_input, limit=5)
        if not results:
            print("  No matching memories found.")
            print("  Tip: use 'remember: <text>' to store knowledge first.")
        else:
            print(f"  Found {len(results)} result(s):\n")
            for i, r in enumerate(results, 1):
                score = r.get("score", 0)
                memory = r.get("memory", "")
                created = r.get("created_at", "")
                # Truncate long memories for display
                if len(memory) > 300:
                    memory = memory[:300] + "..."
                print(f"  {i}. [{score:.2f}] {memory}")
                if created:
                    print(f"     ({created})")
                print()
