"""aibrain/cli/explore.py — discoverability menu.

NOT the default post-install moment. That's auto-play (aibrain review on a
bundled sample, then offer aibrain up for the dashboard). This is the
"ok now show me everything else" menu — called via:

    aibrain explore

Design principles:
  - Menu items are ORDERED by wow density, not alphabetically.
  - Each item is ONE command, not a tree. No submenu nesting.
  - Items explicitly flag what they need: network, API credits, sample data.
  - Refusing to demonstrate something honest about what it costs is worse
    than not demonstrating it.
"""
from __future__ import annotations
import sys
import subprocess
import shutil
from dataclasses import dataclass


def _c(code, text):
    return f"\033[{code}m{text}\033[0m" if sys.stdout.isatty() else text
def _green(t): return _c("32", t)
def _red(t): return _c("31", t)
def _yellow(t): return _c("33", t)
def _blue(t): return _c("36", t)
def _dim(t): return _c("2", t)
def _bold(t): return _c("1", t)


@dataclass
class ExploreItem:
    key: str            # single char for quick select
    title: str          # shown in menu
    one_line: str       # description
    needs: list         # ["network", "api_credits", "sample_diff"] etc — shown as tags
    command: str        # what `aibrain` subcommand this runs
    implemented: bool   # if False, shows as "coming soon"


# Ordered by wow density (most surprising first).
# Each entry's `needs` list is honest about what it'll consume.
ITEMS = [
    ExploreItem(
        key="1",
        title="Review a real code diff",
        one_line="Paste or pipe a git diff; watch the Liaison catch real issues.",
        needs=["network", "api_credits (~$0.02)"],
        command="aibrain review",
        implemented=True,  # shipped as 'aibrain review' (candidate 1 from last turn)
    ),
    ExploreItem(
        key="2",
        title="Watch an agent try to cheat",
        one_line="Demo a weak agent self-recording PASS; see the gate reject it.",
        needs=["network", "api_credits (~$0.04)"],
        command="aibrain demo gaming",
        implemented=False,  # candidate 2 from last turn, not yet shipped
    ),
    ExploreItem(
        key="3",
        title="Run the dream consolidation",
        one_line="50 synthetic memories → consolidated output. No network, no cost.",
        needs=[],
        command="aibrain demo dream",
        implemented=False,  # candidate 3 — shippable in ~3h
    ),
    ExploreItem(
        key="4",
        title="Tour the dashboard",
        one_line="Start backend + open browser to the local dashboard.",
        needs=[],
        command="aibrain up",
        implemented=True,  # shipped as dashboard_launcher.py
    ),
    ExploreItem(
        key="5",
        title="Replay the 30-second intro",
        one_line="The scripted walkthrough of what the review gate does.",
        needs=[],
        command="aibrain demo",
        implemented=True,
    ),
    ExploreItem(
        key="6",
        title="Inspect your audit log",
        one_line="Show the last N rows from execution_log — every task ever run.",
        needs=[],
        command="aibrain audit last",
        implemented=False,  # trivial to build, ~1h
    ),
    ExploreItem(
        key="7",
        title="Browse the workflow registry",
        one_line="List all 76 built-in workflows and what each one does.",
        needs=[],
        command="aibrain workflows list",
        implemented=False,  # ~1h
    ),
    ExploreItem(
        key="8",
        title="Read the docs",
        one_line="Open docs.myaibrain.org in your browser.",
        needs=["network"],
        command="aibrain docs",
        implemented=False,
    ),
]


def _format_tags(needs: list) -> str:
    if not needs:
        return _dim("  (offline, free)")
    parts = []
    for n in needs:
        if "api_credits" in n:
            parts.append(_yellow(f"{n}"))
        elif n == "network":
            parts.append(_dim(f"{n}"))
        else:
            parts.append(_dim(f"{n}"))
    return _dim("  needs: ") + ", ".join(parts)


def _print_menu():
    print()
    print(_bold("  AIBrain — what would you like to see?"))
    print(_dim("  " + "─" * 56))
    print()
    for item in ITEMS:
        marker = _blue(f"  [{item.key}]")
        title = _bold(item.title) if item.implemented else _dim(item.title + "  (coming soon)")
        print(f"{marker}  {title}")
        print(f"       {_dim(item.one_line)}")
        print(f"     {_format_tags(item.needs)}")
        print()
    print(_dim("  [q]  Quit"))
    print()


def _run_item(item: ExploreItem) -> int:
    """Execute an item. For implemented items, invoke the subcommand.
    For unimplemented items, print a useful message."""
    if not item.implemented:
        print()
        print(_yellow(f"  '{item.title}' is not shipped yet in this version."))
        print(_dim(f"  Planned command:  {item.command}"))
        print()
        return 0

    print()
    print(_dim(f"  Running: {item.command}"))
    print()

    # Parse "aibrain <subcommand> [args...]" and invoke directly
    parts = item.command.split()
    if parts[0] != "aibrain":
        print(_red(f"  Malformed command in menu: {item.command}"))
        return 1
    aibrain_exe = shutil.which("aibrain")
    if not aibrain_exe:
        # Fall back to python -m aibrain
        cmd = [sys.executable, "-m", "aibrain", *parts[1:]]
    else:
        cmd = [aibrain_exe, *parts[1:]]

    try:
        return subprocess.call(cmd)
    except KeyboardInterrupt:
        print()
        print(_dim("  (interrupted)"))
        return 130
    except Exception as exc:
        print(_red(f"  Error: {exc}"))
        return 1


def main():
    import argparse
    parser = argparse.ArgumentParser(
        description="Browse what AIBrain can do.",
    )
    parser.add_argument(
        "--item", default=None,
        help="Non-interactive: run this menu item by key (e.g. --item 1)",
    )
    args = parser.parse_args(sys.argv[2:])

    # Non-interactive: run a specific item and exit
    if args.item:
        if args.item in ("q", "quit", "exit"):
            return 0
        for item in ITEMS:
            if item.key == args.item:
                return _run_item(item)
        print(_red(f"  No menu item with key '{args.item}'"))
        return 2

    # Interactive: loop until user quits
    while True:
        _print_menu()
        try:
            choice = input("  Pick one: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if choice in ("q", "quit", "exit", ""):
            print()
            print(_dim("  Come back any time:  aibrain explore"))
            print()
            return 0
        matched = next((i for i in ITEMS if i.key == choice), None)
        if not matched:
            print(_red(f"  No item '{choice}'. Pick a number from the list."))
            continue
        _run_item(matched)
        print()
        print(_dim("  " + "─" * 56))
        try:
            again = input("  Back to menu? [Y/n]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if again.startswith("n"):
            return 0


if __name__ == "__main__":
    sys.exit(main())
