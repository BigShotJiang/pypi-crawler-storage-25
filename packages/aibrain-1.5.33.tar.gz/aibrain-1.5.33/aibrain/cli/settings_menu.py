"""
aibrain.cli.settings_menu — Master settings menu for AIBrain.

Entry point: `aibrain settings` or `aibrain-settings`

Provides a top-level interactive menu to navigate all AIBrain configuration
areas. Each item shows a one-line status summary pulled from live config.

Sub-menu wiring:
  1. Compression  — fully wired (aibrain.tools.compress.config.interactive_menu)
  2-7.            — stubbed ("coming soon"), wired as each phase ships

Navigation:
  Arrow keys or number  — move / jump
  ENTER                 — open selected sub-menu
  Q (from sub-menu)     — return to master menu
  Q (from master menu)  — exit
  ESC                   — same as Q at all levels
"""
from __future__ import annotations

import sys

from aibrain.cli.utils import _getch

# ---------------------------------------------------------------------------
# Status helpers — one line each, read live config
# ---------------------------------------------------------------------------

_COMPRESS_CATEGORIES = [
    'git', 'test', 'build', 'docker', 'pip', 'env', 'json', 'traceback',
]
_TOTAL_COMPRESS_CATS = len(_COMPRESS_CATEGORIES)


def get_compression_status() -> str:
    """Read compress.toml and return 'N/8 enabled' string."""
    try:
        from aibrain.tools.compress.config import load_config, _invalidate_cache
        _invalidate_cache()
        cfg = load_config()
        compress_cfg = cfg.get('compress', {})

        # If master switch is off, all are disabled
        if not compress_cfg.get('enabled', True):
            return '0/8 enabled'

        enabled_count = 0
        for cat in _COMPRESS_CATEGORIES:
            cat_cfg = compress_cfg.get(cat, {})
            if isinstance(cat_cfg, dict):
                if cat_cfg.get('enabled', True):
                    enabled_count += 1
            else:
                enabled_count += 1  # default on

        return f'{enabled_count}/{_TOTAL_COMPRESS_CATS} enabled'
    except Exception:
        return '8/8 enabled'  # default assumption on any error


# ---------------------------------------------------------------------------
# Menu definition
# ---------------------------------------------------------------------------

# (label, status_fn_or_str, sub_menu_fn_or_None)
# status_fn: callable() -> str  OR  a plain str
# sub_menu_fn: callable() -> None  OR  None (stub)

def _stub_menu(title: str) -> None:
    """Display a 'coming soon' placeholder for unbuilt sub-menus."""
    sys.stdout.write('\n')
    sys.stdout.write(f'  {title} — coming soon\n')
    sys.stdout.write('  This menu is not yet available.\n')
    sys.stdout.write('  Press any key to return...\n')
    sys.stdout.flush()
    _getch()


def _open_compression_menu() -> None:
    """Open the compression sub-menu (fully wired)."""
    from aibrain.tools.compress.config import interactive_menu
    interactive_menu()


def get_workflows_status() -> str:
    """Read workflows DB and return 'N/M enabled' string."""
    try:
        from aibrain.tools.workflows.config import _resolve_db_path, _load_workflows
        db_path = _resolve_db_path()
        workflows = _load_workflows(db_path)
        total = len(workflows)
        enabled = sum(1 for w in workflows if w.get('enabled'))
        return f'{enabled}/{total} enabled'
    except Exception:
        return 'unavailable'


def _open_workflows_menu() -> None:
    """Open the workflows config sub-menu."""
    from aibrain.tools.workflows.config import interactive_menu
    interactive_menu()


def get_learning_status() -> str:
    """Read learn.toml and return a brief status string."""
    try:
        from aibrain.tools.learn.config import load_learn_config, _invalidate_cache
        _invalidate_cache()
        cfg = load_learn_config()
        active = sum(1 for v in cfg['signals'].values() if v)
        total = len(cfg['signals'])
        return f'{active}/{total} signals, min {cfg["min_msg_length"]} chars'
    except Exception:
        return '5/5 signals (defaults)'


def _open_learning_menu() -> None:
    """Open the learning config sub-menu."""
    from aibrain.tools.learn.config import interactive_menu
    interactive_menu()


def get_model_status() -> str:
    """Read model.toml and return a brief status string."""
    try:
        from aibrain.tools.model.config import load_model_config, _invalidate_cache
        _invalidate_cache()
        mcfg = load_model_config()
        return f'provider={mcfg["provider"]}, routing={mcfg["routing"]["simple"]}/{mcfg["routing"]["judgment"]}'
    except Exception:
        return 'defaults'


def _open_model_menu() -> None:
    """Open the model routing config sub-menu."""
    from aibrain.tools.model.config import interactive_menu
    interactive_menu()


def get_setup_status() -> str:
    """Read config.json and return a brief reconfigure status."""
    try:
        from aibrain.tools.setup.reconfigure import _load_config, _section_status
        cfg = _load_config()
        status = _section_status(cfg)
        configured = sum(1 for v in status.values() if v)
        return f'{configured}/{len(status)} sections configured'
    except Exception:
        return 'available'


def _open_setup_menu() -> None:
    """Open the setup reconfigure sub-menu."""
    from aibrain.tools.setup.reconfigure import interactive_menu
    interactive_menu()


def get_sync_status() -> str:
    """Read sync.toml and return a brief status string."""
    try:
        from aibrain.tools.sync.config import get_sync_status as _get
        return _get()
    except Exception:
        return 'push+pull, 7/7 tables'


def _open_sync_menu() -> None:
    """Open the brain sync config sub-menu."""
    from aibrain.tools.sync.config import interactive_menu
    interactive_menu()


def get_evolution_status() -> str:
    """Read evolution.toml and return a brief status string."""
    try:
        from aibrain.tools.evolution.config import load_evolution_config, _invalidate_cache
        _invalidate_cache()
        cfg = load_evolution_config()
        status = "on" if cfg["auto_evolve"] else "off"
        return f'auto={status}, every {cfg["interval_hours"]}h'
    except Exception:
        return 'on, every 6h'


def _open_evolution_menu() -> None:
    """Open the evolution config sub-menu."""
    from aibrain.tools.evolution.config import interactive_menu
    interactive_menu()


def get_agents_status() -> str:
    """Read company agents and return a brief status string."""
    try:
        from aibrain.tools.agents.config import get_agents_status as _get
        return _get()
    except Exception:
        return 'unavailable'


def _open_agents_menu() -> None:
    """Open the agents config sub-menu."""
    from aibrain.tools.agents.config import interactive_menu
    interactive_menu()


def get_schedule_status() -> str:
    """Read scheduled jobs and return a brief status string."""
    try:
        from aibrain.tools.schedule.config import get_schedule_status as _get
        return _get()
    except Exception:
        return 'unavailable'


def _open_schedule_menu() -> None:
    """Open the schedule config sub-menu."""
    from aibrain.tools.schedule.config import interactive_menu
    interactive_menu()


_MENU_ITEMS: list[tuple[str, object, object]] = [
    ('Compression',   get_compression_status,         _open_compression_menu),
    ('Learning',      get_learning_status,             _open_learning_menu),
    ('Model routing', get_model_status,               _open_model_menu),
    ('Workflows',     get_workflows_status,            _open_workflows_menu),
    ('Setup',         get_setup_status,                _open_setup_menu),
    ('Brain sync',    get_sync_status,                 _open_sync_menu),
    ('Evolution',     get_evolution_status,            _open_evolution_menu),
    ('Agents',        get_agents_status,              _open_agents_menu),
    ('Schedule',      get_schedule_status,            _open_schedule_menu),
]

_DIVIDER = '  ' + '─' * 45


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

def _get_status(item: tuple) -> str:
    """Resolve the status string for a menu item."""
    _, status_src, _ = item
    if callable(status_src):
        try:
            return status_src()
        except Exception:
            return 'error'
    return str(status_src)


def render_master_menu(items: list[tuple], selected_idx: int) -> str:
    """
    Build the master menu string.

    Args:
        items: list of (label, status_src, sub_menu_fn)
        selected_idx: 0-based index of highlighted item

    Returns:
        Printable string (includes leading newline for clean redraw).
    """
    lines = [
        '',
        '  AIBrain Settings',
        _DIVIDER,
    ]
    for i, item in enumerate(items):
        label, _, _ = item
        status = _get_status(item)
        cursor = '>' if i == selected_idx else ' '
        # Pad label to 16 chars for alignment
        lines.append(f'  {cursor} {i + 1}. {label:<16} [{status}]')
    lines.append(_DIVIDER)
    lines.append('  Arrow keys or number to select  |  Q to quit')
    lines.append('')
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def master_settings() -> None:
    """
    Launch the AIBrain master settings menu.

    Non-tty fallback: print a plain list of settings items.
    """
    # Non-tty fallback
    if not sys.stdout.isatty():
        for i, item in enumerate(_MENU_ITEMS):
            label, _, _ = item
            status = _get_status(item)
            print(f'{i + 1}. {label}: {status}')
        return

    items = _MENU_ITEMS
    n = len(items)
    selected = 0

    menu_text = render_master_menu(items, selected)
    sys.stdout.write(menu_text)
    sys.stdout.flush()
    menu_lines = menu_text.count('\n')

    while True:
        ch = _getch()

        # Q / ESC — exit
        if ch in ('q', 'Q', '\x1b'):
            # Check if ESC is start of an arrow key sequence
            if ch == '\x1b':
                try:
                    next1 = _getch()
                    if next1 == '[':
                        next2 = _getch()
                        if next2 == 'A':  # Up arrow
                            selected = (selected - 1) % n
                        elif next2 == 'B':  # Down arrow
                            selected = (selected + 1) % n
                        # Redraw and continue
                        sys.stdout.write(f'\x1b[{menu_lines}A')
                        new_text = render_master_menu(items, selected)
                        sys.stdout.write(new_text)
                        sys.stdout.flush()
                        menu_lines = new_text.count('\n')
                        continue
                    # ESC alone (not arrow) — exit
                except Exception:
                    pass
                # Plain ESC — exit
                sys.stdout.write('\n')
                return
            # Q — exit
            sys.stdout.write('\n')
            return

        # ENTER — open sub-menu
        if ch in ('\r', '\n'):
            _, _, sub_fn = items[selected]
            sys.stdout.write('\n')
            sys.stdout.flush()
            if callable(sub_fn):
                sub_fn()
            # Redraw master menu after returning from sub-menu
            menu_text = render_master_menu(items, selected)
            sys.stdout.write(menu_text)
            sys.stdout.flush()
            menu_lines = menu_text.count('\n')
            continue

        # Number keys 1-N — jump to item or open it directly
        if ch.isdigit():
            idx = int(ch) - 1
            if 0 <= idx < n:
                selected = idx
                # Open immediately on number press (matches compress menu UX)
                _, _, sub_fn = items[selected]
                sys.stdout.write('\n')
                sys.stdout.flush()
                if callable(sub_fn):
                    sub_fn()
                menu_text = render_master_menu(items, selected)
                sys.stdout.write(menu_text)
                sys.stdout.flush()
                menu_lines = menu_text.count('\n')
                continue

        # Redraw after any state change
        sys.stdout.write(f'\x1b[{menu_lines}A')
        new_text = render_master_menu(items, selected)
        sys.stdout.write(new_text)
        sys.stdout.flush()
        menu_lines = new_text.count('\n')
