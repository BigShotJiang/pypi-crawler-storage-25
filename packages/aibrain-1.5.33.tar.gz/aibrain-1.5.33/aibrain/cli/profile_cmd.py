"""
aibrain/cli/profile_cmd.py — CLI for managing AIBrain Claude Code profiles.

Usage:
  aibrain profile list
  aibrain profile create <name> [--mode hive|isolated] [--label "..."]
  aibrain profile info <name>
  aibrain profile delete <name> --confirm

Modes:
  hive      Shares the primary brain DB, skills, agents, and rules via junctions/symlinks.
            Use for spreading token load across multiple Claude Code subscriptions.

  isolated  Dedicated brain DB at AIBRAIN_ROOT/aibrain_<name>.db.
            Use for training specialist brains for the marketplace.
            NOTE: profile-level separation via DB path override — not OS-level process isolation.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Optional


def _get_aibrain_root() -> Path:
    """Use the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    return AIBRAIN_ROOT


def _memory_count(db_path: Path) -> Optional[int]:
    """Return memory count from a DB, or None if unreadable."""
    try:
        if not db_path.exists():
            return None
        conn = sqlite3.connect(str(db_path), timeout=3)
        row = conn.execute("SELECT COUNT(*) FROM memories").fetchone()
        conn.close()
        return row[0] if row else 0
    except Exception:
        return None


def _db_size_str(db_path: Path) -> str:
    try:
        if not db_path.exists():
            return "(not created yet)"
        sz = db_path.stat().st_size
        if sz < 1024:
            return f"{sz}B"
        elif sz < 1024 * 1024:
            return f"{sz // 1024}KB"
        else:
            return f"{sz // (1024 * 1024)}MB"
    except Exception:
        return "?"


def _link_status(path: Path) -> str:
    """Return a short status string for a dir: 'junction', 'symlink', 'dir', or 'missing'."""
    if not path.exists() and not path.is_symlink():
        return "missing"
    if path.is_symlink():
        return "symlink"
    # Windows junctions look like regular dirs — check if resolved == different path
    try:
        if path.resolve() != path:
            return "junction"
    except Exception:
        pass
    return "dir"


def _scan_unregistered_profiles() -> list[str]:
    """Scan ~/.claude-* dirs that are not in the registry."""
    from aibrain.core import profile_registry
    home = Path.home()
    registered = {p["name"] for p in profile_registry.list_profiles()}
    unregistered = []
    try:
        for d in home.iterdir():
            if d.is_dir() and d.name.startswith(".claude-"):
                name = d.name[len(".claude-"):]
                if name and name not in registered:
                    unregistered.append(name)
    except Exception:
        pass
    return sorted(unregistered)


def _launch_cmd(name: str) -> str:
    return f'CLAUDE_CONFIG_DIR=~/.claude-{name} claude'


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------

def cmd_list(args: list[str]) -> int:
    from aibrain.core import profile_registry
    root = _get_aibrain_root()
    primary_db = root / "aibrain.db"

    # Primary profile
    count = _memory_count(primary_db)
    count_str = f"{count} memories" if count is not None else "DB not found"
    size_str = _db_size_str(primary_db)
    print(f"\n  {'Profile':<20} {'Mode':<10} {'Memories':<14} {'DB Size':<10}  Label")
    print(f"  {'─'*20} {'─'*10} {'─'*14} {'─'*10}  {'─'*20}")
    print(f"  {'(primary)':<20} {'hive':<10} {count_str:<14} {size_str:<10}  ~/.claude")

    profiles = profile_registry.list_profiles()
    if profiles:
        for p in profiles:
            name = p["name"]
            mode = p["mode"]
            label = p.get("label") or ""
            if mode == "isolated":
                db_p = p.get("db_path")
                db_path = Path(db_p) if db_p else root / f"aibrain_{name}.db"
                mem_count = _memory_count(db_path)
                mem_str = f"{mem_count} memories" if mem_count is not None else "not created yet"
                size_str = _db_size_str(db_path)
                mode_badge = "ISOLATED"
            else:
                mem_str = "shared"
                size_str = "shared"
                mode_badge = "HIVE"
            print(f"  {name:<20} {mode_badge:<10} {mem_str:<14} {size_str:<10}  {label}")
    else:
        print("  (no registered profiles)")

    unregistered = _scan_unregistered_profiles()
    if unregistered:
        print("\n  Unregistered .claude-* dirs:")
        for name in unregistered:
            print(f"    .claude-{name}  — run: aibrain profile create {name}")

    print()
    return 0


def cmd_create(args: list[str]) -> int:
    if not args:
        print("Usage: aibrain profile create <name> [--mode hive|isolated] [--label \"...\"]")
        return 1

    name = args[0]
    mode = "hive"
    label = None

    i = 1
    while i < len(args):
        arg = args[i]
        if arg == "--mode" and i + 1 < len(args):
            mode = args[i + 1]
            i += 2
        elif arg == "--label" and i + 1 < len(args):
            label = args[i + 1]
            i += 2
        elif arg.startswith("--mode="):
            mode = arg.split("=", 1)[1]
            i += 1
        elif arg.startswith("--label="):
            label = arg.split("=", 1)[1]
            i += 1
        else:
            i += 1

    if mode not in ("hive", "isolated"):
        print(f"Error: --mode must be 'hive' or 'isolated', got: {mode!r}")
        return 1

    from aibrain.core.profile_ops import create_profile, validate_profile_name
    err = validate_profile_name(name)
    if err:
        print(f"Error: {err}")
        return 1

    try:
        entry = create_profile(name, mode=mode, label=label)
    except (ValueError, RuntimeError) as exc:
        print(f"Error: {exc}")
        return 1
    except Exception as exc:
        print(f"Error creating profile: {exc}")
        return 1

    profile_dir = Path.home() / f".claude-{name}"
    print(f"\n  Profile '{name}' created ({mode})")
    print(f"  Directory: {profile_dir}")

    if mode == "isolated":
        db_path = entry.get("db_path", "")
        print(f"  Isolated DB: {db_path}  (created on first MCP connect)")
        print("  NOTE: profile-level separation via DB path override — not OS-level process isolation.")
        print()
        print(f"  To launch: CLAUDE_CONFIG_DIR={profile_dir} claude")
    else:
        print("  Brain DB: shared (primary)")
        print()
        print(f"  To launch: CLAUDE_CONFIG_DIR={profile_dir} claude")

    print()
    return 0


def cmd_info(args: list[str]) -> int:
    if not args:
        print("Usage: aibrain profile info <name>")
        return 1

    name = args[0]
    from aibrain.core import profile_registry
    entry = profile_registry.get_profile_entry(name)
    if entry is None:
        print(f"Profile '{name}' is not registered. Use 'aibrain profile list' to see all profiles.")
        return 1

    profile_dir = Path.home() / f".claude-{name}"
    root = _get_aibrain_root()

    print(f"\n  Profile: {name}")
    print(f"  Mode:    {entry['mode'].upper()}")
    if entry.get("label"):
        print(f"  Label:   {entry['label']}")
    print(f"  Created: {entry.get('created', 'unknown')}")
    print(f"  Dir:     {profile_dir}  ({'exists' if profile_dir.exists() else 'MISSING'})")

    if entry["mode"] == "isolated":
        db_p = entry.get("db_path")
        db_path = Path(db_p) if db_p else root / f"aibrain_{name}.db"
        count = _memory_count(db_path)
        print(f"  DB:      {db_path}")
        print(f"           {_db_size_str(db_path)}  |  {count if count is not None else 'N/A'} memories")
    else:
        print("  DB:      shared (primary)")

    # Show dir statuses
    print("\n  Directory layout:")
    for d in ["skills", "agents", "rules", "projects"]:
        p = profile_dir / d
        status = _link_status(p)
        print(f"    {d:<12} {status}")
    claude_md = profile_dir / "CLAUDE.md"
    print(f"    {'CLAUDE.md':<12} {'exists' if claude_md.exists() else 'missing'}")

    print("\n  Launch command:")
    print(f"    CLAUDE_CONFIG_DIR={profile_dir} claude")
    print()
    return 0


def cmd_delete(args: list[str]) -> int:
    if not args:
        print("Usage: aibrain profile delete <name> --confirm")
        return 1

    name = args[0]
    if "--confirm" not in args:
        print(f"This will unregister profile '{name}' from profiles.json.")
        print(f"The directory ~/.claude-{name} and any associated DB are preserved.")
        print("")
        print(f"To confirm, run: aibrain profile delete {name} --confirm")
        return 1

    from aibrain.core import profile_registry
    existed = profile_registry.unregister_profile(name)
    if not existed:
        print(f"Profile '{name}' was not registered.")
        return 1

    print(f"Profile '{name}' unregistered from profiles.json.")
    print(f"Directory ~/.claude-{name} and DB are preserved.")
    return 0


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(args: list[str]) -> int:
    if not args or args[0] in ("-h", "--help"):
        print(__doc__.strip())
        return 0

    subcmd = args[0]
    rest = args[1:]

    if subcmd == "list":
        return cmd_list(rest)
    elif subcmd == "create":
        return cmd_create(rest)
    elif subcmd == "info":
        return cmd_info(rest)
    elif subcmd == "delete":
        return cmd_delete(rest)
    else:
        print(f"Unknown profile subcommand: {subcmd!r}")
        print("Usage: aibrain profile [list|create|info|delete] ...")
        return 1
