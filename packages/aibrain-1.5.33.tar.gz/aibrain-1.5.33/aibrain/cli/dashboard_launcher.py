"""aibrain/cli/dashboard_launcher.py — start backend + open browser, correctly.

Handles the cases the naive `webbrowser.open()` approach gets wrong:
  - Headless environments (SSH, WSL-without-display, Docker, CI)
  - Batch mode (--yes) where no human is watching
  - Dashboard backend not running yet (don't open a 404)
  - Port already in use (reuse existing server, don't double-start)
  - Slow first-boot (poll readiness before opening)
"""
from __future__ import annotations
import os
import sys
import socket
import subprocess
import time
import webbrowser
import platform
import shutil
from pathlib import Path
from dataclasses import dataclass
from typing import Optional

BACKEND_PORT = int(os.environ.get("AIBRAIN_BACKEND_PORT", "8001"))
# Frontend is now served by the backend (static files mount) — use the same port.
DASHBOARD_PORT = int(os.environ.get("AIBRAIN_DASHBOARD_PORT", str(BACKEND_PORT)))
# Bundled React frontend (included in pip wheel when built)
_FRONTEND_DIST = Path(__file__).parent.parent / "data" / "frontend_dist"
READINESS_TIMEOUT_SECONDS = 30
READINESS_POLL_SECONDS = 0.5


def _c(code, text):
    return f"\033[{code}m{text}\033[0m" if sys.stdout.isatty() else text
def _green(t): return _c("32", t)
def _red(t): return _c("31", t)
def _yellow(t): return _c("33", t)
def _dim(t): return _c("2", t)
def _bold(t): return _c("1", t)


@dataclass
class LaunchResult:
    backend_started: bool = False
    backend_already_running: bool = False
    dashboard_url: str = ""
    browser_opened: bool = False
    headless_detected: bool = False
    reason: str = ""


def _is_headless() -> bool:
    """Detect whether we're in an environment where launching a browser
    doesn't make sense.

    Cases this catches:
      - Linux without DISPLAY or WAYLAND_DISPLAY (SSH, container, CI)
      - WSL without WSLg (old WSL2, no GUI forwarding)
      - Explicit CI env vars
      - AIBRAIN_NO_BROWSER=1 override
    Cases this does NOT catch:
      - Windows without a user logged in (rare, and webbrowser.open fails safely)
      - macOS over SSH (rare for our segment)
    """
    if os.environ.get("AIBRAIN_NO_BROWSER"):
        return True
    if os.environ.get("CI") or os.environ.get("GITHUB_ACTIONS"):
        return True
    system = platform.system()
    if system == "Linux":
        if not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY"):
            # Could be WSL2 with WSLg — check for WSL distro indicator
            if "WSL_DISTRO_NAME" in os.environ:
                # WSL but no DISPLAY — WSLg not configured or old WSL1
                return True
            return True
    return False


def _port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    """Is something already listening on this port?"""
    try:
        with socket.create_connection((host, port), timeout=1):
            return True
    except (socket.timeout, ConnectionRefusedError, OSError):
        return False


def _wait_for_readiness(url: str, timeout: float) -> bool:
    """Poll the backend's /health endpoint until it responds or we time out."""
    try:
        import requests
    except ImportError:
        # Fall back to raw TCP probe on the port
        import urllib.parse as up
        parsed = up.urlparse(url)
        port = parsed.port or 80
        deadline = time.time() + timeout
        while time.time() < deadline:
            if _port_in_use(port, parsed.hostname or "127.0.0.1"):
                return True
            time.sleep(READINESS_POLL_SECONDS)
        return False

    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            r = requests.get(url, timeout=2)
            if r.status_code < 500:
                return True
        except Exception:
            pass
        time.sleep(READINESS_POLL_SECONDS)
    return False


def _start_backend(data_dir: Path) -> tuple[bool, Optional[subprocess.Popen]]:
    """Start the aibrain backend in a detached subprocess.

    Returns (success, popen_handle). If the port is already in use, assume
    it's a running instance and return (True, None).
    """
    if _port_in_use(BACKEND_PORT):
        return True, None

    # The backend is exposed via `aibrain-server` or `python -m aibrain`.
    # Prefer the entry point if it's on PATH.
    # On Windows, console scripts are .cmd wrappers — shutil.which("aibrain")
    # misses "aibrain.cmd".  Try extensions explicitly.
    def _find_exe(name: str) -> Optional[str]:
        candidates = [name]
        if platform.system() == "Windows":
            candidates = [f"{name}.cmd", f"{name}.exe", f"{name}.bat", name]
        for c in candidates:
            found = shutil.which(c)
            if found:
                return found
        return None

    exe = _find_exe("aibrain-server") or _find_exe("aibrain")
    if exe:
        # Use the console script
        if "server" not in exe:
            cmd = [exe, "server", "--port", str(BACKEND_PORT)]
        else:
            cmd = [exe, "--port", str(BACKEND_PORT)]
    else:
        # Fallback: invoke module directly
        cmd = [sys.executable, "-m", "aibrain", "server", "--port", str(BACKEND_PORT)]

    # Detach so the backend survives setup_wizard exiting
    log_file = data_dir / "backend.log"
    log_file.parent.mkdir(parents=True, exist_ok=True)

    # Open log file explicitly so we can close our end after Popen inherits it.
    # Passing log_file.open("a") inline leaks the handle — on Windows this causes
    # PermissionError on subsequent opens of the same log file.
    try:
        log_fh = open(log_file, "a", encoding="utf-8")  # noqa: WPS515
    except OSError as exc:
        print(_red(f"  ✗ Could not open backend log: {exc}"))
        return False, None

    try:
        if platform.system() == "Windows":
            # Windows: CREATE_NEW_PROCESS_GROUP + DETACHED_PROCESS
            CREATE_NEW_PROCESS_GROUP = 0x00000200
            DETACHED_PROCESS = 0x00000008
            popen = subprocess.Popen(
                cmd,
                stdout=log_fh,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                creationflags=CREATE_NEW_PROCESS_GROUP | DETACHED_PROCESS,
                close_fds=True,
            )
        else:
            # Unix: start_new_session to detach from our process group
            popen = subprocess.Popen(
                cmd,
                stdout=log_fh,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
                close_fds=True,
            )
        return True, popen
    except Exception as exc:
        print(_red(f"  ✗ Could not start backend: {exc}"))
        return False, None
    finally:
        # Close our copy — the child process inherited its own handle
        log_fh.close()


def launch_dashboard(
    data_dir: Path,
    auto_open_browser: bool = True,
    start_backend: bool = True,
    quiet: bool = False,
) -> LaunchResult:
    """Launch sequence:
      1. Check if backend port is already bound (reuse if so)
      2. If not, start backend as detached subprocess
      3. Poll backend /health until ready (30s timeout)
      4. If interactive + not headless + auto_open_browser: open browser
      5. Always print the URL so the user sees it regardless

    This is called at the END of `aibrain setup` only if the user opted in,
    and via `aibrain up` or `aibrain dashboard` as an explicit command.
    """
    result = LaunchResult()
    dashboard_url = f"http://localhost:{DASHBOARD_PORT}"
    backend_url = f"http://localhost:{BACKEND_PORT}"
    result.dashboard_url = dashboard_url

    # ── Frontend check ──────────────────────────────────────
    # _FRONTEND_DIST is the package-bundled dist. If missing (fresh install
    # without the built frontend), don't open a URL that will 404.
    _frontend_index = _FRONTEND_DIST / "index.html"
    if not _frontend_index.exists():
        if not quiet:
            print(_yellow("  ⚠ Dashboard frontend files not found."))
            print(_dim(f"    Expected: {_frontend_index}"))
            print(_dim("    The dashboard page will not load until the frontend is built."))
            print(_dim("    URL:  " + dashboard_url + "  (API only until frontend present)"))
        auto_open_browser = False  # don't open a broken page

    # ── Backend ────────────────────────────────────────────────
    if start_backend:
        if _port_in_use(BACKEND_PORT):
            result.backend_already_running = True
            result.backend_started = True
            if not quiet:
                print(_green(f"  ✓ Backend already running on :{BACKEND_PORT}"))
        else:
            if not quiet:
                print(_dim(f"  Starting backend on :{BACKEND_PORT}..."))
            ok, _ = _start_backend(data_dir)
            if ok:
                # Wait for /health to respond
                ready = _wait_for_readiness(f"{backend_url}/health", READINESS_TIMEOUT_SECONDS)
                if ready:
                    result.backend_started = True
                    if not quiet:
                        print(_green(f"  ✓ Backend ready on {backend_url}"))
                else:
                    result.reason = "backend_started_but_not_ready"
                    if not quiet:
                        print(_yellow(
                            f"  ⚠ Backend started but /health did not respond within "
                            f"{READINESS_TIMEOUT_SECONDS}s. Check {data_dir}/backend.log"
                        ))
            else:
                result.reason = "backend_start_failed"
                return result

    # ── Browser ────────────────────────────────────────────────
    result.headless_detected = _is_headless()

    if not auto_open_browser:
        result.reason = "auto_open_disabled"
    elif result.headless_detected:
        result.reason = "headless_environment"
    else:
        # On Windows, webbrowser.open() can silently fail for localhost URLs
        # depending on the default browser and security zone configuration.
        # Primary: os.startfile (Windows-native ShellExecuteEx, most reliable).
        # Fallback: webbrowser.open with new=2 (new tab).
        opened = False
        exc_reason = ""
        if platform.system() == "Windows":
            try:
                os.startfile(dashboard_url)  # type: ignore[attr-defined]
                opened = True
            except Exception as exc:
                exc_reason = f"os.startfile failed: {exc}"
        if not opened:
            try:
                opened = webbrowser.open(dashboard_url, new=2)  # new=2 = new tab
                if not opened and exc_reason:
                    result.reason = exc_reason
                elif not opened:
                    result.reason = "webbrowser_open_returned_false"
            except Exception as exc:
                result.reason = exc_reason or f"webbrowser_exception: {exc}"
        result.browser_opened = opened

    # ── Always print URL — regardless of whether browser opened ─
    if not quiet:
        print()
        if result.browser_opened:
            print(_green(f"  ✓ Opened {dashboard_url} in your browser"))
        else:
            print(_bold(f"  Dashboard:  {dashboard_url}"))
            if result.headless_detected:
                print(_dim("  (headless environment — browser not opened)"))
            elif not auto_open_browser:
                print(_dim("  (auto-open disabled — open manually)"))

    return result


def main():
    """CLI entry: `aibrain dashboard` or `aibrain up`."""
    import argparse
    parser = argparse.ArgumentParser(description="Start the AIBrain dashboard.")
    parser.add_argument("--no-browser", action="store_true",
                        help="Start backend but don't open browser")
    parser.add_argument("--no-backend", action="store_true",
                        help="Open browser but don't start backend")
    parser.add_argument("--root", default=None,
                        help="Data directory (default: ~/aibrain)")
    args = parser.parse_args()

    root = Path(args.root) if args.root else Path.home() / "aibrain"

    result = launch_dashboard(
        data_dir=root,
        auto_open_browser=not args.no_browser,
        start_backend=not args.no_backend,
    )

    return 0 if (result.backend_started or result.browser_opened) else 1


if __name__ == "__main__":
    sys.exit(main())
