"""aibrain/cli/demo.py — 30-second memory demo shown during setup.

Before/after terminal exchange: agents forget vs. agents remember.
Standalone so `aibrain demo` and the setup wizard both call run_demo().
"""
from __future__ import annotations
import time
import threading


def _c(style: str, text: str) -> str:
    codes = {
        "bold":   "\033[1m",
        "dim":    "\033[2m",
        "green":  "\033[32m",
        "yellow": "\033[33m",
        "teal":   "\033[36m",
        "reset":  "\033[0m",
    }
    return f"{codes.get(style, '')}{text}{codes['reset']}"


def run_demo(brain_name: str = "your brain") -> None:
    print()
    print(f"  {_c('teal', '─' * 52)}")
    print(f"  {_c('bold', 'The 30-second memory demo')}")
    print(f"  {_c('teal', '─' * 52)}")
    print()
    time.sleep(0.3)

    print(f"  {_c('yellow', 'WITHOUT AIBrain:')} {_c('dim', 'your agent starts fresh every session')}")
    print()

    for speaker, line in [
        ("You",   "My API key is sk-proj-XXXX. Save it."),
        ("Agent", "Got it! I'll remember that."),
        ("—",     "[ New session ]"),
        ("You",   "What was my API key?"),
        ("Agent", "I don't have access to previous conversations."),
        ("You",   "I just told you this."),
        ("Agent", "I'm sorry — each session starts fresh."),
    ]:
        if speaker == "—":
            time.sleep(0.2)
            print(f"\n    {_c('dim', line)}\n")
            time.sleep(0.2)
        elif speaker == "You":
            time.sleep(0.15)
            print(f"    {_c('bold', 'You:  ')}{line}")
        else:
            time.sleep(0.15)
            print(f"    {_c('dim', 'AI:   ')}{_c('dim', line)}")

    print()
    time.sleep(0.4)

    print(f"  {_c('green', 'WITH AIBrain:')} {_c('dim', 'memories persist — forever')}")
    print()

    for speaker, line in [
        ("You",   "My API key is sk-proj-XXXX. Save it."),
        ("Agent", f"Stored in {brain_name}. I'll never forget this."),
        ("—",     f"[ New session — {brain_name} loaded ]"),
        ("You",   "What was my API key?"),
        ("Agent", "Your API key is sk-proj-XXXX — stored 3 days ago."),
        ("You",   "Perfect."),
        ("Agent", "Always. That's what I'm here for."),
    ]:
        if speaker == "—":
            time.sleep(0.2)
            print(f"\n    {_c('dim', line)}\n")
            time.sleep(0.2)
        elif speaker == "You":
            time.sleep(0.15)
            print(f"    {_c('bold', 'You:  ')}{line}")
        else:
            time.sleep(0.15)
            print(f"    {_c('green', 'AI:   ')}{line}")

    print()
    time.sleep(0.3)

    spinner_frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    stop = threading.Event()

    def _spin():
        i = 0
        while not stop.is_set():
            print(f"\r  {_c('teal', spinner_frames[i % len(spinner_frames)])} {_c('dim', f'Loading {brain_name}...')}  ",
                  end="", flush=True)
            time.sleep(0.1)
            i += 1

    t = threading.Thread(target=_spin, daemon=True)
    t.start()
    time.sleep(2.0)
    stop.set()
    t.join(timeout=0.5)

    print(f"\r  {_c('green', '[OK]')} {_c('bold', brain_name)} is ready.{' ' * 30}")
    print()
    print(f"  {_c('teal', 'Your agent will now remember everything.')}")
    print()
