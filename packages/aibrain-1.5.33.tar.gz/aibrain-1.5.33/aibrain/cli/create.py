"""
aibrain create <name> — Scaffold a new AIBrain project.

Creates a ready-to-run project structure with agent definitions,
task configs, sample workflow, sample flow, and entry point.
"""

from pathlib import Path


# ---------------------------------------------------------------------------
# Templates (plain string formatting, no Jinja)
# ---------------------------------------------------------------------------

AGENTS_YAML = """\
# Agent definitions for {name}
# Each agent has a role, goal, and backstory that shapes its behavior.

researcher:
  role: "Senior Researcher"
  goal: "Find accurate, relevant information on any topic"
  backstory: >
    You are an experienced researcher with expertise in finding
    and synthesizing information from multiple sources. You always
    verify facts before presenting them.

writer:
  role: "Content Writer"
  goal: "Create clear, engaging content from research findings"
  backstory: >
    You are a skilled writer who transforms raw research into
    polished, readable content. You focus on clarity and accuracy.
"""

TASKS_YAML = """\
# Task definitions for {name}
# Each task has a description, expected output, and assigned agent.

research_task:
  description: "Research the given topic and compile key findings"
  expected_output: "A structured summary with 3-5 key points and sources"
  agent: researcher

writing_task:
  description: "Write a clear report based on the research findings"
  expected_output: "A well-structured report of 200-500 words"
  agent: writer
  depends_on:
    - research_task
"""

EXAMPLE_WORKFLOW = '''\
"""
Example workflow for {name}.

Workflows are simple Python functions that return a result.
Run with: aibrain workflows run example
"""


def run(**kwargs):
    """Main entry point — called by the workflow runner."""
    print("Running {name} example workflow...")

    # Your workflow logic here
    steps_completed = []

    # Step 1: Gather data
    steps_completed.append("gathered data")

    # Step 2: Process
    steps_completed.append("processed results")

    # Step 3: Output
    steps_completed.append("generated output")

    return {{
        "success": True,
        "steps": steps_completed,
        "message": "{name} workflow completed successfully",
    }}


if __name__ == "__main__":
    result = run()
    print(result)
'''

EXAMPLE_FLOW = '''\
"""
Example flow for {name}.

Flows use @start, @listen, and @router decorators to create
event-driven pipelines where each step reacts to the output
of previous steps.
"""

from aibrain.core.flow import Flow, start, listen, router


class {class_name}Flow(Flow):
    """{name} processing flow."""

    @start()
    def begin(self):
        """Entry point — kicks off the flow."""
        print("Flow started")
        return {{"topic": "AIBrain", "status": "started"}}

    @listen("begin")
    def research(self, data):
        """React to the start event — do research."""
        topic = data.get("topic", "unknown")
        print(f"Researching: {{topic}}")
        return {{"topic": topic, "findings": ["finding 1", "finding 2"]}}

    @listen("research")
    def summarize(self, data):
        """React to research results — create summary."""
        findings = data.get("findings", [])
        summary = f"Found {{len(findings)}} key points about {{data.get('topic')}}"
        print(f"Summary: {{summary}}")
        return {{"summary": summary, "status": "complete"}}


if __name__ == "__main__":
    flow = {class_name}Flow()
    result = flow.kickoff()
    print(f"Flow result: {{result}}")
'''

BRAIN_CONFIG_YAML = """\
# AIBrain configuration for {name}
# See https://myaibrain.org/docs for full reference

project:
  name: "{name}"
  version: "0.1.0"

brain:
  # Embedding model for semantic search
  embedding_model: "all-MiniLM-L6-v2"
  # Database path (relative to project root)
  db_path: "aibrain.db"

# MCP servers to connect to (optional)
# mcp_servers:
#   - name: memory
#     command: "aibrain mcp"
#   - name: web_search
#     url: "http://localhost:8080"

# Model routing preferences
models:
  simple: "haiku"
  judgment: "sonnet"
  complex: "opus"

# Execution settings
execution:
  quality_threshold: 0.5
  max_retries: 1
  timeout_seconds: 300
"""

MAIN_PY = '''\
"""
{name} — AIBrain-powered project.

Entry point: creates a Team of agents and runs the workflow.

Usage:
    python main.py
    python main.py --topic "Your topic here"
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from aibrain import Brain, Agent, Task, Team


def main():
    topic = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "AI agents"

    # Initialize the brain (memory layer)
    brain = Brain()

    # Define agents
    researcher = Agent(
        role="Senior Researcher",
        goal=f"Find accurate information about {{topic}}",
        backstory="You are an experienced researcher who verifies facts.",
    )

    writer = Agent(
        role="Content Writer",
        goal="Create clear, engaging content from research",
        backstory="You transform raw research into polished reports.",
    )

    # Define tasks
    research_task = Task(
        description=f"Research the topic: {{topic}}",
        expected_output="3-5 key findings with sources",
        agent=researcher,
    )

    writing_task = Task(
        description="Write a report based on the research findings",
        expected_output="A 200-500 word report",
        agent=writer,
    )

    # Create team and run
    team = Team(
        agents=[researcher, writer],
        tasks=[research_task, writing_task],
    )

    print(f"Running {name} on topic: {{topic}}")
    result = team.kickoff()
    print(f"\\nResult:\\n{{result}}")


if __name__ == "__main__":
    main()
'''

README_MD = """\
# {name}

An AIBrain-powered project.

## Quick Start

```bash
# Install AIBrain
pip install aibrain

# Run the project
python main.py

# Or with a custom topic
python main.py "Your topic here"
```

## Structure

- `config/agents.yaml` — Agent definitions (role, goal, backstory)
- `config/tasks.yaml` — Task definitions and dependencies
- `workflows/example.py` — Sample workflow (imperative style)
- `flows/example.py` — Sample flow (event-driven style)
- `brain_config.yaml` — AIBrain settings
- `main.py` — Entry point

## Learn More

- [AIBrain Documentation](https://myaibrain.org/docs)
- [AIBrain on PyPI](https://pypi.org/project/aibrain/)
"""


# ---------------------------------------------------------------------------
# Scaffold function
# ---------------------------------------------------------------------------

def create_project(name: str, target_dir: str = None):
    """Create a new AIBrain project scaffold.

    Args:
        name: Project name (used for directory and template vars).
        target_dir: Parent directory. Defaults to current directory.
    """
    if not name:
        print("Usage: aibrain create <project_name>")
        return 1

    # Sanitize name for use as Python identifier
    safe_name = name.replace("-", "_").replace(" ", "_")
    class_name = "".join(w.capitalize() for w in safe_name.split("_"))

    base = Path(target_dir or ".") / name
    if base.exists():
        print(f"Error: directory already exists: {base}")
        return 1

    fmt = {"name": name, "class_name": class_name}

    files = {
        "config/agents.yaml": AGENTS_YAML.format(**fmt),
        "config/tasks.yaml": TASKS_YAML.format(**fmt),
        "workflows/example.py": EXAMPLE_WORKFLOW.format(**fmt),
        "flows/example.py": EXAMPLE_FLOW.format(**fmt),
        "brain_config.yaml": BRAIN_CONFIG_YAML.format(**fmt),
        "main.py": MAIN_PY.format(**fmt),
        "README.md": README_MD.format(**fmt),
    }

    for rel_path, content in files.items():
        full_path = base / rel_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")

    print(f"Created AIBrain project: {base}")
    print("  config/agents.yaml    — agent definitions")
    print("  config/tasks.yaml     — task definitions")
    print("  workflows/example.py  — sample workflow")
    print("  flows/example.py      — sample flow")
    print("  brain_config.yaml     — AIBrain settings")
    print("  main.py               — entry point")
    print("  README.md             — getting started")
    print("\nNext steps:")
    print(f"  cd {name}")
    print("  python main.py")
    return 0
