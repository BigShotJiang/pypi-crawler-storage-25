"""
aibrain train <workflow> -n <iterations> — Training loop with human feedback.

Runs a workflow N times, collects human feedback after each run,
stores feedback as evolution outcomes, and distills principles.
"""

import json
import sqlite3
import sys
from pathlib import Path


def run_train(workflow: str, iterations: int = 3, actor: str = "trainer",
              db_path: str = None):
    """Run a workflow multiple times with human feedback loop.

    Args:
        workflow: Name of the workflow to train.
        iterations: Number of training iterations.
        actor: Who is running the training.
        db_path: Optional database path.
    """
    try:
        from aibrain.core.workflow_runner import run_workflow
    except ImportError:
        print("Error: workflow_runner not available", file=sys.stderr)
        return 1

    print(f"\n  AIBrain Training: {workflow}")
    print("  ────────────────────────")
    print(f"  Iterations: {iterations}")
    print("  After each run, provide feedback to improve performance.")
    print("  Type 'skip' to skip feedback, 'quit' to stop early.\n")

    feedback_log = []

    for i in range(1, iterations + 1):
        print(f"  ── Iteration {i}/{iterations} ──")

        # Run the workflow
        result = run_workflow(workflow, actor=actor)

        print(f"  Success:  {result.success}")
        print(f"  Quality:  {result.quality:.2f}")
        print(f"  Duration: {result.duration_ms}ms")
        if result.error:
            print(f"  Error:    {result.error}")
        if result.output:
            output_preview = str(result.output)[:300]
            print(f"  Output:   {output_preview}")

        # Collect feedback
        print()
        try:
            feedback = input("  feedback> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Training stopped.")
            break

        if feedback.lower() == "quit":
            print("  Training stopped.")
            break

        if feedback.lower() == "skip" or not feedback:
            print("  (skipped)\n")
            continue

        # Score: ask for a 1-5 rating
        rating = 3
        try:
            rating_input = input("  rating (1-5, default 3)> ").strip()
            if rating_input:
                rating = max(1, min(5, int(rating_input)))
        except (EOFError, KeyboardInterrupt, ValueError):
            pass

        # Store as evolution outcome
        entry = {
            "iteration": i,
            "workflow": workflow,
            "success": result.success,
            "quality": result.quality,
            "feedback": feedback,
            "rating": rating,
            "run_id": result.run_id,
        }
        feedback_log.append(entry)

        _store_evolution_outcome(workflow, result, feedback, rating, db_path)
        print(f"  Stored feedback (rating={rating})\n")

    # Distill principles from collected feedback
    if feedback_log:
        print("\n  ── Training Summary ──")
        print(f"  Iterations completed: {len(feedback_log)}")
        avg_quality = sum(e["quality"] for e in feedback_log) / len(feedback_log)
        avg_rating = sum(e["rating"] for e in feedback_log) / len(feedback_log)
        print(f"  Average quality: {avg_quality:.2f}")
        print(f"  Average rating:  {avg_rating:.1f}/5")

        # Distill principles from feedback text
        principles = _distill_principles(feedback_log)
        if principles:
            _save_principles(workflow, principles, db_path)
            print(f"\n  Distilled {len(principles)} principle(s):")
            for p in principles:
                print(f"    - {p}")

    return 0


def _store_evolution_outcome(workflow: str, result, feedback: str,
                             rating: int, db_path: str = None):
    """Store training feedback as an evolution outcome."""
    try:
        db = _get_db(db_path)
        if not db:
            return

        db.execute("""
            CREATE TABLE IF NOT EXISTS evolution_outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT, source_id TEXT, action TEXT,
                result TEXT, details TEXT, failure_reason TEXT,
                duration_seconds REAL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        db.execute("""
            INSERT INTO evolution_outcomes (source, source_id, action, result, details, duration_seconds)
            VALUES (?, ?, ?, ?, ?, ?)
        """, [
            "training",
            result.run_id,
            f"workflow.{workflow}",
            "positive" if rating >= 3 else "negative",
            json.dumps({
                "feedback": feedback,
                "rating": rating,
                "quality": result.quality,
                "success": result.success,
            }),
            result.duration_ms / 1000.0,
        ])
        db.commit()
        db.close()
    except Exception as e:
        print(f"  Warning: could not store outcome: {e}", file=sys.stderr)


def _distill_principles(feedback_log: list) -> list[str]:
    """Extract principles from feedback entries.

    Pure extraction (no LLM) — looks for recurring themes and patterns.
    """
    principles = []
    all_feedback = [e["feedback"] for e in feedback_log if e.get("feedback")]

    if not all_feedback:
        return principles

    # Count word frequencies (simple theme extraction)
    word_counts: dict[str, int] = {}
    for fb in all_feedback:
        words = fb.lower().split()
        seen = set()
        for w in words:
            w = w.strip(".,!?;:'\"")
            if len(w) > 3 and w not in seen:
                word_counts[w] = word_counts.get(w, 0) + 1
                seen.add(w)

    # Find words that appear in multiple feedback entries
    recurring = {w: c for w, c in word_counts.items() if c >= 2}

    # Group high-rated vs low-rated feedback
    good = [e["feedback"] for e in feedback_log if e.get("rating", 3) >= 4]
    bad = [e["feedback"] for e in feedback_log if e.get("rating", 3) <= 2]

    if good:
        principles.append(f"Positive patterns: {'; '.join(good[:3])}")
    if bad:
        principles.append(f"Areas to improve: {'; '.join(bad[:3])}")
    if recurring:
        top_themes = sorted(recurring.items(), key=lambda x: -x[1])[:5]
        themes_str = ", ".join(f"{w}({c}x)" for w, c in top_themes)
        principles.append(f"Recurring themes: {themes_str}")

    return principles


def _save_principles(workflow: str, principles: list[str], db_path: str = None):
    """Save distilled principles to skill memory."""
    try:
        db = _get_db(db_path)
        if not db:
            return

        # Use the memories table as skill memory store
        for p in principles:
            db.execute("""
                INSERT INTO memories (name, type, content, tags, active, importance)
                VALUES (?, 'pattern', ?, ?, 1, 8)
            """, [
                f"training_principle:{workflow}",
                p,
                f"training,principle,{workflow}",
            ])
        db.commit()
        db.close()
    except Exception as e:
        print(f"  Warning: could not save principles: {e}", file=sys.stderr)


def _get_db(db_path: str = None):
    """Get a database connection via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    if db_path:
        path = Path(db_path)
    else:
        from aibrain_db import AIBRAIN_ROOT
        path = AIBRAIN_ROOT / "aibrain.db"
    if not path.exists():
        return None
    db = sqlite3.connect(str(path))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    return db
