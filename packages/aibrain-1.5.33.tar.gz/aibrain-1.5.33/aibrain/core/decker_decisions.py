"""
WTL Phase 3 — NEEDS-DECKER queue reader + Decker-reply parser + decision applier.

Consumes schema from migrations v6-v15. Pure library: no Telegram/email I/O,
no subprocess calls. Phase 5 (needs_decker_poller.py) and Phase 6 (broker_hook
banner + Telegram listener) wire this module's surface into the real channels.

Responsibilities:
  * list_open_needs_decker(limit=None) — queue reader for surfacing
  * parse_decker_reply(text) — extract `approve | revert | rerun | reassign <id>`
    from the first non-empty line of a Telegram/email reply
  * record_decker_decision(task_id, decision, raw_reply=None) — write decision
    column + decided_at; idempotent; refuses unknown decisions
  * apply_decker_decision(...) — dispatch terminal_state + auto_action on
    company_issues so the next loop tick picks it up

Out of scope (later phases):
  * Telegram/email send/re-send cadence — Phase 5
  * UPS banner rendering — Phase 6
  * Physical-channel fallback — Phase 5
"""

import logging
import re
from typing import Optional

from aibrain.core.companies import _get_db

log = logging.getLogger(__name__)

# Decker's reply-command vocabulary (v4.1 §5b "Decker reply parser")
ALLOWED_DECISIONS = frozenset({"approve", "revert", "rerun", "reassign"})

# Matches the first-line command, anchoring on the reply start after optional
# whitespace/bullets. `reassign <agent_id>` captures an alphanumeric id token.
_CMD_RE = re.compile(
    r"^\s*[-*>]?\s*(approve|revert|rerun|reassign)(?:\s+([A-Za-z0-9_]+))?\b",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Queue reader
# ---------------------------------------------------------------------------


def list_open_needs_decker(limit: Optional[int] = None, db=None) -> list[dict]:
    """Return unresolved NEEDS-DECKER rows (decker_decision IS NULL), oldest first.

    Each row is a plain dict so callers don't need sqlite3.Row handling. Oldest-
    first ordering matches the surfacing cadence: longest-unresolved items
    appear highest in the UPS banner.
    """
    db = db or _get_db()
    sql = (
        "SELECT task_id, surfaced_at, urgent_at, physical_fallback_at,"
        " last_telegram_send, last_email_send, last_banner_render,"
        " calibration_flag, ambiguity_flag"
        " FROM needs_decker_queue WHERE decker_decision IS NULL"
        " ORDER BY surfaced_at ASC"
    )
    if limit is not None:
        sql += f" LIMIT {int(limit)}"
    return [dict(r) for r in db.execute(sql).fetchall()]


# ---------------------------------------------------------------------------
# Reply parser
# ---------------------------------------------------------------------------


def parse_decker_reply(text: str) -> Optional[dict]:
    """Extract Decker's decision from the first non-empty line of a reply.

    Returns {decision, agent_id|None, raw_first_line} on match, else None.
    `reassign` requires a trailing token; `reassign` alone is rejected as
    malformed.
    """
    if not text:
        return None

    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        m = _CMD_RE.match(stripped)
        if not m:
            return None
        decision = m.group(1).lower()
        agent_id = m.group(2) if decision == "reassign" else None
        if decision == "reassign" and not agent_id:
            return None
        return {
            "decision": decision,
            "agent_id": agent_id,
            "raw_first_line": stripped,
        }
    return None


# ---------------------------------------------------------------------------
# Decision writer
# ---------------------------------------------------------------------------


def record_decker_decision(
    task_id: str,
    decision: str,
    raw_reply: Optional[str] = None,
    db=None,
) -> dict:
    """Write the decision + decided_at onto needs_decker_queue. Idempotent.

    Returns {recorded: bool, reason: str|None}.
    Refuses unknown decisions; refuses writes for task_ids with no open row.
    Preserves the existing decision if one is already recorded (no overwrite
    of Decker's first answer).

    First-write-wins rationale: a Decker reply parser has no reliable way to
    distinguish "Decker is correcting his prior answer" from "Decker is replying
    to the wrong thread" or "adversarial replay". The safe default is to refuse
    silent overwrites. A genuine correction flow goes through NEEDS_DECKER re-
    surfacing after the first decision executes, not through overwrite.
    """
    decision = (decision or "").lower()
    if decision not in ALLOWED_DECISIONS:
        return {"recorded": False, "reason": f"unknown_decision:{decision}"}

    # If the caller passed their own db handle they own the transaction
    # boundary; we must NOT commit inside a caller-provided transaction or
    # the outer BEGIN...COMMIT wrapping (ingest_decker_reply) breaks.
    owns_txn = db is None
    db = db or _get_db()
    row = db.execute(
        "SELECT decker_decision FROM needs_decker_queue WHERE task_id=?",
        (task_id,),
    ).fetchone()
    if row is None:
        return {"recorded": False, "reason": "no_open_queue_row"}
    if row["decker_decision"]:
        return {"recorded": False, "reason": "already_decided"}

    db.execute(
        "UPDATE needs_decker_queue SET decker_decision=?, decided_at=datetime('now')"
        " WHERE task_id=?",
        (decision, task_id),
    )
    if owns_txn:
        db.commit()
    log.info("Task %s: Decker decision recorded = %s", task_id, decision)
    return {"recorded": True, "reason": None, "raw_reply_len": len(raw_reply or "")}


# ---------------------------------------------------------------------------
# Decision applier — terminal state + auto_action dispatch
# ---------------------------------------------------------------------------

# Maps Decker command -> (terminal_state, auto_action) written to company_issues.
_DECISION_DISPATCH = {
    "approve":  ("AUTO_PASS",   "merge"),
    "revert":   ("AUTO_REVERT", "revert"),
    "rerun":    (None,          "rerun"),
    "reassign": (None,          "reassign"),
}


def apply_decker_decision(
    task_id: str,
    decision: str,
    agent_id: Optional[str] = None,
    db=None,
) -> dict:
    """Apply Decker's decision to company_issues so the next loop tick executes it.

    `approve` → AUTO_PASS + merge (downstream promotes the work).
    `revert`  → AUTO_REVERT + revert (downstream runs execute_auto_revert).
    `rerun`   → clears terminal_state; auto_action=rerun (loop re-queues the task).
    `reassign`→ sets assignee_agent_id + auto_action=reassign; clears terminal_state.

    Caller is expected to have already called record_decker_decision() — this
    function does not touch needs_decker_queue.
    """
    decision = (decision or "").lower()
    dispatch = _DECISION_DISPATCH.get(decision)
    if dispatch is None:
        return {"applied": False, "reason": f"unknown_decision:{decision}"}
    if decision == "reassign" and not agent_id:
        return {"applied": False, "reason": "reassign_without_agent_id"}

    terminal, auto_action = dispatch
    owns_txn = db is None
    db = db or _get_db()

    # rerun/reassign clear review_round so the next Liaison cycle starts fresh,
    # and clear stuck_pattern so the stuck-detector isn't pre-latched by a
    # prior stuck-event on a task Decker has now explicitly re-directed.
    # approve/revert keep those columns untouched — the task is terminal.
    if decision == "reassign":
        cur = db.execute(
            "UPDATE company_issues SET assignee_agent_id=?, auto_action=?,"
            " terminal_state=NULL, review_round=0, stuck_pattern=0,"
            " updated_at=datetime('now') WHERE id=?",
            (agent_id, auto_action, task_id),
        )
    elif decision == "rerun":
        cur = db.execute(
            "UPDATE company_issues SET terminal_state=NULL, auto_action=?,"
            " review_round=0, stuck_pattern=0,"
            " updated_at=datetime('now') WHERE id=?",
            (auto_action, task_id),
        )
    else:
        cur = db.execute(
            "UPDATE company_issues SET terminal_state=?, auto_action=?,"
            " updated_at=datetime('now') WHERE id=?",
            (terminal, auto_action, task_id),
        )
    if cur.rowcount == 0:
        log.warning(
            "Task %s: apply_decker_decision matched 0 rows (orphan queue entry?)",
            task_id,
        )
        return {"applied": False, "reason": "no_company_issues_row"}
    if owns_txn:
        db.commit()
    log.info(
        "Task %s: applied Decker decision=%s terminal=%s auto_action=%s",
        task_id, decision, terminal, auto_action,
    )
    return {
        "applied": True,
        "task_id": task_id,
        "decision": decision,
        "terminal_state": terminal,
        "auto_action": auto_action,
        "agent_id": agent_id if decision == "reassign" else None,
    }


# ---------------------------------------------------------------------------
# One-shot ingest helper — parse + record + apply in a single call
# ---------------------------------------------------------------------------


def ingest_decker_reply(task_id: str, reply_text: str, db=None) -> dict:
    """Top-level entry for Phase 5/6 callers: parse → record → apply.

    Runs record + apply inside a single DB transaction so the three operations
    either all land or none do. If apply reports applied=False (e.g. orphan
    queue row with no matching company_issues), the recorded decision is
    rolled back so NEEDS-DECKER re-surfaces on the next tick rather than
    silently stalling with decker_decision set on an un-applied task.

    Returns a composite dict:
      {parsed, recorded, applied, decision, agent_id, reason?}
    """
    parsed = parse_decker_reply(reply_text)
    if not parsed:
        return {"parsed": False, "reason": "no_command_in_first_line"}

    db = db or _get_db()

    # Single transaction: record + apply either both land or neither does.
    # Sub-functions receive our db and skip their own commit (owns_txn=False).
    try:
        rec = record_decker_decision(task_id, parsed["decision"], reply_text, db=db)
        if not rec["recorded"]:
            db.rollback()
            return {"parsed": True, "recorded": False, "reason": rec["reason"],
                    "decision": parsed["decision"]}

        applied = apply_decker_decision(
            task_id, parsed["decision"], parsed["agent_id"], db=db,
        )
        if not applied["applied"]:
            # Orphan / zero-rowcount — roll the recorded decision back so the
            # queue does not show "decided" on a task that wasn't actually
            # transitioned. NEEDS-DECKER will re-surface on the next tick.
            db.rollback()
            return {"parsed": True, "recorded": False, "applied": False,
                    "decision": parsed["decision"],
                    "agent_id": parsed["agent_id"],
                    "reason": applied["reason"]}

        db.commit()
        return {
            "parsed": True,
            "recorded": True,
            "applied": True,
            "decision": parsed["decision"],
            "agent_id": parsed["agent_id"],
        }
    except Exception:
        db.rollback()
        raise
