"""
secrets_filter.py — Shared secrets redaction for AIBrain.

Single source of truth for the token / API-key / credential patterns that
must never be stored in the brain DB. Used by:

  - realtime_learner.py (live conversation extraction)
  - retrolearn sweep (historical JSONL file scan — TIER 2)
  - memory_store writes (defense in depth at the write boundary)
  - brain export (final safety net before the DB leaves the machine)

Designed to be cheap enough to run on every message (compiled regex set,
no LLM calls, no external services) and loud enough that the caller knows
when it redacted something.

Principles:
  1. Redact, don't reject. Surrounding context is still valuable; only the
     secret itself is replaced with a labeled placeholder.
  2. Label by type. The placeholder carries what KIND of secret was found
     so downstream code can decide if the memory is still useful.
  3. Never silently pass unknown-looking long hex/base64 strings in
     security-sensitive contexts. Prefer over-redaction to under-redaction.
  4. Zero network calls. Zero LLM calls. Pure stdlib.

History: Apr 10 2026 split-brain cleanup session discovered real secrets
had been saved into conversation memories (GitHub PAT, broker bearer,
Telegram bot token). The rogue-db fix landed but we lacked a shared
filter — every writer rolled its own partial regex. This module
centralises that.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable


@dataclass
class RedactionResult:
    """Outcome of a redaction pass."""
    text: str                  # the cleaned text
    redactions: list[str]      # list of redaction labels applied (e.g. ["github_pat", "telegram_token"])
    was_clean: bool            # True iff nothing was redacted

    @property
    def count(self) -> int:
        return len(self.redactions)


# ---------------------------------------------------------------------------
# Patterns — ordered most-specific first so earlier patterns win
# ---------------------------------------------------------------------------

_PATTERNS: list[tuple[str, re.Pattern, str]] = [
    # Anthropic API key (most specific first — has a prefix)
    (
        "anthropic_api_key",
        re.compile(r"sk-ant-[A-Za-z0-9_\-]{30,}"),
        "[REDACTED:anthropic_api_key]",
    ),
    # OpenAI API key
    (
        "openai_api_key",
        re.compile(r"sk-(?:proj-)?[A-Za-z0-9]{32,}"),
        "[REDACTED:openai_api_key]",
    ),
    # Stripe secret / restricted key
    (
        "stripe_secret_key",
        re.compile(r"sk_(?:test|live)_[A-Za-z0-9]{20,}"),
        "[REDACTED:stripe_secret_key]",
    ),
    (
        "stripe_restricted_key",
        re.compile(r"rk_(?:test|live)_[A-Za-z0-9]{20,}"),
        "[REDACTED:stripe_restricted_key]",
    ),
    # GitHub classic PAT
    (
        "github_classic_pat",
        re.compile(r"ghp_[A-Za-z0-9]{36}"),
        "[REDACTED:github_pat]",
    ),
    # GitHub fine-grained PAT
    (
        "github_fine_grained_pat",
        re.compile(r"github_pat_[A-Za-z0-9_]{60,}"),
        "[REDACTED:github_pat]",
    ),
    # GitHub OAuth access token
    (
        "github_oauth",
        re.compile(r"gho_[A-Za-z0-9]{36}"),
        "[REDACTED:github_oauth]",
    ),
    # AWS access key ID
    (
        "aws_access_key",
        re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
        "[REDACTED:aws_access_key]",
    ),
    # Telegram bot token (numeric:AA... — very distinctive shape)
    (
        "telegram_bot_token",
        re.compile(r"\b[0-9]{8,12}:AA[A-Za-z0-9_\-]{30,}\b"),
        "[REDACTED:telegram_bot_token]",
    ),
    # JWT / signed token (three base64url segments separated by dots)
    (
        "jwt",
        re.compile(r"\beyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+"),
        "[REDACTED:jwt]",
    ),
    # SSH private key block
    (
        "ssh_private_key",
        re.compile(
            r"-----BEGIN (?:RSA |DSA |EC |OPENSSH )?PRIVATE KEY-----"
            r"[\s\S]*?"
            r"-----END (?:RSA |DSA |EC |OPENSSH )?PRIVATE KEY-----",
            re.DOTALL,
        ),
        "[REDACTED:ssh_private_key]",
    ),
    # Generic bearer token in header / curl style (case-insensitive)
    (
        "bearer_header",
        re.compile(r"(?i)\bbearer\s+[A-Za-z0-9_\-\.=]{20,}"),
        "bearer [REDACTED:bearer_token]",
    ),
]

# Contextual hex — needs custom replacement logic (preserve the context word)
_CONTEXTUAL_HEX_TOKEN = re.compile(
    r"(?i)(token|bearer|secret|api[_-]?key|auth)(\s*[=:]\s*|\s+is\s+|\s+)"
    r"['\"]?([a-fA-F0-9]{32,})['\"]?"
)


def redact_secrets(text: str) -> RedactionResult:
    """
    Scan text and replace any detected secrets with labeled placeholders.

    Returns a RedactionResult carrying both the cleaned text and a list of
    redaction labels that were applied. The caller can choose to:
      - store the cleaned text and drop the original
      - refuse to store at all if redactions.count > N
      - flag the memory for human review

    Safe to call on None / empty / non-string input (returns clean empty).
    """
    if not text or not isinstance(text, str):
        return RedactionResult(text=text or "", redactions=[], was_clean=True)

    result = text
    redactions: list[str] = []

    # Pass 1: simple find-and-replace patterns
    for label, pattern, replacement in _PATTERNS:
        if pattern.search(result):
            result, n = pattern.subn(replacement, result)
            redactions.extend([label] * n)

    # Pass 2: contextual hex token — preserve the context word but redact the hex
    def _contextual_redact(m: re.Match) -> str:
        ctx_word = m.group(1)
        sep = m.group(2)
        return f"{ctx_word}{sep}[REDACTED:contextual_hex_token]"

    if _CONTEXTUAL_HEX_TOKEN.search(result):
        result, n = _CONTEXTUAL_HEX_TOKEN.subn(_contextual_redact, result)
        redactions.extend(["contextual_hex_token"] * n)

    return RedactionResult(text=result, redactions=redactions, was_clean=not redactions)


def contains_secret(text: str) -> bool:
    """Cheap boolean check — does the text contain ANY recognized secret pattern?"""
    if not text or not isinstance(text, str):
        return False
    for label, pattern, _ in _PATTERNS:
        if pattern.search(text):
            return True
    return bool(_CONTEXTUAL_HEX_TOKEN.search(text))


def scan_lines(lines: Iterable[str]) -> dict:
    """
    Run the filter over a sequence of lines. Returns a summary dict:
        {
            "total_lines": int,
            "lines_with_secrets": int,
            "total_redactions": int,
            "by_label": {label: count, ...},
        }
    """
    total = 0
    lines_with = 0
    total_red = 0
    by_label: dict[str, int] = {}
    for line in lines:
        total += 1
        r = redact_secrets(line)
        if not r.was_clean:
            lines_with += 1
            total_red += r.count
            for lbl in r.redactions:
                by_label[lbl] = by_label.get(lbl, 0) + 1
    return {
        "total_lines": total,
        "lines_with_secrets": lines_with,
        "total_redactions": total_red,
        "by_label": by_label,
    }
