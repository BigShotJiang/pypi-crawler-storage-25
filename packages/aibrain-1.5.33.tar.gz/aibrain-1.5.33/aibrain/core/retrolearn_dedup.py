"""
retrolearn_dedup.py — content-level dedup helper for retrolearn extraction.

Used by the TIER 2 retrolearn sweep agents (and any future retrolearn pass —
Case's VPS, missed subdir re-sweep, user-facing setup wizard "learn from
your saved data" feature) to skip writing memories whose content is already
in the brain DB.

The live realtime_learner extractor uses dedup-by-name (md5 of first 200
chars). That works for the live path because realtime extraction processes
recent turns and same-content-different-name collisions are rare. The retro
sweep is different: 32 days of conversation history across 100+ files
produce many cross-session content duplicates that hash to different names
because the session_id varies. Phase 6 SuperWorker quality review found 554
exact-content duplicates in the TIER 2 sweep (8.4% of writes) that
dedup-by-name missed.

This module provides two helpers:
  - content_already_in_brain(content) -> bool
      Single-row check. Use sparingly; one query per insert.
  - filter_unique_content(rows, content_key='content') -> list
      Batch helper. Pulls existing content set once, filters in-memory.
      Much faster for batch inserts.

Both normalize content the same way before hashing: strip leading/trailing
whitespace, collapse internal whitespace runs to single spaces, lowercase.
This catches minor formatting variation as the same content (e.g. tabs vs
spaces, trailing newlines).
"""
from __future__ import annotations

import hashlib
import re
import sqlite3
from typing import Iterable

_WHITESPACE_RE = re.compile(r"\s+")


def _normalize_content(text: str) -> str:
    """Normalize content for hashing — strip + collapse whitespace + lowercase.

    Catches near-duplicates where only formatting differs (tabs vs spaces,
    trailing newlines, slight indentation). Does NOT catch semantic duplicates
    (different wording, same meaning) — those require embedding similarity
    and a separate pass.
    """
    if not text:
        return ""
    return _WHITESPACE_RE.sub(" ", text.strip().lower())


def _content_hash(text: str) -> str:
    """SHA-256 hash of the normalized content. 32-char hex prefix."""
    return hashlib.sha256(_normalize_content(text).encode("utf-8")).hexdigest()[:32]


def content_already_in_brain(content: str, conn: sqlite3.Connection) -> bool:
    """Check if a piece of content already exists in any brain memory.

    Returns True if there's at least one active memory with matching
    normalized content. The query is a full-table scan so this is slow on
    large brains — use `filter_unique_content` for batch operations.
    """
    if not content:
        return False
    target_hash = _content_hash(content)
    # Pull active memory contents in a streaming way to avoid loading
    # everything at once on a large brain.
    cursor = conn.execute("SELECT content FROM memories WHERE active=1")
    for (row_content,) in cursor:
        if not row_content:
            continue
        if _content_hash(row_content) == target_hash:
            return True
    return False


def filter_unique_content(
    rows: Iterable[dict],
    conn: sqlite3.Connection,
    content_key: str = "content",
) -> list[dict]:
    """Batch helper. Returns only rows whose content is NOT already in brain.

    Pulls all active memory content hashes ONCE into a Python set, then
    filters the input rows in-memory. Much faster than per-row queries for
    batches of 100+ rows.

    `rows` is an iterable of dicts; each dict must have a `content_key` field
    holding the content string. Other fields are preserved on the output.
    """
    # Build the existing-content hash set ONCE
    existing_hashes: set[str] = set()
    cursor = conn.execute("SELECT content FROM memories WHERE active=1")
    for (row_content,) in cursor:
        if row_content:
            existing_hashes.add(_content_hash(row_content))

    # Also track content hashes WITHIN this batch to dedup intra-batch
    seen_in_batch: set[str] = set()

    out: list[dict] = []
    for row in rows:
        c = row.get(content_key) or ""
        if not c:
            continue
        h = _content_hash(c)
        if h in existing_hashes or h in seen_in_batch:
            continue
        seen_in_batch.add(h)
        out.append(row)
    return out
