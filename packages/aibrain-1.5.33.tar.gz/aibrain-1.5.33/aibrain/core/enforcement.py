"""
enforcement.py — HARD RULE enforcement as compiled constraints.

The key insight: a retrieved rule is a reminder. A compiled constraint is a law.
This module loads HARD RULEs from the memory DB and .md files, parses them into
structured checks, and enforces them at action time. When a new HARD RULE is
saved to memory, it automatically becomes an enforcement constraint on next load.

Enforcement points:
  - pre_commit: before git commit (credential scan, co-author block, repo check)
  - pre_delete: before any file deletion (archive-first rule)
  - pre_push: before git push (repo separation)
  - pre_publish: before any publish/send (comms agent approval)
  - pre_spend: before any money spend (Decker approval)
  - pre_action: general catch-all for irreversible actions

Usage:
    from aibrain.core.enforcement import enforce, load_rules, EnforcementViolation

    # Load rules from DB + files (cached after first call)
    rules = load_rules()

    # Check before an action
    result = enforce("pre_commit", context={"files": ["main.py"], "diff": "..."})
    if not result.passed:
        for v in result.violations:
            print(f"BLOCKED: {v.rule_id} — {v.message}")
"""

import logging
import os
import re
import shutil
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

log = logging.getLogger("aibrain.enforcement")

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

ENFORCEMENT_POINTS = frozenset({
    "pre_commit", "pre_delete", "pre_push", "pre_publish",
    "pre_spend", "pre_action",
})


@dataclass
class HardRule:
    """A compiled enforcement constraint."""
    rule_id: str                        # unique identifier
    name: str                           # human-readable name
    description: str                    # what it enforces
    enforcement_points: list[str]       # when to check
    check_fn: str                       # name of checker function
    patterns: list[str] = field(default_factory=list)  # regex patterns if applicable
    source: str = "db"                  # "db" or "file" or "builtin"
    severity: str = "block"             # "block" or "warn"
    memory_name: str = ""               # original memory name for traceability


@dataclass
class Violation:
    """A single rule violation."""
    rule_id: str
    rule_name: str
    message: str
    severity: str = "block"
    context: dict = field(default_factory=dict)
    source: str = "builtin"  # "builtin", "db", or "file" — which rule triggered this


@dataclass
class EnforcementResult:
    """Result of running enforcement checks."""
    passed: bool = True
    violations: list[Violation] = field(default_factory=list)
    warnings: list[Violation] = field(default_factory=list)
    rules_checked: int = 0

    def add_violation(self, v: Violation):
        if v.severity == "block":
            self.passed = False
            self.violations.append(v)
        else:
            self.warnings.append(v)


# ---------------------------------------------------------------------------
# Credential patterns — compiled once
# ---------------------------------------------------------------------------

# These catch real secrets, not variable names or placeholders
CREDENTIAL_PATTERNS = [
    # Generic high-entropy tokens (at least 20 chars of base64-ish)
    (r'(?:api[_-]?key|api[_-]?token|secret[_-]?key|access[_-]?token|auth[_-]?token|private[_-]?key)'
     r'\s*[=:]\s*["\']?[A-Za-z0-9+/=_\-]{20,}["\']?',
     "API key/token assignment"),
    # AWS keys
    (r'AKIA[0-9A-Z]{16}', "AWS access key"),
    # GitHub PAT (classic and fine-grained)
    (r'gh[ps]_[A-Za-z0-9_]{36,}', "GitHub personal access token"),
    (r'github_pat_[A-Za-z0-9_]{22,}', "GitHub fine-grained token"),
    # Slack tokens
    (r'xox[bporas]-[0-9]{10,}-[A-Za-z0-9\-]+', "Slack token"),
    # Telegram bot tokens
    (r'[0-9]{8,10}:[A-Za-z0-9_\-]{35}', "Telegram bot token"),
    # Google/Gmail app passwords (4x4 lowercase). Must be labelled — a bare
    # "aaaa bbbb cccc dddd" run in English prose ("They have zero work",
    # "paste this into Clau...") is not a credential, and the label-free
    # regex previously blocked every docs commit. Require an explicit
    # password label within ~32 chars before the 16-char block so the
    # match is anchored to an actual credential context.
    (r'(?i:app[\s_-]*password|gmail[\s_-]*password|google[\s_-]*password|'
     r'smtp[\s_-]*password)[^a-zA-Z0-9]{0,32}'
     r'[a-z]{4}\s+[a-z]{4}\s+[a-z]{4}\s+[a-z]{4}',
     "Google app password"),
    # Generic password assignments
    (r'(?:password|passwd|pwd)\s*[=:]\s*["\'][^"\']{8,}["\']', "Hardcoded password"),
    # Private key blocks
    (r'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----', "Private key"),
    # Connection strings with credentials
    (r'(?:mongodb|postgres|mysql|redis)://[^:]+:[^@]+@', "Database connection string with credentials"),
    # Bearer tokens in code
    (r'[Bb]earer\s+[A-Za-z0-9\-._~+/]+=*', "Bearer token"),
    # .env file content pasted into code
    (r'(?:GITHUB_PAT|SINDECKER_PAT|TELEGRAM_TOKEN|SMTP_PASSWORD|BROKER_TOKEN)'
     r'\s*=\s*[A-Za-z0-9+/=_\-]{8,}',
     "Environment variable with credential value"),
]

COMPILED_CREDENTIAL_PATTERNS = [
    (re.compile(pat, re.IGNORECASE), desc)
    for pat, desc in CREDENTIAL_PATTERNS
]

# ---------------------------------------------------------------------------
# Sensor layer --- deterministic pre-LLM classification
# ---------------------------------------------------------------------------

# Patterns that are CERTAINLY credentials (high-specificity anchors only).
# These fire BLOCK at high confidence --- no ambiguity.
_SENSOR_BLOCK_PATTERNS = [
    (re.compile(r'AKIA[0-9A-Z]{16}', re.IGNORECASE), "AWS access key"),
    (re.compile(r'gh[ps]_[A-Za-z0-9_]{36,}'), "GitHub PAT"),
    (re.compile(r'github_pat_[A-Za-z0-9_]{22,}'), "GitHub fine-grained PAT"),
    (re.compile(r'xox[bporas]-[0-9]{10,}-[A-Za-z0-9\-]+'), "Slack token"),
    (re.compile(r'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----'), "Private key (PEM block)"),
    (re.compile(
        r'(?:GITHUB_PAT|SINDECKER_PAT|TELEGRAM_TOKEN|SMTP_PASSWORD|BROKER_TOKEN)'
        r'\s*=\s*[A-Za-z0-9+/=_\-]{8,}',
    ), "Known env-var credential"),
    # sk- style tokens (OpenAI, Anthropic, generic secret keys)
    (re.compile(r'\bsk-[A-Za-z0-9_\-]{20,}\b'), "Secret key token (sk-)"),
]

# Patterns that are CERTAINLY benign content --- ALLOW at high confidence.
_SENSOR_ALLOW_PATTERNS = [
    re.compile(r'^\s*#'),                                # comment lines
    re.compile(r'\bos\.environ\b|\bgetenv\b|\benv\.get\b'),  # env-var reads
    re.compile(r'\b(?:your_|example|placeholder|xxx|test_|dummy|changeme|replace_)\b',
               re.IGNORECASE),
]

# Placeholder phrases that make an otherwise-blocky string safe.
_PLACEHOLDER_PHRASES = [
    "your_", "example", "placeholder", "xxx", "test_", "dummy",
    "changeme", "replace_", "insert_", "<", "os.environ", "getenv", "env.get",
]


def _sensor_classify(text: str) -> tuple:
    """Deterministic sensor-layer classification --- NO LLM calls.

    Returns (label, confidence, descriptor) where label is one of:
        'BLOCK'     --- text almost certainly contains real credentials
        'ALLOW'     --- text is almost certainly safe
        'UNCERTAIN' --- cannot determine without LLM reasoning

    confidence is 0.0-1.0.  Labels with confidence >= 0.85 are acted on
    directly by the enforcement layer; UNCERTAIN and low-confidence labels
    are passed to the LLM reviewer unchanged.

    descriptor is a human-readable string describing what triggered the label.

    Design: sensor fires BEFORE any LLM call. LLM is only involved for
    UNCERTAIN cases. This eliminates LLM calls for the majority of benign
    memories and for obvious credential patterns.
    """
    if not text:
        return ("ALLOW", 1.0, "empty text")

    lower = text.lower()

    # Fast ALLOW path: placeholder phrases anywhere in text
    if any(ph in lower for ph in _PLACEHOLDER_PHRASES):
        return ("ALLOW", 0.95, "placeholder phrase")

    # Check BLOCK patterns --- high-specificity anchors
    for pattern, desc in _SENSOR_BLOCK_PATTERNS:
        if pattern.search(text):
            return ("BLOCK", 0.95, desc)

    # Check ALLOW patterns --- lines that are clearly benign
    lines = text.splitlines()
    if lines:
        benign_lines = sum(
            1 for ln in lines
            if any(p.search(ln) for p in _SENSOR_ALLOW_PATTERNS)
        )
        if benign_lines == len(lines):
            return ("ALLOW", 0.90, "all lines matched benign patterns")

    # No strong signal either way --- pass to LLM
    return ("UNCERTAIN", 0.5, "uncertain")



# Co-Authored-By pattern
CO_AUTHOR_PATTERN = re.compile(
    r'Co-Authored-By:.*(?:Claude|Anthropic)', re.IGNORECASE
)

# File deletion commands
DELETE_PATTERNS = [
    re.compile(r'\brm\s+(?:-[a-zA-Z]*\s+)*(?!.*archive)', re.IGNORECASE),
    re.compile(r'\bdel\s+', re.IGNORECASE),
    re.compile(r'\bRemove-Item\s+', re.IGNORECASE),
    re.compile(r'os\.(?:remove|unlink)\s*\(', re.IGNORECASE),
    re.compile(r'shutil\.rmtree\s*\(', re.IGNORECASE),
    re.compile(r'Path\([^)]*\)\.unlink\s*\(', re.IGNORECASE),
]

# Internal code indicators (things that should never be in sindecker repos)
INTERNAL_CODE_INDICATORS = [
    "wintermute", "remediate", "permeate", "aibrain",
    "rogue_paragon", "decker_system", "from aibrain",
    "import aibrain", "DeckerOps",
]


# ---------------------------------------------------------------------------
# Checker functions
# ---------------------------------------------------------------------------

def check_no_credentials(context: dict) -> list[Violation]:
    """Scan content for credential patterns.

    Uses the sensor layer (_sensor_classify) as a deterministic pre-filter:
    - BLOCK (confidence >= 0.85): return violation immediately, no further regex scan.
    - ALLOW (confidence >= 0.85): return empty violations immediately.
    - UNCERTAIN: fall through to the full regex scan as before.

    This eliminates the full regex pass for the majority of safe memories
    and for obvious high-specificity credential patterns.
    """
    violations = []
    raw = context.get("diff", "") or context.get("content", "")
    files = context.get("files", [])

    if not raw:
        return violations

    # When scanning a git diff, only check added lines (prefixed with '+')
    # so that removing an old credential doesn't trigger a false positive.
    is_diff = bool(context.get("diff"))
    if is_diff:
        content = "\n".join(
            line[1:] for line in raw.splitlines()
            if line.startswith("+") and not line.startswith("+++")
        )
        # If no added lines in the diff, fall back to raw text.
        if not content.strip():
            content = raw
    else:
        content = raw

    # --- Sensor layer: deterministic pre-check ---
    sensor_label, sensor_conf, sensor_desc = _sensor_classify(content)
    if sensor_conf >= 0.85:
        if sensor_label == "ALLOW":
            return violations
        if sensor_label == "BLOCK":
            violations.append(Violation(
                rule_id="no_credentials",
                rule_name="No credentials to git",
                message=f"Credential detected ({sensor_desc}): [sensor layer, high confidence]",
                severity="block",
                context={"sensor": True, "confidence": sensor_conf, "desc": sensor_desc},
            ))
            return violations
    # UNCERTAIN or low confidence --- fall through to full scan.

    for pattern, desc in COMPILED_CREDENTIAL_PATTERNS:
        matches = pattern.findall(content)
        for match in matches:
            # Skip obvious placeholders/examples
            match_str = match if isinstance(match, str) else str(match)
            lower = match_str.lower()
            if any(ph in lower for ph in [
                "your_", "example", "placeholder", "xxx", "test_",
                "dummy", "changeme", "replace_", "insert_", "<",
                "os.environ", "getenv", "env.get",
            ]):
                continue
            violations.append(Violation(
                rule_id="no_credentials",
                rule_name="No credentials to git",
                message=f"Credential detected ({desc}): {match_str[:40]}...",
                severity="block",
                context={"pattern": desc, "match_preview": match_str[:60]},
            ))
    return violations


def check_no_co_author(context: dict) -> list[Violation]:
    """Block Co-Authored-By lines mentioning Claude/Anthropic.

    When context comes from a git diff, only scan added lines (prefixed with '+')
    so that pre-existing Co-Authored-By pattern strings in unchanged code do not
    produce false positives when those files are modified.
    """
    violations = []
    raw = context.get("message", "") or context.get("diff", "") or context.get("content", "")
    if not raw:
        return violations

    # If context includes a diff with +/- lines, scan only added lines.
    if context.get("diff") and any(ln.startswith("+") for ln in raw.splitlines()):
        scan_content = "\n".join(
            line[1:] for line in raw.splitlines()
            if line.startswith("+") and not line.startswith("+++")
        )
    else:
        scan_content = raw

    if CO_AUTHOR_PATTERN.search(scan_content):
        violations.append(Violation(
            rule_id="no_co_author",
            rule_name="No Claude/Anthropic Co-Authored-By",
            message="Commit message contains Co-Authored-By referencing Claude or Anthropic",
            severity="block",
        ))
    return violations


def check_repo_separation(context: dict) -> list[Violation]:
    """Ensure internal code never goes to sindecker repos."""
    violations = []
    remote = context.get("remote", "") or ""
    content = context.get("diff", "") or context.get("content", "")
    files = context.get("files", [])

    if "sindecker" not in remote.lower():
        return violations

    # Check if any internal code indicators are present
    for indicator in INTERNAL_CODE_INDICATORS:
        if indicator.lower() in content.lower():
            violations.append(Violation(
                rule_id="repo_separation",
                rule_name="Git repo separation",
                message=f"Internal code indicator '{indicator}' found in sindecker push",
                severity="block",
                context={"remote": remote, "indicator": indicator},
            ))
            break  # One violation is enough to block

    # Check file paths for internal project files
    internal_extensions = {".py", ".js", ".ts", ".rs", ".go"}
    allowed_sindecker = {"myaibrain-site", "selroute"}
    for f in files:
        ext = Path(f).suffix.lower()
        if ext in internal_extensions:
            # Check if it's in an allowed sindecker project
            if not any(proj in remote for proj in allowed_sindecker):
                violations.append(Violation(
                    rule_id="repo_separation",
                    rule_name="Git repo separation",
                    message=f"Code file '{f}' being pushed to sindecker (not allowed)",
                    severity="block",
                    context={"file": f, "remote": remote},
                ))
                break

    return violations


def check_archive_before_delete(context: dict) -> list[Violation]:
    """Ensure files are archived before deletion."""
    violations = []
    command = context.get("command", "")
    file_path = context.get("file_path", "")
    action = context.get("action", "")

    # Check if this is a delete operation
    is_delete = action == "delete" or any(
        p.search(command) for p in DELETE_PATTERNS
    )

    if not is_delete:
        return violations

    # Check if archive step was done
    archive_done = context.get("archived", False)
    if not archive_done:
        target = file_path or command
        violations.append(Violation(
            rule_id="archive_before_delete",
            rule_name="Never delete — archive first",
            message=f"File deletion attempted without archiving first: {target}",
            severity="block",
            context={"command": command, "file_path": file_path},
        ))

    return violations


# ---------------------------------------------------------------------------
# Pre-action deletion guard — implements "never delete, always archive"
# ---------------------------------------------------------------------------

# Default archive root (overridable for testing)
_ARCHIVE_ROOT = Path.home() / ".aibrain" / "archive"


def _extract_file_path_from_command(command: str) -> Optional[str]:
    """
    Best-effort extraction of a file path from a delete command.

    Handles: rm <file>, del <file>, Remove-Item <file>,
    os.remove('<file>'), shutil.rmtree('<file>'), Path(...).unlink()
    """
    # rm/del/Remove-Item with flags
    m = re.search(r'(?:rm|del|Remove-Item)\s+(?:-[a-zA-Z]*\s+)*["\']?([^\s"\']+)', command)
    if m:
        return m.group(1)

    # os.remove/os.unlink/shutil.rmtree with string arg
    m = re.search(r'(?:os\.(?:remove|unlink)|shutil\.rmtree)\s*\(\s*["\']([^"\']+)["\']', command)
    if m:
        return m.group(1)

    # Path(...).unlink()
    m = re.search(r'Path\(\s*["\']([^"\']+)["\']\s*\)\.unlink', command)
    if m:
        return m.group(1)

    return None


def _archive_exists(file_path: str, archive_root: Optional[Path] = None) -> Optional[str]:
    """
    Check if an archive copy of the given file already exists.

    Scans archive_root/*/filename for a match.
    Returns the archive path if found, None otherwise.
    """
    root = archive_root or _ARCHIVE_ROOT
    if not root.exists():
        return None

    target_name = Path(file_path).name
    for subdir in root.iterdir():
        if subdir.is_dir():
            candidate = subdir / target_name
            if candidate.exists():
                return str(candidate)

    return None


def guard_deletion(
    file_path: str,
    reason: str = "",
    archive_root: Optional[Path] = None,
) -> dict:
    """
    Pre-action deletion guard: ensures an archive copy exists before deletion.

    If no archive copy exists, creates one at archive_root/[timestamp]/[filename].
    Returns dict with:
        allowed: bool — True if deletion can proceed (archive confirmed)
        archive_path: str — path to the archive copy
        created: bool — True if a new archive was created
        error: str — error message if something went wrong

    This implements the "never delete — always archive" HARD RULE at the
    enforcement level. Call this BEFORE any file deletion.
    """
    root = archive_root or _ARCHIVE_ROOT
    source = Path(file_path)

    # Check if file exists
    if not source.exists():
        return {
            "allowed": True,
            "archive_path": "",
            "created": False,
            "error": "",
            "message": f"File does not exist: {file_path} — deletion is a no-op",
        }

    # Check if archive already exists
    existing_archive = _archive_exists(file_path, archive_root=root)
    if existing_archive:
        return {
            "allowed": True,
            "archive_path": existing_archive,
            "created": False,
            "error": "",
            "message": f"Archive already exists at {existing_archive}",
        }

    # Create archive
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        archive_dir = root / timestamp
        archive_dir.mkdir(parents=True, exist_ok=True)

        dest = archive_dir / source.name
        if source.is_dir():
            shutil.copytree(str(source), str(dest))
        else:
            shutil.copy2(str(source), str(dest))

        log.info("Deletion guard: archived %s → %s (reason: %s)", file_path, dest, reason)

        return {
            "allowed": True,
            "archive_path": str(dest),
            "created": True,
            "error": "",
            "message": f"Archived {file_path} → {dest}",
        }

    except Exception as e:
        log.error("Deletion guard: failed to archive %s: %s", file_path, e)
        return {
            "allowed": False,
            "archive_path": "",
            "created": False,
            "error": str(e),
            "message": f"BLOCKED: Could not archive {file_path} — {e}",
        }


def enforce_deletion(
    file_path: str = "",
    command: str = "",
    reason: str = "",
    archive_root: Optional[Path] = None,
) -> dict:
    """
    Full deletion enforcement: extract path, guard, and report.

    Pass either file_path directly or command (will attempt to extract path).
    Returns guard_deletion result dict.
    Raises EnforcementViolation if archiving fails.
    """
    # Resolve file path
    target = file_path
    if not target and command:
        target = _extract_file_path_from_command(command) or ""

    if not target:
        raise EnforcementViolation(
            "Deletion attempted but no file path could be determined",
            violations=[Violation(
                rule_id="archive_before_delete",
                rule_name="Never delete — archive first",
                message=f"Cannot determine file path from: {command or '(no command)'}",
                severity="block",
            )],
        )

    result = guard_deletion(target, reason=reason, archive_root=archive_root)

    if not result["allowed"]:
        raise EnforcementViolation(
            f"Deletion blocked — archiving failed: {result['error']}",
            violations=[Violation(
                rule_id="archive_before_delete",
                rule_name="Never delete — archive first",
                message=result["message"],
                severity="block",
                context={"file_path": target, "error": result["error"]},
            )],
        )

    return result


def check_comms_approval(context: dict) -> list[Violation]:
    """Ensure public-facing content goes through communications_agent."""
    violations = []
    approved = context.get("comms_approved", False)
    content_type = context.get("content_type", "")

    public_types = {
        "linkedin", "twitter", "x_post", "email_external",
        "gumroad", "press", "cfp", "blog", "social",
    }

    if content_type.lower() in public_types and not approved:
        violations.append(Violation(
            rule_id="comms_approval",
            rule_name="Communications agent approval",
            message=f"Public content ({content_type}) requires communications_agent approval",
            severity="block",
            context={"content_type": content_type},
        ))

    return violations


def check_spend_approval(context: dict) -> list[Violation]:
    """Ensure money spend has Decker approval."""
    violations = []
    approved = context.get("decker_approved", False)
    amount = context.get("amount", 0)

    if amount > 0 and not approved:
        violations.append(Violation(
            rule_id="spend_approval",
            rule_name="No spend without Decker approval",
            message=f"Spending ${amount} requires explicit Decker approval",
            severity="block",
            context={"amount": amount},
        ))

    return violations


def check_never_kill_browser(context: dict) -> list[Violation]:
    """Block broad browser process kills."""
    violations = []
    command = context.get("command", "")
    lower = command.lower()

    browser_procs = ["chrome.exe", "msedge.exe", "firefox.exe", "brave.exe"]
    kill_cmds = ["taskkill", "kill ", "pkill ", "killall "]

    if any(k in lower for k in kill_cmds):
        if any(b in lower for b in browser_procs):
            violations.append(Violation(
                rule_id="never_kill_browser",
                rule_name="Never kill browser processes",
                message=f"Broad browser process kill attempted: {command[:80]}",
                severity="block",
                context={"command": command},
            ))

    return violations


def check_verify_before_irreversible(context: dict) -> list[Violation]:
    """Warn on irreversible actions without verification flag."""
    violations = []
    action = context.get("action", "")
    verified = context.get("verified", False)

    irreversible = {"publish", "submit", "deploy", "send_email", "push_production"}
    if action in irreversible and not verified:
        violations.append(Violation(
            rule_id="verify_before_irreversible",
            rule_name="Verify before irreversible action",
            message=f"Irreversible action '{action}' — set verified=True after confirmation",
            severity="warn",
            context={"action": action},
        ))

    return violations


# ---------------------------------------------------------------------------
# Checker registry — maps check_fn names to actual functions
# ---------------------------------------------------------------------------

CHECKER_REGISTRY: dict[str, callable] = {
    "check_no_credentials": check_no_credentials,
    "check_no_co_author": check_no_co_author,
    "check_repo_separation": check_repo_separation,
    "check_archive_before_delete": check_archive_before_delete,
    "check_comms_approval": check_comms_approval,
    "check_spend_approval": check_spend_approval,
    "check_never_kill_browser": check_never_kill_browser,
    "check_verify_before_irreversible": check_verify_before_irreversible,
}

# ---------------------------------------------------------------------------
# Built-in rules — always present regardless of DB state
# ---------------------------------------------------------------------------

BUILTIN_RULES: list[HardRule] = [
    HardRule(
        rule_id="no_credentials",
        name="No credentials to git",
        description="Never commit secrets, tokens, passwords, API keys to any git repo",
        enforcement_points=["pre_commit"],
        check_fn="check_no_credentials",
        source="builtin",
        severity="block",
    ),
    HardRule(
        rule_id="no_co_author",
        name="No Claude/Anthropic Co-Authored-By",
        description="Never include Co-Authored-By lines mentioning Claude or Anthropic",
        enforcement_points=["pre_commit"],
        check_fn="check_no_co_author",
        source="builtin",
        severity="block",
    ),
    HardRule(
        rule_id="repo_separation",
        name="Git repo separation",
        description="DeckerOps = internal code, sindecker = public artifacts only",
        enforcement_points=["pre_push"],
        check_fn="check_repo_separation",
        source="builtin",
        severity="block",
    ),
    HardRule(
        rule_id="archive_before_delete",
        name="Never delete — archive first",
        description="Move to archive/ before any file deletion, 48hr hold",
        enforcement_points=["pre_delete", "pre_action"],
        check_fn="check_archive_before_delete",
        source="builtin",
        severity="block",
    ),
    HardRule(
        rule_id="comms_approval",
        name="Communications agent approval",
        description="Public content goes through communications_agent + Decker approval",
        enforcement_points=["pre_publish"],
        check_fn="check_comms_approval",
        source="builtin",
        severity="block",
    ),
    HardRule(
        rule_id="spend_approval",
        name="No spend without Decker approval",
        description="Never spend money without explicit Decker approval",
        enforcement_points=["pre_spend"],
        check_fn="check_spend_approval",
        source="builtin",
        severity="block",
    ),
    HardRule(
        rule_id="never_kill_browser",
        name="Never kill browser processes",
        description="Never taskkill/kill browser executables broadly",
        enforcement_points=["pre_action"],
        check_fn="check_never_kill_browser",
        source="builtin",
        severity="block",
    ),
    HardRule(
        rule_id="verify_before_irreversible",
        name="Verify before irreversible action",
        description="Verify with Decker before any irreversible action",
        enforcement_points=["pre_publish", "pre_action"],
        check_fn="check_verify_before_irreversible",
        source="builtin",
        severity="warn",
    ),
]


# ---------------------------------------------------------------------------
# Rule loading — from DB and .md files
# ---------------------------------------------------------------------------

_loaded_rules: Optional[list[HardRule]] = None


# Rule patterns — each entry defines a check function and the signals that
# match it. Signals are split into:
#   - name_patterns:    regex or phrases to match against the memory NAME
#                       (highest trust: the name declares intent)
#   - required_phrases: phrases that must appear in CONTENT; matching any one
#                       counts as strong signal (weight 1.0 each)
#   - supporting:       weaker signals (weight 0.3 each) — only boost confidence
#   - anti_phrases:     presence REDUCES confidence (false-positive guards)
#
# A rule is accepted only when the total weighted score ≥ 0.6.
#
# Previous version used `any(kw in content.lower() for kw in keywords)` which
# produced false positives like "Pattern: Chain outputs without consumers are
# dead code" matching `check_no_credentials` because the word "credential"
# appeared somewhere in the content unrelated to the actual rule (gap #6
# finding). This version requires specific phrases and uses the memory NAME
# as the primary signal since the name is the intent declaration.

import re as _re

_RULE_PATTERNS = [
    {
        "check_fn": "check_no_credentials",
        "points": ["pre_commit"],
        "name_patterns": [
            r"no[_ ]creds", r"no[_ ]credentials", r"credentials[_ ]to[_ ]git",
            r"commit[_ ]credentials", r"api[_ ]key[_ ]rule",
        ],
        "required_phrases": [
            "never commit credentials", "never commit credential",
            "no credentials in git", "no creds to git", "creds to git",
            "never put secrets in git", "no api keys in source",
            "don't commit secrets", "do not commit secrets",
        ],
        "supporting": ["api key", "api token", "secret key", "access token",
                       "auth token", "private key", "commit credentials",
                       "credentials to git", "secrets in git"],
        "anti_phrases": ["test credential", "mock credential", "example credential",
                         "placeholder credential", "sample api key"],
    },
    {
        "check_fn": "check_no_co_author",
        "points": ["pre_commit"],
        "name_patterns": [r"no[_ ]co[_ ]author", r"co[_ ]author"],
        "required_phrases": [
            "co-authored-by", "never include co-authored",
            "no co-authored-by", "do not add co-author",
        ],
        "supporting": ["co_authored", "co author"],
        "anti_phrases": [],
    },
    {
        "check_fn": "check_repo_separation",
        "points": ["pre_push"],
        "name_patterns": [r"repo[_ ]separation", r"sindecker[_ ]rule", r"deckerops[_ ]repo"],
        "required_phrases": [
            "never push code to sindecker", "sindecker public artifacts only",
            "deckerops all internal code", "never double-push",
            "sindecker=public artifacts",
        ],
        "supporting": ["sindecker", "repo separation"],
        "anti_phrases": [],
    },
    {
        "check_fn": "check_archive_before_delete",
        "points": ["pre_delete", "pre_action"],
        "name_patterns": [r"never[_ ]delete", r"archive[_ ]first", r"no[_ ]delete"],
        "required_phrases": [
            "never delete files", "never delete", "archive first",
            "never delete, always archive", "archive before delete",
        ],
        "supporting": ["archive first", "rm -rf"],
        "anti_phrases": [],
    },
    {
        "check_fn": "check_comms_approval",
        "points": ["pre_publish"],
        "name_patterns": [r"comms[_ ]approval", r"publish[_ ]approval", r"communications[_ ]agent"],
        "required_phrases": [
            "communications_agent workflow", "never publish without",
            "comms approval required", "decker approval before publishing",
            "public-facing goes through communications",
        ],
        "supporting": ["communications_agent"],
        "anti_phrases": [],
    },
    {
        "check_fn": "check_spend_approval",
        "points": ["pre_spend"],
        "name_patterns": [r"no[_ ]spend", r"spend[_ ]approval", r"financial[_ ]rule"],
        "required_phrases": [
            "never spend without", "no spending without approval",
            "financial hard rule", "decker approval on all spending",
            "never spend money without",
        ],
        "supporting": ["spend money", "financial"],
        "anti_phrases": [],
    },
    {
        "check_fn": "check_never_kill_browser",
        "points": ["pre_action"],
        "name_patterns": [r"never[_ ]kill[_ ](browser|chrome|edge)", r"browser[_ ]kill"],
        "required_phrases": [
            "never kill chrome", "never kill browser", "never kill edge",
            "do not kill browser processes",
        ],
        "supporting": ["taskkill chrome", "kill chrome"],
        "anti_phrases": [],
    },
    {
        "check_fn": "check_verify_before_irreversible",
        "points": ["pre_action"],
        "name_patterns": [r"verify[_ ]before", r"irreversible"],
        "required_phrases": [
            "verify before irreversible", "verify before any irreversible",
            "never take irreversible action without",
            "hard rule: verify before",
        ],
        "supporting": ["verify before", "irreversible"],
        "anti_phrases": [],
    },
]


def _classify_memory_intent(name: str, content: str) -> dict:
    """
    Classify a memory into a rule-check intent with a confidence score.

    Returns a dict:
        {"check_fn": str|None, "confidence": float, "matched": list[str], "points": list[str]}
    confidence is 0.0-1.0. The caller decides whether to use the result.
    Threshold for acceptance is 0.6.

    Scoring:
      - name regex match     → +1.0  (strongest: name declares intent)
      - required phrase hit  → +1.0  (strong: specific phrase)
      - supporting hit       → +0.3  (contextual boost only — see gate below)
      - anti_phrase hit      → -0.5  (reduces false positives)

    FALSE-POSITIVE GATE: Supporting-word signals alone cannot push a candidate
    over the 0.6 threshold. A strong anchor — at least one name-pattern match
    OR at least one required-phrase match — is mandatory for the rule to fire.
    This prevents memories like "the key insight is that we NEVER ignore errors"
    from accumulating enough supporting words ('key', 'never') to trigger the
    credentials checker when the context is unrelated to git secrets.

    Example of what this blocks:
      Memory: "Workflow note: credential flow uses a token. Password is hashed,
               secret is encrypted."
      Without the gate: 4 supporting words × 0.3 = 1.2 → confidence 0.8 → FIRES
      With the gate:    no name-pattern, no required-phrase → rejected at 0.0
    """
    name_lower = name.lower()
    content_lower = content.lower()

    best = {"check_fn": None, "confidence": 0.0, "matched": [], "points": []}

    for pattern in _RULE_PATTERNS:
        score = 0.0
        matched = []
        has_strong_anchor = False  # name-pattern OR required-phrase hit

        # Name regex matches — strongest signal
        for pat in pattern["name_patterns"]:
            if _re.search(pat, name_lower):
                score += 1.0
                matched.append(f"name:{pat}")
                has_strong_anchor = True

        # Required-phrase matches — must match in content
        for phrase in pattern["required_phrases"]:
            if phrase in content_lower:
                score += 1.0
                matched.append(f"phrase:{phrase[:40]}")
                has_strong_anchor = True

        # FALSE-POSITIVE GATE: no strong anchor → skip this pattern entirely.
        # Supporting words must only boost an already-anchored match, never
        # be the sole reason a rule fires.
        if not has_strong_anchor:
            continue

        # Supporting phrases — weaker, boost an already-anchored match only
        for phrase in pattern["supporting"]:
            if phrase in content_lower:
                score += 0.3
                matched.append(f"supporting:{phrase}")

        # Anti-phrases — reduce score to catch false positives
        for phrase in pattern["anti_phrases"]:
            if phrase in content_lower:
                score -= 0.5
                matched.append(f"anti:{phrase}")

        # Clip to [0, 1.5] — we care about crossing 0.6, not absolute max
        confidence = max(0.0, min(1.5, score)) / 1.5

        if confidence > best["confidence"]:
            best = {
                "check_fn": pattern["check_fn"],
                "confidence": round(confidence, 3),
                "matched": matched,
                "points": pattern["points"],
            }

    return best


def _parse_memory_to_rule(name: str, content: str, source: str = "db") -> Optional[HardRule]:
    """
    Attempt to parse a memory entry into a HardRule using confidence scoring.

    Only returns a HardRule when confidence >= 0.6. The previous version used
    naive substring matching which produced false positives (gap #6 finding:
    "Pattern: Chain outputs without consumers are dead code" matched
    check_no_credentials because the word "credential" appeared unrelated).
    """
    intent = _classify_memory_intent(name, content)
    if intent["confidence"] < 0.6 or intent["check_fn"] is None:
        return None

    lower = content.lower()
    severity = "block" if "hard rule" in lower or "never" in lower else "warn"

    return HardRule(
        rule_id=f"mem_{name.replace(' ', '_').lower()[:50]}",
        name=name,
        description=content[:200].strip(),
        enforcement_points=intent["points"],
        check_fn=intent["check_fn"],
        source=source,
        severity=severity,
        memory_name=name,
    )


def _load_rules_from_db(db_path: Path) -> list[HardRule]:
    """Load HARD RULE memories from the aibrain database."""
    rules = []
    try:
        db = sqlite3.connect(str(db_path))
        rows = db.execute(
            "SELECT name, content FROM memories WHERE status='active' "
            "AND (content LIKE '%HARD RULE%' OR content LIKE '%NEVER%' "  # noqa:LIKE WILDCARD INJECTION
            "OR name LIKE '%feedback%') "  # noqa:LIKE WILDCARD INJECTION
            "AND (content LIKE '%HARD RULE%' OR content LIKE '%NEVER%')"  # noqa:LIKE WILDCARD INJECTION
        ).fetchall()
        db.close()

        for name, content in rows:
            rule = _parse_memory_to_rule(name, content, source="db")
            if rule:
                rules.append(rule)

    except Exception as e:
        log.warning("Failed to load rules from DB: %s", e)

    return rules


def _load_rules_from_files(memory_dir: Path) -> list[HardRule]:
    """Load HARD RULE entries from feedback_*.md files."""
    rules = []
    if not memory_dir.exists():
        return rules

    for md_file in memory_dir.glob("feedback_*.md"):
        try:
            content = md_file.read_text(encoding="utf-8")
            if "HARD RULE" in content or "NEVER" in content.upper():
                name = md_file.stem.replace("feedback_", "").replace("_", " ")
                rule = _parse_memory_to_rule(name, content, source="file")
                if rule:
                    rules.append(rule)
        except Exception as e:
            log.debug("Failed to read %s: %s", md_file, e)

    return rules


def load_rules(
    db_path: Optional[Path] = None,
    memory_dir: Optional[Path] = None,
    force_reload: bool = False,
) -> list[HardRule]:
    """
    Load all HARD RULEs: builtins + DB + .md files.

    Deduplication is by rule_id only — a DB rule with the same check_fn as a
    builtin but a different rule_id is APPENDED (not dropped). This means the
    dynamic rule learner actually works: saving "NEVER push to public repo" in
    the DB as mem_feedback_never_push_brain_to_public_repo adds a second rule
    alongside the check_repo_separation builtin, rather than silently discarding
    it because the check_fn already exists.

    If a DB/file rule specifies enforcement_points that are a superset of the
    matched builtin's set, those extra points are added to the builtin's
    effective enforcement_points so the check fires at the new points too.

    Results are cached; pass force_reload=True to refresh.
    """
    global _loaded_rules
    if _loaded_rules is not None and not force_reload:
        return _loaded_rules

    # Index builtins by rule_id (the true dedup key) and track which check_fns
    # have builtins so we can merge extra enforcement_points.
    rules_by_id: dict[str, HardRule] = {}
    builtin_check_fns: dict[str, HardRule] = {}  # check_fn → builtin rule
    for r in BUILTIN_RULES:
        rules_by_id[r.rule_id] = r
        builtin_check_fns[r.check_fn] = r

    def _integrate_rule(r: HardRule) -> None:
        """Add a DB/file rule, handling merging and true-duplicate detection."""
        # True duplicate: same rule_id as a builtin — drop (backward compat).
        if r.rule_id in rules_by_id:
            log.debug("Enforcement: skipping true duplicate rule_id '%s'", r.rule_id)
            return

        # Same check_fn as a builtin: merge any extra enforcement_points into
        # the builtin so the check fires at those new points too.
        if r.check_fn in builtin_check_fns:
            builtin = builtin_check_fns[r.check_fn]
            extra_points = [
                pt for pt in r.enforcement_points
                if pt not in builtin.enforcement_points
            ]
            if extra_points:
                builtin.enforcement_points = list(builtin.enforcement_points) + extra_points
                log.debug(
                    "Enforcement: added extra points %s to builtin '%s' from rule '%s'",
                    extra_points, builtin.rule_id, r.rule_id,
                )

        # Always append — same check_fn ≠ duplicate when rule_ids differ.
        rules_by_id[r.rule_id] = r

    # Load from DB
    if db_path is None:
        db_path = _find_db()
    if db_path:
        for r in _load_rules_from_db(db_path):
            _integrate_rule(r)

    # Load from .md files
    if memory_dir is None:
        memory_dir = Path(os.path.expanduser(
            "~/.claude-deckerops/projects/C--Users-sinde/memory"
        ))
    for r in _load_rules_from_files(memory_dir):
        _integrate_rule(r)

    _loaded_rules = list(rules_by_id.values())
    log.info("Enforcement: loaded %d rules (%d builtin, rest from memory)",
             len(_loaded_rules), len(BUILTIN_RULES))
    return _loaded_rules


def clear_cache():
    """Clear the loaded rules cache (for testing)."""
    global _loaded_rules
    _loaded_rules = None


def _integrate_rule_for_test(
    r: HardRule,
    rules_by_id: dict,
    builtin_check_fns: dict,
) -> None:
    """
    Exposed for unit tests: the same dedup+merge logic used inside load_rules().

    Mutates rules_by_id and builtin_check_fns in place exactly as load_rules()
    does internally, so tests can call it directly without going through the
    full DB-loading stack.
    """
    if r.rule_id in rules_by_id:
        log.debug("Enforcement: skipping true duplicate rule_id '%s'", r.rule_id)
        return

    if r.check_fn in builtin_check_fns:
        builtin = builtin_check_fns[r.check_fn]
        extra_points = [
            pt for pt in r.enforcement_points
            if pt not in builtin.enforcement_points
        ]
        if extra_points:
            builtin.enforcement_points = list(builtin.enforcement_points) + extra_points

    rules_by_id[r.rule_id] = r


# ---------------------------------------------------------------------------
# Enforcement engine
# ---------------------------------------------------------------------------

def enforce(
    enforcement_point: str,
    context: dict[str, Any],
    rules: Optional[list[HardRule]] = None,
) -> EnforcementResult:
    """
    Run all rules for the given enforcement point against the provided context.

    Args:
        enforcement_point: One of ENFORCEMENT_POINTS (e.g., "pre_commit")
        context: Dict with relevant data (diff, files, command, etc.)
        rules: Optional rule list (defaults to load_rules())

    Returns:
        EnforcementResult with passed=True/False and violation details.
    """
    if rules is None:
        rules = load_rules()

    result = EnforcementResult()

    for rule in rules:
        if enforcement_point not in rule.enforcement_points:
            continue

        checker = CHECKER_REGISTRY.get(rule.check_fn)
        if not checker:
            log.warning("No checker function '%s' for rule '%s'", rule.check_fn, rule.rule_id)
            continue

        result.rules_checked += 1

        try:
            violations = checker(context)
            for v in violations:
                # Override severity from rule definition and tag with source so
                # callers can see whether the violation came from a builtin or a
                # learnt DB/file rule.  Both the rule_id and source are set so
                # the violation record identifies WHICH rule (builtin or DB)
                # triggered — important when both a builtin and a DB rule with
                # the same check_fn fire at the same enforcement point.
                v.severity = rule.severity
                v.source = rule.source
                # When a DB/file rule triggers alongside a builtin (same
                # check_fn, different rule_id), preserve the full rule_id from
                # the triggering rule so the violation accurately references it.
                if v.rule_id != rule.rule_id and rule.source != "builtin":
                    v.rule_id = rule.rule_id
                    v.rule_name = rule.name
                result.add_violation(v)
        except Exception as e:
            log.error("Checker '%s' raised: %s", rule.check_fn, e)

    return result


def enforce_or_raise(
    enforcement_point: str,
    context: dict[str, Any],
    rules: Optional[list[HardRule]] = None,
) -> EnforcementResult:
    """Like enforce(), but raises EnforcementViolation if any blocking violations."""
    result = enforce(enforcement_point, context, rules)
    if not result.passed:
        msgs = [v.message for v in result.violations]
        raise EnforcementViolation(
            f"HARD RULE violation(s): {'; '.join(msgs)}",
            violations=result.violations,
        )
    return result


class EnforcementViolation(Exception):
    """Raised when a HARD RULE is violated."""
    def __init__(self, message: str, violations: list[Violation] = None):
        super().__init__(message)
        self.violations = violations or []


# ---------------------------------------------------------------------------
# DB persistence — hard_rules table
# ---------------------------------------------------------------------------

def ensure_hard_rules_table(db_path: Optional[Path] = None):
    """Create the hard_rules table if it doesn't exist."""
    if db_path is None:
        db_path = _find_db()
    if not db_path:
        return

    db = sqlite3.connect(str(db_path))
    db.execute("""
        CREATE TABLE IF NOT EXISTS hard_rules (
            rule_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            enforcement_points TEXT,
            check_fn TEXT NOT NULL,
            patterns TEXT,
            source TEXT DEFAULT 'db',
            severity TEXT DEFAULT 'block',
            memory_name TEXT,
            is_active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    db.commit()
    db.close()


def sync_rules_to_db(db_path: Optional[Path] = None):
    """Sync current rules to the hard_rules table for visibility/editing."""
    if db_path is None:
        db_path = _find_db()
    if not db_path:
        return

    ensure_hard_rules_table(db_path)
    rules = load_rules(db_path=db_path)

    db = sqlite3.connect(str(db_path))
    for r in rules:
        db.execute("""
            INSERT OR REPLACE INTO hard_rules
            (rule_id, name, description, enforcement_points, check_fn,
             patterns, source, severity, memory_name, is_active, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, datetime('now'))
        """, [
            r.rule_id, r.name, r.description,
            ",".join(r.enforcement_points), r.check_fn,
            ",".join(r.patterns) if r.patterns else "",
            r.source, r.severity, r.memory_name,
        ])
    db.commit()
    db.close()
    log.info("Synced %d rules to hard_rules table", len(rules))


# ---------------------------------------------------------------------------
# Scan staged files for credentials (pre-commit hook helper)
# ---------------------------------------------------------------------------

def scan_staged_content(diff_text: str) -> EnforcementResult:
    """
    Convenience: scan a git diff for credential patterns and co-author lines.
    Used by the pre-commit hook.
    """
    return enforce("pre_commit", {
        "diff": diff_text,
        "content": diff_text,
        "message": diff_text,
        "files": [],
    })


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def _find_db() -> Optional[Path]:
    """Find the aibrain database — uses the canonical aibrain_db resolution.

    Checks all standard locations and picks the largest existing DB so we don't
    end up shadowing the real DB with an empty stub at an old default path.
    """
    # Prefer the canonical resolution from aibrain_db (handles all edge cases)
    try:
        from aibrain_db import AIBRAIN_ROOT  # type: ignore
        canonical = AIBRAIN_ROOT / "aibrain.db"
        if canonical.exists():
            return canonical
    except Exception:
        pass

    # Explicit env var override
    if "AIBRAIN_DB" in os.environ:
        p = Path(os.environ["AIBRAIN_DB"])
        if p.exists():
            return p

    # Fallback: scan candidates and pick the largest non-empty file. This
    # fallback only runs when `from aibrain_db import AIBRAIN_ROOT` fails
    # (early boot / broken install / circular import). It exists so the
    # enforcement layer can still find a DB even when the canonical resolver
    # is unavailable — required for the pre-commit linter itself to run.
    candidates = [
        Path.home() / "projects" / "aibrain" / "aibrain.db",
        Path.home() / "aibrain" / "aibrain.db",  # noqa:rogue-aibrain-path — last-resort fallback when aibrain_db import fails
        Path(__file__).parent.parent.parent / "aibrain.db",
        Path("aibrain.db"),
    ]

    best, best_size = None, -1
    for c in candidates:
        try:
            if c.exists() and c.stat().st_size > best_size:
                best, best_size = c, c.stat().st_size
        except Exception:
            pass

    return best
