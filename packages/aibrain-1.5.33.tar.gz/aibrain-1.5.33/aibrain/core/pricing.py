"""pricing.py — token → cents equivalence table for Claude list rates.

Purpose
-------
SuperWorker's claude-CLI backend runs on a Pro/Max subscription and therefore
reports cost_cents_actual=0 (honest: no per-call billing occurs). That hides
the signal Decker actually needs to track: how much of the monthly subscription
allowance is being burned through. This module converts the token counts that
the CLI envelope reports (`modelUsage`) into an EQUIVALENT list-rate cost so
both subscription runs and metered SDK runs produce comparable dollar numbers.

Two orthogonal fields result:
  - cost_cents_actual     — real money spent (0 for CLI, real int for SDK)
  - cost_cents_equivalent — what the same tokens would cost at list rates
                             (computed for BOTH backends when tokens known)

Honest-rubric contract
----------------------
If token counts are NOT available (e.g. old envelope, missing modelUsage,
non-claude model we have no rate for), both `compute_equivalent_cents` and
`compute_equivalent_cents_from_sdk_usage` return None — never 0, never a
fabricated default. None propagates through the harness, persistence layer,
and `aibrain usage` aggregation.

Rate verification: verified 2026-04-11 against
https://platform.claude.com/docs/en/about-claude/pricing. Opus 4.6 uses the
new $5/$25 MTok slot (not the legacy $15/$75 that Opus 4.0/4.1 still carry);
Haiku 4.5 is $1/$5 MTok, superseding Haiku 3.5's $0.80/$4. See comments on
each ModelRate for the dated verification.

Rates are expressed as CENTS PER MILLION TOKENS (USD * 100) for integer math.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Rate table — cents per MILLION tokens (not per 1K — per 1M for less rounding
# slop; division-then-round lands on a sane integer for realistic token counts)
# ---------------------------------------------------------------------------
#
# Conversion: $15/M input → 1500 cents/M input
# All rates verified 2026-04-11 against
# https://platform.claude.com/docs/en/about-claude/pricing

@dataclass(frozen=True)
class ModelRate:
    """List-rate for one Claude model, cents per million tokens."""
    input_cents_per_m: float       # price of fresh input tokens
    output_cents_per_m: float      # price of output tokens
    cache_read_cents_per_m: float  # price of cache-hit tokens (cheap)
    cache_write_cents_per_m: float  # price of cache-creation tokens (5-min write)


# Keyed by the model-name prefix the CLI envelope reports. The CLI returns the
# full model slug (e.g. "claude-opus-4-6[1m]", "claude-sonnet-4-20250514",
# "claude-haiku-4-5-20251001"). match_rate() resolves prefix → ModelRate via
# LONGEST-prefix-wins so a 4.6 slug doesn't fall back to the legacy 4.0/4.1 row.
RATES: dict[str, ModelRate] = {
    # Opus 4.6 / 4.5 — $5/M input, $25/M output, $0.50/M cache read,
    #                  $6.25/M cache write (5m).
    # (verified 2026-04-11 against platform.claude.com/docs/en/about-claude/pricing)
    # NOTE: Opus 4.6 and 4.5 share the new $5/$25 slot. Opus 4.0/4.1 still use
    # the legacy $15/$75 slot below — hence the separate prefix entries.
    "claude-opus-4-6": ModelRate(
        input_cents_per_m=500.0,
        output_cents_per_m=2500.0,
        cache_read_cents_per_m=50.0,
        cache_write_cents_per_m=625.0,
    ),
    "claude-opus-4-5": ModelRate(
        input_cents_per_m=500.0,
        output_cents_per_m=2500.0,
        cache_read_cents_per_m=50.0,
        cache_write_cents_per_m=625.0,
    ),
    # Opus 4.0 / 4.1 — $15/M input, $75/M output, $1.50/M cache read,
    #                  $18.75/M cache write (5m). Legacy slot.
    # (verified 2026-04-11 against platform.claude.com/docs/en/about-claude/pricing)
    "claude-opus-4": ModelRate(
        input_cents_per_m=1500.0,
        output_cents_per_m=7500.0,
        cache_read_cents_per_m=150.0,
        cache_write_cents_per_m=1875.0,
    ),
    # Sonnet 4 / 4.5 / 4.6 — $3/M input, $15/M output, $0.30/M cache read,
    #                        $3.75/M cache write (5m). All Sonnet 4.x share one slot.
    # (verified 2026-04-11 against platform.claude.com/docs/en/about-claude/pricing)
    "claude-sonnet-4": ModelRate(
        input_cents_per_m=300.0,
        output_cents_per_m=1500.0,
        cache_read_cents_per_m=30.0,
        cache_write_cents_per_m=375.0,
    ),
    # Haiku 4.5 — $1/M input, $5/M output, $0.10/M cache read,
    #             $1.25/M cache write (5m).
    # (verified 2026-04-11 against platform.claude.com/docs/en/about-claude/pricing;
    #  superseded the old Haiku-3.5 $0.80/$4 values the first cut of this file held)
    "claude-haiku-4-5": ModelRate(
        input_cents_per_m=100.0,
        output_cents_per_m=500.0,
        cache_read_cents_per_m=10.0,
        cache_write_cents_per_m=125.0,
    ),
    # Haiku 4.x fallback — same as 4.5 for now. Longest-prefix match means
    # "claude-haiku-4-5-..." hits the explicit 4.5 row first; any other
    # "claude-haiku-4-..." slug falls through to this one.
    "claude-haiku-4": ModelRate(
        input_cents_per_m=100.0,
        output_cents_per_m=500.0,
        cache_read_cents_per_m=10.0,
        cache_write_cents_per_m=125.0,
    ),
}


def match_rate(model: Optional[str]) -> Optional[ModelRate]:
    """Resolve a full model slug to a ModelRate by prefix match.

    Returns None if the model is unknown — callers convert that to a None
    cost_cents_equivalent per the honest-rubric contract.

    Examples:
      "claude-opus-4-6[1m]"          → RATES["claude-opus-4"]
      "claude-sonnet-4-20250514"     → RATES["claude-sonnet-4"]
      "claude-haiku-4-5-20251001"    → RATES["claude-haiku-4"]
      "gpt-4o"                       → None (not a Claude model)
      None / ""                      → None
    """
    if not model or not isinstance(model, str):
        return None
    # Longest-prefix wins so "claude-opus-4" doesn't accidentally match
    # "claude-opus-3" if we later add one. Sort keys by length descending.
    for prefix in sorted(RATES.keys(), key=len, reverse=True):
        if model.startswith(prefix):
            return RATES[prefix]
    return None


# ---------------------------------------------------------------------------
# Token → cost computations
# ---------------------------------------------------------------------------

def compute_equivalent_cents(
    model: Optional[str],
    input_tokens: Optional[int],
    output_tokens: Optional[int],
    cache_read_tokens: Optional[int] = 0,
    cache_write_tokens: Optional[int] = 0,
) -> Optional[int]:
    """Compute cost_cents_equivalent from token counts at list rates.

    Returns None (honest-rubric) when:
      - model is unknown to the rate table
      - input_tokens or output_tokens is None (core signal missing)

    Cache tokens default to 0 when not reported — they're opportunistic
    signal, not load-bearing. If only input+output are known, the answer is
    still real, just without the cache discount/premium.

    Returns an int (rounded cents). Zero input AND zero output → 0 (not None)
    — a zero-token call really did cost zero and that IS measurable signal.
    """
    rate = match_rate(model)
    if rate is None:
        return None
    if input_tokens is None or output_tokens is None:
        return None

    cr = cache_read_tokens or 0
    cw = cache_write_tokens or 0

    # cents = tokens / 1_000_000 * cents_per_m
    cents = (
        (input_tokens / 1_000_000.0) * rate.input_cents_per_m
        + (output_tokens / 1_000_000.0) * rate.output_cents_per_m
        + (cr / 1_000_000.0) * rate.cache_read_cents_per_m
        + (cw / 1_000_000.0) * rate.cache_write_cents_per_m
    )
    if cents < 0:
        return None  # defensive — negative is never honest
    return int(round(cents))


def extract_tokens_from_cli_envelope(envelope: dict) -> tuple[Optional[str], dict]:
    """Pull (model_name, token_dict) from a `claude -p --output-format json` envelope.

    The CLI envelope's `modelUsage` field is a dict keyed by the actual model
    slug that ran, each value a usage object with camelCase token counts:

        {
          "modelUsage": {
            "claude-sonnet-4-20250514": {
              "inputTokens": 1234,
              "outputTokens": 567,
              "cacheReadInputTokens": 8900,
              "cacheCreationInputTokens": 0
            }
          }
        }

    Returns (None, {}) if the shape is missing or malformed — caller treats
    that as "no token signal" and sets cost_cents_equivalent = None.

    The returned dict uses our snake_case internal names so the rest of the
    code never has to know about camelCase CLI conventions:
      input_tokens, output_tokens, cache_read_tokens, cache_write_tokens
    """
    if not isinstance(envelope, dict):
        return None, {}
    mu = envelope.get("modelUsage")
    if not isinstance(mu, dict) or not mu:
        return None, {}
    # Take the first (and usually only) model the run touched
    first_key = next(iter(mu.keys()), None)
    if not isinstance(first_key, str) or not first_key:
        return None, {}
    usage = mu[first_key]
    if not isinstance(usage, dict):
        return first_key, {}

    def _coerce_int(v: Any) -> Optional[int]:
        if v is None:
            return None
        try:
            return int(v)
        except (TypeError, ValueError):
            return None

    tokens = {
        "input_tokens": _coerce_int(usage.get("inputTokens")),
        "output_tokens": _coerce_int(usage.get("outputTokens")),
        "cache_read_tokens": _coerce_int(usage.get("cacheReadInputTokens")) or 0,
        "cache_write_tokens": _coerce_int(usage.get("cacheCreationInputTokens")) or 0,
    }
    return first_key, tokens


def compute_equivalent_cents_from_sdk_usage(
    usage: Any,
    model: Optional[str],
) -> Optional[int]:
    """SDK path: Anthropic usage object → equivalent cents at list rates.

    The SDK returns an object with .input_tokens / .output_tokens (snake_case),
    plus optional .cache_read_input_tokens / .cache_creation_input_tokens on
    prompt-caching calls. Mirrors extract_tokens_from_cli_envelope() for parity.
    """
    if usage is None:
        return None

    def _safe_int(v: Any) -> Optional[int]:
        """Coerce to int, returning None on anything that doesn't convert
        cleanly. Critical for test-mock robustness: MagicMock instances with
        unset attributes return new MagicMocks, which must NOT be treated
        as real token counts."""
        if v is None:
            return None
        if isinstance(v, bool):
            return None  # bools sneak past int() — explicitly reject
        if isinstance(v, (int, float)):
            return int(v)
        try:
            return int(v)
        except (TypeError, ValueError):
            return None

    in_tok = _safe_int(getattr(usage, "input_tokens", None))
    out_tok = _safe_int(getattr(usage, "output_tokens", None))
    if in_tok is None or out_tok is None:
        return None
    cr = _safe_int(getattr(usage, "cache_read_input_tokens", 0)) or 0
    cw = _safe_int(getattr(usage, "cache_creation_input_tokens", 0)) or 0
    return compute_equivalent_cents(
        model=model,
        input_tokens=in_tok,
        output_tokens=out_tok,
        cache_read_tokens=cr,
        cache_write_tokens=cw,
    )
