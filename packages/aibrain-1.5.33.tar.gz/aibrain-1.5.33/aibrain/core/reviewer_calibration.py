"""
WTL Phase 4 — reviewer_calibration.

Rolling FAIL-rate + second-Liaison-disagreement metrics with bootstrap guard
and audit spawner. Implements §Calibration of path_forward_wtl_karpathy_loop.md
(lines 286-296). Consumes schema from migrations v6-v15; depends on the
hardened escalator contract shipped in Phase 2 + 2b.

Responsibilities:
  * rolling_metrics — last N execution_log rows where actor='special_liaison'
  * check_rubber_stamp_drift — fail_rate < 15% on a ≥20 sample → drift
  * check_second_liaison_disagreement — calibration_flag / ambiguity_flag
    rate > 40% over last 10 stuck-events → calibration miss
  * spawn_audit — writes a calibration_audit row to execution_log; silent
    during bootstrap window (N<20 total reviews), flagged=1 once live
  * run_calibration_check — one-shot composite; caller drives cadence

Known schema limitation (documented for Phase 7 follow-up):
  execution_log.agent_id is NOT populated by record_liaison_verdict today,
  so "per-Liaison-instance" calibration collapses to aggregate calibration
  across all special_liaison invocations. The aggregate read is still
  useful as an early bootstrap signal, but the spec's per-instance
  disambiguation requires a record_liaison_verdict backfill before it can
  be load-bearing. Falsifiability: when agent_id is populated, update
  rolling_metrics' WHERE clause to filter by instance and re-run the
  bootstrap window count.

Schema-version compatibility:
  The ``source`` column on execution_log is added by migration v16 and
  backfilled by v17. Two legacy-schema regimes are guarded:
    1. v16 ran but produced pre-gate NULL rows → ``COALESCE(source,
       'agent_review') = 'agent_review'`` treats them as agent-review so
       grandfathered data continues to count (tested in
       test_legacy_null_source_counts_as_agent_review).
    2. v16 has NOT run yet (mixed-deploy window where aibrain core
       upgraded ahead of the DB migration) → ``_has_source_column`` returns
       False and the query fans out to the unfiltered fallback branch
       (tested in test_legacy_schema_no_source_column). Without the
       helper rolling_metrics would throw OperationalError ("no such
       column: source") and silently break calibration until the DB
       caught up.
  A log warning is NOT emitted in the fallback path intentionally: the
  calibration signal stays live during the mid-deploy window, and the
  next migration tick resolves the column divergence.

Out of scope (later phases):
  * Third-Liaison spawn when drift/miss fires — Phase 5 (broker hook)
  * URGENT digest rendering of bootstrap-silent rows — Phase 6
"""

import json
import logging

from aibrain.core.companies import _get_db

log = logging.getLogger(__name__)

# Spec constants (path_forward_wtl_karpathy_loop.md §Calibration)
RUBBER_STAMP_FAIL_RATE_THRESHOLD = 0.15  # fail_rate < 15% → drift
DISAGREEMENT_RATE_THRESHOLD = 0.40       # disagreement > 40% → miss
DEFAULT_ROLLING_WINDOW = 20
DEFAULT_DISAGREEMENT_WINDOW = 10
BOOTSTRAP_N_THRESHOLD = 20               # total reviews needed before thresholds go live
AUDIT_COOLDOWN_HOURS = 6                 # suppress duplicate audits with same reason


# ---------------------------------------------------------------------------
# Rolling metric reader
# ---------------------------------------------------------------------------


_fallback_warned = False


def _has_source_column(db) -> bool:
    """execution_log.source is added by migration v16. Older schemas lack it.

    Emits a one-shot ``log.warning`` the first time a fallback is detected in
    this process. Rationale: silent fallback cannot distinguish a short mid-
    deploy window (v16 about to run) from a permanently-stuck pre-v16 DB;
    the warning surfaces the latter without spamming the logs during the
    expected transient window. The module-level flag means subsequent calls
    in the same process stay silent.
    """
    global _fallback_warned
    try:
        db.execute("SELECT source FROM execution_log LIMIT 0")
        return True
    except Exception:
        if not _fallback_warned:
            log.warning(
                "execution_log.source column missing — running in pre-v16 "
                "fallback. Calibration gate is NOT source-filtered; if this "
                "persists beyond the next migration tick it indicates a "
                "stuck migration, not a mid-deploy transient."
            )
            _fallback_warned = True
        return False


def rolling_metrics(window: int = DEFAULT_ROLLING_WINDOW, db=None) -> dict:
    """Return pass/fail stats over last `window` special_liaison verdicts.

    Only rows where ``source='agent_review'`` (real Agent-tool Liaison verdicts)
    are counted. ``pre_filter`` (regex pre-check) and ``self_recorded``
    (worker-side self-assessment) rows exist for audit-trail purposes but are
    NOT gate-clearing and must NOT pollute the calibration fail-rate — if they
    did, rubber-stamp-drift would fire on the reviewer's own non-gating rows.

    Rows with NULL verdict are ignored so non-verdict Liaison actions don't
    skew the rate. On legacy DBs without the ``source`` column (pre-v16),
    COALESCE treats NULL as ``agent_review`` so existing rows still count
    (backward-compat path that matches migrations v16/v17 backfill semantics).
    """
    db = db or _get_db()
    if _has_source_column(db):
        rows = db.execute(
            "SELECT verdict FROM execution_log"
            " WHERE actor='special_liaison' AND verdict IN ('PASS','FAIL')"
            "   AND COALESCE(source, 'agent_review') = 'agent_review'"
            " ORDER BY id DESC LIMIT ?",
            (int(window),),
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT verdict FROM execution_log"
            " WHERE actor='special_liaison' AND verdict IN ('PASS','FAIL')"
            " ORDER BY id DESC LIMIT ?",
            (int(window),),
        ).fetchall()
    n = len(rows)
    fails = sum(1 for r in rows if r["verdict"] == "FAIL")
    fail_rate = fails / n if n else 0.0
    return {
        "n": n,
        "fail_rate": round(fail_rate, 4),
        "pass_rate": round(1.0 - fail_rate, 4) if n else 0.0,
        "window": window,
    }


def _total_special_liaison_reviews(db) -> int:
    """Total count of gate-clearing PASS/FAIL verdicts — bootstrap-window gate.

    Filters source='agent_review' for the same reason rolling_metrics does:
    pre_filter and self_recorded rows must not inflate the bootstrap count
    and let the threshold go live before enough real reviews exist. Uses
    COALESCE so legacy NULL-source rows still count (matches migration v17
    backfill semantics).
    """
    if _has_source_column(db):
        row = db.execute(
            "SELECT COUNT(*) AS n FROM execution_log"
            " WHERE actor='special_liaison' AND verdict IN ('PASS','FAIL')"
            "   AND COALESCE(source, 'agent_review') = 'agent_review'"
        ).fetchone()
    else:
        row = db.execute(
            "SELECT COUNT(*) AS n FROM execution_log"
            " WHERE actor='special_liaison' AND verdict IN ('PASS','FAIL')"
        ).fetchone()
    return int(row["n"]) if row else 0


# ---------------------------------------------------------------------------
# Rubber-stamp-drift check
# ---------------------------------------------------------------------------


def check_rubber_stamp_drift(
    window: int = DEFAULT_ROLLING_WINDOW,
    threshold: float = RUBBER_STAMP_FAIL_RATE_THRESHOLD,
    db=None,
) -> dict:
    """Fail-rate < threshold over the rolling window = reviewer drift.

    Returns {drift_detected, fail_rate, bootstrap, n, threshold}.
    Bootstrap guard: when n < BOOTSTRAP_N_THRESHOLD the threshold is not
    yet statistically meaningful. bootstrap=True, drift_detected=False.
    """
    db = db or _get_db()
    m = rolling_metrics(window=window, db=db)
    bootstrap = m["n"] < BOOTSTRAP_N_THRESHOLD
    drift = (not bootstrap) and (m["fail_rate"] < threshold)
    return {
        "drift_detected": drift,
        "fail_rate": m["fail_rate"],
        "bootstrap": bootstrap,
        "n": m["n"],
        "threshold": threshold,
    }


# ---------------------------------------------------------------------------
# Second-Liaison disagreement check
# ---------------------------------------------------------------------------


def check_second_liaison_disagreement(
    window: int = DEFAULT_DISAGREEMENT_WINDOW,
    threshold: float = DISAGREEMENT_RATE_THRESHOLD,
    db=None,
) -> dict:
    """DISAGREE-VERDICT + CONVERGENT-FAIL-DIVERGENT-REASON rate over last
    `window` stuck-events.

    Reads needs_decker_queue; a row counts as "disagreement" when
    calibration_flag=1 (DISAGREE-VERDICT) OR ambiguity_flag=1 (convergent
    FAIL, divergent reason). Rate = flagged / window.

    Bootstrap gate fires on TOTAL special_liaison reviews (not on `window`):
    the reviewer itself must have enough history before the second-Liaison
    disagreement threshold is load-bearing.
    """
    db = db or _get_db()
    # INNER JOIN against company_issues filters orphan queue rows — e.g.
    # fixtures that leaked into production via a non-isolated test run, or
    # queue rows whose underlying task was later deleted. Without this
    # guard, disagreement_rate can spike on ghost data and fire spurious
    # audits. Ghost-contamination incident 2026-04-19 drove this.
    rows = db.execute(
        "SELECT q.calibration_flag, q.ambiguity_flag"
        " FROM needs_decker_queue q"
        " INNER JOIN company_issues ci ON ci.id = q.task_id"
        " ORDER BY q.surfaced_at DESC LIMIT ?",
        (int(window),),
    ).fetchall()
    total_reviews = _total_special_liaison_reviews(db)
    n_events = len(rows)
    flagged = sum(
        1 for r in rows
        if (r["calibration_flag"] or 0) == 1 or (r["ambiguity_flag"] or 0) == 1
    )
    rate = flagged / n_events if n_events else 0.0
    bootstrap = total_reviews < BOOTSTRAP_N_THRESHOLD
    miss = (not bootstrap) and (n_events > 0) and (rate > threshold)
    return {
        "miss_detected": miss,
        "disagreement_rate": round(rate, 4),
        "bootstrap": bootstrap,
        "n": n_events,
        "total_reviews": total_reviews,
        "threshold": threshold,
    }


# ---------------------------------------------------------------------------
# Audit spawner
# ---------------------------------------------------------------------------


def spawn_audit(
    reason: str,
    metric: dict,
    db=None,
    cooldown_hours: float = AUDIT_COOLDOWN_HOURS,
) -> dict:
    """File an audit row to execution_log.

    During bootstrap (total_reviews < BOOTSTRAP_N_THRESHOLD), the row goes
    in with status='bootstrap_silent' and flagged=0 — spec §Calibration
    says audit firings during bootstrap surface only in the 7-day URGENT
    digest, not live monitoring. Once total_reviews >= N, flagged=1 and
    status='live' so downstream URGENT renderers pick it up immediately.

    Cooldown: if an audit with the same reason was written within
    cooldown_hours, skip this spawn and return spawned=False,
    reason='cooldown'. Prevents per-tick spam when drift persists
    across multiple heartbeat cycles. Pass cooldown_hours=0 to disable.

    Returns {spawned, bootstrap, row_id, reason, flagged, skipped?}.
    """
    owns_txn = db is None
    db = db or _get_db()

    if cooldown_hours and cooldown_hours > 0:
        recent = db.execute(
            "SELECT id FROM execution_log"
            " WHERE actor='calibration_audit' AND detail=?"
            "   AND created_at > datetime('now', ?)"
            " ORDER BY id DESC LIMIT 1",
            (reason, f"-{float(cooldown_hours)} hours"),
        ).fetchone()
        if recent is not None:
            return {
                "spawned": False,
                "skipped": "cooldown",
                "reason": reason,
                "prior_row_id": recent["id"],
            }

    bootstrap = _total_special_liaison_reviews(db) < BOOTSTRAP_N_THRESHOLD
    status = "bootstrap_silent" if bootstrap else "live"
    flagged = 0 if bootstrap else 1
    cur = db.execute(
        "INSERT INTO execution_log"
        " (actor, action, detail, metadata, status, flagged, created_at)"
        " VALUES (?, ?, ?, ?, ?, ?, datetime('now'))",
        (
            "calibration_audit",
            "audit_spawn",
            reason,
            json.dumps(metric, sort_keys=True),
            status,
            flagged,
        ),
    )
    if owns_txn:
        db.commit()
    log.info(
        "Calibration audit spawned: reason=%s bootstrap=%s flagged=%s row_id=%s",
        reason, bootstrap, flagged, cur.lastrowid,
    )
    return {
        "spawned": True,
        "bootstrap": bootstrap,
        "row_id": cur.lastrowid,
        "reason": reason,
        "flagged": flagged,
    }


# ---------------------------------------------------------------------------
# Composite one-shot check
# ---------------------------------------------------------------------------


def run_calibration_check(db=None) -> dict:
    """Run both calibration checks and spawn audits where warranted.

    Idempotent in the sense that it reads state and files audits without
    mutating the reviewed data itself. Caller drives cadence (heartbeat
    hooks into this at the 30-minute tick).

    Transaction boundary: when no db is provided we open one and commit
    after the audit spawns. When a db is passed in, the caller owns
    the transaction and must commit — spawn_audit won't, because we
    pass the same handle through.
    """
    owns_txn = db is None
    db = db or _get_db()
    drift = check_rubber_stamp_drift(db=db)
    miss = check_second_liaison_disagreement(db=db)
    spawned = []
    if drift["drift_detected"]:
        spawned.append(spawn_audit("rubber_stamp_drift", drift, db=db))
    if miss["miss_detected"]:
        spawned.append(spawn_audit("second_liaison_disagreement", miss, db=db))
    if owns_txn and spawned:
        db.commit()
    return {
        "drift": drift,
        "disagreement": miss,
        "audits_spawned": spawned,
    }
