"""
Correction-rate baseline — track whether the brain is learning per domain.

Queries correction/fix/feedback memories, classifies by domain via keyword
matching on content, buckets into 7-day windows, and computes trend direction.

CLI:  aibrain corrections
API:  from aibrain.core.correction_baseline import correction_baseline
"""

from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional


# ── Domain classifier ────────────────────────────────────────────

DOMAIN_KEYWORDS: dict[str, list[str]] = {
    "security": [
        "vuln", "exploit", "scan", "wintermute", "cve", "rce", "xss",
        "injection", "attack", "target", "kill-chain", "payload", "remediat",
        "nmap", "pentest", "brute", "auth bypass", "csrf",
    ],
    "git": [
        "git ", "commit", "push", "pull", "branch", "rebase", "merge",
        "stash", "github", "remote", "checkout", "cherry-pick",
    ],
    "aibrain": [
        "aibrain", "memory", "brain", "workflow", "harness", "evolution",
        "metric", "mcp", "agent", "skill", "profile",
    ],
    "infrastructure": [
        "docker", "deploy", "server", "vps", "nginx", "port", "ssh",
        "tailscale", "ci/cd", "cron", "systemd", "firewall",
    ],
    "testing": [
        "test", "assert", "pytest", "verify", "fixture", "mock",
    ],
    "communications": [
        "telegram", "email", "outreach", "message", "notification", "inbox",
    ],
    "config": [
        "config", "setting", "env var", "credential", "token", "path",
        ".env", "dotenv",
    ],
    "trading": [
        "trade", "momentum", "exchange", "wallet", "eth ", "crypto",
        "price", "fill", "order", "slippage",
    ],
}

CORRECTION_TYPES = ("correction", "fix", "feedback")


def classify_domain(content: str) -> str:
    """Return the first matching domain for *content*, or 'other'."""
    lowered = content.lower()
    for domain, keywords in DOMAIN_KEYWORDS.items():
        if any(kw in lowered for kw in keywords):
            return domain
    return "other"


# ── DB helper ────────────────────────────────────────────────────

def _connect(db_path: Optional[str] = None) -> sqlite3.Connection:
    if db_path is None:
        db_path = str(Path(__file__).resolve().parents[2] / "aibrain.db")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


# ── Core analysis ────────────────────────────────────────────────

def _bucket_key(created: str, origin: str, window_days: int = 7) -> int:
    """Return the 0-based window index for a timestamp relative to origin."""
    try:
        t = datetime.fromisoformat(created)
        t0 = datetime.fromisoformat(origin)
        return int((t - t0).total_seconds() / (window_days * 86400))
    except (ValueError, TypeError):
        return 0


def correction_baseline(
    days: int = 60,
    window_days: int = 7,
    db_path: Optional[str] = None,
) -> dict:
    """Compute correction rate per domain per 7-day window.

    Returns dict with:
      - domains: {domain: {windows: [{bucket, count, total, rate}], trend}}
      - summary: {total_corrections, date_range, learning, regressing, stable}
    """
    conn = _connect(db_path)
    c = conn.cursor()

    cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()

    # All memories in the period (for total-per-window denominator)
    c.execute(
        "SELECT created, content, type FROM memories "
        "WHERE created >= ? AND active = 1",
        (cutoff,),
    )
    all_rows = c.fetchall()

    # Separate corrections from totals
    corrections = []
    totals_by_domain: dict[str, dict[int, int]] = {}
    corrections_by_domain: dict[str, dict[int, int]] = {}

    if not all_rows:
        conn.close()
        return {"domains": {}, "summary": _empty_summary()}

    origin = min(r["created"] for r in all_rows)

    for row in all_rows:
        domain = classify_domain(row["content"] or "")
        bucket = _bucket_key(row["created"], origin, window_days)

        totals_by_domain.setdefault(domain, {})
        totals_by_domain[domain][bucket] = totals_by_domain[domain].get(bucket, 0) + 1

        if row["type"] in CORRECTION_TYPES:
            corrections_by_domain.setdefault(domain, {})
            corrections_by_domain[domain][bucket] = (
                corrections_by_domain[domain].get(bucket, 0) + 1
            )
            corrections.append(row)

    conn.close()

    # Build per-domain windows
    domains: dict[str, dict] = {}
    learning = []
    regressing = []
    stable = []

    all_domains = sorted(set(list(totals_by_domain.keys()) + list(corrections_by_domain.keys())))

    for domain in all_domains:
        d_totals = totals_by_domain.get(domain, {})
        d_corrections = corrections_by_domain.get(domain, {})
        all_buckets = sorted(set(list(d_totals.keys()) + list(d_corrections.keys())))

        windows = []
        for b in all_buckets:
            total = d_totals.get(b, 0)
            corr = d_corrections.get(b, 0)
            rate = round(corr / total, 4) if total else 0.0
            windows.append({
                "bucket": b,
                "corrections": corr,
                "total": total,
                "rate": rate,
            })

        trend = _compute_trend(windows)
        domains[domain] = {"windows": windows, "trend": trend}

        if trend == "learning":
            learning.append(domain)
        elif trend == "regressing":
            regressing.append(domain)
        else:
            stable.append(domain)

    summary = {
        "total_corrections": len(corrections),
        "total_memories": len(all_rows),
        "date_range_days": days,
        "window_days": window_days,
        "learning": learning,
        "regressing": regressing,
        "stable": stable,
    }

    return {"domains": domains, "summary": summary}


def _compute_trend(windows: list[dict]) -> str:
    """Determine trend from a list of rate windows.

    Uses simple linear comparison: first-half avg vs second-half avg.
    Needs at least 2 windows with data.
    """
    rates = [w["rate"] for w in windows if w["total"] > 0]
    if len(rates) < 2:
        return "insufficient_data"

    mid = len(rates) // 2
    first_half = sum(rates[:mid]) / mid
    second_half = sum(rates[mid:]) / (len(rates) - mid)

    threshold = 0.02  # 2 percentage point change required
    if second_half < first_half - threshold:
        return "learning"
    elif second_half > first_half + threshold:
        return "regressing"
    return "stable"


def _empty_summary() -> dict:
    return {
        "total_corrections": 0,
        "total_memories": 0,
        "date_range_days": 0,
        "window_days": 7,
        "learning": [],
        "regressing": [],
        "stable": [],
    }


# ── Store baseline to evolution_metrics ──────────────────────────

def store_baseline(db_path: Optional[str] = None) -> int:
    """Snapshot current correction rates into evolution_metrics. Returns row count."""
    data = correction_baseline(db_path=db_path)
    conn = _connect(db_path)
    c = conn.cursor()
    count = 0

    for domain, info in data["domains"].items():
        # Store latest window rate as the baseline metric
        if info["windows"]:
            latest = info["windows"][-1]
            c.execute(
                "INSERT INTO evolution_metrics "
                "(metric_name, metric_value, source, period, recorded_at) "
                "VALUES (?, ?, ?, ?, datetime('now'))",
                (
                    f"correction_rate_{domain}",
                    latest["rate"],
                    "correction_baseline",
                    "weekly",
                ),
            )
            count += 1

    # Store trend summary
    for trend_type in ("learning", "regressing", "stable"):
        domains = data["summary"].get(trend_type, [])
        if domains:
            c.execute(
                "INSERT INTO evolution_metrics "
                "(metric_name, metric_value, source, period, recorded_at) "
                "VALUES (?, ?, ?, ?, datetime('now'))",
                (
                    f"correction_trend_{trend_type}_count",
                    float(len(domains)),
                    "correction_baseline",
                    "snapshot",
                ),
            )
            count += 1

    conn.commit()
    conn.close()
    return count


# ── Sparkline renderer ───────────────────────────────────────────

_SPARK_CHARS = " ▁▂▃▄▅▆▇█"


def _sparkline(values: list[float]) -> str:
    """Render a list of floats as a Unicode sparkline."""
    if not values:
        return ""
    lo, hi = min(values), max(values)
    span = hi - lo if hi != lo else 1.0
    return "".join(
        _SPARK_CHARS[min(len(_SPARK_CHARS) - 1, int((v - lo) / span * (len(_SPARK_CHARS) - 1)))]
        for v in values
    )


_TREND_ICONS = {
    "learning": "↓ LEARNING",
    "regressing": "↑ REGRESSING",
    "stable": "— STABLE",
    "insufficient_data": "? NO DATA",
}


def print_corrections(days: int = 60, db_path: Optional[str] = None) -> None:
    """CLI renderer: correction rate trend per domain with sparklines."""
    data = correction_baseline(days=days, db_path=db_path)
    summary = data["summary"]

    print()
    print("=" * 62)
    print("  Correction Rate Baseline")
    print(f"  {summary['total_corrections']:,} corrections / "
          f"{summary['total_memories']:,} memories over {days}d")
    print("=" * 62)

    if not data["domains"]:
        print("\n  No correction data found.\n")
        return

    # Sort: regressing first (needs attention), then stable, then learning
    order = {"regressing": 0, "stable": 1, "insufficient_data": 2, "learning": 3}
    sorted_domains = sorted(
        data["domains"].items(),
        key=lambda kv: (order.get(kv[1]["trend"], 2), kv[0]),
    )

    for domain, info in sorted_domains:
        trend_label = _TREND_ICONS.get(info["trend"], info["trend"])
        rates = [w["rate"] for w in info["windows"]]
        spark = _sparkline(rates)
        total_corr = sum(w["corrections"] for w in info["windows"])
        latest_rate = f"{rates[-1]:.0%}" if rates else "n/a"

        print(f"\n  {domain:<16} {trend_label}")
        print(f"    {spark}  latest: {latest_rate}  total: {total_corr}")

    # Summary
    print(f"\n  {'─' * 50}")
    if summary["learning"]:
        print(f"  Learning:    {', '.join(summary['learning'])}")
    if summary["regressing"]:
        print(f"  Regressing:  {', '.join(summary['regressing'])}")
    if summary["stable"]:
        print(f"  Stable:      {', '.join(summary['stable'])}")
    print()


# ── CLI entry point ──────────────────────────────────────────────

def cli_corrections(args: list[str] | None = None) -> int:
    """Entry point for `aibrain corrections`."""
    import sys
    args = args or sys.argv[1:]

    days = 60
    db_path = None
    store = False

    i = 0
    while i < len(args):
        if args[i] == "--days" and i + 1 < len(args):
            days = int(args[i + 1])
            i += 2
        elif args[i] == "--db" and i + 1 < len(args):
            db_path = args[i + 1]
            i += 2
        elif args[i] == "--store":
            store = True
            i += 1
        else:
            i += 1

    print_corrections(days=days, db_path=db_path)

    if store:
        n = store_baseline(db_path=db_path)
        print(f"  Stored {n} metrics to evolution_metrics.\n")

    return 0
