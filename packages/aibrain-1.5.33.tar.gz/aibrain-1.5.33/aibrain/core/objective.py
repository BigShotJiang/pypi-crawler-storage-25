"""
objective.py — Primary objective function for AIBrain self-improvement.

Answers the question: "Is this brain getting better?"

The brain fitness score is a composite of five measurable signals:

1. Task Quality Trend     (weight 0.30) — Are eval_scores trending up?
2. Correction Rate Trend  (weight 0.25) — Are failure patterns decreasing?
3. Memory Consolidation   (weight 0.20) — Is the brain denser, not just bigger?
4. Recall Precision       (weight 0.15) — Are recalled memories accessed repeatedly?
5. Response Efficiency    (weight 0.10) — Is execution getting faster?

Each metric is normalized to 0.0–1.0. The composite brain_fitness score
is their weighted sum, also 0.0–1.0.

Usage:
    from aibrain.core.objective import brain_fitness, brain_fitness_trend

    score = brain_fitness()                  # last 30 days, 0.0–1.0
    trend = brain_fitness_trend()            # last 4 weeks
    record_fitness()                         # write to evolution_metrics

CLI:
    aibrain fitness
"""

import sqlite3
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.objective")

# ── Metric weights ──────────────────────────────────────────────────────
WEIGHTS = {
    "task_quality_trend":     0.30,
    "correction_rate_trend":  0.25,
    "memory_consolidation":   0.20,
    "recall_precision":       0.15,
    "response_efficiency":    0.10,
}


def _find_db() -> Optional[Path]:
    """Locate the aibrain database via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    db_path = AIBRAIN_ROOT / "aibrain.db"
    return db_path if db_path.exists() else None


def _open_db(db_path: Optional[Path] = None) -> Optional[sqlite3.Connection]:
    """Open a read-only connection to the brain DB."""
    if db_path is None:
        db_path = _find_db()
    if db_path is None or not db_path.exists():
        return None
    db = sqlite3.connect(str(db_path))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    return db


# ── Individual Metrics ──────────────────────────────────────────────────

def metric_task_quality_trend(db: sqlite3.Connection, window_days: int = 30) -> float:
    """
    Are eval_scores trending up over the window?

    Compares average quality in the second half of the window to the first half.
    Score: 0.0 (declining) to 1.0 (strongly improving).
    Baseline (flat) = 0.5.
    """
    cutoff = (datetime.utcnow() - timedelta(days=window_days)).isoformat()
    midpoint = (datetime.utcnow() - timedelta(days=window_days // 2)).isoformat()

    try:
        first_half = db.execute(
            "SELECT AVG(quality_score) FROM execution_log "
            "WHERE success=1 AND quality_score IS NOT NULL "
            "AND created_at >= ? AND created_at < ?",
            (cutoff, midpoint)
        ).fetchone()[0]

        second_half = db.execute(
            "SELECT AVG(quality_score) FROM execution_log "
            "WHERE success=1 AND quality_score IS NOT NULL "
            "AND created_at >= ?",
            (midpoint,)
        ).fetchone()[0]
    except Exception:
        return 0.5

    if first_half is None or second_half is None:
        # Not enough data — return neutral
        return 0.5

    # Delta normalized: +0.3 improvement maps to 1.0, -0.3 maps to 0.0
    delta = second_half - first_half
    normalized = 0.5 + (delta / 0.6)  # ±0.3 -> 0..1
    return max(0.0, min(1.0, normalized))


def metric_correction_rate_trend(db: sqlite3.Connection, window_days: int = 30) -> float:
    """
    Are failure patterns decreasing over time?

    Compares failure count in the second half vs first half of the window.
    Fewer failures in the recent half = higher score.
    Score: 0.0 (failures increasing) to 1.0 (failures decreasing).
    """
    cutoff = (datetime.utcnow() - timedelta(days=window_days)).isoformat()
    midpoint = (datetime.utcnow() - timedelta(days=window_days // 2)).isoformat()

    try:
        first_failures = db.execute(
            "SELECT COUNT(*) FROM execution_log "
            "WHERE success=0 AND created_at >= ? AND created_at < ?",
            (cutoff, midpoint)
        ).fetchone()[0]

        second_failures = db.execute(
            "SELECT COUNT(*) FROM execution_log "
            "WHERE success=0 AND created_at >= ?",
            (midpoint,)
        ).fetchone()[0]
    except Exception:
        return 0.5

    total = first_failures + second_failures
    if total == 0:
        # No failures at all — perfect
        return 1.0

    # Ratio: if first_half had all failures and second_half had none, score = 1.0
    # If second_half has all failures, score = 0.0
    # If equal, score = 0.5
    first_ratio = first_failures / total
    # first_ratio = 1.0 means all failures were in the past (good, score 1.0)
    # first_ratio = 0.0 means all failures are recent (bad, score 0.0)
    return max(0.0, min(1.0, first_ratio))


def metric_memory_consolidation(db: sqlite3.Connection, window_days: int = 30) -> float:
    """
    Is the brain getting denser, not just bigger?

    Measures: (active memories with access_count > 1) / (total active memories).
    Higher ratio = memories are being reused, not just accumulated.
    Score: 0.0 (all memories unused) to 1.0 (all memories reused).
    """
    try:
        total = db.execute(
            "SELECT COUNT(*) FROM memories WHERE active=1"
        ).fetchone()[0]

        if total == 0:
            return 0.5

        reused = db.execute(
            "SELECT COUNT(*) FROM memories WHERE active=1 AND access_count > 1"
        ).fetchone()[0]

        # Also factor in: what fraction of memories were created in the window
        # but have already been accessed? (fresh memories being useful = good)
        cutoff = (datetime.utcnow() - timedelta(days=window_days)).isoformat()
        recent_total = db.execute(
            "SELECT COUNT(*) FROM memories WHERE active=1 AND created >= ?",
            (cutoff,)
        ).fetchone()[0]

        recent_accessed = db.execute(
            "SELECT COUNT(*) FROM memories WHERE active=1 AND created >= ? AND access_count > 0",
            (cutoff,)
        ).fetchone()[0]

    except Exception:
        return 0.5

    # Base: overall reuse ratio (weight 0.6)
    reuse_ratio = reused / total if total > 0 else 0

    # Recent: fresh memory utility (weight 0.4)
    recent_ratio = recent_accessed / recent_total if recent_total > 0 else 0.5

    score = 0.6 * reuse_ratio + 0.4 * recent_ratio
    return max(0.0, min(1.0, score))


def metric_recall_precision(db: sqlite3.Connection, window_days: int = 30) -> float:
    """
    Are recalled memories useful?

    Proxy: memories with high access_count relative to their age are being
    recalled precisely (the system finds what it needs).
    Measures the median access_count / age_days for active memories.
    Higher = better recall precision.
    """
    try:
        rows = db.execute(
            "SELECT access_count, "
            "julianday('now') - julianday(created) AS age_days "
            "FROM memories WHERE active=1 AND access_count > 0"
        ).fetchall()
    except Exception:
        return 0.5

    if not rows:
        return 0.5

    # Access rate per day for each memory
    rates = []
    for r in rows:
        age = max(r["age_days"], 1.0)  # avoid division by zero
        rates.append(r["access_count"] / age)

    rates.sort()
    median_rate = rates[len(rates) // 2]

    # Normalize: a median rate of 0.5 accesses/day = 1.0 (very actively used brain)
    # A rate of 0.01 = ~0.02 (dormant brain)
    normalized = min(1.0, median_rate / 0.5)
    return max(0.0, normalized)


def metric_response_efficiency(db: sqlite3.Connection, window_days: int = 30) -> float:
    """
    Is execution getting faster?

    Compares median duration_ms in the second half vs first half.
    Faster = higher score.
    """
    cutoff = (datetime.utcnow() - timedelta(days=window_days)).isoformat()
    midpoint = (datetime.utcnow() - timedelta(days=window_days // 2)).isoformat()

    try:
        first_durations = [r[0] for r in db.execute(
            "SELECT duration_ms FROM execution_log "
            "WHERE success=1 AND duration_ms > 0 "
            "AND created_at >= ? AND created_at < ?",
            (cutoff, midpoint)
        ).fetchall()]

        second_durations = [r[0] for r in db.execute(
            "SELECT duration_ms FROM execution_log "
            "WHERE success=1 AND duration_ms > 0 "
            "AND created_at >= ?",
            (midpoint,)
        ).fetchall()]
    except Exception:
        return 0.5

    if not first_durations or not second_durations:
        return 0.5

    first_durations.sort()
    second_durations.sort()
    first_median = first_durations[len(first_durations) // 2]
    second_median = second_durations[len(second_durations) // 2]

    if first_median == 0:
        return 0.5

    # Speedup ratio: if second is half the duration, that's great
    speedup = (first_median - second_median) / first_median
    # speedup = 0.5 means 50% faster -> score 1.0
    # speedup = 0.0 means same speed -> score 0.5
    # speedup = -0.5 means 50% slower -> score 0.0
    normalized = 0.5 + speedup
    return max(0.0, min(1.0, normalized))


# ── Composite Score ─────────────────────────────────────────────────────

def brain_fitness(window_days: int = 30, db_path: Optional[Path] = None) -> dict:
    """
    Compute the composite brain fitness score.

    Returns:
        {
            "fitness": float,                    # composite 0.0–1.0
            "metrics": {name: float, ...},       # individual metric scores
            "weights": {name: float, ...},       # weights used
            "window_days": int,
            "computed_at": str,                  # ISO timestamp
        }
    """
    db = _open_db(db_path)
    if db is None:
        return {
            "fitness": 0.0,
            "metrics": {k: 0.0 for k in WEIGHTS},
            "weights": dict(WEIGHTS),
            "window_days": window_days,
            "computed_at": datetime.utcnow().isoformat(),
            "error": "database not found",
        }

    try:
        metrics = {
            "task_quality_trend":    metric_task_quality_trend(db, window_days),
            "correction_rate_trend": metric_correction_rate_trend(db, window_days),
            "memory_consolidation":  metric_memory_consolidation(db, window_days),
            "recall_precision":      metric_recall_precision(db, window_days),
            "response_efficiency":   metric_response_efficiency(db, window_days),
        }

        fitness = sum(metrics[k] * WEIGHTS[k] for k in WEIGHTS)
        fitness = round(max(0.0, min(1.0, fitness)), 4)

        return {
            "fitness": fitness,
            "metrics": {k: round(v, 4) for k, v in metrics.items()},
            "weights": dict(WEIGHTS),
            "window_days": window_days,
            "computed_at": datetime.utcnow().isoformat(),
        }
    finally:
        db.close()


def brain_fitness_trend(
    periods: int = 4,
    window_days: int = 7,
    db_path: Optional[Path] = None,
) -> list[dict]:
    """
    Compute fitness over the last N periods (each `window_days` wide).

    Returns a list of dicts, oldest first:
        [{"period": 1, "window_start": "...", "fitness": 0.72, "metrics": {...}}, ...]
    """
    db = _open_db(db_path)
    if db is None:
        return []

    try:
        results = []
        now = datetime.utcnow()

        for i in range(periods, 0, -1):
            # Period i: ends (periods - i) * window_days ago
            period_end = now - timedelta(days=(i - 1) * window_days)
            period_start = period_end - timedelta(days=window_days)

            # Temporarily override the window by computing metrics
            # over a specific time range. We use a synthetic approach:
            # compute each metric using the period boundaries.
            metrics = _compute_period_metrics(db, period_start, period_end)
            fitness = sum(metrics[k] * WEIGHTS[k] for k in WEIGHTS)
            fitness = round(max(0.0, min(1.0, fitness)), 4)

            results.append({
                "period": periods - i + 1,
                "window_start": period_start.isoformat(),
                "window_end": period_end.isoformat(),
                "fitness": fitness,
                "metrics": {k: round(v, 4) for k, v in metrics.items()},
            })

        return results
    finally:
        db.close()


def _compute_period_metrics(
    db: sqlite3.Connection,
    start: datetime,
    end: datetime,
) -> dict:
    """Compute all metrics for a specific time period."""
    start_iso = start.isoformat()
    end_iso = end.isoformat()
    mid_iso = (start + (end - start) / 2).isoformat()

    metrics = {}

    # 1. Task quality trend (compare first half vs second half of period)
    try:
        first = db.execute(
            "SELECT AVG(quality_score) FROM execution_log "
            "WHERE success=1 AND quality_score IS NOT NULL "
            "AND created_at >= ? AND created_at < ?",
            (start_iso, mid_iso)
        ).fetchone()[0]
        second = db.execute(
            "SELECT AVG(quality_score) FROM execution_log "
            "WHERE success=1 AND quality_score IS NOT NULL "
            "AND created_at >= ? AND created_at < ?",
            (mid_iso, end_iso)
        ).fetchone()[0]
        if first is not None and second is not None:
            delta = second - first
            metrics["task_quality_trend"] = max(0.0, min(1.0, 0.5 + delta / 0.6))
        else:
            metrics["task_quality_trend"] = 0.5
    except Exception:
        metrics["task_quality_trend"] = 0.5

    # 2. Correction rate trend
    try:
        f_fail = db.execute(
            "SELECT COUNT(*) FROM execution_log "
            "WHERE success=0 AND created_at >= ? AND created_at < ?",
            (start_iso, mid_iso)
        ).fetchone()[0]
        s_fail = db.execute(
            "SELECT COUNT(*) FROM execution_log "
            "WHERE success=0 AND created_at >= ? AND created_at < ?",
            (mid_iso, end_iso)
        ).fetchone()[0]
        total_fail = f_fail + s_fail
        if total_fail == 0:
            metrics["correction_rate_trend"] = 1.0
        else:
            metrics["correction_rate_trend"] = max(0.0, min(1.0, f_fail / total_fail))
    except Exception:
        metrics["correction_rate_trend"] = 0.5

    # 3. Memory consolidation (snapshot at period end — not period-scoped)
    try:
        total = db.execute(
            "SELECT COUNT(*) FROM memories WHERE active=1 AND created <= ?",
            (end_iso,)
        ).fetchone()[0]
        reused = db.execute(
            "SELECT COUNT(*) FROM memories WHERE active=1 AND access_count > 1 AND created <= ?",
            (end_iso,)
        ).fetchone()[0]
        metrics["memory_consolidation"] = reused / total if total > 0 else 0.5
    except Exception:
        metrics["memory_consolidation"] = 0.5

    # 4. Recall precision (snapshot at period end)
    try:
        rows = db.execute(
            "SELECT access_count, "
            "julianday(?) - julianday(created) AS age_days "
            "FROM memories WHERE active=1 AND access_count > 0 AND created <= ?",
            (end_iso, end_iso)
        ).fetchall()
        if rows:
            rates = sorted(max(r["access_count"], 0) / max(r["age_days"], 1.0) for r in rows)
            median = rates[len(rates) // 2]
            metrics["recall_precision"] = min(1.0, median / 0.5)
        else:
            metrics["recall_precision"] = 0.5
    except Exception:
        metrics["recall_precision"] = 0.5

    # 5. Response efficiency
    try:
        f_dur = [r[0] for r in db.execute(
            "SELECT duration_ms FROM execution_log "
            "WHERE success=1 AND duration_ms > 0 "
            "AND created_at >= ? AND created_at < ?",
            (start_iso, mid_iso)
        ).fetchall()]
        s_dur = [r[0] for r in db.execute(
            "SELECT duration_ms FROM execution_log "
            "WHERE success=1 AND duration_ms > 0 "
            "AND created_at >= ? AND created_at < ?",
            (mid_iso, end_iso)
        ).fetchall()]
        if f_dur and s_dur:
            f_dur.sort()
            s_dur.sort()
            f_med = f_dur[len(f_dur) // 2]
            s_med = s_dur[len(s_dur) // 2]
            if f_med > 0:
                speedup = (f_med - s_med) / f_med
                metrics["response_efficiency"] = max(0.0, min(1.0, 0.5 + speedup))
            else:
                metrics["response_efficiency"] = 0.5
        else:
            metrics["response_efficiency"] = 0.5
    except Exception:
        metrics["response_efficiency"] = 0.5

    return metrics


# ── Persistence ─────────────────────────────────────────────────────────

def record_fitness(db_path: Optional[Path] = None) -> dict:
    """
    Compute brain fitness and record it in evolution_metrics.

    Call this after each evolution cycle to build a historical record.
    """
    result = brain_fitness(db_path=db_path)

    db = _open_db(db_path)
    if db is None:
        return result

    try:
        # Ensure table exists
        db.execute("""
            CREATE TABLE IF NOT EXISTS evolution_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                metric_name TEXT NOT NULL,
                metric_value REAL NOT NULL,
                source TEXT,
                period TEXT,
                recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Record composite fitness
        db.execute(
            "INSERT INTO evolution_metrics (metric_name, metric_value, source, period) "
            "VALUES (?, ?, ?, ?)",
            ("brain_fitness", result["fitness"], "objective", "snapshot")
        )

        # Record individual metrics
        for name, value in result["metrics"].items():
            db.execute(
                "INSERT INTO evolution_metrics (metric_name, metric_value, source, period) "
                "VALUES (?, ?, ?, ?)",
                (name, value, "objective", "snapshot")
            )

        db.commit()
    except Exception as e:
        log.warning("Failed to record fitness: %s", e)
    finally:
        db.close()

    return result


# ── CLI ─────────────────────────────────────────────────────────────────

def cli_fitness(args: list[str] = None) -> int:
    """CLI handler for `aibrain fitness`."""
    args = args or []

    window = 30
    if "--window" in args:
        idx = args.index("--window")
        if idx + 1 < len(args):
            try:
                window = int(args[idx + 1])
            except ValueError:
                pass

    show_trend = "--trend" in args or not args

    # Current fitness
    result = brain_fitness(window_days=window)

    if result.get("error"):
        print(f"\n  Brain Fitness: unavailable ({result['error']})")
        return 1

    score = result["fitness"]

    # Score interpretation
    if score >= 0.8:
        label = "excellent"
    elif score >= 0.6:
        label = "good"
    elif score >= 0.4:
        label = "developing"
    elif score >= 0.2:
        label = "needs attention"
    else:
        label = "critical"

    print(f"\n  Brain Fitness Score: {score:.2f} ({label})")
    print(f"  {'='*44}")
    print(f"  Window: last {window} days")
    print()

    # Individual metrics with bar visualization
    for name, value in result["metrics"].items():
        weight = WEIGHTS[name]
        bar_len = int(value * 20)
        bar = "#" * bar_len + "-" * (20 - bar_len)
        display_name = name.replace("_", " ").title()
        print(f"  {display_name:<26} [{bar}] {value:.2f}  (w={weight:.2f})")

    # Trend
    if show_trend:
        trend = brain_fitness_trend()
        if trend:
            print(f"\n  Weekly Trend (last {len(trend)} weeks):")
            for period in trend:
                f = period["fitness"]
                bar_len = int(f * 20)
                bar = "#" * bar_len + "-" * (20 - bar_len)
                week_label = f"Week {period['period']}"
                print(f"    {week_label:<10} [{bar}] {f:.2f}")

            # Direction arrow
            if len(trend) >= 2:
                first_f = trend[0]["fitness"]
                last_f = trend[-1]["fitness"]
                if last_f > first_f + 0.05:
                    direction = "^ improving"
                elif last_f < first_f - 0.05:
                    direction = "v declining"
                else:
                    direction = "= stable"
                print(f"\n  Direction: {direction}")

    print()
    return 0
