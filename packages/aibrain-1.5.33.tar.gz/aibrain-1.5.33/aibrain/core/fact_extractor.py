"""
fact_extractor.py — Pattern-based fact extraction from conversation text.

Parses conversation content for factual statements and classifies each as:
  ADD    — new fact not in memory
  UPDATE — modifies/corrects an existing fact
  DELETE — invalidates an old fact
  NOOP   — not a factual statement (opinion, question, filler)

Uses keyword/pattern matching only — no LLM calls. Fast and free.

Usage:
    from aibrain.core.fact_extractor import extract_facts

    facts = extract_facts("The server IP changed to 10.0.0.5. We no longer use Redis.")
    # [
    #   {"action": "UPDATE", "content": "The server IP changed to 10.0.0.5", "confidence": 0.7, "category": "change"},
    #   {"action": "DELETE", "content": "We no longer use Redis", "confidence": 0.8, "category": "removal"},
    # ]

Wire into realtime_learner as an additional signal source via extract_facts_from_messages().
"""

from __future__ import annotations

import re
from typing import Any

# ---------------------------------------------------------------------------
# Sentence splitter
# ---------------------------------------------------------------------------

_SENTENCE_RE = re.compile(
    r'(?<=[.!?])\s+(?=[A-Z])'   # split on sentence-ending punctuation followed by capital
    r'|(?<=\n)\s*(?=\S)',        # or on newline boundaries
)


def _split_sentences(text: str) -> list[str]:
    """Split text into sentences. Returns non-empty, stripped sentences."""
    parts = _SENTENCE_RE.split(text)
    return [s.strip() for s in parts if s.strip() and len(s.strip()) >= 10]


# ---------------------------------------------------------------------------
# Pattern sets for classification
# ---------------------------------------------------------------------------

# UPDATE indicators: something changed, was corrected, moved
_UPDATE_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in [
        r"changed?\s+(?:to|from)",
        r"(?:updated?|switched|migrated?|moved?|renamed?)\s+(?:to|from)",
        r"(?:now|currently)\s+(?:is|uses?|runs?|lives?|points?)",
        r"corrected?\s+to",
        r"(?:was|were)\s+wrong.*(?:actually|really|should be)",
        r"(?:turns out|actually)[,:]?\s+(?:it'?s|the|we|they)",
        r"(?:not|no longer)\s+\w+\s*[,;]\s*(?:now|instead|rather)",
        r"replaced?\s+(?:by|with)",
        r"(?:new|different)\s+(?:address|ip|url|port|path|name|version|key|token)",
    ]
]

# DELETE indicators: something is gone, deprecated, removed
_DELETE_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in [
        r"(?:no longer|don'?t|doesn'?t|won'?t)\s+(?:use|need|have|support|run|exist)",
        r"(?:removed?|deleted?|dropped?|deprecated?|archived?|killed?|stopped?)\s",
        r"(?:is|was|has been)\s+(?:obsolete|dead|gone|removed|deprecated|retired)",
        r"(?:shut\s*down|torn\s*down|decommissioned)",
        r"never\s+(?:use|do|run|deploy|call)\s",
    ]
]

# ADD indicators: new fact, definition, declaration
_ADD_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in [
        r"(?:the|our|my)\s+\w+\s+(?:is|are|was|were|runs?|lives?|uses?)\s",
        r"(?:we|i|they)\s+(?:use|have|run|deploy|created?|built|installed?|set up)\s",
        r"(?:located|stored|found|hosted|deployed)\s+(?:at|in|on|under)\s",
        r"(?:ip|url|port|path|key|version|address)\s*(?:is|:|=)\s",
        r"(?:requires?|depends?\s+on|needs?)\s",
        r"(?:the )?(?:password|token|secret|credential|api.?key)\s+(?:is|for)\s",
        r"(?:default|config|setting)\s+(?:is|=|:)\s",
    ]
]

# NOOP indicators: questions, opinions, filler, commands
_NOOP_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in [
        r"^\s*(?:can you|could you|would you|please|let me|let's|I'll|I will)\s",
        r"^\s*(?:what|where|when|who|why|how|which)\s.*\?\s*$",
        r"^\s*(?:thanks|thank you|ok|okay|sure|yes|no|got it|right|agreed)\s*[.!]?\s*$",
        r"^\s*(?:I think|I believe|maybe|perhaps|probably|might be|could be)\s",
        r"^\s*(?:```|import |def |class |function |const |let |var )\s",
    ]
]

# Noise: system messages, XML tags, tool output
_NOISE_RE = re.compile(
    r"^<(?:system|tool|function|antml|result)", re.IGNORECASE
)


# ---------------------------------------------------------------------------
# Core extraction
# ---------------------------------------------------------------------------

def _classify_sentence(sentence: str) -> tuple[str, float, str]:
    """Classify a single sentence.

    Returns (action, confidence, category) where category is a short label
    like 'change', 'removal', 'definition', 'noop'.
    """
    s = sentence.strip()

    # Skip noise
    if _NOISE_RE.match(s) or len(s) < 10:
        return ("NOOP", 0.0, "noise")

    # Check NOOP first (questions, opinions, commands)
    for pat in _NOOP_PATTERNS:
        if pat.search(s):
            return ("NOOP", 0.9, "noop")

    # Check DELETE (highest priority factual action)
    for pat in _DELETE_PATTERNS:
        if pat.search(s):
            return ("DELETE", 0.8, "removal")

    # Check UPDATE
    for pat in _UPDATE_PATTERNS:
        if pat.search(s):
            return ("UPDATE", 0.7, "change")

    # Check ADD
    for pat in _ADD_PATTERNS:
        if pat.search(s):
            return ("ADD", 0.5, "definition")

    # Default: not a recognizable fact
    return ("NOOP", 0.3, "unclassified")


def extract_facts(text: str) -> list[dict[str, Any]]:
    """Extract structured facts from conversation text.

    Args:
        text: Raw conversation text (can be multi-sentence, multi-line).

    Returns:
        List of dicts with keys:
          - action: "ADD" | "UPDATE" | "DELETE" | "NOOP"
          - content: The sentence containing the fact
          - confidence: 0.0-1.0 confidence in classification
          - category: Short label (e.g., "change", "removal", "definition")

        NOOP entries are excluded from the output by default.
    """
    if not text or not text.strip():
        return []

    sentences = _split_sentences(text)
    facts = []

    for sentence in sentences:
        action, confidence, category = _classify_sentence(sentence)
        if action == "NOOP":
            continue
        facts.append({
            "action": action,
            "content": sentence,
            "confidence": confidence,
            "category": category,
        })

    return facts


# ---------------------------------------------------------------------------
# Integration with realtime_learner
# ---------------------------------------------------------------------------

def extract_facts_from_messages(messages: list[dict]) -> list[dict[str, Any]]:
    """Extract facts from a list of transcript messages.

    Designed to be called alongside extract_learnings() in realtime_learner.
    Returns fact dicts suitable for saving as memories.

    Args:
        messages: List of transcript message dicts (same format as realtime_learner).

    Returns:
        List of dicts with keys: name, type, content, importance, tags, action
    """
    import hashlib

    all_facts: list[dict] = []
    seen_hashes: set[str] = set()

    for msg in messages:
        role = msg.get("role", msg.get("type", "unknown"))
        inner = msg.get("message")
        if isinstance(inner, dict) and inner.get("role"):
            role = inner["role"]

        if role not in ("human", "user", "assistant"):
            continue

        # Extract text — only human-authored prose, not tool call payloads.
        # Inline version to avoid circular import with realtime_learner.
        # tool_use blocks contain JSON-encoded function arguments;
        # tool_result blocks contain raw bash/file output. Both are structured
        # data that generates false-positive ADD/UPDATE facts (e.g. a JSON key
        # "port" matches the ADD pattern r"(?:ip|url|port|...)"). Skip them.
        content = inner if isinstance(inner, dict) else msg
        text = ""
        c = content.get("content")
        if isinstance(c, str):
            text = c
        elif isinstance(c, list):
            text_parts = []
            for b in c:
                if isinstance(b, dict):
                    if b.get("type") == "text":
                        text_parts.append(b.get("text", ""))
                    # tool_use and tool_result intentionally omitted
                elif isinstance(b, str):
                    text_parts.append(b)
            text = "\n".join(text_parts)
        elif content.get("text"):
            text = content["text"]

        if len(text) < 40:
            continue

        facts = extract_facts(text)
        for fact in facts:
            # Confidence threshold: skip low-confidence ADD facts (0.5 is the
            # minimum — they match only a broad ADD pattern). UPDATE (0.7) and
            # DELETE (0.8) are specific enough to keep at their native confidence.
            # This prevents generic sentences like "The task requires admin access"
            # from being stored as factual memories.
            if fact["confidence"] < 0.6 and fact["action"] == "ADD":
                continue

            h = hashlib.md5(fact["content"][:200].encode()).hexdigest()[:10]
            if h in seen_hashes:
                continue
            seen_hashes.add(h)

            importance_map = {"DELETE": 0.8, "UPDATE": 0.7, "ADD": 0.5}

            # Map action to a richer memory type so UPDATE/DELETE facts are
            # routed correctly in the memory store rather than all landing as
            # the generic "fact" type. ADD stays as "fact" (it's a definition).
            type_map = {"UPDATE": "correction", "DELETE": "correction", "ADD": "fact"}

            all_facts.append({
                "name": f"fact_{fact['action'].lower()}_{h}",
                "type": type_map.get(fact["action"], "fact"),
                "content": fact["content"],
                "importance": importance_map.get(fact["action"], 0.5),
                "tags": f"fact,{fact['action'].lower()},{fact['category']},auto-extracted",
                "action": fact["action"],
            })

    return all_facts
