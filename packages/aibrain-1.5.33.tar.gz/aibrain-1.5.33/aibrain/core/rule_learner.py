"""
rule_learner.py — Dynamic HARD RULE learner.

Monitors correction memories via event bus (CORRECTION_RECEIVED events),
tracks correction frequency per pattern (using correction_analysis clusters),
and suggests promoting repeated patterns to HARD RULEs for human review.

Usage:
    from aibrain.core.rule_learner import suggest_new_rules

    suggestions = suggest_new_rules()
    for s in suggestions:
        print(f"[{s['count']}x] {s['pattern']} — {s['representative']}")

CLI:
    aibrain suggest-rules [-n 10] [--threshold 3] [--json]
"""

from __future__ import annotations

import json
import logging
import sqlite3
from collections import defaultdict
from datetime import datetime, timezone

log = logging.getLogger("aibrain.rule_learner")

# ---------------------------------------------------------------------------
# In-memory tracker for live corrections within a session
# ---------------------------------------------------------------------------

_correction_counts: dict[str, list[dict]] = defaultdict(list)

# Minimum repetitions before suggesting a pattern as a rule
DEFAULT_THRESHOLD = 3


def _get_db() -> sqlite3.Connection:
    """Open a connection to aibrain.db via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    db_path = AIBRAIN_ROOT / "aibrain.db"
    conn = sqlite3.connect(str(db_path), check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.row_factory = sqlite3.Row
    return conn


# ---------------------------------------------------------------------------
# Event handler — register on the event bus
# ---------------------------------------------------------------------------

def on_correction_received(payload: dict) -> None:
    """Handle CORRECTION_RECEIVED events from the event bus.

    Tracks each correction by its error_category for frequency analysis.
    """
    category = payload.get("error_category", "other")
    _correction_counts[category].append({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "name": payload.get("name", ""),
        "severity": payload.get("severity", "minor"),
        "content_preview": (payload.get("content", "") or "")[:200],
    })
    log.debug("Correction tracked: category=%s, total=%d", category, len(_correction_counts[category]))


def register_handlers() -> None:
    """Register the correction handler on the event bus."""
    try:
        from aibrain.core.event_bus import on, EventTypes
        on(EventTypes.CORRECTION_RECEIVED, on_correction_received)
        log.debug("Rule learner registered on event bus")
    except ImportError:
        log.debug("Event bus not available — rule learner running in offline mode")


# ---------------------------------------------------------------------------
# Core: suggest rules from correction_analysis clusters
# ---------------------------------------------------------------------------

def suggest_new_rules(
    threshold: int = DEFAULT_THRESHOLD,
    n: int = 10,
    db: sqlite3.Connection | None = None,
) -> list[dict]:
    """Analyze correction patterns and suggest ones that should become HARD RULEs.

    Uses correction_analysis.top_failure_modes() to find clusters of repeated
    corrections. Any cluster with count >= threshold is a candidate rule.

    Args:
        threshold: Minimum correction count to suggest as a rule (default 3).
        n: Maximum number of suggestions to return.
        db: Optional DB connection (for testing).

    Returns:
        List of dicts with keys:
        - pattern: str — description of the failure pattern
        - count: int — number of times this correction appeared
        - representative: str — name of the most important correction
        - importance_avg: float — average importance across cluster
        - example_ids: list[int] — memory IDs in the cluster
        - suggested_rule: str — draft rule text for human review
    """
    from aibrain.core.correction_analysis import top_failure_modes

    # Get all failure modes (request more than n to filter by threshold)
    modes = top_failure_modes(n=50, db=db)

    suggestions = []
    for mode in modes:
        if mode["count"] < threshold:
            continue

        # Generate a suggested rule from the pattern
        rule_text = _draft_rule(mode)

        suggestions.append({
            "pattern": mode["pattern"],
            "count": mode["count"],
            "representative": mode["representative"],
            "importance_avg": mode["importance_avg"],
            "example_ids": mode["example_ids"],
            "suggested_rule": rule_text,
        })

    # Sort by count descending, then by importance
    suggestions.sort(key=lambda s: (-s["count"], -s["importance_avg"]))
    return suggestions[:n]


def _draft_rule(mode: dict) -> str:
    """Draft a HARD RULE suggestion from a failure mode cluster.

    Extracts the representative correction name and formats it as a
    rule statement. Human review is always required.
    """
    rep = mode.get("representative", "").strip()
    pattern = mode.get("pattern", "").strip()
    count = mode.get("count", 0)

    # Use representative name as the base — it's the highest-importance correction
    if rep:
        base = rep
    elif pattern:
        base = pattern
    else:
        base = "Unknown pattern"

    # Clean up: remove common prefixes like "feedback_" or file extensions
    base = base.replace("feedback_", "").replace(".md", "").replace("_", " ")

    return f"HARD RULE: {base} (observed {count}x in corrections)"


# ---------------------------------------------------------------------------
# Session-local suggestions (from live event tracking)
# ---------------------------------------------------------------------------

def suggest_from_session(threshold: int = DEFAULT_THRESHOLD) -> list[dict]:
    """Suggest rules from corrections received in this session only.

    Returns patterns that have repeated >= threshold times in the current
    process lifetime (tracked via event bus handler).
    """
    suggestions = []
    for category, corrections in _correction_counts.items():
        if len(corrections) >= threshold:
            suggestions.append({
                "pattern": f"[session] {category}",
                "count": len(corrections),
                "representative": corrections[0].get("name", category),
                "importance_avg": 0.0,
                "example_ids": [],
                "suggested_rule": f"HARD RULE: Address recurring {category} corrections ({len(corrections)}x this session)",
            })
    suggestions.sort(key=lambda s: -s["count"])
    return suggestions


def reset_session_tracking() -> None:
    """Clear session-local correction tracking (for tests)."""
    _correction_counts.clear()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cli_suggest_rules(args: list[str] | None = None) -> int:
    """CLI entry point for `aibrain suggest-rules`."""
    args = args or []
    threshold = DEFAULT_THRESHOLD
    n = 10
    as_json = "--json" in args

    if "-n" in args:
        idx = args.index("-n")
        if idx + 1 < len(args):
            try:
                n = int(args[idx + 1])
            except ValueError:
                pass

    if "--threshold" in args:
        idx = args.index("--threshold")
        if idx + 1 < len(args):
            try:
                threshold = int(args[idx + 1])
            except ValueError:
                pass

    suggestions = suggest_new_rules(threshold=threshold, n=n)

    # Also include session-local suggestions
    session_suggestions = suggest_from_session(threshold=threshold)
    all_suggestions = suggestions + session_suggestions

    if not all_suggestions:
        if as_json:
            print("[]")
        else:
            print(f"\n  No correction patterns found with {threshold}+ repetitions.")
            print("  Tip: Lower the threshold with --threshold 2\n")
        return 0

    if as_json:
        print(json.dumps(all_suggestions, indent=2))
        return 0

    total = len(all_suggestions)
    print(f"\n  Rule Suggestions ({total} patterns with {threshold}+ repetitions)")
    print(f"  {'=' * 65}")

    for i, s in enumerate(all_suggestions, 1):
        print(f"\n  {i}. {s['pattern']}")
        print(f"     Occurrences: {s['count']} | Avg importance: {s['importance_avg']:.2f}")
        print(f"     Representative: {s['representative']}")
        print(f"     Suggested rule: {s['suggested_rule']}")
        if s["example_ids"]:
            ids_str = str(s["example_ids"][:5])
            if len(s["example_ids"]) > 5:
                ids_str = ids_str[:-1] + f", ... +{len(s['example_ids']) - 5} more]"
            print(f"     Memory IDs: {ids_str}")

    print("\n  Review these suggestions and promote worthy ones to HARD RULEs.")
    print("  These are suggestions only — no rules are created automatically.\n")
    return 0
