"""
local_router.py — SelRoute-inspired local-first model router for AIBrain harness.

Routes tasks to the cheapest capable model based on task classification:
  DETERMINISTIC → no model (code_only, $0)
  SIMPLE        → local Ollama model (if available) → haiku fallback
  JUDGMENT      → claude-sonnet (current default, unchanged)
  COMPLEX       → claude-opus (current default, unchanged)

Local model preference order (smallest capable first):
  1. gemma3:4b   — 4B, fast, general purpose
  2. qwen2.5:7b-instruct — 7B, instruction-tuned
  3. qwen3:8b    — 8B, strong reasoning
  4. gemma3:12b  — 12B, more capable
  5. gemma3:27b  — 27B, near-cloud quality

The router is fully additive — if Ollama is unavailable it falls back silently
to the existing haiku label with zero behavior change.

Usage:
    from aibrain.core.local_router import select_model, is_ollama_available, get_ollama_models

    model_id = select_model("simple")    # → "ollama/gemma3:4b" or "haiku"
    model_id = select_model("judgment")  # → "sonnet"
    model_id = select_model("complex")   # → "opus"
    model_id = select_model("deterministic")  # → "code_only"
"""

import json
import logging
import os
import urllib.request
from functools import lru_cache
from typing import Optional

log = logging.getLogger("aibrain.local_router")

# Ollama endpoint — override via env var if needed
OLLAMA_BASE_URL = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")

# Local model preference order: smallest capable first (cheapest wins)
# Only models that are instruction-tuned / general purpose are included.
# OCR-specific or experimental models are skipped.
LOCAL_MODEL_PREFERENCE = [
    "gemma3:4b",
    "qwen2.5:7b-instruct",
    "qwen3:8b",
    "gemma3:12b",
    "gemma3:27b",
]

# Fallbacks when Ollama not available
CLOUD_MODEL_MAP = {
    "deterministic": "code_only",
    "simple": "haiku",
    "judgment": "sonnet",
    "complex": "opus",
}


@lru_cache(maxsize=1)
def _fetch_ollama_models_cached() -> tuple[str, ...]:
    """Fetch available Ollama models. Cached for the process lifetime."""
    try:
        req = urllib.request.Request(
            f"{OLLAMA_BASE_URL}/api/tags",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=2) as resp:
            data = json.loads(resp.read())
        models = tuple(m["name"] for m in data.get("models", []))
        log.debug("Ollama available — %d models: %s", len(models), models)
        return models
    except Exception as e:
        log.debug("Ollama not available: %s", e)
        return ()


def is_ollama_available() -> bool:
    """Return True if Ollama is running and has at least one model."""
    return len(_fetch_ollama_models_cached()) > 0


def get_ollama_models() -> list[str]:
    """Return list of available Ollama model names."""
    return list(_fetch_ollama_models_cached())


def _pick_local_model(available: tuple[str, ...]) -> Optional[str]:
    """Pick the best local model from available ones, using preference order."""
    for preferred in LOCAL_MODEL_PREFERENCE:
        if preferred in available:
            return preferred
    # None of the preferred models found — use first available non-OCR model
    for model in available:
        if "ocr" not in model.lower() and "vision" not in model.lower():
            return model
    return None


def select_model(task_type: str) -> str:
    """
    Select the optimal model for a given task type.

    Returns a model identifier string:
      - "code_only"          — deterministic, no LLM
      - "ollama/<model>"     — local model via Ollama
      - "haiku"              — Claude Haiku (cloud, cheap)
      - "sonnet"             — Claude Sonnet (cloud, mid)
      - "opus"               — Claude Opus (cloud, best)
    """
    task_type = task_type.lower().strip()

    # DETERMINISTIC: never needs a model
    if task_type == "deterministic":
        return "code_only"

    # JUDGMENT / COMPLEX: always cloud (no local substitution — quality matters)
    if task_type == "judgment":
        return "sonnet"
    if task_type == "complex":
        return "opus"

    # SIMPLE: try Ollama first, fall back to haiku
    if task_type == "simple":
        available = _fetch_ollama_models_cached()
        if available:
            local = _pick_local_model(available)
            if local:
                log.debug("Routing SIMPLE task to local model: %s", local)
                return f"ollama/{local}"
        log.debug("Ollama unavailable — SIMPLE task falls back to haiku")
        return "haiku"

    # Unknown task type — safe default
    log.warning("Unknown task type '%s' — defaulting to sonnet", task_type)
    return "sonnet"


def invalidate_cache():
    """Force a fresh Ollama probe on next call (use after Ollama restarts)."""
    _fetch_ollama_models_cached.cache_clear()
