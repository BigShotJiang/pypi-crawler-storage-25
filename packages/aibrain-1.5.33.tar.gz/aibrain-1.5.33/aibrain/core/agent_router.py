"""
agent_router.py — Layer 1 of SelRoute v3: handler-shape selection.

Given (task_type, task_description, flags), picks which HANDLER SHAPE
should process the task:

    tool_action  — single operational dispatch (e.g. send email, run deploy)
    specialist   — one deep single-lens review (e.g. Security Engineer)
    superworker  — multi-lens synthesis (delegates lens picking to lens_router)

Layer 2 (which lenses if superworker) lives in lens_router.py.

Design principles (see R1A design doc):
  * Pure function `route()` — no DB writes, no network, no LLM calls.
  * Data-driven SHAPE_TABLE — one row per task_type from
    `lens_router.TASK_TYPE_LENSES`. Judgment calls; the feedback loop
    auto-corrects them once we have honest quality scores.
  * `record_outcome()` is the only writer — honest-rubric filter drops
    runs where quality_score is None (mirrors harness.py:348-357).
  * Agent NAMES, never IDs — dispatcher resolves name→id at call time.
  * Lazy-import lens_router inside the superworker branch to dodge
    circular-import traps with harness.py.

Example:
    >>> route(task_type="security_review",
    ...       task_description="check login form for XSS")
    RouteDecision(handler_shape='specialist',
                  agent_name='Security Engineer', ...)
"""

from __future__ import annotations

import logging
import random
import sqlite3
import time
from dataclasses import dataclass
from typing import Optional

log = logging.getLogger("aibrain.agent_router")

# ─── Handler shape constants ───────────────────────────────────────────
TOOL_ACTION = "tool_action"
SPECIALIST = "specialist"
SUPERWORKER = "superworker"

HANDLER_SHAPES = (TOOL_ACTION, SPECIALIST, SUPERWORKER)

# ─── Tuning constants (named for clarity) ─────────────────────────────
MIN_STATS_SAMPLES_FOR_OVERRIDE = 20   # below this, ignore learned stats
MIN_QUALITY_DELTA_FOR_OVERRIDE = 0.10  # shape-flip only if gap this big
EXPLORATION_RATE = 0.05                # 5% random exploration (warm-start only)
STATS_CACHE_TTL_SECONDS = 60           # _load_routing_stats cache window

DEFAULT_COMPANY_ID = "GT_LRWrEBQQ"     # DeckerOps
DEFAULT_FALLBACK_AGENT = "Lead Engineer"  # when a referenced name is missing


# ─── SHAPE_TABLE — 25 task_types from lens_router.TASK_TYPE_LENSES ─────
SHAPE_TABLE: dict[str, str] = {
    # ─── Multi-lens synthesis → SUPERWORKER ─────────────────────────
    "architecture_review":  SUPERWORKER,   # cross-perspective design
    "code_review":          SUPERWORKER,   # style + correctness + ops
    "strategy_decision":    SUPERWORKER,   # Long-Term Vision + Product Philosopher + CEO
    "product_decision":     SUPERWORKER,   # design taste + PM + founder
    "polish_refine":        SUPERWORKER,   # pattern Decker codified
    "first_principles":     SUPERWORKER,   # First Principles + Algorithmic Rigor
    "long_term_vision":     SUPERWORKER,   # Long-Term Vision + Systems Theorist
    "founder_decision":     SUPERWORKER,   # Product Philosopher + Long-Term Vision + CEO
    "memory_synthesis":     SUPERWORKER,   # multi-angle session summaries
    "broad_unknown":        SUPERWORKER,   # safe default — fan out
    "ai_safety":            SUPERWORKER,   # Adversarial Security Lens + Cognitive Bias Audit
    "writing_synthesis":    SUPERWORKER,   # voice + craft + taste
    "research_question":    SUPERWORKER,   # method + domain + analyst
    "business_impact":      SUPERWORKER,   # CFO + Accountant + Competitive Intelligence Analyst
    "ux_design":            SUPERWORKER,   # Product Taste + Product Manager + Cognitive Bias Audit
    "distributed_systems":  SUPERWORKER,   # Distributed Systems + Algorithmic Rigor + Systems Architect
    "scaling_decision":     SUPERWORKER,   # Distributed Systems + Architecture & Performance Analyst

    # ─── Single deep lens → SPECIALIST ──────────────────────────────
    "security_review":      SPECIALIST,    # Security Engineer applied lens
    "metrics_analysis":     SPECIALIST,    # Data Analyst owns it
    "legal_compliance":     SPECIALIST,    # Legal Advisor
    "ml_implementation":    SPECIALIST,    # Empirical Metrics — single deep lens
    "concurrency":          SPECIALIST,    # one correctness lens suffices
    "data_modeling":        SPECIALIST,    # Data-First Thinking single lens
    # Specialty SPECIALIST task types (Apr 11): each routes to ONE
    # mid-tier expert from the new specialty agents added today
    "code_audit":           SPECIALIST,    # Code Security Auditor
    "chain_validation":     SPECIALIST,    # Chain Logic Reviewer
    "regression_test":      SPECIALIST,    # Integration & Regression Risk Analyst
    "test_coverage":        SPECIALIST,    # QA & Test Coverage Analyst
    "dependency_audit":     SPECIALIST,    # Dependency & Supply Chain Auditor
    "defensive_security":   SPECIALIST,    # Blue Team Defense Analyst
    "offensive_security":   SPECIALIST,    # Red Team Adversarial Reviewer
    "desktop_engineering":  SPECIALIST,    # Tauri/Rust Specialist
    "performance_review":   SPECIALIST,    # Architecture & Performance Analyst
    "competitive_analysis": SPECIALIST,    # Competitive Intelligence Analyst
    "archive_search":       SPECIALIST,    # Strategic Archivist
    "product_framing":      SPECIALIST,    # Product Philosopher

    # ─── Operational single-action → TOOL_ACTION ───────────────────
    "operations":           TOOL_ACTION,   # DevOps/COO execute
    "outreach_creator":     TOOL_ACTION,   # Outreach Coordinator dispatches
    "send_communication":   TOOL_ACTION,   # Communications Agent dispatches

    # ─── Reserved enterprise slot task_type (Q1 stub) ──────────────
    "enterprise_reserved":  SUPERWORKER,   # placeholder — filled in v1.4.1+
}

# Default agent NAME per specialist task_type.
# v1.4 lens split: ml_implementation / concurrency / data_modeling used to
# hardcode named personas which leaked into the public wheel. They now
# resolve to public archetypes. A private overlay at
# ``decker_system/02_subagents/lens_overlay.py`` can patch them back to
# named experts on Decker's machine via OVERLAY_AGENT_ROUTER_DEFAULTS.
_DEFAULT_SPECIALIST_AGENT_PUBLIC: dict[str, str] = {
    "security_review":      "Security Engineer",
    "metrics_analysis":     "Data Analyst",
    "legal_compliance":     "Legal Advisor",
    "ml_implementation":    "Empirical Metrics",
    "concurrency":          "Distributed Systems",
    "data_modeling":        "Data-First Thinking",
    # Apr 11 specialty agents (each routes to ONE mid-tier expert).
    # These names MUST exist in lens_router.LENSES — _validate_agent_names
    # at module load enforces this.
    "code_audit":           "Code Security Auditor",
    "chain_validation":     "Chain Logic Reviewer",
    "regression_test":      "Integration & Regression Risk Analyst",
    "test_coverage":        "QA & Test Coverage Analyst",
    "dependency_audit":     "Dependency & Supply Chain Auditor",
    "defensive_security":   "Blue Team Defense Analyst",
    "offensive_security":   "Red Team Adversarial Reviewer",
    "desktop_engineering":  "Tauri/Rust Specialist",
    "performance_review":   "Architecture & Performance Analyst",
    "competitive_analysis": "Competitive Intelligence Analyst",
    "archive_search":       "Strategic Archivist",
    "product_framing":      "Product Philosopher",
}

# Apply the private overlay patch (no-op without a decker_system overlay).
try:
    from aibrain.core.lens_router import OVERLAY_AGENT_ROUTER_DEFAULTS as _OVERLAY_DEFAULTS
except Exception:
    _OVERLAY_DEFAULTS = {}

DEFAULT_SPECIALIST_AGENT: dict[str, str] = {
    **_DEFAULT_SPECIALIST_AGENT_PUBLIC,
    **_OVERLAY_DEFAULTS,
}

# Default agent NAME per tool_action task_type
DEFAULT_TOOL_ACTION_AGENT: dict[str, str] = {
    "operations":         "DevOps Engineer",
    "outreach_creator":   "Outreach Coordinator",
    "send_communication": "Communications Agent",
}


# ─── Frozen result dataclass ───────────────────────────────────────────
@dataclass(frozen=True)
class RouteDecision:
    """Immutable routing decision — all invariants enforced in __post_init__."""
    handler_shape: str                      # one of HANDLER_SHAPES
    task_type: str                          # resolved post-inference
    routing_reason: str
    model_recommendation: str               # "haiku" | "sonnet" | "opus" | "code_only"
    confidence: float                       # 0.0-1.0
    override_mode: str = "auto"             # "auto" | "manual" | "budget_forced"
    agent_name: Optional[str] = None        # for SPECIALIST / TOOL_ACTION
    agent_id: Optional[str] = None          # filled later by dispatcher
    lens_set: Optional[tuple[str, ...]] = None  # for SUPERWORKER (tuple = frozen-safe)
    high_stakes: bool = False

    def __post_init__(self):
        # Shape-coupling invariant #2
        if self.handler_shape in (TOOL_ACTION, SPECIALIST):
            if self.agent_name is None:
                raise ValueError(f"{self.handler_shape} requires agent_name")
            if self.lens_set is not None:
                raise ValueError(f"{self.handler_shape} must not carry lens_set")
        elif self.handler_shape == SUPERWORKER:
            if self.lens_set is None or len(self.lens_set) == 0:
                raise ValueError("superworker requires non-empty lens_set")
            if self.agent_name is not None:
                raise ValueError("superworker must not carry single agent_name")
        else:
            raise ValueError(f"invalid handler_shape: {self.handler_shape!r}")


# ─── Stats cache (read-only overlay) ───────────────────────────────────
_stats_cache: dict[tuple[str, str], tuple[int, float]] = {}
_stats_cache_ts: float = 0.0


def _get_db_conn() -> Optional[sqlite3.Connection]:
    """Open aibrain.db via canonical resolver; return None on any failure."""
    try:
        from aibrain_db import AIBRAIN_ROOT
        db_path = AIBRAIN_ROOT / "aibrain.db"
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        log.debug("agent_router: could not open aibrain.db: %s", e)
        return None


def _ensure_schema(conn: sqlite3.Connection) -> None:
    """Create routing_outcomes table if missing. Idempotent."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS routing_outcomes (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            ts              INTEGER NOT NULL,
            task_type       TEXT    NOT NULL,
            handler_shape   TEXT    NOT NULL,
            override_mode   TEXT    NOT NULL,
            quality_score   REAL,
            duration_ms     INTEGER,
            actor           TEXT
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_routing_outcomes_tt_shape
            ON routing_outcomes(task_type, handler_shape)
    """)
    conn.commit()


def _load_routing_stats() -> dict[tuple[str, str], tuple[int, float]]:
    """Return {(task_type, handler_shape): (n_samples, mean_quality)}.

    Cached for STATS_CACHE_TTL_SECONDS. On DB failure, returns empty
    dict so the router degrades cleanly to pure-table mode.
    Honest-rubric: rows with quality_score IS NULL are excluded.
    """
    global _stats_cache, _stats_cache_ts
    now = time.time()
    if _stats_cache and (now - _stats_cache_ts) < STATS_CACHE_TTL_SECONDS:
        return _stats_cache

    conn = _get_db_conn()
    if conn is None:
        return {}

    stats: dict[tuple[str, str], tuple[int, float]] = {}
    try:
        _ensure_schema(conn)
        rows = conn.execute("""
            SELECT task_type, handler_shape,
                   COUNT(*) AS n, AVG(quality_score) AS mean_q
            FROM routing_outcomes
            WHERE quality_score IS NOT NULL
            GROUP BY task_type, handler_shape
        """).fetchall()
        for r in rows:
            stats[(r["task_type"], r["handler_shape"])] = (int(r["n"]), float(r["mean_q"]))
    except Exception as e:
        log.warning("agent_router: stats load failed, degrading to table mode: %s", e)
        stats = {}
    finally:
        conn.close()

    _stats_cache = stats
    _stats_cache_ts = now
    return stats


def _invalidate_stats_cache() -> None:
    """Force next _load_routing_stats() to re-query. Used by tests."""
    global _stats_cache, _stats_cache_ts
    _stats_cache = {}
    _stats_cache_ts = 0.0


def _pick_model(handler_shape: str, high_stakes: bool) -> str:
    """Pick the model recommendation for a shape.

    tool_action  → haiku
    specialist   → sonnet
    superworker  → sonnet (opus when high_stakes)

    Returns a string the harness translates via dynamic_router.select_model()
    by mapping haiku→"simple", sonnet→"judgment", opus→"complex".
    Monotonic invariant #3: never decreases as high_stakes goes True.
    """
    if handler_shape == TOOL_ACTION:
        return "haiku"
    if handler_shape == SPECIALIST:
        return "sonnet"
    if handler_shape == SUPERWORKER:
        return "opus" if high_stakes else "sonnet"
    return "sonnet"  # defensive default


def _infer_task_type_local(description: str) -> str:
    """Thin wrapper around lens_router._infer_task_type — lazy import."""
    try:
        from aibrain.core import lens_router
        return lens_router._infer_task_type(description)
    except Exception:
        return "broad_unknown"


def _apply_stats_overlay(
    task_type: str,
    default_shape: str,
    stats: dict[tuple[str, str], tuple[int, float]],
) -> tuple[str, Optional[str]]:
    """Return (chosen_shape, overlay_reason).

    If any non-default shape has n≥MIN_STATS_SAMPLES and quality delta
    ≥MIN_QUALITY_DELTA over the default, flip to it. Otherwise keep default.
    5% exploration once both arms have a baseline.
    """
    default_n, default_q = stats.get((task_type, default_shape), (0, 0.0))
    if default_n < MIN_STATS_SAMPLES_FOR_OVERRIDE:
        return default_shape, None

    best_alt: Optional[str] = None
    best_alt_q: float = default_q
    for alt in HANDLER_SHAPES:
        if alt == default_shape:
            continue
        n, q = stats.get((task_type, alt), (0, 0.0))
        if n < MIN_STATS_SAMPLES_FOR_OVERRIDE:
            continue
        if (q - default_q) >= MIN_QUALITY_DELTA_FOR_OVERRIDE and q > best_alt_q:
            best_alt = alt
            best_alt_q = q

    if best_alt is not None:
        return best_alt, (
            f"stats overlay: {best_alt} q={best_alt_q:.2f} beats "
            f"{default_shape} q={default_q:.2f} (n>={MIN_STATS_SAMPLES_FOR_OVERRIDE})"
        )

    # Warm-start exploration: only if at least one alt also has a baseline
    alt_with_data = [
        s for s in HANDLER_SHAPES
        if s != default_shape
        and stats.get((task_type, s), (0, 0.0))[0] >= MIN_STATS_SAMPLES_FOR_OVERRIDE
    ]
    if alt_with_data and random.random() < EXPLORATION_RATE:
        pick = random.choice(alt_with_data)
        return pick, f"exploration: sampling {pick} ({EXPLORATION_RATE*100:.0f}% rate)"

    return default_shape, None


def _compute_lens_set(task_type: str, task_description: str) -> tuple[str, ...]:
    """Delegate to lens_router.route() — lazy import for Layer-2 isolation."""
    from aibrain.core import lens_router
    lr = lens_router.route(task_type=task_type, task_description=task_description)
    return tuple(lr.all_lenses)


def _default_agent_for(shape: str, task_type: str) -> str:
    """Return the default agent NAME for a specialist/tool_action task_type."""
    if shape == SPECIALIST:
        return DEFAULT_SPECIALIST_AGENT.get(task_type, DEFAULT_FALLBACK_AGENT)
    if shape == TOOL_ACTION:
        return DEFAULT_TOOL_ACTION_AGENT.get(task_type, DEFAULT_FALLBACK_AGENT)
    return DEFAULT_FALLBACK_AGENT


# ─── Public API ────────────────────────────────────────────────────────
def route(
    task_type: Optional[str] = None,
    task_description: str = "",
    force_shape: Optional[str] = None,
    high_stakes: bool = False,
    actor: str = "system",
    token_budget_exceeded: bool = False,
) -> RouteDecision:
    """Layer 1 of SelRoute v3 — pick the handler shape.

    Args:
        task_type: explicit category from SHAPE_TABLE. If None / unknown,
                   inferred from task_description via lens_router keywords.
        task_description: free text for keyword inference fallback.
        force_shape: manual override. One of HANDLER_SHAPES or None.
        high_stakes: escalates superworker's final synthesis model to opus.
        actor: for audit trail / future per-user routing.
        token_budget_exceeded: budget-checker signal. When True, ALWAYS
                               forces tool_action with override_mode
                               "budget_forced" regardless of force_shape.

    Returns:
        RouteDecision — guaranteed non-None, all invariants hold.
    """
    # Resolve task_type (may fall through inference to "broad_unknown")
    fallback = False
    resolved_type = task_type
    if resolved_type is None or resolved_type not in SHAPE_TABLE:
        inferred = _infer_task_type_local(task_description)
        if inferred in SHAPE_TABLE:
            resolved_type = inferred
        else:
            resolved_type = "broad_unknown"
            fallback = True

    # ── Priority 1: budget-forced down-tier (beats manual force) ──
    if token_budget_exceeded:
        agent_name = DEFAULT_TOOL_ACTION_AGENT.get(resolved_type, DEFAULT_FALLBACK_AGENT)
        return RouteDecision(
            handler_shape=TOOL_ACTION,
            task_type=resolved_type,
            routing_reason="budget_forced: daily token budget exceeded, downgraded to tool_action",
            model_recommendation=_pick_model(TOOL_ACTION, high_stakes=False),
            confidence=1.0,
            override_mode="budget_forced",
            agent_name=agent_name,
            high_stakes=high_stakes,
        )

    # ── Priority 2: manual force_shape ──
    if force_shape is not None:
        if force_shape not in HANDLER_SHAPES:
            raise ValueError(
                f"force_shape must be one of {HANDLER_SHAPES}, got {force_shape!r}"
            )
        return _build_decision(
            shape=force_shape,
            task_type=resolved_type,
            task_description=task_description,
            routing_reason=f"manual override: user forced {force_shape}",
            override_mode="manual",
            high_stakes=high_stakes,
            confidence=1.0,
        )

    # ── Priority 3: table + stats overlay (automatic path) ──
    default_shape = SHAPE_TABLE.get(resolved_type, SUPERWORKER)
    stats = _load_routing_stats()
    chosen_shape, overlay_reason = _apply_stats_overlay(resolved_type, default_shape, stats)

    reason_parts = [f"task_type={resolved_type!r} → {chosen_shape} (table default)"]
    if fallback:
        reason_parts.append("FALLBACK to broad_unknown")
    if overlay_reason:
        reason_parts.append(overlay_reason)
    confidence = 0.6 if fallback else 0.85

    return _build_decision(
        shape=chosen_shape,
        task_type=resolved_type,
        task_description=task_description,
        routing_reason=" | ".join(reason_parts),
        override_mode="auto",
        high_stakes=high_stakes,
        confidence=confidence,
    )


def _build_decision(
    shape: str,
    task_type: str,
    task_description: str,
    routing_reason: str,
    override_mode: str,
    high_stakes: bool,
    confidence: float,
) -> RouteDecision:
    """Populate agent_name/lens_set for the chosen shape and return a RouteDecision."""
    model_rec = _pick_model(shape, high_stakes=high_stakes)

    if shape == SUPERWORKER:
        lens_set = _compute_lens_set(task_type, task_description)
        return RouteDecision(
            handler_shape=SUPERWORKER,
            task_type=task_type,
            routing_reason=routing_reason,
            model_recommendation=model_rec,
            confidence=confidence,
            override_mode=override_mode,
            lens_set=lens_set,
            high_stakes=high_stakes,
        )

    agent_name = _default_agent_for(shape, task_type)
    return RouteDecision(
        handler_shape=shape,
        task_type=task_type,
        routing_reason=routing_reason,
        model_recommendation=model_rec,
        confidence=confidence,
        override_mode=override_mode,
        agent_name=agent_name,
        high_stakes=high_stakes,
    )


def record_outcome(
    task_type: str,
    handler_shape: str,
    quality_score: Optional[float],
    override_mode: str,
    duration_ms: int,
    actor: str,
) -> None:
    """Record a post-hoc routing outcome for the feedback loop.

    Honest-rubric filter: if quality_score is None, we record NOTHING —
    unmeasurable runs contribute zero signal (matches harness.py:348-357).
    Called by the harness AFTER quality eval.
    """
    if quality_score is None:
        log.debug("agent_router.record_outcome: skipping None-quality run (honest-rubric)")
        return

    if handler_shape not in HANDLER_SHAPES:
        log.warning("agent_router.record_outcome: invalid handler_shape %r", handler_shape)
        return

    conn = _get_db_conn()
    if conn is None:
        return
    try:
        _ensure_schema(conn)
        conn.execute("""
            INSERT INTO routing_outcomes
            (ts, task_type, handler_shape, override_mode, quality_score, duration_ms, actor)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            int(time.time()),
            task_type,
            handler_shape,
            override_mode,
            float(quality_score),
            int(duration_ms),
            actor,
        ))
        conn.commit()
        # Invalidate cache so next route() call sees the new data within TTL
        _invalidate_stats_cache()
    except Exception as e:
        log.warning("agent_router.record_outcome: write failed: %s", e)
    finally:
        conn.close()


def list_shapes_for_task_type(task_type: str) -> dict:
    """Diagnostic — returns the SHAPE_TABLE row plus any overlay stats."""
    default_shape = SHAPE_TABLE.get(task_type)
    stats = _load_routing_stats()
    overlay = {
        shape: stats.get((task_type, shape), (0, 0.0))
        for shape in HANDLER_SHAPES
    }
    return {
        "task_type": task_type,
        "default_shape": default_shape,
        "default_agent_name": (
            DEFAULT_SPECIALIST_AGENT.get(task_type)
            or DEFAULT_TOOL_ACTION_AGENT.get(task_type)
        ),
        "stats": overlay,
    }


# ─── Module-load validation (Adversarial Security Lens: prevent roster drift) ──────────
def _validate_agent_names() -> None:
    """Warn if any SHAPE_TABLE / DEFAULT_*_AGENT name is missing from LENSES.

    Non-blocking: logs a warning so the router still imports even if
    the registry has drifted. Invalid references will fall back to
    DEFAULT_FALLBACK_AGENT at route() time.
    """
    try:
        from aibrain.core.lens_router import LENSES
    except Exception as e:
        log.debug("agent_router: cannot validate agent names (lens_router unavailable): %s", e)
        return

    referenced: set[str] = set()
    referenced.update(DEFAULT_SPECIALIST_AGENT.values())
    referenced.update(DEFAULT_TOOL_ACTION_AGENT.values())
    referenced.add(DEFAULT_FALLBACK_AGENT)

    missing = [name for name in referenced if name not in LENSES]
    if missing:
        log.warning(
            "agent_router: referenced agent names missing from LENSES: %s "
            "(will fall back to %r at route time)",
            missing, DEFAULT_FALLBACK_AGENT,
        )


_validate_agent_names()
