"""llm_pricing.py — Simple model-ID → cost-per-token lookup and cost computation.

Thin API layer over aibrain.core.pricing (which carries the full rate table with
cache-read/write columns and per-million-token precision).

Design
------
- PRICING dict: keyed by model ID prefix (longest-prefix-wins via compute_cost_cents).
  Values are (input_cents_per_1k, output_cents_per_1k) tuples — the format the
  harness task spec requested. Internally converts to per-million for math to avoid
  rounding slop on small calls.
- compute_cost_cents(model, input_tokens, output_tokens) → int: harness-facing helper.
  Returns 0 (not None) for local/Ollama models (they genuinely cost $0).
  Returns None when the model is unknown AND 'default' is not set — honest-rubric.
  Returns the 'default' rate when the model slug doesn't match any known prefix.
- Fail-open contract: if anything goes wrong, returns None — harness treats that as
  "could not measure" and leaves cost_cents_equivalent = None rather than faking 0.

Relationship to pricing.py
---------------------------
aibrain.core.pricing carries the authoritative rate table (ModelRate dataclass,
match_rate, compute_equivalent_cents, extract_tokens_from_cli_envelope, etc.).
This module re-uses that table and adds:
  1. The simpler PRICING dict (cents per 1K tokens) for callers that don't need
     the cache-read/write breakdown.
  2. compute_cost_cents() — the one-liner the harness calls to auto-populate
     cost_cents_equivalent when an action returns _input_tokens/_output_tokens
     without computing cost themselves.

Honest-rubric contract
----------------------
- Local/Ollama models (qwen3, llama, mistral, etc.) → 0 cents (genuinely free).
- Known Claude models (claude-*) → computed from rate table.
- Unknown model + no 'default' entry → None (not a fake 0).
- Negative inputs rejected → None.
"""

from __future__ import annotations

from typing import Optional

# cents per 1K tokens (input, output) — for the simple API
# Values are derived from the authoritative per-million rates in pricing.py:
#   cents_per_1k = cents_per_million / 1000
PRICING: dict[str, tuple[float, float]] = {
    # Sonnet 4.x — $3/$15 per million → 0.3/1.5 per 1K
    "claude-sonnet-4": (0.3, 1.5),
    # Opus 4.6 / 4.5 — $5/$25 per million → 0.5/2.5 per 1K
    "claude-opus-4-6": (0.5, 2.5),
    "claude-opus-4-5": (0.5, 2.5),
    # Opus 4.0 / 4.1 (legacy) — $15/$75 per million → 1.5/7.5 per 1K
    "claude-opus-4": (1.5, 7.5),
    # Haiku 4.5 — $1/$5 per million → 0.1/0.5 per 1K
    "claude-haiku-4-5": (0.1, 0.5),
    # Haiku 4.x fallback
    "claude-haiku-4": (0.1, 0.5),
    # Local / Ollama models — genuinely free
    "qwen": (0.0, 0.0),
    "llama": (0.0, 0.0),
    "mistral": (0.0, 0.0),
    "gemma": (0.0, 0.0),
    "phi": (0.0, 0.0),
    "ollama": (0.0, 0.0),
    "local": (0.0, 0.0),
    # Fallback — used when no prefix matches. Set to Sonnet 4 rates as a
    # conservative estimate. None means "unknown — honest-rubric returns None".
    "default": (0.3, 1.5),
}

# Model name substrings that indicate a local/free model regardless of prefix.
# Checked after prefix matching fails so a prefixed local model still hits 0.
_LOCAL_SIGNALS = frozenset({
    "ollama", "local", "qwen", "llama", "mistral", "gemma", "phi",
    "gguf", "ggml", "llamafile",
})


def _match_pricing(model: str) -> Optional[tuple[float, float]]:
    """Longest-prefix match against PRICING. Returns None if no match and no default."""
    if not model:
        return None
    m_lower = model.lower()
    # Local-signal shortcut — even if the prefix table doesn't have an entry,
    # a local model slug containing these strings costs $0.
    if any(sig in m_lower for sig in _LOCAL_SIGNALS):
        return (0.0, 0.0)
    # Longest-prefix-wins
    for prefix in sorted(PRICING.keys(), key=len, reverse=True):
        if prefix == "default":
            continue
        if m_lower.startswith(prefix.lower()):
            return PRICING[prefix]
    # Fallback to 'default' if present
    if "default" in PRICING:
        return PRICING["default"]
    return None


def compute_cost_cents(
    model: str,
    input_tokens: int,
    output_tokens: int,
) -> Optional[int]:
    """Compute cost in integer cents from token counts and model ID.

    Args:
        model:         Model slug (e.g. 'claude-sonnet-4-20250514').
        input_tokens:  Number of input/prompt tokens consumed.
        output_tokens: Number of output/completion tokens produced.

    Returns:
        Integer cents (>= 0), OR None when the cost is not measurable.

    Honest-rubric contract:
        - Returns 0 for local/Ollama models (genuinely free).
        - Returns None for unknown models when no 'default' is in PRICING
          (prefer honest None over a fabricated estimate).
        - Negative inputs → None (defensive, never a fake).
        - Any exception inside → None (fail-open, never breaks callers).
    """
    try:
        if input_tokens is None or output_tokens is None:
            return None
        if input_tokens < 0 or output_tokens < 0:
            return None

        rates = _match_pricing(model)
        if rates is None:
            return None  # unknown model, no default → honest None

        input_rate, output_rate = rates
        # cents_per_1k * tokens / 1000
        cost = (input_tokens / 1000.0) * input_rate + (output_tokens / 1000.0) * output_rate
        if cost < 0:
            return None
        return int(round(cost))

    except Exception:
        return None  # fail-open — never break callers


def compute_cost_cents_from_response(
    response: object,
    model: Optional[str] = None,
) -> tuple[Optional[str], Optional[int]]:
    """Extract model and compute cost from a common LLM response object.

    Handles the Anthropic SDK response shape (.usage.input_tokens / .usage.output_tokens)
    and the OpenAI-compatible shape (.usage.prompt_tokens / .usage.completion_tokens).

    Args:
        response: The LLM client response object (or None).
        model:    Model slug override. If None, attempts response.model.

    Returns:
        (model_slug, cost_cents_equivalent) — either or both may be None.

    This is the harness integration point: called after an action's LLM call
    returns so the harness can stamp cost_cents_equivalent on the HarnessResult
    without requiring every action to manually compute it.
    """
    if response is None:
        return None, None

    try:
        # Resolve model slug
        resolved_model = model
        if not resolved_model:
            resolved_model = getattr(response, "model", None)
            if isinstance(resolved_model, str):
                resolved_model = resolved_model.strip() or None

        # Try to get usage
        usage = getattr(response, "usage", None)
        if usage is None:
            return resolved_model, None

        # Anthropic SDK shape: input_tokens / output_tokens
        in_tok = getattr(usage, "input_tokens", None)
        out_tok = getattr(usage, "output_tokens", None)

        # OpenAI-compatible shape fallback: prompt_tokens / completion_tokens
        if in_tok is None:
            in_tok = getattr(usage, "prompt_tokens", None)
        if out_tok is None:
            out_tok = getattr(usage, "completion_tokens", None)

        if in_tok is None or out_tok is None:
            return resolved_model, None

        try:
            in_tok = int(in_tok)
            out_tok = int(out_tok)
        except (TypeError, ValueError):
            return resolved_model, None

        cost = compute_cost_cents(resolved_model, in_tok, out_tok)
        return resolved_model, cost

    except Exception:
        return None, None  # fail-open
