"""
local_rag.py — Keyword-based RAG (Retrieval-Augmented Generation) for air-gapped use.

Retrieves relevant memories from aibrain.db using keyword overlap (BM25-style token
matching), prepends them as context to a local LLM call via LocalLLMClient.

No numpy, scipy, or heavy deps required — pure stdlib + sqlite3.

Similarity approach (keyword overlap):
    1. Tokenize query: lowercase, split on non-alphanumeric chars, drop stopwords.
    2. SQL WHERE clause with OR across tokens:
           SELECT id, content, importance FROM memories
           WHERE active=1 AND status='active'
           AND (content LIKE '%token1%' OR content LIKE '%token2%' ...)
    3. Score each result: count of matching tokens in content.
    4. Rank: primary = match_count DESC, secondary = importance DESC.
    5. Deduplicate by content prefix (first 80 chars) and return top_n.

Usage:
    from aibrain.core.local_rag import build_rag_context, complete_with_rag

    # Just retrieval
    context = build_rag_context("CVE-2024-1234 buffer overflow", top_n=5)
    print(context)
    # [MEMORY 1] (importance: 0.9): ...
    # [MEMORY 2] (importance: 0.7): ...

    # Full RAG completion (retrieval + local LLM)
    answer = complete_with_rag(
        query="What do we know about lateral movement techniques?",
        system="You are a security analyst.",
        top_n=5,
    )
"""

import logging
import re
import sqlite3
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.local_rag")

# Stopwords to strip from query tokens — keeps SQL WHERE clause focused
_STOPWORDS = frozenset({
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "is", "it", "this", "that", "be", "are",
    "was", "were", "as", "has", "have", "had", "do", "does", "did", "not",
    "what", "how", "when", "where", "which", "who", "will", "can", "could",
    "would", "should", "may", "might", "about", "into", "than", "then",
    "them", "they", "their", "there", "these", "those", "been", "being",
})


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_rag_context(
    query: str,
    top_n: int = 5,
    db_path: Optional[str] = None,
    min_token_len: int = 3,
) -> str:
    """Query brain memories by keyword overlap, return formatted context block.

    Args:
        query:         Natural language query string.
        top_n:         Maximum number of memories to return.
        db_path:       Path to aibrain.db. Defaults to canonical AIBRAIN_ROOT/aibrain.db.
        min_token_len: Minimum token length to include in SQL WHERE clause (filters noise).

    Returns:
        Formatted string ready to prepend to a system prompt, e.g.:
            [MEMORY 1] (importance: 0.9): content here...
            [MEMORY 2] (importance: 0.7): content here...
        Returns empty string "" if no memories match or DB is unavailable.
    """
    if not query or not query.strip():
        return ""

    db_path = db_path or _resolve_db_path()
    if not Path(db_path).exists():
        log.warning("local_rag: DB not found at %s", db_path)
        return ""

    tokens = _tokenize(query, min_len=min_token_len)
    if not tokens:
        log.debug("local_rag: no usable tokens in query %r", query)
        return ""

    rows = _query_memories(db_path, tokens, fetch_limit=top_n * 6)  # over-fetch for dedup
    if not rows:
        log.debug("local_rag: no memories matched tokens %r", tokens)
        return ""

    # Score by token match count, break ties by importance
    scored = _score_and_rank(rows, tokens)

    # Deduplicate by content prefix (catches near-duplicates)
    deduped = _deduplicate(scored)

    top = deduped[:top_n]
    log.debug("local_rag: query=%r tokens=%r matches=%d returned=%d", query, tokens, len(rows), len(top))

    return _format_context(top)


def complete_with_rag(
    query: str,
    system: str = "",
    model: str = "auto",
    top_n: int = 5,
    db_path: Optional[str] = None,
) -> str:
    """Retrieve RAG context from brain, prepend to system prompt, call LocalLLMClient.

    Args:
        query:   User query. Used for both RAG retrieval and as the user message.
        system:  Base system prompt. RAG context is prepended to this.
        model:   Ollama model name or "auto" (smallest available).
        top_n:   Number of memories to retrieve for context.
        db_path: Path to aibrain.db (optional, uses canonical root by default).

    Returns:
        LLM response string.

    Raises:
        RuntimeError: If Ollama is unavailable.
    """
    from aibrain.core.local_llm import LocalLLMClient

    rag_context = build_rag_context(query, top_n=top_n, db_path=db_path)

    if rag_context:
        full_system = (
            "Relevant context from brain memory:\n\n"
            + rag_context
            + ("\n\n" + system if system else "")
        )
    else:
        full_system = system
        log.debug("complete_with_rag: no matching memories for query %r", query)

    client = LocalLLMClient(model=model)
    messages = [{"role": "user", "content": query}]
    return client.complete(messages=messages, system=full_system)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _resolve_db_path() -> str:
    """Resolve canonical DB path via aibrain_db.AIBRAIN_ROOT."""
    try:
        from aibrain_db import AIBRAIN_ROOT
        return str(AIBRAIN_ROOT / "aibrain.db")
    except Exception:
        # Fallback: look relative to this file
        fallback = Path(__file__).resolve().parent.parent.parent / "aibrain.db"
        return str(fallback)


def _tokenize(query: str, min_len: int = 3) -> list:
    """Split query into lowercase tokens, drop stopwords and short tokens."""
    raw_tokens = re.split(r"[^a-zA-Z0-9_]", query.lower())
    tokens = [
        t for t in raw_tokens
        if len(t) >= min_len and t not in _STOPWORDS
    ]
    # Deduplicate while preserving order
    seen = set()
    result = []
    for t in tokens:
        if t not in seen:
            seen.add(t)
            result.append(t)
    return result


def _query_memories(db_path: str, tokens: list, fetch_limit: int = 50) -> list:
    """SQL keyword search across memories table. Returns list of (id, content, importance) rows."""
    if not tokens:
        return []

    # Build WHERE clause: OR across all tokens
    like_clauses = " OR ".join(["content LIKE ?" for _ in tokens])
    like_args = [f"%{t}%" for t in tokens]

    sql = f"""
        SELECT id, content, importance
        FROM memories
        WHERE active=1
          AND (status IS NULL OR status='active')
          AND ({like_clauses})
        ORDER BY importance DESC
        LIMIT ?
    """
    params = like_args + [fetch_limit]

    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(sql, params).fetchall()
        conn.close()
        return [(r["id"], r["content"] or "", float(r["importance"] or 0.0)) for r in rows]
    except sqlite3.OperationalError as e:
        # Table may not have 'status' column in older schemas — retry without it
        if "no such column: status" in str(e):
            return _query_memories_legacy(db_path, tokens, fetch_limit)
        log.warning("local_rag: DB query error: %s", e)
        return []
    except Exception as e:
        log.warning("local_rag: DB error: %s", e)
        return []


def _query_memories_legacy(db_path: str, tokens: list, fetch_limit: int = 50) -> list:
    """Fallback query for older DB schemas without status column."""
    like_clauses = " OR ".join(["content LIKE ?" for _ in tokens])
    like_args = [f"%{t}%" for t in tokens]

    sql = f"""
        SELECT id, content, importance
        FROM memories
        WHERE active=1
          AND ({like_clauses})
        ORDER BY importance DESC
        LIMIT ?
    """
    params = like_args + [fetch_limit]

    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(sql, params).fetchall()
        conn.close()
        return [(r["id"], r["content"] or "", float(r["importance"] or 0.0)) for r in rows]
    except Exception as e:
        log.warning("local_rag: legacy DB query error: %s", e)
        return []


def _score_and_rank(rows: list, tokens: list) -> list:
    """Score rows by number of matching tokens in content.

    Returns list of (match_count, importance, id, content) sorted desc by
    match_count then importance.
    """
    scored = []
    for mem_id, content, importance in rows:
        content_lower = content.lower()
        match_count = sum(1 for t in tokens if t in content_lower)
        scored.append((match_count, importance, mem_id, content))

    # Primary: match_count DESC, secondary: importance DESC
    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return scored


def _deduplicate(scored: list, prefix_len: int = 80) -> list:
    """Remove near-duplicate memories by content prefix fingerprint."""
    seen_prefixes = set()
    result = []
    for item in scored:
        _, _, _, content = item
        prefix = content[:prefix_len].lower().strip()
        if prefix not in seen_prefixes:
            seen_prefixes.add(prefix)
            result.append(item)
    return result


def _format_context(scored: list) -> str:
    """Format scored memories into a context block string."""
    lines = []
    for i, (match_count, importance, mem_id, content) in enumerate(scored, 1):
        # Truncate very long memories to keep context window manageable
        snippet = content[:800]
        if len(content) > 800:
            snippet += "..."
        lines.append(f"[MEMORY {i}] (importance: {importance:.1f}): {snippet}")
    return "\n".join(lines)
