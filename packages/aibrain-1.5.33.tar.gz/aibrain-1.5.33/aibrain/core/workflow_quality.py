"""
workflow_quality.py — Per-workflow quality evaluation functions.

Each workflow type has different quality criteria. This module defines
specialised evaluators that understand what "good output" means for each
workflow, then exposes a single entry point for the harness.

Usage:
    from aibrain.core.workflow_quality import evaluate_workflow
    score = evaluate_workflow("heartbeat", output)
"""

from __future__ import annotations

from typing import Any

# ──────────────────────────────────────────────────────────────
# Helper
# ──────────────────────────────────────────────────────────────

def _safe_str(output: Any) -> str:
    """Lowercase string representation, safe for None."""
    return str(output).lower() if output is not None else ""


def _is_dict(output: Any) -> bool:
    return isinstance(output, dict)


def _has_error(output: Any) -> bool:
    """Check for error signals in output.

    Uses structured dict key inspection only — NOT broad str-repr scanning.
    Broad scanning falsely flags substantive outputs that mention error handling
    (e.g. a security report discussing 'no errors found', a migration plan with
    'exception handling' section). Only traceback/exception patterns — which
    never appear in legitimate structured output — are still string-checked.

    This mirrors the fix already applied to _check_output_not_error in harness.py
    (Round 1 honest-rubric audit, Apr 11).
    """
    if output is None:
        return False

    # Structured dict: check explicit error keys only
    if isinstance(output, dict):
        if output.get("error"):
            return True
        if output.get("success") is False:
            return True
        if output.get("status") in ("failed", "error"):
            return True
        # SuperWorker shape
        sw_result = output.get("result")
        if sw_result is not None:
            if getattr(sw_result, "parse_status", None) == "failed":
                return True
            if getattr(sw_result, "success", True) is False:
                return True
        return False

    # For non-dict outputs: only flag hard Python exception signals —
    # these never appear in legitimate output and are reliable.
    s = _safe_str(output)
    return any(sig in s for sig in ["traceback (most recent call last)", "exception:", "attributeerror:", "typeerror:", "valueerror:", "runtimeerror:"])


# ──────────────────────────────────────────────────────────────
# Per-Workflow Evaluators
# ──────────────────────────────────────────────────────────────

def evaluate_correction_learner(output: Any) -> float:
    """
    Good if: corrections extracted > 0, no duplicates, importance > 0.5.
    """
    if output is None or _has_error(output):
        return 0.1

    score = 0.3  # baseline: it ran

    if _is_dict(output):
        corrections = output.get("corrections", output.get("extracted", []))
        if isinstance(corrections, (list, tuple)):
            count = len(corrections)
            if count > 0:
                score += 0.3  # extracted something

                # Check for duplicates
                texts = [str(c) for c in corrections]
                unique = len(set(texts))
                if unique == count:
                    score += 0.1  # no duplicates

                # Check importance scores
                high_importance = 0
                for c in corrections:
                    if isinstance(c, dict):
                        imp = c.get("importance", c.get("weight", 0))
                        if isinstance(imp, (int, float)) and imp > 0.5:
                            high_importance += 1
                if high_importance > 0:
                    score += 0.2  # meaningful corrections

                # Bonus for volume
                if count >= 3:
                    score += 0.1
            else:
                score += 0.1  # ran but nothing found (might be correct)

        # If output has a success flag, give partial credit
        if output.get("success"):
            score = max(score, 0.5)
    elif isinstance(output, (list, tuple)) and len(output) > 0:
        score = 0.6  # list of corrections directly

    return min(1.0, score)


def evaluate_evolution(output: Any) -> float:
    """
    Good if: patterns identified, metrics recorded, outcomes logged.
    """
    if output is None or _has_error(output):
        return 0.1

    score = 0.3  # baseline

    if _is_dict(output):
        # Patterns identified
        patterns = output.get("patterns", output.get("insights", []))
        if patterns and len(patterns) > 0:
            score += 0.25

        # Metrics recorded
        metrics = output.get("metrics", output.get("scores", {}))
        if metrics:
            score += 0.2

        # Outcomes logged
        outcomes = output.get("outcomes", output.get("logged", output.get("entries", 0)))
        if outcomes:
            if isinstance(outcomes, (int, float)) and outcomes > 0:
                score += 0.15
            elif isinstance(outcomes, (list, dict)) and len(outcomes) > 0:
                score += 0.15

        if output.get("success") or output.get("status") in ("ok", "done"):
            score = max(score, 0.6)

    return min(1.0, score)


def evaluate_heartbeat(output: Any) -> float:
    """
    Good if: all services responding, no timeouts, DB accessible.
    """
    if output is None:
        return 0.0
    if _has_error(output):
        return 0.2

    score = 0.4  # baseline: it returned something

    s = _safe_str(output)

    if _is_dict(output):
        # Check for service statuses
        services = output.get("services", output.get("checks", {}))
        if isinstance(services, dict) and services:
            total = len(services)
            healthy = sum(
                1 for v in services.values()
                if (isinstance(v, dict) and v.get("status") in ("ok", "healthy", "up"))
                or (isinstance(v, str) and v in ("ok", "healthy", "up"))
                or v is True
            )
            if total > 0:
                ratio = healthy / total
                score = 0.3 + 0.5 * ratio  # 0.3 base + up to 0.5 for services
                if ratio == 1.0:
                    score += 0.2  # all healthy bonus

        # DB accessible
        if output.get("db") in (True, "ok", "healthy", "accessible"):
            score = min(1.0, score + 0.1)
        elif output.get("db_accessible") is True:
            score = min(1.0, score + 0.1)

        # Timeout detection
        if "timeout" in s:
            score = min(score, 0.4)

        # heartbeat.py returns {"health": "healthy"|"degraded"|"critical", ...}
        # while some callers use {"status": "ok"|"healthy", ...}
        if output.get("status") in ("ok", "healthy") or output.get("health") == "healthy":
            score = max(score, 0.8)
        elif output.get("health") == "degraded":
            score = max(score, 0.5)

    elif isinstance(output, str):
        if "healthy" in s or "all ok" in s or "all services" in s:
            score = 0.9
        elif "timeout" in s:
            score = 0.3

    return min(1.0, score)


def evaluate_memory_consolidation(output: Any) -> float:
    """
    Good if: clusters found, merges performed, no data loss.
    """
    if output is None or _has_error(output):
        return 0.1

    score = 0.3

    if _is_dict(output):
        # Clusters found
        clusters = output.get("clusters", output.get("groups", 0))
        if isinstance(clusters, (int, float)) and clusters > 0:
            score += 0.2
        elif isinstance(clusters, (list, tuple)) and len(clusters) > 0:
            score += 0.2

        # Merges performed
        merges = output.get("merges", output.get("merged", output.get("consolidated", 0)))
        if isinstance(merges, (int, float)) and merges > 0:
            score += 0.2
        elif isinstance(merges, (list, tuple)) and len(merges) > 0:
            score += 0.2

        # No data loss
        if output.get("data_loss") is False or output.get("data_loss") == 0:
            score += 0.2
        elif "data_loss" not in output:
            score += 0.1  # assume ok if not flagged

        if output.get("success"):
            score = max(score, 0.6)

    return min(1.0, score)


def evaluate_social_poster(output: Any) -> float:
    """
    Good if: post actually published, no error, within schedule window.
    """
    if output is None or _has_error(output):
        return 0.1

    score = 0.3

    if _is_dict(output):
        # Post published
        published = output.get("published", output.get("posted", output.get("sent", False)))
        if published:
            score += 0.4

        # Has post ID / URL (proof of publish)
        if output.get("post_id") or output.get("url") or output.get("tweet_id"):
            score += 0.15

        # Within schedule
        if output.get("on_schedule") is True or output.get("within_window") is True:
            score += 0.15
        elif output.get("on_schedule") is not False:
            score += 0.05  # not flagged as late

        if output.get("success"):
            score = max(score, 0.7)

    elif isinstance(output, str):
        if "published" in _safe_str(output) or "posted" in _safe_str(output):
            score = 0.7

    return min(1.0, score)


def evaluate_interview_prep(output: Any) -> float:
    """
    Good if: output contains company name, role requirements mapped, questions prepared.
    """
    if output is None or _has_error(output):
        return 0.1

    score = 0.3
    s = _safe_str(output)

    if _is_dict(output):
        # Company name present
        if output.get("company") or output.get("company_name"):
            score += 0.2

        # Role requirements mapped
        reqs = output.get("requirements", output.get("role_requirements", []))
        if reqs and len(reqs) > 0:
            score += 0.2

        # Questions prepared
        questions = output.get("questions", output.get("interview_questions", []))
        if isinstance(questions, (list, tuple)) and len(questions) > 0:
            score += 0.2
            if len(questions) >= 5:
                score += 0.1  # thorough prep

        if output.get("success"):
            score = max(score, 0.6)

    elif isinstance(output, str):
        # Check for key content in string output
        has_company = any(w in s for w in ["company:", "employer:", "organization:"])
        has_questions = "question" in s
        has_requirements = "requirement" in s or "qualification" in s
        score = 0.3 + 0.2 * has_company + 0.2 * has_questions + 0.2 * has_requirements

    return min(1.0, score)


def evaluate_security_scan(output: Any) -> float:
    """
    Good if: findings count > 0 (for known-vulnerable targets), no crashes, report generated.
    """
    if output is None:
        return 0.0
    if _has_error(output) and "crash" in _safe_str(output):
        return 0.1

    score = 0.3

    if _is_dict(output):
        # Findings
        findings = output.get("findings", output.get("vulnerabilities", []))
        if isinstance(findings, (list, tuple)):
            if len(findings) > 0:
                score += 0.3
                # Severity distribution bonus
                if any(isinstance(f, dict) and f.get("severity") in ("high", "critical")
                       for f in findings):
                    score += 0.1
        elif isinstance(findings, (int, float)) and findings > 0:
            score += 0.3

        # No crashes
        if not _has_error(output):
            score += 0.1

        # Report generated
        if output.get("report") or output.get("report_path") or output.get("report_generated"):
            score += 0.2

        if output.get("success"):
            score = max(score, 0.6)

    return min(1.0, score)


def evaluate_generic(output: Any):
    """
    Fallback evaluator for unknown workflow types.

    Returns a float 0.0-1.0 ONLY when there's a real signal to score against.
    Returns None when the output shape gives no measurable signal — the
    caller must treat None as "could not measure" and store NULL rather
    than fake a baseline. The previous version returned a hardcoded 0.5
    baseline for any non-empty output, which made 79% of execution_log rows
    have quality_score=0.5 exactly (Round 1 honest-rubric audit). We refuse
    to stamp a fake score now.
    """
    if output is None:
        return 0.0
    if _has_error(output):
        return 0.2

    if _is_dict(output):
        if output.get("success") or output.get("status") in ("ok", "done", "healthy"):
            return 0.8
        if output.get("error") or output.get("status") == "failed":
            return 0.2
        # Dict with no explicit success/error signal — cannot judge.
        return None
    if isinstance(output, (list, tuple)):
        return 0.7 if len(output) > 0 else 0.3
    if isinstance(output, bool):
        return 0.8 if output else 0.3
    if isinstance(output, str):
        # A string by itself with no error signal carries no quality information.
        # Long string is not the same as good string. Refuse to stamp.
        return None

    # Unknown type — cannot judge.
    return None


# ──────────────────────────────────────────────────────────────
# Registry
# ──────────────────────────────────────────────────────────────

QUALITY_FUNCTIONS: dict[str, callable] = {
    "correction_learner": evaluate_correction_learner,
    "learning_extractor": evaluate_correction_learner,  # same shape
    "evolution": evaluate_evolution,
    "evolution_cycle": evaluate_evolution,
    "evolution_auto_loop": evaluate_evolution,
    "evolution_experiment": evaluate_evolution,
    "heartbeat": evaluate_heartbeat,
    "service_monitor": evaluate_heartbeat,
    "uptime_monitor": evaluate_heartbeat,
    "memory_consolidation": evaluate_memory_consolidation,
    "social_poster": evaluate_social_poster,
    "social_scheduler": evaluate_social_poster,
    "instagram_poster": evaluate_social_poster,
    "interview_prep": evaluate_interview_prep,
    "security_scan": evaluate_security_scan,
    "security_advisories": evaluate_security_scan,
}


def evaluate_workflow(workflow_name: str, output: Any):
    """
    Look up the workflow-specific quality function and return a 0.0-1.0 score
    OR None when no measurement is possible. Falls back to evaluate_generic
    for unknown workflow types.

    The caller (harness.evaluate_task_quality) must handle None — see that
    function for the propagation rules.
    """
    # Strip "workflow." prefix so "workflow.heartbeat" hits "heartbeat" in the registry.
    # The harness uses task names like "workflow.heartbeat" but the registry keys are bare names.
    lookup_name = workflow_name
    if lookup_name.startswith("workflow."):
        lookup_name = lookup_name[len("workflow."):]
    fn = QUALITY_FUNCTIONS.get(lookup_name, evaluate_generic)
    return fn(output)
