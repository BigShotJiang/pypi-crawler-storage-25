"""
rbac.py — Role-Based Access Control for AIBrain multi-user support.

Roles:
  - owner: full access, can manage users and settings
  - admin: manage agents, tasks, workflows, but not billing/users
  - member: use dashboard, run workflows, view data
  - viewer: read-only access to dashboard

Usage:
    from aibrain.core.rbac import create_user, check_permission, list_users, invite_user

    create_user("matt@example.com", role="owner")
    if check_permission(user_id, "manage_agents"):
        hire_agent(...)
"""

import hashlib
import secrets
import sqlite3
import os
from datetime import datetime, timezone
from pathlib import Path


def _get_db():
    db_path = os.environ.get("AIBRAIN_DB", str(Path(__file__).parent.parent.parent / "aibrain.db"))
    db = sqlite3.connect(db_path)
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            email TEXT UNIQUE NOT NULL,
            name TEXT DEFAULT '',
            role TEXT NOT NULL DEFAULT 'member',
            api_key_hash TEXT,
            status TEXT DEFAULT 'active',
            invited_by TEXT,
            joined_at TEXT,
            last_seen_at TEXT,
            created_at TEXT NOT NULL
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS invites (
            id TEXT PRIMARY KEY,
            email TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'member',
            token TEXT UNIQUE NOT NULL,
            invited_by TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at TEXT NOT NULL,
            accepted_at TEXT
        )
    """)
    db.commit()
    return db


# Permission matrix
PERMISSIONS = {
    "owner": {
        "manage_users", "manage_billing", "manage_settings",
        "manage_agents", "manage_tasks", "manage_workflows",
        "manage_secrets", "manage_goals", "manage_companies",
        "run_heartbeats", "run_workflows", "approve_tasks",
        "view_dashboard", "view_data", "export_brain", "import_brain",
    },
    "admin": {
        "manage_agents", "manage_tasks", "manage_workflows",
        "manage_secrets", "manage_goals", "manage_companies",
        "run_heartbeats", "run_workflows", "approve_tasks",
        "view_dashboard", "view_data", "export_brain", "import_brain",
    },
    "member": {
        "manage_tasks", "manage_goals",
        "run_heartbeats", "run_workflows",
        "view_dashboard", "view_data",
    },
    "viewer": {
        "view_dashboard", "view_data",
    },
}


def create_user(email: str, name: str = "", role: str = "member", invited_by: str = None) -> dict:
    """Create a new user."""
    db = _get_db()
    user_id = secrets.token_urlsafe(8)
    api_key = secrets.token_urlsafe(32)
    api_key_hash = hashlib.sha256(api_key.encode()).hexdigest()
    now = datetime.now(timezone.utc).isoformat()

    db.execute(
        "INSERT INTO users (id, email, name, role, api_key_hash, invited_by, joined_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (user_id, email, name, role, api_key_hash, invited_by, now, now),
    )
    db.commit()
    db.close()
    return {"id": user_id, "email": email, "role": role, "api_key": api_key}


def list_users() -> list[dict]:
    """List all users (without API keys)."""
    db = _get_db()
    rows = db.execute("SELECT id, email, name, role, status, joined_at, last_seen_at FROM users ORDER BY created_at").fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_user(user_id: str) -> dict | None:
    db = _get_db()
    row = db.execute("SELECT id, email, name, role, status, joined_at, last_seen_at FROM users WHERE id=?", (user_id,)).fetchone()
    db.close()
    return dict(row) if row else None


def update_role(user_id: str, new_role: str) -> bool:
    """Change a user's role. Only owner can do this."""
    if new_role not in PERMISSIONS:
        return False
    db = _get_db()
    db.execute("UPDATE users SET role=? WHERE id=?", (new_role, user_id))
    db.commit()
    db.close()
    return True


def check_permission(user_id: str, permission: str) -> bool:
    """Check if a user has a specific permission."""
    db = _get_db()
    row = db.execute("SELECT role FROM users WHERE id=? AND status='active'", (user_id,)).fetchone()
    db.close()
    if not row:
        return False
    return permission in PERMISSIONS.get(row["role"], set())


def get_permissions(role: str) -> set[str]:
    """Get all permissions for a role."""
    return PERMISSIONS.get(role, set())


def invite_user(email: str, role: str = "member", invited_by: str = "") -> dict:
    """Create an invite token for a new user."""
    db = _get_db()
    invite_id = secrets.token_urlsafe(8)
    token = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc).isoformat()

    db.execute(
        "INSERT INTO invites (id, email, role, token, invited_by, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (invite_id, email, role, token, invited_by, now),
    )
    db.commit()
    db.close()
    return {"id": invite_id, "email": email, "role": role, "invite_token": token}


def accept_invite(token: str, name: str = "") -> dict | None:
    """Accept an invite and create the user."""
    db = _get_db()
    invite = db.execute("SELECT * FROM invites WHERE token=? AND status='pending'", (token,)).fetchone()
    if not invite:
        db.close()
        return None

    db.execute("UPDATE invites SET status='accepted', accepted_at=? WHERE id=?",
               (datetime.now(timezone.utc).isoformat(), invite["id"]))
    db.commit()
    db.close()

    return create_user(invite["email"], name=name, role=invite["role"], invited_by=invite["invited_by"])


def revoke_user(user_id: str) -> bool:
    """Deactivate a user."""
    db = _get_db()
    db.execute("UPDATE users SET status='revoked' WHERE id=?", (user_id,))
    db.commit()
    db.close()
    return True


def authenticate_by_key(api_key: str) -> dict | None:
    """Authenticate a user by API key."""
    key_hash = hashlib.sha256(api_key.encode()).hexdigest()
    db = _get_db()
    row = db.execute(
        "SELECT id, email, name, role, status FROM users WHERE api_key_hash=? AND status='active'",
        (key_hash,),
    ).fetchone()
    if row:
        db.execute("UPDATE users SET last_seen_at=? WHERE id=?",
                   (datetime.now(timezone.utc).isoformat(), row["id"]))
        db.commit()
    db.close()
    return dict(row) if row else None
