"""Tests for aibrain.core.reactive_chains — 3 reactive event bus chains."""

import os
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

# Point AIBRAIN_ROOT to a temp dir so tests don't touch the real DB
_tmpdir = tempfile.mkdtemp()
os.environ["AIBRAIN_ROOT"] = _tmpdir

from aibrain.core.event_bus import emit, clear_handlers, EventTypes
from aibrain.core.reactive_chains import (
    on_correction_received,
    on_quality_low,
    on_task_completed,
    register_reactive_chains,
    reset,
    get_agent_completions,
    get_correction_stats,
)


# ---------------------------------------------------------------------------
# Setup / teardown
# ---------------------------------------------------------------------------

def _make_db():
    """Create test DB with needed tables."""
    db_path = Path(_tmpdir) / "aibrain.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS event_bus_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            payload TEXT,
            created TEXT DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS idx_event_bus_type ON event_bus_log(event_type);

        CREATE TABLE IF NOT EXISTS company_issues (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL DEFAULT '',
            title TEXT NOT NULL DEFAULT '',
            assignee_agent_id TEXT,
            status TEXT DEFAULT 'todo',
            quality_score REAL,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            completed_at TEXT
        );

        CREATE TABLE IF NOT EXISTS evolution_outcomes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT, source_id TEXT, action TEXT,
            result TEXT, details TEXT, failure_reason TEXT,
            duration_seconds REAL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)
    conn.commit()
    conn.close()
    return db_path


@pytest.fixture(autouse=True)
def _clean_state():
    """Reset everything between tests."""
    clear_handlers()
    reset()
    db_path = _make_db()
    # Clean tables
    conn = sqlite3.connect(str(db_path))
    conn.execute("DELETE FROM event_bus_log")
    conn.execute("DELETE FROM company_issues")
    conn.execute("DELETE FROM evolution_outcomes")
    conn.commit()
    conn.close()
    yield
    clear_handlers()
    reset()


# ---------------------------------------------------------------------------
# 1. register_reactive_chains hooks into event bus
# ---------------------------------------------------------------------------

def test_register_wires_handlers():
    """After registration, emitting events should call the handlers."""
    register_reactive_chains()

    # Emit a correction — should update in-memory counters
    emit(EventTypes.CORRECTION_RECEIVED, {
        "id": 1, "name": "test_correction", "type": "correction",
        "content_preview": "Fix git push error",
    })

    stats = get_correction_stats()
    assert "git" in stats
    assert stats["git"]["corrections"] >= 1


# ---------------------------------------------------------------------------
# 2. Double registration is idempotent
# ---------------------------------------------------------------------------

def test_register_idempotent():
    """Calling register twice should not double-fire handlers."""
    register_reactive_chains()
    register_reactive_chains()

    emit(EventTypes.CORRECTION_RECEIVED, {
        "id": 2, "name": "test", "type": "correction",
        "content_preview": "Fix docker deploy",
    })

    stats = get_correction_stats()
    # Should be 1, not 2
    assert stats["infrastructure"]["corrections"] == 1


# ---------------------------------------------------------------------------
# 3. CORRECTION_RECEIVED tracks domain counts
# ---------------------------------------------------------------------------

def test_correction_domain_tracking():
    """Corrections are classified by domain and counted."""
    on_correction_received({
        "content_preview": "vuln scan failed for target",
    })
    on_correction_received({
        "content_preview": "git push rejected by remote",
    })
    on_correction_received({
        "content_preview": "vuln exploit chain broken",
    })

    stats = get_correction_stats()
    assert stats["security"]["corrections"] == 2
    assert stats["git"]["corrections"] == 1


# ---------------------------------------------------------------------------
# 4. CORRECTION_RECEIVED warns on high rate
# ---------------------------------------------------------------------------

def test_correction_high_rate_warning(caplog):
    """When correction rate exceeds threshold, a warning is logged."""
    import logging
    caplog.set_level(logging.WARNING, logger="aibrain.reactive_chains")

    # Feed 5 corrections for the same domain (100% rate, well above 25%)
    for i in range(5):
        on_correction_received({
            "content_preview": f"Fix aibrain memory issue #{i}",
        })

    assert any("exceeds" in r.message and "aibrain" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# 5. QUALITY_LOW logs failure details
# ---------------------------------------------------------------------------

def test_quality_low_logs_details(caplog):
    """Quality failures are logged with task name and score."""
    import logging
    caplog.set_level(logging.WARNING, logger="aibrain.reactive_chains")

    on_quality_low({
        "task_name": "test_workflow",
        "eval_score": 0.2,
        "self_score": 0.8,
        "detail": "output was empty",
    })

    assert any("QUALITY_LOW" in r.message and "test_workflow" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# 6. QUALITY_LOW sends Telegram for critical workflows
# ---------------------------------------------------------------------------

def test_quality_low_telegram_for_critical():
    """Critical workflows trigger a Telegram alert."""
    with patch("aibrain.core.reactive_chains._send_telegram") as mock_tg:
        mock_tg.return_value = True

        on_quality_low({
            "task_name": "heartbeat",
            "eval_score": 0.1,
            "detail": "heartbeat failed completely",
        })

        mock_tg.assert_called_once()
        call_msg = mock_tg.call_args[0][0]
        assert "QUALITY ALERT" in call_msg
        assert "heartbeat" in call_msg


# ---------------------------------------------------------------------------
# 7. QUALITY_LOW does NOT send Telegram for non-critical workflows
# ---------------------------------------------------------------------------

def test_quality_low_no_telegram_for_noncritical():
    """Non-critical workflows do not trigger Telegram alerts."""
    with patch("aibrain.core.reactive_chains._send_telegram") as mock_tg:
        on_quality_low({
            "task_name": "some_random_task",
            "eval_score": 0.3,
            "detail": "mediocre output",
        })

        mock_tg.assert_not_called()


# ---------------------------------------------------------------------------
# 8. TASK_COMPLETED updates agent completion count
# ---------------------------------------------------------------------------

def test_task_completed_agent_tracking():
    """Completing a task increments the agent's completion counter."""
    db_path = Path(_tmpdir) / "aibrain.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute(
        "INSERT INTO company_issues (id, company_id, title, assignee_agent_id, status) "
        "VALUES (?, ?, ?, ?, ?)",
        ("task-001", "co1", "Test task", "agent-A", "done"),
    )
    conn.commit()
    conn.close()

    on_task_completed({
        "task_id": "task-001",
        "eval_score": 0.85,
        "self_score": 0.9,
        "title": "Test task",
    })

    completions = get_agent_completions()
    assert completions.get("agent-A") == 1


# ---------------------------------------------------------------------------
# 9. TASK_COMPLETED records to evolution_outcomes
# ---------------------------------------------------------------------------

def test_task_completed_evolution_outcome():
    """Task completion writes a record to evolution_outcomes."""
    db_path = Path(_tmpdir) / "aibrain.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute(
        "INSERT INTO company_issues (id, company_id, title, assignee_agent_id, status) "
        "VALUES (?, ?, ?, ?, ?)",
        ("task-002", "co1", "Another task", "agent-B", "done"),
    )
    conn.commit()
    conn.close()

    on_task_completed({
        "task_id": "task-002",
        "eval_score": 0.3,
        "title": "Another task",
    })

    conn = sqlite3.connect(str(db_path))
    row = conn.execute(
        "SELECT * FROM evolution_outcomes WHERE source='reactive_chain' AND source_id='task-002'"
    ).fetchone()
    conn.close()

    assert row is not None
    assert row[3] == "task_completed"  # action column
    assert row[4] == "low_quality"     # result column (eval_score < 0.5)


# ---------------------------------------------------------------------------
# 10. Handlers never raise — even with bad payloads
# ---------------------------------------------------------------------------

def test_handlers_never_raise():
    """All handlers must tolerate None, empty, and garbage payloads."""
    # None of these should raise
    on_correction_received({})
    on_correction_received({"content_preview": None})
    on_quality_low({})
    on_quality_low({"task_name": None, "eval_score": None})
    on_task_completed({})
    on_task_completed({"task_id": "nonexistent-task"})


# ---------------------------------------------------------------------------
# 11. reset() clears all state
# ---------------------------------------------------------------------------

def test_reset_clears_state():
    """reset() should clear counters and unregister handlers."""
    on_correction_received({"content_preview": "git push fix"})
    assert get_correction_stats()  # non-empty

    register_reactive_chains()
    reset()

    assert get_correction_stats() == {}
    assert get_agent_completions() == {}
