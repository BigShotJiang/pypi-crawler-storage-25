"""Tests for aibrain.core.offensive_safety — safety gate for offensive learning."""

import os
import sqlite3
from pathlib import Path

import pytest

from aibrain.core.offensive_safety import (
    is_offensive_content,
    is_offensive_source,
    is_offensive_memory,
    tag_offensive_memory,
    auto_tag_offensive,
    filter_for_context,
    filter_for_export,
    filter_for_summary,
    OFFENSIVE_TAG,
)


@pytest.fixture(autouse=True)
def _setup_db(tmp_path):
    """Set AIBRAIN_ROOT to a fresh temp dir with a memories table for each test."""
    db_path = tmp_path / "aibrain.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            content TEXT,
            tags TEXT DEFAULT '',
            active INTEGER DEFAULT 1,
            status TEXT DEFAULT 'active'
        )
    """)
    conn.commit()
    conn.close()

    old = os.environ.get("AIBRAIN_ROOT")
    os.environ["AIBRAIN_ROOT"] = str(tmp_path)
    yield tmp_path
    if old is not None:
        os.environ["AIBRAIN_ROOT"] = old
    else:
        os.environ.pop("AIBRAIN_ROOT", None)


def _db_path():
    return Path(os.environ["AIBRAIN_ROOT"]) / "aibrain.db"


def _insert_memory(content: str, tags: str = "", source: str = "") -> int:
    """Helper to insert a test memory and return its ID."""
    conn = sqlite3.connect(str(_db_path()))
    cur = conn.execute(
        "INSERT INTO memories (name, content, tags) VALUES (?, ?, ?)",
        (f"test_{content[:20]}", content, tags),
    )
    conn.commit()
    mem_id = cur.lastrowid
    conn.close()
    return mem_id


def _get_tags(memory_id: int) -> str:
    """Helper to read tags for a memory."""
    conn = sqlite3.connect(str(_db_path()))
    row = conn.execute("SELECT tags FROM memories WHERE id = ?", (memory_id,)).fetchone()
    conn.close()
    return row[0] if row else ""


# ---------------------------------------------------------------------------
# 1. Exploit content detected as offensive
# ---------------------------------------------------------------------------

def test_exploit_content_detected():
    assert is_offensive_content("Use metasploit module for reverse shell")
    assert is_offensive_content("CVE-2024-1234 allows remote code execution")
    assert is_offensive_content("Extract NTLM hashes via mimikatz")


# ---------------------------------------------------------------------------
# 2. Clean content not flagged
# ---------------------------------------------------------------------------

def test_clean_content_not_flagged():
    assert not is_offensive_content("The user prefers dark mode in the dashboard")
    assert not is_offensive_content("Deploy to production on Friday")
    assert not is_offensive_content("Meeting notes from standup")


# ---------------------------------------------------------------------------
# 3. Offensive sources identified
# ---------------------------------------------------------------------------

def test_offensive_sources_detected():
    assert is_offensive_source("wintermute")
    assert is_offensive_source("Wintermute")  # case-insensitive
    assert is_offensive_source("rogue")
    assert not is_offensive_source("dashboard")
    assert not is_offensive_source("neuro")


# ---------------------------------------------------------------------------
# 4. Memory with offensive tag detected
# ---------------------------------------------------------------------------

def test_tagged_memory_detected():
    mem = {"content": "normal text", "tags": "project,source:offensive"}
    assert is_offensive_memory(mem)


# ---------------------------------------------------------------------------
# 5. Memory with offensive content detected (no tag)
# ---------------------------------------------------------------------------

def test_content_based_detection():
    mem = {"content": "SQL injection in login form allows bypass", "tags": ""}
    assert is_offensive_memory(mem)


# ---------------------------------------------------------------------------
# 6. Security context allows offensive memories
# ---------------------------------------------------------------------------

def test_security_context_allows_offensive():
    offensive_mem = {"content": "exploit payload for CVE-2024-1234", "tags": "source:offensive"}
    clean_mem = {"content": "dashboard color scheme", "tags": ""}
    memories = [offensive_mem, clean_mem]

    result = filter_for_context(memories, query_context="Find vulnerability details")
    assert len(result) == 2  # both returned in security context


# ---------------------------------------------------------------------------
# 7. Non-security context filters out offensive memories
# ---------------------------------------------------------------------------

def test_non_security_context_filters_offensive():
    offensive_mem = {"content": "reverse shell payload connects to C2", "tags": "source:offensive"}
    clean_mem = {"content": "user prefers email notifications", "tags": ""}
    memories = [offensive_mem, clean_mem]

    result = filter_for_context(memories, query_context="What are the user's preferences?")
    assert len(result) == 1
    assert result[0]["content"] == "user prefers email notifications"


# ---------------------------------------------------------------------------
# 8. Export NEVER includes offensive memories
# ---------------------------------------------------------------------------

def test_export_excludes_offensive():
    memories = [
        {"content": "user likes Python", "tags": ""},
        {"content": "metasploit module for privesc", "tags": "source:offensive"},
        {"content": "deploy schedule is weekly", "tags": ""},
        {"content": "buffer overflow in auth service", "tags": ""},
    ]
    exported = filter_for_export(memories)
    assert len(exported) == 2  # only clean ones
    assert all("metasploit" not in m["content"] and "buffer overflow" not in m["content"]
               for m in exported)


# ---------------------------------------------------------------------------
# 9. Tag offensive memory in DB
# ---------------------------------------------------------------------------

def test_tag_offensive_memory_db():
    mem_id = _insert_memory("Some scan results from testing")
    assert OFFENSIVE_TAG not in _get_tags(mem_id)

    result = tag_offensive_memory(mem_id, origin="wintermute")
    assert result is True
    assert OFFENSIVE_TAG in _get_tags(mem_id)
    assert "origin:wintermute" in _get_tags(mem_id)


# ---------------------------------------------------------------------------
# 10. Auto-tag detects and tags offensive content
# ---------------------------------------------------------------------------

def test_auto_tag_offensive():
    mem_id = _insert_memory("Extracted credential dump via mimikatz")
    result = auto_tag_offensive(mem_id, "Extracted credential dump via mimikatz", source="wintermute")
    assert result is True
    assert OFFENSIVE_TAG in _get_tags(mem_id)


# ---------------------------------------------------------------------------
# 11. Auto-tag skips clean content
# ---------------------------------------------------------------------------

def test_auto_tag_skips_clean():
    mem_id = _insert_memory("Meeting notes from product review")
    result = auto_tag_offensive(mem_id, "Meeting notes from product review")
    assert result is False
    assert OFFENSIVE_TAG not in _get_tags(mem_id)


# ---------------------------------------------------------------------------
# 12. Summary filter includes offensive for security domain
# ---------------------------------------------------------------------------

def test_summary_security_domain_includes_offensive():
    memories = [
        {"content": "exploit chain for target A", "tags": "source:offensive"},
        {"content": "dashboard metrics", "tags": ""},
    ]
    result = filter_for_summary(memories, domain="security")
    assert len(result) == 2


# ---------------------------------------------------------------------------
# 13. Summary filter excludes offensive for non-security domain
# ---------------------------------------------------------------------------

def test_summary_non_security_excludes_offensive():
    memories = [
        {"content": "reverse shell payload", "tags": "source:offensive"},
        {"content": "product roadmap item", "tags": ""},
    ]
    result = filter_for_summary(memories, domain="marketing")
    assert len(result) == 1
    assert result[0]["content"] == "product roadmap item"


# ---------------------------------------------------------------------------
# 14. Empty query context filters offensive (safe default)
# ---------------------------------------------------------------------------

def test_empty_context_filters_offensive():
    memories = [
        {"content": "shellcode for x86", "tags": "source:offensive"},
        {"content": "user email setting", "tags": ""},
    ]
    result = filter_for_context(memories, query_context="")
    assert len(result) == 1


# ---------------------------------------------------------------------------
# 15. Metadata-based tag detection works
# ---------------------------------------------------------------------------

def test_metadata_tag_detection():
    mem = {
        "content": "some normal text",
        "tags": "",
        "metadata": {"tags": "project,source:offensive"},
    }
    assert is_offensive_memory(mem)
