"""
Tests for aibrain/core/risk_classifier.py

Uses a temp SQLite DB — never touches the real aibrain.db.
"""

from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from aibrain.core.risk_classifier import (
    LOW_RISK_TYPES,
    MEDIUM_RISK_TYPES,
    HIGH_RISK_TYPES,
    classify_approval_risk,
    auto_process_approvals,
    classify_queue,
)


# ── Fixtures ─────────────────────────────────────────────────────

@pytest.fixture
def approval_db(tmp_path):
    """Create a temp DB with company_approvals table and seed data."""
    db_path = str(tmp_path / "test.db")
    conn = sqlite3.connect(db_path)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS company_approvals (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL,
            type TEXT NOT NULL,
            requested_by_agent_id TEXT,
            payload TEXT DEFAULT '{}',
            status TEXT DEFAULT 'pending',
            decision_note TEXT DEFAULT '',
            decided_at TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );
    """)

    # Seed: 1 LOW, 1 MEDIUM, 1 HIGH
    conn.execute(
        "INSERT INTO company_approvals (id, company_id, type, status, payload) "
        "VALUES (?, ?, ?, 'pending', ?)",
        ("low1", "COMP1", "notification", json.dumps({"msg": "CI passed"})),
    )
    conn.execute(
        "INSERT INTO company_approvals (id, company_id, type, status, payload) "
        "VALUES (?, ?, ?, 'pending', ?)",
        ("med1", "COMP1", "config_change", json.dumps({"key": "interval", "value": "30m"})),
    )
    conn.execute(
        "INSERT INTO company_approvals (id, company_id, type, status, payload) "
        "VALUES (?, ?, ?, 'pending', ?)",
        ("high1", "COMP1", "spend_money", json.dumps({"amount": 50, "reason": "API credits"})),
    )
    conn.commit()
    conn.close()
    return db_path


# ── Test: classify_approval_risk ─────────────────────────────────

def test_low_risk_by_type():
    """Known LOW types are classified correctly."""
    for t in LOW_RISK_TYPES:
        approval = {"type": t, "payload": "{}"}
        assert classify_approval_risk(approval) == "low", f"Expected low for type={t}"


def test_medium_risk_by_type():
    """Known MEDIUM types are classified correctly."""
    for t in MEDIUM_RISK_TYPES:
        approval = {"type": t, "payload": "{}"}
        assert classify_approval_risk(approval) == "medium", f"Expected medium for type={t}"


def test_high_risk_by_type():
    """Known HIGH types are classified correctly."""
    for t in HIGH_RISK_TYPES:
        approval = {"type": t, "payload": "{}"}
        assert classify_approval_risk(approval) == "high", f"Expected high for type={t}"


def test_keyword_fallback_high():
    """Unknown type with HIGH keywords in payload is classified high."""
    approval = {
        "type": "custom_action",
        "payload": json.dumps({"action": "delete production database"}),
    }
    assert classify_approval_risk(approval) == "high"


def test_keyword_fallback_low():
    """Unknown type with LOW keywords in payload is classified low."""
    approval = {
        "type": "custom_action",
        "payload": json.dumps({"action": "file move to archive dir"}),
    }
    assert classify_approval_risk(approval) == "low"


def test_unknown_defaults_to_medium():
    """Completely unknown type and content defaults to medium (conservative)."""
    approval = {"type": "xyz_unknown_thing", "payload": "{}"}
    assert classify_approval_risk(approval) == "medium"


# ── Test: auto_process_approvals ─────────────────────────────────

def test_auto_process_approves_low_only(approval_db):
    """auto_process_approvals approves LOW and holds MEDIUM/HIGH."""
    result = auto_process_approvals("COMP1", db_path=approval_db)

    assert result["processed"] == 3
    assert result["auto_approved"] == 1
    assert result["medium_held"] == 1
    assert result["high_held"] == 1

    # Verify DB state: low1 should be approved, others still pending
    conn = sqlite3.connect(approval_db)
    conn.row_factory = sqlite3.Row
    low = dict(conn.execute("SELECT * FROM company_approvals WHERE id='low1'").fetchone())
    med = dict(conn.execute("SELECT * FROM company_approvals WHERE id='med1'").fetchone())
    high = dict(conn.execute("SELECT * FROM company_approvals WHERE id='high1'").fetchone())
    conn.close()

    assert low["status"] == "approved"
    assert "risk_classifier" in low["decision_note"]
    assert med["status"] == "pending"
    assert high["status"] == "pending"


def test_dry_run_does_not_modify(approval_db):
    """dry_run=True classifies but does not change DB."""
    result = auto_process_approvals("COMP1", db_path=approval_db, dry_run=True)

    assert result["auto_approved"] == 1  # classified as would-approve
    assert result["processed"] == 3

    # DB unchanged
    conn = sqlite3.connect(approval_db)
    conn.row_factory = sqlite3.Row
    low = dict(conn.execute("SELECT * FROM company_approvals WHERE id='low1'").fetchone())
    conn.close()
    assert low["status"] == "pending"


def test_empty_queue_returns_zeros(approval_db):
    """No pending items for a different company returns all zeros."""
    result = auto_process_approvals("NONEXISTENT", db_path=approval_db)
    assert result["processed"] == 0
    assert result["auto_approved"] == 0


def test_classify_queue_returns_all(approval_db):
    """classify_queue returns classification for all pending items without modifying."""
    items = classify_queue("COMP1", db_path=approval_db)
    assert len(items) == 3
    risks = {item["id"]: item["risk"] for item in items}
    assert risks["low1"] == "low"
    assert risks["med1"] == "medium"
    assert risks["high1"] == "high"
