"""Tests for aibrain.core.correction_analysis — failure mode clustering."""

import os
import sqlite3
import tempfile

import pytest

# Point AIBRAIN_ROOT to a temp dir so tests don't touch the real DB
_tmpdir = tempfile.mkdtemp()
os.environ["AIBRAIN_ROOT"] = _tmpdir

# Create a minimal aibrain.db with memories table
_db_path = os.path.join(_tmpdir, "aibrain.db")
_setup_conn = sqlite3.connect(_db_path)
_setup_conn.executescript("""
    CREATE TABLE IF NOT EXISTS memories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT DEFAULT 'project',
        memory_class TEXT DEFAULT 'semantic',
        tags TEXT DEFAULT '',
        content TEXT DEFAULT '',
        importance REAL DEFAULT 0.5,
        access_count INTEGER DEFAULT 0,
        last_accessed TEXT,
        created TEXT DEFAULT (datetime('now')),
        updated TEXT DEFAULT (datetime('now')),
        active INTEGER DEFAULT 1,
        status TEXT DEFAULT 'active',
        storage_strength REAL DEFAULT 1.0
    );
""")
_setup_conn.commit()
_setup_conn.close()

from aibrain.core.correction_analysis import (
    _cluster_by_tags,
    _cluster_greedy,
    _cosine_sim,
    _extract_pattern,
    _load_corrections,
    cli_failures,
    top_failure_modes,
)


def _get_test_db():
    conn = sqlite3.connect(_db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


@pytest.fixture(autouse=True)
def _clean_state():
    """Clear memories between tests."""
    conn = _get_test_db()
    conn.execute("DELETE FROM memories")
    conn.commit()
    conn.close()
    yield


def _insert_correction(name, content="", tags="", importance=0.5, mem_type="correction"):
    conn = _get_test_db()
    conn.execute(
        "INSERT INTO memories (name, type, content, tags, importance, active, status) "
        "VALUES (?, ?, ?, ?, ?, 1, 'active')",
        (name, mem_type, content, tags, importance),
    )
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# 1. _cosine_sim computes correctly
# ---------------------------------------------------------------------------

def test_cosine_sim_identical():
    a = [1.0, 0.0, 0.0]
    assert abs(_cosine_sim(a, a) - 1.0) < 1e-6


def test_cosine_sim_orthogonal():
    a = [1.0, 0.0]
    b = [0.0, 1.0]
    assert abs(_cosine_sim(a, b)) < 1e-6


# ---------------------------------------------------------------------------
# 2. _cluster_greedy groups similar vectors
# ---------------------------------------------------------------------------

def test_cluster_greedy_basic():
    # Two clusters: [0,1] similar, [2] different
    embs = [
        [1.0, 0.0, 0.0],
        [0.95, 0.05, 0.0],
        [0.0, 0.0, 1.0],
    ]
    clusters = _cluster_greedy(embs, threshold=0.8)
    assert len(clusters) == 2
    # Largest cluster first
    assert len(clusters[0]) == 2
    assert len(clusters[1]) == 1


# ---------------------------------------------------------------------------
# 3. _load_corrections only loads correction/feedback types
# ---------------------------------------------------------------------------

def test_load_corrections_filters_types():
    _insert_correction("correction 1", mem_type="correction")
    _insert_correction("feedback 1", mem_type="feedback")
    _insert_correction("project mem", mem_type="project")

    db = _get_test_db()
    results = _load_corrections(db)
    db.close()
    assert len(results) == 2
    types = {r["type"] for r in results}
    assert types == {"correction", "feedback"}


# ---------------------------------------------------------------------------
# 4. top_failure_modes returns structured results
# ---------------------------------------------------------------------------

def test_top_failure_modes_structure():
    _insert_correction("Never force push", "force push destroys history", "git", 0.9)
    _insert_correction("Never skip hooks", "hooks are safety nets", "git", 0.8)
    _insert_correction("Verify before deploy", "check live site", "deploy", 0.7)

    db = _get_test_db()
    modes = top_failure_modes(n=5, db=db)
    db.close()

    assert len(modes) > 0
    mode = modes[0]
    assert "pattern" in mode
    assert "count" in mode
    assert "example_ids" in mode
    assert "representative" in mode
    assert "importance_avg" in mode
    assert isinstance(mode["count"], int)
    assert mode["count"] > 0


# ---------------------------------------------------------------------------
# 5. top_failure_modes returns empty for no corrections
# ---------------------------------------------------------------------------

def test_top_failure_modes_empty():
    db = _get_test_db()
    modes = top_failure_modes(n=5, db=db)
    db.close()
    assert modes == []


# ---------------------------------------------------------------------------
# 6. _extract_pattern picks highest importance as representative
# ---------------------------------------------------------------------------

def test_extract_pattern_representative():
    memories = [
        {"name": "Low importance", "importance": 0.3, "tags": "git"},
        {"name": "High importance", "importance": 0.9, "tags": "git"},
    ]
    pattern = _extract_pattern(memories)
    assert "High importance" in pattern


# ---------------------------------------------------------------------------
# 7. _cluster_by_tags groups by first tag
# ---------------------------------------------------------------------------

def test_cluster_by_tags():
    corrections = [
        {"tags": "git, safety"},
        {"tags": "git, hooks"},
        {"tags": "deploy, production"},
        {"tags": ""},
    ]
    clusters = _cluster_by_tags(corrections)
    # Should have 3 groups: git(2), deploy(1), untagged(1)
    sizes = sorted([len(c) for c in clusters], reverse=True)
    assert sizes[0] == 2  # git group


# ---------------------------------------------------------------------------
# 8. cli_failures runs without crash
# ---------------------------------------------------------------------------

def test_cli_failures_no_crash(capsys):
    _insert_correction("test correction", "content", "test")
    ret = cli_failures([])
    assert ret == 0
    out = capsys.readouterr().out
    assert "Failure Modes" in out
