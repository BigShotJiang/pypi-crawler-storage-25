"""Tests for aibrain.core.cross_domain_bus — cross-domain event bridge."""

import json
import os
import tempfile

import pytest

# Point AIBRAIN_ROOT to a temp dir so tests don't touch the real DB
_tmpdir = tempfile.mkdtemp()
os.environ["AIBRAIN_ROOT"] = _tmpdir

from aibrain.core.cross_domain_bus import (
    register_external_source,
    unregister_external_source,
    get_registered_sources,
    clear_sources,
    ingest_external_event,
    ingest_from_file_queue,
    get_event_mapping,
    set_event_mapping,
)
from aibrain.core.event_bus import clear_handlers


@pytest.fixture(autouse=True)
def _clean_state():
    """Reset all state between tests."""
    clear_sources()
    clear_handlers()
    yield
    clear_sources()
    clear_handlers()


# ---------------------------------------------------------------------------
# Test 1: register_external_source whitelisting
# ---------------------------------------------------------------------------

def test_register_and_list_sources():
    """Registering a source stores its allowed event types."""
    register_external_source("wintermute", [
        "WINTERMUTE_SCAN_COMPLETE",
        "WINTERMUTE_FINDING",
    ])
    sources = get_registered_sources()
    assert "wintermute" in sources
    assert "WINTERMUTE_SCAN_COMPLETE" in sources["wintermute"]
    assert "WINTERMUTE_FINDING" in sources["wintermute"]


def test_register_rejects_empty_name():
    """Empty product name raises ValueError."""
    with pytest.raises(ValueError, match="non-empty string"):
        register_external_source("", ["SOME_EVENT"])


def test_register_rejects_empty_events():
    """Empty event_types raises ValueError."""
    with pytest.raises(ValueError, match="non-empty list"):
        register_external_source("wintermute", [])


# ---------------------------------------------------------------------------
# Test 2: unregistered source is rejected
# ---------------------------------------------------------------------------

def test_ingest_rejects_unknown_source():
    """Events from unregistered sources are rejected."""
    result = ingest_external_event("unknown_product", "SOME_EVENT", {"data": 1})
    assert not result.ok
    assert "unknown external source" in result.reason


# ---------------------------------------------------------------------------
# Test 3: non-whitelisted event type is rejected
# ---------------------------------------------------------------------------

def test_ingest_rejects_non_whitelisted_event():
    """Events not in the source's whitelist are rejected."""
    register_external_source("wintermute", ["WINTERMUTE_SCAN_COMPLETE"])
    result = ingest_external_event("wintermute", "WINTERMUTE_SECRET_STEAL", {"data": 1})
    assert not result.ok
    assert "not whitelisted" in result.reason


# ---------------------------------------------------------------------------
# Test 4: successful ingestion maps and emits
# ---------------------------------------------------------------------------

def test_ingest_maps_and_emits():
    """A valid external event is mapped to internal type and emitted."""
    register_external_source("wintermute", ["WINTERMUTE_SCAN_COMPLETE"])

    received = []
    from aibrain.core.event_bus import on
    on("SCAN_FINDING_STORED", lambda p: received.append(p))

    result = ingest_external_event("wintermute", "WINTERMUTE_SCAN_COMPLETE", {
        "target": "example.com",
        "findings": 12,
    })

    assert result.ok
    assert result.internal_event_type == "SCAN_FINDING_STORED"
    assert len(received) == 1
    assert received[0]["target"] == "example.com"
    assert received[0]["_cross_domain"]["source_product"] == "wintermute"
    assert received[0]["_cross_domain"]["original_event_type"] == "WINTERMUTE_SCAN_COMPLETE"


# ---------------------------------------------------------------------------
# Test 5: validation blocks poisoned payloads
# ---------------------------------------------------------------------------

def test_ingest_blocks_shell_injection():
    """Payloads with shell injection in content fields are rejected by validation."""
    register_external_source("wintermute", ["WINTERMUTE_FINDING"])
    # WINTERMUTE_FINDING maps to SCAN_FINDING_STORED which is not in
    # _CONTENT_CHECK_EVENTS, so we need to use an event that triggers content checks.
    # Map a custom type to CORRECTION_RECEIVED which has content safety checks
    set_event_mapping("WINTERMUTE_FINDING_LEARN", "CORRECTION_RECEIVED")
    register_external_source("evil_product", ["WINTERMUTE_FINDING_LEARN"])

    result = ingest_external_event("evil_product", "WINTERMUTE_FINDING_LEARN", {
        "content_preview": "legit finding ; rm -rf / bad stuff",
    })
    assert not result.ok
    assert "validation failed" in result.reason


# ---------------------------------------------------------------------------
# Test 6: event type mapping works
# ---------------------------------------------------------------------------

def test_event_type_mapping():
    """get_event_mapping returns the mapped type or passthrough."""
    assert get_event_mapping("WINTERMUTE_SCAN_COMPLETE") == "SCAN_FINDING_STORED"
    assert get_event_mapping("UNKNOWN_TYPE") == "UNKNOWN_TYPE"  # passthrough

    set_event_mapping("CUSTOM_EVENT", "MEMORY_STORED")
    assert get_event_mapping("CUSTOM_EVENT") == "MEMORY_STORED"


# ---------------------------------------------------------------------------
# Test 7: file queue ingestion
# ---------------------------------------------------------------------------

def test_file_queue_ingestion(tmp_path):
    """File queue reads JSON files and dispatches events."""
    register_external_source("wintermute", ["WINTERMUTE_SCAN_COMPLETE"])

    # Write a valid event file
    event_file = tmp_path / "event_001.json"
    event_file.write_text(json.dumps({
        "product": "wintermute",
        "event_type": "WINTERMUTE_SCAN_COMPLETE",
        "payload": {"target": "10.0.0.1", "findings": 5},
    }))

    received = []
    from aibrain.core.event_bus import on
    on("SCAN_FINDING_STORED", lambda p: received.append(p))

    results = ingest_from_file_queue(queue_dir=tmp_path)
    assert len(results) == 1
    assert results[0].ok
    assert len(received) == 1
    assert received[0]["target"] == "10.0.0.1"

    # File should be moved to processed/
    assert not event_file.exists()
    assert (tmp_path / "processed" / "event_001.json").exists()


def test_file_queue_bad_json(tmp_path):
    """Malformed JSON files are moved to failed/."""
    bad_file = tmp_path / "bad_event.json"
    bad_file.write_text("not valid json {{{")

    results = ingest_from_file_queue(queue_dir=tmp_path)
    assert len(results) == 1
    assert not results[0].ok
    assert "bad JSON" in results[0].reason
    assert (tmp_path / "failed" / "bad_event.json").exists()


# ---------------------------------------------------------------------------
# Test 8: unregister source
# ---------------------------------------------------------------------------

def test_unregister_source():
    """Unregistering a source removes it from the registry."""
    register_external_source("wintermute", ["WINTERMUTE_SCAN_COMPLETE"])
    assert "wintermute" in get_registered_sources()

    removed = unregister_external_source("wintermute")
    assert removed
    assert "wintermute" not in get_registered_sources()

    # Unregistering again returns False
    assert not unregister_external_source("wintermute")


# ---------------------------------------------------------------------------
# Test 9: case-insensitive product names
# ---------------------------------------------------------------------------

def test_case_insensitive_product_name():
    """Product names are normalized to lowercase."""
    register_external_source("Wintermute", ["WINTERMUTE_SCAN_COMPLETE"])

    received = []
    from aibrain.core.event_bus import on
    on("SCAN_FINDING_STORED", lambda p: received.append(p))

    result = ingest_external_event("WINTERMUTE", "WINTERMUTE_SCAN_COMPLETE", {"x": 1})
    assert result.ok
    assert len(received) == 1
