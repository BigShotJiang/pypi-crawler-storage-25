"""Tests for aibrain.core.attention_telemetry — retrieval event logging."""

import json
import os
import sqlite3
import tempfile

import pytest

# Point AIBRAIN_ROOT to a temp dir so tests don't touch the real DB
_tmpdir = tempfile.mkdtemp()
os.environ["AIBRAIN_ROOT"] = _tmpdir

# Create a minimal aibrain.db in the temp dir so _get_db works
_db_path = os.path.join(_tmpdir, "aibrain.db")
_setup_conn = sqlite3.connect(_db_path)
_setup_conn.execute("PRAGMA journal_mode=WAL")
_setup_conn.close()

from aibrain.core.attention_telemetry import (
    _get_db,
    get_attention_stats,
    log_retrieval,
    reset_connection,
)


@pytest.fixture(autouse=True)
def _clean_state():
    """Reset connection and clear table between tests."""
    reset_connection()
    db = _get_db()
    db.execute("DELETE FROM attention_log")
    db.commit()
    yield
    reset_connection()


# ---------------------------------------------------------------------------
# 1. log_retrieval writes a row
# ---------------------------------------------------------------------------

def test_log_retrieval_basic():
    row_id = log_retrieval("test query", [{"id": 1}, {"id": 2}], {"search_type": "fts_only"})
    assert row_id is not None
    assert isinstance(row_id, int)

    db = _get_db()
    row = db.execute("SELECT * FROM attention_log WHERE id = ?", (row_id,)).fetchone()
    assert row["query"] == "test query"
    assert row["result_count"] == 2
    assert row["search_type"] == "fts_only"
    ids = json.loads(row["result_ids"])
    assert ids == [1, 2]


# ---------------------------------------------------------------------------
# 2. log_retrieval with empty query returns None
# ---------------------------------------------------------------------------

def test_log_retrieval_empty_query():
    row_id = log_retrieval("", [], {})
    assert row_id is None


# ---------------------------------------------------------------------------
# 3. log_retrieval with no context defaults to unknown
# ---------------------------------------------------------------------------

def test_log_retrieval_no_context():
    row_id = log_retrieval("something", [{"id": 5}])
    assert row_id is not None
    db = _get_db()
    row = db.execute("SELECT search_type FROM attention_log WHERE id = ?", (row_id,)).fetchone()
    assert row["search_type"] == "unknown"


# ---------------------------------------------------------------------------
# 4. get_attention_stats returns correct totals
# ---------------------------------------------------------------------------

def test_get_attention_stats_totals():
    log_retrieval("query a", [{"id": 1}], {"search_type": "fts_only"})
    log_retrieval("query b", [{"id": 2}, {"id": 3}], {"search_type": "rrf"})
    log_retrieval("query a", [{"id": 1}], {"search_type": "fts_only"})

    stats = get_attention_stats(days=7)
    assert stats["total_retrievals"] == 3
    assert stats["avg_result_count"] > 0


# ---------------------------------------------------------------------------
# 5. get_attention_stats top_queries groups correctly
# ---------------------------------------------------------------------------

def test_get_attention_stats_top_queries():
    log_retrieval("common query", [{"id": 1}], {"search_type": "fts_only"})
    log_retrieval("common query", [{"id": 1}], {"search_type": "fts_only"})
    log_retrieval("rare query", [{"id": 2}], {"search_type": "rrf"})

    stats = get_attention_stats(days=7)
    # common query should be first (appears 2x)
    assert len(stats["top_queries"]) >= 2
    assert stats["top_queries"][0][0] == "common query"
    assert stats["top_queries"][0][1] == 2


# ---------------------------------------------------------------------------
# 6. search_type_breakdown counts correctly
# ---------------------------------------------------------------------------

def test_search_type_breakdown():
    log_retrieval("q1", [{"id": 1}], {"search_type": "fts_only"})
    log_retrieval("q2", [{"id": 2}], {"search_type": "fts_only"})
    log_retrieval("q3", [{"id": 3}], {"search_type": "rrf"})

    stats = get_attention_stats(days=7)
    assert stats["search_type_breakdown"]["fts_only"] == 2
    assert stats["search_type_breakdown"]["rrf"] == 1


# ---------------------------------------------------------------------------
# 7. top_memories counts memory retrieval frequency
# ---------------------------------------------------------------------------

def test_top_memories():
    log_retrieval("q1", [{"id": 10}, {"id": 20}], {"search_type": "fts_only"})
    log_retrieval("q2", [{"id": 10}, {"id": 30}], {"search_type": "rrf"})
    log_retrieval("q3", [{"id": 10}], {"search_type": "fts_only"})

    stats = get_attention_stats(days=7)
    # Memory 10 was retrieved 3 times
    top = dict(stats["top_memories"])
    assert top[10] == 3
    assert top.get(20, 0) == 1


# ---------------------------------------------------------------------------
# 8. latency_ms is recorded
# ---------------------------------------------------------------------------

def test_latency_recorded():
    log_retrieval("q", [{"id": 1}], {"search_type": "fts_only", "latency_ms": 42.5})
    db = _get_db()
    row = db.execute("SELECT latency_ms FROM attention_log ORDER BY id DESC LIMIT 1").fetchone()
    assert abs(row["latency_ms"] - 42.5) < 0.01
