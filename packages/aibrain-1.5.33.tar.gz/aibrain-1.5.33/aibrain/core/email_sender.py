"""Resend transactional email sender for AIBrain.

Provides welcome emails, trial expiry alerts, and upgrade nudges via the
Resend REST API (https://resend.com). No SDK dependency — uses requests.

Configuration (env vars):
    RESEND_API_KEY   — required; if missing all sends return False with a warning
    RESEND_FROM_EMAIL — optional; defaults to 'noreply@myaibrain.org'

Fail-open contract: every public function catches all exceptions and returns
False rather than crashing the caller.
"""

import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)

_RESEND_API_URL = "https://api.resend.com/emails"


# ---------------------------------------------------------------------------
# Internal send primitive
# ---------------------------------------------------------------------------

def _send_via_resend(to: str, subject: str, html: str) -> bool:
    """POST a single email to the Resend API.

    Reads RESEND_API_KEY and RESEND_FROM_EMAIL from the environment.
    Returns True on HTTP 200/201, False on any error (including missing key).
    Never raises.
    """
    api_key = os.environ.get("RESEND_API_KEY", "").strip()
    if not api_key:
        logger.warning(
            "RESEND_API_KEY not set — email to %s not sent: %s", to, subject
        )
        return False

    from_email = os.environ.get(
        "RESEND_FROM_EMAIL", "noreply@myaibrain.org"
    ).strip()

    try:
        import requests  # noqa: PLC0415 (lazy import — requests is always present)

        resp = requests.post(
            _RESEND_API_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "from": from_email,
                "to": [to],
                "subject": subject,
                "html": html,
            },
            timeout=(10, 30),  # (connect_timeout, read_timeout) — prevent slow-server hangs
        )
        if resp.status_code in (200, 201):
            logger.info("Email sent via Resend: %s → %s", subject, to)
            return True
        else:
            logger.error(
                "Resend API error %s sending to %s: %s",
                resp.status_code,
                to,
                resp.text[:200],
            )
            return False
    except Exception as exc:  # noqa: BLE001
        logger.error("Resend send exception for %s: %s", to, exc)
        return False


# ---------------------------------------------------------------------------
# Public email functions
# ---------------------------------------------------------------------------

def send_welcome_email(to_email: str, name: Optional[str] = None) -> bool:
    """Send a welcome email on first install/register.

    Args:
        to_email: Recipient email address.
        name: Optional display name for personalisation.

    Returns:
        True if the email was accepted by Resend, False otherwise.
    """
    greeting = f"Hi {name}," if name else "Hi there,"

    html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px;color:#1a1a1a;">
  <h1 style="font-size:24px;margin-bottom:8px;">Your AIBrain is live.</h1>
  <p style="color:#555;">{greeting}</p>
  <p>Welcome to AIBrain — your portable AI memory layer. Here's what to do first:</p>
  <ol style="line-height:2;">
    <li><strong>Store your first memory</strong> — run <code>aibrain store "your first insight"</code></li>
    <li><strong>Run your first workflow</strong> — try <code>aibrain workflow run heartbeat</code></li>
    <li><strong>Join the community</strong> — <a href="https://myaibrain.org/community">myaibrain.org/community</a></li>
  </ol>
  <p>Questions? Reply to this email or visit <a href="https://myaibrain.org">myaibrain.org</a>.</p>
  <hr style="border:none;border-top:1px solid #eee;margin:24px 0;">
  <p style="font-size:12px;color:#888;">AIBrain · <a href="https://myaibrain.org">myaibrain.org</a></p>
</body>
</html>"""

    return _send_via_resend(
        to=to_email,
        subject="Your AIBrain is live — here's what to do first",
        html=html,
    )


def send_trial_expiry_alert(to_email: str, days_remaining: int) -> bool:
    """Send a warning email before a Pro trial expires.

    Args:
        to_email: Recipient email address.
        days_remaining: Number of days left on the trial.

    Returns:
        True if accepted by Resend, False otherwise.
    """
    day_word = "day" if days_remaining == 1 else "days"

    html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px;color:#1a1a1a;">
  <h1 style="font-size:24px;margin-bottom:8px;">Your Pro trial ends in {days_remaining} {day_word}.</h1>
  <p>When your trial expires you'll lose access to:</p>
  <ul style="line-height:2;">
    <li>Unlimited memory storage (capped at 500 on free)</li>
    <li>Scheduled workflows &amp; automation</li>
    <li>Priority model routing</li>
    <li>Brain sync across devices</li>
  </ul>
  <p>
    <a href="https://myaibrain.org/upgrade"
       style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;
              padding:12px 24px;border-radius:6px;font-weight:600;">
      Keep Pro — $9.95/mo
    </a>
  </p>
  <p style="color:#555;font-size:14px;">
    Cancel any time. No questions asked.
  </p>
  <hr style="border:none;border-top:1px solid #eee;margin:24px 0;">
  <p style="font-size:12px;color:#888;">AIBrain · <a href="https://myaibrain.org">myaibrain.org</a></p>
</body>
</html>"""

    return _send_via_resend(
        to=to_email,
        subject=f"Your AIBrain Pro trial ends in {days_remaining} {day_word}",
        html=html,
    )


def send_upgrade_nudge(
    to_email: str, usage_summary: Optional[str] = None
) -> bool:
    """Send a Day-7 upgrade nudge with an optional usage summary.

    Args:
        to_email: Recipient email address.
        usage_summary: Short human-readable summary of usage, e.g.
            "You've stored 42 memories". If omitted a generic message is used.

    Returns:
        True if accepted by Resend, False otherwise.
    """
    usage_line = usage_summary or "You've been using AIBrain for a week"

    html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px;color:#1a1a1a;">
  <h1 style="font-size:24px;margin-bottom:8px;">One week in — you're already ahead.</h1>
  <p>{usage_line}. Pro users unlock everything you need to go further:</p>
  <ul style="line-height:2;">
    <li>Unlimited memories (free tier caps at 500)</li>
    <li>Scheduled workflows that run while you sleep</li>
    <li>Brain sync — same memory on every machine</li>
    <li>Priority routing to the best models</li>
    <li>Brain Marketplace access</li>
  </ul>
  <p>
    <a href="https://myaibrain.org/upgrade"
       style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;
              padding:12px 24px;border-radius:6px;font-weight:600;">
      Upgrade to Pro — $9.95/mo
    </a>
  </p>
  <p style="color:#555;font-size:14px;">
    Cancel any time. Your memories stay yours regardless of tier.
  </p>
  <hr style="border:none;border-top:1px solid #eee;margin:24px 0;">
  <p style="font-size:12px;color:#888;">AIBrain · <a href="https://myaibrain.org">myaibrain.org</a></p>
</body>
</html>"""

    return _send_via_resend(
        to=to_email,
        subject="One week in — here's what Pro unlocks for you",
        html=html,
    )
