"""
workflow_base.py — canonical entry point for workflow self-execution.

HARD RULE: every file in `workflows/` MUST import this module and, if it has a
`__main__` block, route its top-level entry call through `workflow_execute()`.

Why this exists (task v1.4 P0-1, Apr 11 2026):
    The internal audit on 2026-04-11 found that 0 of 58 workflow files import
    `aibrain.core.harness`, 44 of 58 open raw `sqlite3.connect` directly, and
    `workflow_runs` in the last 7 days = 0. The "all workflow execution goes
    through the harness" HARD RULE was live-violated. This module is the
    single-line fix: import it, wrap your entry function, done.

Usage:
    from aibrain.core.workflow_base import workflow_execute

    def main():
        ...                         # existing workflow logic, untouched

    if __name__ == "__main__":
        workflow_execute(
            workflow_name="my_workflow",
            action=main,
            task_type="simple",     # deterministic | simple | judgment | complex
        )

Design notes:
    - Thin wrapper over `aibrain.core.harness.execute()` with workflow-sane
      defaults (task_type="simple", audit=True, tags=[workflow_name, "workflow"]).
    - Uses `_get_or_create_db` via harness for Bug #6 compliance — writes land
      on the canonical DB every time.
    - Never swallows exceptions. If the action raises, the HarnessResult surfaces
      `success=False` and the audit row still lands in `execution_log`.
    - Backwards compatible: the old `workflow_runner.run_workflow(name)` path
      is unchanged. This wrapper is the self-execution counterpart — workflows
      that are run directly (cron, CLI, manual) still get a harness row.
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from aibrain.core.harness import HarnessConfig, HarnessResult, execute

# Workflow-sane default caps. These mirror `workflow_runner.run_workflow`'s
# per-workflow defaults for the "no registry entry" path: quality_threshold
# 0.3 (workflows are established, not novel), max_retries 0 (don't double-run
# side effects), audit=True (every invocation lands in execution_log).
_DEFAULT_TASK_TYPE = "simple"
_DEFAULT_AUTHORITY = "standard"
_DEFAULT_TIMEOUT_SECONDS = 600
_DEFAULT_QUALITY_THRESHOLD = 0.3
_DEFAULT_MAX_RETRIES = 0
# Task-type → cost cap. Mirrors the execute_* convenience wrappers in
# harness.py. Deterministic workflows must not spend cents; judgment/complex
# workflows get progressively larger headroom.
_DEFAULT_MAX_COST_CENTS = {
    "deterministic": 0,
    "simple": 10,
    "judgment": 100,
    "complex": 500,
}


def workflow_execute(
    workflow_name: str,
    action: Callable[[], Any],
    actor: str = "workflow_runner",
    task_type: str = _DEFAULT_TASK_TYPE,
    authority: str = _DEFAULT_AUTHORITY,
    max_cost_cents: Optional[int] = None,
    timeout_seconds: int = _DEFAULT_TIMEOUT_SECONDS,
    quality_threshold: float = _DEFAULT_QUALITY_THRESHOLD,
    max_retries: int = _DEFAULT_MAX_RETRIES,
    tags: Optional[list] = None,
    **extra_config,
) -> HarnessResult:
    """
    Execute a workflow action through the harness pipeline.

    This is the ONLY supported entry point for workflow self-execution. All
    files under `workflows/` must route their main action through this call
    so every invocation:
        - gets classified (deterministic/simple/judgment/complex)
        - gets routed to the cheapest correct model
        - gets authority-checked and budget-capped
        - gets a quality score (0.0–1.0) written to execution_log
        - emits a WORKFLOW_EXECUTED event on the bus
        - contributes to the self-improvement feedback loop

    Args:
        workflow_name:     Stem of the workflow file (e.g. "heartbeat",
                           "db_backup"). Used for the task label and audit tags.
        action:            A zero-arg callable that performs the workflow's
                           work. Typically `main` or `run`. Can return any
                           value — the return is captured in `result.output`.
        actor:             Who initiated this run. Defaults to "workflow_runner".
        task_type:         One of deterministic/simple/judgment/complex.
                           Defaults to "simple" — the correct default for the
                           majority of workflows (light LLM use, cheap model).
        authority:         read_only/standard/elevated/admin. Defaults to
                           "standard" — can write DBs/files but not send mail.
        max_cost_cents:    Budget cap. Defaults by task_type (see table above).
        timeout_seconds:   Hard wall-clock cap on the action. Default 600s.
        quality_threshold: Minimum quality to accept. Default 0.3 — workflows
                           are established, not novel.
        max_retries:       Default 0 — don't retry workflows automatically;
                           most have observable side effects.
        tags:              Extra audit tags. `workflow_name` and "workflow"
                           are always appended.
        **extra_config:    Forwarded to HarnessConfig for advanced callers.

    Returns:
        HarnessResult — .success, .output, .quality, .audit_id, .run_id, etc.
        Never raises; execution errors land in result.error.
    """
    if max_cost_cents is None:
        max_cost_cents = _DEFAULT_MAX_COST_CENTS.get(task_type, 10)

    merged_tags = [workflow_name, "workflow"]
    if tags:
        merged_tags.extend(t for t in tags if t not in merged_tags)

    config = HarnessConfig(
        task_type=task_type,
        authority=authority,
        max_cost_cents=max_cost_cents,
        timeout_seconds=timeout_seconds,
        quality_threshold=quality_threshold,
        max_retries=max_retries,
        audit=True,
        actor=actor,
        tags=merged_tags,
        **extra_config,
    )

    return execute(
        task=f"workflow.{workflow_name}",
        action=action,
        config=config,
    )


__all__ = ["workflow_execute"]
