"""
risk_classifier.py — Auto-approve low-risk items in the approval queue.

The COO flagged that 125+ approvals accumulate because generation rate exceeds
processing rate. This module classifies each pending approval by risk and
auto-approves LOW items so Decker only sees MEDIUM and HIGH.

Risk levels:
  LOW    — auto-approve immediately (file moves, CI alerts, notifications)
  MEDIUM — batch review (config changes, outreach, scheduling)
  HIGH   — requires Decker (money, publishing, deletions, security, external comms)

Usage:
    from aibrain.core.risk_classifier import classify_approval_risk, auto_process_approvals

    risk = classify_approval_risk(approval)          # -> "low", "medium", "high"
    result = auto_process_approvals("GT_LRWrEBQQ")   # auto-approve LOW, return stats

Wire into heartbeat or scheduled workflow to drain the queue continuously.
"""

from __future__ import annotations

import json
import logging
import re
import sqlite3
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.risk_classifier")


# ── Risk keyword sets ──────────────────────────────────────────────

LOW_RISK_TYPES = {
    "file_move", "file_copy", "notification", "ci_alert", "ci_status",
    "marketing_post", "status_update", "heartbeat", "log_entry",
    "email_notification", "metric_snapshot", "health_check",
}

MEDIUM_RISK_TYPES = {
    "config_change", "outreach", "scheduling_change", "new_outreach",
    "workflow_update", "agent_config", "hire_agent", "quality_escalation",
}

HIGH_RISK_TYPES = {
    "spend_money", "publish", "external_comms", "delete", "security_change",
    "budget_override", "trade", "purchase", "deploy_production",
    "send_external_email", "revoke_access", "data_export",
}

# Keyword patterns for content-based classification when type alone is ambiguous
_HIGH_KEYWORDS = re.compile(
    r"(?:spend|money|doll|pay|purchas|delet|remov|secur|publish|deploy prod|"
    r"extern|budget|trade|revoke|credential|token change|key rotat)",
    re.IGNORECASE,
)

_MEDIUM_KEYWORDS = re.compile(
    r"(?:config|schedul|outreach|new agent|hire|workflow change|"
    r"cron|setting|permission)",
    re.IGNORECASE,
)

_LOW_KEYWORDS = re.compile(
    r"(?:file mov|copy|notif|alert|ci |status|heartbeat|log|metric|"
    r"health|ping|marketing post|newsletter|email notif)",
    re.IGNORECASE,
)


# ── Classification ────────────────────────────────────────────────

def classify_approval_risk(approval: dict) -> str:
    """Classify a single approval dict as 'low', 'medium', or 'high'.

    Classification uses three signals (in priority order):
    1. The approval 'type' field matched against known risk sets
    2. Payload content scanned for risk keywords
    3. Default to 'medium' when uncertain (safe middle ground)
    """
    approval_type = (approval.get("type") or "").lower().strip()
    payload_str = ""
    payload = approval.get("payload")
    if isinstance(payload, str):
        try:
            payload_obj = json.loads(payload)
            payload_str = json.dumps(payload_obj)
        except (json.JSONDecodeError, TypeError):
            payload_str = payload
    elif isinstance(payload, dict):
        payload_str = json.dumps(payload)

    combined_text = f"{approval_type} {payload_str}"

    # 1. Exact type match (highest confidence)
    if approval_type in HIGH_RISK_TYPES:
        return "high"
    if approval_type in LOW_RISK_TYPES:
        return "low"
    if approval_type in MEDIUM_RISK_TYPES:
        return "medium"

    # 2. Keyword scan on combined text (type + payload)
    if _HIGH_KEYWORDS.search(combined_text):
        return "high"
    if _LOW_KEYWORDS.search(combined_text):
        return "low"
    if _MEDIUM_KEYWORDS.search(combined_text):
        return "medium"

    # 3. Unknown type, no keyword match — default medium (conservative)
    return "medium"


# ── DB helpers ────────────────────────────────────────────────────

def _get_db(db_path: Optional[str] = None) -> sqlite3.Connection:
    """Open the aibrain database."""
    if db_path:
        p = Path(db_path)
    else:
        from aibrain_db import AIBRAIN_ROOT
        p = AIBRAIN_ROOT / "aibrain.db"
    db = sqlite3.connect(str(p))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    return db


# ── Auto-processing ──────────────────────────────────────────────

def auto_process_approvals(
    company_id: str,
    *,
    db_path: Optional[str] = None,
    dry_run: bool = False,
) -> dict:
    """Classify all pending approvals and auto-approve LOW-risk items.

    Args:
        company_id: The company whose approval queue to process.
        db_path: Optional explicit DB path (for testing).
        dry_run: If True, classify but don't actually approve anything.

    Returns:
        {
            "processed": int,      # total pending reviewed
            "auto_approved": int,  # LOW items approved
            "medium_held": int,    # MEDIUM items left for batch review
            "high_held": int,      # HIGH items left for Decker
            "details": [...]       # per-approval classification
        }
    """
    db = _get_db(db_path)

    rows = db.execute(
        "SELECT * FROM company_approvals "
        "WHERE company_id=? AND status IN ('pending', 'revision_requested') "
        "ORDER BY created_at",
        (company_id,),
    ).fetchall()

    stats = {
        "processed": 0,
        "auto_approved": 0,
        "medium_held": 0,
        "high_held": 0,
        "details": [],
    }

    for row in rows:
        approval = dict(row)
        risk = classify_approval_risk(approval)
        stats["processed"] += 1

        detail = {
            "id": approval["id"],
            "type": approval.get("type", ""),
            "risk": risk,
            "action": "held",
        }

        if risk == "low":
            if not dry_run:
                db.execute(
                    "UPDATE company_approvals "
                    "SET status='approved', decision_note=?, decided_at=datetime('now') "
                    "WHERE id=?",
                    ("Auto-approved (low risk) by risk_classifier", approval["id"]),
                )
            detail["action"] = "auto_approved"
            stats["auto_approved"] += 1
        elif risk == "medium":
            stats["medium_held"] += 1
        else:
            stats["high_held"] += 1

        stats["details"].append(detail)

    if not dry_run and stats["auto_approved"] > 0:
        db.commit()

    db.close()

    log.info(
        "Risk classifier: %d pending, %d auto-approved, %d medium held, %d high held (company %s%s)",
        stats["processed"], stats["auto_approved"],
        stats["medium_held"], stats["high_held"],
        company_id, " DRY RUN" if dry_run else "",
    )

    return stats


def classify_queue(
    company_id: str,
    *,
    db_path: Optional[str] = None,
) -> list[dict]:
    """Classify all pending approvals without modifying them. For dashboard display.

    Returns list of dicts with id, type, risk, created_at, payload summary.
    """
    db = _get_db(db_path)

    rows = db.execute(
        "SELECT * FROM company_approvals "
        "WHERE company_id=? AND status IN ('pending', 'revision_requested') "
        "ORDER BY created_at",
        (company_id,),
    ).fetchall()
    db.close()

    results = []
    for row in rows:
        approval = dict(row)
        risk = classify_approval_risk(approval)
        results.append({
            "id": approval["id"],
            "type": approval.get("type", ""),
            "risk": risk,
            "created_at": approval.get("created_at", ""),
            "requested_by": approval.get("requested_by_agent_id", ""),
        })

    return results
