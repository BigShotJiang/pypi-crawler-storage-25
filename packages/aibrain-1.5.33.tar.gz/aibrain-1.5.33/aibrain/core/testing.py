"""
testing.py — Experiment and regression testing framework for AIBrain.

Run workflows or teams multiple times, collect quality metrics, save baselines,
and detect regressions over time. Every execution goes through the harness.

Usage:
    from aibrain.core.testing import ExperimentRunner

    runner = ExperimentRunner()
    results = runner.run("heartbeat", n_iterations=5)
    results.print_summary()
    results.save_baseline()

    # Later, check for regressions:
    results2 = runner.run("heartbeat", n_iterations=5)
    report = results2.check_regression()
    results2.assert_no_regression()  # raises if quality dropped
"""

import json
import logging
import sqlite3
import statistics
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel, Field

log = logging.getLogger("aibrain.testing")

# Default baselines directory (relative to project root)
_PROJECT_ROOT = Path(__file__).parent.parent.parent
DEFAULT_BASELINES_DIR = _PROJECT_ROOT / "baselines"


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class RegressionReport(BaseModel):
    """Result of comparing current experiment against a saved baseline."""
    workflow: str
    baseline_avg: float
    current_avg: float
    delta: float
    regressed: bool
    threshold: float
    message: str


class ExperimentResults(BaseModel):
    """Collected metrics from running a workflow/team N times."""
    workflow: str
    iterations: int
    scores: list[float] = Field(default_factory=list)
    task_scores: dict[str, list[float]] = Field(default_factory=dict)
    errors: list[str] = Field(default_factory=list)
    duration_seconds: float = 0.0
    timestamp: str = ""

    @property
    def avg_quality(self) -> float:
        if not self.scores:
            return 0.0
        return statistics.mean(self.scores)

    @property
    def min_quality(self) -> float:
        if not self.scores:
            return 0.0
        return min(self.scores)

    @property
    def max_quality(self) -> float:
        if not self.scores:
            return 0.0
        return max(self.scores)

    @property
    def stddev(self) -> float:
        if len(self.scores) < 2:
            return 0.0
        return statistics.stdev(self.scores)

    def print_summary(self) -> str:
        """Print a formatted summary table. Returns the formatted string."""
        lines = [
            "",
            f"  Experiment: {self.workflow}",
            f"  Iterations: {self.iterations}",
            f"  Timestamp:  {self.timestamp}",
            f"  Duration:   {self.duration_seconds:.2f}s",
            "",
            f"  Avg Quality: {self.avg_quality:.3f}",
            f"  Min Quality: {self.min_quality:.3f}",
            f"  Max Quality: {self.max_quality:.3f}",
            f"  Std Dev:     {self.stddev:.3f}",
        ]

        if self.scores:
            lines.append("")
            lines.append("  Per-iteration scores:")
            for i, score in enumerate(self.scores, 1):
                bar = "#" * int(score * 20)
                lines.append(f"    Run {i:>3}: {score:.3f} |{bar}")

        if self.task_scores:
            lines.append("")
            lines.append("  Per-task avg scores:")
            for task_name, task_scores in self.task_scores.items():
                avg = statistics.mean(task_scores) if task_scores else 0.0
                lines.append(f"    {task_name}: {avg:.3f} ({len(task_scores)} runs)")

        if self.errors:
            lines.append("")
            lines.append(f"  Errors ({len(self.errors)}):")
            for err in self.errors[:5]:
                lines.append(f"    - {err[:120]}")
            if len(self.errors) > 5:
                lines.append(f"    ... and {len(self.errors) - 5} more")

        lines.append("")
        output = "\n".join(lines)
        print(output)
        return output

    def save_baseline(self, path: str = "") -> Path:
        """Save results as baseline JSON for future regression checks.

        Returns the path to the saved file.
        """
        baselines_dir = Path(path) if path else DEFAULT_BASELINES_DIR
        baselines_dir.mkdir(parents=True, exist_ok=True)

        # Sanitize workflow name for filename
        safe_name = (self.workflow
                     .replace("/", "_").replace("\\", "_")
                     .replace(" ", "_").replace(":", "_"))
        filepath = baselines_dir / f"{safe_name}.json"

        data = {
            "workflow": self.workflow,
            "iterations": self.iterations,
            "avg_quality": self.avg_quality,
            "min_quality": self.min_quality,
            "max_quality": self.max_quality,
            "stddev": self.stddev,
            "scores": self.scores,
            "task_scores": self.task_scores,
            "errors": self.errors,
            "duration_seconds": self.duration_seconds,
            "timestamp": self.timestamp,
        }

        filepath.write_text(json.dumps(data, indent=2), encoding="utf-8")
        log.info("Baseline saved: %s", filepath)
        return filepath

    def _load_baseline(self, path: str = "") -> Optional[dict]:
        """Load the saved baseline for this workflow, if it exists."""
        baselines_dir = Path(path) if path else DEFAULT_BASELINES_DIR
        safe_name = (self.workflow
                     .replace("/", "_").replace("\\", "_")
                     .replace(" ", "_").replace(":", "_"))
        filepath = baselines_dir / f"{safe_name}.json"

        if not filepath.exists():
            return None

        return json.loads(filepath.read_text(encoding="utf-8"))

    def check_regression(self, threshold: float = 0.1,
                         baseline_path: str = "") -> RegressionReport:
        """Compare against saved baseline. Flag if avg quality dropped by threshold.

        Args:
            threshold: Maximum acceptable quality drop (0.1 = 10%).
            baseline_path: Directory containing baseline JSON files.

        Returns:
            RegressionReport with comparison details.
        """
        baseline = self._load_baseline(baseline_path)

        if baseline is None:
            return RegressionReport(
                workflow=self.workflow,
                baseline_avg=0.0,
                current_avg=self.avg_quality,
                delta=0.0,
                regressed=False,
                threshold=threshold,
                message=f"No baseline found for '{self.workflow}'. Save one first.",
            )

        baseline_avg = baseline.get("avg_quality", 0.0)
        delta = baseline_avg - self.avg_quality
        regressed = delta > threshold

        if regressed:
            message = (
                f"REGRESSION: '{self.workflow}' quality dropped "
                f"{delta:.3f} (from {baseline_avg:.3f} to {self.avg_quality:.3f}), "
                f"exceeding threshold {threshold:.3f}"
            )
        else:
            message = (
                f"OK: '{self.workflow}' quality delta {delta:.3f} "
                f"(from {baseline_avg:.3f} to {self.avg_quality:.3f}), "
                f"within threshold {threshold:.3f}"
            )

        return RegressionReport(
            workflow=self.workflow,
            baseline_avg=baseline_avg,
            current_avg=self.avg_quality,
            delta=delta,
            regressed=regressed,
            threshold=threshold,
            message=message,
        )

    def assert_no_regression(self, threshold: float = 0.1,
                             baseline_path: str = ""):
        """Raise AssertionError if regression detected. For CI integration."""
        report = self.check_regression(threshold=threshold,
                                       baseline_path=baseline_path)
        if report.regressed:
            raise AssertionError(report.message)


# ---------------------------------------------------------------------------
# ExperimentRunner
# ---------------------------------------------------------------------------

class ExperimentRunner:
    """Run workflows/teams multiple times and track quality metrics.

    Each iteration runs through the execution harness, collecting quality
    scores, errors, and timing. Results are optionally persisted to SQLite.
    """

    def __init__(self, db_path: Optional[str] = None):
        """Initialize runner.

        Args:
            db_path: Path to SQLite database for history. If None, uses
                     the project aibrain.db if available.
        """
        self._db_path = db_path
        self._ensure_table()

    def _get_db_path(self) -> Optional[Path]:
        """Resolve the database path."""
        if self._db_path:
            return Path(self._db_path)
        # Use project aibrain.db
        candidate = _PROJECT_ROOT / "aibrain.db"
        if candidate.exists():
            return candidate
        return None

    def _ensure_table(self):
        """Create the experiment_results table if it doesn't exist."""
        db_path = self._get_db_path()
        if not db_path:
            return
        try:
            db = sqlite3.connect(str(db_path))
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("""
                CREATE TABLE IF NOT EXISTS experiment_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    workflow TEXT NOT NULL,
                    iterations INTEGER,
                    avg_quality REAL,
                    min_quality REAL,
                    max_quality REAL,
                    scores_json TEXT,
                    errors_json TEXT,
                    duration_seconds REAL,
                    created_at TEXT NOT NULL
                )
            """)
            db.commit()
            db.close()
        except Exception as e:
            log.warning("Could not create experiment_results table: %s", e)

    def _save_to_db(self, results: ExperimentResults):
        """Persist experiment results to SQLite."""
        db_path = self._get_db_path()
        if not db_path:
            return
        try:
            db = sqlite3.connect(str(db_path))
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("""
                INSERT INTO experiment_results
                (workflow, iterations, avg_quality, min_quality, max_quality,
                 scores_json, errors_json, duration_seconds, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, [
                results.workflow,
                results.iterations,
                results.avg_quality,
                results.min_quality,
                results.max_quality,
                json.dumps(results.scores),
                json.dumps(results.errors),
                results.duration_seconds,
                results.timestamp,
            ])
            db.commit()
            db.close()
        except Exception as e:
            log.warning("Could not save experiment results to DB: %s", e)

    def run(self, workflow: str, n_iterations: int = 3,
            inputs: Optional[dict] = None,
            actor: str = "experiment",
            dry_run: bool = False) -> ExperimentResults:
        """Run a workflow N times through the harness, collect quality scores.

        Args:
            workflow: Name of the workflow to run.
            n_iterations: How many times to run it.
            inputs: Optional keyword arguments passed to the workflow.
            actor: Actor identifier for harness audit.
            dry_run: If True, pass dry_run=True to workflow.

        Returns:
            ExperimentResults with scores, timing, and errors.
        """
        from aibrain.core.workflow_runner import run_workflow

        results = ExperimentResults(
            workflow=workflow,
            iterations=n_iterations,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

        start = time.time()
        kwargs = dict(inputs or {})

        for i in range(n_iterations):
            log.info("Experiment '%s' iteration %d/%d", workflow, i + 1, n_iterations)
            try:
                harness_result = run_workflow(
                    workflow,
                    dry_run=dry_run,
                    actor=actor,
                    **kwargs,
                )
                results.scores.append(harness_result.quality)
                if harness_result.error:
                    results.errors.append(
                        f"iter {i + 1}: {harness_result.error}"
                    )
            except Exception as e:
                results.scores.append(0.0)
                results.errors.append(f"iter {i + 1}: {e}")
                log.warning("Experiment iteration %d failed: %s", i + 1, e)

        results.duration_seconds = time.time() - start

        # Persist to DB
        self._save_to_db(results)

        return results

    def run_team(self, team: Any, n_iterations: int = 3,
                 inputs: Optional[dict] = None) -> ExperimentResults:
        """Run a team N times, collect quality scores per task.

        Args:
            team: A Team instance with agents and tasks.
            n_iterations: How many times to run it.
            inputs: Optional inputs dict passed to team.kickoff().

        Returns:
            ExperimentResults with per-task scores.
        """
        results = ExperimentResults(
            workflow=f"team:{getattr(team, 'name', 'unnamed')}",
            iterations=n_iterations,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

        start = time.time()

        for i in range(n_iterations):
            team_name = getattr(team, "name", "unnamed")
            log.info("Experiment team '%s' iteration %d/%d",
                     team_name, i + 1, n_iterations)
            try:
                team_output = team.kickoff(inputs=inputs)

                # Aggregate quality across all tasks for this run
                task_qualities = []
                for task_output in team_output.task_outputs:
                    quality = task_output.quality
                    task_qualities.append(quality)

                    # Track per-task scores
                    task_key = task_output.task_id or task_output.agent_role
                    if task_key not in results.task_scores:
                        results.task_scores[task_key] = []
                    results.task_scores[task_key].append(quality)

                # Overall score for this iteration = mean of task qualities
                if task_qualities:
                    run_score = statistics.mean(task_qualities)
                else:
                    run_score = 0.0
                results.scores.append(run_score)

                if not team_output.success:
                    results.errors.append(f"iter {i + 1}: team reported failure")

            except Exception as e:
                results.scores.append(0.0)
                results.errors.append(f"iter {i + 1}: {e}")
                log.warning("Team experiment iteration %d failed: %s", i + 1, e)

        results.duration_seconds = time.time() - start

        # Persist to DB
        self._save_to_db(results)

        return results

    def history(self, workflow: str, limit: int = 20) -> list[dict]:
        """Retrieve past experiment results for a workflow from SQLite.

        Returns list of dicts with keys: id, workflow, iterations,
        avg_quality, min_quality, max_quality, duration_seconds, created_at.
        """
        db_path = self._get_db_path()
        if not db_path:
            return []
        try:
            db = sqlite3.connect(str(db_path))
            db.row_factory = sqlite3.Row
            rows = db.execute("""
                SELECT id, workflow, iterations, avg_quality, min_quality,
                       max_quality, duration_seconds, created_at
                FROM experiment_results
                WHERE workflow = ?
                ORDER BY created_at DESC
                LIMIT ?
            """, (workflow, limit)).fetchall()
            db.close()
            return [dict(r) for r in rows]
        except Exception as e:
            log.warning("Could not read experiment history: %s", e)
            return []
