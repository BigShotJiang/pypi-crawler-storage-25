"""
retrieval_router.py — Six-channel parallel retrieval router for AIBrain.

Prototype (not wired into the live search path).

Inspired by SLM V3.3 multi-channel retrieval. Sits below SelRoute:
  SelRoute picks task shape → retrieval_router picks memory channel(s).

Six channels:
  1. semantic      — MiniLM/bge-base embedding cosine similarity (via sqlite-vec)
  2. bm25          — BM25 keyword term frequency (FTS5 rank function)
  3. entity_graph  — Recursive CTE walk over entity_links / memory_relations
  4. temporal      — Recency-weighted, importance-scaled retrieval
  5. associative   — Co-occurrence patterns from attention_log result_ids
  6. pattern       — type='pattern' memories + evolution_patterns text match

Usage:
    from aibrain.core.retrieval_router import retrieve

    hits = retrieve("what happened with the split-brain bug?", n=10)
    hits = retrieve("deploy to production", n=5, channel="bm25")
    hits = retrieve("latest AIBrain release", n=5, channel="temporal")

API:
    retrieve(query, n=5, channel='auto', db=None) -> list[dict]

    channel options:
        'auto'         — run all six channels, RRF-fuse (default)
        'semantic'     — dense vector similarity only
        'bm25'         — FTS5 keyword only
        'entity_graph' — graph walk only (seeds itself from semantic+BM25)
        'temporal'     — recency-weighted only
        'associative'  — attention_log co-occurrence only
        'pattern'      — pattern memories + evolution_patterns only

All channels degrade gracefully: missing infrastructure (no vec store, empty
entity_links, sparse attention_log) returns empty and RRF fuses the rest.

Do NOT integrate into aibrain_db.search_memories yet — prototype only.
"""

from __future__ import annotations

import json
import logging
import re
import sqlite3
import struct
from typing import Optional

log = logging.getLogger("aibrain.retrieval_router")

# ---------------------------------------------------------------------------
# RRF defaults — tuned to match tempr_retrieval.py's proven values
# ---------------------------------------------------------------------------

DEFAULT_RRF_K = 60
DEFAULT_POOL_MULT = 3   # per-channel pool = max(n * mult, 50)
DEFAULT_GRAPH_DEPTH = 2

CHANNEL_WEIGHTS = {
    "semantic": 1.2,
    "bm25": 1.0,
    "temporal": 0.8,
    "entity_graph": 0.7,
    "associative": 0.6,
    "pattern": 0.5,
}

# ---------------------------------------------------------------------------
# Temporal keyword list — used by the heuristic classifier
# ---------------------------------------------------------------------------

_TEMPORAL_KEYWORDS = frozenset({
    "recently", "last", "today", "yesterday", "since", "before", "after",
    "current", "latest", "now", "when", "week", "month", "hour", "ago",
    "recent", "new", "updated", "just", "earlier", "previously",
})

_PATTERN_KEYWORDS = frozenset({
    "pattern", "rule", "protocol", "always", "never", "whenever", "each",
    "best practice", "how should", "guideline", "standard", "principle",
    "convention", "workflow", "checklist",
})

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def retrieve(
    query: str,
    n: int = 5,
    channel: str = "auto",
    db: Optional[sqlite3.Connection] = None,
) -> list[dict]:
    """Six-channel retrieval router.

    Args:
        query: Natural language query string.
        n: Number of results to return.
        channel: Channel to use. One of 'auto', 'semantic', 'bm25',
                 'entity_graph', 'temporal', 'associative', 'pattern'.
                 'auto' runs all channels and fuses via RRF.
        db: Optional SQLite connection. Uses aibrain_db.get_db() if None.

    Returns:
        List of memory dicts. Each dict has the standard memories columns
        plus 'rrf_score' (float) and 'retrieval_methods' (list[str]) when
        channel='auto', or the channel-specific score field otherwise.
    """
    if not query or not query.strip():
        return []

    _db = db or _get_db()
    pool = max(n * DEFAULT_POOL_MULT, 50)

    if channel == "auto":
        return _auto_retrieve(_db, query, n, pool)
    elif channel == "semantic":
        return _channel_semantic(_db, query, pool)[:n]
    elif channel == "bm25":
        return _channel_bm25(_db, query, pool)[:n]
    elif channel == "entity_graph":
        # Seed from semantic + BM25 for entity_graph to be meaningful
        sem = _channel_semantic(_db, query, pool)
        bm = _channel_bm25(_db, query, pool)
        seeds = _seed_ids(sem, bm, limit=max(10, n))
        return _channel_entity_graph(_db, seeds, pool)[:n]
    elif channel == "temporal":
        return _channel_temporal(_db, pool)[:n]
    elif channel == "associative":
        sem = _channel_semantic(_db, query, pool)
        bm = _channel_bm25(_db, query, pool)
        seeds = _seed_ids(sem, bm, limit=max(10, n))
        return _channel_associative(_db, seeds, pool)[:n]
    elif channel == "pattern":
        return _channel_pattern(_db, query, pool)[:n]
    else:
        log.warning("Unknown channel %r — falling back to auto", channel)
        return _auto_retrieve(_db, query, n, pool)


def classify_channel(query: str) -> str:
    """Heuristic classifier: map a query to its most likely channel.

    Used for single-channel fast-path requests. In 'auto' mode, all channels
    run and this classifier is not called — RRF handles the weighting.

    Priority (evaluated in order):
      1. Temporal keywords          → 'temporal'
      2. Pattern keywords           → 'pattern'
      3. Multiple entity-like tokens → 'entity_graph'
      4. Short query (≤3 words)    → 'bm25'
      5. Long query (≥10 words)    → 'semantic'
      6. Default                   → 'semantic'

    Returns:
        One of: 'semantic', 'bm25', 'temporal', 'entity_graph', 'pattern'
    """
    tokens = query.lower().split()
    token_set = set(tokens)

    # 1. Temporal keywords
    if token_set & _TEMPORAL_KEYWORDS:
        return "temporal"

    # 2. Pattern keywords (check substring too for multi-word patterns)
    query_lower = query.lower()
    if token_set & _PATTERN_KEYWORDS or any(pk in query_lower for pk in _PATTERN_KEYWORDS):
        return "pattern"

    # 3. Entity-like tokens: capitalized words, snake_case, UUIDs, camelCase
    entity_pattern = re.compile(
        r'[A-Z][a-z]{2,}|[a-z]+_[a-z]+|[a-f0-9]{8}-[a-f0-9]{4}|[a-z]+[A-Z][a-z]+'
    )
    entity_hits = entity_pattern.findall(query)
    if len(entity_hits) > 1:
        return "entity_graph"

    # 4. Short query → BM25 (exact term lookup)
    if len(tokens) <= 3:
        return "bm25"

    # 5. Long query → semantic
    if len(tokens) >= 10:
        return "semantic"

    # 6. Default
    return "semantic"


# ---------------------------------------------------------------------------
# Auto mode: run all six channels and RRF-fuse
# ---------------------------------------------------------------------------


def _auto_retrieve(
    db: sqlite3.Connection, query: str, n: int, pool: int
) -> list[dict]:
    """Run all six channels in sequence and fuse via RRF."""
    # Channels 1 & 2 run first — their results seed channels 3 & 5
    semantic = _channel_semantic(db, query, pool)
    bm25 = _channel_bm25(db, query, pool)

    seeds = _seed_ids(semantic, bm25, limit=max(10, n))

    entity_graph = _channel_entity_graph(db, seeds, pool)
    temporal = _channel_temporal(db, pool)
    associative = _channel_associative(db, seeds, pool)
    pattern = _channel_pattern(db, query, pool)

    fused = _rrf_fuse(
        result_lists=[semantic, bm25, entity_graph, temporal, associative, pattern],
        rrf_k=DEFAULT_RRF_K,
        weights=[
            CHANNEL_WEIGHTS["semantic"],
            CHANNEL_WEIGHTS["bm25"],
            CHANNEL_WEIGHTS["entity_graph"],
            CHANNEL_WEIGHTS["temporal"],
            CHANNEL_WEIGHTS["associative"],
            CHANNEL_WEIGHTS["pattern"],
        ],
        labels=["semantic", "bm25", "entity_graph", "temporal", "associative", "pattern"],
    )
    return fused[:n]


# ---------------------------------------------------------------------------
# Channel implementations
# ---------------------------------------------------------------------------


def _channel_semantic(db: sqlite3.Connection, query: str, limit: int) -> list[dict]:
    """Channel 1: Dense vector similarity via sqlite-vec.

    Delegates to the proven tempr_retrieval implementation where possible.
    Falls back gracefully when vec store is unavailable.
    """
    try:
        from aibrain_db import _compute_embedding, _db_vec_enabled
    except ImportError:
        return []

    if not _db_vec_enabled:
        return []

    emb = _compute_embedding(query)
    if emb is None:
        return []

    emb_bytes = struct.pack(f"{len(emb)}f", *emb)
    try:
        rows = db.execute(
            "SELECT v.memory_id, v.distance FROM memories_vec v "
            "WHERE v.embedding MATCH ? AND k = ?",
            (emb_bytes, limit),
        ).fetchall()
        # Batch fetch — single IN() query instead of one SELECT per row (fixes N+1)
        id_distance = {row[0]: row[1] for row in rows}
        if not id_distance:
            return []
        placeholders = ",".join("?" * len(id_distance))
        mems = db.execute(
            f"SELECT * FROM memories WHERE id IN ({placeholders}) AND active=1 AND status='active'",
            list(id_distance.keys()),
        ).fetchall()
        results: list[dict] = []
        for mem in mems:
            d = dict(mem)
            d["vec_distance"] = id_distance[d["id"]]
            results.append(d)
        return results
    except Exception as exc:
        log.debug("semantic channel failed: %s", exc)
        return []


def _channel_bm25(db: sqlite3.Connection, query: str, limit: int) -> list[dict]:
    """Channel 2: BM25 via FTS5 rank function.

    Falls back to LIKE scan when FTS5 is unavailable.
    """
    fts_query = _prepare_fts_query(query)
    if not fts_query:
        return []
    try:
        rows = db.execute(
            "SELECT m.*, rank AS bm25_rank "
            "FROM memories m JOIN memories_fts f ON m.id=f.rowid "
            "WHERE memories_fts MATCH ? AND m.active=1 AND m.status='active' "
            "ORDER BY rank LIMIT ?",
            [fts_query, limit],
        ).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.DatabaseError as exc:
        log.debug("bm25 channel fell back to LIKE: %s", exc)
        try:
            rows = db.execute(
                "SELECT * FROM memories WHERE active=1 AND status='active' AND "
                "(name LIKE ? OR content LIKE ?) ORDER BY updated DESC LIMIT ?",
                [f"%{query}%", f"%{query}%", limit],
            ).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []


def _channel_entity_graph(
    db: sqlite3.Connection, seed_ids: list[int], limit: int
) -> list[dict]:
    """Channel 3: Graph walk over entity_links from seed memories.

    Walks entity_links (source_type='memory', target_type='memory') up to
    DEFAULT_GRAPH_DEPTH hops from seed IDs. Also checks memory_relations
    if the table exists.

    Seeds must come from another channel (semantic or BM25) for this to be
    meaningful. Returns empty when no seeds or no entity_links table.
    """
    if not seed_ids:
        return []

    # Check entity_links exists
    try:
        db.execute("SELECT 1 FROM entity_links LIMIT 1").fetchone()
    except sqlite3.OperationalError:
        # Try memory_relations fallback
        return _channel_entity_graph_via_relations(db, seed_ids, limit)

    placeholders = ",".join("?" for _ in seed_ids)
    depth = DEFAULT_GRAPH_DEPTH

    # entity_links uses source_type/target_type to distinguish node types
    cte = f"""
    WITH RECURSIVE walk(mem_id, dist) AS (
        SELECT id, 0 FROM memories
         WHERE id IN ({placeholders})
           AND active=1 AND status='active'
        UNION
        SELECT CAST(el.target_id AS INTEGER), w.dist + 1
          FROM entity_links el
          JOIN walk w ON CAST(w.mem_id AS TEXT) = el.source_id
         WHERE el.source_type='memory' AND el.target_type='memory'
           AND w.dist < ?
        UNION
        SELECT CAST(el.source_id AS INTEGER), w.dist + 1
          FROM entity_links el
          JOIN walk w ON CAST(w.mem_id AS TEXT) = el.target_id
         WHERE el.source_type='memory' AND el.target_type='memory'
           AND w.dist < ?
    )
    SELECT m.*, MIN(w.dist) AS graph_dist
      FROM walk w
      JOIN memories m ON m.id = w.mem_id
     WHERE m.active=1 AND m.status='active'
       AND m.id NOT IN ({placeholders})
     GROUP BY m.id
     ORDER BY graph_dist ASC, m.importance DESC
     LIMIT ?
    """
    params = list(seed_ids) + [depth, depth] + list(seed_ids) + [limit]
    try:
        rows = db.execute(cte, params).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.OperationalError as exc:
        log.debug("entity_graph channel failed, trying memory_relations: %s", exc)
        return _channel_entity_graph_via_relations(db, seed_ids, limit)


def _channel_entity_graph_via_relations(
    db: sqlite3.Connection, seed_ids: list[int], limit: int
) -> list[dict]:
    """Entity graph fallback using memory_relations table (from graph_memory.py)."""
    if not seed_ids:
        return []
    try:
        db.execute("SELECT 1 FROM memory_relations LIMIT 1").fetchone()
    except sqlite3.OperationalError:
        return []

    # Collect all IDs reachable within 2 hops via memory_relations
    visited: set[int] = set(seed_ids)
    frontier = list(seed_ids)

    for _ in range(DEFAULT_GRAPH_DEPTH):
        if not frontier:
            break
        placeholders = ",".join("?" for _ in frontier)
        try:
            rows = db.execute(
                f"SELECT to_memory_id as nid FROM memory_relations WHERE from_memory_id IN ({placeholders}) "
                f"UNION SELECT from_memory_id as nid FROM memory_relations WHERE to_memory_id IN ({placeholders})",
                frontier + frontier,
            ).fetchall()
        except Exception:
            break
        next_frontier = []
        for row in rows:
            nid = row[0]
            if nid not in visited:
                visited.add(nid)
                next_frontier.append(nid)
        frontier = next_frontier

    neighbor_ids = [i for i in visited if i not in set(seed_ids)]
    if not neighbor_ids:
        return []

    placeholders = ",".join("?" for _ in neighbor_ids[:limit])
    try:
        rows = db.execute(
            f"SELECT * FROM memories WHERE id IN ({placeholders}) AND active=1 AND status='active' "
            f"ORDER BY importance DESC LIMIT ?",
            neighbor_ids[:limit] + [limit],
        ).fetchall()
        return [dict(r) for r in rows]
    except Exception as exc:
        log.debug("memory_relations graph channel failed: %s", exc)
        return []


def _channel_temporal(db: sqlite3.Connection, limit: int) -> list[dict]:
    """Channel 4: Recency-weighted retrieval.

    Score = recency * importance * validity_penalty
    recency = 1 / (1 + days_old / 14)  — 14-day horizon (TEMPR-tuned value)
    validity_penalty = 0.3 if superseded (valid_until set), else 1.0

    Query-agnostic by design: surfaces "what matters lately" and lets
    RRF blend it with the query-aware channels.
    """
    try:
        cols = {r[1] for r in db.execute("PRAGMA table_info(memories)").fetchall()}
        has_validity = "valid_until" in cols
        validity_expr = (
            "CASE WHEN valid_until IS NOT NULL THEN 0.3 ELSE 1.0 END"
            if has_validity
            else "1.0"
        )
        sql = (
            f"SELECT *, "
            f"julianday('now') - julianday(COALESCE(updated, created)) AS days_old, "
            f"{validity_expr} AS validity_penalty "
            f"FROM memories WHERE active=1 AND status='active' "
            f"ORDER BY updated DESC LIMIT ?"
        )
        rows = db.execute(sql, [limit]).fetchall()
        results: list[dict] = []
        for r in rows:
            d = dict(r)
            days_old = d.pop("days_old", 0) or 0
            validity = d.pop("validity_penalty", 1.0)
            recency = 1.0 / (1.0 + max(days_old, 0) / 14.0)
            importance = float(d.get("importance", 0.5) or 0.5)
            d["temporal_score"] = round(recency * importance * validity, 6)
            results.append(d)
        results.sort(key=lambda x: x.get("temporal_score", 0), reverse=True)
        return results
    except Exception as exc:
        log.debug("temporal channel failed: %s", exc)
        return []


def _channel_associative(
    db: sqlite3.Connection, seed_ids: list[int], limit: int
) -> list[dict]:
    """Channel 5: Co-occurrence patterns from attention_log.

    Finds memories that frequently appear alongside the seed memories in past
    retrieval sessions. Implements associative recall: "what tends to come up
    with these memories".

    Algorithm:
      1. Find attention_log rows that contain any seed_id in result_ids
      2. Parse all result_ids from those rows
      3. Count frequency of each non-seed ID across those rows
      4. Return top-N by co-occurrence count

    Cold-start: returns empty when attention_log has <50 rows or no seeds.
    This is expected and harmless — RRF fuses the other channels.
    """
    if not seed_ids:
        return []

    try:
        # Check table exists and has meaningful data
        count = db.execute("SELECT COUNT(*) FROM attention_log").fetchone()[0]
        if count < 50:
            return []
    except sqlite3.OperationalError:
        return []

    # Build LIKE patterns to find rows containing any seed ID
    # We search for the seed ID as a JSON number in result_ids
    co_counts: dict[int, int] = {}
    seed_set = set(seed_ids)

    for seed_id in seed_ids[:10]:  # Cap at 10 seeds for query performance
        try:
            # result_ids is a JSON array like "[123, 456, 789]"
            rows = db.execute(
                "SELECT result_ids FROM attention_log "
                "WHERE result_ids LIKE ? "
                "ORDER BY timestamp DESC LIMIT 200",
                (f"%{seed_id}%",),
            ).fetchall()
            for row in rows:
                try:
                    ids = json.loads(row[0])
                    for mid in ids:
                        if isinstance(mid, int) and mid not in seed_set:
                            co_counts[mid] = co_counts.get(mid, 0) + 1
                except (json.JSONDecodeError, TypeError):
                    pass
        except Exception as exc:
            log.debug("associative channel query failed for seed %s: %s", seed_id, exc)
            continue

    if not co_counts:
        return []

    # Sort by co-occurrence count, take top candidates
    top_ids = sorted(co_counts, key=lambda x: co_counts[x], reverse=True)[:limit]

    results: list[dict] = []
    for mid in top_ids:
        try:
            mem = db.execute(
                "SELECT * FROM memories WHERE id=? AND active=1 AND status='active'",
                (mid,),
            ).fetchone()
            if mem:
                d = dict(mem)
                d["co_occurrence_count"] = co_counts[mid]
                results.append(d)
        except Exception:
            pass

    return results


def _channel_pattern(
    db: sqlite3.Connection, query: str, limit: int
) -> list[dict]:
    """Channel 6: Pattern memories + evolution_patterns text match.

    Two sub-sources:
      (a) Memories with type='pattern' — user/system behavioral rules
      (b) evolution_patterns rows — harness-discovered system patterns

    Both are scored by BM25/LIKE match against the query, merged,
    and deduplicated by memory ID (evolution_patterns are returned as
    synthetic memory-like dicts for RRF compatibility).

    Returns empty for evolution_patterns sub-source when there are no
    matching rows — harmless, the type='pattern' memories still contribute.
    """
    results: list[dict] = []
    fts_query = _prepare_fts_query(query)

    # Sub-source A: type='pattern' memories via FTS5
    if fts_query:
        try:
            rows = db.execute(
                "SELECT m.*, rank AS bm25_rank "
                "FROM memories m JOIN memories_fts f ON m.id=f.rowid "
                "WHERE memories_fts MATCH ? AND m.active=1 AND m.status='active' "
                "AND m.type='pattern' "
                "ORDER BY rank LIMIT ?",
                [fts_query, limit],
            ).fetchall()
            results.extend(dict(r) for r in rows)
        except sqlite3.DatabaseError as exc:
            log.debug("pattern channel FTS failed, using LIKE: %s", exc)
            try:
                rows = db.execute(
                    "SELECT * FROM memories WHERE active=1 AND status='active' "
                    "AND type='pattern' AND (name LIKE ? OR content LIKE ?) "
                    "ORDER BY importance DESC LIMIT ?",
                    [f"%{query}%", f"%{query}%", limit],
                ).fetchall()
                results.extend(dict(r) for r in rows)
            except Exception:
                pass

    # Sub-source B: evolution_patterns table
    try:
        cols = {r[1] for r in db.execute("PRAGMA table_info(evolution_patterns)").fetchall()}
        if "pattern" in cols:
            # Use LIKE for simplicity — evolution_patterns has no FTS index
            rows = db.execute(
                "SELECT * FROM evolution_patterns WHERE pattern LIKE ? "
                "ORDER BY frequency DESC LIMIT ?",
                [f"%{query.split()[0] if query.split() else query}%", limit // 2],
            ).fetchall()
            seen_ids = {r.get("id") for r in results if r.get("id")}
            for row in rows:
                d = dict(row)
                # Wrap evolution_pattern in a memory-compatible envelope
                synthetic_id = f"evo_pattern_{d.get('id', 'unknown')}"
                if synthetic_id not in seen_ids:
                    seen_ids.add(synthetic_id)
                    results.append({
                        "id": synthetic_id,
                        "name": f"Pattern: {str(d.get('pattern', ''))[:80]}",
                        "content": str(d.get("pattern", "")),
                        "type": "evolution_pattern",
                        "importance": min(1.0, (d.get("frequency", 1) or 1) / 100.0),
                        "active": 1,
                        "status": "active",
                        "evo_frequency": d.get("frequency"),
                        "evo_status": d.get("status"),
                    })
    except sqlite3.OperationalError as exc:
        log.debug("pattern channel evolution_patterns query failed: %s", exc)

    return results[:limit]


# ---------------------------------------------------------------------------
# RRF fusion
# ---------------------------------------------------------------------------


def _rrf_fuse(
    result_lists: list[list[dict]],
    rrf_k: int = DEFAULT_RRF_K,
    weights: Optional[list[float]] = None,
    labels: Optional[list[str]] = None,
) -> list[dict]:
    """Reciprocal Rank Fusion — combine N ranked lists.

    For each item in each list:
        contribution = weight / (rrf_k + rank + 1)
    Final score = sum of contributions across all lists.

    Handles heterogeneous ID types: numeric (from memories table) and
    string synthetic IDs (from evolution_patterns wrapper).

    Note: kept deliberately in sync with tempr_retrieval._rrf_fuse.
    """
    if weights is None:
        weights = [1.0] * len(result_lists)
    if labels is None:
        labels = [f"ch_{i}" for i in range(len(result_lists))]

    scores: dict = {}
    items: dict = {}
    methods: dict = {}

    for weight, results, label in zip(weights, result_lists, labels):
        for rank, mem in enumerate(results):
            mid = mem.get("id")
            if mid is None:
                continue
            contribution = weight / (rrf_k + rank + 1)
            scores[mid] = scores.get(mid, 0.0) + contribution
            if mid not in items:
                items[mid] = mem
            methods.setdefault(mid, []).append(label)

    fused: list[tuple[float, dict]] = []
    for mid, score in scores.items():
        item = items[mid]
        item["rrf_score"] = round(score, 6)
        item["retrieval_methods"] = methods[mid]
        fused.append((score, item))
    fused.sort(key=lambda x: x[0], reverse=True)
    return [item for _, item in fused]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _seed_ids(*result_lists: list[dict], limit: int = 10) -> list[int]:
    """Collect unique numeric memory IDs from the top of each result list.

    Round-robin across lists so no single channel dominates the seed set.
    Skips synthetic IDs (strings) from evolution_patterns.
    """
    seen: set[int] = set()
    ordered: list[int] = []
    i = 0
    while len(ordered) < limit:
        added_this_round = False
        for lst in result_lists:
            if i < len(lst):
                mid = lst[i].get("id")
                if isinstance(mid, int) and mid not in seen:
                    seen.add(mid)
                    ordered.append(mid)
                    added_this_round = True
                    if len(ordered) >= limit:
                        break
        if not added_this_round:
            break
        i += 1
    return ordered


def _prepare_fts_query(query: str) -> str:
    """Quote each term, join with OR for FTS5 MATCH.

    Kept in sync with tempr_retrieval._prepare_fts_query.
    """
    words = query.strip().split()
    if not words:
        return ""
    terms = [f'"{w}"' for w in words if len(w) > 1]
    return " OR ".join(terms) if terms else ""


def _get_db() -> sqlite3.Connection:
    """Get the canonical AIBrain DB connection."""
    import aibrain_db
    return aibrain_db.get_db()
