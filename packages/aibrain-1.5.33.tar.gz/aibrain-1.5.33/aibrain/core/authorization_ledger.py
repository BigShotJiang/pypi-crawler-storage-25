"""
authorization_ledger.py — Legal authorization ledger for external scanning.

Every external target scanned by Wintermute must have a documented authorization
record in this ledger. Blocks scans when no authorization exists.

Usage:
    from aibrain.core.authorization_ledger import (
        authorize_target, check_authorization, list_authorizations,
        revoke_authorization, require_authorization,
    )

    # Record authorization
    authorize_target("scanme.nmap.org", "scan_me", "decker_verbal", "full_scan",
                     authorized_by="Decker", rate_limit_rps=2.0)

    # Pre-scan gate
    auth = require_authorization("scanme.nmap.org")  # raises if unauthorized

    # CLI: aibrain authorizations
"""

import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.authorization_ledger")

# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

_SCHEMA = """
CREATE TABLE IF NOT EXISTS scan_authorizations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target TEXT NOT NULL,
    target_type TEXT NOT NULL,
    authorization_source TEXT,
    authorized_by TEXT,
    authorized_date TEXT,
    expires TEXT,
    scope TEXT,
    rate_limit_rps REAL DEFAULT 2.0,
    notes TEXT,
    active INTEGER DEFAULT 1,
    created TEXT DEFAULT (datetime('now'))
);
"""

VALID_TARGET_TYPES = ("internal", "bug_bounty", "scan_me", "client")
VALID_SCOPES = ("discovery_only", "full_scan", "exploit")
VALID_SOURCES = ("decker_verbal", "bug_bounty_program", "scan_me_header", "contract")


def _get_db(db_path: Optional[str] = None) -> sqlite3.Connection:
    """Get database connection, creating schema if needed."""
    if db_path:
        p = Path(db_path)
    else:
        from aibrain_db import AIBRAIN_ROOT
        p = AIBRAIN_ROOT / "aibrain.db"

    db = sqlite3.connect(str(p))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA busy_timeout=5000")
    db.executescript(_SCHEMA)
    return db


# ---------------------------------------------------------------------------
# Core API
# ---------------------------------------------------------------------------

def authorize_target(
    target: str,
    target_type: str,
    authorization_source: str,
    scope: str,
    *,
    authorized_by: str = "Decker",
    authorized_date: Optional[str] = None,
    expires: Optional[str] = None,
    rate_limit_rps: float = 2.0,
    notes: Optional[str] = None,
    db_path: Optional[str] = None,
) -> dict:
    """Record authorization for a scan target. Returns the new record."""
    if target_type not in VALID_TARGET_TYPES:
        raise ValueError(f"target_type must be one of {VALID_TARGET_TYPES}, got {target_type!r}")
    if scope not in VALID_SCOPES:
        raise ValueError(f"scope must be one of {VALID_SCOPES}, got {scope!r}")
    if authorization_source not in VALID_SOURCES:
        raise ValueError(f"authorization_source must be one of {VALID_SOURCES}, got {authorization_source!r}")

    if authorized_date is None:
        authorized_date = datetime.utcnow().strftime("%Y-%m-%d")

    db = _get_db(db_path)
    try:
        cur = db.execute(
            """INSERT INTO scan_authorizations
               (target, target_type, authorization_source, authorized_by,
                authorized_date, expires, scope, rate_limit_rps, notes)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (target, target_type, authorization_source, authorized_by,
             authorized_date, expires, scope, rate_limit_rps, notes),
        )
        db.commit()
        row = db.execute(
            "SELECT * FROM scan_authorizations WHERE id = ?", (cur.lastrowid,)
        ).fetchone()
        return dict(row)
    finally:
        db.close()


def check_authorization(target: str, *, db_path: Optional[str] = None) -> Optional[dict]:
    """Return the active authorization record for *target*, or None."""
    db = _get_db(db_path)
    try:
        row = db.execute(
            """SELECT * FROM scan_authorizations
               WHERE target = ? AND active = 1
               ORDER BY id DESC LIMIT 1""",
            (target,),
        ).fetchone()
        if row is None:
            return None
        rec = dict(row)
        # Check expiry
        if rec.get("expires"):
            try:
                exp = datetime.strptime(rec["expires"], "%Y-%m-%d")
                if exp < datetime.utcnow():
                    log.warning("Authorization for %s expired on %s", target, rec["expires"])
                    return None
            except ValueError:
                pass
        return rec
    finally:
        db.close()


def list_authorizations(active_only: bool = True, *, db_path: Optional[str] = None) -> list[dict]:
    """Return all authorization records."""
    db = _get_db(db_path)
    try:
        q = "SELECT * FROM scan_authorizations"
        if active_only:
            q += " WHERE active = 1"
        q += " ORDER BY target_type, target"
        rows = db.execute(q).fetchall()
        return [dict(r) for r in rows]
    finally:
        db.close()


def revoke_authorization(target: str, *, db_path: Optional[str] = None) -> int:
    """Deactivate all authorizations for *target*. Returns rows affected."""
    db = _get_db(db_path)
    try:
        cur = db.execute(
            "UPDATE scan_authorizations SET active = 0 WHERE target = ? AND active = 1",
            (target,),
        )
        db.commit()
        count = cur.rowcount
        if count:
            log.info("Revoked %d authorization(s) for %s", count, target)
        else:
            log.warning("No active authorization found for %s", target)
        return count
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Pre-scan gate
# ---------------------------------------------------------------------------

class UnauthorizedScanError(Exception):
    """Raised when a scan target has no valid authorization."""
    pass


def require_authorization(target: str, *, db_path: Optional[str] = None) -> dict:
    """Gate function for Wintermute pre-scan. Returns auth record or raises."""
    auth = check_authorization(target, db_path=db_path)
    if auth is None:
        raise UnauthorizedScanError(
            f"No active authorization for target {target!r}. "
            "Record authorization with authorize_target() before scanning."
        )
    return auth


# ---------------------------------------------------------------------------
# Pre-populate known authorizations
# ---------------------------------------------------------------------------

_INTERNAL_ENTITIES = [
    "Entity-A", "Entity-B", "Entity-C", "Entity-D", "Entity-E",
    "Entity-F", "Entity-G", "Entity-H", "Entity-I",
]

_SCAN_ME_SITES = [
    "scanme.nmap.org",
    "testphp.vulnweb.com",
    "demo.testfire.net",
    "juice-shop.herokuapp.com",
]


def seed_authorizations(*, db_path: Optional[str] = None) -> int:
    """Pre-populate ledger with known authorized targets. Skips duplicates. Returns count added."""
    added = 0

    # Internal targets — autonomous, no approval needed
    for entity in _INTERNAL_ENTITIES:
        existing = check_authorization(entity, db_path=db_path)
        if existing is None:
            authorize_target(
                entity, "internal", "contract", "full_scan",
                authorized_by="Decker",
                authorized_date="2026-01-01",
                notes="Internal entity — autonomous scanning authorized",
                db_path=db_path,
            )
            added += 1

    # Scan-me sites — authorized by Decker 2026-03-10, rate limit 2 RPS
    for site in _SCAN_ME_SITES:
        existing = check_authorization(site, db_path=db_path)
        if existing is None:
            authorize_target(
                site, "scan_me", "scan_me_header", "full_scan",
                authorized_by="Decker",
                authorized_date="2026-03-10",
                rate_limit_rps=2.0,
                notes="Scan-me site — Decker approved 2026-03-10, 2 RPS rate limit",
                db_path=db_path,
            )
            added += 1

    # Bug bounty — discovery only, requires explicit approval for full scan
    for program in ["hackerone_example", "bugcrowd_example"]:
        existing = check_authorization(program, db_path=db_path)
        if existing is None:
            authorize_target(
                program, "bug_bounty", "bug_bounty_program", "discovery_only",
                authorized_by="Decker",
                authorized_date="2026-03-10",
                rate_limit_rps=2.0,
                notes="Bug bounty — discovery only. Full scan requires explicit Decker approval.",
                db_path=db_path,
            )
            added += 1

    log.info("Seeded %d authorization records", added)
    return added


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cli_authorizations(args: list[str]) -> int:
    """CLI entry point: aibrain authorizations [seed|list|revoke <target>]"""
    subcmd = args[0] if args else "list"

    if subcmd == "seed":
        count = seed_authorizations()
        print(f"Seeded {count} authorization records.")
        return 0

    if subcmd == "revoke" and len(args) >= 2:
        target = args[1]
        count = revoke_authorization(target)
        print(f"Revoked {count} authorization(s) for {target}.")
        return 0

    if subcmd in ("list", "all"):
        active_only = subcmd != "all"
        records = list_authorizations(active_only=active_only)
        if not records:
            print("No authorizations found. Run 'aibrain authorizations seed' to pre-populate.")
            return 0
        # Table output
        print(f"{'Target':<30} {'Type':<12} {'Scope':<16} {'Source':<20} {'RPS':>5} {'Active':>6}")
        print("-" * 95)
        for r in records:
            print(
                f"{r['target']:<30} {r['target_type']:<12} {r['scope']:<16} "
                f"{r['authorization_source']:<20} {r['rate_limit_rps']:>5.1f} "
                f"{'Yes' if r['active'] else 'No':>6}"
            )
        print(f"\nTotal: {len(records)} record(s)")
        return 0

    print("Usage: aibrain authorizations [list|all|seed|revoke <target>]")
    return 1
