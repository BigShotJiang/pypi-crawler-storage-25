"""
local_llm.py — Ollama-backed local LLM client for air-gapped use cases.

Drop-in replacement for Claude when running Rogue/Paragon in air-gapped or
SENSITIVE-data environments where cloud models are prohibited.

Uses Ollama's /api/chat endpoint (OpenAI-compatible messages format).
Fully graceful when Ollama is down — is_available() returns False, no crash.

Usage:
    from aibrain.core.local_llm import LocalLLMClient

    client = LocalLLMClient()               # auto-picks smallest available model
    client = LocalLLMClient(model="qwen3:8b")  # specific model

    if client.is_available():
        response = client.complete(
            messages=[{"role": "user", "content": "Explain CVE-2024-1234"}],
            system="You are a security analyst.",
        )
        # streaming
        for chunk in client.complete(messages=[...], stream=True):
            print(chunk, end="", flush=True)

Environment:
    OLLAMA_BASE_URL — override Ollama endpoint (default: http://localhost:11434)
"""

import json
import logging
import os
import urllib.error
import urllib.request
from typing import Generator, Optional, Union

log = logging.getLogger("aibrain.local_llm")

# Model preference order: smallest capable first — matches local_router.LOCAL_MODEL_PREFERENCE
_MODEL_PREFERENCE = [
    "gemma3:4b",
    "qwen2.5:7b-instruct",
    "qwen3:8b",
    "gemma3:12b",
    "gemma3:27b",
]

# Models to skip — not general-purpose LLMs
_SKIP_KEYWORDS = ("ocr", "vision", "embed", "minilm", "nomic", "bge", "bert")


class LocalLLMClient:
    """Ollama-backed local LLM. Drop-in for Claude when air-gapped.

    Wraps Ollama's /api/chat endpoint in an OpenAI-compatible messages format.
    All operations degrade gracefully if Ollama is unavailable.
    """

    def __init__(
        self,
        model: str = "auto",
        base_url: str = "",
        timeout: int = 120,
    ):
        """
        Args:
            model:    Model name (e.g. "qwen3:8b") or "auto" to pick smallest available.
            base_url: Ollama base URL. Defaults to OLLAMA_BASE_URL env var or localhost:11434.
            timeout:  HTTP request timeout in seconds. Default 120 (LLMs can be slow).
        """
        self.base_url = (
            base_url
            or os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
        ).rstrip("/")
        self.timeout = timeout
        self._requested_model = model
        self._resolved_model: Optional[str] = None  # resolved on first use

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def is_available(self) -> bool:
        """Return True if Ollama is running and at least one usable model is available."""
        return len(self._get_available_models()) > 0

    def complete(
        self,
        messages: list,
        system: str = "",
        stream: bool = False,
    ) -> Union[str, Generator[str, None, None]]:
        """Call Ollama /api/chat with OpenAI-compatible messages format.

        Args:
            messages: List of {"role": "user"|"assistant", "content": "..."} dicts.
                      System message should be passed via the `system` param.
            system:   System prompt prepended to the conversation.
            stream:   If True, returns a generator yielding text chunks.

        Returns:
            Full response string (stream=False) or chunk generator (stream=True).

        Raises:
            RuntimeError: If Ollama is unavailable or request fails.
        """
        model = self._resolve_model()
        if model is None:
            raise RuntimeError(
                "Ollama is not available or has no usable models. "
                "Start Ollama and pull a model (e.g. `ollama pull gemma3:4b`)."
            )

        payload = {
            "model": model,
            "messages": messages,
            "stream": stream,
        }
        if system:
            payload["system"] = system

        log.debug("LocalLLMClient: POST /api/chat model=%s stream=%s", model, stream)

        if stream:
            return self._stream_chat(payload)
        else:
            return self._blocking_chat(payload)

    def model_name(self) -> Optional[str]:
        """Return the resolved model name, or None if Ollama unavailable."""
        return self._resolve_model()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_model(self) -> Optional[str]:
        """Resolve 'auto' to the best available model. Cached after first call."""
        if self._resolved_model is not None:
            return self._resolved_model

        available = self._get_available_models()
        if not available:
            return None

        if self._requested_model == "auto":
            model = _pick_model(available)
        else:
            # Exact match first
            if self._requested_model in available:
                model = self._requested_model
            else:
                # Fallback: try prefix match (e.g. "gemma3" → "gemma3:4b")
                prefix_matches = [m for m in available if m.startswith(self._requested_model)]
                if prefix_matches:
                    model = prefix_matches[0]
                else:
                    log.warning(
                        "Requested model '%s' not in Ollama (%s). Falling back to auto.",
                        self._requested_model, available
                    )
                    model = _pick_model(available)

        self._resolved_model = model
        log.debug("LocalLLMClient resolved model: %s", model)
        return model

    def _get_available_models(self) -> list:
        """Fetch available Ollama models. Returns [] if Ollama is down."""
        try:
            req = urllib.request.Request(
                f"{self.base_url}/api/tags",
                headers={"Accept": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=3) as resp:
                data = json.loads(resp.read())
            models = [
                m["name"] for m in data.get("models", [])
                if not _should_skip(m["name"])
            ]
            return models
        except Exception as e:
            log.debug("Ollama unavailable: %s", e)
            return []

    def _blocking_chat(self, payload: dict) -> str:
        """POST to /api/chat, wait for full response, return text."""
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"{self.base_url}/api/chat",
            data=body,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read()
        except urllib.error.URLError as e:
            raise RuntimeError(f"Ollama request failed: {e}") from e

        try:
            result = json.loads(raw)
        except json.JSONDecodeError as e:
            raise RuntimeError(f"Ollama returned invalid JSON: {e!r}") from e

        # /api/chat non-stream response: {"message": {"role": ..., "content": ...}, ...}
        try:
            return result["message"]["content"]
        except (KeyError, TypeError) as e:
            raise RuntimeError(f"Unexpected Ollama response shape: {result!r}") from e

    def _stream_chat(self, payload: dict) -> Generator[str, None, None]:
        """POST to /api/chat with stream=True, yield text chunks."""
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"{self.base_url}/api/chat",
            data=body,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST",
        )
        try:
            resp = urllib.request.urlopen(req, timeout=self.timeout)
        except urllib.error.URLError as e:
            raise RuntimeError(f"Ollama stream request failed: {e}") from e

        with resp:
            for raw_line in resp:
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    chunk = json.loads(line)
                except json.JSONDecodeError:
                    continue
                # /api/chat stream: each line has {"message": {"content": "..."}, "done": bool}
                content = chunk.get("message", {}).get("content", "")
                if content:
                    yield content
                if chunk.get("done"):
                    break


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------

def _should_skip(model_name: str) -> bool:
    """Return True for non-general-purpose models (embeddings, vision, etc.)."""
    lower = model_name.lower()
    return any(kw in lower for kw in _SKIP_KEYWORDS)


def _pick_model(available: list) -> Optional[str]:
    """Pick best model from available list using preference order."""
    for preferred in _MODEL_PREFERENCE:
        if preferred in available:
            return preferred
    # None in preference list found — return first non-skipped
    for m in available:
        if not _should_skip(m):
            return m
    return None
