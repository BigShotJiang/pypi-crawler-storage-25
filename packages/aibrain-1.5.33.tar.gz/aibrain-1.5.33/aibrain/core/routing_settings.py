"""
routing_settings.py — User-facing routing mode and token budget toggles for SuperWorker.

Persists to ~/.aibrain/routing.json. Optional — if missing, pure defaults apply (no startup cost).

Modes:
    auto              — SuperWorker for judgment/complex tasks only (default, cost-aware)
    always_superworker — Force SuperWorker on every invocable task
    never_superworker  — Never use SuperWorker (single-worker only)
    manual             — Controlled by per-invocation flags (--fast / --deep)

Per-invocation overrides (applied in this priority order, highest first):
    deep_mode=True  → always SuperWorker (beats mode setting)
    fast_mode=True  → never SuperWorker (beats mode, but not deep_mode)
    mode            → fallback when no per-invocation flags set

Daily token budget:
    token_budget_per_day_cents — None = no cap (default). When set, check_budget_exceeded()
    sums cost_cents_equivalent from execution_log for today and returns True when exceeded.
    Callers should downgrade to single-worker when True.
"""
from __future__ import annotations

import json
import logging
import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.routing_settings")

SETTINGS_PATH = Path.home() / ".aibrain" / "routing.json"

VALID_MODES = ("auto", "always_superworker", "never_superworker", "manual")


@dataclass
class RoutingSettings:
    """User-facing routing preferences. Serialized to ~/.aibrain/routing.json."""

    mode: str = "auto"
    # auto              → SuperWorker for judgment/complex
    # always_superworker → force SuperWorker regardless of task type
    # never_superworker  → single-worker always
    # manual             → per-invocation fast_mode / deep_mode decide

    token_budget_per_day_cents: Optional[int] = None
    # None = no daily cap. >0 = hard daily cent limit (list-rate equivalent).

    fast_mode: bool = False
    # Per-invocation: no SuperWorker this run (overrides mode; deep_mode beats fast_mode)

    deep_mode: bool = False
    # Per-invocation: force SuperWorker this run (highest priority override)

    def save(self) -> None:
        """Persist settings to disk."""
        SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        SETTINGS_PATH.write_text(
            json.dumps(self.__dict__, indent=2),
            encoding="utf-8",
        )
        log.debug("Routing settings saved to %s", SETTINGS_PATH)

    @classmethod
    def load(cls) -> "RoutingSettings":
        """Load settings from disk. Returns defaults if file missing or corrupt."""
        if SETTINGS_PATH.exists():
            try:
                raw = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
                # Filter to only known fields — forward-compatible with new fields added later
                known = {f for f in cls.__dataclass_fields__}
                filtered = {k: v for k, v in raw.items() if k in known}
                return cls(**filtered)
            except Exception as exc:
                log.warning(
                    "routing_settings: failed to load %s (%s) — using defaults",
                    SETTINGS_PATH,
                    exc,
                )
        return cls()

    def should_use_superworker(self, task_type: str) -> bool:
        """
        Decide whether to use SuperWorker for this task invocation.

        Priority (highest → lowest):
          1. deep_mode=True  → always SuperWorker
          2. fast_mode=True  → never SuperWorker
          3. mode="always_superworker" → always SuperWorker
          4. mode="never_superworker"  → never SuperWorker
          5. mode="manual"   → False (no per-invocation flag set; use single-worker)
          6. mode="auto"     → SuperWorker for judgment/complex tasks only
        """
        # Per-invocation flags beat the mode setting
        if self.deep_mode:
            return True
        if self.fast_mode:
            return False

        # Mode-level settings
        if self.mode == "always_superworker":
            return True
        if self.mode == "never_superworker":
            return False
        if self.mode == "manual":
            # No per-invocation flag set — default to single-worker in manual mode
            return False

        # auto (default): SuperWorker only for high-complexity tasks
        return task_type in ("judgment", "complex")

    def reset(self) -> None:
        """Reset to defaults in-place."""
        self.mode = "auto"
        self.token_budget_per_day_cents = None
        self.fast_mode = False
        self.deep_mode = False


def _today_bounds() -> tuple[str, str]:
    """Return (start_iso, end_iso) for today (UTC calendar day)."""
    now = datetime.utcnow()
    start = datetime(now.year, now.month, now.day)
    end = datetime(now.year, now.month, now.day, 23, 59, 59)
    return (
        start.strftime("%Y-%m-%d %H:%M:%S"),
        end.strftime("%Y-%m-%d %H:%M:%S"),
    )


def _find_db() -> Optional[Path]:
    """Resolve canonical aibrain DB path. Returns None if unavailable."""
    try:
        from aibrain_db import AIBRAIN_ROOT
        p = AIBRAIN_ROOT / "aibrain.db"
        return p if p.exists() else None
    except Exception:
        return None


def get_today_spend_cents(db_path: Optional[Path] = None) -> Optional[int]:
    """
    Sum cost_cents_equivalent from execution_log for today's UTC calendar day.

    Returns:
        int   — total cents spent today (0 if no rows with cost signal)
        None  — DB unavailable or schema too old (caller should treat as "unknown")
    """
    p = db_path or _find_db()
    if p is None:
        return None

    try:
        db = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
        db.row_factory = sqlite3.Row
        try:
            # Check table + column exist (schema guard — schema_old returns None)
            has_log = db.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='execution_log'"
            ).fetchone()
            if not has_log:
                return None
            cols = {r[1] for r in db.execute("PRAGMA table_info(execution_log)").fetchall()}
            if "cost_cents_equivalent" not in cols:
                return None

            start_iso, end_iso = _today_bounds()
            row = db.execute(
                """
                SELECT COALESCE(SUM(cost_cents_equivalent), 0) AS total
                FROM execution_log
                WHERE created_at >= ? AND created_at <= ?
                  AND cost_cents_equivalent IS NOT NULL
                """,
                (start_iso, end_iso),
            ).fetchone()
            return int(row["total"]) if row else 0
        finally:
            db.close()
    except Exception as exc:
        log.debug("get_today_spend_cents: DB query failed: %s", exc)
        return None


def check_budget_exceeded(
    settings: RoutingSettings,
    db_path: Optional[Path] = None,
) -> bool:
    """
    Check if the daily token budget has been exceeded.

    Returns True if the budget is set AND today's spend >= the cap.
    Returns False when:
      - No budget is configured (token_budget_per_day_cents is None)
      - DB is unavailable (fail-open: never block on missing signal)
      - Spend is below the cap

    Callers should downgrade to single-worker when True.
    """
    if settings.token_budget_per_day_cents is None:
        return False  # No cap configured

    today_cents = get_today_spend_cents(db_path=db_path)
    if today_cents is None:
        # Cannot measure — fail-open (don't block execution on missing signal)
        log.debug(
            "check_budget_exceeded: spend unknown (DB unavailable) — failing open"
        )
        return False

    exceeded = today_cents >= settings.token_budget_per_day_cents
    if exceeded:
        log.warning(
            "Daily token budget exceeded: spent=%d cents, cap=%d cents — downgrading to single-worker",
            today_cents,
            settings.token_budget_per_day_cents,
        )
    return exceeded
