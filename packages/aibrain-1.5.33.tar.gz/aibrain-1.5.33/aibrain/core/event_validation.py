"""
event_validation.py — Pre-dispatch validation filter for AIBrain event bus.

Prevents learning loop poisoning by validating:
  1. Event source (which agent/process emitted it)
  2. Payload schema (correct fields and types per event type)
  3. Content safety (rejects shell injection, suspicious URLs in learning data)
  4. Audit logging of all rejected events

Wired into event_bus.emit() as a pre-dispatch filter.

Usage:
    from aibrain.core.event_validation import validate_event

    result = validate_event("CORRECTION_RECEIVED", {"content_preview": "..."}, source="neuro")
    if not result.ok:
        print(f"Rejected: {result.reason}")
"""

from __future__ import annotations

import json
import logging
import re
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.event_validation")

# ---------------------------------------------------------------------------
# Validation result
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    """Outcome of event validation."""
    ok: bool
    reason: str = ""
    violations: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Known agents — only these can emit events
# ---------------------------------------------------------------------------

KNOWN_AGENTS = frozenset({
    "neuro", "case",
    # DeckerOps company agents (by ID)
    "CDTYrHYkyH8", "w_wqv7t9huE", "I5JwaUTVUps", "RFYhIipppGs",
    "RztUQUCs-h4", "v_sJ2kha1EQ", "vZX67BqBmjo", "RrYNwHqrzYY",
    "B3OLnCI3fXk", "9IXqSnCBLLQ", "wAfRAIHL_Kc", "BCQ0gfGgsZ0",
    "1KHYPUDXh2g", "iEsw2ApS2gU", "5nvOImJifUU", "NyFKX783dO8",
    "ag89hZc-swI", "FlTsbFpW4TQ", "m2FRRZhP5lw", "5qbok8h7CIg",
    # System processes
    "harness", "workflow_runner", "reactive_chain", "mcp_server",
    "backend", "scheduler", "broker", "peer_daemon",
})

# ---------------------------------------------------------------------------
# Payload schemas — required fields and types per event type
# ---------------------------------------------------------------------------

# Maps event_type → dict of {field_name: (required, allowed_types)}
PAYLOAD_SCHEMAS: dict[str, dict[str, tuple[bool, tuple]]] = {
    "CORRECTION_RECEIVED": {
        "content_preview": (False, (str,)),
        "name": (False, (str,)),
        "domain": (False, (str,)),
    },
    "QUALITY_LOW": {
        "task_name": (True, (str,)),
        "eval_score": (True, (int, float)),
        "detail": (False, (str,)),
        "self_score": (False, (int, float, type(None))),
    },
    "TASK_COMPLETED": {
        "task_id": (True, (str,)),
        "title": (False, (str,)),
        "eval_score": (False, (int, float, type(None))),
        "self_score": (False, (int, float, type(None))),
    },
    "WORKFLOW_EXECUTED": {
        "workflow": (False, (str,)),
        "result": (False, (str,)),
    },
    "MEMORY_STORED": {
        "id": (False, (int,)),
        "type": (False, (str,)),
    },
}

# ---------------------------------------------------------------------------
# Content safety patterns — reject if matched in learning payloads
# ---------------------------------------------------------------------------

# Shell injection patterns
_SHELL_PATTERNS = [
    re.compile(r';\s*(rm|wget|curl|bash|sh|python|powershell|cmd)\s', re.IGNORECASE),
    re.compile(r'\|\s*(bash|sh|python|powershell|cmd)\b', re.IGNORECASE),
    re.compile(r'`[^`]*(rm|wget|curl|bash|sh)\s', re.IGNORECASE),
    re.compile(r'\$\([^)]*\)', re.IGNORECASE),  # command substitution $(...)
    re.compile(r'&&\s*(rm|wget|curl|bash|sh|python)\s', re.IGNORECASE),
]

# Suspicious URL patterns in correction/memory content
_URL_PATTERNS = [
    re.compile(r'https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'),  # raw IP URLs
    re.compile(r'https?://[^\s]*\.(ru|cn|tk|ml|ga|cf|gq)/'),  # suspicious TLDs
    re.compile(r'data:text/(html|javascript)', re.IGNORECASE),  # data URIs
]

# Event types where content safety checks apply (learning-related)
_CONTENT_CHECK_EVENTS = frozenset({
    "CORRECTION_RECEIVED", "MEMORY_STORED", "QUALITY_LOW",
})

# Payload fields to scan for dangerous content
_CONTENT_FIELDS = frozenset({
    "content_preview", "content", "name", "detail", "title",
    "correction_text", "memory_content",
})


# ---------------------------------------------------------------------------
# Validation logic
# ---------------------------------------------------------------------------

def _validate_source(source: Optional[str], strict: bool = False) -> list[str]:
    """Check that the event source is a known agent/process.

    Args:
        source: The agent/process identifier.
        strict: If False (default), missing source is allowed for backward
                compatibility. Set True to enforce source on all events.
    """
    if source is None:
        if strict:
            return ["missing event source (source=None)"]
        # Backward-compatible: existing callers don't pass source yet.
        # Log but don't block.
        log.debug("Event emitted without source — consider adding source= for audit")
        return []
    if source not in KNOWN_AGENTS:
        return [f"unknown event source: {source!r}"]
    return []


def _validate_schema(event_type: str, payload: dict) -> list[str]:
    """Check payload matches expected schema for the event type."""
    violations = []
    schema = PAYLOAD_SCHEMAS.get(event_type)
    if schema is None:
        # Unknown event type — allow but note it
        return []

    for field_name, (required, allowed_types) in schema.items():
        if field_name not in payload:
            if required:
                violations.append(f"missing required field: {field_name}")
            continue
        value = payload[field_name]
        if not isinstance(value, allowed_types):
            violations.append(
                f"field {field_name!r}: expected {allowed_types}, got {type(value).__name__}"
            )
    return violations


def _validate_content_safety(event_type: str, payload: dict) -> list[str]:
    """Scan payload text fields for shell injection and suspicious URLs."""
    if event_type not in _CONTENT_CHECK_EVENTS:
        return []

    violations = []
    for key, value in payload.items():
        if key not in _CONTENT_FIELDS or not isinstance(value, str):
            continue

        for pattern in _SHELL_PATTERNS:
            if pattern.search(value):
                violations.append(
                    f"shell injection detected in {key!r}: matched {pattern.pattern!r}"
                )
                break  # one violation per field is enough

        for pattern in _URL_PATTERNS:
            if pattern.search(value):
                violations.append(
                    f"suspicious URL in {key!r}: matched {pattern.pattern!r}"
                )
                break

    return violations


def validate_event(
    event_type: str,
    payload: dict,
    source: Optional[str] = None,
) -> ValidationResult:
    """Run all validation checks on an event before dispatch.

    Args:
        event_type: The event type string.
        payload: The event payload dict.
        source: The agent/process that emitted the event.

    Returns:
        ValidationResult with ok=True if all checks pass,
        or ok=False with reason and violations list.
    """
    violations = []

    # 1. Source validation
    violations.extend(_validate_source(source))

    # 2. Schema validation
    violations.extend(_validate_schema(event_type, payload))

    # 3. Content safety
    violations.extend(_validate_content_safety(event_type, payload))

    if violations:
        reason = f"Event {event_type} rejected: {'; '.join(violations)}"
        _log_rejection(event_type, payload, source, reason)
        return ValidationResult(ok=False, reason=reason, violations=violations)

    return ValidationResult(ok=True)


# ---------------------------------------------------------------------------
# Rejection audit log
# ---------------------------------------------------------------------------

_REJECT_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS event_rejections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    source TEXT,
    payload TEXT,
    reason TEXT NOT NULL,
    created TEXT DEFAULT (datetime('now'))
);
"""


def _get_db_path() -> Path:
    """Resolve aibrain.db path via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    return AIBRAIN_ROOT / "aibrain.db"


def _log_rejection(
    event_type: str,
    payload: dict,
    source: Optional[str],
    reason: str,
) -> None:
    """Write rejection to the event_rejections audit table."""
    try:
        db_path = _get_db_path()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(db_path))
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript(_REJECT_TABLE_SQL)
        conn.execute(
            "INSERT INTO event_rejections (event_type, source, payload, reason) "
            "VALUES (?, ?, ?, ?)",
            (event_type, source, json.dumps(payload, default=str), reason),
        )
        conn.commit()
        conn.close()
    except Exception as e:
        log.debug("Failed to log event rejection (non-fatal): %s", e)

    log.warning("EVENT REJECTED: %s from source=%s — %s", event_type, source, reason)


def get_rejections(last: int = 20) -> list[dict]:
    """Fetch recent event rejections for audit review."""
    try:
        db_path = _get_db_path()
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript(_REJECT_TABLE_SQL)
        rows = conn.execute(
            "SELECT * FROM event_rejections ORDER BY id DESC LIMIT ?",
            (last,),
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception:
        return []
