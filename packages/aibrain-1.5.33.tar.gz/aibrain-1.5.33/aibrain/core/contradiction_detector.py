"""
contradiction_detector.py — Recall-time contradiction detection.

Scans recall results for internal contradictions. For each pair of results
that share a topic_cluster_id or have matching claims subjects, checks if
their claims conflict.

Part of the Memory Lifecycle v1.6 feature.
"""

from __future__ import annotations

import logging
import sqlite3
from collections import defaultdict
from typing import Optional

log = logging.getLogger("aibrain.contradiction_detector")

# Claim type precedence (higher = more authoritative)
_CLAIM_PRECEDENCE = {
    "verified_fact": 4,
    "observation": 3,
    "assertion": 2,
    "plan": 1,
    "deprecated": 0,
}


def detect_contradictions_in_results(
    results: list[dict],
    db: Optional[sqlite3.Connection] = None,
) -> list[dict]:
    """Scan recall results for internal contradictions.

    For each pair of results that share a topic_cluster_id or have high
    embedding similarity (>0.70), check if their claims conflict.

    A conflict exists when:
    1. Two memories share the same subject+predicate but different objects
    2. One memory is claim_type='plan' and another is 'verified_fact' on the
       same subject (the plan is stale)
    3. One memory has valid_until < now() (explicitly expired)

    Resolution strategy (applied to the RESULTS list, not to the DB):
    - The NEWER memory wins (by created timestamp)
    - The HIGHER claim_type wins (verified_fact > assertion > plan)
    - Losing memories get a 'contradiction_flag' field added to their dict
    - Losing memories get confidence *= 0.3 in the returned results
    - A 'contradicted_by' field is added pointing to the winning memory ID

    Returns the same results list, annotated. Does NOT mutate the DB.
    """
    if len(results) < 2:
        return results

    # Step 1: Group by topic_cluster_id (fast path)
    clusters = defaultdict(list)
    for r in results:
        tc = r.get("topic_cluster_id")
        if tc:
            clusters[tc].append(r)

    # Step 2: For ungrouped results, check claims-based subject matching
    ungrouped = [r for r in results if not r.get("topic_cluster_id")]
    if len(ungrouped) > 1 and len(ungrouped) <= 50 and db is not None:
        _group_by_shared_subjects(ungrouped, clusters, db)

    # Step 3: Within each cluster, detect contradictions
    contradictions = []
    for cluster_id, members in clusters.items():
        if len(members) < 2:
            continue
        contradictions.extend(_find_contradictions_in_cluster(members))

    # Step 4: Apply resolution — annotate losing memories
    for loser_id, winner_id, reason in contradictions:
        for r in results:
            if r.get("id") == loser_id:
                r["contradiction_flag"] = True
                r["contradicted_by"] = winner_id
                r["contradiction_reason"] = reason
                r["confidence"] = (r.get("confidence") or 0.5) * 0.3
                break

    return results


def _group_by_shared_subjects(
    ungrouped: list[dict],
    clusters: dict,
    db: sqlite3.Connection,
) -> None:
    """Group ungrouped memories by shared claim subjects.

    Queries memory_claims table to find memories that share
    subject+predicate pairs, then adds them to clusters.
    """
    memory_ids = [r.get("id") for r in ungrouped if r.get("id")]
    if not memory_ids:
        return

    placeholders = ",".join("?" * len(memory_ids))
    try:
        rows = db.execute(f"""
            SELECT mc1.memory_id AS m1, mc2.memory_id AS m2
            FROM memory_claims mc1
            JOIN memory_claims mc2
              ON mc1.subject = mc2.subject
              AND mc1.predicate = mc2.predicate
              AND mc1.memory_id != mc2.memory_id
            WHERE mc1.memory_id IN ({placeholders})
              AND mc2.memory_id IN ({placeholders})
        """, memory_ids + memory_ids).fetchall()
    except Exception as e:
        log.debug("Subject grouping query failed: %s", e)
        return

    # Build a graph of related memories, then create synthetic clusters
    id_to_mem = {r.get("id"): r for r in ungrouped}
    related = defaultdict(set)
    for row in rows:
        m1, m2 = row[0], row[1]
        related[m1].add(m2)
        related[m2].add(m1)

    # BFS to find connected components
    visited = set()
    cluster_counter = max(clusters.keys(), default=0) + 1000  # Avoid ID collision

    for mid in related:
        if mid in visited:
            continue
        # BFS
        component = set()
        queue = [mid]
        while queue:
            current = queue.pop(0)
            if current in visited:
                continue
            visited.add(current)
            component.add(current)
            for neighbor in related.get(current, set()):
                if neighbor not in visited:
                    queue.append(neighbor)

        if len(component) >= 2:
            cluster_key = f"_synthetic_{cluster_counter}"
            cluster_counter += 1
            for cid in component:
                if cid in id_to_mem:
                    clusters[cluster_key].append(id_to_mem[cid])


def _find_contradictions_in_cluster(members: list[dict]) -> list[tuple]:
    """Find contradictions within a cluster of related memories.

    Returns list of (loser_id, winner_id, reason) tuples.
    """
    contradictions = []

    # Sort by claim_type precedence DESC, then by created DESC (newest first)
    ranked = sorted(
        members,
        key=lambda m: (
            _CLAIM_PRECEDENCE.get(m.get("claim_type", "assertion"), 2),
            m.get("created", ""),
        ),
        reverse=True,
    )

    winner = ranked[0]
    for loser in ranked[1:]:
        # Case 1: plan vs verified_fact — plan is stale
        if (loser.get("claim_type") == "plan" and
                winner.get("claim_type") == "verified_fact"):
            contradictions.append((
                loser.get("id"), winner.get("id"),
                f"Plan superseded by verified fact (memory {winner.get('id')})"
            ))
            continue

        # Case 2: Lower epistemic authority
        loser_prec = _CLAIM_PRECEDENCE.get(loser.get("claim_type", "assertion"), 2)
        winner_prec = _CLAIM_PRECEDENCE.get(winner.get("claim_type", "assertion"), 2)
        if loser_prec < winner_prec:
            contradictions.append((
                loser.get("id"), winner.get("id"),
                f"Lower epistemic authority ({loser.get('claim_type')} vs {winner.get('claim_type')})"
            ))
            continue

        # Case 3: Same claim_type — newer wins, but only if content contradicts
        if loser.get("created", "") < winner.get("created", ""):
            if _detect_content_contradiction(
                winner.get("content", ""), loser.get("content", "")
            ):
                contradictions.append((
                    loser.get("id"), winner.get("id"),
                    f"Older memory contradicted by newer memory {winner.get('id')}"
                ))

    return contradictions


def _detect_content_contradiction(new_content: str, old_content: str) -> bool:
    """Check if new content contradicts old content.

    Reuses the existing heuristic from aibrain_db._detect_contradiction.
    """
    try:
        from aibrain_db import _detect_contradiction
        return _detect_contradiction(new_content, old_content)
    except ImportError:
        # Fallback: simple keyword check
        new_lower = new_content.lower()
        signals = [
            "no longer", "not anymore", "deprecated", "replaced",
            "instead of", "migrated from", "switched from", "removed",
            "actually", "correction:", "wrong", "incorrect", "false",
            "outdated", "stale", "obsolete",
        ]
        return any(s in new_lower for s in signals)
