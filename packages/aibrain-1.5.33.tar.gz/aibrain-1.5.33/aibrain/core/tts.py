"""
aibrain/core/tts.py — Kokoro TTS integration (optional dependency).

Usage:
    from aibrain.core.tts import speak
    speak("Hello Decker")
    speak("Processing complete", voice="af_heart", speed=1.0)

Install TTS support:
    pip install aibrain[tts]
    # or: pip install kokoro-onnx sounddevice

If kokoro-onnx is not installed, speak() is a no-op that prints a one-time
warning. The rest of aibrain is unaffected — TTS is always optional.

Voices (kokoro-onnx):
    af_heart (default), af_bella, af_sarah, am_adam, am_michael,
    bf_emma, bf_isabella, bm_george, bm_lewis
"""
from __future__ import annotations

import hashlib
import time
import warnings
from typing import Optional

# ---------------------------------------------------------------------------
# Optional import — graceful no-op if kokoro-onnx not installed
# ---------------------------------------------------------------------------

_KOKORO_AVAILABLE = False
_KOKORO_WARNED = False

try:
    from kokoro_onnx import Kokoro as _Kokoro          # type: ignore[import]
    _KOKORO_AVAILABLE = True
except ImportError:
    pass

# ---------------------------------------------------------------------------
# Simple in-process cache: (text_hash, voice) -> (generated_at, samples, rate)
# Entries expire after 60 seconds so hot loops don't re-synthesise.
# ---------------------------------------------------------------------------

_cache: dict[str, tuple[float, object, int]] = {}
_CACHE_TTL = 60.0   # seconds

# Single lazy-loaded Kokoro instance — created on first speak() call.
_kokoro_instance: Optional[object] = None


def _get_kokoro():
    global _kokoro_instance
    if _kokoro_instance is None and _KOKORO_AVAILABLE:
        _kokoro_instance = _Kokoro("kokoro-v1.0.onnx", "voices-v1.0.bin")  # type: ignore[operator]
    return _kokoro_instance


def _play(samples, sample_rate: int) -> None:
    """Play audio samples via sounddevice (preferred) or scipy fallback."""
    try:
        import sounddevice as sd      # type: ignore[import]
        sd.play(samples, samplerate=sample_rate, blocking=True)
        return
    except ImportError:
        pass
    # scipy.io.wavfile fallback — write tmp file, open with default player
    try:
        import tempfile
        import subprocess
        import scipy.io.wavfile as _wav  # type: ignore[import]
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            tmp = f.name
        _wav.write(tmp, sample_rate, samples)
        # Windows: start /min opens silently
        subprocess.Popen(
            ["cmd", "/c", "start", "/min", "", tmp],
            creationflags=0x08000000,
        )
    except Exception as exc:
        warnings.warn(f"[tts] audio playback failed: {exc}", stacklevel=3)


def speak(text: str, voice: str = "af_heart", speed: float = 1.0) -> None:
    """Synthesise `text` with Kokoro TTS and play through speakers.

    No-op (with one-time warning) if kokoro-onnx is not installed.
    Cached: calling speak() with the same text within 60 seconds replays
    the cached audio without re-synthesising.

    Args:
        text:  Text to speak.
        voice: Kokoro voice name (default "af_heart").
        speed: Playback speed multiplier (default 1.0).
    """
    global _KOKORO_WARNED

    if not text or not text.strip():
        return

    if not _KOKORO_AVAILABLE:
        if not _KOKORO_WARNED:
            warnings.warn(
                "[tts] kokoro-onnx not installed — speak() is a no-op. "
                "Install with: pip install aibrain[tts]",
                stacklevel=2,
            )
            _KOKORO_WARNED = True
        return

    cache_key = hashlib.sha1(f"{text}:{voice}:{speed}".encode()).hexdigest()
    now = time.monotonic()
    if cache_key in _cache:
        generated_at, samples, rate = _cache[cache_key]
        if now - generated_at < _CACHE_TTL:
            _play(samples, rate)
            return

    kokoro = _get_kokoro()
    if kokoro is None:
        return

    try:
        samples, sample_rate = kokoro.create(text, voice=voice, speed=speed)  # type: ignore[operator]
        _cache[cache_key] = (now, samples, sample_rate)
        _play(samples, sample_rate)
    except Exception as exc:
        warnings.warn(f"[tts] synthesis failed: {exc}", stacklevel=2)


__all__ = ["speak"]
