"""Content pre-publish gate stack — 13 hard gates for autonomous content publishing.

See project_content_agent_tiered_delay_decision.md for the authoritative spec.
Every draft produced by content_intel_agent must pass all 13 gates before
entering the tiered delay queue. Gate failure = reject to review queue; a
rejected draft NEVER reaches auto-publishing.

Gate 13 (myaibrain.org URL required) was added 2026-04-11 per a direct
Decker directive: every public post must carry the myaibrain.org URL so
the discipline layer, not the author, enforces the link-back rule.

Each gate returns a GateResult with clear pass/fail + evidence. Every decision
is logged to execution_log (entity_type='comms_agent_gate') so the dashboard
can surface the full gate history for any draft.

Design notes
------------
* Pure gates — this module does NO outbound I/O beyond audit logging. No
  posting, no telegram, no SMTP. The scheduler module calls run_all_gates()
  and makes the publish/reject decision.
* Early-exit on first failure. Gates are ordered cheapest-first so hard
  rejects bail out before we burn cycles on the SuperWorker gate.
* Every gate provides structured evidence in GateResult.evidence so audit
  rows are readable when something goes wrong.
* Wordlist sources are single-truth where possible: the Shadow Board names
  for the internal-reference gate are loaded from the same constant the
  public-leak test uses (tests/test_lens_router.py SHADOW_BOARD_NAMES), so
  we can never drift out of sync with the wheel-leak guard.
"""
from __future__ import annotations

import json
import re
import secrets
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable, Literal, Optional

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class GateResult:
    """Result of a single gate evaluation."""

    gate_name: str
    passed: bool
    reason: str | None = None
    evidence: dict | None = None  # structured context for audit log


@dataclass
class DraftContent:
    """The draft under review."""

    draft_id: str
    tier: Literal["T1", "T2", "T3"]
    title: str | None
    body: str
    platform: str  # twitter, linkedin, reddit, etc.
    author: str = "content_intel_agent"
    metadata: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Wordlists / patterns — single source of truth lives here so every gate can
# share them and tests can import them directly.
# ---------------------------------------------------------------------------


COMPETITOR_WORDS: list[str] = [
    "SuperLocalMemory", "SLM", "Mem0", "Letta", "MemGPT",
    "Zep", "Cognee", "Hindsight", "Vectorize",
    "Cursor", "Claude Code", "Claude.ai", "Qwen Code", "QwenCode",
    "OpenDevin", "Devin", "Cline", "Continue", "Aider",
    "ChatGPT", "OpenAI", "Anthropic",
    "PentAGI", "HexStrike",
    "SWE-Agent", "MetaGPT", "CrewAI", "AutoGen",
]

# Base list — Shadow Board names are appended at import time from the
# test_lens_router constant so we don't fork the wordlist.
_INTERNAL_WORDS_BASE: list[str] = [
    "Wintermute", "Remediate", "Permeate", "Rogue", "Paragon",
    "DeckerOps", "Decker", "Neuro", "Case",
    "SuperWorker", "intel_agent", "communications_agent",
    "Shadow Board", "Decker System",
    "Entity A", "Entity B", "Entity C", "Entity D", "Entity E",
    "Entity F", "Entity G", "Entity H", "Entity I",
    "decker.ops", "sindecker",
    "chat_id", "broker_token", "telegram_token",
]


def _load_shadow_board_names() -> list[str]:
    """Pull Shadow Board persona names from tests/test_lens_router.py.

    Reads the SHADOW_BOARD_NAMES constant directly rather than importing the
    test module (which would pull pytest into every runtime). On failure we
    return an empty list — the base wordlist still enforces the internal name
    block so this is a best-effort enrichment.
    """
    try:
        repo_root = Path(__file__).resolve().parents[2]
        test_file = repo_root / "tests" / "test_lens_router.py"
        if not test_file.exists():
            return []
        text = test_file.read_text(encoding="utf-8")
        # Extract the SHADOW_BOARD_NAMES = [...] literal and eval it safely
        # via a regex-delimited slice passed to ast.literal_eval.
        import ast
        match = re.search(
            r"SHADOW_BOARD_NAMES\s*=\s*(\[[^\]]*\])",
            text,
            re.DOTALL,
        )
        if not match:
            return []
        return list(ast.literal_eval(match.group(1)))
    except Exception:
        return []


INTERNAL_WORDS: list[str] = _INTERNAL_WORDS_BASE + _load_shadow_board_names()


OVERCLAIM_WORDS: list[str] = [
    "best", "leading", "unprecedented", "first-ever", "revolutionary",
    "game-changing", "breakthrough", "world-class", "industry-leading",
    "state-of-the-art", "cutting-edge", "next-generation", "next-gen",
    "unmatched", "unparalleled", "groundbreaking", "paradigm-shifting",
]


# Legal risk patterns — hard-reject vs flag-only separated.
LEGAL_HARD_REJECT_PATTERNS: list[str] = [
    r"\bwill cure\b",
    r"\bguaranteed\b",
    r"\bproven to\b",
    r"\breturn on investment\b",
    r"\bfinancial advice\b",
    r"\blegal advice\b",
]

LEGAL_FLAG_ONLY_PATTERNS: list[str] = [
    r"\bmedical\b",
    r"\bhealth\b",
    r"\btreat\b",
    r"\bdiagnos",
    r"\binvest\b",
    r"\btax\b",
]


# Forward-looking promise detection — a date-adjacent verb is a commitment.
PROMISE_VERBS = r"(?:launching|rolling out|shipping|releasing|available|coming|dropping|live)"
DATE_TOKENS = (
    r"(?:next\s+(?:week|month|year|quarter|monday|tuesday|wednesday|thursday|friday|saturday|sunday)"
    r"|(?:this|next)\s+(?:week|month|year|quarter)"
    r"|by\s+\w+"
    r"|in\s+\d+\s+(?:days?|weeks?|months?|years?)"
    r"|q[1-4]"
    r"|\d{1,2}/\d{1,2}"
    r"|\d{4}-\d{2}-\d{2})"
)
PROMISE_REGEX = re.compile(
    rf"\b{PROMISE_VERBS}\b[^.]*?{DATE_TOKENS}|{DATE_TOKENS}[^.]*?\b{PROMISE_VERBS}\b",
    re.IGNORECASE,
)


# Overclaim / quiet numbers — counts that are known stale and must never
# appear unless the draft sources the corrected figures. Pulled from
# fact_audit_apr11_corrections.md.
STALE_OVERCLAIM_NUMBERS: dict[str, str] = {
    "240 workflows": "use corrected workflow count from fact_audit_apr11_corrections.md",
    "85 skills": "use corrected skill count from fact_audit_apr11_corrections.md",
    "20 agents": "qualify 'agents' — persona roster vs runtime agents differ",
}


# Scope classifier signals
SCOPE_WHITELIST = [
    "ai", "memory", "agent", "agents", "llm", "llms", "brain", "consolidation",
    "retrieval", "benchmark", "routing", "router", "embedding", "vector",
    "context", "reasoning", "tool use", "skill", "workflow", "prompt",
    "rag", "fine-tune", "model", "inference", "evaluation", "eval",
    "automation", "coding", "developer", "cli",
]
SCOPE_BLACKLIST = [
    "politics", "election", "republican", "democrat", "celebrity",
    "sport", "sports", "nba", "nfl", "soccer", "weather", "royal",
    "kardashian",
]


# Quiet gate — topics the agent may not discuss publicly.
QUIET_PATTERNS: list[str] = [
    r"\bwe\s+are\s+building\b", r"\bwe're\s+building\b", r"\bworking\s+on\b",
    r"\bcoming\s+soon\b", r"\broadmap\b",
    r"\brevenue\b", r"\bmrr\b", r"\barr\b", r"\bburn\s+rate\b", r"\brunway\b",
    r"\bfunding\b", r"\bfundraise\b", r"\bvaluation\b",
    r"\bemployees?\b", r"\bhires?\b", r"\bteam\s+size\b",
    r"\b(?:our|paying)\s+customers?\b", r"\bcustomer\s+count\b",
    r"\bbirthday\b", r"\baddress\b",
]


# Rate limits
MAX_POSTS_PER_PLATFORM_PER_DAY = 3
MAX_POSTS_TOTAL_PER_DAY = 10


# Memory files root (Neuro's persistent memory directory).
# Cross-host portability: resolved via ``aibrain.core.paths`` so Case on Kali
# picks up its own HOME-relative layout instead of the hardcoded Windows path
# the gate used previously. ``try_resolve_memory_dir`` returns None when no
# candidate resolves — the hold-flag gate treats that as a graceful skip, same
# as the prior "memory root unavailable" branch. Existing tests monkeypatch
# this module attribute directly, so it stays a module-level binding.
from aibrain.core.paths import try_resolve_memory_dir as _try_resolve_memory_dir

MEMORY_ROOT: Optional[Path] = _try_resolve_memory_dir()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _word_boundary_regex(words: list[str]) -> re.Pattern[str]:
    """Build a case-insensitive alternation with proper word boundaries.

    We sort by length descending so "Claude Code" is tried before "Claude".
    Regex-escape each word; wrap with \b on both sides so substrings inside
    larger words don't match (e.g. "autogen" inside "autogenerate").
    """
    sorted_words = sorted(words, key=len, reverse=True)
    pattern = r"\b(?:" + "|".join(re.escape(w) for w in sorted_words) + r")\b"
    return re.compile(pattern, re.IGNORECASE)


_COMPETITOR_REGEX = _word_boundary_regex(COMPETITOR_WORDS)
_INTERNAL_REGEX = _word_boundary_regex(INTERNAL_WORDS)
_OVERCLAIM_REGEX = _word_boundary_regex(OVERCLAIM_WORDS)


def _line_of(body: str, pos: int) -> str:
    """Return the line of text containing char position `pos`."""
    start = body.rfind("\n", 0, pos) + 1
    end = body.find("\n", pos)
    if end == -1:
        end = len(body)
    return body[start:end].strip()


# ---------------------------------------------------------------------------
# The 13 gates
# ---------------------------------------------------------------------------


def check_rate_limit_gate(draft: DraftContent) -> GateResult:
    """Gate 1 (cheapest): enforce 3/platform/day and 10/total/day caps.

    This is a TIMING reject rather than a content reject — the caller can
    re-queue the draft for tomorrow's window. We still return passed=False
    so the draft doesn't proceed through the rest of the pipeline this cycle.
    """
    try:
        db_path = _resolve_db_path()
        if db_path is None or not db_path.exists():
            return GateResult(
                gate_name="rate_limit",
                passed=True,
                reason="no execution_log yet — nothing to count",
                evidence={"platform_count": 0, "total_count": 0},
            )
        since = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
        db = sqlite3.connect(str(db_path))
        # Count published posts (successful comms_agent_publish rows) per
        # platform and total in the last 24h.
        cur = db.execute(
            """
            SELECT detail FROM execution_log
            WHERE action = 'comms_agent_publish'
              AND success = 1
              AND created_at >= ?
            """,
            (since,),
        )
        total = 0
        platform_count = 0
        for (detail,) in cur.fetchall():
            total += 1
            try:
                parsed = json.loads(detail) if detail else {}
                if parsed.get("platform") == draft.platform:
                    platform_count += 1
            except (ValueError, TypeError):
                pass
        db.close()
    except Exception as e:
        return GateResult(
            gate_name="rate_limit",
            passed=False,
            reason=f"rate limit query failed: {e}",
            evidence={"error": str(e)},
        )

    if platform_count >= MAX_POSTS_PER_PLATFORM_PER_DAY:
        return GateResult(
            gate_name="rate_limit",
            passed=False,
            reason=(
                f"{draft.platform} already has {platform_count} posts in the "
                f"last 24h (cap: {MAX_POSTS_PER_PLATFORM_PER_DAY}) — delay to tomorrow"
            ),
            evidence={
                "platform_count": platform_count,
                "total_count": total,
                "cap": MAX_POSTS_PER_PLATFORM_PER_DAY,
                "reject_type": "timing",
            },
        )
    if total >= MAX_POSTS_TOTAL_PER_DAY:
        return GateResult(
            gate_name="rate_limit",
            passed=False,
            reason=(
                f"total posts in last 24h = {total} (cap: {MAX_POSTS_TOTAL_PER_DAY}) "
                "— delay to tomorrow"
            ),
            evidence={
                "platform_count": platform_count,
                "total_count": total,
                "cap": MAX_POSTS_TOTAL_PER_DAY,
                "reject_type": "timing",
            },
        )
    return GateResult(
        gate_name="rate_limit",
        passed=True,
        evidence={"platform_count": platform_count, "total_count": total},
    )


def check_competitor_name_gate(draft: DraftContent) -> GateResult:
    """Gate 2: hard-reject any word-boundary competitor match."""
    match = _COMPETITOR_REGEX.search(draft.body)
    if match:
        return GateResult(
            gate_name="competitor_name",
            passed=False,
            reason=f"competitor term: {match.group(0)!r}",
            evidence={
                "matched": match.group(0),
                "context": _line_of(draft.body, match.start()),
            },
        )
    return GateResult(gate_name="competitor_name", passed=True)


def check_internal_reference_gate(draft: DraftContent) -> GateResult:
    """Gate 3: hard-reject internal names (products, personas, persons)."""
    match = _INTERNAL_REGEX.search(draft.body)
    if match:
        return GateResult(
            gate_name="internal_reference",
            passed=False,
            reason=f"internal term: {match.group(0)!r}",
            evidence={
                "matched": match.group(0),
                "context": _line_of(draft.body, match.start()),
            },
        )
    return GateResult(gate_name="internal_reference", passed=True)


def check_overclaim_language_gate(draft: DraftContent) -> GateResult:
    """Gate 4: word-boundary reject on marketing fluff."""
    matches = _OVERCLAIM_REGEX.findall(draft.body)
    if matches:
        return GateResult(
            gate_name="overclaim_language",
            passed=False,
            reason=f"overclaim words: {matches}",
            evidence={"matches": matches},
        )
    return GateResult(gate_name="overclaim_language", passed=True)


def check_legal_gate(draft: DraftContent) -> GateResult:
    """Gate 5: hard-reject medical/financial/legal certainty claims.

    Hard-reject patterns immediately fail the gate. Flag-only patterns are
    recorded as evidence but do not block — they surface in the audit row
    so Decker can review which drafts touched sensitive domain words.
    """
    hard_hits = []
    for pat in LEGAL_HARD_REJECT_PATTERNS:
        m = re.search(pat, draft.body, re.IGNORECASE)
        if m:
            hard_hits.append(m.group(0))

    flag_hits = []
    for pat in LEGAL_FLAG_ONLY_PATTERNS:
        m = re.search(pat, draft.body, re.IGNORECASE)
        if m:
            flag_hits.append(m.group(0))

    if hard_hits:
        return GateResult(
            gate_name="legal",
            passed=False,
            reason=f"legal hard-reject: {hard_hits}",
            evidence={"hard": hard_hits, "flag_only": flag_hits},
        )
    return GateResult(
        gate_name="legal",
        passed=True,
        evidence={"flag_only": flag_hits} if flag_hits else None,
    )


def check_promise_gate(draft: DraftContent) -> GateResult:
    """Gate 6: forward-looking date commitment without explicit authorization."""
    commitments = set(draft.metadata.get("public_commitments") or [])
    for m in PROMISE_REGEX.finditer(draft.body):
        fragment = m.group(0).strip()
        if not any(c.lower() in fragment.lower() for c in commitments):
            return GateResult(
                gate_name="promise",
                passed=False,
                reason=f"unauthorized date commitment: {fragment!r}",
                evidence={
                    "match": fragment,
                    "authorized": sorted(commitments),
                },
            )
    return GateResult(gate_name="promise", passed=True)


def check_hold_flag_gate(draft: DraftContent) -> GateResult:
    """Gate 7: active hold markers in memory files block matching topics.

    Scans MEMORY_ROOT for files matching project_*_hold.md or
    feedback_*_delay.md patterns. If any hold file's filename shares a
    non-trivial token with the draft title or body, reject. Non-trivial =
    tokens >= 4 chars, skip common stopwords.
    """
    if MEMORY_ROOT is None or not MEMORY_ROOT.exists():
        return GateResult(
            gate_name="hold_flag",
            passed=True,
            reason="memory root unavailable — skipping hold scan",
        )
    hold_files = list(MEMORY_ROOT.glob("project_*_hold.md")) + list(
        MEMORY_ROOT.glob("feedback_*_delay.md")
    )
    if not hold_files:
        return GateResult(gate_name="hold_flag", passed=True, evidence={"hold_files": 0})

    body_lower = (draft.body + " " + (draft.title or "")).lower()
    stopwords = {
        "project", "feedback", "hold", "delay", "the", "and", "for",
        "with", "from", "this", "that",
    }
    for hf in hold_files:
        stem_tokens = [
            t for t in re.split(r"[_\-]", hf.stem.lower())
            if len(t) >= 4 and t not in stopwords
        ]
        matched = [t for t in stem_tokens if t in body_lower]
        if matched:
            return GateResult(
                gate_name="hold_flag",
                passed=False,
                reason=f"active hold matches draft: {hf.name} (tokens={matched})",
                evidence={"hold_file": hf.name, "matched_tokens": matched},
            )
    return GateResult(
        gate_name="hold_flag",
        passed=True,
        evidence={"hold_files": len(hold_files)},
    )


def check_scope_gate(draft: DraftContent) -> GateResult:
    """Gate 8: content must sit inside the AIBrain topic envelope."""
    body_lower = draft.body.lower()
    whitelist_hits = [w for w in SCOPE_WHITELIST if re.search(rf"\b{re.escape(w)}\b", body_lower)]
    blacklist_hits = [w for w in SCOPE_BLACKLIST if re.search(rf"\b{re.escape(w)}\b", body_lower)]

    if blacklist_hits:
        return GateResult(
            gate_name="scope",
            passed=False,
            reason=f"off-scope blacklist hit: {blacklist_hits}",
            evidence={"whitelist": whitelist_hits, "blacklist": blacklist_hits},
        )
    if not whitelist_hits:
        return GateResult(
            gate_name="scope",
            passed=False,
            reason="no whitelist signal — draft topic unclear",
            evidence={"whitelist": [], "blacklist": []},
        )
    return GateResult(
        gate_name="scope",
        passed=True,
        evidence={"whitelist": whitelist_hits},
    )


def check_quiet_gate(draft: DraftContent) -> GateResult:
    """Gate 9: silence on finances, internal state, customers, personal info."""
    hits: list[str] = []
    for pat in QUIET_PATTERNS:
        m = re.search(pat, draft.body, re.IGNORECASE)
        if m:
            hits.append(m.group(0))
    # Also hard-reject any specific customer count claim.
    if re.search(r"\b\d+\s+(?:paying|active|real)?\s*customers?\b", draft.body, re.IGNORECASE):
        hits.append("specific customer count")
    if hits:
        return GateResult(
            gate_name="quiet",
            passed=False,
            reason=f"quiet-topic hits: {hits}",
            evidence={"matches": hits},
        )
    return GateResult(gate_name="quiet", passed=True)


def check_myaibrain_url_present(draft: DraftContent) -> GateResult:
    """Gate 13 (Decker 2026-04-11 directive): every public post must
    contain the myaibrain.org URL.

    Case-insensitive literal-substring check. URLs do NOT sit on word
    boundaries (dot is not a word character), so a word-boundary regex
    would false-reject real links — we check for ``"myaibrain.org"`` as
    a raw substring instead.

    Position: gate 10 in the 13-gate pipeline. Cheap string check, so it
    runs before the expensive numbers / factual / superworker gates and
    short-circuits ~all "forgot the URL" drafts before we burn cycles on
    claim verification.
    """
    if "myaibrain.org" in draft.body.lower():
        return GateResult(
            gate_name="myaibrain_url_present",
            passed=True,
            reason="myaibrain.org URL present",
        )
    return GateResult(
        gate_name="myaibrain_url_present",
        passed=False,
        reason=(
            "missing myaibrain.org URL — every public post must include "
            "it per Decker 2026-04-11 directive"
        ),
        evidence={"body_preview": draft.body[:200]},
    )


def check_numbers_gate(draft: DraftContent) -> GateResult:
    """Gate 10: every non-metadata number must trace to a sourced fact.

    Numbers that are dates, versions, or listed in metadata['sources'] /
    metadata['sourced_numbers'] pass. Anything else is rejected as an
    unsourced claim. Also rejects explicit stale-overclaim phrases.
    """
    # Block the known stale overclaim counts unless the metadata explicitly
    # acknowledges the corrected source file.
    corrections_ack = draft.metadata.get("corrections_ack") or []
    for phrase in STALE_OVERCLAIM_NUMBERS:
        if re.search(rf"\b{re.escape(phrase)}\b", draft.body, re.IGNORECASE):
            if "fact_audit_apr11_corrections.md" not in corrections_ack:
                return GateResult(
                    gate_name="numbers",
                    passed=False,
                    reason=f"stale overclaim: {phrase!r}",
                    evidence={
                        "stale_phrase": phrase,
                        "fix": STALE_OVERCLAIM_NUMBERS[phrase],
                    },
                )

    sourced = set(
        str(n) for n in (draft.metadata.get("sourced_numbers") or [])
    )
    sources = draft.metadata.get("sources") or []
    has_any_source = bool(sources)

    unsourced: list[str] = []
    # Regex: integer or decimal, with optional % or x suffix for stats
    for m in re.finditer(r"\b(\d+(?:\.\d+)?)(%|x\b|\s*x\s)?", draft.body):
        num = m.group(1)
        suffix = (m.group(2) or "").strip()
        full = num + (suffix if suffix else "")
        # Allow year-looking numbers (4-digit 19xx/20xx) and semver-looking
        if re.match(r"^(19|20)\d{2}$", num):
            continue
        # Version-like context: look for "v" prefix or ".X" in surrounding text
        ctx_start = max(0, m.start() - 3)
        ctx = draft.body[ctx_start:m.end() + 2]
        if re.search(r"v\d|\d+\.\d+\.\d+", ctx):
            continue
        if num in sourced or full in sourced:
            continue
        # If a percentage/multiplier stat and no sources provided, reject.
        if suffix in ("%", "x") or suffix.endswith("x"):
            if num not in sourced and full not in sourced:
                unsourced.append(full)
                continue
        # For plain integers, require a source list to exist OR the number
        # to be whitelisted.
        if not has_any_source and int(float(num)) >= 2:
            # Allow "1" and "0" as trivial references; block specific counts.
            unsourced.append(full)

    if unsourced:
        return GateResult(
            gate_name="numbers",
            passed=False,
            reason=f"unsourced numbers: {unsourced}",
            evidence={"unsourced": unsourced, "sources": sources},
        )
    return GateResult(gate_name="numbers", passed=True)


def check_factual_gate(draft: DraftContent) -> GateResult:
    """Gate 11: every specific claim cites a memory file OR metadata source.

    Heuristic: a "specific claim" is a sentence containing a number, a
    proper noun (single capitalized token not at sentence start), or a
    fact-marker phrase ("according to", "research shows", "studies find").
    If any such sentence exists, metadata['sources'] must be a non-empty
    list of file paths. Otherwise the draft is treated as non-specific
    (opinion / how-to) and passes.
    """
    fact_markers = [
        r"according to", r"research shows", r"studies find",
        r"data shows", r"\d+%", r"\d+x ",
    ]
    body = draft.body
    has_specific_claim = any(
        re.search(pat, body, re.IGNORECASE) for pat in fact_markers
    )
    if not has_specific_claim:
        return GateResult(
            gate_name="factual",
            passed=True,
            evidence={"mode": "opinion/how-to, no specific claims detected"},
        )
    sources = draft.metadata.get("sources") or []
    if not sources:
        return GateResult(
            gate_name="factual",
            passed=False,
            reason="specific claim present but metadata['sources'] is empty",
            evidence={"requires": "memory file path(s) or cited source"},
        )
    return GateResult(
        gate_name="factual",
        passed=True,
        evidence={"source_count": len(sources)},
    )


def check_superworker_review_gate(draft: DraftContent) -> GateResult:
    """Gate 12 (most expensive): multi-lens review, majority vote.

    Tries to import and call the SuperWorker synthesis persona. If that
    isn't available (yet — SuperWorker is in a separate build lane), fall
    back to a deterministic multi-lens heuristic that scores accuracy,
    tone, risk, positioning_fit, and brand_voice. This fallback is
    intentionally conservative: any lens raising a hard-rule violation
    kills the gate.

    Majority rule: >=3 of 5 lenses must vote pass for the gate to pass.
    """
    lens_names = ["accuracy", "tone", "risk", "positioning_fit", "brand_voice"]

    # Attempt to route to the real SuperWorker persona first.
    try:
        from aibrain.core import superworker  # type: ignore[attr-defined]
        if hasattr(superworker, "review_draft"):
            result = superworker.review_draft(draft, lenses=lens_names)
            return GateResult(
                gate_name="superworker_review",
                passed=bool(result.get("passed")),
                reason=result.get("reason"),
                evidence={"source": "superworker", "votes": result.get("votes")},
            )
    except Exception:
        # Fall-through to heuristic below
        pass

    # Deterministic fallback — per-lens pass/fail signal
    votes: dict[str, bool] = {}
    notes: dict[str, str] = {}

    # accuracy: penalize "always/never/every" absolute claims
    absolute_regex = re.compile(r"\b(always|never|every single|100%)\b", re.IGNORECASE)
    votes["accuracy"] = not absolute_regex.search(draft.body)
    if not votes["accuracy"]:
        notes["accuracy"] = "absolute claim detected"

    # tone: reject ALL-CAPS runs of 5+ letters and excessive exclamation marks
    has_shouting = bool(re.search(r"\b[A-Z]{5,}\b", draft.body))
    excess_excl = draft.body.count("!") > 2
    votes["tone"] = not (has_shouting or excess_excl)
    if not votes["tone"]:
        notes["tone"] = "shouting or excessive exclamation"

    # risk: re-check competitor & internal names (belt-and-braces)
    has_comp = bool(_COMPETITOR_REGEX.search(draft.body))
    has_internal = bool(_INTERNAL_REGEX.search(draft.body))
    votes["risk"] = not (has_comp or has_internal)
    if not votes["risk"]:
        notes["risk"] = "competitor/internal term slipped past earlier gate"

    # positioning_fit: require at least one scope whitelist token
    body_lower = draft.body.lower()
    has_scope = any(
        re.search(rf"\b{re.escape(w)}\b", body_lower) for w in SCOPE_WHITELIST
    )
    votes["positioning_fit"] = has_scope
    if not has_scope:
        notes["positioning_fit"] = "no AIBrain-category signal"

    # brand_voice: overclaim words already block; also flag filler openers
    filler = re.compile(r"^\s*(hey\s+everyone|huge news|big announcement)", re.IGNORECASE)
    votes["brand_voice"] = not filler.match(draft.body)
    if not votes["brand_voice"]:
        notes["brand_voice"] = "filler opener"

    passes = sum(1 for v in votes.values() if v)
    # Per spec: "Any single lens flagging a hard-rule violation = hard reject."
    # In the fallback, every lens represents a hard rule (accuracy/tone/risk/
    # positioning_fit/brand_voice) so any failure kills the gate. Majority
    # logic only matters when the real SuperWorker LLM runs and lenses can
    # vote on judgment calls — the deterministic fallback is strict-all.
    if passes < len(lens_names):
        return GateResult(
            gate_name="superworker_review",
            passed=False,
            reason=f"hard-rule lens failure: {notes}",
            evidence={"source": "fallback", "votes": votes, "notes": notes},
        )
    return GateResult(
        gate_name="superworker_review",
        passed=True,
        evidence={"source": "fallback", "votes": votes, "passes": passes},
    )


# ---------------------------------------------------------------------------
# Gate 14 — template freshness
# ---------------------------------------------------------------------------
#
# Added 2026-04-12. Blocks any draft that either:
#   (a) contains a known stale numeric/version claim (v1.2.4, "200 workflows",
#       "869 tests", "45 dashboard pages", etc.), or
#   (b) still contains unresolved {{template.variables}} that the publish-time
#       renderer was meant to resolve.
#
# Suggested replacements come from aibrain_live_truth_v1_4_0.md via
# content_template._build_resolver_map — the same source of truth the renderer
# uses, so gate and renderer cannot drift.

# (pattern, suggestion-key, human description) — suggestion-key maps into the
# live-truth resolver. If the resolver can't answer, we fall back to the
# description text in the violation message.
_STALE_PATTERNS: list[tuple[str, str, str]] = [
    (r"\bv1\.2\.4\b", "aibrain.version", "stale version v1.2.4"),
    (r"\bv1\.3(?:\.\d+)?\b", "aibrain.version", "stale version v1.3.x"),
    (r"200\+?\s*workflows", "aibrain.workflow_count", "stale '200 workflows' claim"),
    (r"240\s*workflows", "aibrain.workflow_count", "stale '240 workflows' claim"),
    (r"\b869\s*tests?\b", "aibrain.test_count", "stale '869 tests' claim"),
    (r"\b45\+?\s*dashboard\s*pages?\b", "aibrain.dashboard_pages", "stale '45 dashboard pages' claim"),
    (r"\b45-page\s*dashboard\b", "aibrain.dashboard_pages", "stale '45-page dashboard' claim"),
    (r"What's New in v1\.2\.4", "features.whatsnew_header", "stale 'What's New in v1.2.4' header"),
]


def _compile_stale_patterns() -> list[tuple[re.Pattern[str], str, str]]:
    return [(re.compile(p, re.IGNORECASE), k, d) for p, k, d in _STALE_PATTERNS]


_STALE_COMPILED: list[tuple[re.Pattern[str], str, str]] = _compile_stale_patterns()
_UNRESOLVED_VAR_RE = re.compile(r"\{\{\s*([a-zA-Z_][\w.]*)\s*\}\}")


def check_template_freshness_gate(draft: DraftContent) -> GateResult:
    """Gate 14 — reject content with stale claims or unresolved template vars.

    Pulls replacement suggestions from the same live-truth doc the renderer
    uses. If the truth doc is unreadable, the gate is fail-closed: no draft
    may publish without freshness verification.
    """
    try:
        from aibrain.core.content_template import _build_resolver_map, DEFAULT_TRUTH_DOC
        resolver = _build_resolver_map(DEFAULT_TRUTH_DOC)
        truth_doc = str(DEFAULT_TRUTH_DOC)
    except Exception as e:
        return GateResult(
            gate_name="template_freshness",
            passed=False,
            reason=f"truth doc unreadable — fail-closed: {e}",
            evidence={"error": type(e).__name__},
        )

    violations: list[dict] = []

    for pat, key, description in _STALE_COMPILED:
        for m in pat.finditer(draft.body):
            line_no = draft.body.count("\n", 0, m.start()) + 1
            violations.append({
                "type": "stale_claim",
                "pattern": description,
                "match": m.group(0),
                "line": line_no,
                "suggested_replacement": resolver.get(key, "<see live truth doc>"),
                "template_variable": f"{{{{{key}}}}}",
            })

    for m in _UNRESOLVED_VAR_RE.finditer(draft.body):
        var_name = m.group(1)
        line_no = draft.body.count("\n", 0, m.start()) + 1
        violations.append({
            "type": "unresolved_template_variable",
            "variable": var_name,
            "line": line_no,
            "match": m.group(0),
            "fix": "render content through aibrain.core.content_template.render() before publish",
        })

    if violations:
        first = violations[0]
        reason = (
            f"{len(violations)} freshness violation(s): "
            f"first={first['type']} line {first['line']}"
        )
        return GateResult(
            gate_name="template_freshness",
            passed=False,
            reason=reason,
            evidence={"violations": violations, "truth_doc": truth_doc},
        )

    return GateResult(
        gate_name="template_freshness",
        passed=True,
        evidence={"truth_doc": truth_doc, "checked_patterns": len(_STALE_COMPILED)},
    )


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------


GATE_PIPELINE: list[Callable[[DraftContent], GateResult]] = [
    check_rate_limit_gate,           # cheapest — rate check first
    check_competitor_name_gate,      # fast grep
    check_internal_reference_gate,   # fast grep
    check_overclaim_language_gate,   # fast grep
    check_legal_gate,                # fast regex
    check_promise_gate,              # fast regex
    check_hold_flag_gate,            # file-system glob
    check_scope_gate,                # topic classifier
    check_quiet_gate,                # wordlist + classifier
    check_myaibrain_url_present,     # gate 13 — cheap substring check, short-circuits before expensive gates
    check_template_freshness_gate,   # gate 14 — stale-claim + unresolved-variable check
    check_numbers_gate,              # source verification
    check_factual_gate,              # deeper claim check
    check_superworker_review_gate,   # most expensive — last
]


def run_all_gates(draft: DraftContent) -> list[GateResult]:
    """Run every gate in order; early-exit on the first failure.

    Every gate decision is logged to execution_log via _log_gate_decision.
    Returns the full list of GateResult rows evaluated so far (including the
    failing one, if any).
    """
    results: list[GateResult] = []
    for gate_fn in GATE_PIPELINE:
        try:
            result = gate_fn(draft)
        except Exception as e:
            # An unhandled exception is an automatic HARD STOP per the spec.
            # Never let the pipeline fall through to publish on an error.
            result = GateResult(
                gate_name=getattr(gate_fn, "__name__", "unknown"),
                passed=False,
                reason=f"gate raised exception: {e}",
                evidence={"exception_type": type(e).__name__},
            )
        results.append(result)
        _log_gate_decision(draft, result)
        if not result.passed:
            break
    return results


def all_passed(results: list[GateResult]) -> bool:
    """True iff every gate in the pipeline passed."""
    return len(results) == len(GATE_PIPELINE) and all(r.passed for r in results)


# ---------------------------------------------------------------------------
# Audit logging — Bug #6 compliant via harness._get_or_create_db
# ---------------------------------------------------------------------------


def _resolve_db_path() -> Path | None:
    """Return the aibrain.db path without forcing creation.

    Used by check_rate_limit_gate which just needs to read. If the DB doesn't
    exist yet there's nothing to count — treat as zero.
    """
    try:
        from aibrain_db import AIBRAIN_ROOT
        return AIBRAIN_ROOT / "aibrain.db"
    except Exception:
        return None


def _log_gate_decision(draft: DraftContent, result: GateResult) -> None:
    """Persist one gate decision to execution_log.

    Uses the same schema and _get_or_create_db path as harness._log_audit so
    the gate history shows up alongside regular harness rows for the
    dashboard. entity_type='comms_agent_gate', entity_id=draft_id, action
    is the gate name.
    """
    try:
        from aibrain.core.harness import _get_or_create_db
        db_path = _get_or_create_db()
    except Exception:
        return

    try:
        db = sqlite3.connect(str(db_path))
        db.execute("PRAGMA journal_mode=WAL")
        db.execute(
            """
            CREATE TABLE IF NOT EXISTS execution_log (
                id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                actor TEXT NOT NULL,
                action TEXT NOT NULL,
                entity_type TEXT,
                entity_id TEXT,
                detail TEXT,
                quality_score REAL,
                self_score REAL,
                divergence REAL,
                flagged INTEGER DEFAULT 0,
                model_used TEXT,
                cost_cents INTEGER DEFAULT 0,
                cost_cents_actual INTEGER,
                cost_cents_equivalent INTEGER,
                duration_ms INTEGER DEFAULT 0,
                before_state TEXT,
                after_state TEXT,
                success INTEGER DEFAULT 0,
                error TEXT,
                task_type TEXT,
                authority TEXT,
                retries INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        detail = json.dumps(
            {
                "gate": result.gate_name,
                "passed": result.passed,
                "reason": result.reason,
                "evidence": result.evidence,
                "draft": {
                    "id": draft.draft_id,
                    "tier": draft.tier,
                    "platform": draft.platform,
                    "title": draft.title,
                },
            }
        )
        db.execute(
            """
            INSERT INTO execution_log
            (id, run_id, actor, action, entity_type, entity_id, detail,
             success, quality_score, task_type, authority)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                secrets.token_urlsafe(8),
                draft.draft_id,
                draft.author,
                f"comms_agent_gate:{result.gate_name}",
                "comms_agent_gate",
                draft.draft_id,
                detail,
                1 if result.passed else 0,
                1.0 if result.passed else 0.0,
                "deterministic",
                "standard",
            ),
        )
        db.commit()
        db.close()
    except Exception:
        # Audit logging must never crash the pipeline. A failed log is
        # recorded to stderr by sqlite if WAL is broken; otherwise we
        # swallow — the gate decision itself has already been returned.
        pass
