"""
flow.py — Decorator-driven state machine engine for AIBrain.

Sits above the reactive engine as a developer-friendly API for building
multi-step workflows with conditional routing, parallel execution,
human-in-the-loop approval, and persistence.

Usage:
    from aibrain.core.flow import Flow, FlowState, start, listen, router, or_, and_

    class MyState(FlowState):
        data: str = ""
        result: str = ""

    class MyFlow(Flow[MyState]):
        @start()
        def begin(self):
            self.state.data = "fetched"

        @listen(begin)
        def process(self):
            self.state.result = self.state.data.upper()

        @router(process)
        def check(self) -> str:
            return "good" if self.state.result else "bad"

        @listen("good")
        def publish(self):
            pass

        @listen("bad")
        def retry(self):
            pass
"""

import asyncio
import functools
import inspect
import json
import logging
import os
import sqlite3
import threading
import time
import traceback
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Generic, TypeVar
from uuid import uuid4

from pydantic import BaseModel, Field

log = logging.getLogger("aibrain.flow")

# ---------------------------------------------------------------------------
# Condition combinators
# ---------------------------------------------------------------------------

class _OrCondition:
    """Any of the wrapped conditions triggers."""
    def __init__(self, *conditions):
        self.conditions = conditions

    def __repr__(self):
        return f"or_({', '.join(repr(c) for c in self.conditions)})"


class _AndCondition:
    """All wrapped conditions must complete before triggering."""
    def __init__(self, *conditions):
        self.conditions = conditions

    def __repr__(self):
        return f"and_({', '.join(repr(c) for c in self.conditions)})"


def or_(*conditions) -> _OrCondition:
    """Any condition triggers the decorated method."""
    return _OrCondition(*conditions)


def and_(*conditions) -> _AndCondition:
    """All conditions must complete before triggering."""
    return _AndCondition(*conditions)


# ---------------------------------------------------------------------------
# Decorators
# ---------------------------------------------------------------------------

_FLOW_MARKER = "__flow_meta__"


def start(condition=None):
    """Mark a method as a flow entry point."""
    def decorator(fn):
        meta = getattr(fn, _FLOW_MARKER, {})
        meta["type"] = "start"
        meta["condition"] = condition
        setattr(fn, _FLOW_MARKER, meta)
        return fn
    return decorator


def listen(condition):
    """Mark a method to execute when condition is met.
    condition: method reference, string, or_(), and_() compound.
    """
    def decorator(fn):
        meta = getattr(fn, _FLOW_MARKER, {})
        meta["type"] = "listen"
        meta["condition"] = condition
        setattr(fn, _FLOW_MARKER, meta)
        return fn
    return decorator


def router(condition):
    """Like listen but return value becomes a new trigger for downstream listeners."""
    def decorator(fn):
        meta = getattr(fn, _FLOW_MARKER, {})
        meta["type"] = "router"
        meta["condition"] = condition
        setattr(fn, _FLOW_MARKER, meta)
        return fn
    return decorator


def retry(max_retries: int = 3, backoff: float = 1.0):
    """Retry a flow step on failure with exponential backoff."""
    def decorator(fn):
        meta = getattr(fn, _FLOW_MARKER, {})
        meta["retry"] = {"max_retries": max_retries, "backoff": backoff}
        setattr(fn, _FLOW_MARKER, meta)

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            last_err = None
            for attempt in range(max_retries + 1):
                try:
                    return fn(*args, **kwargs)
                except Exception as e:
                    last_err = e
                    if attempt < max_retries:
                        time.sleep(backoff * (2 ** attempt))
            raise last_err

        @functools.wraps(fn)
        async def async_wrapper(*args, **kwargs):
            last_err = None
            for attempt in range(max_retries + 1):
                try:
                    return await fn(*args, **kwargs)
                except Exception as e:
                    last_err = e
                    if attempt < max_retries:
                        await asyncio.sleep(backoff * (2 ** attempt))
            raise last_err

        if inspect.iscoroutinefunction(fn):
            setattr(async_wrapper, _FLOW_MARKER, meta)
            return async_wrapper
        setattr(wrapper, _FLOW_MARKER, meta)
        return wrapper
    return decorator


def timeout(seconds: float):
    """Set a timeout on a flow step."""
    def decorator(fn):
        meta = getattr(fn, _FLOW_MARKER, {})
        meta["timeout"] = seconds
        setattr(fn, _FLOW_MARKER, meta)
        return fn
    return decorator


# ---------------------------------------------------------------------------
# FlowState
# ---------------------------------------------------------------------------

class FlowState(BaseModel):
    """Base state for all flows."""
    id: str = Field(default_factory=lambda: str(uuid4()))


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

class FlowPersistence(ABC):
    @abstractmethod
    def save_state(self, flow_id: str, method_name: str, state_json: str) -> None:
        ...

    @abstractmethod
    def load_state(self, flow_id: str) -> str | None:
        ...

    @abstractmethod
    def save_pending(self, flow_id: str, context: dict, state_json: str) -> None:
        ...

    @abstractmethod
    def load_pending(self, flow_id: str) -> dict | None:
        ...


class SQLiteFlowPersistence(FlowPersistence):
    """Persistence using the existing aibrain.db."""

    def __init__(self, db_path: str | None = None):
        if db_path is None:
            root = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent.parent))
            db_path = str(root / "aibrain.db")
        self.db_path = db_path
        self._ensure_table()

    def _ensure_table(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS flow_states (
                    flow_id TEXT NOT NULL,
                    method_name TEXT NOT NULL DEFAULT '',
                    state_json TEXT NOT NULL,
                    status TEXT DEFAULT 'running',
                    pending_context TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (flow_id, method_name)
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_flow_states_status ON flow_states(status)")

    def save_state(self, flow_id: str, method_name: str, state_json: str) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO flow_states (flow_id, method_name, state_json, updated_at) "
                "VALUES (?, ?, ?, ?)",
                (flow_id, method_name, state_json, datetime.utcnow().isoformat()),
            )

    def load_state(self, flow_id: str) -> str | None:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT state_json FROM flow_states WHERE flow_id=? ORDER BY updated_at DESC LIMIT 1",
                (flow_id,),
            ).fetchone()
            return row[0] if row else None

    def save_pending(self, flow_id: str, context: dict, state_json: str) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO flow_states (flow_id, method_name, state_json, status, pending_context, updated_at) "
                "VALUES (?, ?, ?, 'pending_human', ?, ?)",
                (flow_id, "__pending__", state_json, json.dumps(context), datetime.utcnow().isoformat()),
            )

    def load_pending(self, flow_id: str) -> dict | None:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT pending_context, state_json FROM flow_states WHERE flow_id=? AND status='pending_human'",
                (flow_id,),
            ).fetchone()
            if row:
                return {"context": json.loads(row[0]) if row[0] else {}, "state_json": row[1]}
            return None


# ---------------------------------------------------------------------------
# Human-in-the-loop
# ---------------------------------------------------------------------------

class HumanFeedbackPending(Exception):
    """Raised to pause a flow and wait for human input."""
    def __init__(self, flow_id: str, context: dict, state: FlowState):
        self.flow_id = flow_id
        self.context = context
        self.state = state
        super().__init__(f"Flow {flow_id} paused — waiting for human feedback")


# ---------------------------------------------------------------------------
# Thread-safe state proxy
# ---------------------------------------------------------------------------

class _StateProxy:
    """Thread-safe proxy for FlowState — wraps attribute access with a lock."""
    __slots__ = ("_obj", "_lock")

    def __init__(self, obj: FlowState, lock: threading.Lock):
        object.__setattr__(self, "_obj", obj)
        object.__setattr__(self, "_lock", lock)

    def __getattr__(self, name):
        with object.__getattribute__(self, "_lock"):
            return getattr(object.__getattribute__(self, "_obj"), name)

    def __setattr__(self, name, value):
        with object.__getattribute__(self, "_lock"):
            setattr(object.__getattribute__(self, "_obj"), name, value)

    def _unwrap(self) -> FlowState:
        return object.__getattribute__(self, "_obj")


# ---------------------------------------------------------------------------
# DAG node
# ---------------------------------------------------------------------------

class _FlowNode:
    """A single node in the flow DAG."""
    __slots__ = ("name", "fn", "node_type", "condition", "timeout_s", "retry_cfg", "_and_key", "_and_required")

    def __init__(self, name: str, fn: Callable, node_type: str, condition, timeout_s: float | None, retry_cfg: dict | None):
        self.name = name
        self.fn = fn
        self.node_type = node_type  # "start" | "listen" | "router"
        self.condition = condition
        self.timeout_s = timeout_s
        self.retry_cfg = retry_cfg
        self._and_key = None
        self._and_required = None

    def __repr__(self):
        return f"_FlowNode({self.name!r}, type={self.node_type})"


# ---------------------------------------------------------------------------
# Flow metaclass — scans decorated methods and builds the DAG
# ---------------------------------------------------------------------------

def _resolve_condition_name(cond) -> str | list:
    """Turn a condition into a trigger name (or compound)."""
    if isinstance(cond, str):
        return cond
    if callable(cond) and hasattr(cond, "__name__"):
        return cond.__name__
    if isinstance(cond, (_OrCondition, _AndCondition)):
        return cond
    return str(cond)


T = TypeVar("T", bound=FlowState)


class Flow(BaseModel, Generic[T]):
    """Decorator-driven state machine.

    Subclass this, decorate methods with @start, @listen, @router, and call
    kickoff() to execute.
    """

    model_config = {"arbitrary_types_allowed": True}

    persistence: FlowPersistence | None = None
    max_method_calls: int = 100
    emit_events: bool = False
    pattern_bus: Any = None  # PatternBus instance if emit_events=True

    # Internal — set during init
    _state: Any = None
    _state_lock: threading.Lock = None
    _nodes: dict = {}          # name -> _FlowNode
    _trigger_map: dict = {}    # trigger_name -> [_FlowNode]
    _and_tracker: dict = {}    # and_condition_id -> set of completed triggers
    _call_counts: dict = {}
    _completed: set = set()
    _resume_trigger: str | None = None

    def model_post_init(self, __context: Any) -> None:
        object.__setattr__(self, "_state_lock", threading.Lock())
        object.__setattr__(self, "_call_counts", {})
        object.__setattr__(self, "_completed", set())
        object.__setattr__(self, "_and_tracker", {})
        object.__setattr__(self, "_resume_trigger", None)
        object.__setattr__(self, "_last_result", None)

        # Resolve T and instantiate state — walk MRO to find Flow[ConcreteState]
        # Pydantic stores generic args in __pydantic_generic_metadata__
        state_cls = FlowState
        for klass in type(self).__mro__:
            pgm = getattr(klass, "__pydantic_generic_metadata__", None)
            if pgm and pgm.get("args"):
                for arg in pgm["args"]:
                    if isinstance(arg, type) and issubclass(arg, FlowState) and arg is not FlowState:
                        state_cls = arg
                        break
            if state_cls is not FlowState:
                break
        object.__setattr__(self, "_state", state_cls())

        # Build DAG from decorated methods
        nodes = {}
        trigger_map = {}
        for name in dir(type(self)):
            if name.startswith("_"):
                continue
            attr = getattr(type(self), name, None)
            if attr is None:
                continue
            meta = getattr(attr, _FLOW_MARKER, None)
            if meta is None:
                continue
            node = _FlowNode(
                name=name,
                fn=attr,
                node_type=meta["type"],
                condition=meta.get("condition"),
                timeout_s=meta.get("timeout"),
                retry_cfg=meta.get("retry"),
            )
            nodes[name] = node

            # Register triggers
            if meta["type"] == "start":
                trigger_map.setdefault("__start__", []).append(node)
            else:
                cond = meta["condition"]
                resolved = _resolve_condition_name(cond)
                if isinstance(resolved, _OrCondition):
                    for sub in resolved.conditions:
                        sub_name = _resolve_condition_name(sub)
                        trigger_map.setdefault(sub_name, []).append(node)
                elif isinstance(resolved, _AndCondition):
                    # and_ nodes are triggered by each sub-condition but only fire when all are met
                    and_key = id(resolved)
                    node._and_key = and_key
                    node._and_required = set()
                    for sub in resolved.conditions:
                        sub_name = _resolve_condition_name(sub)
                        node._and_required.add(sub_name)
                        trigger_map.setdefault(sub_name, []).append(node)
                else:
                    trigger_map.setdefault(resolved, []).append(node)

        object.__setattr__(self, "_nodes", nodes)
        object.__setattr__(self, "_trigger_map", trigger_map)

    @property
    def state(self) -> T:
        return _StateProxy(self._state, self._state_lock)

    @property
    def flow_id(self) -> str:
        return self._state.id

    @property
    def last_result(self) -> Any:
        """The return value of the last method executed during kickoff()."""
        return self._last_result

    # ---------------------------------------------------------------------------
    # Event emission helpers
    # ---------------------------------------------------------------------------

    def _emit(self, event_type: str, key: str, value: Any = None, metadata: dict | None = None):
        """Emit a DomainEvent via centralized events.emit() if configured."""
        if not self.emit_events:
            return
        try:
            from aibrain.core.events import emit
            emit(event_type, key, value=value, domain="flow", **(metadata or {}))
        except Exception as e:
            log.warning("Flow event emission failed: %s", e)

    # ---------------------------------------------------------------------------
    # Execution
    # ---------------------------------------------------------------------------

    def _run_node(self, node: _FlowNode) -> Any:
        """Run a single flow node with timeout support."""
        name = node.name
        counts = self._call_counts
        counts[name] = counts.get(name, 0) + 1
        if counts[name] > self.max_method_calls:
            raise RuntimeError(
                f"Flow infinite loop protection: {name} called {counts[name]} times "
                f"(max {self.max_method_calls})"
            )

        self._emit("step_start", name, metadata={"flow_id": self.flow_id})

        # Persist state before step
        if self.persistence:
            self.persistence.save_state(
                self.flow_id, name, self._state.model_dump_json()
            )

        try:
            bound = node.fn.__get__(self, type(self))
            if node.timeout_s:
                result = self._run_with_timeout(bound, node.timeout_s)
            else:
                result = bound()
        except HumanFeedbackPending:
            raise
        except Exception:
            self._emit("step_error", name, metadata={"flow_id": self.flow_id, "error": traceback.format_exc()})
            raise

        self._completed.add(name)
        self._emit("step_complete", name, value=str(result)[:200] if result else None, metadata={"flow_id": self.flow_id})

        # Persist state after step
        if self.persistence:
            self.persistence.save_state(
                self.flow_id, f"{name}__done", self._state.model_dump_json()
            )

        return result

    def _run_with_timeout(self, fn: Callable, seconds: float) -> Any:
        """Run fn with a wall-clock timeout using a thread."""
        result_box = [None]
        error_box = [None]

        def target():
            try:
                result_box[0] = fn()
            except Exception as e:
                error_box[0] = e

        t = threading.Thread(target=target, daemon=True)
        t.start()
        t.join(timeout=seconds)
        if t.is_alive():
            raise TimeoutError(f"Flow step timed out after {seconds}s")
        if error_box[0]:
            raise error_box[0]
        return result_box[0]

    def _fire_trigger(self, trigger_name: str) -> list[Any]:
        """Fire all listeners for a trigger, running parallel where possible."""
        listeners = self._trigger_map.get(trigger_name, [])
        if not listeners:
            return []

        results = []
        for node in listeners:
            # and_ gate check
            and_key = getattr(node, "_and_key", None)
            if and_key is not None:
                tracker = self._and_tracker
                tracker.setdefault(and_key, set())
                tracker[and_key].add(trigger_name)
                if not node._and_required.issubset(tracker[and_key]):
                    continue  # not all conditions met yet

            try:
                result = self._run_node(node)
            except HumanFeedbackPending as e:
                if self.persistence:
                    self.persistence.save_pending(self.flow_id, e.context, self._state.model_dump_json())
                raise

            results.append((node, result))

            # Router: return value is a new trigger
            if node.node_type == "router" and result is not None:
                self._emit("router_decision", node.name, value=str(result), metadata={"flow_id": self.flow_id})
                sub_results = self._fire_trigger(str(result))
                results.extend(sub_results)
            else:
                # Regular listener: its completion triggers downstream
                sub_results = self._fire_trigger(node.name)
                results.extend(sub_results)

        return results

    def kickoff(self, inputs: dict | None = None) -> T:
        """Execute the flow synchronously. Returns final state.

        The last method's return value is available via flow.last_result
        after execution. The flow ID is available via flow.flow_id.
        """
        if inputs:
            for k, v in inputs.items():
                setattr(self._state, k, v)

        self._emit("flow_start", self.flow_id, metadata={"flow_class": type(self).__name__})

        last_result = None

        # Run all @start nodes
        start_nodes = self._trigger_map.get("__start__", [])
        for node in start_nodes:
            try:
                result = self._run_node(node)
            except HumanFeedbackPending:
                raise

            if result is not None:
                last_result = result

            # Fire downstream listeners
            downstream = self._fire_trigger(node.name)
            for _dn_node, dn_result in downstream:
                if dn_result is not None:
                    last_result = dn_result

            # Router start nodes
            if node.node_type == "router" and result is not None:
                router_downstream = self._fire_trigger(str(result))
                for _dn_node, dn_result in router_downstream:
                    if dn_result is not None:
                        last_result = dn_result

        self._emit("flow_complete", self.flow_id, metadata={"flow_class": type(self).__name__})

        # Store last method's return value for callers who want flow output
        object.__setattr__(self, "_last_result", last_result)

        # Persist final state
        if self.persistence:
            self.persistence.save_state(
                self.flow_id, "__final__", self._state.model_dump_json()
            )

        return self._state

    async def kickoff_async(self, inputs: dict | None = None) -> T:
        """Async execution — runs in executor to preserve thread-safe state."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.kickoff(inputs))

    # ---------------------------------------------------------------------------
    # Human-in-the-loop resume
    # ---------------------------------------------------------------------------

    @classmethod
    def from_pending(cls, flow_id: str, persistence: FlowPersistence, **kwargs) -> "Flow":
        """Reconstruct a flow from persisted pending state."""
        pending = persistence.load_pending(flow_id)
        if not pending:
            raise ValueError(f"No pending flow found for {flow_id}")

        instance = cls(persistence=persistence, **kwargs)
        state_data = json.loads(pending["state_json"])
        for k, v in state_data.items():
            setattr(instance._state, k, v)
        # Override the state ID to match the persisted flow
        object.__setattr__(instance._state, "id", flow_id)
        return instance

    def resume(self, feedback: str, trigger: str = "__resume__") -> T:
        """Resume a flow after human feedback.

        The feedback is stored in state and the given trigger fires downstream listeners.
        """
        self._state.id = self.flow_id  # preserve
        # Store feedback in state metadata if possible
        if hasattr(self._state, "feedback"):
            self._state.feedback = feedback

        self._emit("flow_resume", self.flow_id, value=feedback[:200], metadata={"trigger": trigger})

        # Fire listeners for the resume trigger
        self._fire_trigger(trigger)

        return self._state

    # ---------------------------------------------------------------------------
    # Visualization
    # ---------------------------------------------------------------------------

    def plot(self) -> str:
        """Generate an HTML visualization of the flow graph using Mermaid. Returns file path."""
        lines = ["graph TD"]
        for name, node in self._nodes.items():
            shape = {
                "start": f'{name}[["@start: {name}"]]',
                "router": f'{name}{{{{"@router: {name}"}}}}',
                "listen": f'{name}("{name}")',
            }.get(node.node_type, f'{name}("{name}")')
            lines.append(f"    {shape}")

        # Draw edges
        for trigger, listeners in self._trigger_map.items():
            if trigger == "__start__":
                continue
            for listener in listeners:
                and_key = getattr(listener, "_and_key", None)
                if and_key is not None:
                    for req in listener._and_required:
                        lines.append(f"    {req} -->|and| {listener.name}")
                else:
                    lines.append(f"    {trigger} --> {listener.name}")

        mermaid_src = "\n".join(lines)
        html = f"""<!DOCTYPE html>
<html><head>
<script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
<style>body {{ font-family: sans-serif; padding: 2em; }}</style>
</head><body>
<h2>Flow: {type(self).__name__}</h2>
<div class="mermaid">
{mermaid_src}
</div>
<script>mermaid.initialize({{startOnLoad:true}});</script>
</body></html>"""

        out_dir = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent.parent))
        out_path = out_dir / f"flow_{type(self).__name__}.html"
        out_path.write_text(html, encoding="utf-8")
        return str(out_path)
