"""
migration_lifecycle.py — Backfill scripts for Memory Lifecycle v1.6.

One-time migration scripts to:
1. Classify existing memories with claim_type
2. Build topic clusters from embedding similarity
3. Classify .md memory files
4. Backfill file references from existing memories

All scripts are idempotent (safe to re-run).
"""

from __future__ import annotations

import logging
import sqlite3
from pathlib import Path

log = logging.getLogger("aibrain.migration_lifecycle")


def backfill_claim_types(db: sqlite3.Connection, batch_size: int = 500) -> int:
    """Classify all existing memories that have claim_type='assertion' (default).

    Processes in batches to avoid locking the DB for long periods.
    Returns total count of memories reclassified.
    """
    from aibrain.core.claim_classifier import classify_claim_type, extract_plan_deadline, CLAIM_CONFIDENCE

    offset = 0
    total_updated = 0

    while True:
        rows = db.execute(
            "SELECT id, content, name FROM memories "
            "WHERE claim_type = 'assertion' OR claim_type IS NULL "
            "ORDER BY id LIMIT ? OFFSET ?",
            (batch_size, offset)
        ).fetchall()

        if not rows:
            break

        batch_updates = 0
        for row in rows:
            content = row[1] or ""
            ct = classify_claim_type(content)
            if ct == "assertion":
                offset += 1  # No change needed, skip
                continue

            deadline = extract_plan_deadline(content) if ct == "plan" else None
            confidence = CLAIM_CONFIDENCE.get(ct, 0.5)

            db.execute(
                "UPDATE memories SET claim_type = ?, plan_deadline = ?, confidence = ? WHERE id = ?",
                (ct, deadline, confidence, row[0])
            )
            total_updated += 1
            batch_updates += 1

        db.commit()
        if batch_updates == 0:
            # All rows in this batch were assertions, advance offset
            offset += batch_size
        else:
            # Some rows were updated, re-query from same offset
            # (updated rows no longer match WHERE clause)
            pass

        log.info("backfill_claim_types: processed batch at offset %d, updated %d total", offset, total_updated)

    return total_updated


def backfill_claims_table(db: sqlite3.Connection, batch_size: int = 500) -> int:
    """Extract structured claims from all existing memories into memory_claims.

    Returns total count of claims inserted.
    """
    from aibrain.core.claim_extractor import extract_claims, store_claims

    offset = 0
    total_claims = 0

    while True:
        rows = db.execute(
            "SELECT id, content, claim_type FROM memories "
            "WHERE active = 1 AND id NOT IN (SELECT DISTINCT memory_id FROM memory_claims) "
            "ORDER BY id LIMIT ?",
            (batch_size,)
        ).fetchall()

        if not rows:
            break

        for row in rows:
            mem_id = row[0]
            content = row[1] or ""
            claim_type = row[2] or "assertion"

            claims = extract_claims(mem_id, content, claim_type)
            count = store_claims(db, claims)
            total_claims += count

        log.info("backfill_claims_table: batch complete, %d claims total", total_claims)

    return total_claims


def backfill_topic_clusters(db: sqlite3.Connection, similarity_threshold: float = 0.75) -> int:
    """Group existing memories into topic clusters.

    Strategy: iterate memories by ID. For each, check if any existing cluster
    has a centroid embedding within threshold. If yes, assign to that cluster.
    If no, create a new cluster.

    Returns count of memories assigned to clusters.
    """
    import struct

    try:
        from aibrain_db import _db_vec_enabled
    except ImportError:
        log.warning("Cannot backfill topic clusters: aibrain_db not available")
        return 0

    if not _db_vec_enabled:
        log.warning("Cannot backfill topic clusters: vec not enabled")
        return 0

    # Get all memories with embeddings that don't have a cluster
    rows = db.execute(
        "SELECT m.id, m.name, m.content, v.embedding "
        "FROM memories m "
        "JOIN memories_vec v ON m.id = v.memory_id "
        "WHERE m.active = 1 AND (m.topic_cluster_id IS NULL OR m.topic_cluster_id = 0) "
        "ORDER BY m.id"
    ).fetchall()

    if not rows:
        return 0

    # Build cluster centroids incrementally
    # cluster_id -> (centroid_embedding, count)
    cluster_centroids = {}
    assigned = 0

    for row in rows:
        mem_id = row[0]
        name = row[1] or ""
        emb_bytes = row[3]

        if not emb_bytes:
            continue

        # Decode embedding
        dim = len(emb_bytes) // 4
        emb = list(struct.unpack(f"{dim}f", emb_bytes))

        # Check against existing cluster centroids
        best_cluster_id = None
        best_sim = 0.0

        for cid, (centroid, count) in cluster_centroids.items():
            sim = _cosine_similarity(emb, centroid)
            if sim > best_sim:
                best_sim = sim
                best_cluster_id = cid

        if best_sim >= similarity_threshold and best_cluster_id is not None:
            # Assign to existing cluster
            db.execute(
                "UPDATE memories SET topic_cluster_id = ? WHERE id = ?",
                (best_cluster_id, mem_id)
            )
            # Update centroid (running average)
            old_centroid, old_count = cluster_centroids[best_cluster_id]
            new_count = old_count + 1
            new_centroid = [
                (oc * old_count + ne) / new_count
                for oc, ne in zip(old_centroid, emb)
            ]
            cluster_centroids[best_cluster_id] = (new_centroid, new_count)
        else:
            # Create new cluster
            # Derive cluster name from memory name
            canonical = _normalize_cluster_name(name)
            try:
                db.execute(
                    "INSERT INTO topic_clusters (canonical_name, description) VALUES (?, ?)",
                    (canonical, f"Auto-generated from memory: {name[:100]}")
                )
                new_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
            except sqlite3.IntegrityError:
                # Name collision — get existing ID
                existing = db.execute(
                    "SELECT id FROM topic_clusters WHERE canonical_name = ?",
                    (canonical,)
                ).fetchone()
                new_id = existing[0] if existing else None
                if not new_id:
                    continue

            db.execute(
                "UPDATE memories SET topic_cluster_id = ? WHERE id = ?",
                (new_id, mem_id)
            )
            cluster_centroids[new_id] = (emb, 1)

        assigned += 1
        if assigned % 500 == 0:
            db.commit()
            log.info("backfill_topic_clusters: %d memories assigned", assigned)

    db.commit()
    log.info("backfill_topic_clusters: done — %d memories assigned to clusters", assigned)
    return assigned


def backfill_md_memories(memory_dir: str, db: sqlite3.Connection) -> int:
    """Classify .md memory files and sync claim_type to DB.

    Returns count of memories updated.
    """
    from aibrain.core.claim_classifier import classify_claim_type

    updated = 0
    for md_file in Path(memory_dir).glob("*.md"):
        try:
            content = md_file.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        ct = classify_claim_type(content)

        # Find matching DB row by name (strip .md extension)
        name = md_file.stem
        result = db.execute(
            "UPDATE memories SET claim_type = ? WHERE name = ? AND claim_type = 'assertion'",
            (ct, name)
        )
        if result.rowcount > 0:
            updated += 1

    db.commit()
    log.info("backfill_md_memories: %d memories updated from .md files", updated)
    return updated


def backfill_file_references(db: sqlite3.Connection, batch_size: int = 500) -> int:
    """Extract file references from all existing memories.

    One-time backfill. Safe to re-run (checks for existing refs before insert).
    Returns total count of file references created.
    """
    from aibrain.core.file_reference_extractor import extract_file_references, store_file_references

    offset = 0
    total = 0

    while True:
        rows = db.execute(
            "SELECT id, content, name FROM memories WHERE active = 1 ORDER BY id LIMIT ? OFFSET ?",
            (batch_size, offset)
        ).fetchall()

        if not rows:
            break

        for row in rows:
            mem_id, content, name = row[0], row[1], row[2]
            if not content:
                continue

            refs = extract_file_references(content, mem_id)
            count = store_file_references(db, refs)
            total += count

        offset += batch_size
        log.info("backfill_file_references: processed %d memories, %d refs total", offset, total)

    return total


# --- Internal helpers ---

def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors."""
    if len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = sum(x * x for x in a) ** 0.5
    norm_b = sum(x * x for x in b) ** 0.5
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def _normalize_cluster_name(name: str) -> str:
    """Normalize a memory name into a topic cluster canonical name."""
    import re
    # Lowercase, strip non-alphanumeric, collapse underscores
    normalized = re.sub(r'[^a-z0-9_]', '_', name.lower().strip())
    normalized = re.sub(r'_+', '_', normalized).strip('_')
    return normalized[:80] or "unknown"
