"""
WTL Phase 5 — NEEDS-DECKER outbound surfacing poller.

Consumes schema from migrations v11 (needs_decker_queue). Pure library:
no Telegram/email/banner I/O embedded. Callers inject `send_telegram`,
`send_email`, and `emit_banner` callables so tests can mock and operators
can route through their own comms layer (Case uses agent_comms.reply_to_*;
Neuro uses the same helper via different paths).

Responsibilities
----------------
  * plan_tick(now=None, db=None) — pure scan: read needs_decker_queue and
    emit the per-row action list WITHOUT side effects. Useful for "what
    would the next tick do" dry-runs and for the broker_hook banner stage
    computation (Phase 6).
  * execute_tick(...)            — call the injected senders, write back
    last_telegram_send / last_email_send / urgent_at / physical_fallback_at
    timestamps in one transaction. Idempotent: the cadence gate rejects
    second-in-window calls with a no-op.

Cadence (v4.1 §5c)
------------------
  Stage A (fresh):    last_telegram_send IS NULL         → Telegram send
  Stage B (urgent):   now - surfaced_at >= URGENT_DELAY
                      AND urgent_at IS NULL              → urgent Telegram
  Stage C (fallback): now - urgent_at >= FALLBACK_DELAY
                      AND last_email_send IS NULL        → email fallback
  Stage D (physical): now - physical_fallback_at
                      >= PHYSICAL_DELAY                  → physical banner

Default delays (minutes) tuned for Decker's average response pattern:
  WTL_URGENT_DELAY_MIN   = 30
  WTL_FALLBACK_DELAY_MIN = 180 (3h)
  WTL_PHYSICAL_DELAY_MIN = 720 (12h)

Env overrides apply to both the library and tests. Tests use very small
windows + an injected `now` for determinism.

Sender contract
---------------
  send_telegram(task_id, stage, queue_row) -> bool
  send_email(task_id, stage, queue_row)    -> bool
  emit_banner(task_id, stage, queue_row)   -> bool

Each returns True on successful dispatch, False otherwise. A False result
means the timestamp is NOT written — the next tick will retry the same
stage. This is the same "never ack on a dropped outbound" discipline
called out in feedback_outside_comms_unreliable.md.

Out of scope
------------
  * Actual Telegram/email wire I/O (callers bring those).
  * Decker-reply ingestion — Phase 3 (decker_decisions.ingest_decker_reply).
  * Banner rendering inside broker_hook UI — Phase 6 wraps plan_tick().
  * Re-send on same-stage repeat: each stage writes at most once per
    row. Repeat-nag cadence (e.g. hourly urgent re-sends) is a Phase 7
    refinement and deliberately absent here — ship the stage transitions
    first, then layer repeats if the signal proves weak.

Honest-null
-----------
plan_tick() returns [] when the queue is empty or every row is already
past its last applicable stage. Callers must NOT treat [] as "broken" —
it means "nothing actionable this tick." The execute-side caller should
log a per-tick summary so persistent silence is observable instead of
being indistinguishable from a crashed poller.

Falsified in production if
--------------------------
The cadence contract is observably broken if any of the following land
in the DB:
  1. A row with ``surfaced_at`` older than WTL_URGENT_DELAY_MIN minutes
     and ``urgent_at IS NULL`` AND ``last_telegram_send IS NOT NULL`` at
     a tick boundary → Stage B gate broken (never transitioned).
  2. Two ``last_telegram_send`` bumps on the same task_id within a 5-second
     window → concurrency race (two tickers fired in parallel; the
     compare-and-swap write below prevents this).
  3. ``last_banner_render`` set but ``last_email_send IS NULL`` →
     Stage-C skipped, Stage-D fired prematurely (impossible by the
     plan_tick gate, but worth a DB audit alert).
  4. A row staying in the queue with ``decker_decision IS NULL`` for
     longer than WTL_PHYSICAL_DELAY_MIN + 24h → physical banner never
     dispatched or Decker never saw it (outside the library's control
     but surfaces a comms-system failure).

Cross-host operators: run a daily DB audit against the four predicates
above; any hit is a structural bug, not a stale-data artifact.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta, timezone
from typing import Callable, Optional

from aibrain.core.companies import _get_db

log = logging.getLogger(__name__)

# Warn-once-per-(task_id, channel) set for the no_sender_configured path.
# Without this, a permanently-disabled channel (e.g. email sender never
# wired up by the operator) floods logs with an identical warning every
# tick. Reset is a process-lifetime concern — a restart re-arms the
# warning; that's intentional, it means post-restart silence is a bug.
_disabled_channel_warned: set[tuple[str, str]] = set()


def _env_minutes(name: str, default: int) -> int:
    """Read an integer env override; fall back to `default` on empty/bad values."""
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        v = int(raw)
        return v if v >= 0 else default
    except ValueError:
        return default


def _urgent_delay() -> timedelta:
    return timedelta(minutes=_env_minutes("WTL_URGENT_DELAY_MIN", 30))


def _fallback_delay() -> timedelta:
    return timedelta(minutes=_env_minutes("WTL_FALLBACK_DELAY_MIN", 180))


def _physical_delay() -> timedelta:
    return timedelta(minutes=_env_minutes("WTL_PHYSICAL_DELAY_MIN", 720))


# Stage tokens are the exposed vocabulary — senders branch on them and
# tests assert against them. Do not rename without updating callers.
STAGE_FRESH = "fresh"
STAGE_URGENT = "urgent"
STAGE_FALLBACK = "fallback"
STAGE_PHYSICAL = "physical"

# Channel tokens match stage but are separate so a future repeat-nag can
# reuse a channel for a different stage.
CHANNEL_TELEGRAM = "telegram"
CHANNEL_EMAIL = "email"
CHANNEL_BANNER = "banner"


def _parse_ts(value) -> Optional[datetime]:
    """Parse a SQLite timestamp string into a tz-aware datetime.

    SQLite's ``datetime('now')`` emits naive UTC ("YYYY-MM-DD HH:MM:SS").
    We promote to tz-aware UTC so timedelta math works against `now`
    regardless of caller tz. None/empty returns None so callers can
    branch on "this stage has not landed yet."
    """
    if not value:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    try:
        dt = datetime.fromisoformat(str(value).replace(" ", "T"))
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _stage_for_row(row: dict, now: datetime) -> Optional[dict]:
    """Decide which cadence stage this row is currently due for.

    Returns a plan dict {task_id, stage, channel, reason} or None if the
    row is fully drained (all applicable stages have fired).

    Order of evaluation matters — later-stage check wins because a row
    that's past physical-delay is also past fallback-delay is also past
    urgent-delay; we only want the HIGHEST un-dispatched stage per tick.
    Each stage is gated by "this stage's marker is not yet set," so a row
    that hit urgent last tick will not re-fire urgent this tick — it will
    progress to fallback or stay silent until fallback-delay expires.
    """
    if row.get("decker_decision"):
        return None  # already decided; nothing to surface

    surfaced_at = _parse_ts(row.get("surfaced_at"))
    urgent_at = _parse_ts(row.get("urgent_at"))
    physical_fallback_at = _parse_ts(row.get("physical_fallback_at"))
    last_tg = _parse_ts(row.get("last_telegram_send"))
    last_email = _parse_ts(row.get("last_email_send"))

    # Stage D: physical banner — fires when physical_fallback_at was set
    # but we have not yet handed off to the physical channel. The physical
    # channel emits at MOST once per row; after that the row stays in the
    # physical-surfaced state and the poller stops nagging until Decker
    # replies or a new stuck-event bumps urgent_at forward.
    if physical_fallback_at and now - physical_fallback_at >= _physical_delay():
        if not row.get("last_banner_render"):
            return {
                "task_id": row["task_id"],
                "stage": STAGE_PHYSICAL,
                "channel": CHANNEL_BANNER,
                "reason": "physical_delay_elapsed",
            }
        return None  # physical already emitted; idle until Decker replies

    # Stage C: email fallback — fires when urgent has aged past fallback
    # delay AND no email has been sent yet. urgent_at MUST be set (stage B
    # must have already fired) for this to trigger.
    if urgent_at and now - urgent_at >= _fallback_delay() and last_email is None:
        return {
            "task_id": row["task_id"],
            "stage": STAGE_FALLBACK,
            "channel": CHANNEL_EMAIL,
            "reason": "fallback_delay_elapsed",
        }

    # Stage B: urgent Telegram — fires when surfaced has aged past urgent
    # delay AND urgent_at has not been stamped yet AND a fresh Telegram
    # has already landed. The `last_tg is not None` gate prevents the
    # epistemic inconsistency where urgent would overwrite a never-sent
    # fresh timestamp: if the first-send failed and the caller keeps
    # retrying, the row stays at Stage A until fresh actually lands,
    # then steps up to urgent on a subsequent tick. Audit-trail stays
    # honest: we never claim "first pinged Decker at urgent_at" when
    # the fresh send never actually delivered.
    if (
        surfaced_at
        and now - surfaced_at >= _urgent_delay()
        and urgent_at is None
        and last_tg is not None
    ):
        return {
            "task_id": row["task_id"],
            "stage": STAGE_URGENT,
            "channel": CHANNEL_TELEGRAM,
            "reason": "urgent_delay_elapsed",
        }

    # Stage A: fresh surfacing — fires when nothing has been sent yet.
    # Distinct from "never will fire" because the fresh-send gate checks
    # last_telegram_send, not surfaced_at.
    if last_tg is None:
        return {
            "task_id": row["task_id"],
            "stage": STAGE_FRESH,
            "channel": CHANNEL_TELEGRAM,
            "reason": "fresh_surface",
        }

    return None  # quiet window — nothing due


def plan_tick(now: Optional[datetime] = None, db=None) -> list[dict]:
    """Scan needs_decker_queue and return the per-row action list.

    Pure: no DB writes, no sender calls. Safe to run as a dry-run preview
    or from the broker_hook banner so the banner shows exactly what the
    next execute_tick will do.

    `now` defaults to ``datetime.now(timezone.utc)``. Tests inject a fixed
    `now` so cadence gates are deterministic.
    """
    now = now or datetime.now(timezone.utc)
    db = db or _get_db()
    rows = db.execute(
        "SELECT task_id, surfaced_at, urgent_at, physical_fallback_at,"
        " last_telegram_send, last_email_send, last_banner_render,"
        " decker_decision, calibration_flag, ambiguity_flag"
        " FROM needs_decker_queue WHERE decker_decision IS NULL"
        " ORDER BY surfaced_at ASC"
    ).fetchall()

    plans = []
    for r in rows:
        plan = _stage_for_row(dict(r), now)
        if plan:
            plans.append(plan)
    return plans


def execute_tick(
    send_telegram: Optional[Callable[[str, str, dict], bool]] = None,
    send_email: Optional[Callable[[str, str, dict], bool]] = None,
    emit_banner: Optional[Callable[[str, str, dict], bool]] = None,
    now: Optional[datetime] = None,
    db=None,
) -> list[dict]:
    """Execute the plan for this tick — call senders + write timestamps.

    Each plan entry gets dispatched to exactly one of the three injected
    callables based on its channel token. A None-callable for a channel
    means "skip that channel" — the plan entry is reported back with
    ``dispatched=False, reason='no_sender_configured'`` and no timestamp
    write happens. This is the "honest skip" path for operators who want
    to disable email but keep Telegram live.

    Successful dispatch writes the appropriate timestamp(s):
      fresh    → last_telegram_send = now
      urgent   → last_telegram_send = now, urgent_at = now
      fallback → last_email_send = now, physical_fallback_at = now
      physical → last_banner_render = now

    Returns a list of result dicts, one per dispatched plan entry:
      {task_id, stage, channel, dispatched: bool, reason: str}

    Transactional: each successful dispatch is committed independently so
    a sender failure partway through the tick does not roll back earlier
    successful sends. Senders that partially succeed (e.g. Telegram API
    rate-limited) should return False and the next tick will retry.
    """
    now = now or datetime.now(timezone.utc)
    db = db or _get_db()
    # The plan reads the pre-tick state; plan_tick sees every applicable
    # row before any writes happen. We re-parse rows inside the loop when
    # we need the full queue_row payload for the sender callable — cheap.
    plans = plan_tick(now=now, db=db)
    results: list[dict] = []

    for plan in plans:
        task_id = plan["task_id"]
        stage = plan["stage"]
        channel = plan["channel"]

        # Fetch the full row payload to hand to the sender — gives the
        # sender access to calibration_flag/ambiguity_flag for contextual
        # messaging without widening the plan_tick return shape.
        row = db.execute(
            "SELECT * FROM needs_decker_queue WHERE task_id=?", (task_id,)
        ).fetchone()
        if row is None:
            # Row vanished between plan and execute — surface and continue.
            results.append({
                "task_id": task_id,
                "stage": stage,
                "channel": channel,
                "dispatched": False,
                "reason": "row_vanished",
            })
            continue
        queue_row = dict(row)

        sender = {
            CHANNEL_TELEGRAM: send_telegram,
            CHANNEL_EMAIL: send_email,
            CHANNEL_BANNER: emit_banner,
        }.get(channel)

        if sender is None:
            key = (task_id, channel)
            if key not in _disabled_channel_warned:
                log.warning(
                    "No sender configured for channel %s on task %s (stage %s). "
                    "Row will stall at this stage until a sender is wired up. "
                    "Suppressing this warning for this task/channel until "
                    "process restart.",
                    channel, task_id, stage,
                )
                _disabled_channel_warned.add(key)
            results.append({
                "task_id": task_id,
                "stage": stage,
                "channel": channel,
                "dispatched": False,
                "reason": "no_sender_configured",
            })
            continue

        try:
            ok = bool(sender(task_id, stage, queue_row))
        except Exception as exc:  # noqa: BLE001 — honest-None on sender crash
            log.warning(
                "Sender %s raised for task %s stage %s: %s",
                channel, task_id, stage, exc,
            )
            ok = False

        if not ok:
            results.append({
                "task_id": task_id,
                "stage": stage,
                "channel": channel,
                "dispatched": False,
                "reason": "sender_returned_false",
            })
            continue

        rowcount = _stamp_success(db, task_id, stage, now)
        if rowcount == 0:
            # Parallel ticker landed this stage first. Sender fired but
            # our stamp was a no-op; report the race so the operator can
            # see the double-send in logs and tune cron to serialize.
            log.warning(
                "Lost stamp race on task %s stage %s — another ticker "
                "stamped first; send was a likely duplicate.",
                task_id, stage,
            )
            results.append({
                "task_id": task_id,
                "stage": stage,
                "channel": channel,
                "dispatched": False,
                "reason": "lost_stamp_race",
            })
            continue

        results.append({
            "task_id": task_id,
            "stage": stage,
            "channel": channel,
            "dispatched": True,
            "reason": None,
        })

    return results


def _stamp_success(db, task_id: str, stage: str, now: datetime) -> int:
    """Write the stage-appropriate timestamps + commit. Returns rows updated.

    Centralised so the stage→column mapping lives in one place. The
    commit is isolated per plan entry so a later-row failure does not
    roll back an earlier successful send.

    Compare-and-swap: each UPDATE is gated by the stage-marker column
    being NULL. If a parallel execute_tick landed the same stage between
    our plan_tick and our _stamp_success, the UPDATE affects zero rows
    and we return 0 so the caller can report dispatched=False,
    reason='lost_race'. The double-send is still bad (the sender already
    fired) but the timestamp does not get bumped twice, keeping the
    audit trail honest — and the next tick won't re-fire because the
    rival ticker's stamp wins.
    """
    ts = now.strftime("%Y-%m-%d %H:%M:%S")
    if stage == STAGE_FRESH:
        cur = db.execute(
            "UPDATE needs_decker_queue SET last_telegram_send=?"
            " WHERE task_id=? AND last_telegram_send IS NULL",
            (ts, task_id),
        )
    elif stage == STAGE_URGENT:
        cur = db.execute(
            "UPDATE needs_decker_queue SET last_telegram_send=?, urgent_at=?"
            " WHERE task_id=? AND urgent_at IS NULL",
            (ts, ts, task_id),
        )
    elif stage == STAGE_FALLBACK:
        cur = db.execute(
            "UPDATE needs_decker_queue SET last_email_send=?, physical_fallback_at=?"
            " WHERE task_id=? AND last_email_send IS NULL",
            (ts, ts, task_id),
        )
    elif stage == STAGE_PHYSICAL:
        cur = db.execute(
            "UPDATE needs_decker_queue SET last_banner_render=?"
            " WHERE task_id=? AND last_banner_render IS NULL",
            (ts, task_id),
        )
    else:
        return 0
    db.commit()
    return cur.rowcount or 0
