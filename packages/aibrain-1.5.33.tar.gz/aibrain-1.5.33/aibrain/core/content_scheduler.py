"""content_scheduler.py — tiered delay queue for content_intel_agent publishing.

Purpose
-------
This is the queue that sits BETWEEN the 12-gate stack and the channel
adapters for the content_intel_agent autopublish pipeline. Decker picked
Option A (tiered delay framework) on 2026-04-11 — see
`project_content_agent_tiered_delay_decision.md` for the authoritative
decision.

Flow: draft -> 12-gate stack -> scheduler (this module) -> tiered delay
countdown -> channel adapter -> publish.

Three tiers
-----------
- T1 (technical/educational): immediate publish, zero delay
- T2 (product updates, changelog): 1-hour delay + Telegram ping
- T3 (strategic positioning, launches): 4-hour delay + Telegram ping

Critical principle: **inaction = publish**. Decker does NOT need to
actively approve anything. He only actively VETOES if something looks
wrong. If the veto window elapses silently, the post fires.

Persistence
-----------
The scheduler stores queued drafts in the canonical aibrain.db (Bug #6
compliant — writers route through `_get_or_create_db`). Schema is
applied idempotently on every call so fresh installs work.

Telegram
--------
T2 and T3 enqueues trigger a Telegram notification to Decker's DM via
the existing decker_system/04_tools/agent_comms.reply_to_telegram
helper. T1 drafts do NOT notify — they fire immediately, so a ping would
be redundant. The helper is imported lazily so the scheduler stays
import-safe in test environments where the decker_system path isn't on
sys.path — if the import fails the notification is silently skipped and
an audit row still records the enqueue.

Channel adapters
----------------
The scheduler calls platform-specific adapters via a tiny registry.
Wave-2 agents will build concrete Twitter/Reddit/etc adapters and
register them at import time. For the MVP this module ships a
`DryRunAdapter` that logs "would publish to X: <body>" to execution_log
without hitting any external API — that lets the scheduler be tested
end-to-end without network access.

Rate limit
----------
Rate limiting is one of the 12 pre-queue gates, but state may change
between queue-in and fire time, so the scheduler double-checks at
publish time via `_rate_limit_ok`. On exceed, the draft is pushed 1
hour forward and retries on the next tick.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Literal, Optional, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tier configuration
# ---------------------------------------------------------------------------

Tier = Literal["T1", "T2", "T3"]
Status = Literal["queued", "publishing", "published", "vetoed", "killed", "failed"]

TIER_DELAYS: Dict[str, int] = {
    "T1": 0,            # immediate — fires on next scheduler tick
    "T2": 60 * 60,      # 1 hour
    "T3": 4 * 60 * 60,  # 4 hours
}

DECKER_DM_CHAT_ID = 8267616606

# Decker's rate limits (gate 11 — also enforced at publish time).
MAX_POSTS_PER_PLATFORM_PER_DAY = 3
MAX_POSTS_TOTAL_PER_DAY = 10
RATE_LIMIT_RETRY_DELAY_SECONDS = 60 * 60  # push 1h into future on exceed


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class ScheduledDraft:
    """A draft sitting in the delay queue, waiting for fires_at to pass."""

    draft_id: str
    tier: Tier
    title: Optional[str]
    body: str
    platform: str
    author: str
    metadata: Dict[str, Any]
    queued_at: datetime
    fires_at: datetime
    status: Status
    veto_reason: Optional[str] = None
    published_post_id: Optional[str] = None

    def to_row(self) -> tuple:
        return (
            self.draft_id,
            self.tier,
            self.title,
            self.body,
            self.platform,
            self.author,
            json.dumps(self.metadata, default=str),
            self.queued_at.isoformat(),
            self.fires_at.isoformat(),
            self.status,
            self.veto_reason,
            self.published_post_id,
        )

    @classmethod
    def from_row(cls, row: tuple) -> "ScheduledDraft":
        (draft_id, tier, title, body, platform, author, metadata_json,
         queued_at, fires_at, status, veto_reason, published_post_id, *_) = row
        return cls(
            draft_id=draft_id,
            tier=tier,
            title=title,
            body=body,
            platform=platform,
            author=author,
            metadata=json.loads(metadata_json) if metadata_json else {},
            queued_at=_parse_ts(queued_at),
            fires_at=_parse_ts(fires_at),
            status=status,
            veto_reason=veto_reason,
            published_post_id=published_post_id,
        )

    def countdown_seconds(self, now: Optional[datetime] = None) -> float:
        """Seconds until this draft fires (negative = already due)."""
        now = now or _utcnow()
        return (self.fires_at - now).total_seconds()


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _parse_ts(raw: str) -> datetime:
    """Parse ISO timestamps written by to_row — tolerates naive and
    timezone-aware variants."""
    dt = datetime.fromisoformat(raw)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


# ---------------------------------------------------------------------------
# Channel adapter protocol + registry
# ---------------------------------------------------------------------------

@runtime_checkable
class ChannelAdapter(Protocol):
    """Minimal interface that a platform-specific adapter must implement."""

    platform: str

    def publish(self, draft: ScheduledDraft) -> str:
        """Publish the draft. Returns platform post_id."""
        ...

    def delete_post(self, post_id: str) -> bool:
        """Delete a post by platform post_id. Returns True if deleted."""
        ...


_CHANNEL_REGISTRY: Dict[str, ChannelAdapter] = {}


def register_channel(adapter: ChannelAdapter) -> None:
    """Register a channel adapter at runtime. Wave-2 adapters call this
    on import. Re-registering overwrites — tests rely on this to swap
    in mocks."""
    _CHANNEL_REGISTRY[adapter.platform] = adapter


def get_channel(platform: str) -> Optional[ChannelAdapter]:
    return _CHANNEL_REGISTRY.get(platform)


def _reset_registry_for_tests() -> None:
    """Test helper — clears all registered adapters so each test starts
    from a known baseline."""
    _CHANNEL_REGISTRY.clear()
    register_channel(DryRunAdapter())


class DryRunAdapter:
    """Default placeholder adapter. Logs 'would publish to X: <body>' to
    execution_log instead of hitting a real platform. Wave-2 agents
    replace this with real Twitter/Reddit/etc adapters.

    publish() returns a synthetic post_id so the end-to-end flow works
    in tests without mocking the network.
    """

    platform = "dry_run"

    def publish(self, draft: ScheduledDraft) -> str:
        post_id = f"dryrun_{draft.draft_id}_{int(time.time())}"
        logger.info("DryRunAdapter.publish draft_id=%s platform=%s body=%r",
                    draft.draft_id, draft.platform, draft.body[:80])
        _log_scheduler_audit(
            action="content_scheduler_dry_publish",
            draft_id=draft.draft_id,
            detail={
                "platform": draft.platform,
                "tier": draft.tier,
                "body_preview": draft.body[:200],
                "post_id": post_id,
            },
        )
        return post_id

    def delete_post(self, post_id: str) -> bool:
        logger.info("DryRunAdapter.delete_post post_id=%s", post_id)
        _log_scheduler_audit(
            action="content_scheduler_dry_delete",
            draft_id=post_id,
            detail={"post_id": post_id},
        )
        return True


# Register the dry-run adapter on import so the scheduler is usable
# out of the box. Wave-2 adapters can register additional platforms.
register_channel(DryRunAdapter())


def _autoload_pipeline_adapters() -> None:
    """Best-effort import of content_pipeline_adapter.register_channel_adapters.

    The adapter module reaches into ``decker_system/04_tools/content`` via
    dynamic path resolution, so in test sandboxes where that tree doesn't
    exist (or in packaging environments where we don't want the real
    publishers wired) the import is allowed to fail silently — the
    DryRunAdapter still covers ``dry_run`` and tests always re-register
    the adapters they need explicitly.
    """
    try:
        from aibrain.core import content_pipeline_adapter as _cpa
        _cpa.register_channel_adapters()
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("content_pipeline_adapter autoload skipped: %s", exc)


_autoload_pipeline_adapters()


# ---------------------------------------------------------------------------
# DB access
# ---------------------------------------------------------------------------

def _get_db_path() -> Path:
    """Canonical DB resolver — uses harness._get_or_create_db so Bug #6
    compliance is automatic and so tests that monkeypatch the harness
    resolver also redirect the scheduler."""
    from aibrain.core import harness
    return harness._get_or_create_db()


def _connect() -> sqlite3.Connection:
    db = sqlite3.connect(str(_get_db_path()))
    db.execute("PRAGMA journal_mode=WAL")
    _ensure_schema(db)
    return db


def _ensure_schema(db: sqlite3.Connection) -> None:
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS content_queue (
            draft_id TEXT PRIMARY KEY,
            tier TEXT NOT NULL CHECK(tier IN ('T1', 'T2', 'T3')),
            title TEXT,
            body TEXT NOT NULL,
            platform TEXT NOT NULL,
            author TEXT NOT NULL,
            metadata TEXT,
            queued_at TIMESTAMP NOT NULL,
            fires_at TIMESTAMP NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('queued', 'publishing', 'published', 'vetoed', 'killed', 'failed')),
            veto_reason TEXT,
            published_post_id TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    db.execute(
        "CREATE INDEX IF NOT EXISTS idx_content_queue_status_fires "
        "ON content_queue(status, fires_at)"
    )
    db.execute(
        "CREATE INDEX IF NOT EXISTS idx_content_queue_post_id "
        "ON content_queue(published_post_id)"
    )
    db.commit()


def _log_scheduler_audit(action: str, draft_id: str, detail: Dict[str, Any]) -> None:
    """Write a row to execution_log. Silent on failure — audit is
    best-effort, the scheduler should never crash because logging broke.
    """
    try:
        from aibrain.core import harness
        db_path = harness._get_or_create_db()
        db = sqlite3.connect(str(db_path))
        try:
            db.execute(
                """
                CREATE TABLE IF NOT EXISTS execution_log (
                    id TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL,
                    actor TEXT NOT NULL,
                    action TEXT NOT NULL,
                    entity_type TEXT,
                    entity_id TEXT,
                    detail TEXT,
                    quality_score REAL,
                    self_score REAL,
                    divergence REAL,
                    flagged INTEGER DEFAULT 0,
                    model_used TEXT,
                    cost_cents INTEGER DEFAULT 0,
                    cost_cents_actual INTEGER,
                    cost_cents_equivalent INTEGER,
                    duration_ms INTEGER DEFAULT 0,
                    before_state TEXT,
                    after_state TEXT,
                    success INTEGER DEFAULT 0,
                    error TEXT,
                    task_type TEXT,
                    authority TEXT,
                    retries INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            import secrets
            db.execute(
                """
                INSERT INTO execution_log (id, run_id, actor, action, entity_type,
                    entity_id, detail, success, task_type, authority)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    secrets.token_urlsafe(8),
                    f"content_scheduler_{int(time.time())}",
                    "content_scheduler",
                    action,
                    "content_draft",
                    draft_id,
                    json.dumps(detail, default=str),
                    1,
                    "deterministic",
                    "standard",
                ),
            )
            db.commit()
        finally:
            db.close()
    except Exception as exc:  # pragma: no cover - best-effort logging
        logger.debug("content_scheduler audit write failed: %s", exc)


# ---------------------------------------------------------------------------
# Telegram notification
# ---------------------------------------------------------------------------

def _send_veto_window_notification(draft: ScheduledDraft) -> bool:
    """Notify Decker that a T2/T3 draft is waiting. Best-effort — if
    the decker_system agent_comms helper isn't importable (test env,
    packaging sandbox) we log and move on.
    """
    text = _format_veto_window_message(draft)
    sender = _resolve_telegram_sender()
    if sender is None:
        logger.info("telegram sender unavailable; draft %s notification skipped",
                    draft.draft_id)
        return False
    try:
        return bool(sender(DECKER_DM_CHAT_ID, text))
    except Exception as exc:  # pragma: no cover - network path
        logger.warning("telegram notification failed for %s: %s", draft.draft_id, exc)
        return False


def _format_veto_window_message(draft: ScheduledDraft) -> str:
    delay_seconds = TIER_DELAYS[draft.tier]
    hours = delay_seconds // 3600
    lines = [
        f"[content_intel_agent] {draft.tier} draft queued — fires in {hours}h",
        f"draft_id: {draft.draft_id}",
        f"platform: {draft.platform}",
        f"author:   {draft.author}",
    ]
    if draft.title:
        lines.append(f"title:    {draft.title}")
    lines.append("")
    lines.append("--- body ---")
    lines.append(draft.body)
    lines.append("--- end ---")
    lines.append("")
    lines.append(f"To cancel: /veto {draft.draft_id}")
    lines.append(f"Fires at (UTC): {draft.fires_at.isoformat()}")
    return "\n".join(lines)


# Tests monkeypatch this to replace the real telegram sender.
_telegram_sender_override: Optional[Callable[[int, str], bool]] = None


def set_telegram_sender(sender: Optional[Callable[[int, str], bool]]) -> None:
    """Inject an alternate telegram sender. Used by tests to capture
    outbound messages without hitting the real bot."""
    global _telegram_sender_override
    _telegram_sender_override = sender


def _resolve_telegram_sender() -> Optional[Callable[[int, str], bool]]:
    if _telegram_sender_override is not None:
        return _telegram_sender_override
    # Lazy import — decker_system/04_tools is not a package, so we load
    # agent_comms by file path and pull out reply_to_telegram.
    try:
        import importlib.util
        comms_path = Path(os.environ.get("AIBRAIN_COMMS_PATH", ""))
        if not comms_path.exists():
            return None
        spec = importlib.util.spec_from_file_location("_decker_agent_comms", comms_path)
        if spec is None or spec.loader is None:
            return None
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        fn = getattr(module, "reply_to_telegram", None)
        if fn is None:
            return None
        return lambda chat_id, text: bool(fn(chat_id, text))
    except Exception as exc:  # pragma: no cover - import path
        logger.debug("agent_comms import failed: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Rate limit gate (publish-time double-check)
# ---------------------------------------------------------------------------

def _rate_limit_ok(db: sqlite3.Connection, platform: str,
                   now: Optional[datetime] = None) -> bool:
    """Return True if another post to `platform` is still within the
    daily limits. Counts drafts with status='published' inside the last
    24h window, both per-platform and total.
    """
    now = now or _utcnow()
    cutoff = (now - timedelta(days=1)).isoformat()

    per_platform = db.execute(
        """
        SELECT COUNT(*) FROM content_queue
        WHERE status = 'published'
          AND platform = ?
          AND fires_at >= ?
        """,
        (platform, cutoff),
    ).fetchone()[0]
    if per_platform >= MAX_POSTS_PER_PLATFORM_PER_DAY:
        return False

    total = db.execute(
        """
        SELECT COUNT(*) FROM content_queue
        WHERE status = 'published'
          AND fires_at >= ?
        """,
        (cutoff,),
    ).fetchone()[0]
    return total < MAX_POSTS_TOTAL_PER_DAY


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_tick_lock = threading.Lock()


def enqueue(draft_id: str, tier: str, title: Optional[str], body: str,
            platform: str, author: str,
            metadata: Optional[Dict[str, Any]] = None) -> ScheduledDraft:
    """Queue a draft with the tier-appropriate delay.

    The caller is responsible for running the 12-gate stack BEFORE
    calling this function. The scheduler trusts the draft is clean.

    Returns the ScheduledDraft with fires_at computed. T2 and T3
    enqueues trigger a Telegram notification to Decker.
    """
    if tier not in TIER_DELAYS:
        raise ValueError(f"unknown tier {tier!r}; expected one of {list(TIER_DELAYS)}")
    metadata = dict(metadata or {})
    now = _utcnow()
    fires_at = now + timedelta(seconds=TIER_DELAYS[tier])
    draft = ScheduledDraft(
        draft_id=draft_id,
        tier=tier,  # type: ignore[arg-type]
        title=title,
        body=body,
        platform=platform,
        author=author,
        metadata=metadata,
        queued_at=now,
        fires_at=fires_at,
        status="queued",
    )

    db = _connect()
    try:
        db.execute(
            """
            INSERT INTO content_queue
            (draft_id, tier, title, body, platform, author, metadata,
             queued_at, fires_at, status, veto_reason, published_post_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            draft.to_row(),
        )
        db.commit()
    finally:
        db.close()

    _log_scheduler_audit(
        action="content_scheduler_enqueue",
        draft_id=draft_id,
        detail={
            "tier": tier,
            "platform": platform,
            "author": author,
            "fires_at": fires_at.isoformat(),
        },
    )

    # Tier-specific notifications. T1 fires on next tick — no point
    # pinging Decker because the post will be live before he reads it.
    if tier in ("T2", "T3"):
        _send_veto_window_notification(draft)

    return draft


def veto(draft_id: str, reason: str) -> bool:
    """Pull a queued draft from the queue before it fires.

    Returns True if the draft was queued and is now vetoed. Returns
    False if the draft doesn't exist or already fired (published /
    killed / failed / vetoed).
    """
    db = _connect()
    try:
        cur = db.execute(
            """
            UPDATE content_queue
            SET status = 'vetoed',
                veto_reason = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE draft_id = ? AND status = 'queued'
            """,
            (reason, draft_id),
        )
        db.commit()
        vetoed = cur.rowcount > 0
    finally:
        db.close()

    _log_scheduler_audit(
        action="content_scheduler_veto",
        draft_id=draft_id,
        detail={"reason": reason, "applied": vetoed},
    )
    return vetoed


def get_draft(draft_id: str) -> Optional[ScheduledDraft]:
    db = _connect()
    try:
        row = db.execute(
            """
            SELECT draft_id, tier, title, body, platform, author, metadata,
                   queued_at, fires_at, status, veto_reason, published_post_id
            FROM content_queue
            WHERE draft_id = ?
            """,
            (draft_id,),
        ).fetchone()
    finally:
        db.close()
    return ScheduledDraft.from_row(row) if row else None


def get_queue_status() -> List[ScheduledDraft]:
    """Return all queued drafts ordered by fires_at ascending so the
    next-to-fire sits at index 0. Useful for the /queue Telegram
    command and the dashboard."""
    db = _connect()
    try:
        rows = db.execute(
            """
            SELECT draft_id, tier, title, body, platform, author, metadata,
                   queued_at, fires_at, status, veto_reason, published_post_id
            FROM content_queue
            WHERE status = 'queued'
            ORDER BY fires_at ASC
            """,
        ).fetchall()
    finally:
        db.close()
    return [ScheduledDraft.from_row(r) for r in rows]


def run_scheduler_tick(now: Optional[datetime] = None) -> List[ScheduledDraft]:
    """Fire every draft whose fires_at has passed and is still queued.

    Called periodically by the workflow cron (wave-2 wires this into
    scheduled_jobs.json). Thread-safe via a module lock + a DB-level
    status transition guard so two concurrent ticks cannot publish the
    same draft twice.

    Rate limit: if a draft's platform is over quota, the draft is
    pushed one hour forward and retried on the next tick instead of
    failing. This prevents queue bunching at tick boundaries.

    Returns the list of drafts that fired this tick (published OR
    failed — NOT rate-limit-retried, those stay queued).
    """
    now = now or _utcnow()
    fired: List[ScheduledDraft] = []

    with _tick_lock:
        db = _connect()
        try:
            # Find candidates. The publish step re-checks status inside
            # a transaction so concurrent ticks can't double-publish.
            rows = db.execute(
                """
                SELECT draft_id, tier, title, body, platform, author, metadata,
                       queued_at, fires_at, status, veto_reason, published_post_id
                FROM content_queue
                WHERE status = 'queued' AND fires_at <= ?
                ORDER BY fires_at ASC
                """,
                (now.isoformat(),),
            ).fetchall()
            candidates = [ScheduledDraft.from_row(r) for r in rows]
        finally:
            db.close()

        for draft in candidates:
            result = _attempt_publish(draft, now)
            if result is not None:
                fired.append(result)

    return fired


def _attempt_publish(draft: ScheduledDraft,
                     now: datetime) -> Optional[ScheduledDraft]:
    """Try to publish one draft. Returns the updated ScheduledDraft on
    success or failure, or None if the draft was rate-limit-deferred
    or lost a concurrency race.
    """
    db = _connect()
    try:
        # Concurrency guard: claim the draft by flipping status to an
        # interim state that only one tick can win. Using the filter
        # `WHERE status='queued'` in the UPDATE makes this atomic even
        # across connections.
        cur = db.execute(
            """
            UPDATE content_queue
            SET status = 'publishing', updated_at = CURRENT_TIMESTAMP
            WHERE draft_id = ? AND status = 'queued'
            """,
            (draft.draft_id,),
        )
        db.commit()
        if cur.rowcount == 0:
            # Another tick beat us, or the draft was vetoed in the gap.
            return None

        # Rate limit check — at publish time, not enqueue time.
        if not _rate_limit_ok(db, draft.platform, now):
            new_fires_at = now + timedelta(seconds=RATE_LIMIT_RETRY_DELAY_SECONDS)
            db.execute(
                """
                UPDATE content_queue
                SET status = 'queued',
                    fires_at = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE draft_id = ?
                """,
                (new_fires_at.isoformat(), draft.draft_id),
            )
            db.commit()
            _log_scheduler_audit(
                action="content_scheduler_rate_limited",
                draft_id=draft.draft_id,
                detail={
                    "platform": draft.platform,
                    "retry_at": new_fires_at.isoformat(),
                },
            )
            return None

        # Actually publish.
        adapter = get_channel(draft.platform) or get_channel("dry_run")
        if adapter is None:
            db.execute(
                """
                UPDATE content_queue
                SET status = 'failed', updated_at = CURRENT_TIMESTAMP
                WHERE draft_id = ?
                """,
                (draft.draft_id,),
            )
            db.commit()
            _log_scheduler_audit(
                action="content_scheduler_publish_failed",
                draft_id=draft.draft_id,
                detail={"error": "no channel adapter registered",
                        "platform": draft.platform},
            )
            draft.status = "failed"
            return draft

        try:
            post_id = adapter.publish(draft)
        except Exception as exc:
            db.execute(
                """
                UPDATE content_queue
                SET status = 'failed', updated_at = CURRENT_TIMESTAMP
                WHERE draft_id = ?
                """,
                (draft.draft_id,),
            )
            db.commit()
            _log_scheduler_audit(
                action="content_scheduler_publish_failed",
                draft_id=draft.draft_id,
                detail={"error": str(exc), "platform": draft.platform},
            )
            draft.status = "failed"
            return draft

        db.execute(
            """
            UPDATE content_queue
            SET status = 'published',
                published_post_id = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE draft_id = ?
            """,
            (post_id, draft.draft_id),
        )
        db.commit()
        draft.status = "published"
        draft.published_post_id = post_id
        _log_scheduler_audit(
            action="content_scheduler_published",
            draft_id=draft.draft_id,
            detail={"platform": draft.platform, "post_id": post_id,
                    "tier": draft.tier},
        )
        return draft
    finally:
        db.close()


def kill_published(published_post_id: str, reason: str) -> bool:
    """Post-publish kill switch.

    Looks up a draft by its published_post_id, calls the channel
    adapter's delete_post, and flips status to 'killed'. Returns
    True if the post was successfully killed (adapter returned True
    and DB was updated), False otherwise.

    Per spec, this is the 24-hour recovery path — the caller (or the
    telegram command handler) is responsible for enforcing the 24h
    window if desired. We do not enforce it at this layer because the
    same API is useful for manual admin recovery.
    """
    db = _connect()
    try:
        row = db.execute(
            """
            SELECT draft_id, tier, title, body, platform, author, metadata,
                   queued_at, fires_at, status, veto_reason, published_post_id
            FROM content_queue
            WHERE published_post_id = ?
            """,
            (published_post_id,),
        ).fetchone()
        if row is None:
            _log_scheduler_audit(
                action="content_scheduler_kill_not_found",
                draft_id=published_post_id,
                detail={"reason": reason},
            )
            return False
        draft = ScheduledDraft.from_row(row)
        if draft.status != "published":
            _log_scheduler_audit(
                action="content_scheduler_kill_bad_state",
                draft_id=draft.draft_id,
                detail={"current_status": draft.status, "reason": reason},
            )
            return False

        adapter = get_channel(draft.platform) or get_channel("dry_run")
        if adapter is None:
            return False
        try:
            ok = adapter.delete_post(published_post_id)
        except Exception as exc:
            _log_scheduler_audit(
                action="content_scheduler_kill_failed",
                draft_id=draft.draft_id,
                detail={"error": str(exc), "post_id": published_post_id},
            )
            return False
        if not ok:
            return False

        db.execute(
            """
            UPDATE content_queue
            SET status = 'killed',
                veto_reason = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE draft_id = ?
            """,
            (reason, draft.draft_id),
        )
        db.commit()
        _log_scheduler_audit(
            action="content_scheduler_killed",
            draft_id=draft.draft_id,
            detail={"post_id": published_post_id, "reason": reason},
        )
        return True
    finally:
        db.close()


__all__ = [
    "ScheduledDraft",
    "ChannelAdapter",
    "DryRunAdapter",
    "TIER_DELAYS",
    "DECKER_DM_CHAT_ID",
    "register_channel",
    "get_channel",
    "set_telegram_sender",
    "enqueue",
    "veto",
    "get_draft",
    "get_queue_status",
    "run_scheduler_tick",
    "kill_published",
]
