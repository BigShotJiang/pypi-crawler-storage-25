"""
brain_self_model.py — The brain's model of itself (meta-cognition).

Queries all active memories, groups by domain/type, and builds a knowledge map
showing what the brain knows, how deep its knowledge is, and where gaps exist.

Usage:
    from aibrain.core.brain_self_model import knowledge_map
    km = knowledge_map()

CLI:
    aibrain knowledge           — show what the brain knows
    aibrain knowledge --json    — machine-readable output
"""

import json
import sqlite3
from collections import defaultdict
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Domain detection — keyword-based classification
# ---------------------------------------------------------------------------

DOMAIN_KEYWORDS: dict[str, list[str]] = {
    "security": [
        "vulnerability", "exploit", "cve", "attack", "pentest", "scan",
        "wintermute", "remediate", "permeate", "rogue", "paragon",
        "adversarial", "threat", "defense", "offensive", "bug bounty",
        "injection", "xss", "sqli", "csrf", "ssrf", "rce", "lfi",
    ],
    "architecture": [
        "architecture", "design", "system_thinking", "pattern", "refactor",
        "modular", "abstraction", "interface", "schema", "migration",
    ],
    "product": [
        "product", "feature", "roadmap", "release", "pricing", "tier",
        "marketplace", "launch", "onboarding", "ux", "dashboard",
    ],
    "operations": [
        "deploy", "ci/cd", "cron", "infra", "server", "docker",
        "scheduled", "workflow", "devops", "monitoring", "heartbeat",
    ],
    "git": [
        "git", "commit", "branch", "merge", "rebase", "push", "pull",
        "github", "repo",
    ],
    "marketing": [
        "marketing", "outreach", "campaign", "seo", "content", "social",
        "influencer", "email campaign", "launch calendar",
    ],
    "trading": [
        "trading", "momentum", "exchange", "crypto", "eth", "token",
        "swap", "liquidity", "edge", "adverse selection",
    ],
    "research": [
        "paper", "arxiv", "selroute", "benchmark", "evaluation",
        "routing", "embedding", "model", "llm", "inference",
    ],
    "memory_system": [
        "memory", "embedding", "vector", "fts", "retrieval", "brain",
        "consolidat", "retention", "recall", "semantic",
    ],
    "job_search": [
        "job", "application", "resume", "interview", "salary",
        "seek", "linkedin", "hiring",
    ],
}

# Expected domains for a well-rounded brain — used for gap detection
EXPECTED_DOMAINS = set(DOMAIN_KEYWORDS.keys())


def _resolve_db_path(db_path: Optional[str] = None) -> str:
    """Resolve aibrain.db path via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    if db_path:
        return db_path
    from aibrain_db import AIBRAIN_ROOT
    return str(AIBRAIN_ROOT / "aibrain.db")


def _classify_domain(text: str) -> list[str]:
    """Classify a text string into zero or more domains by keyword matching."""
    text_lower = text.lower()
    domains = []
    for domain, keywords in DOMAIN_KEYWORDS.items():
        for kw in keywords:
            if kw in text_lower:
                domains.append(domain)
                break
    return domains if domains else ["uncategorized"]


def _extract_tag_domains(tags: str) -> list[str]:
    """Extract explicit domain:X tags from the tags field."""
    if not tags:
        return []
    domains = []
    # Handle JSON-array style tags
    if tags.startswith("["):
        try:
            tag_list = json.loads(tags)
        except (json.JSONDecodeError, ValueError):
            tag_list = tags.split(",")
    else:
        tag_list = tags.split(",")

    for tag in tag_list:
        tag = tag.strip().strip('"')
        if tag.startswith("domain:"):
            domains.append(tag[7:])
    return domains


def knowledge_map(db_path: Optional[str] = None) -> dict[str, Any]:
    """Build the brain's self-model — a knowledge map of what it knows.

    Returns a dict with:
        - total_active: int — total active memories
        - total_embedded: int — memories with vector embeddings
        - embedding_coverage: float — fraction embedded
        - by_type: dict[str, int] — count per memory type
        - by_domain: dict[str, dict] — per-domain breakdown with count, types, sample_names
        - gaps: list[str] — expected domains with zero or very few memories
        - strengths: list[str] — domains with the most memories
        - depth_score: float — 0.0-1.0 measure of domain coverage breadth
    """
    db_file = _resolve_db_path(db_path)
    conn = sqlite3.connect(db_file)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    # Detect schema: some DBs use 'status' column, others use 'active' (int)
    cur.execute("PRAGMA table_info(memories)")
    columns = {row[1] for row in cur.fetchall()}
    if "status" in columns:
        active_filter = "status='active'"
    elif "active" in columns:
        active_filter = "active=1"
    else:
        active_filter = "1=1"  # no filter available

    # --- Counts ---
    cur.execute(f"SELECT COUNT(*) FROM memories WHERE {active_filter}")  # noqa:sql-fstring — active_filter is hardcoded, not user input
    total_active = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM memories")
    total_all = cur.fetchone()[0]

    # Vec embeddings count
    try:
        cur.execute("SELECT COUNT(*) FROM memories_vec_rowids")
        total_embedded = cur.fetchone()[0]
    except sqlite3.OperationalError:
        total_embedded = 0

    embedding_coverage = total_embedded / total_all if total_all > 0 else 0.0

    # --- By type ---
    cur.execute(
        f"SELECT type, COUNT(*) as cnt FROM memories WHERE {active_filter} "  # noqa:sql-fstring
        "GROUP BY type ORDER BY cnt DESC"
    )
    by_type = {row["type"]: row["cnt"] for row in cur.fetchall()}

    # --- Domain classification ---
    # Fetch active memories: id, name, type, tags, first 500 chars of content
    cur.execute(
        f"SELECT id, name, type, tags, SUBSTR(content, 1, 500) as excerpt "  # noqa:sql-fstring
        f"FROM memories WHERE {active_filter}"  # noqa:sql-fstring
    )
    rows = cur.fetchall()

    domain_data: dict[str, dict[str, Any]] = defaultdict(
        lambda: {"count": 0, "types": defaultdict(int), "sample_names": []}
    )

    for row in rows:
        # Try explicit tag domains first
        domains = _extract_tag_domains(row["tags"] or "")
        if not domains:
            # Fall back to keyword classification on name + excerpt
            text = f"{row['name'] or ''} {row['excerpt'] or ''} {row['tags'] or ''}"
            domains = _classify_domain(text)

        for domain in domains:
            entry = domain_data[domain]
            entry["count"] += 1
            entry["types"][row["type"]] += 1
            if len(entry["sample_names"]) < 5:
                entry["sample_names"].append(row["name"] or f"memory_{row['id']}")

    # Convert defaultdicts to regular dicts for serialization
    by_domain = {}
    for domain, data in sorted(domain_data.items(), key=lambda x: -x[1]["count"]):
        by_domain[domain] = {
            "count": data["count"],
            "types": dict(data["types"]),
            "sample_names": data["sample_names"],
        }

    # --- Gap analysis ---
    domain_counts = {d: by_domain.get(d, {}).get("count", 0) for d in EXPECTED_DOMAINS}
    threshold = max(1, total_active * 0.01)  # <1% of total = gap
    gaps = [d for d, c in sorted(domain_counts.items()) if c < threshold]
    strengths = sorted(domain_counts, key=lambda d: -domain_counts[d])[:5]

    # Depth score: what fraction of expected domains have meaningful coverage
    covered = sum(1 for c in domain_counts.values() if c >= threshold)
    depth_score = covered / len(EXPECTED_DOMAINS) if EXPECTED_DOMAINS else 0.0

    conn.close()

    return {
        "total_active": total_active,
        "total_all": total_all,
        "total_embedded": total_embedded,
        "embedding_coverage": round(embedding_coverage, 3),
        "by_type": by_type,
        "by_domain": by_domain,
        "gaps": gaps,
        "strengths": strengths,
        "depth_score": round(depth_score, 2),
    }


def cli_knowledge(args: list[str]) -> int:
    """CLI handler for 'aibrain knowledge'."""
    as_json = "--json" in args
    db_path = None
    if "--db" in args:
        idx = args.index("--db")
        db_path = args[idx + 1] if idx + 1 < len(args) else None

    km = knowledge_map(db_path=db_path)

    if as_json:
        print(json.dumps(km, indent=2, default=str))
        return 0

    print("\n  Brain Self-Model")
    print(f"  {'=' * 50}")
    print(f"  Active memories:    {km['total_active']:,}")
    print(f"  Total (inc. archived): {km['total_all']:,}")
    print(f"  Embedded:           {km['total_embedded']:,} ({km['embedding_coverage']:.1%})")
    print(f"  Depth score:        {km['depth_score']:.0%} ({len(EXPECTED_DOMAINS)} domains)")

    print("\n  Memory Types")
    print(f"  {'─' * 40}")
    for mtype, count in km["by_type"].items():
        bar = "#" * min(count // 20, 40)
        print(f"  {mtype:<20s} {count:>5,}  {bar}")

    print("\n  Domain Knowledge")
    print(f"  {'─' * 40}")
    for domain, data in km["by_domain"].items():
        if data["count"] < 3:
            continue
        print(f"  {domain:<20s} {data['count']:>5,} memories")
        top_types = sorted(data["types"].items(), key=lambda x: -x[1])[:3]
        type_str = ", ".join(f"{t}({c})" for t, c in top_types)
        print(f"  {'':20s} types: {type_str}")

    if km["strengths"]:
        print("\n  Strengths (top 5)")
        print(f"  {'─' * 40}")
        for d in km["strengths"]:
            c = km["by_domain"].get(d, {}).get("count", 0)
            print(f"  + {d:<18s} {c:>5,} memories")

    if km["gaps"]:
        print("\n  Gaps (< 1% coverage)")
        print(f"  {'─' * 40}")
        for d in km["gaps"]:
            c = km["by_domain"].get(d, {}).get("count", 0)
            print(f"  - {d:<18s} {c:>5,} memories")

    print()
    return 0
