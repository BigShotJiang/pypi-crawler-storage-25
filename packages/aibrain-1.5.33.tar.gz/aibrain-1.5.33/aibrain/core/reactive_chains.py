"""
reactive_chains.py — Event-driven reactive handlers for the AIBrain event bus.

Three chains:
  1. CORRECTION_RECEIVED → update correction baseline, warn on high rate
  2. QUALITY_LOW → log failure, Telegram alert for critical workflows, suggest rerun
  3. TASK_COMPLETED → update agent completion metrics, record to evolution_outcomes

All handlers are fire-and-forget: wrapped in try/except, never raise,
never slow down the event bus.

Usage:
    from aibrain.core.reactive_chains import register_reactive_chains
    register_reactive_chains()   # call once at startup
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import urllib.request
import urllib.error
from collections import defaultdict
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.reactive_chains")

# ---------------------------------------------------------------------------
# In-memory counters (process-lifetime, no persistence needed — DB is source of truth)
# ---------------------------------------------------------------------------

_correction_counts: dict[str, int] = defaultdict(int)   # domain → count
_memory_counts: dict[str, int] = defaultdict(int)        # domain → total memories
_agent_completions: dict[str, int] = defaultdict(int)    # agent_id → completed tasks

# Threshold: if >25% of memories in a domain are corrections, warn
CORRECTION_RATE_THRESHOLD = 0.25

# Workflows considered critical (quality failures trigger Telegram alerts)
CRITICAL_WORKFLOWS = frozenset({
    "heartbeat", "db_backup", "service_monitor", "telegram_check",
    "brain_sync", "scheduled_runner",
})

_registered = False


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

def _get_db_path() -> Optional[Path]:
    """Resolve aibrain.db path."""
    root = os.environ.get("AIBRAIN_ROOT", "")
    if root:
        return Path(root) / "aibrain.db"
    here = Path(__file__).resolve().parent
    for p in [here.parent.parent, here.parent, Path.cwd()]:
        candidate = p / "aibrain.db"
        if candidate.exists():
            return candidate
    return None


def _connect() -> Optional[sqlite3.Connection]:
    """Open a connection to aibrain.db. Returns None if not found."""
    db_path = _get_db_path()
    if not db_path or not db_path.exists():
        return None
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


# ---------------------------------------------------------------------------
# Chain 1: CORRECTION_RECEIVED → update correction baseline
# ---------------------------------------------------------------------------

def on_correction_received(payload: dict) -> None:
    """Track correction rate per domain, warn if threshold exceeded."""
    try:
        from aibrain.core.correction_baseline import classify_domain

        content = payload.get("content_preview", "") or payload.get("name", "")
        domain = classify_domain(content)

        _correction_counts[domain] += 1
        _memory_counts[domain] += 1

        total = _memory_counts[domain]
        corrections = _correction_counts[domain]

        if total >= 4:  # need minimum sample before warning
            rate = corrections / total
            if rate > CORRECTION_RATE_THRESHOLD:
                log.warning(
                    "Correction rate for domain '%s' is %.0f%% (%d/%d) — exceeds %.0f%% threshold",
                    domain, rate * 100, corrections, total,
                    CORRECTION_RATE_THRESHOLD * 100,
                )

        log.debug(
            "Correction tracked: domain=%s, count=%d/%d",
            domain, corrections, total,
        )
    except Exception as e:
        log.debug("on_correction_received handler error: %s", e)


# ---------------------------------------------------------------------------
# Chain 2: QUALITY_LOW → alert + suggest rerun
# ---------------------------------------------------------------------------

def _send_telegram(message: str) -> bool:
    """Send a Telegram message to Decker. Returns True on success."""
    token = os.environ.get("TELEGRAM_TOKEN", "")
    chat_id = "8267616606"  # Decker DM

    if not token:
        # Try loading from .decker_env
        env_file = Path.home() / ".decker_env"
        if env_file.exists():
            try:
                for line in env_file.read_text().splitlines():
                    if line.startswith("TELEGRAM_TOKEN="):
                        token = line.split("=", 1)[1].strip().strip('"').strip("'")
                        break
            except Exception:
                pass

    if not token:
        log.debug("No TELEGRAM_TOKEN available, skipping alert")
        return False

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    data = json.dumps({"chat_id": chat_id, "text": message, "parse_mode": "Markdown"}).encode()

    try:
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=5)
        return True
    except Exception as e:
        log.debug("Telegram send failed: %s", e)
        return False


def on_quality_low(payload: dict) -> None:
    """Log quality failure details, alert Decker for critical workflows, suggest rerun."""
    try:
        task_name = payload.get("task_name", "unknown")
        eval_score = payload.get("eval_score", 0)
        detail = payload.get("detail", "")
        self_score = payload.get("self_score")

        log.warning(
            "QUALITY_LOW: task=%s eval_score=%.4f self_score=%s detail=%s",
            task_name, eval_score, self_score, detail,
        )

        # Check if this is a critical workflow
        # task_name may be "task:ID", "workflow.name", or a plain workflow name
        # Strip "task:" prefix first, then strip "workflow." prefix so
        # "workflow.heartbeat" correctly matches "heartbeat" in CRITICAL_WORKFLOWS
        base_name = task_name.split(":")[-1] if ":" in task_name else task_name
        if base_name.startswith("workflow."):
            base_name = base_name[len("workflow."):]
        is_critical = base_name in CRITICAL_WORKFLOWS

        if is_critical:
            msg = (
                f"*QUALITY ALERT*\n"
                f"Task: `{task_name}`\n"
                f"Score: {eval_score:.2f}\n"
                f"Detail: {detail[:200]}\n"
                f"Suggestion: rerun with elevated model or manual review"
            )
            _send_telegram(msg)

        # Log rerun suggestion
        log.info(
            "Suggest rerun: task=%s — try with task_type='complex' or manual review",
            task_name,
        )
    except Exception as e:
        log.debug("on_quality_low handler error: %s", e)


# ---------------------------------------------------------------------------
# Chain 3: TASK_COMPLETED → update company metrics
# ---------------------------------------------------------------------------

def on_task_completed(payload: dict) -> None:
    """Update agent completion count, track rate, record to evolution_outcomes."""
    try:
        task_id = payload.get("task_id", "")
        eval_score = payload.get("eval_score")
        self_score = payload.get("self_score")
        title = payload.get("title", "")

        # Look up the agent for this task
        agent_id = _get_task_agent(task_id)
        if agent_id:
            _agent_completions[agent_id] += 1
            log.debug(
                "Agent %s completed task %s (total: %d)",
                agent_id, task_id, _agent_completions[agent_id],
            )

        # Record to evolution_outcomes
        _record_completion_outcome(task_id, agent_id, eval_score, title)

    except Exception as e:
        log.debug("on_task_completed handler error: %s", e)


def _get_task_agent(task_id: str) -> Optional[str]:
    """Look up the assignee_agent_id for a task."""
    try:
        conn = _connect()
        if not conn:
            return None
        row = conn.execute(
            "SELECT assignee_agent_id FROM company_issues WHERE id=?",
            (task_id,),
        ).fetchone()
        conn.close()
        return row["assignee_agent_id"] if row else None
    except Exception:
        return None


def _record_completion_outcome(
    task_id: str,
    agent_id: Optional[str],
    eval_score: Optional[float],
    title: str,
) -> None:
    """Write a completion record to evolution_outcomes."""
    try:
        conn = _connect()
        if not conn:
            return

        conn.execute("""
            CREATE TABLE IF NOT EXISTS evolution_outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT, source_id TEXT, action TEXT,
                result TEXT, details TEXT, failure_reason TEXT,
                duration_seconds REAL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        result_str = "success" if (eval_score is None or eval_score >= 0.5) else "low_quality"
        details = json.dumps({
            "agent_id": agent_id,
            "eval_score": eval_score,
            "title": title,
        }, default=str)

        conn.execute(
            "INSERT INTO evolution_outcomes (source, source_id, action, result, details) "
            "VALUES (?, ?, ?, ?, ?)",
            ("reactive_chain", task_id, "task_completed", result_str, details),
        )
        conn.commit()
        conn.close()
    except Exception as e:
        log.debug("Failed to record completion outcome: %s", e)


# ---------------------------------------------------------------------------
# Chain 4: MEMORY_STORED → SCAN_FINDING_STORED for security memories
# ---------------------------------------------------------------------------

# Keywords that indicate a security/scan-related memory
_SECURITY_KEYWORDS = frozenset({
    "vuln", "exploit", "scan", "cve", "rce", "xss", "injection",
    "attack", "payload", "finding", "pentest", "brute", "auth bypass",
    "csrf", "kill-chain", "wintermute", "remediat", "nmap", "ssti",
    "sqli", "lfi", "rfi", "deserialization", "privilege escalation",
})


def _is_security_memory(payload: dict) -> bool:
    """Check if a memory payload is security/scan-related."""
    # Check type field
    mem_type = (payload.get("type") or "").lower()
    if mem_type in ("finding", "scan", "vulnerability"):
        return True

    # Check tags
    tags = payload.get("tags") or ""
    if isinstance(tags, list):
        tags = " ".join(tags)
    tags_lower = tags.lower()
    if any(kw in tags_lower for kw in ("security", "scan", "finding", "vuln", "exploit")):
        return True

    # Check content/name for security keywords
    text = " ".join(filter(None, [
        payload.get("name", ""),
        payload.get("content_preview", ""),
        payload.get("content", ""),
    ])).lower()

    return any(kw in text for kw in _SECURITY_KEYWORDS)


def on_memory_stored(payload: dict) -> None:
    """If a stored memory is security/scan-related, emit SCAN_FINDING_STORED.

    This bridges the brain's memory system to Wintermute's learning system
    (permeate_brain). The SCAN_FINDING_STORED event carries the original
    memory payload so downstream consumers can process the finding.
    """
    try:
        if not _is_security_memory(payload):
            return

        from aibrain.core.event_bus import emit as bus_emit, EventTypes
        bus_emit(EventTypes.SCAN_FINDING_STORED, {
            "memory_id": payload.get("id"),
            "name": payload.get("name", ""),
            "type": payload.get("type", ""),
            "tags": payload.get("tags", ""),
            "content_preview": payload.get("content_preview", "")
                or (payload.get("content", "") or "")[:200],
            "source": "memory_stored_bridge",
        })
        log.debug("SCAN_FINDING_STORED emitted for memory %s", payload.get("id"))
    except Exception as e:
        log.debug("on_memory_stored handler error: %s", e)


# ---------------------------------------------------------------------------
# Public: agent completion stats
# ---------------------------------------------------------------------------

def get_agent_completions() -> dict[str, int]:
    """Return a copy of the in-memory agent completion counts."""
    return dict(_agent_completions)


def get_correction_stats() -> dict[str, dict]:
    """Return correction rate stats per domain from in-memory counters."""
    result = {}
    for domain in set(list(_correction_counts.keys()) + list(_memory_counts.keys())):
        total = _memory_counts.get(domain, 0)
        corrections = _correction_counts.get(domain, 0)
        rate = corrections / total if total > 0 else 0.0
        result[domain] = {
            "corrections": corrections,
            "total": total,
            "rate": round(rate, 4),
            "warning": rate > CORRECTION_RATE_THRESHOLD and total >= 4,
        }
    return result


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register_reactive_chains() -> None:
    """Register all reactive chain handlers with the event bus.

    Safe to call multiple times — only registers once.
    """
    global _registered
    if _registered:
        return

    from aibrain.core.event_bus import on, EventTypes

    on(EventTypes.CORRECTION_RECEIVED, on_correction_received)
    on(EventTypes.QUALITY_LOW, on_quality_low)
    on(EventTypes.TASK_COMPLETED, on_task_completed)
    on(EventTypes.MEMORY_STORED, on_memory_stored)

    _registered = True
    log.debug("Reactive chains registered: CORRECTION_RECEIVED, QUALITY_LOW, TASK_COMPLETED, MEMORY_STORED")


def reset() -> None:
    """Reset all in-memory state and unregister handlers. For testing only."""
    global _registered
    _correction_counts.clear()
    _memory_counts.clear()
    _agent_completions.clear()

    from aibrain.core.event_bus import off, EventTypes
    off(EventTypes.CORRECTION_RECEIVED, on_correction_received)
    off(EventTypes.QUALITY_LOW, on_quality_low)
    off(EventTypes.TASK_COMPLETED, on_task_completed)
    off(EventTypes.MEMORY_STORED, on_memory_stored)

    _registered = False
