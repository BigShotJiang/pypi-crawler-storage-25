"""
correction_schema.py — Structured schema for correction-type memories.

When correction/feedback memories are stored, this module extracts structured
fields (error_category, wrong_action, correct_action, severity) and stores
them as JSON metadata alongside the memory content.

This enables:
  - Querying corrections by error domain
  - Measuring repeat-mistake rates per category
  - Feeding structured data into the correction_baseline system

Usage:
    from aibrain.core.correction_schema import extract_correction_fields, enrich_correction

    fields = extract_correction_fields(content)
    # {'error_category': 'git', 'wrong_action': '...', 'correct_action': '...', 'severity': 'major'}

    enriched = enrich_correction(name, content)
    # Returns content with structured JSON metadata appended
"""

from __future__ import annotations

import json
import logging
import re
from typing import Optional

log = logging.getLogger("aibrain.correction_schema")

# ---------------------------------------------------------------------------
# Severity keywords
# ---------------------------------------------------------------------------

_SEVERITY_MAP = {
    "critical": [
        "hard rule", "never", "critical", "catastrophic", "data loss",
        "credential", "security", "production down",
    ],
    "major": [
        "major", "broke", "broken", "wrong", "incorrect", "failed",
        "violation", "must", "always", "important",
    ],
    "minor": [
        "minor", "style", "preference", "typo", "cosmetic",
        "formatting", "naming", "convention",
    ],
    "info": [
        "note", "reminder", "tip", "fyi", "consider",
    ],
}

# ---------------------------------------------------------------------------
# Error category keywords (reuses correction_baseline domains + extras)
# ---------------------------------------------------------------------------

ERROR_CATEGORIES = {
    "security": [
        "credential", "api key", "token", "password", "secret", "vuln",
        "exploit", "scan", "cve", "injection", "attack", "auth",
    ],
    "git": [
        "git ", "commit", "push", "pull", "branch", "rebase", "merge",
        "co-authored", "repo separation", "sindecker", "deckerops",
    ],
    "aibrain": [
        "aibrain", "memory", "brain", "workflow", "harness", "evolution",
        "mcp", "agent", "skill", "profile", "doctor",
    ],
    "infrastructure": [
        "docker", "deploy", "server", "nginx", "port", "ssh",
        "tailscale", "ci/cd", "cron", "firewall", "process",
    ],
    "testing": [
        "test", "assert", "pytest", "verify", "fixture", "mock",
    ],
    "communications": [
        "telegram", "email", "outreach", "message", "notification",
        "publish", "approval",
    ],
    "config": [
        "config", "setting", "env var", ".env", "path", "backup",
    ],
    "deletion": [
        "delete", "remove", "rm ", "unlink", "archive", "purge",
    ],
    "data": [
        "data", "database", "query", "sql", "migration", "schema",
    ],
    "code_quality": [
        "refactor", "duplicate", "dead code", "complexity",
        "lint", "format", "clean",
    ],
}

# ---------------------------------------------------------------------------
# Action extraction patterns
# ---------------------------------------------------------------------------

# Patterns to extract "wrong" and "correct" actions from text
_WRONG_PATTERNS = [
    re.compile(r"(?:wrong|incorrect|bad|don'?t|never|stop)\s*(?:action|approach|way)?[:\-]?\s*(.+?)(?:\.|$)", re.IGNORECASE | re.MULTILINE),
    re.compile(r"(?:was doing|did|used to|mistake was|error was)[:\-]?\s*(.+?)(?:\.|$)", re.IGNORECASE | re.MULTILINE),
    re.compile(r"instead of\s+(.+?)(?:,|\.|$)", re.IGNORECASE),
]

_CORRECT_PATTERNS = [
    re.compile(r"(?:correct|right|should|must|always|instead)[:\-]?\s*(.+?)(?:\.|$)", re.IGNORECASE | re.MULTILINE),
    re.compile(r"(?:fix|solution|do this|use)\s*(?:instead)?[:\-]?\s*(.+?)(?:\.|$)", re.IGNORECASE | re.MULTILINE),
    re.compile(r"HARD RULE[:\-]?\s*(.+?)(?:\.|$)", re.IGNORECASE | re.MULTILINE),
]


# ---------------------------------------------------------------------------
# Core extraction
# ---------------------------------------------------------------------------

def classify_severity(content: str) -> str:
    """Classify the severity of a correction from its content."""
    lowered = content.lower()
    for severity, keywords in _SEVERITY_MAP.items():
        if any(kw in lowered for kw in keywords):
            return severity
    return "minor"


def classify_error_category(content: str) -> str:
    """Classify the error domain from correction content."""
    lowered = content.lower()
    for category, keywords in ERROR_CATEGORIES.items():
        if any(kw in lowered for kw in keywords):
            return category
    return "other"


def extract_wrong_action(content: str) -> str:
    """Extract what was done incorrectly from correction text."""
    for pattern in _WRONG_PATTERNS:
        match = pattern.search(content)
        if match:
            action = match.group(1).strip()
            if len(action) > 10:  # skip tiny fragments
                return action[:200]
    return ""


def extract_correct_action(content: str) -> str:
    """Extract what should have been done from correction text."""
    for pattern in _CORRECT_PATTERNS:
        match = pattern.search(content)
        if match:
            action = match.group(1).strip()
            if len(action) > 10:  # skip tiny fragments
                return action[:200]
    return ""


def extract_correction_fields(content: str) -> dict:
    """
    Extract structured correction fields from memory content.

    Returns dict with:
        error_category: domain of the error
        wrong_action: what was done incorrectly
        correct_action: what should have been done
        severity: how bad the error was
    """
    return {
        "error_category": classify_error_category(content),
        "wrong_action": extract_wrong_action(content),
        "correct_action": extract_correct_action(content),
        "severity": classify_severity(content),
    }


# ---------------------------------------------------------------------------
# Enrichment — append structured metadata to content
# ---------------------------------------------------------------------------

_CORRECTION_MARKER = "\n\n---CORRECTION_SCHEMA---\n"


def enrich_correction(name: str, content: str) -> str:
    """
    Enrich correction content with structured metadata.

    Appends a JSON block after a marker so it can be parsed back out
    without altering the human-readable text.
    """
    # Don't double-enrich
    if _CORRECTION_MARKER in content:
        return content

    fields = extract_correction_fields(content)
    fields["name"] = name

    return content + _CORRECTION_MARKER + json.dumps(fields)


def parse_correction_metadata(content: str) -> Optional[dict]:
    """
    Parse structured correction metadata from enriched content.

    Returns the metadata dict if present, None otherwise.
    """
    if _CORRECTION_MARKER not in content:
        return None

    try:
        _, json_part = content.split(_CORRECTION_MARKER, 1)
        return json.loads(json_part.strip())
    except (ValueError, json.JSONDecodeError):
        return None


def strip_correction_metadata(content: str) -> str:
    """Return the human-readable portion of correction content (without metadata)."""
    if _CORRECTION_MARKER not in content:
        return content
    return content.split(_CORRECTION_MARKER, 1)[0]
