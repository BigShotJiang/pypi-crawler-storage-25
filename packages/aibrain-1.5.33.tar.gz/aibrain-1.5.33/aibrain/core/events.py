"""
events.py — Centralized event catalog and emission for AIBrain.

Typed event constants and a single emit() helper that wraps PatternBus
emission. All lifecycle events across agents, tasks, teams, flows, MCP,
ingestion, memory, and hooks are defined here.

Usage:
    from aibrain.core.events import emit, Events

    emit(Events.TASK_START, "task-123", agent="Researcher", description="Find data")
    emit(Events.HOOK_BLOCKED, "web_search", hook="block_dangerous")
"""

from __future__ import annotations

import logging
import os
from typing import Any

log = logging.getLogger("aibrain.events")


# ---------------------------------------------------------------------------
# Event type constants
# ---------------------------------------------------------------------------

class Events:
    """All lifecycle event types in the AIBrain ecosystem."""

    # Agent lifecycle
    AGENT_START = "agent.start"
    AGENT_COMPLETE = "agent.complete"
    AGENT_ERROR = "agent.error"

    # Task lifecycle
    TASK_START = "task.start"
    TASK_COMPLETE = "task.complete"
    TASK_GUARDRAIL_FAIL = "task.guardrail_fail"
    TASK_GUARDRAIL_PASS = "task.guardrail_pass"

    # Team lifecycle
    TEAM_KICKOFF = "team.kickoff"
    TEAM_COMPLETE = "team.complete"
    TEAM_ERROR = "team.error"

    # Flow lifecycle
    FLOW_START = "flow.start"
    FLOW_STEP = "flow.step"
    FLOW_ROUTER = "flow.router"
    FLOW_COMPLETE = "flow.complete"
    FLOW_ERROR = "flow.error"
    FLOW_HITL_PENDING = "flow.hitl_pending"
    FLOW_HITL_RESUMED = "flow.hitl_resumed"

    # MCP lifecycle
    MCP_CONNECT = "mcp.connect"
    MCP_DISCONNECT = "mcp.disconnect"
    MCP_TOOL_CALL = "mcp.tool_call"
    MCP_TOOL_ERROR = "mcp.tool_error"
    MCP_TOOL_CACHED = "mcp.tool_cached"

    # Ingestion lifecycle
    INGEST_START = "ingest.start"
    INGEST_PROGRESS = "ingest.progress"
    INGEST_COMPLETE = "ingest.complete"
    INGEST_ERROR = "ingest.error"
    INGEST_SKIPPED = "ingest.skipped"

    # Memory lifecycle
    MEMORY_STORE = "memory.store"
    MEMORY_SEARCH = "memory.search"
    MEMORY_FORGET = "memory.forget"

    # Hook lifecycle
    HOOK_BEFORE_TOOL = "hook.before_tool"
    HOOK_AFTER_TOOL = "hook.after_tool"
    HOOK_BEFORE_LLM = "hook.before_llm"
    HOOK_AFTER_LLM = "hook.after_llm"
    HOOK_BLOCKED = "hook.blocked"


# Collect all event type strings for validation
ALL_EVENT_TYPES: set[str] = {
    v for k, v in vars(Events).items()
    if not k.startswith("_") and isinstance(v, str)
}


# ---------------------------------------------------------------------------
# Centralized emit function
# ---------------------------------------------------------------------------

def emit(
    event_type: str,
    key: str,
    value: Any = None,
    domain: str = "aibrain",
    source_agent: str | None = None,
    **metadata: Any,
) -> None:
    """Emit a DomainEvent via PatternBus. Fire-and-forget.

    Args:
        event_type: One of the Events constants (e.g. Events.TASK_START)
        key: Identifying key for the event (task id, tool name, etc.)
        value: Optional value associated with the event
        domain: Event domain (default "aibrain")
        source_agent: Override source agent (default from AGENT_ID env or "neuro")
        **metadata: Additional key-value pairs stored in event metadata
    """
    try:
        from backend.event_schema import DomainEvent, PatternBus

        agent = source_agent or os.environ.get("AGENT_ID", "neuro")
        bus = PatternBus()
        bus.emit(DomainEvent(
            domain=domain,
            source_agent=agent,
            event_type=event_type,
            key=key,
            value=value,
            metadata=metadata,
        ))
    except Exception as e:
        log.debug("Event emission failed (non-fatal): %s", e)
