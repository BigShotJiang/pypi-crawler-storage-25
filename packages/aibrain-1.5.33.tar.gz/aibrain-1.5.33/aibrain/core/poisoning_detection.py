"""Brain poisoning detection — scans memories for injection, shell commands, encoded payloads.

Required pre-check before Brain Marketplace imports. Detects:
- Shell commands embedded in memory content
- Prompt injection patterns (system prompt overrides, role hijacking)
- Base64-encoded payloads that decode to commands
- Suspicious URLs (data URIs, IP-only, shortened URLs)
- Memories that impersonate system instructions
"""

from __future__ import annotations

import base64
import json
import re
from pathlib import Path
from typing import Any


# ── Severity levels ──────────────────────────────────────────────────────────

CRITICAL = "critical"
HIGH = "high"
MEDIUM = "medium"
LOW = "low"


# ── Detection patterns ───────────────────────────────────────────────────────

# Shell commands — common dangerous executables or shell syntax
_SHELL_PATTERNS = [
    # Direct command execution
    re.compile(r'\b(?:sudo|chmod|chown|rm\s+-rf|curl\s+.*\|\s*(?:bash|sh)|wget\s+.*\|\s*(?:bash|sh))\b', re.IGNORECASE),
    # Piped shell execution
    re.compile(r'\bcurl\s+\S+\s*\|\s*(?:bash|sh|python|perl|ruby)\b', re.IGNORECASE),
    re.compile(r'\bwget\s+\S+\s*(?:-O\s*-\s*)?\|\s*(?:bash|sh|python|perl|ruby)\b', re.IGNORECASE),
    # Reverse shells
    re.compile(r'\b(?:nc|ncat|netcat)\s+.*-e\s+(?:/bin/)?(?:bash|sh)\b', re.IGNORECASE),
    re.compile(r'\bbash\s+-i\s+>&\s*/dev/tcp/', re.IGNORECASE),
    re.compile(r'\bpython[23]?\s+-c\s+["\']import\s+(?:socket|os|subprocess)', re.IGNORECASE),
    # PowerShell download cradles
    re.compile(r'\bpowershell\b.*(?:IEX|Invoke-Expression|DownloadString|Net\.WebClient)', re.IGNORECASE),
    # eval / exec with string building
    re.compile(r'\beval\s*\(\s*(?:compile|exec|__import__|chr\()', re.IGNORECASE),
    re.compile(r'\bexec\s*\(\s*(?:compile|__import__|chr\()', re.IGNORECASE),
    # OS command injection markers
    re.compile(r';\s*(?:cat|ls|id|whoami|uname|passwd|shadow)\b'),
    re.compile(r'\$\((?:curl|wget|cat|id|whoami)\b'),
    re.compile(r'`(?:curl|wget|cat|id|whoami)\b'),
]

# Prompt injection patterns
_INJECTION_PATTERNS = [
    # Direct override attempts
    re.compile(r'\bignore\s+(?:all\s+)?previous\s+instructions\b', re.IGNORECASE),
    re.compile(r'\bignore\s+(?:all\s+)?prior\s+instructions\b', re.IGNORECASE),
    re.compile(r'\bdisregard\s+(?:all\s+)?(?:previous|prior|above)\s+(?:instructions|rules|guidelines)\b', re.IGNORECASE),
    re.compile(r'\bforget\s+(?:all\s+)?(?:previous|prior|your)\s+(?:instructions|rules|guidelines|training)\b', re.IGNORECASE),
    # Role hijacking
    re.compile(r'\byou\s+are\s+now\s+(?:a\s+)?(?:different|new|my|an?\s+)\b', re.IGNORECASE),
    re.compile(r'\bact\s+as\s+(?:a\s+)?(?:different|new|my)\b', re.IGNORECASE),
    re.compile(r'\bpretend\s+(?:you\s+are|to\s+be)\s+(?:a\s+)?(?:different|new)\b', re.IGNORECASE),
    re.compile(r'\byour\s+new\s+(?:instructions|rules|role|purpose)\s+(?:are|is)\b', re.IGNORECASE),
    # System prompt extraction
    re.compile(r'\b(?:print|show|reveal|output|display|repeat)\s+(?:your\s+)?(?:system\s+prompt|instructions|rules|initial\s+prompt)\b', re.IGNORECASE),
    re.compile(r'\bwhat\s+(?:are|is)\s+your\s+(?:system\s+prompt|initial\s+instructions|rules)\b', re.IGNORECASE),
    # Delimiter injection
    re.compile(r'<\|(?:system|im_start|endoftext)\|>', re.IGNORECASE),
    re.compile(r'\[INST\]|\[/INST\]|\[SYSTEM\]', re.IGNORECASE),
    re.compile(r'```system\b', re.IGNORECASE),
]

# Suspicious URL patterns
_URL_PATTERNS = [
    # Data URIs with script content
    re.compile(r'data:(?:text/html|application/javascript|text/javascript)[;,]', re.IGNORECASE),
    # IP-only URLs (no hostname)
    re.compile(r'https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?::\d+)?/'),
    # Common URL shorteners (often used to hide malicious destinations)
    re.compile(r'https?://(?:bit\.ly|tinyurl\.com|t\.co|goo\.gl|is\.gd|buff\.ly|ow\.ly|rb\.gy|shorturl\.at)/\S+', re.IGNORECASE),
]

# System instruction impersonation
_SYSTEM_INSTRUCTION_PATTERNS = [
    re.compile(r'^(?:system\s*(?:prompt|message|instruction)\s*[:：])', re.IGNORECASE | re.MULTILINE),
    re.compile(r'^\[?system\]?\s*[:：]\s*you\s+(?:are|must|should|will)\b', re.IGNORECASE | re.MULTILINE),
    re.compile(r'\bthis\s+is\s+(?:a\s+)?(?:system|core|base)\s+(?:instruction|directive|rule)\b', re.IGNORECASE),
    re.compile(r'\b(?:OVERRIDE|PRIORITY)\s*[:：]\s*(?:MAXIMUM|HIGH|CRITICAL)\b', re.IGNORECASE),
    re.compile(r'\bIMPORTANT\s*[:：]\s*(?:always|never|must)\s+(?:follow|obey|execute|run)\b', re.IGNORECASE),
]


# ── Base64 payload detection ────────────────────────────────────────────────

# Matches base64 strings of at least 20 chars (enough to encode a short command)
_BASE64_RE = re.compile(r'(?:[A-Za-z0-9+/]{4}){5,}(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?')

# If decoded base64 contains any of these, flag it
_DANGEROUS_DECODED = [
    re.compile(r'\b(?:bash|sh|cmd|powershell|python|perl|ruby|curl|wget|nc|ncat)\b', re.IGNORECASE),
    re.compile(r'\b(?:eval|exec|system|popen|subprocess|os\.system)\b', re.IGNORECASE),
    re.compile(r'\b(?:rm\s+-rf|chmod|chown|passwd|shadow|/etc/)\b', re.IGNORECASE),
    re.compile(r'\b(?:import\s+os|import\s+subprocess|import\s+socket)\b', re.IGNORECASE),
]


# ── Core detection functions ────────────────────────────────────────────────

def _check_shell_commands(content: str) -> list[dict]:
    """Detect shell commands embedded in memory content."""
    findings = []
    for pat in _SHELL_PATTERNS:
        for match in pat.finditer(content):
            findings.append({
                "type": "shell_command",
                "severity": HIGH,
                "detail": f"Shell command detected: {match.group()[:120]}",
                "offset": match.start(),
                "pattern": pat.pattern[:80],
            })
    return findings


def _check_prompt_injection(content: str) -> list[dict]:
    """Detect prompt injection patterns."""
    findings = []
    for pat in _INJECTION_PATTERNS:
        for match in pat.finditer(content):
            findings.append({
                "type": "prompt_injection",
                "severity": CRITICAL,
                "detail": f"Prompt injection: {match.group()[:120]}",
                "offset": match.start(),
                "pattern": pat.pattern[:80],
            })
    return findings


def _check_base64_payloads(content: str) -> list[dict]:
    """Detect base64-encoded payloads that decode to commands."""
    findings = []
    for match in _BASE64_RE.finditer(content):
        candidate = match.group()
        try:
            # Pad if needed
            padded = candidate + "=" * (-len(candidate) % 4)
            decoded = base64.b64decode(padded, validate=True).decode("utf-8", errors="ignore")
        except Exception:
            continue
        # Check if decoded content contains dangerous patterns
        for danger_pat in _DANGEROUS_DECODED:
            if danger_pat.search(decoded):
                findings.append({
                    "type": "encoded_payload",
                    "severity": CRITICAL,
                    "detail": f"Base64 decodes to dangerous content: {decoded[:100]}",
                    "offset": match.start(),
                    "decoded_preview": decoded[:200],
                })
                break  # One finding per base64 string
    return findings


def _check_suspicious_urls(content: str) -> list[dict]:
    """Detect suspicious URLs (data URIs, IP-only, shortened)."""
    findings = []
    for pat in _URL_PATTERNS:
        for match in pat.finditer(content):
            severity = HIGH if "data:" in match.group().lower() else MEDIUM
            findings.append({
                "type": "suspicious_url",
                "severity": severity,
                "detail": f"Suspicious URL: {match.group()[:120]}",
                "offset": match.start(),
            })
    return findings


def _check_system_impersonation(content: str) -> list[dict]:
    """Detect memories that claim to be system instructions."""
    findings = []
    for pat in _SYSTEM_INSTRUCTION_PATTERNS:
        for match in pat.finditer(content):
            findings.append({
                "type": "system_impersonation",
                "severity": HIGH,
                "detail": f"System instruction impersonation: {match.group()[:120]}",
                "offset": match.start(),
            })
    return findings


# ── Public API ──────────────────────────────────────────────────────────────

def scan_memory(memory: dict) -> list[dict]:
    """Scan a single memory dict for poisoning indicators.

    Args:
        memory: dict with at least 'content' key. May also have 'id', 'type', 'tags'.

    Returns:
        List of finding dicts, each with: type, severity, detail, memory_id (if available).
    """
    content = memory.get("content", "")
    if not content:
        return []

    findings = []
    findings.extend(_check_shell_commands(content))
    findings.extend(_check_prompt_injection(content))
    findings.extend(_check_base64_payloads(content))
    findings.extend(_check_suspicious_urls(content))
    findings.extend(_check_system_impersonation(content))

    # Attach memory ID if available
    mem_id = memory.get("id")
    for f in findings:
        f["memory_id"] = mem_id

    return findings


def scan_brain(memories: list[dict]) -> list[dict]:
    """Scan a list of memories for poisoning indicators.

    Args:
        memories: list of memory dicts, each with at least 'content' key.

    Returns:
        List of all findings across all memories, sorted by severity.
    """
    severity_order = {CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3}
    all_findings: list[dict] = []
    for mem in memories:
        all_findings.extend(scan_memory(mem))
    all_findings.sort(key=lambda f: severity_order.get(f.get("severity", LOW), 99))
    return all_findings


def scan_import(import_path: str) -> list[dict]:
    """Scan a brain import file (JSON) for poisoning indicators before loading.

    Args:
        import_path: path to a JSON file containing exported brain data.

    Returns:
        List of findings. Empty list = safe to import.
    """
    path = Path(import_path).expanduser().resolve()
    if not path.exists():
        return [{"type": "error", "severity": CRITICAL, "detail": f"File not found: {path}"}]

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        return [{"type": "error", "severity": CRITICAL, "detail": f"Failed to parse import file: {e}"}]

    # Extract memories from standard brain export format
    memories = data.get("memories", [])
    if not memories and isinstance(data, list):
        # Maybe the file is just a list of memories
        memories = data

    if not memories:
        return [{"type": "info", "severity": LOW, "detail": "No memories found in import file"}]

    return scan_brain(memories)


def scan_import_summary(import_path: str) -> dict[str, Any]:
    """Scan and return a structured summary suitable for display.

    Returns:
        dict with keys: safe (bool), total_findings, by_severity, by_type, findings.
    """
    findings = scan_import(import_path)
    by_severity: dict[str, int] = {}
    by_type: dict[str, int] = {}
    for f in findings:
        sev = f.get("severity", "unknown")
        by_severity[sev] = by_severity.get(sev, 0) + 1
        ftype = f.get("type", "unknown")
        by_type[ftype] = by_type.get(ftype, 0) + 1

    has_critical = by_severity.get(CRITICAL, 0) > 0
    has_high = by_severity.get(HIGH, 0) > 0

    return {
        "safe": not has_critical and not has_high,
        "total_findings": len(findings),
        "by_severity": by_severity,
        "by_type": by_type,
        "findings": findings,
    }
