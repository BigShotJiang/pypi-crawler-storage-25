"""lenses_public.py — public lens floor that ships on PyPI.

v1.4 public/private lens split. This module contains ZERO named personas
and ZERO product jargon. It carries:

  * 20 standard role-worker lenses (generic job titles)
  * 13 specialty role-worker lenses (generic specialty titles)
  * 10 thinking-style archetypes (generic cognitive lenses)
  *  5 enterprise-tier stub slots (placeholders, filled in v1.4.1+)

  = 48 shippable lens entries

Two always-on safety lenses (`Operator Lens`, `Adversarial Security Lens`)
are added to every route. The `TIER_LENSES` map defines which lenses are
available to Free / Pro / Team / Enterprise users.

Decker's local install loads `decker_system/02_subagents/lens_overlay.py`
via `lens_router._load_overlay()`. Overlay keys REPLACE public-floor keys
entirely (Q4 decision) — same key, better content on Decker's machine.

See `tmp/design_lens_split_v14.md` for the full design and the 5 locked-in
Decker decisions driving this module's shape.
"""
from __future__ import annotations

# ---------------------------------------------------------------------------
# Always-on safety lenses — added to every route regardless of task_type.
# ---------------------------------------------------------------------------
# Neutral labels only. A private overlay can rename them on Decker's machine.
ALWAYS_ON_LENSES: list[str] = ["Operator Lens", "Adversarial Security Lens"]


# ---------------------------------------------------------------------------
# Public lens registry — name → {specialty, categories}
# ---------------------------------------------------------------------------
LENSES: dict[str, dict] = {
    # ───── Standard role workers (20 — generic job titles) ─────
    "CEO":                       {"specialty": "strategic synthesis",        "categories": ["strategy", "decision_making", "long_term"]},
    "CTO":                       {"specialty": "architecture authority",     "categories": ["architecture", "code_review", "systems", "decision_making"]},
    "Lead Engineer":             {"specialty": "implementation execution",   "categories": ["code_review", "engineering", "ship_first"]},
    "DevOps Engineer":           {"specialty": "deployment / CI / infra",    "categories": ["systems", "operations", "deployment"]},
    "Security Engineer":         {"specialty": "applied security review",    "categories": ["security", "code_review"]},
    "QA Lead":                   {"specialty": "test coverage / quality",    "categories": ["correctness", "code_review", "reliability"]},
    "Data Analyst":              {"specialty": "data verification / metrics", "categories": ["metrics", "data_modeling", "research"]},
    "Research Analyst":          {"specialty": "fact-finding / dossiers",    "categories": ["research", "metrics"]},
    "Product Manager":           {"specialty": "feature planning / roadmap", "categories": ["product", "strategy", "ux"]},
    "CMO":                       {"specialty": "marketing / outreach",       "categories": ["product", "content", "business"]},
    "Outreach Coordinator":      {"specialty": "creator outreach / email",   "categories": ["content", "operations"]},
    "Content Writer":            {"specialty": "long-form content",          "categories": ["content", "writing", "writing_synthesis"]},
    "SEO Specialist":            {"specialty": "discovery / search",         "categories": ["content", "business"]},
    "Video Producer":            {"specialty": "video / media",              "categories": ["content"]},
    "Community Manager":         {"specialty": "community / support",        "categories": ["product", "operations", "customer"]},
    "Legal Advisor":             {"specialty": "legal / compliance",         "categories": ["legal", "safety", "decision_making"]},
    "CFO":                       {"specialty": "financial planning",         "categories": ["business", "decision_making"]},
    "Accountant":                {"specialty": "invoices / records",         "categories": ["business", "operations"]},
    "HR Manager":                {"specialty": "hiring / onboarding",        "categories": ["operations", "founder"]},
    "COO":                       {"specialty": "operations / process",       "categories": ["operations", "scaling", "decision_making"]},

    # ───── Specialty role workers (13 — generic specialty titles) ─────
    "Architecture & Performance Analyst":    {"specialty": "architecture + performance pair review",  "categories": ["architecture", "performance", "scaling", "code_review"]},
    "Blue Team Defense Analyst":             {"specialty": "defensive security posture",              "categories": ["security", "reliability", "safety"]},
    "Chain Logic Reviewer":                  {"specialty": "attack chain correctness",                "categories": ["security", "correctness", "code_review"]},
    "Code Security Auditor":                 {"specialty": "per-commit code security review",         "categories": ["security", "code_review"]},
    "Communications Agent":                  {"specialty": "outbound message drafting + reply",       "categories": ["content", "operations", "writing_synthesis"]},
    "Competitive Intelligence Analyst":      {"specialty": "market + competitor + positioning",       "categories": ["strategy", "business", "research"]},
    "Dependency & Supply Chain Auditor":     {"specialty": "supply chain + dependency risk",          "categories": ["security", "reliability"]},
    "Integration & Regression Risk Analyst": {"specialty": "regression + integration safety",         "categories": ["correctness", "code_review", "reliability"]},
    "Product Philosopher":                   {"specialty": "product framing + positioning",           "categories": ["product", "strategy", "founder", "content"]},
    "QA & Test Coverage Analyst":            {"specialty": "test coverage gap analysis",              "categories": ["correctness", "code_review", "reliability"]},
    "Red Team Adversarial Reviewer":         {"specialty": "offensive security review",               "categories": ["security"]},
    "Strategic Archivist":                   {"specialty": "knowledge consolidation + recall",        "categories": ["research", "memory_synthesis"]},
    "Desktop App Engineer":                  {"specialty": "desktop app + native toolchain",          "categories": ["architecture", "engineering"]},

    # ───── Generic thinking-style archetypes (10) ─────
    "Systems Architect":         {"specialty": "architectural rigor — system structure + module boundaries",  "categories": ["architecture", "systems", "code_review", "first_principles"]},
    "Algorithmic Rigor":         {"specialty": "correctness + complexity proofs + premature-optimization watch", "categories": ["architecture", "algorithms", "performance", "correctness"]},
    "Distributed Systems":       {"specialty": "concurrency + consensus + formal proof",                         "categories": ["systems", "concurrency", "correctness", "distributed"]},
    "Data-First Thinking":       {"specialty": "model the data shape before the code",                           "categories": ["architecture", "data_modeling", "code_review"]},
    "First Principles":          {"specialty": "strip to fundamentals + question every assumption",              "categories": ["strategy", "first_principles", "engineering"]},
    "Product Taste":             {"specialty": "end-user obsession + design quality bar",                        "categories": ["product", "ux", "design"]},
    "Long-Term Vision":          {"specialty": "50-year horizon + pace layers + foundational research",          "categories": ["strategy", "long_term", "research", "vision"]},
    "Cognitive Bias Audit":      {"specialty": "what bias am I falling into / system 1 vs system 2",             "categories": ["decision_making", "metrics", "audit"]},
    "Empirical Metrics":         {"specialty": "measure not vibe — instrument before claim",                     "categories": ["metrics", "ml", "research", "measurement"]},
    "Systems Theorist":          {"specialty": "feedback loops + cybernetics + complex-system reasoning",        "categories": ["systems", "research", "feedback_loops"]},

    # ───── Always-on safety lenses (listed for registry completeness) ─────
    "Operator Lens":             {"specialty": "operator-side always-on — verify before action, customer-count honesty", "categories": ["always_on", "decision_making", "long_term"]},
    "Adversarial Security Lens": {"specialty": "always-on red-team mindset — what could go wrong",               "categories": ["always_on", "security"]},

    # ───── Enterprise tier stub slots (5 — Q1 decision: STUB) ─────
    # Placeholders only. Real picks happen in v1.4.1+ once a real enterprise
    # customer exists and has signaled their specific needs. Landing page copy:
    # "Enterprise: custom lens roster tuned to your org — contact us".
    "enterprise_tier_slot_1":    {"specialty": "reserved enterprise slot — content TBD post-customer-signal", "categories": ["enterprise_reserved"]},
    "enterprise_tier_slot_2":    {"specialty": "reserved enterprise slot — content TBD post-customer-signal", "categories": ["enterprise_reserved"]},
    "enterprise_tier_slot_3":    {"specialty": "reserved enterprise slot — content TBD post-customer-signal", "categories": ["enterprise_reserved"]},
    "enterprise_tier_slot_4":    {"specialty": "reserved enterprise slot — content TBD post-customer-signal", "categories": ["enterprise_reserved"]},
    "enterprise_tier_slot_5":    {"specialty": "reserved enterprise slot — content TBD post-customer-signal", "categories": ["enterprise_reserved"]},
}


# ---------------------------------------------------------------------------
# Tier → allowed lens set (additive — each tier includes all lower tiers).
# ---------------------------------------------------------------------------
# Free: 5 lenses (Research Analyst + Content Writer confirmed by Decker,
#   plus three broad archetypes so a free user has enough coverage for any
#   inferred task_type).
# Pro: +20 standard role workers + 2 safety lenses.
# Team: +13 specialty workers.
# Enterprise: +5 stub slots.
TIER_LENSES: dict[str, list[str]] = {
    "free": [
        "Research Analyst",
        "Content Writer",
        "Systems Architect",
        "Empirical Metrics",
        "Product Taste",
    ],
    "pro": [
        "CEO", "CTO", "Lead Engineer", "DevOps Engineer", "Security Engineer",
        "QA Lead", "Data Analyst", "Product Manager", "CMO",
        "Outreach Coordinator", "SEO Specialist", "Video Producer",
        "Community Manager", "Legal Advisor", "CFO", "Accountant",
        "HR Manager", "COO",
        "Operator Lens", "Adversarial Security Lens",
        # Remaining archetypes (free already has three)
        "Algorithmic Rigor", "Distributed Systems", "Data-First Thinking",
        "First Principles", "Long-Term Vision", "Cognitive Bias Audit",
        "Systems Theorist",
    ],
    "team": [
        "Architecture & Performance Analyst",
        "Blue Team Defense Analyst",
        "Chain Logic Reviewer",
        "Code Security Auditor",
        "Communications Agent",
        "Competitive Intelligence Analyst",
        "Dependency & Supply Chain Auditor",
        "Integration & Regression Risk Analyst",
        "Product Philosopher",
        "QA & Test Coverage Analyst",
        "Red Team Adversarial Reviewer",
        "Strategic Archivist",
        "Desktop App Engineer",
    ],
    "enterprise": [
        "enterprise_tier_slot_1",
        "enterprise_tier_slot_2",
        "enterprise_tier_slot_3",
        "enterprise_tier_slot_4",
        "enterprise_tier_slot_5",
    ],
}


def tier_allowed_lenses(tier: str) -> set[str]:
    """Return the union of lens keys available to ``tier`` (additive)."""
    _TIER_ORDER = ["free", "pro", "team", "enterprise"]
    if tier not in _TIER_ORDER:
        tier = "free"
    allowed: set[str] = set()
    for t in _TIER_ORDER:
        allowed.update(TIER_LENSES.get(t, []))
        if t == tier:
            break
    return allowed


# ---------------------------------------------------------------------------
# Task-type → lens priority list (references only public lens keys).
# ---------------------------------------------------------------------------
TASK_TYPE_LENSES: dict[str, list[str]] = {
    "architecture_review": [
        "Systems Architect", "Data-First Thinking", "Algorithmic Rigor",
        "Architecture & Performance Analyst", "CTO", "Long-Term Vision",
        "Desktop App Engineer",
    ],
    "code_review": [
        "Lead Engineer", "Code Security Auditor", "Systems Architect",
        "QA & Test Coverage Analyst", "Algorithmic Rigor",
        "Data-First Thinking", "QA Lead",
        "Integration & Regression Risk Analyst", "Chain Logic Reviewer",
    ],
    "security_review": [
        "Adversarial Security Lens", "Security Engineer",
        "Red Team Adversarial Reviewer", "Code Security Auditor",
        "Blue Team Defense Analyst", "Dependency & Supply Chain Auditor",
        "Chain Logic Reviewer",
    ],
    "metrics_analysis": [
        "Empirical Metrics", "Data Analyst", "Cognitive Bias Audit",
    ],
    "scaling_decision": [
        "Distributed Systems", "Architecture & Performance Analyst",
        "Systems Architect",
    ],
    "distributed_systems": [
        "Distributed Systems", "Algorithmic Rigor", "Systems Architect",
    ],
    "product_decision": [
        "Product Taste", "Product Manager", "Product Philosopher",
    ],
    "strategy_decision": [
        "Competitive Intelligence Analyst", "Product Philosopher",
        "Long-Term Vision", "First Principles", "CEO",
    ],
    "business_impact": [
        "CFO", "Accountant", "Competitive Intelligence Analyst",
    ],
    "writing_synthesis": [
        "Content Writer", "Communications Agent", "Video Producer",
        "SEO Specialist",
    ],
    "research_question": [
        "Research Analyst", "Strategic Archivist",
        "Competitive Intelligence Analyst", "Empirical Metrics",
    ],
    "ai_safety": [
        "Adversarial Security Lens", "Cognitive Bias Audit",
    ],
    "ml_implementation": [
        "Empirical Metrics", "Algorithmic Rigor", "First Principles",
    ],
    "first_principles": [
        "First Principles", "Algorithmic Rigor",
    ],
    "ux_design": [
        "Product Taste", "Product Manager",
    ],
    "concurrency": [
        "Distributed Systems", "Algorithmic Rigor",
        "QA & Test Coverage Analyst",
    ],
    "data_modeling": [
        "Data-First Thinking", "Data Analyst", "Algorithmic Rigor",
    ],
    "long_term_vision": [
        "Long-Term Vision", "Product Philosopher", "Systems Theorist",
    ],
    "founder_decision": [
        "Product Philosopher", "First Principles", "Long-Term Vision", "CEO",
    ],
    "memory_synthesis": [
        "Strategic Archivist", "Cognitive Bias Audit", "Content Writer",
    ],
    "polish_refine": [
        "Lead Engineer", "QA & Test Coverage Analyst",
        "Integration & Regression Risk Analyst", "Code Security Auditor",
        "Systems Architect", "QA Lead",
    ],
    "operations": [
        "COO", "DevOps Engineer", "HR Manager",
    ],
    "legal_compliance": [
        "Legal Advisor", "Adversarial Security Lens",
    ],
    "outreach_creator": [
        "Outreach Coordinator", "CMO", "Communications Agent",
        "Community Manager", "SEO Specialist",
    ],

    # Specialty SPECIALIST task types (single-expert dispatch)
    "code_audit": [
        "Code Security Auditor", "Adversarial Security Lens", "Security Engineer",
    ],
    "chain_validation": [
        "Chain Logic Reviewer", "Algorithmic Rigor",
    ],
    "regression_test": [
        "Integration & Regression Risk Analyst", "QA Lead",
        "QA & Test Coverage Analyst",
    ],
    "test_coverage": [
        "QA & Test Coverage Analyst", "QA Lead",
        "Integration & Regression Risk Analyst",
    ],
    "dependency_audit": [
        "Dependency & Supply Chain Auditor", "Adversarial Security Lens",
        "Security Engineer",
    ],
    "defensive_security": [
        "Blue Team Defense Analyst", "Adversarial Security Lens",
        "Security Engineer",
    ],
    "offensive_security": [
        "Red Team Adversarial Reviewer", "Adversarial Security Lens",
    ],
    "desktop_engineering": [
        "Desktop App Engineer", "Lead Engineer",
        "Architecture & Performance Analyst",
    ],
    "performance_review": [
        "Architecture & Performance Analyst", "Algorithmic Rigor",
    ],
    "competitive_analysis": [
        "Competitive Intelligence Analyst",
    ],
    "archive_search": [
        "Strategic Archivist", "Research Analyst",
    ],
    "product_framing": [
        "Product Philosopher", "Product Taste",
    ],
    "send_communication": [
        "Communications Agent",
    ],
    "broad_unknown": [
        "Systems Architect", "First Principles", "Empirical Metrics",
        "Cognitive Bias Audit", "Product Taste",
    ],
    # Reserved enterprise slots — routable only when tier=enterprise so the
    # completeness invariant (every lens appears in at least one task_type)
    # stays satisfied even with the Q1-stub placeholders in LENSES.
    "enterprise_reserved": [
        "enterprise_tier_slot_1",
        "enterprise_tier_slot_2",
        "enterprise_tier_slot_3",
        "enterprise_tier_slot_4",
        "enterprise_tier_slot_5",
    ],
}
