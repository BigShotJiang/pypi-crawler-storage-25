"""
memory_recall.py — opt-in entrypoint for memory recall.

Existing recall pipelines (mcp_server._recall, backend/memory_api.memory_recall,
aibrain_db.search_memories) are untouched. This module adds ONE new capability:
``memory_recall(query, mode="tempr")`` — route a query through the 4-channel
TEMPR retriever instead of the legacy single-index / multi_retrieval paths.

Default behaviour (mode="default") is the existing canonical
``aibrain_db.search_memories`` call — so importing this module is a no-op for
any caller that doesn't ask for TEMPR.

Usage:
    from aibrain.core.memory_recall import memory_recall
    results = memory_recall("how do I deploy?", limit=10)                 # legacy
    results = memory_recall("how do I deploy?", limit=10, mode="tempr")   # TEMPR
"""

from __future__ import annotations

import logging
import sqlite3
from typing import Optional

log = logging.getLogger("aibrain.memory_recall")

VALID_MODES = ("default", "tempr")


def memory_recall(
    query: str,
    limit: int = 10,
    mode: str = "default",
    search_type: Optional[str] = None,
    db: Optional[sqlite3.Connection] = None,
) -> list[dict]:
    """Retrieve memories for a query.

    Args:
        query: Natural-language query. Empty string falls back to the
            legacy top-by-importance recall (for mode="default") or returns
            [] for mode="tempr".
        limit: Max results.
        mode: "default" = existing search_memories path (no behaviour change),
              "tempr"   = new 4-channel TEMPR hybrid retrieval.
        search_type: Optional routing hint for mode="default" (ignored in
            TEMPR mode — TEMPR always runs all 4 channels).
        db: Optional sqlite3 connection. TEMPR mode uses this directly;
            default mode ignores it and uses the canonical aibrain_db handle.

    Returns:
        List of memory dicts, ranked best-first. TEMPR results carry
        ``rrf_score`` and ``retrieval_methods`` fields.
    """
    if mode not in VALID_MODES:
        raise ValueError(f"mode must be one of {VALID_MODES}, got {mode!r}")

    if mode == "tempr":
        results = _recall_tempr(query, limit=limit, db=db)
        _telemetry(query, "recall", results)
        return results

    # Default path — delegate to the canonical search_memories.
    # search_memories already calls _log_attention with the SelRoute channel name;
    # we write an additional 'recall' row here so callers can filter by query_type.
    try:
        import aibrain_db
        results = aibrain_db.search_memories(query, limit=limit, search_type=search_type)
        _telemetry(query, "recall", results)
        return results
    except Exception as exc:
        log.error("memory_recall default path failed: %s", exc, exc_info=True)
        return []


def _telemetry(query: str, query_type: str, results: list) -> None:
    """Fail-open telemetry write for recall events (CLS Step 4)."""
    try:
        import aibrain_db
        aibrain_db.log_attention(query=query, query_type=query_type, results=results)
    except Exception:
        pass


def _recall_tempr(
    query: str, limit: int, db: Optional[sqlite3.Connection]
) -> list[dict]:
    """TEMPR retrieval path. Isolated so the import is lazy — callers who
    never set mode='tempr' don't pay the cost of loading tempr_retrieval.
    """
    from aibrain.core.tempr_retrieval import TEMPRRetriever

    retriever = TEMPRRetriever(db=db)
    return retriever.retrieve(query, k=limit)
