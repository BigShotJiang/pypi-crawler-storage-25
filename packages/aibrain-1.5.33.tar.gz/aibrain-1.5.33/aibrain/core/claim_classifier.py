"""
claim_classifier.py — Epistemic claim type classification for memories.

Classifies memory content as plan/assertion/verified_fact/observation.
Used at write-time to tag memories with their epistemic state, and at
backfill time to reclassify existing memories.

Part of the Memory Lifecycle v1.6 feature.
"""

import math
import re
from datetime import datetime
from typing import Optional


# Plan indicators: future intent, deadlines, goals
_PLAN_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in [
        r"(?:plan(?:ning)?|going|aim(?:ing)?|intend(?:ing)?|target(?:ing)?)\s+to\s",
        r"(?:will|shall|should)\s+(?:be|have|do|build|ship|launch|deploy|create|write|finish)\s",
        r"(?:by|before|until|deadline|target date|due)\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|\d{4}|\d{1,2}/\d{1,2})",
        r"(?:goal|objective|milestone|roadmap|next step|todo|to-do|backlog)\s*[:=]?\s",
        r"(?:phase \d|sprint \d|v\d+\.\d+)\s+(?:will|should|plan)",
        r"(?:eta|estimated|timeline|schedule)\s*[:=]?\s",
        r"(?:need to|want to|have to|must)\s+(?:build|ship|deploy|create|fix|add)\s",
        r"^(?:verify|check|test|validate|confirm|ensure)\s+\w",  # imperative = task to do
    ]
]

# Completion indicators: something is done
_COMPLETION_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in [
        r"(?:is|are|was)\s+(?:done|complete|finished|shipped|deployed|published|live|released|launched)",
        r"(?:completed?|finished|shipped|deployed|published|launched|released|went live)\s",
        r"(?:confirmed|verified|validated|tested|checked)\s+(?:working|live|active|running)",
        r"(?:now|already|successfully)\s+(?:live|running|deployed|published|working|available)",
        r"(?:merged|pushed|committed|landed)\s+(?:to|into|on)\s+(?:main|master|prod|production)",
        r"(?:migrated|switched|moved|transitioned|upgraded)\s+(?:to|from)\s",  # migration = completed action
        r"arxiv\.org/abs/\d+\.\d+",                    # arxiv ID = published
        r"pypi\.org/project/",                          # PyPI URL = published
        r"(?:v\d+\.\d+\.\d+)\s+(?:on|live|released)",  # version + live = shipped
    ]
]

# Observation indicators: events without truth claims
_OBSERVATION_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in [
        r"(?:session|run|execution|scan|build)\s+(?:started|ended|completed|failed)",
        r"(?:error|warning|exception|crash|timeout)\s+(?:occurred|detected|raised)",
        r"(?:decker|user)\s+(?:said|asked|requested|approved|rejected)",
    ]
]

# Confidence map: claim_type -> default confidence
CLAIM_CONFIDENCE = {
    "plan": 0.3,           # plans are low-confidence by nature
    "assertion": 0.5,      # default — stated but not verified
    "verified_fact": 0.85, # completion signals detected in content
    "observation": 0.7,    # events happened, but interpretation may vary
    "deprecated": 0.1,     # explicitly outdated
}


def classify_claim_type(text: str) -> str:
    """Classify text as plan/assertion/verified_fact/observation.

    Priority: completion > plan > observation > assertion (default).
    Completion signals override plan signals (handles the exact case where
    "plan to do X" and "X is done" coexist in the same content).
    """
    if not text:
        return "assertion"

    # Check completion first — highest priority
    for pat in _COMPLETION_PATTERNS:
        if pat.search(text):
            return "verified_fact"

    for pat in _PLAN_PATTERNS:
        if pat.search(text):
            return "plan"

    for pat in _OBSERVATION_PATTERNS:
        if pat.search(text):
            return "observation"

    return "assertion"


def extract_plan_deadline(text: str) -> Optional[str]:
    """Extract a deadline date from plan-type text.

    Returns ISO date string or None. Handles:
      "by April 25" -> "2026-04-25"
      "before 2026-05-01" -> "2026-05-01"
      "deadline: May 15" -> "2026-05-15"
    """
    # Month name mapping
    month_map = {
        "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
        "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
        "january": 1, "february": 2, "march": 3, "april": 4,
        "june": 6, "july": 7, "august": 8, "september": 9,
        "october": 10, "november": 11, "december": 12,
    }

    # Pattern: "by/before/until April 25" or "April 25, 2026"
    m = re.search(
        r"(?:by|before|until|deadline|due|target)\s+(\w+)\s+(\d{1,2})(?:\s*,?\s*(\d{4}))?",
        text, re.IGNORECASE
    )
    if m:
        month_str = m.group(1).lower()
        if month_str in month_map:
            month = month_map[month_str]
            day = int(m.group(2))
            year = int(m.group(3)) if m.group(3) else datetime.now().year
            try:
                return f"{year:04d}-{month:02d}-{day:02d}"
            except ValueError:
                pass

    # Pattern: ISO date "2026-05-01"
    m = re.search(r"(\d{4}-\d{2}-\d{2})", text)
    if m:
        return m.group(1)

    return None


# --- Staleness threshold helpers (used by memory_lifecycle.py) ---

STALENESS_THRESHOLDS = {
    "plan": 7,              # Plans stale after 7 days past deadline (or 30 days if no deadline)
    "assertion": 30,        # Unverified assertions stale after 30 days
    "verified_fact": 90,    # Verified facts stale after 90 days
    "observation": 365,     # Observations decay slowly (historical record)
}


def adjusted_staleness_threshold(memory: dict) -> int:
    """Return adjusted staleness threshold for a memory.

    Well-reinforced memories (high access_count) get extended thresholds.
    Reference-type memories get a minimum of 180 days.
    """
    base = STALENESS_THRESHOLDS.get(memory.get("claim_type", "assertion"), 30)
    access_count = memory.get("access_count", 0)
    if access_count > 0:
        base += int(math.log2(access_count + 1)) * 7
    # Reference-type memories get bonus stability
    if memory.get("type") == "reference":
        base = max(base, 180)
    return base
