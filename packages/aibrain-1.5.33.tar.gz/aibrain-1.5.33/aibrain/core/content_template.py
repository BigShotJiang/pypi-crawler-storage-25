"""Content template resolver — live truth doc variable substitution.

Resolves {{aibrain.*}} / {{features.*}} / {{positioning.*}} / {{mission.*}}
placeholders in content at publish time against the canonical live-truth
markdown doc. Purpose: kill the "content scheduled 3 days ago, numbers
moved" staleness class by late-binding numeric + version claims.

Syntax supported:
    {{aibrain.version}}          -> v1.4.0
    {{aibrain.workflow_count}}   -> 59
    {{aibrain.test_count}}       -> 2,056
    {{aibrain.dashboard_pages}}  -> 53
    {{aibrain.memory_count}}     -> 18,491
    {{features.whatsnew}}        -> block text for "what's new in <version>"
    {{features.whatsnew_header}} -> "What's New in v1.4.0"
    {{positioning.tagline}}      -> tagline string from truth doc
    {{mission.statement}}        -> mission statement from truth doc

Design:
    * Pure Python, no deps — lives inside aibrain.core
    * Single `render(content, truth_doc_path=None)` entry point
    * Parser reads the markdown tables (| Field | Value |) from the truth doc
    * Missing variables raise MissingTemplateVariable with the variable name
      and a pointer to add it to the truth doc
    * Unknown variables never silently resolve to empty string
"""
from __future__ import annotations

import os
import re
from pathlib import Path

_default_truth_doc_str = os.environ.get("AIBRAIN_TRUTH_DOC", "")
DEFAULT_TRUTH_DOC = Path(_default_truth_doc_str) if _default_truth_doc_str else Path("")

VAR_PATTERN = re.compile(r"\{\{\s*([a-zA-Z_][\w.]*)\s*\}\}")


class MissingTemplateVariable(KeyError):
    """Raised when a template variable has no resolver in the truth doc."""

    def __init__(self, variable: str, truth_doc: Path):
        self.variable = variable
        self.truth_doc = truth_doc
        super().__init__(
            f"Template variable {{{{{variable}}}}} is not defined. "
            f"Add it to the live truth doc at {truth_doc} "
            f"or update content_template.py if it needs a new resolver."
        )


def _parse_field_tables(markdown: str) -> dict[str, str]:
    """Extract pipe-table rows mapping first-cell (field) to second-cell (value).

    Permissive: any 2-or-3-column row gets indexed by its first cell. The
    third-column "source of truth" cell in the code-surface-counts table is
    dropped on purpose — we want the raw count, not its provenance. First
    writer wins (the top-of-doc Version table anchors canonical values).
    Header rows and separators are skipped.
    """
    rows: dict[str, str] = {}
    header_keys = {"field", "claim category", "readme v1.2.4 claim", "stale claim"}
    for raw_line in markdown.splitlines():
        line = raw_line.strip()
        if not line.startswith("|") or not line.endswith("|"):
            continue
        if re.fullmatch(r"\|[\s\-:|]+\|", line):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 2:
            continue
        field = re.sub(r"[*_`]", "", cells[0]).strip().lower()
        value = re.sub(r"^[*`]+|[*`]+$", "", cells[1]).strip()
        if not field or not value or field in header_keys:
            continue
        # First writer wins — the canonical Version table is above the
        # comparison tables, so it anchors first.
        if field not in rows:
            rows[field] = value
    return rows


def _extract_section(markdown: str, heading: str) -> str:
    """Return the body of the first markdown section with the given heading.

    Heading match is case-insensitive and ignores leading #'s. Section body
    ends at the next heading of same-or-higher level or at EOF.
    """
    lines = markdown.splitlines()
    start = None
    start_level = 0
    heading_lc = heading.strip().lower()
    for i, line in enumerate(lines):
        m = re.match(r"^(#{1,6})\s+(.*?)\s*$", line)
        if m and m.group(2).strip().lower() == heading_lc:
            start = i + 1
            start_level = len(m.group(1))
            break
    if start is None:
        return ""
    body: list[str] = []
    for line in lines[start:]:
        m = re.match(r"^(#{1,6})\s+", line)
        if m and len(m.group(1)) <= start_level:
            break
        body.append(line)
    return "\n".join(body).strip()


def _build_resolver_map(truth_doc_path: Path) -> dict[str, str]:
    """Return variable_name -> string value map from the parsed truth doc."""
    markdown = truth_doc_path.read_text(encoding="utf-8")
    fields = _parse_field_tables(markdown)

    # Version — "Latest shipped version" field is the canonical value
    version_raw = fields.get("latest shipped version", "").strip()
    # Normalize "v1.4.0" format — truth doc writes "**v1.4.0**", parser strips to "v1.4.0"
    version = version_raw or ""

    def _num(raw: str) -> str:
        """Extract the first integer (with optional thousands commas) from a cell."""
        m = re.search(r"\d[\d,]*", raw)
        return m.group(0) if m else raw

    resolver: dict[str, str] = {}
    if version:
        resolver["aibrain.version"] = version
    if "workflows" in fields:
        resolver["aibrain.workflow_count"] = _num(fields["workflows"])
    if "tests" in fields:
        resolver["aibrain.test_count"] = _num(fields["tests"])
    if "dashboard pages" in fields:
        resolver["aibrain.dashboard_pages"] = _num(fields["dashboard pages"])
    if "memories in live db" in fields:
        resolver["aibrain.memory_count"] = _num(fields["memories in live db"])

    whatsnew_body = _extract_section(markdown, "v1.4.0 release content (for \"What's New\" sections)")
    if whatsnew_body:
        resolver["features.whatsnew"] = whatsnew_body
    if version:
        resolver["features.whatsnew_header"] = f"What's New in {version}"

    # Positioning / mission — truth doc does not currently define these under
    # explicit tables, so we pull them from dedicated sections if present.
    tagline = _extract_section(markdown, "Tagline")
    if tagline:
        resolver["positioning.tagline"] = tagline.splitlines()[0].strip()
    mission = _extract_section(markdown, "Mission")
    if mission:
        resolver["mission.statement"] = mission.splitlines()[0].strip()

    return resolver


def render(content: str, truth_doc_path: Path | None = None) -> str:
    """Resolve all {{variable}} placeholders in `content` against the truth doc.

    Raises MissingTemplateVariable on any unresolved variable, naming the
    offender and the truth doc it should be added to.
    """
    truth = Path(truth_doc_path) if truth_doc_path else DEFAULT_TRUTH_DOC
    resolver = _build_resolver_map(truth)

    def _sub(match: re.Match[str]) -> str:
        name = match.group(1)
        if name not in resolver:
            raise MissingTemplateVariable(name, truth)
        return resolver[name]

    return VAR_PATTERN.sub(_sub, content)


def find_unresolved(content: str) -> list[str]:
    """Return variable names still present in content (diagnostic helper)."""
    return [m.group(1) for m in VAR_PATTERN.finditer(content)]


__all__ = ["render", "find_unresolved", "MissingTemplateVariable", "DEFAULT_TRUTH_DOC"]
