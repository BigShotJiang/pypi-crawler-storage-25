"""
memory_lifecycle_hooks.py — Completion hooks for Memory Lifecycle v1.6.

Contains:
- supersede_plans_on_completion(): called when a verified_fact is stored
- sweep_related_memories(): called when a company task completes

These hooks update plan-state memories to reflect completed work,
preventing stale plans from being recalled as current.
"""

from __future__ import annotations

import logging
import sqlite3
from datetime import datetime, timezone

log = logging.getLogger("aibrain.memory_lifecycle_hooks")


def supersede_plans_on_completion(
    new_memory_id: int,
    content: str,
    db: sqlite3.Connection,
) -> int:
    """When a verified_fact is stored, find and supersede related plans.

    This handles the case where completion is recorded as a NEW memory
    rather than updating an existing plan memory.

    Returns count of plans superseded.
    """
    try:
        import aibrain_db
        related = aibrain_db.search_memories(content, limit=10)
    except Exception as e:
        log.debug("Plan supersession search failed: %s", e)
        return 0

    now = datetime.now(timezone.utc).isoformat()
    superseded = 0

    for mem in related:
        if mem.get("claim_type") != "plan":
            continue
        if mem.get("id") == new_memory_id:
            continue

        old_type = mem.get("claim_type", "assertion")
        old_conf = mem.get("confidence", 0.5)

        try:
            # Supersede the plan
            db.execute("""
                UPDATE memories
                SET claim_type = 'deprecated',
                    status = 'superseded',
                    superseded_by = ?,
                    valid_until = ?,
                    confidence = confidence * 0.2,
                    updated = datetime('now')
                WHERE id = ?
            """, (new_memory_id, now, mem["id"]))

            # Log verification
            db.execute("""
                INSERT INTO verification_log
                (memory_id, verified_at, verified_by, result,
                 old_claim_type, new_claim_type, old_confidence, new_confidence, notes)
                VALUES (?, ?, ?, 'contradicted', ?, 'deprecated', ?, ?, ?)
            """, (mem["id"], now, f"memory:{new_memory_id}", old_type,
                  old_conf, old_conf * 0.2,
                  f"Superseded by verified_fact memory {new_memory_id}"))

            superseded += 1
        except Exception as e:
            log.debug("Failed to supersede plan memory %s: %s", mem.get("id"), e)

    if superseded:
        db.commit()
        # Emit event
        try:
            from aibrain.core.event_bus import emit as bus_emit
            bus_emit("MEMORY_SUPERSEDED", {
                "new_memory_id": new_memory_id,
                "superseded_count": superseded,
            })
        except Exception:
            pass

    return superseded


def sweep_related_memories(task: dict, db: sqlite3.Connection) -> int:
    """Find plan-state memories related to a completed task and update them.

    Called from complete_task() after status='done' is written.

    Strategy:
    1. Search memories for the task title/description using embedding similarity
    2. For each match with claim_type='plan', promote to 'verified_fact'
    3. Set verified_at=now, verified_by=f"task:{task_id}"
    4. Log to verification_log

    Returns count of memories promoted.
    """
    try:
        import aibrain_db
        search_text = (task.get("title", "") + " " + task.get("description", "")).strip()
        if not search_text:
            return 0
        related = aibrain_db.search_memories(search_text, limit=10)
    except Exception as e:
        log.debug("Task sweep search failed: %s", e)
        return 0

    now = datetime.now(timezone.utc).isoformat()
    task_id = task.get("id", "unknown")
    promoted = 0

    for mem in related:
        if mem.get("claim_type") != "plan":
            continue

        old_type = mem.get("claim_type", "assertion")
        old_conf = mem.get("confidence", 0.5)

        try:
            db.execute("""
                UPDATE memories
                SET claim_type = 'verified_fact',
                    confidence = 0.85,
                    verified_at = ?,
                    verified_by = ?,
                    updated = datetime('now')
                WHERE id = ?
            """, (now, f"task:{task_id}", mem["id"]))

            # Log verification
            db.execute("""
                INSERT INTO verification_log
                (memory_id, verified_at, verified_by, result,
                 old_claim_type, new_claim_type, old_confidence, new_confidence, notes)
                VALUES (?, ?, ?, 'confirmed', ?, 'verified_fact', ?, 0.85, ?)
            """, (mem["id"], now, f"task:{task_id}", old_type, old_conf,
                  f"Task '{task.get('title', '')}' completed"))

            promoted += 1
        except Exception as e:
            log.debug("Failed to promote plan memory %s: %s", mem.get("id"), e)

    if promoted:
        db.commit()
        # Emit event
        try:
            from aibrain.core.event_bus import emit as bus_emit
            bus_emit("MEMORY_VERIFIED", {
                "task_id": task_id,
                "promoted_count": promoted,
            })
        except Exception:
            pass

    return promoted
