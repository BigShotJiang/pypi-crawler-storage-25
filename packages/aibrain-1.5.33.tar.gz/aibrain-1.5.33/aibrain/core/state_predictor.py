"""
state_predictor.py — Predict next likely workflow from execution_log patterns.

Frequency-based transition model with time-of-day and day-of-week weighting.
No ML — just counted transitions weighted by recency.

Usage:
    from aibrain.core.state_predictor import predict_next, log_prediction_accuracy
    predictions = predict_next(n=3)
    # [{"workflow": "heartbeat", "confidence": 0.82, "reasons": [...]}, ...]
"""

import math
import sqlite3
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import List, Optional


def _find_db() -> Optional[Path]:
    """Find the aibrain database via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    db_path = AIBRAIN_ROOT / "aibrain.db"
    return db_path if db_path.exists() else None


def _get_entries(limit: int = 500) -> list:
    """Fetch recent execution_log entries."""
    db_path = _find_db()
    if not db_path:
        return []
    db = sqlite3.connect(str(db_path))
    db.row_factory = sqlite3.Row
    try:
        rows = db.execute(
            "SELECT action, success, quality_score, created_at "
            "FROM execution_log ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []
    finally:
        db.close()


def _parse_workflow(action: str) -> Optional[str]:
    """Extract workflow name from action string. Returns None for non-workflows."""
    if action.startswith("workflow."):
        return action[len("workflow."):]
    return None


def _recency_weight(index: int, total: int) -> float:
    """Exponential decay weight: most recent entries weigh more.

    index=0 is the most recent entry. Uses half-life of total/4 so the
    oldest quarter of entries contribute ~25% of the newest entry's weight.
    """
    if total <= 1:
        return 1.0
    half_life = max(total / 4, 1)
    return math.exp(-0.693 * index / half_life)


def build_transition_model(entries: list) -> dict:
    """Build transition counts: {prev_workflow: {next_workflow: weighted_count}}.

    Entries must be ordered most-recent-first (as returned by _get_entries).
    We reverse to get chronological order, then count transitions.
    """
    # Reverse to chronological order
    chronological = list(reversed(entries))

    # Filter to workflow entries only
    workflow_entries = []
    for e in chronological:
        wf = _parse_workflow(e["action"])
        if wf is not None:
            workflow_entries.append({**e, "workflow": wf})

    transitions = defaultdict(lambda: defaultdict(float))
    total = len(workflow_entries)

    for i in range(len(workflow_entries) - 1):
        prev_wf = workflow_entries[i]["workflow"]
        next_wf = workflow_entries[i + 1]["workflow"]
        # Index from end (most recent = lowest index for recency weight)
        recency_idx = total - 1 - (i + 1)
        weight = _recency_weight(recency_idx, total)
        transitions[prev_wf][next_wf] += weight

    return dict(transitions)


def build_time_model(entries: list) -> dict:
    """Build time-of-day frequency: {workflow: {hour: weighted_count}}.

    Groups by hour-of-day (0-23) to predict what runs at a given hour.
    """
    hour_model = defaultdict(lambda: defaultdict(float))
    total = len(entries)

    for i, e in enumerate(entries):
        wf = _parse_workflow(e["action"])
        if wf is None:
            continue
        try:
            dt = datetime.fromisoformat(e["created_at"])
            hour = dt.hour
        except (ValueError, TypeError):
            continue
        weight = _recency_weight(i, total)
        hour_model[wf][hour] += weight

    return dict(hour_model)


def build_dow_model(entries: list) -> dict:
    """Build day-of-week frequency: {workflow: {dow: weighted_count}}.

    dow: 0=Monday, 6=Sunday.
    """
    dow_model = defaultdict(lambda: defaultdict(float))
    total = len(entries)

    for i, e in enumerate(entries):
        wf = _parse_workflow(e["action"])
        if wf is None:
            continue
        try:
            dt = datetime.fromisoformat(e["created_at"])
            dow = dt.weekday()
        except (ValueError, TypeError):
            continue
        weight = _recency_weight(i, total)
        dow_model[wf][dow] += weight

    return dict(dow_model)


def predict_next(
    n: int = 3,
    now: Optional[datetime] = None,
    entries: Optional[list] = None,
) -> List[dict]:
    """Predict the top N most likely next workflows.

    Scoring formula (each component normalized to [0, 1]):
        score = 0.50 * transition_score
              + 0.30 * time_of_day_score
              + 0.20 * day_of_week_score

    Args:
        n: Number of predictions to return.
        now: Override current time (for testing).
        entries: Override execution log entries (for testing).

    Returns:
        List of dicts sorted by confidence descending:
        [{"workflow": str, "confidence": float, "reasons": [str]}, ...]
    """
    if now is None:
        now = datetime.utcnow()
    if entries is None:
        entries = _get_entries(limit=500)

    if not entries:
        return []

    transitions = build_transition_model(entries)
    time_model = build_time_model(entries)
    dow_model = build_dow_model(entries)

    # Find the most recent workflow
    last_wf = None
    for e in entries:
        wf = _parse_workflow(e["action"])
        if wf is not None:
            last_wf = wf
            break

    current_hour = now.hour
    current_dow = now.weekday()

    # Collect all known workflows
    all_workflows = set()
    for e in entries:
        wf = _parse_workflow(e["action"])
        if wf is not None:
            all_workflows.add(wf)

    if not all_workflows:
        return []

    scores = {}
    reasons_map = {}

    for wf in all_workflows:
        reasons = []

        # --- Transition score ---
        trans_score = 0.0
        if last_wf and last_wf in transitions:
            nexts = transitions[last_wf]
            total_weight = sum(nexts.values())
            if total_weight > 0 and wf in nexts:
                trans_score = nexts[wf] / total_weight
                reasons.append(f"follows '{last_wf}' {trans_score:.0%} of the time")

        # --- Time-of-day score ---
        time_score = 0.0
        if wf in time_model:
            hours = time_model[wf]
            total_weight = sum(hours.values())
            if total_weight > 0:
                # Check current hour and +/- 1 hour neighbors (with lower weight)
                hour_weight = hours.get(current_hour, 0)
                hour_weight += 0.5 * hours.get((current_hour - 1) % 24, 0)
                hour_weight += 0.5 * hours.get((current_hour + 1) % 24, 0)
                time_score = min(hour_weight / total_weight, 1.0)
                if time_score > 0.1:
                    reasons.append(f"often runs around {current_hour:02d}:00")

        # --- Day-of-week score ---
        dow_score = 0.0
        if wf in dow_model:
            dows = dow_model[wf]
            total_weight = sum(dows.values())
            if total_weight > 0:
                dow_score = dows.get(current_dow, 0) / total_weight
                if dow_score > 0.1:
                    day_name = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][current_dow]
                    reasons.append(f"common on {day_name}")

        # Combined score
        combined = (0.50 * trans_score) + (0.30 * time_score) + (0.20 * dow_score)
        if combined > 0:
            scores[wf] = combined
            reasons_map[wf] = reasons

    # Sort by score descending, take top N
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:n]

    # Normalize confidence to max 1.0 (relative to top scorer)
    if ranked:
        max_score = ranked[0][1]
        if max_score > 0:
            return [
                {
                    "workflow": wf,
                    "confidence": round(score / max_score, 2) if max_score > 1 else round(score, 2),
                    "reasons": reasons_map.get(wf, []),
                }
                for wf, score in ranked
            ]

    return []


def log_prediction_accuracy(
    predicted: List[dict],
    actual_workflow: str,
) -> Optional[dict]:
    """Log how accurate a prediction was. Called after workflow completion.

    Writes a row to execution_log with action='prediction.accuracy'.

    Returns:
        {"hit": bool, "rank": int|None, "predicted_top": str|None}
    """
    hit = False
    rank = None
    predicted_top = predicted[0]["workflow"] if predicted else None

    for i, p in enumerate(predicted):
        if p["workflow"] == actual_workflow:
            hit = True
            rank = i + 1
            break

    result = {"hit": hit, "rank": rank, "predicted_top": predicted_top, "actual": actual_workflow}

    db_path = _find_db()
    if db_path:
        try:
            import json
            db = sqlite3.connect(str(db_path))
            db.execute("PRAGMA journal_mode=WAL")
            db.execute(
                "INSERT INTO execution_log (action, success, quality_score, "
                "task_type, created_at) VALUES (?, ?, ?, ?, ?)",
                (
                    "prediction.accuracy",
                    1 if hit else 0,
                    1.0 if rank == 1 else (0.5 if hit else 0.0),
                    json.dumps(result),
                    datetime.utcnow().isoformat(),
                ),
            )
            db.commit()
            db.close()
        except Exception:
            pass

    return result


def format_predictions(predictions: List[dict]) -> str:
    """Format predictions for CLI display."""
    if not predictions:
        return "No predictions available — not enough execution history."

    lines = ["\n  Predicted next workflows:\n"]
    for i, p in enumerate(predictions, 1):
        bar_len = int(p["confidence"] * 20)
        bar = "#" * bar_len + "." * (20 - bar_len)
        reasons = ", ".join(p["reasons"]) if p["reasons"] else "frequency-based"
        lines.append(f"  {i}. {p['workflow']:<30} [{bar}] {p['confidence']:.0%}")
        lines.append(f"     {reasons}")
    lines.append("")
    return "\n".join(lines)
