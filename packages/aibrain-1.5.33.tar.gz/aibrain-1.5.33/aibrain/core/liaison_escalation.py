"""
WTL Phase 2 + 2b — stuck-detector, second-Liaison spawn queue, three-mode outcome handler,
auto-reassign before escalation, 3-tries hard cap.

Implements §2, §2b, §3, §4 (structural FOLLOW-UPS check), and §11 of company task
2fw8UooTW2s v4.1 (Liaison PASS 0.89). Phase 2b driven by Neuro's 2026-04-19 feedback
(recovery_7aabbf217f, recovery_7c1a0064fd) on unfinished escalation gaps.
Consumes schema from migrations v6-v15.

Responsibilities:
  * Reject VAGUE Liaison FAIL verdicts at record time (regex + semantic layer)
  * Detect stuck-pattern — either the last two FAILs share ≥70% FOLLOW-UPS overlap
    (same_critique_recurring), OR review_round ≥ 3 (max_rounds_exceeded, catches
    thrashing where each complaint differs but the worker is not converging)
  * Enqueue second-Liaison spawn request for broker_hook pickup (Phase 6)
  * Auto-reassign to a same-role peer BEFORE AUTO_REVERT / NEEDS_DECKER, when AGREE
    (both Liaisons FAIL with ≥30% majors overlap) and a peer is available
  * Apply three-mode outcome: AGREE → AUTO_REVERT / DISAGREE-VERDICT → NEEDS_DECKER
    / CONVERGENT-FAIL-DIVERGENT-REASON → NEEDS_DECKER
  * Execute safe auto-revert on PR branch (never main, never force-push)

Out of scope for this module (separate phases):
  * Hook into record_liaison_verdict itself (Phase 7 — companies.py edit)
  * Broker hook dispatch of queued spawns (Phase 6)
  * NEEDS-DECKER surfacing cadence (Phase 5)
  * Calibration metrics — rolling FAIL-rate + disagreement-rate (Phase 4)
"""

import json
import logging
import re
import subprocess
from typing import Optional

from aibrain.core.companies import _get_db

log = logging.getLogger(__name__)


def _has_source_column(db) -> bool:
    """Return True if execution_log.source exists (v16 migration applied).

    Pre-v16 databases (legacy) lack the column; callers should fall back to
    unfiltered queries. Same helper pattern as reviewer_calibration.
    """
    try:
        db.execute("SELECT source FROM execution_log LIMIT 0")
        return True
    except Exception:
        return False

# ---------------------------------------------------------------------------
# Tokenization (v4.1 §2 + §4)
# ---------------------------------------------------------------------------

# Regex layer — any of these anywhere in the FOLLOW-UPS text is sufficient
_PATH_RE = re.compile(r"\w+/\w+\.\w+")
_LINEREF_RE = re.compile(r":\d+")
_SYMBOL_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*\(\)")
_FALSIFY_RE = re.compile(r"if .+ then|would fail if|falsification:", re.IGNORECASE)
_RULE_RE = re.compile(r"CLAUDE\.md|V2 Addition|rule [A-Za-z_-]+|hard rule", re.IGNORECASE)

# Semantic layer — per-item requirement
_VERB_ALLOWLIST = frozenset({
    "add", "remove", "replace", "rename", "split", "merge",
    "cite", "verify", "test", "downgrade", "delete",
})
_NOUN_HINT_RE = re.compile(r"\b(file|function|schema|rule|persona|module|table|column)\b", re.IGNORECASE)

# Thresholds — Decker decisions 2026-04-19
STUCK_OVERLAP_THRESHOLD = 0.70          # §2 — two consecutive FAILs with ≥70% FOLLOW-UPS overlap
AGREE_MAJORS_OVERLAP_THRESHOLD = 0.70   # §3 AGREE mode
DIVERGENT_MAJORS_OVERLAP_THRESHOLD = 0.30  # §3 CONVERGENT-FAIL-DIVERGENT-REASON threshold
MIN_ITEM_LENGTH = 30                    # §4 — per-item ≥30 chars
MAX_REVIEW_ROUNDS = 3                   # §2b — Decker's 3-tries hard cap, thrashing catches

# ---------------------------------------------------------------------------
# FOLLOW-UPS structural tokens
# ---------------------------------------------------------------------------


def extract_followups_tokens(text: str) -> set:
    """Return set of structural tokens per v4.1 §2 — paths, symbols, falsifiability, rule citations."""
    tokens: set = set()
    if not text:
        return tokens
    for regex in (_PATH_RE, _LINEREF_RE, _SYMBOL_RE, _FALSIFY_RE, _RULE_RE):
        for m in regex.finditer(text):
            tokens.add(m.group(0).lower())
    return tokens


def compute_followups_overlap(text_a: str, text_b: str) -> float:
    """Jaccard overlap (intersection / union) of structural tokens. 1.0 = identical, 0.0 = disjoint."""
    a = extract_followups_tokens(text_a)
    b = extract_followups_tokens(text_b)
    if not a and not b:
        return 0.0
    union = a | b
    if not union:
        return 0.0
    return len(a & b) / len(union)


# ---------------------------------------------------------------------------
# VAGUE rejection (v4.1 §4)
# ---------------------------------------------------------------------------


def vague_reject_reason(followups_text: str) -> Optional[str]:
    """Structural check on a FOLLOW-UPS block. Returns rejection reason string, or None to accept.

    Both layers must pass; either-only pass = VAGUE.
      Regex layer: at least one of file-path, line-ref, symbol, falsifiability, rule-citation
      Semantic layer: every item has an actionable verb AND concrete noun AND length ≥30
    """
    if not followups_text or not followups_text.strip():
        return "empty_followups"

    regex_matched = any(
        r.search(followups_text)
        for r in (_PATH_RE, _LINEREF_RE, _SYMBOL_RE, _FALSIFY_RE, _RULE_RE)
    )
    if not regex_matched:
        return "no_structural_anchor"

    items = [ln for ln in (line.strip() for line in followups_text.splitlines()) if ln]
    if not items:
        return "no_items_after_line_split"

    for item in items:
        if len(item) < MIN_ITEM_LENGTH:
            return f"item_too_short:{len(item)}"
        words = set(re.findall(r"\b[a-z]+\b", item.lower()))
        if not (words & _VERB_ALLOWLIST):
            return "no_actionable_verb"
        if not _NOUN_HINT_RE.search(item):
            return "no_concrete_noun_target"

    return None


# ---------------------------------------------------------------------------
# Stuck-detector (v4.1 §2 + §6)
# ---------------------------------------------------------------------------


def detect_stuck(task_id: str, db=None) -> Optional[dict]:
    """Return stuck-pattern metadata if a termination signal fires. None otherwise.

    Two triggers — either is sufficient:
      * same_critique_recurring — last two FAIL verdicts with ≥70% FOLLOW-UPS Jaccard overlap
      * max_rounds_exceeded — review_round ≥ 3 (Decker's 3-tries hard cap; catches thrashing
        where each round has a different complaint but worker is not converging)
    """
    db = db or _get_db()

    # Hard cap first — catches thrashing regardless of critique similarity.
    task_row = db.execute(
        "SELECT review_round FROM company_issues WHERE id=?",
        (task_id,),
    ).fetchone()
    review_round = (task_row["review_round"] if task_row else 0) or 0
    if review_round >= MAX_REVIEW_ROUNDS:
        return {
            "stuck": True,
            "reason": "max_rounds_exceeded",
            "review_round": review_round,
        }

    # Similarity trigger — same critique firing twice in a row.
    # Source filter (v1.5.22+): only real agent_review FAILs count toward stuck-state.
    # self_recorded FAILs are audit-only and must NOT pollute the top-2 window, or
    # they can both false-trigger stuck-state AND bump real agent_review FAILs off
    # the window. Legacy rows with NULL source are treated as agent_review via
    # COALESCE (matches Neuro's v17 backfill semantics). Same pattern as
    # reviewer_calibration.rolling_metrics (commit f3f9dda).
    if _has_source_column(db):
        rows = db.execute(
            """SELECT run_id, critique
               FROM execution_log
               WHERE entity_id=? AND actor='special_liaison' AND verdict='FAIL'
                 AND COALESCE(source, 'agent_review') = 'agent_review'
               ORDER BY created_at DESC LIMIT 2""",
            (task_id,),
        ).fetchall()
    else:
        rows = db.execute(
            """SELECT run_id, critique
               FROM execution_log
               WHERE entity_id=? AND actor='special_liaison' AND verdict='FAIL'
               ORDER BY created_at DESC LIMIT 2""",
            (task_id,),
        ).fetchall()
    if len(rows) < 2:
        return None

    current, previous = rows[0], rows[1]
    overlap = compute_followups_overlap(current["critique"] or "", previous["critique"] or "")
    if overlap < STUCK_OVERLAP_THRESHOLD:
        return None

    return {
        "stuck": True,
        "reason": "same_critique_recurring",
        "overlap": overlap,
        "current_run_id": current["run_id"],
        "prev_run_id": previous["run_id"],
    }


# ---------------------------------------------------------------------------
# Spawn queue writer (v4.1 §11 decoupled dispatch)
# ---------------------------------------------------------------------------


def enqueue_second_liaison(task_id: str, first_verdict_run_id: str, first_majors: list, db=None) -> int:
    """Write a row to second_liaison_spawn_queue + set company_issues.stuck_pattern=1.

    Returns the inserted queue row id. broker_hook.py (Phase 6) picks up dispatched_at IS NULL rows.
    """
    db = db or _get_db()
    cur = db.execute(
        """INSERT INTO second_liaison_spawn_queue
           (task_id, first_verdict_run_id, first_majors_json, queued_at)
           VALUES (?, ?, ?, datetime('now'))""",
        (task_id, first_verdict_run_id, json.dumps(first_majors or [])),
    )
    db.execute(
        "UPDATE company_issues SET stuck_pattern=1, updated_at=datetime('now') WHERE id=?",
        (task_id,),
    )
    db.commit()
    qid = cur.lastrowid
    log.info("Task %s: stuck pattern confirmed, spawn-queued as id=%d", task_id, qid)
    return qid


# ---------------------------------------------------------------------------
# Auto-reassign on repeated same-assignee failure (§2b)
# ---------------------------------------------------------------------------


def auto_reassign_on_repeat(task_id: str, db=None) -> dict:
    """Reassign a stuck task to a same-role peer before escalating to terminal state.

    Rationale: if the worker has failed repeatedly on the same task, the assignee may
    be wrong for the job. Rotating to a same-role peer BEFORE AUTO_REVERT / NEEDS_DECKER
    gives the loop one more chance to self-resolve without burning Decker's attention.

    Invariant note: the current assignee has carried every failing round since the last
    reassignment, because both this function and apply_decker_decision('reassign', ...)
    reset review_round to 0 on reassignment. So there is no need to walk execution_log
    history — the current assignee IS the stuck worker by construction.

    Returns {reassigned: bool, new_assignee: str|None, reason: str|None}.
    Clears terminal_state, review_round, stuck_pattern when successful so the task
    re-enters the normal loop under the new assignee.
    """
    db = db or _get_db()

    task = db.execute(
        "SELECT assignee_agent_id, company_id FROM company_issues WHERE id=?",
        (task_id,),
    ).fetchone()
    if task is None:
        return {"reassigned": False, "new_assignee": None, "reason": "no_company_issues_row"}

    current_assignee = task["assignee_agent_id"]
    company_id = task["company_id"]
    if not current_assignee:
        return {"reassigned": False, "new_assignee": None, "reason": "no_current_assignee"}

    # Look up current assignee's role, then pick an active same-role peer.
    current_role_row = db.execute(
        "SELECT role FROM company_agents WHERE id=? AND company_id=?",
        (current_assignee, company_id),
    ).fetchone()
    if current_role_row is None:
        return {"reassigned": False, "new_assignee": None, "reason": "assignee_not_in_roster"}
    role = current_role_row["role"]

    peer = db.execute(
        """SELECT id FROM company_agents
           WHERE company_id=? AND role=? AND status='active' AND id != ?
           ORDER BY id LIMIT 1""",
        (company_id, role, current_assignee),
    ).fetchone()
    if peer is None:
        return {"reassigned": False, "new_assignee": None, "reason": "no_same_role_peer"}

    new_assignee = peer["id"]
    db.execute(
        """UPDATE company_issues
           SET assignee_agent_id=?, auto_action='reassign',
               terminal_state=NULL, review_round=0, stuck_pattern=0,
               updated_at=datetime('now')
           WHERE id=?""",
        (new_assignee, task_id),
    )
    db.commit()
    log.info(
        "Task %s: auto-reassigned %s → %s (role=%s)",
        task_id, current_assignee, new_assignee, role,
    )
    return {"reassigned": True, "new_assignee": new_assignee, "reason": None}


# ---------------------------------------------------------------------------
# Three-mode outcome handler (v4.1 §3)
# ---------------------------------------------------------------------------


def _majors_overlap(majors_a: list, majors_b: list) -> float:
    """Case-insensitive Jaccard overlap of MAJOR citation strings."""
    set_a = {m.strip().lower() for m in (majors_a or []) if m and m.strip()}
    set_b = {m.strip().lower() for m in (majors_b or []) if m and m.strip()}
    if not (set_a | set_b):
        return 0.0
    return len(set_a & set_b) / len(set_a | set_b)


def resolve_second_liaison_outcome(
    task_id: str,
    first_verdict: str,
    first_majors: list,
    second_verdict: str,
    second_majors: list,
    db=None,
) -> dict:
    """Apply the three-mode decision per §3. Writes terminal_state + auto_action to company_issues.

    If NEEDS_DECKER, also inserts (or upserts) a needs_decker_queue row with the appropriate flag.

    Branches:
      both FAIL, majors-overlap ≥70%  → AGREE                          → AUTO_REVERT
      both FAIL, majors-overlap <30%  → CONVERGENT-FAIL-DIVERGENT-REASON → NEEDS_DECKER (ambiguity_flag)
      both FAIL, 30-70%              → AGREE-MIDBAND (default to AGREE)  → AUTO_REVERT
      verdict mismatch (PASS vs FAIL) → DISAGREE-VERDICT                → NEEDS_DECKER (calibration_flag)
    """
    db = db or _get_db()

    first_verdict = (first_verdict or "").upper()
    second_verdict = (second_verdict or "").upper()
    major_overlap = _majors_overlap(first_majors, second_majors)

    # Try auto-reassign on any AGREE / AGREE-MIDBAND (§2b): if one assignee has carried
    # every failing round and a same-role peer is available, rotate before committing to
    # a terminal state. The reassign function itself writes the DB update and returns early;
    # we short-circuit and report it instead of the usual terminal_state path.
    reassign_outcome = None
    if first_verdict == second_verdict == "FAIL" and major_overlap >= DIVERGENT_MAJORS_OVERLAP_THRESHOLD:
        reassign_outcome = auto_reassign_on_repeat(task_id, db=db)
        if reassign_outcome["reassigned"]:
            base_mode = "AGREE" if major_overlap >= AGREE_MAJORS_OVERLAP_THRESHOLD else "AGREE-MIDBAND"
            result = {
                "task_id": task_id,
                "mode": f"{base_mode}_REASSIGNED",
                "terminal_state": None,
                "auto_action": "reassign",
                "major_overlap": round(major_overlap, 3),
                "new_assignee": reassign_outcome["new_assignee"],
            }
            log.info(
                "Task %s: reassigned to %s before terminal (%s, major_overlap=%.2f)",
                task_id, reassign_outcome["new_assignee"], base_mode, major_overlap,
            )
            return result

    if first_verdict != second_verdict:
        mode = "DISAGREE-VERDICT"
        terminal = "NEEDS_DECKER"
        auto_action = "needs_decker"
        flag_col = "calibration_flag"
    elif first_verdict == "FAIL":
        if major_overlap >= AGREE_MAJORS_OVERLAP_THRESHOLD:
            mode = "AGREE"
            terminal = "AUTO_REVERT"
            auto_action = "revert"
            flag_col = None
        elif major_overlap < DIVERGENT_MAJORS_OVERLAP_THRESHOLD:
            mode = "CONVERGENT-FAIL-DIVERGENT-REASON"
            terminal = "NEEDS_DECKER"
            auto_action = "needs_decker"
            flag_col = "ambiguity_flag"
        else:
            mode = "AGREE-MIDBAND"
            terminal = "AUTO_REVERT"
            auto_action = "revert"
            flag_col = None
    else:
        # Both PASS after stuck-detector fired — degenerate, second confirms first
        mode = "BOTH_PASS"
        terminal = "AUTO_PASS"
        auto_action = "merge"
        flag_col = None

    db.execute(
        "UPDATE company_issues SET terminal_state=?, auto_action=?, updated_at=datetime('now') WHERE id=?",
        (terminal, auto_action, task_id),
    )

    if terminal == "NEEDS_DECKER" and flag_col:
        db.execute(
            f"""INSERT INTO needs_decker_queue
               (task_id, surfaced_at, urgent_at, physical_fallback_at, {flag_col})
               VALUES (?, datetime('now'),
                       datetime('now', '+7 days'),
                       datetime('now', '+14 days'), 1)
               ON CONFLICT(task_id) DO UPDATE SET
                   surfaced_at = datetime('now'),
                   urgent_at = datetime('now', '+7 days'),
                   physical_fallback_at = datetime('now', '+14 days'),
                   {flag_col} = 1,
                   decided_at = NULL""",
            (task_id,),
        )

    db.commit()
    result = {
        "task_id": task_id,
        "mode": mode,
        "terminal_state": terminal,
        "auto_action": auto_action,
        "major_overlap": round(major_overlap, 3),
    }
    log.info(
        "Task %s: three-mode resolved to %s (terminal=%s, major_overlap=%.2f)",
        task_id, mode, terminal, major_overlap,
    )
    return result


# ---------------------------------------------------------------------------
# Auto-revert executor (v4.1 §1 AUTO-REVERT)
# ---------------------------------------------------------------------------

_PROTECTED_BRANCHES = frozenset({"main", "master", "trunk", "production", "release"})


def execute_auto_revert(task_id: str, pr_branch: str, repo_path: str) -> dict:
    """Run `git revert --no-edit HEAD` on a PR branch. Refuses protected branches. Never force-pushes.

    Returns {reverted: bool, commit_sha: str|None, error: str|None}.
    """
    if pr_branch in _PROTECTED_BRANCHES:
        err = f"refuse to auto-revert protected branch: {pr_branch}"
        log.error("Task %s: %s", task_id, err)
        return {"reverted": False, "commit_sha": None, "error": err}

    def _git(*args, timeout=60):
        return subprocess.run(
            ["git", "-C", repo_path, *args],
            check=True, capture_output=True, text=True, timeout=timeout,
        )

    try:
        _git("checkout", pr_branch)
        head = _git("rev-parse", "HEAD").stdout.strip()
        _git("revert", "--no-edit", head)
        _git("push", "origin", pr_branch)
        new_sha = _git("rev-parse", "HEAD").stdout.strip()
        log.info("Task %s: auto-reverted branch=%s %s → %s", task_id, pr_branch, head, new_sha)
        return {"reverted": True, "commit_sha": new_sha, "error": None}
    except subprocess.CalledProcessError as e:
        err = f"{' '.join(e.cmd)}: {e.stderr.strip()[:200]}"
        log.error("Task %s: auto-revert failed: %s", task_id, err)
        return {"reverted": False, "commit_sha": None, "error": err}
    except subprocess.TimeoutExpired as e:
        err = f"timeout: {e.cmd}"
        log.error("Task %s: auto-revert timeout: %s", task_id, err)
        return {"reverted": False, "commit_sha": None, "error": err}
