"""
routing_config.py — Config-table persistence for routing.* settings.

Stores routing mode, token budget, and daily spend counters in the aibrain
config table (key TEXT, value TEXT) so they survive across sessions and are
visible via `aibrain config get routing`.

Keys stored:
    routing.mode                 — "auto"|"always_superworker"|"never_superworker"|"manual"
    routing.token_budget_per_day — integer cents, or "null" for no cap
    routing.token_spent_today    — integer cents spent today (UTC)
    routing.budget_reset_date    — YYYY-MM-DD of last reset

Tier defaults (applied on first read when keys are absent):
    Free tier  : mode="auto", token_budget_per_day=200
    Pro/Team/Enterprise: mode="auto", token_budget_per_day=null

Per-invocation flags (fast_mode / deep_mode) are NOT stored in the config
table — they are transient and stored in routing_settings.RoutingSettings
(~/.aibrain/routing.json) by the CLI arg parser in __main__.py.

Usage:
    from aibrain.core.routing_config import RoutingConfig

    rc = RoutingConfig()
    rc.set_mode("never_superworker")
    rc.set_budget(500)          # 500 cents = $5.00 / day
    rc.set_budget(None)         # remove cap

    mode = rc.get_mode()        # "never_superworker"
    over  = rc.is_budget_exceeded()  # True/False
    rc.increment_spend(42)      # +42 cents spent today

    all_keys = rc.get_all()     # {routing.mode: ..., ...}
"""
from __future__ import annotations

import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.routing_config")

VALID_MODES = ("auto", "always_superworker", "never_superworker", "manual")

# Config-table keys
_KEY_MODE = "routing.mode"
_KEY_BUDGET = "routing.token_budget_per_day"
_KEY_SPENT = "routing.token_spent_today"
_KEY_RESET_DATE = "routing.budget_reset_date"

_ALL_ROUTING_KEYS = (_KEY_MODE, _KEY_BUDGET, _KEY_SPENT, _KEY_RESET_DATE)

# Tier defaults
_FREE_TIER_BUDGET = 200          # cents
_DEFAULT_MODE = "auto"


def _today_utc() -> str:
    """Return today's UTC date as YYYY-MM-DD."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


class RoutingConfig:
    """
    Read/write routing.* settings from the aibrain config table.

    All methods are idempotent: calling set_mode() twice with the same value
    produces the same result. Falls back gracefully when DB is unavailable
    (returns defaults, skips writes silently).
    """

    def __init__(self, db_path: Optional[Path] = None):
        self._db_path = db_path  # None → resolve at call time via aibrain_db

    def _resolve_db(self) -> Optional[Path]:
        if self._db_path is not None:
            return self._db_path if self._db_path.exists() else None
        try:
            from aibrain_db import AIBRAIN_ROOT
            p = AIBRAIN_ROOT / "aibrain.db"
            return p if p.exists() else None
        except Exception:
            return None

    def _get_raw(self, key: str) -> Optional[str]:
        """Return raw string value from config table, or None if absent/unavailable."""
        p = self._resolve_db()
        if p is None:
            return None
        try:
            db = sqlite3.connect(str(p))
            try:
                row = db.execute(
                    "SELECT value FROM config WHERE key=?", (key,)
                ).fetchone()
                return row[0] if row else None
            finally:
                db.close()
        except Exception as exc:
            log.debug("routing_config._get_raw(%r): %s", key, exc)
            return None

    def _set_raw(self, key: str, value: str) -> None:
        """Write string value to config table. No-op if DB unavailable."""
        p = self._resolve_db()
        if p is None:
            log.debug("routing_config._set_raw: DB unavailable, skipping write for %r", key)
            return
        try:
            db = sqlite3.connect(str(p))
            try:
                db.execute(
                    "INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)",
                    (key, value),
                )
                db.commit()
            finally:
                db.close()
        except Exception as exc:
            log.warning("routing_config._set_raw(%r): write failed: %s", key, exc)

    # ── Mode ──────────────────────────────────────────────────────────────

    def get_mode(self, tier: str = "free") -> str:
        """Return the routing mode, applying tier default if not set."""
        raw = self._get_raw(_KEY_MODE)
        if raw is None:
            return _DEFAULT_MODE
        if raw in VALID_MODES:
            return raw
        log.warning("routing_config: unknown mode %r stored — falling back to auto", raw)
        return _DEFAULT_MODE

    def set_mode(self, mode: str) -> None:
        """
        Set the routing mode.

        Raises:
            ValueError: if mode is not in VALID_MODES.
        """
        if mode not in VALID_MODES:
            raise ValueError(
                f"Invalid routing mode {mode!r}. "
                f"Valid modes: {', '.join(VALID_MODES)}"
            )
        self._set_raw(_KEY_MODE, mode)
        log.info("routing_config: mode set to %r", mode)

    # ── Token Budget ──────────────────────────────────────────────────────

    def get_budget(self) -> Optional[int]:
        """Return daily token budget in cents, or None if no cap."""
        raw = self._get_raw(_KEY_BUDGET)
        if raw is None or raw.lower() in ("null", "none", ""):
            return None
        try:
            return int(raw)
        except (ValueError, TypeError):
            return None

    def set_budget(self, cents: Optional[int]) -> None:
        """
        Set the daily token budget.

        Args:
            cents: integer >= 0, or None to remove the cap.

        Raises:
            ValueError: if cents is negative.
        """
        if cents is None:
            self._set_raw(_KEY_BUDGET, "null")
            log.info("routing_config: budget cap removed")
        else:
            if cents < 0:
                raise ValueError(f"Budget must be >= 0 cents, got {cents}")
            self._set_raw(_KEY_BUDGET, str(cents))
            log.info("routing_config: budget set to %d cents/day", cents)

    # ── Daily Spend ───────────────────────────────────────────────────────

    def _maybe_reset_daily_spend(self) -> None:
        """Reset token_spent_today to 0 if the reset date is not today (UTC)."""
        today = _today_utc()
        stored_date = self._get_raw(_KEY_RESET_DATE)
        if stored_date != today:
            self._set_raw(_KEY_SPENT, "0")
            self._set_raw(_KEY_RESET_DATE, today)
            log.info(
                "routing_config: daily spend reset to 0 (was reset_date=%r, now=%s)",
                stored_date,
                today,
            )

    def get_spent_today(self) -> int:
        """Return cents spent today, resetting if the stored date is stale."""
        self._maybe_reset_daily_spend()
        raw = self._get_raw(_KEY_SPENT)
        if raw is None:
            return 0
        try:
            return int(raw)
        except (ValueError, TypeError):
            return 0

    def increment_spend(self, cents: int) -> None:
        """Add cents to today's spend total."""
        if cents <= 0:
            return
        self._maybe_reset_daily_spend()
        current = self.get_spent_today()
        self._set_raw(_KEY_SPENT, str(current + cents))

    # ── Budget Enforcement ────────────────────────────────────────────────

    def is_budget_exceeded(self) -> bool:
        """
        Return True if a daily budget is set AND today's spend >= the cap.

        Callers should downgrade to single-worker when True (unless --deep flag).
        """
        budget = self.get_budget()
        if budget is None:
            return False
        spent = self.get_spent_today()
        exceeded = spent >= budget
        if exceeded:
            log.warning(
                "routing_config: daily budget exceeded (spent=%d >= cap=%d) — "
                "callers should downgrade to single-worker",
                spent,
                budget,
            )
        return exceeded

    # ── Combined routing decision ─────────────────────────────────────────

    def should_use_superworker(
        self,
        task_type: str,
        *,
        fast_mode: bool = False,
        deep_mode: bool = False,
    ) -> bool:
        """
        Decide whether to use SuperWorker for this invocation.

        Priority (highest → lowest):
          1. deep_mode=True  → always SuperWorker (even if over budget)
          2. Budget exceeded  → downgrade to single-worker (log warning)
          3. fast_mode=True  → never SuperWorker
          4. mode="always_superworker" → always SuperWorker
          5. mode="never_superworker"  → never SuperWorker
          6. mode="manual"   → False (no per-invocation flag set)
          7. mode="auto"     → SuperWorker for judgment/complex tasks only

        Args:
            task_type: "deterministic" | "simple" | "judgment" | "complex"
            fast_mode: Per-invocation --fast flag
            deep_mode: Per-invocation --deep flag
        """
        # deep_mode beats everything — always SuperWorker
        if deep_mode:
            budget = self.get_budget()
            if budget is not None and self.get_spent_today() >= budget:
                log.warning(
                    "routing_config: --deep flag set but budget exceeded — "
                    "proceeding with SuperWorker as requested"
                )
            return True

        # Budget gate: downgrade unless deep_mode
        if self.is_budget_exceeded():
            log.warning(
                "routing_config: budget exceeded — downgrading to single-worker"
            )
            return False

        # fast_mode: never SuperWorker
        if fast_mode:
            return False

        mode = self.get_mode()
        if mode == "always_superworker":
            return True
        if mode == "never_superworker":
            return False
        if mode == "manual":
            return False

        # auto (default): SuperWorker for judgment/complex only
        return task_type in ("judgment", "complex")

    # ── All settings (for display) ────────────────────────────────────────

    def get_all(self) -> dict:
        """Return all routing.* config values as a dict."""
        # Trigger daily reset check before reading
        self._maybe_reset_daily_spend()
        result = {}
        for key in _ALL_ROUTING_KEYS:
            raw = self._get_raw(key)
            result[key] = raw if raw is not None else "(not set)"
        return result


# ── CLI helpers ────────────────────────────────────────────────────────────────

def cli_config_set_routing(key: str, value: str, db_path: Optional[Path] = None) -> str:
    """
    Handle `aibrain config set <routing.key> <value>` with validation.

    Returns a human-readable result string.
    Raises ValueError on invalid input.
    """
    rc = RoutingConfig(db_path=db_path)

    if key == "routing.mode":
        rc.set_mode(value)
        return f"routing.mode = {value}"

    elif key == "routing.token_budget_per_day":
        if value.lower() in ("none", "null", ""):
            rc.set_budget(None)
            return "routing.token_budget_per_day = null (no cap)"
        try:
            cents = int(value)
        except ValueError:
            raise ValueError(
                f"routing.token_budget_per_day must be an integer (cents) or 'none', got {value!r}"
            )
        rc.set_budget(cents)
        return f"routing.token_budget_per_day = {cents} cents/day"

    else:
        raise ValueError(
            f"Unknown routing config key: {key!r}. "
            f"Settable keys: routing.mode, routing.token_budget_per_day"
        )


def cli_config_get_routing(db_path: Optional[Path] = None) -> str:
    """
    Handle `aibrain config get routing` — show all routing.* in a table.

    Returns formatted multi-line string.
    """
    rc = RoutingConfig(db_path=db_path)
    all_keys = rc.get_all()
    budget = rc.get_budget()
    spent = rc.get_spent_today()

    lines = [
        "",
        "  Routing Settings",
        "  " + "─" * 44,
    ]
    label_map = {
        "routing.mode":                 "mode",
        "routing.token_budget_per_day": "budget (cents/day)",
        "routing.token_spent_today":    "spent today (cents)",
        "routing.budget_reset_date":    "budget reset date (UTC)",
    }
    for key in _ALL_ROUTING_KEYS:
        raw = all_keys.get(key, "(not set)")
        label = label_map.get(key, key)
        lines.append(f"  {label:<26}  {raw}")

    # Budget status line
    lines.append("")
    if budget is None:
        lines.append("  Budget: no cap")
    else:
        status = "EXCEEDED" if spent >= budget else "OK"
        lines.append(f"  Budget: {spent}/{budget} cents today ({status})")
    lines.append(f"  Valid modes: {', '.join(VALID_MODES)}")
    lines.append("")
    return "\n".join(lines)
