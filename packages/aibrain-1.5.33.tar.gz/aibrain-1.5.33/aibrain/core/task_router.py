"""
aibrain.core.task_router — SelRoute-inspired agent routing for company tasks.

When create_task is called, score all available agents for fitness
and assign primary + secondary (reviewer/QA) agents automatically.

Scoring uses keyword overlap between task text and agent attributes
(name, role, title, capabilities). If embedding infra is available,
cosine similarity is used instead for higher accuracy.

Usage:
    from aibrain.core.task_router import route_task

    assignments = route_task(company_id, title, description)
    # => {"primary": agent_id, "secondary": agent_id, "scores": [...]}
"""
from __future__ import annotations

import logging
import re
from typing import Optional

log = logging.getLogger("aibrain.task_router")

# ---------------------------------------------------------------------------
# Keyword overlap scoring (fallback when no embeddings available)
# ---------------------------------------------------------------------------

# Stop words to filter out from scoring — common English words that add noise
_STOP_WORDS = frozenset({
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "shall", "can", "need", "must",
    "and", "or", "but", "if", "for", "of", "in", "on", "at", "to",
    "with", "by", "from", "as", "into", "that", "this", "it", "its",
    "not", "no", "so", "up", "out", "about", "all", "each", "every",
})

# Role keywords that boost score when matched in task text
_ROLE_KEYWORDS: dict[str, list[str]] = {
    "ceo": ["strategic", "decision", "escalation", "priority", "company", "vision"],
    "manager": ["review", "plan", "coordinate", "architecture", "approve", "design"],
    "general": ["build", "implement", "fix", "create", "write", "test", "deploy"],
}


def _tokenize(text: str) -> set[str]:
    """Extract meaningful lowercase tokens from text."""
    tokens = set(re.findall(r'[a-z]+', text.lower()))
    return tokens - _STOP_WORDS


def _keyword_score(task_tokens: set[str], agent: dict) -> float:
    """Score agent fitness via keyword overlap.

    Combines:
      - Name words overlap (weight 1.0)
      - Role match (weight 1.5)
      - Title words overlap (weight 1.0)
      - Capabilities words overlap (weight 2.0)
      - Role-specific keyword bonus (weight 0.5 each)

    Returns a float score (higher = better fit). Normalized to 0-1 range.
    """
    if not task_tokens:
        return 0.0

    score = 0.0
    max_possible = 0.0

    # Name overlap
    name_tokens = _tokenize(agent.get("name", ""))
    if name_tokens:
        overlap = len(task_tokens & name_tokens)
        score += overlap * 1.0
    max_possible += max(len(name_tokens), 1) * 1.0

    # Role match — if role word appears in task
    role = agent.get("role", "general")
    role_tokens = _tokenize(role)
    if role_tokens:
        overlap = len(task_tokens & role_tokens)
        score += overlap * 1.5
    max_possible += max(len(role_tokens), 1) * 1.5

    # Title overlap
    title_tokens = _tokenize(agent.get("title", ""))
    if title_tokens:
        overlap = len(task_tokens & title_tokens)
        score += overlap * 1.0
    max_possible += max(len(title_tokens), 1) * 1.0

    # Capabilities overlap (highest weight — most descriptive)
    cap_tokens = _tokenize(agent.get("capabilities", ""))
    if cap_tokens:
        overlap = len(task_tokens & cap_tokens)
        score += overlap * 2.0
    max_possible += max(len(cap_tokens), 1) * 2.0

    # Role-specific keyword bonus
    role_kw = _ROLE_KEYWORDS.get(role, [])
    for kw in role_kw:
        if kw in task_tokens:
            score += 0.5
    max_possible += len(role_kw) * 0.5

    if max_possible == 0:
        return 0.0

    return min(score / max_possible, 1.0)


def _cosine_score(task_text: str, agent_text: str) -> float:
    """Score agent fitness via cosine similarity of embeddings.

    Returns 0.0 if embedding infra is unavailable.
    """
    try:
        from aibrain_db import _compute_embedding, _cosine_similarity, _db_vec_enabled
        if not _db_vec_enabled:
            return 0.0
        task_emb = _compute_embedding(task_text)
        agent_emb = _compute_embedding(agent_text)
        if task_emb is None or agent_emb is None:
            return 0.0
        return max(0.0, _cosine_similarity(task_emb, agent_emb))
    except Exception:
        return 0.0


def _agent_text(agent: dict) -> str:
    """Build a text representation of an agent for embedding comparison."""
    parts = [
        agent.get("name", ""),
        agent.get("role", ""),
        agent.get("title", ""),
        agent.get("capabilities", ""),
    ]
    return " ".join(p for p in parts if p)


# ---------------------------------------------------------------------------
# QA/Review agent selection — pick the best reviewer (different from primary)
# ---------------------------------------------------------------------------

# Roles that are better suited for review/QA tasks
_REVIEW_ROLES = {"manager", "ceo"}


def _review_bonus(agent: dict) -> float:
    """Extra score for agents with review-appropriate roles."""
    if agent.get("role") in _REVIEW_ROLES:
        return 0.15
    name_lower = (agent.get("name", "") + " " + agent.get("title", "")).lower()
    if any(kw in name_lower for kw in ("qa", "review", "quality", "test", "lead")):
        return 0.1
    return 0.0


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def score_agents(company_id: str, title: str, description: str = "") -> list[dict]:
    """Score all active agents in a company for a given task.

    Returns a list of dicts sorted by score descending:
        [{"agent_id": str, "name": str, "role": str, "score": float}, ...]

    Uses cosine similarity if embeddings are available, falls back to keyword overlap.
    """
    from aibrain.core.companies import list_agents

    agents = list_agents(company_id)
    if not agents:
        return []

    task_text = f"{title} {description}".strip()
    task_tokens = _tokenize(task_text)

    # Try embedding-based scoring first
    use_embeddings = False
    try:
        from aibrain_db import _db_vec_enabled
        use_embeddings = _db_vec_enabled
    except Exception:
        pass

    scored = []
    for agent in agents:
        if use_embeddings:
            s = _cosine_score(task_text, _agent_text(agent))
        else:
            s = _keyword_score(task_tokens, agent)

        scored.append({
            "agent_id": agent["id"],
            "name": agent.get("name", ""),
            "role": agent.get("role", "general"),
            "score": round(s, 4),
        })

    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored


def route_task(
    company_id: str,
    title: str,
    description: str = "",
    explicit_assignee: Optional[str] = None,
    min_agents: int = 2,
) -> dict:
    """Route a task to primary + secondary agents using SelRoute scoring.

    Args:
        company_id: The company to route within.
        title: Task title.
        description: Task description.
        explicit_assignee: If provided, this agent is primary regardless of score.
        min_agents: Minimum agents to assign (default 2: primary + secondary).

    Returns:
        {
            "primary": agent_id or None,
            "secondary": agent_id or None,
            "scores": [{"agent_id", "name", "role", "score"}, ...],
        }
    """
    scored = score_agents(company_id, title, description)

    if not scored:
        return {"primary": None, "secondary": None, "scores": []}

    # Determine primary
    if explicit_assignee:
        primary = explicit_assignee
        # Remove explicit assignee from candidates for secondary selection
        remaining = [s for s in scored if s["agent_id"] != explicit_assignee]
    else:
        primary = scored[0]["agent_id"]
        remaining = scored[1:]

    # Determine secondary — best remaining agent with review bonus
    secondary = None
    if remaining and min_agents >= 2:
        # Re-score remaining with review bonus
        for r in remaining:
            r["_review_score"] = r["score"] + _review_bonus(
                {"name": r["name"], "role": r["role"], "title": r.get("title", "")}
            )
        remaining.sort(key=lambda x: x["_review_score"], reverse=True)
        secondary = remaining[0]["agent_id"]
        # Clean up temp key
        for r in remaining:
            r.pop("_review_score", None)

    log.info(
        "Task routed: primary=%s secondary=%s (from %d candidates)",
        primary, secondary, len(scored),
    )

    return {
        "primary": primary,
        "secondary": secondary,
        "scores": scored,
    }
