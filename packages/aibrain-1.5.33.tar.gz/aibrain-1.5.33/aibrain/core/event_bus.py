"""
event_bus.py — AIBrain event bus with persistent audit log.

Simple pub/sub: emit() fires events, on() registers handlers.
Every event is logged to the event_bus_log SQLite table for
interpretability — see what's happening before wiring reactive chains.

Usage:
    from aibrain.core.event_bus import emit, on

    emit("MEMORY_STORED", {"id": 42, "type": "feedback"})
    on("QUALITY_LOW", lambda payload: print(f"Low quality: {payload}"))
"""

from __future__ import annotations

import atexit
import json
import logging
import sqlite3
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable

log = logging.getLogger("aibrain.event_bus")

# ---------------------------------------------------------------------------
# Background executor for non-blocking handler dispatch
# ---------------------------------------------------------------------------

_handler_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="event_handler")
atexit.register(_handler_executor.shutdown, wait=False)

# Track in-flight futures so drain() can wait for all pending handler calls.
_pending_futures: list = []


def drain(timeout: float = 5.0) -> None:
    """Wait for all in-flight handler futures to complete.

    Useful in tests to ensure handlers dispatched in background threads have
    finished before making assertions.  Clears the pending list when done.

    Args:
        timeout: Maximum seconds to wait per future before giving up.
    """
    from concurrent.futures import wait as _fut_wait
    futures = list(_pending_futures)
    _pending_futures.clear()
    if futures:
        _fut_wait(futures, timeout=timeout)


def _safe_call(handler: Callable, payload: dict) -> None:
    """Invoke a handler, catching and logging any exception so it never propagates."""
    try:
        handler(payload)
    except Exception as exc:
        log.error("event_handler error in %s: %s", getattr(handler, "__name__", repr(handler)), exc)


# ---------------------------------------------------------------------------
# Handler registry (in-memory, per-process)
# ---------------------------------------------------------------------------

_handlers: dict[str, list[Callable]] = defaultdict(list)


def on(event_type: str, handler: Callable) -> None:
    """Register a handler for an event type.

    Args:
        event_type: Event name (e.g. "MEMORY_STORED", "QUALITY_LOW").
        handler: Callable that receives a single dict (the payload).
    """
    _handlers[event_type].append(handler)


def off(event_type: str, handler: Callable) -> None:
    """Unregister a handler."""
    try:
        _handlers[event_type].remove(handler)
    except ValueError:
        pass


def clear_handlers() -> None:
    """Remove all registered handlers (useful for tests)."""
    _handlers.clear()


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS event_bus_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    actor TEXT,
    payload TEXT,
    created TEXT DEFAULT (datetime('now'))
);
"""

_INDEX_SQL = """
CREATE INDEX IF NOT EXISTS idx_event_bus_type ON event_bus_log(event_type);
"""

_ACTOR_INDEX_SQL = """
CREATE INDEX IF NOT EXISTS idx_event_bus_actor ON event_bus_log(actor);
"""

_MIGRATE_ACTOR_SQL = """
ALTER TABLE event_bus_log ADD COLUMN actor TEXT;
"""


def _get_db_path() -> Path:
    """Resolve the aibrain.db path via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    return AIBRAIN_ROOT / "aibrain.db"


def _ensure_table(db: sqlite3.Connection) -> None:
    """Create event_bus_log table if it doesn't exist. Migrates actor column on existing DBs."""
    db.execute(_TABLE_SQL)
    db.execute(_INDEX_SQL)
    # Idempotent migration: add actor column if the table pre-dates this change.
    try:
        db.execute(_MIGRATE_ACTOR_SQL)
    except Exception:
        pass  # Column already exists — expected on all DBs created after this patch
    try:
        db.execute(_ACTOR_INDEX_SQL)
    except Exception:
        pass
    db.commit()


def _connect() -> sqlite3.Connection:
    """Open a connection to aibrain.db with WAL mode."""
    db_path = _get_db_path()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    _ensure_table(conn)
    return conn


# ---------------------------------------------------------------------------
# Core: emit
# ---------------------------------------------------------------------------

def emit(event_type: str, payload: dict | None = None, source: str | None = None,
         actor: str | None = None) -> int | None:
    """Fire an event: validate, log to DB, then call registered handlers.

    Args:
        event_type: Event name string.
        payload: Arbitrary dict stored as JSON.
        source: Agent/process that emitted the event (validated against allowlist).
        actor: Human-readable actor label (e.g. "neuro", "lead_engineer"). Stored
               in the event_bus_log actor column for filter queries.

    Returns:
        Row ID of the logged event, or None if logging/validation failed.
    """
    payload = payload or {}
    # Resolve actor: explicit > source > AGENT_ID env > None
    _actor = actor or source or None

    # 0. Pre-dispatch validation (learning loop poisoning defense)
    try:
        from aibrain.core.event_validation import validate_event
        result = validate_event(event_type, payload, source=source)
        if not result.ok:
            log.warning("Event blocked by validation: %s", result.reason)
            return None
    except ImportError:
        pass  # validation module not available, allow event through
    except Exception as e:
        log.debug("Event validation error (non-fatal, allowing event): %s", e)

    row_id = None

    # 1. Persist to audit log
    try:
        conn = _connect()
        cur = conn.execute(
            "INSERT INTO event_bus_log (event_type, actor, payload) VALUES (?, ?, ?)",
            (event_type, _actor, json.dumps(payload, default=str)),
        )
        conn.commit()
        row_id = cur.lastrowid
        conn.close()
    except Exception as e:
        log.debug("Event bus log write failed (non-fatal): %s", e)

    # 2. Dispatch to in-memory handlers (non-blocking — each runs in background thread)
    for handler in _handlers.get(event_type, []):
        fut = _handler_executor.submit(_safe_call, handler, payload)
        _pending_futures.append(fut)

    log.debug("Event emitted: %s (id=%s)", event_type, row_id)
    return row_id


# ---------------------------------------------------------------------------
# Query: recent events
# ---------------------------------------------------------------------------

def recent(last: int = 20, event_type: str | None = None,
           actor: str | None = None) -> list[dict]:
    """Fetch recent events from the audit log.

    Args:
        last: Number of events to return.
        event_type: Optional filter by event type.
        actor: Optional filter by actor.

    Returns:
        List of dicts with id, event_type, actor, payload (parsed), created.
    """
    try:
        conn = _connect()
        where_clauses = []
        params: list = []
        if event_type:
            where_clauses.append("event_type = ?")
            params.append(event_type)
        if actor:
            where_clauses.append("actor = ?")
            params.append(actor)
        where_sql = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""
        params.append(last)
        rows = conn.execute(
            f"SELECT id, event_type, actor, payload, created FROM event_bus_log "
            f"{where_sql} ORDER BY id DESC LIMIT ?",
            params,
        ).fetchall()
        conn.close()

        results = []
        for r in rows:
            try:
                p = json.loads(r["payload"]) if r["payload"] else {}
            except (json.JSONDecodeError, TypeError):
                p = {"raw": r["payload"]}
            results.append({
                "id": r["id"],
                "event_type": r["event_type"],
                "actor": r["actor"],
                "payload": p,
                "created": r["created"],
            })
        return results
    except Exception as e:
        log.debug("Event bus query failed: %s", e)
        return []


def count_by_type() -> dict[str, int]:
    """Return event counts grouped by type."""
    try:
        conn = _connect()
        rows = conn.execute(
            "SELECT event_type, COUNT(*) as cnt FROM event_bus_log "
            "GROUP BY event_type ORDER BY cnt DESC"
        ).fetchall()
        conn.close()
        return {r["event_type"]: r["cnt"] for r in rows}
    except Exception:
        return {}


# ---------------------------------------------------------------------------
# Event type constants
# ---------------------------------------------------------------------------

class EventTypes:
    """Standard AIBrain event types."""
    MEMORY_STORED = "MEMORY_STORED"
    CORRECTION_RECEIVED = "CORRECTION_RECEIVED"
    QUALITY_LOW = "QUALITY_LOW"
    TASK_COMPLETED = "TASK_COMPLETED"
    WORKFLOW_EXECUTED = "WORKFLOW_EXECUTED"
    SCAN_FINDING_STORED = "SCAN_FINDING_STORED"
    # Harness lifecycle events
    HARNESS_TASK_START = "harness.task.start"
    HARNESS_TASK_COMPLETE = "harness.task.complete"
    HARNESS_TASK_FAIL = "harness.task.fail"
    # Company task lifecycle events
    COMPANY_TASK_CHECKOUT = "company.task.checkout"
    COMPANY_TASK_COMPLETE = "company.task.complete"
    # Memory Lifecycle v1.6 events
    MEMORY_VERIFIED = "MEMORY_VERIFIED"
    MEMORY_SUPERSEDED = "MEMORY_SUPERSEDED"
    PLAN_EXPIRED = "PLAN_EXPIRED"
    CONTRADICTION_DETECTED = "CONTRADICTION_DETECTED"


# ---------------------------------------------------------------------------
# CLI helper
# ---------------------------------------------------------------------------

def cli_events(args: list[str]) -> int:
    """CLI entry point for `aibrain events [--last N] [--type TYPE] [--actor ACTOR]`."""
    last = 20
    event_type = None
    actor = None

    i = 0
    while i < len(args):
        if args[i] in ("--last", "--limit") and i + 1 < len(args):
            try:
                last = int(args[i + 1])
            except ValueError:
                pass
            i += 2
        elif args[i] == "--type" and i + 1 < len(args):
            event_type = args[i + 1]
            i += 2
        elif args[i] == "--actor" and i + 1 < len(args):
            actor = args[i + 1]
            i += 2
        elif args[i] == "--summary":
            counts = count_by_type()
            if not counts:
                print("  No events recorded yet.")
                return 0
            print("\n  Event Bus Summary")
            print("  " + "-" * 40)
            for etype, cnt in counts.items():
                print(f"  {etype:<30} {cnt:>5}")
            total = sum(counts.values())
            print("  " + "-" * 40)
            print(f"  {'TOTAL':<30} {total:>5}")
            print()
            return 0
        else:
            i += 1

    events = recent(last=last, event_type=event_type, actor=actor)
    if not events:
        print("  No events found.")
        return 0

    print(f"\n  Event Bus Log (last {last})")
    print("  " + "-" * 80)
    for e in reversed(events):  # oldest first
        actor_str = (e.get("actor") or "-")[:12]
        payload_str = json.dumps(e["payload"], default=str)
        if len(payload_str) > 50:
            payload_str = payload_str[:47] + "..."
        print(f"  {e['created']}  {actor_str:<12}  {e['event_type']:<25} {payload_str}")
    print()
    return 0
