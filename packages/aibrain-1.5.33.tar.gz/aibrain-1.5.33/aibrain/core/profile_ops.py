"""
aibrain/core/profile_ops.py — Shared logic for profile create/manage operations.

Used by:
  - aibrain/cli/profile_cmd.py  (Phase 3 CLI)
  - backend/profiles_api.py     (Phase 5 API — deferred)

Isolation model: profile-level separation via DB path override.
An isolated profile uses its own brain DB at AIBRAIN_ROOT/aibrain_<name>.db.
This is a convenience boundary, NOT OS-level process isolation.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Optional

from aibrain.core import profile_registry


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")  # 1-32 chars, lowercase alphanum + hyphen
_MAX_NAME_LEN = 32


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_aibrain_root() -> Path:
    """Use the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    return AIBRAIN_ROOT


def _get_python() -> str:
    return sys.executable


def validate_profile_name(name: str) -> Optional[str]:
    """Return an error string if name is invalid, else None."""
    if not name:
        return "Profile name cannot be empty."
    if len(name) > _MAX_NAME_LEN:
        return f"Profile name must be {_MAX_NAME_LEN} chars or fewer (got {len(name)})."
    if not _NAME_RE.match(name):
        return "Profile name must match [a-z0-9][a-z0-9-]* (lowercase, numbers, hyphens only)."
    return None


def _write_settings_json(profile_dir: Path) -> None:
    """Write a settings.json with the standard hooks template into profile_dir.

    Mirrors the hooks written by setup_wizard so new profiles get the same
    realtime_learner + broker_hook + memory_md_sync hooks out of the box.

    HISTORY: Prior version had three bugs: (1) mixed Windows backslash from
    sys.executable with hardcoded forward slashes producing path strings bash
    couldn't execute, (2) used `_get_aibrain_root()` for SCRIPT location when
    AIBRAIN_ROOT is the DATA directory not the script directory, (3) never
    verified the referenced scripts existed before writing. The Apr 6-10 2026
    split-brain incident exposed this — see project_aibrain_lobotomy_apr6_apr10.

    FIX: Use forward-slash python invocation (bash-safe on Windows Git Bash),
    look up scripts via the canonical AIBRAIN_ROOT (where the dev layout has
    them), and SKIP hooks whose scripts don't exist rather than writing broken
    settings.json that bash will reject.
    """
    from aibrain_db import AIBRAIN_ROOT

    # Forward-slash python path — survives bash escape on Windows
    python = Path(sys.executable).as_posix()

    # Script locations — these live in the source tree alongside aibrain/, not
    # in AIBRAIN_ROOT-the-data-dir. On a dev install AIBRAIN_ROOT IS the source
    # tree so this works; on a user install via pip, the scripts must be
    # importable as `python -m aibrain.X` (TODO: refactor scripts into package).
    script_root = AIBRAIN_ROOT
    broker_hook_script = script_root / "broker_hook.py"
    realtime_learner_script = script_root / "realtime_learner.py"
    memory_sync_script = script_root / "workflows" / "memory_md_sync.py"

    # Verify each script exists before referencing it. If a script is missing,
    # SKIP its hook rather than writing a broken command. This makes the function
    # safe across dev / pip / site-packages layouts.
    hooks: dict = {}

    if broker_hook_script.exists():
        hooks["UserPromptSubmit"] = [{
            "hooks": [{
                "type": "command",
                "command": f'"{python}" "{broker_hook_script.as_posix()}"',
                "timeout": 5,
                "statusMessage": "Checking messages...",
            }]
        }]

    precompact_hooks = []
    if realtime_learner_script.exists():
        precompact_hooks.append({
            "type": "command",
            "command": f'"{python}" "{realtime_learner_script.as_posix()}"',
            "timeout": 15,
            "statusMessage": "Extracting learnings before compaction...",
        })
    if memory_sync_script.exists():
        precompact_hooks.append({
            "type": "command",
            "command": f'"{python}" "{memory_sync_script.as_posix()}" --stats-only --all',
            "timeout": 10,
            "statusMessage": "Syncing MEMORY.md with DB...",
        })
    if precompact_hooks:
        hooks["PreCompact"] = [{"matcher": "*", "hooks": precompact_hooks}]

    if memory_sync_script.exists():
        hooks["PostCompact"] = [{
            "matcher": "*",
            "hooks": [{
                "type": "command",
                "command": f'"{python}" "{memory_sync_script.as_posix()}" --stats-only --all',
                "timeout": 10,
                "statusMessage": "Syncing MEMORY.md after compaction...",
            }]
        }]

    if realtime_learner_script.exists():
        hooks["Stop"] = [{
            "matcher": "*",
            "hooks": [{
                "type": "command",
                "command": f'"{python}" "{realtime_learner_script.as_posix()}"',
                "timeout": 10,
            }]
        }]

    settings = {"hooks": hooks} if hooks else {}

    settings_path = profile_dir / "settings.json"
    settings_path.write_text(json.dumps(settings, indent=2, ensure_ascii=False), encoding="utf-8")


def _write_mcp_config(profile_dir: Path, db_path: Optional[Path]) -> None:
    """Write .claude.json with mcpServers into profile_dir.

    For isolated profiles: uses explicit --db <db_path> so the MCP server
    always connects to the isolated DB.

    For hive profiles: copies mcpServers from the primary ~/.claude.json
    (same servers, same primary DB — sharing is handled at the DB level).
    """
    aibrain_root = str(_get_aibrain_root())
    python = _get_python()
    mcp_script = f"{aibrain_root}/mcp_server.py"

    if db_path is not None:
        # Isolated: explicit --db pointing to isolated DB
        args = [mcp_script, "--db", str(db_path)]
    else:
        # Hive: use primary DB (same as primary profile)
        primary_db = str(_get_aibrain_root() / "aibrain.db")
        args = [mcp_script, "--db", primary_db]

    # Build base mcpServers block
    mcp_servers: dict = {
        "aibrain-memory": {
            "command": python,
            "args": args,
        }
    }

    # Also carry peer-discovery if it exists
    peer_script = Path(aibrain_root) / "mcp_peer_discovery.py"
    if peer_script.exists():
        mcp_servers["peer-discovery"] = {
            "command": python,
            "args": [str(peer_script)],
        }

    # Merge any additional servers from the primary ~/.claude.json
    primary_state = Path.home() / ".claude.json"
    if primary_state.exists():
        try:
            primary_data = json.loads(primary_state.read_text(encoding="utf-8"))
            for srv_name, srv_cfg in primary_data.get("mcpServers", {}).items():
                if srv_name not in mcp_servers:
                    mcp_servers[srv_name] = srv_cfg
        except Exception:
            pass  # Best-effort — don't block profile creation

    profile_state = profile_dir / ".claude.json"
    # Preserve existing non-mcpServers keys if file already exists
    existing: dict = {}
    if profile_state.exists():
        try:
            existing = json.loads(profile_state.read_text(encoding="utf-8"))
        except Exception:
            existing = {}

    existing["mcpServers"] = mcp_servers
    profile_state.write_text(json.dumps(existing, indent=2, ensure_ascii=False), encoding="utf-8")


# ---------------------------------------------------------------------------
# Hive profile helpers
# ---------------------------------------------------------------------------

def _link_hive_dirs(profile_dir: Path) -> None:
    """Create junctions/symlinks for shared hive dirs.

    Links the following from ~/.claude-<name>/ to the primary ~/.claude/:
      skills/, agents/, rules/, projects/
    And copies CLAUDE.md (if present in primary) rather than linking it,
    so each hive profile can have its own identity notes if needed.

    On Windows, directories use NTFS junctions (no admin required).
    On POSIX, symlinks are used.
    """
    primary_claude = Path.home() / ".claude"
    shared_dirs = ["skills", "agents", "rules", "projects"]

    for dirname in shared_dirs:
        src = primary_claude / dirname
        dst = profile_dir / dirname

        if not src.exists():
            # Source does not exist yet — create it so the link target is valid
            src.mkdir(parents=True, exist_ok=True)

        if dst.exists() or dst.is_symlink():
            continue  # Already set up — idempotent

        _create_link(dst, src)

    # Copy (not link) CLAUDE.md so profile identity can diverge
    src_claude_md = primary_claude / "CLAUDE.md"
    dst_claude_md = profile_dir / "CLAUDE.md"
    if src_claude_md.exists() and not dst_claude_md.exists():
        import shutil
        shutil.copy2(str(src_claude_md), str(dst_claude_md))


def _create_link(dst: Path, src: Path) -> None:
    """Create a symlink or NTFS junction from dst -> src."""
    try:
        dst.symlink_to(src)
    except (OSError, NotImplementedError):
        # Windows: try NTFS junction (no admin rights needed for directories)
        try:
            subprocess.run(
                ["cmd", "/c", "mklink", "/J", str(dst), str(src)],
                check=True,
                capture_output=True,
            )
        except Exception as exc:
            raise OSError(f"Could not create link {dst} -> {src}: {exc}") from exc


# ---------------------------------------------------------------------------
# Isolated profile helpers
# ---------------------------------------------------------------------------

def _create_isolated_dirs(profile_dir: Path) -> None:
    """Create real (non-linked) directories for an isolated profile.

    Isolated profiles have their own skills/, agents/, rules/, projects/ dirs.
    These are real directories — nothing is shared with the primary brain.
    """
    for dirname in ["skills", "agents", "rules", "projects"]:
        (profile_dir / dirname).mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def create_profile(
    name: str,
    mode: str,
    label: Optional[str] = None,
) -> dict:
    """Create a new Claude Code profile directory and register it.

    Args:
        name:  Profile name — must match [a-z0-9][a-z0-9-]*, max 32 chars.
        mode:  "hive" or "isolated".
        label: Optional human-readable label.

    Returns the registry entry dict on success.
    Raises ValueError for invalid input.
    Raises RuntimeError if profile already exists in registry.
    """
    # Validate name
    err = validate_profile_name(name)
    if err:
        raise ValueError(err)

    if mode not in ("hive", "isolated"):
        raise ValueError(f"mode must be 'hive' or 'isolated', got: {mode!r}")

    # Check not already registered
    existing = profile_registry.get_profile_entry(name)
    if existing is not None:
        raise RuntimeError(f"Profile '{name}' is already registered (mode={existing['mode']}). Use 'aibrain profile info {name}' to inspect.")

    # Create profile directory
    profile_dir = Path.home() / f".claude-{name}"
    profile_dir.mkdir(parents=True, exist_ok=True)

    if mode == "hive":
        _link_hive_dirs(profile_dir)
        db_path_str = None
        _write_settings_json(profile_dir)
        _write_mcp_config(profile_dir, db_path=None)
    else:
        # isolated
        _create_isolated_dirs(profile_dir)
        # Determine isolated DB path — MCP server creates it on first connect
        isolated_db = _get_aibrain_root() / f"aibrain_{name}.db"
        db_path_str = str(isolated_db)
        _write_settings_json(profile_dir)
        _write_mcp_config(profile_dir, db_path=isolated_db)
        # Copy CLAUDE.md if present (not linked — isolated identity can diverge)
        src_claude_md = Path.home() / ".claude" / "CLAUDE.md"
        dst_claude_md = profile_dir / "CLAUDE.md"
        if src_claude_md.exists() and not dst_claude_md.exists():
            import shutil
            shutil.copy2(str(src_claude_md), str(dst_claude_md))

    # Register in profiles.json
    entry = profile_registry.register_profile(name, mode=mode, db_path=db_path_str, label=label)
    return entry


# ---------------------------------------------------------------------------
# Hive filesystem permission model
# ---------------------------------------------------------------------------
#
# Hive profiles share the primary brain but have restricted writes:
#
#   Path                 Hive access    Isolated access
#   ─────────────────    ───────────    ───────────────
#   aibrain.db           read-write     N/A (own DB)
#   skills/              read-only      read-write
#   agents/              read-only      read-write
#   rules/               read-only      read-write
#   workflows/           read-only      read-write
#   projects/            read-only      read-write
#   CLAUDE.md            read-write     read-write  (copied, not linked)
#   settings.json        read-write     read-write  (per-profile)
#
# "read-only" for hive means the dirs are junctions/symlinks to the primary
# profile — writes should go through the primary profile, not the hive copy.
# This is enforced at the application level via check_permissions().

# Directories that hive profiles can only read (shared config)
HIVE_READ_ONLY_DIRS = frozenset({"skills", "agents", "rules", "workflows", "projects"})

# Paths that hive profiles can write (own copy or shared DB)
HIVE_WRITABLE = frozenset({"aibrain.db", "CLAUDE.md", "settings.json", ".claude.json"})


def _resolve_profile_dir(profile_name: str) -> Path:
    """Return the profile directory for a given profile name."""
    return Path.home() / f".claude-{profile_name}"


def get_profile_permissions(profile_name: str) -> dict:
    """Return the permission map for a profile.

    Returns:
        Dict with keys:
          mode:           "hive" or "isolated"
          writable_files: list of writable file basenames
          read_only_dirs: list of read-only directory names (hive only)
          writable_dirs:  list of writable directory names
          db_access:      "read-write" or "own" (isolated has its own DB)
    """
    entry = profile_registry.get_profile_entry(profile_name)
    if entry is None:
        # Unregistered profiles default to hive behaviour
        mode = "hive"
    else:
        mode = entry.get("mode", "hive")

    if mode == "hive":
        return {
            "mode": "hive",
            "writable_files": sorted(HIVE_WRITABLE),
            "read_only_dirs": sorted(HIVE_READ_ONLY_DIRS),
            "writable_dirs": [],
            "db_access": "read-write",
        }
    else:
        return {
            "mode": "isolated",
            "writable_files": sorted(HIVE_WRITABLE),
            "read_only_dirs": [],
            "writable_dirs": sorted(HIVE_READ_ONLY_DIRS),
            "db_access": "own",
        }


def check_permissions(profile_name: str) -> dict:
    """Verify that filesystem permissions match the expected profile mode.

    Checks:
      - Profile directory exists
      - For hive: shared dirs are symlinks/junctions (read-only pointers)
      - For hive: aibrain.db is accessible (read-write)
      - For isolated: shared dirs are real directories (writable)
      - For isolated: own DB file exists or is creatable

    Returns:
        Dict with keys:
          ok:       bool — True if all checks pass
          mode:     "hive" or "isolated"
          errors:   list of error strings (empty if ok=True)
          warnings: list of warning strings
    """
    entry = profile_registry.get_profile_entry(profile_name)
    if entry is None:
        mode = "hive"
    else:
        mode = entry.get("mode", "hive")

    profile_dir = _resolve_profile_dir(profile_name)
    errors: list[str] = []
    warnings: list[str] = []

    # Check profile dir exists
    if not profile_dir.exists():
        errors.append(f"Profile directory does not exist: {profile_dir}")
        return {"ok": False, "mode": mode, "errors": errors, "warnings": warnings}

    if mode == "hive":
        # Shared dirs should be symlinks or junctions
        for dirname in HIVE_READ_ONLY_DIRS:
            target = profile_dir / dirname
            if not target.exists():
                warnings.append(f"Shared dir missing (may not be set up yet): {dirname}/")
                continue
            if not target.is_symlink() and not _is_junction(target):
                errors.append(
                    f"{dirname}/ is a real directory but should be a symlink/junction "
                    f"for hive mode (read-only shared config)"
                )

        # DB should be the shared one and accessible
        shared_db = _get_aibrain_root() / "aibrain.db"
        if shared_db.exists():
            if not os.access(str(shared_db), os.R_OK | os.W_OK):
                errors.append(f"Shared brain DB is not read-write: {shared_db}")
        else:
            warnings.append(f"Shared brain DB does not exist yet: {shared_db}")

    else:
        # Isolated: dirs should be real (not links)
        for dirname in HIVE_READ_ONLY_DIRS:
            target = profile_dir / dirname
            if not target.exists():
                warnings.append(f"Isolated dir missing: {dirname}/")
                continue
            if target.is_symlink() or _is_junction(target):
                errors.append(
                    f"{dirname}/ is a symlink/junction but should be a real directory "
                    f"for isolated mode (writable)"
                )

        # Own DB should exist or be creatable
        db_path = entry.get("db_path") if entry else None
        if db_path:
            db_file = Path(db_path)
            if db_file.exists():
                if not os.access(str(db_file), os.R_OK | os.W_OK):
                    errors.append(f"Isolated DB is not read-write: {db_file}")
            else:
                # Check parent is writable
                if not db_file.parent.exists():
                    errors.append(f"Isolated DB parent dir does not exist: {db_file.parent}")
                elif not os.access(str(db_file.parent), os.W_OK):
                    errors.append(f"Cannot create isolated DB — parent not writable: {db_file.parent}")

    return {
        "ok": len(errors) == 0,
        "mode": mode,
        "errors": errors,
        "warnings": warnings,
    }


def _is_junction(path: Path) -> bool:
    """Check if a path is an NTFS junction (Windows-specific).

    On non-Windows systems, always returns False.
    """
    if sys.platform != "win32":
        return False
    try:
        import ctypes
        FILE_ATTRIBUTE_REPARSE_POINT = 0x400
        attrs = ctypes.windll.kernel32.GetFileAttributesW(str(path))  # type: ignore[attr-defined]
        if attrs == -1:
            return False
        return bool(attrs & FILE_ATTRIBUTE_REPARSE_POINT)
    except Exception:
        return False
