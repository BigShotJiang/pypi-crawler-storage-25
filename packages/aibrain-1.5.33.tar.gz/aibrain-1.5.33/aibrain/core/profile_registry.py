"""
aibrain/core/profile_registry.py — Profile mode registry (hive vs isolated).

Profile-level separation via DB path override — not OS-level process isolation.
An isolated profile uses a dedicated DB file; it does not sandbox network, filesystem,
or subprocess access. Treat it as a convenience boundary, not a security boundary.

Registry file: AIBRAIN_ROOT/profiles.json
Schema:
  {
    "<profile_name>": {
      "name": str,
      "mode": "hive" | "isolated",
      "label": str | null,
      "db_path": str | null,   # only used for isolated mode
      "created": ISO-8601 str
    },
    ...
  }
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Root resolution — same pattern as rest of codebase
# ---------------------------------------------------------------------------

def _get_aibrain_root() -> Path:
    """Use the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    return AIBRAIN_ROOT


def _profiles_json() -> Path:
    return _get_aibrain_root() / "profiles.json"


# Public constant for use by other modules
PROFILES_JSON: Path = _profiles_json()


# ---------------------------------------------------------------------------
# Core I/O
# ---------------------------------------------------------------------------

def load_registry() -> dict:
    """Load profiles registry from disk.

    Returns {} if the file is missing or unreadable — never raises.
    """
    try:
        path = _profiles_json()
        if not path.exists():
            return {}
        text = path.read_text(encoding="utf-8")
        data = json.loads(text)
        if not isinstance(data, dict):
            return {}
        return data
    except Exception:
        return {}


def save_registry(data: dict) -> None:
    """Atomically save profiles registry to disk.

    Writes to a .tmp file then renames — prevents corruption on crash mid-write.
    """
    path = _profiles_json()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    try:
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)  # atomic on POSIX; best-effort on Windows
    except Exception:
        # Clean up tmp if something went wrong
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        raise


# ---------------------------------------------------------------------------
# Query helpers
# ---------------------------------------------------------------------------

def get_profile_entry(profile_name: str) -> Optional[dict]:
    """Return the registry entry for a profile, or None if not registered."""
    registry = load_registry()
    return registry.get(profile_name)


def is_isolated(profile_name: str) -> bool:
    """Return True if the named profile is registered with mode='isolated'.

    Returns False for missing entries (backward-compatible — unregistered profiles
    behave as hive by default).
    """
    entry = get_profile_entry(profile_name)
    if entry is None:
        return False
    return entry.get("mode") == "isolated"


def list_profiles() -> list[dict]:
    """Return all registered profiles sorted by name, with computed fields."""
    registry = load_registry()
    profiles = []
    for name, entry in registry.items():
        if not isinstance(entry, dict):
            continue
        item = dict(entry)
        item["name"] = name  # ensure name is present in each entry
        profiles.append(item)
    return sorted(profiles, key=lambda x: x.get("name", ""))


# ---------------------------------------------------------------------------
# Mutation helpers
# ---------------------------------------------------------------------------

def register_profile(
    name: str,
    mode: str,
    db_path: Optional[str] = None,
    label: Optional[str] = None,
) -> dict:
    """Upsert a profile entry in the registry.

    Args:
        name:     Profile name (matches the ~/.claude-<name> dir).
        mode:     "hive" or "isolated".
        db_path:  Explicit DB path for isolated profiles. Ignored for hive.
        label:    Human-readable label.

    Returns the saved entry dict.
    """
    registry = load_registry()
    existing = registry.get(name, {})
    entry = {
        "name": name,
        "mode": mode,
        "label": label if label is not None else existing.get("label"),
        "db_path": db_path if db_path is not None else existing.get("db_path"),
        "created": existing.get("created") or _iso_now(),
    }
    registry[name] = entry
    save_registry(registry)
    return entry


def unregister_profile(name: str) -> bool:
    """Remove a profile from the registry.

    Returns True if it existed, False if it was not registered.
    Does NOT touch the filesystem directory or database.
    """
    registry = load_registry()
    if name not in registry:
        return False
    del registry[name]
    save_registry(registry)
    return True


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _iso_now() -> str:
    import datetime
    return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
