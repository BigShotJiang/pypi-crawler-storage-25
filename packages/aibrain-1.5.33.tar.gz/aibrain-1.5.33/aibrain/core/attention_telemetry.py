"""Attention telemetry — logs every memory retrieval for pattern analysis.

Tracks which memories get retrieved, which queries are most common,
and which search types are used. Enables data-driven memory optimization.
"""

import json
import sqlite3
import threading

_lock = threading.Lock()
_conn = None


def _get_db() -> sqlite3.Connection:
    """Lazy singleton connection to aibrain.db for telemetry writes."""
    global _conn
    if _conn is not None:
        return _conn
    with _lock:
        if _conn is not None:
            return _conn
        from aibrain_db import AIBRAIN_ROOT
        db_path = AIBRAIN_ROOT / "aibrain.db"
        _conn = sqlite3.connect(str(db_path), check_same_thread=False)
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.row_factory = sqlite3.Row
        _init_table(_conn)
        return _conn


def _init_table(conn: sqlite3.Connection):
    """Create attention_log table if it doesn't exist."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS attention_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            query TEXT NOT NULL,
            result_ids TEXT DEFAULT '[]',
            result_count INTEGER DEFAULT 0,
            search_type TEXT DEFAULT 'unknown',
            latency_ms REAL DEFAULT 0.0,
            timestamp TEXT DEFAULT (datetime('now'))
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_attention_log_ts
        ON attention_log(timestamp)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_attention_log_search_type
        ON attention_log(search_type)
    """)
    conn.commit()


def reset_connection():
    """Reset the singleton connection (used by tests)."""
    global _conn
    with _lock:
        if _conn is not None:
            try:
                _conn.close()
            except Exception:
                pass
            _conn = None


def log_retrieval(query: str, results: list, context: dict | None = None) -> int | None:
    """Log a memory retrieval event.

    Args:
        query: The search query text.
        results: List of memory dicts returned by search.
        context: Optional dict with search_type, latency_ms, route, etc.

    Returns:
        Row ID of the logged event, or None on failure.
    """
    if not query:
        return None
    ctx = context or {}
    result_ids = [r.get("id") for r in (results or []) if isinstance(r, dict) and r.get("id")]
    result_count = len(results or [])
    search_type = ctx.get("search_type") or ctx.get("route") or "unknown"
    latency_ms = ctx.get("latency_ms", 0.0)

    try:
        db = _get_db()
        cur = db.execute(
            "INSERT INTO attention_log (query, result_ids, result_count, search_type, latency_ms) "
            "VALUES (?, ?, ?, ?, ?)",
            (query, json.dumps(result_ids), result_count, search_type, latency_ms),
        )
        db.commit()
        return cur.lastrowid
    except Exception:
        return None


def get_attention_stats(days: int = 7) -> dict:
    """Aggregate attention stats over the last N days.

    Returns:
        Dict with keys:
        - total_retrievals: int
        - top_queries: list of (query, count) tuples — most common queries
        - top_memories: list of (memory_id, count) tuples — most retrieved memories
        - search_type_breakdown: dict of search_type -> count
        - avg_latency_ms: float
        - avg_result_count: float
    """
    db = _get_db()
    cutoff = f"-{days} days"

    # Total retrievals
    total = db.execute(
        "SELECT COUNT(*) FROM attention_log WHERE timestamp >= datetime('now', ?)",
        (cutoff,),
    ).fetchone()[0]

    # Top queries (normalized to lowercase for grouping)
    top_queries_rows = db.execute(
        "SELECT LOWER(query) as q, COUNT(*) as c FROM attention_log "
        "WHERE timestamp >= datetime('now', ?) "
        "GROUP BY q ORDER BY c DESC LIMIT 20",
        (cutoff,),
    ).fetchall()
    top_queries = [(r[0], r[1]) for r in top_queries_rows]

    # Search type breakdown
    type_rows = db.execute(
        "SELECT search_type, COUNT(*) as c FROM attention_log "
        "WHERE timestamp >= datetime('now', ?) "
        "GROUP BY search_type ORDER BY c DESC",
        (cutoff,),
    ).fetchall()
    search_type_breakdown = {r[0]: r[1] for r in type_rows}

    # Average latency
    avg_lat = db.execute(
        "SELECT AVG(latency_ms) FROM attention_log WHERE timestamp >= datetime('now', ?)",
        (cutoff,),
    ).fetchone()[0] or 0.0

    # Average result count
    avg_rc = db.execute(
        "SELECT AVG(result_count) FROM attention_log WHERE timestamp >= datetime('now', ?)",
        (cutoff,),
    ).fetchone()[0] or 0.0

    # Top retrieved memory IDs (parse JSON result_ids and count)
    rows = db.execute(
        "SELECT result_ids FROM attention_log WHERE timestamp >= datetime('now', ?)",
        (cutoff,),
    ).fetchall()
    mem_counts: dict[int, int] = {}
    for row in rows:
        try:
            ids = json.loads(row[0])
            for mid in ids:
                if isinstance(mid, int):
                    mem_counts[mid] = mem_counts.get(mid, 0) + 1
        except (json.JSONDecodeError, TypeError):
            pass
    top_memories = sorted(mem_counts.items(), key=lambda x: x[1], reverse=True)[:20]

    return {
        "total_retrievals": total,
        "top_queries": top_queries,
        "top_memories": top_memories,
        "search_type_breakdown": search_type_breakdown,
        "avg_latency_ms": round(avg_lat, 2),
        "avg_result_count": round(avg_rc, 2),
    }
