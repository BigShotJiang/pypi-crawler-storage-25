"""superworker.py — programmatic wrapper for the SuperWorker persona.

WARNING: returns untrusted LLM text. Never exec/eval/splice into shell/SQL.

Design (R1B): one Anthropic backend, JSON sidecar parser + markdown fallback,
lens_router.route() verbatim, persona cached from decker_system, honest None
on unmeasurable fields (commit 730a682), read-only (only write: superworker_runs).

Pair: decker_system/02_subagents/superworker_agent.md, lens_router.py, harness.py.
"""
from __future__ import annotations

import json
import logging
import os
import re
import secrets
import shutil
import sqlite3
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from aibrain.core import lens_router
from aibrain.core.adapters import ADAPTERS
from aibrain.core.pricing import (
    compute_equivalent_cents,
    compute_equivalent_cents_from_sdk_usage,
    extract_tokens_from_cli_envelope,
)

log = logging.getLogger(__name__)

# Original: C:/Users/sinde/decker_system/02_subagents/superworker_agent.md
SUPERWORKER_PERSONA_PATH = Path(os.environ.get("DECKER_SYSTEM", "")) / "02_subagents" / "superworker_agent.md"


class SuperWorkerQuotaError(Exception):
    """Raised when a free-tier user exceeds their monthly SuperWorker quota (5/mo)."""
    pass
MAX_TOKENS = 8000
_PERSONA_CACHE: Optional[str] = None

# Module-level cache for claude CLI availability probe. None = not yet checked,
# True/False = cached result. Reset to None in tests via monkeypatch if needed.
# _CLAUDE_CLI_PATH caches the resolved binary path (Windows: claude.CMD, POSIX:
# claude) so _run_via_claude_cli can exec it directly — critical on Windows,
# where subprocess can't spawn `.CMD` shims from a bare "claude" argv[0].
_CLAUDE_CLI_AVAILABLE: Optional[bool] = None
_CLAUDE_CLI_PATH: Optional[str] = None
_CLAUDE_CLI_TIMEOUT_SEC = 300  # 5 minute cap on a single CLI call

_SIDECAR_RE = re.compile(r"<!--\s*superworker_json:\s*(\{.*?\})\s*-->", re.DOTALL)
_SYNTH_HEADER_RE = re.compile(r"^##\s+Synthesis\s*$", re.MULTILINE | re.IGNORECASE)
_FINAL_REC_RE = re.compile(r"^\*\*Final recommendation:\*\*\s*(.+?)(?=^\*\*|\Z)", re.MULTILINE | re.DOTALL)
_SYNTH_CONF_RE = re.compile(r"^\*\*Synthesis confidence:\*\*\s*([0-9.]+|null)", re.MULTILINE | re.IGNORECASE)
_EVAL_RE = re.compile(r"^\*\*Honest-rubric eval_score[^:]*:\*\*\s*([0-9.]+|null)", re.MULTILINE | re.IGNORECASE)


@dataclass
class SuperWorkerResult:
    """One SuperWorker invocation. raw_markdown always preserved; unmeasurable fields are None."""
    task: str
    task_type: str
    lenses_consulted: list[str]
    routing_reason: str
    per_lens: list[dict]
    synthesis: str
    compatible_views: list[str]
    conflicts: list[str]
    overrode: list[str]
    synthesis_confidence: Optional[float]
    eval_score: Optional[float]
    raw_markdown: str
    parse_status: str  # "ok" | "partial" | "failed"
    warnings: list[str]
    cost_cents: Optional[int]
    model_used: Optional[str]  # None when model cannot be determined (honest-rubric contract)
    duration_ms: int
    success: bool
    run_id: str
    # Token-to-cents equivalence (Apr 11 2026 — task #11).
    # cost_cents_actual:     real money spent (0 for CLI/subscription path, real int for SDK)
    # cost_cents_equivalent: what the tokens WOULD cost at list rates, computed for BOTH backends
    #                         from the envelope's usage fields. Honest-None when token counts
    #                         are unavailable (old runs, missing envelope, unknown model).
    # cost_cents stays for backwards compat (it's the same as cost_cents_actual).
    # These come LAST in the field list with default=None so pre-existing callers
    # that pass only the original positional args keep working — dataclass default
    # field ordering requires defaults to follow non-defaults.
    cost_cents_actual: Optional[int] = None
    cost_cents_equivalent: Optional[int] = None
    # Lens transparency: top contributing voices from the sidecar JSON.
    # Each entry: {"lens": str, "argument": str, "weight": float 0-1}
    # Empty list when the sidecar omits voices or parse fails (honest-null).
    voices: list[dict] = field(default_factory=list)

    def to_harness_dict(self) -> dict:
        """Dict shaped for harness.execute() self-report at harness.py:318.

        Carries the SuperWorker's three self-report fields:
          _cost_cents  — measured cost from Anthropic usage (None if missing)
          _model_used  — the actual model that ran (e.g. claude-sonnet-4-...)
          _self_score  — the LLM's self-assessed eval_score from its output
                         (0.0-1.0 OR None per honest-rubric). The harness
                         compares this against its INDEPENDENT eval_score
                         and persists divergence in execution_log.

        Bidirectional null rule (Apr 11, after first divergence-loop dogfood):
        when the persona returns eval_score=null but synthesis_confidence is
        a real number, fall back to synthesis_confidence as _self_score. The
        persona spec at decker_system/02_subagents/superworker_agent.md now
        forbids this asymmetry, but this code-level safety net catches drift
        from older personas or future persona regressions. The two fields
        are tightly coupled — if the persona could rate the synthesis, it
        had enough signal to score the work product overall.
        """
        # Honest-rubric fallback: if eval_score is None but synthesis_confidence
        # is a real number, use synthesis_confidence as the self-score signal.
        # This is NOT a fake default — it's "use the measurement we DO have
        # rather than report None when we have signal".
        self_score_value = self.eval_score
        if self_score_value is None and self.synthesis_confidence is not None:
            self_score_value = self.synthesis_confidence
        return {
            "result": self,
            "_cost_cents": self.cost_cents,
            "_cost_cents_actual": self.cost_cents_actual,
            "_cost_cents_equivalent": self.cost_cents_equivalent,
            "_model_used": self.model_used,
            "_self_score": self_score_value,
        }


_FREE_TIER_MONTHLY_LIMIT = 5


def invoke(
    task: str,
    task_type: Optional[str] = None,
    lens_count: int = 7,
    model: str = "claude-sonnet-4-20250514",
    user_id: Optional[str] = None,
    tier: Optional[str] = None,
) -> SuperWorkerResult:
    """Call a SuperWorker. Never raises — errors become success=False with warnings.

    Tier gating (Apr 13 2026):
      - tier='free':  enforces 5 runs/month quota. Raises SuperWorkerQuotaError on exceed.
      - tier='pro':   unlimited runs.
      - tier=None:    no quota check (backwards compat for callers that don't pass tier).
    user_id is used as the quota key. Falls back to 'anonymous' when not supplied.
    """
    # Quota check BEFORE spending any compute.
    _user_key = user_id or "anonymous"
    if tier == "free":
        current_count = _get_monthly_usage(_user_key)
        if current_count >= _FREE_TIER_MONTHLY_LIMIT:
            raise SuperWorkerQuotaError(
                f"Free tier: {_FREE_TIER_MONTHLY_LIMIT} SuperWorker tasks/month. "
                "Upgrade to Pro for unlimited."
            )

    run_id = secrets.token_urlsafe(8)
    t0 = time.time()
    route = None
    text, used_model, cost_cents = "", model, None
    cost_cents_equivalent: Optional[int] = None
    warnings: list[str] = []
    parsed: dict = {"parse_status": "failed"}

    try:
        route = lens_router.route(task_type=task_type, task_description=task, lens_count=lens_count)
        system_prompt = _build_system_prompt(_load_persona(), route)
        user_prompt = _build_user_prompt(task)
        text, used_model, cost_cents, cost_cents_equivalent = _run_llm(
            user_prompt, system_prompt, model,
        )
        parsed, parse_warnings = _parse_output(text)
        warnings.extend(parse_warnings)
    except Exception as e:
        log.exception("superworker.invoke failed")
        warnings.append(f"{type(e).__name__}: {e}")

    result = SuperWorkerResult(
        task=task,
        task_type=route.task_type if route else (task_type or ""),
        lenses_consulted=route.all_lenses if route else [],
        routing_reason=route.routing_reason if route else "",
        per_lens=parsed.get("per_lens", []),
        synthesis=parsed.get("synthesis", ""),
        compatible_views=parsed.get("compatible_views", []),
        conflicts=parsed.get("conflicts", []),
        overrode=parsed.get("overrode", []),
        synthesis_confidence=parsed.get("synthesis_confidence"),
        eval_score=parsed.get("eval_score"),
        raw_markdown=text,
        parse_status=parsed.get("parse_status", "failed"),
        warnings=warnings,
        cost_cents=cost_cents,
        cost_cents_actual=cost_cents,
        cost_cents_equivalent=cost_cents_equivalent,
        model_used=used_model,
        duration_ms=int((time.time() - t0) * 1000),
        success=parsed.get("parse_status", "failed") != "failed",
        run_id=run_id,
        voices=parsed.get("voices", []),
    )
    _validate(result)
    _record_run(result)
    # Increment usage AFTER successful run (not on quota errors, which raised above).
    if tier is not None:
        _increment_monthly_usage(_user_key)
    return result


# --- internals -------------------------------------------------------------

def _get_monthly_usage(user_id: str) -> int:
    """Return the current month's SuperWorker run count for user_id. Returns 0 on any error."""
    try:
        from aibrain.core.harness import _get_or_create_db
        p = _get_or_create_db()
        if p is None:
            return 0
        month = time.strftime("%Y-%m")
        with sqlite3.connect(str(p)) as db:
            row = db.execute(
                "SELECT count FROM superworker_usage WHERE user_id=? AND month=?",
                (user_id, month),
            ).fetchone()
        return row[0] if row else 0
    except Exception as e:
        log.debug("_get_monthly_usage failed (non-fatal): %s", e)
        return 0


def _increment_monthly_usage(user_id: str) -> None:
    """Increment (or create) this month's SuperWorker usage row for user_id. Silent on DB failure."""
    try:
        from aibrain.core.harness import _get_or_create_db
        p = _get_or_create_db()
        if p is None:
            return
        month = time.strftime("%Y-%m")
        with sqlite3.connect(str(p)) as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute(
                "INSERT INTO superworker_usage (user_id, month, count) VALUES (?, ?, 1) "
                "ON CONFLICT(user_id, month) DO UPDATE SET count = count + 1",
                (user_id, month),
            )
            db.commit()
    except Exception as e:
        log.debug("_increment_monthly_usage failed (non-fatal): %s", e)


def _resolve_persona_path(base_path: Path) -> Path:
    """Prefer the V2 persona file when it exists; fall back to V1.

    V1 files are immutable per the lineage rule. V2 files live beside V1
    with a `_v2.md` suffix. When the loader does not specify a version
    explicitly, pick V2 iff present, else V1. Added 2026-04-12 for V2
    deployment. See decker_system/02_subagents/*_v2.md.
    """
    v2 = base_path.with_name(f"{base_path.stem}_v2{base_path.suffix}")
    return v2 if v2.exists() else base_path


def _load_persona() -> str:
    global _PERSONA_CACHE
    if _PERSONA_CACHE is None:
        persona_path = _resolve_persona_path(SUPERWORKER_PERSONA_PATH)
        _PERSONA_CACHE = persona_path.read_text(encoding="utf-8")
    return _PERSONA_CACHE


def _build_system_prompt(persona: str, route: "lens_router.LensRoute") -> str:
    """Build the system prompt by injecting the full lens roster with descriptions.

    Each lens gets its name AND specialty so the model knows what perspective
    to channel — not just a name. Always-on lenses (Decker + Schneier, or
    Operator/Adversarial on public floor) are listed first and marked as such.

    Dissent contract: at least one adversarial/Red Team/Devil's Advocate lens
    must produce a dissenting view. If the synthesis naturally converges without
    dissent, the model is instructed to inject a 'strongest counterargument'
    section before finalising.
    """
    lens_details = lens_router.describe_lenses(route.all_lenses)
    always_on_set = set(route.always_on)

    always_on_lines = []
    routed_lines = []
    for ld in lens_details:
        line = f"  - **{ld['name']}** — {ld['specialty']}"
        if ld["name"] in always_on_set:
            always_on_lines.append(line)
        else:
            routed_lines.append(line)

    always_on_block = (
        "Always-on lenses (NEVER deselected — present in every synthesis):\n"
        + "\n".join(always_on_lines)
    )
    routed_block = (
        "Task-specific lenses (routed for this task_type):\n"
        + ("\n".join(routed_lines) if routed_lines else "  (none beyond always-on)")
    )

    # Identify dissent lenses in this roster
    dissent_keywords = {"adversarial", "red team", "devil", "security", "schneier", "mcafee"}
    dissent_lenses = [
        ld["name"] for ld in lens_details
        if any(kw in ld["name"].lower() or kw in ld["specialty"].lower()
               for kw in dissent_keywords)
    ]
    dissent_note = ""
    if dissent_lenses:
        dissent_note = (
            "\n\n## Dissent contract\n"
            f"At least one of {dissent_lenses} MUST surface a dissenting view.\n"
            "If the synthesis naturally converges, you MUST append a final section:\n"
            "**Strongest counterargument:** [the best case that this synthesis is wrong]\n"
            "Majority outvoting a dissenter without explicit address is BANNED."
        )

    return (
        f"{persona}\n\n---\n\n## Lens roster for THIS task\n\n"
        f"Routed by lens_router for task_type={route.task_type!r}.\n"
        f"Routing reason: {route.routing_reason}\n\n"
        f"{always_on_block}\n\n"
        f"{routed_block}\n"
        f"{dissent_note}\n"
    )


def _build_user_prompt(task: str) -> str:
    return (
        f"{task}\n\n---\n\n"
        "Produce the markdown output exactly as specified in the persona spec. "
        "Channel ONLY the lenses listed in the system prompt — walk each one independently "
        "before writing the synthesis section.\n\n"
        "**Dissent requirement:** Before finalising your synthesis, confirm that at least one "
        "adversarial/security/Red Team lens has expressed a dissenting or challenging view. "
        "If no natural dissent arose, append this section before the JSON sidecar:\n"
        "> **Strongest counterargument:** [state the best argument that your synthesis is wrong "
        "or incomplete, as the most adversarial lens on your roster would frame it]\n\n"
        "After the final section, append a single HTML comment on its own line with a JSON sidecar:\n\n"
        "<!-- superworker_json: {\"synthesis\": \"...\", \"compatible_views\": [...], "
        "\"conflicts\": [...], \"overrode\": [...], \"synthesis_confidence\": 0.0, "
        "\"eval_score\": 0.0, "
        "\"per_lens\": [{\"name\": \"...\", \"finding\": \"...\", \"confidence\": 0.0}], "
        "\"voices\": [{\"lens\": \"...\", \"argument\": \"...\", \"weight\": 0.0}]} -->\n\n"
        "For 'voices': include the top 5 lenses (by weight) that most shaped your synthesis. "
        "weight is 0.0-1.0 (1.0 = decisive). "
        "Use null (not a fake number) when there is no real signal. Use exactly the lens names given."
    )


def _claude_cli_available() -> bool:
    """Probe for a working `claude` binary on PATH. Result cached module-level.

    Returns True iff:
      1. `shutil.which('claude')` finds the binary, AND
      2. `claude --version` exits 0 within a short timeout.

    Any exception → False. The cache means we only pay this probe cost once
    per process; tests can reset via `superworker._CLAUDE_CLI_AVAILABLE = None`
    or monkeypatch the function directly.
    """
    global _CLAUDE_CLI_AVAILABLE, _CLAUDE_CLI_PATH
    if _CLAUDE_CLI_AVAILABLE is not None:
        return _CLAUDE_CLI_AVAILABLE

    path = shutil.which("claude")
    if not path:
        _CLAUDE_CLI_AVAILABLE = False
        _CLAUDE_CLI_PATH = None
        return False

    try:
        r = subprocess.run(
            [path, "--version"],
            capture_output=True, text=True, timeout=10, check=False,
        )
        _CLAUDE_CLI_AVAILABLE = (r.returncode == 0)
        _CLAUDE_CLI_PATH = path if _CLAUDE_CLI_AVAILABLE else None
    except (subprocess.TimeoutExpired, OSError) as e:
        log.debug("claude --version probe failed: %s", e)
        _CLAUDE_CLI_AVAILABLE = False
        _CLAUDE_CLI_PATH = None
    return _CLAUDE_CLI_AVAILABLE


def _load_canonical_claude_cli():
    """Resolve and import the canonical claude_cli helper from decker_system.

    The helper lives at `decker_system/04_tools/claude_cli.py`. We discover
    the decker_system root via the same sentinel as lens_router (
    `~/.aibrainrc` key → `DECKER_SYSTEM_ROOT` env var → platform defaults).
    Returns the `call_claude_cli` function, or None if the helper is
    unavailable (public-only install without the overlay).
    """
    try:
        from aibrain.core.lens_router import _resolve_overlay_root
    except Exception:
        return None
    root = _resolve_overlay_root()
    if root is None:
        return None
    helper_path = Path(root) / "04_tools" / "claude_cli.py"
    if not helper_path.exists():
        return None
    try:
        import importlib.util as _ilu
        spec = _ilu.spec_from_file_location("_ds_claude_cli", str(helper_path))
        if spec is None or spec.loader is None:
            return None
        mod = _ilu.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore[union-attr]
        fn = getattr(mod, "call_claude_cli", None)
        return fn if callable(fn) else None
    except Exception as e:
        log.debug("canonical claude_cli helper load failed: %s", e)
        return None


_CANONICAL_CALL_CLAUDE_CLI = None


def _run_via_claude_cli(
    prompt: str, system: str, model: str,
) -> tuple[str, str, Optional[int], Optional[int]]:
    """Invoke the `claude` CLI in non-interactive JSON mode. Free via subscription.

    Command shape (flags verified against `claude --help` on v2.1.101):
      claude -p --output-format json --no-session-persistence \
             --append-system-prompt-file <temp_path> --model <model>
      [prompt on stdin]

    All Windows-specific subprocess handling (`.CMD` path resolution,
    stdin piping for >32KB prompts, tempfile system-prompt cleanup) is
    delegated to the canonical helper at
    `decker_system/04_tools/claude_cli.py`. See
    `feedback_claude_cli_windows_bug_class.md` for the bug-class history.

    Returns (assistant_text, model_used, cost_cents_actual, cost_cents_equivalent).
    cost_cents_actual=0 because this path goes through the user's Claude Pro/Max
    subscription, not the metered API. cost_cents_equivalent is computed from
    the envelope's modelUsage token counts at list rates (aibrain.core.pricing),
    giving Decker a real dollar number for subscription utilization tracking.
    Returns cost_cents_equivalent=None when the envelope lacks token counts or
    the model is unknown to the rate table (honest-rubric contract).

    Raises RuntimeError on any failure (missing helper, non-zero exit,
    malformed JSON, missing `result` field, is_error=True). The caller in
    _run_llm is responsible for catching and falling back to the SDK path.
    """
    global _CANONICAL_CALL_CLAUDE_CLI
    if _CANONICAL_CALL_CLAUDE_CLI is None:
        _CANONICAL_CALL_CLAUDE_CLI = _load_canonical_claude_cli()
    if _CANONICAL_CALL_CLAUDE_CLI is None:
        raise RuntimeError(
            "canonical claude_cli helper missing — decker_system overlay "
            "not discoverable. See feedback_claude_cli_windows_bug_class.md."
        )

    rc, stdout, stderr = _CANONICAL_CALL_CLAUDE_CLI(
        prompt=prompt,
        system_prompt=system,
        model=model,
        timeout_s=_CLAUDE_CLI_TIMEOUT_SEC,
        batch_flags=False,
        extra_args=["-p", "--output-format", "json", "--no-session-persistence"],
    )

    if rc == 124:
        raise RuntimeError(f"claude CLI timed out after {_CLAUDE_CLI_TIMEOUT_SEC}s")
    if rc == 127:
        raise RuntimeError(f"claude CLI not found: {stderr.strip()[:200]}")
    if rc != 0:
        tail = (stderr or "").strip()[:500]
        raise RuntimeError(f"claude CLI exit {rc}: {tail}")

    if not stdout.strip():
        raise RuntimeError("claude CLI returned empty stdout")

    try:
        envelope = json.loads(stdout)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"claude CLI JSON parse failed: {e}") from e

    if not isinstance(envelope, dict):
        raise RuntimeError(f"claude CLI envelope not a dict: {type(envelope).__name__}")

    if envelope.get("is_error") is True:
        subtype = envelope.get("subtype", "unknown")
        raise RuntimeError(f"claude CLI reported is_error=true (subtype={subtype})")

    text = envelope.get("result")
    if not isinstance(text, str):
        raise RuntimeError("claude CLI envelope missing 'result' string field")

    # modelUsage is a dict keyed by the actual model name that ran. Prefer the
    # first key if present; fall back to the requested model if the shape is
    # missing or unexpected (still honest — we report what we asked for).
    used_model = model
    model_from_envelope, token_counts = extract_tokens_from_cli_envelope(envelope)
    if isinstance(model_from_envelope, str) and model_from_envelope:
        used_model = model_from_envelope

    # cost_cents_actual=0 is the honest answer here: this call went through the
    # Pro/Max subscription, NOT the metered API. The envelope's total_cost_usd
    # reflects what the same call WOULD have cost via API, not what the user
    # was charged. cost_cents_equivalent IS that "would-have-cost" — computed
    # from the token counts the CLI reports, at list rates from pricing.py.
    # Honest-None: when token counts are missing, equivalent stays None.
    if token_counts:
        equivalent = compute_equivalent_cents(
            model=used_model,
            input_tokens=token_counts.get("input_tokens"),
            output_tokens=token_counts.get("output_tokens"),
            cache_read_tokens=token_counts.get("cache_read_tokens", 0),
            cache_write_tokens=token_counts.get("cache_write_tokens", 0),
        )
    else:
        equivalent = None

    return text, used_model, 0, equivalent


def _run_llm(
    prompt: str, system: str, model: str,
) -> tuple[str, str, Optional[int], Optional[int]]:
    """Substitution seam. Tries claude CLI first (free via subscription),
    falls back to Anthropic SDK (metered) on any CLI failure.

    Returns (text, model_used, cost_cents_actual, cost_cents_equivalent).

    cost_cents_actual:     real spend (0 on CLI path; adapter-computed on SDK)
    cost_cents_equivalent: list-rate equivalent for BOTH paths, None when
                           token counts unavailable (honest-rubric contract).
    """
    if _claude_cli_available():
        try:
            return _run_via_claude_cli(prompt, system, model)
        except Exception as e:
            log.info("claude CLI backend failed, falling back to SDK: %s", e)
            # Fall through to SDK path

    import anthropic  # lazy so tests can mock
    client = anthropic.Anthropic()
    resp = client.messages.create(
        model=model, max_tokens=MAX_TOKENS, system=system,
        messages=[{"role": "user", "content": prompt}],
    )
    usage = getattr(resp, "usage", None)
    actual = _compute_cost(usage, "claude")
    equivalent = compute_equivalent_cents_from_sdk_usage(usage, model)
    return resp.content[0].text, model, actual, equivalent


def _compute_cost(usage: Any, adapter_name: str) -> Optional[int]:
    """Honest None when usage/rates missing. int cents otherwise."""
    if usage is None:
        return None
    in_tok = getattr(usage, "input_tokens", None)
    out_tok = getattr(usage, "output_tokens", None)
    if in_tok is None or out_tok is None:
        return None
    a = ADAPTERS.get(adapter_name)
    if a is None:
        return None
    usd = (in_tok / 1000.0) * a.cost_per_1k_input + (out_tok / 1000.0) * a.cost_per_1k_output
    return int(round(usd * 100)) if usd >= 0 else None


def _parse_output(text: str) -> tuple[dict, list[str]]:
    """JSON sidecar first, markdown regex fallback. Both miss → parse_status=failed."""
    warnings: list[str] = []
    if not text:
        return {"parse_status": "failed"}, ["empty LLM output"]

    sidecar = _SIDECAR_RE.search(text)
    if sidecar:
        try:
            d = json.loads(sidecar.group(1))
            # Extract and validate voices: list of {lens, argument, weight}
            raw_voices = d.get("voices") or []
            voices: list[dict] = []
            for v in raw_voices[:5]:  # cap at 5 per spec
                if isinstance(v, dict) and "lens" in v:
                    voices.append({
                        "lens": str(v.get("lens", "")),
                        "argument": str(v.get("argument", "")),
                        "weight": _coerce_float(v.get("weight")) or 0.0,
                    })
            return {
                "synthesis": d.get("synthesis", "") or "",
                "compatible_views": d.get("compatible_views") or [],
                "conflicts": d.get("conflicts") or [],
                "overrode": d.get("overrode") or [],
                "synthesis_confidence": _coerce_float(d.get("synthesis_confidence")),
                "eval_score": _coerce_float(d.get("eval_score")),
                "per_lens": d.get("per_lens") or [],
                "voices": voices,
                "parse_status": "ok",
            }, warnings
        except (json.JSONDecodeError, ValueError) as e:
            warnings.append(f"JSON sidecar malformed: {e}")

    if not _SYNTH_HEADER_RE.search(text):
        warnings.append("no ## Synthesis section found")
        return {"parse_status": "failed"}, warnings

    body = text.split("## Synthesis", 1)[1]
    fr = _FINAL_REC_RE.search(body)
    sc = _SYNTH_CONF_RE.search(body)
    ev = _EVAL_RE.search(body)
    if not fr:
        warnings.append("markdown regex: no **Final recommendation:** found")
    return {
        "synthesis": fr.group(1).strip() if fr else "",
        "compatible_views": [], "conflicts": [], "overrode": [],
        "synthesis_confidence": _coerce_float(sc.group(1)) if sc else None,
        "eval_score": _coerce_float(ev.group(1)) if ev else None,
        "per_lens": [],
        "parse_status": "ok" if fr else "partial",
    }, warnings


def _coerce_float(v: Any) -> Optional[float]:
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        s = v.strip().lower()
        if s in ("null", "none", ""):
            return None
        try:
            return float(s)
        except ValueError:
            return None
    return None


def _validate(r: SuperWorkerResult) -> None:
    """Invariants: 0<=eval_score<=1, 0<=synthesis_confidence<=1, cost_cents>=0, duration>=0."""
    if r.eval_score is not None and not (0.0 <= r.eval_score <= 1.0):
        r.warnings.append(f"eval_score {r.eval_score} out of [0,1] — clamped to None")
        r.eval_score = None
    if r.synthesis_confidence is not None and not (0.0 <= r.synthesis_confidence <= 1.0):
        r.warnings.append(f"synthesis_confidence {r.synthesis_confidence} out of [0,1] — clamped to None")
        r.synthesis_confidence = None
    if r.cost_cents is not None and r.cost_cents < 0:
        r.warnings.append(f"cost_cents {r.cost_cents} negative — clamped to None")
        r.cost_cents = None
    if r.cost_cents_actual is not None and r.cost_cents_actual < 0:
        r.warnings.append(f"cost_cents_actual {r.cost_cents_actual} negative — clamped to None")
        r.cost_cents_actual = None
    if r.cost_cents_equivalent is not None and r.cost_cents_equivalent < 0:
        r.warnings.append(
            f"cost_cents_equivalent {r.cost_cents_equivalent} negative — clamped to None"
        )
        r.cost_cents_equivalent = None
    if r.duration_ms < 0:
        r.duration_ms = 0


_SCHEMA = (
    "CREATE TABLE IF NOT EXISTS superworker_runs ("
    "run_id TEXT PRIMARY KEY, ts INTEGER NOT NULL, task TEXT NOT NULL, "
    "task_type TEXT NOT NULL, lenses TEXT NOT NULL, routing_reason TEXT, "
    "model_used TEXT, cost_cents INTEGER, "
    "cost_cents_actual INTEGER, cost_cents_equivalent INTEGER, "
    "duration_ms INTEGER, "
    "synthesis_conf REAL, eval_score REAL, parse_status TEXT, success INTEGER NOT NULL)"
)

# Idempotent column migration for pre-Apr11 DBs that already have
# superworker_runs without the equivalence columns. Runs once per INSERT call;
# sqlite handles duplicate-column errors gracefully via a try/except.
_MIGRATIONS = (
    "ALTER TABLE superworker_runs ADD COLUMN cost_cents_actual INTEGER",
    "ALTER TABLE superworker_runs ADD COLUMN cost_cents_equivalent INTEGER",
)


def _record_run(r: SuperWorkerResult) -> None:
    """INSERT into superworker_runs. Silent on DB failure — observability, not load-bearing.

    Uses _get_or_create_db (Bug #6 fix) so the FIRST ever SuperWorker run on
    a fresh install persists its row instead of silently no-op'ing.
    """
    try:
        from aibrain.core.harness import _get_or_create_db
        p = _get_or_create_db()
        if p is None:
            return
        with sqlite3.connect(str(p)) as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute(_SCHEMA)
            # Idempotent column add for legacy schema. duplicate-column errors
            # are expected on fresh schema (where _SCHEMA already includes
            # the new columns) and ignored.
            for ddl in _MIGRATIONS:
                try:
                    db.execute(ddl)
                except sqlite3.OperationalError:
                    pass  # column already exists
            db.execute(
                "INSERT OR REPLACE INTO superworker_runs "
                "(run_id, ts, task, task_type, lenses, routing_reason, "
                " model_used, cost_cents, cost_cents_actual, cost_cents_equivalent, "
                " duration_ms, synthesis_conf, eval_score, parse_status, success) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (r.run_id, int(time.time()), r.task[:2000], r.task_type,
                 json.dumps(r.lenses_consulted), r.routing_reason, r.model_used,
                 r.cost_cents, r.cost_cents_actual, r.cost_cents_equivalent,
                 r.duration_ms, r.synthesis_confidence,
                 r.eval_score, r.parse_status, 1 if r.success else 0),
            )
            db.commit()
    except Exception as e:
        log.debug("superworker_runs record failed (non-fatal): %s", e)
