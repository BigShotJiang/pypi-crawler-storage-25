"""
Product metrics — operationalize AIBrain's 5 marketing claims.

Each function returns a dict with measured values from the live DB.
CLI: `aibrain metrics`
"""

from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional


def _connect(db_path: Optional[str] = None) -> sqlite3.Connection:
    """Open the aibrain DB (WAL-safe, read-only intent)."""
    if db_path is None:
        db_path = str(Path(__file__).resolve().parents[2] / "aibrain.db")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


# ── 1. Self-improving ─────────────────────────────────────────────

def measure_self_improving(days: int = 30, db_path: Optional[str] = None) -> dict:
    """Correction rate over rolling 7-day windows.

    A *decreasing* correction rate with stable/increasing task count
    proves the brain is self-improving.
    """
    conn = _connect(db_path)
    c = conn.cursor()

    cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()

    # Total outcomes per 7-day bucket
    c.execute("""
        SELECT
            CAST((julianday(created_at) - julianday(?)) / 7 AS INTEGER) AS bucket,
            COUNT(*) AS total,
            SUM(CASE WHEN action = 'correction' THEN 1 ELSE 0 END) AS corrections
        FROM evolution_outcomes
        WHERE created_at >= ?
        GROUP BY bucket
        ORDER BY bucket
    """, (cutoff, cutoff))

    windows = []
    for row in c.fetchall():
        total = row["total"]
        corrections = row["corrections"]
        rate = round(corrections / total, 4) if total else 0.0
        windows.append({
            "window": row["bucket"],
            "total_outcomes": total,
            "corrections": corrections,
            "correction_rate": rate,
        })

    conn.close()

    trend = "insufficient_data"
    if len(windows) >= 2:
        rates = [w["correction_rate"] for w in windows]
        trend = "improving" if rates[-1] < rates[0] else "stable_or_regressing"

    return {
        "claim": "Self-improving",
        "metric": "correction_rate_trend",
        "days": days,
        "windows": windows,
        "trend": trend,
    }


# ── 2. Embedded memory ───────────────────────────────────────────

def measure_embedded_memory(db_path: Optional[str] = None) -> dict:
    """Memory utilization: active memories, access patterns, recall depth."""
    conn = _connect(db_path)
    c = conn.cursor()

    c.execute("SELECT COUNT(*) AS n FROM memories WHERE active = 1")
    active = c.fetchone()["n"]

    c.execute("SELECT COUNT(*) AS n FROM memories WHERE active = 1 AND access_count > 0")
    accessed = c.fetchone()["n"]

    c.execute("SELECT AVG(access_count) AS avg_acc FROM memories WHERE active = 1 AND access_count > 0")
    avg_access = round(c.fetchone()["avg_acc"] or 0, 2)

    # Memory-sourced evolution outcomes (corrections that came from memory recall)
    c.execute("SELECT COUNT(*) AS n FROM evolution_outcomes WHERE source = 'memory'")
    memory_sourced = c.fetchone()["n"]

    c.execute("SELECT COUNT(*) AS n FROM evolution_outcomes")
    total_outcomes = c.fetchone()["n"]

    conn.close()

    recall_precision = round(accessed / active, 4) if active else 0.0
    memory_assist_rate = round(memory_sourced / total_outcomes, 4) if total_outcomes else 0.0

    return {
        "claim": "Embedded memory",
        "metric": "memory_utilization",
        "active_memories": active,
        "accessed_memories": accessed,
        "recall_precision": recall_precision,
        "avg_access_count": avg_access,
        "memory_assisted_outcomes": memory_sourced,
        "total_outcomes": total_outcomes,
        "memory_assist_rate": memory_assist_rate,
    }


# ── 3. Smart retrieval ──────────────────────────────────────────

def measure_smart_retrieval(db_path: Optional[str] = None) -> dict:
    """Tiered search: category summaries (Tier 1) vs individual lookups (Tier 2/3)."""
    conn = _connect(db_path)
    c = conn.cursor()

    # Tier 1: category summaries available
    c.execute("SELECT COUNT(*) AS n FROM category_summaries")
    tier1_categories = c.fetchone()["n"]

    c.execute("SELECT SUM(memory_count) AS n FROM category_summaries")
    tier1_coverage = c.fetchone()["n"] or 0

    # Tier 2/3: individual memories
    c.execute("SELECT COUNT(*) AS n FROM memories WHERE active = 1")
    total_active = c.fetchone()["n"]

    # High-value memories (importance >= 0.7 AND accessed)
    c.execute("""
        SELECT COUNT(*) AS n FROM memories
        WHERE active = 1 AND importance >= 0.7 AND access_count > 0
    """)
    high_value = c.fetchone()["n"]

    # Stale memories (active but never accessed, older than 7 days)
    c.execute("""
        SELECT COUNT(*) AS n FROM memories
        WHERE active = 1 AND access_count = 0
        AND julianday('now') - julianday(created) > 7
    """)
    stale = c.fetchone()["n"]

    conn.close()

    coverage_rate = round(tier1_coverage / total_active, 4) if total_active else 0.0

    return {
        "claim": "Smart retrieval",
        "metric": "tiered_search_quality",
        "tier1_categories": tier1_categories,
        "tier1_memory_coverage": tier1_coverage,
        "total_active_memories": total_active,
        "coverage_rate": coverage_rate,
        "high_value_accessed": high_value,
        "stale_memories": stale,
    }


# ── 4. Portable ──────────────────────────────────────────────────

def measure_portable(db_path: Optional[str] = None) -> dict:
    """Sync success rate, profile count, cross-agent execution."""
    conn = _connect(db_path)
    c = conn.cursor()

    # Sync state
    c.execute("SELECT agent_id, records_exported, records_imported, last_export, last_import FROM sync_state")
    syncs = []
    total_exported = 0
    total_imported = 0
    for row in c.fetchall():
        exp = row["records_exported"] or 0
        imp = row["records_imported"] or 0
        total_exported += exp
        total_imported += imp
        syncs.append({
            "agent": row["agent_id"],
            "exported": exp,
            "imported": imp,
            "last_export": row["last_export"],
            "last_import": row["last_import"],
        })

    # Distinct source agents (cross-machine evidence)
    c.execute("SELECT source_agent, COUNT(*) AS n FROM memories WHERE active = 1 AND source_agent IS NOT NULL GROUP BY source_agent")
    agents = {row["source_agent"]: row["n"] for row in c.fetchall()}

    # Profiles
    try:
        from aibrain.core.profile_registry import list_profiles
        profiles = list_profiles()
        profile_count = len(profiles) if profiles else 0
    except Exception:
        profile_count = 0

    conn.close()

    return {
        "claim": "Portable",
        "metric": "cross_machine_sync",
        "sync_agents": syncs,
        "total_exported": total_exported,
        "total_imported": total_imported,
        "distinct_source_agents": len(agents),
        "source_agent_breakdown": agents,
        "profile_count": profile_count,
    }


# ── 5. Zero config ──────────────────────────────────────────────

def measure_zero_config(db_path: Optional[str] = None) -> dict:
    """Onboarding speed: time from first DB write to first successful task."""
    conn = _connect(db_path)
    c = conn.cursor()

    # Earliest memory (proxy for install/first-use)
    c.execute("SELECT MIN(created) AS first FROM memories")
    first_memory = c.fetchone()["first"]

    # First successful execution
    c.execute("SELECT MIN(created_at) AS first FROM execution_log WHERE success = 1")
    first_exec = c.fetchone()["first"]

    # Setup steps (if tracked)
    c.execute("SELECT COUNT(*) AS n FROM setup_steps")
    setup_steps = c.fetchone()["n"]

    # Config entries (fewer = more zero-config)
    c.execute("SELECT COUNT(*) AS n FROM config")
    config_entries = c.fetchone()["n"]

    conn.close()

    onboarding_seconds = None
    if first_memory and first_exec:
        try:
            t0 = datetime.fromisoformat(first_memory)
            t1 = datetime.fromisoformat(first_exec)
            onboarding_seconds = max(0, (t1 - t0).total_seconds())
        except (ValueError, TypeError):
            pass

    return {
        "claim": "Zero config",
        "metric": "onboarding_speed",
        "first_memory_at": first_memory,
        "first_execution_at": first_exec,
        "onboarding_seconds": onboarding_seconds,
        "setup_steps_defined": setup_steps,
        "config_entries": config_entries,
    }


# ── Dashboard ────────────────────────────────────────────────────

def product_dashboard(db_path: Optional[str] = None) -> dict:
    """All 5 product metrics in one call."""
    return {
        "self_improving": measure_self_improving(db_path=db_path),
        "embedded_memory": measure_embedded_memory(db_path=db_path),
        "smart_retrieval": measure_smart_retrieval(db_path=db_path),
        "portable": measure_portable(db_path=db_path),
        "zero_config": measure_zero_config(db_path=db_path),
    }


# ── CLI renderer ─────────────────────────────────────────────────

def print_dashboard(db_path: Optional[str] = None) -> None:
    """Pretty-print all 5 product metrics."""
    data = product_dashboard(db_path=db_path)

    print("\n" + "=" * 60)
    print("  AIBrain Product Metrics Dashboard")
    print("=" * 60)

    # 1. Self-improving
    si = data["self_improving"]
    print(f"\n1. SELF-IMPROVING  [{si['trend']}]")
    print(f"   Correction rate over {si['days']}d in 7-day windows:")
    for w in si["windows"]:
        bar = "#" * int(w["correction_rate"] * 40)
        print(f"   W{w['window']:>2}: {w['correction_rate']:.1%} ({w['corrections']}/{w['total_outcomes']}) {bar}")

    # 2. Embedded memory
    em = data["embedded_memory"]
    print("\n2. EMBEDDED MEMORY")
    print(f"   Active: {em['active_memories']:,}  |  Accessed: {em['accessed_memories']:,}  ({em['recall_precision']:.1%} recall)")
    print(f"   Avg access count: {em['avg_access_count']}  |  Memory-assist rate: {em['memory_assist_rate']:.1%}")

    # 3. Smart retrieval
    sr = data["smart_retrieval"]
    print("\n3. SMART RETRIEVAL")
    print(f"   Tier 1 categories: {sr['tier1_categories']}  |  Coverage: {sr['tier1_memory_coverage']:,} / {sr['total_active_memories']:,} ({sr['coverage_rate']:.1%})")
    print(f"   High-value accessed: {sr['high_value_accessed']:,}  |  Stale: {sr['stale_memories']:,}")

    # 4. Portable
    po = data["portable"]
    print("\n4. PORTABLE")
    print(f"   Profiles: {po['profile_count']}  |  Source agents: {po['distinct_source_agents']}")
    print(f"   Synced: {po['total_exported']:,} exported, {po['total_imported']:,} imported")
    for s in po["sync_agents"]:
        print(f"     {s['agent']}: {s['exported']:,} exp / {s['imported']:,} imp")

    # 5. Zero config
    zc = data["zero_config"]
    print("\n5. ZERO CONFIG")
    if zc["onboarding_seconds"] is not None:
        if zc["onboarding_seconds"] < 60:
            speed = f"{zc['onboarding_seconds']:.0f}s"
        elif zc["onboarding_seconds"] < 3600:
            speed = f"{zc['onboarding_seconds'] / 60:.1f}m"
        else:
            speed = f"{zc['onboarding_seconds'] / 3600:.1f}h"
        print(f"   First memory -> first execution: {speed}")
    else:
        print("   Onboarding time: not measurable (missing data)")
    print(f"   Config entries: {zc['config_entries']}  |  Setup steps: {zc['setup_steps_defined']}")

    print("\n" + "=" * 60 + "\n")
