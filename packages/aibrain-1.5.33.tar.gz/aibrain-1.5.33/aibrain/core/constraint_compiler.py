"""
constraint_compiler.py — Load HARD RULEs as session-start invariants.

Companion to enforcement.py. On session start:
  1. Loads all active HARD RULEs (builtin + DB + .md files)
  2. Prints a summary: N rules active, M enforcement points
  3. Validates wiring: checks for orphan rules (rules whose check_fn has no
     registered checker) and enforcement points with no rules
  4. Wired into `aibrain doctor` as a health check

Usage:
    from aibrain.core.constraint_compiler import compile_constraints, validate_wiring

    report = compile_constraints()
    print(report.summary)

    issues = validate_wiring()
    for issue in issues:
        print(f"  {issue.severity}: {issue.message}")
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from aibrain.core.enforcement import (
    BUILTIN_RULES,
    CHECKER_REGISTRY,
    ENFORCEMENT_POINTS,
    HardRule,
    load_rules,
)

log = logging.getLogger("aibrain.constraint_compiler")


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

@dataclass
class WiringIssue:
    """A problem found during wiring validation."""
    severity: str           # "error" or "warning"
    issue_type: str         # "orphan_rule", "missing_checker", "uncovered_point", "duplicate"
    message: str
    rule_id: str = ""
    enforcement_point: str = ""


@dataclass
class ConstraintReport:
    """Result of compiling constraints."""
    rules: list[HardRule]
    rule_count: int
    enforcement_point_count: int
    points_with_rules: dict[str, int]     # {point: count of rules}
    source_breakdown: dict[str, int]      # {source: count}
    severity_breakdown: dict[str, int]    # {severity: count}
    issues: list[WiringIssue]
    summary: str

    @property
    def is_healthy(self) -> bool:
        return not any(i.severity == "error" for i in self.issues)


# ---------------------------------------------------------------------------
# Core compilation
# ---------------------------------------------------------------------------

def compile_constraints(
    db_path: Optional[Path] = None,
    memory_dir: Optional[Path] = None,
    force_reload: bool = True,
) -> ConstraintReport:
    """
    Load all HARD RULEs and produce a constraint report.

    This is the session-start entry point: loads rules, validates wiring,
    and returns a structured report.
    """
    rules = load_rules(db_path=db_path, memory_dir=memory_dir, force_reload=force_reload)

    # Count rules per enforcement point
    points_with_rules: dict[str, int] = {}
    for rule in rules:
        for ep in rule.enforcement_points:
            points_with_rules[ep] = points_with_rules.get(ep, 0) + 1

    # Source breakdown
    source_breakdown: dict[str, int] = {}
    for rule in rules:
        source_breakdown[rule.source] = source_breakdown.get(rule.source, 0) + 1

    # Severity breakdown
    severity_breakdown: dict[str, int] = {}
    for rule in rules:
        severity_breakdown[rule.severity] = severity_breakdown.get(rule.severity, 0) + 1

    # Validate wiring
    issues = validate_wiring(rules)

    # Build summary
    active_points = len(points_with_rules)
    total_point_rules = sum(points_with_rules.values())
    summary = (
        f"{len(rules)} rules active, "
        f"{active_points} enforcement points covered, "
        f"{total_point_rules} enforcement bindings"
    )

    if issues:
        error_count = sum(1 for i in issues if i.severity == "error")
        warning_count = sum(1 for i in issues if i.severity == "warning")
        parts = []
        if error_count:
            parts.append(f"{error_count} error(s)")
        if warning_count:
            parts.append(f"{warning_count} warning(s)")
        summary += f" — {', '.join(parts)}"

    report = ConstraintReport(
        rules=rules,
        rule_count=len(rules),
        enforcement_point_count=active_points,
        points_with_rules=points_with_rules,
        source_breakdown=source_breakdown,
        severity_breakdown=severity_breakdown,
        issues=issues,
        summary=summary,
    )

    log.info("Constraint compiler: %s", summary)
    return report


# ---------------------------------------------------------------------------
# Wiring validation
# ---------------------------------------------------------------------------

def validate_wiring(rules: Optional[list[HardRule]] = None) -> list[WiringIssue]:
    """
    Validate that the enforcement system is wired correctly.

    Checks:
      1. No orphan rules (rules with check_fn not in CHECKER_REGISTRY)
      2. No enforcement points with zero rules
      3. All builtin rules are present in the loaded set
      4. No duplicate rule_ids
    """
    if rules is None:
        rules = load_rules()

    issues: list[WiringIssue] = []

    # Check 1: Orphan rules — check_fn not in registry
    for rule in rules:
        if rule.check_fn not in CHECKER_REGISTRY:
            issues.append(WiringIssue(
                severity="error",
                issue_type="orphan_rule",
                message=f"Rule '{rule.rule_id}' references checker '{rule.check_fn}' which is not registered",
                rule_id=rule.rule_id,
            ))

    # Check 2: Enforcement points with no rules
    covered_points = set()
    for rule in rules:
        covered_points.update(rule.enforcement_points)

    for ep in ENFORCEMENT_POINTS:
        if ep not in covered_points:
            issues.append(WiringIssue(
                severity="warning",
                issue_type="uncovered_point",
                message=f"Enforcement point '{ep}' has no rules assigned",
                enforcement_point=ep,
            ))

    # Check 3: All builtins present
    loaded_ids = {r.rule_id for r in rules}
    for builtin in BUILTIN_RULES:
        if builtin.rule_id not in loaded_ids:
            issues.append(WiringIssue(
                severity="error",
                issue_type="missing_builtin",
                message=f"Builtin rule '{builtin.rule_id}' not found in loaded rules",
                rule_id=builtin.rule_id,
            ))

    # Check 4: Duplicate rule_ids
    seen_ids: dict[str, int] = {}
    for rule in rules:
        seen_ids[rule.rule_id] = seen_ids.get(rule.rule_id, 0) + 1
    for rule_id, count in seen_ids.items():
        if count > 1:
            issues.append(WiringIssue(
                severity="warning",
                issue_type="duplicate",
                message=f"Rule ID '{rule_id}' appears {count} times",
                rule_id=rule_id,
            ))

    # Check 5: Invalid enforcement points on rules
    for rule in rules:
        for ep in rule.enforcement_points:
            if ep not in ENFORCEMENT_POINTS:
                issues.append(WiringIssue(
                    severity="error",
                    issue_type="invalid_point",
                    message=f"Rule '{rule.rule_id}' references invalid enforcement point '{ep}'",
                    rule_id=rule.rule_id,
                    enforcement_point=ep,
                ))

    return issues


# ---------------------------------------------------------------------------
# Doctor check — integration point for `aibrain doctor`
# ---------------------------------------------------------------------------

def doctor_check(
    db_path: Optional[Path] = None,
    memory_dir: Optional[Path] = None,
    verbose: bool = True,
) -> bool:
    """
    Run constraint compiler as a doctor check.

    Prints results and returns True if healthy, False if errors found.
    Used by `aibrain doctor`.
    """
    if verbose:
        print("\nChecking enforcement constraints...")

    try:
        report = compile_constraints(db_path=db_path, memory_dir=memory_dir)
    except Exception as e:
        if verbose:
            print(f"  ERROR  Failed to compile constraints: {e}")
        return False

    if verbose:
        print(f"  {report.summary}")

        # Show source breakdown
        for source, count in sorted(report.source_breakdown.items()):
            print(f"    {source}: {count} rule(s)")

        # Show enforcement point coverage
        for ep in sorted(ENFORCEMENT_POINTS):
            count = report.points_with_rules.get(ep, 0)
            status = "OK" if count > 0 else "UNCOVERED"
            print(f"    {ep}: {count} rule(s)  [{status}]")

        # Show issues
        if report.issues:
            for issue in report.issues:
                tag = "ERROR" if issue.severity == "error" else "WARNING"
                print(f"  {tag}  {issue.message}")
        else:
            print("  All constraints wired correctly.")

    return report.is_healthy


# ---------------------------------------------------------------------------
# Session-start printer
# ---------------------------------------------------------------------------

def print_session_summary(
    db_path: Optional[Path] = None,
    memory_dir: Optional[Path] = None,
) -> ConstraintReport:
    """
    Print a compact session-start summary of active constraints.

    Returns the full report for programmatic use.
    """
    report = compile_constraints(db_path=db_path, memory_dir=memory_dir)

    print(f"Enforcement: {report.summary}")

    if not report.is_healthy:
        for issue in report.issues:
            if issue.severity == "error":
                print(f"  ERROR: {issue.message}")

    return report
