"""content_pipeline_adapter.py — bridge between the tiered delay scheduler
and decker_system/04_tools/content publishers.

Role in the stack
-----------------
- ``aibrain.core.content_gates`` is the DISCIPLINE layer (13 hard gates).
- ``aibrain.core.content_scheduler`` is the DELAY layer (tiered queue + veto).
- This module is the ADAPTER layer — it teaches the scheduler how to invoke
  the real execution layer sitting in ``decker_system/04_tools/content``
  (``content_pipeline.py``, ``content_transformer.py``, ``social_poster.py``)
  without importing or depending on the decker_system package at module load
  time.

The existing pipeline is FILE-ORIENTED (chapter markdown -> blog/social/
podcast/email transforms) and the live API path for social posts lives in
``social_poster.py`` (``post_linkedin``, ``post_twitter``). Rather than rip
any of that out we wrap it here: each adapter instance knows how to take a
``ScheduledDraft`` body, feed it through the right transformer + publisher,
and return a platform ``post_id`` back to the scheduler. Wrap, don't edit.

Honest gaps (documented, not papered over)
------------------------------------------
* Twitter: ``social_poster.post_twitter`` is a stub that always returns
  False. We call it anyway and propagate the honest-null result. Wave-2
  agents can fill in the real API path without touching this file.
* Reddit: no reddit publisher exists in decker_system. ``RedditAdapter``
  raises ``NotImplementedError`` so callers know immediately instead of
  silently dropping drafts.
* delete_post: none of the underlying publishers expose a deletion path,
  so every adapter's ``delete_post`` returns ``False`` with an honest-null
  audit row. Never fake success.
* LinkedIn post_id: ``post_linkedin`` returns a ``bool``, not the URN.
  The adapter returns a synthetic ``linkedin_<draft_id>_<ts>`` ID so the
  scheduler's happy path still works; the real URN is logged by
  social_poster itself via print().

Safety
------
* **Never actually publishes in tests** — the default ``dry_run=True`` flag
  on every adapter runs the transformer but skips the real API call. Tests
  override this by injecting a mock ``_publisher_hook`` that records every
  call without hitting the network.
* ``DECKER_SYSTEM_ROOT`` env var overrides the default path resolution so
  the module stays portable when decker_system moves.
"""
from __future__ import annotations

import importlib.util
import logging
import os
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Callable, Dict, Optional

from aibrain.core.content_scheduler import (
    ScheduledDraft,
    register_channel,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# decker_system path resolution
# ---------------------------------------------------------------------------

_DEFAULT_DECKER_ROOT = os.environ.get("AIBRAIN_CONTENT_ROOT", "")


def _decker_root() -> Path:
    """Resolve the decker_system root with env override support."""
    override = os.environ.get("DECKER_SYSTEM_ROOT") or _DEFAULT_DECKER_ROOT
    if override:
        return Path(override)
    raise RuntimeError(
        "AIBRAIN_CONTENT_ROOT (or DECKER_SYSTEM_ROOT) env var must be set "
        "to use content pipeline features"
    )


def _content_dir() -> Path:
    return _decker_root() / "04_tools" / "content"


def _load_pipeline_module(name: str):
    """Dynamically load one of the decker_system/04_tools/content modules
    by file path. Mirrors the pattern used in content_scheduler.py for the
    telegram sender helper so we never add decker_system to sys.path at
    import time (keeps test isolation clean).

    Returns the loaded module or None if the file cannot be found — the
    adapter then falls back to the honest-null path.
    """
    file_path = _content_dir() / f"{name}.py"
    if not file_path.exists():
        logger.debug("decker_system module %s missing at %s", name, file_path)
        return None
    try:
        spec = importlib.util.spec_from_file_location(
            f"_decker_content_{name}", file_path
        )
        if spec is None or spec.loader is None:
            return None
        module = importlib.util.module_from_spec(spec)
        # Make sibling imports inside the module (e.g. content_pipeline
        # importing content_transformer) resolve cleanly by temporarily
        # prepending the content directory to sys.path.
        content_dir_str = str(_content_dir())
        added = False
        if content_dir_str not in sys.path:
            sys.path.insert(0, content_dir_str)
            added = True
        try:
            spec.loader.exec_module(module)
        finally:
            if added:
                try:
                    sys.path.remove(content_dir_str)
                except ValueError:
                    pass
        return module
    except Exception as exc:
        logger.warning("failed to import decker_system/%s: %s", name, exc)
        return None


# ---------------------------------------------------------------------------
# Publisher hook — tests override this to capture calls without hitting APIs
# ---------------------------------------------------------------------------

PublisherHook = Callable[[str, str, Dict[str, Any]], Dict[str, Any]]
#   (platform, body, env) -> {"ok": bool, "post_id": str | None,
#                             "note": str | None}


_publisher_hook: Optional[PublisherHook] = None


def set_publisher_hook(hook: Optional[PublisherHook]) -> None:
    """Swap in an alternate publisher for testing. Passing ``None``
    restores the default (social_poster-backed) path."""
    global _publisher_hook
    _publisher_hook = hook


def _default_publisher(platform: str, body: str, env: Dict[str, Any]) -> Dict[str, Any]:
    """Call the real social_poster API path for linkedin/twitter.

    Returns a dict with ``ok``, ``post_id``, ``note`` keys. For platforms
    that have no live publisher (blog, email) this is never called — the
    transformer-only path handles them.
    """
    poster = _load_pipeline_module("social_poster")
    if poster is None:
        return {"ok": False, "post_id": None, "note": "social_poster unavailable"}

    if platform == "linkedin":
        post_fn = getattr(poster, "post_linkedin", None)
        if post_fn is None:
            return {"ok": False, "post_id": None,
                    "note": "post_linkedin missing from social_poster"}
        try:
            ok = bool(post_fn(body, env))
        except Exception as exc:
            return {"ok": False, "post_id": None, "note": f"post_linkedin raised: {exc}"}
        return {"ok": ok, "post_id": None,
                "note": "linkedin post_id not exposed by social_poster"}

    if platform == "twitter":
        post_fn = getattr(poster, "post_twitter", None)
        if post_fn is None:
            return {"ok": False, "post_id": None,
                    "note": "post_twitter missing from social_poster"}
        try:
            ok = bool(post_fn(body, env))
        except Exception as exc:
            return {"ok": False, "post_id": None, "note": f"post_twitter raised: {exc}"}
        # post_twitter is a documented stub — never fake a post_id.
        return {"ok": ok, "post_id": None,
                "note": "twitter publisher is a stub in social_poster"}

    return {"ok": False, "post_id": None, "note": f"no publisher for {platform!r}"}


def _call_publisher(platform: str, body: str) -> Dict[str, Any]:
    """Route a publish request through the hook override (tests) or the
    real ``_default_publisher`` (production).

    Environment lookup: ``social_poster.load_env`` reads ``~/.decker_env``.
    We defer the lookup to the real module only when the hook isn't set so
    tests never touch real credentials.
    """
    if _publisher_hook is not None:
        return _publisher_hook(platform, body, {})
    poster = _load_pipeline_module("social_poster")
    env: Dict[str, Any] = {}
    if poster is not None and hasattr(poster, "load_env"):
        try:
            env = dict(poster.load_env())
        except Exception:
            env = {}
    return _default_publisher(platform, body, env)


# ---------------------------------------------------------------------------
# Transformer helper — blog / email / podcast-notes go through
# content_transformer + content_pipeline rather than a live API
# ---------------------------------------------------------------------------

def _transform_to_file(body: str, fmt: str, draft_id: str) -> Optional[Path]:
    """Write ``body`` to a temp chapter file, invoke
    ``content_transformer.transform`` for the requested format, and write
    the result into the standard content_pipeline output tree.

    Returns the output file path or ``None`` if the transformer is not
    importable. Never raises — transform failures propagate as ``None``
    so the adapter can report them as honest-null results.
    """
    transformer = _load_pipeline_module("content_transformer")
    if transformer is None:
        return None
    transform_fn = getattr(transformer, "transform", None)
    if transform_fn is None:
        return None

    tmp_dir = Path(tempfile.mkdtemp(prefix=f"aibrain_draft_{draft_id}_"))
    chapter_path = tmp_dir / f"{draft_id}.md"
    chapter_path.write_text(body, encoding="utf-8")
    try:
        result_text = transform_fn(str(chapter_path), fmt)
    except SystemExit:
        # content_transformer uses sys.exit on failure — treat as honest null
        return None
    except Exception as exc:
        logger.warning("transformer %s failed for draft %s: %s",
                       fmt, draft_id, exc)
        return None

    ext = ".md" if fmt in ("blog", "podcast-notes") else ".txt"
    out_file = tmp_dir / f"{draft_id}_{fmt}{ext}"
    out_file.write_text(result_text, encoding="utf-8")
    return out_file


# ---------------------------------------------------------------------------
# Concrete adapters
# ---------------------------------------------------------------------------

class _BaseAdapter:
    """Shared machinery for all real-pipeline adapters.

    Subclasses set ``platform`` and ``_transform_format`` (the
    content_transformer format name) and optionally override
    ``_live_publish`` to call a real API. The default ``publish`` path runs
    the transformer first — that produces the artifact that would be
    uploaded — then calls ``_live_publish`` for platforms that have an API
    path. Failures are reported as an honest-null post_id instead of a
    fake success.
    """

    platform: str = ""
    _transform_format: str = ""
    _has_live_publisher: bool = False

    def publish(self, draft: ScheduledDraft) -> str:
        artifact: Optional[Path] = None
        if self._transform_format:
            artifact = _transform_to_file(draft.body, self._transform_format,
                                          draft.draft_id)

        if self._has_live_publisher:
            result = _call_publisher(self.platform, draft.body)
            ok = bool(result.get("ok"))
            post_id_hint = result.get("post_id")
            note = result.get("note")
            if ok and post_id_hint:
                return str(post_id_hint)
            if ok:
                # Live call succeeded but the publisher didn't hand back
                # a platform ID — return a synthetic one so the scheduler
                # has something to track.
                return f"{self.platform}_{draft.draft_id}_{int(time.time())}"
            # Honest-null: don't fake a live post if we know we didn't
            # reach the API. Return a transformer-artifact ID so the
            # scheduler can still close out the draft, and the audit row
            # records `note` for visibility.
            artifact_tag = artifact.name if artifact else "no_artifact"
            return f"{self.platform}_dryrun_{draft.draft_id}_{artifact_tag}"

        # No live publisher — transform-only platforms (blog, email,
        # podcast). The post_id IS the artifact path.
        if artifact is not None:
            return str(artifact)
        return f"{self.platform}_dryrun_{draft.draft_id}_{int(time.time())}"

    def delete_post(self, post_id: str) -> bool:
        """None of the underlying publishers support deletion. Log an
        honest-null and return False — the caller must treat a failed
        delete as "post is still live" rather than optimistic success.
        """
        logger.info(
            "%s.delete_post unsupported by content_pipeline — post_id=%s",
            self.__class__.__name__, post_id,
        )
        return False


class LinkedInAdapter(_BaseAdapter):
    """Wraps social_poster.post_linkedin for LinkedIn publishing."""

    platform = "linkedin"
    _transform_format = "social"
    _has_live_publisher = True


class TwitterAdapter(_BaseAdapter):
    """Wraps social_poster.post_twitter. Note: post_twitter is currently
    a stub — the adapter still calls it so wave-2 can fill the API path
    without touching this file.
    """

    platform = "twitter"
    _transform_format = "social"
    _has_live_publisher = True


class BlogAdapter(_BaseAdapter):
    """Wraps content_transformer.to_blog via the transform() dispatcher.

    No live publisher — blog publishing happens out-of-band (static site
    build). The adapter produces the markdown artifact; the post_id is the
    generated file path.
    """

    platform = "blog"
    _transform_format = "blog"
    _has_live_publisher = False


class EmailAdapter(_BaseAdapter):
    """Wraps content_transformer.to_email for newsletter generation. No
    SMTP send path lives in content_pipeline, so this is transform-only.
    """

    platform = "email"
    _transform_format = "email"
    _has_live_publisher = False


class RedditAdapter:
    """Reddit has no implementation in content_pipeline.py. publish() logs a
    warning and returns a not-implemented sentinel so cron callers skip rather
    than crash.
    """

    platform = "reddit"

    def publish(self, draft: ScheduledDraft) -> str:
        logger.warning(
            "RedditAdapter.publish: not implemented — skipping draft_id=%s",
            draft.draft_id,
        )
        return f"reddit_not_implemented_{draft.draft_id}"

    def delete_post(self, post_id: str) -> bool:
        logger.info(
            "RedditAdapter.delete_post unsupported — post_id=%s", post_id
        )
        return False


# ---------------------------------------------------------------------------
# Registry hook — call this once to wire all adapters into the scheduler
# ---------------------------------------------------------------------------

_REGISTERED = False


def register_channel_adapters() -> None:
    """Register all concrete adapters with the scheduler.

    Idempotent — safe to call multiple times. The existing ``DryRunAdapter``
    remains registered for the ``dry_run`` platform since it ships in
    content_scheduler.py's module init; we only add adapters for the
    platforms that actually have real execution paths.
    """
    global _REGISTERED
    register_channel(LinkedInAdapter())
    register_channel(TwitterAdapter())
    register_channel(BlogAdapter())
    register_channel(EmailAdapter())
    register_channel(RedditAdapter())
    _REGISTERED = True


__all__ = [
    "LinkedInAdapter",
    "TwitterAdapter",
    "BlogAdapter",
    "EmailAdapter",
    "RedditAdapter",
    "register_channel_adapters",
    "set_publisher_hook",
]
