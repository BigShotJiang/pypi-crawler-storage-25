"""usage_report.py — `aibrain usage` summary.

Reads execution_log and sums cost_cents_equivalent (list-rate token cost)
for the current calendar month. Gives Decker and end users visibility into
subscription utilization even when cost_cents_actual=0 on CLI-backed runs.

Honest-rubric contract:
  - Rows with cost_cents_equivalent IS NULL are EXCLUDED from the sum (never
    counted as 0). The row count in the "measured" tally is separate from
    the "unmeasured" tally so users see exactly what's being tracked.
  - Rows with cost_cents_actual IS NULL get the same split treatment.
"""
from __future__ import annotations

import sqlite3
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional


def _find_db() -> Optional[Path]:
    """Canonical DB path. Read-only — never creates the file."""
    try:
        from aibrain_db import AIBRAIN_ROOT
    except Exception:
        return None
    p = AIBRAIN_ROOT / "aibrain.db"
    return p if p.exists() else None


def _month_bounds(now: Optional[datetime] = None) -> tuple[str, str]:
    """Return (start_iso, end_iso) of the current calendar month.

    Inclusive-start, exclusive-end so the SQL WHERE clause can use >= and <.
    Uses ISO strings because execution_log.created_at is TIMESTAMP DEFAULT
    CURRENT_TIMESTAMP which sqlite stores as ISO text.
    """
    now = now or datetime.now()
    start = datetime(now.year, now.month, 1)
    if now.month == 12:
        end = datetime(now.year + 1, 1, 1)
    else:
        end = datetime(now.year, now.month + 1, 1)
    return start.strftime("%Y-%m-%d %H:%M:%S"), end.strftime("%Y-%m-%d %H:%M:%S")


def collect_usage(db_path: Optional[Path] = None) -> dict:
    """Aggregate current-month usage from execution_log.

    Returns a dict with these keys (all integers unless noted):
      total_rows                  — rows in execution_log for this month
      rows_with_equivalent        — rows where cost_cents_equivalent IS NOT NULL
      rows_with_actual            — rows where cost_cents_actual IS NOT NULL
      sum_cents_equivalent        — sum of cost_cents_equivalent this month
      sum_cents_actual            — sum of cost_cents_actual this month
      per_model                   — list of dicts: {model, rows, sum_equivalent, sum_actual}
      month                       — "YYYY-MM" string for display
      rows_unmeasured_equivalent  — rows where equivalent IS NULL (honest-rubric)

    When the DB does not exist, returns {"error": "no_db"}.
    When the schema is pre-migration (no cost_cents_equivalent column), returns
    {"error": "schema_old", "hint": "run a task under the harness to auto-migrate"}.
    """
    p = db_path or _find_db()
    if p is None:
        return {"error": "no_db"}

    try:
        db = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
    except sqlite3.OperationalError:
        return {"error": "no_db"}
    db.row_factory = sqlite3.Row
    try:
        # Check execution_log exists
        has_log = db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='execution_log'"
        ).fetchone()
        if not has_log:
            return {"error": "no_execution_log"}
        cols = {r[1] for r in db.execute("PRAGMA table_info(execution_log)").fetchall()}
        if "cost_cents_equivalent" not in cols:
            return {
                "error": "schema_old",
                "hint": "run any task through the harness once — it auto-migrates on write",
            }

        start_iso, end_iso = _month_bounds()
        month = datetime.now().strftime("%Y-%m")

        # Totals
        row = db.execute(
            """
            SELECT
              COUNT(*)                                                   AS total_rows,
              SUM(CASE WHEN cost_cents_equivalent IS NOT NULL THEN 1 ELSE 0 END) AS rows_eq,
              SUM(CASE WHEN cost_cents_actual IS NOT NULL THEN 1 ELSE 0 END)     AS rows_act,
              COALESCE(SUM(cost_cents_equivalent), 0)                    AS sum_eq,
              COALESCE(SUM(cost_cents_actual), 0)                        AS sum_act
            FROM execution_log
            WHERE created_at >= ? AND created_at < ?
            """,
            (start_iso, end_iso),
        ).fetchone()

        total_rows = row["total_rows"] or 0
        rows_eq = row["rows_eq"] or 0
        rows_act = row["rows_act"] or 0

        # Per-model breakdown
        per_model_rows = db.execute(
            """
            SELECT
              COALESCE(model_used, '(unknown)')                          AS model,
              COUNT(*)                                                   AS rows,
              COALESCE(SUM(cost_cents_equivalent), 0)                    AS sum_eq,
              COALESCE(SUM(cost_cents_actual), 0)                        AS sum_act
            FROM execution_log
            WHERE created_at >= ? AND created_at < ?
            GROUP BY model_used
            ORDER BY sum_eq DESC
            """,
            (start_iso, end_iso),
        ).fetchall()

        per_model = [
            {
                "model": r["model"],
                "rows": r["rows"],
                "sum_equivalent": r["sum_eq"] or 0,
                "sum_actual": r["sum_act"] or 0,
            }
            for r in per_model_rows
        ]

        return {
            "month": month,
            "total_rows": total_rows,
            "rows_with_equivalent": rows_eq,
            "rows_with_actual": rows_act,
            "rows_unmeasured_equivalent": total_rows - rows_eq,
            "sum_cents_equivalent": int(row["sum_eq"] or 0),
            "sum_cents_actual": int(row["sum_act"] or 0),
            "per_model": per_model,
        }
    finally:
        db.close()


def _fmt_dollars(cents: int) -> str:
    return f"${cents / 100:.2f}"


def print_usage() -> int:
    """CLI entry point for `aibrain usage`. Returns shell exit code."""
    data = collect_usage()

    if "error" in data:
        err = data["error"]
        if err == "no_db":
            print("aibrain usage: no brain DB found. Run `aibrain setup` first.")
            return 1
        if err == "no_execution_log":
            print("aibrain usage: execution_log table missing. No harnessed runs yet.")
            return 0
        if err == "schema_old":
            print("aibrain usage: execution_log schema is pre-migration.")
            print(f"  hint: {data.get('hint', '')}")
            return 0
        print(f"aibrain usage: error {err}")
        return 1

    print()
    print("=" * 60)
    print(f"  AIBrain usage — {data['month']}")
    print("=" * 60)
    print()
    print(f"  Harnessed runs this month:  {data['total_rows']}")
    print(f"    with token signal:        {data['rows_with_equivalent']}")
    print(f"    without token signal:     {data['rows_unmeasured_equivalent']}  (cost_cents_equivalent NULL)")
    print()
    print(f"  List-rate equivalent spend: {_fmt_dollars(data['sum_cents_equivalent'])}")
    print(f"  Real money spent (actual):  {_fmt_dollars(data['sum_cents_actual'])}")
    subscription_value = data["sum_cents_equivalent"] - data["sum_cents_actual"]
    if subscription_value > 0:
        print(f"  Subscription value burned:  {_fmt_dollars(subscription_value)}  "
              f"(what Pro/Max saved vs metered API)")
    print()

    if data["per_model"]:
        print("  Per-model breakdown:")
        print(f"    {'model':<40} {'runs':>6} {'equivalent':>14} {'actual':>12}")
        print(f"    {'-' * 40} {'-' * 6} {'-' * 14} {'-' * 12}")
        for m in data["per_model"]:
            name = (m["model"] or "(unknown)")[:40]
            print(
                f"    {name:<40} {m['rows']:>6} "
                f"{_fmt_dollars(m['sum_equivalent']):>14} "
                f"{_fmt_dollars(m['sum_actual']):>12}"
            )
        print()

    if data["rows_unmeasured_equivalent"] > 0:
        print(
            f"  Note: {data['rows_unmeasured_equivalent']} run(s) had no token signal "
            "(old runs or non-Claude models).\n"
            "        These are EXCLUDED from the equivalent total — honest-rubric, never faked."
        )
        print()

    return 0


if __name__ == "__main__":
    sys.exit(print_usage())
