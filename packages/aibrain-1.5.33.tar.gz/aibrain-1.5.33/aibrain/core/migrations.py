# Lightweight migration runner.
# Each migration is (version: int, name: str, sql: str).
# run_migrations(conn) applies any unapplied entries in order.
# Idempotent — safe to call multiple times.

import logging
log = logging.getLogger(__name__)

MIGRATIONS = [
    (1, "create_schema_migrations_table", """
        CREATE TABLE IF NOT EXISTS schema_migrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            version INTEGER UNIQUE NOT NULL,
            name TEXT NOT NULL,
            applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """),
    (2, "create_budget_policies", """
        CREATE TABLE IF NOT EXISTS budget_policies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scope_type TEXT NOT NULL DEFAULT 'global',
            scope_id TEXT NOT NULL DEFAULT '*',
            window TEXT NOT NULL DEFAULT 'month',
            limit_cents INTEGER NOT NULL,
            warn_percent INTEGER NOT NULL DEFAULT 80,
            hard_stop INTEGER NOT NULL DEFAULT 1,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """),
    (3, "create_budget_incidents", """
        CREATE TABLE IF NOT EXISTS budget_incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            policy_id INTEGER,
            actor TEXT,
            incident_type TEXT NOT NULL,
            spend_cents INTEGER,
            limit_cents INTEGER,
            message TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """),
    # 2026-04-19 — Karpathy loop infrastructure. Shadow mode logs each
    # production invocation that runs baseline + candidate in parallel so
    # promotion criteria (shadow_score > baseline) can be computed post-hoc.
    # Consumed by workflows/autoresearch_engine.py and any per-target wrapper.
    (4, "create_shadow_runs", """
        CREATE TABLE IF NOT EXISTS shadow_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id TEXT,
            target TEXT NOT NULL,
            candidate_id TEXT NOT NULL,
            baseline_output TEXT,
            candidate_output TEXT,
            baseline_score REAL,
            candidate_score REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """),
    (5, "create_shadow_runs_idx_target_candidate", """
        CREATE INDEX IF NOT EXISTS idx_shadow_runs_target_candidate
        ON shadow_runs(target, candidate_id)
    """),
    # 2026-04-19 — WTL (Wintermute Testing Loop) auto-loop terminal-state
    # machine + calibration discipline. Company task 2fw8UooTW2s v4.1
    # (Liaison PASS 0.89). Adds per-task review state tracking on
    # company_issues and three supporting tables: needs_decker_queue
    # (NEEDS-DECKER surfacing), second_liaison_spawn_queue (decoupled
    # dispatch for stuck-detector), liaison_reviews (calibration metrics).
    #
    # ALTERs are guarded against columns already added by earlier lazy
    # migrations in companies.py (review_required, review_pending) — each
    # new column here is unique.
    (6, "wtl_company_issues_add_review_round", """
        ALTER TABLE company_issues ADD COLUMN review_round INTEGER DEFAULT 0
    """),
    (7, "wtl_company_issues_add_stuck_pattern", """
        ALTER TABLE company_issues ADD COLUMN stuck_pattern INTEGER DEFAULT 0
    """),
    (8, "wtl_company_issues_add_reassignment_suggested", """
        ALTER TABLE company_issues ADD COLUMN reassignment_suggested INTEGER DEFAULT 0
    """),
    (9, "wtl_company_issues_add_auto_action", """
        ALTER TABLE company_issues ADD COLUMN auto_action TEXT
    """),
    (10, "wtl_company_issues_add_terminal_state", """
        ALTER TABLE company_issues ADD COLUMN terminal_state TEXT
    """),
    (11, "wtl_create_needs_decker_queue", """
        CREATE TABLE IF NOT EXISTS needs_decker_queue (
            task_id TEXT PRIMARY KEY,
            surfaced_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_telegram_send TIMESTAMP,
            last_email_send TIMESTAMP,
            last_banner_render TIMESTAMP,
            urgent_at TIMESTAMP,
            physical_fallback_at TIMESTAMP,
            decker_decision TEXT,
            decided_at TIMESTAMP,
            calibration_flag INTEGER DEFAULT 0,
            ambiguity_flag INTEGER DEFAULT 0
        )
    """),
    (12, "wtl_create_second_liaison_spawn_queue", """
        CREATE TABLE IF NOT EXISTS second_liaison_spawn_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id TEXT NOT NULL,
            first_verdict_run_id TEXT,
            first_majors_json TEXT,
            queued_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            dispatched_at TIMESTAMP,
            verdict_run_id TEXT
        )
    """),
    (13, "wtl_create_second_liaison_spawn_queue_idx_dispatched", """
        CREATE INDEX IF NOT EXISTS idx_second_liaison_spawn_queue_dispatched
        ON second_liaison_spawn_queue(dispatched_at)
    """),
    (14, "wtl_create_liaison_reviews", """
        CREATE TABLE IF NOT EXISTS liaison_reviews (
            review_id TEXT PRIMARY KEY,
            task_id TEXT NOT NULL,
            liaison_instance_id TEXT,
            verdict TEXT,
            score REAL,
            majors TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """),
    (15, "wtl_create_liaison_reviews_idx_task", """
        CREATE INDEX IF NOT EXISTS idx_liaison_reviews_task
        ON liaison_reviews(task_id)
    """),
    # 2026-04-19 — Caller-auth / source-tag on liaison verdicts.
    # Task sC9X5a7ytaY. Closes the author-self-reviews gaming class: a worker
    # could previously call record_liaison_verdict() themselves with verdict=PASS
    # and the gate would clear. Adding source column + gate filter means only
    # rows written by a legitimate Agent-based review (source='agent_review')
    # clear complete_task()'s Special Liaison gate.
    #
    # Enum values:
    #   'agent_review'   — real Special Liaison Agent verdict (gate-clearing)
    #   'pre_filter'     — review_task() regex pre-filter (audit only)
    #   'self_recorded'  — author-supplied verdict (audit only, never clears)
    #
    # Backfill: existing verdict rows get source='agent_review' (do NOT
    # retroactively invalidate existing PASS rows — per task constraints).
    (16, "add_execution_log_source_column", """
        ALTER TABLE execution_log ADD COLUMN source TEXT DEFAULT NULL
    """),
    (17, "backfill_execution_log_source_agent_review", """
        UPDATE execution_log
        SET source='agent_review'
        WHERE actor='special_liaison' AND verdict IS NOT NULL AND source IS NULL
    """),
    # 2026-04-21 — Persist work_output on company_issues so agent findings
    # survive context compaction. Previously update_task(work_output=...) silently
    # discarded the field (not in allowed set) and complete_task() never wrote it
    # to the DB. This migration adds the column to legacy DBs; aibrain_db.py
    # canonical CREATE already includes it for fresh installs (idempotent).
    (18, "company_issues_add_work_output", """
        ALTER TABLE company_issues ADD COLUMN work_output TEXT
    """),
]

import sqlite3 as _sqlite3


def _apply_one(conn, sql: str) -> str:
    """Execute one migration SQL statement with idempotent-skip semantics.

    Returns one of: "applied", "skipped_missing_table", "skipped_duplicate_column".

    Rationale (Pattern #11 — fix the holes, don't bail the water): ALTER TABLE
    migrations in this file (e.g. v6-v10 against ``company_issues``, v16 against
    ``execution_log``) assume the target table exists. The canonical CREATE for
    those tables lives in ``aibrain_db.py`` (production DB) or in per-test
    fixtures, NOT in this migration chain. When ``run_migrations()`` is invoked
    on a fresh DB that skipped the CREATE path (e.g. ``workflows/autoresearch_engine``
    calling ``_open_db()`` on a tmp test DB that only needs ``shadow_runs``),
    the ALTER fails with "no such table".

    Similarly, when a caller's canonical CREATE already includes a column that
    a later ALTER would also add, the ALTER fails with "duplicate column name".

    Both failures are semantically idempotent-skips: the migration's intent is
    "ensure column X exists on table Y". If Y doesn't exist here, the column
    isn't needed either. If X already exists, the goal is already satisfied.
    In both cases we record the version as applied so re-runs return 0 new
    applications (idempotency contract), and any caller that later CREATEs the
    table is responsible for including all columns (as ``aibrain_db.py`` does).
    """
    try:
        conn.execute(sql)
        return "applied"
    except _sqlite3.OperationalError as e:
        msg = str(e).lower()
        if "no such table" in msg:
            return "skipped_missing_table"
        if "duplicate column name" in msg:
            return "skipped_duplicate_column"
        if "no such column" in msg:
            # Backfill UPDATE on a column the canonical CREATE doesn't include
            # (e.g. v17 backfill of execution_log.source filters on verdict,
            # which is added lazily by companies.py on legacy DBs only). Fresh
            # DBs have nothing to backfill — treat as idempotent-skip.
            return "skipped_missing_column"
        raise


def run_migrations(conn) -> int:
    """Apply unapplied migrations. Returns count of migrations applied.

    Idempotent: a second call on the same DB returns 0. ALTER migrations whose
    target table is absent (caller never CREATEd it) or whose column already
    exists (caller's canonical CREATE already included it) are recorded as
    applied-with-skip — see ``_apply_one`` for the full contract.
    """
    # Bootstrap: ensure schema_migrations table exists first
    conn.execute(MIGRATIONS[0][2])
    conn.commit()

    applied = {row[0] for row in conn.execute("SELECT version FROM schema_migrations").fetchall()}
    count = 0
    for version, name, sql in MIGRATIONS:
        if version not in applied:
            status = _apply_one(conn, sql)
            conn.execute("INSERT INTO schema_migrations (version, name) VALUES (?, ?)", (version, name))
            conn.commit()
            if status == "applied":
                log.info("Applied migration %d: %s", version, name)
            else:
                log.info("Migration %d: %s — %s (recorded as applied)", version, name, status)
            count += 1
    return count
