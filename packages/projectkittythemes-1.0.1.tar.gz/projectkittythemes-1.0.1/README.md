# PROJECT KITTY THEMES

[![Themes](https://img.shields.io/badge/18-Themes-ff6b6b?style=flat-square)](themes)
[![Terminals](https://img.shields.io/badge/4-Terminals-4ecdc4?style=flat-square)]()
[![License](https://img.shields.io/badge/License-MIT-45b7d1?style=flat-square)](LICENSE)
[![PyPI](https://img.shields.io/badge/PyPI-1.0.0-4ecdc4?style=flat-square)](https://pypi.org/project/projectkittythemes/)

Beautiful color themes for your terminal. Transform your terminal from boring default colors to something you'll love.

![SAMPLE](https://github.com/roshhellwett/projectkittythemes/blob/dbaae069ba9f29a86b538aaa41c65d1d5fd56a68/sample/sample.png)

---

## Installation

### Quick Install (PyPI)

```bash
pip install projectkittythemes
```

### Interactive Menu Mode

```bash
python -m projectkittythemes start
```

This opens an interactive menu where you can:
- Browse & preview all themes with color samples
- Apply a theme directly or preview first
- Rollback to your default OS theme
- Update the package from PyPI

---

## Quick Commands

| Command | Description |
|---------|-------------|
| `projectkittythemes start` | Start interactive menu mode |
| `projectkittythemes list` | List all available themes |
| `projectkittythemes install <theme>` | Install a specific theme |
| `projectkittythemes browse` | Browse themes interactively |
| `projectkittythemes update` | Check for updates from PyPI |
| `projectkittythemes rollback` | Restore default terminal theme |
| `projectkittythemes --help` | Show all options |
| `projectkittythemes --version` | Show version info |

---

## Available Themes (18)

| Theme | Look | Best For |
|-------|------|----------|
| **Tokyo Night** | Blue & purple, modern | Late-night coding |
| **Catppuccin Mocha** | Purple & pink, cozy | Catppuccin fans |
| **Catppuccin Latte** | Light pastel | Daytime use |
| **Gruvbox Dark** | Warm browns, retro | Retro lovers |
| **Rosé Pine** | Soft pink & purple | Aesthetic setups |
| **Nord** | Cool blue, clean | Maximum readability |
| **Solarized Dark** | Classic, easy on eyes | Long reading sessions |
| **Dracula** | Purple & colorful | Vibrant coding |
| **One Dark Pro** | Atom-inspired purple | Atom fans |
| **Monokai Pro** | Classic editor colors | Professional look |
| **Night Owl** | Blue & orange night | VS Code fans |
| **Ayu Dark** | Clean orange & blue | Minimalist |
| **Ayu Light** | Soft pastel light | Daylight use |
| **Material Theme** | Material Design colors | Android fans |
| **Gruvbox Material** | Warm refined browns | Refined retro |
| **Nightball** | Deep blue tones | Night coding |
| **Iceberg** | Cool blue, deep ocean | Cool aesthetics |
| **Palenight** | Soft purple editor | Light purple |

---

## Supported Terminals

| Terminal | Windows | Linux | macOS |
|----------|---------|-------|-------|
| Windows Terminal | ✅ | - | - |
| Kitty | ✅ | ✅ | ✅ |
| Alacritty | ✅ | ✅ | ✅ |
| WezTerm | ✅ | ✅ | ✅ |

---

## How to Use

### Interactive Menu (Recommended)

```bash
python -m projectkittythemes start
```

1. Select **Browse & Preview Themes** to see all themes
2. Choose a theme number to preview colors
3. Press **Y** to confirm and apply, **N** to go back, **Q** to quit
4. Restart your terminal to see the changes

### Direct Install

```bash
# Install a theme by name
projectkittythemes install "Tokyo Night"

# Install by slug
projectkittythemes install tokyonight

# Install to specific terminal
projectkittythemes install tokyonight --terminal kitty
```

### Rollback

If something goes wrong, restore your default theme:

```bash
projectkittythemes rollback
```

---

## Need Help?

### "Theme not showing?"

1. Close and reopen your terminal completely
2. If using Windows Terminal: open a new tab
3. Still not working? Run `projectkittythemes rollback` to restore defaults

### "I don't know what terminal I use"

The app auto-detects your terminal. You can check manually:

- **Windows**: `echo $env:TERM_PROGRAM`
- **Linux/macOS**: `echo $TERM_PROGRAM`

---

## Troubleshooting

### "Command not found" or "Permission denied"

**Windows (PowerShell):**
```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

**Linux/macOS:**
```bash
chmod +x install.sh
```

### "pip not found"

Ensure Python and pip are properly installed:
```bash
python --version
pip --version
```

---

## Development

### Clone & Install locally

```bash
git clone https://github.com/zenithopensourceprojects/projectkittythemes.git
cd projectkittythemes
pip install -e .
```

### Build & Publish

```bash
python -m build
python -m twine upload dist/* -r pypi
```

---

## Credits

**Copyright © 2026 Zenith Open Source Projects**  
**Developer:** roshhellwett

---

## License

MIT License - See [LICENSE](LICENSE) for details.
