"""Characterization tests for .claude/hooks/permission_handler.py

既存実装の挙動を固定するテスト群（後付け characterization test）。

テストケース:
 load_rules:
  1. permission_rules.json が無い → DEFAULT_RULES
  2. permission_rules.json が壊れた JSON → DEFAULT_RULES（crash しない）
  3. permission_rules.json が正常 → そのまま読まれる

 _glob_to_regex:
  4. * を [^/]* に変換（パス境界を超えない）
  5. ** を .* に変換（パス境界を超える）
  6. * と ** の混在
  7. メタ文字（. ( 等）が re.escape でエスケープされる

 matches_pattern:
  8.  Bash（括弧なし）+ 任意コマンド → True
  9.  Bash(git *) + git status → True
  10. Bash(git *) + npm install → False
  11. Bash(git *) + Bash 以外のツール → False
  12. Write(.claude/**) + Write + .claude/foo/bar.md → True
  13. Write(.claude/**) + Write + /etc/passwd → False
  14. WebFetch(domain:github.com) + WebFetch + https://github.com/foo → True
  15. WebFetch(domain:github.com) + WebFetch + https://example.com/foo → False
  16. malformed パターン → False

 describe_tool:
  17. Bash + 短いコマンド → Bash(git status) 形式
  18. Bash + 60 文字超 → 60 文字 + ... で truncate
  19. Write + file_path → Write(<file_path>) 形式
  20. WebFetch + url → WebFetch(<url>) 形式
  21. その他ツール → <ToolName>(<str(tool_input)[:60]>) 形式

 main (subprocess):
  22. payload が壊れた JSON → exit 0、stdout 出力なし
  23. auto_allow にマッチ → JSON 出力が stdout に出る
  24. auto_allow にマッチしない → stdout 空
  25. notify_on_auto: false → マッチしても notify が呼ばれない（モック検証）
"""

from __future__ import annotations

import importlib.util
import io
import json
import re
import subprocess
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

WORKTREE_ROOT = Path(__file__).parents[2]
HOOK_PATH = WORKTREE_ROOT / ".claude" / "hooks" / "permission_handler.py"


def _load_module(monkeypatch: pytest.MonkeyPatch, rules_path: Path) -> types.ModuleType:
    """permission_handler.py をモジュールとしてロードし、RULES_PATH を差し替える。"""
    spec = importlib.util.spec_from_file_location("permission_handler", HOOK_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[attr-defined]
    monkeypatch.setattr(module, "RULES_PATH", str(rules_path))
    return module


def _run_main_in_process(module: types.ModuleType, payload: dict) -> str:
    """module.main() を呼び出し、stdout を文字列で返す。"""
    original_stdin = sys.stdin
    original_stdout = sys.stdout
    sys.stdin = io.StringIO(json.dumps(payload))
    sys.stdout = io.StringIO()
    try:
        module.main()
        return sys.stdout.getvalue()
    finally:
        sys.stdin = original_stdin
        sys.stdout = original_stdout


def _setup_tmp_hook(tmp_path: Path) -> tuple[Path, Path]:
    """tmp_path 配下に .claude/hooks/ 構造を作り、スクリプトをコピーして返す。
    returns: (hooks_dir, claude_dir)
    """
    claude_dir = tmp_path / ".claude"
    hooks_dir = claude_dir / "hooks"
    hooks_dir.mkdir(parents=True)
    tmp_script = hooks_dir / "permission_handler.py"
    tmp_script.write_text(HOOK_PATH.read_text(encoding="utf-8"), encoding="utf-8")
    return hooks_dir, claude_dir


def _run_main_subprocess(
    tmp_path: Path, payload: dict, rules: dict | None = None
) -> subprocess.CompletedProcess:
    """permission_handler.py を別プロセスで実行する。

    tmp_path 配下に .claude/hooks/permission_handler.py を配置し、
    スクリプトが RULES_PATH = .claude/permission_rules.json を参照する構造を作る。
    rules が None の場合、permission_rules.json を作成しない。
    """
    hooks_dir, claude_dir = _setup_tmp_hook(tmp_path)
    if rules is not None:
        rules_file = claude_dir / "permission_rules.json"
        rules_file.write_text(json.dumps(rules), encoding="utf-8")

    tmp_script = hooks_dir / "permission_handler.py"
    return subprocess.run(
        [sys.executable, str(tmp_script)],
        input=json.dumps(payload),
        capture_output=True,
        text=True,
        encoding="utf-8",
    )


# ---------------------------------------------------------------------------
# 1. load_rules: permission_rules.json が無い → DEFAULT_RULES
# ---------------------------------------------------------------------------


class TestLoadRulesFileNotFound:
    """load_rules: rules ファイルが存在しない場合は DEFAULT_RULES を返す。"""

    def test_returns_default_rules_when_file_absent(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """存在しないパスを RULES_PATH に設定すると DEFAULT_RULES が返る。"""
        nonexistent = tmp_path / "nonexistent" / "permission_rules.json"
        module = _load_module(monkeypatch, nonexistent)

        result = module.load_rules()

        assert result == module.DEFAULT_RULES, (
            f"期待 {module.DEFAULT_RULES!r}、実際 {result!r}"
        )


# ---------------------------------------------------------------------------
# 2. load_rules: 壊れた JSON → DEFAULT_RULES（crash しない）
# ---------------------------------------------------------------------------


class TestLoadRulesBrokenJson:
    """load_rules: 壊れた JSON のファイルでも DEFAULT_RULES を返してクラッシュしない。"""

    def test_returns_default_rules_on_json_decode_error(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """不正 JSON が書かれたファイルを読んでも例外を投げず DEFAULT_RULES を返す。"""
        broken_rules = tmp_path / "permission_rules.json"
        broken_rules.write_text("{this is not valid json}", encoding="utf-8")
        module = _load_module(monkeypatch, broken_rules)

        result = module.load_rules()

        assert result == module.DEFAULT_RULES, (
            f"期待 {module.DEFAULT_RULES!r}、実際 {result!r}"
        )


# ---------------------------------------------------------------------------
# 3. load_rules: 正常 JSON → そのまま読まれる
# ---------------------------------------------------------------------------


class TestLoadRulesValidJson:
    """load_rules: 正常な JSON ファイルはその内容を返す。"""

    def test_returns_parsed_content_when_valid_json(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """正常な permission_rules.json の内容がそのまま返される。"""
        expected = {"auto_allow": ["Bash(git *)", "Read(***)"], "notify_on_auto": False}
        rules_file = tmp_path / "permission_rules.json"
        rules_file.write_text(json.dumps(expected), encoding="utf-8")
        module = _load_module(monkeypatch, rules_file)

        result = module.load_rules()

        assert result == expected, f"期待 {expected!r}、実際 {result!r}"


# ---------------------------------------------------------------------------
# 4. _glob_to_regex: * を [^/]* に変換
# ---------------------------------------------------------------------------


class TestGlobToRegexSingleStar:
    """_glob_to_regex: * は [^/]* に変換される（パス境界を超えない）。"""

    def test_single_star_converted_to_non_slash_wildcard(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """git * の * が [^/]* に変換される。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")
        regex = module._glob_to_regex("git *")

        assert "[^/]*" in regex, f"[^/]* が含まれていない: {regex!r}"
        # パス境界を越えないことを確認: git status はマッチ、git a/b はしない
        assert re.fullmatch(regex, "git status") is not None
        assert re.fullmatch(regex, "git a/b") is None


# ---------------------------------------------------------------------------
# 5. _glob_to_regex: ** を .* に変換
# ---------------------------------------------------------------------------


class TestGlobToRegexDoubleStar:
    """_glob_to_regex: ** は .* に変換される（パス境界を超える）。"""

    def test_double_star_converted_to_dot_star(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """.claude/** の ** が .* に変換され、スラッシュを含むパスにもマッチする。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")
        regex = module._glob_to_regex(".claude/**")

        # パス境界を越えることを確認
        assert re.fullmatch(regex, ".claude/foo/bar.md") is not None, (
            f"'.claude/foo/bar.md' がマッチしない: regex={regex!r}"
        )
        assert re.fullmatch(regex, ".claude/") is not None, (
            f"'.claude/' がマッチしない: regex={regex!r}"
        )


# ---------------------------------------------------------------------------
# 6. _glob_to_regex: * と ** の混在
# ---------------------------------------------------------------------------


class TestGlobToRegexMixedStars:
    """_glob_to_regex: * と ** が混在するパターンを正しく変換する。"""

    def test_mixed_star_patterns(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """foo/*/bar/** のような混在パターンを正しく変換する。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")
        regex = module._glob_to_regex("foo/*/bar/**")

        # foo/baz/bar/a/b/c.txt はマッチする
        assert re.fullmatch(regex, "foo/baz/bar/a/b/c.txt") is not None, (
            f"'foo/baz/bar/a/b/c.txt' がマッチしない: regex={regex!r}"
        )
        # foo/a/b/bar/c.txt は foo/ * が a/b を含むのでマッチしない（* はスラッシュを超えない）
        assert re.fullmatch(regex, "foo/a/b/bar/c.txt") is None, (
            f"'foo/a/b/bar/c.txt' が誤ってマッチした: regex={regex!r}"
        )


# ---------------------------------------------------------------------------
# 7. _glob_to_regex: メタ文字が re.escape でエスケープされる
# ---------------------------------------------------------------------------


class TestGlobToRegexMetaCharsEscaped:
    """_glob_to_regex: . ( ) 等のメタ文字が re.escape でエスケープされる。"""

    def test_dot_is_escaped(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """foo.bar パターンの . がリテラルドットとして扱われる。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")
        regex = module._glob_to_regex("foo.bar")

        # foo.bar はマッチ、fooXbar はマッチしない（. はリテラル）
        assert re.fullmatch(regex, "foo.bar") is not None
        assert re.fullmatch(regex, "fooXbar") is None, (
            f"'fooXbar' が誤ってマッチした（. が未エスケープ）: regex={regex!r}"
        )

    def test_parentheses_are_escaped(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """( ) が正規表現のグループ記号ではなくリテラルとして扱われる。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")
        regex = module._glob_to_regex("foo(bar)")

        assert re.fullmatch(regex, "foo(bar)") is not None
        # "foobar" は ( ) が省略されているのでマッチしない
        assert re.fullmatch(regex, "foobar") is None


# ---------------------------------------------------------------------------
# 8. matches_pattern: Bash（括弧なし）+ 任意コマンド → True
# ---------------------------------------------------------------------------


class TestMatchesPatternBashNoArg:
    """matches_pattern: Bash パターン（括弧なし）は任意の Bash コマンドにマッチする。"""

    def test_bash_no_arg_matches_any_command(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Bash パターン（引数なし）は tool_name == Bash であれば常に True。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        assert module.matches_pattern("Bash", {"command": "git status"}, "Bash") is True
        assert module.matches_pattern("Bash", {"command": "rm -rf /"}, "Bash") is True
        assert module.matches_pattern("Bash", {}, "Bash") is True


# ---------------------------------------------------------------------------
# 9. matches_pattern: Bash(git *) + git status → True
# ---------------------------------------------------------------------------


class TestMatchesPatternBashGitWildcard:
    """matches_pattern: Bash(git *) は git で始まるコマンドにマッチする。"""

    def test_git_status_matches_git_wildcard(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """git status は Bash(git *) パターンにマッチする。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        result = module.matches_pattern("Bash", {"command": "git status"}, "Bash(git *)")

        assert result is True, "git status が Bash(git *) にマッチしなかった"


# ---------------------------------------------------------------------------
# 10. matches_pattern: Bash(git *) + npm install → False
# ---------------------------------------------------------------------------


class TestMatchesPatternBashGitWildcardNoMatch:
    """matches_pattern: Bash(git *) は git 以外のコマンドにマッチしない。"""

    def test_npm_install_does_not_match_git_wildcard(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """npm install は Bash(git *) パターンにマッチしない。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        result = module.matches_pattern("Bash", {"command": "npm install"}, "Bash(git *)")

        assert result is False, "npm install が Bash(git *) に誤ってマッチした"


# ---------------------------------------------------------------------------
# 11. matches_pattern: Bash(git *) + Bash 以外のツール → False
# ---------------------------------------------------------------------------


class TestMatchesPatternToolNameMismatch:
    """matches_pattern: ツール名が一致しなければ False。"""

    def test_write_tool_does_not_match_bash_pattern(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Write ツールは Bash(git *) パターンにマッチしない。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        result = module.matches_pattern("Write", {"file_path": "git status"}, "Bash(git *)")

        assert result is False, "Write ツールが Bash パターンに誤ってマッチした"

    def test_read_tool_does_not_match_bash_pattern(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Read ツールは Bash(git *) パターンにマッチしない。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        result = module.matches_pattern("Read", {"file_path": "git status"}, "Bash(git *)")

        assert result is False, "Read ツールが Bash パターンに誤ってマッチした"


# ---------------------------------------------------------------------------
# 12. matches_pattern: Write(.claude/**) + Write + .claude/foo/bar.md → True
# ---------------------------------------------------------------------------


class TestMatchesPatternWriteClaudeDir:
    """matches_pattern: Write(.claude/**) は .claude 配下のパスにマッチする。"""

    def test_claude_subpath_matches_write_pattern(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """.claude/foo/bar.md は Write(.claude/**) パターンにマッチする。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        result = module.matches_pattern(
            "Write", {"file_path": ".claude/foo/bar.md"}, "Write(.claude/**)"
        )

        assert result is True, ".claude/foo/bar.md が Write(.claude/**) にマッチしなかった"


# ---------------------------------------------------------------------------
# 13. matches_pattern: Write(.claude/**) + Write + /etc/passwd → False
# ---------------------------------------------------------------------------


class TestMatchesPatternWriteOutsideClaudeDir:
    """matches_pattern: Write(.claude/**) は .claude 配下以外のパスにマッチしない。"""

    def test_etc_passwd_does_not_match_write_claude_pattern(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """/etc/passwd は Write(.claude/**) パターンにマッチしない。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        result = module.matches_pattern(
            "Write", {"file_path": "/etc/passwd"}, "Write(.claude/**)"
        )

        assert result is False, "/etc/passwd が Write(.claude/**) に誤ってマッチした"


# ---------------------------------------------------------------------------
# 14. matches_pattern: WebFetch(domain:github.com) + github.com URL → True
# ---------------------------------------------------------------------------


class TestMatchesPatternWebFetchDomainMatch:
    """matches_pattern: WebFetch(domain:github.com) は github.com を含む URL にマッチする。"""

    def test_github_url_matches_domain_pattern(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """https://github.com/foo は WebFetch(domain:github.com) にマッチする。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        result = module.matches_pattern(
            "WebFetch",
            {"url": "https://github.com/foo"},
            "WebFetch(domain:github.com)",
        )

        assert result is True, (
            "https://github.com/foo が WebFetch(domain:github.com) にマッチしなかった"
        )


# ---------------------------------------------------------------------------
# 15. matches_pattern: WebFetch(domain:github.com) + example.com → False
# ---------------------------------------------------------------------------


class TestMatchesPatternWebFetchDomainNoMatch:
    """matches_pattern: WebFetch(domain:github.com) は github.com 以外の URL にマッチしない。"""

    def test_example_url_does_not_match_github_domain_pattern(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """https://example.com/foo は WebFetch(domain:github.com) にマッチしない。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        result = module.matches_pattern(
            "WebFetch",
            {"url": "https://example.com/foo"},
            "WebFetch(domain:github.com)",
        )

        assert result is False, (
            "https://example.com/foo が WebFetch(domain:github.com) に誤ってマッチした"
        )


# ---------------------------------------------------------------------------
# 16. matches_pattern: malformed パターン → False
# ---------------------------------------------------------------------------


class TestMatchesPatternMalformed:
    """matches_pattern: パターン文字列が malformed の場合は False を返す。"""

    def test_malformed_pattern_returns_false(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """空文字列や括弧が合わないパターンは False を返す。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        # 空文字列
        assert module.matches_pattern("Bash", {"command": "git status"}, "") is False
        # 括弧が合わない（閉じ括弧が無い）
        assert module.matches_pattern("Bash", {"command": "git status"}, "Bash(git *") is False


# ---------------------------------------------------------------------------
# 17. describe_tool: Bash + 短いコマンド → Bash(git status) 形式
# ---------------------------------------------------------------------------


class TestDescribeToolBashShortCommand:
    """describe_tool: Bash と 60 文字以内のコマンドは Bash(<command>) 形式。"""

    def test_short_bash_command_formatted_correctly(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """git status は Bash(git status) 形式で返される。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        result = module.describe_tool("Bash", {"command": "git status"})

        assert result == "Bash(git status)", f"期待 'Bash(git status)'、実際 {result!r}"


# ---------------------------------------------------------------------------
# 18. describe_tool: Bash + 60 文字超 → 60 文字 + ... で truncate
# ---------------------------------------------------------------------------


class TestDescribeToolBashLongCommand:
    """describe_tool: Bash と 60 文字超のコマンドは 60 文字 + ... で truncate される。"""

    def test_long_bash_command_truncated(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """61 文字のコマンドは 60 文字 + ... で truncate される。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        long_cmd = "a" * 61
        result = module.describe_tool("Bash", {"command": long_cmd})

        expected = f"Bash({'a' * 60}...)"
        assert result == expected, f"期待 {expected!r}、実際 {result!r}"

    def test_exactly_60_chars_not_truncated(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """ちょうど 60 文字のコマンドは truncate されない。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        exact_cmd = "a" * 60
        result = module.describe_tool("Bash", {"command": exact_cmd})

        expected = f"Bash({'a' * 60})"
        assert result == expected, f"期待 {expected!r}、実際 {result!r}"


# ---------------------------------------------------------------------------
# 19. describe_tool: Write + file_path → Write(<file_path>) 形式
# ---------------------------------------------------------------------------


class TestDescribeToolWrite:
    """describe_tool: Write は Write(<file_path>) 形式で返される。"""

    def test_write_with_file_path(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Write と file_path は Write(<file_path>) 形式で返される。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        result = module.describe_tool("Write", {"file_path": "/path/to/file.py"})

        assert result == "Write(/path/to/file.py)", f"期待 'Write(/path/to/file.py)'、実際 {result!r}"


# ---------------------------------------------------------------------------
# 20. describe_tool: WebFetch + url → WebFetch(<url>) 形式
# ---------------------------------------------------------------------------


class TestDescribeToolWebFetch:
    """describe_tool: WebFetch は WebFetch(<url>) 形式で返される。"""

    def test_webfetch_with_url(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """WebFetch と url は WebFetch(<url>) 形式で返される。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        result = module.describe_tool("WebFetch", {"url": "https://github.com/foo"})

        assert result == "WebFetch(https://github.com/foo)", (
            f"期待 'WebFetch(https://github.com/foo)'、実際 {result!r}"
        )


# ---------------------------------------------------------------------------
# 21. describe_tool: その他ツール → <ToolName>(<str(tool_input)[:60]>) 形式
# ---------------------------------------------------------------------------


class TestDescribeToolOther:
    """describe_tool: その他ツールは <ToolName>(<str(tool_input)[:60]>) 形式。"""

    def test_other_tool_uses_str_of_input(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Glob ツールの場合は str(tool_input)[:60] が使われる。"""
        module = _load_module(monkeypatch, tmp_path / "rules.json")

        tool_input = {"pattern": "**/*.py"}
        result = module.describe_tool("Glob", tool_input)
        expected_content = str(tool_input)[:60]

        assert result == f"Glob({expected_content})", (
            f"期待 'Glob({expected_content})'、実際 {result!r}"
        )


# ---------------------------------------------------------------------------
# 22. main (subprocess): 壊れた JSON → exit 0、stdout 出力なし
# ---------------------------------------------------------------------------


class TestMainBrokenJsonInput:
    """main: stdin に壊れた JSON が来ても exit 0、stdout 出力なし。"""

    def test_broken_json_exits_0_with_no_stdout(self, tmp_path: Path) -> None:
        """不正な JSON を stdin に流すと exit code = 0 で stdout は空。"""
        hooks_dir, _ = _setup_tmp_hook(tmp_path)
        tmp_script = hooks_dir / "permission_handler.py"

        result = subprocess.run(
            [sys.executable, str(tmp_script)],
            input="{this is not valid json}",
            capture_output=True,
            text=True,
            encoding="utf-8",
        )

        assert result.returncode == 0, f"期待 exit 0、実際 {result.returncode}"
        assert result.stdout == "", f"期待 空の stdout、実際 {result.stdout!r}"


# ---------------------------------------------------------------------------
# 23. main (subprocess): auto_allow にマッチ → JSON 出力が stdout に出る
# ---------------------------------------------------------------------------


class TestMainAutoAllowMatched:
    """main: auto_allow にマッチするツールは JSON 出力が stdout に出る。"""

    def test_matched_payload_outputs_allow_json(self, tmp_path: Path) -> None:
        """auto_allow にマッチする payload を流すと allow JSON が stdout に出る。"""
        rules = {"auto_allow": ["Bash(git *)"], "notify_on_auto": False}
        payload = {"tool_name": "Bash", "tool_input": {"command": "git status"}}

        result = _run_main_subprocess(tmp_path, payload, rules=rules)

        assert result.returncode == 0, f"期待 exit 0、実際 {result.returncode}"
        assert result.stdout.strip() != "", "マッチ時に stdout が空だった"

        output = json.loads(result.stdout.strip())
        assert "hookSpecificOutput" in output, (
            f"hookSpecificOutput キーが無い: {output!r}"
        )
        assert output["hookSpecificOutput"]["hookEventName"] == "PermissionRequest"
        assert output["hookSpecificOutput"]["decision"]["behavior"] == "allow"


# ---------------------------------------------------------------------------
# 24. main (subprocess): auto_allow にマッチしない → stdout 空
# ---------------------------------------------------------------------------


class TestMainAutoAllowNotMatched:
    """main: auto_allow にマッチしないツールは stdout が空。"""

    def test_unmatched_payload_outputs_nothing(self, tmp_path: Path) -> None:
        """auto_allow にマッチしない payload を流すと stdout は空。"""
        rules = {"auto_allow": ["Bash(git *)"], "notify_on_auto": False}
        payload = {"tool_name": "Bash", "tool_input": {"command": "rm -rf /"}}

        result = _run_main_subprocess(tmp_path, payload, rules=rules)

        assert result.returncode == 0, f"期待 exit 0、実際 {result.returncode}"
        assert result.stdout.strip() == "", (
            f"マッチしない場合も stdout に出力があった: {result.stdout!r}"
        )


# ---------------------------------------------------------------------------
# 25. notify_on_auto: false → マッチしても notify が呼ばれない（モック検証）
# ---------------------------------------------------------------------------


class TestNotifyOnAutoFalse:
    """notify_on_auto が false の場合、マッチしても notify が呼ばれない。"""

    def test_notify_not_called_when_notify_on_auto_false(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """notify_on_auto: false の rules でマッチしても notify が呼ばれないこと。"""
        rules_file = tmp_path / "permission_rules.json"
        rules_file.write_text(
            json.dumps({"auto_allow": ["Bash(git *)"], "notify_on_auto": False}),
            encoding="utf-8",
        )
        module = _load_module(monkeypatch, rules_file)

        notify_mock = MagicMock()
        monkeypatch.setattr(module, "notify", notify_mock)

        payload = {"tool_name": "Bash", "tool_input": {"command": "git status"}}
        _run_main_in_process(module, payload)

        notify_mock.assert_not_called(), "notify_on_auto: false なのに notify が呼ばれた"

    def test_notify_called_when_notify_on_auto_true(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """notify_on_auto: true の rules でマッチしたとき notify が呼ばれること。"""
        rules_file = tmp_path / "permission_rules.json"
        rules_file.write_text(
            json.dumps({"auto_allow": ["Bash(git *)"], "notify_on_auto": True}),
            encoding="utf-8",
        )
        module = _load_module(monkeypatch, rules_file)

        notify_mock = MagicMock()
        monkeypatch.setattr(module, "notify", notify_mock)

        payload = {"tool_name": "Bash", "tool_input": {"command": "git status"}}
        _run_main_in_process(module, payload)

        notify_mock.assert_called_once()
        call_args = notify_mock.call_args[0][0]
        assert "自動承認" in call_args, f"notify の引数に '自動承認' が含まれない: {call_args!r}"
