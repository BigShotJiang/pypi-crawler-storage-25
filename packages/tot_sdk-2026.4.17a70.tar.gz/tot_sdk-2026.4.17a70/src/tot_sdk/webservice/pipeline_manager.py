from __future__ import annotations

from typing import IO

from sapiopylib.rest.User import SapioUser
from sapiopylib.rest.utils.singletons import SapioContextManager

from tot_sdk.webservice.pojos.pipeline import TriggerPipelineWithRecordsRequest, \
    TriggerPipelineWithRecordsResponse


class PipelineManager(SapioContextManager):
    """
    REST API service for managing pipeline instances.
    """
    def __init__(self, user: SapioUser):
        super().__init__(user)

    def add_step_output_from_file(self, pipeline_step_id: int, output_config_number: int,
                                  content_entry: IO, complete: bool | None = None) -> None:
        """
        Upload a file blob and let the server parse it into the step output for the given output configuration.

        :param pipeline_step_id: The instance ID of the step instance to add output to.
        :param output_config_number: The output configuration number.
        :param content_entry: The file blob to be parsed and added to the step.
        :param complete: Whether the step should be marked as complete.
        """
        sub_path = f"/pipeline/{pipeline_step_id}/addOutputFromFile/{output_config_number}"
        params = {}
        if complete is not None:
            params["complete"] = str(complete).lower()
        response = self.user.post_data_stream(sub_path, content_entry, params=params or None)
        self.user.raise_for_status(response)

    def add_step_output(self, pipeline_step_id: int, output_config_number: int,
                        content_entry: IO, complete: bool | None = None) -> None:
        """
        Add output data to a step instance with the specified output configuration number.
        The output data is provided as a stream, to be set on the step instance as a ContentEntry.

        :param pipeline_step_id: The instance ID of the step instance to add output to.
        :param output_config_number: The output configuration number.
        :param content_entry: The ContentEntry output data to be added to the step.
        :param complete: Whether the step should be marked as complete.
        """
        sub_path = f"/pipeline/{pipeline_step_id}/addOutput/{output_config_number}"
        params = {}
        if complete is not None:
            params["complete"] = str(complete).lower()
        response = self.user.post_data_stream(sub_path, content_entry, params=params or None)
        self.user.raise_for_status(response)

    def add_step_json_output(self, pipeline_step_id: int, output_config_number: int,
                             content_entry: IO, complete: bool | None = None) -> None:
        """
        Add JSON output data to a step instance with the specified output configuration number.
        The output data is provided as a stream and is expected to be in JSONL format.

        :param pipeline_step_id: The instance ID of the step instance to add output to.
        :param output_config_number: The output configuration number.
        :param content_entry: The output data to be added to the step, expected to be JSONL format.
        :param complete: Whether the step should be marked as complete.
        """
        sub_path = f"/pipeline/{pipeline_step_id}/addJsonOutput/{output_config_number}"
        params = {}
        if complete is not None:
            params["complete"] = str(complete).lower()
        response = self.user.post_data_stream(sub_path, content_entry, params=params or None)
        self.user.raise_for_status(response)

    def trigger_pipeline_with_records(self, request: TriggerPipelineWithRecordsRequest) \
            -> TriggerPipelineWithRecordsResponse:
        """
        Create or select records based on provided inputs, inject them into the single input step of the template,
        and start the pipeline run. The template must contain exactly one input step and that step must be a
        DataRecord input. This endpoint may return before downstream processing completes; use the returned
        pipeline_id to query status.

        :param request: The pipeline trigger request payload.
        :return: The trigger response containing the pipeline ID, step ID, and record IDs.
        """
        sub_path = "/pipeline/triggerPipelineWithRecords"
        response = self.user.post(sub_path, payload=request.to_json())
        self.user.raise_for_status(response)
        return TriggerPipelineWithRecordsResponse.from_json(response.json())
