from __future__ import annotations

import urllib.parse

from sapiopylib.rest.User import SapioUser
from sapiopylib.rest.utils.singletons import SapioContextManager

from tot_sdk.webservice.pojos.pipeline import PipelineTemplateInfo, PipelineTemplate, VersionId, ContentType


class PipelineTemplateManager(SapioContextManager):
    """
    REST API service for managing pipeline templates.
    """
    def __init__(self, user: SapioUser):
        super().__init__(user)

    def get_pipeline_template_infos(self, active_only: bool) -> list[PipelineTemplateInfo]:
        """
        Retrieve a list of pipeline template information objects.

        :param active_only: Whether to return only active pipeline templates.
        :return: A list of PipelineTemplateInfo objects.
        """
        sub_path = "/pipelinetemplate/infos"
        params = {"activeOnly": str(active_only).lower()}
        response = self.user.get(sub_path, params)
        self.user.raise_for_status(response)
        return [PipelineTemplateInfo.from_json(x) for x in response.json()]

    def get_pipeline_template(self, template_id: VersionId | str, version: int | None = None) -> PipelineTemplate:
        """
        Retrieve a complete pipeline template by its VersionId.

        :param template_id: The version of the pipeline template, as either a VersionId or a string for the UUID.
        :param version: The version number of the pipeline template. Optional if a VersionId is provided.
        :return: The full PipelineTemplate object.
        """
        if isinstance(template_id, VersionId):
            uuid: str = template_id.uuid
            version: int = template_id.version
            # TODO: get_pipeline_template doesn't work on drafts, since the version number is required.
            #  Potential platform change?
            if version is None:
                raise ValueError("Arg \"template_id\" of type VersionId must have a version number.")
        else:
            uuid: str = template_id
            if version is None:
                raise ValueError("Arg \"version\" must be provided if \"template_id\" is not of type VersionId.")
        sub_path = f"/pipelinetemplate/{urllib.parse.quote(uuid)}/{version}"
        response = self.user.get(sub_path)
        self.user.raise_for_status(response)
        return PipelineTemplate.from_json(response.json())

    def store_draft_pipeline_template(self, template: PipelineTemplate) -> PipelineTemplate:
        """
        Store a pipeline template as a draft.

        :param template: The pipeline template to store as a draft.
        :return: The stored PipelineTemplate as returned by the server.
        """
        sub_path = "/pipelinetemplate/draft"
        response = self.user.post(sub_path, payload=template.to_json())
        self.user.raise_for_status(response)
        return PipelineTemplate.from_json(response.json())

    def store_final_pipeline_template(self, template: PipelineTemplate) -> PipelineTemplate:
        """
        Store a pipeline template as a final/published version.

        :param template: The pipeline template to store as final.
        :return: The stored PipelineTemplate as returned by the server.
        """
        sub_path = "/pipelinetemplate/final"
        response = self.user.post(sub_path, payload=template.to_json())
        self.user.raise_for_status(response)
        return PipelineTemplate.from_json(response.json())

    def deactivate_pipeline_templates(self, version_ids: list[VersionId]) -> list[PipelineTemplate]:
        """
        Deactivate one or more pipeline templates.

        :param version_ids: List of VersionIds identifying the templates to deactivate.
        :return: The list of deactivated PipelineTemplate objects.
        """
        sub_path = "/pipelinetemplate/deactivate"
        payload = [vid.to_json() for vid in version_ids]
        response = self.user.post(sub_path, payload=payload)
        self.user.raise_for_status(response)
        return [PipelineTemplate.from_json(x) for x in response.json()]

    def activate_pipeline_templates(self, version_ids: list[VersionId]) -> list[PipelineTemplate]:
        """
        Activate one or more pipeline templates.

        :param version_ids: List of VersionIds identifying the templates to activate.
        :return: The list of activated PipelineTemplate objects.
        """
        sub_path = "/pipelinetemplate/activate"
        payload = [vid.to_json() for vid in version_ids]
        response = self.user.post(sub_path, payload=payload)
        self.user.raise_for_status(response)
        return [PipelineTemplate.from_json(x) for x in response.json()]

    def delete_pipeline_templates(self, version_ids: list[VersionId]) -> None:
        """
        Delete one or more pipeline templates.

        :param version_ids: List of VersionIds identifying the templates to delete.
        """
        sub_path = "/pipelinetemplate/delete"
        payload = [vid.to_json() for vid in version_ids]
        response = self.user.post(sub_path, payload=payload)
        self.user.raise_for_status(response)

    def get_content_types(self) -> list[ContentType]:
        """
        Retrieve available content types for pipeline steps.

        :return: A list of ContentType objects.
        """
        sub_path = "/pipelinetemplate/contenttypes"
        response = self.user.get(sub_path)
        self.user.raise_for_status(response)
        return [ContentType.from_json(x) for x in response.json()]

    def get_pipeline_category_library(self) -> list[str]:
        """
        Retrieve list of available pipeline categories.

        :return: A list of category name strings.
        """
        sub_path = "/pipelinetemplate/categories"
        response = self.user.get(sub_path)
        self.user.raise_for_status(response)
        return response.json()
