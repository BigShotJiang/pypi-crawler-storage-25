from __future__ import annotations

from typing import Any

from tot_sdk.webservice.pojos.pipeline import VersionId


class AgentCitation:
    """
    A citation attached to an agent configuration.
    """
    title: str | None
    url: str | None

    def __init__(self, title: str | None = None, url: str | None = None):
        self.title = title
        self.url = url

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> AgentCitation:
        return AgentCitation(
            title=json_dct.get("title"),
            url=json_dct.get("url"),
        )

    def to_json(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "url": self.url,
        }


class AgentConfigInfo:
    """
    Summary definition of an agent configuration.
    """
    id: VersionId
    import_id: str | None
    display_name: str | None
    agent_type: str | None
    script_hash: str | None
    agent_image: str | bytes | None
    description: str | None
    full_description: str | None
    category: str | None
    sub_category: str | None
    active: bool
    restricted: bool
    created_by: str | None
    date_created: int | None
    last_modified_by: str | None
    last_modified_date: int | None
    published_by: str | None
    published_date: int | None
    execution_url: str | None
    input_library_step_instance: int | None

    def __init__(self, version_id: VersionId, display_name: str | None = None):
        self.id = version_id
        self.import_id = None
        self.display_name = display_name
        self.agent_type = None
        self.script_hash = None
        self.agent_image = None
        self.description = None
        self.full_description = None
        self.category = None
        self.sub_category = None
        self.active = True
        self.restricted = False
        self.created_by = None
        self.date_created = None
        self.last_modified_by = None
        self.last_modified_date = None
        self.published_by = None
        self.published_date = None
        self.execution_url = None
        self.input_library_step_instance = None

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> AgentConfigInfo:
        id_value = json_dct.get("id")
        version_id = VersionId.from_json(id_value) if isinstance(id_value, str) else VersionId("", None)
        info = AgentConfigInfo(version_id, json_dct.get("displayName"))
        info.import_id = json_dct.get("importId")
        info.agent_type = json_dct.get("agentType")
        info.script_hash = json_dct.get("scriptHash")
        info.agent_image = json_dct.get("agentImage")
        info.description = json_dct.get("description")
        info.full_description = json_dct.get("fullDescription")
        info.category = json_dct.get("category")
        info.sub_category = json_dct.get("subCategory")
        info.active = json_dct.get("active", True)
        info.restricted = json_dct.get("restricted", False)
        info.created_by = json_dct.get("createdBy")
        info.date_created = json_dct.get("dateCreated")
        info.last_modified_by = json_dct.get("lastModifiedBy")
        info.last_modified_date = json_dct.get("lastModifiedDate")
        info.published_by = json_dct.get("publishedBy")
        info.published_date = json_dct.get("publishedDate")
        info.execution_url = json_dct.get("executionUrl")
        info.input_library_step_instance = json_dct.get("inputLibraryStepInstance")
        return info

    def to_json(self) -> dict[str, Any]:
        return {
            "id": self.id.to_json(),
            "importId": self.import_id,
            "displayName": self.display_name,
            "agentType": self.agent_type,
            "scriptHash": self.script_hash,
            "agentImage": self.agent_image,
            "description": self.description,
            "fullDescription": self.full_description,
            "category": self.category,
            "subCategory": self.sub_category,
            "active": self.active,
            "restricted": self.restricted,
            "createdBy": self.created_by,
            "dateCreated": self.date_created,
            "lastModifiedBy": self.last_modified_by,
            "lastModifiedDate": self.last_modified_date,
            "publishedBy": self.published_by,
            "publishedDate": self.published_date,
            "executionUrl": self.execution_url,
            "inputLibraryStepInstance": self.input_library_step_instance,
        }


class AgentConfig(AgentConfigInfo):
    """
    Complete agent configuration including scripts, IO definitions, and execution settings.
    """
    input_configs: list[dict[str, Any]]
    output_configs: list[dict[str, Any]]
    citations: list[AgentCitation]
    output_data_type_name: str | None
    script_language: str | None
    script: str | None
    async_step_completion: bool
    license_info: str | None
    review_on_instance_field_names: list[str]
    output_data_type_display_name: str | None
    output_data_type_icon: str | bytes | None
    output_data_type_field_definitions: list[dict[str, Any]]
    external_credentials: list[dict[str, Any]]
    agent_config_field_definitions: list[dict[str, Any]]

    def __init__(self, info: AgentConfigInfo):
        super().__init__(info.id, info.display_name)
        self.__dict__ = info.__dict__.copy()
        self.input_configs = []
        self.output_configs = []
        self.citations = []
        self.output_data_type_name = None
        self.script_language = None
        self.script = None
        self.async_step_completion = False
        self.license_info = None
        self.review_on_instance_field_names = []
        self.output_data_type_display_name = None
        self.output_data_type_icon = None
        self.output_data_type_field_definitions = []
        self.external_credentials = []
        self.agent_config_field_definitions = []

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> AgentConfig:
        config = AgentConfig(AgentConfigInfo.from_json(json_dct))
        config.input_configs = json_dct.get("inputConfigs") or []
        config.output_configs = json_dct.get("outputConfigs") or []
        config.citations = [AgentCitation.from_json(x) for x in json_dct.get("citations") or []]
        config.output_data_type_name = json_dct.get("outputDataTypeName")
        config.script_language = json_dct.get("scriptLanguage")
        config.script = json_dct.get("script")
        config.async_step_completion = json_dct.get("asyncStepCompletion", False)
        config.license_info = json_dct.get("licenseInfo")
        config.review_on_instance_field_names = json_dct.get("reviewOnInstanceFieldNames") or []
        config.output_data_type_display_name = json_dct.get("outputDataTypeDisplayName")
        config.output_data_type_icon = json_dct.get("outputDataTypeIcon")
        config.output_data_type_field_definitions = json_dct.get("outputDataTypeFieldDefinitions") or []
        config.external_credentials = json_dct.get("externalCredentials") or []
        config.agent_config_field_definitions = json_dct.get("agentConfigFieldDefinitions") or []
        return config

    def to_json(self) -> dict[str, Any]:
        result = super().to_json()
        result.update({
            "inputConfigs": self.input_configs,
            "outputConfigs": self.output_configs,
            "citations": [citation.to_json() for citation in self.citations],
            "outputDataTypeName": self.output_data_type_name,
            "scriptLanguage": self.script_language,
            "script": self.script,
            "asyncStepCompletion": self.async_step_completion,
            "licenseInfo": self.license_info,
            "reviewOnInstanceFieldNames": self.review_on_instance_field_names,
            "outputDataTypeDisplayName": self.output_data_type_display_name,
            "outputDataTypeIcon": self.output_data_type_icon,
            "outputDataTypeFieldDefinitions": self.output_data_type_field_definitions,
            "externalCredentials": self.external_credentials,
            "agentConfigFieldDefinitions": self.agent_config_field_definitions,
        })
        return result


class RetrievedFormPosition:
    column_order: int
    column_span: int

    def __init__(self, column_order: int = 0, column_span: int = 0):
        self.column_order = column_order
        self.column_span = column_span

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> RetrievedFormPosition:
        return RetrievedFormPosition(
            column_order=json_dct.get("columnOrder", 0),
            column_span=json_dct.get("columnSpan", 0),
        )

    def to_json(self) -> dict[str, Any]:
        return {
            "columnOrder": self.column_order,
            "columnSpan": self.column_span,
        }


class RetrievedCustomLayoutComponent:
    component_name: str | None
    display_name: str | None
    plugin_path: str | None
    attributes: dict[str, str]

    def __init__(self):
        self.component_name = None
        self.display_name = None
        self.plugin_path = None
        self.attributes = {}

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> RetrievedCustomLayoutComponent:
        component = RetrievedCustomLayoutComponent()
        component.component_name = json_dct.get("componentName")
        component.display_name = json_dct.get("displayName")
        component.plugin_path = json_dct.get("pluginPath")
        component.attributes = json_dct.get("attributes") or {}
        return component

    def to_json(self) -> dict[str, Any]:
        return {
            "componentName": self.component_name,
            "displayName": self.display_name,
            "pluginPath": self.plugin_path,
            "attributes": self.attributes,
        }


class RetrievedCustomLayoutTab:
    tab_name: str | None
    tab_display_name: str | None
    tab_order: int
    custom_components: list[RetrievedCustomLayoutComponent]

    def __init__(self):
        self.tab_name = None
        self.tab_display_name = None
        self.tab_order = 0
        self.custom_components = []

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> RetrievedCustomLayoutTab:
        tab = RetrievedCustomLayoutTab()
        tab.tab_name = json_dct.get("tabName")
        tab.tab_display_name = json_dct.get("tabDisplayName")
        tab.tab_order = json_dct.get("tabOrder", 0)
        tab.custom_components = [
            RetrievedCustomLayoutComponent.from_json(x)
            for x in json_dct.get("customComponents") or []
        ]
        return tab

    def to_json(self) -> dict[str, Any]:
        return {
            "tabName": self.tab_name,
            "tabDisplayName": self.tab_display_name,
            "tabOrder": self.tab_order,
            "customComponents": [component.to_json() for component in self.custom_components],
        }


class RetrievedDataTypeLayout:
    table_column_order: list[str]
    form_positions: dict[str, RetrievedFormPosition]
    form_tab_order: int | None
    custom_tabs: list[RetrievedCustomLayoutTab]

    def __init__(self):
        self.table_column_order = []
        self.form_positions = {}
        self.form_tab_order = None
        self.custom_tabs = []

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> RetrievedDataTypeLayout:
        layout = RetrievedDataTypeLayout()
        layout.table_column_order = json_dct.get("tableColumnOrder") or []
        layout.form_positions = {
            key: RetrievedFormPosition.from_json(value)
            for key, value in (json_dct.get("formPositions") or {}).items()
        }
        layout.form_tab_order = json_dct.get("formTabOrder")
        layout.custom_tabs = [RetrievedCustomLayoutTab.from_json(x) for x in json_dct.get("customTabs") or []]
        return layout

    def to_json(self) -> dict[str, Any]:
        return {
            "tableColumnOrder": self.table_column_order,
            "formPositions": {
                key: value.to_json() for key, value in self.form_positions.items()
            },
            "formTabOrder": self.form_tab_order,
            "customTabs": [tab.to_json() for tab in self.custom_tabs],
        }


class RetrievedAgentDataType:
    data_type_name: str | None
    display_name: str | None
    plural_display_name: str | None
    description: str | None
    tag: str | None
    icon: str | bytes | None
    icon_color: str | None
    is_high_volume: bool
    is_high_volume_on_save_enabled: bool
    record_image_assignable: bool
    is_attachment_data_type: bool
    child_data_types: list[str]
    parent_data_types: list[str]
    data_type_layout: RetrievedDataTypeLayout | None
    velox_field_definitions: list[dict[str, Any]]

    def __init__(self):
        self.data_type_name = None
        self.display_name = None
        self.plural_display_name = None
        self.description = None
        self.tag = None
        self.icon = None
        self.icon_color = None
        self.is_high_volume = False
        self.is_high_volume_on_save_enabled = False
        self.record_image_assignable = False
        self.is_attachment_data_type = False
        self.child_data_types = []
        self.parent_data_types = []
        self.data_type_layout = None
        self.velox_field_definitions = []

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> RetrievedAgentDataType:
        data_type = RetrievedAgentDataType()
        data_type.data_type_name = json_dct.get("dataTypeName")
        data_type.display_name = json_dct.get("displayName")
        data_type.plural_display_name = json_dct.get("pluralDisplayName")
        data_type.description = json_dct.get("description")
        data_type.tag = json_dct.get("tag")
        data_type.icon = json_dct.get("icon")
        data_type.icon_color = json_dct.get("iconColor")
        data_type.is_high_volume = json_dct.get("highVolume", json_dct.get("isHighVolume", False))
        data_type.is_high_volume_on_save_enabled = json_dct.get(
            "highVolumeOnSaveEnabled",
            json_dct.get("isHighVolumeOnSaveEnabled", False),
        )
        data_type.record_image_assignable = json_dct.get("recordImageAssignable", False)
        data_type.is_attachment_data_type = json_dct.get("attachmentDataType", json_dct.get("isAttachmentDataType", False))
        data_type.child_data_types = json_dct.get("childDataTypes") or []
        data_type.parent_data_types = json_dct.get("parentDataTypes") or []
        layout_json = json_dct.get("dataTypeLayout")
        if isinstance(layout_json, dict):
            data_type.data_type_layout = RetrievedDataTypeLayout.from_json(layout_json)
        data_type.velox_field_definitions = json_dct.get("veloxFieldDefinitions") or []
        return data_type

    def to_json(self) -> dict[str, Any]:
        return {
            "dataTypeName": self.data_type_name,
            "displayName": self.display_name,
            "pluralDisplayName": self.plural_display_name,
            "description": self.description,
            "tag": self.tag,
            "icon": self.icon,
            "iconColor": self.icon_color,
            "isHighVolume": self.is_high_volume,
            "isHighVolumeOnSaveEnabled": self.is_high_volume_on_save_enabled,
            "recordImageAssignable": self.record_image_assignable,
            "isAttachmentDataType": self.is_attachment_data_type,
            "childDataTypes": self.child_data_types,
            "parentDataTypes": self.parent_data_types,
            "dataTypeLayout": self.data_type_layout.to_json() if self.data_type_layout is not None else None,
            "veloxFieldDefinitions": self.velox_field_definitions,
        }


class RetrievedAgentConfigs:
    """
    Result of retrieving externally defined agent configurations.
    """
    agent_data_types: list[RetrievedAgentDataType]
    agent_configs: list[AgentConfig]

    def __init__(self):
        self.agent_data_types = []
        self.agent_configs = []

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> RetrievedAgentConfigs:
        configs = RetrievedAgentConfigs()
        configs.agent_data_types = [
            RetrievedAgentDataType.from_json(x) for x in json_dct.get("agentDataTypes") or []
        ]
        configs.agent_configs = [
            AgentConfig.from_json(x) for x in json_dct.get("agentConfigs") or []
        ]
        return configs

    def to_json(self) -> dict[str, Any]:
        return {
            "agentDataTypes": [data_type.to_json() for data_type in self.agent_data_types],
            "agentConfigs": [config.to_json() for config in self.agent_configs],
        }
