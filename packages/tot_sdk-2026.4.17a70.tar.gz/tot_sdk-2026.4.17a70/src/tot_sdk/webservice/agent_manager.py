from __future__ import annotations

import urllib.parse

from sapiopylib.rest.User import SapioUser
from sapiopylib.rest.utils.singletons import SapioContextManager

from tot_sdk.webservice.pojos.agent import AgentConfig, AgentConfigInfo, RetrievedAgentConfigs
from tot_sdk.webservice.pojos.pipeline import VersionId


class AgentManager(SapioContextManager):
    """
    REST API service for managing agent configurations.
    """
    def __init__(self, user: SapioUser):
        super().__init__(user)

    @staticmethod
    def _version_id_payload(version_ids: list[VersionId | str]) -> list[str]:
        return [version_id.to_json() if isinstance(version_id, VersionId) else version_id for version_id in version_ids]

    def get_agent_config_infos(self, active_only: bool) -> list[AgentConfigInfo]:
        """
        Retrieve a list of agent configuration information objects.

        :param active_only: Whether to return only active agent configs.
        :return: A list of AgentConfigInfo objects.
        """
        response = self.user.get("/agent/infos", {"activeOnly": str(active_only).lower()})
        self.user.raise_for_status(response)
        return [AgentConfigInfo.from_json(item) for item in response.json()]

    def get_agent_config(self, agent_id: VersionId | str, version: int | None = None) -> AgentConfig:
        """
        Retrieve a complete agent configuration by ID and version.

        :param agent_id: The versioned ID or raw UUID of the agent config.
        :param version: The version of the agent config if ``agent_id`` is not a VersionId.
        :return: The complete AgentConfig.
        """
        if isinstance(agent_id, VersionId):
            uuid = agent_id.uuid
            version = agent_id.version
            if version is None:
                raise ValueError("Arg \"agent_id\" of type VersionId must have a version number.")
        else:
            uuid = agent_id
            if version is None:
                raise ValueError("Arg \"version\" must be provided if \"agent_id\" is not of type VersionId.")

        sub_path = f"/agent/{urllib.parse.quote(uuid)}/{version}"
        response = self.user.get(sub_path)
        self.user.raise_for_status(response)
        return AgentConfig.from_json(response.json())

    def store_draft_agent_config(self, config: AgentConfig) -> AgentConfig:
        """
        Store an agent configuration as a draft.

        :param config: The agent config to store as a draft.
        :return: The stored AgentConfig as returned by the server.
        """
        response = self.user.post("/agent/draft", payload=config.to_json())
        self.user.raise_for_status(response)
        return AgentConfig.from_json(response.json())

    def store_final_agent_config(self, config: AgentConfig) -> AgentConfig:
        """
        Store an agent configuration as a final/published version.

        :param config: The agent config to store as final.
        :return: The stored AgentConfig as returned by the server.
        """
        response = self.user.post("/agent/final", payload=config.to_json())
        self.user.raise_for_status(response)
        return AgentConfig.from_json(response.json())

    def deactivate_agent_configs(self, version_ids: list[VersionId | str]) -> list[AgentConfig]:
        """
        Deactivate one or more agent configurations.

        :param version_ids: List of version IDs to deactivate.
        :return: The list of deactivated AgentConfig objects.
        """
        response = self.user.post("/agent/deactivate", payload=self._version_id_payload(version_ids))
        self.user.raise_for_status(response)
        return [AgentConfig.from_json(item) for item in response.json()]

    def activate_agent_configs(self, version_ids: list[VersionId | str]) -> list[AgentConfig]:
        """
        Activate one or more agent configurations.

        :param version_ids: List of version IDs to activate.
        :return: The list of activated AgentConfig objects.
        """
        response = self.user.post("/agent/activate", payload=self._version_id_payload(version_ids))
        self.user.raise_for_status(response)
        return [AgentConfig.from_json(item) for item in response.json()]

    def delete_agent_configs(self, version_ids: list[VersionId | str]) -> None:
        """
        Delete one or more agent configurations.

        :param version_ids: List of version IDs to delete.
        """
        response = self.user.post("/agent/delete", payload=self._version_id_payload(version_ids))
        self.user.raise_for_status(response)

    def get_agent_category_library(self) -> list[str]:
        """
        Retrieve the list of available agent categories.

        :return: A list of agent category strings.
        """
        response = self.user.get("/agent/categories")
        self.user.raise_for_status(response)
        return response.json()

    def retrieve_defined_agent_configs(self, url: str) -> RetrievedAgentConfigs:
        """
        Retrieve externally defined agent configurations from the provided URL.

        :param url: The URL to retrieve agent configs from.
        :return: The retrieved agent configs payload.
        """
        response = self.user.get("/agent/retrieve", {"url": url})
        self.user.raise_for_status(response)
        return RetrievedAgentConfigs.from_json(response.json())
