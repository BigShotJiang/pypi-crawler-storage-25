from sapiopylib.rest.pojo.DateRange import DateRange
from sapiopylib.rest.pojo.datatype.FieldDefinition import VeloxStringFieldDefinition, SapioStringFormat, \
    FieldValidator, VeloxAccessionFieldDefinition, VeloxBooleanFieldDefinition, VeloxDateFieldDefinition, \
    VeloxDateRangeFieldDefinition, VeloxDoubleFieldDefinition, VeloxEnumFieldDefinition, VeloxIntegerFieldDefinition, \
    VeloxLongFieldDefinition, VeloxPickListFieldDefinition, VeloxSelectionFieldDefinition, VeloxShortFieldDefinition, \
    SapioDoubleFormat, VeloxFileBlobFieldDefinition

from sapiopycommons.callbacks.field_builder import FieldBuilder, AnyFieldInfo
from sapiopycommons.general.aliases import FieldIdentifier, DataTypeIdentifier


# noinspection PyMethodOverriding
class AgentFieldBuilder(FieldBuilder):
    """
    A variant of FieldBuilder with adjusted default values better suited for agents.

    Compared to FieldBuilder, this class:
    - Defaults to non-editable fields (editable=False) when no abstract_info is provided.
    - Uses a higher default max_length for string fields (100_000 instead of 100).
    - Uses a higher default precision for double fields (3 instead of 1).
    - Moves the display_name parameter to be the second parameter (after field_name) for all field methods.
    """

    def __init__(self, data_type: DataTypeIdentifier = "Default"):
        super().__init__(data_type, default_editable=False)

    def accession_field(self, field_name: FieldIdentifier, display_name: str,
                        sequence_key: str, prefix: str | None = None, suffix: str | None = None,
                        number_of_digits: int = 8, starting_value: int = 1,
                        link_out: dict[str, str] | None = None, abstract_info: AnyFieldInfo | None = None, *,
                        data_type_name: DataTypeIdentifier | None = None) -> VeloxAccessionFieldDefinition:
        return super().accession_field(field_name, sequence_key, prefix=prefix, suffix=suffix,
                                       number_of_digits=number_of_digits, starting_value=starting_value,
                                       link_out=link_out, abstract_info=abstract_info,
                                       data_type_name=data_type_name, display_name=display_name)

    def boolean_field(self, field_name: FieldIdentifier, display_name: str,
                      default_value: bool | None = False,
                      abstract_info: AnyFieldInfo | None = None, *,
                      data_type_name: DataTypeIdentifier | None = None) -> VeloxBooleanFieldDefinition:
        return super().boolean_field(field_name, default_value=default_value,
                                     abstract_info=abstract_info,
                                     data_type_name=data_type_name, display_name=display_name)

    def date_field(self, field_name: FieldIdentifier, display_name: str,
                   default_value: int | None = None, date_time_format: str = "MMM dd, yyyy",
                   static_date: bool = False, abstract_info: AnyFieldInfo | None = None, *,
                   data_type_name: DataTypeIdentifier | None = None) -> VeloxDateFieldDefinition:
        return super().date_field(field_name, default_value=default_value,
                                  date_time_format=date_time_format, static_date=static_date,
                                  abstract_info=abstract_info,
                                  data_type_name=data_type_name, display_name=display_name)

    def date_range_field(self, field_name: FieldIdentifier, display_name: str,
                         default_value: str | DateRange | None = None,
                         date_time_format: str = "MMM dd, yyyy", static_date: bool = False,
                         abstract_info: AnyFieldInfo | None = None, *,
                         data_type_name: DataTypeIdentifier | None = None) -> VeloxDateRangeFieldDefinition:
        return super().date_range_field(field_name, default_value=default_value,
                                        date_time_format=date_time_format, static_date=static_date,
                                        abstract_info=abstract_info,
                                        data_type_name=data_type_name, display_name=display_name)

    def double_field(self, field_name: FieldIdentifier, display_name: str,
                     default_value: float | None = None,
                     min_value: float = -10.**120, max_value: float = 10.**120, precision: int = 3,
                     double_format: SapioDoubleFormat | None = None,
                     abstract_info: AnyFieldInfo | None = None, *,
                     data_type_name: DataTypeIdentifier | None = None) -> VeloxDoubleFieldDefinition:
        return super().double_field(field_name, default_value=default_value, min_value=min_value,
                                    max_value=max_value, precision=precision, double_format=double_format,
                                    abstract_info=abstract_info,
                                    data_type_name=data_type_name, display_name=display_name)

    def enum_field(self, field_name: FieldIdentifier, display_name: str,
                   options: list[str], default_value: int | None = None,
                   abstract_info: AnyFieldInfo | None = None, *,
                   data_type_name: DataTypeIdentifier | None = None) -> VeloxEnumFieldDefinition:
        return super().enum_field(field_name, options, default_value=default_value,
                                  abstract_info=abstract_info,
                                  data_type_name=data_type_name, display_name=display_name)

    def file_blob_field(self, field_name: FieldIdentifier, display_name: str,
                        abstract_info: AnyFieldInfo | None = None, *,
                        data_type_name: DataTypeIdentifier | None = None) -> VeloxFileBlobFieldDefinition:
        return super().file_blob_field(field_name, abstract_info,
                                       data_type_name=data_type_name, display_name=display_name)

    def int_field(self, field_name: FieldIdentifier, display_name: str,
                  default_value: int | None = None,
                  min_value: int = -2**31, max_value: int = 2**31 - 1, unique_value: bool = False,
                  abstract_info: AnyFieldInfo | None = None, *,
                  data_type_name: DataTypeIdentifier | None = None) -> VeloxIntegerFieldDefinition:
        return super().int_field(field_name, default_value=default_value, min_value=min_value,
                                 max_value=max_value, unique_value=unique_value,
                                 abstract_info=abstract_info,
                                 data_type_name=data_type_name, display_name=display_name)

    def long_field(self, field_name: FieldIdentifier, display_name: str,
                   default_value: int | None = None,
                   min_value: int = -2**63, max_value: int = 2**63 - 1, unique_value: bool = False,
                   abstract_info: AnyFieldInfo | None = None, *,
                   data_type_name: DataTypeIdentifier | None = None) -> VeloxLongFieldDefinition:
        return super().long_field(field_name, default_value=default_value, min_value=min_value,
                                  max_value=max_value, unique_value=unique_value,
                                  abstract_info=abstract_info,
                                  data_type_name=data_type_name, display_name=display_name)

    def pick_list_field(self, field_name: FieldIdentifier, display_name: str,
                        pick_list_name: str, default_value: str | None = None,
                        direct_edit: bool = False, abstract_info: AnyFieldInfo | None = None, *,
                        data_type_name: DataTypeIdentifier | None = None) -> VeloxPickListFieldDefinition:
        return super().pick_list_field(field_name, pick_list_name, default_value=default_value,
                                       direct_edit=direct_edit, abstract_info=abstract_info,
                                       data_type_name=data_type_name, display_name=display_name)

    def selection_list_field(self, field_name: FieldIdentifier, display_name: str,
                             default_value: str | None = None,
                             direct_edit: bool = False, multi_select: bool = False, unique_value: bool = False,
                             abstract_info: AnyFieldInfo | None = None, *, pick_list_name: str | None = None,
                             custom_report_name: str | None = None, plugin_name: str | None = None,
                             static_values: list[str] | None = None, user_list: bool = False,
                             user_group_list: bool = False, non_api_user_list: bool = False,
                             data_type_name: DataTypeIdentifier | None = None) -> VeloxSelectionFieldDefinition:
        return super().selection_list_field(field_name, default_value=default_value,
                                            direct_edit=direct_edit, multi_select=multi_select,
                                            unique_value=unique_value, abstract_info=abstract_info,
                                            pick_list_name=pick_list_name,
                                            custom_report_name=custom_report_name,
                                            plugin_name=plugin_name, static_values=static_values,
                                            user_list=user_list, user_group_list=user_group_list,
                                            non_api_user_list=non_api_user_list,
                                            data_type_name=data_type_name, display_name=display_name)

    def short_field(self, field_name: FieldIdentifier, display_name: str,
                    default_value: int | None = None,
                    min_value: int = -2**15, max_value: int = 2**15 - 1, unique_value: bool = False,
                    abstract_info: AnyFieldInfo | None = None, *,
                    data_type_name: DataTypeIdentifier | None = None) -> VeloxShortFieldDefinition:
        return super().short_field(field_name, default_value=default_value, min_value=min_value,
                                   max_value=max_value, unique_value=unique_value,
                                   abstract_info=abstract_info,
                                   data_type_name=data_type_name, display_name=display_name)

    def string_field(self, field_name: FieldIdentifier, display_name: str,
                     default_value: str | None = None, max_length: int = 100_000,
                     unique_value: bool = False, html_editor: bool = False,
                     string_format: SapioStringFormat | None = None, num_lines: int = 1, auto_size: bool = True,
                     link_out: dict[str, str] | None = None, field_validator: FieldValidator | None = None,
                     abstract_info: AnyFieldInfo | None = None, *,
                     data_type_name: DataTypeIdentifier | None = None) -> VeloxStringFieldDefinition:
        return super().string_field(field_name, default_value=default_value, max_length=max_length,
                                    unique_value=unique_value, html_editor=html_editor,
                                    string_format=string_format, num_lines=num_lines, auto_size=auto_size,
                                    link_out=link_out, field_validator=field_validator,
                                    abstract_info=abstract_info,
                                    data_type_name=data_type_name, display_name=display_name)
