from __future__ import annotations

from sapiopylib.rest.utils.recordmodel.PyRecordModel import PyRecordModel
from sapiopylib.rest.utils.recordmodel.RecordModelWrapper import WrappedType

from sapiopycommons.general.aliases import SapioRecord, AliasUtil, UserIdentifier
from sapiopycommons.recordmodel.record_handler import RecordHandler

from tot_sdk.models.pipeline_models import VeloxPipelineModel, VeloxPipelineStepModel, \
    VeloxPipelineStepOutputRecordModel


class PipelineReportUtil:
    """
    Utility class for querying pipeline-related relationships across multiple pipelines or records.
    """
    rec_handler: RecordHandler

    def __init__(self, context: UserIdentifier):
        """
        :param context: The current webhook context or a user object to send requests from.
        """
        self.rec_handler = RecordHandler(AliasUtil.to_sapio_user(context))

    def map_records_to_pipeline_step_ids(self, records: list[SapioRecord]) \
            -> dict[SapioRecord, list[int]]:
        """
        Given a list of records, return a dictionary mapping each record to the list of pipeline step record IDs
        that the record appears in as an output. Records are related to pipeline steps through the
        VeloxPipelineStepOutputRecord data type.

        :param records: A list of records to look up.
        :return: A dictionary mapping each input record to a list of pipeline step record IDs that contain it.
            If a record does not appear in any pipeline steps, it maps to an empty list.
        """
        if not records:
            return {}

        record_ids: list[int] = AliasUtil.to_record_ids(records)

        output_records: list[VeloxPipelineStepOutputRecordModel] = self.rec_handler.query_models(
            VeloxPipelineStepOutputRecordModel,
            VeloxPipelineStepOutputRecordModel.OUTPUTRECORDID__FIELD_NAME,
            record_ids
        )

        if not output_records:
            return {record: [] for record in records}

        self.rec_handler.rel_man.load_parents_of_type(output_records, VeloxPipelineStepModel)
        output_to_step: dict[VeloxPipelineStepOutputRecordModel, VeloxPipelineStepModel] = \
            RecordHandler.map_to_parent(output_records, VeloxPipelineStepModel)

        id_to_record: dict[int, SapioRecord] = RecordHandler.map_by_id(records)
        record_to_step_ids: dict[SapioRecord, set[int]] = {record: set() for record in records}
        for output_rec, step in output_to_step.items():
            if step is None:
                continue
            linked_rec_id: int = output_rec.get_OutputRecordId_field()
            if linked_rec_id in id_to_record:
                record_to_step_ids[id_to_record[linked_rec_id]].add(step.record_id)

        return {record: list(step_ids) for record, step_ids in record_to_step_ids.items()}

    def map_pipelines_to_records_of_type(self, pipelines: list[SapioRecord], wrapper_type: type[WrappedType] | str) \
            -> dict[SapioRecord, list[WrappedType] | list[PyRecordModel]]:
        """
        Given a list of pipeline records, return a dictionary mapping each pipeline to a list of records of the given
        type that were produced as outputs in that pipeline. Traverses the pipeline's child steps and their child
        output records to find records matching the requested type.

        :param pipelines: A list of VeloxPipeline records.
        :param wrapper_type: The record model wrapper or data type name to retrieve, corresponding to which data type
            of output records will be queried for. If a data type name is provided, the returned records will be
            PyRecordModels instead of WrappedRecordModels.
        :return: A dictionary mapping each input pipeline to a list of records of the given type that appear as
            outputs in its steps. If a pipeline has no output records of the given type, it maps to an empty list.
        """
        if not pipelines:
            return {}

        data_type_name: str = AliasUtil.to_data_type_name(wrapper_type)
        pipeline_ids: list[int] = AliasUtil.to_record_ids(pipelines)
        id_to_pipeline: dict[int, SapioRecord] = RecordHandler.map_by_id(pipelines)

        pipeline_models: list[VeloxPipelineModel] = self.rec_handler.query_models_by_id(
            VeloxPipelineModel, pipeline_ids
        )

        if not pipeline_models:
            return {pipeline: [] for pipeline in pipelines}

        self.rec_handler.rel_man.load_children_of_type(pipeline_models, VeloxPipelineStepModel)
        pipeline_to_steps: dict[VeloxPipelineModel, list[VeloxPipelineStepModel]] = \
            RecordHandler.map_to_children(pipeline_models, VeloxPipelineStepModel)

        all_steps: list[VeloxPipelineStepModel] = [step for steps in pipeline_to_steps.values() for step in steps]
        if not all_steps:
            return {pipeline: [] for pipeline in pipelines}

        self.rec_handler.rel_man.load_children_of_type(all_steps, VeloxPipelineStepOutputRecordModel)
        step_to_outputs: dict[VeloxPipelineStepModel, list[VeloxPipelineStepOutputRecordModel]] = \
            RecordHandler.map_to_children(all_steps, VeloxPipelineStepOutputRecordModel)

        pipeline_to_output_rec_ids: dict[int, set[int]] = {pid: set() for pid in pipeline_ids}
        for pipeline_model, steps in pipeline_to_steps.items():
            for step in steps:
                for output_rec in step_to_outputs.get(step, []):
                    if output_rec.get_OutputDataTypeName_field() != data_type_name:
                        continue
                    rec_id: int = output_rec.get_OutputRecordId_field()
                    if rec_id is not None:
                        pipeline_to_output_rec_ids[pipeline_model.record_id].add(rec_id)

        all_rec_ids: set[int] = set()
        for rec_ids in pipeline_to_output_rec_ids.values():
            all_rec_ids.update(rec_ids)

        if not all_rec_ids:
            return {pipeline: [] for pipeline in pipelines}

        records = self.rec_handler.query_models_by_id(wrapper_type, all_rec_ids)
        id_to_record: dict[int, WrappedType | PyRecordModel] = RecordHandler.map_by_id(records)

        pipeline_to_records: dict[SapioRecord, set[SapioRecord]] = {pipeline: set() for pipeline in pipelines}
        for pipeline_id, rec_ids in pipeline_to_output_rec_ids.items():
            pipeline: SapioRecord = id_to_pipeline.get(pipeline_id)
            if pipeline is None:
                continue
            for rec_id in rec_ids:
                record = id_to_record.get(rec_id)
                if record is not None:
                    pipeline_to_records[pipeline].add(record)

        return {pipeline: list(recs) for pipeline, recs in pipeline_to_records.items()}
