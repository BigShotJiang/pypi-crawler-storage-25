from __future__ import annotations

from typing import Iterable, TypeAlias
from weakref import WeakValueDictionary

from sapiopylib.rest.User import SapioUser
from sapiopylib.rest.utils.recordmodel.PyRecordModel import PyRecordModel
from sapiopylib.rest.utils.recordmodel.RecordModelManager import RecordModelManager, RecordModelInstanceManager
from sapiopylib.rest.utils.recordmodel.RecordModelWrapper import WrappedType
from sapiopylib.rest.utils.recordmodel.properties import Children

from sapiopycommons.general.aliases import AliasUtil, RecordIdentifier, UserIdentifier
from sapiopycommons.recordmodel.record_handler import RecordHandler

from tot_sdk.models.pipeline_models import VeloxPipelineModel, VeloxPipelineStepModel, \
    VeloxPipelineStepOutputRecordModel
from tot_sdk.webservice.pipeline_manager import PipelineManager

PipelineStepIdentifier: TypeAlias = str | int | VeloxPipelineStepModel
"""An identifier for a pipeline step. May be a step template name, a record ID, or the step model itself."""


class PipelineHandler:
    """
    A handler class for dealing with pipelines. Provides lazy-cached access to the pipeline's steps
    and their output records.

    A pipeline ID or record must be provided. If a record is given, it is used directly without querying
    the system. If an integer ID is given, the system is queried at construction time to confirm validity.

    Instances are cached per user and pipeline ID using a WeakValueDictionary, so constructing a PipelineHandler
    with the same user and pipeline ID will return the same instance.
    """
    user: SapioUser
    _pipeline_id: int

    inst_man: RecordModelInstanceManager
    rec_handler: RecordHandler
    pipeline_man: PipelineManager
    """REST API service for managing pipeline instances. Provides functions for adding step outputs and
    triggering pipelines."""

    _pipeline_model: VeloxPipelineModel | None

    _queried_all_steps: bool
    _steps: list[VeloxPipelineStepModel]
    _steps_by_name: dict[str, VeloxPipelineStepModel]
    _steps_by_id: dict[int, VeloxPipelineStepModel]

    __instances: WeakValueDictionary[str, PipelineHandler] = WeakValueDictionary()
    __initialized: bool

    def __new__(cls, context: UserIdentifier, pipeline_id: RecordIdentifier):
        user = AliasUtil.to_sapio_user(context)
        resolved_id = AliasUtil.to_record_id(pipeline_id)
        key = f"{user.__hash__()}:{resolved_id}"
        obj = cls.__instances.get(key)
        if not obj:
            obj = object.__new__(cls)
            obj.__initialized = False
            cls.__instances[key] = obj
        return obj

    def __init__(self, context: UserIdentifier, pipeline_id: RecordIdentifier):
        """
        :param context: The current webhook context or a user object to send requests from.
        :param pipeline_id: The pipeline to handle. May be a record (SapioRecord) or an integer record ID.
            If a record is provided, it is used directly to populate the pipeline model cache. If an integer
            is provided, the system is queried to confirm that the pipeline exists.
        :raises Exception: If an integer pipeline_id is provided and no matching pipeline record is found.
        """
        self.user = AliasUtil.to_sapio_user(context)
        self._pipeline_id = AliasUtil.to_record_id(pipeline_id)
        self.inst_man = RecordModelManager(self.user).instance_manager
        self.rec_handler = RecordHandler(self.user)
        self.pipeline_man = PipelineManager(self.user)

        if isinstance(pipeline_id, int):
            self._pipeline_model = self.rec_handler.query_models_by_id(VeloxPipelineModel, [pipeline_id])[0]
        else:
            self._pipeline_model = self.inst_man.wrap(pipeline_id, VeloxPipelineModel)

        self._queried_all_steps = False
        self._steps = []
        self._steps_by_name = {}
        self._steps_by_id = {}

    def pipeline_record(self) -> VeloxPipelineModel:
        """
        Retrieve the pipeline record associated with this handler.

        :return: The pipeline record as a VeloxPipelineModel.
        """
        return self._pipeline_model

    def _load_all_steps(self) -> None:
        """
        Query the system for every step in the pipeline and populate the caches.
        """
        self._queried_all_steps = True
        pipeline: VeloxPipelineModel = self.pipeline_record()
        self.rec_handler.rel_man.load_children_of_type([pipeline], VeloxPipelineStepModel)
        self._steps = pipeline.get(Children.of_type(VeloxPipelineStepModel))
        for step in self._steps:
            name: str | None = step.get_VeloxStepTemplateName_field()
            if name is not None:
                self._steps_by_name[name] = step
            self._steps_by_id[step.record_id] = step

    def get_step(self, step: PipelineStepIdentifier, exception_on_none: bool = True) \
            -> VeloxPipelineStepModel | None:
        """
        Get a pipeline step by name, record ID, or model.

        If a VeloxPipelineStepModel is provided, it is added to the cache and returned directly. Otherwise,
        lazily loads all steps from the system on the first call if the requested step is not already cached.

        :param step: A step template name (str), record ID (int), or VeloxPipelineStepModel.
        :param exception_on_none: If true, raises an exception when the step cannot be found.
            If false, returns None instead.
        :return: The matching VeloxPipelineStepModel, or None if not found and exception_on_none is false.
        """
        return self.get_steps([step], exception_on_none)[0]

    def get_steps(self, steps: Iterable[PipelineStepIdentifier], exception_on_none: bool = True) \
            -> list[VeloxPipelineStepModel | None]:
        """
        Get a list of pipeline steps, returned in the same order as the provided identifiers.

        Each identifier may be a step template name (str), record ID (int), or VeloxPipelineStepModel.
        If a VeloxPipelineStepModel is provided, it is added to the cache and included directly.

        Lazily loads all steps from the system if a requested step is not already cached.

        :param steps: An iterable of step identifiers in the desired return order.
        :param exception_on_none: If true, raises an exception when any step cannot be found.
            If false, returns None for steps that cannot be found.
        :return: A list of VeloxPipelineStepModels in the same order as the input identifiers.
        """
        step_ids: list[str | int] = []
        for step in steps:
            if isinstance(step, VeloxPipelineStepModel):
                step_ids.append(step.record_id)
                self._steps_by_id[step.record_id] = step
                name: str | None = step.get_VeloxStepTemplateName_field()
                if name is not None:
                    self._steps_by_name[name] = step
            elif isinstance(step, (str, int)):
                step_ids.append(step)

        ret_list: list[VeloxPipelineStepModel | None] = []
        for step_id in step_ids:
            if not self._queried_all_steps:
                if ((isinstance(step_id, str) and step_id not in self._steps_by_name)
                        or (isinstance(step_id, int) and step_id not in self._steps_by_id)):
                    self._load_all_steps()
            if isinstance(step_id, str):
                result: VeloxPipelineStepModel | None = self._steps_by_name.get(step_id)
            else:
                result: VeloxPipelineStepModel | None = self._steps_by_id.get(step_id)
            if result is None and exception_on_none:
                raise Exception(f"Pipeline step \"{step_id}\" not found in pipeline {self._pipeline_id}.")
            ret_list.append(result)
        return ret_list

    def get_all_steps(self) -> list[VeloxPipelineStepModel]:
        """
        Get a list of every step in the pipeline.

        Lazily loads all steps from the system on the first call.

        :return: Every step in the pipeline.
        """
        if not self._queried_all_steps:
            self._load_all_steps()
        return list(self._steps)

    def get_step_output_records(self, step: PipelineStepIdentifier, wrapper_type: type[WrappedType] | str) \
            -> list[WrappedType] | list[PyRecordModel]:
        """
        Retrieve the output records of a pipeline step, filtered to a specific data type.

        Loads the child VeloxPipelineStepOutputRecord records of the step, filters them by OutputDataTypeName
        matching the requested wrapper_type, queries the actual records by OutputRecordId, and returns them
        as typed record models.

        :param step: The step to get outputs for. May be a step template name, record ID, or VeloxPipelineStepModel.
        :param wrapper_type: The record model wrapper or data type name of the output records to retrieve. If a data
            type name is provided, the returned records will be PyRecordModels instead of WrappedRecordModels.
        :return: The output records of the given type for the step.
        """
        if not isinstance(step, VeloxPipelineStepModel):
            step = self.get_step(step)
        data_type_name: str = AliasUtil.to_data_type_name(wrapper_type)

        self.rec_handler.rel_man.load_children_of_type([step], VeloxPipelineStepOutputRecordModel)
        output_links: list[VeloxPipelineStepOutputRecordModel] = \
            step.get(Children.of_type(VeloxPipelineStepOutputRecordModel))

        rec_ids: list[int] = []
        for link in output_links:
            if link.get_OutputDataTypeName_field() != data_type_name:
                continue
            rec_id: int | None = link.get_OutputRecordId_field()
            if rec_id is not None:
                rec_ids.append(rec_id)

        if not rec_ids:
            return []

        return self.rec_handler.query_models_by_id(wrapper_type, rec_ids)
