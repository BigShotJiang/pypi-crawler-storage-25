from tot_sdk.protoapi.externalcredentials import external_credentials_pb2 as _external_credentials_pb2
from tot_sdk.protoapi.fielddefinitions import fields_pb2 as _fields_pb2
from tot_sdk.protoapi.fielddefinitions import velox_field_def_pb2 as _velox_field_def_pb2
from tot_sdk.protoapi.agent import entry_pb2 as _entry_pb2
from tot_sdk.protoapi.agent.item import item_container_pb2 as _item_container_pb2
from tot_sdk.protoapi.pipeline import step_pb2 as _step_pb2
from tot_sdk.protoapi.session import sapio_conn_info_pb2 as _sapio_conn_info_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union
from tot_sdk.protoapi.externalcredentials.external_credentials_pb2 import ExternalCredentialsPbo as ExternalCredentialsPbo
from tot_sdk.protoapi.fielddefinitions.fields_pb2 import DateRangePbo as DateRangePbo
from tot_sdk.protoapi.fielddefinitions.fields_pb2 import FieldValuePbo as FieldValuePbo
from tot_sdk.protoapi.fielddefinitions.fields_pb2 import FieldValueMapPbo as FieldValueMapPbo
from tot_sdk.protoapi.fielddefinitions.fields_pb2 import FileBlobDataPbo as FileBlobDataPbo
from tot_sdk.protoapi.fielddefinitions.fields_pb2 import DataRecordPbo as DataRecordPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import FieldValidatorPbo as FieldValidatorPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import ColorRangePbo as ColorRangePbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import BooleanDependentFieldEntryPbo as BooleanDependentFieldEntryPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import SelectionDependentFieldEntryPbo as SelectionDependentFieldEntryPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import EnumDependentFieldEntryPbo as EnumDependentFieldEntryPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import ProcessDetailEntryPbo as ProcessDetailEntryPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import BooleanPropertiesPbo as BooleanPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import DatePropertiesPbo as DatePropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import DoublePropertiesPbo as DoublePropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import IntegerPropertiesPbo as IntegerPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import LongPropertiesPbo as LongPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import ShortPropertiesPbo as ShortPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import SelectionPropertiesPbo as SelectionPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import StringPropertiesPbo as StringPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import SideLinkPropertiesPbo as SideLinkPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import PickListPropertiesPbo as PickListPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import ParentLinkPropertiesPbo as ParentLinkPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import MultiParentPropertiesPbo as MultiParentPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import IdentifierPropertiesPbo as IdentifierPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import FileBlobPropertiesPbo as FileBlobPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import EnumPropertiesPbo as EnumPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import DateRangePropertiesPbo as DateRangePropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import ChildLinkPropertiesPbo as ChildLinkPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import ActionStringPropertiesPbo as ActionStringPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import ActionPropertiesPbo as ActionPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import AccessionPropertiesPbo as AccessionPropertiesPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import VeloxFieldDefPbo as VeloxFieldDefPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import VeloxFieldDefListPbo as VeloxFieldDefListPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import FieldTypePbo as FieldTypePbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import SortDirectionPbo as SortDirectionPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import FontSizePbo as FontSizePbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import TextDecorationPbo as TextDecorationPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import StringFormatPbo as StringFormatPbo
from tot_sdk.protoapi.fielddefinitions.velox_field_def_pb2 import DoubleFormatPbo as DoubleFormatPbo
from tot_sdk.protoapi.agent.entry_pb2 import StepInputBatchPbo as StepInputBatchPbo
from tot_sdk.protoapi.agent.entry_pb2 import StepOutputBatchPbo as StepOutputBatchPbo
from tot_sdk.protoapi.pipeline.step_pb2 import StepIoInfoPbo as StepIoInfoPbo
from tot_sdk.protoapi.pipeline.step_pb2 import StepIoDetailsPbo as StepIoDetailsPbo
from tot_sdk.protoapi.pipeline.step_pb2 import StepInputDetailsPbo as StepInputDetailsPbo
from tot_sdk.protoapi.pipeline.step_pb2 import StepOutputDetailsPbo as StepOutputDetailsPbo
from tot_sdk.protoapi.session.sapio_conn_info_pb2 import SapioConnectionInfoPbo as SapioConnectionInfoPbo
from tot_sdk.protoapi.session.sapio_conn_info_pb2 import SapioUserSecretTypePbo as SapioUserSecretTypePbo

DESCRIPTOR: _descriptor.FileDescriptor
FIELD_TYPE_UNSPECIFIED: _velox_field_def_pb2.FieldTypePbo
BOOLEAN: _velox_field_def_pb2.FieldTypePbo
DOUBLE: _velox_field_def_pb2.FieldTypePbo
ENUM: _velox_field_def_pb2.FieldTypePbo
LONG: _velox_field_def_pb2.FieldTypePbo
INTEGER: _velox_field_def_pb2.FieldTypePbo
SHORT: _velox_field_def_pb2.FieldTypePbo
STRING: _velox_field_def_pb2.FieldTypePbo
DATE: _velox_field_def_pb2.FieldTypePbo
ACTION: _velox_field_def_pb2.FieldTypePbo
SELECTION: _velox_field_def_pb2.FieldTypePbo
PARENTLINK: _velox_field_def_pb2.FieldTypePbo
IDENTIFIER: _velox_field_def_pb2.FieldTypePbo
PICKLIST: _velox_field_def_pb2.FieldTypePbo
LINK: _velox_field_def_pb2.FieldTypePbo
MULTIPARENTLINK: _velox_field_def_pb2.FieldTypePbo
CHILDLINK: _velox_field_def_pb2.FieldTypePbo
AUTO_ACCESSION: _velox_field_def_pb2.FieldTypePbo
DATE_RANGE: _velox_field_def_pb2.FieldTypePbo
SIDE_LINK: _velox_field_def_pb2.FieldTypePbo
ACTION_STRING: _velox_field_def_pb2.FieldTypePbo
FILE_BLOB: _velox_field_def_pb2.FieldTypePbo
SORT_DIRECTION_UNSPECIFIED: _velox_field_def_pb2.SortDirectionPbo
SORT_DIRECTION_ASCENDING: _velox_field_def_pb2.SortDirectionPbo
SORT_DIRECTION_DESCENDING: _velox_field_def_pb2.SortDirectionPbo
SORT_DIRECTION_NONE: _velox_field_def_pb2.SortDirectionPbo
FONT_SIZE_UNSPECIFIED: _velox_field_def_pb2.FontSizePbo
FONT_SIZE_SMALL: _velox_field_def_pb2.FontSizePbo
FONT_SIZE_MEDIUM: _velox_field_def_pb2.FontSizePbo
FONT_SIZE_LARGE: _velox_field_def_pb2.FontSizePbo
TEXT_DECORATION_UNSPECIFIED: _velox_field_def_pb2.TextDecorationPbo
TEXT_DECORATION_NONE: _velox_field_def_pb2.TextDecorationPbo
TEXT_DECORATION_UNDERLINE: _velox_field_def_pb2.TextDecorationPbo
TEXT_DECORATION_STRIKETHROUGH: _velox_field_def_pb2.TextDecorationPbo
STRING_FORMAT_UNSPECIFIED: _velox_field_def_pb2.StringFormatPbo
STRING_FORMAT_PHONE: _velox_field_def_pb2.StringFormatPbo
STRING_FORMAT_EMAIL: _velox_field_def_pb2.StringFormatPbo
DOUBLE_FORMAT_UNSPECIFIED: _velox_field_def_pb2.DoubleFormatPbo
DOUBLE_FORMAT_CURRENCY: _velox_field_def_pb2.DoubleFormatPbo
DOUBLE_FORMAT_PERCENTAGE: _velox_field_def_pb2.DoubleFormatPbo
SESSION_TOKEN: _sapio_conn_info_pb2.SapioUserSecretTypePbo
PASSWORD: _sapio_conn_info_pb2.SapioUserSecretTypePbo

class ProcessStepResponseStatusPbo(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    UNKNOWN: _ClassVar[ProcessStepResponseStatusPbo]
    SUCCESS: _ClassVar[ProcessStepResponseStatusPbo]
    FAILURE: _ClassVar[ProcessStepResponseStatusPbo]
UNKNOWN: ProcessStepResponseStatusPbo
SUCCESS: ProcessStepResponseStatusPbo
FAILURE: ProcessStepResponseStatusPbo

class ExampleContainerPbo(_message.Message):
    __slots__ = ("text_example", "binary_example")
    TEXT_EXAMPLE_FIELD_NUMBER: _ClassVar[int]
    BINARY_EXAMPLE_FIELD_NUMBER: _ClassVar[int]
    text_example: str
    binary_example: bytes
    def __init__(self, text_example: _Optional[str] = ..., binary_example: _Optional[bytes] = ...) -> None: ...

class AgentIoConfigBasePbo(_message.Message):
    __slots__ = ("content_type", "io_number", "display_name", "description", "deprecated_old_example", "structure_example", "testing_example", "data_type_name")
    CONTENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    IO_NUMBER_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DEPRECATED_OLD_EXAMPLE_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_EXAMPLE_FIELD_NUMBER: _ClassVar[int]
    TESTING_EXAMPLE_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_NAME_FIELD_NUMBER: _ClassVar[int]
    content_type: str
    io_number: int
    display_name: str
    description: str
    deprecated_old_example: str
    structure_example: ExampleContainerPbo
    testing_example: ExampleContainerPbo
    data_type_name: str
    def __init__(self, content_type: _Optional[str] = ..., io_number: _Optional[int] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., deprecated_old_example: _Optional[str] = ..., structure_example: _Optional[_Union[ExampleContainerPbo, _Mapping]] = ..., testing_example: _Optional[_Union[ExampleContainerPbo, _Mapping]] = ..., data_type_name: _Optional[str] = ...) -> None: ...

class AgentDataTypeDefinitionPbo(_message.Message):
    __slots__ = ("data_type_name", "display_name", "plural_display_name", "description", "tag", "icon", "icon_color", "is_high_volume", "is_high_volume_on_save_enabled", "record_image_assignable", "is_attachment_data_type", "child_data_types", "parent_data_types", "data_type_layout", "velox_field_definition")
    DATA_TYPE_NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    PLURAL_DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    ICON_COLOR_FIELD_NUMBER: _ClassVar[int]
    IS_HIGH_VOLUME_FIELD_NUMBER: _ClassVar[int]
    IS_HIGH_VOLUME_ON_SAVE_ENABLED_FIELD_NUMBER: _ClassVar[int]
    RECORD_IMAGE_ASSIGNABLE_FIELD_NUMBER: _ClassVar[int]
    IS_ATTACHMENT_DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    CHILD_DATA_TYPES_FIELD_NUMBER: _ClassVar[int]
    PARENT_DATA_TYPES_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_LAYOUT_FIELD_NUMBER: _ClassVar[int]
    VELOX_FIELD_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    data_type_name: str
    display_name: str
    plural_display_name: str
    description: str
    tag: str
    icon: bytes
    icon_color: str
    is_high_volume: bool
    is_high_volume_on_save_enabled: bool
    record_image_assignable: bool
    is_attachment_data_type: bool
    child_data_types: _containers.RepeatedScalarFieldContainer[str]
    parent_data_types: _containers.RepeatedScalarFieldContainer[str]
    data_type_layout: DataTypeLayoutPbo
    velox_field_definition: _containers.RepeatedCompositeFieldContainer[_velox_field_def_pb2.VeloxFieldDefPbo]
    def __init__(self, data_type_name: _Optional[str] = ..., display_name: _Optional[str] = ..., plural_display_name: _Optional[str] = ..., description: _Optional[str] = ..., tag: _Optional[str] = ..., icon: _Optional[bytes] = ..., icon_color: _Optional[str] = ..., is_high_volume: bool = ..., is_high_volume_on_save_enabled: bool = ..., record_image_assignable: bool = ..., is_attachment_data_type: bool = ..., child_data_types: _Optional[_Iterable[str]] = ..., parent_data_types: _Optional[_Iterable[str]] = ..., data_type_layout: _Optional[_Union[DataTypeLayoutPbo, _Mapping]] = ..., velox_field_definition: _Optional[_Iterable[_Union[_velox_field_def_pb2.VeloxFieldDefPbo, _Mapping]]] = ...) -> None: ...

class FormPositionPbo(_message.Message):
    __slots__ = ("column_order", "column_span")
    COLUMN_ORDER_FIELD_NUMBER: _ClassVar[int]
    COLUMN_SPAN_FIELD_NUMBER: _ClassVar[int]
    column_order: int
    column_span: int
    def __init__(self, column_order: _Optional[int] = ..., column_span: _Optional[int] = ...) -> None: ...

class CustomLayoutComponentPbo(_message.Message):
    __slots__ = ("component_name", "display_name", "plugin_path", "attributes")
    class AttributesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    COMPONENT_NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    PLUGIN_PATH_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    component_name: str
    display_name: str
    plugin_path: str
    attributes: _containers.ScalarMap[str, str]
    def __init__(self, component_name: _Optional[str] = ..., display_name: _Optional[str] = ..., plugin_path: _Optional[str] = ..., attributes: _Optional[_Mapping[str, str]] = ...) -> None: ...

class CustomLayoutTabPbo(_message.Message):
    __slots__ = ("tab_name", "tab_display_name", "tab_order", "custom_components")
    TAB_NAME_FIELD_NUMBER: _ClassVar[int]
    TAB_DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    TAB_ORDER_FIELD_NUMBER: _ClassVar[int]
    CUSTOM_COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    tab_name: str
    tab_display_name: str
    tab_order: int
    custom_components: _containers.RepeatedCompositeFieldContainer[CustomLayoutComponentPbo]
    def __init__(self, tab_name: _Optional[str] = ..., tab_display_name: _Optional[str] = ..., tab_order: _Optional[int] = ..., custom_components: _Optional[_Iterable[_Union[CustomLayoutComponentPbo, _Mapping]]] = ...) -> None: ...

class DataTypeLayoutPbo(_message.Message):
    __slots__ = ("table_column_order", "form_positions", "form_tab_order", "custom_tabs", "form_column_span")
    class FormPositionsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: FormPositionPbo
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[FormPositionPbo, _Mapping]] = ...) -> None: ...
    TABLE_COLUMN_ORDER_FIELD_NUMBER: _ClassVar[int]
    FORM_POSITIONS_FIELD_NUMBER: _ClassVar[int]
    FORM_TAB_ORDER_FIELD_NUMBER: _ClassVar[int]
    CUSTOM_TABS_FIELD_NUMBER: _ClassVar[int]
    FORM_COLUMN_SPAN_FIELD_NUMBER: _ClassVar[int]
    table_column_order: _containers.RepeatedScalarFieldContainer[str]
    form_positions: _containers.MessageMap[str, FormPositionPbo]
    form_tab_order: int
    custom_tabs: _containers.RepeatedCompositeFieldContainer[CustomLayoutTabPbo]
    form_column_span: int
    def __init__(self, table_column_order: _Optional[_Iterable[str]] = ..., form_positions: _Optional[_Mapping[str, FormPositionPbo]] = ..., form_tab_order: _Optional[int] = ..., custom_tabs: _Optional[_Iterable[_Union[CustomLayoutTabPbo, _Mapping]]] = ..., form_column_span: _Optional[int] = ...) -> None: ...

class AgentInputDetailsPbo(_message.Message):
    __slots__ = ("base_config", "validation", "min_input_count", "max_input_count", "paged", "min_page_size", "max_page_size", "max_request_bytes")
    BASE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    VALIDATION_FIELD_NUMBER: _ClassVar[int]
    MIN_INPUT_COUNT_FIELD_NUMBER: _ClassVar[int]
    MAX_INPUT_COUNT_FIELD_NUMBER: _ClassVar[int]
    PAGED_FIELD_NUMBER: _ClassVar[int]
    MIN_PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    MAX_PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    MAX_REQUEST_BYTES_FIELD_NUMBER: _ClassVar[int]
    base_config: AgentIoConfigBasePbo
    validation: str
    min_input_count: int
    max_input_count: int
    paged: bool
    min_page_size: int
    max_page_size: int
    max_request_bytes: int
    def __init__(self, base_config: _Optional[_Union[AgentIoConfigBasePbo, _Mapping]] = ..., validation: _Optional[str] = ..., min_input_count: _Optional[int] = ..., max_input_count: _Optional[int] = ..., paged: bool = ..., min_page_size: _Optional[int] = ..., max_page_size: _Optional[int] = ..., max_request_bytes: _Optional[int] = ...) -> None: ...

class AgentOutputDetailsPbo(_message.Message):
    __slots__ = ("base_config",)
    BASE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    base_config: AgentIoConfigBasePbo
    def __init__(self, base_config: _Optional[_Union[AgentIoConfigBasePbo, _Mapping]] = ...) -> None: ...

class ProcessStepRequestPbo(_message.Message):
    __slots__ = ("sapio_user", "agent_name", "pipeline_id", "pipeline_step_id", "invocation_id", "input_configs", "output_configs", "config_field_values", "dry_run", "verbose_logging", "external_credential", "output_data_type_name", "agent_import_id", "data_type_namespace", "input")
    class ConfigFieldValuesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _fields_pb2.FieldValuePbo
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_fields_pb2.FieldValuePbo, _Mapping]] = ...) -> None: ...
    SAPIO_USER_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    PIPELINE_ID_FIELD_NUMBER: _ClassVar[int]
    PIPELINE_STEP_ID_FIELD_NUMBER: _ClassVar[int]
    INVOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    INPUT_CONFIGS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_CONFIGS_FIELD_NUMBER: _ClassVar[int]
    CONFIG_FIELD_VALUES_FIELD_NUMBER: _ClassVar[int]
    DRY_RUN_FIELD_NUMBER: _ClassVar[int]
    VERBOSE_LOGGING_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_CREDENTIAL_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_DATA_TYPE_NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_IMPORT_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    INPUT_FIELD_NUMBER: _ClassVar[int]
    sapio_user: _sapio_conn_info_pb2.SapioConnectionInfoPbo
    agent_name: str
    pipeline_id: int
    pipeline_step_id: int
    invocation_id: int
    input_configs: _containers.RepeatedCompositeFieldContainer[_step_pb2.StepIoInfoPbo]
    output_configs: _containers.RepeatedCompositeFieldContainer[_step_pb2.StepIoInfoPbo]
    config_field_values: _containers.MessageMap[str, _fields_pb2.FieldValuePbo]
    dry_run: bool
    verbose_logging: bool
    external_credential: _containers.RepeatedCompositeFieldContainer[_external_credentials_pb2.ExternalCredentialsPbo]
    output_data_type_name: str
    agent_import_id: str
    data_type_namespace: str
    input: _containers.RepeatedCompositeFieldContainer[_entry_pb2.StepInputBatchPbo]
    def __init__(self, sapio_user: _Optional[_Union[_sapio_conn_info_pb2.SapioConnectionInfoPbo, _Mapping]] = ..., agent_name: _Optional[str] = ..., pipeline_id: _Optional[int] = ..., pipeline_step_id: _Optional[int] = ..., invocation_id: _Optional[int] = ..., input_configs: _Optional[_Iterable[_Union[_step_pb2.StepIoInfoPbo, _Mapping]]] = ..., output_configs: _Optional[_Iterable[_Union[_step_pb2.StepIoInfoPbo, _Mapping]]] = ..., config_field_values: _Optional[_Mapping[str, _fields_pb2.FieldValuePbo]] = ..., dry_run: bool = ..., verbose_logging: bool = ..., external_credential: _Optional[_Iterable[_Union[_external_credentials_pb2.ExternalCredentialsPbo, _Mapping]]] = ..., output_data_type_name: _Optional[str] = ..., agent_import_id: _Optional[str] = ..., data_type_namespace: _Optional[str] = ..., input: _Optional[_Iterable[_Union[_entry_pb2.StepInputBatchPbo, _Mapping]]] = ...) -> None: ...

class ProcessStepResponsePbo(_message.Message):
    __slots__ = ("status", "status_message", "step_summary", "display_records", "new_records", "log", "output")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STATUS_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    STEP_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_RECORDS_FIELD_NUMBER: _ClassVar[int]
    NEW_RECORDS_FIELD_NUMBER: _ClassVar[int]
    LOG_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FIELD_NUMBER: _ClassVar[int]
    status: ProcessStepResponseStatusPbo
    status_message: str
    step_summary: str
    display_records: _containers.RepeatedCompositeFieldContainer[_fields_pb2.DataRecordPbo]
    new_records: _containers.RepeatedCompositeFieldContainer[_fields_pb2.FieldValueMapPbo]
    log: _containers.RepeatedScalarFieldContainer[str]
    output: _containers.RepeatedCompositeFieldContainer[_entry_pb2.StepOutputBatchPbo]
    def __init__(self, status: _Optional[_Union[ProcessStepResponseStatusPbo, str]] = ..., status_message: _Optional[str] = ..., step_summary: _Optional[str] = ..., display_records: _Optional[_Iterable[_Union[_fields_pb2.DataRecordPbo, _Mapping]]] = ..., new_records: _Optional[_Iterable[_Union[_fields_pb2.FieldValueMapPbo, _Mapping]]] = ..., log: _Optional[_Iterable[str]] = ..., output: _Optional[_Iterable[_Union[_entry_pb2.StepOutputBatchPbo, _Mapping]]] = ...) -> None: ...

class AgentDetailsRequestPbo(_message.Message):
    __slots__ = ("sapio_conn_info",)
    SAPIO_CONN_INFO_FIELD_NUMBER: _ClassVar[int]
    sapio_conn_info: _sapio_conn_info_pb2.SapioConnectionInfoPbo
    def __init__(self, sapio_conn_info: _Optional[_Union[_sapio_conn_info_pb2.SapioConnectionInfoPbo, _Mapping]] = ...) -> None: ...

class AgentDetailsPbo(_message.Message):
    __slots__ = ("import_id", "name", "description", "output_data_type_name", "input_configs", "output_configs", "config_fields", "license_info", "category", "citation", "review_on_instance_field_names", "output_data_type_display_name", "output_type_fields", "sub_category", "icon", "output_data_type_icon", "full_description", "is_commercial")
    IMPORT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_DATA_TYPE_NAME_FIELD_NUMBER: _ClassVar[int]
    INPUT_CONFIGS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_CONFIGS_FIELD_NUMBER: _ClassVar[int]
    CONFIG_FIELDS_FIELD_NUMBER: _ClassVar[int]
    LICENSE_INFO_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    CITATION_FIELD_NUMBER: _ClassVar[int]
    REVIEW_ON_INSTANCE_FIELD_NAMES_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_DATA_TYPE_DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TYPE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    SUB_CATEGORY_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_DATA_TYPE_ICON_FIELD_NUMBER: _ClassVar[int]
    FULL_DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    IS_COMMERCIAL_FIELD_NUMBER: _ClassVar[int]
    import_id: str
    name: str
    description: str
    output_data_type_name: str
    input_configs: _containers.RepeatedCompositeFieldContainer[AgentInputDetailsPbo]
    output_configs: _containers.RepeatedCompositeFieldContainer[AgentOutputDetailsPbo]
    config_fields: _containers.RepeatedCompositeFieldContainer[_velox_field_def_pb2.VeloxFieldDefPbo]
    license_info: str
    category: str
    citation: _containers.RepeatedCompositeFieldContainer[AgentCitationPbo]
    review_on_instance_field_names: _containers.RepeatedScalarFieldContainer[str]
    output_data_type_display_name: str
    output_type_fields: _containers.RepeatedCompositeFieldContainer[_velox_field_def_pb2.VeloxFieldDefPbo]
    sub_category: str
    icon: bytes
    output_data_type_icon: bytes
    full_description: str
    is_commercial: bool
    def __init__(self, import_id: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., output_data_type_name: _Optional[str] = ..., input_configs: _Optional[_Iterable[_Union[AgentInputDetailsPbo, _Mapping]]] = ..., output_configs: _Optional[_Iterable[_Union[AgentOutputDetailsPbo, _Mapping]]] = ..., config_fields: _Optional[_Iterable[_Union[_velox_field_def_pb2.VeloxFieldDefPbo, _Mapping]]] = ..., license_info: _Optional[str] = ..., category: _Optional[str] = ..., citation: _Optional[_Iterable[_Union[AgentCitationPbo, _Mapping]]] = ..., review_on_instance_field_names: _Optional[_Iterable[str]] = ..., output_data_type_display_name: _Optional[str] = ..., output_type_fields: _Optional[_Iterable[_Union[_velox_field_def_pb2.VeloxFieldDefPbo, _Mapping]]] = ..., sub_category: _Optional[str] = ..., icon: _Optional[bytes] = ..., output_data_type_icon: _Optional[bytes] = ..., full_description: _Optional[str] = ..., is_commercial: bool = ...) -> None: ...

class AgentCitationPbo(_message.Message):
    __slots__ = ("title", "url")
    TITLE_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    title: str
    url: str
    def __init__(self, title: _Optional[str] = ..., url: _Optional[str] = ...) -> None: ...

class AgentDetailsResponsePbo(_message.Message):
    __slots__ = ("agent_framework_version", "agent_details", "data_type_definition")
    class DataTypeDefinitionEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: AgentDataTypeDefinitionPbo
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[AgentDataTypeDefinitionPbo, _Mapping]] = ...) -> None: ...
    AGENT_FRAMEWORK_VERSION_FIELD_NUMBER: _ClassVar[int]
    AGENT_DETAILS_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    agent_framework_version: int
    agent_details: _containers.RepeatedCompositeFieldContainer[AgentDetailsPbo]
    data_type_definition: _containers.MessageMap[str, AgentDataTypeDefinitionPbo]
    def __init__(self, agent_framework_version: _Optional[int] = ..., agent_details: _Optional[_Iterable[_Union[AgentDetailsPbo, _Mapping]]] = ..., data_type_definition: _Optional[_Mapping[str, AgentDataTypeDefinitionPbo]] = ...) -> None: ...

class CalculateCostRequestPbo(_message.Message):
    __slots__ = ("agent_name", "input_configs", "output_configs", "config_field_values", "verbose_logging", "agent_import_id", "input_count")
    class ConfigFieldValuesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _fields_pb2.FieldValuePbo
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_fields_pb2.FieldValuePbo, _Mapping]] = ...) -> None: ...
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    INPUT_CONFIGS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_CONFIGS_FIELD_NUMBER: _ClassVar[int]
    CONFIG_FIELD_VALUES_FIELD_NUMBER: _ClassVar[int]
    VERBOSE_LOGGING_FIELD_NUMBER: _ClassVar[int]
    AGENT_IMPORT_ID_FIELD_NUMBER: _ClassVar[int]
    INPUT_COUNT_FIELD_NUMBER: _ClassVar[int]
    agent_name: str
    input_configs: _containers.RepeatedCompositeFieldContainer[_step_pb2.StepIoInfoPbo]
    output_configs: _containers.RepeatedCompositeFieldContainer[_step_pb2.StepIoInfoPbo]
    config_field_values: _containers.MessageMap[str, _fields_pb2.FieldValuePbo]
    verbose_logging: bool
    agent_import_id: str
    input_count: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, agent_name: _Optional[str] = ..., input_configs: _Optional[_Iterable[_Union[_step_pb2.StepIoInfoPbo, _Mapping]]] = ..., output_configs: _Optional[_Iterable[_Union[_step_pb2.StepIoInfoPbo, _Mapping]]] = ..., config_field_values: _Optional[_Mapping[str, _fields_pb2.FieldValuePbo]] = ..., verbose_logging: bool = ..., agent_import_id: _Optional[str] = ..., input_count: _Optional[_Iterable[int]] = ...) -> None: ...

class CalculateCostResponsePbo(_message.Message):
    __slots__ = ("cost_tokens", "cost_calculation_message")
    COST_TOKENS_FIELD_NUMBER: _ClassVar[int]
    COST_CALCULATION_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    cost_tokens: float
    cost_calculation_message: str
    def __init__(self, cost_tokens: _Optional[float] = ..., cost_calculation_message: _Optional[str] = ...) -> None: ...
