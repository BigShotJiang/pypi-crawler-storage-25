
# tot-sdk: Official Tool of Tools Framework Package

-----------------
[![PyPI Latest Release](https://img.shields.io/pypi/v/tot-sdk.svg)](https://pypi.org/project/tot-sdk/) [![License](https://img.shields.io/pypi/l/tot-sdk.svg)](https://www.mozilla.org/en-US/MPL/2.0/)

## What is it?
tot-sdk contains the code necessary for creation of agents/tools capable of being used within the Tool of Tools framework.

## Where to get it
Installation is simple:
```sh
pip install tot-sdk
```

## Licenses
tot-sdk is licensed under MPL 2.0.

pypi.org is granted the right to distribute tot-sdk forever.

This license does not provide any rights to use any other copyrighted artifacts from Tool of Tools/Sigmatic Sciences. (And they are typically written in another programming language with no linkages to this library.)

## Dependencies
The following dependencies are required for this package:
- [sapiopycommons - The official Sapio Python API utilities package.](https://pypi.org/project/sapiopylib/)
- [grpcio-tools - Package for gRPC Python tools.](https://pypi.org/project/grpcio-tools)
- [grpcio-health-checking - Reference package for GRPC Python health checking.](https://pypi.org/project/grpcio-health-checking)
- [jsonschema - An implementation of the JSON Schema specification for Python.](https://pypi.org/project/jsonschema/)

## About Us
Sigmatic Sciences is a technology company dedicated to accelerating research and development for biopharmaceutical organizations. Its platform, empowers scientific teams to design and execute in silico R&D workflows supporting a wide range of activities—from early-stage drug discovery to scale-up and bioproduction.

By integrating scientific data from public, private, and client sources with computational models and AI-driven orchestration, Sigmatic Sciences enables researchers to explore hypotheses more efficiently and prioritize the most promising drug candidates for further development. This approach drives faster, more informed decision-making while optimizing both scientific and wet-lab resources.

Visit us at <a href="https://www.sigmaticsciences.com/">Sigmatic Sciences</a>.
