# SmartChecker

A smart spell checker that uses phonetic similarity and proximate keyboard layout analysis to suggest corrections.

## Features
- GUI and CLI interfaces.
- English and French support.
- Phonetic dictionary search.
- Proximate keyboard distance calculations.

## Installation
```bash
pip install smartchecker
```

## Usage
Run the command-line tool:
```bash
smartchecker
```
