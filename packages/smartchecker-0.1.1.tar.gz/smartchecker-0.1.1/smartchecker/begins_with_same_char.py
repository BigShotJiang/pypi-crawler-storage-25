def begins_with_same_char(word1,word2):
    """ to check if 2 words begins with the same char
    """
    return word1[:1]==word2[:1] and word1!=""