def smart_cost(a:str,b:str,proximate_dict):
    if a==b:
        return 0 # here no change needed
    elif b in proximate_dict.get(a,set()):
        return 0.5 # here we must change the cost , adjacent characters
    
    return 1  # here the normal cost 