import os
from .proximate_dict import get_proximate_dict
from .dict_infos import dict_extract
from .spell import spell
from .get_phonetic_dict import get_phonetic_dict

class SmartChecker:
    def __init__(self, lang='en', data_dir='data'):
        self.lang = lang
        self.data_dir = data_dir
        self.dictionary = None
        self.prox_dict = None
        self.phonetic_dict = None
        self._load_data()

    def _load_data(self):
        # Paths are relative to the project root (C:\Users\lenovo\NLP(Natural Langauge Processing)\SmartChecker)
        # But we should be careful about how we call it.
        # Assuming we are running from the SmartChecker directory or its parent.

        qwerty_path = os.path.join(self.data_dir, 'qwerty_graph.txt')
        if self.lang == 'en':
            dict_path = os.path.join(self.data_dir, 'words.txt')
        elif self.lang == 'fr':
            dict_path = os.path.join(self.data_dir, 'dictoinnaire_fr.txt')
        else:
            raise ValueError(f"Unsupported language: {self.lang}")

        self.prox_dict = get_proximate_dict(qwerty_path)
        self.dictionary = dict_extract(dict_path)
        self.phonetic_dict = get_phonetic_dict(self.dictionary)

    def check(self, word, k=6):
        if not word:
            return []
        candidates = spell(word.lower(), self.dictionary, self.phonetic_dict, k, self.prox_dict)
        return candidates

    def set_language(self, lang):
        if lang != self.lang:
            self.lang = lang
            self._load_data()
