import jellyfish
def verify_phonetic(word,phonetic_dict):
    """ verify if a word have the same phonetic in a dict 
    """
    code=jellyfish.metaphone(word)
    return phonetic_dict.get(code,[])
    