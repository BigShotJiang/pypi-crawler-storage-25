from .smart_distance_matrix import smart_distance_matrix
from .print_matrix import print_matrix
from .backtrace import backtrace
from .print_edits import print_edits
def smartMinDistance(word1:str,word2:str,proximate_dict):
    cache=smart_distance_matrix(word1,word2,proximate_dict)

    print_matrix(cache,word1,word2)

    edits=backtrace(cache,word1,word2)

    print_edits(word1,word2,edits,cache)
    return cache[len(word1)][len(word2)]
