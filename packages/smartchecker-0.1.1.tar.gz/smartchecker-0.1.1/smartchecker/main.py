from smartchecker.cli import cli
# from src.utils.gui import start_gui
from smartchecker.banner import print_gemini_banner

def main():
    print_gemini_banner()
    lang_choice = input("en or fr: ").strip().lower()
    cli(lang_choice)
