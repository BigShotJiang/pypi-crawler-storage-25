def print_matrix(cache,word1,word2):
    print(f"")
    print("     ","  ".join(word2))
    for i, row in enumerate(cache):
        if i ==0:
            print(' ',row)
        else:
            print(word1[i-1],row)