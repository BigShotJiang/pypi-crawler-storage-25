from distance_matrix import distance_matrix
from print_matrix import print_matrix
from print_edits import print_edits
from backtrace import backtrace
def minDistance(word1:str,word2:str):
    """ the min Distance function , prints the matrix also the edits required to correct the wrong word(word 1)
    Args:
        word1 (str): the wrong word
        word2 (str): the correct word
    Returns:
       returns the cache matrix for the min distance 
    """
    cache=distance_matrix(word1,word2)
    print_matrix(cache,word1,word2)
    edits=backtrace(cache,word1,word2)
    print_edits(word1,word2,edits,cache)
    
    return cache[len(word1)][len(word2)]