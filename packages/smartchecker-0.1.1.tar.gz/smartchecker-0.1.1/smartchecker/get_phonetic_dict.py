import jellyfish
def get_phonetic_dict(dictionary):
    """ get the phonetic dict , its a constraint in order to make the comparison more easy and make the minDistance algorithm more faster
    """
    phonetic_dict={}
    for word in dictionary:
        code=jellyfish.metaphone(word)
        if code not in phonetic_dict:
            phonetic_dict[code]=[]
        phonetic_dict[code].append(word)
    return phonetic_dict