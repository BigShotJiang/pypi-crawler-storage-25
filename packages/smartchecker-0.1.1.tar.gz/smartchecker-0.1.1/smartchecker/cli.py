import os
from .checker import SmartChecker

def cli(lang_choice):
    if lang_choice not in ['en', 'fr']:
        print("Invalid language choice!")
        return

    # Chemin absolu basé sur ce fichier
    current_dir = os.path.dirname(__file__)
    data_dir = os.path.join(current_dir, "data")  # smartchecker/data

    # Vérifier que le dossier existe
    if not os.path.exists(data_dir):
        print(f"Erreur : le dossier de données n'existe pas: {data_dir}")
        return

    checker = SmartChecker(lang=lang_choice, data_dir=data_dir)

    prompt = "enter your word to check!" if lang_choice == 'en' else "entrer votre mot:"
    print("you are going with english now!" if lang_choice == 'en' else "tu as choisit francais!")

    word = input(prompt)
    if not word:
        print("There is a problem! No word entered.")
        return

    candidates = checker.check(word)

    if not candidates:
        print("No candidates found.")
        return

    for word_checked, distance in candidates:
        print(f"{word_checked} --> {distance}.")

    correct_word, dist = candidates[0]
    if dist == 0:
        print("no change needed!" if lang_choice == 'en' else "pas de changement sur le mot.!")
    else:
        print(
            f"The correct word with the distance: {correct_word} --> {dist}."
            if lang_choice == 'en'
            else f"la correction avec le mot convenable et sa distance: {correct_word} --> {dist}."
        )
