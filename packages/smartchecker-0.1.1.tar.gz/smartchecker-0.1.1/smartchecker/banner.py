from pyfiglet import Figlet
from colorama import init, Style


def rgb(r, g, b):
    return f"\033[38;2;{r};{g};{b}m"

def lerp(a, b, t):
    return int(a + (b - a) * t)

# Define your palette here — easy to swap
COLORS = [
    (0xFF, 0x00, 0x88),  # hot pink
    (0x80, 0x00, 0xFF),  # purple
    (0x00, 0xC9, 0xFF),  # cyan
]

def gradient_color(t):
    n = len(COLORS) - 1
    seg = min(int(t * n), n - 1)
    s = (t * n) - seg
    r = lerp(COLORS[seg][0], COLORS[seg+1][0], s)
    g = lerp(COLORS[seg][1], COLORS[seg+1][1], s)
    b = lerp(COLORS[seg][2], COLORS[seg+1][2], s)
    return r, g, b


def print_gemini_banner():
    init(autoreset=True)

    f = Figlet(font='banner')
    ascii_text = f.renderText('SMART  CHECKER')
    lines = ascii_text.splitlines()
    total_lines = max(len(lines), 1)

    # Find max line width for horizontal gradient normalization
    max_width = max((len(line) for line in lines), default=1)

    for line_idx, line in enumerate(lines):
        output = ""
        for col_idx, ch in enumerate(line):
            if ch == '#':
                t_v = line_idx / total_lines
                t_h = col_idx / max_width
                t = t_v * 0.4 + t_h * 0.6
                r, g, b = gradient_color(t)
                output += rgb(r, g, b) + Style.BRIGHT + '█'
            else:
                output += ' '
        print(output + Style.RESET_ALL)

    spark = rgb(0x42, 0x85, 0xF4) + "◆" + Style.RESET_ALL
    label = "\033[38;2;160;160;190m" + "  Welcome to SmartChecker — your smart spelling assistant is ready." + Style.RESET_ALL
    print(f"\n{spark}{label}\n")

