def print_edits(word1,word2,edits,cache):
    print("number of edits:",cache[len(word1)][len(word2)])   
    for edit in reversed(edits):
        print(edit)