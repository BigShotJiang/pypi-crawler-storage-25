def distance_matrix(word1,word2):
    cache=[[float("inf")]*(len(word2)+1) for _ in range(len(word1)+1)] # here to fill the grid of the Distance
    for i in range(len(word1)+1): # here to fill the first column
            cache[i][0]=i
    for j in range(len(word2)+1): # here to fill the first row
            cache[0][j]=j
        # ---- fill the cache ---- # 
    for i in range(1,len(word1)+1):
        for j in range(1,len(word2)+1):
            if word1[i-1]==word2[j-1]:
                cache[i][j]=cache[i-1][j-1]
            else:
                cache[i][j]=1+min(
                        cache[i-1][j],# delete
                        cache[i][j-1],# insertion
                        cache[i-1][j-1] # replace
                    )
    return cache