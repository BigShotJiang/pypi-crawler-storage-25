def check_dict(word,dictionary):
    """ check dict

    Args:
        word (str): the word 
        dictionary (dict): the dictionary

    Returns:
        Bool: if the word in dict or not 
    """
    return word.lower in dictionary