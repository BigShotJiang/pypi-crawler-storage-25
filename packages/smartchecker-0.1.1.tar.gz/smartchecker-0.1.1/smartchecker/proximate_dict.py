import ast
# Load the qwerty graph
# here the qwerty graph is like the map of the keyboard
def get_proximate_dict(filename):
    with open(filename,'r',encoding='utf-8') as f:
        keyboard=ast.literal_eval(f.read())
        proximate_dict={}
        for key , neighbors in keyboard.items():
            proximate_dict[key]=set(neighbors.values())
            
        return proximate_dict
    
