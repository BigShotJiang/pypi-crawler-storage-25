import tkinter as tk
from tkinter import messagebox, ttk
from .checker import SmartChecker
import os

class SmartCheckerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart Checker")
        self.root.geometry("400x500")

        self.lang_var = tk.StringVar(value="en")

        # Determine data directory
        self.data_dir = 'SmartChecker/data'
        if not os.path.exists(self.data_dir):
            self.data_dir = 'data'

        self.checker = None
        self._initialize_checker()

        self._build_ui()

    def _initialize_checker(self):
        try:
            self.checker = SmartChecker(lang=self.lang_var.get(), data_dir=self.data_dir)
        except Exception as e:
            messagebox.showerror("Error", f"Could not load data: {e}")

    def _build_ui(self):
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Language Selection
        lang_frame = ttk.LabelFrame(main_frame, text="Language Selection", padding="5")
        lang_frame.pack(fill=tk.X, pady=5)

        ttk.Radiobutton(lang_frame, text="English", variable=self.lang_var, value="en", command=self._on_lang_change).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(lang_frame, text="French", variable=self.lang_var, value="fr", command=self._on_lang_change).pack(side=tk.LEFT, padx=5)

        # Input
        input_frame = ttk.Frame(main_frame, padding="5")
        input_frame.pack(fill=tk.X, pady=5)

        ttk.Label(input_frame, text="Enter Word:").pack(side=tk.LEFT)
        self.word_entry = ttk.Entry(input_frame)
        self.word_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self.word_entry.bind('<Return>', lambda e: self._check_word())

        # Check Button
        self.check_btn = ttk.Button(main_frame, text="Check Spell", command=self._check_word)
        self.check_btn.pack(pady=10)

        # Results
        result_frame = ttk.LabelFrame(main_frame, text="Suggestions", padding="5")
        result_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.result_list = tk.Listbox(result_frame)
        self.result_list.pack(fill=tk.BOTH, expand=True)

        self.status_label = ttk.Label(main_frame, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def _on_lang_change(self):
        self.status_label.config(text=f"Loading {self.lang_var.get()} dictionary...")
        self.root.update_idletasks()
        self._initialize_checker()
        self.status_label.config(text=f"Switched to {self.lang_var.get()}")

    def _check_word(self):
        word = self.word_entry.get().strip()
        if not word:
            return

        self.result_list.delete(0, tk.END)
        self.status_label.config(text="Checking...")
        self.root.update_idletasks()

        candidates = self.checker.check(word)

        if not candidates:
            self.result_list.insert(tk.END, "No candidates found.")
            self.status_label.config(text="Finished.")
            return

        for word_checked, dist in candidates:
            display_text = f"{word_checked} (dist: {dist})"
            self.result_list.insert(tk.END, display_text)

        if candidates[0][1] == 0:
            self.status_label.config(text="No change needed!")
        else:
            self.status_label.config(text=f"Top suggestion: {candidates[0][0]}")

def start_gui():
    root = tk.Tk()
    app = SmartCheckerGUI(root)
    root.mainloop()
