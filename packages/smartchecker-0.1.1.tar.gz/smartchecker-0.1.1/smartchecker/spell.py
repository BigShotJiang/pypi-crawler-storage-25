from .check_dict import check_dict
from .smartMinDistance import smartMinDistance
from .begins_with_same_char import begins_with_same_char
from .verfiy_phonetic import verify_phonetic

def spell(word,dictionary,phonetic_dict,k=1,proximate_dict=None):
    if check_dict(word,dictionary):
        return [(word,0)]

    candidates=[]
    phonetic_candidates=verify_phonetic(word,phonetic_dict)
    for w in phonetic_candidates:
        if abs(len(w)-len(word)) <= 2 and begins_with_same_char(word,w):
            dist=smartMinDistance(word,w,proximate_dict)
            candidates.append((w,dist))

    candidates.sort(key=lambda x: x[1])
    return candidates[:k]


