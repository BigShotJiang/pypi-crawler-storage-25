def backtrace(cache,word1,word2):
    edits=[]
    i,j=len(word1),len(word2)
    while i >0 or j>0:
        if i>0 and j>0 and word1[i-1]==word2[j-1]:
            i-=1
            j-=1
        elif i >0 and cache[i][j]==cache[i-1][j]+1:
            edits.append(f"Delete {word1[i-1]} from word1.")
            i-=1
        elif j >0 and cache[i][j]==cache[i][j-1]+1:
            edits.append(f"Insert {word2[j-1]} into word1")
            j-=1
        else:
            edits.append(f"Replace {word1[i-1]} with {word2[j-1]}.")
            j-=1
            i-=1
    
    return edits