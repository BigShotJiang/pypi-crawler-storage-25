def dict_extract(filename):
    with open(filename,'r',encoding='utf-8') as f:
        dict_lang={line.strip().lower() for line in f if line.strip()}

    return dict_lang

