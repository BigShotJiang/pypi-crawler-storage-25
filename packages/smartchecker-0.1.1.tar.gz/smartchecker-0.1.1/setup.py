from setuptools import setup, find_packages

setup(
    name="smartchecker",
    version="0.1.1",
    packages=find_packages(),
    include_package_data=True,  # include data files
    install_requires=["pyfiglet",
    "colorama",
    "jellyfish"],
    entry_points={
        "console_scripts": [
            "smartchecker=smartchecker.main:main",  # terminal command
        ]
    },
    package_data={
        "smartchecker": ["data/*.txt"],  # include all .txt in data folder
    },
    author="Amine",
    description="A smart spell checker with English/French support",
    python_requires=">=3.8",
)
