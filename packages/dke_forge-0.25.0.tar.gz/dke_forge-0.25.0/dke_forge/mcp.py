"""FastMCP server for DKE-Forge — 48 tools over ForgeClient.

Each ``@mcp.tool()`` function delegates to a ``ForgeClient`` method via
``asyncio.to_thread``, keeping the stdio JSON-RPC loop responsive while
the synchronous ``requests``-based client runs on a worker thread.

Configuration resolution order (matches CLI conventions, with MCP-specific
env var names):

1. Environment: ``FORGE_URL`` / ``FORGE_API_KEY``
2. Local config file: ``~/.config/dke-forge/config.json``
3. Built-in default URL; empty API key

Category tags are carried as a ``[Category]`` prefix in each tool's
description (the portable surface today — MCP annotations don't yet have a
formal ``category`` field).
"""

import asyncio
import os
import sys
from typing import Any, Dict, List, Optional, Union

from mcp.server.fastmcp import FastMCP

from dke_forge import config as _config
from dke_forge.client import ForgeClient, ForgeError


# -- Module state --------------------------------------------------------

_client: Optional[ForgeClient] = None


def _resolve_config():
    """Return ``(url, api_key, graph)`` resolved from env → config → default.

    ``graph`` is the X-Forge-Graph routing hint from the ``FORGE_GRAPH``
    env var (FG-96). ``None`` disables routing and the workspace's
    default_graph_id is used.
    """
    cfg = _config.load()
    url = os.environ.get("FORGE_URL") or cfg.get("url") or _config.DEFAULT_URL
    api_key = os.environ.get("FORGE_API_KEY") or cfg.get("api_key", "")
    graph = os.environ.get("FORGE_GRAPH") or cfg.get("graph") or None
    return url, api_key, graph


mcp = FastMCP("dke-forge")


# -- Foundation ----------------------------------------------------------

@mcp.tool()
async def forge_graph_stats() -> Dict[str, Any]:
    """[Foundation] Graph statistics — node/edge counts, language breakdown, last ingest."""
    return await asyncio.to_thread(_client.graph_stats)


# -- Navigation ----------------------------------------------------------

@mcp.tool()
async def forge_query_function(
    name: str,
    branch: Optional[str] = None,
    file: Optional[str] = None,
) -> Dict[str, Any]:
    """[Navigation] Look up a function by name (cross-language).

    Returns a BranchView envelope ``{name, branch_count, canonical_file?,
    branches: [...]}`` by default. Pass ``branch`` (16-char ``def_hash``) to
    narrow a multi-branch result to a single FunctionBranch object; pass
    ``file`` when the name is declared in multiple translation units."""
    return await asyncio.to_thread(_client.graph_function, name, branch, file)


@mcp.tool()
async def forge_callers_of(
    name: str,
    depth: int = 2,
    branch: Optional[str] = None,
    file: Optional[str] = None,
) -> Dict[str, Any]:
    """[Navigation] Callers of a function, transitively up to ``depth`` hops.

    Response carries ``branch_count`` so consumers detect multi-branch
    targets. Default returns the dedup-union of callers across every
    branch (callers are rarely branch-sensitive); pass ``branch`` to
    filter to a specific branch's callers only."""
    return await asyncio.to_thread(_client.graph_callers, name, depth, branch, file)


@mcp.tool()
async def forge_callees_of(
    name: str,
    depth: int = 2,
    branch: Optional[str] = None,
    file: Optional[str] = None,
) -> Dict[str, Any]:
    """[Navigation] Functions called by ``name``, transitively up to ``depth`` hops.

    Default returns a per-branch map ``callees_by_branch: {def_hash: [...]}``
    — callees genuinely differ per branch (e.g. ``nstime_get``'s five
    ``#if/#elif/#else`` alternates each call a different system-timing
    primitive). Pass ``branch`` to get a flat array for one branch."""
    return await asyncio.to_thread(_client.graph_callees, name, depth, branch, file)


@mcp.tool()
async def forge_depends_on(path: str) -> Dict[str, Any]:
    """[Navigation] Dependencies of a file or module path."""
    return await asyncio.to_thread(_client.graph_depends, path)


@mcp.tool()
async def forge_impact_analysis(
    name: str,
    change_type: str = "modify",
    branch: Optional[str] = None,
    file: Optional[str] = None,
) -> Dict[str, Any]:
    """[Navigation] Impact of changing a function. ``change_type``: modify | rename | remove.

    Default unions the reachable sets across every branch of ``name``
    for safety-side cascade analysis. Pass ``branch`` to analyze a
    single branch's cascade only."""
    return await asyncio.to_thread(_client.graph_impact, name, change_type, branch, file)


@mcp.tool()
async def forge_callgraph_reachable(
    name: str, via: Optional[str] = None
) -> List[Dict[str, Any]]:
    """[Navigation] Transitively reachable functions from an entry point.

    Optional ``via`` restricts traversal to an edge label (e.g. ``Implements``).
    Comma-separated list also accepted (e.g. ``Calls,UsesType``) — BFS unions
    over the listed edge types per FG-CODE-REASONING-LIBRARY Phase 3 step 3.
    """
    return await asyncio.to_thread(_client.graph_reachable, name, via)


@mcp.tool()
async def forge_find_implementers(name: str) -> List[Dict[str, Any]]:
    """[Navigation] All implementers / subclasses of a type or interface."""
    return await asyncio.to_thread(_client.graph_implementers, name)


# -- Architecture --------------------------------------------------------

@mcp.tool()
async def forge_dead_code(exclude_tests: bool = True) -> List[Dict[str, Any]]:
    """[Architecture] Functions with no incoming Calls edges. Test files excluded by default."""
    return await asyncio.to_thread(_client.graph_dead_code, exclude_tests)


@mcp.tool()
async def forge_subgraph(
    module: Optional[str] = None,
    type: Optional[str] = None,
    functions: Optional[Union[List[str], str]] = None,
    max_depth: Optional[int] = None,
) -> Dict[str, Any]:
    """[Architecture] Focused subgraph by module, type, or a list of function names.

    ``functions`` accepts either a list or a comma-joined string.
    """
    kwargs: Dict[str, Any] = {}
    if module is not None:
        kwargs["module"] = module
    if type is not None:
        kwargs["type"] = type
    if functions is not None:
        kwargs["functions"] = functions
    if max_depth is not None:
        kwargs["max_depth"] = max_depth
    return await asyncio.to_thread(_client.graph_subgraph, **kwargs)


# Wave 1 / FG-30 — Architecture Suite expansion (continues Architecture)

@mcp.tool()
async def forge_circular_deps(
    scope: Optional[str] = None,
    max_cycles: Optional[int] = None,
    max_length: Optional[int] = None,
) -> Dict[str, Any]:
    """[Architecture] Cycles in DependsOn + Includes (Tier 1).

    ``scope`` is ``"all"`` | ``"file"`` | ``"module"`` | ``"library"``.
    ``max_cycles`` / ``max_length`` cap the result on pathological graphs.
    """
    return await asyncio.to_thread(
        _client.analysis_circular_deps, scope, max_cycles, max_length,
    )


@mcp.tool()
async def forge_god_classes(
    threshold: Optional[int] = None,
) -> Dict[str, Any]:
    """[Architecture] Types with excessive outgoing edges (Tier 1).

    ``threshold`` sets the minimum combined outgoing degree (default 20).
    """
    return await asyncio.to_thread(_client.analysis_god_classes, threshold)


@mcp.tool()
async def forge_architecture_map(
    top_n: Optional[int] = None,
    damping: Optional[float] = None,
    max_iterations: Optional[int] = None,
    tolerance: Optional[float] = None,
) -> Dict[str, Any]:
    """[Architecture] Top-N most-central nodes by PageRank (Tier 2).

    ``damping`` must be in ``(0, 1)``. Defaults: α=0.85, 50 iter, 1e-6 tol.
    """
    return await asyncio.to_thread(
        _client.analysis_architecture_map,
        top_n, damping, max_iterations, tolerance,
    )


@mcp.tool()
async def forge_api_surface(
    module_id: Optional[int] = None,
    module_name: Optional[str] = None,
) -> Dict[str, Any]:
    """[Architecture] Auto-detected public boundary for a module (Tier 1).

    Pass ``module_id`` (uint64) or ``module_name``; 404 when not found.
    """
    return await asyncio.to_thread(
        _client.analysis_api_surface, module_id, module_name,
    )


@mcp.tool()
async def forge_abstractions(
    min_group_size: Optional[int] = None,
) -> Dict[str, Any]:
    """[Architecture] Candidate interfaces from shared method shapes (Tier 2).

    ``min_group_size`` must be ``>= 2`` (default 3).
    """
    return await asyncio.to_thread(
        _client.analysis_abstractions, min_group_size,
    )


@mcp.tool()
async def forge_module_topology() -> Dict[str, Any]:
    """[Architecture] High-level Module-Module dep graph with edge-count weights (Tier 1)."""
    return await asyncio.to_thread(_client.analysis_module_topology)


# -- Change Suite (Wave 2 / FG-32) ---------------------------------------

@mcp.tool()
async def forge_refactor_preview(
    symbol_name: str,
    new_name: str,
    kind: Optional[str] = None,
) -> Dict[str, Any]:
    """[Change] Preview the impact of renaming a symbol (Tier 1).

    Returns affected callers, tests, and files plus any rule conflicts
    triggered by the new name. ``kind`` is an optional ``NodeType`` filter
    (``"Function"`` | ``"Type"`` | ``"Variable"`` ...) when the symbol is
    ambiguous.
    """
    return await asyncio.to_thread(
        _client.change_refactor_preview, symbol_name, new_name, kind,
    )


@mcp.tool()
async def forge_breaking_change(
    symbol_name: str,
    new_return_type: str,
    new_param_types: List[str],
) -> Dict[str, Any]:
    """[Change] Analyze a function-signature change (Tier 1).

    ``new_param_types`` is an ordered list of parameter-type strings.
    Returns affected callers with per-caller mismatch descriptions,
    the breaking test set, and reasoner contradictions against the
    proposed signature.
    """
    return await asyncio.to_thread(
        _client.change_breaking_change,
        symbol_name, new_return_type, new_param_types,
    )


@mcp.tool()
async def forge_deprecation_path(
    symbol_name: str,
    kind: Optional[str] = None,
    max_depth: Optional[int] = None,
) -> Dict[str, Any]:
    """[Change] Staged deprecation plan — migrate-then-remove ordering (Tier 2).

    Walks the canonical reverse-dep edge set
    (``Calls + DependsOn + UsesType + InheritsFrom``) via the cascade
    reasoner. ``max_depth`` caps the closure (default 100; 0 = seed only).
    """
    return await asyncio.to_thread(
        _client.change_deprecation_path, symbol_name, kind, max_depth,
    )


@mcp.tool()
async def forge_risky_change(commit: str) -> Dict[str, Any]:
    """[Change] Risk score for a commit tag (Tier 2).

    Composite of thermal mean + pattern-drift rate + rule-violation rate
    across nodes tagged with the commit SHA. Returns ``score`` plus a
    ``breakdown`` with the three components and the node/rule/pattern
    violation lists.
    """
    return await asyncio.to_thread(_client.change_risky, commit)


@mcp.tool()
async def forge_commit_impact(commit: str) -> Dict[str, Any]:
    """[Change] Structural impact of a commit tag (Tier 1).

    Returns ``{commit_sha, touched_count, touched_node_ids,
    cascade_summary, contradictions}``. ``cascade_summary`` has
    ``total_direct``, ``total_transitive``, ``modules_affected``,
    ``files_affected``.
    """
    return await asyncio.to_thread(_client.change_commit_impact, commit)


@mcp.tool()
async def forge_review(
    commit: str,
    focus_area_top_n: Optional[int] = None,
) -> Dict[str, Any]:
    """[Change] Composite commit review (Tier 2).

    Wraps structural impact with pattern-alignment + rule-violation
    summaries and a ranked list of recommended focus areas.
    ``focus_area_top_n`` caps the focus-area list (default 5; 0 = unlimited).
    """
    return await asyncio.to_thread(
        _client.change_review, commit, focus_area_top_n,
    )


# -- Rules ---------------------------------------------------------------

@mcp.tool()
async def forge_rules() -> List[Dict[str, Any]]:
    """[Rules] List all configured validation rules."""
    return await asyncio.to_thread(_client.graph_rules)


@mcp.tool()
async def forge_check_rules(name: str) -> List[Dict[str, Any]]:
    """[Rules] Check a function against every rule; returns violations only."""
    return await asyncio.to_thread(_client.graph_check, name)


# -- Provenance ----------------------------------------------------------

@mcp.tool()
async def forge_contradictions() -> List[Dict[str, Any]]:
    """[Provenance] ForgeReasoner-detected contradictions in the current graph."""
    return await asyncio.to_thread(_client.graph_contradictions)


@mcp.tool()
async def forge_last_modified(name: str) -> Dict[str, Any]:
    """[Provenance] Last-commit tag for the named node."""
    return await asyncio.to_thread(_client.graph_last_modified, name)


@mcp.tool()
async def forge_provenance(
    edge_id: Optional[int] = None,
    node_id: Optional[int] = None,
    property: Optional[str] = None,
) -> Dict[str, Any]:
    """[Provenance] Sources + confidence for a claim.

    Pass either ``edge_id`` OR both ``node_id`` and ``property``.
    """
    return await asyncio.to_thread(
        _client.graph_provenance,
        edge_id=edge_id,
        node_id=node_id,
        property=property,
    )


@mcp.tool()
async def forge_reasoning_trace(
    query_type: str,
    name: Optional[str] = None,
    change_type: Optional[str] = None,
) -> Dict[str, Any]:
    """[Provenance] Inference trace for a derived query.

    ``query_type`` is ``"cascade"`` (requires ``name``) or ``"check_all"``.
    """
    return await asyncio.to_thread(
        _client.graph_reasoning_trace, query_type, name, change_type
    )


# -- Patterns ------------------------------------------------------------

@mcp.tool()
async def forge_patterns(name: str) -> List[Dict[str, Any]]:
    """[Patterns] Structural patterns similar to the given function."""
    return await asyncio.to_thread(_client.graph_patterns_similar, name)


@mcp.tool()
async def forge_pattern_catalog() -> List[Dict[str, Any]]:
    """[Patterns] Catalog of every learned structural pattern."""
    return await asyncio.to_thread(_client.graph_patterns)


@mcp.tool()
async def forge_pattern_detail(
    pattern_id: Optional[int] = None,
    name: Optional[str] = None,
) -> Dict[str, Any]:
    """[Patterns] Pattern detail — pass either ``pattern_id`` or ``name``."""
    if pattern_id is not None:
        return await asyncio.to_thread(_client.graph_pattern, pattern_id)
    if name is not None:
        return await asyncio.to_thread(_client.graph_pattern_by_name, name)
    raise ValueError("forge_pattern_detail requires pattern_id or name")


@mcp.tool()
async def forge_learn_patterns(
    similarity_threshold: Optional[float] = None,
    min_exemplars: Optional[int] = None,
) -> Dict[str, Any]:
    """[Patterns] Run pattern learning on the shared graph (admin only)."""
    return await asyncio.to_thread(
        _client.admin_learn_patterns, similarity_threshold, min_exemplars
    )


# -- Generation-prep -----------------------------------------------------

@mcp.tool()
async def forge_envelope(
    name: str, task: str, max_context: Optional[int] = None
) -> Dict[str, Any]:
    """[Generation-prep] Assemble a Forge envelope (grounding context) for a function + task."""
    return await asyncio.to_thread(_client.envelope, name, task, max_context)


# -- Ingestion -----------------------------------------------------------

@mcp.tool()
async def forge_declare(
    archive_bytes: bytes,
    content_type: str,
    commit: Optional[str] = None,
) -> Dict[str, Any]:
    """[Ingestion] Bulk-import a codebase as an archive (Phase-13).

    POSTs ``archive_bytes`` to ``/v1/declare/`` with one of the
    whitelisted archive ``content_type`` values: ``application/zip``,
    ``application/x-tar``, or ``application/x-tar+gzip``. The unified
    DARQ surface infers the granularity (whole-codebase) from the
    Root URL path.

    Returns ``{status_code, body}``. ``status_code=200`` means the
    archive ingested synchronously; ``status_code=202`` means the
    server spawned a worker — the body carries an ``op_id`` and
    ``status_path``; poll ``forge_query`` against
    ``/.forge/ops/<op_id>`` for progress.

    Replaces the legacy ``forge_scan`` + ``forge_scan_status`` +
    ``forge_ingest`` triple (Phase-13 sub-D, finding §12.3): one
    endpoint for any granularity, status polling via the unified
    ``/.forge/ops/`` facet rather than a one-off ``/v1/scan/:id`` URL.
    """
    return await asyncio.to_thread(
        _client.declare_archive, archive_bytes, content_type, commit)


# -- Reasoning (FG-CODE-REASONING-LIBRARY Phase 1) -----------------------
#
# R7 multi-hop coordinator chain DSL — the L0.5 reasoning surface that
# composes the 10-operator catalog into multi-hop reasoning programs.
# Phase 1 ships parse-only; operator dispatch lands at Phase 1 step 8 +
# Phases 2-8. Future siblings under this category will surface the
# individual L0.5 operators (`forge_reach_*`, `forge_flow_*`,
# `forge_effect_*`, `forge_type_*`, `forge_contract_check`,
# `forge_consistency_detect`) as the per-operator phases land.

@mcp.tool()
async def forge_reason_chain(
    entry: str,
    chain_text: str,
) -> Dict[str, Any]:
    """[Reasoning] Submit a chain DSL plan against ``entry``.

    Body is forge-native chain DSL source (Datalog-flavor named
    bindings per finding §11.1, dotted operator namespaces per §11.2,
    `as`-introduced filter element bindings per §11.3.1, hybrid
    infix + function-call predicates per §11.3.2). The grammar lives
    at ``bcm/findings/forge-code-reasoning-library.md`` §11.5;
    binding-validation scope rule in §11.6.

    Phase 1 is parse-only — the response is a ``CHAIN SUMMARY``
    block (let count, return shape, trace level, bound directives)
    with a Phase-1 status disclosure. Operator dispatch lands at
    Phase 1 step 8 + Phases 2-8.

    Returns ``{status_code, body}``. ``status_code=200`` carries the
    chain summary; ``status_code=400`` carries a ``<line>:<col>
    <message>`` parse-error prose with grammar pointers. Other
    non-ok statuses raise on the client side.

    Example (entry=``src/foo.c/main``, body)::

        let entries = reach.from start
        let cone    = reach.cone entries
        bound: depth=12 timeout=45s
        return (entries, cone)
    """
    return await asyncio.to_thread(
        _client.reason_chain, entry, chain_text)


@mcp.tool()
async def forge_audit_changes(
    changes_text: str,
) -> Dict[str, Any]:
    """[Reasoning] Forward-chain a proposed change set against rules.

    Body is forge-native change DSL source (per finding §12.2/§12.3/
    §12.5/§12.7 grammar — `add` / `remove` / `modify` statements with
    field bags, optional `as <name>` postfix, `set` partition for
    `modify`, edge endpoint `from=(...)/to=(...)` syntax for Edge
    statements, optional `# trace:` directive). 10 parse-error
    classes (§12.10 amendment included `IncompatibleVerbKind`); 2
    runtime classes (`EntityNotFound`, `AmbiguousEntityRef`).

    Bare-only path — the body carries the plan, the URL does NOT
    take an entity-path tail. Sibling of ``forge_contradictions_
    hypothetical`` (same body, different L0 surface).

    Returns ``{status_code, body}``. ``status_code=200`` carries the
    ``=== FORGE AUDIT CHANGES ===`` envelope (top-line tally + one
    ``CHANGE <name|echo>:`` block per input). ``status_code=400``
    carries parse-error or empty-body prose. Other non-ok raise.

    Example body::

        # trace: summary
        add Function name="HttpHandler" file="app/h.cpp" line=42 as h1
        modify Function name="oldName" file="app/h.cpp" set name="newName"
        add Calls from=(Function name="A") to=(Function name="B")
    """
    return await asyncio.to_thread(
        _client.audit_changes, changes_text)


@mcp.tool()
async def forge_contradictions_hypothetical(
    changes_text: str,
) -> Dict[str, Any]:
    """[Reasoning] Hypothetical contradictions a change set creates.

    Sibling of ``forge_audit_changes`` — same body grammar (change
    DSL per finding §12), same diagnostic surface. Banner reads
    ``=== FORGE HYPOTHETICAL CONTRADICTIONS ===`` and per-change
    inner content names ``contradictions:`` instead of
    ``violations:``.

    Graph-level contradictions (NO change set, current state only)
    use the legacy ``forge_contradictions`` tool per finding §10.6
    fork-δ-2 — that surface stays its own thing; this one is
    specifically for "what would *break* if I applied these
    changes" reasoning.

    Returns ``{status_code, body}``. Same status-code contract as
    ``forge_audit_changes`` — 200 envelope, 400 pass-through,
    non-400 non-ok raises.
    """
    return await asyncio.to_thread(
        _client.contradictions_hypothetical, changes_text)


@mcp.tool()
async def forge_reach_from(
    entity_path: str,
    via: Optional[str] = None,
) -> Dict[str, Any]:
    """[Reasoning] Forward transitive call-graph reachability from a seed.

    L0.5 promotion of ``forge_callgraph_reachable`` to the DARQ surface
    per FG-CODE-REASONING-LIBRARY Phase 2 (finding §4 row 1 — BFS over
    Calls edges). ``entity_path`` is the substrate-canonical entity
    path (e.g. ``src/foo.c/main`` or ``src/widget.py/init``). Optional
    ``via`` restricts traversal to a different edge type (e.g.
    ``Implements``) or a comma-separated set (e.g. ``Calls,UsesType``)
    — BFS unions over the listed types per Phase 3 step 3. Default is
    ``Calls``; unknown tokens in the list are silently skipped.

    Returns ``{status_code, body}`` — body is the prose manifest with
    one ``kind:name@file`` line per reachable node in BFS order
    (including the seed) and a ``reached_count=N`` footer. The header
    line names the seed and the comma-joined edge-type description so
    a 1-edge consumer sees byte-identical pre-step-3 output.
    """
    return await asyncio.to_thread(
        _client.code_reachability, entity_path, via)


@mcp.tool()
async def forge_reach_cone(
    entity_path: str,
    change_type: str = "modify",
) -> Dict[str, Any]:
    """[Reasoning] Bidirectional cone-of-influence cascade from a seed.

    L0.5 promotion of ``forge_impact_analysis`` to the DARQ surface
    per FG-CODE-REASONING-LIBRARY Phase 2 (finding §4 row 2 —
    Reachability bidirectional). ``entity_path`` is the substrate-
    canonical entity path; ``change_type`` selects cascade semantics
    (``modify`` | ``delete`` | ``rename``, default ``modify``).

    Returns ``{status_code, body}`` — body is a four-section prose
    envelope: ``directly_affected``, ``transitively_affected``,
    ``test_cases_affected``, ``files_to_update``. Each section
    carries its count and ID-sorted entries.
    """
    return await asyncio.to_thread(
        _client.code_cone, entity_path, change_type)


@mcp.tool()
async def forge_use_def(entity_path: str) -> Dict[str, Any]:
    """[Reasoning] Direct producers of values consumed at the seed.

    FG-CODE-REASONING-LIBRARY Phase 3 step 6 — `flow.use_def` operator
    over the L0 substrate at ``forge/flow.hpp``. Convention A canonical
    (finding §13.7.1): backward, one-hop, edge filter Calls + UsesType
    + HasParam. ``entity_path`` is the substrate-canonical entity path
    (e.g. ``src/foo.c/main``). Seed is excluded from the result.

    Returns ``{status_code, body}`` — body is prose with header line +
    per-reached-node ``kind:name (depth=N)`` lines + ``reached_count=N``
    footer.
    """
    return await asyncio.to_thread(_client.code_use_def, entity_path)


@mcp.tool()
async def forge_reaching_defs(entity_path: str) -> Dict[str, Any]:
    """[Reasoning] Transitive producer set reachable from the seed.

    FG-CODE-REASONING-LIBRARY Phase 3 step 6 — `flow.reaching_defs`
    operator over the L0 substrate. Convention A: backward, transitive,
    edge filter Calls + UsesType + HasParam. Same prose contract as
    ``forge_use_def`` — header + per-node lines + ``reached_count=N``.
    """
    return await asyncio.to_thread(_client.code_reaching_defs, entity_path)


@mcp.tool()
async def forge_live_vars(entity_path: str) -> Dict[str, Any]:
    """[Reasoning] Transitive consumer set downstream of the seed.

    FG-CODE-REASONING-LIBRARY Phase 3 step 6 — `flow.live_vars` operator
    over the L0 substrate. Convention A: forward, transitive, edge
    filter Calls + UsesType (HasParam excluded — a Function "has"
    parameters as structural members, not as downstream consumers). Same
    prose contract as ``forge_use_def``.
    """
    return await asyncio.to_thread(_client.code_live_vars, entity_path)


@mcp.tool()
async def forge_effects(entity_path: str) -> Dict[str, Any]:
    """[Reasoning] Forward effect-set propagation from a seed Function.

    FG-CODE-REASONING-LIBRARY Phase 5a — `effects` operator over the L0
    substrate at ``forge/effects.hpp``. Convention A: forward,
    transitive, edge filter Calls only (narrows from `forge_taint`'s
    Calls + UsesType + HasParam — effects propagate through control-
    transfer, not value-flow). Reads per-function
    ``Function.props["effects"]`` (open-set comma-separated string) and
    unions across the seed plus its forward Calls closure.

    **Phase 5a is source-of-truth-agnostic** per finding §15.1 Q15.4
    LOAD-BEARING: substrate reads the property and propagates; it does
    not classify functions. Phase 5b will tackle automatic
    classification.

    Returns ``{status_code, body}`` — body is prose with header (seed
    + edge-filter), ``effect_set:`` summary, per-reached-node
    ``kind:name (depth=N, contributed_effects=[...])`` lines, and
    ``reached_count=N`` + ``effect_set_count=M`` footer.
    """
    return await asyncio.to_thread(_client.code_effects, entity_path)


@mcp.tool()
async def forge_classify_effects() -> Dict[str, Any]:
    """[Reasoning] Run the effects classifier on the tenant graph.

    FG-CODE-REASONING-LIBRARY Phase 5b — explicit operator-trigger for
    ``forge::classifyEffects``. Resets every Function's ``effects`` prop
    to empty, applies the C-stdlib convention table (printf-family /
    malloc-family / setjmp / exit / pthread_create), then applies all
    current ``Rule`` graph nodes with ``action="Derive"`` and non-empty
    ``effects_to_set``. Last-write-wins per finding §16.6 Q16.2;
    full-rebuild idempotent per Q16.5. End-of-archive-ingest auto-fire
    wires this into ingest paths automatically; call this tool
    explicitly after declaring a new tenant Rule to apply it.

    Q16.4 amendment 2026-05-07: DECLARE-Rule auto-fire deferred to
    Phase 5c — call this tool after rule operations as the v1
    surface.

    Returns JSON ``{"writes_total": <int>}`` — the sum of convention
    writes + rule writes.
    """
    return await asyncio.to_thread(_client.classify_effects)


@mcp.tool()
async def forge_effects_classification(source_name: str) -> Dict[str, Any]:
    """[Reasoning] Per-Function effects introspection with attribution.

    FG-CODE-REASONING-LIBRARY Phase 5b — returns the named Function's
    current ``effects`` prop + best-effort source attribution
    (``"rule:<rule_name>"`` if any tenant Rule produces the same
    effects via name/file/props/edge match; ``"none"`` if effects is
    empty; ``"tenant_declare_or_convention"`` otherwise). Provenance
    tracking is out-of-scope per Q16.5 (full-rebuild model);
    attribution re-evaluates predicates at query time.

    Returns JSON ``{node_id, name, effects, source}``.
    """
    return await asyncio.to_thread(_client.effects_classification, source_name)


@mcp.tool()
async def forge_declare_rule(
    rule_name: str,
    target_kind: str = "Function",
    name_match: Optional[str] = None,
    file_match: Optional[str] = None,
    effects_to_set: Optional[List[str]] = None,
    action: str = "Derive",
    severity: str = "info",
    message: str = "",
    eager: bool = True,
) -> Dict[str, Any]:
    """[Rules] DECLARE a tenant Rule and auto-fire effects classification.

    FG-CODE-REASONING-LIBRARY Phase 5c — closes the Q16.4 step-3
    amendment deferral from Phase 5b. POSTs to
    ``/v1/declare/.forge/rules/<rule_name>`` over the §17.1 surgical
    carve-out (LOAD-BEARING) on the §7.1 read-only invariant.

    Rule body fields per finding §17.2 (canonical L0 synth corpus
    shape): ``target_kind`` (default "Function"), ``name_match``
    (glob against Node.name), ``file_match`` (glob against Node.file),
    ``effects_to_set`` (list of strings), ``action`` (default "Derive"
    — Phase 5b classifier only fires on Derive rules), ``severity``,
    ``message``, ``eager``. ``props_match`` and ``edge_match`` deferred
    to Phase 5e (rich condition grammar).

    After successful Rule node creation, the L1 handler auto-fires
    ``forge::classifyEffects`` over the tenant graph; the response
    carries ``classify_writes`` so the tenant sees the round-trip in
    one response.

    Returns JSON ``{rule_name, rule_node_id, op_id, classify_writes,
    status="declared"}``. Tier 3 Cycle.
    """
    return await asyncio.to_thread(
        _client.declare_rule, rule_name, target_kind, name_match, file_match,
        effects_to_set, action, severity, message, eager,
    )


@mcp.tool()
async def forge_amend_rule(
    rule_name: str,
    target_kind: str = "Function",
    name_match: Optional[str] = None,
    file_match: Optional[str] = None,
    effects_to_set: Optional[List[str]] = None,
    action: str = "Derive",
    severity: str = "info",
    message: str = "",
    eager: bool = True,
) -> Dict[str, Any]:
    """[Rules] AMEND an existing tenant Rule and auto-fire classification.

    FG-CODE-REASONING-LIBRARY Phase 5c — companion to
    ``forge_declare_rule``. POSTs to
    ``/v1/amend/.forge/rules/<rule_name>`` with the same canonical
    JSON body shape; the body fully replaces the rule's props
    (no patch semantics in v1).

    After successful Rule node update, the L1 handler auto-fires
    ``forge::classifyEffects`` (full-rebuild per Q16.5 — last-write-wins
    re-applies all current rules + convention table).

    Returns JSON ``{rule_name, rule_node_id, op_id, classify_writes,
    status="amended"}``. Tier 3 Cycle. 404 if the rule does not exist.
    """
    return await asyncio.to_thread(
        _client.amend_rule, rule_name, target_kind, name_match, file_match,
        effects_to_set, action, severity, message, eager,
    )


@mcp.tool()
async def forge_retire_rule(rule_name: str) -> Dict[str, Any]:
    """[Rules] RETIRE a tenant Rule and auto-fire classification.

    FG-CODE-REASONING-LIBRARY Phase 5c — companion to
    ``forge_declare_rule`` / ``forge_amend_rule``. POSTs to
    ``/v1/retire/.forge/rules/<rule_name>`` with an empty body.

    The L1 handler removes the Rule graph node and auto-fires
    ``forge::classifyEffects`` (full-rebuild per Q16.5; effects the
    rule had written are revoked because no provenance is tracked —
    the rebuild simply omits the gone rule).

    Returns JSON ``{rule_name, op_id, classify_writes,
    status="retired"}``. Tier 3 Cycle. 404 if the rule does not exist.
    """
    return await asyncio.to_thread(_client.retire_rule, rule_name)


@mcp.tool()
async def forge_taint(entity_path: str, label: str) -> Dict[str, Any]:
    """[Reasoning] Forward label-propagation BFS from a seed entity.

    FG-CODE-REASONING-LIBRARY Phase 4 — `taint` operator over the L0
    substrate at ``forge/taint.hpp``. Convention A: forward, transitive,
    edge filter Calls + UsesType + HasParam (HasParam INCLUDED — differs
    from ``forge_live_vars``'s exclusion; parameter binding IS the
    canonical channel for forward taint propagation per finding §14.1
    Q14.2). The ``label`` is the source classifier propagated unchanged
    to every reached node — semantics are caller-defined (e.g.
    ``"user_input"``, ``"untrusted"``); the L0.5 surface treats labels
    as opaque strings.

    Returns ``{status_code, body}`` — body is prose with header (seed
    + label + edge-filter description), per-reached-node
    ``kind:name (depth=N, label=L)`` lines, and ``reached_count=N``
    footer.
    """
    return await asyncio.to_thread(_client.code_taint, entity_path, label)


@mcp.tool()
async def forge_type_flow(
    entity_path: str, direction: str = "forward"
) -> Dict[str, Any]:
    """[Reasoning] Type-token propagation through the call graph.

    FG-CODE-REASONING-LIBRARY Phase 6 — `type_flow` operator over the L0
    substrate at ``forge/type_flow.hpp``. Substrate transit-only per
    finding §20.1 (classifier deferred to Phase 6b parallel-to-5a/5b).
    Reads type-tokens stamped on each node (``Function.props
    ["return_type"]``, ``Parameter.props["type_name"]``,
    ``Variable.props["type_name"]``, plus outgoing ``UsesType`` edges)
    and propagates through ``Calls + HasParam`` (§20.3 edge-set; same
    slot-level decomposition as Phase 4 Taint).

    ``direction`` is ``"forward"`` (default) or ``"backward"``;
    transitive in either direction. The ``unknown`` sentinel propagates
    through the chain when no source supplies a type-token (null-vs-
    escape-hatch distinction per §20.2 — explicit escape-hatch types
    like TS ``any`` / C ``void*`` / Python ``Any`` emit the real token,
    only null/absent props emit ``unknown``).

    Returns ``{status_code, body}`` — body is prose with header
    (selector + seed + direction + edge-filter + ``seed_types=[...]``),
    per-reached-node ``kind:name (depth=N, types=[...])`` lines, and
    ``reached_count=N`` footer.
    """
    return await asyncio.to_thread(_client.code_types, entity_path, direction)


@mcp.tool()
async def forge_refine(
    type_set: List[str], predicate: Dict[str, Any]
) -> Dict[str, Any]:
    """[Reasoning] Predicate-filter a type-token set.

    FG-CODE-REASONING-LIBRARY Phase 6 — `refine` operator over the L0
    substrate at ``forge/refinement.hpp``. Query-time post-processor over
    Type-flow output (or any type-token set) per finding §20.5; never
    bakes lattice into propagation. Closure §20.7 — no new grammar:
    reuses Phase 5e PropsMatch + set-membership + lattice composition.

    ``type_set`` is the input list of type-token strings. ``predicate``
    is a JSON predicate object with ``kind``:

    - ``"props_match"`` — applies PropsMatch grammar to the Type node
      that backs each token. Body: ``{"key": "...", "op":
      "Eq|NotEq|Contains|Exists|NotExists", "value": ...}``.
    - ``"set_membership"`` — token must equal one of ``allowed_types``.
      Body: ``{"allowed_types": ["..."]}``.
    - ``"lattice"`` — token's backing Type node must be reachable from
      one of ``lattice_anchors`` via ``lattice_edges`` (default
      ``{"InheritsFrom","Implements"}``). Body:
      ``{"lattice_anchors": [<uint64>], "lattice_edges": ["..."]}``.
    - ``"and"`` / ``"or"`` — boolean composition over ``children``.

    Returns ``{status_code, body}`` — body is prose with header
    (selector + ``input_count=N`` + ``predicate.kind=K``), one
    surviving token per line, and ``refined_count=N`` footer.
    """
    return await asyncio.to_thread(_client.code_refinement, type_set, predicate)


@mcp.tool()
async def forge_contract_check(
    entity_path: Optional[str] = None,
) -> Dict[str, Any]:
    """[Reasoning] Walk contract Rules and emit caller/callee violations.

    FG-CODE-REASONING-LIBRARY Phase 7 — `contract.check` operator over
    the L0 substrate at ``forge/contracts.hpp``. Substrate is thin-helper-
    only per finding §21.1: zero new graph state, zero new edge types,
    zero new node kinds. Composition over Phase 5e PropsMatch + Phase 5c
    Rule machinery + ``ForgeGraph::edgesTo`` (Calls only, hard-coded
    edge filter per §21.4).

    Pass ``entity_path=None`` (default) for a whole-graph scan: walks
    every Rule with non-empty ``contract_tag``, groups by tag, and
    emits a violation for every Calls edge whose callee-end matches
    its rule but the caller-end fails its paired rule. Pass an
    entity-path string to narrow the scan to that seed Function's
    incoming + outgoing Calls neighborhood (per §21.1 — caller
    discovery restricted to direct Calls edges of the seed).

    Contracts in Forge are **graph patterns over Rule nodes**, not
    symbolic effect predicates (per §21.6 — explicitly NOT the Eiffel
    / Liquid-types lineage). Tenants author contracts as paired Rules
    sharing a ``contract_tag``: one Rule's pattern matches the callee,
    the other's matches the caller. The substrate distinguishes them
    structurally rather than by named role (see :meth:`declare_rule`'s
    ``contract_tag`` parameter).

    Returns ``{status_code, body}`` — body is prose with header
    (whole-graph or seeded), ``tags_walked=[...]`` summary line,
    per-violation ``tag=... caller=... (rule:...) callee=...
    (rule:...)`` lines, and ``violation_count=N`` +
    ``tags_walked_count=K`` footer.
    """
    return await asyncio.to_thread(_client.code_contracts, entity_path)


@mcp.tool()
async def forge_effect_behavioral(
    entity_path: str, lens: Optional[str] = None
) -> Dict[str, Any]:
    """[Reasoning] Per-Function Behavioral analysis across four lenses.

    FG-CODE-REASONING-LIBRARY Phase 7 — `effect.behavioral` operator
    over the L0 substrate at ``forge/behavior.hpp``. Single dispatcher
    over four internal helpers per finding §21.2: Exceptions /
    Concurrency / Termination / Purity. Substrate is thin-helper-only
    (§21.1): zero new graph state, zero new node kinds, zero new edge
    types. Composition over Phase 5a ``computeEffects``, the existing
    Calls-graph BFS machinery, and per-Function props stamped by
    ingestors.

    ``entity_path`` is the seed Function — Behavioral is per-Function
    by construction (each function has its own behavioral fingerprint;
    whole-graph scan is not meaningful). ``lens`` selects which lens
    to populate; one of ``"exceptions"``, ``"concurrency"``,
    ``"termination"``, ``"purity"``, or ``"all"`` (default). Selecting
    a single lens emits only that lens's evidence section in the prose
    response.

    Lens semantics (per finding §21.2):

    - ``exceptions`` — does the seed (or its transitive Calls closure)
      throw? Reads ``Function.props["effects"]`` for the canonical
      "throwing" effect kind and rolls up.
    - ``concurrency`` — does the seed introduce concurrency primitives?
      Reads ``effects`` for "async" + the open-set ``Function.props
      ["concurrency_markers"]`` list (substrate is source-of-truth-
      agnostic per §15.1 Q15.4 — props are read, not classified).
    - ``termination`` — does the seed have a recursive cycle in its
      Calls closure? Direct (seed → seed) and transitive (seed → A →
      seed) recursion both detected. ``definitely_terminates=true``
      requires both: no cycle found AND every reached function
      analyzed.
    - ``purity`` — is the seed pure? Reads ``computeEffects(seed)``
      and checks against the tenant-declared pure allowlist
      (default ``{}`` — only the empty effect set is pure per
      §15.1 Q15.7's absence-is-not-purity rule).

    The lens envelope DOES NOT mirror LLVM FunctionAttributes per
    `feedback_dkeforge_no_imported_compiler_assumptions` — Forge's
    lens shape is graph-derived, reporting evidence from the graph
    rather than a flat compiler-frontend attribute set.

    Returns ``{status_code, body}`` — body is prose with header
    (seed + selected lens), per-lens ``[exceptions]`` / ``[concurrency]``
    / ``[termination]`` / ``[purity]`` evidence sections (each populated
    lens emits its own block; non-populated lenses are silently absent),
    and lens-specific evidence body (boolean rollups + node-id lists +
    marker sets).
    """
    return await asyncio.to_thread(_client.code_behavior, entity_path, lens)


# -- Meta ----------------------------------------------------------------

@mcp.tool()
async def forge_health() -> Dict[str, Any]:
    """[Meta] Server health — connectivity + version."""
    return await asyncio.to_thread(_client.health)


@mcp.tool()
async def forge_auth_verify() -> Dict[str, Any]:
    """[Meta] Verify the current API key is accepted by the server."""
    return await asyncio.to_thread(_client.auth_verify)


# -- Graphs (FG-96) ------------------------------------------------------
#
# Multi-graph CRUD — every workspace owns N graphs. The X-Forge-Graph
# header (set once via ``FORGE_GRAPH`` or on ``ForgeClient.__init__``)
# routes per-request reads/writes; the tools below manage the graph set
# itself.

@mcp.tool()
async def forge_list_graphs() -> Dict[str, Any]:
    """[Graphs] List every alive graph in the workspace + current default_graph_id."""
    return await asyncio.to_thread(_client.list_graphs)


@mcp.tool()
async def forge_create_graph(slug: str, name: str) -> Dict[str, Any]:
    """[Graphs] Create a new graph. Slug: [a-z0-9][a-z0-9-]{0,39}. Gated on LCN balance > 0."""
    return await asyncio.to_thread(_client.create_graph, slug, name)


@mcp.tool()
async def forge_get_graph(graph_id: str) -> Dict[str, Any]:
    """[Graphs] Fetch a single graph row by id."""
    return await asyncio.to_thread(_client.get_graph, graph_id)


@mcp.tool()
async def forge_rename_graph(
    graph_id: str,
    slug: Optional[str] = None,
    name: Optional[str] = None,
) -> Dict[str, Any]:
    """[Graphs] Rename a graph's slug and/or name. At least one of `slug`/`name` must be set."""
    return await asyncio.to_thread(_client.rename_graph, graph_id, slug, name)


@mcp.tool()
async def forge_delete_graph(
    graph_id: str,
    reassign_default_to: Optional[str] = None,
) -> Dict[str, Any]:
    """[Graphs] Soft-delete a graph. Pass `reassign_default_to` when deleting the current default."""
    return await asyncio.to_thread(
        _client.delete_graph, graph_id, reassign_default_to)


@mcp.tool()
async def forge_promote_default_graph(graph_id: str) -> Dict[str, Any]:
    """[Graphs] Set `tenants.default_graph_id` to the named graph."""
    return await asyncio.to_thread(_client.promote_default_graph, graph_id)


# -- Invitations (FG-API-INVITATION-RESEND + FG-API-INVITATION-PREVIEW) --
#
# Workspace invitation lifecycle. Resend re-triggers the email for a
# live invite without rotating the token (so accept-urls already shared
# remain valid); preview is public (no auth — the token IS the auth)
# and returns metadata so a caller can render workspace context BEFORE
# acting on the invite. Useful when an MCP consumer is helping with
# member-management workflow (e.g., "the invite I sent yesterday hasn't
# landed — can you resend it?").

@mcp.tool()
async def forge_invitation_resend(token: str) -> Dict[str, Any]:
    """[Invitations] Resend the invitation email for a live invite (token preserved).

    Recovery path for the "Resend outage / invitee can't find email"
    failure. Auth: workspace ManageMembers permission. Returns the
    invitation row + ``accept_url`` + ``email_sent``. 410 if revoked
    or expired, 409 if already accepted, 404 if token unknown.
    """
    return await asyncio.to_thread(_client.invitation_resend, token)


@mcp.tool()
async def forge_invitation_preview(token: str) -> Dict[str, Any]:
    """[Invitations] Public lookup-by-token returning invite metadata + state.

    No auth required (token is the auth). Always 200 with a ``state``
    field (``pending`` / ``revoked`` / ``accepted`` / ``expired``) so
    callers can render any state from one shape. Other fields:
    ``workspace_id``, ``workspace_name``, ``invitee_email``, ``role``,
    ``expires_at``. 404 only when the token is unknown.
    """
    return await asyncio.to_thread(_client.invitation_preview, token)


# -- Entry point ---------------------------------------------------------

def main():
    """Console entry for ``dke-forge-mcp``.

    Resolves config, performs a one-shot health check, then hands control
    to FastMCP's stdio loop. Exits non-zero on unreachable server.
    """
    global _client
    url, api_key, graph = _resolve_config()
    _client = ForgeClient(url, api_key, graph=graph)
    try:
        _client.health()
    except ForgeError as e:
        print(
            f"dke-forge-mcp: cannot reach forge-api at {url}: {e.message}\n"
            "  Set FORGE_URL / FORGE_API_KEY or run:\n"
            "    dke-forge config set url <url>\n"
            "    dke-forge config set api_key <key>",
            file=sys.stderr,
        )
        sys.exit(1)
    mcp.run()


if __name__ == "__main__":
    main()
