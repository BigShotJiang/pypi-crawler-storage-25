"""DKE-Forge — Code Intelligence Engine client."""

from dke_forge.client import ForgeClient, ForgeError

__version__ = "0.25.0"
__all__ = ["ForgeClient", "ForgeError", "__version__"]
