"""ForgeClient — REST client for the DKE-Forge API."""

import requests
from urllib.parse import quote


class ForgeError(Exception):
    """Error returned by the DKE-Forge API or connection layer."""

    def __init__(self, status_code, message):
        self.status_code = status_code
        self.message = message
        super().__init__(f"HTTP {status_code}: {message}" if status_code else message)


class ForgeClient:
    """Python client for the DKE-Forge code intelligence API.

    Usage::

        from dke_forge import ForgeClient

        client = ForgeClient("https://dke-forge.com", api_key="fga_...")
        stats = client.graph_stats()
    """

    def __init__(self, url, api_key="", timeout=120, graph=None):
        """Initialize the client.

        `graph` is an optional X-Forge-Graph routing hint — may be a
        graph id or a slug. When set, every request carries the header
        so the server routes to that graph instead of the workspace
        default. None disables routing (workspace default_graph_id is
        used).
        """
        self.url = url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.graph = graph

    def _headers(self):
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            h["X-Forge-Graph"] = self.graph
        return h

    def _request(self, method, path, timeout=None, **kwargs):
        try:
            r = requests.request(
                method,
                f"{self.url}{path}",
                headers=self._headers(),
                timeout=timeout or self.timeout,
                **kwargs,
            )
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if not r.ok:
            try:
                msg = r.json().get("error", r.text)
            except Exception:
                msg = r.text
            raise ForgeError(r.status_code, msg)
        if r.status_code == 204:
            return {}
        return r.json()

    def _get(self, path, params=None):
        return self._request("GET", path, params=params)

    def _post(self, path, data=None, timeout=None):
        return self._request("POST", path, json=data, timeout=timeout)

    def _delete(self, path, params=None):
        return self._request("DELETE", path, params=params)

    def _patch(self, path, data=None):
        return self._request("PATCH", path, json=data)

    @staticmethod
    def _encode(name):
        return quote(name, safe="")

    # -- Public endpoints --

    def health(self):
        return self._get("/health")

    def register(self, email, name):
        return self._post("/v1/register", {"email": email, "name": name})

    # -- Auth --

    def auth_verify(self):
        return self._post("/v1/auth/verify")

    # -- Graph queries (Tier 1: Oracle) --

    def graph_stats(self):
        return self._get("/v1/graph/stats")

    # FG-SUBSTRATE-MULTI-DEF-POLICY Slice 4: `branch` + `file` kwargs
    # plumb the forge-api BranchView qualifiers through to the MCP layer.
    # `branch` = 16-char def_hash → narrows a multi-branch response to
    # one branch. `file` = translation-unit path → narrows when a name
    # is declared in multiple TUs. Both are omitted from the query when
    # unset so pre-Slice-3b consumers see no change.
    def graph_function(self, name, branch=None, file=None):
        params = {}
        if branch is not None: params["branch"] = branch
        if file   is not None: params["file"]   = file
        return self._get(
            f"/v1/graph/function/{self._encode(name)}",
            params if params else None,
        )

    def graph_callers(self, name, depth=2, branch=None, file=None):
        params = {"depth": depth}
        if branch is not None: params["branch"] = branch
        if file   is not None: params["file"]   = file
        return self._get(f"/v1/graph/callers/{self._encode(name)}", params)

    def graph_callees(self, name, depth=2, branch=None, file=None):
        params = {"depth": depth}
        if branch is not None: params["branch"] = branch
        if file   is not None: params["file"]   = file
        return self._get(f"/v1/graph/callees/{self._encode(name)}", params)

    def graph_depends(self, name):
        return self._get(f"/v1/graph/depends/{self._encode(name)}")

    def graph_impact(self, name, change_type="modify", branch=None, file=None):
        params = {"change_type": change_type}
        if branch is not None: params["branch"] = branch
        if file   is not None: params["file"]   = file
        return self._get(
            f"/v1/graph/impact/{self._encode(name)}", params,
        )

    def graph_rules(self):
        return self._get("/v1/graph/rules")

    def graph_check(self, name):
        return self._post("/v1/graph/check", {"name": name})

    def graph_patterns(self):
        return self._get("/v1/graph/patterns")

    def graph_pattern(self, pattern_id):
        return self._get(f"/v1/graph/pattern/{pattern_id}")

    # -- Graph queries (Wave 0 extensions) --

    def graph_patterns_similar(self, name):
        return self._get(f"/v1/graph/patterns/similar/{self._encode(name)}")

    def graph_pattern_by_name(self, name):
        return self._get(f"/v1/graph/pattern/by-name/{self._encode(name)}")

    def graph_implementers(self, name):
        return self._get(f"/v1/graph/implementers/{self._encode(name)}")

    def graph_dead_code(self, exclude_tests=True):
        return self._get(
            "/v1/graph/dead-code",
            {"exclude_tests": 1 if exclude_tests else 0},
        )

    def graph_subgraph(self, **filters):
        """Focused subgraph export.

        Accepted filters: ``module`` (str), ``type`` (str), ``functions``
        (list or comma-joined str), ``max_depth`` (int). Unknown keys are
        silently dropped; the server enforces the real contract.
        """
        params = {}
        for key in ("module", "type", "max_depth"):
            if filters.get(key) is not None:
                params[key] = filters[key]
        fns = filters.get("functions")
        if fns:
            params["functions"] = ",".join(fns) if isinstance(fns, (list, tuple)) else fns
        return self._get("/v1/graph/subgraph", params or None)

    def graph_reachable(self, name, via=None):
        params = {"via": via} if via else None
        return self._get(f"/v1/graph/reachable/{self._encode(name)}", params)

    def graph_contradictions(self):
        return self._get("/v1/graph/contradictions")

    def graph_last_modified(self, name):
        return self._get(f"/v1/graph/last-modified/{self._encode(name)}")

    def graph_provenance(self, edge_id=None, node_id=None, property=None):
        """Provenance for either an edge or a node property.

        Must pass ``edge_id`` OR both ``node_id`` and ``property``.
        """
        if edge_id is not None:
            params = {"edge_id": edge_id}
        elif node_id is not None and property is not None:
            params = {"node_id": node_id, "property": property}
        else:
            raise ValueError(
                "graph_provenance requires either edge_id or (node_id + property)"
            )
        return self._get("/v1/graph/provenance", params)

    def graph_reasoning_trace(self, query_type, name=None, change_type=None):
        """Inference trace for a derived query.

        ``query_type`` is ``"cascade"`` or ``"check_all"``. Cascade requires
        ``name``; optional ``change_type`` defaults server-side to ``"modify"``.
        """
        params = {"query_type": query_type}
        if name is not None:
            params["name"] = name
        if change_type is not None:
            params["change_type"] = change_type
        return self._get("/v1/graph/reasoning-trace", params)

    # -- Envelope (Tier 2) --

    def envelope(self, name, task, max_context=None):
        body = {"name": name, "task": task}
        if max_context is not None:
            body["max_context"] = max_context
        return self._post("/v1/envelope", body)

    # -- Multi-graph management (FG-96) --

    def list_graphs(self):
        """List every alive graph in the workspace plus the current
        ``default_graph_id``."""
        return self._get("/v1/graphs")

    def create_graph(self, slug, name):
        """Create a new graph in the workspace. ``slug`` must match
        ``[a-z0-9][a-z0-9-]{0,39}``. Gated on a funded LCN balance.
        Returns the new GraphRow (dict)."""
        return self._post("/v1/graphs", {"slug": slug, "name": name})

    def get_graph(self, graph_id):
        return self._get(f"/v1/graphs/{self._encode(graph_id)}")

    def rename_graph(self, graph_id, slug=None, name=None):
        """Update slug and/or name. Pass either or both — at least one
        is required. Returns the updated GraphRow."""
        body = {}
        if slug is not None:
            body["slug"] = slug
        if name is not None:
            body["name"] = name
        return self._patch(f"/v1/graphs/{self._encode(graph_id)}", body)

    def delete_graph(self, graph_id, reassign_default_to=None):
        """Soft-delete a graph. If the target is the current default,
        pass ``reassign_default_to`` (another alive graph id in the same
        workspace) — the soft-delete fails with 409 otherwise."""
        params = None
        if reassign_default_to:
            params = {"reassign_default_to": reassign_default_to}
        return self._delete(
            f"/v1/graphs/{self._encode(graph_id)}", params=params)

    def promote_default_graph(self, graph_id):
        """Repoint ``tenants.default_graph_id`` to the named graph."""
        return self._post(
            f"/v1/graphs/{self._encode(graph_id)}/default")

    def declare_archive(self, archive_bytes, content_type, commit=None):
        """FG-DARQ-PHASE-13: bulk-import a codebase as an archive.

        POSTs the archive bytes to ``/v1/declare/`` (Root path) with the
        whitelisted archive Content-Type (one of ``application/zip``,
        ``application/x-tar``, ``application/x-tar+gzip``). Replaces the
        legacy ``scan`` + ``scan_status`` + ``ingest`` triple — the
        unified DARQ surface uses one endpoint for any granularity,
        with the granularity inferred from the URL path.

        Synchronous return for archives ≤ ~1 MiB: 200 with rich-Envelope
        ack. Async return for larger archives: 202 with ``op_id`` +
        ``status_path`` + ``entries_to_ingest``; poll
        :meth:`query_op_status(op_id)` until the response no longer
        carries ``status=in_progress``.

        ``commit`` (optional) rides as a URL query parameter and lands
        on the op_log row's ``commit_sha`` column for replay
        provenance.

        Returns ``{"status_code": int, "body": str}`` — body is prose
        per the Phase-12 wire format, not JSON.
        """
        url = f"{self.url}/v1/declare/"
        params = {"commit": commit} if commit else None
        headers = {"Content-Type": content_type}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        try:
            r = requests.post(url, data=archive_bytes, headers=headers,
                               params=params, timeout=300)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if not r.ok and r.status_code != 202:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def query_op_status(self, op_id):
        """FG-DARQ-PHASE-13: poll status for an in-flight or completed
        DARQ op via the unified ``/.forge/ops/<op_id>`` virtual-path
        facet (Phase 14 sub-B). Returns rich prose with ``status=ok |
        failed | in_progress``; for in_progress also carries
        ``progress=N% entities_seen=K of N elapsed_ms=T``.

        Replaces the legacy ``scan_status(scan_id)`` API. The scan_id
        was a per-process random hex; op_id is a per-tenant
        SQLite-AUTOINCREMENT integer that survives forge-api restarts.

        Returns ``{"status_code": int, "body": str}`` — body is prose.
        """
        url = f"{self.url}/v1/query/.forge/ops/{op_id}"
        headers = {"Content-Type": "text/plain"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        try:
            r = requests.post(url, data="", headers=headers, timeout=30)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def reason_chain(self, entry, chain_text):
        """FG-CODE-REASONING-LIBRARY Phase 1: submit a chain DSL plan
        against the given entry-entity-path.

        POSTs ``chain_text`` (chain DSL source per finding §11.5 grammar)
        to ``/v1/query/.forge/reason/chain/<entry>`` with
        Content-Type ``text/vnd.forge.chain``. The L1 handler parses
        the body and returns a chain summary as prose; Phase 1 is
        parse-only — operator dispatch lands at Phase 1 step 8 +
        Phases 2-8 (the 10-operator L0.5 catalog).

        ``entry`` is the entry-entity-path the chain reasons over
        (e.g. ``"src/foo.c/main"``). Leading ``/`` is stripped before
        URL construction; embedded ``/`` separators stay literal so
        the path-addressed wire format resolves the entity normally.

        ``chain_text`` is the chain DSL source — newline-separated
        statements per finding §11.5. The grammar lives in
        ``bcm/findings/forge-code-reasoning-library.md`` §11.5;
        binding-validation scope rule in §11.6.

        Returns ``{"status_code": int, "body": str}`` — body is
        prose. ``status_code=200`` carries the chain summary (one
        ``CHAIN SUMMARY`` block + Phase-1 status disclosure);
        ``status_code=400`` carries a ``formatError``-shaped parse
        error (``<line>:<col> <message>``) with grammar pointers.
        Other non-ok statuses raise ``ForgeError`` since they are
        auth/billing/rate-limit conditions the response body alone
        can't help the caller fix.
        """
        # Leading slash would produce `.../chain//src/...` — strip it
        # to keep the URL well-formed regardless of caller convention.
        entry = entry.lstrip("/")
        # `safe="/"` keeps path separators literal (the URL structure
        # IS the entity-path) while percent-encoding other unsafe
        # bytes (spaces, special chars in non-conventional names).
        url = f"{self.url}/v1/query/.forge/reason/chain/{quote(entry, safe='/')}"
        headers = {"Content-Type": "text/vnd.forge.chain"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        try:
            r = requests.post(url, data=chain_text, headers=headers,
                              timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        # 400 is the diagnostic surface — pass-through so the caller
        # (especially MCP consumers) reads the formatError prose
        # directly. Auth (401/403), rate limit (429), 5xx all raise
        # because their bodies are server-side conditions, not
        # tenant-actionable parser feedback.
        if r.status_code == 400:
            return {"status_code": r.status_code, "body": r.text}
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def audit_changes(self, changes_text):
        """FG-CODE-REASONING-LIBRARY Phase 1.5: forward-chain a
        proposed change set against the current rule catalog.

        POSTs ``changes_text`` (change DSL source per finding §12)
        to ``/v1/query/.forge/audit/changes`` with Content-Type
        ``text/vnd.forge.changes``. The L1 handler parses the body,
        resolves each statement against the graph, and renders an
        ``=== FORGE AUDIT CHANGES ===`` envelope (Q1.5.6 ε2 shape):
        a top-line tally plus one ``CHANGE <name|echo>:`` block per
        input change with ``resolution: <atom>`` and ``violations:
        ...`` inside. Skipped-on-not-found is explicit (``violations:
        skipped (entity not found)``), never silent.

        Bare-only path — change DSL bodies carry the *plan*, the URL
        does NOT take an entity-path tail. Sub-paths (e.g.
        ``/.forge/audit/changes/foo``) are rejected at L1 with 400.

        Returns ``{"status_code": int, "body": str}`` — body is prose.
        ``status_code=200`` carries the audit envelope; ``status_code
        =400`` carries either a ``change DSL parse error`` (10 parse
        classes per finding §12.3 / §12.5 / §12.7 / §12.10) or an
        empty-body usage prose. Other non-ok statuses raise
        ``ForgeError`` (415 wrong-CT, 405 wrong-verb, auth/billing).
        """
        url = f"{self.url}/v1/query/.forge/audit/changes"
        headers = {"Content-Type": "text/vnd.forge.changes"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        try:
            r = requests.post(url, data=changes_text, headers=headers,
                              timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        # 400 is the diagnostic surface — pass-through for parse-error
        # / empty-body prose. Auth/billing/415/405/5xx raise.
        if r.status_code == 400:
            return {"status_code": r.status_code, "body": r.text}
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def contradictions_hypothetical(self, changes_text):
        """FG-CODE-REASONING-LIBRARY Phase 1.5: detect contradictions
        a proposed change set would create against current graph state.

        Sibling of :meth:`audit_changes` — same body grammar (change
        DSL per finding §12), same Content-Type (``text/vnd.forge.
        changes``), same ε2 envelope shape, same diagnostic surface.
        Endpoint is ``/v1/query/.forge/contradictions/hypothetical``;
        the L1 banner reads ``=== FORGE HYPOTHETICAL CONTRADICTIONS
        ===`` and per-change inner content uses ``contradictions:``
        instead of ``violations:``.

        The bare ``/.forge/contradictions`` path (without the
        ``/hypothetical`` segment) intentionally returns nullopt at
        L1 → 404 listing. Graph-level contradictions (no change set)
        ship via the legacy ``GET /v1/graph/contradictions`` +
        ``forge_contradictions`` MCP tool per finding §10.6 fork-δ-2.

        Returns ``{"status_code": int, "body": str}``. Same status-
        code contract as :meth:`audit_changes` — 200 envelope, 400
        pass-through, non-400 non-ok raises.
        """
        url = f"{self.url}/v1/query/.forge/contradictions/hypothetical"
        headers = {"Content-Type": "text/vnd.forge.changes"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        try:
            r = requests.post(url, data=changes_text, headers=headers,
                              timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if r.status_code == 400:
            return {"status_code": r.status_code, "body": r.text}
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def code_reachability(self, entity_path, via=None):
        """FG-CODE-REASONING-LIBRARY Phase 2: forward transitive Calls
        closure (BFS) from a seed entity.

        POSTs to ``/v1/query/.forge/code/reachability/<entity_path>``
        with no body. Optional ``via`` swaps edge type or accepts a
        comma-separated list (e.g. ``Calls,UsesType``) — BFS unions
        over all listed types per Phase 3 step 3. Default ``Calls``;
        unknown tokens silently skipped. The L1 handler resolves the
        entity-path via
        ``readEntity``, runs ``ForgeGraph::reachableFrom``, and
        renders a prose manifest: header names the seed + edge type;
        body emits one ``kind:name@file`` line per node in BFS order
        (including the seed); footer carries ``reached_count=N``.

        Returns ``{"status_code": int, "body": str}`` — body is prose.
        ``200`` carries the manifest; ``400`` carries empty entity-
        path / unresolvable kind / malformed entity-path prose;
        ``404`` carries did-you-mean candidates when the seed isn't
        found. Non-400/404 non-ok statuses raise ``ForgeError``.
        """
        safe_path = quote(entity_path, safe="/")
        url = f"{self.url}/v1/query/.forge/code/reachability/{safe_path}"
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        params = {}
        if via:
            params["via"] = via
        try:
            r = requests.post(url, headers=headers, params=params,
                              timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if r.status_code in (400, 404):
            return {"status_code": r.status_code, "body": r.text}
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def code_cone(self, entity_path, change_type="modify"):
        """FG-CODE-REASONING-LIBRARY Phase 2: bidirectional cone-of-
        influence cascade from a seed entity.

        POSTs to ``/v1/query/.forge/code/cone/<entity_path>`` with no
        body. Optional ``change_type`` (``modify`` | ``delete`` |
        ``rename``, default ``modify``) swaps cascade semantics. The
        L1 handler resolves the seed via ``readEntity``, runs
        ``ForgeReasoner::analyzeCascade``, and renders a four-section
        prose envelope — ``directly_affected``,
        ``transitively_affected``, ``test_cases_affected``,
        ``files_to_update`` — each with a count and ID-sorted entries.

        Returns ``{"status_code": int, "body": str}`` — same status-
        code contract as :meth:`code_reachability` (200 manifest,
        400 usage/parse, 404 did-you-mean, others raise).
        """
        safe_path = quote(entity_path, safe="/")
        url = f"{self.url}/v1/query/.forge/code/cone/{safe_path}"
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        params = {"change_type": change_type}
        try:
            r = requests.post(url, headers=headers, params=params,
                              timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if r.status_code in (400, 404):
            return {"status_code": r.status_code, "body": r.text}
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def _code_flow_op(self, op_label, entity_path):
        """FG-CODE-REASONING-LIBRARY Phase 3 step 6: shared transport for
        the three flow.* operators (``code_use_def`` /
        ``code_reaching_defs`` / ``code_live_vars``). POSTs to
        ``/v1/query/.forge/code/<op_label>/<entity_path>`` with no body
        and no params; same prose-response contract as the Phase 2 DARQ
        wrappers — 200 manifest, 400 usage/parse, 404 did-you-mean,
        others raise.
        """
        safe_path = quote(entity_path, safe="/")
        url = f"{self.url}/v1/query/.forge/code/{op_label}/{safe_path}"
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        try:
            r = requests.post(url, headers=headers, timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if r.status_code in (400, 404):
            return {"status_code": r.status_code, "body": r.text}
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def code_use_def(self, entity_path):
        """FG-CODE-REASONING-LIBRARY Phase 3 step 6: direct producers of
        values consumed at the seed (Convention A: backward, one-hop;
        edge filter Calls + UsesType + HasParam).

        POSTs to ``/v1/query/.forge/code/use-def/<entity_path>`` with
        no body. Returns ``{status_code, body}`` — body is prose with
        header line + per-reached-node ``kind:name (depth=N)`` lines +
        ``reached_count=N`` footer. The seed is excluded from the result
        per Convention A.
        """
        return self._code_flow_op("use-def", entity_path)

    def code_reaching_defs(self, entity_path):
        """FG-CODE-REASONING-LIBRARY Phase 3 step 6: transitive set of
        producer entities reachable from the seed (Convention A:
        backward, transitive; edge filter Calls + UsesType + HasParam).

        POSTs to ``/v1/query/.forge/code/reaching-defs/<entity_path>``
        with no body. Same response contract as :meth:`code_use_def`.
        """
        return self._code_flow_op("reaching-defs", entity_path)

    def code_live_vars(self, entity_path):
        """FG-CODE-REASONING-LIBRARY Phase 3 step 6: transitive set of
        downstream consumer entities (Convention A: forward, transitive;
        edge filter Calls + UsesType — HasParam excluded by the
        directional asymmetry, since a Function "has" parameters as
        structural members not as downstream consumers).

        POSTs to ``/v1/query/.forge/code/live-vars/<entity_path>`` with
        no body. Same response contract as :meth:`code_use_def`.
        """
        return self._code_flow_op("live-vars", entity_path)

    def code_effects(self, entity_path):
        """FG-CODE-REASONING-LIBRARY Phase 5a: forward effect-set
        propagation from a seed Function (Convention A: forward,
        transitive; edge filter Calls only — narrows from
        :meth:`code_taint`'s Calls + UsesType + HasParam since effects
        propagate through control-transfer, not value-flow).

        POSTs to ``/v1/query/.forge/code/effects/<entity_path>`` with no
        body and no required query parameters. The substrate reads
        per-function ``Function.props["effects"]`` (open-set comma-
        separated string; absent = empty contribution) and unions across
        the seed plus its forward Calls closure.

        **Phase 5a is source-of-truth-agnostic** per finding §15.1
        Q15.4 LOAD-BEARING: substrate reads the property and propagates;
        it does not classify functions. Tenants populate the property
        via DECLARE; Phase 5b will tackle automatic classification.

        Returns ``{status_code, body}`` — body is prose with header
        (seed + edge-filter `Calls only`), an ``effect_set:`` summary
        line, per-reached-node ``kind:name (depth=N,
        contributed_effects=[...])`` lines, and ``reached_count=N`` +
        ``effect_set_count=M`` footer. Same status-code contract as
        :meth:`code_use_def`.
        """
        safe_path = quote(entity_path, safe="/")
        url = f"{self.url}/v1/query/.forge/code/effects/{safe_path}"
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        try:
            r = requests.post(url, headers=headers, timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if r.status_code in (400, 404):
            return {"status_code": r.status_code, "body": r.text}
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def classify_effects(self):
        """FG-CODE-REASONING-LIBRARY Phase 5b: explicit operator-trigger
        for the effects classifier.

        POSTs to ``/v1/flow/classify-effects`` with no body. Runs
        ``forge::classifyEffects`` on the tenant graph: resets all
        ``Function.props["effects"]`` to empty, then applies the C-stdlib
        convention table (printf-family / malloc-family / setjmp /
        exit / pthread_create), then applies all current ``Rule`` graph
        nodes with ``action="Derive"`` and non-empty ``effects_to_set``.
        Last-write-wins per finding §16.6 Q16.2; full-rebuild
        idempotent per Q16.5.
        End-of-archive-ingest auto-fire wires this into ingest paths;
        this method exists for explicit re-classify (e.g., after
        DECLAREing a new tenant Rule). Q16.4 amendment 2026-05-07:
        DECLARE-Rule auto-fire deferred to Phase 5c — POST this
        endpoint after rule operations as the v1 surface.

        Returns ``{"writes_total": <int>}`` JSON envelope; the int is
        the sum of convention writes + rule writes. Tier 1 Oracle.
        """
        url = f"{self.url}/v1/flow/classify-effects"
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        try:
            r = requests.post(url, headers=headers, timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return r.json()

    def effects_classification(self, source_name):
        """FG-CODE-REASONING-LIBRARY Phase 5b: per-Function effects
        introspection — current ``effects`` prop + best-effort
        attribution of the source.

        GETs ``/v1/flow/effects-classification?source_name=<name>`` and
        returns ``{node_id, name, effects, source}`` where ``source`` is
        ``"rule:<rule_name>"`` if any tenant Rule with non-empty
        ``effects_to_set`` matches the function and produces the same
        effects, ``"none"`` if effects is empty, or
        ``"tenant_declare_or_convention"`` otherwise. Provenance
        tracking is out-of-scope per Q16.5 (full-rebuild model);
        attribution re-evaluates predicates at query time.

        Tier 1 Oracle.
        """
        url = f"{self.url}/v1/flow/effects-classification"
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        params = {"source_name": source_name}
        try:
            r = requests.get(url, headers=headers, params=params, timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return r.json()

    def declare_rule(self, rule_name, target_kind="Function", name_match=None,
                     file_match=None, effects_to_set=None, action="Derive",
                     severity="info", message="", eager=True,
                     contract_tag=None):
        """FG-CODE-REASONING-LIBRARY Phase 5c: DECLARE a tenant Rule and
        auto-fire effects classification.

        POSTs to ``/v1/declare/.forge/rules/<rule_name>`` with a JSON
        body matching the canonical L0 synth corpus shape per finding
        §17.2. The §7.1 read-only invariant is surgically relaxed for
        this carve-out per §17.1 (LOAD-BEARING).

        ``effects_to_set`` may be a list of strings (canonical) or a
        comma-separated string; the L1 handler accepts both. Other
        rule fields default to the v1 minimum-anchor shape (per finding
        §16.3 D2 + §16.6 Q16.6 fixture canon).

        Phase 7 §21.3 addition: pass ``contract_tag`` to mark this Rule
        as one half of a contract pair. The substrate
        (``forge::checkContracts``) walks every Rule with non-empty
        ``contract_tag``, groups by tag, and treats every pairwise
        (R_callee, R_caller) within a tag as a contract pair. Two
        Rules sharing a tag form a contract; a third Rule on the same
        tag fans out as an LSP-style triple (every pairwise combination
        considered).

        After successful Rule node creation, the L1 handler auto-fires
        ``forge::classifyEffects`` over the tenant graph; the response
        carries ``classify_writes`` (the integer return from the
        classifier) so the tenant sees the round-trip in one response.

        Returns ``{rule_name, rule_node_id, op_id, classify_writes,
        status="declared"}``.

        Raises ``ForgeError(409, ...)`` on duplicate rule name; use
        :meth:`amend_rule` to update an existing rule, or
        :meth:`retire_rule` then :meth:`declare_rule` to recreate.
        """
        return self._rule_verb("declare", rule_name, target_kind, name_match,
                               file_match, effects_to_set, action, severity,
                               message, eager, contract_tag)

    def amend_rule(self, rule_name, target_kind="Function", name_match=None,
                   file_match=None, effects_to_set=None, action="Derive",
                   severity="info", message="", eager=True,
                   contract_tag=None):
        """FG-CODE-REASONING-LIBRARY Phase 5c: AMEND an existing tenant
        Rule and auto-fire effects classification.

        POSTs to ``/v1/amend/.forge/rules/<rule_name>`` with the same
        JSON body shape as :meth:`declare_rule` (including the Phase 7
        ``contract_tag`` field — see :meth:`declare_rule`). The body
        fully replaces the rule's props (no patch semantics in v1;
        tenants re-send the canonical shape).

        After successful Rule node update, the L1 handler auto-fires
        ``forge::classifyEffects`` (full-rebuild per Q16.5; tenant
        sees re-classified effects in ``classify_writes``).

        Returns ``{rule_name, rule_node_id, op_id, classify_writes,
        status="amended"}``.

        Raises ``ForgeError(404, ...)`` if the rule does not exist.
        """
        return self._rule_verb("amend", rule_name, target_kind, name_match,
                               file_match, effects_to_set, action, severity,
                               message, eager, contract_tag)

    def retire_rule(self, rule_name):
        """FG-CODE-REASONING-LIBRARY Phase 5c: RETIRE a tenant Rule and
        auto-fire effects classification.

        POSTs to ``/v1/retire/.forge/rules/<rule_name>`` with an empty
        body (the rule name lives in the URL; no body needed). The L1
        handler removes the Rule graph node and auto-fires
        ``forge::classifyEffects`` (full-rebuild per Q16.5 — effects
        the rule had written are revoked because no provenance is
        tracked; the rebuild simply omits the gone rule).

        Returns ``{rule_name, op_id, classify_writes, status="retired"}``.

        Raises ``ForgeError(404, ...)`` if the rule does not exist.
        """
        url = f"{self.url}/v1/retire/.forge/rules/{rule_name}"
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        try:
            r = requests.post(url, headers=headers, data="", timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return r.json()

    def _rule_verb(self, verb, rule_name, target_kind, name_match, file_match,
                   effects_to_set, action, severity, message, eager,
                   contract_tag=None):
        """Shared body builder + POST for declare_rule / amend_rule.
        Builds the canonical JSON envelope, sends it to the §17.1
        carve-out path, returns the parsed response.
        """
        import json as _json
        body = {
            "target_kind": target_kind,
            "name_match":  name_match,
            "file_match":  file_match,
            "effects_to_set": effects_to_set if effects_to_set is not None else [],
            "action":      action,
            "severity":    severity,
            "message":     message,
            "eager":       eager,
        }
        if contract_tag is not None:
            body["contract_tag"] = contract_tag
        url = f"{self.url}/v1/{verb}/.forge/rules/{rule_name}"
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        try:
            r = requests.post(url, headers=headers,
                              data=_json.dumps(body), timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return r.json()

    def code_taint(self, entity_path, label):
        """FG-CODE-REASONING-LIBRARY Phase 4: forward label-propagation
        BFS from a seed entity (Convention A: forward, transitive; edge
        filter Calls + UsesType + HasParam — HasParam INCLUDED, differs
        from :meth:`code_live_vars`'s exclusion).

        POSTs to ``/v1/query/.forge/code/taint/<entity_path>?label=<label>``
        with no body. The ``label`` is the source classifier propagated
        unchanged to every reached node — semantics are caller-defined
        (e.g. ``"user_input"``, ``"untrusted"``); the L0.5 surface treats
        labels as opaque strings.

        Returns ``{status_code, body}`` — body is prose with header
        (seed + label + edge-filter description), per-reached-node
        ``kind:name (depth=N, label=L)`` lines, and ``reached_count=N``
        footer. Same status-code contract as :meth:`code_use_def`
        (200 manifest, 400 usage/parse, 404 did-you-mean, others raise).
        """
        if not label:
            raise ValueError("code_taint requires a non-empty label")
        safe_path = quote(entity_path, safe="/")
        url = f"{self.url}/v1/query/.forge/code/taint/{safe_path}"
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        params = {"label": label}
        try:
            r = requests.post(url, headers=headers, params=params,
                              timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if r.status_code in (400, 404):
            return {"status_code": r.status_code, "body": r.text}
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def code_types(self, entity_path, direction="forward"):
        """FG-CODE-REASONING-LIBRARY Phase 6: type-token propagation through
        the call graph (substrate transit-only per finding §20.1; classifier
        deferred to Phase 6b). Reads per-node type-tokens
        (``Function.props["return_type"]``, ``Parameter.props["type_name"]``,
        ``Variable.props["type_name"]``, plus outgoing ``UsesType`` edges)
        and propagates through ``Calls + HasParam`` (§20.3 edge-set; same
        slot-level decomposition as Phase 4 Taint).

        POSTs to ``/v1/query/.forge/code/types/<entity_path>`` with optional
        ``?direction=forward|backward`` (default ``forward``); transitive in
        either direction.
        """
        if direction not in ("forward", "backward"):
            raise ValueError(
                "code_types direction must be 'forward' or 'backward'")
        safe_path = quote(entity_path, safe="/")
        url = f"{self.url}/v1/query/.forge/code/types/{safe_path}"
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        params = {"direction": direction}
        try:
            r = requests.post(url, headers=headers, params=params, timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if r.status_code in (400, 404):
            return {"status_code": r.status_code, "body": r.text}
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def code_contracts(self, entity_path=None):
        """FG-CODE-REASONING-LIBRARY Phase 7: caller/callee contract
        enforcement (substrate thin-helper-only per finding §21.1; cross-
        prop relations expressed as paired Rules joined by ``contract_tag``
        per §21.3; edge filter ``Calls``-only per §21.4).

        POSTs to ``/v1/query/.forge/code/contracts`` (whole-graph) or
        ``/v1/query/.forge/code/contracts/<entity_path>`` (seeded —
        narrows to the seed Function's incoming + outgoing Calls
        neighborhood). Pass ``entity_path=None`` for the whole-graph
        scan; pass an entity-path string for the seeded variant.

        The substrate walks every Rule with non-empty ``contract_tag``,
        groups by tag, and emits a violation envelope for every Calls
        edge where the callee-side rule matches but the caller-side
        rule fails. Empty-result discrimination follows §21.1: an
        empty ``tags_walked`` means "no contracts are declared",
        whereas a populated ``tags_walked`` with empty ``violations``
        means "every contract was satisfied across the walked Calls
        edges".

        Returns ``{status_code, body}`` — body is prose with header
        (whole-graph or seeded), ``tags_walked=[...]`` summary line,
        per-violation ``tag=... caller=... (rule:...) callee=...
        (rule:...)`` lines, and ``violation_count=N`` +
        ``tags_walked_count=K`` footer. Same status-code contract as
        :meth:`code_use_def` (200 manifest, 400 usage/parse, 404
        did-you-mean, others raise).
        """
        if entity_path is None:
            url = f"{self.url}/v1/query/.forge/code/contracts"
        else:
            safe_path = quote(entity_path, safe="/")
            url = f"{self.url}/v1/query/.forge/code/contracts/{safe_path}"
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        try:
            r = requests.post(url, headers=headers, timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if r.status_code in (400, 404):
            return {"status_code": r.status_code, "body": r.text}
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def code_behavior(self, entity_path, lens=None):
        """FG-CODE-REASONING-LIBRARY Phase 7: per-Function Behavioral
        analysis across four lenses (Exceptions / Concurrency /
        Termination / Purity). Substrate is single-dispatcher per
        finding §21.2; helpers compose Phase 5a ``computeEffects`` +
        cycle detection in the Calls subgraph (no new edge filters,
        no new graph kinds).

        POSTs to ``/v1/query/.forge/code/behavior/<entity_path>`` with
        optional ``?lens=<name>`` query parameter; valid lens names are
        ``"exceptions"``, ``"concurrency"``, ``"termination"``,
        ``"purity"``, or ``"all"`` (default). Selecting a single lens
        emits only that lens's evidence section in the prose response;
        ``"all"`` emits all four.

        Lens semantics (per finding §21.2):
          * ``exceptions`` — does the seed (or its transitive Calls
            closure) throw? Reads ``Function.props["effects"]`` for
            the canonical "throwing" effect kind.
          * ``concurrency`` — does the seed introduce concurrency
            primitives? Reads ``effects`` for "async" + the open-set
            ``Function.props["concurrency_markers"]`` list.
          * ``termination`` — does the seed have a recursive cycle in
            its Calls closure? Direct + transitive recursion both
            detected.
          * ``purity`` — is the seed pure? Reads
            ``computeEffects(seed)`` and checks against an optional
            tenant-declared pure allowlist (default ``{}`` — only the
            empty effect set is pure per §15.1 Q15.7).

        Returns ``{status_code, body}`` — body is prose with header
        (seed + selected lens), per-lens ``[lens-name]`` evidence
        sections (each populated lens emits its own block; non-
        populated lenses are silently absent), and lens-specific
        evidence body (boolean rollups + node-id lists + marker
        sets). Same status-code contract as :meth:`code_use_def`.
        """
        valid_lens = ("exceptions", "concurrency", "termination",
                      "purity", "all")
        if lens is not None and lens not in valid_lens:
            raise ValueError(
                "code_behavior lens must be one of: " +
                ", ".join(valid_lens))
        safe_path = quote(entity_path, safe="/")
        url = f"{self.url}/v1/query/.forge/code/behavior/{safe_path}"
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        params = {"lens": lens} if lens is not None else None
        try:
            r = requests.post(url, headers=headers, params=params,
                              timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if r.status_code in (400, 404):
            return {"status_code": r.status_code, "body": r.text}
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    def code_refinement(self, type_set, predicate):
        """FG-CODE-REASONING-LIBRARY Phase 6: predicate-filter a type-token
        set (post-processor over Type-flow output per finding §20.5).
        Predicate kinds reuse the Phase 5e PropsMatch grammar plus
        set-membership and lattice composition (closure §20.7 — no new
        grammar): ``props_match`` / ``set_membership`` / ``lattice`` /
        ``and`` / ``or``.

        POSTs to ``/v1/query/.forge/code/refinement`` (bare path) with
        JSON body ``{"type_set": [...], "predicate": {...}}``.
        ``type_set`` is the input list of type-token strings; ``predicate``
        is the predicate dict per the wire shape documented at the L1
        endpoint.
        """
        url = f"{self.url}/v1/query/.forge/code/refinement"
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            headers["X-Forge-Graph"] = self.graph
        body = {"type_set": list(type_set), "predicate": predicate}
        try:
            r = requests.post(url, headers=headers, json=body, timeout=60)
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if r.status_code in (400, 404):
            return {"status_code": r.status_code, "body": r.text}
        if not r.ok:
            raise ForgeError(r.status_code, r.text)
        return {"status_code": r.status_code, "body": r.text}

    # -- Analysis / Architecture suite (Wave 1 / FG-30) --

    def analysis_circular_deps(self, scope=None, max_cycles=None, max_length=None):
        """Cycles in DependsOn + Includes edges.

        ``scope`` is ``"all"`` (default, server-side) | ``"file"`` |
        ``"module"`` | ``"library"``. ``max_cycles`` / ``max_length`` cap
        the result to keep responses bounded on pathological graphs.
        """
        params = {}
        if scope is not None:
            params["scope"] = scope
        if max_cycles is not None:
            params["max_cycles"] = max_cycles
        if max_length is not None:
            params["max_length"] = max_length
        return self._get("/v1/analysis/circular-deps", params or None)

    def analysis_god_classes(self, threshold=None):
        """Types whose combined outgoing degree exceeds ``threshold``."""
        params = {"threshold": threshold} if threshold is not None else None
        return self._get("/v1/analysis/god-classes", params)

    def analysis_architecture_map(
        self,
        top_n=None,
        damping=None,
        max_iterations=None,
        tolerance=None,
    ):
        """Top-N most-central nodes by PageRank.

        ``damping`` must be in ``(0, 1)`` (enforced server-side).
        """
        params = {}
        if top_n is not None:
            params["top_n"] = top_n
        if damping is not None:
            params["damping"] = damping
        if max_iterations is not None:
            params["max_iterations"] = max_iterations
        if tolerance is not None:
            params["tolerance"] = tolerance
        return self._get("/v1/analysis/architecture-map", params or None)

    def analysis_api_surface(self, module_id=None, module_name=None):
        """Auto-detected public boundary for a module.

        Must pass exactly one of ``module_id`` (uint64) or
        ``module_name``. Server returns 404 when the module is not found.
        """
        if module_id is not None:
            params = {"module_id": module_id}
        elif module_name is not None:
            params = {"module_name": module_name}
        else:
            raise ValueError(
                "analysis_api_surface requires module_id or module_name"
            )
        return self._get("/v1/analysis/api-surface", params)

    def analysis_abstractions(self, min_group_size=None):
        """Candidate interfaces from shared method shapes.

        ``min_group_size`` must be ``>= 2`` (enforced server-side).
        """
        params = (
            {"min_group_size": min_group_size}
            if min_group_size is not None else None
        )
        return self._get("/v1/analysis/abstractions", params)

    def analysis_module_topology(self):
        """Module-Module dependency graph with edge-count weights."""
        return self._get("/v1/analysis/module-topology")

    # -- Change suite (Wave 2 / FG-32) --

    def change_refactor_preview(self, symbol_name, new_name, kind=None):
        """Preview the impact of renaming a symbol (Oracle / Tier 1).

        Returns the affected callers, tests, and files plus any rule
        conflicts triggered by the proposed name. ``kind`` is an optional
        ``NodeType`` name filter (``"Function"`` | ``"Type"`` |
        ``"Variable"`` ...) used when the symbol is ambiguous.
        """
        body = {"symbol_name": symbol_name, "new_name": new_name}
        if kind is not None:
            body["kind"] = kind
        return self._post("/v1/change/refactor-preview", body)

    def change_breaking_change(self, symbol_name, new_return_type, new_param_types):
        """Signature-change impact analysis (Oracle / Tier 1).

        ``new_param_types`` is an ordered list of parameter-type strings.
        Returns affected callers with per-caller mismatch descriptions,
        the breaking test set, and any contradictions surfaced by the
        reasoner against the proposed signature.
        """
        body = {
            "symbol_name": symbol_name,
            "new_return_type": new_return_type,
            "new_param_types": list(new_param_types),
        }
        return self._post("/v1/change/breaking-change", body)

    def change_deprecation_path(self, symbol_name, kind=None, max_depth=None):
        """Staged deprecation plan — migrate-then-remove ordering (Envelope / Tier 2).

        Walks the canonical reverse-dep edge set
        (``Calls + DependsOn + UsesType + InheritsFrom``) via
        ``ForgeReasoner::analyzeCascade`` to compute a per-depth
        migration plan. ``max_depth`` caps the closure (default 100;
        0 = target only). ``kind`` is an optional ``NodeType`` filter.
        """
        body = {"symbol_name": symbol_name}
        if kind is not None:
            body["kind"] = kind
        if max_depth is not None:
            body["max_depth"] = max_depth
        return self._post("/v1/change/deprecation-path", body)

    def change_risky(self, commit):
        """Risk score for a commit tag (Envelope / Tier 2).

        Composite of thermal mean + pattern-drift rate + rule-violation
        rate across the nodes tagged with the commit SHA. Returns
        ``{score, breakdown, touched_*, rule_violations, pattern_violations}``
        where each ``pattern_violations`` entry is
        ``{touched_node_id, drifted_pattern_id}``.
        """
        return self._get("/v1/change/risky", {"commit": commit})

    def change_commit_impact(self, commit):
        """Structural impact of a commit tag (Oracle / Tier 1).

        Returns ``{commit_sha, touched_count, touched_node_ids,
        cascade_summary, contradictions}`` — cascade_summary has
        ``total_direct``, ``total_transitive``, ``modules_affected``,
        ``files_affected``.
        """
        return self._get("/v1/change/commit-impact", {"commit": commit})

    def change_review(self, commit, focus_area_top_n=None):
        """Composite commit review (Envelope / Tier 2).

        Wraps ``change_commit_impact`` with pattern-alignment +
        rule-violation summaries and a ranked list of recommended focus
        areas. ``focus_area_top_n`` caps the focus-area list (default 5;
        0 = unlimited).
        """
        params = {"commit": commit}
        if focus_area_top_n is not None:
            params["focus_area_top_n"] = focus_area_top_n
        return self._get("/v1/change/review", params)

    # -- Invitations (FG-API-INVITATION-RESEND + FG-API-INVITATION-PREVIEW) --
    #
    # Workspace invitation lifecycle endpoints. Resend re-triggers the
    # email for a live invite without rotating the token (so accept-urls
    # already shared remain valid); preview is a public lookup-by-token
    # for UI rendering before the user clicks Accept. Pairs with
    # forge-api 0.20.0.

    def invitation_resend(self, token):
        """Resend the invitation email for a live invite (token preserved).

        Recovery path for the "Resend outage / invitee can't find email"
        failure mode. Auth: workspace member with ManageMembers
        permission (owner or admin in practice). Returns the same shape
        as create — invitation row + ``accept_url`` + ``email_sent``.

        Status semantics mirror Accept: 410 if revoked or expired, 409
        if already accepted, 404 if the token doesn't exist or belongs
        to another workspace (we deliberately don't leak existence
        cross-tenant).
        """
        return self._post(f"/v1/invitations/{self._encode(token)}/resend")

    def invitation_preview(self, token):
        """Public lookup-by-token returning invite metadata for UI rendering.

        No auth required — the token IS the auth, same posture as the
        accept endpoint. Always returns 200 with a ``state`` field
        (``pending`` / ``revoked`` / ``accepted`` / ``expired``) so the
        UI caller can render a single shape across all states; 404 only
        when the token is unknown. Other fields: ``workspace_id``,
        ``workspace_name``, ``invitee_email``, ``role``, ``expires_at``.
        ``invited_by`` user_id is deliberately omitted (PII not useful
        to UI).
        """
        return self._get(f"/v1/invitations/{self._encode(token)}/preview")

    # -- Admin --

    def admin_create_tenant(self, name, tier=None):
        body = {"name": name}
        if tier is not None:
            body["tier"] = tier
        return self._post("/v1/admin/tenants", body)

    def admin_list_tenants(self):
        return self._get("/v1/admin/tenants")

    def admin_revoke_tenant(self, tenant_id):
        return self._delete(f"/v1/admin/tenants/{tenant_id}")

    def admin_learn_patterns(self, similarity_threshold=None, min_exemplars=None):
        body = {}
        if similarity_threshold is not None:
            body["similarity_threshold"] = similarity_threshold
        if min_exemplars is not None:
            body["min_exemplars"] = min_exemplars
        return self._post("/v1/admin/patterns/learn", body or None)
