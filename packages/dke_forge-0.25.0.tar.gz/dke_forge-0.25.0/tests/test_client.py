"""Tests for ForgeClient — REST client for the DKE-Forge API."""

import json
import pytest
from unittest.mock import patch, MagicMock

from dke_forge.client import ForgeClient, ForgeError


def _mock_response(status=200, json_data=None, text=""):
    resp = MagicMock()
    resp.ok = 200 <= status < 400
    resp.status_code = status
    resp.json.return_value = json_data or {}
    resp.text = text
    return resp


class TestHeaders:
    def test_auth_header_present(self):
        client = ForgeClient("https://dke-forge.com", "fga_test123")
        h = client._headers()
        assert h["Authorization"] == "Bearer fga_test123"
        assert h["Content-Type"] == "application/json"

    def test_auth_header_absent_when_no_key(self):
        client = ForgeClient("https://dke-forge.com")
        h = client._headers()
        assert "Authorization" not in h


class TestURLConstruction:
    @patch("dke_forge.client.requests.request")
    def test_trailing_slash_stripped(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"status": "ok"})
        client = ForgeClient("https://dke-forge.com/", "key")
        client.health()
        url = mock_req.call_args[0][1]
        assert url == "https://dke-forge.com/health"

    @patch("dke_forge.client.requests.request")
    def test_function_name_encoded(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        client = ForgeClient("https://dke-forge.com", "key")
        client.graph_function("MyClass::method")
        url = mock_req.call_args[0][1]
        assert "MyClass%3A%3Amethod" in url

    @patch("dke_forge.client.requests.request")
    def test_function_with_template(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        client = ForgeClient("https://dke-forge.com", "key")
        client.graph_function("vector<int>")
        url = mock_req.call_args[0][1]
        assert "vector%3Cint%3E" in url


class TestHTTPMethods:
    @patch("dke_forge.client.requests.request")
    def test_health_is_get(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"status": "ok"})
        ForgeClient("http://localhost", "k").health()
        assert mock_req.call_args[0][0] == "GET"

    @patch("dke_forge.client.requests.request")
    def test_register_is_post(self, mock_req):
        mock_req.return_value = _mock_response(
            status=201, json_data={"api_key": "fga_x"}
        )
        ForgeClient("http://localhost", "").register("a@b.com", "Test")
        assert mock_req.call_args[0][0] == "POST"
        body = mock_req.call_args[1]["json"]
        assert body == {"email": "a@b.com", "name": "Test"}

    @patch("dke_forge.client.requests.request")
    def test_revoke_is_delete(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"revoked": True})
        ForgeClient("http://localhost", "k").admin_revoke_tenant("t1")
        assert mock_req.call_args[0][0] == "DELETE"

    @patch("dke_forge.client.requests.request")
    def test_callers_passes_depth(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_callers("fn", depth=5)
        assert mock_req.call_args[1]["params"] == {"depth": 5}

    @patch("dke_forge.client.requests.request")
    def test_impact_passes_change_type(self, mock_req):
        mock_req.return_value = _mock_response(json_data={})
        ForgeClient("http://localhost", "k").graph_impact("fn", "remove")
        assert mock_req.call_args[1]["params"] == {"change_type": "remove"}

    # -- FG-SUBSTRATE-MULTI-DEF-POLICY Slice 4: branch + file qualifiers --

    @patch("dke_forge.client.requests.request")
    def test_function_no_qualifiers_sends_no_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={})
        ForgeClient("http://localhost", "k").graph_function("fn")
        assert mock_req.call_args[1].get("params") is None

    @patch("dke_forge.client.requests.request")
    def test_function_branch_in_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={})
        ForgeClient("http://localhost", "k").graph_function(
            "fn", branch="4c373c25a9e2b1f8")
        assert mock_req.call_args[1]["params"] == {"branch": "4c373c25a9e2b1f8"}

    @patch("dke_forge.client.requests.request")
    def test_function_file_qualifier_in_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={})
        ForgeClient("http://localhost", "k").graph_function(
            "fn", file="src/fn.c")
        assert mock_req.call_args[1]["params"] == {"file": "src/fn.c"}

    @patch("dke_forge.client.requests.request")
    def test_function_both_qualifiers_in_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={})
        ForgeClient("http://localhost", "k").graph_function(
            "fn", branch="aabbccdd00112233", file="src/fn.c")
        assert mock_req.call_args[1]["params"] == {
            "branch": "aabbccdd00112233", "file": "src/fn.c"}

    @patch("dke_forge.client.requests.request")
    def test_callers_branch_coexists_with_depth(self, mock_req):
        mock_req.return_value = _mock_response(json_data={})
        ForgeClient("http://localhost", "k").graph_callers(
            "fn", depth=3, branch="4c373c25a9e2b1f8")
        assert mock_req.call_args[1]["params"] == {
            "depth": 3, "branch": "4c373c25a9e2b1f8"}

    @patch("dke_forge.client.requests.request")
    def test_callees_branch_coexists_with_depth(self, mock_req):
        mock_req.return_value = _mock_response(json_data={})
        ForgeClient("http://localhost", "k").graph_callees(
            "fn", branch="deadbeefcafef00d")
        assert mock_req.call_args[1]["params"] == {
            "depth": 2, "branch": "deadbeefcafef00d"}

    @patch("dke_forge.client.requests.request")
    def test_impact_branch_coexists_with_change_type(self, mock_req):
        mock_req.return_value = _mock_response(json_data={})
        ForgeClient("http://localhost", "k").graph_impact(
            "fn", "remove", branch="789bebff7a0e1234")
        assert mock_req.call_args[1]["params"] == {
            "change_type": "remove", "branch": "789bebff7a0e1234"}


class TestRequestBody:
    @patch("dke_forge.client.requests.request")
    def test_envelope_body(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"envelope_text": ""})
        ForgeClient("http://localhost", "k").envelope("fn", "add timeout", 50)
        body = mock_req.call_args[1]["json"]
        assert body == {"name": "fn", "task": "add timeout", "max_context": 50}

    @patch("dke_forge.client.requests.request")
    def test_envelope_omits_max_context_when_none(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"envelope_text": ""})
        ForgeClient("http://localhost", "k").envelope("fn", "task")
        body = mock_req.call_args[1]["json"]
        assert "max_context" not in body


    # FG-DARQ-PHASE-13 sub-D: ingest test retired alongside the legacy
    # client method. The Phase-13 `declare_archive` test cluster lives
    # in TestPhase13DarqArchive below.


class TestErrorHandling:
    @patch("dke_forge.client.requests.request")
    def test_401_raises_forge_error(self, mock_req):
        mock_req.return_value = _mock_response(
            status=401, json_data={"error": "Invalid API key"}
        )
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "bad").graph_stats()
        assert exc.value.status_code == 401
        assert "Invalid API key" in exc.value.message

    @patch("dke_forge.client.requests.request")
    def test_404_raises_forge_error(self, mock_req):
        mock_req.return_value = _mock_response(
            status=404, json_data={"error": "No function found: xyz"}
        )
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "k").graph_function("xyz")
        assert exc.value.status_code == 404

    @patch("dke_forge.client.requests.request")
    def test_non_json_error_uses_text(self, mock_req):
        resp = MagicMock()
        resp.ok = False
        resp.status_code = 500
        resp.json.side_effect = ValueError("no json")
        resp.text = "Internal Server Error"
        mock_req.return_value = resp
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "k").health()
        assert "Internal Server Error" in exc.value.message

    @patch("dke_forge.client.requests.request")
    def test_connection_error(self, mock_req):
        import requests
        mock_req.side_effect = requests.ConnectionError("refused")
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost:1", "k").health()
        assert exc.value.status_code == 0
        assert "Cannot connect" in exc.value.message

    @patch("dke_forge.client.requests.request")
    def test_timeout_error(self, mock_req):
        import requests
        mock_req.side_effect = requests.Timeout("timed out")
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "k").health()
        assert exc.value.status_code == 0
        assert "timed out" in exc.value.message


# -- Wave 0 extensions --


class TestWave0GraphQueries:
    @patch("dke_forge.client.requests.request")
    def test_patterns_similar(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_patterns_similar("myFn")
        url = mock_req.call_args[0][1]
        assert url.endswith("/v1/graph/patterns/similar/myFn")
        assert mock_req.call_args[0][0] == "GET"

    @patch("dke_forge.client.requests.request")
    def test_pattern_by_name_encodes(self, mock_req):
        mock_req.return_value = _mock_response(json_data={})
        ForgeClient("http://localhost", "k").graph_pattern_by_name("ns::Name")
        url = mock_req.call_args[0][1]
        assert "ns%3A%3AName" in url
        assert "/v1/graph/pattern/by-name/" in url

    @patch("dke_forge.client.requests.request")
    def test_implementers(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_implementers("Renderer")
        assert mock_req.call_args[0][1].endswith(
            "/v1/graph/implementers/Renderer"
        )

    @patch("dke_forge.client.requests.request")
    def test_dead_code_default_excludes_tests(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_dead_code()
        assert mock_req.call_args[1]["params"] == {"exclude_tests": 1}

    @patch("dke_forge.client.requests.request")
    def test_dead_code_include_tests(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_dead_code(exclude_tests=False)
        assert mock_req.call_args[1]["params"] == {"exclude_tests": 0}

    @patch("dke_forge.client.requests.request")
    def test_subgraph_joins_functions(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"nodes": [], "edges": []}
        )
        ForgeClient("http://localhost", "k").graph_subgraph(
            functions=["live", "caller"], max_depth=0
        )
        params = mock_req.call_args[1]["params"]
        assert params["functions"] == "live,caller"
        assert params["max_depth"] == 0

    @patch("dke_forge.client.requests.request")
    def test_subgraph_module_filter(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"nodes": [], "edges": []}
        )
        ForgeClient("http://localhost", "k").graph_subgraph(module="render")
        params = mock_req.call_args[1]["params"]
        assert params == {"module": "render"}

    @patch("dke_forge.client.requests.request")
    def test_subgraph_accepts_string_functions(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"nodes": [], "edges": []}
        )
        ForgeClient("http://localhost", "k").graph_subgraph(functions="a,b")
        assert mock_req.call_args[1]["params"]["functions"] == "a,b"

    @patch("dke_forge.client.requests.request")
    def test_subgraph_no_filters(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"nodes": [], "edges": []}
        )
        ForgeClient("http://localhost", "k").graph_subgraph()
        assert mock_req.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.request")
    def test_reachable_basic(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_reachable("caller")
        assert mock_req.call_args[0][1].endswith("/v1/graph/reachable/caller")
        assert mock_req.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.request")
    def test_reachable_with_via(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_reachable(
            "caller", via="Implements"
        )
        assert mock_req.call_args[1]["params"] == {"via": "Implements"}

    @patch("dke_forge.client.requests.request")
    def test_contradictions(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_contradictions()
        assert mock_req.call_args[0][1].endswith("/v1/graph/contradictions")

    @patch("dke_forge.client.requests.request")
    def test_last_modified(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"name": "live", "entries": []}
        )
        ForgeClient("http://localhost", "k").graph_last_modified("live")
        assert mock_req.call_args[0][1].endswith("/v1/graph/last-modified/live")

    @patch("dke_forge.client.requests.request")
    def test_provenance_edge(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"found": True})
        ForgeClient("http://localhost", "k").graph_provenance(edge_id=42)
        assert mock_req.call_args[1]["params"] == {"edge_id": 42}

    @patch("dke_forge.client.requests.request")
    def test_provenance_node_property(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"found": True})
        ForgeClient("http://localhost", "k").graph_provenance(
            node_id=7, property="signature"
        )
        params = mock_req.call_args[1]["params"]
        assert params == {"node_id": 7, "property": "signature"}

    def test_provenance_missing_args_raises(self):
        client = ForgeClient("http://localhost", "k")
        with pytest.raises(ValueError):
            client.graph_provenance()
        with pytest.raises(ValueError):
            client.graph_provenance(node_id=1)  # property missing

    @patch("dke_forge.client.requests.request")
    def test_reasoning_trace_cascade(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"query_type": "cascade", "steps": []}
        )
        ForgeClient("http://localhost", "k").graph_reasoning_trace(
            "cascade", name="live", change_type="rename"
        )
        params = mock_req.call_args[1]["params"]
        assert params == {
            "query_type": "cascade",
            "name": "live",
            "change_type": "rename",
        }

    @patch("dke_forge.client.requests.request")
    def test_reasoning_trace_check_all(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"query_type": "check_all", "steps": []}
        )
        ForgeClient("http://localhost", "k").graph_reasoning_trace("check_all")
        assert mock_req.call_args[1]["params"] == {"query_type": "check_all"}


class TestPhase13DarqArchive:
    """FG-DARQ-PHASE-13 sub-D: legacy `scan` + `scan_status` + `ingest`
    triple retired in favour of `declare_archive` + `query_op_status`.

    The wire format also changed shape: archive bytes ride as the
    request body (binary, with archive Content-Type), responses are
    prose (rich Envelope) not JSON, and the methods return
    ``{status_code, body}`` instead of a parsed JSON dict.
    """

    @patch("dke_forge.client.requests.post")
    def test_declare_archive_zip_sync_200(self, mock_post):
        # Synchronous 200 response — the rich-Envelope ack body.
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "// === FORGE ARCHIVE DECLARE ===\n// path: /\n"
        mock_post.return_value = mock_resp
        archive = b"PK\x03\x04..."
        result = ForgeClient("http://localhost", "k").declare_archive(
            archive, "application/zip", commit="deadbeef")
        assert result["status_code"] == 200
        assert "FORGE ARCHIVE DECLARE" in result["body"]
        # POST hit /v1/declare/ with the archive bytes + commit URL param.
        assert mock_post.call_args[0][0].endswith("/v1/declare/")
        assert mock_post.call_args[1]["data"] == archive
        assert mock_post.call_args[1]["params"] == {"commit": "deadbeef"}
        assert mock_post.call_args[1]["headers"]["Content-Type"] == \
            "application/zip"

    @patch("dke_forge.client.requests.post")
    def test_declare_archive_async_202(self, mock_post):
        # 202 Accepted shape — async path; tenant polls status_path.
        mock_resp = MagicMock()
        mock_resp.ok = False  # 202 is not in the requests.ok=True range
        mock_resp.status_code = 202
        mock_resp.text = "op_id=42\nstatus_path=/v1/query/.forge/ops/42\n"
        mock_post.return_value = mock_resp
        archive = b"PK\x03\x04..." * 1000  # large-ish
        result = ForgeClient("http://localhost", "k").declare_archive(
            archive, "application/x-tar")
        assert result["status_code"] == 202
        assert "op_id=42" in result["body"]
        # No commit param when not supplied.
        assert mock_post.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.post")
    def test_query_op_status(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "op_id=42 op_type=DECLARE path=/\nstatus=ok\n"
        mock_post.return_value = mock_resp
        result = ForgeClient("http://localhost", "k").query_op_status(42)
        assert result["status_code"] == 200
        assert "status=ok" in result["body"]
        assert mock_post.call_args[0][0].endswith("/v1/query/.forge/ops/42")


# -- FG-CODE-REASONING-LIBRARY Phase 1 step 7: chain DSL client method --


class TestReasonChain:
    """``ForgeClient.reason_chain`` wraps the
    ``POST /v1/query/.forge/reason/chain/<entry>`` endpoint with
    Content-Type ``text/vnd.forge.chain``. Wire format and grammar
    locked at finding §11; binding-validation scope rule at §11.6.
    Phase 1 is parse-only — operator dispatch lands at step 8.
    """

    @patch("dke_forge.client.requests.post")
    def test_reason_chain_happy_path_200(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "200 OK — Chain parsed successfully\n\n"
            "CHAIN SUMMARY\nlet bindings  : 1\nreturn        : x\n")
        mock_post.return_value = mock_resp
        chain = "let x = reach.from origin\nreturn x\n"
        result = ForgeClient("http://localhost", "k").reason_chain(
            "src/foo.c/main", chain)
        assert result["status_code"] == 200
        assert "CHAIN SUMMARY" in result["body"]
        # URL: entry-path slashes preserved literal (path-addressed wire
        # format); the chain DSL rides as the request body verbatim.
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/reason/chain/src/foo.c/main")
        assert mock_post.call_args[1]["data"] == chain
        # Content-Type is locked at finding §11.4.4 — vendor subtype
        # outside the standard code/prose/archive whitelist.
        assert mock_post.call_args[1]["headers"]["Content-Type"] == \
            "text/vnd.forge.chain"
        assert mock_post.call_args[1]["headers"]["Authorization"] == "Bearer k"

    @patch("dke_forge.client.requests.post")
    def test_reason_chain_parse_error_400_passthrough(self, mock_post):
        # 400-with-prose is the diagnostic surface for chain parse
        # errors. Pass-through (NOT raise) so the caller — particularly
        # MCP consumers — reads the formatError shape directly.
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 400
        mock_resp.text = (
            "400 Bad Request — chain parse error\n\n"
            "2:8 unknown operator `bogus.op` (not in L0.5 catalog)\n")
        mock_post.return_value = mock_resp
        chain = "let x = bogus.op foo\nreturn x\n"
        result = ForgeClient("http://localhost", "k").reason_chain(
            "src/foo.c/main", chain)
        assert result["status_code"] == 400
        assert "chain parse error" in result["body"]
        # Specifically: 2:8 line:col format from forge::chain::formatError.
        assert "2:8" in result["body"]
        assert "bogus.op" in result["body"]

    @patch("dke_forge.client.requests.post")
    def test_reason_chain_strips_leading_slash_from_entry(self, mock_post):
        # Caller convention is forgiving: a leading "/" on entry is
        # stripped so `.../chain//src/...` (double slash) never appears.
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "200 OK"
        mock_post.return_value = mock_resp
        ForgeClient("http://localhost", "k").reason_chain(
            "/src/foo.c/main", "let x = reach.from f\nreturn x\n")
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/reason/chain/src/foo.c/main")

    @patch("dke_forge.client.requests.post")
    def test_reason_chain_url_encodes_unsafe_chars(self, mock_post):
        # Path separators stay literal (URL structure IS the entity-
        # path), but unsafe bytes within a segment percent-encode so
        # weird names — spaces, special chars — survive transit.
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "200 OK"
        mock_post.return_value = mock_resp
        ForgeClient("http://localhost", "k").reason_chain(
            "src/has space/main", "let x = reach.from f\nreturn x\n")
        url = mock_post.call_args[0][0]
        # `/` separators preserved; space encoded as %20.
        assert "/v1/query/.forge/reason/chain/src/has%20space/main" in url

    @patch("dke_forge.client.requests.post")
    def test_reason_chain_raises_on_auth_403(self, mock_post):
        # Non-400 non-ok statuses (auth, rate, 5xx) raise ForgeError.
        # The response body for these is a server-side condition the
        # caller can't fix from the prose alone — surfacing as an
        # exception keeps the diagnostic surface dedicated to parse
        # errors. 403 is the realistic case (tier-1 tenant attempting
        # a Tier::Oracle endpoint without billing).
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 403
        mock_resp.text = "Forbidden: insufficient tier"
        mock_post.return_value = mock_resp
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "k").reason_chain(
                "src/foo.c/main", "let x = reach.from f\nreturn x\n")
        assert exc.value.status_code == 403

    @patch("dke_forge.client.requests.post")
    def test_reason_chain_emits_x_forge_graph_when_set(self, mock_post):
        # The X-Forge-Graph routing hint flows through every method —
        # including methods that bypass `_request` because of the
        # custom Content-Type. Pinning here so a workspace-default-
        # graph regression doesn't slip through.
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "200 OK"
        mock_post.return_value = mock_resp
        c = ForgeClient("http://localhost", "k", graph="featurex")
        c.reason_chain("src/foo.c/main",
                       "let x = reach.from f\nreturn x\n")
        assert mock_post.call_args[1]["headers"]["X-Forge-Graph"] == \
            "featurex"


# -- FG-CODE-REASONING-LIBRARY Phase 1.5 step 6: change DSL endpoints --


class TestAuditChanges:
    """``ForgeClient.audit_changes`` wraps the bare-only
    ``POST /v1/query/.forge/audit/changes`` endpoint with
    Content-Type ``text/vnd.forge.changes``. Wire format and grammar
    locked at finding §12; ε2 envelope at §12.6; 10 parse-error
    classes at §12.10. Phase 1.5 ships the resolver + executor
    end-to-end (not parse-only — Phase 1.5's substrate predates
    this client method via L0 step 4 + L1 step 5).
    """

    @patch("dke_forge.client.requests.post")
    def test_audit_changes_happy_path_200(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "200 OK — Change set audited\n\n"
            "=== FORGE AUDIT CHANGES ===\n"
            "1 changes proposed, 1 resolved\n"
            "CHANGE h1:\n  resolution: pre-add\n  violations: 0\n")
        mock_post.return_value = mock_resp
        body = ('add Function name="HttpHandler" file="app/h.cpp" '
                'as h1\n')
        result = ForgeClient("http://localhost", "k").audit_changes(body)
        assert result["status_code"] == 200
        assert "FORGE AUDIT CHANGES" in result["body"]
        # Bare-only path — no entry-path tail. Pinning the URL shape
        # so a regression that wires audit_changes against the
        # path-addressed `/.forge/reason/chain/<entry>` shape gets
        # caught here.
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/audit/changes")
        assert mock_post.call_args[1]["data"] == body
        assert mock_post.call_args[1]["headers"]["Content-Type"] == \
            "text/vnd.forge.changes"
        assert mock_post.call_args[1]["headers"]["Authorization"] == "Bearer k"

    @patch("dke_forge.client.requests.post")
    def test_audit_changes_parse_error_400_passthrough(self, mock_post):
        # 400 is the diagnostic surface — pass-through (NOT raise) so
        # the caller (especially MCP consumers) reads the change-DSL
        # parse-error prose verbatim.
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 400
        mock_resp.text = (
            "400 Bad Request — change DSL parse error\n\n"
            "1:8 unknown kind `Frobozz` (see §12 grammar)\n")
        mock_post.return_value = mock_resp
        body = 'add Frobozz name="bogus" file="f.cpp"\n'
        result = ForgeClient("http://localhost", "k").audit_changes(body)
        assert result["status_code"] == 400
        assert "change DSL parse error" in result["body"]
        # `<line>:<col>` shape from forge::change_dsl::formatError —
        # mirrors chain DSL's formatError exactly per §12.10.
        assert "1:8" in result["body"]
        assert "Frobozz" in result["body"]

    @patch("dke_forge.client.requests.post")
    def test_audit_changes_empty_body_400_passthrough(self, mock_post):
        # Empty body has no plan to audit — L1 returns 400 with the
        # `Change DSL body is empty` usage prose. The 400-passthrough
        # contract means the empty-body case is also tenant-readable
        # without an exception unwrap.
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 400
        mock_resp.text = (
            "400 Bad Request — Change DSL body is empty\n\n"
            "POST a body with Content-Type: text/vnd.forge.changes\n")
        mock_post.return_value = mock_resp
        result = ForgeClient("http://localhost", "k").audit_changes("")
        assert result["status_code"] == 400
        assert "body is empty" in result["body"]
        assert "text/vnd.forge.changes" in result["body"]

    @patch("dke_forge.client.requests.post")
    def test_audit_changes_raises_on_415(self, mock_post):
        # 415 (wrong Content-Type) raises — there's no parse-error
        # prose for the caller to act on textually; raising surfaces
        # the issue in the same shape as auth/billing/5xx. Realistic
        # case: a caller forgets the Content-Type plumbing and the
        # client sends with the requests-default `application/x-www-
        # form-urlencoded` instead of `text/vnd.forge.changes`.
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 415
        mock_resp.text = (
            "415 Unsupported Media Type — expected "
            "text/vnd.forge.changes\n")
        mock_post.return_value = mock_resp
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "k").audit_changes(
                'add Function name="X" file="f.cpp"\n')
        assert exc.value.status_code == 415

    @patch("dke_forge.client.requests.post")
    def test_audit_changes_raises_on_auth_403(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 403
        mock_resp.text = "Forbidden: insufficient tier"
        mock_post.return_value = mock_resp
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "k").audit_changes(
                'add Function name="X" file="f.cpp"\n')
        assert exc.value.status_code == 403

    @patch("dke_forge.client.requests.post")
    def test_audit_changes_emits_x_forge_graph_when_set(self, mock_post):
        # Per-method graph header plumbing — pinned because audit_
        # changes bypasses `_request` for the custom Content-Type, so
        # a workspace-default-graph regression couldn't slip through.
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "200 OK"
        mock_post.return_value = mock_resp
        c = ForgeClient("http://localhost", "k", graph="featurex")
        c.audit_changes('add Function name="X" file="f.cpp"\n')
        assert mock_post.call_args[1]["headers"]["X-Forge-Graph"] == \
            "featurex"


class TestContradictionsHypothetical:
    """``ForgeClient.contradictions_hypothetical`` wraps the bare-
    only ``POST /v1/query/.forge/contradictions/hypothetical``
    endpoint. Sibling of audit_changes — same body grammar (change
    DSL), same Content-Type, same diagnostic surface. The bare
    ``/.forge/contradictions`` path (without the ``/hypothetical``
    segment) is intentionally NOT exposed here — graph-level
    contradictions ship via the legacy ``GET /v1/graph/
    contradictions`` per finding §10.6 fork-δ-2.
    """

    @patch("dke_forge.client.requests.post")
    def test_contradictions_hypothetical_happy_path_200(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "200 OK — Change set checked for contradictions\n\n"
            "=== FORGE HYPOTHETICAL CONTRADICTIONS ===\n"
            "1 changes proposed, 1 resolved\n"
            "CHANGE c1:\n  resolution: pre-add\n  contradictions: 0\n")
        mock_post.return_value = mock_resp
        body = ('add Function name="HttpHandler" file="app/h.cpp" '
                'as c1\n')
        result = ForgeClient(
            "http://localhost", "k").contradictions_hypothetical(body)
        assert result["status_code"] == 200
        assert "FORGE HYPOTHETICAL CONTRADICTIONS" in result["body"]
        # Inner-content keyword differs from audit_changes — `contra-
        # dictions:` vs. `violations:` — pinning here so the L1
        # banner / content disclosure stays endpoint-specific.
        assert "contradictions:" in result["body"]
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/contradictions/hypothetical")
        assert mock_post.call_args[1]["headers"]["Content-Type"] == \
            "text/vnd.forge.changes"

    @patch("dke_forge.client.requests.post")
    def test_contradictions_hypothetical_parse_error_400_passthrough(
            self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 400
        mock_resp.text = (
            "400 Bad Request — change DSL parse error\n\n"
            "1:1 statement must start with `add`, `remove`, or `modify`\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k"
        ).contradictions_hypothetical("nope nothing useful here\n")
        assert result["status_code"] == 400
        assert "change DSL parse error" in result["body"]

    @patch("dke_forge.client.requests.post")
    def test_contradictions_hypothetical_empty_body_400_passthrough(
            self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 400
        mock_resp.text = "400 Bad Request — Change DSL body is empty\n"
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k").contradictions_hypothetical("")
        assert result["status_code"] == 400
        assert "body is empty" in result["body"]

    @patch("dke_forge.client.requests.post")
    def test_contradictions_hypothetical_raises_on_403(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 403
        mock_resp.text = "Forbidden: insufficient tier"
        mock_post.return_value = mock_resp
        with pytest.raises(ForgeError) as exc:
            ForgeClient(
                "http://localhost", "k").contradictions_hypothetical(
                'add Function name="X" file="f.cpp"\n')
        assert exc.value.status_code == 403

    @patch("dke_forge.client.requests.post")
    def test_contradictions_hypothetical_emits_x_forge_graph_when_set(
            self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "200 OK"
        mock_post.return_value = mock_resp
        c = ForgeClient("http://localhost", "k", graph="featurex")
        c.contradictions_hypothetical(
            'add Function name="X" file="f.cpp"\n')
        assert mock_post.call_args[1]["headers"]["X-Forge-Graph"] == \
            "featurex"


class TestCodeReachability:
    """``ForgeClient.code_reachability`` wraps the L0.5 DARQ surface
    ``POST /v1/query/.forge/code/reachability/<entity-path>`` from
    FG-CODE-REASONING-LIBRARY Phase 2 (finding §4 row 1). Same prose
    response shape as the other DARQ wrappers; the entity-path tail
    uses URL-encoding that PRESERVES forward slashes (the DARQ path
    structure is meaningful to the L1 router).
    """

    @patch("dke_forge.client.requests.post")
    def test_code_reachability_happy_path_200(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "/.forge/code/reachability/  seed=Function:main@src/foo.c  "
            "(forward transitive Calls closure, BFS order including seed)\n\n"
            "Function:main@src/foo.c\n"
            "Function:helper@src/foo.c\n"
            "\nreached_count=2\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k").code_reachability("src/foo.c/main")
        assert result["status_code"] == 200
        assert "reached_count=2" in result["body"]
        # URL pin — path-style entity tail with slashes preserved (the
        # L1 router needs to see `src/foo.c/main` as a path, not a
        # percent-encoded blob).
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/code/reachability/src/foo.c/main")
        # No body — read-only QUERY uses query-string params, not body.
        assert mock_post.call_args[1].get("data") is None
        assert mock_post.call_args[1]["headers"]["Authorization"] == "Bearer k"

    @patch("dke_forge.client.requests.post")
    def test_code_reachability_forwards_via_param(self, mock_post):
        # Optional ?via=<edge> swaps the edge type. Pinning the
        # query-string plumbing because the via knob is the legacy
        # `/v1/graph/reachable/:name` parity hook — consumers
        # migrating to the L0.5 surface need this to stay routable.
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "200 OK"
        mock_post.return_value = mock_resp
        ForgeClient("http://localhost", "k").code_reachability(
            "src/foo.c/main", via="Implements")
        assert mock_post.call_args[1]["params"] == {"via": "Implements"}

    @patch("dke_forge.client.requests.post")
    def test_code_reachability_404_passthrough(self, mock_post):
        # Did-you-mean prose is the diagnostic surface on a missing
        # seed — pass-through (NOT raise) so the caller reads the
        # candidates verbatim.
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 404
        mock_resp.text = (
            "404 Not Found — entity not found\n\n"
            "did you mean:\n  src/foo.c/maine\n  src/foo.c/mainz\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k").code_reachability("src/foo.c/typo")
        assert result["status_code"] == 404
        assert "did you mean" in result["body"]

    @patch("dke_forge.client.requests.post")
    def test_code_reachability_raises_on_auth_403(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 403
        mock_resp.text = "Forbidden: insufficient tier"
        mock_post.return_value = mock_resp
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "k").code_reachability(
                "src/foo.c/main")
        assert exc.value.status_code == 403

    @patch("dke_forge.client.requests.post")
    def test_code_reachability_emits_x_forge_graph(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "200 OK"
        mock_post.return_value = mock_resp
        c = ForgeClient("http://localhost", "k", graph="featurex")
        c.code_reachability("src/foo.c/main")
        assert mock_post.call_args[1]["headers"]["X-Forge-Graph"] == \
            "featurex"


class TestCodeCone:
    """``ForgeClient.code_cone`` wraps the L0.5 DARQ surface
    ``POST /v1/query/.forge/code/cone/<entity-path>`` from
    FG-CODE-REASONING-LIBRARY Phase 2 (finding §4 row 2 — bidirectional
    cone via ``analyzeCascade``). ``change_type`` selects cascade
    semantics (``modify`` | ``delete`` | ``rename``); default ``modify``.
    """

    @patch("dke_forge.client.requests.post")
    def test_code_cone_happy_path_200(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "/.forge/code/cone/  seed=Function:main@src/foo.c  "
            "(bidirectional cascade, change_type=modify)\n\n"
            "directly_affected (count=1):\n  Function:caller@src/foo.c\n\n"
            "transitively_affected (count=0):\n\n"
            "test_cases_affected (count=0):\n\n"
            "files_to_update (count=1):\n  src/foo.c\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k").code_cone("src/foo.c/main")
        assert result["status_code"] == 200
        assert "directly_affected" in result["body"]
        assert "files_to_update" in result["body"]
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/code/cone/src/foo.c/main")
        # Default change_type is `modify` — pinned because the L1
        # cascade default is also `modify` and a regression that
        # silently drops the param would still 200 (just with a
        # different cascade semantic), which is the worst kind of
        # silent change.
        assert mock_post.call_args[1]["params"] == {"change_type": "modify"}

    @patch("dke_forge.client.requests.post")
    def test_code_cone_forwards_change_type(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "200 OK"
        mock_post.return_value = mock_resp
        ForgeClient("http://localhost", "k").code_cone(
            "src/foo.c/main", change_type="delete")
        assert mock_post.call_args[1]["params"] == {"change_type": "delete"}

    @patch("dke_forge.client.requests.post")
    def test_code_cone_400_passthrough_on_empty_path(self, mock_post):
        # Empty entity-path → 400 from L1 with usage prose. The
        # 400-passthrough contract means the caller reads the
        # actionable error directly; same shape as the chain/audit
        # endpoints' usage-prose case.
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 400
        mock_resp.text = (
            "400 Bad Request\n\n/.forge/code/cone/ requires an "
            "entity-path suffix.\n")
        mock_post.return_value = mock_resp
        result = ForgeClient("http://localhost", "k").code_cone("")
        assert result["status_code"] == 400
        assert "entity-path suffix" in result["body"]

    @patch("dke_forge.client.requests.post")
    def test_code_cone_raises_on_500(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 500
        mock_resp.text = "Internal server error"
        mock_post.return_value = mock_resp
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "k").code_cone("src/foo.c/main")
        assert exc.value.status_code == 500


class TestCodeFlowOps:
    """``ForgeClient.code_use_def`` / ``code_reaching_defs`` /
    ``code_live_vars`` wrap the L0.5 DARQ surface
    ``POST /v1/query/.forge/code/{use-def,reaching-defs,live-vars}/<entity>``
    from FG-CODE-REASONING-LIBRARY Phase 3 step 6. All three share the
    ``_code_flow_op`` helper; per-method tests pin URL routing and one
    shared ``404 did-you-mean`` passthrough + ``403 raises`` test
    exercises the helper's status-code contract.
    """

    @patch("dke_forge.client.requests.post")
    def test_code_use_def_happy_path_200(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "/.forge/code/use-def/  seed=c_function:main@src/foo.c  "
            "(backward one-hop, seed excluded)\n\n"
            "c_function:helper  (depth=1)\n"
            "\nreached_count=1\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k").code_use_def("src/foo.c/main")
        assert result["status_code"] == 200
        assert "reached_count=1" in result["body"]
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/code/use-def/src/foo.c/main")

    @patch("dke_forge.client.requests.post")
    def test_code_reaching_defs_happy_path_200(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "/.forge/code/reaching-defs/  ..."
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k").code_reaching_defs("src/foo.c/main")
        assert result["status_code"] == 200
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/code/reaching-defs/src/foo.c/main")

    @patch("dke_forge.client.requests.post")
    def test_code_live_vars_happy_path_200(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "/.forge/code/live-vars/  ..."
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k").code_live_vars("src/foo.c/main")
        assert result["status_code"] == 200
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/code/live-vars/src/foo.c/main")

    @patch("dke_forge.client.requests.post")
    def test_code_use_def_404_passthrough(self, mock_post):
        # Did-you-mean prose is the diagnostic surface on a missing
        # seed — pass-through (NOT raise) so the caller reads the
        # candidates verbatim. Tested on use-def; shared `_code_flow_op`
        # helper carries the status-code contract for the other two.
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 404
        mock_resp.text = (
            "404 Not Found — entity not found\n\n"
            "did you mean:\n  src/foo.c/maine\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k").code_use_def("src/foo.c/typo")
        assert result["status_code"] == 404
        assert "did you mean" in result["body"]

    @patch("dke_forge.client.requests.post")
    def test_code_use_def_raises_on_500(self, mock_post):
        # Non-400/404 non-ok statuses raise ForgeError.
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 500
        mock_resp.text = "Internal Server Error"
        mock_post.return_value = mock_resp
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "k").code_use_def("src/foo.c/main")
        assert exc.value.status_code == 500


class TestCodeEffects:
    """``ForgeClient.code_effects`` wraps the L0.5 DARQ surface
    ``POST /v1/query/.forge/code/effects/<entity-path>`` from
    FG-CODE-REASONING-LIBRARY Phase 5a. No required arguments beyond
    the entity-path — the effect set is determined entirely by per-
    function ``effects`` props at every visited function (substrate is
    source-of-truth-agnostic per §15.1 Q15.4 LOAD-BEARING).
    """

    @patch("dke_forge.client.requests.post")
    def test_code_effects_happy_path_200(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "/.forge/code/effects/  seed=c_function:parse@src/handler.c  "
            "(forward transitive, Calls only, seed excluded from "
            "reached but contributes to effect_set)\n\n"
            "effect_set: io,throwing\n\n"
            "c_function:helper  (depth=1, contributed_effects=[io])\n"
            "\nreached_count=1\neffect_set_count=2\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k").code_effects("src/handler.c/parse")
        assert result["status_code"] == 200
        assert "effect_set: io,throwing" in result["body"]
        assert "effect_set_count=2" in result["body"]
        # URL pin — entity-path slashes preserved.
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/code/effects/src/handler.c/parse")
        # No body, no params required.
        assert mock_post.call_args[1].get("data") is None

    @patch("dke_forge.client.requests.post")
    def test_code_effects_404_passthrough(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 404
        mock_resp.text = "404 — did you mean: src/foo.c/maine\n"
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k").code_effects("src/foo.c/typo")
        assert result["status_code"] == 404
        assert "did you mean" in result["body"]


class TestClassifyEffects:
    """``ForgeClient.classify_effects`` wraps the Phase 5b explicit
    operator-trigger ``POST /v1/flow/classify-effects``. Returns JSON
    ``{writes_total: <int>}``. Per finding §16.4 with step-3 amendment
    (DECLARE-Rule auto-fire deferred to Phase 5c) this is the canonical
    surface tenants call after rule operations.
    """

    @patch("dke_forge.client.requests.post")
    def test_classify_effects_happy_path(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"writes_total": 3}
        mock_post.return_value = mock_resp
        result = ForgeClient("http://localhost", "k").classify_effects()
        assert result == {"writes_total": 3}
        assert mock_post.call_args[0][0].endswith("/v1/flow/classify-effects")

    @patch("dke_forge.client.requests.post")
    def test_classify_effects_403_raises(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 403
        mock_resp.text = "billing"
        mock_post.return_value = mock_resp
        try:
            ForgeClient("http://localhost", "k").classify_effects()
            raise AssertionError("expected ForgeError")
        except ForgeError as e:
            assert e.status_code == 403


class TestEffectsClassification:
    """``ForgeClient.effects_classification`` wraps Phase 5b
    introspection ``GET /v1/flow/effects-classification?source_name=X``.
    Returns JSON ``{node_id, name, effects, source}`` where ``source``
    re-evaluates classification predicates at query time.
    """

    @patch("dke_forge.client.requests.get")
    def test_effects_classification_happy_path(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "node_id": 7,
            "name": "printf",
            "effects": "io",
            "source": "tenant_declare_or_convention",
        }
        mock_get.return_value = mock_resp
        result = ForgeClient("http://localhost", "k").effects_classification(
            "printf")
        assert result["node_id"] == 7
        assert result["name"] == "printf"
        assert result["effects"] == "io"
        assert mock_get.call_args[1]["params"] == {"source_name": "printf"}
        assert mock_get.call_args[0][0].endswith(
            "/v1/flow/effects-classification")

    @patch("dke_forge.client.requests.get")
    def test_effects_classification_404_raises(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 404
        mock_resp.text = "no function"
        mock_get.return_value = mock_resp
        try:
            ForgeClient("http://localhost", "k").effects_classification(
                "ghost")
            raise AssertionError("expected ForgeError")
        except ForgeError as e:
            assert e.status_code == 404


class TestRuleDarqVerbs:
    """``ForgeClient.declare_rule`` / ``amend_rule`` / ``retire_rule``
    wrap the Phase 5c §7.1 surgical carve-out for `/.forge/rules/<name>`
    write verbs. Closes the Q16.4 step-3 amendment deferral from Phase
    5b — each verb auto-fires ``forge::classifyEffects`` post-mutation
    and the response carries ``classify_writes`` so the tenant sees
    the round-trip in one HTTP call.
    """

    @patch("dke_forge.client.requests.post")
    def test_declare_rule_happy_path(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "rule_name": "io_for_mylog",
            "rule_node_id": 42,
            "op_id": 7,
            "classify_writes": 1,
            "status": "declared",
        }
        mock_post.return_value = mock_resp
        result = ForgeClient("http://localhost", "k").declare_rule(
            "io_for_mylog", name_match="mylog", effects_to_set=["io"])
        assert result["status"] == "declared"
        assert result["classify_writes"] == 1
        # URL path lands on the §17.1 carve-out
        assert mock_post.call_args[0][0].endswith(
            "/v1/declare/.forge/rules/io_for_mylog")
        # Body is canonical JSON envelope per §17.2
        body = json.loads(mock_post.call_args[1]["data"])
        assert body["target_kind"] == "Function"
        assert body["name_match"] == "mylog"
        assert body["effects_to_set"] == ["io"]
        assert body["action"] == "Derive"

    @patch("dke_forge.client.requests.post")
    def test_declare_rule_409_propagates(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 409
        mock_resp.text = "already exists"
        mock_post.return_value = mock_resp
        try:
            ForgeClient("http://localhost", "k").declare_rule(
                "dup_rule", name_match="x", effects_to_set=["io"])
            raise AssertionError("expected ForgeError")
        except ForgeError as e:
            assert e.status_code == 409

    @patch("dke_forge.client.requests.post")
    def test_amend_rule_happy_path(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "rule_name": "r1",
            "rule_node_id": 99,
            "op_id": 12,
            "classify_writes": 2,
            "status": "amended",
        }
        mock_post.return_value = mock_resp
        result = ForgeClient("http://localhost", "k").amend_rule(
            "r1", name_match="mylog", effects_to_set=["throwing"])
        assert result["status"] == "amended"
        assert mock_post.call_args[0][0].endswith(
            "/v1/amend/.forge/rules/r1")
        body = json.loads(mock_post.call_args[1]["data"])
        assert body["effects_to_set"] == ["throwing"]

    @patch("dke_forge.client.requests.post")
    def test_amend_rule_404_propagates(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 404
        mock_resp.text = "does not exist"
        mock_post.return_value = mock_resp
        try:
            ForgeClient("http://localhost", "k").amend_rule(
                "ghost", name_match="x", effects_to_set=["io"])
            raise AssertionError("expected ForgeError")
        except ForgeError as e:
            assert e.status_code == 404

    @patch("dke_forge.client.requests.post")
    def test_retire_rule_happy_path(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "rule_name": "r1",
            "op_id": 13,
            "classify_writes": 0,
            "status": "retired",
        }
        mock_post.return_value = mock_resp
        result = ForgeClient("http://localhost", "k").retire_rule("r1")
        assert result["status"] == "retired"
        assert mock_post.call_args[0][0].endswith(
            "/v1/retire/.forge/rules/r1")
        # Empty body — rule name lives in URL
        assert mock_post.call_args[1]["data"] == ""

    @patch("dke_forge.client.requests.post")
    def test_retire_rule_404_propagates(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 404
        mock_resp.text = "does not exist"
        mock_post.return_value = mock_resp
        try:
            ForgeClient("http://localhost", "k").retire_rule("ghost")
            raise AssertionError("expected ForgeError")
        except ForgeError as e:
            assert e.status_code == 404

    @patch("dke_forge.client.requests.post")
    def test_declare_rule_passes_contract_tag_when_set(self, mock_post):
        # FG-CODE-REASONING-LIBRARY Phase 7 §21.3: declare_rule accepts
        # an optional contract_tag kwarg that lands in the JSON body.
        # The L1 decoder reads it under the existing string-prop fan-out
        # (no grammar amendment).
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "rule_name": "withdraw_pre",
            "rule_node_id": 51,
            "op_id": 8,
            "classify_writes": 0,
            "status": "declared",
        }
        mock_post.return_value = mock_resp
        ForgeClient("http://localhost", "k").declare_rule(
            "withdraw_pre", name_match="do_withdraw",
            contract_tag="withdraw_contract")
        body = json.loads(mock_post.call_args[1]["data"])
        assert body["contract_tag"] == "withdraw_contract"

    @patch("dke_forge.client.requests.post")
    def test_declare_rule_omits_contract_tag_when_unset(self, mock_post):
        # When contract_tag is None (default), the body must NOT carry
        # the key — Phase 5b/5c rules without contracts stay byte-
        # identical pre-Phase-7.
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "rule_name": "io_for_mylog",
            "rule_node_id": 42,
            "op_id": 7,
            "classify_writes": 1,
            "status": "declared",
        }
        mock_post.return_value = mock_resp
        ForgeClient("http://localhost", "k").declare_rule(
            "io_for_mylog", name_match="mylog", effects_to_set=["io"])
        body = json.loads(mock_post.call_args[1]["data"])
        assert "contract_tag" not in body


class TestCodeTaint:
    """``ForgeClient.code_taint`` wraps the L0.5 DARQ surface
    ``POST /v1/query/.forge/code/taint/<entity-path>?label=<label>`` from
    FG-CODE-REASONING-LIBRARY Phase 4. Distinct from the flow.* family
    in requiring a non-empty ``label`` (the source classifier propagated
    to every reached node) — a ValueError is raised client-side before
    any HTTP if the label is empty.
    """

    @patch("dke_forge.client.requests.post")
    def test_code_taint_happy_path_200(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "/.forge/code/taint/  seed=c_function:parse@src/handler.c  "
            "label=user_input  (forward transitive, "
            "Calls + UsesType + HasParam, seed excluded)\n\n"
            "c_function:helper  (depth=1, label=user_input)\n"
            "\nreached_count=1\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k"
        ).code_taint("src/handler.c/parse", "user_input")
        assert result["status_code"] == 200
        assert "label=user_input" in result["body"]
        assert "reached_count=1" in result["body"]
        # URL pin — entity-path slashes preserved (path-style routing
        # is meaningful to the L1 dispatcher).
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/code/taint/src/handler.c/parse")
        # Label sent as a query parameter, not in the body.
        assert mock_post.call_args[1]["params"] == {"label": "user_input"}
        # No body — read-only QUERY uses query-string params.
        assert mock_post.call_args[1].get("data") is None

    def test_code_taint_empty_label_raises_valueerror(self):
        # Empty / falsy label is a client-side error — fail fast before
        # the HTTP rather than relying on the server's 400.
        with pytest.raises(ValueError):
            ForgeClient("http://localhost",
                        "k").code_taint("src/foo.c/main", "")

    @patch("dke_forge.client.requests.post")
    def test_code_taint_404_passthrough(self, mock_post):
        # Did-you-mean prose passes through (NOT raise). Same status-
        # code contract as code_reachability + the flow.* family.
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 404
        mock_resp.text = (
            "404 Not Found — entity not found\n\n"
            "did you mean:\n  src/foo.c/maine\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k"
        ).code_taint("src/foo.c/typo", "L")
        assert result["status_code"] == 404
        assert "did you mean" in result["body"]


class TestCodeTypes:
    """``ForgeClient.code_types`` wraps the L0.5 DARQ surface
    ``POST /v1/query/.forge/code/types/<entity-path>?direction=...`` from
    FG-CODE-REASONING-LIBRARY Phase 6. Direction defaults to ``forward``;
    invalid values raise ``ValueError`` client-side before the HTTP.
    """

    @patch("dke_forge.client.requests.post")
    def test_code_types_happy_path_default_direction(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "/.forge/code/types/  seed=c_function:parse  "
            "(forward transitive, seed excluded, edge filter "
            "Calls + HasParam)\nseed_types=[int]\n\nreached_count=0\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k"
        ).code_types("src/handler.c/parse")
        assert result["status_code"] == 200
        assert "seed_types=" in result["body"]
        assert "reached_count=0" in result["body"]
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/code/types/src/handler.c/parse")
        assert mock_post.call_args[1]["params"] == {"direction": "forward"}

    @patch("dke_forge.client.requests.post")
    def test_code_types_explicit_backward(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = "/.forge/code/types/  ...backward transitive..."
        mock_post.return_value = mock_resp
        ForgeClient("http://localhost",
                    "k").code_types("src/foo.c/main", direction="backward")
        assert mock_post.call_args[1]["params"] == {"direction": "backward"}

    def test_code_types_invalid_direction_raises_valueerror(self):
        with pytest.raises(ValueError):
            ForgeClient(
                "http://localhost", "k"
            ).code_types("src/foo.c/main", direction="sideways")

    @patch("dke_forge.client.requests.post")
    def test_code_types_404_passthrough(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 404
        mock_resp.text = "404 Not Found — entity not found\n"
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k"
        ).code_types("src/foo.c/typo")
        assert result["status_code"] == 404


class TestCodeRefinement:
    """``ForgeClient.code_refinement`` wraps the L0.5 DARQ surface
    ``POST /v1/query/.forge/code/refinement`` from FG-CODE-REASONING-LIBRARY
    Phase 6. Body-driven (no entity-path slot); reuses Phase 5e PropsMatch
    grammar plus set-membership and lattice composition (closure §20.7).
    """

    @patch("dke_forge.client.requests.post")
    def test_code_refinement_set_membership_happy_path(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "/.forge/code/refinement  input_count=2  "
            "predicate.kind=set_membership\n\nint\n\nrefined_count=1\n")
        mock_post.return_value = mock_resp
        result = ForgeClient("http://localhost", "k").code_refinement(
            ["int", "string"],
            {"kind": "set_membership", "allowed_types": ["int"]})
        assert result["status_code"] == 200
        assert "refined_count=1" in result["body"]
        # URL pin — bare path, no entity-path suffix.
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/code/refinement")
        # Body sent as JSON via requests' json= kwarg, not data=.
        sent = mock_post.call_args[1]["json"]
        assert sent["type_set"] == ["int", "string"]
        assert sent["predicate"]["kind"] == "set_membership"

    @patch("dke_forge.client.requests.post")
    def test_code_refinement_400_passthrough(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 400
        mock_resp.text = ("400 Bad Request\n\nUnknown predicate.kind: magic"
                           " (expected props_match|set_membership|lattice|"
                           "and|or)\n")
        mock_post.return_value = mock_resp
        result = ForgeClient("http://localhost", "k").code_refinement(
            ["int"], {"kind": "magic"})
        assert result["status_code"] == 400
        assert "Unknown predicate.kind" in result["body"]

    @patch("dke_forge.client.requests.post")
    def test_code_refinement_accepts_iterable_type_set(self, mock_post):
        # type_set is normalized to list — generators / tuples / sets ok.
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = ""
        mock_post.return_value = mock_resp
        ForgeClient("http://localhost", "k").code_refinement(
            ("a", "b"), {"kind": "set_membership", "allowed_types": ["a"]})
        sent = mock_post.call_args[1]["json"]
        assert sent["type_set"] == ["a", "b"]

    @patch("dke_forge.client.requests.post")
    def test_code_refinement_500_raises(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 500
        mock_resp.text = "internal error"
        mock_post.return_value = mock_resp
        with pytest.raises(ForgeError):
            ForgeClient("http://localhost", "k").code_refinement(
                ["int"], {"kind": "set_membership", "allowed_types": []})


class TestCodeContracts:
    """``ForgeClient.code_contracts`` wraps the L0.5 DARQ surface
    ``POST /v1/query/.forge/code/contracts[/<entity-path>]`` from
    FG-CODE-REASONING-LIBRARY Phase 7. Whole-graph variant on the bare
    form (entity_path=None per §21.1); seeded variant when an entity-
    path is given (narrows to the seed Function's incoming + outgoing
    Calls neighborhood per §21.4 Calls-only edge filter).
    """

    @patch("dke_forge.client.requests.post")
    def test_code_contracts_whole_graph_no_entity_path(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "/.forge/code/contracts/  (whole-graph scan — every Rule with "
            "non-empty contract_tag walked)\ntags_walked=[]\n\n"
            "(no contract Rules declared — DECLARE Rules with non-empty "
            "contract_tag to enable contract checking)\n\n"
            "violation_count=0\ntags_walked_count=0\n")
        mock_post.return_value = mock_resp
        result = ForgeClient("http://localhost", "k").code_contracts()
        assert result["status_code"] == 200
        assert "whole-graph scan" in result["body"]
        assert "violation_count=0" in result["body"]
        # URL pin — bare path, no entity-path suffix.
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/code/contracts")
        # No params — Contracts has none.
        assert mock_post.call_args[1].get("params") is None

    @patch("dke_forge.client.requests.post")
    def test_code_contracts_seeded_with_entity_path(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "/.forge/code/contracts/  seed=c_function:parse@src/handler.c  "
            "(seeded — incoming + outgoing Calls neighborhood)\n"
            "tags_walked=[]\n\nviolation_count=0\ntags_walked_count=0\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k"
        ).code_contracts("src/handler.c/parse")
        assert result["status_code"] == 200
        assert "seeded —" in result["body"]
        # URL pin — entity-path slashes preserved.
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/code/contracts/src/handler.c/parse")

    @patch("dke_forge.client.requests.post")
    def test_code_contracts_404_passthrough(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 404
        mock_resp.text = (
            "404 Not Found — entity not found\n\n"
            "did you mean:\n  src/foo.c/maine\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k"
        ).code_contracts("src/foo.c/typo")
        assert result["status_code"] == 404
        assert "did you mean" in result["body"]

    @patch("dke_forge.client.requests.post")
    def test_code_contracts_500_raises(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 500
        mock_resp.text = "internal error"
        mock_post.return_value = mock_resp
        with pytest.raises(ForgeError):
            ForgeClient("http://localhost", "k").code_contracts()


class TestCodeBehavior:
    """``ForgeClient.code_behavior`` wraps the L0.5 DARQ surface
    ``POST /v1/query/.forge/code/behavior/<entity-path>?lens=<name>`` from
    FG-CODE-REASONING-LIBRARY Phase 7. Single dispatcher over four
    lenses (Exceptions / Concurrency / Termination / Purity) per §21.2;
    lens defaults to None (server-side default ``all``); invalid lens
    values raise ``ValueError`` client-side before the HTTP.
    """

    @patch("dke_forge.client.requests.post")
    def test_code_behavior_default_lens(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "/.forge/code/behavior/  seed=c_function:parse@src/handler.c  "
            "lens=all\n\n[exceptions]\n  throws=false\n  "
            "throwing_node_ids=[]\n[concurrency]\n  has_concurrency=false\n  "
            "concurrency_node_ids=[]\n  markers=[]\n[termination]\n  "
            "has_cycle=false\n  definitely_terminates=true\n  "
            "cycle_node_ids=[]\n[purity]\n  is_pure=true\n  "
            "contributed_effects=[]\n")
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k"
        ).code_behavior("src/handler.c/parse")
        assert result["status_code"] == 200
        assert "lens=all" in result["body"]
        assert "[exceptions]" in result["body"]
        # URL pin — entity-path slashes preserved.
        assert mock_post.call_args[0][0].endswith(
            "/v1/query/.forge/code/behavior/src/handler.c/parse")
        # No lens kwarg → params is None (server picks default `all`).
        assert mock_post.call_args[1].get("params") is None

    @patch("dke_forge.client.requests.post")
    def test_code_behavior_explicit_purity_lens(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.text = (
            "/.forge/code/behavior/  seed=c_function:work  lens=purity\n\n"
            "[purity]\n  is_pure=true\n  contributed_effects=[]\n")
        mock_post.return_value = mock_resp
        ForgeClient("http://localhost",
                    "k").code_behavior("src/foo.c/work", lens="purity")
        assert mock_post.call_args[1]["params"] == {"lens": "purity"}

    def test_code_behavior_invalid_lens_raises_valueerror(self):
        with pytest.raises(ValueError):
            ForgeClient(
                "http://localhost", "k"
            ).code_behavior("src/foo.c/main", lens="fictional")

    @patch("dke_forge.client.requests.post")
    def test_code_behavior_404_passthrough(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 404
        mock_resp.text = "404 Not Found — entity not found\n"
        mock_post.return_value = mock_resp
        result = ForgeClient(
            "http://localhost", "k"
        ).code_behavior("src/foo.c/typo")
        assert result["status_code"] == 404

    @patch("dke_forge.client.requests.post")
    def test_code_behavior_500_raises(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 500
        mock_resp.text = "internal error"
        mock_post.return_value = mock_resp
        with pytest.raises(ForgeError):
            ForgeClient(
                "http://localhost", "k"
            ).code_behavior("src/foo.c/main")


# -- FG-29 Phase 1.1.C: semantic search + embed client methods --










class TestClientCircularDeps:
    @patch("dke_forge.client.requests.request")
    def test_default_no_params(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"cycles": [], "scope": "all"}
        )
        ForgeClient("http://localhost", "k").analysis_circular_deps()
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/analysis/circular-deps")
        assert mock_req.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.request")
    def test_forwards_all_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"cycles": []})
        ForgeClient("http://localhost", "k").analysis_circular_deps(
            scope="module", max_cycles=10, max_length=50,
        )
        params = mock_req.call_args[1]["params"]
        assert params == {"scope": "module", "max_cycles": 10, "max_length": 50}

    @patch("dke_forge.client.requests.request")
    def test_partial_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"cycles": []})
        ForgeClient("http://localhost", "k").analysis_circular_deps(scope="file")
        assert mock_req.call_args[1]["params"] == {"scope": "file"}


class TestClientGodClasses:
    @patch("dke_forge.client.requests.request")
    def test_default_no_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"entries": []})
        ForgeClient("http://localhost", "k").analysis_god_classes()
        assert mock_req.call_args[0][1].endswith("/v1/analysis/god-classes")
        assert mock_req.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.request")
    def test_threshold_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"entries": []})
        ForgeClient("http://localhost", "k").analysis_god_classes(threshold=30)
        assert mock_req.call_args[1]["params"] == {"threshold": 30}


class TestClientArchitectureMap:
    @patch("dke_forge.client.requests.request")
    def test_default_no_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"top_nodes": []})
        ForgeClient("http://localhost", "k").analysis_architecture_map()
        assert mock_req.call_args[0][1].endswith("/v1/analysis/architecture-map")
        assert mock_req.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.request")
    def test_all_params_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"top_nodes": []})
        ForgeClient("http://localhost", "k").analysis_architecture_map(
            top_n=100, damping=0.85, max_iterations=50, tolerance=1e-6,
        )
        params = mock_req.call_args[1]["params"]
        assert params == {
            "top_n": 100,
            "damping": 0.85,
            "max_iterations": 50,
            "tolerance": 1e-6,
        }


class TestClientApiSurface:
    @patch("dke_forge.client.requests.request")
    def test_module_id(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"module_id": 42, "public_symbols": []}
        )
        ForgeClient("http://localhost", "k").analysis_api_surface(module_id=42)
        assert mock_req.call_args[0][1].endswith("/v1/analysis/api-surface")
        assert mock_req.call_args[1]["params"] == {"module_id": 42}

    @patch("dke_forge.client.requests.request")
    def test_module_name(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"module_id": 1, "public_symbols": []}
        )
        ForgeClient("http://localhost", "k").analysis_api_surface(
            module_name="render",
        )
        assert mock_req.call_args[1]["params"] == {"module_name": "render"}

    def test_requires_one_of(self):
        client = ForgeClient("http://localhost", "k")
        with pytest.raises(ValueError):
            client.analysis_api_surface()


class TestClientAbstractions:
    @patch("dke_forge.client.requests.request")
    def test_default_no_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"groups": []})
        ForgeClient("http://localhost", "k").analysis_abstractions()
        assert mock_req.call_args[0][1].endswith("/v1/analysis/abstractions")
        assert mock_req.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.request")
    def test_min_group_size_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"groups": []})
        ForgeClient("http://localhost", "k").analysis_abstractions(min_group_size=4)
        assert mock_req.call_args[1]["params"] == {"min_group_size": 4}


class TestClientModuleTopology:
    @patch("dke_forge.client.requests.request")
    def test_no_params(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"modules": [], "deps": []}
        )
        ForgeClient("http://localhost", "k").analysis_module_topology()
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/analysis/module-topology")
        assert mock_req.call_args[1]["params"] is None


# -- FG-32 Phase 2.1.C: change suite client methods --


class TestClientChangeRefactorPreview:
    @patch("dke_forge.client.requests.request")
    def test_posts_required_fields(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"found": False, "conflicts": []},
        )
        ForgeClient("http://localhost", "k").change_refactor_preview(
            "oldName", "newName",
        )
        assert mock_req.call_args[0][0] == "POST"
        assert mock_req.call_args[0][1].endswith("/v1/change/refactor-preview")
        assert mock_req.call_args[1]["json"] == {
            "symbol_name": "oldName", "new_name": "newName",
        }

    @patch("dke_forge.client.requests.request")
    def test_kind_forwarded_when_present(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"found": True})
        ForgeClient("http://localhost", "k").change_refactor_preview(
            "Foo", "Bar", kind="Type",
        )
        assert mock_req.call_args[1]["json"] == {
            "symbol_name": "Foo", "new_name": "Bar", "kind": "Type",
        }


class TestClientChangeBreakingChange:
    @patch("dke_forge.client.requests.request")
    def test_posts_required_fields(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"found": True, "affected_callers": []},
        )
        ForgeClient("http://localhost", "k").change_breaking_change(
            "parse", "int", ["const std::string&", "std::size_t"],
        )
        assert mock_req.call_args[0][0] == "POST"
        assert mock_req.call_args[0][1].endswith("/v1/change/breaking-change")
        assert mock_req.call_args[1]["json"] == {
            "symbol_name": "parse",
            "new_return_type": "int",
            "new_param_types": ["const std::string&", "std::size_t"],
        }

    @patch("dke_forge.client.requests.request")
    def test_param_types_always_a_list(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"found": True})
        # Pass a tuple to prove it's normalized to a list before JSON encode.
        ForgeClient("http://localhost", "k").change_breaking_change(
            "f", "void", ("int",),
        )
        assert mock_req.call_args[1]["json"]["new_param_types"] == ["int"]


class TestClientChangeDeprecationPath:
    @patch("dke_forge.client.requests.request")
    def test_posts_required_fields_only(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"found": True, "stages": []},
        )
        ForgeClient("http://localhost", "k").change_deprecation_path("OldApi")
        assert mock_req.call_args[0][0] == "POST"
        assert mock_req.call_args[0][1].endswith("/v1/change/deprecation-path")
        assert mock_req.call_args[1]["json"] == {"symbol_name": "OldApi"}

    @patch("dke_forge.client.requests.request")
    def test_all_params_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"found": True})
        ForgeClient("http://localhost", "k").change_deprecation_path(
            "OldApi", kind="Function", max_depth=50,
        )
        assert mock_req.call_args[1]["json"] == {
            "symbol_name": "OldApi", "kind": "Function", "max_depth": 50,
        }


class TestClientChangeRisky:
    @patch("dke_forge.client.requests.request")
    def test_commit_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"commit_sha": "abc123", "score": 0.12},
        )
        ForgeClient("http://localhost", "k").change_risky("abc123")
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/change/risky")
        assert mock_req.call_args[1]["params"] == {"commit": "abc123"}


class TestClientChangeCommitImpact:
    @patch("dke_forge.client.requests.request")
    def test_commit_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"commit_sha": "abc123", "touched_count": 0},
        )
        ForgeClient("http://localhost", "k").change_commit_impact("abc123")
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/change/commit-impact")
        assert mock_req.call_args[1]["params"] == {"commit": "abc123"}


class TestClientChangeReview:
    @patch("dke_forge.client.requests.request")
    def test_commit_only(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"commit_sha": "abc123", "risk_score": 0.0},
        )
        ForgeClient("http://localhost", "k").change_review("abc123")
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/change/review")
        assert mock_req.call_args[1]["params"] == {"commit": "abc123"}

    @patch("dke_forge.client.requests.request")
    def test_focus_area_top_n_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"commit_sha": "abc123", "risk_score": 0.0},
        )
        ForgeClient("http://localhost", "k").change_review(
            "abc123", focus_area_top_n=10,
        )
        assert mock_req.call_args[1]["params"] == {
            "commit": "abc123", "focus_area_top_n": 10,
        }




class TestGraphRouting:
    def test_no_header_by_default(self):
        client = ForgeClient("http://localhost", "k")
        h = client._headers()
        assert "X-Forge-Graph" not in h

    def test_header_set_when_graph_kwarg_given(self):
        client = ForgeClient("http://localhost", "k", graph="featurex")
        h = client._headers()
        assert h["X-Forge-Graph"] == "featurex"

    @patch("dke_forge.client.requests.request")
    def test_graph_header_sent_on_request(self, mock_req):
        mock_req.return_value = _mock_response(json_data={})
        client = ForgeClient("http://localhost", "k",
                              graph="side-graph")
        client.graph_stats()
        headers = mock_req.call_args[1]["headers"]
        assert headers["X-Forge-Graph"] == "side-graph"


class TestGraphCRUD:
    @patch("dke_forge.client.requests.request")
    def test_list_graphs_is_get(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"graphs": [], "default_graph_id": ""}
        )
        ForgeClient("http://localhost", "k").list_graphs()
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/graphs")

    @patch("dke_forge.client.requests.request")
    def test_create_graph_body(self, mock_req):
        mock_req.return_value = _mock_response(
            status=201, json_data={"id": "g1", "slug": "a", "name": "A"}
        )
        ForgeClient("http://localhost", "k").create_graph("a", "A")
        assert mock_req.call_args[0][0] == "POST"
        assert mock_req.call_args[1]["json"] == {"slug": "a", "name": "A"}

    @patch("dke_forge.client.requests.request")
    def test_rename_graph_is_patch(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"id": "g1"})
        ForgeClient("http://localhost", "k").rename_graph(
            "g1", slug="new", name="New")
        assert mock_req.call_args[0][0] == "PATCH"
        assert mock_req.call_args[1]["json"] == {"slug": "new", "name": "New"}

    @patch("dke_forge.client.requests.request")
    def test_rename_graph_omits_unset_fields(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"id": "g1"})
        ForgeClient("http://localhost", "k").rename_graph("g1", slug="x")
        assert mock_req.call_args[1]["json"] == {"slug": "x"}

    @patch("dke_forge.client.requests.request")
    def test_delete_graph_passes_reassign(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"deleted": True}
        )
        ForgeClient("http://localhost", "k").delete_graph(
            "g1", reassign_default_to="g2")
        assert mock_req.call_args[0][0] == "DELETE"
        assert mock_req.call_args[1]["params"] == {
            "reassign_default_to": "g2"}

    @patch("dke_forge.client.requests.request")
    def test_promote_default_graph_url(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"default_graph_id": "g1"}
        )
        ForgeClient("http://localhost", "k").promote_default_graph("g1")
        assert mock_req.call_args[0][0] == "POST"
        assert mock_req.call_args[0][1].endswith("/v1/graphs/g1/default")


# FG-API-INVITATION-{RESEND,PREVIEW} L2 follow-on — workspace
# invitation lifecycle endpoints. Same mocked-HTTP pattern as
# TestGraphCRUD; verify URL + method + body shape, no live API.
class TestInvitations:
    @patch("dke_forge.client.requests.request")
    def test_invitation_resend_is_post(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"token": "abc", "email_sent": True})
        ForgeClient("http://localhost", "k").invitation_resend("abc123token")
        assert mock_req.call_args[0][0] == "POST"
        assert mock_req.call_args[0][1].endswith(
            "/v1/invitations/abc123token/resend")

    @patch("dke_forge.client.requests.request")
    def test_invitation_resend_token_is_url_encoded(self, mock_req):
        # Tokens are 64-hex from the server; no encoding needed in
        # practice. But the client must not corrupt unusual chars if
        # a future token shape uses them — pin via _encode round-trip.
        mock_req.return_value = _mock_response(json_data={"email_sent": True})
        ForgeClient("http://localhost", "k").invitation_resend("a/b c")
        # _encode replaces / and space with %2F / %20.
        assert mock_req.call_args[0][1].endswith(
            "/v1/invitations/a%2Fb%20c/resend")

    @patch("dke_forge.client.requests.request")
    def test_invitation_preview_is_get(self, mock_req):
        mock_req.return_value = _mock_response(json_data={
            "workspace_id": "ws1",
            "workspace_name": "Acme Corp",
            "invitee_email": "alice@example.com",
            "role": "contributor",
            "state": "pending",
            "expires_at": 1234567890,
        })
        result = ForgeClient("http://localhost", "k").invitation_preview(
            "abc123token")
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith(
            "/v1/invitations/abc123token/preview")
        # Preview returns the metadata as-is — no client-side
        # transformation. Caller branches on `state`.
        assert result["state"] == "pending"
        assert result["workspace_name"] == "Acme Corp"

    @patch("dke_forge.client.requests.request")
    def test_invitation_resend_propagates_410(self, mock_req):
        mock_req.return_value = _mock_response(
            status=410,
            json_data={"error": "Invitation has been revoked"})
        with pytest.raises(ForgeError) as exc_info:
            ForgeClient("http://localhost", "k").invitation_resend("dead")
        assert exc_info.value.status_code == 410
