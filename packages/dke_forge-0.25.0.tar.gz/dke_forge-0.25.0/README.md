# dke-forge

Python CLI and MCP server for [DKE-Forge](https://dke-forge.com) — a
deterministic, graph-native code intelligence engine.

This package is a thin HTTP client over the Forge API. The reasoning engine
itself (graph construction, pattern learning, provenance tracking, impact
analysis) runs server-side at `dke-forge.com`. Your code is ingested into a
private graph; every query returns grounded, provenance-tagged answers —
no LLM guessing.

## Install

```bash
pip install dke-forge              # CLI only
pip install 'dke-forge[mcp]'       # CLI + MCP stdio server
```

## Configure

Sign up at [dke-forge.com](https://dke-forge.com) to get an API key, then:

```bash
dke-forge config set api_key fga_your_key
```

Or set environment variables (overrides the config file):

```bash
export FORGE_URL=https://dke-forge.com
export FORGE_API_KEY=fga_your_key
```

The config file lives at `~/.config/dke-forge/config.json` (chmod 600).

## CLI

```bash
dke-forge health                          # server status
dke-forge graph stats                     # node/edge counts
dke-forge graph function main             # look up a function
dke-forge graph callers authenticate      # who calls authenticate?
dke-forge graph impact login              # what breaks if login changes?
dke-forge scan /path/to/repo              # ingest a repo (polls to completion)
dke-forge scan /path/to/repo --no-wait    # returns scan_id; poll separately
dke-forge scan-status <scan_id>           # check async scan progress
```

Run `dke-forge --help` for the full command tree.

## MCP — Claude Code, VS Code, Cursor, any MCP client

Install with the `[mcp]` extra, then add this to your MCP client config.

### Claude Code (`.mcp.json` at project root, or `~/.mcp.json` for global):

```json
{
  "mcpServers": {
    "forge": {
      "command": "dke-forge-mcp",
      "env": {
        "FORGE_URL": "https://dke-forge.com",
        "FORGE_API_KEY": "fga_your_key"
      }
    }
  }
}
```

### Cursor / VS Code (via `settings.json`):

```json
{
  "mcp.servers": {
    "forge": {
      "command": "dke-forge-mcp",
      "env": {
        "FORGE_URL": "https://dke-forge.com",
        "FORGE_API_KEY": "fga_your_key"
      }
    }
  }
}
```

The server advertises **63 tools** over stdio. Your assistant will discover
them automatically and invoke them when it needs structural facts about
your code.

## 63 Tools, 13 Categories

| Category | Tools |
|---|---|
| **Foundation** | `forge_graph_stats` |
| **Graphs** | `forge_list_graphs`, `forge_create_graph`, `forge_get_graph`, `forge_rename_graph`, `forge_delete_graph`, `forge_promote_default_graph` |
| **Navigation** | `forge_query_function`, `forge_callers_of`, `forge_callees_of`, `forge_depends_on`, `forge_impact_analysis`, `forge_callgraph_reachable`, `forge_find_implementers` |
| **Architecture** | `forge_dead_code`, `forge_subgraph`, `forge_circular_deps`, `forge_god_classes`, `forge_architecture_map`, `forge_api_surface`, `forge_abstractions`, `forge_module_topology` |
| **Change** | `forge_refactor_preview`, `forge_breaking_change`, `forge_deprecation_path`, `forge_risky_change`, `forge_commit_impact`, `forge_review` |
| **Rules** | `forge_rules`, `forge_check_rules`, `forge_declare_rule`, `forge_amend_rule`, `forge_retire_rule` |
| **Provenance** | `forge_contradictions`, `forge_last_modified`, `forge_provenance`, `forge_reasoning_trace` |
| **Patterns** | `forge_patterns`, `forge_pattern_catalog`, `forge_pattern_detail`, `forge_learn_patterns` |
| **Generation-prep** | `forge_envelope` |
| **Ingestion** | `forge_declare` |
| **Reasoning** | `forge_reason_chain`, `forge_audit_changes`, `forge_contradictions_hypothetical`, `forge_reach_from`, `forge_reach_cone`, `forge_use_def`, `forge_reaching_defs`, `forge_live_vars`, `forge_taint`, `forge_effects`, `forge_classify_effects`, `forge_effects_classification`, `forge_type_flow`, `forge_refine`, `forge_contract_check`, `forge_effect_behavioral` |
| **Meta** | `forge_health`, `forge_auth_verify` |
| **Invitations** | `forge_invitation_resend`, `forge_invitation_preview` |

Ingestion covers **8 languages**: C++, C, Python, TypeScript, Go, Rust,
Java, JavaScript. Cross-language relationships resolve into a single
graph by construction &mdash; a Python call into a C++ library surfaces
as a first-class edge.

Full tool reference: [dke-forge.com/mcp.html](https://dke-forge.com/mcp.html)

## What Makes Forge Different

Every MCP tool answer is **provenance-tagged** — you can ask where a claim
came from. Queries are **deterministic** — same graph, same answer.
Contradictions in the graph are surfaced, not hidden. Pattern discovery
has a lifecycle (proposed → supported → confirmed) with confidence
propagation. This is the set of things a graph-native reasoning engine
can do that LLM-plus-grep fundamentally cannot.

## Requirements

- Python 3.8+
- A DKE-Forge account with an API key ([sign up](https://dke-forge.com))

## License

MIT. See [LICENSE](LICENSE).

## Links

- **Homepage:** [dke-forge.com](https://dke-forge.com)
- **API Docs:** [dke-forge.com/docs.html](https://dke-forge.com/docs.html)
- **MCP Guide:** [dke-forge.com/mcp.html](https://dke-forge.com/mcp.html)
