"""
Tests for the alphainfo Python SDK.

These tests verify client construction, input validation, response parsing,
and error handling — all without hitting the real API (mocked with httpx).
"""

import httpx
import pytest

from alphainfo import (
    AlphaInfo,
    AnalysisResult,
    AuditReplay,
    BatchResult,
    HealthStatus,
    MatrixResult,
    VectorResult,
)
from alphainfo.exceptions import (
    APIError,
    AuthError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)

# ---------------------------------------------------------------------------
# Fixtures & helpers
# ---------------------------------------------------------------------------

MOCK_ANALYSIS_RESPONSE = {
    "structural_score": 0.85,
    "change_detected": True,
    "change_score": 0.42,
    "confidence_band": "transition",
    "engine_version": "abc123",
    "analysis_id": "550e8400-e29b-41d4-a716-446655440000",
    "metrics": {"method": "structural_signature"},
    "provenance": None,
    "semantic": {"alert_level": "attention"},
}

MOCK_BATCH_RESPONSE = {
    "results": [
        {
            "index": 0,
            "structural_score": 0.95,
            "change_detected": False,
            "change_score": 0.01,
            "confidence_band": "stable",
            "engine_version": "abc123",
            "analysis_id": "id-0",
        },
        {
            "index": 1,
            "error": "signal too short",
        },
    ],
    "analyses_consumed": 1,
    "total_signals": 2,
}

MOCK_VECTOR_RESPONSE = {
    "analysis_id": "vec-001",
    "structural_score": 0.72,
    "change_detected": True,
    "n_channels": 2,
    "channels": {
        "ch1": {
            "structural_score": 0.72,
            "change_detected": True,
            "change_score": 0.30,
            "confidence_band": "transition",
            "engine_version": "abc123",
        },
        "ch2": {
            "structural_score": 0.95,
            "change_detected": False,
            "change_score": 0.02,
            "confidence_band": "stable",
            "engine_version": "abc123",
        },
    },
    "analyses_consumed": 1,
}

MOCK_HEALTH_RESPONSE = {
    "status": "healthy",
    "version": "2.3.0",
    "message": "alphainfo API is running",
}


def _mock_transport(response_data, status_code=200, headers=None):
    """Create a mock httpx transport that returns a fixed response."""
    resp_headers = {"content-type": "application/json"}
    if headers:
        resp_headers.update(headers)

    def handler(request):
        return httpx.Response(
            status_code=status_code,
            json=response_data,
            headers=resp_headers,
        )

    return httpx.MockTransport(handler)


# ---------------------------------------------------------------------------
# Client construction
# ---------------------------------------------------------------------------

class TestClientConstruction:
    def test_requires_api_key(self):
        with pytest.raises(ValueError, match="api_key"):
            AlphaInfo(api_key="")

    def test_default_base_url(self):
        client = AlphaInfo(api_key="ai_test")
        assert client._base_url == "https://www.alphainfo.io"
        client.close()

    def test_custom_base_url(self):
        client = AlphaInfo(api_key="ai_test", base_url="https://custom.example.com/")
        assert client._base_url == "https://custom.example.com"
        client.close()

    def test_context_manager(self):
        with AlphaInfo(api_key="ai_test") as client:
            assert client._api_key == "ai_test"


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------

class TestInputValidation:
    def test_analyze_empty_signal(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="empty"):
            client.analyze(signal=[], sampling_rate=250.0)
        client.close()

    def test_analyze_negative_rate(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="positive"):
            client.analyze(signal=[1.0, 2.0], sampling_rate=-1.0)
        client.close()

    def test_batch_empty(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="empty"):
            client.analyze_batch(signals=[], sampling_rate=250.0)
        client.close()

    def test_batch_too_large(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="100"):
            client.analyze_batch(signals=[[] for _ in range(101)], sampling_rate=250.0)
        client.close()

    def test_batch_baselines_length_mismatch(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="baselines length"):
            client.analyze_batch(
                signals=[[1.0] * 50, [2.0] * 50],
                sampling_rate=10.0,
                baselines=[[0.0] * 50],  # only 1 baseline for 2 signals
            )
        client.close()

    def test_vector_empty_channels(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="empty"):
            client.analyze_vector(channels={}, sampling_rate=250.0)
        client.close()

    def test_audit_empty_id(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="empty"):
            client.audit_replay(analysis_id="")
        client.close()


# ---------------------------------------------------------------------------
# Response parsing
# ---------------------------------------------------------------------------

class TestResponseParsing:
    def test_analyze_response(self):
        transport = _mock_transport(MOCK_ANALYSIS_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)

        result = client.analyze(signal=[1.0] * 100, sampling_rate=250.0)

        assert isinstance(result, AnalysisResult)
        assert result.structural_score == 0.85
        assert result.change_detected is True
        assert result.confidence_band == "transition"
        assert result.analysis_id == "550e8400-e29b-41d4-a716-446655440000"
        assert result.semantic is not None
        assert result.semantic.alert_level == "attention"
        client.close()

    def test_batch_response(self):
        transport = _mock_transport(MOCK_BATCH_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)

        result = client.analyze_batch(
            signals=[[1.0] * 100, [2.0] * 5],
            sampling_rate=250.0,
        )

        assert isinstance(result, BatchResult)
        assert result.total_signals == 2
        assert len(result.successful) == 1
        assert len(result.failed) == 1
        assert result.results[0].structural_score == 0.95
        assert result.results[1].error == "signal too short"
        client.close()

    def test_vector_response(self):
        transport = _mock_transport(MOCK_VECTOR_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)

        result = client.analyze_vector(
            channels={"ch1": [1.0] * 100, "ch2": [2.0] * 100},
            sampling_rate=250.0,
        )

        assert isinstance(result, VectorResult)
        assert result.n_channels == 2
        assert result.change_detected is True
        assert "ch1" in result.channels
        assert result.channels["ch2"].confidence_band == "stable"
        client.close()

    def test_health_response(self):
        transport = _mock_transport(MOCK_HEALTH_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)

        health = client.health()

        assert isinstance(health, HealthStatus)
        assert health.is_healthy()
        assert health.version == "2.3.0"
        client.close()


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    def test_401_raises_auth_error(self):
        transport = _mock_transport({"detail": "Invalid API key"}, status_code=401)
        client = AlphaInfo(api_key="ai_bad", max_retries=0)
        client._client = httpx.Client(transport=transport)

        with pytest.raises(AuthError):
            client.analyze(signal=[1.0] * 100, sampling_rate=250.0)
        client.close()

    def test_400_raises_validation_error(self):
        transport = _mock_transport({"detail": "signal too short"}, status_code=400)
        client = AlphaInfo(api_key="ai_test", max_retries=0)
        client._client = httpx.Client(transport=transport)

        with pytest.raises(ValidationError):
            client.analyze(signal=[1.0] * 100, sampling_rate=250.0)
        client.close()

    def test_404_raises_not_found(self):
        transport = _mock_transport({"detail": "Analysis not found"}, status_code=404)
        client = AlphaInfo(api_key="ai_test", max_retries=0)
        client._client = httpx.Client(transport=transport)

        with pytest.raises(NotFoundError):
            client.audit_replay("nonexistent-id")
        client.close()

    def test_429_raises_rate_limit(self):
        transport = _mock_transport(
            {"detail": {"error": "rate_limit", "message": "Too many requests"}},
            status_code=429,
            headers={"Retry-After": "30"},
        )
        client = AlphaInfo(api_key="ai_test", max_retries=0)
        client._client = httpx.Client(transport=transport)

        with pytest.raises(RateLimitError) as exc_info:
            client.analyze(signal=[1.0] * 100, sampling_rate=250.0)
        assert exc_info.value.retry_after == 30
        client.close()

    def test_500_raises_api_error(self):
        transport = _mock_transport({"detail": "Internal error"}, status_code=500)
        client = AlphaInfo(api_key="ai_test", max_retries=0)
        client._client = httpx.Client(transport=transport)

        with pytest.raises(APIError):
            client.analyze(signal=[1.0] * 100, sampling_rate=250.0)
        client.close()


# ---------------------------------------------------------------------------
# Rate limit tracking
# ---------------------------------------------------------------------------

class TestRateLimit:
    def test_extracts_rate_limit_headers(self):
        transport = _mock_transport(
            MOCK_ANALYSIS_RESPONSE,
            headers={
                "x-ratelimit-limit": "1000",
                "x-ratelimit-remaining": "999",
                "x-ratelimit-reset": "1700000000",
            },
        )
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)

        client.analyze(signal=[1.0] * 100, sampling_rate=250.0)

        info = client.rate_limit_info
        assert info is not None
        assert info.limit == 1000
        assert info.remaining == 999
        client.close()

    def test_no_rate_limit_headers(self):
        transport = _mock_transport(MOCK_HEALTH_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)

        client.health()
        assert client.rate_limit_info is None
        client.close()


# ---------------------------------------------------------------------------
# Repr & properties
# ---------------------------------------------------------------------------

class TestRepr:
    def test_analysis_result_repr(self):
        from alphainfo.models import AnalysisResult
        r = AnalysisResult(
            structural_score=0.85, change_detected=True, change_score=0.42,
            confidence_band="transition", engine_version="v1", analysis_id="id-1",
        )
        assert "0.850" in repr(r)
        assert "transition" in repr(r)

    def test_batch_result_properties(self):
        from alphainfo.models import BatchItemResult, BatchResult
        items = [
            BatchItemResult(index=0, structural_score=0.9, confidence_band="stable"),
            BatchItemResult(index=1, error="too short"),
        ]
        batch = BatchResult(results=items, analyses_consumed=1, total_signals=2)
        assert len(batch.successful) == 1
        assert len(batch.failed) == 1

    def test_batch_result_iterable(self):
        """BatchResult must be iterable: for r in batch works."""
        from alphainfo.models import BatchItemResult, BatchResult
        items = [
            BatchItemResult(index=0, structural_score=0.9, confidence_band="stable"),
            BatchItemResult(index=1, structural_score=0.7, confidence_band="transition"),
        ]
        batch = BatchResult(results=items, analyses_consumed=2, total_signals=2)
        # for ... in batch
        collected = [r for r in batch]
        assert len(collected) == 2
        assert collected[0].index == 0
        assert collected[1].index == 1
        # len()
        assert len(batch) == 2
        # indexing
        assert batch[0].structural_score == 0.9
        assert batch[1].structural_score == 0.7

    def test_analysis_result_no_composite(self):
        """composite was never a public field — accessing it raises AttributeError."""
        from alphainfo.models import AnalysisResult
        r = AnalysisResult(
            structural_score=0.85, change_detected=False, change_score=0.1,
            confidence_band="stable", engine_version="v1", analysis_id="id-1",
        )
        assert not hasattr(r, "composite")
        # safe pattern for clients: getattr with default
        assert getattr(r, "composite", None) is None


# ---------------------------------------------------------------------------
# Security: ensure NO engine code is exposed
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Contract tests: ensure every API field maps to an SDK attribute
# ---------------------------------------------------------------------------

class TestContractAnalyze:
    """Every field in a full API /v1/analyze/stream response must be
    accessible as a direct attribute on AnalysisResult or SemanticResult."""

    FULL_API_RESPONSE = {
        "structural_score": 0.25,
        "change_detected": True,
        "change_score": 0.75,
        "confidence_band": "unstable",
        "engine_version": "abc123",
        "analysis_id": "id-contract-1",
        "metrics": {"sim_spectral": 0.3},
        "provenance": None,
        "warning": "Signal has only 30 samples. Minimum ~50 samples needed.",
        "semantic": {
            "alert_level": "critical",
            "divergence_level": "high",
            "severity": "high",
            "severity_score": 75.0,
            "recommended_action": "immediate_human_review",
            "summary": "⚠️ Structural divergence detected (severity: high)",
            "trend": "diverging",
            "interpretation": "Significant structural change detected.",
            "human_readable": "⚠️ Structural divergence detected (severity: high)",
        },
    }

    def test_all_top_level_fields_mapped(self):
        transport = _mock_transport(self.FULL_API_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.analyze(signal=[1.0] * 100, sampling_rate=250.0)

        # Core fields
        assert r.structural_score == 0.25
        assert r.change_detected is True
        assert r.change_score == 0.75
        assert r.confidence_band == "unstable"
        assert r.engine_version == "abc123"
        assert r.analysis_id == "id-contract-1"
        assert r.metrics is not None
        assert r.warning == "Signal has only 30 samples. Minimum ~50 samples needed."
        client.close()

    def test_all_semantic_fields_mapped(self):
        transport = _mock_transport(self.FULL_API_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.analyze(signal=[1.0] * 100, sampling_rate=250.0)

        s = r.semantic
        assert s is not None
        assert s.alert_level == "critical"
        assert s.alert_level in ("normal", "attention", "alert", "critical")
        assert s.recommended_action == "immediate_human_review"
        assert s.severity == "high"
        assert s.severity_score == 75.0
        assert s.summary == "⚠️ Structural divergence detected (severity: high)"
        assert s.trend == "diverging"
        client.close()

    def test_semantic_none_when_absent(self):
        resp = {k: v for k, v in self.FULL_API_RESPONSE.items() if k != "semantic"}
        resp["semantic"] = None
        transport = _mock_transport(resp)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.analyze(signal=[1.0] * 100, sampling_rate=250.0)
        assert r.semantic is None
        assert r.warning is not None  # warning is independent of semantic
        client.close()


class TestContractVector:
    """Every field in a full API /v1/analyze/vector response must map."""

    FULL_API_RESPONSE = {
        "analysis_id": "vec-contract-1",
        "structural_score": 0.65,
        "change_detected": True,
        "change_score": 0.48,
        "confidence_band": "transition",
        "n_channels": 2,
        "channels": {
            "ch1": {
                "structural_score": 0.65,
                "change_detected": True,
                "change_score": 0.48,
                "confidence_band": "transition",
                "engine_version": "abc123",
            },
            "ch2": {
                "structural_score": 0.92,
                "change_detected": False,
                "change_score": 0.05,
                "confidence_band": "stable",
                "engine_version": "abc123",
            },
        },
        "analyses_consumed": 1,
        "warning": "Channels ch1 have fewer than 50 samples.",
    }

    def test_all_top_level_fields_mapped(self):
        transport = _mock_transport(self.FULL_API_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.analyze_vector(
            channels={"ch1": [1.0] * 50, "ch2": [2.0] * 100},
            sampling_rate=250.0,
        )
        assert r.analysis_id == "vec-contract-1"
        assert r.structural_score == 0.65
        assert r.change_detected is True
        assert r.change_score == 0.48
        assert r.confidence_band == "transition"
        assert r.n_channels == 2
        assert r.analyses_consumed == 1
        assert r.warning == "Channels ch1 have fewer than 50 samples."
        client.close()

    def test_channel_results_mapped(self):
        transport = _mock_transport(self.FULL_API_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.analyze_vector(
            channels={"ch1": [1.0] * 50, "ch2": [2.0] * 100},
            sampling_rate=250.0,
        )
        assert "ch1" in r.channels
        assert r.channels["ch1"].structural_score == 0.65
        assert r.channels["ch1"].confidence_band == "transition"
        assert r.channels["ch2"].structural_score == 0.92
        assert r.channels["ch2"].confidence_band == "stable"
        client.close()


class TestContractBatch:
    """Batch response contract — results, consumed, totals."""

    FULL_API_RESPONSE = {
        "results": [
            {
                "index": 0,
                "structural_score": 0.88,
                "change_detected": False,
                "change_score": 0.12,
                "confidence_band": "stable",
                "engine_version": "abc123",
                "analysis_id": "batch-0",
                "metrics": {"sim_spectral": 0.9},
                "semantic": {
                    "alert_level": "normal",
                    "severity": "none",
                    "severity_score": 12.0,
                    "recommended_action": "log_only",
                    "summary": "✅ Stable (structural: 0.88)",
                    "trend": "stable",
                },
            },
            {
                "index": 1,
                "error": "Signal too short (minimum 10 samples)",
            },
        ],
        "analyses_consumed": 1,
        "total_signals": 2,
    }

    def test_batch_fields_mapped(self):
        transport = _mock_transport(self.FULL_API_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.analyze_batch(
            signals=[[1.0] * 100, [1.0]],
            sampling_rate=250.0,
        )
        assert r.analyses_consumed == 1
        assert r.total_signals == 2
        assert len(r.successful) == 1
        assert len(r.failed) == 1
        ok = r.results[0]
        assert ok.structural_score == 0.88
        assert ok.confidence_band == "stable"
        assert ok.analysis_id == "batch-0"
        fail = r.results[1]
        assert fail.error == "Signal too short (minimum 10 samples)"
        client.close()

    def test_batch_with_baselines_payload(self):
        """Verify baselines are included in the request payload."""
        payloads = []

        class CaptureTransport(httpx.BaseTransport):
            def handle_request(self, request):
                import json as _json
                payloads.append(_json.loads(request.content))
                return httpx.Response(200, json=TestContractBatch.FULL_API_RESPONSE)

        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=CaptureTransport())
        client.analyze_batch(
            signals=[[1.0] * 50, [2.0] * 50],
            sampling_rate=10.0,
            baselines=[[0.0] * 50, None],
        )
        assert "baselines" in payloads[0]
        assert payloads[0]["baselines"][0] == [0.0] * 50
        assert payloads[0]["baselines"][1] is None
        client.close()

    def test_batch_without_baselines_no_key(self):
        """Verify baselines key is omitted when not provided."""
        payloads = []

        class CaptureTransport(httpx.BaseTransport):
            def handle_request(self, request):
                import json as _json
                payloads.append(_json.loads(request.content))
                return httpx.Response(200, json=TestContractBatch.FULL_API_RESPONSE)

        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=CaptureTransport())
        client.analyze_batch(
            signals=[[1.0] * 50, [2.0] * 50],
            sampling_rate=10.0,
        )
        assert "baselines" not in payloads[0]
        client.close()


class TestContractMatrix:
    """Matrix endpoint contract."""

    FULL_API_RESPONSE = {
        "matrix": [[1.0, 0.72, 0.15], [0.72, 1.0, 0.83], [0.15, 0.83, 1.0]],
        "labels": ["signal_0", "signal_1", "signal_2"],
        "n_signals": 3,
        "n_pairs": 3,
        "analyses_consumed": 3,
    }

    def test_matrix_fields_mapped(self):
        transport = _mock_transport(self.FULL_API_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.analyze_matrix(
            signals=[[1.0] * 50, [2.0] * 50, [3.0] * 50],
            sampling_rate=10.0,
        )
        assert isinstance(r, MatrixResult)
        assert r.n_signals == 3
        assert r.n_pairs == 3
        assert r.analyses_consumed == 3
        assert len(r.matrix) == 3
        assert r.score(0, 1) == 0.72
        assert r.score(1, 2) == 0.83
        assert r.score(0, 0) == 1.0
        client.close()

    def test_matrix_most_similar(self):
        transport = _mock_transport(self.FULL_API_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.analyze_matrix(
            signals=[[1.0] * 50, [2.0] * 50, [3.0] * 50],
            sampling_rate=10.0,
        )
        assert r.most_similar(0) == 1   # 0.72 > 0.15
        assert r.most_different(0) == 2  # 0.15 < 0.72
        client.close()

    def test_matrix_validation_too_few(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="at least 2"):
            client.analyze_matrix(signals=[[1.0] * 50], sampling_rate=10.0)
        client.close()

    def test_matrix_validation_too_many(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="50"):
            client.analyze_matrix(
                signals=[[] for _ in range(51)], sampling_rate=10.0,
            )
        client.close()


class TestContractAuditReplay:
    """AuditReplay field contract."""

    FULL_API_RESPONSE = {
        "analysis_id": "audit-001",
        "timestamp": "2026-04-09T14:30:00",
        "signal_length": 500,
        "n_samples": 500,
        "parameters": {"domain": "finance", "sampling_rate": 250.0},
        "output": {"structural_score": 0.72, "change_detected": True},
        "engine_version": "abc123",
        "client_id": "client-x",
        "request_id": "req-y",
    }

    def test_replay_fields_mapped(self):
        transport = _mock_transport(self.FULL_API_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.audit_replay("audit-001")
        assert isinstance(r, AuditReplay)
        assert r.analysis_id == "audit-001"
        assert r.signal_length == 500
        assert r.sampling_rate == 250.0
        assert r.output["structural_score"] == 0.72
        assert r.engine_version == "abc123"
        client.close()

    def test_sampling_rate_from_parameters(self):
        """Bug fix: sampling_rate lives inside parameters, not top-level."""
        resp = {
            "analysis_id": "audit-002",
            "timestamp": "2026-04-09T15:00:00",
            "signal_length": 1000,
            "n_samples": 1000,
            "parameters": {"domain": "biomedical", "sampling_rate": 500.0},
            "output": {"structural_score": 0.9},
            "engine_version": "abc123",
        }
        # No top-level sampling_rate — must read from parameters
        transport = _mock_transport(resp)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.audit_replay("audit-002")
        assert r.sampling_rate == 500.0  # was 0.0 before fix
        client.close()


class TestAuditPathRegression:
    """Regression tests for audit replay edge cases — run in CI."""

    def test_signal_length_fallback_to_n_samples(self):
        """Old audit logs may only have n_samples, not signal_length."""
        resp = {
            "analysis_id": "audit-old-001",
            "timestamp": "2026-01-01T00:00:00",
            "n_samples": 300,
            # no signal_length field
            "parameters": {"domain": "generic", "sampling_rate": 100.0},
            "output": {"structural_score": 0.5},
            "engine_version": "old-v1",
        }
        transport = _mock_transport(resp)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.audit_replay("audit-old-001")
        assert r.signal_length == 300  # fallback to n_samples
        assert r.sampling_rate == 100.0
        client.close()

    def test_missing_both_length_fields(self):
        """Neither signal_length nor n_samples — should default to 0."""
        resp = {
            "analysis_id": "audit-empty-001",
            "timestamp": "2026-01-01T00:00:00",
            "parameters": {"domain": "generic"},
            "output": {},
            "engine_version": "v1",
        }
        transport = _mock_transport(resp)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.audit_replay("audit-empty-001")
        assert r.signal_length == 0
        assert r.sampling_rate == 0.0
        client.close()

    def test_sampling_rate_zero_when_no_parameters(self):
        """No parameters dict at all."""
        resp = {
            "analysis_id": "audit-noparam-001",
            "timestamp": "2026-01-01T00:00:00",
            "signal_length": 50,
            "output": {},
            "engine_version": "v1",
        }
        transport = _mock_transport(resp)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.audit_replay("audit-noparam-001")
        assert r.signal_length == 50
        assert r.sampling_rate == 0.0
        assert r.parameters == {}
        client.close()

    def test_output_preserves_all_fields(self):
        """Audit output dict must be passed through intact."""
        output = {
            "structural_score": 0.33,
            "change_detected": True,
            "change_score": 0.88,
            "confidence_band": "unstable",
            "metrics": {"sim_spectral": 0.1, "sim_temporal": 0.2},
        }
        resp = {
            "analysis_id": "audit-full-001",
            "timestamp": "2026-04-09T12:00:00",
            "signal_length": 1000,
            "parameters": {"sampling_rate": 256.0, "domain": "biomedical"},
            "output": output,
            "engine_version": "v2",
            "client_id": "test-client",
            "request_id": "req-123",
        }
        transport = _mock_transport(resp)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        r = client.audit_replay("audit-full-001")
        assert r.output == output
        assert r.client_id == "test-client"
        assert r.request_id == "req-123"
        client.close()


class TestContractPlans:
    """PlanInfo field contract — including Enterprise unlimited."""

    MOCK_PLANS_RESPONSE = {
        "plans": [
            {
                "id": 1, "name": "Free", "slug": "free",
                "price_cents": 0, "currency": "USD",
                "monthly_limit": 100, "features": {"batch": False},
            },
            {
                "id": 4, "name": "Enterprise", "slug": "enterprise",
                "price_cents": 49900, "currency": "USD",
                "monthly_limit": -1, "features": {"batch": True, "vector": True},
            },
        ]
    }

    def test_enterprise_unlimited(self):
        transport = _mock_transport(self.MOCK_PLANS_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)
        plans = client.plans()
        free = plans[0]
        enterprise = plans[1]
        assert free.monthly_limit == 100
        assert not free.is_unlimited
        assert enterprise.monthly_limit == -1
        assert enterprise.is_unlimited
        assert "unlimited" in repr(enterprise)
        client.close()


class TestSecurity:
    """Verify the SDK contains zero proprietary engine code."""

    def test_no_engine_imports(self):
        """SDK must not import from core/, metrics/, or config/."""
        import alphainfo
        import alphainfo.client
        import alphainfo.exceptions
        import alphainfo.models

        for mod in [alphainfo, alphainfo.client, alphainfo.models, alphainfo.exceptions]:
            source = open(mod.__file__).read()
            assert "from core" not in source, f"{mod.__name__} imports from core/"
            assert "from metrics" not in source, f"{mod.__name__} imports from metrics/"
            assert "from config" not in source, f"{mod.__name__} imports from config/"
            assert "structural_engine" not in source.lower(), (
                f"{mod.__name__} references engine")
            assert "structural_kernel" not in source.lower(), (
                f"{mod.__name__} references kernel module")
            # Historical language-of-use sentinels — fail loudly if any
            # implementation-family term ever creeps back into an SDK file.
            # Strings concatenated so this guard itself doesn't grep-leak.
            _forbidden_substrings = (
                "c" + "urvature",
                "f" + "isher",
                "b" + "utterworth",
                "sc" + "ale_entropy",
            )
            for _term in _forbidden_substrings:
                assert _term not in source.lower(), (
                    f"{mod.__name__} leaks {_term!r}")

    def test_no_algorithm_exposure(self):
        """SDK must not contain algorithmic details."""
        import alphainfo.client
        import alphainfo.models

        for mod in [alphainfo.client, alphainfo.models]:
            source = open(mod.__file__).read()
            # No numpy / scipy / signal processing
            assert "import numpy" not in source
            assert "import scipy" not in source
            assert "from numpy" not in source
            # No algorithm names
            assert "eigenvalue" not in source.lower()
            assert "hessian" not in source.lower()
            assert "kolmogorov" not in source.lower()
            assert "wasserstein" not in source.lower()
