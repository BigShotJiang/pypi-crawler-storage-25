"""
sdk/tests/test_async_cleanup.py — Block 1.2

Regression coverage for the ResourceWarning that can leak from an
un-closed AsyncAlphaInfo client. The Python SDK uses two layered mechanisms:

  1. ``async with AsyncAlphaInfo(...) as client`` — the idiomatic path.
     __aenter__ / __aexit__ close the underlying httpx.AsyncClient.
  2. weakref.finalize hook — fires if the caller forgets (1) AND the
     instance is garbage-collected before aclose() is awaited. Emits a
     friendlier ResourceWarning pointing at the fix.

The tests below cover three scenarios:

  • test_async_context_manager_no_warnings:
      Proper ``async with`` usage → zero warnings emitted.

  • test_explicit_close_no_warnings:
      Manual ``await client.close()`` → zero warnings.

  • test_forgotten_close_emits_resource_warning:
      Deliberate leak → our weakref finalizer fires with a helpful message.
"""

from __future__ import annotations

import asyncio
import gc
import warnings

import pytest

from alphainfo import AsyncAlphaInfo


@pytest.mark.asyncio
async def test_async_context_manager_no_warnings():
    """The idiomatic path must NOT emit any ResourceWarning."""
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        async with AsyncAlphaInfo(api_key="ai_test_fake") as client:
            assert client is not None
        # Allow httpx's background tasks to settle
        await asyncio.sleep(0)

    resource_warnings = [
        w for w in captured
        if issubclass(w.category, ResourceWarning)
    ]
    assert resource_warnings == [], (
        "context-manager path must not leak sockets: "
        f"{[str(w.message) for w in resource_warnings]}"
    )


@pytest.mark.asyncio
async def test_explicit_close_no_warnings():
    """Manual ``await client.close()`` must also be warning-free."""
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        client = AsyncAlphaInfo(api_key="ai_test_fake")
        await client.close()
        await asyncio.sleep(0)

    resource_warnings = [
        w for w in captured
        if issubclass(w.category, ResourceWarning)
    ]
    assert resource_warnings == [], (
        "explicit close() must not leak sockets: "
        f"{[str(w.message) for w in resource_warnings]}"
    )


def test_forgotten_close_emits_resource_warning():
    """If the caller forgets to close, the weakref finalize hook must fire
    with a ResourceWarning pointing at the idiomatic fix."""
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")

        # Instantiate inside an event loop so httpx.AsyncClient constructs
        # without complaints, then drop the reference without closing.
        def _leak():
            client = AsyncAlphaInfo(api_key="ai_test_fake")
            # deliberately do NOT close — simulates a caller bug
            return id(client)

        asyncio.run(asyncio.coroutine(lambda: _leak())()) if False else _leak()
        gc.collect()

    resource_warnings = [
        w for w in captured
        if issubclass(w.category, ResourceWarning)
    ]
    # At least one ResourceWarning must be emitted, and it must mention
    # the remedy — "async with" or "await client.close()".
    assert resource_warnings, (
        "expected ResourceWarning from the weakref finalizer; got none"
    )
    messages = " | ".join(str(w.message) for w in resource_warnings)
    assert "async with" in messages or "close()" in messages, (
        f"warning text must guide the caller to the fix: {messages!r}"
    )
