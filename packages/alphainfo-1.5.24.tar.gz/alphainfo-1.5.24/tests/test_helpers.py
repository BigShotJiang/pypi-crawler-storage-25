"""
Tests for the high-level intent-based helpers added in 1.5.21.

Exercises ``compare``, ``detect_internal_change``, ``analyze_windowed`` and
``fit_parameter_grid`` on :class:`AlphaInfo`. We do not hit the real API
— every test uses ``httpx.MockTransport`` swapped onto the client's
private ``_client`` attribute (the same pattern as tests/test_sdk.py).
"""

from __future__ import annotations

import httpx
import pytest

from alphainfo import AlphaInfo


# ---------------------------------------------------------------------------
# Mock responses
# ---------------------------------------------------------------------------

MOCK_ANALYSIS = {
    "structural_score": 0.83,
    "change_detected": True,
    "change_score": 0.17,
    "confidence_band": "transition",
    "engine_version": "abc123",
    "analysis_id": "id-analysis-1",
    "metrics": {"method": "structural_signature"},
    "provenance": None,
    "semantic": {"alert_level": "attention"},
}


def _batch_response_for_scores(scores):
    """Build a /v1/analyze/batch payload with given per-window scores."""
    results = []
    for i, score in enumerate(scores):
        results.append(
            {
                "index": i,
                "structural_score": float(score),
                "change_detected": score < 0.6,
                "change_score": float(1.0 - score),
                "confidence_band": "stable" if score > 0.7 else "transition",
                "engine_version": "abc123",
                "analysis_id": f"batch-id-{i}",
            }
        )
    return {
        "results": results,
        "analyses_consumed": len(scores),
        "total_signals": len(scores),
    }


def _swap_transport(client, response_factory):
    """Replace ``client._client`` with one that calls ``response_factory(request)``.

    The factory should return either a JSON-serialisable dict (used as the
    response body, status 200) or an ``httpx.Response`` directly.
    """
    def handler(request):
        out = response_factory(request)
        if isinstance(out, httpx.Response):
            return out
        return httpx.Response(
            status_code=200,
            json=out,
            headers={"content-type": "application/json"},
        )

    transport = httpx.MockTransport(handler)
    # Replace the underlying client only; keep auth headers etc. intact.
    client._client.close()
    client._client = httpx.Client(transport=transport)


# ---------------------------------------------------------------------------
# compare()
# ---------------------------------------------------------------------------


class TestCompare:
    def test_compare_calls_analyze_with_baseline(self):
        captured = {}

        def factory(request):
            captured["body"] = request.read().decode()
            captured["url"] = str(request.url)
            return MOCK_ANALYSIS

        client = AlphaInfo(api_key="ai_test")
        _swap_transport(client, factory)

        result = client.compare(
            signal=[1.0] * 100,
            baseline=[1.0] * 100,
            sampling_rate=1.0,
        )
        client.close()

        assert result.structural_score == 0.83
        assert "baseline" in captured["body"]
        assert "/v1/analyze" in captured["url"]
        assert "/v1/analyze/auto" not in captured["url"]

    def test_compare_intent_arg_doesnt_break(self):
        client = AlphaInfo(api_key="ai_test")
        _swap_transport(client, lambda req: MOCK_ANALYSIS)

        for intent in (
            "regime_change",
            "similarity_general",
            "amplitude_sensitive",
            "amplitude_invariant",
            "frequency_sensitive",
            "distribution_shift",
        ):
            r = client.compare(
                signal=[1.0] * 100, baseline=[1.0] * 100, intent=intent,
            )
            assert r.structural_score == 0.83

        client.close()


# ---------------------------------------------------------------------------
# detect_internal_change()
# ---------------------------------------------------------------------------


class TestDetectInternalChange:
    def test_detect_internal_change_no_baseline_in_payload(self):
        captured = {}

        def factory(request):
            captured["body"] = request.read().decode()
            return MOCK_ANALYSIS

        client = AlphaInfo(api_key="ai_test")
        _swap_transport(client, factory)

        result = client.detect_internal_change(
            signal=[1.0] * 200, sampling_rate=1.0,
        )
        client.close()

        assert result.structural_score == 0.83
        assert '"baseline"' not in captured["body"]


# ---------------------------------------------------------------------------
# analyze_windowed()
# ---------------------------------------------------------------------------


class TestAnalyzeWindowed:
    def test_basic_window_slicing(self):
        # 1000-sample signal, 200-sample windows, step=100
        # → expected window count = (1000-200)/100 + 1 = 9
        scores = [0.9, 0.85, 0.8, 0.5, 0.2, 0.5, 0.8, 0.85, 0.9]
        client = AlphaInfo(api_key="ai_test")
        _swap_transport(client, lambda req: _batch_response_for_scores(scores))

        out = client.analyze_windowed(
            signal=list(range(1000)),
            window_size=200,
            step=100,
        )
        client.close()

        assert len(out["windows"]) == 9
        first = out["windows"][0]
        assert first[0] == 0
        assert first[1] == 200
        assert first[2] == 0.9
        # worst should be the dip at score=0.2 (index 4 → start=400)
        assert out["worst_window"] == (400, 600, 0.2)
        assert out["best_window"][2] == 0.9
        assert out["window_size"] == 200
        assert out["step"] == 100

    def test_window_size_too_small(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValueError, match="window_size must be >= 10"):
            client.analyze_windowed(signal=[1.0] * 100, window_size=5, step=1)
        client.close()

    def test_step_too_small(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValueError, match="step must be >= 1"):
            client.analyze_windowed(signal=[1.0] * 100, window_size=20, step=0)
        client.close()

    def test_signal_shorter_than_window(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValueError, match="signal too short"):
            client.analyze_windowed(signal=[1.0] * 50, window_size=200, step=10)
        client.close()


# ---------------------------------------------------------------------------
# fit_parameter_grid()
# ---------------------------------------------------------------------------


class TestFitParameterGrid:
    def test_ranks_candidates_by_score(self):
        scores = [0.55, 0.92, 0.71]
        client = AlphaInfo(api_key="ai_test")
        _swap_transport(client, lambda req: _batch_response_for_scores(scores))

        out = client.fit_parameter_grid(
            target_signal=[1.0] * 100,
            candidates={
                "k=1.0": [1.0] * 100,
                "k=1.5": [1.5] * 100,
                "k=2.0": [2.0] * 100,
            },
        )
        client.close()

        # Best should be k=1.5 (highest score 0.92)
        assert out["best"][0] == "k=1.5"
        assert out["best"][1] == 0.92
        # Ranked descending by score
        assert out["ranked"][0][0] == "k=1.5"
        assert out["ranked"][1][0] == "k=2.0"
        assert out["ranked"][2][0] == "k=1.0"

    def test_empty_candidates_raises(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValueError, match="empty"):
            client.fit_parameter_grid(
                target_signal=[1.0] * 100, candidates={},
            )
        client.close()
