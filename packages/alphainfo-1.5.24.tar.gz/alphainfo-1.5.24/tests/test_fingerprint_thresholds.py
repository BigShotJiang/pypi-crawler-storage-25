"""
Tests for the fingerprint length threshold constants + warning behaviour.

These tests pin down the public contract for what the SDK claims about
minimum signal lengths. If the backend's actual threshold drifts, we
want the test suite to tell us before users do.

The "actual threshold matches constant" test is skipped unless the caller
sets ``ALPHAINFO_API_KEY`` — it requires hitting the live API.
"""

from __future__ import annotations

import math
import os
import warnings

import pytest

from alphainfo import (
    MIN_FINGERPRINT_SAMPLES,
    MIN_FINGERPRINT_SAMPLES_WITH_BASELINE,
    AlphaInfo,
    FingerprintResult,
)


def _sine(n: int) -> list[float]:
    return [math.sin(i / 10) for i in range(n)]


# ---------------------------------------------------------------------------
# Constants are the values the SDK and docs claim
# ---------------------------------------------------------------------------

def test_min_samples_constant_matches_documented_value():
    """Any change to this constant must be intentional and reflected in
    /v1/guide, the README, and the client.fingerprint() docstring."""
    assert MIN_FINGERPRINT_SAMPLES == 192
    assert MIN_FINGERPRINT_SAMPLES_WITH_BASELINE == 50
    assert MIN_FINGERPRINT_SAMPLES > MIN_FINGERPRINT_SAMPLES_WITH_BASELINE


# ---------------------------------------------------------------------------
# Client warns when a signal is below the threshold
# ---------------------------------------------------------------------------

def test_fingerprint_warns_when_signal_too_short_no_baseline(monkeypatch):
    """Below the threshold without baseline → one UserWarning before any HTTP call."""
    client = AlphaInfo(api_key="ai_test_key", base_url="http://127.0.0.1:1")

    # Short-circuit the HTTP call so the test doesn't hit the network.
    def fake_request(*a, **kw):
        return {
            "analysis_id": "t", "structural_score": 0.5, "change_score": 0.5,
            "change_detected": False, "confidence_band": "transition",
            "engine_version": "test", "metrics": {
                "sim_local": None, "sim_spectral": None, "sim_fractal": None,
                "sim_transition": None, "sim_trend": None,
                "fingerprint_available": False,
                "fingerprint_reason": "signal_too_short",
            },
        }
    monkeypatch.setattr(client, "_request", fake_request)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        fp = client.fingerprint(signal=_sine(50), sampling_rate=1.0)

    short = [w for w in caught if issubclass(w.category, UserWarning)]
    assert len(short) == 1, "expected exactly one UserWarning for short signal"
    assert "50 samples" in str(short[0].message)
    assert str(MIN_FINGERPRINT_SAMPLES) in str(short[0].message)
    assert isinstance(fp, FingerprintResult)


def test_fingerprint_does_not_warn_at_or_above_threshold(monkeypatch):
    client = AlphaInfo(api_key="ai_test_key", base_url="http://127.0.0.1:1")
    monkeypatch.setattr(client, "_request", lambda *a, **kw: {
        "analysis_id": "t", "structural_score": 0.9, "change_score": 0.1,
        "change_detected": False, "confidence_band": "stable",
        "engine_version": "test", "metrics": {
            "sim_local": 0.9, "sim_spectral": 0.9, "sim_fractal": 0.9,
            "sim_transition": 0.9, "sim_trend": 0.9,
            "fingerprint_available": True, "fingerprint_reason": None,
        },
    })

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        client.fingerprint(signal=_sine(MIN_FINGERPRINT_SAMPLES), sampling_rate=1.0)
    assert [w for w in caught if issubclass(w.category, UserWarning)] == []


def test_fingerprint_uses_lower_threshold_with_baseline(monkeypatch):
    """A 60-sample signal is too short without baseline, but fine WITH one."""
    client = AlphaInfo(api_key="ai_test_key", base_url="http://127.0.0.1:1")
    monkeypatch.setattr(client, "_request", lambda *a, **kw: {
        "analysis_id": "t", "structural_score": 0.9, "change_score": 0.1,
        "change_detected": False, "confidence_band": "stable",
        "engine_version": "test", "metrics": {
            "sim_local": 0.9, "sim_spectral": 0.9, "sim_fractal": 0.9,
            "sim_transition": 0.9, "sim_trend": 0.9,
            "fingerprint_available": True, "fingerprint_reason": None,
        },
    })

    # 60 samples >= 50 (MIN_FINGERPRINT_SAMPLES_WITH_BASELINE), baseline given → no warn.
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        client.fingerprint(signal=_sine(60), sampling_rate=1.0, baseline=_sine(60))
    fingerprint_warns = [
        w for w in caught
        if issubclass(w.category, UserWarning)
        and "fingerprint" in str(w.message).lower()
    ]
    assert fingerprint_warns == []

    # 30 samples is below BOTH thresholds — warn even with baseline.
    # (Filter for the fingerprint-specific warning; the generic
    # signal-quality validator added in 1.5.22 also warns separately
    # about short signals — both are user-facing and carry different
    # recipe pointers.)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        client.fingerprint(signal=_sine(30), sampling_rate=1.0, baseline=_sine(30))
    fingerprint_warns = [
        w for w in caught
        if issubclass(w.category, UserWarning)
        and "fingerprint" in str(w.message).lower()
    ]
    assert len(fingerprint_warns) == 1


# ---------------------------------------------------------------------------
# __repr__ mentions the threshold when reason is signal_too_short
# ---------------------------------------------------------------------------

def test_repr_for_signal_too_short_includes_threshold():
    fp = FingerprintResult(
        analysis_id="t", structural_score=0.5, confidence_band="transition",
        sim_local=None, sim_spectral=None, sim_fractal=None,
        sim_transition=None, sim_trend=None,
        fingerprint_available=False, fingerprint_reason="signal_too_short",
    )
    r = repr(fp)
    assert "signal_too_short" in r
    assert str(MIN_FINGERPRINT_SAMPLES) in r
    assert str(MIN_FINGERPRINT_SAMPLES_WITH_BASELINE) in r


def test_repr_for_other_reason_omits_threshold():
    fp = FingerprintResult(
        analysis_id="t", structural_score=1.0, confidence_band="stable",
        sim_local=None, sim_spectral=None, sim_fractal=None,
        sim_transition=None, sim_trend=None,
        fingerprint_available=False, fingerprint_reason="structural_degenerate",
    )
    r = repr(fp)
    assert "structural_degenerate" in r
    # Don't mis-mention the minimum-samples threshold for degenerate cases.
    assert str(MIN_FINGERPRINT_SAMPLES) not in r


# ---------------------------------------------------------------------------
# Live check — constant must still match the actual server behavior
# ---------------------------------------------------------------------------

@pytest.mark.skipif(
    not os.environ.get("ALPHAINFO_API_KEY"),
    reason="requires a real API key to hit the server",
)
def test_client_constant_matches_server_actual_threshold():
    """One below the constant must come back incomplete; one AT the constant
    must come back complete. If this ever regresses, the SDK constant has
    drifted from the backend and must be re-measured."""
    client = AlphaInfo(api_key=os.environ["ALPHAINFO_API_KEY"])

    too_short = client.fingerprint(_sine(MIN_FINGERPRINT_SAMPLES - 1), 1.0)
    assert not too_short.is_complete, (
        f"signal of {MIN_FINGERPRINT_SAMPLES - 1} should be incomplete "
        f"but server returned complete — constant may be too high"
    )

    at_threshold = client.fingerprint(_sine(MIN_FINGERPRINT_SAMPLES), 1.0)
    assert at_threshold.is_complete, (
        f"signal of {MIN_FINGERPRINT_SAMPLES} should be complete but "
        f"server returned incomplete — constant may be too low"
    )
