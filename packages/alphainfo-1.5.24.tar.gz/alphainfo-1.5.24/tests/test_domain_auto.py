"""
Briefing 1 — Python SDK tests for domain=auto + new response fields.

The SDK's ``_parse_analysis`` is pure and the new ``analyze_auto`` helpers
are thin wrappers around ``analyze(..., domain="auto")``. Rather than
stand up a full HTTP mock, these tests exercise the parser directly and
monkey-patch ``analyze`` to capture what the helper forwards.
"""

from __future__ import annotations

import pytest

from alphainfo import AlphaInfo, AsyncAlphaInfo


def test_parse_analysis_reads_domain_applied():
    from alphainfo.client import _parse_analysis

    payload = {
        "structural_score": 0.87,
        "change_detected": False,
        "change_score": 0.13,
        "confidence_band": "stable",
        "engine_version": "e95c5d2",
        "analysis_id": "abc-123",
        "domain_applied": "biomedical",
    }
    result = _parse_analysis(payload)
    assert result.domain_applied == "biomedical"
    assert result.domain_inference is None


def test_parse_analysis_reads_domain_inference_when_auto():
    from alphainfo.client import _parse_analysis

    payload = {
        "structural_score": 0.42,
        "change_detected": True,
        "change_score": 0.58,
        "confidence_band": "transition",
        "engine_version": "e95c5d2",
        "analysis_id": "abc-456",
        "domain_applied": "biomedical",
        "domain_inference": {
            "inferred": "biomedical",
            "confidence": 0.78,
            "fallback_used": False,
            "reasoning": "high_sampling_rate_with_periodic_structure",
        },
    }
    result = _parse_analysis(payload)
    assert result.domain_applied == "biomedical"
    assert result.domain_inference is not None
    assert result.domain_inference["inferred"] == "biomedical"
    assert result.domain_inference["confidence"] == 0.78
    assert result.domain_inference["fallback_used"] is False
    assert "periodic" in result.domain_inference["reasoning"]


def test_parse_analysis_legacy_server_without_new_fields():
    """A 1.5.10 server response must still deserialize cleanly — the two new
    fields default to None rather than raising."""
    from alphainfo.client import _parse_analysis

    payload = {
        "structural_score": 0.5,
        "change_detected": False,
        "change_score": 0.5,
        "confidence_band": "transition",
        "engine_version": "old",
        "analysis_id": "legacy-1",
    }
    result = _parse_analysis(payload)
    assert result.domain_applied is None
    assert result.domain_inference is None


def test_analyze_auto_helper_is_shortcut_for_domain_auto(monkeypatch):
    """analyze_auto() must call analyze(..., domain='auto') — nothing more,
    nothing less."""
    captured = {}

    def fake_analyze(self, signal, sampling_rate, domain="generic", **kw):  # noqa: ARG001
        captured["domain"] = domain
        captured["kwargs"] = kw
        # Return a minimal AnalysisResult stub so the helper's return works.
        from alphainfo.models import AnalysisResult
        return AnalysisResult(
            structural_score=1.0, change_detected=False, change_score=0.0,
            confidence_band="stable", engine_version="test", analysis_id="x",
            domain_applied="generic",
        )

    monkeypatch.setattr(AlphaInfo, "analyze", fake_analyze)
    c = AlphaInfo(api_key="ai_test_fake")
    result = c.analyze_auto(signal=[0.0] * 200, sampling_rate=1.0,
                            include_semantic=True)
    assert captured["domain"] == "auto"
    assert captured["kwargs"]["include_semantic"] is True
    assert result.domain_applied == "generic"


@pytest.mark.asyncio
async def test_async_analyze_auto_helper_forwards_domain(monkeypatch):
    captured = {}

    async def fake_analyze(self, signal, sampling_rate, domain="generic", **kw):  # noqa: ARG001
        captured["domain"] = domain
        from alphainfo.models import AnalysisResult
        return AnalysisResult(
            structural_score=1.0, change_detected=False, change_score=0.0,
            confidence_band="stable", engine_version="test", analysis_id="x",
            domain_applied="generic",
        )

    monkeypatch.setattr(AsyncAlphaInfo, "analyze", fake_analyze)
    async with AsyncAlphaInfo(api_key="ai_test_fake") as c:
        result = await c.analyze_auto(signal=[0.0] * 200, sampling_rate=1.0)
    assert captured["domain"] == "auto"
    assert result.domain_applied == "generic"
