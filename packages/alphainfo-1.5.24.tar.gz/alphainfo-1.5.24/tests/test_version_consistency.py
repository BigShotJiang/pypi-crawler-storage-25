"""
Version-consistency guard.

Multiple files in this repo carry a hard-coded SDK version string —
on every release, all of them have to be bumped in lockstep. When
one drifts (the README example showing 1.5.16 while __version__ said
1.5.17 was a real example flagged by an external review), the SDK
publishes inconsistent metadata and confuses users.

This test fails CI when any of the following diverge from the
package's `__version__`:

  • sdk/pyproject.toml             [project] version
  • sdk/alphainfo/__init__.py      __version__
  • sdk/alphainfo/client.py        _SDK_VERSION
  • sdk/README.md                  example output of `client.version()`
                                    in the "Version and compatibility"
                                    section

It also asserts that `__version__` and `_SDK_VERSION` are identical at
import time (they're typed independently, so they CAN drift in a refactor).

When you bump the SDK, run all four updates together. The pre-existing
CHANGELOG references to older versions are NOT checked — the guard is
about the CURRENT release pointers, not history.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

import alphainfo
from alphainfo.client import _SDK_VERSION


REPO_ROOT = Path(__file__).resolve().parent.parent
PYPROJECT = REPO_ROOT / "pyproject.toml"
README = REPO_ROOT / "README.md"


def test_init_and_client_version_match():
    """alphainfo.__version__ and client._SDK_VERSION are independently
    declared but must always agree — they appear in different code paths
    (User-Agent header, programmatic introspection, error messages)."""
    assert alphainfo.__version__ == _SDK_VERSION, (
        f"__version__ ({alphainfo.__version__!r}) and "
        f"_SDK_VERSION ({_SDK_VERSION!r}) drifted"
    )


def test_pyproject_version_matches_init():
    """pyproject.toml [project] version is what PyPI publishes;
    __version__ is what the code reports. They must match."""
    text = PYPROJECT.read_text()
    m = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
    assert m, "could not find a version line in pyproject.toml"
    pyproject_version = m.group(1)
    assert pyproject_version == alphainfo.__version__, (
        f"pyproject.toml version ({pyproject_version!r}) drifted from "
        f"alphainfo.__version__ ({alphainfo.__version__!r}) — bump them "
        "together when releasing."
    )


def test_readme_recommended_version_example_matches():
    """The README's "Version and compatibility" section shows an
    expected `client.version()` output. The recommended_version comment
    there must match the package's own __version__ (since the API
    recommends the latest published SDK).
    """
    text = README.read_text()
    # Look for the line in the form:
    #   print(info["sdk_compat"]["recommended_version"])  # "x.y.z"
    pattern = re.compile(
        r'recommended_version[^\n]*#\s*"([^"]+)"',
    )
    m = pattern.search(text)
    if m is None:
        pytest.skip(
            "README does not have a recommended_version example to check"
        )
    readme_version = m.group(1)
    assert readme_version == alphainfo.__version__, (
        f"README example shows recommended_version={readme_version!r} but "
        f"the package's __version__ is {alphainfo.__version__!r}. Update "
        "the README example when bumping the SDK so the published metadata "
        "stays internally consistent."
    )
