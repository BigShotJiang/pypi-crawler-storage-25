#!/usr/bin/env python3
"""
alphainfo — Handling fingerprint availability

Not every signal can be decomposed into a full 5D structural
fingerprint. Very short inputs or degenerate ones (constant, near-zero
variance) come back with ``fingerprint_available=False`` and all five
``sim_*`` dimensions set to ``None``. Your code must check before
using ``.vector`` for similarity search or ANN indexing — the previous
SDK silently filled missing dimensions with 0.0, which embedded a
bogus "total divergence" signal.

The pattern below is the idiom to adopt:

    1. Call client.fingerprint()
    2. Check fp.is_complete
    3. If True: use fp.vector (safe to index)
    4. If False: fall back to the semantic layer or skip the signal

    export ALPHAINFO_API_KEY="ai_your_key"
    python examples/fingerprint_handling.py
"""
import math
import os

import alphainfo


def run_fingerprint(label: str, signal: list[float], sampling_rate: float = 1.0) -> None:
    client = alphainfo.AlphaInfo(api_key=os.environ["ALPHAINFO_API_KEY"])
    fp = client.fingerprint(signal=signal, sampling_rate=sampling_rate)

    print(f"\n--- {label} (n={len(signal)}) ---")
    print(f"  structural_score: {fp.structural_score:.3f}  band: {fp.confidence_band}")

    if fp.is_complete:
        # Safe to use the 5D vector. This is what you'd feed to pgvector,
        # Qdrant, Faiss, or a similarity search routine.
        print(f"  ✓ fingerprint available  vector={fp.vector}")
    else:
        # Not enough structure to decompose. Two common moves:
        #   a) Skip this signal in an ANN index build.
        #   b) Fall back to the full analysis + semantic layer to still
        #      get a high-level assessment.
        print(f"  ✗ fingerprint unavailable  reason={fp.fingerprint_reason}")
        result = client.analyze(
            signal=signal, sampling_rate=sampling_rate, include_semantic=True
        )
        if result.semantic:
            print(f"    semantic fallback → trend={result.semantic.trend}, "
                  f"severity={result.semantic.severity}")


def main() -> None:
    # A healthy signal (400 pts) — full fingerprint comes back.
    sine_with_break = (
        [math.sin(i / 10) for i in range(200)]
        + [math.sin(i / 10) * 3 for i in range(200)]
    )
    run_fingerprint("regime change, 400 pts", sine_with_break, sampling_rate=100.0)

    # Too short — engine can't decompose; reason = "signal_too_short".
    run_fingerprint("short signal, 30 pts", [math.sin(i / 5) for i in range(30)])

    # Degenerate — constant signal; reason = "structural_degenerate".
    run_fingerprint("constant signal, 100 pts", [1.0] * 100)


if __name__ == "__main__":
    main()
