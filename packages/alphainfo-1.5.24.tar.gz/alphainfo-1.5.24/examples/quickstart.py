#!/usr/bin/env python3
"""
alphainfo — Hello World

Smallest possible example: install, paste your key, run.

    export ALPHAINFO_API_KEY="ai_your_key"
    python examples/quickstart.py

Get a free key at https://www.alphainfo.io/register (50 analyses/month).
"""
import math
import os

from alphainfo import AlphaInfo

client = AlphaInfo(api_key=os.environ["ALPHAINFO_API_KEY"])

# Toy signal: a sine that abruptly changes amplitude at the midpoint.
signal = [math.sin(i / 10) for i in range(200)] + \
         [math.sin(i / 10) * 3 for i in range(200)]

result = client.analyze(signal=signal, sampling_rate=100.0)

print(f"structural_score: {result.structural_score:.3f}")
print(f"confidence_band:  {result.confidence_band}")
print(f"change_detected:  {result.change_detected}")
print(f"analysis_id:      {result.analysis_id}")
