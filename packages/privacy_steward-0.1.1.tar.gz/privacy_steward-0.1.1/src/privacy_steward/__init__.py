"""Example module."""
