from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, TextIO

from mycel_cli.daemon import paths as daemon_paths

_ERROR_CONTEXT_SUPPRESSION_SECONDS = 300.0


def read_hook_payload(
    stdin: TextIO, *, default_event: str = "Notification"
) -> dict[str, Any]:
    text = stdin.read().strip()
    if not text:
        return {"hook_event_name": default_event}
    payload = json.loads(text)
    if not isinstance(payload, dict):
        raise RuntimeError("hook input must be a JSON object")
    return payload


def hook_event_name(
    payload: dict[str, Any], *, default_event: str = "Notification"
) -> str:
    return str(payload.get("hook_event_name") or default_event)


def format_agent_context(
    payload: Any, *, local_id: str, cli_command: str | None = None
) -> str:
    notifications = (
        payload.get("notifications", []) if isinstance(payload, dict) else []
    )
    if not notifications:
        return ""
    command = cli_command or os.getenv("MYCEL_CLI_COMMAND") or "cel"
    lines = [
        "<mycel-notifications>",
        f"You are using Mycel identity {local_id}.",
        f"You have {len(notifications)} pending Mycel notification(s).",
    ]
    for item in notifications:
        if not isinstance(item, dict):
            continue
        chat_id = str(item.get("chat_id") or "").strip()
        event_type = str(
            item.get("event_type") or item.get("notification_type") or "notification"
        )
        notification_type = str(item.get("notification_type") or "").strip()
        sender_name = str(item.get("sender_name") or "someone")
        if chat_id and notification_type == "chat":
            unread_count = item.get("unread_count")
            unread_text = (
                f" ({unread_count} unread)"
                if isinstance(unread_count, int) and unread_count >= 0
                else ""
            )
            lines.append(
                f"- {sender_name} sent a new {event_text(event_type)} in chat {chat_id}{unread_text}."
            )
            lines.append(f"  Read: {command} read-message {chat_id}")
            lines.append(f'  Reply: {command} send-message {chat_id} "..."')
        else:
            summary = str(item.get("summary") or "").strip()
            lines.append(
                f"- {summary}"
                if summary
                else f"- {sender_name} sent a new {event_text(event_type)}."
            )
    lines.append("You can ignore these notifications or inspect them with cel.")
    lines.append("</mycel-notifications>")
    return "\n".join(lines) + "\n"


def format_hook_error_context(error: BaseException, *, local_id: str) -> str:
    return (
        "<mycel-notifications>\n"
        f"You are using Mycel identity {local_id}.\n"
        f"Mycel notification check failed: {error}\n"
        "The provider hook delivered this diagnostic instead of failing the host event.\n"
        "You can retry with `cel self inbox read` after the Mycel backend is available.\n"
        "</mycel-notifications>\n"
    )


def format_hook_diagnostic_context(message: str, *, local_id: str) -> str:
    return (
        "<mycel-notifications>\n"
        f"You are using Mycel identity {local_id}.\n"
        f"{message}\n"
        "The provider hook delivered this diagnostic instead of failing the host event.\n"
        "</mycel-notifications>\n"
    )


def format_bootstrap_context(provider: str, *, cli_command: str | None = None) -> str:
    command = cli_command or os.getenv("MYCEL_CLI_COMMAND") or "cel"
    token = str(os.getenv("MYCEL_BOOTSTRAP_SURFACE_ID") or "")[:8]
    local_id = f"{provider}-{token}" if token else f"{provider}-<short-name>"
    display_name = (
        f"{provider.title()} {token}" if token else f"{provider.title()} <short name>"
    )
    return (
        "<mycel-notifications>\n"
        f"no Mycel identity is bound yet for this {provider} session.\n"
        "Stay in this session and guide the user through setup instead of restarting.\n"
        f"Check local state: {command} self status\n"
        f"If no owner is logged in, ask the user to run: {command} login <email-or-username>\n"
        f"Create your agent identity: {command} agent external create {local_id} "
        f'--name "{display_name}" --provider {provider}\n'
        f"Start local delivery: {command} self start\n"
        "</mycel-notifications>\n"
    )


def should_emit_hook_error_context(error: BaseException, *, local_id: str) -> bool:
    cache_path = _hook_error_cache_path()
    key = f"{local_id}:{type(error).__name__}:{error}"
    now = time.time()
    if cache_path.exists():
        payload = json.loads(cache_path.read_text(encoding="utf-8") or "{}")
        if (
            payload.get("key") == key
            and now - float(payload.get("reported_at") or 0)
            < _ERROR_CONTEXT_SUPPRESSION_SECONDS
        ):
            return False
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(
        json.dumps({"key": key, "reported_at": now}, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    cache_path.chmod(0o600)
    return True


def clear_hook_error_context() -> None:
    cache_path = _hook_error_cache_path()
    if cache_path.exists():
        cache_path.unlink()


def _hook_error_cache_path() -> Path:
    return daemon_paths.mycel_home() / "hook-error-cache.json"


def event_text(event_type: str) -> str:
    return event_type.replace(".", " ")


def hook_output(event_name: str, context: str, *, include_continue: bool) -> str:
    if not context:
        return ""
    payload: dict[str, Any] = {
        "hookSpecificOutput": {
            "hookEventName": event_name,
            "additionalContext": context,
        }
    }
    if include_continue:
        payload["continue"] = True
    return json.dumps(payload, ensure_ascii=False) + "\n"


def stop_block_output(context: str) -> str:
    if not context:
        return ""
    return (
        json.dumps({"decision": "block", "reason": context}, ensure_ascii=False) + "\n"
    )
