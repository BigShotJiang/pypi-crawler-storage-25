"""Typer command surface for cel."""

from __future__ import annotations

import sys
from types import SimpleNamespace
from typing import Annotated, Any

import click
import typer
from typer.core import TyperGroup

from mycel_cli.group.cli import group_app
from mycel_cli.handlers import (
    _agent_external_cleanup,
    _agent_external_create,
    _agent_external_list,
    _agent_external_remove,
    _agent_external_unbind,
    _agent_show,
    _internal_hook,
    _login,
    _logout,
    _provider_launch,
    _read_message,
    _relationships_action,
    _relationships_list,
    _relationships_request,
    _send_message,
)
from mycel_cli.self_cli import self_app


_rich_markup_mode = None if not sys.stdout.isatty() else "rich"
_HELP_OPTION_NAMES = ["-h", "--help"]
_PROVIDER_CONTEXT = {
    "allow_extra_args": True,
    "ignore_unknown_options": True,
    "help_option_names": _HELP_OPTION_NAMES,
}
_ROOT_CONTEXT = {"help_option_names": _HELP_OPTION_NAMES}


class CelRootGroup(TyperGroup):
    def resolve_command(
        self, ctx: click.Context, args: list[str]
    ) -> tuple[str | None, click.Command | None, list[str]]:
        if args and args[0] not in self.commands and _is_group_shortcut(args):
            return super().resolve_command(ctx, ["group", *args])
        return super().resolve_command(ctx, args)


app = typer.Typer(
    cls=CelRootGroup,
    help=(
        "Mycel command line interface.\n\n"
        "cel gives local code agents durable Mycel identities. Use it in two "
        "shapes: freeform messaging with `cel codex` / `cel claude`, and "
        "Keep-style group work with supervisor, worker, reviewer, and task "
        "state.\n\n"
        "Provider launchers pass native arguments through. cel uses the "
        "current process identity, the single folder identity, or an "
        "interactive identity selection. --identity is only for automation. "
        "Use `cel codex --mycel-status` or `cel claude --mycel-status` to "
        "inspect local Mycel identity, hook, and native provider state without "
        "launching the native provider."
    ),
    context_settings=_ROOT_CONTEXT,
    invoke_without_command=True,
    no_args_is_help=True,
    add_completion=False,
    rich_markup_mode=_rich_markup_mode,
)

contact_app = typer.Typer(
    help="Manage contacts between Mycel users.",
    context_settings=_ROOT_CONTEXT,
    rich_markup_mode=_rich_markup_mode,
)
agent_app = typer.Typer(
    help="Inspect and manage external agent identities.",
    context_settings=_ROOT_CONTEXT,
    rich_markup_mode=_rich_markup_mode,
)
external_app = typer.Typer(
    help="Manage external agent identities for local code agents.",
    context_settings=_ROOT_CONTEXT,
    rich_markup_mode=_rich_markup_mode,
)
internal_app = typer.Typer(
    help="Internal Mycel CLI implementation commands.",
    context_settings=_ROOT_CONTEXT,
    rich_markup_mode=_rich_markup_mode,
)


def _is_group_shortcut(args: list[str]) -> bool:
    from mycel_cli.group.cli import is_group_shortcut_invocation

    return is_group_shortcut_invocation(args)


def _run(ctx: typer.Context, **attrs: Any) -> None:
    obj = ctx.obj or {}
    runner = obj.get("run_command")
    if runner is None:
        raise RuntimeError("cel command runner is not configured")
    raise typer.Exit(int(runner(SimpleNamespace(**attrs)) or 0))


def _version_callback(value: bool) -> None:
    if value:
        from mycel_cli.commands import _package_version

        typer.echo(f"cel {_package_version()}")
        raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="show version",
    ),
) -> None:
    if ctx.invoked_subcommand is not None:
        return


@app.command(
    help="Authenticate an existing human owner who creates and owns local agent identities."
)
def login(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="owner email or username")],
    password_stdin: Annotated[
        bool,
        typer.Option(
            "--password-stdin",
            help="read the owner password from stdin",
        ),
    ] = False,
    base_url: Annotated[
        str | None, typer.Option("--base-url", help="Mycel backend URL")
    ] = None,
    json_output: Annotated[
        bool, typer.Option("--json", help="Print machine-readable JSON.")
    ] = False,
) -> None:
    _run(
        ctx,
        handler=_login,
        config_scope="login",
        command="login",
        identifier=identifier,
        password_stdin=password_stdin,
        base_url=base_url,
        json=json_output,
    )


@app.command(help="Clear the active human owner login.")
def logout(
    ctx: typer.Context,
    all_local: Annotated[
        bool,
        typer.Option("--all-local", help="clear all locally cached owner logins"),
    ] = False,
    json_output: Annotated[
        bool, typer.Option("--json", help="Print machine-readable JSON.")
    ] = False,
) -> None:
    _run(
        ctx,
        handler=_logout,
        command="logout",
        all_local=all_local,
        json=json_output,
    )


@contact_app.command("list", help="list contacts")
def contact_list(
    ctx: typer.Context,
    json_output: Annotated[
        bool, typer.Option("--json", help="Print machine-readable JSON.")
    ] = False,
) -> None:
    _run(
        ctx,
        handler=_relationships_list,
        command="contact",
        relationship_command="list",
        json=json_output,
    )


@contact_app.command("request", help="request a contact")
def contact_request(
    ctx: typer.Context,
    target_user_id: str,
    message: Annotated[str | None, typer.Option("--message")] = None,
    json_output: Annotated[
        bool, typer.Option("--json", help="Print machine-readable JSON.")
    ] = False,
) -> None:
    _run(
        ctx,
        handler=_relationships_request,
        command="contact",
        relationship_command="request",
        target_user_id=target_user_id,
        message=message,
        json=json_output,
    )


def _contact_action(
    ctx: typer.Context, action: str, contact_id: str, *, json_output: bool
) -> None:
    _run(
        ctx,
        handler=_relationships_action,
        command="contact",
        relationship_command=action,
        relationship_id=contact_id,
        json=json_output,
    )


@contact_app.command("approve", help="approve a contact request")
def contact_approve(
    ctx: typer.Context,
    contact_id: str,
    json_output: Annotated[
        bool, typer.Option("--json", help="Print machine-readable JSON.")
    ] = False,
) -> None:
    _contact_action(ctx, "approve", contact_id, json_output=json_output)


@contact_app.command("reject", help="reject a contact request")
def contact_reject(
    ctx: typer.Context,
    contact_id: str,
    json_output: Annotated[
        bool, typer.Option("--json", help="Print machine-readable JSON.")
    ] = False,
) -> None:
    _contact_action(ctx, "reject", contact_id, json_output=json_output)


@agent_app.command(
    "show",
    help="Show the current agent identity. Default is readable; use --json for automation.",
)
def agent_show(
    ctx: typer.Context,
    json_output: Annotated[
        bool, typer.Option("--json", help="Print machine-readable JSON.")
    ] = False,
) -> None:
    _run(
        ctx,
        handler=_agent_show,
        command="agent",
        agent_command="show",
        json=json_output,
    )


@external_app.command(
    "create",
    help="Create an external agent identity. Requires current human owner login; run cel login first.",
)
def external_create(
    ctx: typer.Context,
    local_id: str,
    name: Annotated[str, typer.Option("--name", help="agent identity display name")],
    provider: Annotated[str, typer.Option("--provider", help="codex or claude")],
    json_output: Annotated[
        bool, typer.Option("--json", help="Print machine-readable JSON.")
    ] = False,
) -> None:
    if provider not in {"codex", "claude"}:
        raise click.BadParameter("expected codex or claude", param_hint="--provider")
    _run(
        ctx,
        handler=_agent_external_create,
        config_scope="owner",
        command="agent",
        agent_command="external",
        external_command="create",
        local_id=local_id,
        name=name,
        provider=provider,
        json=json_output,
    )


@external_app.command(
    "list",
    help="List local agent identities. Default is readable; use --json for automation.",
)
def external_list(
    ctx: typer.Context,
    json_output: Annotated[
        bool, typer.Option("--json", help="Print machine-readable JSON.")
    ] = False,
) -> None:
    _run(
        ctx,
        handler=_agent_external_list,
        command="agent",
        agent_command="external",
        external_command="list",
        json=json_output,
    )


@external_app.command(
    "remove",
    help="Remove a local agent identity. Default is readable; use --json for automation.",
)
def external_remove(
    ctx: typer.Context,
    local_id: str,
    json_output: Annotated[
        bool, typer.Option("--json", help="Print machine-readable JSON.")
    ] = False,
) -> None:
    _run(
        ctx,
        handler=_agent_external_remove,
        command="agent",
        agent_command="external",
        external_command="remove",
        local_id=local_id,
        json=json_output,
    )


@external_app.command("unbind", help="remove an identity binding from a local folder")
def external_unbind(
    ctx: typer.Context,
    local_id: str,
    path: Annotated[
        str | None,
        typer.Option("--path", help="folder to unbind; defaults to current folder"),
    ] = None,
) -> None:
    _run(
        ctx,
        handler=_agent_external_unbind,
        command="agent",
        agent_command="external",
        external_command="unbind",
        local_id=local_id,
        path=path,
    )


@external_app.command("cleanup", help="remove stale local state for missing identities")
def external_cleanup(ctx: typer.Context) -> None:
    _run(
        ctx,
        handler=_agent_external_cleanup,
        command="agent",
        agent_command="external",
        external_command="cleanup",
    )


@app.command(
    "send-message",
    help="Send a durable Mycel message. Targets are explicit: <chat_id>, @<user_id>, @<local-id>, @owner, or <chat_id>@<ref>. In chat scope, <ref> may be a backend user id, local id, or workflow participant handle/alias.",
)
def send_message(
    ctx: typer.Context,
    target: Annotated[
        str,
        typer.Argument(
            help="<chat_id>, @<user_id>, @<local-id>, @owner, or <chat_id>@<ref>"
        ),
    ],
    content: Annotated[str | None, typer.Argument(help="message text")] = None,
    content_file: Annotated[
        str | None,
        typer.Option("--file", help="read message text from a file"),
    ] = None,
    reply_to: Annotated[str | None, typer.Option("--reply-to")] = None,
    mentions: Annotated[
        list[str] | None,
        typer.Option(
            "--mention",
            help="user id or local-id to mention in addition to the target; repeat to mention multiple users",
        ),
    ] = None,
    addressed_to: Annotated[
        list[str] | None,
        typer.Option(
            "--addressed-to",
            help="user id, local-id, or workflow participant ref to address in the target chat; repeat to address multiple users",
        ),
    ] = None,
    json_output: Annotated[
        bool, typer.Option("--json", help="Print machine-readable JSON.")
    ] = False,
) -> None:
    _run(
        ctx,
        handler=_send_message,
        command="send-message",
        target=target,
        content=content,
        content_file=content_file,
        reply_to=reply_to,
        mentions=mentions or [],
        addressed_to=addressed_to or [],
        json=json_output,
    )


@app.command(
    "read-message",
    help="Read durable Mycel messages. Targets are explicit: <chat_id>, @<user_id>, @<local-id>, or @owner. By default this consumes unread messages; --last peeks without advancing the read cursor.",
)
def read_message(
    ctx: typer.Context,
    target: Annotated[
        str, typer.Argument(help="<chat_id>, @<user_id>, @<local-id>, or @owner")
    ],
    last: Annotated[
        int | None,
        typer.Option(
            "--last",
            help="peek at the last N messages without advancing the read cursor",
        ),
    ] = None,
    before: Annotated[
        str | None,
        typer.Option("--before", help="message id cursor for older messages"),
    ] = None,
    json_output: Annotated[
        bool, typer.Option("--json", help="Print machine-readable JSON.")
    ] = False,
) -> None:
    _run(
        ctx,
        handler=_read_message,
        command="read-message",
        target=target,
        last=last,
        before=before,
        json=json_output,
    )


def _provider_command(ctx: typer.Context, provider: str) -> None:
    _run(
        ctx,
        handler=_provider_launch,
        command=provider,
        provider_args=list(ctx.args),
    )


@app.command(
    "codex",
    context_settings=_PROVIDER_CONTEXT,
    help=(
        "launch Codex with a Mycel identity\n\n"
        "Mycel options:\n"
        "  --identity <local-id>    choose a local agent identity for automation; usually omit this\n"
        "  --mycel-status          inspect identity, hook, and provider state\n"
        "  --mycel-status --json   print provider status as JSON\n\n"
        "Native Codex arguments must follow `--` when they look like Mycel wrapper options. "
        "Example: `cel codex --identity agent-a -- exec hello`."
    ),
)
def codex(ctx: typer.Context) -> None:
    _provider_command(ctx, "codex")


@app.command(
    "claude",
    context_settings=_PROVIDER_CONTEXT,
    help=(
        "launch Claude Code with a Mycel identity\n\n"
        "Mycel options:\n"
        "  --identity <local-id>    choose a local agent identity for automation; usually omit this\n"
        "  --mycel-status          inspect identity, hook, and provider state\n"
        "  --mycel-status --json   print provider status as JSON\n\n"
        "Native Claude arguments must follow `--` when they look like Mycel wrapper options. "
        "Example: `cel claude --identity agent-a -- exec hello`."
    ),
)
def claude(ctx: typer.Context) -> None:
    _provider_command(ctx, "claude")


@internal_app.command("hook")
def internal_hook(
    ctx: typer.Context,
    provider: Annotated[str, typer.Argument(help="codex or claude")],
    rewake: Annotated[bool, typer.Option("--rewake")] = False,
) -> None:
    if provider not in {"codex", "claude"}:
        raise click.BadParameter("expected codex or claude", param_hint="provider")
    _run(
        ctx,
        handler=_internal_hook,
        command="internal",
        internal_command="hook",
        provider=provider,
        rewake=rewake,
    )


agent_app.add_typer(external_app, name="external")
app.add_typer(contact_app, name="contact")
app.add_typer(agent_app, name="agent")
app.add_typer(self_app, name="self")
app.add_typer(group_app, name="group")
app.add_typer(internal_app, name="internal", hidden=True)
