from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from .group._state.groups import load_group
from .group._state.roles import iter_roles
from .daemon.wake import send_surface_hint


@dataclass(frozen=True)
class WorkflowWakeResult:
    ref: str
    status: str
    reason: str | None = None


def wake_local_workflow_refs(
    *,
    chat_id: str,
    refs: list[str],
    sender_local_id: str | None,
    env: dict[str, str] | None = None,
) -> list[WorkflowWakeResult]:
    refs = list(dict.fromkeys(ref for ref in refs if ref))
    if not refs:
        return []
    group = load_group(chat_id)
    if group is None:
        return []
    wake_results: list[WorkflowWakeResult] = []
    reply_ref = _reply_ref(
        group, sender_local_id=sender_local_id, env=env or os.environ
    )
    for ref in refs:
        role = _find_role(group, ref)
        if role is None:
            wake_results.append(
                WorkflowWakeResult(
                    ref=ref, status="skipped", reason="local role not found"
                )
            )
            continue
        local_id = str(role.get("local_id") or "").strip()
        if not local_id:
            wake_results.append(
                WorkflowWakeResult(
                    ref=ref,
                    status="skipped",
                    reason="local role identity not tracked",
                )
            )
            continue
        sent = send_surface_hint(
            local_id,
            _wake_text(chat_id=chat_id, reply_ref=reply_ref),
        )
        if sent:
            wake_results.append(WorkflowWakeResult(ref=ref, status="sent"))
        else:
            wake_results.append(
                WorkflowWakeResult(
                    ref=ref,
                    status="skipped",
                    reason="local role surface not tracked",
                )
            )
    return wake_results


def _find_role(group: dict[str, Any], ref: str) -> dict[str, Any] | None:
    for role in iter_roles(group):
        if ref in _role_refs(role):
            return role
    return None


def _role_refs(role: dict[str, Any]) -> set[str]:
    refs = {
        str(role.get("session") or ""),
        str(role.get("name") or ""),
        str(role.get("local_id") or ""),
    }
    if role.get("role") == "supervisor":
        refs.add("supervisor")
    return {ref for ref in refs if ref}


def _reply_ref(
    group: dict[str, Any], *, sender_local_id: str | None, env: dict[str, str]
) -> str:
    session = str(env.get("MYCEL_USER_SESSION") or "").strip()
    if session:
        sender = _find_role(group, session)
        if sender and sender.get("role") == "supervisor":
            return "supervisor"
        return session
    if sender_local_id:
        return sender_local_id
    return "<sender-ref>"


def _wake_text(*, chat_id: str, reply_ref: str) -> str:
    return (
        f"New Mycel workflow message in chat {chat_id}. "
        f"Read: `cel read-message {chat_id}`. "
        f'Reply: `cel send-message {chat_id}@{reply_ref} "..."` if needed.'
    )
