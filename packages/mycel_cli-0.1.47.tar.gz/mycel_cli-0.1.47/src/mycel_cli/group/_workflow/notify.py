"""Outbound chat notifications to supervisor / reviewers."""

from __future__ import annotations

from typing import Any
from xml.sax.saxutils import escape as xml_escape

from mycel_cli.group._cli.chat_transport import (
    user_id_for,
    group_chat_for,
)
from mycel_cli.group._workflow.constants import log
from mycel_cli.group._workflow.xml_format import build_event_xml
from mycel_cli.group._state.tasks import list_tasks
from mycel_cli.group._state.roles import (
    find_supervisor,
    iter_reviewer_roles,
    role_ready,
)
from mycel_cli.daemon.wake import send_surface_hint


def send_to_local_surface(local_id: str, message: str) -> bool:
    return send_surface_hint(local_id, message)


def notify_supervisor(group: dict[str, Any], message: str) -> None:
    """通知 group 的 supervisor。缺失 Mycel identity 则丢事件。"""
    group_name = group.get("name", "?")
    sup = find_supervisor(group)
    if not sup:
        # 主循环理应过滤 unclaimed group，到这就是 invariant 破了。warning 而不是 debug。
        log.warning(
            "notify_supervisor called on group %r with no supervisor — invariant violation, dropping: %s",
            group_name,
            message[:80],
        )
        return
    local_id = str(sup.get("local_id") or "").strip()
    if not local_id:
        log.warning(
            "Supervisor for group %r has no local identity, dropping event",
            group_name,
        )
        return
    # 替换换行符，避免 Escape 打断 Supervisor 正在运行的 generation
    safe_message = message.replace("\n", " ")
    log.info(
        "→ Supervisor[%s] %s: %s",
        group_name,
        local_id,
        safe_message[:120],
    )
    send_to_local_surface(local_id, safe_message)


def notify_supervisor_from_role(
    *,
    group_id: str,
    group: dict[str, Any],
    sender: dict[str, Any],
    message: str,
) -> None:
    """Send a role-originated daemon event through Mycel chat, then wake supervisor."""
    supervisor = find_supervisor(group)
    if not supervisor:
        log.warning(
            "notify_supervisor_from_role called on group %r with no supervisor",
            group_id,
        )
        return
    sender_role = str(sender["role"])
    sender_session = str(sender["session"])
    try:
        client, chat_id = group_chat_for(
            group_id=group_id,
            sender=sender,
            recipient=supervisor,
        )
        client.messages.send(
            chat_id,
            message,
            delivery_scope="addressed",
            addressed_to_user_ids=[user_id_for(supervisor)],
        )
    except Exception:
        log.exception(
            "role-originated supervisor chat failed [%s/%s -> %s]",
            group_id,
            sender.get("session"),
            supervisor.get("session"),
        )
        return

    local_id = str(supervisor.get("local_id") or "").strip()
    if not local_id:
        log.info(
            "Supervisor for group %r has no local identity; chat event stored without terminal wake",
            group_id,
        )
        return

    wake = (
        f"New Mycel group message from {sender_role} in chat {chat_id} "
        f"for group {group_id}. Read it with "
        f"`cel read-message {chat_id}`. Reply with "
        f'`cel send-message {chat_id}@{sender_session} "..."` if needed.'
    )
    send_to_local_surface(local_id, wake)


def notify_reviewer(
    group: dict[str, Any], reviewer: dict[str, Any], message: str
) -> None:
    """Send a durable review message, then wake the local reviewer surface."""
    group_name = group.get("name", "?")
    reviewer_id = reviewer.get("id", "?")
    supervisor = find_supervisor(group)
    if supervisor is None:
        log.warning(
            "Reviewer notification for group %r has no supervisor sender, dropping message",
            group_name,
        )
        return

    try:
        client, chat_id = group_chat_for(
            group_id=str(group_name),
            sender=supervisor,
            recipient=reviewer,
        )
        client.messages.send(
            chat_id,
            message,
            delivery_scope="addressed",
            addressed_to_user_ids=[user_id_for(reviewer)],
        )
    except Exception:
        log.exception(
            "reviewer chat notification failed [%s -> %s]",
            group_name,
            reviewer_id,
        )
        return

    local_id = str(reviewer.get("local_id") or "").strip()
    if not local_id:
        log.info(
            "Reviewer %s/%s has no local identity; review message stored without terminal wake",
            group_name,
            reviewer_id,
        )
        return
    wake = _reviewer_chat_wake(str(group_name), chat_id)
    log.info(
        "→ Reviewer[%s/%s] %s: %s",
        group_name,
        reviewer_id,
        local_id,
        wake[:120],
    )
    send_to_local_surface(local_id, wake)


def _reviewer_chat_wake(group_name: str, chat_id: str) -> str:
    return (
        f"New Mycel review request in chat {chat_id} for group {group_name}. "
        f"Read it with `cel read-message {chat_id}`, then decide with "
        f"`cel group {group_name} task update ...` or "
        f"`cel group stop {group_name} --status ...`."
    )


def notify_all_reviewers(
    group: dict[str, Any],
    message: str,
    *,
    reviewer_ids: set[str] | None = None,
) -> None:
    """通知 group 的所有 reviewers。session 不可达的 reviewer 静默跳过。"""
    group_name = group.get("name", "?")
    reviewers = [
        {
            **user,
            "id": user.get("session"),
        }
        for user in iter_reviewer_roles(group)
        if user.get("status") == "active" and role_ready(user)
    ]
    if not reviewers:
        log.debug("No reviewers for group %r", group_name)
        return
    for reviewer in reviewers:
        reviewer_id = reviewer.get("id")
        if reviewer_ids is not None and reviewer_id not in reviewer_ids:
            continue
        try:
            notify_reviewer(group, reviewer, message)
        except Exception as e:
            log.warning("Failed to notify reviewer %s: %s", reviewer_id, e)


def sync_group_to_reviewers(group_name: str, group: dict[str, Any]) -> None:
    """推送最新 group 内容（prompt + tasks 摘要）给所有 reviewers。纯信息同步，无判决。"""
    reviewers = [
        {
            **user,
            "id": user.get("session"),
        }
        for user in iter_reviewer_roles(group)
        if user.get("status") == "active" and role_ready(user)
    ]
    if not reviewers:
        return

    prompt = group.get("group_prompt") or "(未设置)"
    tasks = list_tasks(group_name)
    if tasks:
        lines = [f"#{t['id']} [{t['status']}] {t['subject']}" for t in tasks]
        tasks_summary = "\n".join(lines)
    else:
        tasks_summary = "(无 task)"

    body = xml_escape(
        f"Group {group_name} 信息同步:\nPrompt: {prompt}\nTasks:\n{tasks_summary}"
    )
    msg = build_event_xml(
        "group_sync",
        {"group": group_name},
        body,
    )
    for reviewer in reviewers:
        try:
            notify_reviewer(group, reviewer, msg)
        except Exception as e:
            log.warning(
                "Failed to sync group to reviewer %s: %s", reviewer.get("id"), e
            )
