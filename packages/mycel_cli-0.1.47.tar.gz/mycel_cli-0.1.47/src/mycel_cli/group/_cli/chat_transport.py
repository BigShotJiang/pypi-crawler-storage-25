"""Thin Mycel chat transport adapter for group-scoped messages."""

from __future__ import annotations

from mycel_sdk import Client

from mycel_cli.identity_store import IdentityStore


def group_chat_for(
    *, group_id: str, sender: dict, recipient: dict
) -> tuple[Client, str]:
    source_identity = identity_for(sender)
    require_user_id(recipient)
    client = Client(
        auth_token=str(source_identity["auth_token"]),
        base_url=str(source_identity["base_url"]),
    )
    return client, group_id


def require_user_id(user: dict) -> None:
    user_id_for(user)


def user_id_for(user: dict) -> str:
    return _user_id_from_identity(identity_for(user), user)


def _user_id_from_identity(identity: dict, user: dict) -> str:
    user_id = str(identity.get("user_id") or "").strip()
    if not user_id:
        raise RuntimeError(f"group role {user.get('session')!r} has no user_id")
    return user_id


def identity_for(user: dict) -> dict:
    local_id = str(user.get("local_id") or "").strip()
    if not local_id:
        raise RuntimeError(f"group role {user.get('session')!r} has no Mycel identity")
    identity = IdentityStore.from_env().get_identity(local_id)
    return {"local_id": local_id, **identity}
