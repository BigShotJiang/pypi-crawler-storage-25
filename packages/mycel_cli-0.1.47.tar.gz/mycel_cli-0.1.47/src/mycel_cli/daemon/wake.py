from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

from mycel_cli.daemon.paths import rewake_path, wake_path
from mycel_cli.daemon.surfaces import drop, lookup, terminal_context_env
from mycel_cli.debug_log import log_debug_event
from mycel_cli.terminal_wake import send_terminal_hint


def attempt_wake(local_id: str, fresh: list[dict[str, Any]]) -> bool:
    if not fresh:
        return False
    now = _now()
    if now - _last_time(wake_path(local_id)) < 2.0:
        return False
    if now - _last_time(rewake_path(local_id)) < 30.0:
        return False
    sent = send_surface_hint(local_id, wake_hint(fresh))
    if sent:
        _write_time(wake_path(local_id), now)
    return sent


def send_surface_hint(local_id: str, text: str) -> bool:
    ref = lookup(local_id)
    if ref is None:
        log_debug_event(
            "wake",
            "wake.skipped",
            local_id=local_id,
            reason="surface-not-tracked",
        )
        return False
    try:
        with terminal_context_env(ref.terminal_context):
            send_terminal_hint(ref.terminal_type, ref.target_id, text)
    except Exception:
        # @@@surface-drift - terminal handles are dynamic runtime facts; a failed write invalidates this binding.
        log_debug_event(
            "wake",
            "wake.failed",
            local_id=local_id,
            reason="terminal-write-failed",
            details={"terminal_type": ref.terminal_type, "target_id": ref.target_id},
        )
        drop(local_id)
        return False
    log_debug_event(
        "wake",
        "wake.sent",
        local_id=local_id,
        details={"terminal_type": ref.terminal_type, "target_id": ref.target_id},
    )
    return True


def wake_hint(fresh: list[dict[str, Any]]) -> str:
    for item in fresh:
        chat_id = str(item.get("chat_id") or "").strip()
        if chat_id:
            return (
                f"Mycel has new chat activity in {chat_id}. "
                "The provider hook will attach details; "
                f"run cel read-message {chat_id} if needed."
            )
    return "Mycel has new notifications. Inspect them with cel."


def record_rewake(local_id: str) -> None:
    _write_time(rewake_path(local_id), _now())


def _last_time(path: Path) -> float:
    if not path.exists():
        return 0.0
    payload = json.loads(path.read_text(encoding="utf-8") or "{}")
    return float(payload.get("at") or 0.0)


def _write_time(path: Path, at: float) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps({"at": at}, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    path.chmod(0o600)


def _now() -> float:
    return time.time()
