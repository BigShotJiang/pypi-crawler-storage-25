from dataclasses import dataclass
from datetime import datetime
from unittest.mock import MagicMock

import pytest
from pydantic import BaseModel
from pytest_mock import MockerFixture

from mesa_runner.adapters.dry_run import DryRunStorageAdapter
from mesa_runner.adapters.io_schemas import InferenceMetadata, InferenceResult, ModelMetadata


class DryRunStorageAdapterFixture(DryRunStorageAdapter):
    def get_word_pool(self) -> list[str]:
        return self._WORD_POOL

    def generate_random_content(self, min_words=10, max_words=100):
        return self._generate_random_content(min_words, max_words)


@dataclass
class DryRunAdapterMocks:
    logger: MagicMock
    datetime_now: MagicMock
    random_choices: MagicMock
    random_randint: MagicMock


@pytest.fixture
def dry_run_adapter_mocks(mocker: MockerFixture) -> DryRunAdapterMocks:
    return DryRunAdapterMocks(
        logger=mocker.patch("mesa_runner.adapters.dry_run.logging.getLogger"),
        datetime_now=mocker.patch("mesa_runner.adapters.dry_run.datetime"),
        random_choices=mocker.patch("mesa_runner.adapters.dry_run.random.choices"),
        random_randint=mocker.patch("mesa_runner.adapters.dry_run.random.randint"),
    )


class TestDryRunStorageAdapter:
    def test_get_unprocessed_document_count_configured_value_returns_count(self):
        assert DryRunStorageAdapterFixture(document_count=10).get_unprocessed_document_count() == 10

    def test_get_unprocessed_document_count_no_value_returns_default(self):
        assert DryRunStorageAdapterFixture().get_unprocessed_document_count() == 5

    def test_generate_random_content_default_params_returns_string(
        self, dry_run_adapter_mocks: DryRunAdapterMocks
    ):
        dry_run_adapter_mocks.random_randint.return_value = 15
        dry_run_adapter_mocks.random_choices.return_value = ["foo", "bar", "baz"]
        adapter: DryRunStorageAdapterFixture = DryRunStorageAdapterFixture()
        assert adapter.generate_random_content() == "foo bar baz"
        dry_run_adapter_mocks.random_randint.assert_called_once_with(10, 100)
        dry_run_adapter_mocks.random_choices.assert_called_once_with(adapter.get_word_pool(), k=15)

    def test_generate_random_content_custom_params_returns_string(
        self, dry_run_adapter_mocks: DryRunAdapterMocks
    ):
        dry_run_adapter_mocks.random_randint.return_value = 7
        dry_run_adapter_mocks.random_choices.return_value = ["qux", "quux"]
        adapter: DryRunStorageAdapterFixture = DryRunStorageAdapterFixture()
        assert adapter.generate_random_content(5, 20) == "qux quux"
        dry_run_adapter_mocks.random_randint.assert_called_once_with(5, 20)
        dry_run_adapter_mocks.random_choices.assert_called_once_with(adapter.get_word_pool(), k=7)

    def test_get_documents_configured_count_yields_correct_number(
        self, dry_run_adapter_mocks: DryRunAdapterMocks
    ):
        mock_datetime: datetime = datetime(2026, 1, 1, 12, 0, 0)
        dry_run_adapter_mocks.datetime_now.now.return_value = mock_datetime
        dry_run_adapter_mocks.random_randint.return_value = 10
        dry_run_adapter_mocks.random_choices.return_value = ["test"]
        assert len(list(DryRunStorageAdapterFixture(document_count=3).get_documents())) == 3

    def test_get_documents_single_document_yields_valid_structure(
        self, dry_run_adapter_mocks: DryRunAdapterMocks
    ):
        mock_datime: datetime = datetime(2026, 1, 1, 12, 0, 0)
        dry_run_adapter_mocks.datetime_now.now.return_value = mock_datime
        dry_run_adapter_mocks.random_randint.return_value = 10
        dry_run_adapter_mocks.random_choices.return_value = ["foo", "bar"]
        documents: list = list(DryRunStorageAdapterFixture(document_count=1).get_documents())
        assert documents[0].document_id == "dry_run_doc_0"
        assert documents[0].document_content == "foo bar"
        assert documents[0].document_update_dt == mock_datime
        assert documents[0].document_source == {"source": "dry_run", "index": 0}

    def test_get_documents_multiple_documents_yields_unique_ids(
        self, dry_run_adapter_mocks: DryRunAdapterMocks
    ):
        mock_datime: datetime = datetime(2026, 1, 1, 12, 0, 0)
        dry_run_adapter_mocks.datetime_now.now.return_value = mock_datime
        dry_run_adapter_mocks.random_randint.return_value = 10
        dry_run_adapter_mocks.random_choices.return_value = ["test"]
        ids: set = {
            doc.document_id
            for doc in list(DryRunStorageAdapterFixture(document_count=3).get_documents())
        }
        assert len(ids) == 3
        assert all(doc_id.startswith("dry_run_doc_") for doc_id in ids)

    def test_write_document_valid_results_logs_count(
        self, dry_run_adapter_mocks: DryRunAdapterMocks
    ):
        mock_logger: MagicMock = MagicMock()
        dry_run_adapter_mocks.logger.return_value = mock_logger

        class SimpleOutput(BaseModel):
            value: str

        mock_datetime: datetime = datetime(2026, 1, 1, 12, 0, 0)
        results: list[InferenceResult] = [
            InferenceResult(
                master_document_id="master-1",
                document_id="doc-1",
                document_update_dt=mock_datetime,
                validated_output=SimpleOutput(value="test"),
                inference_result_metadata=InferenceMetadata(
                    schema_package_name="test-pkg",
                    schema_package_version="1.0.0",
                    inference_metadata=mock_datetime,
                ),
                model_metadata=ModelMetadata(
                    model_name="test-model",
                    model_version="1.0",
                    trained_schema_name="schema",
                    trained_schema_version="1.0",
                ),
                is_valid=True,
            )
        ]
        DryRunStorageAdapterFixture().write_document(results)
        mock_logger.info.assert_called_once_with("Would write 1 documents")
