from oncoschema.schema import OncologyModel

from mesa_runner.inferrer import ModelConfig


def test_valid_model_config_schema_package_field_validation():
    # This test just ensures that the ModelConfig can be instantiated with a valid package
    # The actual validation of the package/model is done when the model is loaded.
    config = ModelConfig(
        prompt_template="template",
        output_model=OncologyModel,
        max_tokens=100,
        temperature=0.5,
        model_name="oncoqwen_1",
        schema_package="londonaicentre-oncoschema",
    )
    assert config.schema_package == "londonaicentre-oncoschema"
    # Check that a known valid version string is accepted and can derive the version
    assert int(config.schema_version.split(".")[0]) >= 2
