import logging
import socket
import threading
from collections.abc import Generator

import httpx
import pytest
import uvicorn
from fastapi import FastAPI
from httpx import ASGITransport
from openai import AsyncOpenAI
from openai.types.chat import ChatCompletion, ChatCompletionMessage
from openai.types.chat.chat_completion import Choice
from openai.types.completion_usage import CompletionUsage
from tenacity import retry, stop_after_delay, wait_fixed

from mesa_runner.log_filters import DataRedactingFilter, LogPattern


@pytest.fixture
def openai_server_mock() -> FastAPI:
    app: FastAPI = FastAPI()

    @app.post("/v1/chat/completions")
    async def completions() -> ChatCompletion:
        return ChatCompletion(
            id="chatcmpl-foo",
            model="foo",
            object="chat.completion",
            created=1234567890,
            choices=[
                Choice(
                    index=0,
                    message=ChatCompletionMessage(role="assistant", content="bar"),
                    finish_reason="stop",
                )
            ],
            usage=CompletionUsage(prompt_tokens=10, completion_tokens=5, total_tokens=15),
        )

    return app


@pytest.fixture
def openai_client_mock(openai_server_mock: FastAPI) -> AsyncOpenAI:
    return AsyncOpenAI(
        api_key="foo",
        base_url="http://bar/v1",
        http_client=httpx.AsyncClient(
            transport=ASGITransport(app=openai_server_mock), base_url="http://bar"
        ),
    )


@pytest.fixture
def openai_server(openai_server_mock: FastAPI) -> Generator[str, None, None]:
    server: uvicorn.Server = uvicorn.Server(
        uvicorn.Config(openai_server_mock, host="127.0.0.1", port=8765, log_level="error")
    )
    thread: threading.Thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    @retry(stop=stop_after_delay(5), wait=wait_fixed(0.1))
    def wait_for_server() -> None:
        with socket.create_connection(("127.0.0.1", 8765), timeout=0.1):
            pass

    wait_for_server()

    yield "http://127.0.0.1:8765"
    server.should_exit = True
    thread.join(timeout=1)


@pytest.fixture
def openai_client(openai_server: str) -> AsyncOpenAI:
    return AsyncOpenAI(api_key="foo", base_url=f"{openai_server}/v1")


@pytest.fixture
def redacting_filter() -> DataRedactingFilter:
    return DataRedactingFilter()


def _make_record(msg: object, args: tuple[object, ...] = ()) -> logging.LogRecord:
    return logging.LogRecord("foo", logging.DEBUG, "", 0, msg, args or None, None)


class TestOpenAIRequestOptions:
    def test_filter_openai_request_options_redacts_body(
        self, redacting_filter: DataRedactingFilter
    ) -> None:
        record: logging.LogRecord = _make_record(
            LogPattern.OPENAI_REQUEST_OPTIONS,
            ({"model": "foo", "messages": [{"role": "user", "content": "secret"}]},),
        )
        redacting_filter.filter(record)
        assert record.args == (LogPattern.REDACTED,)

    def test_filter_openai_request_options_preserves_msg(
        self, redacting_filter: DataRedactingFilter
    ) -> None:
        record: logging.LogRecord = _make_record(
            LogPattern.OPENAI_REQUEST_OPTIONS, ({"foo": "bar"},)
        )
        redacting_filter.filter(record)
        assert record.msg == LogPattern.OPENAI_REQUEST_OPTIONS

    @pytest.mark.integration
    @pytest.mark.asyncio
    async def test_filter_openai_request_options_redacts_body_integration(
        self, openai_client_mock: AsyncOpenAI, caplog: pytest.LogCaptureFixture
    ) -> None:
        caplog.set_level(logging.DEBUG, logger="openai")
        data_filter: DataRedactingFilter = DataRedactingFilter()
        caplog.handler.addFilter(data_filter)
        await openai_client_mock.chat.completions.create(
            model="foo", messages=[{"role": "user", "content": "secret-request-body"}]
        )
        request_logs: str = "\n".join(
            r.message for r in caplog.records if "Request options" in r.message
        )
        assert "secret-request-body" not in request_logs
        assert LogPattern.REDACTED in request_logs
        caplog.handler.removeFilter(data_filter)


class TestOpenAIHTTPResponse:
    def test_filter_openai_http_response_redacts_headers(
        self, redacting_filter: DataRedactingFilter
    ) -> None:
        record: logging.LogRecord = _make_record(
            LogPattern.OPENAI_HTTP_RESPONSE,
            ("GET", "https://foo.bar/v1/chat", 200, "OK", {"x-secret": "1"}),
        )
        redacting_filter.filter(record)
        assert record.args == ("GET", "https://foo.bar/v1/chat", 200, "OK", LogPattern.REDACTED)

    def test_filter_openai_http_response_preserves_msg(
        self, redacting_filter: DataRedactingFilter
    ) -> None:
        record: logging.LogRecord = _make_record(
            LogPattern.OPENAI_HTTP_RESPONSE,
            ("POST", "https://foo.bar/v1/chat", 201, "Created", {}),
        )
        redacting_filter.filter(record)
        assert record.msg == LogPattern.OPENAI_HTTP_RESPONSE

    @pytest.mark.integration
    @pytest.mark.asyncio
    async def test_filter_openai_http_response_redacts_headers_integration(
        self, openai_client_mock: AsyncOpenAI, caplog: pytest.LogCaptureFixture
    ) -> None:
        caplog.set_level(logging.DEBUG, logger="openai")
        data_filter: DataRedactingFilter = DataRedactingFilter()
        caplog.handler.addFilter(data_filter)
        await openai_client_mock.chat.completions.create(
            model="foo", messages=[{"role": "user", "content": "bar"}]
        )
        http_response_logs: str = "\n".join(
            r.message for r in caplog.records if "HTTP Response" in r.message
        )
        assert LogPattern.REDACTED in http_response_logs
        assert "200" in http_response_logs
        assert "content-type" not in http_response_logs.lower()
        caplog.handler.removeFilter(data_filter)


class TestHTTPCore:
    def test_filter_httpcore_response_headers_redacts_return_value(
        self, redacting_filter: DataRedactingFilter
    ) -> None:
        record: logging.LogRecord = _make_record(
            LogPattern.HTTPCORE_RESPONSE_HEADERS_PREFIX
            + "return_value=(b'HTTP/1.1', 200, b'OK', [(b'x-secret', b'1')])"
        )
        redacting_filter.filter(record)
        assert record.msg == (
            LogPattern.HTTPCORE_RESPONSE_HEADERS_PREFIX
            + LogPattern.REDACTED
            + " http_version=HTTP/1.1 status=200"
        )

    def test_filter_httpcore_response_headers_redacts_http2(
        self, redacting_filter: DataRedactingFilter
    ) -> None:
        record: logging.LogRecord = _make_record(
            LogPattern.HTTPCORE_RESPONSE_HEADERS_PREFIX
            + "return_value=(200, [(b'x-secret', b'1')])"
        )
        redacting_filter.filter(record)
        assert record.msg == (
            LogPattern.HTTPCORE_RESPONSE_HEADERS_PREFIX
            + LogPattern.REDACTED
            + " http_version=HTTP/2 status=200"
        )

    def test_filter_httpcore_non_header_complete_passes_through(
        self, redacting_filter: DataRedactingFilter
    ) -> None:
        msg: str = "send_request_headers.complete return_value=None"
        record: logging.LogRecord = _make_record(msg)
        redacting_filter.filter(record)
        assert record.msg == msg

    @pytest.mark.integration
    @pytest.mark.asyncio
    async def test_filter_httpcore_response_headers_redacts_return_value_integration(
        self, openai_client: AsyncOpenAI, caplog: pytest.LogCaptureFixture
    ) -> None:
        caplog.set_level(logging.DEBUG, logger="httpcore")
        data_filter: DataRedactingFilter = DataRedactingFilter()
        caplog.handler.addFilter(data_filter)
        await openai_client.chat.completions.create(
            model="foo", messages=[{"role": "user", "content": "bar"}]
        )
        httpcore_logs: str = "\n".join(
            r.message for r in caplog.records if "receive_response_headers.complete" in r.message
        )
        assert LogPattern.REDACTED in httpcore_logs
        assert "http_version=HTTP/" in httpcore_logs
        assert "status=200" in httpcore_logs
        assert "content-type" not in httpcore_logs.lower()
        caplog.handler.removeFilter(data_filter)


class TestPassThrough:
    def test_filter_unmatched_message_passes_through(
        self, redacting_filter: DataRedactingFilter
    ) -> None:
        record: logging.LogRecord = _make_record("some other message: %s", ("foo",))
        redacting_filter.filter(record)
        assert record.msg == "some other message: %s"
        assert record.args == ("foo",)

    def test_filter_non_string_msg_passes_through(
        self, redacting_filter: DataRedactingFilter
    ) -> None:
        record: logging.LogRecord = _make_record(12345)
        redacting_filter.filter(record)
        assert record.msg == 12345

    def test_filter_always_returns_true(self, redacting_filter: DataRedactingFilter) -> None:
        assert redacting_filter.filter(_make_record("foo")) is True
