"""Tests for adapter schemas, factory, and buffered write behavior."""

from datetime import datetime
from unittest.mock import MagicMock, patch

import pytest
from pydantic import BaseModel

from mesa_runner.adapters import build_storage_adapter
from mesa_runner.adapters.dry_run import DryRunStorageAdapter
from mesa_runner.adapters.io_schemas import (
    DocumentInput,
    InferenceMetadata,
    InferenceResult,
    ModelMetadata,
)
from mesa_runner.adapters.snowflake import SnowflakeWrapper
from mesa_runner.config.config_base import SourceConfig
from mesa_runner.config.snowflake import SnowflakeConnectionParameters, SnowflakeStorageConfig


class TestDocumentInput:
    def test_create_with_required_fields(self):
        doc = DocumentInput(
            document_id="doc-123",
            document_content="Some content",
            document_update_dt=datetime(2024, 1, 1),
        )
        assert doc.document_id == "doc-123"
        assert doc.document_content == "Some content"
        assert doc.document_source == {}

    def test_create_with_document_source(self):
        doc = DocumentInput(
            document_id="doc-123",
            document_content="Content",
            document_update_dt=None,
            document_source={"NHS_NUMBER": "123456", "PATIENT_NAME": "Test"},
        )
        assert doc.document_source is not None
        assert doc.document_source["NHS_NUMBER"] == "123456"


class TestInferenceResult:
    def test_create_valid_result(self):
        class SimpleOutput(BaseModel):
            value: str

        result = InferenceResult(
            master_document_id="master-1",
            document_id="doc-1",
            document_update_dt=datetime.now(),
            validated_output=SimpleOutput(value="test"),
            document_source={"key": "value"},
            inference_result_metadata=InferenceMetadata(
                schema_package_name="test-pkg",
                schema_package_version="1.0.0",
                inference_metadata=datetime.now(),
            ),
            model_metadata=ModelMetadata(
                model_name="test-model",
                model_version="1.0",
                trained_schema_name="schema",
                trained_schema_version="1.0",
            ),
            is_valid=True,
        )
        assert result.is_valid is True
        assert result.validated_output is not None
        assert result.validated_output.value == "test"

    def test_create_failed_result(self):
        result = InferenceResult(
            master_document_id="master-1",
            document_id="doc-1",
            document_update_dt=datetime.now(),
            validated_output=None,
            inference_result_metadata=InferenceMetadata(
                schema_package_name="test-pkg",
                schema_package_version="1.0.0",
                inference_metadata=datetime.now(),
                failed_output="invalid raw output",
            ),
            model_metadata=ModelMetadata(
                model_name="test-model",
                model_version="1.0",
                trained_schema_name="schema",
                trained_schema_version="1.0",
            ),
            is_valid=False,
        )
        assert result.is_valid is False
        assert result.validated_output is None
        assert result.inference_result_metadata.failed_output == "invalid raw output"


# ---------- Factory tests ----------


class TestBuildStorageAdapter:
    def test_builds_snowflake_adapter(self, source_config: SourceConfig):
        with (
            patch("mesa_runner.adapters.snowflake.Session"),
            patch.object(SnowflakeWrapper, "_check_document_output_writable"),
            patch.object(SnowflakeWrapper, "_check_document_source_exists"),
        ):
            adapter = build_storage_adapter(source_config)
            assert isinstance(adapter, SnowflakeWrapper)

    def test_build_storage_adapter_dry_run_flag_returns_dry_run_adapter(self):
        assert isinstance(build_storage_adapter(MagicMock(), dry_run=True), DryRunStorageAdapter)

    def test_raises_for_unknown_type(self):
        """Factory raises for unsupported storage types."""
        mock_config = MagicMock(spec=SourceConfig)
        mock_storage = MagicMock()
        mock_storage.type = "unknown_type"
        mock_config.storage = mock_storage

        with pytest.raises(ValueError, match="Unknown storage type"):
            build_storage_adapter(mock_config)


# ---------- Buffered write tests ----------


class TestBufferedWrite:
    @pytest.fixture
    def mock_adapter(
        self,
        snowflake_storage_config: SnowflakeStorageConfig,
        snowflake_connection_params: SnowflakeConnectionParameters,
    ):
        """Create adapter with mocked session."""
        with (
            patch("mesa_runner.adapters.snowflake.Session"),
            patch.object(SnowflakeWrapper, "_check_document_output_writable"),
            patch.object(SnowflakeWrapper, "_check_document_source_exists"),
        ):
            return SnowflakeWrapper(snowflake_connection_params, snowflake_storage_config)

    def _make_result(self, doc_id: str) -> InferenceResult:
        """Helper to create a minimal InferenceResult."""
        return InferenceResult(
            master_document_id=doc_id,
            document_id=doc_id,
            document_update_dt=datetime.now(),
            validated_output=None,
            inference_result_metadata=InferenceMetadata(
                schema_package_name="pkg",
                schema_package_version="1.0",
                inference_metadata=datetime.now(),
            ),
            model_metadata=ModelMetadata(
                model_name="model",
                model_version="1.0",
                trained_schema_name="schema",
                trained_schema_version="1.0",
            ),
            is_valid=False,
        )

    def test_buffer_accumulates(self, mock_adapter):
        """Documents accumulate in buffer until threshold."""
        mock_adapter.write_document([self._make_result("doc-1")])
        assert len(mock_adapter._buffer) == 1

        mock_adapter.write_document([self._make_result("doc-2")])
        assert len(mock_adapter._buffer) == 2

    def test_flush_clears_buffer(self, mock_adapter):
        """Flush writes and clears buffer."""
        mock_adapter._buffer = [{"DOCUMENT_ID": "test", "IS_VALID": True}]

        with patch.object(mock_adapter.session, "create_dataframe") as mock_df:
            mock_df.return_value.select.return_value.write = MagicMock()
            mock_adapter.flush()

        assert len(mock_adapter._buffer) == 0

    def test_empty_flush_is_noop(self, mock_adapter):
        """Flush with empty buffer doesn't write."""
        with patch.object(mock_adapter.session, "create_dataframe") as mock_df:
            mock_adapter.flush()
            mock_df.assert_not_called()
