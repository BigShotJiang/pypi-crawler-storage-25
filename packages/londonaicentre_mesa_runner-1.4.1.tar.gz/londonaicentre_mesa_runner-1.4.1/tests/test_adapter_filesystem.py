"""Tests for FileSystemAdapter.get_unprocessed_document_count and get_documents."""

import json
from datetime import datetime
from pathlib import Path
from typing import Literal
from unittest.mock import patch

import duckdb
import pytest
from pydantic import BaseModel

from mesa_runner.adapters.filesystem import FileSystemAdapter
from mesa_runner.adapters.io_schemas import (
    DocumentInput,
    InferenceMetadata,
    InferenceResult,
    ModelMetadata,
)
from mesa_runner.config.filesystem import FilesystemStorageConfig


class _TestableAdapter(FileSystemAdapter):
    """Concrete subclass — abstract check methods are no-ops for testing."""

    def _check_document_output_writable(self): ...

    def _check_document_source_exists(self): ...


@pytest.fixture
def dirs(tmp_path):
    src = tmp_path / "src"
    tgt = tmp_path / "tgt"
    src.mkdir()
    tgt.mkdir()
    return src, tgt


def _make_adapter(
    src: Path,
    tgt: Path,
    input_fmt: Literal["txt", "json", "json.gz", "csv", "csv.gz", "parquet"] = "txt",
    output_fmt: Literal["json", "json.gz", "csv", "csv.gz", "parquet"] = "json",
    model_name: str = "mymodel",
) -> _TestableAdapter:
    config = FilesystemStorageConfig(
        type="filesystem",
        input_file_format=input_fmt,
        output_file_format=output_fmt,
        source_directory=src,
        target_directory=tgt,
    )
    return _TestableAdapter(config, model_name)


class TestGetUnprocessedDocumentCount:
    def test_counts_all_when_no_target_files(self, dirs):
        src, tgt = dirs
        (src / "a.txt").write_text("aaa")
        (src / "b.txt").write_text("bbb")
        (src / "c.txt").write_text("ccc")

        adapter = _make_adapter(src, tgt)

        assert adapter.get_unprocessed_document_count() == 3

    def test_excludes_processed_documents(self, dirs):
        src, tgt = dirs
        (src / "doc1.txt").write_text("one")
        (src / "doc2.txt").write_text("two")
        (src / "doc3.txt").write_text("three")
        (tgt / "doc1.json").write_text(json.dumps({"document_id": "doc1"}))

        adapter = _make_adapter(src, tgt)

        assert adapter.get_unprocessed_document_count() == 2

    def test_zero_when_all_processed(self, dirs):
        src, tgt = dirs
        (src / "doc1.txt").write_text("one")
        (src / "doc2.txt").write_text("two")
        (tgt / "doc1.json").write_text(json.dumps({"document_id": "doc1"}))
        (tgt / "doc2.json").write_text(json.dumps({"document_id": "doc2"}))

        adapter = _make_adapter(src, tgt)

        assert adapter.get_unprocessed_document_count() == 0

    def test_single_source_no_targets(self, dirs):
        src, tgt = dirs
        (src / "only.txt").write_text("solo content")

        adapter = _make_adapter(src, tgt)

        assert adapter.get_unprocessed_document_count() == 1


class TestGetDocuments:
    def test_yields_document_input_instances(self, dirs):
        src, tgt = dirs
        (src / "doc1.txt").write_text("content one")
        (src / "doc2.txt").write_text("content two")
        (tgt / "doc2.json").write_text(json.dumps({"document_id": "doc2"}))

        adapter = _make_adapter(src, tgt)
        docs = list(adapter.get_documents())

        assert all(isinstance(d, DocumentInput) for d in docs)

    def test_yields_only_unprocessed(self, dirs):
        src, tgt = dirs
        (src / "alpha.txt").write_text("alpha content")
        (src / "beta.txt").write_text("beta content")
        (src / "gamma.txt").write_text("gamma content")
        (tgt / "alpha.json").write_text(json.dumps({"document_id": "alpha"}))

        adapter = _make_adapter(src, tgt)
        docs = list(adapter.get_documents())

        assert {d.document_id for d in docs} == {"beta", "gamma"}

    def test_document_id_strips_txt_extension(self, dirs):
        src, tgt = dirs
        (src / "report.txt").write_text("report body")
        (tgt / "other.json").write_text(json.dumps({"document_id": "other"}))

        adapter = _make_adapter(src, tgt)
        docs = list(adapter.get_documents())

        assert len(docs) == 1
        assert docs[0].document_id == "report"

    def test_document_content_matches_file(self, dirs):
        src, tgt = dirs
        (src / "note.txt").write_text("hello world")
        (tgt / "other.json").write_text(json.dumps({"document_id": "other"}))

        adapter = _make_adapter(src, tgt)
        docs = list(adapter.get_documents())

        assert docs[0].document_content == "hello world"

    def test_yields_nothing_when_all_processed(self, dirs):
        src, tgt = dirs
        (src / "doc1.txt").write_text("content")
        (tgt / "doc1.json").write_text(json.dumps({"document_id": "doc1"}))

        adapter = _make_adapter(src, tgt)
        docs = list(adapter.get_documents())

        assert docs == []

    def test_handles_no_output_jsons(self, dirs):
        src, tgt = dirs
        (src / "doc1.txt").write_text("content")

        adapter = _make_adapter(src, tgt)
        docs = list(adapter.get_documents())

        assert docs[0].document_id == "doc1"


def _make_row(doc_id: str) -> dict:
    """Minimal buffer row matching __filesystem_row_format output."""
    return {
        "document_id": doc_id,
        "document_source": "{}",
        "document_inference": "{}",
        "metadata": "{}",
        "is_valid": False,
    }


def _make_result(doc_id: str, valid: bool = False) -> InferenceResult:
    return InferenceResult(
        master_document_id=doc_id,
        document_id=doc_id,
        document_update_dt=datetime.now(),
        validated_output=None,
        inference_result_metadata=InferenceMetadata(
            schema_package_name="pkg",
            schema_package_version="1.0",
            inference_metadata=datetime.now(),
        ),
        model_metadata=ModelMetadata(
            model_name="model",
            model_version="1.0",
            trained_schema_name="schema",
            trained_schema_version="1.0",
        ),
        is_valid=valid,
    )


class TestWriteDocument:
    def test_buffer_accumulates(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        adapter.write_document([_make_result("doc-1")])
        assert len(adapter._buffer) == 1

        adapter.write_document([_make_result("doc-2"), _make_result("doc-3")])
        assert len(adapter._buffer) == 3

    def test_flush_not_called_below_threshold(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        with patch.object(adapter, "flush") as mock_flush:
            adapter.write_document([_make_result(f"doc-{i}") for i in range(49)])
            mock_flush.assert_not_called()

    def test_flush_called_when_buffer_exceeds_50(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        with patch.object(adapter, "flush") as mock_flush:
            adapter.write_document([_make_result(f"doc-{i}") for i in range(51)])
            mock_flush.assert_called_once()

    def test_row_format_document_id(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        adapter.write_document([_make_result("my-doc")])

        assert adapter._buffer[0]["document_id"] == "my-doc"

    def test_row_format_is_valid_flag(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        adapter.write_document([_make_result("doc-ok", valid=True)])

        assert adapter._buffer[0]["is_valid"] is True

    def test_row_format_no_output_produces_empty_json(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        adapter.write_document([_make_result("doc-1")])

        assert adapter._buffer[0]["document_inference"] == "{}"

    def test_row_format_with_validated_output(self, dirs):
        class SimpleOutput(BaseModel):
            label: str

        src, tgt = dirs
        adapter = _make_adapter(src, tgt)
        result = _make_result("doc-1")
        result.validated_output = SimpleOutput(label="yes")

        adapter.write_document([result])

        assert json.loads(adapter._buffer[0]["document_inference"]) == {"label": "yes"}


class TestStructuredInputJson:
    def _write_json_src(self, src: Path, records: list[dict]):
        (src / "docs.json").write_text("\n".join(json.dumps(r) for r in records) + "\n")

    def test_count_all_when_no_output(self, dirs):
        src, tgt = dirs
        self._write_json_src(
            src,
            [
                {"document_id": "id1", "document_content": "one"},
                {"document_id": "id2", "document_content": "two"},
            ],
        )

        assert _make_adapter(src, tgt, input_fmt="json").get_unprocessed_document_count() == 2

    def test_count_excludes_processed(self, dirs):
        src, tgt = dirs
        self._write_json_src(
            src,
            [
                {"document_id": "id1", "document_content": "one"},
                {"document_id": "id2", "document_content": "two"},
            ],
        )
        (tgt / "out.json").write_text(json.dumps({"document_id": "id1"}))

        assert _make_adapter(src, tgt, input_fmt="json").get_unprocessed_document_count() == 1

    def test_get_documents_yields_correct_fields(self, dirs):
        src, tgt = dirs
        self._write_json_src(src, [{"document_id": "x", "document_content": "body text"}])

        docs = list(_make_adapter(src, tgt, input_fmt="json").get_documents())

        assert len(docs) == 1
        assert docs[0].document_id == "x"
        assert docs[0].document_content == "body text"

    def test_get_documents_excludes_processed(self, dirs):
        src, tgt = dirs
        self._write_json_src(
            src,
            [
                {"document_id": "id1", "document_content": "one"},
                {"document_id": "id2", "document_content": "two"},
            ],
        )
        (tgt / "out.json").write_text(json.dumps({"document_id": "id1"}))

        docs = list(_make_adapter(src, tgt, input_fmt="json").get_documents())

        assert {d.document_id for d in docs} == {"id2"}


class TestStructuredInputParquet:
    def _write_parquet_src(self, src: Path, records: list[dict]):
        rows = " UNION ALL ".join(
            f"SELECT '{r['document_id']}' AS document_id,"
            f" '{r['document_content']}' AS document_content"
            for r in records
        )
        with duckdb.connect() as conn:
            conn.sql(f"COPY ({rows}) TO '{src}/docs.parquet'")

    def test_count_all_when_no_output(self, dirs):
        src, tgt = dirs
        self._write_parquet_src(
            src,
            [
                {"document_id": "p1", "document_content": "one"},
                {"document_id": "p2", "document_content": "two"},
            ],
        )

        assert _make_adapter(src, tgt, input_fmt="parquet").get_unprocessed_document_count() == 2

    def test_get_documents_yields_correct_fields(self, dirs):
        src, tgt = dirs
        self._write_parquet_src(src, [{"document_id": "p1", "document_content": "parquet body"}])

        docs = list(_make_adapter(src, tgt, input_fmt="parquet").get_documents())

        assert docs[0].document_id == "p1"
        assert docs[0].document_content == "parquet body"


class TestStructuredInputCsv:
    def _write_csv_src(self, src: Path, records: list[dict]):
        lines = ["document_id,document_content"] + [
            f"{r['document_id']},{r['document_content']}" for r in records
        ]
        (src / "docs.csv").write_text("\n".join(lines) + "\n")

    def test_count_all_when_no_output(self, dirs):
        src, tgt = dirs
        self._write_csv_src(
            src,
            [
                {"document_id": "c1", "document_content": "one"},
                {"document_id": "c2", "document_content": "two"},
            ],
        )

        assert _make_adapter(src, tgt, input_fmt="csv").get_unprocessed_document_count() == 2

    def test_get_documents_yields_correct_fields(self, dirs):
        src, tgt = dirs
        self._write_csv_src(src, [{"document_id": "c1", "document_content": "csv body"}])

        docs = list(_make_adapter(src, tgt, input_fmt="csv").get_documents())

        assert docs[0].document_id == "c1"
        assert docs[0].document_content == "csv body"


class TestFlush:
    def test_empty_buffer_writes_no_files(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        adapter.flush()

        assert list(tgt.glob("*.json")) == []

    def test_writes_json_file_to_target_directory(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)
        adapter._buffer = [_make_row("doc1")]

        adapter.flush()

        assert len(list(tgt.glob("*.json"))) == 1

    def test_filename_starts_with_model_name(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt, model_name="mymodel")
        adapter._buffer = [_make_row("doc1")]

        adapter.flush()

        written = list(tgt.glob("*.json"))
        assert written[0].name.startswith("mymodel_")

    def test_clears_buffer_after_flush(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)
        adapter._buffer = [_make_row("doc1"), _make_row("doc2")]

        adapter.flush()

        assert adapter._buffer == []

    def test_multiple_flushes_write_separate_files(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        adapter._buffer = [_make_row("doc1")]
        adapter.flush()
        adapter._buffer = [_make_row("doc2")]
        adapter.flush()

        assert len(list(tgt.glob("*.json"))) == 2

    def test_document_id_survives_in_output(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)
        adapter._buffer = [_make_row("my-doc")]

        adapter.flush()

        with duckdb.connect() as conn:
            rows = conn.sql(f"SELECT document_id FROM '{tgt}/*.json'").fetchdf()

        assert list(rows["document_id"]) == ["my-doc"]

    def test_flushed_documents_excluded_from_get_documents(self, dirs):
        src, tgt = dirs
        (src / "doc1.txt").write_text("content one")
        (src / "doc2.txt").write_text("content two")
        adapter = _make_adapter(src, tgt)

        adapter.write_document([_make_result("doc1")])
        adapter.flush()

        remaining = list(adapter.get_documents())

        assert {d.document_id for d in remaining} == {"doc2"}
