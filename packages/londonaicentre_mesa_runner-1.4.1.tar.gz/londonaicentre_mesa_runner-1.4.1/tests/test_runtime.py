import json
from collections.abc import Iterable, Iterator
from unittest.mock import MagicMock, patch

import pytest
from openai import APITimeoutError, BadRequestError
from pydantic import BaseModel
from snowflake.snowpark import Session
from snowflake.snowpark.types import (
    BooleanType,
    StringType,
    StructField,
    StructType,
    TimestampType,
    VariantType,
)

from mesa_runner.adapters.snowflake import SnowflakeWrapper
from mesa_runner.config.snowflake import SnowflakeConnectionParameters, SnowflakeStorageConfig
from mesa_runner.inferrer import InferrenceBackend, ModelConfig
from mesa_runner.runner import Runner


class _StubModel(BaseModel):
    """Minimal pydantic model for tests that don't exercise inference."""

    pass


class StubBackend(InferrenceBackend):
    """Minimal backend stub for tests that don't exercise inference."""

    def generate(self, docs: Iterable[tuple[str, str]]) -> Iterator[tuple[str, str]]:
        for doc_id, _ in docs:
            yield doc_id, ""


@pytest.fixture(scope="module")
def local_session():
    """Create a local testing session for Snowpark."""
    return Session.builder.config("local_testing", True).create()


@pytest.fixture
def stub_model_config():
    return ModelConfig(
        prompt_template="test prompt: ",
        output_model=_StubModel,
        model_name="stub",
        schema_package="pydantic",
        max_tokens=20_000,
    )


@pytest.fixture
def stub_backend():
    return StubBackend()


source_df_schema = StructType(
    [
        StructField("DOCUMENT_ID", StringType()),
        StructField("CONTENT", StringType()),
        StructField("TIMESTAMP", TimestampType()),
    ]
)

sink_df_schema = StructType(
    [
        StructField("DOCUMENT_ID", StringType()),
        StructField("DOCUMENT_SOURCE", VariantType()),
        StructField("DOCUMENT_INFERENCE", VariantType()),
        StructField("METADATA", VariantType()),
        StructField("IS_VALID", BooleanType()),
    ]
)


def _make_storage_adapter(
    storage_config: SnowflakeStorageConfig,
    connection_params: SnowflakeConnectionParameters,
    local_session: Session,
) -> SnowflakeWrapper:
    """Helper to create a SnowflakeWrapper with mocked session."""
    with (
        patch("mesa_runner.adapters.snowflake.Session") as mock_session,
        patch.object(SnowflakeWrapper, "_check_document_output_writable", return_value=None),
        patch.object(SnowflakeWrapper, "_check_document_source_exists", return_value=None),
    ):
        mock_builder = MagicMock()
        mock_session.builder = mock_builder
        mock_builder.configs.return_value.create.return_value = local_session

        wrapper = SnowflakeWrapper(connection_params, storage_config)
        wrapper.session = local_session
        return wrapper


# ---------- Storage adapter tests (batch fetching / counting) ----------


def test_get_unprocessed_document_count(
    snowflake_storage_config: SnowflakeStorageConfig,
    snowflake_connection_params: SnowflakeConnectionParameters,
    local_session: Session,
):
    # Create source table with test data (500 documents)
    source_data = [
        {"DOCUMENT_ID": f"document_id_{i}", "CONTENT": f"content_{i}", "TIMESTAMP": "2024-01-01"}
        for i in range(500)
    ]
    source_df = local_session.create_dataframe(source_data, schema=source_df_schema)
    source_df.write.save_as_table(snowflake_storage_config.source_table_fqn, mode="overwrite")

    # Create empty sink table (no processed documents yet) using DataFrame API
    sink_df = local_session.create_dataframe(data=[], schema=sink_df_schema)
    sink_df.write.save_as_table(snowflake_storage_config.sink_table_fqn, mode="overwrite")

    adapter = _make_storage_adapter(
        snowflake_storage_config, snowflake_connection_params, local_session
    )
    result = adapter.get_unprocessed_document_count()

    # All 500 source documents are unprocessed (anti-join with empty sink)
    assert result == 500


def test_get_unprocessed_document_count_with_some_processed(
    snowflake_storage_config: SnowflakeStorageConfig,
    snowflake_connection_params: SnowflakeConnectionParameters,
    local_session: Session,
):
    # Create source table with 500 documents
    source_data = [
        {"DOCUMENT_ID": i, "CONTENT": f"content_{i}", "TIMESTAMP": "2024-01-01"} for i in range(500)
    ]
    source_df = local_session.create_dataframe(source_data, schema=source_df_schema)
    source_df.write.save_as_table(snowflake_storage_config.source_table_fqn, mode="overwrite")

    # Create sink table with 200 already processed documents
    sink_data = [
        {
            "DOCUMENT_ID": i,
            "DOCUMENT_SOURCE": "{}",
            "DOCUMENT_INFERENCE": "{}",
            "METADATA": "{}",
            "IS_VALID": True,
        }
        for i in range(200)
    ]

    sink_df = local_session.create_dataframe(sink_data, schema=sink_df_schema)
    sink_df.write.save_as_table(snowflake_storage_config.sink_table_fqn, mode="overwrite")

    adapter = _make_storage_adapter(
        snowflake_storage_config, snowflake_connection_params, local_session
    )
    result = adapter.get_unprocessed_document_count()

    # 500 source - 200 processed = 300 unprocessed
    assert result == 300


# ---------- Batch inference tests ----------

# Minimal valid OncologyModel JSON
_VALID_ONCOLOGY_JSON = json.dumps(
    {
        "document_has_primary_cancer_flag": False,
        "primary_cancer_confirmed_flag": False,
    }
)

_VALID_RAW_OUTPUT = f"<output>{_VALID_ONCOLOGY_JSON}</output>"


def test_infer_documents_successful_batch(
    snowflake_storage_config: SnowflakeStorageConfig,
    snowflake_connection_params: SnowflakeConnectionParameters,
    local_session: Session,
):
    """All documents in a batch are processed successfully."""
    from oncoschema.schema import OncologyModel

    # Set up source with 3 documents
    source_data = [
        {"DOCUMENT_ID": f"doc_{i}", "CONTENT": f"content_{i}", "TIMESTAMP": "2024-01-01"}
        for i in range(3)
    ]
    source_df = local_session.create_dataframe(source_data, schema=source_df_schema)
    source_df.write.save_as_table(snowflake_storage_config.source_table_fqn, mode="overwrite")

    # Empty sink
    sink_df = local_session.create_dataframe(data=[], schema=sink_df_schema)
    sink_df.write.save_as_table(snowflake_storage_config.sink_table_fqn, mode="overwrite")

    # Mock backend that returns valid output for each prompt; capture inputs for assertions.
    captured_docs: list[tuple[str, str]] = []

    def _gen(docs: Iterable[tuple[str, str]]) -> Iterator[tuple[str, str]]:
        for doc_id, content in docs:
            captured_docs.append((doc_id, content))
            yield doc_id, _VALID_RAW_OUTPUT

    mock_backend = MagicMock(spec=InferrenceBackend)
    mock_backend.generate.side_effect = _gen

    model_config = ModelConfig(
        prompt_template="extract: ",
        output_model=OncologyModel,
        model_name="test_model",
        schema_package="londonaicentre-oncoschema",
        max_tokens=20_000,
    )

    adapter = _make_storage_adapter(
        snowflake_storage_config, snowflake_connection_params, local_session
    )
    runner = Runner(
        backend=mock_backend,
        model_config=model_config,
        storage_adapter=adapter,
        fetch_batch_size=1000,
    )
    runner.infer_documents()

    # Verify backend was called with 3 (doc_id, content) pairs
    mock_backend.generate.assert_called_once()
    assert len(captured_docs) == 3
    assert all(content.startswith("content_") for _, content in captured_docs)

    # Verify results were written to sink
    sink_tbl = local_session.table(snowflake_storage_config.sink_table_fqn)
    assert sink_tbl.count() == 3

    rows = sink_tbl.collect()
    for row in rows:
        assert row["IS_VALID"] is True


def test_infer_documents_partial_failure(
    snowflake_storage_config: SnowflakeStorageConfig,
    snowflake_connection_params: SnowflakeConnectionParameters,
    local_session: Session,
):
    """One document fails parsing, others succeed."""
    from oncoschema.schema import OncologyModel

    source_data = [
        {"DOCUMENT_ID": f"doc_{i}", "CONTENT": f"content_{i}", "TIMESTAMP": "2024-01-01"}
        for i in range(3)
    ]
    source_df = local_session.create_dataframe(source_data, schema=source_df_schema)
    source_df.write.save_as_table(snowflake_storage_config.source_table_fqn, mode="overwrite")

    sink_df = local_session.create_dataframe(data=[], schema=sink_df_schema)
    sink_df.write.save_as_table(snowflake_storage_config.sink_table_fqn, mode="overwrite")

    # Second document returns unparseable output
    def _gen_partial(docs: Iterable[tuple[str, str]]) -> Iterator[tuple[str, str]]:
        docs_list = list(docs)
        yield docs_list[0][0], _VALID_RAW_OUTPUT
        yield docs_list[1][0], "this is not valid output at all"
        yield docs_list[2][0], _VALID_RAW_OUTPUT

    mock_backend = MagicMock(spec=InferrenceBackend)
    mock_backend.generate.side_effect = _gen_partial

    model_config = ModelConfig(
        prompt_template="extract: ",
        output_model=OncologyModel,
        model_name="test_model",
        schema_package="londonaicentre-oncoschema",
        max_tokens=20_000,
    )

    adapter = _make_storage_adapter(
        snowflake_storage_config, snowflake_connection_params, local_session
    )
    runner = Runner(
        backend=mock_backend,
        model_config=model_config,
        storage_adapter=adapter,
        fetch_batch_size=1000,
    )
    runner.infer_documents()

    sink_tbl = local_session.table(snowflake_storage_config.sink_table_fqn)
    assert sink_tbl.count() == 3

    rows = sorted(sink_tbl.collect(), key=lambda r: r["DOCUMENT_ID"])
    assert rows[0]["IS_VALID"] is True
    assert rows[1]["IS_VALID"] is False
    assert rows[2]["IS_VALID"] is True


def test_infer_documents_empty_batch(
    snowflake_storage_config: SnowflakeStorageConfig,
    snowflake_connection_params: SnowflakeConnectionParameters,
    local_session: Session,
    stub_backend: StubBackend,
):
    """No unprocessed documents — loop exits immediately."""
    from oncoschema.schema import OncologyModel

    # Source and sink both have the same document — nothing to process
    source_data = [
        {"DOCUMENT_ID": "doc_0", "CONTENT": "content", "TIMESTAMP": "2024-01-01"},
    ]
    source_df = local_session.create_dataframe(source_data, schema=source_df_schema)
    source_df.write.save_as_table(snowflake_storage_config.source_table_fqn, mode="overwrite")

    sink_data = [
        {
            "DOCUMENT_ID": "doc_0",
            "DOCUMENT_SOURCE": "{}",
            "DOCUMENT_INFERENCE": "{}",
            "METADATA": "{}",
            "IS_VALID": True,
        },
    ]
    sink_df = local_session.create_dataframe(sink_data, schema=sink_df_schema)
    sink_df.write.save_as_table(snowflake_storage_config.sink_table_fqn, mode="overwrite")

    model_config = ModelConfig(
        prompt_template="extract: ",
        output_model=OncologyModel,
        model_name="test_model",
        schema_package="londonaicentre-oncoschema",
        max_tokens=20_000,
    )

    adapter = _make_storage_adapter(
        snowflake_storage_config, snowflake_connection_params, local_session
    )
    runner = Runner(
        backend=stub_backend,
        model_config=model_config,
        storage_adapter=adapter,
        fetch_batch_size=1000,
    )
    runner.infer_documents()

    # Sink should still have exactly 1 row (nothing new added)
    sink_tbl = local_session.table(snowflake_storage_config.sink_table_fqn)
    assert sink_tbl.count() == 1


def test_infer_documents_non_threaded_mode(
    snowflake_storage_config: SnowflakeStorageConfig,
    snowflake_connection_params: SnowflakeConnectionParameters,
    local_session: Session,
    stub_backend: StubBackend,
    stub_model_config: ModelConfig,
):
    source_data = [
        {"DOCUMENT_ID": f"doc_{i}", "CONTENT": f"content_{i}", "TIMESTAMP": "2024-01-01"}
        for i in range(3)
    ]
    source_df = local_session.create_dataframe(source_data, schema=source_df_schema)
    source_df.write.save_as_table(snowflake_storage_config.source_table_fqn, mode="overwrite")

    sink_df = local_session.create_dataframe(data=[], schema=sink_df_schema)
    sink_df.write.save_as_table(snowflake_storage_config.sink_table_fqn, mode="overwrite")

    adapter = _make_storage_adapter(
        snowflake_storage_config, snowflake_connection_params, local_session
    )
    runner = Runner(
        backend=stub_backend,
        model_config=stub_model_config,
        storage_adapter=adapter,
        fetch_batch_size=2,
    )
    runner.infer_documents(threaded=False)

    sink_tbl = local_session.table(snowflake_storage_config.sink_table_fqn)
    assert sink_tbl.count() == 3


@pytest.mark.parametrize(
    ("error", "expected_failed_output"),
    [
        (
            BadRequestError(
                message="simulated bad request error (test)",
                response=MagicMock(),
                body={},
            ),
            "vLLM Response Failure (BadRequestError)",
        ),
        (
            APITimeoutError(request=MagicMock()),
            "vLLM Response Failure (APITimeoutError)",
        ),
    ],
)
def test_infer_documents_request_error_handling(
    snowflake_storage_config: SnowflakeStorageConfig,
    snowflake_connection_params: SnowflakeConnectionParameters,
    local_session: Session,
    error: Exception,
    expected_failed_output: str,
):
    """Request errors are recorded as failed results without halting inference."""
    from oncoschema.schema import OncologyModel

    source_data = [
        {"DOCUMENT_ID": f"doc_{i}", "CONTENT": f"content_{i}", "TIMESTAMP": "2024-01-01"}
        for i in range(2)
    ]
    source_df = local_session.create_dataframe(source_data, schema=source_df_schema)
    source_df.write.save_as_table(snowflake_storage_config.source_table_fqn, mode="overwrite")

    sink_df = local_session.create_dataframe(data=[], schema=sink_df_schema)
    sink_df.write.save_as_table(snowflake_storage_config.sink_table_fqn, mode="overwrite")

    # Generate one bad test result, and one good result
    def _gen_partial(
        docs: Iterable[tuple[str, Exception]],
    ) -> Iterator[tuple[str, Exception | str]]:
        docs_list = list(docs)
        yield docs_list[0][0], error
        yield docs_list[1][0], _VALID_RAW_OUTPUT

    mock_backend = MagicMock(spec=InferrenceBackend)
    mock_backend.generate.side_effect = _gen_partial

    model_config = ModelConfig(
        prompt_template="extract: ",
        output_model=OncologyModel,
        model_name="test_model",
        schema_package="londonaicentre-oncoschema",
        max_tokens=20_000,
    )

    adapter = _make_storage_adapter(
        snowflake_storage_config, snowflake_connection_params, local_session
    )
    runner = Runner(
        backend=mock_backend,
        model_config=model_config,
        storage_adapter=adapter,
        fetch_batch_size=1000,
    )
    runner.infer_documents()

    sink_tbl = local_session.table(snowflake_storage_config.sink_table_fqn)
    assert sink_tbl.count() == 2

    rows = sorted(sink_tbl.collect(), key=lambda r: r["DOCUMENT_ID"])
    assert rows[0]["IS_VALID"] is False

    # Deserialise test case and check we get expected message
    metadata = json.loads(rows[0]["METADATA"])  # pyright: ignore[reportArgumentType]
    assert metadata["inference"]["failed_output"] == expected_failed_output

    # Happily carries on with the next result
    assert rows[1]["IS_VALID"] is True
