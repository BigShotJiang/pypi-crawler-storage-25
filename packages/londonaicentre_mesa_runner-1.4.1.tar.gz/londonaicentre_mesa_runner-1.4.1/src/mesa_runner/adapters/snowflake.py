import json
import logging
from datetime import datetime
from typing import Any, Generator

from snowflake.connector.errors import DatabaseError
from snowflake.snowpark import DataFrame, Session
from snowflake.snowpark.functions import col, parse_json

from mesa_runner.adapters.io_schemas import DocumentInput, InferenceResult
from mesa_runner.adapters.storage_base import AbstractStorageAdapter
from mesa_runner.config.snowflake import SnowflakeConnectionParameters, SnowflakeStorageConfig

logger = logging.getLogger(__name__)


class SnowflakeWrapper(AbstractStorageAdapter):
    def __init__(
        self,
        params: SnowflakeConnectionParameters,
        storage_config: SnowflakeStorageConfig,
    ):
        logger.info("Setting up Snowflake Storage Adapter")
        try:
            self.session: Session = Session.builder.configs(
                {
                    "schema": params.sf_schema,
                    **params.model_dump(exclude={"sf_schema"}),
                }
            ).create()
            self.session.telemetry_enabled = False
        except DatabaseError as de:
            logger.critical("Failed to authorise client to Snowflake endpoint.")
            logger.critical("Unable to proceed further. Check connectivity settings.")
            raise RuntimeError("Failed to authorise client to Snowflake endpoint.") from de

        self.source_config = storage_config

        # Buffer for writing documents in batches
        self._buffer = []

        # Set schema context for temporary table creation during insert
        # Required for using Snowflake Dataframes
        self.session.use_schema(
            f'"{self.source_config.sink_database}"."{self.source_config.sink_schema}"'
        )

        super().__init__()

    def get_unprocessed_document_count(self) -> int:
        source_tbl = self.session.table(self.source_config.source_table_fqn)
        sink_tbl = self.session.table(self.source_config.sink_table_fqn)

        return source_tbl.join(
            sink_tbl,
            source_tbl.document_id == sink_tbl.document_id,
            "anti",
        ).count()

    def get_documents(self) -> Generator[DocumentInput, None, None]:
        """
        Method to get batches of documents to load to infer against.
        """
        source_tbl = self.session.table(self.source_config.source_table_fqn)
        sink_tbl = self.session.table(self.source_config.sink_table_fqn)

        df: DataFrame = source_tbl.join(
            sink_tbl,
            source_tbl.document_id == sink_tbl.document_id,
            "anti",
        ).select(
            source_tbl.document_id,
            source_tbl.content,
            source_tbl.timestamp.alias("DOCUMENT_CREATE_DT"),
        )

        for row in df.to_local_iterator():
            # Cast a dict to make it easier to get everything else
            row_dict = row.as_dict()

            yield DocumentInput(
                document_id=str(row["DOCUMENT_ID"]) if row["DOCUMENT_ID"] is not None else "",
                document_content=str(row["CONTENT"]) if row["CONTENT"] is not None else "",
                document_update_dt=datetime.fromisoformat(str(row["DOCUMENT_CREATE_DT"])),
                document_source={
                    k: v
                    for k, v in row_dict.items()
                    if k not in {"DOCUMENT_ID", "CONTENT", "DOCUMENT_CREATE_DT"}
                },
            )
        logger.debug("Unprocessed documents completed.")

    def write_document(self, documents: list[InferenceResult]):
        rows = [self.__snowflake_row_format(doc) for doc in documents]
        self._buffer.extend(rows)

        if len(self._buffer) >= self.source_config.write_buffer_size:
            self.flush()

    @staticmethod
    def __snowflake_row_format(document: InferenceResult) -> dict[str, Any]:
        return {
            "DOCUMENT_ID": document.document_id,
            "DOCUMENT_SOURCE": json.dumps(document.document_source or {}, default=str),
            "DOCUMENT_INFERENCE": document.validated_output.model_dump_json()
            if document.validated_output
            else "{}",
            "METADATA": json.dumps(
                {
                    "inference": document.inference_result_metadata.model_dump(),
                    "model": document.model_metadata.model_dump(),
                },
                default=str,
            ),
            "IS_VALID": document.is_valid,
        }

    def _check_document_source_exists(self):
        """
        Method to check that our source and sink tables exist as expected.

        Will terminate process if expected tables are not found rather than continuing

        Returns: None
        """
        tables_to_validate = [
            (
                "Source",
                self.source_config.source_database,
                self.source_config.source_schema,
                self.source_config.source_table,
                self.source_config.source_table_fqn,
            ),
            (
                "Sink",
                self.source_config.sink_database,
                self.source_config.sink_schema,
                self.source_config.sink_table,
                self.source_config.sink_table_fqn,
            ),
        ]

        for label, database, schema, table, fqn in tables_to_validate:
            if not self._validate_table_exists(database=database, schema=schema, table=table):
                logger.critical(f"{label} table: `{fqn}` does not exist")
                raise RuntimeError(
                    f"{label} table: `{fqn}` does not exist. "
                    "Please check config and ensure user/role has appropriate permissions."
                )

        logger.info("Source/Sink tables detected.")

    def _check_document_output_writable(self):
        """
        Method to check that we can write to the sink table by attempting a zero row insert.

        Will terminate process if we cannot write to the sink table.

        Returns: None
        """
        try:
            # Try writing zero rows to the sink table to validate write permissions.
            # Use the sink table as a trick so we don't need to worry about structure.
            self.session.sql(f"""
                             INSERT INTO {self.source_config.sink_table_fqn}
                             SELECT * FROM {self.source_config.sink_table_fqn}
                             LIMIT 0
                             """).collect()
        except DatabaseError as de:
            logger.critical(
                f"Unable to write to Sink table: `{self.source_config.sink_table_fqn}`."
            )
            logger.critical("Please check permissions for the configured user/role.")
            raise RuntimeError(
                f"Unable to write to Sink table: `{self.source_config.sink_table_fqn}`."
            ) from de

    def _validate_table_exists(self, database: str, schema: str, table: str) -> bool:
        """Private method to check catalog for table presence.

        Returns True if table exists"""
        return self.session.catalog.table_exists(database=database, schema=schema, table=table)

    def flush(self):
        if not self._buffer:
            return

        logger.debug(f"Writing buffer of length: {len(self._buffer)}")
        df = self.session.create_dataframe(self._buffer).select(
            col("DOCUMENT_ID"),
            parse_json(col("DOCUMENT_SOURCE")).alias("DOCUMENT_SOURCE"),
            parse_json(col("DOCUMENT_INFERENCE")).alias("DOCUMENT_INFERENCE"),
            parse_json(col("METADATA")).alias("METADATA"),
            col("IS_VALID"),
        )
        df.write.insert_into(self.source_config.sink_table_fqn)

        self._buffer = []
