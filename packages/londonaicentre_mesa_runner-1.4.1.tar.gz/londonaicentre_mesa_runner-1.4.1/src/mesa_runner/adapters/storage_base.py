from abc import ABC, abstractmethod
from typing import Generator

from mesa_runner.adapters.io_schemas import DocumentInput, InferenceResult

"""
This storage adapter class represents methods for how other adapters can be setup as different
sources and sinks of data.

It is up to the adapter to decide on batching/write back strategy.
"""


class AbstractStorageAdapter(ABC):
    def __init__(self):
        self._check_document_output_writable()
        self._check_document_source_exists()

    # Get unprocessed document count to consider
    @abstractmethod
    def get_unprocessed_document_count(self) -> int: ...

    @abstractmethod
    def get_documents(self) -> Generator[DocumentInput, None, None]: ...

    @abstractmethod
    def write_document(self, documents: list[InferenceResult]): ...

    @abstractmethod
    def _check_document_output_writable(self): ...

    @abstractmethod
    def _check_document_source_exists(self): ...

    @abstractmethod
    def flush(self): ...
