import logging
import random
from datetime import datetime
from typing import Generator

from mesa_runner.adapters.io_schemas import DocumentInput, InferenceResult
from mesa_runner.adapters.storage_base import AbstractStorageAdapter


class DryRunStorageAdapter(AbstractStorageAdapter):
    _WORD_POOL: list[str] = [
        "patient",
        "diagnosis",
        "treatment",
        "history",
        "medical",
        "clinical",
        "symptoms",
        "examination",
        "results",
        "assessment",
        "procedure",
        "medication",
        "therapy",
        "condition",
        "report",
        "findings",
        "analysis",
        "consultation",
        "follow",
        "up",
        "review",
        "outcome",
        "prognosis",
        "investigation",
        "referral",
    ]

    def __init__(self, document_count: int = 5):
        self.__document_count: int = document_count
        self.__logger: logging.Logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        super().__init__()

    def _generate_random_content(self, min_words: int = 10, max_words: int = 100) -> str:
        return " ".join(random.choices(self._WORD_POOL, k=random.randint(min_words, max_words)))

    def get_unprocessed_document_count(self) -> int:
        return self.__document_count

    def get_documents(self) -> Generator[DocumentInput, None, None]:
        for index in range(self.__document_count):
            yield DocumentInput(
                document_id=f"dry_run_doc_{index}",
                document_content=self._generate_random_content(),
                document_update_dt=datetime.now(),
                document_source={"source": "dry_run", "index": index},
            )

    def write_document(self, documents: list[InferenceResult]):
        self.__logger.info(f"Would write {len(documents)} documents")

    def _check_document_output_writable(self):
        pass

    def _check_document_source_exists(self):
        pass

    def flush(self):
        pass
