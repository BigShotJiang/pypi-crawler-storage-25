import json
import logging
from datetime import datetime
from typing import Any, Generator

import duckdb
import pandas as pd

from mesa_runner.adapters.io_schemas import DocumentInput, InferenceResult
from mesa_runner.adapters.storage_base import AbstractStorageAdapter
from mesa_runner.config.s3 import S3StorageConfig

logger = logging.getLogger(__name__)

_READ_FN: dict[str, str] = {
    "json": "read_json",
    "json.gz": "read_json",
    "csv": "read_csv",
    "csv.gz": "read_csv",
    "parquet": "read_parquet",
}


class S3Adapter(AbstractStorageAdapter):
    def __init__(self, storage_config: S3StorageConfig, model_name: str):
        self.storage_config = storage_config
        self.model_name = model_name
        self._buffer: list[dict[str, Any]] = []

        self._check_document_output_writable()
        self._check_document_source_exists()

    # Connect with minio overwritten params

    def _connect(self) -> duckdb.DuckDBPyConnection:
        conn = duckdb.connect()
        creds = self.storage_config.connection_params
        logger.debug("Loading httpfs extension")
        conn.sql("LOAD httpfs;")
        logger.debug("Creating S3 secret for endpoint %s", creds.endpoint)
        conn.sql(f"""
            CREATE OR REPLACE SECRET mesa_s3 (
                TYPE S3,
                KEY_ID '{creds.key_id}',
                SECRET '{creds.secret}',
                ENDPOINT '{creds.endpoint}',
                REGION '{creds.region}',
                USE_SSL {str(creds.use_ssl).lower()},
                URL_STYLE '{creds.url_style}'
            )
        """)
        logger.debug("S3 connection ready")
        return conn

    def _output_files_exist(self, conn: duckdb.DuckDBPyConnection) -> bool:
        fmt = self.storage_config.output_file_format
        tgt = self.storage_config.destination_path
        logger.debug("Checking for existing output files at %s/*.%s", tgt, fmt)
        result = conn.sql(f"SELECT COUNT(*) FROM glob('{tgt}/*.{fmt}')").fetchone()
        exists = bool(result and result[0] > 0)
        logger.debug("Output files exist: %s", exists)
        return exists

    def get_unprocessed_document_count(self) -> int:
        fmt = self.storage_config.input_file_format
        src = self.storage_config.source_path
        tgt = self.storage_config.destination_path
        out_fmt = self.storage_config.output_file_format

        with self._connect() as conn:
            has_output = self._output_files_exist(conn)
            read_out_fn = _READ_FN[out_fmt]

            if fmt == "txt":
                base = f"SELECT COUNT(*) FROM read_text('{src}/*.txt')"
                anti = f"""
                    SELECT COUNT(*) FROM read_text('{src}/*.txt') src
                    ANTI JOIN {read_out_fn}('{tgt}/*.{out_fmt}') tgt
                        ON replace(parse_filename(src.filename), '.txt', '') = tgt.document_id
                """
                query = base if not has_output else anti
            else:
                read_fn = _READ_FN[fmt]
                base = f"SELECT COUNT(*) FROM {read_fn}('{src}/*.{fmt}')"
                anti = f"""
                    SELECT COUNT(*) FROM {read_fn}('{src}/*.{fmt}') src
                    ANTI JOIN {read_out_fn}('{tgt}/*.{out_fmt}') tgt
                        ON src.document_id = tgt.document_id
                """
                query = base if not has_output else anti

            logger.debug(f"Counting unprocessed documents (anti_join={has_output})")
            res = conn.sql(query).fetchone()

        count = int(res[0]) if res else 0
        logger.info(f"Unprocessed document count: {count}")
        return count

    def get_documents(self) -> Generator[DocumentInput, None, None]:
        fmt = self.storage_config.input_file_format
        src = self.storage_config.source_path
        tgt = self.storage_config.destination_path
        out_fmt = self.storage_config.output_file_format

        with self._connect() as conn:
            has_output = self._output_files_exist(conn)
            read_out_fn = _READ_FN[out_fmt]

            if fmt == "txt":
                select = """
                    replace(parse_filename(src.filename), '.txt', '') AS document_id,
                    src.content AS document_content
                """
                base = f"SELECT {select} FROM read_text('{src}/*.txt') src"
                anti = f"""
                    SELECT {select} FROM read_text('{src}/*.txt') src
                    ANTI JOIN {read_out_fn}('{tgt}/*.{out_fmt}') tgt
                        ON replace(parse_filename(src.filename), '.txt', '') = tgt.document_id
                """
                query = base if not has_output else anti
            else:
                read_fn = _READ_FN[fmt]
                base = f"""
                    SELECT document_id, document_content
                    FROM {read_fn}('{src}/*.{fmt}')
                """
                anti = f"""
                    SELECT src.document_id, src.document_content
                    FROM {read_fn}('{src}/*.{fmt}') src
                    ANTI JOIN {read_out_fn}('{tgt}/*.{out_fmt}') tgt
                        ON src.document_id = tgt.document_id
                """
                query = base if not has_output else anti

            logger.debug("Fetching documents from %s (fmt=%s, anti_join=%s)", src, fmt, has_output)
            rows = conn.sql(query).fetchdf().to_dict(orient="records")

        logger.info(f"Fetched {len(rows)} documents")
        for row in rows:
            yield DocumentInput(
                document_id=str(row["document_id"]),
                document_content=str(row["document_content"]),
                document_update_dt=datetime.now(),
            )

    def write_document(self, documents: list[InferenceResult]):
        self._buffer.extend(self._row_format(doc) for doc in documents)
        if len(self._buffer) >= self.storage_config.write_buffer_size:
            self.flush()

    def _check_document_output_writable(self):
        pass

    def _check_document_source_exists(self):
        pass

    def flush(self):
        if not self._buffer:
            return

        logger.debug("Flushing buffer of %d rows", len(self._buffer))

        tgt = self.storage_config.destination_path
        fmt = self.storage_config.output_file_format
        ts = datetime.now().strftime("%Y%m%d_%H%M%S%f")
        filename = f"{self.model_name}_{ts}.{fmt}"

        logger.debug("Writing output to %s/%s", tgt, filename)
        df = pd.DataFrame(self._buffer)  # noqa
        with self._connect() as conn:
            conn.sql(f"COPY (FROM df) TO '{tgt}/{filename}';")
        logger.debug("Flush complete")

        self._buffer = []

    @staticmethod
    def _row_format(document: InferenceResult) -> dict[str, Any]:
        return {
            "document_id": document.document_id,
            "document_source": json.dumps(document.document_source or {}, default=str),
            "document_inference": document.validated_output.model_dump_json()
            if document.validated_output
            else "{}",
            "metadata": json.dumps(
                {
                    "inference": document.inference_result_metadata.model_dump(),
                    "model": document.model_metadata.model_dump(),
                },
                default=str,
            ),
            "is_valid": document.is_valid,
        }
