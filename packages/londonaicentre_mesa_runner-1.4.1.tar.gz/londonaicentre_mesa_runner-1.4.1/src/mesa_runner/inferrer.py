import asyncio
import logging
import queue
import re
import threading
from abc import ABC, abstractmethod
from collections.abc import Iterable, Iterator
from importlib.metadata import PackageNotFoundError, version
from typing import Any, Generic, TypeVar

import httpx
from openai import APITimeoutError, AsyncOpenAI, BadRequestError
from pydantic import BaseModel, computed_field, field_validator

T = TypeVar("T", bound=BaseModel)

logger = logging.getLogger(__name__)

# Sentinel object to emit after all documents have been drained from the source iterator
_STREAM_SENTINEL = object()


class InferrenceBackend(ABC):
    """Abstract base for different inferrence engines that
    we may want in the future beyond VLLM e.g. Transformers (mac evaluation possible)"""

    @abstractmethod
    def generate(
        self, docs: Iterable[tuple[str, str]]
    ) -> Iterator[tuple[str, str] | tuple[str, Exception]]:
        """Yield (doc_id, raw_text) pairs in completion order."""
        pass


class ModelConfig(BaseModel, Generic[T]):
    """Base config that all models types regardless of backend will need to extend"""

    prompt_template: str
    output_model: type[T]
    model_name: str
    schema_package: str
    max_tokens: int
    temperature: float = 0.0
    max_concurrent_requests: int = 50

    @field_validator("schema_package")
    @classmethod
    def _validate_schema_package_installed(cls, v: str) -> str:
        try:
            version(v)
        except PackageNotFoundError:
            raise ValueError(f"Schema package '{v}' is not installed") from PackageNotFoundError
        return v

    @computed_field
    @property
    def schema_version(self) -> str:
        """Derive schema version from the installed schema package."""
        return version(self.schema_package)


# TODO: Abstract into config.
_MAX_INPUT_TOKENS = 30_000
_MIN_DOC_TOKENS = 10_000


class VLLMBackend(InferrenceBackend):
    def __init__(
        self, model_path: str, max_model_len: int, model_config: ModelConfig, **vllm_kwargs
    ):
        from mesalocal import VLLM
        from mesalocal.inferrer import SamplingParams
        from mesalocal.settings import VLLMConfig
        from transformers import AutoTokenizer

        self._setup(model_config)

        vllm_config = VLLMConfig(max_model_len=max_model_len, **vllm_kwargs)
        self.engine = VLLM(model_path=model_path, config=vllm_config)
        self.tokenizer = AutoTokenizer.from_pretrained(model_path)
        self.sampling_params = SamplingParams(
            temperature=model_config.temperature,
            max_tokens=model_config.max_tokens,
        )

        # Measure template overhead once at startup so per-document budget is known.
        bare_template = self._apply_chat_template("")
        self._template_token_cost = len(self.tokenizer.encode(bare_template))
        self._doc_token_budget = max_model_len - self._template_token_cost
        logger.info(
            f"[tokenizer] Template cost: {self._template_token_cost} tokens | "
            f"Document budget: {self._doc_token_budget} tokens "
            f"(max {_MAX_INPUT_TOKENS}, min doc {_MIN_DOC_TOKENS})"
        )
        if self._doc_token_budget < _MIN_DOC_TOKENS:
            raise ValueError(
                f"Template alone costs {self._template_token_cost} tokens, leaving only "
                f"{self._doc_token_budget} for document content (minimum {_MIN_DOC_TOKENS})."
            )

    def _setup(self, model_config: ModelConfig) -> None:
        # Persistent event loop owned by this backend — AsyncLLMEngine requires
        # a stable loop context across calls.
        self._loop = asyncio.new_event_loop()
        self._loop_thread = threading.Thread(target=self._loop.run_forever, daemon=True)
        self._loop_thread.start()
        self.system_prompt = model_config.prompt_template
        self._max_concurrent_requests = model_config.max_concurrent_requests

    def _apply_chat_template(self, content: str) -> str:
        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": content},
        ]
        return self.tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            # TODO: Discuss - do we need to enable espec on small models.
            enable_thinking=False,
        )

    def _prepare_prompt(self, doc_id: str, content: str) -> str:
        """Apply chat template, truncating document content if it exceeds the token budget."""
        content_tokens = self.tokenizer.encode(content)
        if len(content_tokens) >= self._doc_token_budget:
            logger.warning(
                f"[tokenizer] {doc_id}: content is {len(content_tokens)} tokens, "
                f"truncating to {self._doc_token_budget}"
            )
            content = self.tokenizer.decode(
                content_tokens[: self._doc_token_budget], skip_special_tokens=True
            )
        return self._apply_chat_template(content)

    async def _log_stats(self) -> None:
        await self.engine.log_stats()

    async def _generate_completion(self, content: str, doc_id: str) -> str:
        async for output in self.engine.generate(
            prompt=content, sampling_params=self.sampling_params, request_id=doc_id
        ):
            if output.finished:
                return output.outputs[0].text
        raise RuntimeError(f"Generation did not finish for {doc_id}")

    def generate(
        self, docs: Iterable[tuple[str, str]]
    ) -> Iterator[tuple[str, str] | tuple[str, Exception]]:
        """Main async loop where documents are dispatched and collected.

        Internally uses a semaphore to constrain the number of documents that can be dispatched at
        once.
        This in turn puts results onto a queue which is periodically drained by a storage adapter
        to ensure continuous transmission of results.
        """
        q: queue.Queue[tuple[str, str] | tuple[str, Exception] | None] = queue.Queue()

        async def _produce() -> None:
            sem = asyncio.Semaphore(self._max_concurrent_requests)

            stat_counter: int = 0

            async def handle_one(doc_id: str, content: str) -> None:
                nonlocal stat_counter
                async with sem:
                    logger.debug(f"[engine] Dispatch → {doc_id}")

                    prepared_content = self._prepare_prompt(doc_id, content)
                    try:
                        text = await self._generate_completion(prepared_content, doc_id)
                        logger.debug(f"[engine]  Collect ← {doc_id}")
                        q.put((doc_id, text))
                    except (BadRequestError, APITimeoutError) as request_error:
                        # Pass error down the stack so runner.py can handle
                        logger.error(f"[engine]    Error ← {doc_id}")
                        q.put((doc_id, request_error))

                    stat_counter += 1

                    if stat_counter % 10 == 0:
                        await self._log_stats()

            doc_iter = iter(docs)
            tasks = []
            try:
                while True:
                    item = await asyncio.to_thread(next, doc_iter, _STREAM_SENTINEL)
                    if item is _STREAM_SENTINEL:
                        break
                    doc_id, content = item  # ty: ignore[not-iterable]
                    tasks.append(asyncio.create_task(handle_one(doc_id, content)))
                await asyncio.gather(*tasks)
            finally:
                q.put(None)

        future = asyncio.run_coroutine_threadsafe(_produce(), self._loop)

        while True:
            item = q.get()
            if item is None:
                break
            yield item

        # Surface any exception that occurred inside _produce()
        future.result()


_OUTPUT_TAG_PATTERN = re.compile(r"<output>(.*?)</output>", re.DOTALL | re.IGNORECASE)


class RemoteVLLMBackend(VLLMBackend):
    def __init__(
        self,
        openai_endpoint: str,
        model_config: ModelConfig,
        enable_extended_timeouts: bool = False,
    ):
        self._setup(model_config)
        client_kwargs: dict[str, Any] = {
            "base_url": openai_endpoint,
            "api_key": "blank",
        }
        if enable_extended_timeouts:
            client_kwargs["timeout"] = httpx.Timeout(
                connect=30.0, read=1800.0, write=120.0, pool=120.0
            )
            client_kwargs["max_retries"] = 5
        self.__client: AsyncOpenAI = AsyncOpenAI(**client_kwargs)
        self.__model_name: str = model_config.model_name
        self.__max_tokens: int = model_config.max_tokens
        self.__temperature: float = model_config.temperature

    async def _log_stats(self) -> None:
        pass

    def _prepare_prompt(self, doc_id: str, content: str) -> str:
        return content

    async def _generate_completion(self, content: str, doc_id: str) -> str:
        try:
            response = await self.__client.chat.completions.create(
                model=self.__model_name,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": content},
                ],
                temperature=self.__temperature,
                max_tokens=self.__max_tokens,
            )
        except APITimeoutError as client_request_error:
            logger.error(
                f"Failed to infer on document {doc_id}\n"
                "  Request timed out.\n"
                "    hint: consider reducing `max_concurrent_requests`"
            )
            raise client_request_error
        except BadRequestError as bad_request_error:
            """
            Handle cases where document length is so long that vLLM can produce a reasonable a
            given output.

            Documents that raise this error are generally unusually long.
            """
            logger.error(
                f"Failed to infer on document {doc_id}\n"
                "  vLLM could not produce an output of reasonable length given a long input\n"
                "    hint: consider truncation of input document\n"
                "    hint: consider setting vLLM to use a larger `max_seq_len`"
            )
            raise bad_request_error

        result = response.choices[0].message.content
        if result is None:
            raise RuntimeError(f"Remote backend returned None content for document {doc_id}")
        return result


def parse_output(raw: str, output_model: type[T]) -> T:
    """Extract JSON from <output> tags and validate against a pydantic model."""
    match = _OUTPUT_TAG_PATTERN.search(raw)
    if not match:
        # Attempt to parse the entire raw output if no tags found
        # Sometimes model fails to include tags but still returns valid JSON
        return output_model.model_validate(raw)
    json_str = match.group(1).strip()
    return output_model.model_validate_json(json_str)
