from typing import Literal

from pydantic import BaseModel


class SnowflakeConnectionParameters(BaseModel):
    """
    Minimum config required for python
    """

    account: str
    user: str
    # authenticator: str | None
    password: str | None
    role: str
    warehouse: str
    database: str
    sf_schema: str = "PUBLIC"


class SnowflakeStorageConfig(BaseModel):
    type: Literal["snowflake"]

    # Source configuration
    source_database: str
    source_schema: str
    source_table: str

    # Sink configuration
    sink_database: str
    sink_schema: str
    sink_table: str

    # Auth specific type
    connection_params: SnowflakeConnectionParameters
    write_buffer_size: int = 50

    @property
    def source_table_fqn(self) -> str:
        """Full Qualified Source table name"""
        return f'"{self.source_database}"."{self.source_schema}"."{self.source_table}"'

    @property
    def sink_table_fqn(self) -> str:
        """Full Qualified Sink table name"""
        return f'"{self.sink_database}"."{self.sink_schema}"."{self.sink_table}"'
