import logging
import re
from enum import StrEnum


class LogPattern(StrEnum):
    REDACTED = "[redacted]"
    OPENAI_REQUEST_OPTIONS = "Request options: %s"
    OPENAI_HTTP_RESPONSE = 'HTTP Response: %s %s "%i %s" %s'
    HTTPCORE_RESPONSE_HEADERS_PREFIX = "receive_response_headers.complete "


class DataRedactingFilter(logging.Filter):
    """Strips communicated data from openai and httpcore debug logs.

    Redacts request bodies and response headers while preserving
    diagnostic structure (method, URL, status, operation names).
    """

    def __format_httpcore_suffix(self, msg: str) -> str:
        http_version: str | None = None
        status: str | None = None
        http11_match: re.Match[str] | None = re.search(
            r"return_value=\(b'(HTTP/[\d.]+)',\s*(\d+),", msg
        )
        if http11_match:
            http_version = http11_match.group(1)
            status = http11_match.group(2)
        else:
            http2_match: re.Match[str] | None = re.search(r"return_value=\((\d+),", msg)
            if http2_match:
                http_version = "HTTP/2"
                status = http2_match.group(1)
        return (
            f" {suffix}"
            if (
                suffix := " ".join(
                    filter(
                        None,
                        [
                            http_version and f"http_version={http_version}",
                            status and f"status={status}",
                        ],
                    )
                )
            )
            else ""
        )

    def filter(self, record: logging.LogRecord) -> bool:
        """Redact data-bearing fields in matching log records.

        Args:
            record (logging.LogRecord): the log record to inspect.

        Returns:
            bool: always True; records are retained but may be mutated.

        """
        if not isinstance(record.msg, str):
            return True

        # openai library request body
        if record.msg == LogPattern.OPENAI_REQUEST_OPTIONS:
            record.args = (LogPattern.REDACTED,)
        # openai library response headers
        elif record.msg == LogPattern.OPENAI_HTTP_RESPONSE and isinstance(record.args, tuple):
            record.args = (*record.args[:4], LogPattern.REDACTED)
        # httpcore library response headers (HTTP/1.1 and HTTP/2)
        elif record.msg.startswith(LogPattern.HTTPCORE_RESPONSE_HEADERS_PREFIX):
            record.msg = (
                LogPattern.HTTPCORE_RESPONSE_HEADERS_PREFIX
                + LogPattern.REDACTED
                + self.__format_httpcore_suffix(record.msg)
            )

        return True
