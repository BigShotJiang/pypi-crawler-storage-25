"""Data model tests."""
