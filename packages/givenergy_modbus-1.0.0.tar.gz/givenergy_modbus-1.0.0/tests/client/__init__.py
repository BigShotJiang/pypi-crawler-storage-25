"""Coordinator tests."""
