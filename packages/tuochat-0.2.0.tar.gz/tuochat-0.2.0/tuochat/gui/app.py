"""Minimal Tkinter chat window built on the existing CLI/session flow."""

from __future__ import annotations

import io
import os
import queue
import re
import threading
import tkinter as tk
from dataclasses import dataclass, field
from functools import partial
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk
from tkinter.scrolledtext import ScrolledText
from typing import Any, Literal

from tuochat.cli.io import NullTextIO, prompt_handler, redirect_standard_io
from tuochat.cli.models import ReplState
from tuochat.cli.rendering import humanize_report_key, print_context, print_masked_conversation_transcript
from tuochat.cli.repl import (
    delete_path,
    maybe_prune_expired_conversations,
    nuke_targets,
    print_expiration_warning,
    print_help,
    print_help_menu,
    print_help_section,
    print_session_intro,
    process_repl_submission,
    resolve_help_topic,
    week_start_iso,
)
from tuochat.cli.session import (
    approve_writes_enabled,
    build_provider,
    build_store,
    no_write_enabled,
    open_path,
    print_chat_summary,
    print_saved_conversation_files,
    reset_repl_state,
    switch_to_conversation,
    sync_conversation_artifacts,
    toggle_approve_writes,
    toggle_no_write,
    toggle_write_here_mode,
    update_saved_conversation_artifacts,
    write_here_mode_enabled,
)
from tuochat.cli.setup import get_valid_classifications, maybe_run_first_run_setup, prompt_classification
from tuochat.config import TuochatConfig
from tuochat.constants import MODEL_LABELS, classification_definition, classification_help_label
from tuochat.context.attachments import (
    clear_pending_attachments,
    list_include_candidates_under,
    prepare_include,
    queue_attachment,
    read_include_file,
)
from tuochat.context.composer import (
    ATTACHED_CODE_PROMPT,
    compose_system_prompt,
    load_custom_instruction_sections,
    strip_agents_instructions_prefix,
    system_prompt_includes_agents_instructions,
)
from tuochat.discovery.custom_instructions import describe_custom_instruction_path, list_available_custom_instructions
from tuochat.discovery.skills import describe_skill_path, list_available_skills, render_skill_message
from tuochat.discovery.templates import (
    describe_template_path,
    list_available_templates,
    render_template_prompt_from_path,
)
from tuochat.estimation import estimate_token_cost, format_cost, format_quantity
from tuochat.models import Conversation, ConversationSearchResult, Message
from tuochat.persistence.archive import conversation_archive_dir
from tuochat.provider.duo import DuoProvider
from tuochat.sandbox.api import code_interpreter_runtime_details

export_filename_pattern = re.compile(r"[^A-Za-z0-9._ -]+")


@dataclass
class PromptRequest:
    """A prompt request marshalled back to the Tk main thread."""

    prompt: str
    secret: bool = False
    ready: threading.Event = field(default_factory=threading.Event)
    response: str = ""


class DialogCancelledError(Exception):
    """Raised when the user cancels a blocking GUI dialog."""


class TranscriptStream(io.TextIOBase):
    """Text stream that forwards writes to the GUI transcript queue."""

    def __init__(self, output_queue: queue.Queue[str]) -> None:
        self.output_queue = output_queue

    def write(self, text: str) -> int:
        if text:
            self.output_queue.put(text)
        return len(text)

    def writable(self) -> bool:
        return True


class MultiTextIO(io.TextIOBase):
    """Text stream that broadcasts writes to multiple text streams."""

    def __init__(self, *streams: io.TextIOBase) -> None:
        self.streams = streams

    def write(self, text: str) -> int:
        for stream in self.streams:
            stream.write(text)
        return len(text)

    def flush(self) -> None:
        for stream in self.streams:
            flush = getattr(stream, "flush", None)
            if callable(flush):
                flush()

    def writable(self) -> bool:
        return True


def conversation_menu_label(conv: Conversation, *, current_id: str | None = None) -> str:
    """Return a compact label for a recent conversation menu item."""
    title = (conv.title or "Untitled")[:40]
    updated = conv.updated_at[:19] if conv.updated_at else ""
    current_marker = "* " if current_id and conv.id == current_id else ""
    return f"{current_marker}{conv.id[:8]}  {title}  {updated}".rstrip()


def default_export_filename(conv: Conversation) -> str:
    """Return a safe default markdown filename for a conversation export."""
    base_name = (conv.title or conv.id[:8] or "conversation").strip()
    cleaned = export_filename_pattern.sub("-", base_name).strip(" .-_")
    if not cleaned:
        cleaned = "conversation"
    return f"{cleaned}.md"


def render_conversation_markdown(conv: Conversation, messages: list[Message] | None = None) -> str:
    """Render a conversation to markdown using in-memory state."""
    rendered_messages = messages if messages is not None else list(conv.messages)
    lines = [f"# {conv.title or 'Untitled Conversation'}", ""]
    if conv.system_prompt:
        lines.extend([f"**System prompt:** {conv.system_prompt}", ""])
    lines.append(f"*Started: {conv.created_at}*")
    lines.append("")

    for msg in rendered_messages:
        role_label = msg.role.capitalize()
        lines.append(f"## {role_label}")
        lines.append("")
        lines.append(msg.content)
        lines.append("")

    return "\n".join(lines)


def confirm_nuke(
    *,
    ask_yes_no,
    ask_text,
) -> bool:
    """Return whether the caller confirmed the destructive nuke action."""
    confirmed = ask_yes_no(
        "Confirm nuke",
        "Delete centralized app data and close tuochat?\n\nThis keeps the config folder and current workspace.",
    )
    if not confirmed:
        return False
    typed = ask_text("Confirm nuke", "Type `nuke` to confirm data deletion:")
    return typed is not None and typed.strip().lower() == "nuke"


def is_classification_prompt(prompt: str) -> bool:
    """Return whether a prompt is the CLI classification picker."""
    return prompt.strip().lower().startswith("classify")


def classification_dialog_text(
    cfg: TuochatConfig,
    *,
    current: str | None = None,
    upcoming: bool = False,
) -> str:
    """Build the GUI classification chooser body text."""
    options = get_valid_classifications(cfg)
    label = "the upcoming conversation" if upcoming else "this conversation"
    lines = [
        f"Document classification for {label}.",
        "Enter a number or the classification name.",
        "",
    ]
    for index, option in enumerate(options, start=1):
        marker = " * current" if option == current else ""
        lines.append(f"[{index}] {classification_help_label(option)}{marker}")
    return "\n".join(lines)


def format_token_usage(input_tokens: int, output_tokens: int) -> str:
    """Render the current session token totals in a compact human-friendly form."""
    total_tokens = input_tokens + output_tokens
    return f"Token usage: in {input_tokens:,} | out {output_tokens:,} | total {total_tokens:,}"


def format_info_line(
    *,
    input_tokens: int,
    output_tokens: int,
    active_model: str,
    working_directory: Path,
    classification: str | None,
    elapsed_seconds: float | None,
    sandbox_runtime_summary: str | None = None,
) -> str:
    """Render the compact first-row session summary."""
    definition = classification_definition(classification)
    classification_label = definition.full_name if definition is not None else (classification or "(none)")
    parts: list[str] = []
    if elapsed_seconds is not None:
        parts.append(f"Elapsed: {elapsed_seconds:.2f}s")
    parts.extend(
        [
            format_token_usage(input_tokens, output_tokens),
            f"Model: {MODEL_LABELS.get(active_model, active_model)}",
            f"Cwd: {working_directory}",
            f"Classification: {classification_label}",
        ]
    )
    if sandbox_runtime_summary:
        parts.append(f"Sandbox: {sandbox_runtime_summary}")
    return " | ".join(parts)


def format_writing_directory_line(writing_directory: str) -> str:
    """Render the dedicated second-row writing-directory label."""
    return f"Writing dir: {writing_directory}"


def format_sandbox_runtime_summary(runtime_details: dict[str, object]) -> str:
    """Render a compact sandbox-runtime summary for the GUI info bar."""
    mini_racer_v8 = "yes" if runtime_details.get("mini_racer_v8") else "no"
    lupa = "yes" if runtime_details.get("lupa") else "no"
    return f"mini-racer/V8 {mini_racer_v8} | lupa {lupa}"


def response_warning_text(cfg: TuochatConfig) -> str:
    """Return the compact response warning text when enabled."""
    if not cfg.chat.response_footer_warning_enabled:
        return ""
    return cfg.chat.response_footer_warning_text.strip()


def next_model_toggle_label(active_model: str) -> str:
    """Return the button label for toggling between Duo and Eliza."""
    return "Use Eliza" if active_model == "duo" else "Use Duo"


def attachment_speedbar_labels() -> tuple[str, ...]:
    """Return the compact attachment-control labels for the main speedbar."""
    return ("Attach", "Files", "Skills", "Initial Instr", "Template", "Changed", "Detach All", "AGENTS.md")


def window_title_text(title: str | None) -> str:
    """Return the application window title for the active conversation."""
    cleaned = (title or "").strip()
    return f"Tuochat: {cleaned}" if cleaned else "Tuochat"


def render_attached_files_text(state: ReplState) -> str:
    """Render the Files tab from the current attachment-related session state."""
    names = state.pending_attachment_names or []
    lines: list[str] = []
    lines.append(f"AGENTS.md instructions: {'included' if state.include_agents_file else 'excluded'}")
    if state.pending_custom_name:
        lines.append(f"Pending custom instructions for next new conversation: {state.pending_custom_name}")
    lines.append("")
    if names:
        lines.append(f"Attached files ({len(names)}):")
        for index, name in enumerate(names, start=1):
            lines.append(f"[{index}] {name}")
    else:
        lines.append("No attached files are currently queued.")

    if state.last_include_path is not None:
        lines.extend(
            [
                "",
                f"Last include: {state.last_include_path}",
                f"Last include size: {(state.last_include_size or 0):,} bytes",
            ]
        )
    return "\n".join(lines)


def attached_files_dialog_text(paths: list[Path]) -> str:
    """Build the post-selection attachment summary text."""
    lines = [
        "Attached these files for the next request.",
        "",
    ]
    for index, path in enumerate(paths, start=1):
        lines.append(f"[{index}] {path}")
    return "\n".join(lines)


def is_attached_code_prompt(prompt: str) -> bool:
    """Return whether a prompt should use the template code-file picker."""
    normalized = prompt.strip().rstrip(":>").strip().casefold()
    expected = ATTACHED_CODE_PROMPT.strip().rstrip(":>").strip().casefold()
    return normalized == expected


def prompt_for_template_code_path(parent: tk.Misc | None, *, initialdir: Path | None = None) -> str:
    """Open a file picker for the ATTACHED_CODE template token."""
    selected = filedialog.askopenfilename(
        parent=parent,
        title="Select code file for template",
        initialdir=str(initialdir or Path.cwd()),
    )
    if not selected:
        return ""
    return str(Path(selected).expanduser())


def render_context_text(state: ReplState) -> str:
    """Render the current conversation context snapshot for the Context tab."""
    buffer = io.StringIO()
    with redirect_standard_io(stdout=buffer, stderr=buffer):  # type: ignore[arg-type]
        print_context(state)
    rendered = buffer.getvalue().strip()

    if state.server_context:
        server_lines = ["Server context items:"]
        for index, item in enumerate(state.server_context, start=1):
            server_lines.append(f"[{index}] {item['category']} - {item['name']}")
        rendered = f"{rendered}\n\n" + "\n".join(server_lines) if rendered else "\n".join(server_lines)

    return rendered or "Context is empty."


def render_conversations_text(
    conversations: list[Conversation],
    *,
    current_id: str | None = None,
    unavailable: bool = False,
) -> str:
    """Render the Conversations tab from recent saved conversations."""
    if unavailable:
        return "Saved conversations are unavailable while no-write mode is enabled."
    if not conversations:
        return "No saved conversations yet."

    lines = ["Recent conversations (read-only for now):"]
    for index, conv in enumerate(conversations, start=1):
        lines.append(f"[{index}] {conversation_menu_label(conv, current_id=current_id)}")
    return "\n".join(lines)


def render_search_results_text(
    search_results: list[ConversationSearchResult] | None,
    *,
    query: str | None = None,
) -> str:
    """Render the Search tab from the latest conversation search results."""
    if not search_results:
        if query:
            return f"No saved conversations matched {query!r}."
        return "No search results yet. Run /search to populate this tab."

    lines = [f"Search results for {query!r}:" if query else "Search results:"]
    for index, match in enumerate(search_results, start=1):
        title = (match.title or "Untitled")[:40]
        updated = match.updated_at[:19] if match.updated_at else ""
        role = match.role[:9]
        snippet = re.sub(r"\s+", " ", (match.snippet or "").strip()) or "(no snippet)"
        lines.append(f"[{index}] {match.conversation_id[:8]}  {title}  {updated}  {role}")
        lines.append(f"    {snippet}")
    return "\n".join(lines)


def render_help_text(command_text: str, *, blind_mode: bool = False) -> str:
    """Render /help output into a text block for the Help tab."""
    stripped = command_text.strip() or "/help"
    command, _, argument = stripped.partition(" ")
    normalized_command = command.lower()
    normalized_argument = argument.strip()
    buffer = io.StringIO()

    with redirect_standard_io(stdout=buffer, stderr=buffer):  # type: ignore[arg-type]
        if normalized_command == "/help-menu":
            print_help_menu()
        elif normalized_command == "/help":
            topic = resolve_help_topic(normalized_argument)
            if topic == "menu":
                print_help_menu()
            elif topic is not None:
                print_help_section(topic)
            elif normalized_argument:
                print("Usage: /help [menu|session|files|history|output|safety|exit]")
            elif blind_mode:
                print_help_menu()
            else:
                print_help()
        else:
            print_help()

    return buffer.getvalue().strip() or "Help is unavailable."


def render_weekly_usage_text(store: Any) -> str:
    """Render the weekly usage summary for the Usage tab."""
    week_start = week_start_iso()
    totals = store.get_weekly_usage(week_start)
    input_tok = totals["input_tokens"]
    output_tok = totals["output_tokens"]
    total_tok = totals["total_tokens"]
    turns = totals["turns"]
    input_cost, output_cost, total_cost = estimate_token_cost(input_tok, output_tok)
    approx_words = int(total_tok / 1.3)
    approx_chars = total_tok * 4
    approx_kb = approx_chars / 1024
    rows = [
        ("turns", format_quantity(turns)),
        ("input_tokens", format_quantity(input_tok)),
        ("output_tokens", format_quantity(output_tok)),
        ("total_tokens", format_quantity(total_tok)),
        ("approximate_words", format_quantity(approx_words)),
        ("approximate_characters", format_quantity(approx_chars)),
        ("approximate_kilobytes", format_quantity(approx_kb, decimals=1)),
        ("input_cost", format_cost(input_cost)),
        ("output_cost", format_cost(output_cost)),
        ("total_cost", format_cost(total_cost)),
    ]
    lines = [f"Weekly usage (since {week_start[:10]}, resets Sunday):"]
    lines.extend(f"{humanize_report_key(key)}: {value}" for key, value in rows)
    return "\n".join(lines)


def submit_shortcut_sequences() -> tuple[str, ...]:
    """Return key bindings that submit the current draft."""
    return ("<Alt-s>", "<Alt-S>", "<Control-z>", "<Control-Z>")


class ToolTip:
    """Very small hover tooltip for compact Tk controls."""

    def __init__(self, widget: tk.Widget, text: str) -> None:
        self.widget = widget
        self.text = text
        self.tip_window: tk.Toplevel | None = None
        widget.bind("<Enter>", self.show_tip, add="+")
        widget.bind("<Leave>", self.hide_tip, add="+")
        widget.bind("<ButtonPress>", self.hide_tip, add="+")

    def show_tip(self, _event=None) -> None:
        if self.tip_window is not None or not self.text:
            return
        x = self.widget.winfo_rootx() + 18
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 6
        tip_window = tk.Toplevel(self.widget)
        tip_window.wm_overrideredirect(True)
        tip_window.wm_geometry(f"+{x}+{y}")
        label = tk.Label(
            tip_window,
            text=self.text,
            justify="left",
            relief="solid",
            borderwidth=1,
            background="#ffffe0",
            padx=6,
            pady=3,
        )
        label.pack()
        self.tip_window = tip_window

    def hide_tip(self, _event=None) -> None:
        if self.tip_window is None:
            return
        self.tip_window.destroy()
        self.tip_window = None


class ClassificationDialog(simpledialog.Dialog):
    """Modal classification chooser that mirrors the CLI options list."""

    def __init__(
        self,
        parent: tk.Misc,
        cfg: TuochatConfig,
        *,
        current: str | None = None,
        upcoming: bool = False,
    ) -> None:
        self.cfg = cfg
        self.current = current
        self.upcoming = upcoming
        self.response = ""
        self.options = get_valid_classifications(cfg)
        self.entry: tk.Entry | None = None
        self.result: str | None = None
        super().__init__(parent, title="Choose classification")

    def body(self, master: tk.Misc):
        instructions = tk.Label(
            master,
            justify="left",
            anchor="w",
            text=classification_dialog_text(self.cfg, current=self.current, upcoming=self.upcoming),
        )
        instructions.pack(fill="x", padx=10, pady=(10, 6))

        self.entry = tk.Entry(master, width=48)
        self.entry.pack(fill="x", padx=10, pady=(0, 10))
        return self.entry

    def buttonbox(self) -> None:
        box = tk.Frame(self)
        confirm_button = tk.Button(box, text="OK", width=10, command=self.ok, default="active")
        confirm_button.pack(side="left", padx=5, pady=5)
        cancel_button = tk.Button(box, text="Cancel", width=10, command=self.cancel)
        cancel_button.pack(side="left", padx=5, pady=5)
        self.bind("<Return>", self.ok)
        self.bind("<Escape>", self.cancel)
        box.pack()

    def apply(self) -> None:
        if self.entry is None:
            raise TypeError("self.entry is None and can't be.")
        self.response = self.entry.get().strip()
        self.result = self.response


class AttachmentSummaryDialog(simpledialog.Dialog):
    """Modal summary of the files queued by the GUI file picker."""

    def __init__(self, parent: tk.Misc, body_text: str) -> None:
        self.body_text = body_text
        super().__init__(parent, title="Attached files")

    def body(self, master: tk.Misc):
        instructions = tk.Label(master, justify="left", anchor="w", text=self.body_text)
        instructions.pack(fill="x", padx=10, pady=(10, 10))
        return instructions

    def buttonbox(self) -> None:
        box = tk.Frame(self)
        confirm_button = tk.Button(box, text="OK", width=10, command=self.ok, default="active")
        confirm_button.pack(side="left", padx=5, pady=5)
        self.bind("<Return>", self.ok)
        self.bind("<Escape>", self.cancel)
        box.pack()


class TkChatApp:
    """Small queue-backed Tkinter shell for the existing REPL logic."""

    def __init__(self, state: ReplState, store: Any) -> None:
        self.state = state
        self.store = store
        self.output_queue: queue.Queue[str] = queue.Queue()
        self.prompt_queue: queue.Queue[PromptRequest] = queue.Queue()
        self.event_queue: queue.Queue[tuple[str, bool]] = queue.Queue()
        self.stream = TranscriptStream(self.output_queue)
        self.busy = False
        self.close_when_idle = False
        self.finalized = False
        self.last_search_query: str | None = None
        self.last_help_command: str = "/help"
        self.custom_menu_paths: list[Path] = []
        self.skill_menu_paths: list[Path] = []
        self.template_menu_paths: list[Path] = []

        self.root = tk.Tk()
        self.root.title(window_title_text(self.state.conv.title))
        self.root.geometry("900x700")
        self.root.minsize(640, 480)
        self.root.protocol("WM_DELETE_WINDOW", self.request_quit)

        self.model_var = tk.StringVar(master=self.root, value=self.state.active_model)
        self.build_menu_bar()
        self.build_tabbed_views()

        self.info_var = tk.StringVar(master=self.root)
        self.warning_var = tk.StringVar(master=self.root)
        self.writing_directory_var = tk.StringVar(master=self.root)
        self.model_toggle_var = tk.StringVar(master=self.root)
        self.build_info_panel()

        controls = tk.Frame(self.root)
        controls.pack(fill="x", padx=8, pady=4)

        self.send_button = tk.Button(controls, text="Send", underline=0, command=self.submit_current_text)
        self.send_button.pack(side="left")
        self.primary_separator = ttk.Separator(controls, orient="vertical")
        self.primary_separator.pack(side="left", fill="y", padx=8, pady=2)

        self.approve_writes_var = tk.BooleanVar(master=self.root, value=approve_writes_enabled(self.state.cfg))
        self.write_here_var = tk.BooleanVar(master=self.root, value=write_here_mode_enabled(self.state.cfg))
        self.streaming_var = tk.BooleanVar(master=self.root, value=self.state.streaming)
        self.mask_output_var = tk.BooleanVar(master=self.root, value=self.state.mask_output)
        self.verbose_var = tk.BooleanVar(master=self.root, value=self.state.verbose)
        self.no_write_var = tk.BooleanVar(master=self.root, value=no_write_enabled(self.state.cfg))
        self.include_agents_var = tk.BooleanVar(master=self.root, value=self.state.include_agents_file)
        (
            attach_group_label,
            attach_files_text,
            attach_skills_text,
            attach_initial_instr_text,
            attach_template_text,
            attach_changed_text,
            detach_all_text,
            include_all_text,
        ) = attachment_speedbar_labels()

        self.attach_group_label = tk.Label(controls, text=attach_group_label)
        self.attach_group_label.pack(side="left")
        self.attach_files_button = tk.Button(controls, text=attach_files_text, command=self.attach_files_from_dialog)
        self.attach_files_button.pack(side="left", padx=(4, 0))
        self.attach_skill_button = tk.Menubutton(controls, text=attach_skills_text, relief="raised")
        self.attach_skill_menu = tk.Menu(
            self.attach_skill_button, tearoff=False, postcommand=self.refresh_attach_skill_menu
        )
        self.attach_skill_button.configure(menu=self.attach_skill_menu)
        self.attach_skill_button.pack(side="left", padx=(4, 0))
        self.attach_custom_button = tk.Menubutton(controls, text=attach_initial_instr_text, relief="raised")
        self.attach_custom_menu = tk.Menu(
            self.attach_custom_button,
            tearoff=False,
            postcommand=self.refresh_attach_custom_menu,
        )
        self.attach_custom_button.configure(menu=self.attach_custom_menu)
        self.attach_custom_button.pack(side="left", padx=(4, 0))
        self.attach_template_button = tk.Menubutton(controls, text=attach_template_text, relief="raised")
        self.attach_template_menu = tk.Menu(
            self.attach_template_button,
            tearoff=False,
            postcommand=self.refresh_attach_template_menu,
        )
        self.attach_template_button.configure(menu=self.attach_template_menu)
        self.attach_template_button.pack(side="left", padx=(4, 0))
        self.reinclude_changed_button = tk.Button(
            controls, text=attach_changed_text, command=self.reinclude_changed_file
        )
        self.reinclude_changed_button.pack(side="left", padx=(4, 0))
        self.attach_group_separator = ttk.Separator(controls, orient="vertical")
        self.attach_group_separator.pack(side="left", fill="y", padx=8, pady=2)
        self.detach_all_button = tk.Button(controls, text=detach_all_text, command=self.detach_all_attachments)
        self.detach_all_button.pack(side="left")
        self.include_agents_button = tk.Checkbutton(
            controls,
            text=include_all_text,
            indicatoron=False,
            variable=self.include_agents_var,
            command=self.toggle_agents_file_button,
        )
        self.include_agents_button.pack(side="left", padx=(4, 0))
        self.file_actions_separator = ttk.Separator(controls, orient="vertical")
        self.file_actions_separator.pack(side="left", fill="y", padx=8, pady=2)
        self.clear_button = tk.Button(controls, text="Clear", command=self.confirm_and_start_new_conversation)
        self.clear_button.pack(side="left")
        self.secondary_separator = ttk.Separator(controls, orient="vertical")
        self.secondary_separator.pack(side="left", fill="y", padx=8, pady=2)

        self.streaming_button = tk.Checkbutton(
            controls,
            text="Stream",
            indicatoron=False,
            variable=self.streaming_var,
            command=self.toggle_streaming_button,
        )
        self.streaming_button.pack(side="left", padx=(0, 0))
        self.mask_button = tk.Checkbutton(
            controls,
            text="Mask",
            indicatoron=False,
            variable=self.mask_output_var,
            command=self.toggle_mask_button,
        )
        self.mask_button.pack(side="left", padx=(4, 0))
        self.verbose_button = tk.Checkbutton(
            controls,
            text="Verbose",
            indicatoron=False,
            variable=self.verbose_var,
            command=self.toggle_verbose_button,
        )
        self.verbose_button.pack(side="left", padx=(4, 0))
        self.write_group_separator = ttk.Separator(controls, orient="vertical")
        self.write_group_separator.pack(side="left", fill="y", padx=8, pady=2)
        self.approve_writes_button = tk.Checkbutton(
            controls,
            text="Approve writes",
            indicatoron=False,
            variable=self.approve_writes_var,
            command=self.toggle_approve_writes_button,
        )
        self.approve_writes_button.pack(side="left", padx=(0, 0))
        self.write_here_button = tk.Checkbutton(
            controls,
            text="Write here",
            indicatoron=False,
            variable=self.write_here_var,
            command=self.toggle_write_here_button,
        )
        self.write_here_button.pack(side="left", padx=(4, 0))
        self.no_write_button = tk.Checkbutton(
            controls,
            text="Plan/No Writes",
            indicatoron=False,
            variable=self.no_write_var,
            command=self.toggle_no_write_button,
        )
        self.no_write_button.pack(side="left", padx=(4, 0))
        self.model_group_separator = ttk.Separator(controls, orient="vertical")
        self.model_group_separator.pack(side="left", fill="y", padx=8, pady=2)
        self.model_toggle_button = tk.Button(
            controls,
            textvariable=self.model_toggle_var,
            command=self.toggle_active_model_button,
        )
        self.model_toggle_button.pack(side="left", padx=(0, 4))
        self.action_buttons_separator = ttk.Separator(controls, orient="vertical")
        self.action_buttons_separator.pack(side="left", fill="y", padx=8, pady=2)
        self.help_button = tk.Button(controls, text="Help", underline=0, command=self.show_help_tab)
        self.help_button.pack(side="left")
        self.status_button = tk.Button(
            controls,
            text="Status",
            underline=1,
            command=lambda: self.submit_command("/status"),
        )
        self.status_button.pack(side="left", padx=(4, 0))
        self.config_button = tk.Button(controls, text="Config", command=lambda: self.submit_command("/config"))
        self.config_button.pack(side="left", padx=(4, 0))
        self.doctor_button = tk.Button(controls, text="Doctor", command=lambda: self.submit_command("/doctor"))
        self.doctor_button.pack(side="left", padx=(4, 0))
        self.capabilities_button = tk.Button(
            controls,
            text="Capabilities",
            command=lambda: self.submit_command("/capabilities"),
        )
        self.capabilities_button.pack(side="left", padx=(4, 0))
        self.env_button = tk.Button(controls, text="Env", command=lambda: self.submit_command("/env"))
        self.env_button.pack(side="left", padx=(4, 0))
        self.quit_button = tk.Button(controls, text="Quit", underline=0, command=self.request_quit)
        self.quit_button.pack(side="right")

        self.input_box = tk.Text(self.root, height=8, wrap="word", undo=True)
        self.input_box.pack(fill="x", padx=8, pady=(0, 8))
        self.input_box.focus_set()

        for sequence in submit_shortcut_sequences():
            self.root.bind_all(sequence, self.submit_current_text)
        self.root.bind_all("<Alt-h>", lambda _event: self.show_help_tab())
        self.root.bind_all("<Alt-H>", lambda _event: self.show_help_tab())
        self.root.bind_all("<Alt-t>", lambda _event: self.submit_command("/status"))
        self.root.bind_all("<Alt-T>", lambda _event: self.submit_command("/status"))
        self.root.bind_all("<Alt-q>", self.request_quit)
        self.root.bind_all("<Alt-Q>", self.request_quit)
        self.install_tooltips()
        self.refresh_info_panel()

    def build_tabbed_views(self) -> None:
        """Create the notebook and text views for chat and supporting tabs."""
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=8, pady=(8, 4))

        self.chat_tab = ttk.Frame(self.notebook)
        self.files_tab = ttk.Frame(self.notebook)
        self.context_tab = ttk.Frame(self.notebook)
        self.conversations_tab = ttk.Frame(self.notebook)
        self.search_tab = ttk.Frame(self.notebook)
        self.help_tab = ttk.Frame(self.notebook)
        self.usage_tab = ttk.Frame(self.notebook)

        self.notebook.add(self.chat_tab, text="Chat")
        self.notebook.add(self.files_tab, text="Files")
        self.notebook.add(self.context_tab, text="Context")
        self.notebook.add(self.conversations_tab, text="Conversations")
        self.notebook.add(self.search_tab, text="Search")
        self.notebook.add(self.help_tab, text="Help")
        self.notebook.add(self.usage_tab, text="Usage")

        self.transcript = self.build_tab_text_box(self.chat_tab, state="disabled")
        self.files_view = self.build_tab_text_box(self.files_tab)
        self.context_view = self.build_tab_text_box(self.context_tab)
        self.conversations_view = self.build_tab_text_box(self.conversations_tab)
        self.search_view = self.build_tab_text_box(self.search_tab)
        self.help_view = self.build_tab_text_box(self.help_tab)
        self.usage_view = self.build_tab_text_box(self.usage_tab)

    def build_tab_text_box(self, parent: tk.Misc, *, state: Literal["normal", "disabled"] = "disabled") -> ScrolledText:
        """Create a read-only scrolled text view for a notebook tab."""
        text_box = ScrolledText(parent, wrap="word")
        text_box.pack(fill="both", expand=True)
        text_box.configure(state=state)
        return text_box

    def build_menu_bar(self) -> None:
        """Create the application menu bar."""
        self.menu_bar = tk.Menu(self.root)

        self.file_menu = tk.Menu(self.menu_bar, tearoff=False)
        self.file_menu.add_command(label="Export conversation...", command=self.export_conversation)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Open conversation folder", command=self.open_conversation_folder)
        self.file_menu.add_command(label="Open config folder", command=self.open_config_folder)
        self.file_menu.add_command(label="Open cwd folder", command=self.open_cwd_folder)
        self.file_menu.add_command(label="Select new working directory (cwd)...", command=self.select_working_directory)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Nuke...", command=self.request_nuke)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Exit", command=self.request_quit)
        self.menu_bar.add_cascade(label="File", menu=self.file_menu)

        self.resume_menu = tk.Menu(self.menu_bar, tearoff=False, postcommand=self.refresh_resume_menu)
        self.menu_bar.add_cascade(label="Resume", menu=self.resume_menu)

        self.conversation_menu = tk.Menu(self.menu_bar, tearoff=False)
        self.conversation_menu.add_command(label="Clear/New", command=self.start_new_conversation)
        self.conversation_menu.add_command(label="Classify...", command=self.choose_classification)
        self.menu_bar.add_cascade(label="Conversation", menu=self.conversation_menu)

        self.model_menu = tk.Menu(self.menu_bar, tearoff=False)
        for model_key, model_label in MODEL_LABELS.items():
            self.model_menu.add_radiobutton(
                label=model_label,
                value=model_key,
                variable=self.model_var,
                command=partial(self.set_active_model, model_key),
            )
        self.menu_bar.add_cascade(label="Model", menu=self.model_menu)

        self.skill_menu = tk.Menu(self.menu_bar, tearoff=False, postcommand=self.refresh_skill_menu)
        self.menu_bar.add_cascade(label="Skill", menu=self.skill_menu)

        self.menu_bar.add_command(label="Search", state="disabled")
        self.menu_bar.add_command(label="Tutorial", state="disabled")
        self.menu_bar.add_command(label="Configure", state="disabled")

        self.root.config(menu=self.menu_bar)

    def run(self) -> int:
        self.root.after(30, self.process_gui_queues)
        self.run_startup_messages()
        try:
            self.root.mainloop()
        except KeyboardInterrupt:
            self.handle_keyboard_interrupt()
        return 0

    def build_info_panel(self) -> None:
        """Render a compact session info strip under the transcript."""
        info_panel = tk.Frame(self.root, bd=1, relief="groove")
        info_panel.pack(fill="x", padx=8, pady=(0, 4))
        self.info_label = tk.Label(info_panel, anchor="w", textvariable=self.info_var)
        self.info_label.pack(fill="x", padx=8, pady=(6, 0))
        self.warning_label = tk.Label(info_panel, anchor="w", textvariable=self.warning_var)
        self.writing_directory_label = tk.Label(info_panel, anchor="w", textvariable=self.writing_directory_var)

    def install_tooltips(self) -> None:
        """Attach compact hover help to the main controls."""
        ToolTip(self.send_button, "Send the current draft.")
        ToolTip(self.help_button, "Show slash-command help.")
        ToolTip(self.status_button, "Show current session status.")
        ToolTip(self.config_button, "Show the active configuration.")
        ToolTip(self.doctor_button, "Run local config and path checks.")
        ToolTip(self.capabilities_button, "Probe local and remote capabilities.")
        ToolTip(self.env_button, "Show relevant environment settings.")
        ToolTip(self.attach_files_button, "Pick one or more files, or fall back to a folder, for the next request.")
        ToolTip(self.attach_skill_button, "Attach a discovered skill to the next request.")
        ToolTip(self.attach_custom_button, "Pick custom instructions to apply at the top of the next new conversation.")
        ToolTip(self.attach_template_button, "Attach a rendered template prompt to the next request.")
        ToolTip(self.detach_all_button, "Remove every pending attachment from the next request.")
        ToolTip(self.include_agents_button, "Toggle whether the current cwd AGENTS.md instructions are included.")
        ToolTip(self.reinclude_changed_button, "Re-attach the last included file if it changed on disk.")
        ToolTip(self.clear_button, "Start a new conversation after confirmation.")
        ToolTip(self.approve_writes_button, "Ask before write-here mode writes a named file into the cwd.")
        ToolTip(self.write_here_button, "Write named generated files into the current working directory.")
        ToolTip(self.streaming_button, "Toggle streaming responses for this session.")
        ToolTip(self.mask_button, "Toggle on-screen masking for this session.")
        ToolTip(self.verbose_button, "Toggle verbose context reporting for future turns.")
        ToolTip(self.no_write_button, "Disable local database, filesystem, and file-log writes for this session.")
        ToolTip(self.model_toggle_button, "Switch between Duo and Eliza.")
        ToolTip(self.quit_button, "Close tuochat after showing the final summary.")

    def run_startup_messages(self) -> None:
        with redirect_standard_io(stdout=self.stream, stderr=self.stream), prompt_handler(self.prompt_user):  # type: ignore[arg-type]
            print_expiration_warning(self.state.cfg)
            maybe_prune_expired_conversations(self.store, self.state.cfg)
            print_session_intro(self.state)
            classification_cfg = getattr(self.state.cfg, "classification", None)
            if getattr(classification_cfg, "enabled", False) and getattr(
                classification_cfg,
                "ask_per_conversation",
                True,
            ):
                chosen = prompt_classification(self.state.cfg, upcoming=True)
                if chosen:
                    self.state.active_classification = chosen
                    print(f"Classification: {classification_help_label(chosen)}")
        self.drain_output_queue()
        self.refresh_info_panel()

    def append_transcript(self, text: str) -> None:
        self.transcript.configure(state="normal")
        self.transcript.insert("end", text)
        self.transcript.see("end")
        self.transcript.configure(state="disabled")

    def clear_transcript(self) -> None:
        self.transcript.configure(state="normal")
        self.transcript.delete("1.0", "end")
        self.transcript.configure(state="disabled")

    def append_user_message(self, text: str) -> None:
        self.append_transcript(f"you>\n{text}\n\n")

    def set_busy(self, busy: bool) -> None:
        self.busy = busy
        button_state: Literal["normal", "disabled"] = "disabled" if busy else "normal"
        self.send_button.configure(state=button_state)
        self.help_button.configure(state=button_state)
        self.status_button.configure(state=button_state)
        self.config_button.configure(state=button_state)
        self.doctor_button.configure(state=button_state)
        self.capabilities_button.configure(state=button_state)
        self.env_button.configure(state=button_state)
        self.attach_files_button.configure(state=button_state)
        self.attach_skill_button.configure(state=button_state)
        self.attach_custom_button.configure(state=button_state)
        self.attach_template_button.configure(state=button_state)
        self.detach_all_button.configure(state=button_state)
        self.include_agents_button.configure(state=button_state)
        self.reinclude_changed_button.configure(state=button_state)
        self.clear_button.configure(state=button_state)
        self.approve_writes_button.configure(state=button_state)
        self.write_here_button.configure(state=button_state)
        self.streaming_button.configure(state=button_state)
        self.mask_button.configure(state=button_state)
        self.verbose_button.configure(state=button_state)
        self.no_write_button.configure(state=button_state)
        self.model_toggle_button.configure(state=button_state)
        self.input_box.configure(state=button_state)
        if not busy:
            self.input_box.focus_set()

    def refresh_info_panel(self) -> None:
        """Refresh the compact session summary shown in the info strip."""
        sandbox_runtime_summary = format_sandbox_runtime_summary(code_interpreter_runtime_details())
        self.info_var.set(
            format_info_line(
                input_tokens=self.state.session_input_tokens,
                output_tokens=self.state.session_output_tokens,
                active_model=self.state.active_model,
                working_directory=Path.cwd(),
                classification=self.state.active_classification,
                elapsed_seconds=self.state.last_turn_elapsed_seconds,
                sandbox_runtime_summary=sandbox_runtime_summary,
            )
        )
        warning_text = response_warning_text(self.state.cfg)
        self.warning_var.set(warning_text)
        self.writing_directory_var.set(format_writing_directory_line(self.current_writing_directory()))
        self.warning_label.pack_forget()
        self.writing_directory_label.pack_forget()
        if warning_text:
            self.warning_label.pack(fill="x", padx=8, pady=(0, 0))
        self.writing_directory_label.pack(fill="x", padx=8, pady=(0, 6))
        self.refresh_toggle_controls()
        self.model_toggle_var.set(next_model_toggle_label(self.state.active_model))
        self.refresh_window_title()
        self.refresh_tab_views()

    def refresh_window_title(self) -> None:
        """Sync the window title with the active conversation title."""
        self.root.title(window_title_text(self.state.conv.title))

    def replace_text_view_contents(self, text_view: ScrolledText, text: str) -> None:
        """Replace a read-only text view with new rendered content."""
        text_view.configure(state="normal")
        text_view.delete("1.0", "end")
        text_view.insert("1.0", text)
        text_view.configure(state="disabled")

    def refresh_tab_views(self) -> None:
        """Refresh the non-chat notebook tabs from the latest session state."""
        self.replace_text_view_contents(self.files_view, render_attached_files_text(self.state))
        self.replace_text_view_contents(self.context_view, render_context_text(self.state))
        conversations: list[Conversation] = []
        conversations_unavailable = no_write_enabled(self.state.cfg)
        if not conversations_unavailable:
            conversations = self.store.list_conversations(limit=50)
        self.replace_text_view_contents(
            self.conversations_view,
            render_conversations_text(
                conversations,
                current_id=self.state.conv.id,
                unavailable=conversations_unavailable,
            ),
        )
        self.replace_text_view_contents(
            self.search_view,
            render_search_results_text(self.state.search_candidates, query=self.last_search_query),
        )
        self.replace_text_view_contents(
            self.help_view,
            render_help_text(self.last_help_command, blind_mode=self.state.blind_mode),
        )
        self.replace_text_view_contents(self.usage_view, render_weekly_usage_text(self.store))

    def refresh_toggle_controls(self) -> None:
        """Sync the toggle button states from the current session state."""
        self.approve_writes_var.set(approve_writes_enabled(self.state.cfg))
        self.write_here_var.set(write_here_mode_enabled(self.state.cfg))
        self.streaming_var.set(self.state.streaming)
        self.mask_output_var.set(self.state.mask_output)
        self.verbose_var.set(self.state.verbose)
        self.no_write_var.set(no_write_enabled(self.state.cfg))
        self.include_agents_var.set(self.state.include_agents_file)

    def path_within_cwd(self, path: Path) -> bool:
        """Return whether a selected file-system path stays inside the current cwd."""
        try:
            path.resolve().relative_to(Path.cwd().resolve())
        except ValueError:
            return False
        return True

    def current_writing_directory(self) -> str:
        """Return the current effective write target shown in the info bar."""
        if no_write_enabled(self.state.cfg):
            return "(disabled)"
        if write_here_mode_enabled(self.state.cfg):
            return str(Path.cwd())
        if self.state.last_saved_markdown_path is not None:
            return str(self.state.last_saved_markdown_path.parent)
        return str(conversation_archive_dir(self.state.cfg, self.state.conv, create=False))

    def refresh_skill_menu(self) -> None:
        """Populate the Skill menu from the currently available skill files."""
        self.skill_menu.delete(0, "end")
        self.skill_menu_paths = list_available_skills(self.state.cfg)
        if not self.skill_menu_paths:
            self.skill_menu.add_command(label="No skills found", state="disabled")
            return
        for path in self.skill_menu_paths:
            self.skill_menu.add_command(
                label=describe_skill_path(path, self.state.cfg),
                command=partial(self.attach_skill_to_conversation, path),
            )

    def refresh_attach_skill_menu(self) -> None:
        """Populate the speed-bar skill attachment dropdown."""
        self.attach_skill_menu.delete(0, "end")
        self.skill_menu_paths = list_available_skills(self.state.cfg)
        if not self.skill_menu_paths:
            self.attach_skill_menu.add_command(label="No skills found", state="disabled")
            return
        for path in self.skill_menu_paths:
            self.attach_skill_menu.add_command(
                label=describe_skill_path(path, self.state.cfg),
                command=partial(self.attach_skill_for_next_request, path),
            )

    def refresh_attach_custom_menu(self) -> None:
        """Populate the custom-instructions dropdown for the next new conversation."""
        self.attach_custom_menu.delete(0, "end")
        self.custom_menu_paths = list_available_custom_instructions(self.state.cfg)
        if self.state.pending_custom_path is not None:
            self.attach_custom_menu.add_command(
                label="Clear pending custom instructions", command=self.clear_pending_custom_instruction
            )
            self.attach_custom_menu.add_separator()
        if not self.custom_menu_paths:
            self.attach_custom_menu.add_command(label="No custom instructions found", state="disabled")
            return
        for path in self.custom_menu_paths:
            self.attach_custom_menu.add_command(
                label=describe_custom_instruction_path(path, self.state.cfg),
                command=partial(self.attach_custom_instruction_for_next_conversation, path),
            )

    def refresh_attach_template_menu(self) -> None:
        """Populate the speed-bar template attachment dropdown."""
        self.attach_template_menu.delete(0, "end")
        self.template_menu_paths = list_available_templates(self.state.cfg)
        if not self.template_menu_paths:
            self.attach_template_menu.add_command(label="No templates found", state="disabled")
            return
        for path in self.template_menu_paths:
            self.attach_template_menu.add_command(
                label=describe_template_path(path, self.state.cfg),
                command=partial(self.attach_template_for_next_request, path),
            )

    def queue_virtual_attachment(self, *, label: str, payload: str, attachment_kind: str) -> None:
        """Queue a generated skill or template payload for the next request."""
        queue_attachment(self.state, Path(f"[{attachment_kind}] {label}"), payload)
        self.append_transcript(f"Attached {attachment_kind} for next request: {label}\n")
        self.notebook.select(self.files_tab)
        self.refresh_info_panel()

    def clear_pending_custom_instruction(self) -> None:
        """Clear the custom instructions queued for the next new conversation."""
        if not self.require_idle("clearing custom instructions"):
            return
        self.state.pending_custom_path = None
        self.state.pending_custom_name = None
        self.append_transcript("Cleared pending custom instructions.\n")
        self.notebook.select(self.files_tab)
        self.refresh_info_panel()

    def attach_custom_instruction_for_next_conversation(self, custom_path: Path) -> None:
        """Queue custom instructions for the next new conversation."""
        if not self.require_idle("selecting custom instructions"):
            return
        try:
            read_include_file(custom_path)
        except UnicodeDecodeError:
            messagebox.showerror(
                "tuochat", f"Custom instruction file is not valid UTF-8 text: {custom_path}", parent=self.root
            )
            return
        self.state.pending_custom_path = custom_path
        self.state.pending_custom_name = describe_custom_instruction_path(custom_path, self.state.cfg)
        self.append_transcript(
            "Selected custom instructions for the next new conversation: "
            f"{self.state.pending_custom_name}\n"
            "Start a new conversation to apply them at the top of the system prompt.\n"
        )
        self.notebook.select(self.files_tab)
        self.refresh_info_panel()

    def attach_skill_for_next_request(self, skill_path: Path) -> None:
        """Queue a discovered skill as an attachment for the next request."""
        if not self.require_idle("attaching a skill"):
            return
        try:
            label, payload = render_skill_message(skill_path, self.state.cfg)
        except UnicodeDecodeError:
            messagebox.showerror("tuochat", f"Skill file is not valid UTF-8 text: {skill_path}", parent=self.root)
            return
        except ValueError as exc:
            messagebox.showerror("tuochat", str(exc), parent=self.root)
            return
        self.queue_virtual_attachment(label=label, payload=payload, attachment_kind="skill")

    def prompt_for_template_attachment_value(self, prompt_or_variable: str) -> str:
        """Prompt for a template variable value while attaching a template."""
        if prompt_or_variable == ATTACHED_CODE_PROMPT:
            selected_path = prompt_for_template_code_path(self.root, initialdir=Path.cwd())
            if not selected_path:
                raise DialogCancelledError()
            return selected_path
        prompt = (
            prompt_or_variable if prompt_or_variable.endswith(": ") else f"{humanize_report_key(prompt_or_variable)}: "
        )
        response = simpledialog.askstring("Attach template", prompt.rstrip(), parent=self.root)
        if response is None:
            raise DialogCancelledError()
        return response

    def attach_template_for_next_request(self, template_path: Path) -> None:
        """Queue a rendered template prompt as an attachment for the next request."""
        if not self.require_idle("attaching a template"):
            return
        try:
            label, rendered_prompt, _metadata = render_template_prompt_from_path(
                template_path,
                self.state.cfg,
                prompt_for_value=self.prompt_for_template_attachment_value,
                cwd=Path.cwd(),
            )
        except DialogCancelledError:
            self.append_transcript("Template attachment cancelled.\n")
            return
        except ValueError as exc:
            messagebox.showerror("tuochat", str(exc), parent=self.root)
            return
        payload = f"Rendered template: {label}\n```text\n{rendered_prompt}\n```"
        self.queue_virtual_attachment(label=label, payload=payload, attachment_kind="template")

    def attach_skill_to_conversation(self, skill_path: Path) -> None:
        """Load a skill file into the current conversation without a chat turn."""
        if not self.require_idle("loading a skill"):
            return
        try:
            label, payload = render_skill_message(skill_path, self.state.cfg)
        except UnicodeDecodeError:
            messagebox.showerror("tuochat", f"Skill file is not valid UTF-8 text: {skill_path}", parent=self.root)
            return
        except ValueError as exc:
            messagebox.showerror("tuochat", str(exc), parent=self.root)
            return
        message = self.state.conv.add_message("user", payload)
        self.store.save_conversation(self.state.conv)
        self.store.save_message(message)
        self.append_transcript(f"Loaded skill into the current conversation: {label}\n")
        self.notebook.select(self.context_tab)
        self.refresh_info_panel()

    def toggle_verbose_button(self) -> None:
        """Toggle verbose context reporting for future turns."""
        if not self.require_idle("changing verbose mode"):
            self.refresh_toggle_controls()
            return
        self.state.verbose = self.verbose_var.get()
        self.refresh_info_panel()

    def selected_attachable_paths(self) -> list[Path]:
        """Return GUI-selected files, or a folder-expanded file list, from the cwd."""
        selected_files = [
            Path(raw).expanduser()
            for raw in filedialog.askopenfilenames(
                parent=self.root,
                title="Attach files for the next request",
                initialdir=str(Path.cwd()),
            )
        ]
        if selected_files:
            return selected_files

        selected_folder = filedialog.askdirectory(
            parent=self.root,
            title="Or select a folder to attach recursively",
            initialdir=str(Path.cwd()),
            mustexist=True,
        )
        if not selected_folder:
            return []
        folder_path = Path(selected_folder).expanduser()
        if not folder_path.is_dir():
            return []
        return list_include_candidates_under(folder_path)

    def attach_paths(self, paths: list[Path]) -> list[Path]:
        """Queue selected files for the next request and return the queued subset."""
        queued_paths: list[Path] = []
        for path in paths:
            if not self.path_within_cwd(path):
                self.append_transcript(f"Skipped path outside cwd: {path}\n")
                continue
            message = prepare_include(path, self.state)
            if message is None:
                continue
            queue_attachment(self.state, path, message)
            queued_paths.append(path)
            self.append_transcript(f"Attached for next request: {path}\n")
        return queued_paths

    def attach_files_from_dialog(self) -> None:
        """Pick files or a folder from Tk dialogs and queue them as attachments."""
        if not self.require_idle("attaching files"):
            return
        paths = self.selected_attachable_paths()
        if not paths:
            return
        queued_paths = self.attach_paths(paths)
        self.notebook.select(self.files_tab)
        self.refresh_info_panel()
        if not queued_paths:
            messagebox.showerror("tuochat", "No files could be attached.", parent=self.root)
            return
        AttachmentSummaryDialog(self.root, attached_files_dialog_text(queued_paths))

    def detach_all_attachments(self) -> None:
        """Clear every currently queued attachment from the next request."""
        if not self.require_idle("detaching files"):
            return
        pending = len(self.state.pending_attachment_names or [])
        if pending == 0:
            self.append_transcript("No pending attachments to detach.\n")
            self.notebook.select(self.files_tab)
            self.refresh_info_panel()
            return
        clear_pending_attachments(self.state)
        self.append_transcript(f"Detached {pending} pending attachment(s).\n")
        self.notebook.select(self.files_tab)
        self.refresh_info_panel()

    def toggle_agents_file_button(self) -> None:
        """Toggle whether AGENTS.md instructions are part of the current session prompt."""
        enabled = self.include_agents_var.get()
        if not self.require_idle("changing AGENTS.md inclusion"):
            self.refresh_toggle_controls()
            return
        self.state.include_agents_file = enabled
        extra_custom_paths = [self.state.pending_custom_path] if self.state.pending_custom_path is not None else []
        prompt_without_agents = strip_agents_instructions_prefix(self.state.conv.system_prompt)
        base_prompt = (
            self.state.base_system_prompt if self.state.base_system_prompt is not None else prompt_without_agents
        )
        self.state.conv.system_prompt, self.state.active_system_prompt_sources = compose_system_prompt(
            base_prompt,
            load_custom_instruction_sections(self.state.cfg, extra_paths=extra_custom_paths),
            include_agents=enabled,
        )
        self.append_transcript(f"AGENTS.md instructions {'included' if enabled else 'excluded'} for this session.\n")
        self.notebook.select(self.files_tab)
        self.refresh_info_panel()

    def reinclude_changed_file(self) -> None:
        """Re-attach the last included file when it changed on disk."""
        if not self.require_idle("re-including a changed file"):
            return
        if self.state.last_include_path is None:
            self.append_transcript("No previous include to reuse.\n")
            self.notebook.select(self.files_tab)
            self.refresh_info_panel()
            return
        try:
            text, fingerprint, size = read_include_file(self.state.last_include_path)
        except UnicodeDecodeError:
            self.append_transcript(f"Include file is not valid UTF-8 text: {self.state.last_include_path}\n")
            self.notebook.select(self.files_tab)
            self.refresh_info_panel()
            return
        except ValueError as exc:
            self.append_transcript(f"{exc}\n")
            self.notebook.select(self.files_tab)
            self.refresh_info_panel()
            return
        if fingerprint == self.state.last_include_hash:
            self.append_transcript("Last included file is unchanged; not re-including it.\n")
            self.notebook.select(self.files_tab)
            self.refresh_info_panel()
            return
        self.state.last_include_hash = fingerprint
        self.state.last_include_size = size
        self.state.last_include_message = f"Included file: {self.state.last_include_path}\n```text\n{text}\n```"
        queue_attachment(self.state, self.state.last_include_path, self.state.last_include_message)
        self.append_transcript(f"Re-attached changed file for next request: {self.state.last_include_path}\n")
        self.notebook.select(self.files_tab)
        self.refresh_info_panel()

    def show_help_tab(self, command_text: str = "/help"):
        """Render help into the Help tab instead of the chat transcript."""
        if self.busy:
            return "break"
        self.last_help_command = command_text.strip() or "/help"
        self.refresh_tab_views()
        self.notebook.select(self.help_tab)
        return "break"

    def show_usage_tab(self):
        """Render weekly usage into the Usage tab instead of the chat transcript."""
        if self.busy:
            return "break"
        self.refresh_tab_views()
        self.notebook.select(self.usage_tab)
        return "break"

    def confirm_and_start_new_conversation(self) -> None:
        """Ask for confirmation before clearing to a new conversation from the button row."""
        if not self.require_idle("clearing the conversation"):
            return
        confirmed = messagebox.askyesno(
            "Clear conversation",
            "Start a new conversation and clear the current transcript?",
            parent=self.root,
        )
        if not confirmed:
            return
        self.start_new_conversation()

    def present_main_window(self, *, maximize: bool = False) -> None:
        """Bring the main window to the foreground and optionally maximize it."""
        self.root.deiconify()
        if maximize:
            try:
                self.root.state("zoomed")
            except tk.TclError:
                pass
        self.root.lift()
        try:
            self.root.attributes("-topmost", True)
            self.root.after(200, partial(self.root.attributes, "-topmost", False))
        except tk.TclError:
            pass
        try:
            self.root.focus_force()
        except tk.TclError:
            pass

    def prompt_for_classification(self) -> str:
        """Show the GUI classification chooser and return the raw selection."""
        dialog = ClassificationDialog(
            self.root,
            self.state.cfg,
            current=self.state.active_classification,
            upcoming=not self.state.conv.messages and self.state.session_turns == 0,
        )
        return dialog.response

    def show_text_modal(self, *, title: str, body: str, button_text: str) -> None:
        """Display a blocking modal text dialog with a custom dismiss button."""
        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.transient(self.root)
        dialog.resizable(True, True)
        dialog.geometry("760x420")

        body_text = ScrolledText(dialog, wrap="word", height=18)
        body_text.pack(fill="both", expand=True, padx=12, pady=(12, 8))
        body_text.insert("1.0", body.strip())
        body_text.configure(state="disabled")

        dismiss_button = tk.Button(dialog, text=button_text, command=dialog.destroy)
        dismiss_button.pack(pady=(0, 12))

        dialog.protocol("WM_DELETE_WINDOW", dialog.destroy)
        dialog.bind("<Escape>", lambda event: dialog.destroy())
        self.present_main_window()
        dialog.lift()
        try:
            dialog.attributes("-topmost", True)
            dialog.after(200, lambda: dialog.attributes("-topmost", False))
        except tk.TclError:
            pass
        dialog.grab_set()
        dismiss_button.focus_set()
        self.root.wait_window(dialog)

    def require_idle(self, action_name: str) -> bool:
        """Return whether a menu action can proceed immediately."""
        if not self.busy:
            return True
        messagebox.showinfo("tuochat", f"Finish the current response before {action_name}.", parent=self.root)
        return False

    def apply_session_toggle(self, action_name: str, apply_change) -> None:
        """Run a session toggle through the shared CLI helper path."""
        if not self.require_idle(action_name):
            self.refresh_toggle_controls()
            return
        with redirect_standard_io(stdout=self.stream, stderr=self.stream), prompt_handler(self.prompt_user):  # type: ignore[arg-type]
            apply_change()
        self.drain_output_queue()
        self.refresh_info_panel()

    def toggle_approve_writes_button(self) -> None:
        enabled = self.approve_writes_var.get()
        self.apply_session_toggle(
            "changing approve-writes",
            lambda: toggle_approve_writes(self.state, enabled),
        )

    def toggle_write_here_button(self) -> None:
        enabled = self.write_here_var.get()
        self.apply_session_toggle(
            "changing write-here mode",
            lambda: toggle_write_here_mode(self.state, enabled),
        )

    def toggle_streaming_button(self) -> None:
        enabled = self.streaming_var.get()
        if not self.require_idle("changing streaming"):
            self.refresh_toggle_controls()
            return
        self.state.streaming = enabled
        self.append_transcript(f"Streaming {'enabled' if enabled else 'disabled'} for this session.\n")
        self.refresh_info_panel()

    def toggle_mask_button(self) -> None:
        enabled = self.mask_output_var.get()
        if not self.require_idle("changing masking"):
            self.refresh_toggle_controls()
            return
        self.state.mask_output = enabled
        self.append_transcript(f"On-screen masking {'enabled' if enabled else 'disabled'} for this session.\n")
        self.refresh_info_panel()

    def toggle_no_write_button(self) -> None:
        enabled = self.no_write_var.get()
        self.apply_session_toggle(
            "changing no-write mode",
            lambda: toggle_no_write(self.state, enabled),
        )

    def toggle_active_model_button(self) -> None:
        target = "eliza" if self.state.active_model == "duo" else "duo"
        self.set_active_model(target)

    def submit_current_text(self, _event=None):
        if self.busy:
            return "break"
        raw_input = self.input_box.get("1.0", "end-1c")
        if not raw_input.strip():
            return "break"
        self.input_box.delete("1.0", "end")
        self.start_submission(raw_input)
        return "break"

    def submit_command(self, command: str):
        if self.busy:
            return "break"
        self.start_submission(command)
        return "break"

    def start_submission(self, raw_input: str) -> None:
        stripped = raw_input.strip()
        if stripped.startswith("/"):
            command = stripped.split(maxsplit=1)[0].lower()
            if command in {"/help", "/help-menu"}:
                self.show_help_tab(stripped)
                return
            if command == "/usage":
                self.show_usage_tab()
                return
        self.route_submission_tab(raw_input)
        self.append_user_message(raw_input)
        self.set_busy(True)
        worker = threading.Thread(target=self.process_submission, args=(raw_input,), daemon=True)
        worker.start()

    def route_submission_tab(self, raw_input: str) -> None:
        """Switch to the most relevant tab for the current submission."""
        stripped = raw_input.strip()
        if not stripped.startswith("/"):
            self.notebook.select(self.chat_tab)
            return

        command, _, argument = stripped.partition(" ")
        if command in {"/help", "/help-menu"}:
            self.last_help_command = stripped
            self.notebook.select(self.help_tab)
            return
        if command == "/usage":
            self.notebook.select(self.usage_tab)
            return
        if command == "/search":
            self.last_search_query = argument.strip() or self.last_search_query
            self.notebook.select(self.search_tab)
            return
        if command == "/context":
            self.notebook.select(self.context_tab)
            return
        if command in {"/include", "/include-last", "/detach"}:
            self.notebook.select(self.files_tab)
            return
        self.notebook.select(self.chat_tab)

    def process_submission(self, raw_input: str) -> None:
        should_exit = False
        try:
            with redirect_standard_io(stdout=self.stream, stderr=self.stream), prompt_handler(self.prompt_user):  # type: ignore[arg-type]
                should_exit = process_repl_submission(raw_input=raw_input, state=self.state)
        finally:
            self.event_queue.put(("submission_complete", should_exit))

    def prompt_user(self, prompt: str, *, secret: bool = False) -> str:
        if threading.current_thread() is threading.main_thread():
            response: str | None
            if is_classification_prompt(prompt):
                response = self.prompt_for_classification()
                if response:
                    self.present_main_window(maximize=True)
            elif is_attached_code_prompt(prompt):
                response = prompt_for_template_code_path(self.root)
            else:
                response = simpledialog.askstring(
                    "tuochat",
                    prompt.rstrip(":> "),
                    parent=self.root,
                    show="*" if secret else None,
                )
            return response or ""

        request = PromptRequest(prompt=prompt, secret=secret)
        self.prompt_queue.put(request)
        request.ready.wait()
        return request.response

    def process_gui_queues(self) -> None:
        self.drain_output_queue()
        self.drain_prompt_queue()
        self.drain_event_queue()
        if self.root.winfo_exists():
            self.root.after(30, self.process_gui_queues)

    def drain_output_queue(self) -> None:
        while True:
            try:
                text = self.output_queue.get_nowait()
            except queue.Empty:
                return
            self.append_transcript(text)

    def drain_prompt_queue(self) -> None:
        while True:
            try:
                request = self.prompt_queue.get_nowait()
            except queue.Empty:
                return
            if is_classification_prompt(request.prompt):
                request.response = self.prompt_for_classification() or ""
                if request.response:
                    self.present_main_window(maximize=True)
            elif is_attached_code_prompt(request.prompt):
                request.response = prompt_for_template_code_path(self.root)
            else:
                request.response = (
                    simpledialog.askstring(
                        "tuochat",
                        request.prompt.rstrip(":> "),
                        parent=self.root,
                        show="*" if request.secret else None,
                    )
                    or ""
                )
            request.ready.set()

    def drain_event_queue(self) -> None:
        while True:
            try:
                event_name, should_exit = self.event_queue.get_nowait()
            except queue.Empty:
                return
            if event_name != "submission_complete":
                continue
            self.set_busy(False)
            self.model_var.set(self.state.active_model)
            self.refresh_info_panel()
            if should_exit or self.close_when_idle:
                self.finalize_and_close()

    def refresh_resume_menu(self) -> None:
        """Refresh the Resume menu from recent saved conversations."""
        self.resume_menu.delete(0, "end")
        if no_write_enabled(self.state.cfg):
            self.resume_menu.add_command(label="Unavailable in no-write mode", state="disabled")
            return
        conversations = self.store.list_conversations(limit=20)
        if not conversations:
            self.resume_menu.add_command(label="No saved conversations", state="disabled")
            return
        for conv in conversations:
            self.resume_menu.add_command(
                label=conversation_menu_label(conv, current_id=self.state.conv.id),
                command=partial(self.resume_conversation, conv.id),
            )

    def resume_conversation(self, conversation_id: str) -> None:
        """Load a saved conversation into the GUI session."""
        if not self.require_idle("resuming another conversation"):
            return
        target = self.store.get_conversation(conversation_id)
        if target is None:
            messagebox.showerror("tuochat", f"Conversation {conversation_id} not found.", parent=self.root)
            return
        if isinstance(self.state.provider, DuoProvider):
            self.state.provider.reset_conversation()
        switch_to_conversation(self.state, target)
        self.state.include_agents_file = system_prompt_includes_agents_instructions(self.state.conv.system_prompt)
        self.clear_transcript()
        with redirect_standard_io(stdout=self.stream, stderr=self.stream), prompt_handler(self.prompt_user):  # type: ignore[arg-type]
            print_session_intro(self.state)
            print_masked_conversation_transcript(self.state)
            if self.state.resumed_context_pending:
                print()
                print("[Resumed conversation — prior context will be replayed to the LLM on your next message.]")
                print()
        self.drain_output_queue()
        self.refresh_info_panel()
        self.notebook.select(self.chat_tab)

    def set_active_model(self, selected: str) -> None:
        """Set the active model from the menu radio group."""
        if selected == self.state.active_model:
            return
        if not self.require_idle("changing models"):
            self.model_var.set(self.state.active_model)
            return
        self.state.active_model = selected
        self.model_var.set(selected)
        self.append_transcript(f"Active model: {MODEL_LABELS[selected]}\n")
        self.refresh_info_panel()

    def start_new_conversation(self) -> None:
        """Clear the transcript and begin a new conversation."""
        if not self.require_idle("starting a new conversation"):
            return
        silent_stream = NullTextIO()
        with redirect_standard_io(stdout=silent_stream, stderr=silent_stream), prompt_handler(self.prompt_user):  # type: ignore[arg-type]
            reset_repl_state(self.state)
        self.clear_transcript()
        self.append_transcript(f"Started new conversation: {self.state.conv.id[:8]}\n")
        self.append_transcript("System prompt sources:\n")
        for source in self.state.active_system_prompt_sources or ["(none)"]:
            self.append_transcript(f"  - {source}\n")
        if self.state.active_classification:
            self.append_transcript(f"Classification: {classification_help_label(self.state.active_classification)}\n")
        self.append_transcript("\n")
        self.drain_output_queue()
        self.refresh_info_panel()
        self.notebook.select(self.chat_tab)

    def choose_classification(self) -> None:
        """Prompt for a new classification for the current conversation."""
        if not self.require_idle("changing the classification"):
            return
        with redirect_standard_io(stdout=self.stream, stderr=self.stream), prompt_handler(self.prompt_user):  # type: ignore[arg-type]
            chosen = prompt_classification(self.state.cfg, current=self.state.active_classification)
            if chosen is None:
                print("Classification unchanged.")
            else:
                self.state.active_classification = chosen
                print(f"Classification set to: {classification_help_label(chosen)}")
        self.drain_output_queue()
        if self.state.active_classification == chosen and chosen is not None:
            self.present_main_window(maximize=True)
        self.refresh_info_panel()

    def export_conversation(self) -> None:
        """Export the current conversation to a chosen markdown file."""
        if not self.require_idle("exporting the conversation"):
            return
        target_path = filedialog.asksaveasfilename(
            parent=self.root,
            title="Export conversation",
            defaultextension=".md",
            filetypes=[("Markdown files", "*.md"), ("Text files", "*.txt"), ("All files", "*.*")],
            initialdir=str(Path.cwd()),
            initialfile=default_export_filename(self.state.conv),
        )
        if not target_path:
            return
        path = Path(target_path)
        path.write_text(render_conversation_markdown(self.state.conv), encoding="utf-8")
        self.append_transcript(f"Exported conversation markdown to {path}\n")

    def conversation_folder_path(self) -> Path:
        """Return the best available folder for the current conversation."""
        if self.state.last_saved_markdown_path is not None:
            return self.state.last_saved_markdown_path.parent
        if self.state.conv.messages and not no_write_enabled(self.state.cfg):
            conv_dir, md_path, extracted = sync_conversation_artifacts(
                self.state.cfg,
                self.state.conv,
                classification=self.state.active_classification,
            )
            if md_path is not None:
                update_saved_conversation_artifacts(self.state, md_path, extracted)
            if conv_dir is not None:
                return conv_dir
        return self.state.cfg.data_dir

    def open_conversation_folder(self) -> None:
        """Open the current conversation archive folder."""
        if not self.require_idle("opening the conversation folder"):
            return
        target = self.conversation_folder_path()
        opened, message = open_path(target)
        self.append_transcript(f"{message}\n")
        if not opened:
            messagebox.showerror("tuochat", message, parent=self.root)

    def open_config_folder(self) -> None:
        """Open the current config folder."""
        if not self.require_idle("opening the config folder"):
            return
        target = self.state.cfg.config_dir
        opened, message = open_path(target)
        self.append_transcript(f"{message}\n")
        if not opened:
            messagebox.showerror("tuochat", message, parent=self.root)

    def open_cwd_folder(self) -> None:
        """Open the current working directory."""
        if not self.require_idle("opening the current working directory"):
            return
        target = Path.cwd()
        opened, message = open_path(target)
        self.append_transcript(f"{message}\n")
        if not opened:
            messagebox.showerror("tuochat", message, parent=self.root)

    def select_working_directory(self) -> None:
        """Prompt for a new current working directory."""
        if not self.require_idle("changing the working directory"):
            return
        chosen = filedialog.askdirectory(
            parent=self.root,
            title="Select new working directory",
            initialdir=str(Path.cwd()),
            mustexist=True,
        )
        if not chosen:
            return
        os.chdir(chosen)
        with redirect_standard_io(stdout=NullTextIO(), stderr=NullTextIO()), prompt_handler(self.prompt_user):  # type: ignore[arg-type]
            toggle_write_here_mode(self.state, True)
        self.append_transcript(f"Working directory: {Path.cwd()}\n")
        if write_here_mode_enabled(self.state.cfg):
            self.append_transcript("Write-here mode enabled for this session.\n")
        self.refresh_info_panel()

    def request_nuke(self) -> None:
        """Ask for double confirmation, then close and nuke app data."""
        if not confirm_nuke(
            ask_yes_no=lambda title, prompt: messagebox.askyesno(title, prompt, parent=self.root),
            ask_text=lambda title, prompt: simpledialog.askstring(title, prompt, parent=self.root),
        ):
            self.append_transcript("Nuke cancelled.\n")
            return
        self.state.pending_nuke = True
        if self.busy:
            self.close_when_idle = True
            self.append_transcript("\n[Nuke confirmed. Closing after the current response finishes.]\n")
            return
        self.finalize_and_close()

    def request_quit(self, _event=None):
        if self.busy:
            if not self.close_when_idle:
                self.close_when_idle = True
                self.append_transcript("\n[Closing after the current response finishes.]\n")
            return "break"
        self.finalize_and_close()
        return "break"

    def handle_keyboard_interrupt(self) -> None:
        """Close the GUI cleanly when Ctrl+C interrupts the Tk mainloop."""
        if not self.root.winfo_exists():
            return
        if self.busy and not self.close_when_idle:
            self.close_when_idle = True
            self.append_transcript("\n[Ctrl+C received. Closing after the current response finishes.]\n")
        elif not self.busy:
            self.finalize_and_close()
        while self.root.winfo_exists():
            try:
                self.root.update()
            except KeyboardInterrupt:
                continue
            except tk.TclError:
                break

    def finalize_and_close(self) -> None:
        """Close stores, optionally nuke app data, and destroy the window."""
        if self.finalized:
            return
        self.finalized = True
        summary_buffer = io.StringIO()
        summary_stream = MultiTextIO(self.stream, summary_buffer)
        with redirect_standard_io(stdout=summary_stream, stderr=summary_stream), prompt_handler(self.prompt_user):  # type: ignore[arg-type]
            if self.state.pending_nuke:
                self.store.close()
                self.execute_nuke()
            else:
                print()
                print_chat_summary(self.state.conv, self.state)
                if self.state.conv.messages:
                    print(f"Conversation saved: {self.state.conv.id}")
                    print_saved_conversation_files(self.state)
                self.store.close()
        self.drain_output_queue()
        summary_text = summary_buffer.getvalue().strip()
        if summary_text and not self.state.pending_nuke:
            self.show_text_modal(title="Session summary", body=summary_text, button_text="Dismiss")
        self.root.after(150, self.root.destroy)

    def execute_nuke(self) -> None:
        """Delete centralized app-state paths after confirmation."""
        targets = nuke_targets(self.state.cfg)
        if not targets:
            print("Nuke complete: no centralized app data was present.")
            return
        deleted = 0
        failed = 0
        for path in targets:
            if not path.exists():
                continue
            try:
                delete_path(path)
                deleted += 1
            except OSError as exc:
                print(f"Nuke failed to delete {path}: {exc}")
                failed += 1
        if failed:
            print(f"Nuke partial: deleted {deleted} path(s), failed to delete {failed} path(s).")
        else:
            print(f"Nuke complete: deleted {deleted} centralized path(s).")
        print(f"Config kept: {self.state.cfg.config_dir}")
        print(f"Workspace kept: {Path.cwd()}")


def run_gui_app(cfg: TuochatConfig, args: Any) -> int:
    """Run the minimal Tkinter GUI front end."""
    cfg = maybe_run_first_run_setup(cfg, config_path=args.config if hasattr(args, "config") else None)
    warnings = cfg.validate()

    if not cfg.gitlab.host or not cfg.gitlab.token:
        root = tk.Tk()
        root.withdraw()
        details = "\n".join(
            [
                "GitLab host and token must be configured.",
                f"Create {cfg.config_file} or set TUOCHAT_GITLAB_HOST and TUOCHAT_GITLAB_TOKEN.",
            ]
        )
        messagebox.showerror("tuochat", details, parent=root)
        root.destroy()
        return 1

    timeout_override = getattr(args, "timeout", None)
    provider = build_provider(cfg, timeout_override=timeout_override)
    store = build_store(cfg)
    base_system_prompt = args.prompt
    base_resource_id = args.resource_id or cfg.chat.default_resource_id
    system_prompt, prompt_sources = compose_system_prompt(
        base_system_prompt,
        load_custom_instruction_sections(cfg),
    )
    state = ReplState(
        conv=Conversation(resource_id=base_resource_id, system_prompt=system_prompt),
        store=store,
        provider=provider,
        cfg=cfg,
        streaming=not args.no_stream and cfg.chat.streaming,
        config_path=Path(args.config).expanduser() if getattr(args, "config", None) else None,
        timeout_override=timeout_override,
        quiet=cfg.chat.quiet,
        no_banner=cfg.chat.no_banner,
        blind_mode=cfg.chat.blind,
        debug=getattr(args, "debug", False),
        base_system_prompt=base_system_prompt,
        base_resource_id=base_resource_id,
        mask_output=cfg.chat.mask_output,
        dot_timer_enabled=cfg.chat.dot_timer,
        no_code_mode=False,
        active_model="duo",
        active_system_prompt_sources=prompt_sources,
        command_log=[],
        local_writes_enabled=not no_write_enabled(cfg),
        include_agents_file=system_prompt_includes_agents_instructions(system_prompt),
        gui_mode=True,
    )
    if isinstance(provider, DuoProvider):
        provider.reset_conversation()

    app = TkChatApp(state, store)
    if warnings:
        app.append_transcript("Warnings:\n")
        for warning in warnings:
            app.append_transcript(f"- {warning}\n")
        app.append_transcript("\n")
    return app.run()
