"""Headless non-interactive chat commands."""

from __future__ import annotations

import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from tuochat.cli.models import ReplState
from tuochat.cli.pickers import resolve_skill_path, resolve_template_path
from tuochat.cli.session import build_outbound_input, sync_conversation_artifacts, update_saved_conversation_artifacts
from tuochat.context.attachments import format_included_file, read_include_file
from tuochat.context.composer import compose_system_prompt, load_custom_instruction_sections, resolve_template_prompt
from tuochat.context.validation import validate_user_request
from tuochat.discovery.skills import list_available_skills, render_skill_message
from tuochat.discovery.templates import (
    describe_template_path,
    list_available_templates,
    parse_template_metadata,
    template_body,
)
from tuochat.estimation import estimate_tokens
from tuochat.models import Conversation, MessageStatus, Role, Usage
from tuochat.provider.eliza import ElizaProvider
from tuochat.serialization import json_dumps

if TYPE_CHECKING:
    from collections.abc import Callable

    from tuochat.cli.command_models import HeadlessAskCommand, HeadlessContinueCommand
    from tuochat.config import TuochatConfig
    from tuochat.persistence import ConversationStore, NullConversationStore
    from tuochat.provider.duo import DuoProvider


class HeadlessInteractiveActionRequired(RuntimeError):
    """Raised when headless execution would require an interactive prompt."""


@dataclass
class HeadlessExecution:
    """Structured result for headless commands."""

    conversation: Conversation
    response_text: str
    model: str
    input_tokens: int
    output_tokens: int
    markdown_path: Path | None
    extracted_paths: list[Path]


def reject_interactive_prompt(prompt: str) -> str:
    """Fail fast when a non-interactive run would need user confirmation."""
    raise HeadlessInteractiveActionRequired(prompt)


def parse_variable_args(raw_values: tuple[str, ...]) -> dict[str, str]:
    """Parse repeated NAME=value template arguments."""
    values: dict[str, str] = {}
    for item in raw_values:
        if "=" not in item:
            raise ValueError(f"Expected NAME=value for --var, got: {item}")
        name, value = item.split("=", 1)
        name = name.strip()
        if not name:
            raise ValueError(f"Expected NAME=value for --var, got: {item}")
        values[name] = value
    return values


def read_prompt_source(prompt: str | None, prompt_file: Path | None, use_stdin: bool) -> str:
    """Read prompt text from a positional arg, file, or stdin."""
    sources = int(bool(prompt)) + int(prompt_file is not None) + int(use_stdin)
    if sources > 1:
        raise ValueError("Use only one of prompt text, --file, or --stdin.")
    if prompt_file is not None:
        return prompt_file.expanduser().read_text(encoding="utf-8")
    if use_stdin:
        return sys.stdin.read()
    return prompt or ""


def resolve_include_paths(paths: tuple[Path, ...]) -> list[tuple[Path, str]]:
    """Load include files for the next request."""
    attachments: list[tuple[Path, str]] = []
    for raw_path in paths:
        path = raw_path.expanduser()
        if not path.is_absolute():
            path = Path.cwd() / path
        text, _fingerprint, _size = read_include_file(path)
        attachments.append((path, format_included_file(path, text)))
    return attachments


def resolve_skill_attachment(skill: str | None, cfg: TuochatConfig) -> tuple[Path, str] | None:
    """Resolve a skill selection to a message attachment."""
    if not skill:
        return None
    candidates = list_available_skills(cfg)
    skill_path = resolve_skill_path(skill, cfg=cfg, candidates=candidates)
    if skill_path is None or not skill_path.is_file():
        raise ValueError(f"Skill file not found: {skill}")
    _label, payload = render_skill_message(skill_path, cfg)
    return skill_path, payload


def resolve_selected_template_prompt(
    template: str | None, variables: tuple[str, ...], cfg: TuochatConfig
) -> tuple[str, dict[str, object]] | None:
    """Resolve and fill a template into prompt text and stored metadata."""
    if not template:
        return None
    candidates = list_available_templates(cfg)
    template_path = resolve_template_path(template, cfg=cfg, candidates=candidates)
    if template_path is None or not template_path.is_file():
        raise ValueError(f"Template file not found: {template}")
    body = template_body(template_path)
    if not body:
        raise ValueError(f"Template file is empty: {template_path}")
    values = parse_variable_args(variables)
    rendered_prompt, template_values = resolve_template_prompt(body, provided_values=values, cwd=Path.cwd())
    metadata: dict[str, object] = {
        "path": str(template_path),
        "label": describe_template_path(template_path, cfg),
        "name": parse_template_metadata(template_path)[0],
        **template_values,
    }
    return rendered_prompt, metadata


def prepare_prompt_text(
    prompt: str | None,
    prompt_file: Path | None,
    use_stdin: bool,
    template: str | None,
    variables: tuple[str, ...],
    cfg: TuochatConfig,
) -> tuple[str, dict[str, object] | None]:
    """Build the final prompt text and optional template metadata."""
    prompt_text = read_prompt_source(prompt, prompt_file, use_stdin).strip()
    template_result = resolve_selected_template_prompt(template, variables, cfg)
    if template_result is None:
        if not prompt_text:
            raise ValueError("Provide a prompt, --file, --stdin, or --template.")
        return prompt_text, None
    template_text, metadata = template_result
    final_parts = [part for part in (template_text.strip(), prompt_text) if part]
    return "\n\n".join(final_parts), metadata


def build_headless_state(
    cfg: TuochatConfig,
    *,
    conversation: Conversation,
    store: ConversationStore | NullConversationStore,
    provider: DuoProvider | ElizaProvider,
    streaming: bool,
    active_model: str,
    prompt_sources: list[str],
    timeout_override: int | None = None,
    resumed_context_pending: bool = False,
) -> ReplState:
    """Create a minimal REPL state for non-interactive execution."""
    return ReplState(
        conv=conversation,
        store=store,
        provider=provider,
        cfg=cfg,
        streaming=streaming,
        timeout_override=timeout_override,
        quiet=True,
        no_banner=True,
        blind_mode=False,
        debug=False,
        base_system_prompt=conversation.system_prompt,
        base_resource_id=conversation.resource_id,
        pending_attachment_messages=[],
        pending_attachment_names=[],
        active_system_prompt_sources=prompt_sources,
        pending_template_metadata=None,
        mask_output=False,
        dot_timer_enabled=False,
        no_code_mode=False,
        active_model=active_model,
        command_log=[],
        resumed_context_pending=resumed_context_pending,
        local_writes_enabled=not cfg.chat.no_write,
    )


def resolve_provider(
    cfg: TuochatConfig,
    *,
    model: str,
    timeout: int | None,
    build_provider: Callable[[TuochatConfig, int | None], DuoProvider],
) -> DuoProvider | ElizaProvider:
    """Create the requested provider."""
    if model == "eliza":
        return ElizaProvider()
    if not cfg.gitlab.host or not cfg.gitlab.token:
        raise ValueError("GitLab host and token must be configured for Duo headless mode.")
    return build_provider(cfg, timeout)


def save_output_file(output_file: Path | None, response_text: str) -> None:
    """Write the model response to a requested output file."""
    if output_file is None:
        return
    path = output_file.expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(response_text, encoding="utf-8")


def persist_turn(
    state: ReplState,
    *,
    user_input: str,
    outbound_input: str,
    full_response: str,
    interrupted: bool,
) -> HeadlessExecution:
    """Persist a completed turn and return the machine-readable result."""
    input_tokens = estimate_tokens(outbound_input)
    output_tokens = estimate_tokens(full_response)
    message_extras_json = None
    if state.pending_template_metadata is not None:
        message_extras_json = json_dumps({"template": state.pending_template_metadata}, ensure_ascii=True)
    user_message = state.conv.add_message(Role.USER.value, outbound_input, extras_json=message_extras_json)
    assistant_message = state.conv.add_message(
        Role.ASSISTANT.value,
        full_response,
        status=MessageStatus.PARTIAL.value if interrupted else MessageStatus.COMPLETE.value,
    )
    if state.conv.title is None:
        state.conv.title = state.conv.auto_title(user_input)
    state.store.save_conversation(state.conv)
    state.store.save_message(user_message)
    state.store.save_message(assistant_message)
    state.store.save_usage(
        Usage(
            conversation_id=state.conv.id,
            message_id=assistant_message.id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            model="eliza" if state.active_model == "eliza" else "estimated",
        )
    )
    archive_dir, markdown_path, extracted = sync_conversation_artifacts(
        state.cfg,
        state.conv,
        approve_write=(
            reject_interactive_prompt if state.cfg.chat.approve_writes and state.cfg.chat.write_here_mode else None
        ),
    )
    if markdown_path is not None:
        update_saved_conversation_artifacts(state, markdown_path, extracted)
    _ = archive_dir
    return HeadlessExecution(
        conversation=state.conv,
        response_text=full_response,
        model=state.active_model,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        markdown_path=markdown_path,
        extracted_paths=extracted,
    )


def execute_turn(state: ReplState, user_input: str, *, json_output: bool) -> HeadlessExecution:
    """Run one non-interactive turn."""
    outbound_input = build_outbound_input(state, user_input)
    try:
        valid = validate_user_request(
            user_input,
            outbound_input,
            state.cfg.chat.max_request_chars,
            state.cfg,
            reject_interactive_prompt,
        )
    except HeadlessInteractiveActionRequired as exc:
        raise HeadlessInteractiveActionRequired(
            f"Headless mode would require an interactive confirmation: {exc}"
        ) from exc
    if not valid:
        raise RuntimeError("Request cancelled.")

    started_at = time.perf_counter()
    interrupted = False
    chunks: list[str] = []
    should_stream_stdout = state.streaming and not json_output
    if state.active_model == "eliza":
        provider = ElizaProvider()
        for chunk in provider.chat(outbound_input, streaming=state.streaming and not json_output):
            if should_stream_stdout:
                print(chunk, end="", flush=True)
            chunks.append(chunk)
        if should_stream_stdout:
            print()
    else:
        for chunk in state.provider.chat(
            outbound_input,
            resource_id=state.conv.resource_id,
            streaming=state.streaming and not json_output,
            cancel=lambda: False,
            additional_context=state.server_context or None,
        ):
            if should_stream_stdout:
                print(chunk, end="", flush=True)
            chunks.append(chunk)
        if should_stream_stdout:
            print()
    _ = started_at
    full_response = "".join(chunks)
    if not should_stream_stdout and not json_output:
        print(full_response)
    return persist_turn(
        state,
        user_input=user_input,
        outbound_input=outbound_input,
        full_response=full_response,
        interrupted=interrupted,
    )


def print_headless_json(result: HeadlessExecution, output_file: Path | None) -> None:
    """Render a headless command result as JSON."""
    payload = {
        "conversation_id": result.conversation.id,
        "title": result.conversation.title,
        "model": result.model,
        "input_tokens": result.input_tokens,
        "output_tokens": result.output_tokens,
        "response_text": result.response_text,
        "saved_markdown_path": str(result.markdown_path) if result.markdown_path is not None else None,
        "output_file": str(output_file) if output_file is not None else None,
        "extracted_file_paths": [str(path) for path in result.extracted_paths],
    }
    print(json_dumps(payload, indent=True))


def run_headless_ask(
    cfg: TuochatConfig,
    command: HeadlessAskCommand,
    *,
    build_provider: Callable[[TuochatConfig, int | None], DuoProvider],
    build_store: Callable[[TuochatConfig], ConversationStore | NullConversationStore],
) -> int:
    """Execute a new headless chat request."""
    try:
        user_input, template_metadata = prepare_prompt_text(
            command.prompt,
            command.prompt_file,
            command.use_stdin,
            command.template,
            command.variables,
            cfg,
        )
        provider = resolve_provider(cfg, model=command.model, timeout=command.timeout, build_provider=build_provider)
        store = build_store(cfg)
        system_prompt, prompt_sources = compose_system_prompt(
            command.system_prompt,
            load_custom_instruction_sections(cfg),
        )
        conversation = Conversation(
            resource_id=command.resource_id or cfg.chat.default_resource_id,
            system_prompt=system_prompt,
        )
        state = build_headless_state(
            cfg,
            conversation=conversation,
            store=store,
            provider=provider,
            streaming=not command.no_stream and cfg.chat.streaming and not command.json_output,
            active_model=command.model,
            prompt_sources=prompt_sources,
            timeout_override=command.timeout,
        )
        attachments = resolve_include_paths(command.includes)
        for path, message in attachments:
            state.pending_attachment_messages.append(message)
            state.pending_attachment_names.append(str(path))
        skill_attachment = resolve_skill_attachment(command.skill, cfg)
        if skill_attachment is not None:
            path, message = skill_attachment
            state.pending_attachment_messages.append(message)
            state.pending_attachment_names.append(str(path))
        state.pending_template_metadata = template_metadata
        try:
            result = execute_turn(state, user_input, json_output=command.json_output)
        finally:
            store.close()
        save_output_file(command.output_file, result.response_text)
        if command.json_output:
            print_headless_json(result, command.output_file)
        return 0
    except (HeadlessInteractiveActionRequired, OSError, RuntimeError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 1


def run_headless_continue(
    cfg: TuochatConfig,
    command: HeadlessContinueCommand,
    *,
    build_provider: Callable[[TuochatConfig, int | None], DuoProvider],
    build_store: Callable[[TuochatConfig], ConversationStore | NullConversationStore],
    resolve_conversation_id: Callable[[ConversationStore | NullConversationStore, str], str | None],
) -> int:
    """Continue a saved conversation non-interactively."""
    try:
        user_input, template_metadata = prepare_prompt_text(
            command.prompt,
            command.prompt_file,
            command.use_stdin,
            command.template,
            command.variables,
            cfg,
        )
        provider = resolve_provider(cfg, model=command.model, timeout=command.timeout, build_provider=build_provider)
        store = build_store(cfg)
        try:
            conversation_id = resolve_conversation_id(store, command.id)
            if conversation_id is None:
                return 1
            conversation = store.get_conversation(conversation_id)
            if conversation is None:
                print(f"Conversation {conversation_id} not found.", file=sys.stderr)
                return 1
            conversation.messages = store.get_messages(conversation_id)
            state = build_headless_state(
                cfg,
                conversation=conversation,
                store=store,
                provider=provider,
                streaming=not command.no_stream and cfg.chat.streaming and not command.json_output,
                active_model=command.model,
                prompt_sources=(
                    ["saved conversation prompt (embedded in transcript)"] if conversation.system_prompt else []
                ),
                timeout_override=command.timeout,
                resumed_context_pending=bool(conversation.messages),
            )
            attachments = resolve_include_paths(command.includes)
            for path, message in attachments:
                state.pending_attachment_messages.append(message)
                state.pending_attachment_names.append(str(path))
            skill_attachment = resolve_skill_attachment(command.skill, cfg)
            if skill_attachment is not None:
                path, message = skill_attachment
                state.pending_attachment_messages.append(message)
                state.pending_attachment_names.append(str(path))
            state.pending_template_metadata = template_metadata
            result = execute_turn(state, user_input, json_output=command.json_output)
        finally:
            store.close()
        save_output_file(command.output_file, result.response_text)
        if command.json_output:
            print_headless_json(result, command.output_file)
        return 0
    except (HeadlessInteractiveActionRequired, OSError, RuntimeError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 1
