"""Light-touch I/O seams for alternate front ends."""

from __future__ import annotations

import getpass
import io
from contextlib import ExitStack, contextmanager, redirect_stderr, redirect_stdout
from contextvars import ContextVar
from typing import Any, Protocol


class PromptCallback(Protocol):
    """Callable protocol for injected prompt handlers."""

    def __call__(self, prompt: str, *, secret: bool = False) -> str: ...


prompt_handler_var: ContextVar[PromptCallback | None] = ContextVar("prompt_handler_var", default=None)


def read_prompt(prompt: str, *, secret: bool = False) -> str:
    """Read interactive input from the active prompt handler or the console."""
    handler = prompt_handler_var.get()
    if handler is not None:
        return handler(prompt, secret=secret)
    if secret:
        return getpass.getpass(prompt)
    return input(prompt)


@contextmanager
def prompt_handler(prompt_callback: PromptCallback | None):
    """Install a prompt callback for the current execution context."""
    token = prompt_handler_var.set(prompt_callback)
    try:
        yield
    finally:
        prompt_handler_var.reset(token)


@contextmanager
def redirect_standard_io(
    *,
    stdout: Any = None,
    stderr: Any = None,
):
    """Redirect stdout/stderr for the duration of a context."""
    with ExitStack() as stack:
        if stdout is not None:
            stack.enter_context(redirect_stdout(stdout))
        if stderr is not None:
            stack.enter_context(redirect_stderr(stderr))
        yield


class NullTextIO(io.TextIOBase):
    """Writable text sink that ignores all content."""

    def write(self, text: str) -> int:
        return len(text)

    def writable(self) -> bool:
        return True
