"""Tuochat: GitLab Duo Chat client."""

__version__ = "0.1.0"
