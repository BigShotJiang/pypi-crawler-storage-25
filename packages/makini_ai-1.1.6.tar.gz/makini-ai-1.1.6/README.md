# Makini: The Infrastructure for the Agentic Era

Makini is a federated agent orchestration engine built on the principles of **Stack Physics**. It allows developers to compile fragmented real-world domains into executable, schema-enforced localized ontologies.

By enforcing **Domain Isolation** and **Deterministic State**, Makini ensures that AI agents operate within safe, predictable, and compilable boundaries, eliminating hallucinations in enterprise state management.

## 🚀 Key Principles (Stack Physics)

1. **Domain Isolation:** External systems are black boxes. Each agent owns its localized domain state.
2. **LDS Before Ontology:** Models must be defined as Logical Data Structures (LDS) before being compiled into RDF/OWL.
3. **Deterministic State:** Cross-domain conflicts are resolved via an immutable SQLite-backed decision ledger, not LLM hallucinations.

## 📦 Installation

### **macOS (Recommended)**
The fastest way to install Makini on macOS is via Homebrew:

```bash
brew tap nyabutid/makini
brew install makini
```

### **Other Platforms (pipx)**
We recommend using **pipx** to ensure the CLI is isolated and correctly added to your PATH:

```bash
pipx install makini-ai
```

### 💡 Troubleshooting: "Command Not Found"
If you prefer standard pip, or your PATH is not configured, you can always run Makini as a Python module:

```bash
pip install makini-ai
python3 -m makini --help
```

## 🛠️ Quickstart

### 1. Initialize a Workspace
```bash
makini init --dir my-agent-system
cd my-agent-system
```

### 2. Install a Semantic Mapping Package
Pull pre-mapped enterprise schemas from the official Makini Registry:
```bash
makini package install @makini/salesforce-edge
```

### 3. Connect to Makini Cloud (Managed Moat)
Synchronize your decision ledgers across distributed teams:
```bash
makini cloud login --token <your-api-token>
makini cloud sync
```

## 🏗️ Architecture

Makini consists of a **Headless Compiler Engine** and a **Global Registry of Semantic Mappings**.

- **Compiler:** Translates LDS files into SQL DDL, TTL (Ontologies), and Mermaid diagrams.
- **Broker:** Orchestrates multi-agent state synchronization.
- **Registry:** The definitive source for namespaced enterprise domain models.

## ⚖️ License

Makini Core is Open Source under the Apache License 2.0. Advanced managed services and premium registries are available via [api.makini.ai](https://api.makini.ai).

---
*Built for founders who need to hide the messy reality of fragmented vendor systems behind clean, compilable domain models.*
