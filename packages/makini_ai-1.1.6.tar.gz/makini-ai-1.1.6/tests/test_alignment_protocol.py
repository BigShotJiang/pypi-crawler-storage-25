import unittest
from core.governance.alignment import AlignmentProtocol

class TestAlignmentProtocol(unittest.TestCase):
    def test_export_alignment_api(self):
        protocol = AlignmentProtocol("finance.ttl", "startup.ttl")
        protocol.propose_alignment("finance:Account", "startup:BankAccount", confidence=0.95)
        
        xml_output = protocol.export_alignment_api()
        self.assertIn('<?xml version="1.0"', xml_output)
        self.assertIn('<Alignment>', xml_output)
        self.assertIn('<entity1 rdf:resource="finance:Account"/>', xml_output)
        self.assertIn('<entity2 rdf:resource="startup:BankAccount"/>', xml_output)
        self.assertIn('<measure rdf:datatype="http://www.w3.org/2001/XMLSchema#float">0.95</measure>', xml_output)

if __name__ == "__main__":
    unittest.main()
