import unittest
import os
import shutil
import sqlite3
import json
from pathlib import Path
from core.federated_router import FederatedRouter
from core.broker import MakiniBroker
from core.injector import inject_makini_manifest
from core.sqlite_ledger.injector import DomainSQLiteInjector

class TestFederatedRouterAlignments(unittest.TestCase):
    def setUp(self):
        self.test_dir = Path("test_workspace_alignments")
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
        self.test_dir.mkdir()

        # 1. Setup a workspace with two domains: Banking and PartnerPortal
        packages = ["Banking", "PartnerPortal"]
        inject_makini_manifest(str(self.test_dir), packages, "Gemini CLI")
        
        # 2. Create package directories and LDS files
        # Banking has Account(id, owner)
        # PartnerPortal has Profile(id, bank_ref) where bank_ref -> Account.id
        for pkg in packages:
            pkg_dir = self.test_dir / "packages" / pkg
            pkg_dir.mkdir(parents=True, exist_ok=True)
            if pkg == "Banking":
                lds_content = """
                ENTITY Account {
                    id UUID PK
                    owner String
                }
                """
            elif pkg == "PartnerPortal":
                lds_content = """
                ENTITY Profile {
                    id UUID PK
                    bank_ref UUID
                    bio String
                }
                """
            (pkg_dir / "schema.lds").write_text(lds_content)

        # 3. Inject SQLite databases
        injector = DomainSQLiteInjector(str(self.test_dir))
        injector.inject_all_active()

        # 4. Populate some data
        banking_db = self.test_dir / ".makini" / "states" / "Banking.db"
        conn = sqlite3.connect(banking_db)
        conn.execute("INSERT INTO accounts (id, owner) VALUES ('acc-1', 'Alice')")
        conn.commit()
        conn.close()

        partner_db = self.test_dir / ".makini" / "states" / "PartnerPortal.db"
        conn = sqlite3.connect(partner_db)
        conn.execute("INSERT INTO profiles (id, bank_ref, bio) VALUES ('prof-1', 'acc-1', 'Loves code')")
        conn.commit()
        conn.close()

        self.router = FederatedRouter(str(self.test_dir))
        self.broker = MakiniBroker(str(self.test_dir))

    def tearDown(self):
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)

    def test_join_succeeds_via_auto_discovery(self):
        # This used to fail because 'bank_ref' does not match 'account_id' naming convention.
        # Now it should SUCCEED because the router uses AlignmentNegotiator to find 'bank_ref' -> 'Account.id'
        graphql = """
        {
          Account {
            owner
            Profile {
              bio
            }
          }
        }
        """
        results = self.router.execute(graphql)
        self.assertEqual(len(results), 1)
        # New implementation discovers the join automatically
        self.assertIsNotNone(results[0]['Profile'], "Profile should be resolved via auto-discovery")
        self.assertEqual(results[0]['Profile']['bio'], 'Loves code')

    def test_join_succeeds_with_alignment(self):
        # Now we authorize an alignment: PartnerPortal.Profile.bank_ref -> Banking.Account.id
        self.broker.authorize_alignment(
            source_domain="PartnerPortal",
            target_domain="Banking",
            source_concept="Profile.bank_ref",
            target_concept="Account.id",
            confidence=1.0,
            rationale="Manual mapping for partner portal integration"
        )
        
        graphql = """
        {
          Account {
            owner
            Profile {
              bio
            }
          }
        }
        """
        # This test is expected to FAIL currently because the router doesn't use alignments
        results = self.router.execute(graphql)
        self.assertEqual(len(results), 1)
        self.assertIsNotNone(results[0]['Profile'], "Profile should be resolved via alignment")
        self.assertEqual(results[0]['Profile']['bio'], 'Loves code')

if __name__ == "__main__":
    unittest.main()
