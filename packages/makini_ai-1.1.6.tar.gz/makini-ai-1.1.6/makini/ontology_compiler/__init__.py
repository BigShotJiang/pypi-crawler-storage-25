from .compiler import OntologyCompiler
