import sys
import argparse
import os
import json
import importlib.util
import shutil
from pathlib import Path
from makini.injector import inject_makini_manifest
from makini.lds_compiler import compile_lds_file
from makini.package_builder import PackageBuilder

def get_default_engine():
    """Probes the system for available AI agents (Gemini, Claude, or Codex)."""
    if shutil.which("gemini"):
        return "Gemini CLI"
    if shutil.which("claude"):
        return "Claude Code"
    if shutil.which("codex"):
        return "Codex"
    return "Gemini CLI"

def load_plugins(subparsers):
    """Loads custom CLI commands from the user's .makini/plugins directory."""
    plugins_dir = Path(".makini/plugins")
    if not plugins_dir.exists():
        return

    for plugin_file in plugins_dir.glob("*.py"):
        if plugin_file.name == "__init__.py":
            continue
            
        module_name = f"makini_plugin_{plugin_file.stem}"
        spec = importlib.util.spec_from_file_location(module_name, plugin_file)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            try:
                spec.loader.exec_module(module)
                if hasattr(module, 'register_command'):
                    module.register_command(subparsers)
            except Exception as e:
                print(f"Failed to load plugin {plugin_file.name}: {e}")

def main():
    parser = argparse.ArgumentParser(description="Makini Headless Compiler CLI")
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Load user plugins
    load_plugins(subparsers)

    # init command
    init_parser = subparsers.add_parser("init", help="Initialize a workspace")
    init_parser.add_argument("--dir", help="Target directory (defaults to current directory)")
    init_parser.add_argument("--packages", default="Logical Data Structures", help="Comma separated packages")
    default_engine = get_default_engine()
    init_parser.add_argument("--engine", default=default_engine, help=f"CLI Engine (Detected: {default_engine})")
    init_parser.add_argument("--force", action="store_true", help="Force initialization even if workspace exists")

    # config command
    config_parser = subparsers.add_parser("config", help="Manage workspace configuration")
    config_parser.add_argument("--dir", default=".", help="Target directory")
    config_parser.add_argument("--engine", help="Update the default CLI engine")
    config_parser.add_argument("--list", action="store_true", help="List current configuration")

    # build command
    build_parser = subparsers.add_parser("build", help="Build models from LDS")
    build_parser.add_argument("--dir", help="Target directory (defaults to current directory)")
    build_parser.add_argument("--format", choices=["sql", "ttl", "mermaid"], default="sql", help="Output format")

    # discover command
    discover_parser = subparsers.add_parser("discover", help="Reverse-engineer an LDS from an existing SQLite database")
    discover_parser.add_argument("--db", required=True, help="Path to the SQLite database")
    discover_parser.add_argument("--out", help="Output LDS file (prints to stdout if omitted)")

    # package command
    pkg_parser = subparsers.add_parser("package", help="Package management")
    pkg_subparsers = pkg_parser.add_subparsers(dest="pkg_command", help="Package commands")
    
    create_pkg_parser = pkg_subparsers.add_parser("create", help="Create a new package")
    create_pkg_parser.add_argument("--name", required=True, help="Package name")
    create_pkg_parser.add_argument("--out", default="packages", help="Output directory")
    create_pkg_parser.add_argument("--skill", help="Base skill to inherit from")
    create_pkg_parser.add_argument("--depends", help="Dependency skill")

    create_from_lds_parser = pkg_subparsers.add_parser("import", help="Import an existing LDS into a package")
    create_from_lds_parser.add_argument("--lds", required=True, help="Path to LDS file")
    create_from_lds_parser.add_argument("--name", help="Package name")
    create_from_lds_parser.add_argument("--out", default=".makini/packages", help="Output directory")

    install_pkg_parser = pkg_subparsers.add_parser("install", help="Install a package from a registered remote repository")
    install_pkg_parser.add_argument("--name", required=True, help="Package name")
    install_pkg_parser.add_argument("--dir", default=".", help="Target directory")

    # registry command
    registry_parser = subparsers.add_parser("registry", help="Manage package registries")
    registry_subparsers = registry_parser.add_subparsers(dest="registry_command", help="Registry commands")
    
    add_reg_parser = registry_subparsers.add_parser("add", help="Add a remote git repository as a package registry")
    add_reg_parser.add_argument("--url", required=True, help="Git URL of the registry")
    add_reg_parser.add_argument("--dir", default=".", help="Target directory")
    
    list_reg_parser = registry_subparsers.add_parser("list", help="List configured registries")
    list_reg_parser.add_argument("--dir", default=".", help="Target directory")

    # inject command
    inject_parser = subparsers.add_parser("inject", help="Inject compiled SQLite databases for active domains")
    inject_parser.add_argument("--dir", default=".", help="Target directory")
    inject_parser.add_argument("--crsqlite", action="store_true", help="Enable CR-SQLite Conflict-free Replicated Relations")

    # query command
    query_parser = subparsers.add_parser("query", help="Execute a GraphQL-LD federated query")
    query_parser.add_argument("--dir", default=".", help="Target directory")
    query_parser.add_argument("--graphql", required=True, help="GraphQL query string")

    # ui command
    ui_parser = subparsers.add_parser("ui", help="Launch the Makini Visual Dashboard")
    ui_parser.add_argument("--dir", default=".", help="Target directory")

    # agent command
    agent_launch_parser = subparsers.add_parser("agent", help="Launch your configured AI agent in the current workspace")
    agent_launch_parser.add_argument("--dir", help="Target directory")
    agent_launch_parser.add_argument("--engine", help="Override CLI Engine (Claude Code, Gemini CLI, Codex, Ollama)")

    # interview command
    interview_parser = subparsers.add_parser("interview", help="Launch an autonomous agent to model your domain")
    interview_parser.add_argument("--dir", help="Target directory")
    interview_parser.add_argument("--engine", help="Override CLI Engine (Claude Code, Gemini CLI, Codex, Ollama)")

    # cloud command
    cloud_parser = subparsers.add_parser("cloud", help="Makini Cloud Managed Services")
    cloud_subparsers = cloud_parser.add_subparsers(dest="cloud_command", help="Cloud commands")
    
    login_parser = cloud_subparsers.add_parser("login", help="Login to Makini Cloud")
    login_parser.add_argument("--token", required=True, help="API Token")
    
    sync_cloud_parser = cloud_subparsers.add_parser("sync", help="Synchronize local ledger with Makini Cloud")
    sync_cloud_parser.add_argument("--dir", default=".", help="Target directory")
    sync_cloud_parser.add_argument("--endpoint", default="https://api.makini.ai/v1", help="Cloud endpoint")

    # broker command
    broker_parser = subparsers.add_parser("broker", help="Agent orchestration broker")
    broker_subparsers = broker_parser.add_subparsers(dest="broker_command", help="Broker commands")
    broker_parser.add_argument("--dir", default=".", help="Target directory")

    decide_parser = broker_subparsers.add_parser("decide", help="Record a proposed decision")
    decide_parser.add_argument("--id", required=True, help="Conflict ID")
    decide_parser.add_argument("--type", required=True, help="Entity Type")
    decide_parser.add_argument("--state", required=True, help="Resolved State")
    decide_parser.add_argument("--rationale", required=True, help="Rationale")

    conflict_parser = broker_subparsers.add_parser("conflict", help="Report a contradiction")
    conflict_parser.add_argument("--id", required=True, help="Conflict ID")
    conflict_parser.add_argument("--type", required=True, help="Entity Type")
    conflict_parser.add_argument("--states", required=True, help="Proposed States (JSON)")
    conflict_parser.add_argument("--agent", required=True, help="Agent ID")

    check_parser = broker_subparsers.add_parser("check", help="Check for an existing decision")
    check_parser.add_argument("--id", required=True, help="Conflict ID")

    broker_subparsers.add_parser("conflicts", help="List all pending conflicts")
    broker_subparsers.add_parser("resolutions", help="List all settled resolutions")
    broker_subparsers.add_parser("validate", help="Validate current LDS model")

    add_package_parser = broker_subparsers.add_parser("add-package", help="Add a package to the manifest")
    add_package_parser.add_argument("--name", required=True, help="Package name")

    broker_subparsers.add_parser("sense", help="Scan active domains for contradictions")
    broker_subparsers.add_parser("sync", help="Propagate human resolutions to domain states")

    align_parser = broker_subparsers.add_parser("align", help="Authorize semantic alignment")
    align_parser.add_argument("--src_dom", required=True)
    align_parser.add_argument("--tgt_dom", required=True)
    align_parser.add_argument("--src_con", required=True)
    align_parser.add_argument("--tgt_con", required=True)
    align_parser.add_argument("--conf", type=float, default=1.0)
    align_parser.add_argument("--rat", required=True)

    export_align_parser = broker_subparsers.add_parser("export-alignments", help="Export alignments to EXMO Align API format")
    export_align_parser.add_argument("--domain", help="Filter by source domain")

    import_align_parser = broker_subparsers.add_parser("import-alignments", help="Import alignments from EXMO Align API XML file")
    import_align_parser.add_argument("--file", required=True, help="Path to XML file")

    negotiate_parser = broker_subparsers.add_parser("negotiate", help="Propose alignments between two LDS files")
    negotiate_parser.add_argument("--src", required=True, help="Source LDS file")
    negotiate_parser.add_argument("--tgt", required=True, help="Target LDS file")
    negotiate_parser.add_argument("--threshold", type=float, default=0.6, help="Confidence threshold")

    negotiate_auto_parser = broker_subparsers.add_parser("negotiate-auto", help="Automatically authorize high-confidence alignments")
    negotiate_auto_parser.add_argument("--src", required=True, help="Source LDS file")
    negotiate_auto_parser.add_argument("--tgt", required=True, help="Target LDS file")
    negotiate_auto_parser.add_argument("--src_dom", required=True, help="Source Domain Name")
    negotiate_auto_parser.add_argument("--tgt_dom", required=True, help="Target Domain Name")
    negotiate_auto_parser.add_argument("--threshold", type=float, default=0.8, help="Auto-authorization threshold")

    scan_parser = broker_subparsers.add_parser("scan", help="Run Sentinel package vulnerability scanner")
    scan_parser.add_argument("--package", help="Specific package to scan (scans all if omitted)")

    bypass_parser = broker_subparsers.add_parser("bypass", help="Authorize a bypass for a Sentinel vulnerability (Custom Packages Only)")
    bypass_parser.add_argument("--package", required=True, help="Target package name")
    bypass_parser.add_argument("--id", required=True, help="Vulnerability ID (e.g., SNTNL-CUST-001)")
    bypass_parser.add_argument("--rationale", required=True, help="Reason for bypass")

    args = parser.parse_args()

    if hasattr(args, 'func'):
        args.func(args)
    elif args.command == "init":
        target_dir = args.dir
        if not target_dir:
            confirm = input(f"📂 No --dir provided. Initialize in current directory ({os.getcwd()})? [Y/n]: ").strip().lower()
            if confirm and confirm != 'y':
                print("Aborted.")
                sys.exit(0)
            target_dir = "."
        
        # Safety Check: Does workspace already exist?
        manifest_path = Path(target_dir) / ".makini" / "makini.yaml"
        if manifest_path.exists() and not args.force:
            confirm = input(f"⚠️  Workspace already exists at {target_dir}. Overwrite configuration? [y/N]: ").strip().lower()
            if confirm != 'y':
                print("Aborted. Use --force to override.")
                sys.exit(0)

        packages = [p.strip() for p in args.packages.split(",")]
        success = inject_makini_manifest(target_dir, packages, args.engine)
        if success:
            print(f"✅ Workspace initialized at {target_dir}")
        else:
            print(f"❌ Failed to initialize workspace.")
            sys.exit(1)

    elif args.command == "config":
        import yaml
        target_dir = args.dir
        manifest_path = Path(target_dir) / ".makini" / "makini.yaml"
        
        if not manifest_path.exists():
            print(f"❌ No workspace found at {target_dir}. Did you run 'makini init'?")
            sys.exit(1)
            
        try:
            with open(manifest_path, 'r') as f:
                config = yaml.safe_load(f)
        except Exception as e:
            print(f"❌ Failed to read config: {e}")
            sys.exit(1)
            
        if args.list:
            print(f"--- Makini Workspace Config ({target_dir}) ---")
            for k, v in config.items():
                print(f"{k}: {v}")
            return

        if args.engine:
            config['cli_engine'] = args.engine
            config['last_updated'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            with open(manifest_path, 'w') as f:
                yaml.dump(config, f, default_flow_style=False)
            print(f"✅ Default engine updated to: {args.engine}")
        else:
            print("No changes requested. Use --engine to update settings or --list to view them.")

    elif args.command == "build":
        target_dir = args.dir
        if not target_dir:
            confirm = input(f"🏗️  No --dir provided. Build from current directory ({os.getcwd()})? [Y/n]: ").strip().lower()
            if confirm and confirm != 'y':
                print("Aborted.")
                sys.exit(0)
            target_dir = "."
            
        lds_file = Path(target_dir) / "schema.lds"
        if not lds_file.exists():
            print(f"❌ schema.lds not found in {target_dir}")
            sys.exit(1)
        
        try:
            output = compile_lds_file(str(lds_file), output_format=args.format)
            print(output)
        except Exception as e:
            print(f"❌ Build failed: {e}")
            sys.exit(1)
    
    elif args.command == "discover":
        from makini.lds_compiler.discoverer import DomainDiscoverer
        discoverer = DomainDiscoverer(args.db)
        lds_content = discoverer.discover_lds()
        if args.out:
            with open(args.out, 'w') as f:
                f.write(lds_content)
            print(f"✅ Discovered LDS saved to {args.out}")
        else:
            print(lds_content)
    
    elif args.command == "registry":
        from makini.registry import MakiniRegistry
        registry = MakiniRegistry(args.dir)
        if args.registry_command == "add":
            if registry.add_registry(args.url):
                print(f"✅ Added registry: {args.url}")
            else:
                sys.exit(1)
        elif args.registry_command == "list":
            regs = registry.get_registries()
            print("Configured Registries:")
            for r in regs:
                print(f" - {r}")
                
    elif args.command == "package":
        if args.pkg_command == "create":
            builder = PackageBuilder()
            pkg_path = builder.create_package(
                name=args.name,
                output_dir=args.out,
                base_skill=args.skill,
                depends_on=args.depends
            )
            print(f"✅ Package '{args.name}' created at {pkg_path}")
        elif args.pkg_command == "import":
            builder = PackageBuilder()
            pkg_path = builder.create_package_from_lds(
                lds_path=args.lds,
                name=args.name,
                output_dir=args.out
            )
            print(f"✅ Package imported at {pkg_path}")
        elif args.pkg_command == "install":
            from makini.registry import MakiniRegistry
            registry = MakiniRegistry(args.dir)
            if not registry.install_package(args.name):
                sys.exit(1)
        else:
            pkg_parser.print_help()

    elif args.command == "inject":
        from makini.sqlite_ledger.injector import DomainSQLiteInjector
        injector = DomainSQLiteInjector(args.dir)
        successful = injector.inject_all_active(enable_crsqlite=args.crsqlite)
        if successful:
            print(f"✅ Successfully injected SQLite databases for: {', '.join(successful)}")
        else:
            print("⚠️  No domain databases injected.")

    elif args.command == "query":
        from makini.federated_router import FederatedRouter
        router = FederatedRouter(args.dir)
        results = router.execute(args.graphql)
        print(json.dumps(results, indent=2))

    elif args.command == "ui":
        import subprocess
        import sys
        ui_path = Path(__file__).parent.parent / "ui" / "app.py"
        print(f"🚀 Launching Makini Visual Dashboard...")
        try:
            # Invoke streamlit via the current python interpreter to ensure it works in venvs (like Brew)
            subprocess.run([sys.executable, "-m", "streamlit", "run", str(ui_path)], check=True)
        except KeyboardInterrupt:
            print("\n👋 Dashboard stopped.")
        except Exception as e:
            print(f"❌ Failed to launch dashboard: {e}")

    elif args.command == "agent":
        from makini.cli_runner.runner import launch_agent
        import yaml
        
        target_dir = args.dir
        if not target_dir:
            confirm = input(f"🤖 No --dir provided. Launch agent in current directory ({os.getcwd()})? [Y/n]: ").strip().lower()
            if confirm and confirm != 'y':
                print("Aborted.")
                sys.exit(0)
            target_dir = "."
        
        # Load engine from manifest
        engine = get_default_engine()
        manifest_path = Path(target_dir) / ".makini" / "makini.yaml"
        if manifest_path.exists():
            try:
                with open(manifest_path, 'r') as f:
                    manifest = yaml.safe_load(f)
                    engine = manifest.get('cli_engine', engine)
            except: pass
            
        # Override if provided
        if args.engine:
            engine = args.engine

        print(f"🤖 Launching AI Agent ({engine})...")
        launch_agent(target_dir, engine)

    elif args.command == "interview":
        from makini.cli_runner.runner import launch_agent
        import yaml
        
        target_dir = args.dir
        if not target_dir:
            confirm = input(f"🎤 No --dir provided. Start interview in current directory ({os.getcwd()})? [Y/n]: ").strip().lower()
            if confirm and confirm != 'y':
                print("Aborted.")
                sys.exit(0)
            target_dir = "."

        # 1. Verify workspace is initialized and read the prompt
        prompt_path = Path(target_dir) / "interview_prompt.md"
        if not prompt_path.exists():
            print(f"❌ No interview_prompt.md found in {target_dir}. Did you run 'makini init'?")
            sys.exit(1)
        
        try:
            with open(prompt_path, 'r') as f:
                raw_prompt = f.read()
        except Exception as e:
            print(f"❌ Failed to read interview_prompt.md: {e}")
            sys.exit(1)
            
        # 2. Load engine from manifest
        engine = get_default_engine()
        manifest_path = Path(target_dir) / ".makini" / "makini.yaml"
        if manifest_path.exists():
            try:
                with open(manifest_path, 'r') as f:
                    manifest = yaml.safe_load(f)
                    engine = manifest.get('cli_engine', engine)
            except: pass
            
        # Override if provided
        if args.engine:
            engine = args.engine

        # 3. Context Injection
        # We wrap the file content to ensure the agent understands it is the primary directive.
        injected_prompt = f"SYSTEM INSTRUCTIONS (DO NOT IGNORE):\n\n{raw_prompt}\n\nUSER REQUEST: Begin the modeling interview now."

        print(f"🎤 Starting Autonomous Modeler Interview ({engine})...")
        launch_agent(target_dir, engine, initial_prompt=injected_prompt)

    elif args.command == "cloud":
        if args.cloud_command == "login":
            creds_dir = Path.home() / ".makini"
            creds_dir.mkdir(parents=True, exist_ok=True)
            (creds_dir / "credentials").write_text(f"token: {args.token}")
            print("✅ Successfully logged into Makini Cloud.")
        elif args.cloud_command == "sync":
            from makini.broker import MakiniBroker
            broker = MakiniBroker(args.dir)
            
            token = "anonymous"
            creds_file = Path.home() / ".makini" / "credentials"
            if creds_file.exists():
                try:
                    token = creds_file.read_text().split("token: ")[1].strip()
                except: pass
            
            broker.ledger.sync_with_cloud(args.endpoint, token)

    elif args.command == "broker":
        from makini.broker import MakiniBroker
        broker = MakiniBroker(args.dir)
        
        if args.broker_command == "decide":
            if broker.propose_resolution(args.id, args.type, args.state, args.rationale):
                print(f"✅ Decision '{args.id}' recorded.")
            else:
                sys.exit(1)
        elif args.broker_command == "conflict":
            states = json.loads(args.states)
            result = broker.report_conflict(args.id, args.type, states, args.agent)
            if result:
                # The broker might have auto-resolved it
                decision = broker.check_decision(args.id)
                if decision and "Auto-resolved" in decision.get('rationale', ''):
                    print(f"✅ Conflict '{args.id}' was auto-resolved by Policy.")
                else:
                    print(f"✅ Conflict '{args.id}' reported and logged for review.")
            else:
                sys.exit(1)
        elif args.broker_command == "check":
            decision = broker.check_decision(args.id)
            if decision:
                print(f"FOUND: {decision['state']} (Rationale: {decision['rationale']})")
            else:
                print("NOT_FOUND")
        elif args.broker_command == "conflicts":
            conflicts = broker.ledger.get_pending_conflicts()
            if not conflicts:
                print("No pending conflicts.")
            for c in conflicts:
                print(f"[{c['timestamp']}] ID: {c['conflict_id']} | Type: {c['entity_type']} | Agents: {c['source_agents']}")
                print(f"  Proposed States: {c['proposed_states']}")
        elif args.broker_command == "resolutions":
            resolutions = broker.ledger.get_all_resolutions()
            if not resolutions:
                print("No resolutions found.")
            for r in resolutions:
                print(f"[{r['timestamp']}] ID: {r['conflict_id']} (v{r['version']}) | State: {r['state']}")
                print(f"  Rationale: {r['rationale']}")
        elif args.broker_command == "validate":
            result = broker.validate_model()
            if result['valid']:
                print(f"✅ Model valid: {result['entity_count']} entities, {result['relationship_count']} rels.")
            else:
                print(f"❌ Model invalid: {result['error']}")
                sys.exit(1)
        elif args.broker_command == "add-package":
            if broker.add_package(args.name):
                print(f"✅ Package '{args.name}' added to manifest.")
            else:
                sys.exit(1)
        elif args.broker_command == "sense":
            conflicts = broker.sense_all()
            if not conflicts:
                print("✅ No cross-domain contradictions detected.")
            else:
                print(f"⚠️  Detected {len(conflicts)} contradictions:")
                for c in conflicts:
                    print(f" - {c['id']}: {c['rationale']}")
                    print(f"   States: {c['proposed_states']}")
        elif args.broker_command == "sync":
            broker.sync_resolutions()
            print("✅ Domain states synchronized with human resolutions.")
        elif args.broker_command == "align":
            if broker.authorize_alignment(args.src_dom, args.tgt_dom, args.src_con, args.tgt_con, args.conf, args.rat):
                print(f"✅ Alignment Authorized.")
            else:
                sys.exit(1)
        elif args.broker_command == "export-alignments":
            output = broker.export_alignments(args.domain)
            if output:
                print(output)
            else:
                print("No alignments found.")
        elif args.broker_command == "import-alignments":
            count = broker.import_alignments(args.file)
            print(f"✅ Successfully imported and authorized {count} alignments from {args.file}")
        elif args.broker_command == "negotiate":
            proposals = broker.negotiate_alignments(args.src, args.tgt, args.threshold)
            if not proposals:
                print("No alignment proposals found above threshold.")
            else:
                print(f"Found {len(proposals)} alignment proposals:")
                for p in proposals:
                    print(f" - [{p['confidence']}] {p['source_concept']} <-> {p['target_concept']}")
                    print(f"   Rationale: {p['rationale']}")
        elif args.broker_command == "negotiate-auto":
            proposals = broker.negotiate_alignments(args.src, args.tgt, args.threshold)
            count = 0
            for p in proposals:
                if broker.authorize_alignment(
                    source_domain=args.src_dom,
                    target_domain=args.tgt_dom,
                    source_concept=p['source_concept'],
                    target_concept=p['target_concept'],
                    confidence=p['confidence'],
                    rationale=f"Auto-negotiated: {p['rationale']}"
                ):
                    print(f"✅ Authorized: {p['source_concept']} <-> {p['target_concept']} ({p['confidence']})")
                    count += 1
            print(f"\n✅ Automatically authorized {count} alignments between {args.src_dom} and {args.tgt_dom}.")
        elif args.broker_command == "scan":
            from makini.governance.sentinel import SentinelScanner
            scanner = SentinelScanner(args.dir)
            if args.package:
                results = {args.package: scanner.scan_package(args.package)}
            else:
                results = scanner.scan_all()
            
            if "status" in results and results["status"] == "no_packages_found":
                print("No packages found to scan.")
            else:
                total_vulns = 0
                for pkg, result in results.items():
                    vulns = result.get("vulnerabilities", [])
                    total_vulns += len(vulns)
                    if vulns:
                        pkg_type = "Standard" if result["is_standard"] else "Custom"
                        print(f"\n🛡️  Sentinel Scan: {pkg} ({pkg_type} Package)")
                        for v in vulns:
                            print(f"  [{v['severity']}] {v['id']}: {v['description']}")
                
                if total_vulns == 0:
                    print("✅ Sentinel Scan Complete: No active vulnerabilities found.")
                else:
                    print(f"\n⚠️  Sentinel Scan Complete: Found {total_vulns} active vulnerabilities.")
                    print("   To bypass custom package warnings, use: broker bypass --package <pkg> --id <id> --rationale \"<reason>\"")
        
        elif args.broker_command == "bypass":
            from makini.governance.sentinel import SentinelScanner
            scanner = SentinelScanner(args.dir)
            if not scanner.authorize_bypass(args.package, args.id, args.rationale):
                sys.exit(1)
    
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
