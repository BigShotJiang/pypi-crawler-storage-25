import os
import shlex
import subprocess
import platform
from pathlib import Path


def _escape_applescript(s: str) -> str:
    """Escapes a string for safe embedding inside an AppleScript double-quoted string."""
    return s.replace('\\', '\\\\').replace('"', '\\"')


def launch_agent(target_dir: str, engine: str, yolo: bool = False, initial_prompt: str = ""):
    """
    Attempts to launch the selected CLI agent in the target directory.
    On macOS, it opens a new Terminal window and brings it to the front.
    """
    target_path = Path(target_dir).absolute()

    # Construct base command
    if engine == "Gemini CLI":
        engine_cmd = "gemini"
    elif engine == "Claude Code":
        engine_cmd = "claude"
    elif engine == "Ollama":
        engine_cmd = "ollama run llama3"
    elif engine == "Codex":
        engine_cmd = "codex"
    else:
        engine_cmd = "gemini"

    flags = []
    if yolo:
        if engine == "Gemini CLI":
            flags.append("-y")
        elif engine == "Claude Code":
            flags.append("--dangerously-skip-permissions")
        elif engine == "Codex":
            flags.extend(["--approval-policy", "never"])

    # Shell-quote both the path and the prompt to prevent command injection
    prompt_arg = f" {shlex.quote(initial_prompt)}" if initial_prompt else ""
    cmd = f"cd {shlex.quote(str(target_path))} && {engine_cmd} {' '.join(flags)}{prompt_arg}"

    # Escape backslashes then double-quotes for embedding in AppleScript string literal
    escaped_cmd = _escape_applescript(cmd)

    system = platform.system()
    try:
        if system == "Darwin":  # macOS
            # AppleScript to open Terminal, run command, and FOCUS the window
            applescript = f'''
                tell application "Terminal"
                    activate
                    do script "{escaped_cmd}"
                end tell
            '''
            subprocess.run(["osascript", "-e", applescript])
            return True, "Launched and focused Terminal."
        else:
            return False, f"Auto-launch not supported on {system}. Please run '{cmd}' manually."
    except Exception as e:
        return False, str(e)
