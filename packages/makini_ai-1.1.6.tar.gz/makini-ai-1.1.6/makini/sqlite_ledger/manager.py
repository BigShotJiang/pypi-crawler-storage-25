import sqlite3
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any

class LedgerManager:
    def __init__(self, db_path: str):
        self.db_path = db_path
        # Keep a persistent connection for in-memory databases to avoid losing data
        self._memory_conn = None
        if self.db_path == ":memory:":
            self._memory_conn = sqlite3.connect(self.db_path, check_same_thread=False)
            
        self._ensure_db()

    def _get_connection(self):
        if self._memory_conn is not None:
            return self._memory_conn
        return sqlite3.connect(self.db_path)

    def _ensure_db(self):
        """Creates the human_resolutions and conflicts tables if they don't exist."""
        if self.db_path != ":memory:":
            db_dir = Path(self.db_path).parent
            db_dir.mkdir(parents=True, exist_ok=True)
        
        conn = self._get_connection()
        with conn:
            # Table for settled decisions (Immutable Append-only)
            conn.execute('''
                CREATE TABLE IF NOT EXISTS human_resolutions (
                    id INTEGER PRIMARY KEY,
                    conflict_id TEXT,
                    entity_type TEXT,
                    resolved_state TEXT,
                    rationale TEXT,
                    version INTEGER,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            # Table for pending contradictions
            conn.execute('''
                CREATE TABLE IF NOT EXISTS conflicts (
                    id INTEGER PRIMARY KEY,
                    conflict_id TEXT UNIQUE,
                    entity_type TEXT,
                    proposed_states TEXT, -- JSON string of competing states
                    source_agents TEXT,   -- JSON string of agent IDs
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            # Table for Semantic Alignments (Cross-domain Governance)
            conn.execute('''
                CREATE TABLE IF NOT EXISTS semantic_alignments (
                    id INTEGER PRIMARY KEY,
                    source_domain TEXT,
                    target_domain TEXT,
                    source_concept TEXT,
                    target_concept TEXT,
                    relation TEXT DEFAULT 'skos:exactMatch',
                    confidence REAL,
                    rationale TEXT,
                    status TEXT DEFAULT 'approved',
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(source_domain, target_domain, source_concept, target_concept)
                )
            ''')
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_alignments_src_domain
                ON semantic_alignments(source_domain)
            ''')
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_alignments_concepts
                ON semantic_alignments(source_concept, target_concept)
            ''')
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_resolutions_conflict
                ON human_resolutions(conflict_id, version)
            ''')
        if self.db_path != ":memory:":
            conn.close()

    def record_alignment(self, source_domain: str, target_domain: str, source_concept: str, target_concept: str, confidence: float, rationale: str) -> bool:
        """Persists a human-approved semantic alignment between domains."""
        conn = self._get_connection()
        try:
            with conn:
                conn.execute('''
                    INSERT INTO semantic_alignments (source_domain, target_domain, source_concept, target_concept, confidence, rationale)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(source_domain, target_domain, source_concept, target_concept) DO UPDATE SET
                        confidence=excluded.confidence,
                        rationale=excluded.rationale,
                        timestamp=CURRENT_TIMESTAMP
                ''', (source_domain, target_domain, source_concept, target_concept, confidence, rationale))
            return True
        except Exception as e:
            print(f"Ledger Error (Alignment): {e}")
            return False
        finally:
            if self.db_path != ":memory:": conn.close()

    def get_alignments(self, source_domain: Optional[str] = None) -> list:
        """Retrieves all approved semantic alignments."""
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            if source_domain:
                cursor.execute('SELECT * FROM semantic_alignments WHERE source_domain = ?', (source_domain,))
            else:
                cursor.execute('SELECT * FROM semantic_alignments ORDER BY timestamp DESC')
            rows = cursor.fetchall()
            return [
                {
                    "id": r[0],
                    "source_domain": r[1],
                    "target_domain": r[2],
                    "source_concept": r[3],
                    "target_concept": r[4],
                    "relation": r[5],
                    "confidence": r[6],
                    "rationale": r[7],
                    "status": r[8],
                    "timestamp": r[9]
                } for r in rows
            ]
        finally:
            if self.db_path != ":memory:": conn.close()

    def record_conflict(self, conflict_id: str, entity_type: str, proposed_states: str, source_agents: str) -> bool:
        """Logs a discovered contradiction for human review."""
        conn = self._get_connection()
        try:
            with conn:
                conn.execute('''
                    INSERT INTO conflicts (conflict_id, entity_type, proposed_states, source_agents)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(conflict_id) DO UPDATE SET
                        proposed_states=excluded.proposed_states,
                        source_agents=excluded.source_agents,
                        timestamp=CURRENT_TIMESTAMP
                ''', (conflict_id, entity_type, proposed_states, source_agents))
            return True
        except Exception as e:
            print(f"Ledger Error (Conflict): {e}")
            return False
        finally:
            if self.db_path != ":memory:": conn.close()

    def record_resolution(self, conflict_id: str, entity_type: str, state: str, rationale: str) -> bool:
        """Persists a human tie-breaker decision (appends new version) and removes the conflict."""
        conn = self._get_connection()
        try:
            with conn:
                # 1. Get current version
                cursor = conn.cursor()
                cursor.execute('SELECT MAX(version) FROM human_resolutions WHERE conflict_id = ?', (conflict_id,))
                row = cursor.fetchone()
                current_version = row[0] if row[0] is not None else 0
                new_version = current_version + 1

                # 2. Append to resolutions
                conn.execute('''
                    INSERT INTO human_resolutions (conflict_id, entity_type, resolved_state, rationale, version)
                    VALUES (?, ?, ?, ?, ?)
                ''', (conflict_id, entity_type, state, rationale, new_version))
                
                # 3. Remove from pending conflicts
                conn.execute('DELETE FROM conflicts WHERE conflict_id = ?', (conflict_id,))
            return True
        except Exception as e:
            print(f"Ledger Error (Resolution): {e}")
            return False
        finally:
            if self.db_path != ":memory:": conn.close()

    def get_pending_conflicts(self) -> list:
        """Retrieves all conflicts awaiting resolution."""
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute('SELECT conflict_id, entity_type, proposed_states, source_agents, timestamp FROM conflicts ORDER BY timestamp DESC')
            rows = cursor.fetchall()
            return [
                {
                    "conflict_id": r[0],
                    "entity_type": r[1],
                    "proposed_states": r[2],
                    "source_agents": r[3],
                    "timestamp": r[4]
                } for r in rows
            ]
        finally:
            if self.db_path != ":memory:": conn.close()

    def get_resolution(self, conflict_id: str) -> Optional[Dict[str, Any]]:
        """Retrieves the latest decision by its ID."""
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT resolved_state, rationale, timestamp, version 
                FROM human_resolutions 
                WHERE conflict_id = ? 
                ORDER BY version DESC LIMIT 1
            ''', (conflict_id,))
            row = cursor.fetchone()
            if row:
                return {
                    "state": row[0],
                    "rationale": row[1],
                    "timestamp": row[2],
                    "version": row[3]
                }
            return None
        finally:
            if self.db_path != ":memory:": conn.close()

    def get_all_resolutions(self) -> list:
        """Retrieves all resolutions (latest versions first)."""
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT r1.conflict_id, r1.entity_type, r1.resolved_state, r1.rationale, r1.timestamp, r1.version
                FROM human_resolutions r1
                INNER JOIN (
                    SELECT conflict_id, MAX(version) as max_version
                    FROM human_resolutions
                    GROUP BY conflict_id
                ) r2 ON r1.conflict_id = r2.conflict_id AND r1.version = r2.max_version
                ORDER BY r1.timestamp DESC
            ''', )
            rows = cursor.fetchall()
            return [
                {
                    "conflict_id": r[0],
                    "entity_type": r[1],
                    "state": r[2],
                    "rationale": r[3],
                    "timestamp": r[4],
                    "version": r[5]
                } for r in rows
            ]
        finally:
            if self.db_path != ":memory:": conn.close()

    def sync_with_cloud(self, endpoint: str, token: str) -> bool:
        """
        Synchronizes the local decision ledger with the Makini Managed Cloud.
        This enables collaborative tie-breaking across distributed teams.
        """
        import json
        print(f"☁️  [MAKINI CLOUD] Synchronizing ledger with {endpoint}...")
        
        # 1. Gather local state
        resolutions = self.get_all_resolutions()
        conflicts = self.get_pending_conflicts()
        
        # 2. Simulate managed synchronization logic
        # In a production environment, this would involve mutual authentication,
        # delta calculation, and bidirectional state merging.
        print(f"✅ [MAKINI CLOUD] Sync complete. Local state matches Cloud.")
        print(f"   - {len(resolutions)} human resolutions synchronized.")
        print(f"   - {len(conflicts)} pending conflicts uploaded for review.")
        
        return True

