import re
from typing import List, Dict, Any
from .parser import LDSParser

class LDSLinter:
    """
    LDSLinter: Provides deterministic error codes for Logical Data Structure models.
    Designed to prevent infinite LLM retry loops by giving precise feedback.
    """
    def __init__(self, lds_text: str):
        self.lds_text = lds_text
        self.parser = LDSParser(lds_text)

    def lint(self) -> List[Dict[str, str]]:
        """
        Runs a battery of structural checks on the LDS.
        Returns a list of errors with codes and actionable descriptions.
        """
        errors = []
        try:
            entities, relationships = self.parser.parse()
        except Exception as e:
            return [{"code": "LDS-000", "severity": "CRITICAL", "message": f"Syntax Error: {str(e)}"}]

        if not entities:
            errors.append({"code": "LDS-004", "severity": "HIGH", "message": "No entities found in the model."})
            return errors

        for ent_name, ent in entities.items():
            # Rule LDS-001: Missing Primary Key
            has_pk = any(attr['pk'] for attr in ent.attributes)
            if not has_pk and not ent.external_ref:
                errors.append({
                    "code": "LDS-001",
                    "severity": "HIGH",
                    "message": f"Entity '{ent_name}' is missing a Primary Key (PK). Use '.' prefix or '(..., PK)'."
                })

            # Rule LDS-002: Orphaned Entity
            if not ent.external_ref:
                is_connected = False
                for rel in relationships:
                    if rel.entity_a.lower() == ent_name.lower() or rel.entity_b.lower() == ent_name.lower():
                        is_connected = True
                        break
                if not is_connected and len(entities) > 1:
                    errors.append({
                        "code": "LDS-002",
                        "severity": "MEDIUM",
                        "message": f"Entity '{ent_name}' is orphaned (has no relationships to other entities)."
                    })

        # Rule LDS-003: Relationship Entity Match
        for rel in relationships:
            if rel.entity_a not in entities and not self._is_builtin_or_external(rel.entity_a):
                errors.append({
                    "code": "LDS-003",
                    "severity": "HIGH",
                    "message": f"Relationship refers to undefined entity '{rel.entity_a}'."
                })
            if rel.entity_b not in entities and not self._is_builtin_or_external(rel.entity_b):
                errors.append({
                    "code": "LDS-003",
                    "severity": "HIGH",
                    "message": f"Relationship refers to undefined entity '{rel.entity_b}'."
                })

        return errors

    def _is_builtin_or_external(self, name: str) -> bool:
        # Check if it looks like a namespaced external ref
        if "::" in name or name.startswith("@"):
            return True
        return False

    def format_errors_for_llm(self, errors: List[Dict[str, str]]) -> str:
        """Formats the errors into a prompt-friendly string."""
        if not errors: return "Model is valid."
        
        lines = ["The LDS you generated has the following structural errors:"]
        for err in errors:
            lines.append(f"- [{err['code']}] {err['message']}")
        lines.append("\nPlease correct these errors and regenerate the LDS.")
        return "\n".join(lines)
