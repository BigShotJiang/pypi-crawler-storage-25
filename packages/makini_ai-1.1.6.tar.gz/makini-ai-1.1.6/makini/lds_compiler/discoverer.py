import sqlite3
import inflect
from typing import Dict, List, Any
from makini.lds_compiler.parser import LDSEntity

p = inflect.engine()

class DomainDiscoverer:
    def __init__(self, db_path: str):
        self.db_path = db_path

    def _get_entity_name(self, table_name: str) -> str:
        singular = p.singular_noun(table_name)
        if not singular:
            singular = table_name
        return singular.capitalize()

    def discover_lds(self) -> str:
        """
        Reverse-engineers a SQLite database into an LDS string.
        """
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # 1. Get Tables
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'migrations' AND name NOT LIKE 'crsql_%';")
            tables = [row[0] for row in cursor.fetchall()]
            
            lds_output = []
            for table in tables:
                entity_name = self._get_entity_name(table)
                lds_output.append(f"ENTITY: {entity_name}")
                lds_output.append("ATTRIBUTES:")
                
                cursor.execute(f"PRAGMA table_info({table});")
                cols = cursor.fetchall()
                for col in cols:
                    # cid, name, type, notnull, dflt_value, pk
                    name = col[1]
                    ctype = col[2]
                    is_pk = col[5] == 1
                    
                    prefix = "." if is_pk else "-"
                    attr_line = f"  {prefix} {name} ({ctype})"
                    lds_output.append(attr_line)
                lds_output.append("")

            # 2. Get Relationships (Foreign Keys)
            relationships = []
            for table in tables:
                cursor.execute(f"PRAGMA foreign_key_list({table});")
                fks = cursor.fetchall()
                for fk in fks:
                    # id, seq, table, from, to, on_update, on_delete, match
                    parent_table = fk[2]
                    
                    child_ent = self._get_entity_name(table)
                    parent_ent = self._get_entity_name(parent_table)
                    
                    # Carlis LDS usually expresses this as a relationship line
                    # We'll use a standard 1:MANY MUST/MAY assumption for recovery
                    relationships.append(f"RELATIONSHIP: {parent_ent} (1) [MUST] --- [MAY] (MANY) {child_ent}")

            if relationships:
                lds_output.append("RELATIONSHIPS:")
                # Deduplicate and add
                for rel in sorted(list(set(relationships))):
                    lds_output.append(f"- {rel.replace('RELATIONSHIP: ', '')}")

            return "\n".join(lds_output)
        finally:
            conn.close()

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        discoverer = DomainDiscoverer(sys.argv[1])
        print(discoverer.discover_lds())
    else:
        print("Usage: python -m makini.lds_compiler.discoverer <db_path>")
