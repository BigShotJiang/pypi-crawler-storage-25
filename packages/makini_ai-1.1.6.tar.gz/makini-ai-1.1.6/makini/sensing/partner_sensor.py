import csv
import sqlite3
import os
from pathlib import Path

class PartnerCSVSensor:
    """
    Ingests disparate partner data (CSV) and creates a localized domain database.
    This simulates an external partner providing data in their own proprietary format.
    """
    def __init__(self, target_dir: str):
        self.target_dir = Path(target_dir).expanduser().resolve()
        self.states_dir = self.target_dir / ".makini" / "states"
        self.states_dir.mkdir(parents=True, exist_ok=True)

    def ingest_csv(self, csv_path: str, domain_name: str, table_name: str):
        """
        Creates a SQLite database for the domain and populates it with CSV data.
        Infers types simplistically.
        """
        db_path = self.states_dir / f"{domain_name}.db"
        
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            headers = reader.fieldnames
            rows = list(reader)

        if not headers:
            print(f"❌ Error: CSV {csv_path} has no headers.")
            return False

        conn = sqlite3.connect(db_path)
        try:
            # Drop table if exists for clean demo
            conn.execute(f"DROP TABLE IF EXISTS {table_name}")
            
            # Create table
            cols = ", ".join([f'"{h}" TEXT' for h in headers])
            conn.execute(f"CREATE TABLE {table_name} ({cols})")
            
            # Insert data
            header_cols = ", ".join([f'"{h}"' for h in headers])
            placeholders = ", ".join(["?" for _ in headers])
            sql = f"INSERT INTO {table_name} ({header_cols}) VALUES ({placeholders})"
            
            data = [tuple(row[h] for h in headers) for row in rows]
            conn.executemany(sql, data)
            conn.commit()
            
            print(f"✅ Ingested {len(rows)} rows from {csv_path} into {domain_name}.{table_name}")
            return True
        except Exception as e:
            print(f"❌ Ingestion Error: {e}")
            return False
        finally:
            conn.close()

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 4:
        sensor = PartnerCSVSensor(".")
        sensor.ingest_csv(sys.argv[1], sys.argv[2], sys.argv[3])
    else:
        print("Usage: python3 -m core.sensing.partner_sensor <csv_path> <domain_name> <table_name>")
