from makini.cli_runner.makini_cli import main

if __name__ == "__main__":
    main()
