# Changelog

All notable changes to QAMigrate are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.1] - 2026-04-16

**Theme: Polish from the v0.3.0 test report.** Three user-reported issues
plus the three untested surfaces the tester flagged. No new features --
every change makes the existing v0.3.0 flow safer or cheaper.

### Fixed
- **pom.xml preservation (major).** v0.3.0 used ElementTree to write back
  the pom after adding deps, which stripped every `<!-- comment -->` and
  the `<?xml version="1.0"?>` declaration. On a user's 202-line pom.xml
  we collapsed it to 173 lines of noise. v0.3.1 uses surgical text
  insertion: find the `</dependencies>` tag, insert the new
  `<dependency>` blocks right before it, leave everything else
  byte-for-byte identical. Also detects the existing indent of sibling
  `<dependency>` blocks so the new ones fit in seamlessly.
- **Per-file attempt starvation.** In v0.3.0 the project-wide Fixer loop
  tracked a single "no-progress counter" for the whole batch. If most
  files compiled quickly but one (e.g. `Environment.java` in the
  reporter's project) had a stubborn error, the counter hit its limit
  before the stubborn file got its fair share of attempts. v0.3.1 tracks
  progress per file: each file has its own attempt budget (up to
  `pipeline.max_retries`) and its own two-consecutive-no-progress bailout,
  independent of what's happening in sibling files. A "retired" file
  stops consuming attempts while others keep going.
- **Fixer prompt now explicitly covers enum syntax.** The v0.3.0 report
  showed `enum E { A("a"); B("b"); }` -- `;` instead of `,`. Added a
  dedicated bullet to the Fixer system prompt with the correct rule and
  an example.

### Added (polish)
- **Tighter Fixer system prompt to reduce wasted API calls.** v0.3.0
  regularly returned LLM output that started with prose ("Here's the
  fix:") or contained ` ``` ` fences, which our tree-sitter validator
  correctly rejected -- but that rejection burned a tool call. The
  prompt now explicitly says "return the ORIGINAL source unchanged if
  you're not confident the output will parse" and "no markdown fences,
  no prose outside Java comments." We also call out that the output is
  rejected silently when it fails to parse.

### Tests (now 79/79, was 69/69)
- `tests/test_dependency_injector.py::test_preserves_xml_declaration_and_comments`
  -- regression for the pom.xml stripping bug on a realistic pom with 4
  comments, multi-line `<project>` attributes, and the XML declaration.
- `tests/test_dependency_injector.py::test_no_dependencies_block_creates_one`
  -- edge case where the user's pom has no `<dependencies>` yet; we
  create one right before `</project>` without mangling the XML decl.
- `tests/test_dependency_injector.py::test_line_count_grows_predictably`
  -- two added deps add exactly 12 lines (6 lines each), not "the whole
  file reformatted."
- `tests/test_dependency_injector.py::test_idempotent_byte_for_byte` --
  a second `init --yes` leaves the file byte-for-byte identical so
  `git diff` is empty.
- `tests/test_hallucination.py::test_sensitivity_after_real_method_renamed`
  -- the exact scenario the tester asked about: rename a LoginPage
  method, verify the detector flags the test-class call site.
- `tests/test_pipeline_config.py` -- documents that `batch_compile`
  defaults to True, can be toggled via `--no-batch-compile`, and honors
  the `QAMIGRATE_PIPELINE__BATCH_COMPILE` env var.

### End-to-end validation on selenium-java-project
- pom.xml: 202 -> 214 lines (+12 for 2 deps, exactly as expected).
  All 17 `<!-- ... -->` comments preserved. XML declaration preserved.
  Re-running `init --yes` is a no-op; `git diff` is empty.

---

## [0.3.0] - 2026-04-15

**Theme: Whole-project compile.** Single-file compile was the bottleneck --
LoginPage can't compile without BasePage on the classpath, so every
page-object migration was marked FAIL even when the code was correct.
This release fixes that by compiling the whole project together and
resolving the real Maven classpath.

### Result on the reporter's selenium-java-project (15 files)
- v0.2.2: 7/15 at 70%+ confidence, all via skip-compile fallback
- v0.3.0: **14/15 at 100% compiled** (avg confidence 94%) -- twelve
  files compile cleanly on the first try, one file needs two fix
  iterations, one file still fails (isolated compile errors).

### Added
- **`qamigrate init --yes`** auto-injects Playwright 1.48.0 and
  JUnit Jupiter 5.11.3 into the project's `pom.xml` or `build.gradle`.
  Prompts the user without `--yes`. Idempotent -- re-running is a no-op.
  Gradle Groovy DSL supported; Gradle Kotlin DSL deferred to v0.3.1.
- **`qamigrate.agents.dependency_injector.DependencyInjector`** -- the
  module behind `init`. Preserves XML namespaces so pom.xml doesn't end
  up with `ns0:` prefixes.
- **`qamigrate.agents.classpath.ClasspathResolver`** -- shells out to
  `mvn -q dependency:build-classpath` (60s timeout) and caches the
  resolved JARs in `.qamigrate/classpath.txt`. Gradle classpath is
  deferred to v0.3.1.
- **`qamigrate.agents.pipeline.run_project_migration`** -- the new
  project-level pipeline. Three phases:
  1. Generate all files with scanner + coder (no compile-check yet).
  2. Resolve classpath and batch-compile everything with `javac
     -sourcepath ... -cp ...`.
  3. If there are errors, run the Fixer per file (only its own errors,
     never cross-contaminated), recompile, accept only when errors
     strictly reduce. Stop after `pipeline.max_retries` passes or two
     consecutive non-improvements.
- **`CompilerAgent.group_errors_by_file()`** -- helper that buckets a
  batch-compile result's errors by file path.
- **`FixerAgent.fix_file()`** -- wrapper around `fix()` that filters
  the error list to only those matching the file being fixed.
- **`qamigrate migrate --no-batch-compile`** -- escape hatch to fall
  back to the v0.2 per-file compile loop.
- `PipelineConfig.batch_compile` and `ClasspathConfig` sections in
  `qamigrate.yaml`.

### Fixed
- **`CompilerAgent.compile_batch()` tempdir bug** -- subprocess.run was
  outside the `TemporaryDirectory` context manager, meaning the tempdir
  had already been cleaned up before javac tried to use it. Moved the
  run inside the `with` block.
- **Classpath separator** -- was hard-coded to `;` (Windows). Now uses
  `os.pathsep` so batch compilation works on macOS / Linux.
- **Namespace mangling in pom.xml** -- when adding dependencies via
  ElementTree, the Maven namespace was being renamed to `ns0:` in the
  output. `ET.register_namespace("", maven_ns)` fixes it so the file
  looks normal.

### Developer experience
- Added 23 new tests (69/69 total pass):
  - `tests/test_dependency_injector.py` -- pom.xml (empty, existing
    deps, already-present, malformed) + gradle groovy (no block,
    existing block, idempotent) + Kotlin DSL unsupported.
  - `tests/test_classpath.py` -- mocks subprocess for success,
    not-installed, timeout, non-zero exit, cache hit / miss.
  - `tests/test_compiler_batch.py` -- `group_errors_by_file` and the
    empty-list case.
  - `tests/test_fixer.py::TestFixFilePerFileFiltering` -- ensures
    cross-file errors aren't shown to the per-file fixer.

### Known follow-ups
- One file (`Environment.java`) still fails on the reporter's project
  because its errors are unreachable by the Fixer after earlier files
  absorb attempts. The "rolling back" logic is protecting us but the
  file needs its own fix round.
- Gradle classpath resolution (init script or `./gradlew dependencies`
  parser) -- shipping Maven-only for v0.3.0.
- Gradle Kotlin DSL dep injection -- same.
- Incremental recompile for very large projects (currently always
  compiles everything).

---

## [0.2.2] - 2026-04-15

**Theme: Polish based on second user test report.** Three real issues
surfaced after a second round of testing on the user's project. All fixed
and validated end-to-end: 7/15 files at 70%+ confidence (vs 1/15 in
v0.2.1) with zero cross-file method hallucinations in the test class.

### Fixed
- **`\"` escape leak in generated code.** The LLM occasionally emitted
  literal `\"` sequences inside JSON `tool_use` string fields, which then
  landed in the generated Java as `page.locator(\\"#id\\")`. Added a
  sanitization pass at the tool-response parse boundary that unescapes
  `\\n`, `\\t`, `\\"`, and `\\'` from every string field before
  rendering. This was the single highest-ROI fix -- it flips several
  files from FAIL to PASS.
- **Cross-file method hallucinations.** Test classes no longer invent
  methods like `getSuccessIndicator()` or `getErrorElement()` on migrated
  page objects. Strengthened the Coder prompt to explicitly list allowed
  methods and forbid inventing new ones, with specific guidance on
  TestNG -> JUnit 5 annotation translation (`@Test(description="X")` ->
  `@Test` + `@DisplayName("X")` separately).
- **False compile failures when Playwright JAR is missing.** Previously
  the pipeline would burn API calls trying to "fix" `package
  com.microsoft.playwright does not exist` errors that the LLM can't
  resolve. Added classpath-issue detection on the first compile attempt:
  if more than half the errors look like classpath problems (missing
  Playwright package or cannot-find-symbol for Playwright types), the
  pipeline skips compilation validation, marks the file with 70%
  confidence (generated but not verified), and prints a helpful
  `Note:` at the end of the run with the pom.xml snippet to add.

### Added
- **Cross-file hallucination detector** (`qamigrate.core.hallucination`).
  Scans generated code for calls to methods on sibling classes that
  don't exist in those classes' public APIs. Suggests the closest real
  method name when one exists. Hallucinations appear in the console
  summary, the report (HTML/JSON/Markdown), and subtract 10 points each
  from confidence down to a floor of 20.
- **`MigrationRecord.hallucinations: list[Hallucination]`** field in the
  report data model.
- **CLI surfaces classpath issues** with an actionable pom.xml snippet
  when all files skip compilation due to missing Playwright.
- **10 new tests** (47 total) covering the unescape sanitizer, the
  hallucination detector, and confidence penalties.

### Changed
- `CoderAgent._sanitize_fields` is called on every `tool_use` response.
- `MigrationReport` HTML and Markdown outputs include a hallucinations
  section when any are present.
- Confidence scoring factored into two pieces: `_base_confidence()` and
  a hallucination penalty that applies on top.

### Results on the reporter's selenium-java-project (15 files)
- v0.2.1: 1/15 succeeded, 14 FAIL with uncompilable output.
- v0.2.2: 7/15 at 70%+ confidence, 2 fully compiled, remaining 6 failed
  because they reference app-internal classes (`DriverManager`, `Log`,
  `ExtentManager`) that can't be resolved when compiling single files --
  a separate problem to tackle in a later release.

---

## [0.2.1] - 2026-04-15

**Theme: Fix what v0.2.0 broke in real projects.** A user tested on a real
Selenium project and found the compile-fix loop was destructive and `--all`
missed most files. All six reported bugs are fixed.

### Fixed
- **Windows Unicode crash.** `qamigrate init` on Windows crashed with
  `UnicodeEncodeError: '\u2713'` because Rich emits box-drawing characters
  to a `cp1252` stdout. CLI now reconfigures stdout/stderr to UTF-8 on
  startup, and all Unicode glyphs in the CLI output have been replaced
  with ASCII-safe equivalents (`OK`, `FAIL`, `->`, etc.).
- **`--all` only finding `@Test` files.** The file-discovery loop stopped at
  the first directory under `src/` that had Java files, so it would pick
  `src/test/` and miss everything under `src/main/`. Fixed to walk the
  entire project (excluding `target`, `build`, `node_modules`, `playwright`,
  `.git`, `.venv`, `.idea`). Files are now also sorted so base classes and
  page objects are migrated before tests that depend on them.
- **Destructive compile-fix loop.** This was the headline defect: the
  fixer was splicing LLM prose like "Add this import at the top" into
  `.java` files, creating invalid output from valid first-draft code. Two
  changes:
  1. **Fixer rewrite.** The LLM fixer now uses Anthropic tool use
     (`emit_fixed_java` tool) to return the whole corrected file as a
     structured field. It cannot emit free-form text any more. The output
     is validated with tree-sitter before being accepted -- if it contains
     ERROR nodes, no top-level `class_declaration`, or is implausibly
     short, the fix is rejected.
  2. **Non-regressing pipeline.** The pipeline now tracks the best version
     seen so far (fewest errors). If a fix attempt produces more errors
     than the previous best, the pipeline rolls back to the best version.
     After two consecutive non-improvements, the loop stops early and
     keeps the best output. You no longer get degraded garbage after
     starting with working code.
- **Cross-file context.** When migrating a test class that imports a
  sibling page object, the Coder now receives the signatures of the
  already-migrated Playwright version of that sibling. The test class
  calls `new LoginPage(page)` (the real Playwright constructor) instead
  of inventing method names.
- **Confidence scoring.** The old scale gave 0 or 100 with almost no
  middle ground. Rewritten to 0-100 with honest tiers: 100 (first-try
  compile), 90 (1-2 fixes), 80 (many fixes), 70 (skipped compile),
  50 (didn't compile but output exists for review), 0 (no output).
- **Hours-saved metric.** Was counting every detected pattern, including
  from failed migrations. Now only counts patterns from files with
  confidence >= 70 -- if we didn't actually migrate the file, we don't
  claim credit for saving you time on it.
- **Escaped newlines in generated constructors.** LLM tool_use output
  occasionally contained literal `\n` (backslash-n, two chars) instead of
  real newlines, collapsing the constructor onto a single unreadable
  line. The reindenter now detects and unescapes this.

### Changed
- `FixerAgent` now returns the ORIGINAL code unchanged when no strategy
  worked, instead of returning half-applied partial fixes.
- Pipeline always fixes from the best version seen so far, not from
  whatever drifted version is currently on disk.
- CLI prints `[OK]`/`[FAIL]` tags instead of `OK`/`FAIL` for consistency.
- README has accurate output examples and honest confidence language.

### Removed
- `cli/main.py`: Unicode glyphs (check, cross, warning, rocket, chart,
  star, magnifying glass) replaced with ASCII.
- `reports.py` constants that referenced removed modules.

### Added
- `MigrationResult.class_name` and `MigrationResult.generated_signatures`
  so callers can thread context between files.
- `CoderAgent.extract_signatures()` helper.
- `CoderAgent.generate_from_class_info(..., sibling_signatures=...)`
  parameter.
- `run_migration(..., sibling_signatures=...)` parameter.
- `tests/test_fixer.py` with 8 new tests covering validation, markdown
  stripping, and escaped-newline handling.
- 8 more tests total (26 -> 34). All pass.

### Developer experience
- Removed stale dependency chain that referenced deleted modules.
- Fixed XML-element truthiness warning in scanner.
- `qamigrate --version` reports 0.2.1.

---

## [0.2.0] - 2026-04-15

**Theme: Trust & Evidence.** You no longer just get migrated code — you get proof of what changed, how confident we are, and how much time you saved.

### Added
- **Migration Report** in three formats: HTML, JSON, and Markdown
  - Per-file records with detected patterns, confidence score, compilation status, and before/after diff
  - Batch-level metrics: files succeeded/failed, patterns handled, average confidence, estimated hours saved
  - HTML report includes side-by-side diff viewer (stdlib `difflib`) with dark theme
- **`--dry-run` flag** on `qamigrate migrate`: scan all target files and preview patterns without calling the LLM or writing output
- **`--report <dir>` flag** on `qamigrate migrate`: writes `report.html`, `report.json`, `report.md` to the specified directory
- **`compiler.skip`** config option: skip compilation validation when Playwright JARs aren't available locally
- **Confidence scoring** per file (0-100) derived from success + compilation attempts
- **Time-saved estimate** based on ~15 min of manual effort per pattern

### Changed
- Simplified pipeline: `SupervisorConfig` renamed to `PipelineConfig`
- `QAMigrateConfig` now uses `pipeline.max_retries` instead of `supervisor.max_retries`
- `run_migration()` now returns a `MigrationResult` with an attached `MigrationRecord`
- CLI `migrate` command output: per-file status with confidence score, summary table with batch metrics

### Removed
- Dead modules: `supervisor.py`, `visual.py`, `utom.py`, `test_cleanup.py`, `languages.py`, `pdf_reports.py`, `dependencies.py`, `parallel.py`, `security.py`, `reports.py`, `database.py`, `integrations/jira_client.py`, `cli/interactive.py`
- Old web server (`server/`) and React dashboard (`dashboard/`) — will return in v0.3.0 once backed by the new report format
- CLI commands: `verify` (visual agent was mocked), `export` (superseded by `migrate --report`), `dashboard` (temporarily removed)
- Unused config sections: `visual`, `docker`, `server`, `quality_gates`
- Unused dependencies: `httpx`, `email-validator`, `fastapi`, `uvicorn`, `websockets`, `docker`, `opencv-python`, `pillow`, `imagehash`, `numpy`, `openai`

### Fixed
- `datetime.utcnow()` deprecation warnings on Python 3.12+ (now using `datetime.now(timezone.utc)`)
- Maven `pom.xml` element truthiness deprecation warnings in scanner
- CLI `--all` no longer requires the optional `DependencyAnalyzer` — walks `src/test` then `src/` directly

### Developer experience
- Added `tests/test_report.py` (13 new tests covering report rendering and confidence scoring)
- All 25 tests pass with no warnings

---

## [0.1.0] - 2026-04-14

### Added
- Initial release.
- Selenium Java -> Playwright Java migration pipeline:
  - **Scanner** (Tree-sitter, 70+ pattern queries)
  - **Coder** (Claude tool use for structured output)
  - **Compiler** (javac validation)
  - **Fixer** (rule-based + LLM error remediation with up to 3 retries)
- CLI commands: `init`, `scan`, `migrate`
- Validated end-to-end on real Selenium files covering `@FindBy`, `PageFactory`, `WebDriverWait`, `Actions`, `Select`, alerts, iframes, `JavascriptExecutor`, file uploads, TestNG inheritance, and `@DataProvider`.
