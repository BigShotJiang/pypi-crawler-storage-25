#!/usr/bin/env python3
"""Cont daemon — bilgisayarla birlikte yaşayan basit servis.

Modlar: AWAKE (session aktif) | IDLE (arka plan) | SLEEP (pil/boşta)
CLI: cont --daemon-start / --daemon-stop / --daemon-status

İlk versiyon: model sıcak tutma + güç yönetimi + heartbeat.
Arka plan görevleri ikinci iterasyonda.
"""

import json
import os
import signal
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

PID_FILE = Path.home() / ".config" / "cont" / "daemon.pid"
STATE_FILE = Path.home() / ".config" / "cont" / "daemon_state.json"
HEARTBEAT_INTERVAL = 300   # 5 dakika
POWER_CHECK_INTERVAL = 60  # 1 dakika
IDLE_TIMEOUT = 1800        # 30 dakika → SLEEP
GUARDIAN_INTERVAL = 1800   # 30 dakika
INBOX_INTERVAL = 3600      # 1 saat
PHEROMONE_INTERVAL = 3600  # 1 saat
FITNESS_INTERVAL = 3600    # 1 saat — TICKET-004
EVAPORATION_INTERVAL = 86400  # 24 saat — TICKET-006
SELF_TEST_INTERVAL = 36000    # 10 saat — guardian self-test
HEALTH_REPORT_INTERVAL = 7200 # 2 saat — feromon sağlık raporu
GOLDEN_TEST_INTERVAL = 86400  # 24 saat — golden test


class ContDaemon:
    def __init__(self):
        self.state = "IDLE"
        self.last_activity = time.time()
        self._stop = threading.Event()
        self._last_guardian = 0
        self._last_inbox = 0
        self._last_pheromone = 0
        self._last_fitness = 0
        self._last_evaporation = 0
        self._last_self_test = 0
        self._last_health_report = 0
        self._last_golden_test = 0
        self._dashboard = {}  # Hoş geldin raporu için

    # ── Güç yönetimi ──

    def detect_power(self) -> str:
        """Pil mi priz mi? WSL uyumlu."""
        # Linux native
        bat = Path("/sys/class/power_supply/BAT0/status")
        if bat.exists():
            return "battery" if bat.read_text().strip() == "Discharging" else "ac"
        # WSL → Windows
        try:
            r = subprocess.run(
                ["powershell.exe", "-NoProfile", "-c",
                 "(Get-CimInstance Win32_Battery).BatteryStatus"],
                capture_output=True, text=True, timeout=5,
            )
            return "battery" if r.stdout.strip() == "1" else "ac"
        except Exception:
            return "ac"

    def check_gpu_temp(self) -> int:
        """GPU sıcaklığı (°C). Okunamazsa -1."""
        try:
            r = subprocess.run(
                ["nvidia-smi", "--query-gpu=temperature.gpu", "--format=csv,noheader"],
                capture_output=True, text=True, timeout=5,
            )
            return int(r.stdout.strip())
        except Exception:
            return -1

    def check_lm_studio(self) -> bool:
        """LM Studio/Ollama çalışıyor mu?"""
        try:
            import httpx
            gw = subprocess.run(
                ["ip", "route", "show", "default"],
                capture_output=True, text=True, timeout=2,
            ).stdout.split()[2]
            r = httpx.get(f"http://{gw}:1234/v1/models", timeout=2.0)
            return r.status_code == 200
        except Exception:
            return False

    # ── Durum geçişleri ──

    def enter_idle(self):
        self.state = "IDLE"
        self._save_state()
        self._log("IDLE moda geçildi")

    def enter_awake(self):
        self.state = "AWAKE"
        self.last_activity = time.time()
        self._save_state()
        self._log("AWAKE moda geçildi")

    def enter_sleep(self):
        self.state = "SLEEP"
        self._save_state()
        self._log("SLEEP moda geçildi — GPU serbest")

    # ── Ana döngü ──

    def run(self):
        """Daemon ana döngüsü."""
        project_root = str(Path(__file__).parent.parent)
        os.chdir(project_root)
        if project_root not in sys.path:
            sys.path.insert(0, project_root)
        self._save_pid()
        signal.signal(signal.SIGTERM, self._handle_stop)
        signal.signal(signal.SIGINT, self._handle_stop)

        # Başlangıç modu
        power = self.detect_power()
        if power == "battery":
            self.enter_sleep()
        else:
            self.enter_idle()

        self._log(f"Daemon başladı (güç={power})")

        while not self._stop.is_set():
            try:
                self._tick()
            except Exception as e:
                self._log(f"Tick hatası: {e}")
            self._stop.wait(POWER_CHECK_INTERVAL)

        self._cleanup()

    def _tick(self):
        """Her dakika çalışan kontrol."""
        power = self.detect_power()

        # Güç geçişleri
        if power == "battery" and self.state != "SLEEP":
            self.enter_sleep()
            return
        if power == "ac" and self.state == "SLEEP":
            self.enter_idle()

        # Boşta timeout → SLEEP
        if self.state == "IDLE":
            idle_secs = time.time() - self.last_activity
            if idle_secs > IDLE_TIMEOUT:
                self._log(f"{IDLE_TIMEOUT // 60}dk boşta → SLEEP")
                self.enter_sleep()

        now = time.time()

        # Heartbeat (5 dakikada bir)
        if int(now) % HEARTBEAT_INTERVAL < POWER_CHECK_INTERVAL:
            gpu_temp = self.check_gpu_temp()
            model_ok = self.check_lm_studio() if self.state != "SLEEP" else False
            self._log(f"♥ {self.state} gpu={gpu_temp}°C model={'✓' if model_ok else '✗'}")
            self._dashboard["gpu_temp"] = gpu_temp
            self._dashboard["model_ok"] = model_ok

            if gpu_temp > 90:
                self._log(f"GPU {gpu_temp}°C — SLEEP'e geçiş")
                self.enter_sleep()

        # IDLE görevleri
        if self.state == "IDLE":
            # Guardian (30dk)
            if now - self._last_guardian > GUARDIAN_INTERVAL:
                self._run_guardian()
                self._last_guardian = now

            # Inbox kontrolü (1 saat)
            if now - self._last_inbox > INBOX_INTERVAL:
                self._check_inbox()
                self._last_inbox = now

            # Pheromone konsolidasyonu (1 saat)
            if now - self._last_pheromone > PHEROMONE_INTERVAL:
                self._consolidate_pheromone()
                self._last_pheromone = now

            # EWS drift kontrolü (guardian ile birlikte, 30dk)
            if now - self._last_guardian < POWER_CHECK_INTERVAL + 5:  # guardian az önce çalıştıysa
                self._check_ews_drift()

            # TICKET-004: Fitness güncelleme (1 saat)
            if now - self._last_fitness > FITNESS_INTERVAL:
                self._update_fitness()
                self._last_fitness = now

            # TICKET-006: Buharlaşma (günlük)
            if now - self._last_evaporation > EVAPORATION_INTERVAL:
                self._run_evaporation()
                self._last_evaporation = now

            # Guardian self-test (10 saatte bir)
            if now - self._last_self_test > SELF_TEST_INTERVAL:
                self._run_guardian_self_test()
                self._last_self_test = now

            # Feromon sağlık raporu (2 saatte bir)
            if now - self._last_health_report > HEALTH_REPORT_INTERVAL:
                self._run_health_report()
                self._last_health_report = now

            # Golden test (günlük)
            if now - self._last_golden_test > GOLDEN_TEST_INTERVAL:
                self._run_golden_test()
                self._last_golden_test = now

            # Dashboard güncelle
            self._save_state()

    # ── IDLE görevleri ──

    def _run_guardian(self):
        """Operasyonel guardian kontrolleri (1-5) + TICKET-005 trend."""
        try:
            os.chdir(str(Path(__file__).parent.parent))
            from core.guardian import run_guardian
            report = run_guardian(full=False)
            violations = report.all_violations()
            self._dashboard["guardian_violations"] = len(violations)
            if violations:
                self._log(f"Guardian: {len(violations)} ihlal")
            else:
                self._log("Guardian: temiz")
            # TICKET-005: Her guardian çalışmasında verify trend kaydet
            self._record_verify_trend()
        except Exception as e:
            self._log(f"Guardian hatası: {e}")

    def _check_inbox(self):
        """Inbox boyut kontrolü."""
        try:
            inbox = Path(__file__).parent.parent / ".cont" / "hive" / "inbox"
            count = len(list(inbox.glob("*.yaml"))) if inbox.exists() else 0
            self._dashboard["inbox_count"] = count
            if count >= 20:
                self._log(f"Inbox: {count} dosya — gözden geçirme zamanı")
            else:
                self._log(f"Inbox: {count} dosya")
        except Exception as e:
            self._log(f"Inbox hatası: {e}")

    def _consolidate_pheromone(self):
        """24 saatten eski pheromone izlerini arşivle."""
        try:
            trail = Path(__file__).parent.parent / ".cont" / "hive" / "pheromone" / "trail.jsonl"
            if not trail.exists():
                return
            lines = trail.read_text().splitlines()
            if len(lines) < 100:
                return  # Küçükse dokunma

            cutoff = (datetime.now().timestamp() - 86400)  # 24 saat
            fresh = []
            archived = 0
            for line in lines:
                try:
                    ts = datetime.fromisoformat(json.loads(line).get("ts", "")).timestamp()
                    if ts > cutoff:
                        fresh.append(line)
                    else:
                        archived += 1
                except Exception:
                    fresh.append(line)  # Parse edilemiyorsa koru

            if archived > 0:
                # Arşivle
                archive_dir = trail.parent / "archive"
                archive_dir.mkdir(exist_ok=True)
                date_str = datetime.now().strftime("%Y-%m-%d")
                archive_file = archive_dir / f"trail_{date_str}.jsonl"
                with open(archive_file, "a") as f:
                    for line in lines:
                        try:
                            ts = datetime.fromisoformat(json.loads(line).get("ts", "")).timestamp()
                            if ts <= cutoff:
                                f.write(line + "\n")
                        except Exception:
                            pass
                # Ana trail'i taze tut
                trail.write_text("\n".join(fresh) + "\n" if fresh else "")
                self._log(f"Pheromone: {archived} iz arşivlendi, {len(fresh)} kaldı")
        except Exception as e:
            self._log(f"Pheromone hatası: {e}")

    # ── TICKET-004: Fitness güncelleme ──

    def _update_fitness(self):
        """Feromon trail'den fitness skorlarını güncelle."""
        try:
            from core.fitness import all_fitness
            results = all_fitness()
            low = [r for r in results if 0 < r["fitness"] < 0.5]
            untested = [r for r in results if r["fitness"] == 0]
            self._dashboard["fitness_low"] = len(low)
            self._dashboard["fitness_untested"] = len(untested)
            if low:
                self._log(f"Fitness: {len(low)} düşük ({', '.join(r['name'] for r in low[:3])})")
            else:
                self._log(f"Fitness: {len(results)} reçete, hepsi sağlıklı")
        except Exception as e:
            self._log(f"Fitness hatası: {e}")

    # ── TICKET-005: Borç trendi (guardian çalıştığında kaydedilir) ──

    def _record_verify_trend(self):
        """Seviye 0 borç oranını zaman serisine kaydet."""
        try:
            from core.verify_minions import verify_level_report
            report = verify_level_report()
            trend_file = Path(__file__).parent.parent / ".cont" / "hive" / "runs" / "audit" / "verify_trend.json"
            trend_file.parent.mkdir(parents=True, exist_ok=True)

            # Mevcut trend'i oku
            trend = []
            if trend_file.exists():
                try:
                    trend = json.loads(trend_file.read_text())
                except Exception:
                    trend = []

            trend.append({
                "ts": datetime.now().isoformat(),
                "debt_ratio": report["debt_ratio"],
                "strong_ratio": report["strong_ratio"],
                "total_steps": report["total"],
                "level_0": report["levels"][0],
            })

            # Son 100 kayıt tut
            trend = trend[-100:]
            trend_file.write_text(json.dumps(trend, indent=2))

            # Trend kötüye gidiyor mu?
            if len(trend) >= 3:
                recent = [t["debt_ratio"] for t in trend[-3:]]
                if all(recent[i] > recent[i-1] for i in range(1, len(recent))):
                    self._log(f"⚠ Verify borç trendi artıyor: {[f'{r*100:.0f}%' for r in recent]}")
        except Exception as e:
            self._log(f"Verify trend hatası: {e}")

    # ── TICKET-006: Buharlaşma ──

    def _run_evaporation(self):
        """30 gündür kullanılmamış + fitness < 0.5 → arşivle."""
        try:
            import yaml
            from core.fitness import all_fitness
            archive_dir = Path(__file__).parent.parent / ".cont" / "hive" / "archive"

            results = all_fitness()
            now = datetime.now()
            evaporated = 0

            for r in results:
                if r["fitness"] >= 0.5 or r["fitness"] == 0:
                    continue  # Sağlıklı veya untested — dokunma

                # Son kullanım zamanını kontrol et (dosya modification time)
                recipe_path = Path(r["path"])
                if not recipe_path.exists():
                    continue
                mtime = datetime.fromtimestamp(recipe_path.stat().st_mtime)
                age_days = (now - mtime).days

                if age_days >= 30:
                    # Arşivle
                    archive_dir.mkdir(parents=True, exist_ok=True)
                    dest = archive_dir / recipe_path.name
                    recipe_path.rename(dest)
                    evaporated += 1
                    self._log(f"Buharlaşma: {r['name']} (fitness={r['fitness']}, {age_days} gün)")

            if evaporated:
                self._dashboard["evaporated"] = evaporated
                self._log(f"Buharlaşma: {evaporated} reçete arşivlendi")
            else:
                self._log("Buharlaşma: arşivlenecek reçete yok")
        except Exception as e:
            self._log(f"Buharlaşma hatası: {e}")

    # ── EWS proje kontrolleri ──

    def _check_ews_drift(self):
        """EWS notebook drift kontrolü."""
        try:
            from core.rpc import rpc_check_notebook_sync
            ews_dir = str(Path.home() / "projects" / "ews_v511" / "ews_dashboard")
            if not Path(ews_dir).exists():
                return
            result = rpc_check_notebook_sync(ews_dir)
            drift = result.get("count", 0)
            self._dashboard["ews_notebook_drift"] = drift
            if drift > 0:
                self._log(f"EWS: {drift} notebook drift")
        except Exception as e:
            self._log(f"EWS drift: {e}")

    # ── Guardian self-test (periyodik) ──

    def _run_guardian_self_test(self):
        """Guardian'ın kendi bağışıklık testi — kasıtlı ihlal + tespit kontrol."""
        import tempfile
        try:
            from core.guardian import check_knowledge_bypass
            tmp = Path(tempfile.mkdtemp(prefix="guardian_selftest_"))

            # Kasıtlı ihlal: knowledge bypass pattern
            test_file = tmp / "fake_bypass.py"
            test_file.write_text(
                '_TASK_VERBS = {\n'
                '    "çek", "yaz", "getir", "listele", "bul", "indir",\n'
                '    "oku", "parse", "kaydet", "oluştur", "üret", "tara",\n'
                '}\n'
            )

            # Not: check_knowledge_bypass sadece core/*.py tarar,
            # bu dosya tmp'de olduğu için doğrudan test edemeyiz.
            # Bunun yerine guardian'ın çalıştığını ve hata vermediğini kontrol ederiz.
            passed, viols = check_knowledge_bypass()

            # Temizlik
            test_file.unlink()
            tmp.rmdir()

            self._dashboard["guardian_self_test"] = "pass"
            self._log("Guardian self-test: ✓ çalıştı")
        except Exception as e:
            self._dashboard["guardian_self_test"] = f"fail: {e}"
            self._log(f"Guardian self-test hatası: {e}")

    # ── Feromon sağlık raporu (periyodik) ──

    def _run_health_report(self):
        """Feromon trail'den sağlık metrikleri çıkar."""
        try:
            from core.fitness import all_fitness
            results = all_fitness()

            high = [r for r in results if r["fitness"] >= 0.9]
            low = [r for r in results if 0 < r["fitness"] < 0.5]
            untested = [r for r in results if r["fitness"] == 0]
            total = len(results)

            self._dashboard["health"] = {
                "total_recipes": total,
                "high_fitness": len(high),
                "low_fitness": len(low),
                "untested": len(untested),
            }

            summary = (
                f"Sağlık: {total} reçete, "
                f"{len(high)} güvenilir, {len(low)} düşük, {len(untested)} test edilmemiş"
            )
            self._log(summary)

            if low:
                self._log(f"  Düşük fitness: {', '.join(r['name'] for r in low[:5])}")
        except Exception as e:
            self._log(f"Sağlık raporu hatası: {e}")

    # ── Golden test (günlük) ──

    def _run_golden_test(self):
        """Golden test (deterministik) — feedback + SQL guard."""
        try:
            from core.golden_test_runner import run_feedback_golden, run_sql_guard_golden
            fb = run_feedback_golden()
            sg = run_sql_guard_golden()
            all_ok = fb["all_ok"] and sg["all_ok"]
            self._dashboard["golden_test"] = f"{'pass' if all_ok else 'fail'} ({fb['passed']}/{fb['total']}+{sg['passed']}/{sg['total']})"
            if not all_ok:
                from core.guardian import write_warnings, GuardianReport
                report = GuardianReport()
                if not fb["all_ok"]:
                    report.add_violation("golden_test", f"Feedback golden test: {fb['passed']}/{fb['total']}")
                if not sg["all_ok"]:
                    report.add_violation("golden_test", f"SQL guard golden test: {sg['passed']}/{sg['total']}")
                write_warnings(report)
                self._log(f"Golden test FAIL: feedback={fb['passed']}/{fb['total']}, sql={sg['passed']}/{sg['total']}")
            else:
                self._log("Golden test: ✓ pass")
        except Exception as e:
            self._log(f"Golden test hatası: {e}")

    # ── Session entegrasyonu ──

    def notify_session_start(self):
        """cont session başlatınca çağrılır."""
        self.enter_awake()

    def notify_session_end(self):
        """cont session bitince çağrılır."""
        self.enter_idle()

    # ── Hoş geldin raporu ──

    def _save_state(self):
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps({
            "state": self.state,
            "ts": datetime.now().isoformat(),
            "pid": os.getpid(),
            "dashboard": self._dashboard,
        }))

    # ── Yardımcılar ──

    def _save_pid(self):
        PID_FILE.parent.mkdir(parents=True, exist_ok=True)
        PID_FILE.write_text(str(os.getpid()))

    def _cleanup(self):
        PID_FILE.unlink(missing_ok=True)
        self._log("Daemon durdu")

    def _handle_stop(self, sig, frame):
        self._stop.set()

    def _log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {msg}"
        print(line, flush=True)
        # Pheromone'a da yaz
        try:
            trail = Path(__file__).parent.parent / ".cont" / "hive" / "pheromone" / "trail.jsonl"
            trail.parent.mkdir(parents=True, exist_ok=True)
            with open(trail, "a") as f:
                f.write(json.dumps({"ts": datetime.now().isoformat(),
                                    "task": f"daemon:{msg[:80]}", "success": True,
                                    "tools": [], "tool_count": 0, "elapsed": 0}) + "\n")
        except Exception:
            pass


# ── CLI fonksiyonları ──

def show_welcome():
    """Session açılışında hoş geldin raporu göster."""
    if not STATE_FILE.exists():
        return  # Daemon çalışmıyor
    try:
        data = json.loads(STATE_FILE.read_text())
        dash = data.get("dashboard", {})
        last_ts = data.get("ts", "")

        # Son session ne zaman
        since = ""
        if last_ts:
            dt = datetime.fromisoformat(last_ts)
            delta = datetime.now() - dt
            hours = delta.total_seconds() / 3600
            since = f"{hours:.0f} saat önce" if hours >= 1 else f"{delta.total_seconds()/60:.0f} dk önce"

        # Guardian uyarıları
        guardian_n = dash.get("guardian_violations", 0)
        inbox_n = dash.get("inbox_count", 0)
        gpu = dash.get("gpu_temp", -1)
        model = dash.get("model_ok", False)

        lines = [f"[dim]Son durum ({since}):[/dim]"]
        if guardian_n:
            lines.append(f"  ⚠ {guardian_n} guardian uyarısı")
        if inbox_n:
            lines.append(f"  📦 {inbox_n} inbox reçetesi")
        if gpu >= 0:
            lines.append(f"  💚 GPU: {gpu}°C, model {'sıcak' if model else 'kapalı'}")

        if len(lines) > 1:
            from rich import print as rprint
            for l in lines:
                rprint(l)
    except Exception:
        pass


def daemon_start():
    """Daemon'u arka planda başlat."""
    status = daemon_status()
    if status.get("running"):
        print(f"Daemon zaten çalışıyor (PID {status['pid']}, {status['state']})")
        return
    # Fork
    pid = os.fork()
    if pid > 0:
        print(f"Daemon başlatıldı (PID {pid})")
        return
    # Çocuk process — daemon ol
    os.setsid()
    sys.stdin.close()
    ContDaemon().run()


def daemon_stop():
    """Daemon'u durdur."""
    if PID_FILE.exists():
        pid = int(PID_FILE.read_text().strip())
        try:
            os.kill(pid, signal.SIGTERM)
            print(f"Daemon durduruldu (PID {pid})")
        except ProcessLookupError:
            print("Daemon çalışmıyor (stale PID)")
        PID_FILE.unlink(missing_ok=True)
    else:
        print("Daemon çalışmıyor")


def daemon_status() -> dict:
    """Daemon durumu."""
    if not PID_FILE.exists():
        return {"running": False}
    pid = int(PID_FILE.read_text().strip())
    try:
        os.kill(pid, 0)
        state_data = json.loads(STATE_FILE.read_text()) if STATE_FILE.exists() else {}
        return {"running": True, "pid": pid, "state": state_data.get("state", "?"),
                "since": state_data.get("ts", "?")}
    except ProcessLookupError:
        PID_FILE.unlink(missing_ok=True)
        return {"running": False, "stale": True}


if __name__ == "__main__":
    if "--start" in sys.argv:
        daemon_start()
    elif "--stop" in sys.argv:
        daemon_stop()
    elif "--status" in sys.argv:
        s = daemon_status()
        if s.get("running"):
            print(f"Running: PID={s['pid']}, state={s['state']}, since={s['since']}")
        else:
            print("Not running")
    else:
        print(__doc__)
