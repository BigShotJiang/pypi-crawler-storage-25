#!/usr/bin/env python3
"""Data relationship discovery engine — Synthed'den daha derin kavrayış.

Synthed: FK inference (coverage + naming heuristics)
Cont:    FK + temporal + hierarchical + semantic + anomaly relationships

Usage: python3 core/relation_discovery.py <command> <args...>

Commands:
  discover <path> [--table T1,T2,...]      Full relationship discovery
  fk_candidates <path>                     Foreign key candidates
  temporal <path> --entity <col> --time <col>  Temporal patterns
  hierarchy <path>                         Hierarchical relationships
  join_graph <path>                        Join path graph (DOT format)
  profile_keys <path>                      Primary/candidate key detection
  coverage_matrix <path>                   Cross-table value coverage
  anomaly_relations <path>                 Anomalous/broken relationships
"""

import json
import sys
from collections import defaultdict
from pathlib import Path


class _NpEncoder(json.JSONEncoder):
    def default(self, obj):
        import numpy as np
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, (np.bool_,)):
            return bool(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super().default(obj)


def _dumps(obj, **kw):
    return json.dumps(obj, cls=_NpEncoder, **kw)


def _load_tables(path: str, tables: list[str] = None):
    """Load tables from DuckDB, directory of CSVs, or single file."""
    import pandas as pd

    p = Path(path)
    result = {}

    if p.suffix == ".duckdb":
        import duckdb
        con = duckdb.connect(str(p), read_only=True)
        all_tables = [t[0] for t in con.execute("SHOW TABLES").fetchall()]
        targets = tables or all_tables
        for t in targets:
            if t in all_tables:
                result[t] = con.execute(f"SELECT * FROM {t}").df()
        con.close()
    elif p.is_dir():
        for f in p.glob("*.csv"):
            result[f.stem] = pd.read_csv(f)
        for f in p.glob("*.parquet"):
            result[f.stem] = pd.read_parquet(f)
    else:
        result[p.stem] = pd.read_csv(p) if p.suffix == ".csv" else pd.read_parquet(p)

    return result


# ── 1. Candidate Key Detection ──

def cmd_profile_keys(path: str, tables: list[str] = None):
    """Detect primary key candidates per table."""
    dfs = _load_tables(path, tables)
    result = {}

    for name, df in dfs.items():
        candidates = []
        for col in df.columns:
            nunique = df[col].nunique()
            null_count = int(df[col].isnull().sum())
            total = len(df)

            is_unique = nunique == total - null_count
            is_complete = null_count == 0

            if is_unique and is_complete:
                candidates.append({
                    "column": col,
                    "type": "primary_key",
                    "cardinality": nunique,
                })
            elif is_unique and null_count < total * 0.01:
                candidates.append({
                    "column": col,
                    "type": "candidate_key",
                    "cardinality": nunique,
                    "null_ratio": round(null_count / total, 4),
                })

        result[name] = {
            "rows": len(df),
            "columns": len(df.columns),
            "candidate_keys": candidates,
        }

    print(_dumps(result, indent=2))


# ── 2. FK Candidate Detection (enhanced) ──

def cmd_fk_candidates(path: str, tables: list[str] = None):
    """Detect foreign key candidates with multi-strategy scoring."""
    dfs = _load_tables(path, tables)

    # Step 1: Find PKs
    pk_map = {}
    for name, df in dfs.items():
        for col in df.columns:
            if df[col].nunique() == len(df) and df[col].isnull().sum() == 0:
                pk_map.setdefault(name, []).append(col)

    # Step 2: Cross-table coverage
    candidates = []
    for child_name, child_df in dfs.items():
        for child_col in child_df.columns:
            child_vals = set(child_df[child_col].dropna().unique())
            if len(child_vals) == 0 or len(child_vals) == len(child_df):
                continue  # Skip PKs and empty cols

            for parent_name, parent_pks in pk_map.items():
                if parent_name == child_name:
                    continue
                for parent_col in parent_pks:
                    parent_vals = set(dfs[parent_name][parent_col].dropna().unique())
                    overlap = child_vals & parent_vals
                    coverage = len(overlap) / len(child_vals) if child_vals else 0

                    if coverage < 0.5:
                        continue

                    # Name scoring
                    name_score = _name_similarity(child_col, parent_col, parent_name)

                    # Type compatibility
                    type_compat = _type_compatible(child_df[child_col], dfs[parent_name][parent_col])

                    # Cardinality ratio (many-to-one indicator)
                    card_ratio = len(child_vals) / len(parent_vals) if parent_vals else 0

                    # Combined confidence
                    confidence = (
                        coverage * 0.4
                        + name_score * 0.3
                        + (1.0 if type_compat else 0.0) * 0.2
                        + min(card_ratio, 1.0) * 0.1
                    )

                    if confidence >= 0.5:
                        candidates.append({
                            "child_table": child_name,
                            "child_column": child_col,
                            "parent_table": parent_name,
                            "parent_column": parent_col,
                            "coverage": round(coverage, 4),
                            "name_score": round(name_score, 4),
                            "type_compatible": type_compat,
                            "cardinality_ratio": round(card_ratio, 4),
                            "confidence": round(confidence, 4),
                            "relationship_type": _infer_rel_type(coverage, card_ratio),
                        })

    candidates.sort(key=lambda x: -x["confidence"])
    print(_dumps({"candidates": candidates, "count": len(candidates)}, indent=2))


def _name_similarity(child_col: str, parent_col: str, parent_table: str) -> float:
    """Score FK likelihood from naming conventions."""
    cc, pc, pt = child_col.lower(), parent_col.lower(), parent_table.lower()

    # Turkish conventions
    if cc == pc:
        return 0.8
    if cc in (f"{pt}_id", f"{pt}id", f"{pt}_no", f"{pt}_kod"):
        return 1.0
    if cc.endswith("_id") and pc in ("id", "entity_id"):
        prefix = cc[:-3]
        if pt.startswith(prefix) or prefix in pt:
            return 0.9
    # Partial match
    if pc in cc or cc in pc:
        return 0.5
    # muta convention (EWS-specific but generalizable)
    if cc == "muta" and pc in ("muta", "entity_id"):
        return 0.95
    return 0.0


def _type_compatible(s1, s2) -> bool:
    """Check if two series have compatible types."""
    import pandas as pd
    t1 = "numeric" if pd.api.types.is_numeric_dtype(s1) else "text"
    t2 = "numeric" if pd.api.types.is_numeric_dtype(s2) else "text"
    return t1 == t2


def _infer_rel_type(coverage: float, card_ratio: float) -> str:
    """Infer relationship type from coverage and cardinality."""
    if coverage > 0.95 and card_ratio <= 1.0:
        return "many-to-one"
    if coverage > 0.95 and card_ratio > 1.0:
        return "one-to-one"
    if coverage < 0.95 and coverage > 0.5:
        return "partial-FK"
    return "weak-association"


# ── 3. Temporal Relationship Detection ──

def cmd_temporal(path: str, entity_col: str, time_col: str, tables: list[str] = None):
    """Detect temporal patterns in entity-time data."""
    dfs = _load_tables(path, tables)

    result = {}
    for name, df in dfs.items():
        if entity_col not in df.columns or time_col not in df.columns:
            continue

        g = df.groupby(entity_col)
        periods_per_entity = g[time_col].nunique()

        result[name] = {
            "entities": int(df[entity_col].nunique()),
            "periods": int(df[time_col].nunique()),
            "rows": len(df),
            "density": round(len(df) / (df[entity_col].nunique() * df[time_col].nunique()), 4),
            "periods_per_entity": {
                "min": int(periods_per_entity.min()),
                "max": int(periods_per_entity.max()),
                "mean": round(float(periods_per_entity.mean()), 2),
                "median": round(float(periods_per_entity.median()), 2),
            },
            "is_panel": periods_per_entity.min() > 1,
            "is_balanced": periods_per_entity.nunique() == 1,
            "grain": f"({entity_col}, {time_col})",
        }

    print(_dumps(result, indent=2))


# ── 4. Hierarchical Relationship Detection ──

def cmd_hierarchy(path: str, tables: list[str] = None):
    """Detect hierarchical (parent-child within same table) relationships."""
    dfs = _load_tables(path, tables)
    result = {}

    for name, df in dfs.items():
        id_cols = [c for c in df.columns if c.lower().endswith("_id") or c.lower() in ("id", "kod", "kodu")]
        hierarchies = []

        for col in df.columns:
            if col.lower().startswith("parent_") or col.lower().startswith("ust_"):
                ref_col = col.lower().replace("parent_", "").replace("ust_", "")
                matching = [c for c in id_cols if ref_col in c.lower()]
                if matching:
                    hierarchies.append({
                        "child_column": matching[0],
                        "parent_column": col,
                        "type": "self-referencing",
                    })

        # Detect implicit hierarchy: bolge → sube (region → branch)
        code_cols = [c for c in df.columns if c.lower().endswith("_kodu") or c.lower().endswith("_kod")]
        if len(code_cols) >= 2:
            for i, c1 in enumerate(code_cols):
                for c2 in code_cols[i+1:]:
                    card1 = df[c1].nunique()
                    card2 = df[c2].nunique()
                    if card1 < card2 and card2 / card1 > 2:
                        hierarchies.append({
                            "parent_column": c1,
                            "child_column": c2,
                            "type": "implicit-hierarchy",
                            "parent_cardinality": int(card1),
                            "child_cardinality": int(card2),
                            "ratio": round(card2 / card1, 2),
                        })

        if hierarchies:
            result[name] = hierarchies

    print(_dumps(result, indent=2))


# ── 5. Coverage Matrix ──

def cmd_coverage_matrix(path: str, tables: list[str] = None):
    """Cross-table value coverage heatmap data."""
    dfs = _load_tables(path, tables)
    matrix = []

    table_names = list(dfs.keys())
    for i, t1 in enumerate(table_names):
        for j, t2 in enumerate(table_names):
            if i >= j:
                continue
            # Find shared column names
            shared = set(dfs[t1].columns) & set(dfs[t2].columns)
            for col in shared:
                vals1 = set(dfs[t1][col].dropna().unique())
                vals2 = set(dfs[t2][col].dropna().unique())
                if not vals1 or not vals2:
                    continue
                overlap = vals1 & vals2
                cov_1_in_2 = len(overlap) / len(vals1)
                cov_2_in_1 = len(overlap) / len(vals2)
                matrix.append({
                    "table_a": t1, "table_b": t2, "column": col,
                    "a_in_b": round(cov_1_in_2, 4),
                    "b_in_a": round(cov_2_in_1, 4),
                    "overlap_count": len(overlap),
                })

    matrix.sort(key=lambda x: -max(x["a_in_b"], x["b_in_a"]))
    print(_dumps({"coverage": matrix}, indent=2))


# ── 6. Join Path Graph ──

def cmd_join_graph(path: str, tables: list[str] = None):
    """Generate join path graph from discovered relationships."""
    import io
    dfs = _load_tables(path, tables)

    # Quick FK scan
    pk_map = {}
    for name, df in dfs.items():
        for col in df.columns:
            if df[col].nunique() == len(df) and df[col].isnull().sum() == 0:
                pk_map.setdefault(name, []).append(col)

    edges = []
    for child_name, child_df in dfs.items():
        for child_col in child_df.columns:
            child_vals = set(child_df[child_col].dropna().unique())
            if not child_vals or len(child_vals) == len(child_df):
                continue
            for parent_name, parent_pks in pk_map.items():
                if parent_name == child_name:
                    continue
                for parent_col in parent_pks:
                    parent_vals = set(dfs[parent_name][parent_col].dropna().unique())
                    coverage = len(child_vals & parent_vals) / len(child_vals) if child_vals else 0
                    if coverage > 0.7:
                        edges.append({
                            "from": child_name, "to": parent_name,
                            "via": f"{child_col} → {parent_col}",
                            "coverage": round(coverage, 4),
                        })

    # DOT format
    dot = ["digraph DataRelations {", "  rankdir=LR;"]
    for t in dfs:
        dot.append(f'  "{t}" [shape=box];')
    for e in edges:
        dot.append(f'  "{e["from"]}" -> "{e["to"]}" [label="{e["via"]}\\n{e["coverage"]}"];')
    dot.append("}")

    print(_dumps({"edges": edges, "dot": "\n".join(dot)}, indent=2))


# ── 7. Anomalous Relationships ──

def cmd_anomaly_relations(path: str, tables: list[str] = None):
    """Detect broken or anomalous relationships."""
    dfs = _load_tables(path, tables)
    anomalies = []

    # Detect orphan records (child values not in parent)
    pk_map = {}
    for name, df in dfs.items():
        for col in df.columns:
            if df[col].nunique() == len(df) and df[col].isnull().sum() == 0:
                pk_map.setdefault(name, []).append(col)

    for child_name, child_df in dfs.items():
        for child_col in child_df.columns:
            for parent_name, parent_pks in pk_map.items():
                if parent_name == child_name:
                    continue
                for parent_col in parent_pks:
                    # Check naming convention
                    if _name_similarity(child_col, parent_col, parent_name) < 0.5:
                        continue

                    child_vals = set(child_df[child_col].dropna().unique())
                    parent_vals = set(dfs[parent_name][parent_col].dropna().unique())
                    orphans = child_vals - parent_vals

                    if orphans and len(orphans) < len(child_vals):
                        orphan_ratio = len(orphans) / len(child_vals)
                        if orphan_ratio > 0.01:
                            anomalies.append({
                                "type": "orphan_records",
                                "child_table": child_name,
                                "child_column": child_col,
                                "parent_table": parent_name,
                                "parent_column": parent_col,
                                "orphan_count": len(orphans),
                                "orphan_ratio": round(orphan_ratio, 4),
                                "severity": "high" if orphan_ratio > 0.1 else "medium",
                            })

    print(_dumps({"anomalies": anomalies, "count": len(anomalies)}, indent=2))


# ── Full Discovery ──

def cmd_discover(path: str, tables: list[str] = None):
    """Full relationship discovery — combines all strategies."""
    import io
    from contextlib import redirect_stdout

    results = {}

    # Run each analysis, capture output
    for cmd_name, cmd_fn, args in [
        ("keys", cmd_profile_keys, (path, tables)),
        ("fk_candidates", cmd_fk_candidates, (path, tables)),
        ("hierarchy", cmd_hierarchy, (path, tables)),
        ("coverage", cmd_coverage_matrix, (path, tables)),
        ("anomalies", cmd_anomaly_relations, (path, tables)),
    ]:
        f = io.StringIO()
        try:
            with redirect_stdout(f):
                cmd_fn(*args)
            results[cmd_name] = json.loads(f.getvalue())
        except Exception as e:
            results[cmd_name] = {"error": str(e)}

    print(_dumps(results, indent=2))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1]
    tables = None
    entity_col = time_col = None
    args = []
    i = 2
    while i < len(sys.argv):
        if sys.argv[i] == "--table" and i + 1 < len(sys.argv):
            tables = sys.argv[i + 1].split(","); i += 2
        elif sys.argv[i] == "--entity" and i + 1 < len(sys.argv):
            entity_col = sys.argv[i + 1]; i += 2
        elif sys.argv[i] == "--time" and i + 1 < len(sys.argv):
            time_col = sys.argv[i + 1]; i += 2
        else:
            args.append(sys.argv[i]); i += 1

    commands = {
        "discover": lambda: cmd_discover(args[0], tables),
        "fk_candidates": lambda: cmd_fk_candidates(args[0], tables),
        "temporal": lambda: cmd_temporal(args[0], entity_col, time_col, tables),
        "hierarchy": lambda: cmd_hierarchy(args[0], tables),
        "join_graph": lambda: cmd_join_graph(args[0], tables),
        "profile_keys": lambda: cmd_profile_keys(args[0], tables),
        "coverage_matrix": lambda: cmd_coverage_matrix(args[0], tables),
        "anomaly_relations": lambda: cmd_anomaly_relations(args[0], tables),
    }

    if cmd not in commands:
        print(f"Unknown: {cmd}"); sys.exit(1)
    commands[cmd]()
