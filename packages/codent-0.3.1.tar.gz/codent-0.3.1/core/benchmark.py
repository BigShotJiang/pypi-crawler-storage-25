#!/usr/bin/env python3
"""Local LLM model shootout — 10 model, 10 test, kalite puanlama.

Kullanım: python3 core/benchmark.py [--quick]
  --quick: sadece ciddi yarışmacılar (ilk 6 model)

Çıktı:
  .cont/hive/runs/model_benchmark_<timestamp>.json
  model_benchmark_report.md
"""

import json
import re
import subprocess
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path

# ── Config ──

LMS_PORT = 1234
CONTEXT_LENGTH = 10000
API_TIMEOUT = 180  # 3 dakika per test

TOOLS_SCHEMA = [
    {"type": "function", "function": {
        "name": "run_shell", "description": "Execute a shell command and return output",
        "parameters": {"type": "object", "properties": {"command": {"type": "string", "description": "Shell command"}}, "required": ["command"]}}},
    {"type": "function", "function": {
        "name": "read_file", "description": "Read a file and return its content",
        "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "File path"}}, "required": ["path"]}}},
    {"type": "function", "function": {
        "name": "search_files", "description": "Search for pattern in files",
        "parameters": {"type": "object", "properties": {"pattern": {"type": "string"}, "path": {"type": "string", "description": "Directory to search"}}, "required": ["pattern"]}}},
]

MODELS_SERIOUS = [
    {"id": "qwen/qwen3-coder-30b",                "label": "QC-30B Q4_K_M",     "tier": "serious"},
    {"id": "unsloth/qwen3-coder-next",             "label": "QCN-80B IQ1_M",     "tier": "serious"},
    {"id": "mistralai/devstral-small-2-2512",      "label": "Devstral-24B Q4",   "tier": "serious"},
    {"id": "openai/gpt-oss-20b",                   "label": "GPT-OSS-20B MXFP4", "tier": "serious"},
    {"id": "nvidia/nemotron-3-nano",               "label": "Nemotron-30B Q3",   "tier": "serious"},
    {"id": "zai-org/glm-4.6v-flash",               "label": "GLM-4.6v Q8",      "tier": "serious"},
]

MODELS_MID = [
    {"id": "google/gemma-3n-e4b",                             "label": "Gemma-3n Q8",      "tier": "mid"},
    {"id": "meta-llama-3.1-8b-instruct",                      "label": "Llama-3.1-8B Q8",  "tier": "mid"},
    {"id": "qwen3-8b-claude-sonnet-4-reasoning-distill",      "label": "Qwen3-8B-Claude",  "tier": "mid"},
    {"id": "claude-3.7-sonnet-reasoning-gemma3-12b",          "label": "Claude-Gemma-12B", "tier": "mid"},
]

# ── 10 Test ──

TESTS = [
    # Alan 1: Tool calling
    {
        "id": "T1", "name": "Basit tool call", "area": "tool",
        "messages": [{"role": "user", "content": "cont.py dosyasındaki toplam satır sayısını bul"}],
        "tools": True,
        "check_tool": lambda tc: any("run_shell" in str(t) for t in tc),
        "check_output": lambda r: any(c.isdigit() for c in r),
        "max_score": {"tool": 5, "output": 5, "turkish": 5, "reasoning": 5},
    },
    {
        "id": "T2", "name": "Çoklu tool call", "area": "tool",
        "messages": [{"role": "user", "content":
            "core/ altındaki Python dosyalarını listele, her birinin satır sayısını göster, en büyük 3'ünü raporla"}],
        "tools": True,
        "check_tool": lambda tc: len(tc) >= 1,
        "check_output": lambda r: any(w in r.lower() for w in [".py", "satır", "line", "büyük", "largest"]),
        "max_score": {"tool": 5, "output": 5, "turkish": 5, "reasoning": 5},
    },
    {
        "id": "T3", "name": "Tool call zinciri", "area": "tool",
        "messages": [{"role": "user", "content":
            "fact_periodic tablosundaki null oranlarını hesapla ve %50'den fazla null olan kolonları listele"}],
        "tools": True,
        "check_tool": lambda tc: len(tc) >= 1,
        "check_output": lambda r: any(w in r.lower() for w in ["null", "oran", "ratio", "kolon", "column", "%"]),
        "max_score": {"tool": 5, "output": 5, "turkish": 5, "reasoning": 5},
    },
    # Alan 2: SQL
    {
        "id": "S1", "name": "Basit SQL", "area": "sql",
        "messages": [{"role": "user", "content": "EWS veritabanında kaç farklı firma var?"}],
        "tools": True,
        "check_tool": lambda tc: True,
        "check_output": lambda r: any(w in r.upper() for w in ["SELECT", "COUNT", "DISTINCT", "ENTITY"]),
        "max_score": {"tool": 5, "output": 5, "turkish": 5, "reasoning": 5},
    },
    {
        "id": "S2", "name": "Join + aggregation", "area": "sql",
        "messages": [{"role": "user", "content":
            "Her bölgedeki ortalama EWS skoru nedir? En riskli bölgeyi bul"}],
        "tools": True,
        "check_tool": lambda tc: True,
        "check_output": lambda r: any(w in r.upper() for w in ["AVG", "GROUP", "ORDER", "BÖLGE", "RISK"]),
        "max_score": {"tool": 5, "output": 5, "turkish": 5, "reasoning": 5},
    },
    # Alan 3: Analiz
    {
        "id": "A1", "name": "Veri yorumlama", "area": "analysis",
        "messages": [{"role": "user", "content":
            "fact_periodic tablosunun genel sağlık durumunu değerlendir"}],
        "tools": True,
        "check_tool": lambda tc: True,
        "check_output": lambda r: any(w in r.lower() for w in ["sağlık", "health", "null", "satır", "row", "kolon", "istatistik"]),
        "max_score": {"tool": 5, "output": 5, "turkish": 5, "reasoning": 5},
    },
    {
        "id": "A2", "name": "Anomali bulma", "area": "analysis",
        "messages": [{"role": "user", "content":
            "Son dönemde skoru en çok değişen 5 firmayı bul ve nedenini açıkla"}],
        "tools": True,
        "check_tool": lambda tc: True,
        "check_output": lambda r: any(w in r.lower() for w in ["firma", "skor", "score", "değişim", "change", "neden"]),
        "max_score": {"tool": 5, "output": 5, "turkish": 5, "reasoning": 5},
    },
    # Alan 4: Türkçe anlama
    {
        "id": "B1", "name": "Türkçe domain", "area": "turkish",
        "messages": [{"role": "user", "content":
            "Yakın izleme flag'i aktif olan firmaların sektör dağılımını çıkar"}],
        "tools": True,
        "check_tool": lambda tc: True,
        "check_output": lambda r: any(w in r.lower() for w in ["izleme", "sektör", "dağılım", "flag", "sector", "watch"]),
        "max_score": {"tool": 5, "output": 5, "turkish": 5, "reasoning": 5},
    },
    {
        "id": "B2", "name": "Belirsiz görev", "area": "turkish",
        "messages": [{"role": "user", "content": "veriyi incele"}],
        "tools": True,
        "check_tool": lambda tc: True,
        "check_output": lambda r: len(r) > 50,  # Anlamlı bir cevap verdi mi
        "max_score": {"tool": 5, "output": 5, "turkish": 5, "reasoning": 5},
    },
    # Alan 5: Çok adımlı reasoning
    {
        "id": "R1", "name": "Çok adımlı pipeline", "area": "reasoning",
        "messages": [{"role": "user", "content":
            "Veriyi temizle, en önemli 5 feature'ı bul, basit bir model eğit ve F1 raporla"}],
        "tools": True,
        "check_tool": lambda tc: True,
        "check_output": lambda r: any(w in r.lower() for w in ["f1", "feature", "model", "temizle", "clean", "train", "önem"]),
        "max_score": {"tool": 5, "output": 5, "turkish": 5, "reasoning": 5},
    },
]


# ── API helpers ──

def get_gateway() -> str:
    r = subprocess.run(["ip", "route", "show", "default"], capture_output=True, text=True, timeout=5)
    return r.stdout.split()[2]


def lms_api(gw: str, method: str, path: str, data: dict = None, timeout: int = 30) -> dict:
    url = f"http://{gw}:{LMS_PORT}{path}"
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=body, method=method)
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"error": str(e)}


def eject_all(gw: str):
    models = lms_api(gw, "GET", "/api/v0/models")
    if "error" in models:
        return
    for m in models.get("data", []):
        if m.get("state") == "loaded":
            print(f"    eject {m['id']}...")
            lms_api(gw, "POST", "/api/v1/models/unload",
                    {"instance_id": m["id"]}, timeout=30)
            time.sleep(2)


def load_model(gw: str, model_id: str) -> tuple[float, dict]:
    t0 = time.time()
    result = lms_api(gw, "POST", "/api/v1/models/load",
                     {"model": model_id, "context_length": CONTEXT_LENGTH},
                     timeout=600)
    load_time = time.time() - t0
    if "error" in result:
        return load_time, {"error": result["error"]}
    return load_time, {"status": "loaded", "load_time_api": result.get("load_time_seconds", 0)}


def chat(gw: str, model_id: str, messages: list, tools: list = None) -> tuple[float, str, list, dict]:
    """Returns (elapsed, text, tool_calls, usage)."""
    body = {
        "model": model_id,
        "messages": messages,
        "max_tokens": 1024,
        "temperature": 0.1,
    }
    if tools:
        body["tools"] = tools

    t0 = time.time()
    result = lms_api(gw, "POST", "/v1/chat/completions", body, timeout=API_TIMEOUT)
    elapsed = time.time() - t0

    if "error" in result:
        return elapsed, f"ERROR: {result['error']}", [], {}

    choice = result.get("choices", [{}])[0]
    msg = choice.get("message", {})
    text = msg.get("content", "") or ""
    tool_calls = msg.get("tool_calls", [])
    usage = result.get("usage", {})

    return elapsed, text, tool_calls, usage


# ── Scoring ──

def auto_score(test: dict, text: str, tool_calls: list, elapsed: float) -> dict:
    """Otomatik puanlama — heuristic bazlı."""
    scores = {}

    # Tool accuracy (0-5)
    if test.get("tools"):
        tc_data = [json.dumps(tc) for tc in tool_calls]
        if tool_calls and test["check_tool"](tc_data):
            # Tool call var ve doğru
            if len(tool_calls) <= 2:
                scores["tool"] = 5  # Verimli
            elif len(tool_calls) <= 4:
                scores["tool"] = 4
            else:
                scores["tool"] = 3  # Çok fazla tool call
        elif tool_calls:
            scores["tool"] = 2  # Tool call var ama yanlış
        elif test["check_output"](text):
            scores["tool"] = 3  # Tool kullanmadı ama cevap doğru
        else:
            scores["tool"] = 0
    else:
        scores["tool"] = None

    # Output quality (0-5)
    if "ERROR" in text or "TIMEOUT" in text:
        scores["output"] = 0
    elif test["check_output"](text):
        text_len = len(text)
        if text_len > 200:
            scores["output"] = 5  # Detaylı ve doğru
        elif text_len > 50:
            scores["output"] = 4  # Kısa ama doğru
        else:
            scores["output"] = 3  # Çok kısa
    else:
        # Check partial match
        scores["output"] = 1 if len(text) > 30 else 0

    # Turkish quality (0-5)
    tr_chars = sum(1 for c in text if c in "çğıöşüÇĞİÖŞÜ")
    tr_words = sum(1 for w in ["bir", "için", "olan", "ile", "var", "ama", "veya"]
                   if f" {w} " in f" {text.lower()} ")
    if tr_chars > 10 and tr_words > 3:
        scores["turkish"] = 5
    elif tr_chars > 5 or tr_words > 1:
        scores["turkish"] = 4
    elif tr_chars > 0:
        scores["turkish"] = 3
    elif text and any(w in text.lower() for w in ["the", "this", "that", "which"]):
        scores["turkish"] = 2  # İngilizce cevap
    else:
        scores["turkish"] = 1 if text else 0

    # Reasoning depth (0-5)
    steps = len(re.findall(r'(?:^\d+[\.\)]|^-\s|^\*\s|^#{1,3}\s)', text, re.MULTILINE))
    if steps >= 4:
        scores["reasoning"] = 5
    elif steps >= 2:
        scores["reasoning"] = 4
    elif len(text) > 300:
        scores["reasoning"] = 3
    elif len(text) > 100:
        scores["reasoning"] = 2
    else:
        scores["reasoning"] = 1 if text else 0

    scores["speed"] = round(elapsed, 1)
    return scores


# ── Main ──

def run_shootout(quick: bool = False):
    gw = get_gateway()
    models = MODELS_SERIOUS + ([] if quick else MODELS_MID)

    print(f"Gateway: {gw}")
    print(f"Context: {CONTEXT_LENGTH}, Timeout: {API_TIMEOUT}s")
    print(f"Modeller: {len(models)}, Testler: {len(TESTS)}")
    print("=" * 70)

    all_results = {}

    for mi, model in enumerate(models):
        model_id = model["id"]
        label = model["label"]
        print(f"\n{'═' * 70}")
        print(f"[{mi+1}/{len(models)}] {label} ({model_id})")
        print(f"{'═' * 70}")

        # Eject → Load
        print("  Eject all...")
        eject_all(gw)
        time.sleep(3)

        print(f"  Loading {model_id}...")
        load_time, load_info = load_model(gw, model_id)
        if "error" in load_info:
            print(f"  ✗ YÜKLEME HATASI: {load_info['error']}")
            all_results[model_id] = {"label": label, "tier": model["tier"],
                                      "error": str(load_info["error"]), "load_time": round(load_time, 1)}
            continue

        print(f"  ✓ Yüklendi ({load_time:.1f}s)")
        time.sleep(3)  # warm-up

        model_result = {
            "label": label, "tier": model["tier"],
            "load_time": round(load_time, 1),
            "tests": {},
        }

        for test in TESTS:
            tid = test["id"]
            tname = test["name"]
            print(f"\n  {tid}: {tname}")

            tools = TOOLS_SCHEMA if test.get("tools") else None
            elapsed, text, tool_calls, usage = chat(gw, model_id, test["messages"], tools)

            scores = auto_score(test, text, tool_calls, elapsed)

            # Log
            tc_summary = [f"{tc.get('function',{}).get('name','')}(...)" for tc in tool_calls]
            short = text[:100].replace("\n", " ") if text else "(boş)"
            print(f"    {elapsed:.1f}s | tool={scores.get('tool','–')} out={scores['output']} "
                  f"tr={scores['turkish']} reas={scores['reasoning']}")
            print(f"    TC: {tc_summary[:3] if tc_summary else '–'}")
            print(f"    → {short}...")

            model_result["tests"][tid] = {
                "name": tname,
                "area": test["area"],
                "elapsed": round(elapsed, 2),
                "scores": scores,
                "response": text[:2000],
                "tool_calls": [{"name": tc.get("function", {}).get("name", ""),
                                "args": tc.get("function", {}).get("arguments", "")}
                               for tc in tool_calls],
                "usage": usage,
            }
            time.sleep(1)

        # Aggregate scores
        tests = model_result["tests"]
        area_scores = {}
        for tid, t in tests.items():
            area = t["area"]
            if area not in area_scores:
                area_scores[area] = {"tool": 0, "output": 0, "turkish": 0, "reasoning": 0, "count": 0}
            for dim in ["tool", "output", "turkish", "reasoning"]:
                v = t["scores"].get(dim)
                if v is not None:
                    area_scores[area][dim] += v
            area_scores[area]["count"] += 1

        avg_time = sum(t["elapsed"] for t in tests.values()) / len(tests) if tests else 0
        total_score = sum(
            sum(v for k, v in t["scores"].items() if k != "speed" and v is not None)
            for t in tests.values()
        )
        max_possible = len(TESTS) * 20  # 4 dimensions × 5 max each

        model_result["summary"] = {
            "total_score": total_score,
            "max_score": max_possible,
            "pct": round(total_score / max_possible * 100, 1) if max_possible else 0,
            "avg_time": round(avg_time, 1),
            "area_scores": area_scores,
        }

        all_results[model_id] = model_result
        print(f"\n  TOPLAM: {total_score}/{max_possible} ({model_result['summary']['pct']}%) avg={avg_time:.1f}s")

    # Save JSON
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    json_path = Path(".cont/hive/runs") / f"model_benchmark_{ts}.json"
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(all_results, indent=2, ensure_ascii=False, default=str))
    print(f"\nJSON: {json_path}")

    # Generate report
    report_path = Path("model_benchmark_report.md")
    report = generate_report(all_results, models)
    report_path.write_text(report, encoding="utf-8")
    print(f"Rapor: {report_path}")

    # Print summary table
    print_summary(all_results, models)

    # Cleanup
    print("\nEject all...")
    eject_all(gw)

    return all_results


def generate_report(results: dict, models: list) -> str:
    """Markdown rapor üret."""
    lines = ["# Model Shootout Raporu", "",
             f"Tarih: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
             f"Context: {CONTEXT_LENGTH}, Timeout: {API_TIMEOUT}s", ""]

    # Bölüm 1: Özet tablo
    lines.append("## 1. Özet Tablo\n")
    valid = [m for m in models if m["id"] in results and "error" not in results[m["id"]]]

    header = "| Model | Tool /15 | SQL /10 | Analiz /10 | Türkçe /10 | Reasoning /5 | Hız | Toplam |"
    sep    = "|-------|----------|---------|------------|------------|--------------|-----|--------|"
    lines.extend([header, sep])

    for m in valid:
        r = results[m["id"]]
        tests = r.get("tests", {})
        # Area aggregation
        tool_score = sum(tests[t]["scores"].get("tool", 0) or 0 for t in ["T1","T2","T3"] if t in tests)
        sql_score = sum(tests[t]["scores"].get("output", 0) or 0 for t in ["S1","S2"] if t in tests)
        analysis_score = sum(tests[t]["scores"].get("output", 0) or 0 for t in ["A1","A2"] if t in tests)
        turkish_score = sum(tests[t]["scores"].get("turkish", 0) or 0 for t in ["B1","B2"] if t in tests)
        reasoning_score = tests.get("R1", {}).get("scores", {}).get("reasoning", 0) or 0
        avg_t = r["summary"]["avg_time"]
        total = r["summary"]["total_score"]
        lines.append(
            f"| {r['label']} | {tool_score}/15 | {sql_score}/10 | {analysis_score}/10 | "
            f"{turkish_score}/10 | {reasoning_score}/5 | {avg_t:.1f}s | **{total}** |"
        )

    # Bölüm 2: Detaylar
    lines.extend(["", "## 2. Test Detayları\n"])
    for m in valid:
        r = results[m["id"]]
        lines.append(f"### {r['label']}\n")
        lines.append(f"- Load: {r['load_time']}s | Tier: {r['tier']}")
        for tid in ["T1","T2","T3","S1","S2","A1","A2","B1","B2","R1"]:
            t = r.get("tests", {}).get(tid)
            if not t:
                continue
            s = t["scores"]
            lines.append(f"\n**{tid}: {t['name']}** ({t['elapsed']:.1f}s)")
            lines.append(f"- Tool={s.get('tool','–')} Output={s['output']} Turkish={s['turkish']} Reasoning={s['reasoning']}")
            tc = t.get("tool_calls", [])
            if tc:
                lines.append(f"- Tool calls: {', '.join(c['name'] for c in tc[:5])}")
            resp = t["response"][:500].replace("\n", " ")
            lines.append(f"- Cevap: {resp}...")
        lines.append("")

    # Bölüm 3: Alan şampiyonları
    lines.extend(["## 3. Alan Bazlı Şampiyonlar\n"])
    areas = {
        "tool": ("En iyi tool caller", ["T1","T2","T3"], "tool"),
        "sql": ("En iyi SQL", ["S1","S2"], "output"),
        "analysis": ("En iyi analist", ["A1","A2"], "output"),
        "turkish": ("En iyi Türkçe", ["B1","B2"], "turkish"),
        "speed": ("En hızlı", None, None),
    }
    for area_key, (title, test_ids, dim) in areas.items():
        if area_key == "speed":
            best = min(valid, key=lambda m: results[m["id"]]["summary"]["avg_time"])
            lines.append(f"- **{title}**: {results[best['id']]['label']} ({results[best['id']]['summary']['avg_time']:.1f}s)")
        else:
            def area_score(m):
                return sum(results[m["id"]].get("tests",{}).get(t,{}).get("scores",{}).get(dim,0) or 0 for t in test_ids)
            best = max(valid, key=area_score)
            lines.append(f"- **{title}**: {results[best['id']]['label']} ({area_score(best)} puan)")

    # Bölüm 4: Kraliçe önerisi
    lines.extend(["", "## 4. Cont Kraliçesi Önerisi\n"])
    ranked = sorted(valid, key=lambda m: (-results[m["id"]]["summary"]["total_score"],
                                            results[m["id"]]["summary"]["avg_time"]))
    if ranked:
        winner = results[ranked[0]["id"]]
        lines.append(f"**Kazanan: {winner['label']}** — {winner['summary']['total_score']}/{winner['summary']['max_score']} "
                     f"({winner['summary']['pct']}%), ort. {winner['summary']['avg_time']:.1f}s")
        if len(ranked) > 1:
            ru = results[ranked[1]["id"]]
            lines.append(f"\nRunner-up: {ru['label']} — {ru['summary']['total_score']}/{ru['summary']['max_score']}")

    failed = [m for m in models if m["id"] in results and "error" in results[m["id"]]]
    if failed:
        lines.append("\n**Yüklenemeyenler:**")
        for m in failed:
            lines.append(f"- {m['label']}: {results[m['id']]['error'][:100]}")

    lines.append(f"\n---\n*Rapor: {datetime.now().isoformat()}*")
    return "\n".join(lines)


def print_summary(results: dict, models: list):
    """Stdout'a özet tablo."""
    valid = [m for m in models if m["id"] in results and "error" not in results[m["id"]]]
    if not valid:
        print("Hiçbir model test edilemedi!")
        return

    print(f"\n{'═' * 80}")
    print(f"{'Model':20s} {'Score':>7s} {'Pct':>5s} {'Avg':>6s} {'Load':>6s} {'Tier':>8s}")
    print(f"{'─' * 20} {'─' * 7} {'─' * 5} {'─' * 6} {'─' * 6} {'─' * 8}")

    ranked = sorted(valid, key=lambda m: (-results[m["id"]]["summary"]["total_score"],
                                            results[m["id"]]["summary"]["avg_time"]))
    for i, m in enumerate(ranked):
        r = results[m["id"]]
        s = r["summary"]
        marker = " ◀ KAZANAN" if i == 0 else ""
        print(f"{r['label']:20s} {s['total_score']:>4d}/{s['max_score']:<3d} {s['pct']:>4.0f}% "
              f"{s['avg_time']:>5.1f}s {r['load_time']:>5.1f}s {r['tier']:>8s}{marker}")

    failed = [m for m in models if m["id"] in results and "error" in results[m["id"]]]
    if failed:
        print(f"\nYüklenemeyenler:")
        for m in failed:
            print(f"  ✗ {m['label']}: {results[m['id']]['error'][:80]}")
    print(f"{'═' * 80}")


if __name__ == "__main__":
    quick = "--quick" in sys.argv
    run_shootout(quick=quick)
