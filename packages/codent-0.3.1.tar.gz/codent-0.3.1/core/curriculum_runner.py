#!/usr/bin/env python3
"""Curriculum runner — 33 görev, 8 seviye, ham vs hive karşılaştırma.

Kullanım: python3 core/curriculum_runner.py [--level N] [--max-hours 8]
"""

import json
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(str(PROJECT_ROOT))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

DB = "/home/sertan/projects/ews_v511/ews_dashboard/db/ews.duckdb"
RESULTS_DIR = PROJECT_ROOT / ".cont" / "hive" / "runs" / "training"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

def T(task): return task.replace("$DB", DB)

# ═══════════════════════════════════════
# TÜM GÖREVLER
# ═══════════════════════════════════════

ALL_TASKS = {
  1: [  # KEŞIF
    {"id":"G1.1","name":"Envanter",
     "task":T("DuckDB'deki ($DB) tüm tabloları listele. Satır sayısı, kolon sayısı, tahmini MB. Katman: bronze(brz_*), silver(dim_/fact_/map_/ref_), diag(diag_*), backtest, diğer."),
     "accept":lambda r: "fact_periodic" in r and any(w in r.lower() for w in ["bronze","silver","katman","brz_"])},
    {"id":"G1.2","name":"fact_periodic Şema",
     "task":T("fact_periodic ($DB) tüm kolonlar: tip, NULL%, min/max/distinct. DESCRIBE + COUNT kullan."),
     "accept":lambda r: "entity_id" in r and any(w in r.lower() for w in ["null","varchar","bigint","double"])},
    {"id":"G1.3","name":"Dönem Yapısı",
     "task":T("fact_periodic ($DB) kaç dönem var? Her dönemde firma sayısı, ews_kaynak dağılımı (eus/yis), YI flag sayısı, ort/max risk."),
     "accept":lambda r: "donem" in r.lower() and any(w in r.lower() for w in ["eus","yis"])},
    {"id":"G1.4","name":"İlişki Haritası",
     "task":T("DuckDB ($DB) bronze→silver tablo ilişkileri, JOIN key'leri. entity_id/muta TİPLERİNİ kontrol et (VARCHAR vs BIGINT uyumsuzluğu)."),
     "accept":lambda r: any(w in r.lower() for w in ["join","muta","entity_id"]) and any(w in r.upper() for w in ["VARCHAR","BIGINT","INTEGER"])},
    {"id":"G1.5","name":"Segment Dağılımı",
     "task":T("dim_entity ($DB) segment dağılımı. Her segment: firma sayısı. Son dönem fact_periodic JOIN ile toplam/ortalama risk."),
     "accept":lambda r: any(w in r.lower() for w in ["segment","kobi","mikro","kur-tic","eskk"])},
  ],
  2: [  # KALİTE
    {"id":"G2.1","name":"Duplikasyon",
     "task":T("fact_periodic ($DB): (entity_id, donem) çifti unique mi? SQL çalıştır:\n  SELECT entity_id, donem, COUNT(*) AS cnt FROM fact_periodic GROUP BY entity_id, donem HAVING cnt > 1 LIMIT 5\nAynısını dim_entity için de yap. Sonuçları PASS/FAIL formatında raporla, duplikasyon sayısını yaz."),
     "accept":lambda r: any(w in r.lower() for w in ["duplik","unique","pass","fail","0 dup","cnt","group by"])},
    {"id":"G2.2","name":"EWS Skor Tutarlılığı",
     "task":T("fact_periodic ($DB): EWS skor iş kuralları kontrol et. 5 SQL çalıştır:\n  1. SELECT COUNT(*) FROM fact_periodic WHERE ews_kaynak='eus' AND ews_skor!='YI' AND TRY_CAST(ews_skor AS INTEGER)>500\n  2. SELECT COUNT(*) FROM fact_periodic WHERE ews_kaynak='yis' AND ews_skor!='YI' AND TRY_CAST(ews_skor AS INTEGER)<500\n  3. SELECT COUNT(*) FROM fact_periodic WHERE ykn_izl_flag=1 AND ews_skor!='YI'\n  4. SELECT COUNT(*) FROM fact_periodic WHERE ews_skor='YI' AND (ykn_izl_flag IS NULL OR ykn_izl_flag!=1)\n  5. SELECT COUNT(*) FROM fact_periodic WHERE ews_skor IS NULL AND ews_kaynak IS NOT NULL\nHer kural için ihlal sayısı ve PASS/FAIL yaz."),
     "accept":lambda r: any(w in r.lower() for w in ["ihlal","pass","fail","kural","count"]) and len(re.findall(r'\d+', r)) >= 3},
    {"id":"G2.3","name":"Kapsam Boşluk (var-yok-var)",
     "task":T("fact_periodic ($DB): EUS kapsam boşluk analizi. SQL çalıştır:\n  WITH kaynak_pivot AS (SELECT entity_id, LIST(ews_kaynak ORDER BY donem) AS kdizi FROM fact_periodic WHERE ews_kaynak IS NOT NULL GROUP BY entity_id)\n  SELECT COUNT(*) FILTER (WHERE list_contains(kdizi,'eus') AND list_contains(kdizi,'yis')) AS karisik, COUNT(*) FILTER (WHERE NOT list_contains(kdizi,'yis')) AS sadece_eus, COUNT(*) FILTER (WHERE NOT list_contains(kdizi,'eus')) AS sadece_yis FROM kaynak_pivot\nKarışık sayısı, sadece_eus, sadece_yis raporla."),
     "accept":lambda r: any(w in r.lower() for w in ["karisik","karışık","sadece_eus","sadece_yis","geçiş","switch"]) and any(c.isdigit() for c in r)},
    {"id":"G2.4","name":"Risk=0+YI Anomalisi",
     "task":T("fact_periodic ($DB): Risk=0 ama YI flag=1 anomalisi. SQL çalıştır:\n  WITH sifir_risk AS (SELECT entity_id FROM fact_periodic GROUP BY entity_id HAVING MAX(COALESCE(kombine_risk,0))=0 AND MAX(COALESCE(ykn_izl_flag,0))=1)\n  SELECT COUNT(*) FROM sifir_risk\nSonra dim_entity JOIN ile segment dağılımını çıkar. Kaç firma etkileniyor, hangi segmentte yoğun?"),
     "accept":lambda r: any(c.isdigit() for c in r) and any(w in r.lower() for w in ["risk","yi","firma","segment","sifir","sıfır","anomali"])},
    {"id":"G2.5","name":"entity_id Tip Tutarlılığı",
     "task":T("DuckDB ($DB): tüm tablolarda entity_id/muta tipini kontrol et. Her tablo için SQL çalıştır:\n  SELECT typeof(entity_id) FROM dim_entity LIMIT 1\n  SELECT typeof(entity_id) FROM fact_periodic LIMIT 1\n  SELECT typeof(muta) FROM brz_kik_izleme LIMIT 1\nSonuçları tablo formatında göster, tip uyumsuzluğu varsa UYARI ver ve CAST öner."),
     "accept":lambda r: any(w in r.upper() for w in ["VARCHAR","BIGINT","INTEGER"]) and any(w in r.lower() for w in ["tip","type","cast","uyumsuz","uyarı","typeof"])},
  ],
  3: [  # YATAY
    {"id":"G3.1","name":"EWS Skor Dağılımı",
     "task":T("Son dönemde ($DB) EWS skor band dağılımı: 0-325, 325-500, 500-825, 825-1000, YI. Her band: firma sayısı, toplam risk, ort risk. Segment×band cross-tab."),
     "accept":lambda r: any(w in r for w in ["325","500","825","1000","band"]) and any(c.isdigit() for c in r)},
    {"id":"G3.2","name":"Risk Yoğunlaşma",
     "task":T("Son dönemde ($DB) top 100/1000/10000 firma portföy riskinin yüzde kaçı? Pareto. Window function ile."),
     "accept":lambda r: any(w in r.lower() for w in ["top","portföy","yoğun","pareto","%"])},
    {"id":"G3.3","name":"Diag Katman×Grup",
     "task":T("diag_eus_kapsam_diskalma ($DB) son dönemde katman×grup matrisi. Hangi katmanda hangi grup kaç bulgu?"),
     "accept":lambda r: any(w in r.lower() for w in ["katman","grup","diag","bulgu","gecikme","kik","rkd"])},
    {"id":"G3.4","name":"Skor-Risk Uyumsuzluğu",
     "task":T("Son dönemde ($DB): düşük skor(<325) + yüksek risk(>100M) firmalar kaç? Yüksek skor(>825) + düşük risk(<1M)? Skor↔log(risk) korelasyonu."),
     "accept":lambda r: any(w in r.lower() for w in ["uyumsuz","korelasyon","düşük skor","yüksek risk","outlier"])},
  ],
  4: [  # DİKEY
    {"id":"G4.1","name":"Firma Yaşam Döngüsü",
     "task":T("fact_periodic ($DB) 5 farklı segmentten rastgele firma seç. Her birinin 12 dönemlik zaman serisi: skor, band, kaynak, risk, YI. Band geçişlerini işaretle."),
     "accept":lambda r: any(w in r.lower() for w in ["dönem","donem","skor","band","firma","profil","trajectory"])},
    {"id":"G4.2","name":"Band Geçiş Matrisi",
     "task":T("fact_periodic ($DB) ardışık iki dönem (son 2) arasında 5×5 band geçiş matrisi. Satır toplamları %100. Diyagonal=stabilite."),
     "accept":lambda r: any(w in r.lower() for w in ["geçiş","matris","transition","diyagonal","stabilite","%"])},
    {"id":"G4.3","name":"YI Giriş Sinyali",
     "task":T("Son dönemde ($DB) YI olan firmaların giriş öncesi 3 dönem skor trajectory'si. Ani(1 dönem) vs kademeli(3+) giriş oranı."),
     "accept":lambda r: any(w in r.lower() for w in ["yi","giriş","sinyal","ani","kademeli","trajectory","hızlı"])},
    {"id":"G4.4","name":"Risk Volatilite",
     "task":T("Her firma ($DB) 12 dönem risk standart sapması (volatilite). Top 100 volatil: segment dağılımı. Düşük skor+yüksek volatilite kesişimi."),
     "accept":lambda r: any(w in r.lower() for w in ["volatil","std","sapma","top 100","dalgalı"])},
  ],
  5: [  # ZAMAN
    {"id":"G5.1","name":"Portföy Trend",
     "task":T("12 dönemde ($DB) toplam risk, firma sayısı, YI oranı trendi. Segment bazında."),
     "accept":lambda r: any(w in r.lower() for w in ["trend","dönem","portföy","artış","azalış","↑","↓"])},
    {"id":"G5.2","name":"Kohort EUS→YI",
     "task":T("2503 döneminde ($DB) EUS kapsamındaki firmalar sonraki dönemlerde ne oranda YI olmuş? Kohort analizi."),
     "accept":lambda r: any(w in r.lower() for w in ["kohort","cohort","dönüşüm","kümülatif","eus","yi"])},
    {"id":"G5.3","name":"Dönemsel Anomali",
     "task":T("Her dönemde ($DB) 3σ sapan metrikler: toplam risk, firma sayısı, YI oranı. Hangi dönemlerde anomali?"),
     "accept":lambda r: any(w in r.lower() for w in ["anomali","3σ","sigma","sapma","normal dışı"])},
    {"id":"G5.4","name":"Skor Momentum",
     "task":T("Her firma ($DB) son 3 dönem skor momentum = (skor_t - skor_t-2)/2. Top 100 kötüleşen, top 100 iyileşen. Hareketsiz firma oranı."),
     "accept":lambda r: any(w in r.lower() for w in ["momentum","kötüleş","iyileş","hareketsiz","stabil"])},
  ],
  6: [  # DİAGNOSTİK
    {"id":"G6.1","name":"Diag Bulgu Zenginliği",
     "task":T("diag_eus_kapsam_diskalma ($DB): SQL çalıştır:\n  1. Toplam satır: SELECT COUNT(*) FROM diag_eus_kapsam_diskalma\n  2. Firma×dönem çifti: SELECT COUNT(DISTINCT muta||'-'||donem) FROM diag_eus_kapsam_diskalma\n  3. Firma başına ort bulgu: SELECT ROUND(COUNT(*)::FLOAT / COUNT(DISTINCT muta||'-'||donem), 1) FROM diag_eus_kapsam_diskalma\n  4. Katman çeşitliliği (son dönem): SELECT k_cnt, COUNT(*) AS firma FROM (SELECT muta, COUNT(DISTINCT katman) AS k_cnt FROM diag_eus_kapsam_diskalma WHERE donem=(SELECT MAX(donem) FROM diag_eus_kapsam_diskalma) GROUP BY muta) GROUP BY k_cnt ORDER BY k_cnt\nTüm sonuçları raporla."),
     "accept":lambda r: any(w in r.lower() for w in ["bulgu","katman","firma","diag"]) and len(re.findall(r'\d+', r)) >= 3},
    {"id":"G6.2","name":"Kriter Korelasyonu",
     "task":T("diag_eus_kapsam_diskalma ($DB): son dönemde katman×grup matrisini çıkar. SQL:\n  SELECT katman, grup, COUNT(*) AS cnt FROM diag_eus_kapsam_diskalma WHERE donem=(SELECT MAX(donem) FROM diag_eus_kapsam_diskalma) GROUP BY katman, grup ORDER BY katman, cnt DESC\nHangi katman-grup çiftleri en yaygın? KIK, RKD, DELTA farkını açıkla."),
     "accept":lambda r: any(w in r.lower() for w in ["katman","grup","kik","rkd","delta","matris","cnt"]) and any(c.isdigit() for c in r)},
    {"id":"G6.3","name":"Bulgu Persistence",
     "task":T("diag_eus_kapsam_diskalma ($DB): son iki dönemi bul ve DELTA katmanındaki yeni bulguların (yeni=1) sonraki dönemde hâlâ var olup olmadığını kontrol et. SQL ile grup bazında persistence oranı hesapla. Yüksek persistence = kalıcı sorun, düşük = geçici."),
     "accept":lambda r: any(w in r.lower() for w in ["persist","kalıcı","delta","yeni","geçici","oran","dönem"]) and any(c.isdigit() for c in r)},
  ],
  7: [  # BÜTÜNLEŞİK
    {"id":"G7.1","name":"EUS Backtest",
     "task":T("2503 döneminde ($DB) EUS skor≥325 firmalar sonraki 6 dönemde sorun yaşamış mı? TP/FP/FN/TN, Precision/Recall/F1. Kümülatif."),
     "accept":lambda r: any(w in r.lower() for w in ["tp","fp","fn","precision","recall","f1","backtest"])},
    {"id":"G7.2","name":"Sankey Verisi",
     "task":T("Ardışık dönemler ($DB) arasında band geçişlerini risk ağırlıklı hesapla. JSON: from_band, to_band, count, risk_tl. Tüm segmentler."),
     "accept":lambda r: any(w in r.lower() for w in ["sankey","flow","akış","from_band","to_band","json"])},
    {"id":"G7.3","name":"Firma Skorkart",
     "task":T("Entity 12345678 ($DB) tam skorkart: 12 dönem trajectory, segment/şube, diag bulguları, band geçişleri, risk momentum, benzer firma karşılaştırma."),
     "accept":lambda r: len(r)>200 and any(w in r.lower() for w in ["trajectory","skor","bulgu","segment","dönem"])},
    {"id":"G7.4","name":"Anomali Alarm",
     "task":T("Tüm Seviye 2-6 kontrollerini ($DB) birleştir: alarm listesi. CRITICAL/WARN/INFO severity. Her alarm: açıklama, firma sayısı, aksiyon."),
     "accept":lambda r: any(w in r.lower() for w in ["critical","warn","alarm","aksiyon","severity","sağlık"])},
  ],
  8: [  # ÖLÇEK
    {"id":"G8.1","name":"SQL vs Python Perf",
     "task":T("EWS skor dağılımını ($DB) iki yöntemle: 1)DuckDB SQL GROUP BY 2)Python fetchdf+groupby. Süre ve bellek karşılaştır."),
     "accept":lambda r: any(w in r.lower() for w in ["sql","python","süre","bellek","performans","memory","ms","saniye"])},
    {"id":"G8.2","name":"Parquet Optimization",
     "task":T("Parquet dosyalarını oku: tam read vs column pruning vs row filter vs DuckDB read_parquet. Süre karşılaştır."),
     "accept":lambda r: any(w in r.lower() for w in ["parquet","pruning","filter","read_parquet","optimiz"])},
    {"id":"G8.3","name":"Incremental",
     "task":T("Band geçiş matrisini ($DB) full recompute vs incremental hesapla. Süre farkı. Incremental idempotent mi? DELETE+INSERT neden tehlikeli?"),
     "accept":lambda r: any(w in r.lower() for w in ["incremental","idempotent","delete","full","recompute","tehlike"])},
  ],
}

LEVEL_NAMES = {1:"Keşif",2:"Kalite",3:"Yatay",4:"Dikey",5:"Zaman",6:"Diagnostik",7:"Bütünleşik",8:"Ölçek"}


# ═══════════════════════════════════════
# RUNNER
# ═══════════════════════════════════════

def run_cont(task: str) -> dict:
    t0 = time.time()
    try:
        from cont import run_task
        answer, success = run_task(task)
        return {
            "answer": answer or "", "success": success,
            "elapsed": round(time.time()-t0, 1),
            "tools": [t if isinstance(t,str) else str(t) for t in (getattr(run_task,'_last_tools_used',[]) or [])],
            "recipe": getattr(run_task,'_last_recipe_id',None),
        }
    except Exception as e:
        return {"answer":f"ERROR:{e}","success":False,"elapsed":round(time.time()-t0,1),"tools":[],"recipe":None}


def score(answer: str, task: dict) -> int:
    if not answer or "ERROR" in answer: return 0
    accepted = task["accept"](answer)
    if not accepted: return 1
    # Kabul kriteri geçtiyse minimum 3/5
    has_fmt = any(c in answer for c in "═─│┌├")
    has_num = len(re.findall(r'\d{3,}', answer)) >= 3
    l = len(answer)
    if has_fmt and has_num and l>300: return 5
    if has_num and l>200: return 4
    return 3  # accept=✓ → minimum 3
    return 2


def run_level(level: int):
    tasks = ALL_TASKS[level]
    name = LEVEL_NAMES[level]
    results = []
    print(f"\n{'█'*70}")
    print(f"  SEVİYE {level}: {name} ({len(tasks)} görev)")
    print(f"{'█'*70}")

    for ti, task in enumerate(tasks):
        print(f"\n{'═'*70}")
        print(f"[{ti+1}/{len(tasks)}] {task['id']}: {task['name']}")

        entry = {"id":task["id"],"name":task["name"],"level":level}

        # MOD A: Ham
        print(f"  MOD A (ham):")
        ra = run_cont(task["task"])
        sa = score(ra["answer"], task)
        aa = task["accept"](ra["answer"]) if ra["answer"] else False
        print(f"    {ra['elapsed']:.0f}s | tools={len(ra['tools'])} | {sa}/5 | {'✓' if aa else '✗'}")

        entry["mod_a"] = {"score":sa,"accept":aa,"elapsed":ra["elapsed"],"tools":len(ra["tools"])}
        time.sleep(2)

        # MOD B: Hive
        print(f"  MOD B (hive):")
        rb = run_cont(task["task"])
        sb = score(rb["answer"], task)
        ab = task["accept"](rb["answer"]) if rb["answer"] else False
        print(f"    {rb['elapsed']:.0f}s | tools={len(rb['tools'])} | {sb}/5 | {'✓' if ab else '✗'} | recipe={rb['recipe']}")

        entry["mod_b"] = {"score":sb,"accept":ab,"elapsed":rb["elapsed"],"tools":len(rb["tools"]),"recipe":rb["recipe"]}
        entry["delta"] = sb - sa
        results.append(entry)
        time.sleep(1)

    # Özet
    ra_t = sum(r["mod_a"]["score"] for r in results)
    rb_t = sum(r["mod_b"]["score"] for r in results)
    mx = len(results)*5
    ra_a = sum(1 for r in results if r["mod_a"]["accept"])
    rb_a = sum(1 for r in results if r["mod_b"]["accept"])
    delta = rb_t - ra_t

    print(f"\n{'═'*50}")
    print(f"SEVİYE {level} ({name}): Ham {ra_t}/{mx} vs Hive {rb_t}/{mx}, Δ{'+' if delta>=0 else ''}{delta}")
    print(f"Kabul: Ham {ra_a}/{len(results)} vs Hive {rb_a}/{len(results)}")
    for r in results:
        d = r["delta"]
        print(f"  {r['id']}: {r['mod_a']['score']}→{r['mod_b']['score']} ({'+' if d>=0 else ''}{d})")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = RESULTS_DIR / f"curriculum_L{level}_{ts}.json"
    out.write_text(json.dumps(results, indent=2, ensure_ascii=False, default=str))
    return results, {"level":level,"name":name,"raw":ra_t,"hive":rb_t,"max":mx,"delta":delta,"raw_accept":ra_a,"hive_accept":rb_a}


def run_all(start_level: int = 1, max_hours: float = 8):
    t0 = time.time()
    all_summaries = []

    for level in range(start_level, 9):
        if (time.time()-t0)/3600 > max_hours:
            print(f"\n⏰ Süre doldu")
            break
        _, summary = run_level(level)
        all_summaries.append(summary)

        # Her seviye sonunda guardian
        try:
            from core.guardian import run_guardian
            report = run_guardian(full=True)
            g_pass = sum(1 for r in report.results.values() if r["passed"])
            g_total = len(report.results)
            print(f"  Guardian: {g_pass}/{g_total}")
        except: pass

    # Final rapor
    print(f"\n{'█'*70}")
    print(f"  CURRICULUM SONUÇLARI")
    print(f"{'█'*70}")
    total_raw = sum(s["raw"] for s in all_summaries)
    total_hive = sum(s["hive"] for s in all_summaries)
    total_max = sum(s["max"] for s in all_summaries)
    total_delta = total_hive - total_raw

    print(f"\n{'Seviye':<20s} {'Ham':>7s} {'Hive':>7s} {'Δ':>5s}")
    print(f"{'─'*20} {'─'*7} {'─'*7} {'─'*5}")
    for s in all_summaries:
        d = s["delta"]
        print(f"{s['level']}. {s['name']:<17s} {s['raw']:>4d}/{s['max']:<3d} {s['hive']:>4d}/{s['max']:<3d} {'+' if d>=0 else ''}{d:>3d}")
    print(f"{'─'*20} {'─'*7} {'─'*7} {'─'*5}")
    print(f"{'Toplam':<20s} {total_raw:>4d}/{total_max:<3d} {total_hive:>4d}/{total_max:<3d} {'+' if total_delta>=0 else ''}{total_delta:>3d}")
    print(f"\nHive iyileşme: {total_delta/max(total_raw,1)*100:+.0f}%")
    print(f"Süre: {(time.time()-t0)/3600:.1f}h")

    final = RESULTS_DIR / "opus_curriculum_results.json"
    final.write_text(json.dumps({"summaries":all_summaries,"total_raw":total_raw,"total_hive":total_hive,"total_max":total_max,"delta":total_delta}, indent=2))
    print(f"JSON: {final}")


if __name__ == "__main__":
    level = None
    max_h = 8
    for i, arg in enumerate(sys.argv):
        if arg == "--level": level = int(sys.argv[i+1])
        if arg == "--max-hours": max_h = float(sys.argv[i+1])

    if level:
        run_level(level)
    else:
        run_all(max_hours=max_h)
