# core/spreading_activation.py
"""Spreading activation recall — adım adım bellek canlandırma.

İnsan beyni gibi: keyword→ilgili bilgi canlanır, ihtiyaç anında.
Toptan dump yerine her adımda sadece lazım olan summary enjekte edilir.

Collins & Loftus (1975) spreading activation modeli.
"""

import yaml
from pathlib import Path
from typing import Optional

from core.utils import debug as _debug

KNOWLEDGE_DIR = Path(__file__).parent.parent / ".cont" / "hive" / "knowledge"

_ACTIVATION_MAP: dict | None = None
_activated_this_session: set = set()
_activation_trace: list = []  # Golden test trace
_trace_step: int = 0
_session_tokens: int = 0
SESSION_MAX_TOKENS: int = 500


def _load_map() -> dict:
    """activation_map.yaml'dan keyword→files eşleşmesini yükle (manuel + auto_learned)."""
    global _ACTIVATION_MAP
    if _ACTIVATION_MAP is not None:
        return _ACTIVATION_MAP

    path = KNOWLEDGE_DIR / "activation_map.yaml"
    merged = {}
    if path.exists():
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        # Manuel tanımlı
        for kw, entry in (data.get("activation", {}) or {}).items():
            if isinstance(entry, dict):
                merged[kw] = entry
        # Otomatik öğrenilmiş (manuel override eder)
        for kw, entry in (data.get("auto_learned", {}) or {}).items():
            if isinstance(entry, dict) and kw not in merged:
                merged[kw] = entry
    _ACTIVATION_MAP = merged
    return _ACTIVATION_MAP


def invalidate_cache():
    """Map cache'ini sıfırla (yeni keyword eklendikten sonra)."""
    global _ACTIVATION_MAP
    _ACTIVATION_MAP = None


def extract_keywords(text: str) -> list[str]:
    """Metinden activation keyword'lerini çıkar. Deterministik."""
    amap = _load_map()
    text_lower = text.lower()
    found = []
    for keyword in amap:
        kw_lower = keyword.lower()
        # 2 karakterli keyword'ler (YI, EUS gibi) de eşleşebilir
        min_len = 2 if kw_lower.upper() == kw_lower or len(kw_lower) <= 3 else 3
        if len(kw_lower) >= min_len and kw_lower in text_lower:
            found.append(keyword)
    return found


def _get_summary(knowledge_name: str) -> str:
    """Knowledge dosyasının summary alanını oku."""
    for suffix in (".yaml", ".yml"):
        path = KNOWLEDGE_DIR / f"{knowledge_name}{suffix}"
        if path.exists():
            try:
                data = yaml.safe_load(path.read_text(encoding="utf-8"))
                return data.get("summary", "") if data else ""
            except Exception:
                return ""
    return ""


def micro_recall(keywords: list[str], max_tokens: int = 400) -> str:
    """Keyword'lerden ilgili knowledge summary'lerini getir.

    Priority kuralları:
      high   → summary HER ZAMAN enjekte
      medium → summary sadece ilk kez enjekte (session'da tekrar yok)
      low    → enjekte ETME
    Token limiti: max_tokens aşılınca dur.
    """
    global _session_tokens
    if _session_tokens >= SESSION_MAX_TOKENS:
        return ""  # session bütçesi aşıldı

    amap = _load_map()
    hints = []
    seen_files: set = set()
    total_tokens = 0
    remaining = SESSION_MAX_TOKENS - _session_tokens

    for kw in keywords:
        entry = amap.get(kw, {})
        if not isinstance(entry, dict):
            continue
        files = entry.get("files", [])
        priority = entry.get("priority", "low")

        if priority == "low":
            continue

        for fname in files:
            if fname in seen_files:
                continue
            if priority == "medium" and fname in _activated_this_session:
                continue  # medium: session'da bir kez

            summary = _get_summary(fname)
            if summary:
                token_cost = len(summary) // 4
                if total_tokens + token_cost > min(max_tokens, remaining):
                    break  # bütçe aşıldı
                hints.append(f"[{fname}] {summary}")
                seen_files.add(fname)
                total_tokens += token_cost

                if priority == "medium":
                    _activated_this_session.add(fname)

        # Recipe referansı (suggestive)
        for rname in entry.get("recipes", []):
            if rname in seen_files:
                continue
            try:
                from core.fitness import fitness as _fit_fn
                from core.hive_recall import _load_recipes
                for r in _load_recipes():
                    if r.get("name") == rname:
                        f = _fit_fn(r)
                        if f >= 0.3:
                            hint = f"[recipe:{rname}] İlgili reçete (fitness: {f:.0%})"
                            token_cost = len(hint) // 4
                            if total_tokens + token_cost <= max_tokens:
                                hints.append(hint)
                                seen_files.add(rname)
                                total_tokens += token_cost
                        break
            except Exception:
                pass

    if not hints:
        return ""

    _session_tokens += total_tokens

    # Trace logging
    global _trace_step
    _trace_step += 1
    trace_entry = {
        "step": _trace_step,
        "trigger": "task_text" if _trace_step == 1 else "tool_result",
        "keywords_found": keywords,
        "files_activated": list(seen_files),
        "already_activated": [f for f in _activated_this_session if f not in seen_files],
        "context_tokens_added": len("\n".join(hints)) // 4,
    }
    _activation_trace.append(trace_entry)

    return "<memory_activation>\n" + "\n".join(hints) + "\n</memory_activation>"


def reset_session():
    """Yeni görev başlangıcı — aktivasyon cache'ini sıfırla."""
    global _activated_this_session, _activation_trace, _trace_step, _session_tokens
    _activated_this_session = set()
    _activation_trace = []
    _trace_step = 0
    _session_tokens = 0


def get_trace() -> list:
    """Golden test için trace verisi."""
    return list(_activation_trace)


def save_trace(task_name: str = ""):
    """Trace'i dosyaya kaydet."""
    import json
    from datetime import datetime
    trace_dir = KNOWLEDGE_DIR.parent / "runs" / "activation_trace"
    trace_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = trace_dir / f"{ts}.jsonl"
    with open(path, "w") as f:
        for entry in _activation_trace:
            entry["task"] = task_name
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    return str(path)


def extract_gaps(text: str) -> list[str]:
    """Metindeki potansiyel keyword'leri bul (map'te olmayanlar)."""
    import re
    amap = _load_map()
    known = set(k.lower() for k in amap.keys())
    common = {"bir", "bu", "ile", "için", "var", "yok", "olan", "the", "and",
              "for", "with", "from", "this", "import", "print", "return",
              "true", "false", "none", "def", "class", "self"}

    words = set(re.findall(r'[a-zA-ZçğıöşüÇĞİÖŞÜ_]{4,}', text.lower()))
    return [w for w in words if w not in known and w not in common
            and ("_" in w or any(c.isupper() for c in text[text.lower().find(w):text.lower().find(w)+len(w)]))]


def auto_learn(task: str, success: bool, tools_used: list):
    """Başarılı görevden yeni keyword→knowledge eşleşmesi öğren."""
    if not success:
        return  # başarısız görevden öğrenme tehlikeli

    gaps = extract_gaps(task)
    if not gaps:
        return

    # Hangi knowledge dosyaları bu session'da canlandı?
    used_files = list(_activated_this_session)
    if not used_files:
        return

    map_path = KNOWLEDGE_DIR / "activation_map.yaml"
    if not map_path.exists():
        return

    try:
        import json
        from datetime import datetime
        data = yaml.safe_load(map_path.read_text(encoding="utf-8"))
        if "auto_learned" not in data or not isinstance(data["auto_learned"], dict):
            data["auto_learned"] = {}

        added = 0
        for gap_kw in gaps[:3]:  # max 3 keyword per task
            if gap_kw not in data.get("auto_learned", {}) and gap_kw not in data.get("activation", {}):
                data["auto_learned"][gap_kw] = {
                    "files": used_files[:2],
                    "priority": "medium",
                    "source": "auto_learned",
                    "learned_from": f"task_{datetime.now().strftime('%Y%m%d_%H%M')}",
                }
                added += 1

        if added:
            map_path.write_text(yaml.dump(data, allow_unicode=True, default_flow_style=False, sort_keys=False), encoding="utf-8")
            invalidate_cache()
            _debug(f"[ACTIVATION] Auto-learned: {added} keyword eklendi")

        # Gap log
        gap_log = KNOWLEDGE_DIR.parent / "runs" / "activation_gaps.jsonl"
        gap_log.parent.mkdir(parents=True, exist_ok=True)
        for g in gaps:
            with open(gap_log, "a") as f:
                f.write(json.dumps({"keyword": g, "task": task[:100], "ts": datetime.now().isoformat()}, ensure_ascii=False) + "\n")
    except Exception as e:
        _debug(f"[ACTIVATION] Auto-learn error: {e}")


# ═══════════════════════════════
# HEBB KURALI: DECAY + REINFORCEMENT
# ═══════════════════════════════

_relevance_log: list = []

PRIORITY_WEIGHTS = {"high": 1.0, "medium": 0.6, "low": 0.2}


def track_relevance(activated_file: str, step: int):
    """Canlandırılan dosyayı takibe al."""
    _relevance_log.append({"file": activated_file, "step": step, "used": None})


def check_usage(model_output: str, tool_calls_text: str):
    """Her tool call sonrası: canlandırılanlar kullanıldı mı?"""
    for entry in _relevance_log:
        if entry["used"] is not None:
            continue
        summary = _get_summary(entry["file"])
        if not summary:
            continue
        # Keyword overlap — deterministik
        summary_words = set(summary.lower().split())
        output_words = set(model_output.lower().split()) | set(tool_calls_text.lower().split())
        overlap = len(summary_words & output_words)
        entry["used"] = overlap >= 3


def save_relevance_feedback():
    """Session sonunda: relevance_score güncelle."""
    map_path = KNOWLEDGE_DIR / "activation_map.yaml"
    if not map_path.exists() or not _relevance_log:
        return

    try:
        data = yaml.safe_load(map_path.read_text(encoding="utf-8"))
        changed = False

        for entry in _relevance_log:
            fname = entry["file"]
            used = entry.get("used", False)

            for section in ("activation", "auto_learned"):
                for kw, kw_data in (data.get(section, {}) or {}).items():
                    if not isinstance(kw_data, dict):
                        continue
                    if fname in kw_data.get("files", []):
                        current = kw_data.get("relevance_score", 1.0)
                        if used:
                            new_score = min(2.0, current * 1.1)  # reinforcement
                        else:
                            new_score = max(0.1, current * 0.85)  # decay
                        if round(new_score, 2) != round(current, 2):
                            kw_data["relevance_score"] = round(new_score, 2)
                            changed = True

        if changed:
            map_path.write_text(yaml.dump(data, allow_unicode=True, default_flow_style=False, sort_keys=False), encoding="utf-8")
            invalidate_cache()
    except Exception as e:
        _debug(f"[ACTIVATION] Relevance save error: {e}")


def get_activation_stats() -> dict:
    """Guardian ve dashboard için aktivasyon istatistikleri."""
    amap = _load_map()
    total_keywords = len(amap)
    total_files = set()
    for entry in amap.values():
        if isinstance(entry, dict):
            total_files.update(entry.get("files", []))

    # Summary kontrolü
    missing_summary = []
    for fname in total_files:
        s = _get_summary(fname)
        if not s:
            missing_summary.append(fname)

    # Ölü referans kontrolü
    dead_refs = []
    for fname in total_files:
        found = False
        for suffix in (".yaml", ".yml"):
            if (KNOWLEDGE_DIR / f"{fname}{suffix}").exists():
                found = True
                break
        if not found:
            dead_refs.append(fname)

    # Erişilemeyen knowledge
    all_knowledge = set(f.stem for f in KNOWLEDGE_DIR.glob("*.yaml") if f.stem != "activation_map")
    unreachable = all_knowledge - total_files

    return {
        "total_keywords": total_keywords,
        "total_files": len(total_files),
        "missing_summary": missing_summary,
        "dead_refs": dead_refs,
        "unreachable": list(unreachable),
        "activated_this_session": len(_activated_this_session),
    }
