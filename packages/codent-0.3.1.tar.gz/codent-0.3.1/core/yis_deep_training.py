#!/usr/bin/env python3
"""yis_v21 derinlemesine eğitim — 5 rund, her rund 5 görev, SQL doğrulama."""

import json, os, re, sys, time
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(str(PROJECT_ROOT))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

DB = "/home/sertan/projects/ews_v511/ews_dashboard/db/ews.duckdb"
RESULTS_DIR = PROJECT_ROOT / ".cont" / "hive" / "runs" / "training"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

# ── SQL doğrulama fonksiyonları ──

def sql(query: str) -> str:
    import duckdb
    con = duckdb.connect(DB, read_only=True)
    try:
        rows = con.execute(query).fetchall()
        cols = [d[0] for d in con.description]
        lines = ["\t".join(str(c) for c in cols)]
        for r in rows[:20]:
            lines.append("\t".join(str(v) for v in r))
        return "\n".join(lines)
    except Exception as e:
        return f"SQL_ERROR: {e}"
    finally:
        con.close()


def run_cont(task: str) -> dict:
    t0 = time.time()
    try:
        from cont import run_task
        answer, success = run_task(task)
        return {
            "answer": answer or "", "elapsed": round(time.time()-t0, 1),
            "tools": len(getattr(run_task, '_last_tools_used', []) or []),
            "recipe": getattr(run_task, '_last_recipe_id', None),
        }
    except Exception as e:
        return {"answer": f"ERROR:{e}", "elapsed": round(time.time()-t0, 1), "tools": 0, "recipe": None}


# ── Görevler ──

ROUNDS = {
    1: {
        "name": "Yapıyı Öğren",
        "tasks": [
            {"q": f"fact_periodic ({DB}): her kolonu açıkla — adı, tipi, ne işe yarıyor",
             "verify_sql": "DESCRIBE fact_periodic",
             "check": lambda r: sum(1 for c in ["entity_id","donem","yis_skor","eus_skor","ews_skor","kombine_risk","ykn_izl_flag"] if c in r) >= 5},
            {"q": f"fact_periodic ({DB}): hangi kolonlar kategorik (VARCHAR), hangileri sayısal (INTEGER/DOUBLE/BIGINT)?",
             "verify_sql": "SELECT column_name, data_type FROM information_schema.columns WHERE table_name='fact_periodic'",
             "check": lambda r: any(w in r.upper() for w in ["VARCHAR","INTEGER","DOUBLE","BIGINT"]) and any(w in r.lower() for w in ["kategorik","sayısal","numeric","categorical"])},
            {"q": f"fact_periodic ({DB}): NULL oranı en yüksek 5 kolon hangisi? Her birinin NULL% hesapla.",
             "verify_sql": "SELECT 'yis_skor' AS col, ROUND(100.0*SUM(CASE WHEN yis_skor IS NULL THEN 1 ELSE 0 END)/COUNT(*),1) AS null_pct FROM fact_periodic",
             "check": lambda r: any(w in r.lower() for w in ["null","%","oran"]) and any(c.isdigit() for c in r)},
            {"q": f"fact_periodic ve dim_entity ({DB}): entity_id tipi ne? İkisi arasında JOIN yapılabilir mi, tip uyumsuzluğu var mı?",
             "verify_sql": "SELECT typeof(entity_id) AS fp_type FROM fact_periodic LIMIT 1",
             "check": lambda r: any(w in r.upper() for w in ["VARCHAR","BIGINT"]) and any(w in r.lower() for w in ["entity_id","tip","type","join"])},
            {"q": f"fact_periodic ({DB}): kaç dönem var? Her dönemde kaç firma? MIN/MAX donem değerleri?",
             "verify_sql": "SELECT donem, COUNT(DISTINCT entity_id) AS firma FROM fact_periodic GROUP BY donem ORDER BY donem",
             "check": lambda r: any(w in r.lower() for w in ["dönem","donem"]) and any(c.isdigit() for c in r)},
        ],
    },
    2: {
        "name": "İlişkileri Öğren",
        "tasks": [
            {"q": f"fact_periodic ({DB}): ews_skor ile kombine_risk arasındaki ilişki ne? Yüksek skor=yüksek risk mi?",
             "verify_sql": "SELECT ews_skor, ROUND(AVG(kombine_risk)/1e6,1) AS ort_risk_mio FROM fact_periodic WHERE ews_skor NOT IN ('YI','') AND ews_skor IS NOT NULL GROUP BY ews_skor ORDER BY CAST(ews_skor AS INTEGER) DESC LIMIT 10",
             "check": lambda r: any(w in r.lower() for w in ["skor","risk","ilişki","korelasyon","yüksek","düşük"])},
            {"q": f"fact_periodic ({DB}): ykn_izl_flag=1 olan firmaların ews_skor dağılımı nasıl? Hepsi 'YI' mi?",
             "verify_sql": "SELECT ews_skor, COUNT(*) AS cnt FROM fact_periodic WHERE ykn_izl_flag=1 GROUP BY ews_skor ORDER BY cnt DESC LIMIT 10",
             "check": lambda r: any(w in r.lower() for w in ["yi","ykn_izl","flag","dağılım"])},
            {"q": f"fact_periodic ({DB}): sayısal kolonlar arasında en yüksek korelasyonlu çiftler hangileri?",
             "verify_sql": "SELECT CORR(kombine_risk, kredi_risk) AS risk_corr FROM fact_periodic",
             "check": lambda r: any(w in r.lower() for w in ["korelasyon","correlation","yüksek","çift"])},
            {"q": f"fact_periodic ({DB}): EUS (ews_kaynak='eus') ve YIS (ews_kaynak='yis') firmaları arasında örtüşme var mı? Aynı firma iki kaynakta da olabiliyor mu?",
             "verify_sql": "SELECT COUNT(DISTINCT entity_id) FROM fact_periodic WHERE ews_kaynak='eus' INTERSECT SELECT COUNT(DISTINCT entity_id) FROM fact_periodic WHERE ews_kaynak='yis'",
             "check": lambda r: any(w in r.lower() for w in ["eus","yis","örtüşme","aynı firma","kaynak"])},
            {"q": f"fact_periodic JOIN dim_entity ({DB}): segment bazında ortalama ews_skor nasıl farklılaşıyor?",
             "verify_sql": "SELECT d.segment, COUNT(*) AS firma, ROUND(AVG(CASE WHEN f.ews_skor NOT IN ('YI','') AND f.ews_skor IS NOT NULL THEN CAST(f.ews_skor AS INTEGER) END),0) AS ort_skor FROM fact_periodic f JOIN dim_entity d ON f.entity_id=d.entity_id GROUP BY d.segment",
             "check": lambda r: any(w in r.lower() for w in ["segment","kobi","mikro","kur-tic","eskk","ortalama","skor"])},
        ],
    },
    3: {
        "name": "Anomalileri Bul",
        "tasks": [
            {"q": f"fact_periodic ({DB}): skoru yüksek (>825) ama riski düşük (<1M TL) firmalar var mı? Kaç tane? Son dönem.",
             "verify_sql": "SELECT COUNT(*) FROM fact_periodic WHERE donem=(SELECT MAX(donem) FROM fact_periodic) AND ews_skor NOT IN ('YI','') AND ews_skor IS NOT NULL AND CAST(ews_skor AS INTEGER)>825 AND kombine_risk<1000000",
             "check": lambda r: any(c.isdigit() for c in r) and any(w in r.lower() for w in ["skor","risk","firma","yüksek","düşük"])},
            {"q": f"fact_periodic ({DB}): ews_skor=0 veya NULL olan firmalar normal mi? Kaç tane, hangi ews_kaynak'ta?",
             "verify_sql": "SELECT ews_kaynak, COUNT(*) FROM fact_periodic WHERE ews_skor IS NULL OR ews_skor='0' GROUP BY ews_kaynak",
             "check": lambda r: any(w in r.lower() for w in ["null","0","skor","kaynak","firma"])},
            {"q": f"fact_periodic ({DB}): bir dönemden diğerine ews_skor 200+ puan sıçrayan firmalar? Kaç tane? Son 2 dönem.",
             "verify_sql": "SELECT COUNT(*) FROM fact_periodic a JOIN fact_periodic b ON a.entity_id=b.entity_id AND CAST(b.donem AS INT)=CAST(a.donem AS INT)+1 WHERE a.ews_skor NOT IN ('YI','') AND b.ews_skor NOT IN ('YI','') AND a.ews_skor IS NOT NULL AND b.ews_skor IS NOT NULL AND ABS(CAST(b.ews_skor AS INT)-CAST(a.ews_skor AS INT))>200",
             "check": lambda r: any(c.isdigit() for c in r) and any(w in r.lower() for w in ["sıçra","jump","değişim","puan","firma"])},
            {"q": f"fact_periodic JOIN dim_entity ({DB}): aynı ews_skor bandındaki (örn 0-325) firmalar segment bazında nasıl farklılaşıyor? Risk farkı?",
             "verify_sql": "SELECT d.segment, ROUND(AVG(f.kombine_risk)/1e6,1) AS ort_risk_mio FROM fact_periodic f JOIN dim_entity d ON f.entity_id=d.entity_id WHERE f.ews_skor NOT IN ('YI','') AND f.ews_skor IS NOT NULL AND CAST(f.ews_skor AS INT)<325 AND f.donem=(SELECT MAX(donem) FROM fact_periodic) GROUP BY d.segment",
             "check": lambda r: any(w in r.lower() for w in ["segment","risk","fark","band","karşılaştır"])},
            {"q": f"fact_periodic ({DB}): kombine_risk negatif olan kayıt var mı?",
             "verify_sql": "SELECT COUNT(*) FROM fact_periodic WHERE kombine_risk < 0",
             "check": lambda r: any(c.isdigit() for c in r) or any(w in r.lower() for w in ["negatif","yok","0","var"])},
        ],
    },
    4: {
        "name": "Dönemsel Dinamikler",
        "tasks": [
            {"q": f"fact_periodic ({DB}): firmalar dönemler arası ews_skor bandı nasıl değişiyor? Son 2 dönem geçiş sayıları.",
             "check": lambda r: any(w in r.lower() for w in ["geçiş","band","değişim","dönem","hareket"])},
            {"q": f"fact_periodic ({DB}): son 2 dönem arasında EWS band geçiş matrisi (0-325, 325-500, 500-825, 825-1000, YI).",
             "verify_sql": "SELECT 'placeholder' AS x",
             "check": lambda r: any(w in r for w in ["325","500","825","geçiş","matris","band"])},
            {"q": f"fact_periodic ({DB}): son dönemde yeni YI olan (önceki dönem YI değildi, şimdi YI) firmaların önceki 3 dönemdeki ortalama skor trendi.",
             "check": lambda r: any(w in r.lower() for w in ["yi","yeni","trend","skor","önceki","dönem"])},
            {"q": f"fact_periodic ({DB}): YI'dan çıkan (önceki dönem YI, şimdi değil) firmalar var mı? Kaç tane? Şimdiki skor bandı ne?",
             "check": lambda r: any(w in r.lower() for w in ["yi","çıkan","firma","band","skor"])},
            {"q": f"fact_periodic ({DB}): dönemler arası toplam portföy riski trendi nasıl? Artıyor mu azalıyor mu?",
             "verify_sql": "SELECT donem, ROUND(SUM(kombine_risk)/1e9,1) AS toplam_risk_milyar FROM fact_periodic GROUP BY donem ORDER BY donem",
             "check": lambda r: any(w in r.lower() for w in ["trend","artı","azal","portföy","risk","dönem"])},
        ],
    },
    5: {
        "name": "Derinlemesine",
        "tasks": [
            {"q": f"fact_periodic JOIN dim_entity ({DB}): son dönemde en riskli 100 firmanın ortak özellikleri ne? Segment, bölge, ews_kaynak dağılımı.",
             "check": lambda r: any(w in r.lower() for w in ["segment","bölge","ortak","özellik","risk","top","en riskli"])},
            {"q": f"dim_entity ({DB}): segment değeri NULL olan firmalar var mı? Kaç tane? Bunlar fact_periodic'te nasıl görünüyor?",
             "verify_sql": "SELECT COUNT(*) FROM dim_entity WHERE segment IS NULL",
             "check": lambda r: any(c.isdigit() for c in r) and any(w in r.lower() for w in ["null","segment","firma"])},
            {"q": f"fact_periodic JOIN dim_entity ({DB}): aynı bölgedeki firmalar benzer skor trendi mi gösteriyor? Bölge bazında skor standart sapması.",
             "check": lambda r: any(w in r.lower() for w in ["bölge","std","sapma","benzer","trend","varyans"])},
            {"q": f"fact_periodic ({DB}): eus_skor yüksek (>300) ama yis_skor düşük (<500) olan firmalar var mı? İki skor sistemi ne kadar uyumlu?",
             "check": lambda r: any(w in r.lower() for w in ["eus","yis","skor","uyum","fark","yüksek","düşük"])},
            {"q": f"fact_periodic ({DB}): bu veride modellemeyi zorlaştıran en büyük 3 sorun ne? (sınıf dengesizliği, korelasyon, missing data...)",
             "check": lambda r: any(w in r.lower() for w in ["dengesiz","imbalance","korelasyon","missing","sorun","zorlaştır","null"])},
        ],
    },
}


def run_round(rnd_num: int, rnd: dict, pass_num: int = 1) -> dict:
    name = rnd["name"]
    tasks = rnd["tasks"]
    print(f"\n{'█'*60}")
    print(f"  RUND {rnd_num}: {name} (Pass {pass_num})")
    print(f"{'█'*60}")

    results = []
    for ti, t in enumerate(tasks):
        q = t["q"]
        print(f"\n  [{ti+1}/{len(tasks)}] {q[:70]}...")

        r = run_cont(q)
        passed = t["check"](r["answer"])
        short = r["answer"][:150].replace("\n", " ") if r["answer"] else "(boş)"
        icon = "✓" if passed else "✗"
        print(f"    {r['elapsed']:.0f}s | {icon} | tools={r['tools']} | recipe={r['recipe']}")
        print(f"    → {short}...")

        # SQL doğrulama
        verify = ""
        if t.get("verify_sql") and t["verify_sql"] != "SELECT 'placeholder' AS x":
            verify = sql(t["verify_sql"])
            print(f"    SQL: {verify[:100]}...")

        results.append({
            "q": q[:100], "passed": passed, "elapsed": r["elapsed"],
            "tools": r["tools"], "recipe": r["recipe"],
            "answer_len": len(r["answer"]), "verify": verify[:200],
        })
        time.sleep(1)

    passed_count = sum(1 for r in results if r["passed"])
    print(f"\n  Rund {rnd_num} ({name}) Pass {pass_num}: {passed_count}/{len(tasks)}")
    return {"rund": rnd_num, "name": name, "pass": pass_num, "passed": passed_count, "total": len(tasks), "tasks": results}


def main():
    t0 = time.time()
    all_results = {"pass1": [], "pass2": []}

    # Pass 1
    print("═" * 60)
    print("  PASS 1: İlk deneme")
    print("═" * 60)
    for rnd_num in sorted(ROUNDS.keys()):
        result = run_round(rnd_num, ROUNDS[rnd_num], pass_num=1)
        all_results["pass1"].append(result)

    # Pass 2
    print("\n" + "═" * 60)
    print("  PASS 2: Tekrar — iyileşme oldu mu?")
    print("═" * 60)
    for rnd_num in sorted(ROUNDS.keys()):
        result = run_round(rnd_num, ROUNDS[rnd_num], pass_num=2)
        all_results["pass2"].append(result)

    # Karşılaştırma
    print("\n" + "█" * 60)
    print("  YIS DEEP TRAINING RAPORU")
    print("█" * 60)

    print(f"\n{'Rund':<25s} {'Pass 1':>8s} {'Pass 2':>8s} {'Δ':>5s}")
    print(f"{'─'*25} {'─'*8} {'─'*8} {'─'*5}")
    total_p1, total_p2 = 0, 0
    for p1, p2 in zip(all_results["pass1"], all_results["pass2"]):
        d = p2["passed"] - p1["passed"]
        print(f"R{p1['rund']}. {p1['name']:<22s} {p1['passed']:>4d}/{p1['total']} {p2['passed']:>4d}/{p2['total']} {'+' if d>=0 else ''}{d:>3d}")
        total_p1 += p1["passed"]
        total_p2 += p2["passed"]

    delta = total_p2 - total_p1
    print(f"{'─'*25} {'─'*8} {'─'*8} {'─'*5}")
    print(f"{'Toplam':<25s} {total_p1:>4d}/25  {total_p2:>4d}/25  {'+' if delta>=0 else ''}{delta:>3d}")
    print(f"\nİyileşme: {delta:+d} görev ({delta/max(total_p1,1)*100:+.0f}%)")
    print(f"Süre: {(time.time()-t0)/60:.0f} dakika")

    out = RESULTS_DIR / f"yis_deep_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    out.write_text(json.dumps(all_results, indent=2, ensure_ascii=False, default=str))
    print(f"JSON: {out}")


if __name__ == "__main__":
    main()
