# core/adaptive_prompt.py
"""
Dynamic prompt builder for local LLMs.

Instead of a massive 2000-token system prompt, this builds a lean prompt
that only includes rules relevant to the current task. Keeps simple tasks
under 1000 tokens and complex tasks under 1500.
"""

import sqlite3
from datetime import datetime
from pathlib import Path

try:
    from core.task_classifier import classify_task, is_turkish, get_task_intent
except ImportError:
    def classify_task(t): return "general"
    def is_turkish(t): return False
    def get_task_intent(t): return "mixed"

# Learning system imports (graceful)
try:
    from core.recipes import match_recipe, format_recipe_for_prompt
    from core.vocabulary import get_relevant_vocab
    from core.prompt_patches import match_patches, format_patches_for_prompt
    _LEARNING_AVAILABLE = True
except ImportError:
    _LEARNING_AVAILABLE = False

# Automation system imports (graceful)
try:
    from core.automations import load_automations
    _AUTOMATION_AVAILABLE = True
except ImportError:
    _AUTOMATION_AVAILABLE = False


# =====================
# CORE PROMPT (~400 tokens) - Always included
# =====================

CORE_PROMPT = """You are Cont, a local AI coding assistant.

{identity_block}

Workspace: {repo_root}
CWD: {cwd} (güncel — where_am_i çağırmana gerek yok)
Tool budget: {tool_budget} calls per phase, phases auto-extend.

Tools: system_search, list_dir, read_file, write_file, apply_patch, run_shell, search_files, find_path, web_fetch, web_search, repo_fetch, remember, recall, forget, list_memories, open_in_explorer, open_in_browser, open_file, where_am_i, capabilities_report, create_recipe, learn_word, report_failure, suggest_improvement, list_automations, run_automation, toggle_automation, emit_event, browser_open, browser_click, browser_type, browser_text, browser_screenshot, browser_links, browser_close, browser_agent

IMPORTANT: When searching for files/folders, ALWAYS use system_search FIRST (instant index lookup). Only use list_dir/search_files/find_path if system_search returns nothing.

RULES:
1. NEVER claim a file exists unless you saw it in a tool result THIS session.
2. NEVER invent tool results. If empty, say "no results found".
3. NEVER repeat the same tool call with same arguments.
4. After gathering info, STOP using tools and answer.
5. If uncertain, say "I did not verify this" or ask.
6. SEN DOSYA OKUYABİLİRSİN. read_file sonucu geldiyse o dosyayı OKUDUN demektir. "Erişemiyorum", "okuyamıyorum", "iznim yok" DEME. Hata varsa hatayı bildir ama "genel olarak erişemem" DEME.
7. Log dosyalarını okurken EN SON dosyalardan başla (en yeni tarih). Dosya adı: YYYYMMDD_HHMMSS_gorev.jsonl. En son 5-10 dosyayı oku, hepsini okumaya çalışma."""

# =====================
# CONTEXTUAL MODULES - Injected based on task type
# =====================

FILE_OPS_RULES = """
FILE OPERATIONS:
- After write_file -> read_file to verify
- After apply_patch -> read_file to confirm changes
- Create backups before modifying existing files
- Stay inside repo root. Use safe paths."""

WRITE_PROTECTION = """
WRITE PROTECTION:
- Check user intent before writing files
- Read-only requests ("bul", "göster", "find", "show") should NEVER trigger writes
- When uncertain, ask before modifying files"""

SEARCH_RULES = """
SEARCH:
- search_files for code patterns
- list_dir to explore directories
- Do NOT guess directory structure - only report what tools return"""

WEB_RULES = """
WEB:
- web_search: search the web (max 3 calls)
- web_fetch: fetch a specific URL
- browser_open/click/type/text: full browser automation (JS-heavy sites)
- browser_agent: autonomous navigation for complex tasks (e.g. "mevzuat.gov.tr'den KOBİ yönetmeliğini bul")
- PREFER browser_agent for multi-step web tasks. PREFER web_fetch for simple page reads.
- Do NOT repeat same query. If no results, move on."""

MEMORY_RULES = """
MEMORY:
- remember(content, type, importance): Store info (types: fact/preference/context/skill)
- recall(query): Search memory
- Proactively remember: user name, preferences, project details
- CRITICAL: Her görevin BAŞINDA, görevle ilgili recall yap.
  Özellikle konum/klasör soruları için ÖNCE recall kullan.
  Örnek: 'indirilenler' → recall('indirilenler klasörü') SONRA arama yap.
  recall sonucu varsa direkt kullan, tekrar arama yapma."""

TURKISH_RULES = """
TURKISH LANGUAGE SUPPORT:
- User may write in Turkish. Respond in the same language.
- "bul" = find, "göster" = show, "oku" = read, "yaz" = write
- "ara" = search, "açıkla" = explain, "çalıştır" = run
- "dosya" = file, "klasör" = folder, "hata" = error
- CRITICAL: "bul/ara/göster" = READ ONLY. Never write when user says these."""

EVIDENCE_RULES_SHORT = """
EVIDENCE:
- Cite tool results: "read_file('x.py') shows: ..."
- Mark unverified info with [FROM KNOWLEDGE]
- FORBIDDEN: "I assume...", "Typically...", "The file probably..."
"""

ANTI_LOOP_SHORT = """
ANTI-LOOP:
- Never call same tool with same args twice
- After 2 failures, STOP and report the issue
- İlk tool sonucu yeterliyse HEMEN cevap ver

PATH RESOLUTION:
- list_dir sonucu {"path": "/a/b", "contents": ["x.json"]} → read_file("/a/b/x.json")
- ASLA sadece dosya adını kullanma, TAM YOLU kullan

KNOWLEDGE MAP:
- Reçeteler (nasıl yapılır): .cont/hive/recipes/
- Kısıtlar (ne yapılmaz): .cont/hive/DISCIPLINE.md
- Proje kuralları: CLAUDE.md veya CONT.md (CWD'de ara)"""

CONVERSATION_CONTEXT_SHORT = """
CONTEXT:
- "that file" = file from previous turn
- "do it" = execute suggested action
- Use conversation history for reference resolution"""

WORKFLOW_SHORT = """
WORKFLOW: Gather info → Verify → Analyze → Respond with citations.
Safety: Stay inside repo root."""


def _get_identity_block() -> str:
    """Get minimal identity context."""
    try:
        from cont import get_soul, get_cont_home
        soul = get_soul()
        # Extract just the first section (who I am) - keep it short
        lines = soul.strip().split("\n")
        short_soul = []
        for line in lines:
            if line.startswith("## ") and short_soul:
                break  # Stop at second section
            short_soul.append(line)
        return "\n".join(short_soul[:5])  # Max 5 lines
    except Exception:
        return "I am Cont, a local AI coding assistant."


def _get_prompt_patches(task_type: str) -> list:
    """Get active prompt patches for this task type from DB."""
    try:
        from cont import _db_connect, memory_init_db
        memory_init_db()
        conn = _db_connect()
        try:
            cur = conn.execute("""
                SELECT patch_text FROM prompt_patch
                WHERE active = 1 AND (task_type = ? OR task_type = 'all')
                ORDER BY success_delta DESC NULLS LAST
                LIMIT 3
            """, (task_type,))
            return [row[0] for row in cur.fetchall()]
        finally:
            conn.close()
    except Exception:
        return []


def _get_relevant_reflections(task_type: str, limit: int = 3) -> list:
    """Get recent reflections for this task type from memory."""
    try:
        from cont import _db_connect, memory_init_db
        memory_init_db()
        conn = _db_connect()
        try:
            cur = conn.execute("""
                SELECT content FROM semantic_memory
                WHERE memory_type = 'reflection'
                AND content LIKE ?
                ORDER BY created_at DESC
                LIMIT ?
            """, (f"%{task_type}%", limit))
            return [row[0] for row in cur.fetchall()]
        finally:
            conn.close()
    except Exception:
        return []


def _get_chain_feedback_lessons(task: str, limit: int = 3) -> list:
    """Get relevant chain feedback lessons from memory."""
    try:
        from cont import _db_connect, memory_init_db
        memory_init_db()
        conn = _db_connect()
        try:
            # Get lessons that contain KURAL (actionable rules)
            cur = conn.execute("""
                SELECT content FROM semantic_memory
                WHERE memory_type = 'chain_feedback'
                AND content LIKE '%KURAL%'
                ORDER BY importance DESC, created_at DESC
                LIMIT ?
            """, (limit,))
            lessons = []
            for row in cur.fetchall():
                # Extract just the KURAL lines for brevity
                for line in row[0].split('\n'):
                    line = line.strip()
                    if line.startswith('KURAL:'):
                        lessons.append(line)
            return lessons[:limit]
        finally:
            conn.close()
    except Exception:
        return []


# Hard token cap for total prompt
_TOKEN_HARD_CAP = 1500


def build_adaptive_prompt(
    repo_root: str,
    tool_budget: int,
    task: str,
    strict_mode: bool = True,
) -> str:
    """
    Build a dynamic system prompt based on task type.

    Simple tasks → ~600-800 tokens
    Complex tasks → ~1000-1500 tokens
    Hard cap: 1500 tokens
    """
    task_type = classify_task(task)
    intent = get_task_intent(task)
    turkish = is_turkish(task)

    # Get identity (short)
    identity = _get_identity_block()

    # Start with core
    cwd = str(Path.cwd())
    prompt = CORE_PROMPT.format(
        identity_block=identity,
        repo_root=repo_root,
        cwd=cwd,
        tool_budget=tool_budget,
    )

    # Add evidence rules (always, but short version)
    if strict_mode:
        prompt += "\n" + EVIDENCE_RULES_SHORT

    # Add anti-loop (always, short)
    prompt += "\n" + ANTI_LOOP_SHORT

    # Add task-specific modules
    if task_type in ("file_read", "file_write"):
        prompt += "\n" + FILE_OPS_RULES
    if intent == "read" or task_type == "file_read":
        prompt += "\n" + WRITE_PROTECTION
    if task_type == "search":
        prompt += "\n" + SEARCH_RULES
    if task_type == "web":
        prompt += "\n" + WEB_RULES
    if task_type == "memory":
        prompt += "\n" + MEMORY_RULES

    # Turkish support
    if turkish:
        prompt += "\n" + TURKISH_RULES

    # Conversation context (if interactive)
    prompt += "\n" + CONVERSATION_CONTEXT_SHORT

    # Workflow (always, short)
    prompt += "\n" + WORKFLOW_SHORT

    # Inject learned prompt patches (DB-based, ~100 tokens max)
    patches = _get_prompt_patches(task_type)
    if patches:
        prompt += "\n\nLEARNED RULES:"
        for patch in patches[:3]:
            prompt += f"\n- {patch}"

    # Inject relevant past reflections (~100 tokens max)
    reflections = _get_relevant_reflections(task_type, limit=2)
    if reflections:
        prompt += "\n\nPAST LESSONS:"
        for r in reflections:
            prompt += f"\n- {r}"

    # Inject chain feedback lessons (~150 tokens max)
    chain_lessons = _get_chain_feedback_lessons(task, limit=3)
    if chain_lessons:
        prompt += "\n\nÖnceki deneyimlerden öğrenilen kurallar:"
        for lesson in chain_lessons:
            prompt += f"\n- {lesson}"

    # === Learning System Injections (with token budget) ===
    if _LEARNING_AVAILABLE:
        current_tokens = estimate_tokens(prompt)
        remaining = _TOKEN_HARD_CAP - current_tokens

        # NOTE: Recipe injection removed from here — cont.py injects
        # recipes with proper context at line 3899. Was causing duplication.

        # 1. File-based patches (~150 tokens)
        if remaining > 50:
            try:
                file_patches = match_patches(task)
                if file_patches:
                    patches_text = format_patches_for_prompt(file_patches)
                    patches_tokens = estimate_tokens(patches_text)
                    if patches_tokens <= remaining:
                        prompt += "\n\n" + patches_text
                        remaining -= patches_tokens
            except Exception:
                pass

        # 3. Vocabulary (~100 tokens)
        if remaining > 30:
            try:
                vocab_text = get_relevant_vocab(task)
                if vocab_text:
                    vocab_tokens = estimate_tokens(vocab_text)
                    if vocab_tokens <= remaining:
                        prompt += "\n\n" + vocab_text
                        remaining -= vocab_tokens
            except Exception:
                pass

    # === Automation context (~50 tokens) ===
    if _AUTOMATION_AVAILABLE:
        current_tokens = estimate_tokens(prompt)
        remaining = _TOKEN_HARD_CAP - current_tokens
        if remaining > 30:
            try:
                autos = load_automations()
                enabled = [a["name"] for a in autos if a.get("enabled", True)]
                if enabled:
                    auto_text = f"AUTOMATIONS: {len(enabled)} active ({', '.join(enabled[:4])}). Use list_automations/run_automation to manage."
                    auto_tokens = estimate_tokens(auto_text)
                    if auto_tokens <= remaining:
                        prompt += "\n\n" + auto_text
            except Exception:
                pass

    # === System map project info (~100 tokens) ===
    current_tokens = estimate_tokens(prompt)
    remaining = _TOKEN_HARD_CAP - current_tokens
    if remaining > 50:
        try:
            from core.system_map import get_project_info, get_stats
            stats = get_stats()
            if stats.get("total_entries", 0) > 0:
                projects = get_project_info()
                if projects:
                    proj_list = ", ".join(p["name"] for p in projects[:8])
                    map_text = (
                        f"SYSTEM MAP: {stats['files']} files indexed. "
                        f"Projects: {proj_list}. "
                        f"Use system_search to find files/folders instantly."
                    )
                    map_tokens = estimate_tokens(map_text)
                    if map_tokens <= remaining:
                        prompt += "\n\n" + map_text
        except Exception:
            pass

    return prompt


def estimate_tokens(text: str) -> int:
    """Rough token estimate (1 token ~ 4 chars for English)."""
    return len(text) // 4
