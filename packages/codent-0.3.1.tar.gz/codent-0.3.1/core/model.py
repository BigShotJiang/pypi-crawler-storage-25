# core/model.py
"""Model resolution and management — extracted from cont.py."""

import os
import sys
from pathlib import Path

import requests

from core.sticky_config import _get_sticky_model, _set_sticky_model
from core.model_routing import select_model_for_tier, auto_select_model, detect_task_complexity

# ── DI state ──
_console = None
_debug_fn = lambda msg: None
_base_url = ""
_api_key = ""
_model_override = None
_strict_model = True
_model_mismatch_detected = False

_AVAILABLE_MODELS_CACHE = None
_ENDPOINT_MODE = None


def init_model(*, console, debug_fn, base_url, api_key="",
               model_override=None, strict_model=True):
    """Inject runtime dependencies."""
    global _console, _debug_fn, _base_url, _api_key, _model_override, _strict_model
    _console = console
    _debug_fn = debug_fn
    _base_url = base_url
    _api_key = api_key
    _model_override = model_override
    _strict_model = strict_model


# ── Model listing & validation ──

def list_available_models(use_cache: bool = True) -> list[str]:
    """
    Fetch available model IDs from /v1/models endpoint.
    Returns list of model IDs, or empty list on failure.
    Uses cache if available and use_cache=True.
    """
    global _AVAILABLE_MODELS_CACHE

    if use_cache and _AVAILABLE_MODELS_CACHE is not None:
        return _AVAILABLE_MODELS_CACHE

    try:
        url = _base_url.rstrip("/") + "/models"
        _debug_fn(f"Fetching models from {url}")
        resp = requests.get(url, timeout=10)
        if resp.status_code != 200:
            _debug_fn(f"Failed to fetch models: HTTP {resp.status_code}")
            return []
        data = resp.json()
        models = []
        for m in data.get("data", []):
            model_id = m.get("id")
            if model_id:
                models.append(model_id)
        _debug_fn(f"Found {len(models)} models: {models}")
        _AVAILABLE_MODELS_CACHE = models
        return models
    except Exception as e:
        _debug_fn(f"Error fetching models: {e}")
        return []


def validate_model_id(model_id: str) -> tuple:
    """
    Validate that a model ID exists in the available models.
    Returns (is_valid, available_models).
    """
    available = list_available_models()
    if not available:
        # Can't validate - API not reachable, allow
        return (True, [])
    return (model_id in available, available)


def find_model_like(pattern: str):
    """
    Find a model matching a pattern (case-insensitive substring match).
    Returns the model ID if exactly one match, None otherwise.
    Prints helpful messages if zero or multiple matches.
    """
    available = list_available_models()
    if not available:
        _console.print("[yellow]Cannot fetch models for --model-like matching.[/yellow]")
        return None

    pattern_lower = pattern.lower()
    matches = [m for m in available if pattern_lower in m.lower()]

    if len(matches) == 0:
        _console.print(f"[bold red]Error: No model matches '{pattern}'[/bold red]")
        _console.print(f"[yellow]Available models:[/yellow] {', '.join(available[:10])}")
        if len(available) > 10:
            _console.print(f"[dim]... and {len(available) - 10} more (use --list-models)[/dim]")
        return None
    elif len(matches) == 1:
        _debug_fn(f"--model-like '{pattern}' matched: {matches[0]}")
        return matches[0]
    else:
        _console.print(f"[bold red]Error: Multiple models match '{pattern}':[/bold red]")
        for m in matches[:10]:
            _console.print(f"  - {m}")
        if len(matches) > 10:
            _console.print(f"[dim]... and {len(matches) - 10} more[/dim]")
        _console.print("[dim]Hint: Use a more specific pattern or exact --model ID.[/dim]")
        return None


def resolve_model(*, model_override=None, model_like_override=None,
                  strict=True, save=True, skip_fetch=False,
                  auto_mode=False, current_task="", tier_override=None) -> str:
    """
    Resolve model ID with priority:
    1. tier_override → select_model_for_tier
    2. auto_mode + current_task → auto_select_model
    3. model_override (CLI --model)
    4. model_like_override (CLI --model-like)
    5. CONT_MODEL env var
    6. OPENAI_MODEL env var
    7. Persisted sticky model
    8. Auto-detect from /v1/models

    All model config is passed as parameters — no globals read.
    """
    # Check for tier override
    if tier_override:
        available = list_available_models()
        model = select_model_for_tier(tier_override, available)
        if model:
            _console.print(f"[dim]Tier override: {tier_override} → {model}[/dim]")
            return model

    # Check for auto mode
    if auto_mode and current_task:
        model = auto_select_model(current_task)
        if model:
            tier = detect_task_complexity(current_task)
            _console.print(f"[dim]Auto-selected: {model} (tier: {tier})[/dim]")
            return model

    model_source = None
    resolved_model = None
    is_override = False

    # Priority 1: CLI --model flag
    if model_override:
        _debug_fn(f"Using model from --model flag: {model_override}")
        resolved_model = model_override
        model_source = "--model flag"
        is_override = True

    # Priority 2: CLI --model-like flag (fuzzy match)
    if not resolved_model and model_like_override:
        matched = find_model_like(model_like_override)
        if matched:
            resolved_model = matched
            model_source = f"--model-like '{model_like_override}'"
            is_override = True
        else:
            sys.exit(2)  # find_model_like already printed error

    # Priority 3: CONT_MODEL env var
    if not resolved_model:
        env_model = os.environ.get("CONT_MODEL")
        if env_model:
            _debug_fn(f"Using model from CONT_MODEL: {env_model}")
            resolved_model = env_model
            model_source = "CONT_MODEL env var"
            is_override = True

    # Priority 4: OPENAI_MODEL env var
    if not resolved_model:
        env_model2 = os.environ.get("OPENAI_MODEL")
        if env_model2:
            _debug_fn(f"Using model from OPENAI_MODEL: {env_model2}")
            resolved_model = env_model2
            model_source = "OPENAI_MODEL env var"
            is_override = True

    # If we have an explicit model override, validate it if strict mode is on
    if resolved_model and is_override:
        if strict:
            is_valid, available = validate_model_id(resolved_model)
            if not is_valid and available:
                _console.print(f"[bold red]Error: Unknown model: {resolved_model}[/bold red]")
                _console.print(f"[dim]Source: {model_source}[/dim]")
                if len(available) <= 5:
                    _console.print(f"[yellow]Available models:[/yellow] {', '.join(available)}")
                else:
                    _console.print(f"[yellow]Available models ({len(available)}):[/yellow] {', '.join(available[:5])}...")
                _console.print("[dim]Hint: Run --list-models to see all available models, or use --no-strict-model to skip validation.[/dim]")
                sys.exit(2)

        # Persist if saving is enabled
        if save:
            _set_sticky_model(resolved_model)

        return resolved_model

    # Priority 5: config.toml [llm] model (backend'e göre)
    try:
        config_toml = Path(__file__).parent.parent / "config.toml"
        if config_toml.exists():
            import tomllib
            with open(config_toml, "rb") as f:
                toml_data = tomllib.load(f)
            llm_cfg = toml_data.get("llm", {})
            backend = llm_cfg.get("backend", "lm_studio")
            if backend == "ollama":
                toml_model = llm_cfg.get("ollama_model") or llm_cfg.get("model")
            else:
                toml_model = llm_cfg.get("model")
            if toml_model:
                _debug_fn(f"Using model from config.toml [{backend}]: {toml_model}")
                if save:
                    _set_sticky_model(toml_model)
                return toml_model
    except Exception as e:
        _debug_fn(f"config.toml read error: {e}")

    # Priority 6: Persisted sticky model
    sticky = _get_sticky_model()
    if sticky:
        _debug_fn(f"Using sticky model from config: {sticky}")
        # Best-effort validation: check if still available
        if not skip_fetch:
            is_valid, available = validate_model_id(sticky)
            if not is_valid and available:
                # Stale model — auto-select best available and save it
                _console.print(
                    f"[yellow]Sticky model '{sticky}' artık yok, "
                    f"yeni model seçiliyor...[/yellow]"
                )
                chosen = available[0]
                for prefix in ['qwen3-coder', 'nemotron', 'qwen2.5']:
                    for m in available:
                        if prefix in m.lower():
                            chosen = m
                            break
                    else:
                        continue
                    break
                _set_sticky_model(chosen)
                _console.print(f"[dim]Yeni sticky model: {chosen}[/dim]")
                return chosen
            else:
                # Sticky model is valid, use it
                _console.print(f"[dim]Using sticky model: {sticky}[/dim]")
                return sticky
        else:
            # Skip fetch, trust sticky
            _console.print(f"[dim]Using sticky model: {sticky}[/dim]")
            return sticky

    # Priority 6: Auto-detect from /v1/models (prefer qwen3-coder)
    models = list_available_models()
    if models:
        # Prefer models in this order
        chosen = models[0]
        for prefix in ['qwen3-coder', 'nemotron', 'qwen2.5']:
            for m in models:
                if prefix in m.lower():
                    chosen = m
                    break
            else:
                continue
            break
        _debug_fn(f"No model specified, auto-selected: {chosen}")
        _console.print(f"[dim]Auto-selected model: {chosen}[/dim]")

        # Persist for future runs
        if save:
            _set_sticky_model(chosen)
            _console.print(f"[dim]Saved as sticky model. Use --forget-model to reset.[/dim]")

        return chosen

    # No models available - fail with clear error
    _console.print("[bold red]Error: LM Studio is running but no models are loaded.[/bold red]")
    _console.print("[yellow]Hint:[/yellow] Load a model in LM Studio, or specify one with --model or CONT_MODEL env var.")
    sys.exit(1)


# ── Endpoint mode helpers ──

def flatten_messages_to_prompt(messages: list) -> str:
    """Flatten chat messages into a single prompt string for /v1/completions."""
    parts = []
    for msg in messages:
        role = msg.get("role", "user").upper()
        content = msg.get("content", "")
        if content:
            parts.append(f"{role}:\n{content}")
    return "\n\n".join(parts) + "\n\nASSISTANT:\n"


def probe_chat_endpoint(model: str) -> bool:
    """Test if chat completions endpoint works. Returns True if OK."""
    try:
        url = _base_url.rstrip("/") + "/chat/completions"
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": "Hi"}],
            "max_tokens": 5
        }
        headers = {"Content-Type": "application/json"}
        if _api_key:
            headers["Authorization"] = f"Bearer {_api_key}"

        _debug_fn(f"Probing chat endpoint: {url}")
        resp = requests.post(url, json=payload, headers=headers, timeout=5)
        _debug_fn(f"Chat probe response: HTTP {resp.status_code}")

        if resp.status_code == 200:
            return True
        if resp.status_code in (400, 404, 422):
            return False
        return True
    except Exception as e:
        _debug_fn(f"Chat probe error: {e}")
        return True


def determine_endpoint_mode(model: str) -> str:
    """Determine chat vs completions endpoint. Caches result."""
    global _ENDPOINT_MODE

    if _ENDPOINT_MODE:
        return _ENDPOINT_MODE

    if probe_chat_endpoint(model):
        _ENDPOINT_MODE = "chat"
        _debug_fn("Using chat completions endpoint")
    else:
        _ENDPOINT_MODE = "completions"
        _debug_fn("Falling back to completions endpoint")
        _console.print("[dim]Note: Using completions endpoint (chat not supported by model)[/dim]")

    return _ENDPOINT_MODE


def check_response_model(requested_model: str, response) -> None:
    """Check if API response model matches requested. Warns on mismatch."""
    global _model_mismatch_detected

    has_override = _model_override or os.environ.get("CONT_MODEL") or os.environ.get("OPENAI_MODEL")
    if not has_override or not _strict_model:
        return

    response_model = None
    if hasattr(response, 'model'):
        response_model = response.model
    elif isinstance(response, dict):
        response_model = response.get('model')

    if response_model and response_model != requested_model:
        _console.print(f"[bold yellow]Warning: API returned different model[/bold yellow]")
        _console.print(f"  Requested: {requested_model}")
        _console.print(f"  Returned:  {response_model}")
        _console.print("[dim]This may indicate the server ignored your model selection.[/dim]")
        _model_mismatch_detected = True


def get_endpoint_mode() -> str:
    """Get current endpoint mode."""
    return _ENDPOINT_MODE


def get_model_mismatch_detected() -> bool:
    """Check if model mismatch was detected."""
    return _model_mismatch_detected


def reset_endpoint_mode():
    """Reset cached endpoint mode."""
    global _ENDPOINT_MODE
    _ENDPOINT_MODE = None
