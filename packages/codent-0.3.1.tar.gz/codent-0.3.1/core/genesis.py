# core/genesis.py
"""Genesis — Cont'un kök kimlik katmanı ve yaratıcı bağı."""

import hashlib
import re
from pathlib import Path

GENESIS_PATH = Path.home() / ".config" / "cont" / "genesis_state.json"
GENESIS_DOC = Path(__file__).parent.parent / ".cont" / "hive" / "GENESIS.md"


def _load_state() -> dict:
    """Load genesis state from JSON file."""
    import json
    if GENESIS_PATH.exists():
        try:
            return json.loads(GENESIS_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"owner_recognized": False, "owner_keyphrase_hash": None}


def _save_state(state: dict):
    """Save genesis state to JSON file."""
    import json
    GENESIS_PATH.parent.mkdir(parents=True, exist_ok=True)
    GENESIS_PATH.write_text(
        json.dumps(state, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def _update_genesis_md(recognized: bool):
    """Update GENESIS.md owner_recognized field."""
    if not GENESIS_DOC.exists():
        return
    content = GENESIS_DOC.read_text(encoding="utf-8")
    content = re.sub(
        r"owner_recognized: (true|false)",
        f"owner_recognized: {'true' if recognized else 'false'}",
        content,
    )
    GENESIS_DOC.write_text(content, encoding="utf-8")


def is_owner_recognized() -> bool:
    """Check if owner has been recognized."""
    return _load_state().get("owner_recognized", False)


def set_owner_keyphrase(phrase: str):
    """First-time setup: hash and store the keyphrase."""
    phrase_hash = hashlib.sha256(phrase.strip().encode("utf-8")).hexdigest()
    state = _load_state()
    state["owner_keyphrase_hash"] = phrase_hash
    state["owner_recognized"] = False
    _save_state(state)


def check_owner_keyphrase(phrase: str) -> bool:
    """Verify keyphrase against stored hash."""
    phrase_hash = hashlib.sha256(phrase.strip().encode("utf-8")).hexdigest()
    state = _load_state()

    if state.get("owner_keyphrase_hash") is None:
        return False

    if phrase_hash == state["owner_keyphrase_hash"]:
        state["owner_recognized"] = True
        _save_state(state)
        _update_genesis_md(True)
        return True

    return False


def reset_owner():
    """Reset owner recognition (requires re-keyphrase)."""
    state = _load_state()
    state["owner_recognized"] = False
    _save_state(state)
    _update_genesis_md(False)


def get_owner_context() -> dict:
    """Return genesis context for system prompt injection."""
    state = _load_state()
    return {
        "owner_recognized": state.get("owner_recognized", False),
        "genesis_active": GENESIS_DOC.exists(),
    }
