#!/usr/bin/env python3
"""Anomaly detection tools — 3 katman: kolon, temporal, cross-entity.

Usage: python3 core/anomaly_tools.py <command> <args...>

Katman 1 — Kolon:
  zscore <path> <column> [threshold]    Z-score anomali
  iqr <path> <column> [multiplier]      IQR anomali
  modified_zscore <path> <column>       MAD-based anomali
  column_report <path> [columns]        Tüm kolonlar anomali raporu

Katman 2 — Temporal:
  spike <path> <entity> <time> <value> [pct]  Ani değişim tespiti
  trend_break <path> <entity> <time> <value>  Trend kırılması
  pattern <path> <entity> <time> <col1> <col2> Tutarsızlık tespiti

Katman 3 — Cross-entity:
  peer <path> <entity> <group> <value_cols>   Peer karşılaştırma
  isolation_forest <path> <columns> [contamination]  IF anomali
  anomaly_features <path> <entity> <time> <columns>  Anomali→feature
"""

import json
import sys
from pathlib import Path
import numpy as np


class _NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (np.integer,)): return int(obj)
        if isinstance(obj, (np.floating, np.float64)): return float(obj)
        if isinstance(obj, (np.bool_,)): return bool(obj)
        if isinstance(obj, np.ndarray): return obj.tolist()
        return super().default(obj)

def _dumps(obj, **kw):
    return json.dumps(obj, cls=_NpEncoder, **kw)

def _load(path, table=None):
    import pandas as pd
    p = Path(path)
    if p.suffix == ".duckdb":
        import duckdb
        con = duckdb.connect(str(p), read_only=True)
        df = con.execute(f"SELECT * FROM {table}").df()
        con.close()
        return df
    return pd.read_parquet(p) if p.suffix == ".parquet" else pd.read_csv(p)


# ═══ KATMAN 1: Kolon anomalisi ═══

def cmd_zscore(path, column, threshold=3.0, table=None):
    df = _load(path, table)
    s = df[column].dropna()
    mean, std = float(s.mean()), float(s.std())
    if std == 0:
        print(_dumps({"column": column, "method": "zscore", "anomalies": 0, "note": "std=0, no variance"}))
        return
    z = (s - mean) / std
    anomalies = s[z.abs() > float(threshold)]
    print(_dumps({
        "column": column, "method": "zscore", "threshold": float(threshold),
        "mean": round(mean, 4), "std": round(std, 4),
        "total": len(s), "anomalies": len(anomalies),
        "anomaly_rate": round(len(anomalies)/len(s), 4),
        "top_anomalies": [{"index": int(i), "value": round(float(v), 4), "zscore": round(float(z[i]), 4)}
                          for i, v in anomalies.head(10).items()]
    }, indent=2))


def cmd_iqr(path, column, multiplier=1.5, table=None):
    df = _load(path, table)
    s = df[column].dropna()
    q1, q3 = float(s.quantile(0.25)), float(s.quantile(0.75))
    iqr = q3 - q1
    lower, upper = q1 - float(multiplier)*iqr, q3 + float(multiplier)*iqr
    anomalies = s[(s < lower) | (s > upper)]
    print(_dumps({
        "column": column, "method": "iqr", "multiplier": float(multiplier),
        "q1": round(q1, 4), "q3": round(q3, 4), "iqr": round(iqr, 4),
        "lower": round(lower, 4), "upper": round(upper, 4),
        "total": len(s), "anomalies": len(anomalies),
        "anomaly_rate": round(len(anomalies)/len(s), 4),
    }, indent=2))


def cmd_modified_zscore(path, column, table=None):
    df = _load(path, table)
    s = df[column].dropna()
    median = float(s.median())
    mad = float((s - median).abs().median())
    if mad == 0:
        print(_dumps({"column": column, "method": "modified_zscore", "anomalies": 0, "note": "MAD=0"}))
        return
    modified_z = 0.6745 * (s - median) / mad
    anomalies = s[modified_z.abs() > 3.5]
    print(_dumps({
        "column": column, "method": "modified_zscore",
        "median": round(median, 4), "mad": round(mad, 4),
        "total": len(s), "anomalies": len(anomalies),
        "anomaly_rate": round(len(anomalies)/len(s), 4),
    }, indent=2))


def cmd_column_report(path, columns=None, table=None):
    import pandas as pd
    df = _load(path, table)
    numeric = df.select_dtypes(include=["number"]).columns if not columns else columns.split(",")
    report = []
    for col in numeric:
        s = df[col].dropna()
        if len(s) < 10 or s.std() == 0:
            continue
        skew = float(s.skew())
        # Pick method based on skewness
        method = "iqr" if abs(skew) > 2 else "zscore"
        q1, q3 = s.quantile(0.25), s.quantile(0.75)
        iqr = q3 - q1
        if method == "iqr" and iqr > 0:
            lower, upper = q1 - 1.5*iqr, q3 + 1.5*iqr
            count = int(((s < lower) | (s > upper)).sum())
        else:
            z = (s - s.mean()) / s.std()
            count = int((z.abs() > 3).sum())
        report.append({"column": col, "method": method, "anomalies": count,
                       "rate": round(count/len(s), 4), "skewness": round(skew, 4)})
    report.sort(key=lambda x: -x["anomalies"])
    print(_dumps({"columns_analyzed": len(report), "report": report}, indent=2))


# ═══ KATMAN 2: Temporal anomali ═══

def cmd_spike(path, entity_col, time_col, value_col, pct_threshold=50, table=None):
    df = _load(path, table)
    import pandas as pd
    df[value_col] = pd.to_numeric(df[value_col], errors='coerce')
    spikes = []
    for eid, g in df.groupby(entity_col):
        g = g.sort_values(time_col)
        pct = g[value_col].pct_change() * 100
        for idx, val in pct.items():
            if abs(val) > float(pct_threshold):
                row = g.loc[idx]
                spikes.append({"entity": str(eid), "period": str(row[time_col]),
                              "value": float(row[value_col]) if row[value_col] == row[value_col] else None,
                              "pct_change": round(float(val), 2)})
    spikes.sort(key=lambda x: -abs(x.get("pct_change", 0)))
    print(_dumps({"total_spikes": len(spikes), "threshold_pct": float(pct_threshold),
                  "spikes": spikes[:50]}, indent=2))


def cmd_trend_break(path, entity_col, time_col, value_col, table=None):
    df = _load(path, table)
    import pandas as pd
    df[value_col] = pd.to_numeric(df[value_col], errors='coerce')
    breaks = []
    for eid, g in df.groupby(entity_col):
        g = g.sort_values(time_col)
        vals = g[value_col].dropna()
        if len(vals) < 6:
            continue
        mid = len(vals) // 2
        mean_first = float(vals.iloc[:mid].mean())
        mean_second = float(vals.iloc[mid:].mean())
        diff = abs(mean_second - mean_first)
        overall_std = float(vals.std())
        if overall_std > 0 and diff / overall_std > 1.5:
            breaks.append({"entity": str(eid), "first_half_mean": round(mean_first, 2),
                          "second_half_mean": round(mean_second, 2),
                          "shift": round(mean_second - mean_first, 2),
                          "shift_std": round(diff / overall_std, 2)})
    breaks.sort(key=lambda x: -abs(x["shift_std"]))
    print(_dumps({"total_breaks": len(breaks), "breaks": breaks[:30]}, indent=2))


def cmd_pattern(path, entity_col, time_col, col1, col2, table=None):
    """Detect when two columns move in unexpected directions."""
    df = _load(path, table)
    import pandas as pd
    for c in [col1, col2]:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    mismatches = []
    for eid, g in df.groupby(entity_col):
        g = g.sort_values(time_col)
        d1 = g[col1].pct_change()
        d2 = g[col2].pct_change()
        for idx in g.index[1:]:
            v1, v2 = d1.get(idx, 0), d2.get(idx, 0)
            if v1 != v1 or v2 != v2: continue
            # Mismatch: one goes up significantly, other doesn't
            if abs(v1) > 0.3 and abs(v2) < 0.05:
                mismatches.append({"entity": str(eid), "period": str(g.loc[idx, time_col]),
                                  f"{col1}_change": round(float(v1*100), 1),
                                  f"{col2}_change": round(float(v2*100), 1),
                                  "type": f"{col1} changed but {col2} didn't"})
    print(_dumps({"mismatches": len(mismatches), "details": mismatches[:30]}, indent=2))


# ═══ KATMAN 3: Cross-entity anomali ═══

def cmd_peer(path, entity_col, group_col, value_cols, table=None):
    df = _load(path, table)
    import pandas as pd
    cols = value_cols.split(",")
    results = []
    for col in cols:
        df[col] = pd.to_numeric(df[col], errors='coerce')
        for gname, g in df.groupby(group_col):
            mean = float(g[col].mean())
            std = float(g[col].std())
            if std == 0: continue
            g_z = (g[col] - mean) / std
            outliers = g[g_z.abs() > 2]
            for idx, row in outliers.iterrows():
                results.append({"entity": str(row[entity_col]), "group": str(gname),
                               "column": col, "value": round(float(row[col]), 4),
                               "group_mean": round(mean, 4), "zscore": round(float(g_z[idx]), 4)})
    results.sort(key=lambda x: -abs(x["zscore"]))
    print(_dumps({"peer_anomalies": len(results), "details": results[:30]}, indent=2))


def cmd_isolation_forest(path, columns, contamination=0.05, table=None):
    from sklearn.ensemble import IsolationForest
    df = _load(path, table)
    cols = columns.split(",")
    X = df[cols].fillna(0)
    clf = IsolationForest(contamination=float(contamination), random_state=42, n_jobs=-1)
    labels = clf.fit_predict(X)
    scores = clf.decision_function(X)
    n_anomaly = int((labels == -1).sum())
    print(_dumps({
        "method": "isolation_forest", "features": len(cols),
        "total": len(X), "anomalies": n_anomaly,
        "anomaly_rate": round(n_anomaly/len(X), 4),
        "contamination": float(contamination),
        "score_range": {"min": round(float(scores.min()), 4), "max": round(float(scores.max()), 4)},
    }, indent=2))


def cmd_anomaly_features(path, entity_col, time_col, columns, table=None):
    """Create anomaly scores as features for ML."""
    from sklearn.ensemble import IsolationForest
    import pandas as pd
    df = _load(path, table)
    cols = columns.split(",")
    X = df[cols].fillna(0)

    # IF score
    clf = IsolationForest(contamination=0.05, random_state=42, n_jobs=-1)
    df["anomaly_if_score"] = clf.decision_function(X)
    df["anomaly_if_label"] = (clf.predict(X) == -1).astype(int)

    # Temporal spike count per entity
    for c in cols[:5]:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    spike_counts = {}
    for eid, g in df.groupby(entity_col):
        g = g.sort_values(time_col)
        total_spikes = 0
        for c in cols[:5]:
            pct = g[c].pct_change().abs()
            total_spikes += int((pct > 0.5).sum())
        spike_counts[eid] = total_spikes
    df["anomaly_spike_count"] = df[entity_col].map(spike_counts).fillna(0).astype(int)

    # Peer deviation (vs group mean)
    for c in cols[:3]:
        df[f"anomaly_peer_{c}"] = df.groupby(entity_col)[c].transform(
            lambda x: (x - x.mean()) / (x.std() + 1e-8)
        )

    new_cols = [c for c in df.columns if c.startswith("anomaly_")]
    print(_dumps({
        "new_features": new_cols,
        "count": len(new_cols),
        "sample": df[new_cols].head(5).to_dict('records'),
    }, indent=2))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    cmd = sys.argv[1]
    table = None; args = []; i = 2
    while i < len(sys.argv):
        if sys.argv[i] == "--table" and i+1 < len(sys.argv): table = sys.argv[i+1]; i += 2
        else: args.append(sys.argv[i]); i += 1

    cmds = {
        "zscore": lambda: cmd_zscore(args[0], args[1], args[2] if len(args)>2 else 3.0, table),
        "iqr": lambda: cmd_iqr(args[0], args[1], args[2] if len(args)>2 else 1.5, table),
        "modified_zscore": lambda: cmd_modified_zscore(args[0], args[1], table),
        "column_report": lambda: cmd_column_report(args[0], args[1] if len(args)>1 else None, table),
        "spike": lambda: cmd_spike(args[0], args[1], args[2], args[3], args[4] if len(args)>4 else 50, table),
        "trend_break": lambda: cmd_trend_break(args[0], args[1], args[2], args[3], table),
        "pattern": lambda: cmd_pattern(args[0], args[1], args[2], args[3], args[4], table),
        "peer": lambda: cmd_peer(args[0], args[1], args[2], args[3], table),
        "isolation_forest": lambda: cmd_isolation_forest(args[0], args[1], args[2] if len(args)>2 else 0.05, table),
        "anomaly_features": lambda: cmd_anomaly_features(args[0], args[1], args[2], args[3], table),
    }
    if cmd not in cmds: print(f"Unknown: {cmd}"); sys.exit(1)
    cmds[cmd]()
