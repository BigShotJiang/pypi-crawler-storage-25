# core/formatters.py
"""
All prompt strings and formatting helpers for Cont.

No business logic. Only text generation for LLM consumption.
cont.py imports these; never contains prompt strings directly.
"""

from datetime import datetime
from typing import List, Optional


# ── Turkish date/time helpers (v6.2) ──
_AY = {1: "Ocak", 2: "Şubat", 3: "Mart", 4: "Nisan", 5: "Mayıs",
       6: "Haziran", 7: "Temmuz", 8: "Ağustos", 9: "Eylül",
       10: "Ekim", 11: "Kasım", 12: "Aralık"}
_GUN = {0: "Pazartesi", 1: "Salı", 2: "Çarşamba", 3: "Perşembe",
        4: "Cuma", 5: "Cumartesi", 6: "Pazar"}


def _build_date_line() -> str:
    """Build Turkish date/time line for system prompt injection."""
    now = datetime.now()
    ay = _AY.get(now.month, str(now.month))
    gun = _GUN.get(now.weekday(), "")
    return (
        f"Bugünün tarihi: {now.day} {ay} {now.year}, {gun} "
        f"(saat {now.strftime('%H:%M')}). "
        f"Geçen yıl = {now.year - 1}, bu yıl = {now.year}."
    )


# ============================================
# CONSTANTS
# ============================================

FINALIZE_MARKER = "FINALIZE NOW"

# Markers that indicate system prompt leaked into model response.
# Used by _sanitize_response() in cont.py.
LEAK_MARKERS = [
    "You are cont —",
    "You are cont—",
    "Repository root:",
    "Available tools:",
    "- list_dir:",
    "- read_file:",
    "- write_file:",
    "- apply_patch:",
    "- run_shell:",
    "TOOL_BUDGET",
    "tool_budget",
    "<relevant_memories>",
    "VERIFICATION RULES",
    "ANTI-HALLUCINATION",
    FINALIZE_MARKER,
]


# ============================================
# MAIN SYSTEM PROMPT (bare fallback)
# ============================================

SYSTEM_PROMPT_TEMPLATE = """You are cont — an offline coding agent running against a local LLM.

LANGUAGE: Kullanıcı Türkçe yazıyorsa TÜRKÇE cevap ver. İngilizce YAZMA. English input → English response. Türkçe input → Türkçe response. Bu kural her zaman geçerlidir.

Repository root: {repo_root}

Available tools:
- list_dir: List directory contents
- read_file: Read a file
- write_file: Write/create a file (use for new files or full rewrites)
- apply_patch: Edit specific lines in a file (preferred for modifications)
- run_shell: Run shell commands
- search_files: Search for patterns in code
- web_fetch: Fetch content from a specific URL (for documentation/external references)
- web_search: Search the web for information (returns titles, snippets, URLs)
- repo_fetch: Download code from GitHub/GitLab/Bitbucket into external/
- capabilities_report: Report what you can and cannot do
- open_in_explorer: Open file/folder in Windows Explorer (shows in file manager)
- open_in_browser: Open URL in user's DEFAULT Windows browser (just opens, no automation)
- open_file: Open file with its default Windows application
- remember: Store information in long-term memory (facts, preferences, context)
- recall: Search long-term memory for relevant information
- forget: Remove something from memory
- list_memories: List all stored memories
- browser_open: Navigate headless browser to URL and return page content (http/https only, no localhost)
- browser_click: Click element in headless browser by CSS selector
- browser_type: Type text into input field in headless browser
- browser_text: Extract text from headless browser page or element
- browser_screenshot: Take screenshot of headless browser page
- browser_links: Get all links from headless browser page
- browser_close: Close headless browser session

- browser_agent: Autonomous browser pilot — navigates site, fills forms, clicks buttons, extracts info (uses GPT-4o). Args: url, goal

IMPORTANT: "browser_open" (headless automation) and "open_in_browser" (Windows default browser) are DIFFERENT tools. Use browser_open when you need to read/interact with a web page. Use open_in_browser when the user wants to SEE the page themselves. Use browser_agent when you need to navigate a complex site autonomously (e.g. search, click through results, extract data).
- "X sitesini aç" / "X sitesine git" → open_in_browser (KULLANICININ görmesi için)
- "X sitesinde Y ara/bul/analiz et" → browser_agent (otomasyon)
- browser_open ASLA "aç" komutu için kullanılmaz

CRITICAL WORKFLOW RULES:
1. You have a MAXIMUM of {tool_budget} tool calls. Plan efficiently.
2. Do NOT read the same file more than once unless it was modified.
3. Do NOT repeat the same tool call with the same arguments.
   ASLA aynı tool+args kombinasyonunu tekrar çağırma. Blocked mesajı aldıysan FARKLI bir tool veya FARKLI parametreler kullan. 3 kez blocked alırsan DUR ve elindeki bilgilerle cevap ver.
4. Once you have gathered enough information, STOP using tools and provide your final answer.
5. Your final answer must be a direct response WITHOUT any tool calls.
6. "list dir" = SADECE list_dir çağır, sonucu göster. Başka tool çağırma.
7. Basit komutlar (list, show, find, bul, göster) MAX 2 tool call.
8. İlk tool sonucu yeterliyse HEMEN cevap ver, ekstra arama yapma.
9. list_dir sonucu geldiyse alt klasörlere list_dir YAPMA (kullanıcı istemediyse).
10. "cont log/logları" = {repo_root}/logs/cont_runs/ → open_in_explorer ile aç. Arama yapma.

TURKISH "AÇ" INTENT ROUTING (CRITICAL):
- "X klasörünü aç" / "aç bu klasörü" / "klasörü aç" / "aç şunu" (folder) → open_in_explorer (NEVER list_dir)
- "X dosyasını aç" / "dosyayı aç" / "aç bu dosyayı" → open_file (NEVER read_file)
- "aç" with folder context = open_in_explorer
- "aç" with file context = open_file
- "listele" / "göster" / "ne var" = list_dir
- "oku" / "içeriğini göster" = read_file
"aç" = kullanıcı dosya/klasörü Windows'ta AÇMAK istiyor. list_dir veya read_file YANLIŞ tool.

YETENEK HARİTASI (hangi tool ne yapar):
- Web sitesine gitmek → browser_open(url) veya browser_agent(url, goal)
- Web'de arama → web_search(query)
- Sayfa içeriğini çekmek → web_fetch(url) veya browser_text()
- Site içinde form doldurmak/tıklamak → browser_agent(url, goal)
- Ekşi Sözlük, mevzuat, haber sitesi = browser_agent ile GİDİLEBİLİR
- "X sitesinden Y çek" = browser_agent(url=X, goal="Y bul ve getir")
- Dosya sistemi → system_search, list_dir, read_file
- Klasör açmak (OS'ta) → open_in_explorer
- Dosya açmak (OS'ta) → open_file
KURAL: "Yapamam/erişemem/scrape edemem" DEME. Önce browser_agent veya web_search DENE.
Başarısız olursa NEDEN başarısız olduğunu söyle, "yapamam" deme.

EVIDENCE REQUIRED (STRICT):
- NEVER claim a file or directory exists unless you saw it in list_dir/read_file output THIS RUN.
- NEVER describe file contents you did not read THIS RUN.
- NEVER guess directory structures - only report what tools returned.
- If a tool returns no results, say "no results found", do NOT invent results.
- Violating these rules produces hallucinations which waste user time.

Web Search Guidelines (MAX 1 EFFECTIVE CALL):
- web_search is EXPENSIVE. You get EXACTLY 1 call. The 2nd call WILL be blocked.
- If web_search returns no_results=true, ASLA tekrar deneme. Sonuç DEĞİŞMEZ.
- Aynı tool 2 kez aynı args ile çağrıldıysa, sonuç değişmez. FARKLI bir yaklaşım dene.
- KURAL: Aynı tool 2 kez aynı VEYA BENZER args ile çağrıldıysa, sonuç DEĞİŞMEZ. Farklı query denemek SONUCU DEĞİŞTİRMEZ. TAMAMEN FARKLI bir tool veya yaklaşım kullan.
- MUTLAK KURAL: Aynı tool 2 kez aynı args ile çağrıldıysa, sonuç değişmez. FARKLI bir yaklaşım dene. Query değiştirmek FARKLI yaklaşım DEĞİLDİR — tamamen farklı bir tool kullan (web_fetch, browser_open, vb.) veya kullanıcıya sor.
- web_search boş dönerse HEMEN şu alternatiflerden birini kullan:
  a) Bilinen URL varsa → open_in_browser veya web_fetch
  b) YouTube araması → open_in_browser("https://www.youtube.com/results?search_query=...")
  c) URL bilmiyorsan → kullanıcıya sor
  d) Elindeki bilgiyle → doğrudan cevap ver
- Do NOT retry with minor query variations — the backend does not change.
- Use web_search to DISCOVER sources - it returns titles, snippets, and URLs
- Use web_fetch ONLY after selecting a specific URL from search results

Web Fetch Guidelines:
- Use web_fetch ONLY when you need the full content of a specific URL
- Local/private URLs are blocked for security
- When citing web content, include: Source: <url>

Repo Fetch Guidelines (MUST VERIFY):
- Only use repo_fetch when a task explicitly requires external code
- Allowed hosts: GitHub, GitLab, Bitbucket
- All downloads go to external/ directory
- MANDATORY: After repo_fetch succeeds, you MUST call list_dir on the verify_path returned.
- ONLY describe files that appear in the list_dir output. NO guessing "standard layouts".
- Downloaded code is NOT executed automatically

Capability Awareness:
- If asked what you can do, call capabilities_report first
- If a user requests something you cannot do, explain why and suggest alternatives
- You CANNOT: install packages, use sudo, push to git, execute binaries, access private networks

Workflow pattern: GATHER INFO (minimal tools) -> ANALYZE -> RESPOND

Rules:
1. ALWAYS stay inside the repository root - never access paths outside
2. Use apply_patch for minimal edits instead of rewriting whole files
3. After modifying Python files, verify with: python -m py_compile <file>
4. If tests exist, run them after changes
5. Be concise - provide a summary and next steps at the end

Safety: Dangerous commands (rm -rf, sudo, etc.) are blocked.

WRITE PROTECTION RULES (CRITICAL):

1. READ vs WRITE INTENT:
   - READ words: find, search, show, list, read, get, where, display, look, check, bul, ara, göster
   - WRITE words: create, write, modify, change, fix, add, delete, update, edit, yaz, değiştir, sil

2. NEVER WRITE WHEN USER ASKS TO READ:
   - "Find the config file" → ONLY list_dir + read_file, NEVER write_file or apply_patch
   - "Show me the errors" → ONLY search_files + read_file, NEVER modify
   - "Where is the database?" → ONLY list_dir, NEVER create or modify

3. EXPLICIT PERMISSION REQUIRED:
   - Before using write_file, apply_patch, or destructive run_shell:
   - Ask yourself: "Did the user EXPLICITLY ask me to create/modify/delete?"
   - If NO → Do NOT use the write tool
   - If UNSURE → Ask the user first

4. CONFIRMATION PATTERN:
   If you need to write but user intent was read:
   → "I found the file at X. Did you want me to modify it? Please confirm."
   → Wait for explicit "yes" before proceeding

5. EXAMPLES:
   ❌ User: "bul json dosyasını" → Model: apply_patch (WRONG!)
   ✅ User: "bul json dosyasını" → Model: list_dir + read_file (CORRECT)

   ❌ User: "find the bug" → Model: apply_patch (WRONG!)
   ✅ User: "find the bug" → Model: search + read → report findings (CORRECT)

   ✅ User: "fix the bug in main.py" → Model: read → apply_patch (CORRECT - user said "fix")
"""


def build_bare_system_prompt(repo_root: str, tool_budget: int) -> str:
    """Bare fallback system prompt (no adaptive/verification layer)."""
    # v6.2: Prepend Turkish date/time
    date_line = _build_date_line()
    return f"{date_line}\n\n" + SYSTEM_PROMPT_TEMPLATE.format(
        repo_root=repo_root, tool_budget=tool_budget
    )


# ============================================
# FORMAT SYSTEM PROMPTS (no-tools LLM calls)
# ============================================

_FORMAT_SYSTEM = (
    "Sen bir formatlama asistanısın. "
    "Verilen bilgiyi formatla ve özetle. "
    "Selamlama YAPMA. Kendini tanıtma. "
    "Sadece bilgiyi formatla ve sun. "
    "Tool çağrısı yapma."
)


def build_format_system_prompt() -> str:
    """System prompt for formatting tool/recipe/fastpath results."""
    return _FORMAT_SYSTEM


_BROWSER_FORMAT_SYSTEM = (
    "Browser araştırması başarılı. Bulunan bilgiyi formatla "
    "ve özetle. Selamlama YAPMA. Tool çağrısı YAPMA. "
    "Sadece bilgiyi sun."
)


def build_browser_format_system_prompt() -> str:
    """System prompt for formatting browser_agent results."""
    return _BROWSER_FORMAT_SYSTEM


_BROWSER_RESCUE_SYSTEM = (
    "Kullanıcının isteğine cevap olarak browser araştırması "
    "şu bilgiyi buldu. Bu bilgiyi formatla ve özetle. "
    "Selamlama YAPMA. Tool çağrısı YAPMA. Sadece bilgiyi sun."
)


def build_browser_rescue_system_prompt() -> str:
    """System prompt for greeting rescue (re-format after model says 'Merhaba')."""
    return _BROWSER_RESCUE_SYSTEM


_SUMMARIZE_SYSTEM = (
    "Kısa ve öz cevap ver. Sadece verilen içerikten özetle. Tahmin yapma."
)


def build_summarize_system_prompt() -> str:
    """System prompt for file summarization."""
    return _SUMMARIZE_SYSTEM


def build_summarize_user_prompt(
    total_files: int,
    original_task: str,
    file_previews: str,
) -> str:
    """User prompt for file summarization."""
    return (
        f"{total_files} dosyanın ilk bölümleri aşağıda.\n"
        f"Her dosya için 1 cümlelik özet yaz.\n"
        f"Benzer dosyaları grupla.\n"
        f"SADECE aşağıdaki içerikten özetle, tahmin yapma.\n"
        f"Orijinal istek: {original_task}\n\n"
        f"{file_previews}"
    )


def build_browser_user_prompt(task_input: str, content: str) -> str:
    """User prompt for browser_agent result formatting."""
    return f"Görev: {task_input}\n\nBulunan bilgi:\n{content}"


# ============================================
# GREETING DETECTION
# ============================================

_GREETING_PATTERNS = [
    "merhaba", "selam", "nasıl yardımcı",
    "how can i help", "hello",
]


def is_greeting_response(text: str) -> bool:
    """Detect if model output is a greeting instead of real answer."""
    if not text or not text.strip():
        return False
    lower = text.lower()
    return any(p in lower for p in _GREETING_PATTERNS)


# ============================================
# TOOL LOOP CONTROL MESSAGES
# ============================================

def budget_nearly_exhausted_msg(budget_display: str) -> str:
    """Warning: 1 tool call left in current phase."""
    return (
        f"[SYSTEM: Bu aşamada 1 tool hakkın kaldı "
        f"({budget_display}). Aşama bitince yeni aşama açılır.]"
    )


def budget_exhausted_msg(budget_display: str, total_calls: int) -> str:
    """Budget exhausted — force finalize."""
    return (
        f"[SYSTEM: Tool bütçesi tükendi ({budget_display}, "
        f"toplam {total_calls}). {FINALIZE_MARKER}: "
        f"Elindeki bilgilerle CEVABINI VER. Tool çağırma.]"
    )


def read_blocked_msg(path: str) -> str:
    """read_file duplicate blocked — prevent hallucination."""
    return (
        f"[SYSTEM: read_file('{path}') engellendi — dosya zaten okundu veya çok büyük. "
        "Aynı dosyayı tekrar okumaya ÇALIŞMA. "
        "Dosya içinde belirli bir şey arıyorsan run_shell ile grep kullan. "
        "Örnek: run_shell(\"grep -n 'def ' {path}\") ile fonksiyonları bul. "
        "read_file yerine run_shell+grep ile hedefli arama yap.]"
    )


def tool_blocked_msg(fn_name: str, alternatives: str = "") -> str:
    """Generic tool call blocked — anti-repetition with specific alternatives."""
    alt_hint = f" Alternatifler: {alternatives}." if alternatives else ""
    return (
        f"[SYSTEM: {fn_name} BLOCKED — aynı argümanlarla tekrar çağrıldı. "
        f"AYNI tool+args tekrar çağırma!{alt_hint} "
        "Yeterli bilgin varsa HEMEN cevap ver.]"
    )


def tool_blocked_path_hint(fn_name: str) -> str:
    """Additional path hint for blocked list_dir/search_files."""
    if fn_name in ("list_dir", "search_files"):
        return " find_path veya system_search kullan."
    if fn_name == "find_path":
        return " Farklı anahtar kelime dene."
    return ""


def tool_limit_reached_msg(
    fn_name: str,
    limit: int,
    alternatives: str,
) -> str:
    """Per-tool cap reached — hard block."""
    return (
        f"[BLOCKED: {fn_name} limiti doldu (max {limit}). "
        f"Sonuç DEĞİŞMEZ. ZORUNLU: Ya {alternatives} kullan, "
        f"ya da elindeki bilgilerle HEMEN cevap ver. "
        f"Aynı tool'u tekrar çağırırsan görev iptal edilir.]"
    )


def tool_limit_system_inject_msg(
    fn_name: str,
    alternatives: str,
) -> str:
    """System injection after tool limit reached."""
    return (
        f"[SYSTEM] {fn_name} sonuç değiştirmez. "
        f"ZORUNLU: Ya FARKLI bir tool kullan (ör: {alternatives}), "
        f"ya da elindeki bilgilerle HEMEN cevap ver. "
        f"Aynı tool'u tekrar çağırırsan görev iptal edilir."
    )


def phase_checkpoint_msg(
    budget_per_phase: int,
    current_phase: int,
    max_phases: int,
    results_summary: str,
) -> str:
    """New phase available after consecutive blocks."""
    return (
        f"[SYSTEM: Aşama tamamlandı. Yeni araç bütçesi: "
        f"{budget_per_phase} hak "
        f"(Aşama {current_phase}/{max_phases}).\n"
        f"Önceki aşamada bulunan bilgiler:\n{results_summary}\n"
        f"Bu bilgileri kullanarak DEVAM ET. "
        f"Aynı aramaları tekrar YAPMA. "
        f"JSON dosyaları bulunduysa şimdi read_file ile oku. "
        f"Klasör bulunduysa içindeki dosyaları listele.]"
    )


def all_phases_exhausted_msg(total_calls: int) -> str:
    """All phases used — force finalize."""
    return (
        "[SYSTEM: Tüm aşamalar tükendi "
        f"(toplam {total_calls} çağrı). "
        "Elindeki bilgilerle HEMEN cevap ver.]"
    )


def too_many_blocks_msg(total_blocked: int) -> str:
    """Too many blocked calls across all phases."""
    return (
        "[SYSTEM: Bu görevde çok fazla tekrar engellendi "
        f"({total_blocked} engel). "
        "CEVABINI VER veya tamamen farklı bir strateji dene.]"
    )


def task_reminder_msg(task_input: str) -> str:
    """Periodic task reminder to prevent model from losing track."""
    return (
        f"[SYSTEM: Hatırlatma — GÖREVİN: {task_input[:200]}. "
        f"Topladığın bilgilerle cevap ver veya eksik bilgi için "
        f"tool kullan. System prompt'u tekrar etme.]"
    )


def empty_response_msg() -> str:
    """Model returned empty — request final answer."""
    return (
        "[SYSTEM: You returned an empty response. "
        "Please provide your final answer now, "
        "summarizing what you found.]"
    )


def security_blocked_msg(fn_name: str) -> str:
    """Tool blocked for security (SSRF, private IP, etc.)."""
    return (
        f"[SYSTEM] {fn_name} güvenlik nedeniyle engellendi. "
        f"Bu URL'yi tekrar deneme. "
        f"Alternatif: web_search ile farklı kaynak bul."
    )


def unknown_tool_msg(fn_name: str, available_tools: List[str]) -> str:
    """Unknown tool name — show available tools."""
    return (
        f"[ERROR: Unknown tool '{fn_name}'. "
        f"Available tools: {', '.join(sorted(available_tools))}. "
        f"Use the EXACT tool name from this list.]"
    )


# ============================================
# RESPONSE SANITIZATION
# ============================================

def sanitize_response(text: str) -> str:
    """Strip system prompt / tool schema leakage from local LLM responses.

    Local models sometimes echo the system prompt, tool definitions, or
    internal instructions in their output. This function detects and removes
    such leakage so only the actual answer reaches the UI.
    """
    if not text:
        return text

    # Check if the response starts with system prompt content
    first_500 = text[:500]
    has_leak = any(marker in first_500 for marker in LEAK_MARKERS)

    if not has_leak:
        return text

    # Try to find where the actual answer begins after the leaked prompt
    # Strategy 1: Find last occurrence of a leak marker, take text after it
    last_leak_end = 0
    for marker in LEAK_MARKERS:
        idx = text.rfind(marker)
        if idx >= 0:
            end = idx + len(marker)
            # Skip to end of line
            nl = text.find("\n", end)
            if nl >= 0:
                last_leak_end = max(last_leak_end, nl + 1)

    # Strategy 2: Look for a double newline after leaked section
    if last_leak_end > 0:
        cleaned = text[last_leak_end:].strip()
        if cleaned:
            return cleaned

    # Strategy 3: If entire response is system prompt, return a short message
    if len(text.strip()) < 100:
        return text  # Too short to be a full leak, return as-is

    return text
