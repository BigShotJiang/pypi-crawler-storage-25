#!/usr/bin/env python3
"""EWS domain analysis tools — firma hikayesi, kriter analizi, anomali tespiti.

Usage: python3 core/domain_tools.py <command> <args...>

Commands:
  firm_story <db_path> <entity_id>          Firma hikayesi anlat
  top_changers <db_path> [top_n]            En çok skor değişen firmalar
  score_anomalies <db_path>                 Skor anomalileri
  segment_profile <db_path>                 Segment bazlı profil
  criteria_check <db_path> <entity_id>      Firma kriter durumu
"""

import json
import sys
from pathlib import Path
import numpy as np


class _NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (np.integer,)): return int(obj)
        if isinstance(obj, (np.floating,)): return float(obj)
        if isinstance(obj, (np.bool_,)): return bool(obj)
        if isinstance(obj, np.ndarray): return obj.tolist()
        return super().default(obj)

def _dumps(obj, **kw):
    return json.dumps(obj, cls=_NpEncoder, **kw)


def cmd_firm_story(db_path, entity_id):
    import duckdb
    con = duckdb.connect(db_path, read_only=True)

    tl = con.execute(f"""
        SELECT f.donem,
            CAST(CASE WHEN f.ews_skor='YI' THEN 1000
                 WHEN f.ews_skor IS NOT NULL THEN CAST(f.ews_skor AS DOUBLE)
                 ELSE NULL END AS DOUBLE) as score,
            f.ykn_izl_flag, f.kombine_risk, f.risk_degisim,
            f.tfrs_rating, f.ews_kaynak, f.eus_kapsam,
            d.segment, d.bolge_kodu
        FROM fact_periodic f
        JOIN dim_entity d ON f.entity_id = d.entity_id
        WHERE f.entity_id = '{entity_id}'
        ORDER BY f.donem
    """).df()
    con.close()

    if len(tl) == 0:
        print(_dumps({"error": f"Firma bulunamadı: {entity_id}"}))
        return

    scores = [round(float(s)) if s == s else None for s in tl['score']]
    yi_periods = tl[tl['ykn_izl_flag'] == 1]['donem'].tolist()

    # Trend
    valid = [s for s in scores if s is not None]
    trend = "stabil"
    if len(valid) >= 3:
        if valid[-1] > valid[0] + 100: trend = "yükseliyor"
        elif valid[-1] < valid[0] - 100: trend = "düşüyor"

    # Risk trend
    risk_vals = tl['kombine_risk'].dropna()
    risk_trend = "stabil"
    if len(risk_vals) >= 2:
        if float(risk_vals.iloc[-1]) > float(risk_vals.iloc[0]) * 1.5: risk_trend = "artıyor"
        elif float(risk_vals.iloc[-1]) < float(risk_vals.iloc[0]) * 0.5: risk_trend = "azalıyor"

    # Rating changes
    ratings = tl['tfrs_rating'].dropna().unique().tolist()

    story = {
        "entity_id": entity_id,
        "segment": tl['segment'].iloc[0],
        "bolge": int(tl['bolge_kodu'].iloc[0]),
        "periods": len(tl),
        "score_trajectory": scores,
        "score_trend": trend,
        "yi_periods": yi_periods,
        "yi_count": len(yi_periods),
        "current_score": scores[-1] if scores else None,
        "max_score": max(s for s in scores if s is not None) if valid else None,
        "min_score": min(s for s in scores if s is not None) if valid else None,
        "risk_range_tl": [int(risk_vals.min()), int(risk_vals.max())] if len(risk_vals) > 0 else [0, 0],
        "risk_trend": risk_trend,
        "ratings": ratings,
        "current_rating": tl['tfrs_rating'].iloc[-1] if len(tl) > 0 else None,
        "narrative": _build_narrative(entity_id, tl['segment'].iloc[0], scores, yi_periods, trend, ratings),
    }

    print(_dumps(story, indent=2))


def _build_narrative(eid, segment, scores, yi_periods, trend, ratings):
    valid = [s for s in scores if s is not None]
    if not valid:
        return f"Firma {eid}: veri yetersiz."

    parts = [f"Firma {eid} ({segment} segmenti)."]

    if trend == "yükseliyor":
        parts.append(f"Skor trendi yükseliyor ({valid[0]:.0f}→{valid[-1]:.0f}).")
    elif trend == "düşüyor":
        parts.append(f"Skor trendi düşüyor ({valid[0]:.0f}→{valid[-1]:.0f}).")
    else:
        parts.append(f"Skor stabil (ortalama {sum(valid)/len(valid):.0f}).")

    if yi_periods:
        parts.append(f"Yakın izlemeye alınmış: {', '.join(yi_periods)} dönemlerinde.")
    else:
        parts.append("Hiç yakın izlemeye alınmamış.")

    if len(ratings) > 1:
        parts.append(f"Rating değişmiş: {' → '.join(ratings)}.")

    return " ".join(parts)


def cmd_top_changers(db_path, top_n=10):
    import duckdb
    con = duckdb.connect(db_path, read_only=True)
    df = con.execute(f"""
        WITH scored AS (
            SELECT entity_id, donem,
                CAST(CASE WHEN ews_skor='YI' THEN 1000
                     WHEN ews_skor IS NOT NULL THEN CAST(ews_skor AS DOUBLE)
                     ELSE NULL END AS DOUBLE) as score,
                ykn_izl_flag
            FROM fact_periodic WHERE ews_skor IS NOT NULL
        )
        SELECT entity_id,
            MAX(score)-MIN(score) as score_range,
            MAX(score) as max_score, MIN(score) as min_score,
            MAX(ykn_izl_flag) as ever_yi, COUNT(DISTINCT donem) as periods
        FROM scored GROUP BY entity_id HAVING COUNT(DISTINCT donem) >= 6
        ORDER BY score_range DESC LIMIT {int(top_n)}
    """).df()
    con.close()
    print(_dumps({"top_changers": df.to_dict('records')}, indent=2))


def cmd_score_anomalies(db_path):
    import duckdb
    con = duckdb.connect(db_path, read_only=True)
    # YI olan ama önceki dönem düşük skorlu firmalar
    df = con.execute("""
        WITH scored AS (
            SELECT entity_id, donem,
                CAST(CASE WHEN ews_skor='YI' THEN 1000
                     WHEN ews_skor IS NOT NULL THEN CAST(ews_skor AS DOUBLE)
                     ELSE NULL END AS DOUBLE) as score,
                ykn_izl_flag, LAG(CAST(CASE WHEN ews_skor='YI' THEN 1000
                     WHEN ews_skor IS NOT NULL THEN CAST(ews_skor AS DOUBLE)
                     ELSE NULL END AS DOUBLE)) OVER (PARTITION BY entity_id ORDER BY donem) as prev_score
            FROM fact_periodic
        )
        SELECT entity_id, donem, score, prev_score,
            score - prev_score as jump
        FROM scored
        WHERE ykn_izl_flag = 1 AND prev_score IS NOT NULL AND prev_score < 500
        ORDER BY jump DESC LIMIT 20
    """).df()
    con.close()
    print(_dumps({"anomalies": df.to_dict('records'), "count": len(df),
                  "description": "YI olmuş ama önceki dönem skoru düşük olan firmalar (missed_yi pattern)"}, indent=2))


def cmd_segment_profile(db_path):
    import duckdb
    con = duckdb.connect(db_path, read_only=True)
    df = con.execute("""
        SELECT d.segment,
            COUNT(DISTINCT f.entity_id) as firma_sayisi,
            ROUND(AVG(CAST(CASE WHEN f.ews_skor='YI' THEN 1000
                 WHEN f.ews_skor IS NOT NULL THEN CAST(f.ews_skor AS DOUBLE)
                 ELSE NULL END AS DOUBLE)), 1) as avg_skor,
            ROUND(AVG(f.kombine_risk), 0) as avg_risk,
            SUM(f.ykn_izl_flag) as yi_count,
            COUNT(*) as total_records,
            ROUND(SUM(f.ykn_izl_flag) * 100.0 / COUNT(*), 2) as yi_rate
        FROM fact_periodic f JOIN dim_entity d ON f.entity_id = d.entity_id
        GROUP BY d.segment ORDER BY avg_skor DESC
    """).df()
    con.close()
    print(_dumps({"segments": df.to_dict('records')}, indent=2))


def cmd_criteria_check(db_path, entity_id):
    import duckdb
    con = duckdb.connect(db_path, read_only=True)
    # Son dönem verileri
    latest = con.execute(f"""
        SELECT f.donem, f.ews_skor, f.ykn_izl_flag, f.tfrs_rating,
            f.kombine_risk, f.risk_degisim, f.eus_kapsam
        FROM fact_periodic f
        WHERE f.entity_id = '{entity_id}'
        ORDER BY f.donem DESC LIMIT 1
    """).df()
    con.close()

    if len(latest) == 0:
        print(_dumps({"error": "Firma bulunamadı"}))
        return

    r = latest.iloc[0]
    checks = {
        "yi_flag": {"value": int(r['ykn_izl_flag']), "status": "ALERT" if r['ykn_izl_flag'] == 1 else "OK"},
        "ews_skor": {"value": str(r['ews_skor']), "status": "ALERT" if r['ews_skor'] == 'YI' else "HIGH" if r['ews_skor'] and str(r['ews_skor']).isdigit() and int(r['ews_skor']) >= 825 else "OK"},
        "risk_degisim": {"value": int(r['risk_degisim']) if r['risk_degisim'] else 0, "status": "WARNING" if r['risk_degisim'] and r['risk_degisim'] > 0 else "OK"},
    }
    print(_dumps({"entity_id": entity_id, "donem": r['donem'], "criteria": checks}, indent=2))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    cmd = sys.argv[1]
    args = sys.argv[2:]
    cmds = {
        "firm_story": lambda: cmd_firm_story(args[0], args[1]),
        "top_changers": lambda: cmd_top_changers(args[0], args[1] if len(args) > 1 else 10),
        "score_anomalies": lambda: cmd_score_anomalies(args[0]),
        "segment_profile": lambda: cmd_segment_profile(args[0]),
        "criteria_check": lambda: cmd_criteria_check(args[0], args[1]),
    }
    if cmd not in cmds: print(f"Unknown: {cmd}"); sys.exit(1)
    cmds[cmd]()
