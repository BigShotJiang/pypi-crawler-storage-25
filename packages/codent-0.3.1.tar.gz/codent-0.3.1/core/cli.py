# core/cli.py
"""
CLI argument parser and command handlers for Cont agent.

Extracted from cont.py to reduce main module size.
"""

import argparse


def build_parser() -> argparse.ArgumentParser:
    """Build the main argument parser for cont CLI."""
    parser = argparse.ArgumentParser(
        description="cont - Offline Claude Code-like coding agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  cont                  # Interactive REPL mode
  cont "List all Python files and describe what they do"
  cont --model qwen2.5-coder "Fix the bug"
  cont --list-models    # Show available models
  cont --debug "hello"  # Verbose output
  cont --tasks tasks.txt
  cont do orders.txt    # Run commands from cont/orders.txt
  CONT_MODEL=deepseek-coder cont "Fix the bug in main.py"
  CONT_TOOL_BUDGET=8 cont "Summarize the codebase"
  CONT_OFFLINE=1 cont "task"  # Bank-grade offline mode

Backend (config.toml [llm] backend = "lm_studio" | "ollama"):
  lm_studio: WSL2 gateway → Windows host port 1234
  ollama:    127.0.0.1:11434 (WSL local, no network leak)

Switching backend:
  sed -i 's/backend = "lm_studio"/backend = "ollama"/' config.toml
  python3 -c "from core.sticky_config import _set_sticky_model; _set_sticky_model('cont-qc30b')"

Offline mode (CONT_OFFLINE=1):
  Tek seferlik:  CONT_OFFLINE=1 cont "task"
  Kalıcı:        echo 'export CONT_OFFLINE=1' >> ~/.bashrc
  Çıkış:         unset CONT_OFFLINE

  Aktifken:
    - Sadece localhost host'larına bağlantı (127.0.0.1, localhost, ::1, 0.0.0.0)
    - web_search, web_fetch dış URL'leri engellenir
    - github, huggingface, pypi vb. tüm dış kaynaklar kapalı
    - pip install denemez, model download yapmaz
  Bank-grade: tek bir paket bile dışa çıkmaz.

  Pasifken (varsayılan):
    - Lokal LLM (Ollama/LM Studio) kullanılır — zaten dışa çıkmaz
    - Opsiyonel web tools açıktır (web_search, web_fetch, github)

Environment variables:
  OPENAI_BASE_URL   - Override LLM server URL (auto-discovered if not set)
  CONT_OFFLINE      - 1 = bank-grade offline mode (only localhost allowed)
  CONT_LOG_LEVEL    - Set to "debug" for verbose output
  CONT_REPO_ROOT    - Repository root (default: current directory)
  CONT_MODEL        - Model name (auto-detected if not set)
  OPENAI_MODEL      - Alternative model name env var
  CONT_TIMEOUT      - API timeout in seconds (default: 120)
  CONT_MAX_STEPS    - Max iterations (default: 40)
  CONT_TOOL_BUDGET  - Max tool calls before forced finalization (default: 12)
  CONT_MAX_TOKENS   - Max generation tokens (optional)
  CONT_CONTEXT_LIMIT - Context limit hint (optional, not all backends support)
  CONT_WEB_MAX_BYTES - Max bytes for web_fetch (default: 1000000)
  CONT_WEB_TIMEOUT  - Web fetch timeout in seconds (default: 15)
  CONT_WEB_CACHE    - Enable web cache: 1 or 0 (default: 1)
  CONT_REPO_MAX_MB  - Max size for repo_fetch in MB (default: 50)
  CONT_TRACE        - Trace level: off, compact, story, full (default: off)

Model selection:
  Model is selected with priority: --model > --model-like > CONT_MODEL > OPENAI_MODEL > sticky > config.toml > auto
  Sticky model is persisted in ~/.config/cont/config.json and reused across runs.
  Use --forget-model to reset sticky model, --no-save-model to skip persisting.
        """
    )
    parser.add_argument("task", nargs="*", help="Task description (if not using --tasks)")
    parser.add_argument("--model", "-m", metavar="ID",
                        help="Model ID to use (overrides CONT_MODEL env var)")
    parser.add_argument("--model-like", metavar="PATTERN",
                        help="Use model matching pattern (case-insensitive substring)")
    parser.add_argument("--no-strict-model", action="store_true",
                        help="Disable strict model validation (allow unknown model IDs)")
    parser.add_argument("--forget-model", action="store_true",
                        help="Forget sticky model and use auto-detect")
    parser.add_argument("--no-save-model", action="store_true",
                        help="Don't persist model selection as sticky")
    parser.add_argument("--no-unload", action="store_true",
                        help="Don't unload previous model when switching (LM Studio)")
    parser.add_argument("--list-models", action="store_true",
                        help="List available models from LM Studio and exit")
    parser.add_argument("--model-info", action="store_true",
                        help="Show current model configuration and tier assignments")
    parser.add_argument("--map-stats", action="store_true",
                        help="Show filesystem index statistics")
    parser.add_argument("--map-projects", action="store_true",
                        help="List all detected projects")
    parser.add_argument("--max-tokens", type=int, metavar="N",
                        help="Max generation tokens (env: CONT_MAX_TOKENS)")
    parser.add_argument("--context-limit", type=int, metavar="N",
                        help="Context limit hint (env: CONT_CONTEXT_LIMIT)")
    parser.add_argument("--debug", action="store_true",
                        help="Enable debug output (same as CONT_LOG_LEVEL=debug)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Show what would be done without making changes")
    parser.add_argument("--no-write-protect", action="store_true",
                        help="Disable write protection (dangerous)")
    parser.add_argument("--auto-backup", action="store_true", default=True,
                        help="Create backups before modifying files (default: True)")
    parser.add_argument("--tasks", "-t", metavar="FILE", help="File with tasks, one per line")
    parser.add_argument("--no-log", action="store_true", help="Disable logging")
    parser.add_argument("--unattended", action="store_true",
                        help="Auto-approve TIER_2 actions (no user prompts, for overnight training)")
    parser.add_argument("--print-openai-base-url", action="store_true",
                        help="Print the resolved OpenAI base URL and exit")
    parser.add_argument("--doctor", action="store_true",
                        help="Print environment/model diagnostics as JSON and exit")
    parser.add_argument("--auto", action="store_true",
                        help="Enable automatic model selection based on task complexity")
    parser.add_argument("--auto-on", action="store_true",
                        help="Enable auto model selection permanently")
    parser.add_argument("--auto-off", action="store_true",
                        help="Disable auto model selection permanently")
    parser.add_argument("--tier", choices=["fast", "balanced", "powerful"],
                        help="Force specific model tier for this task")
    parser.add_argument("--memory-stats", action="store_true",
                        help="Print memory database statistics as JSON and exit")
    parser.add_argument("--memory-selftest", action="store_true",
                        help="Run a test shell command and print memory stats")
    parser.add_argument("--memory-add", metavar="SPEC",
                        help="Add solution: '<signature>|||<title>|||<step1>;;<step2>'")
    parser.add_argument("--memory-find", metavar="SIG",
                        help="Find best solution for signature")
    parser.add_argument("--memory-apply", metavar="SIG",
                        help="Apply best solution for signature (run steps)")
    parser.add_argument("--memory-apply-unsafe", action="store_true",
                        help="Bypass safety checks for --memory-apply")
    parser.add_argument("--memory-solution-stats", metavar="SIG",
                        help="Show stats for all solutions with signature")
    parser.add_argument("--memory-map-error", metavar="SPEC",
                        help="Map error: '<error_sig>|||<problem_signature>|||<title>'")
    parser.add_argument("--memory-unmap-error", metavar="SIG",
                        help="Remove error signature mapping")
    parser.add_argument("--memory-show-error-map", action="store_true",
                        help="Show all error mappings")
    parser.add_argument("--memory-enable-autofix", metavar="SIG",
                        help="Enable autofix for problem signature")
    parser.add_argument("--memory-disable-autofix", metavar="SIG",
                        help="Disable autofix for problem signature")
    parser.add_argument("--memory-show-autofix", action="store_true",
                        help="Show autofix allowlist")
    parser.add_argument("--memory-suggest-map", action="store_true",
                        help="Suggest mapping from last failed attempt")
    parser.add_argument("--memory-map-last-fail", metavar="SPEC", nargs="?", const="",
                        help="Map last failure: '<problem_sig>|||<title>' or empty for auto")
    parser.add_argument("--memory-recent", metavar="N", nargs="?", type=int, const=20,
                        help="Show N recent attempts (default 20)")
    parser.add_argument("--memory-recent-fail", metavar="N", nargs="?", type=int, const=20,
                        help="Show N recent failed attempts (default 20)")
    parser.add_argument("--memory-recent-env", metavar="N", nargs="?", type=int, const=20,
                        help="Show N recent attempts for current env (default 20)")
    parser.add_argument("--memory-prune", metavar="DAYS", type=int, nargs="?", const=90,
                        help="Prune attempts older than DAYS (default 90), respects CONT_MEMORY_KEEP_MIN env var")
    parser.add_argument("--memory-export", metavar="PATH",
                        help="Export memory to JSON file (solutions, error_map, autofix_allow)")
    parser.add_argument("--memory-export-all", metavar="PATH",
                        help="Export memory to JSON file including attempts")
    parser.add_argument("--memory-import", metavar="PATH",
                        help="Import memory from JSON file (merge mode)")
    parser.add_argument("--set-home", type=str, metavar="PATH",
                        help="Set Cont's home directory")
    parser.add_argument("--show-soul", action="store_true",
                        help="Display SOUL.md content")
    parser.add_argument("--show-state", action="store_true",
                        help="Display current context state")
    parser.add_argument("--show-home", action="store_true",
                        help="Display Cont's home directory")
    parser.add_argument("--edit-soul", action="store_true",
                        help="Open SOUL.md in editor")
    parser.add_argument("--relay", action="store_true",
                        help="Start relay server for Browser Claude <-> Claude Code bridge")
    parser.add_argument("--relay-port", type=int, default=8765,
                        help="Relay server port (default: 8765)")
    parser.add_argument("--bridge", action="store_true",
                        help="Start Chrome extension bridge for Claude.ai")
    parser.add_argument("--bridge-port", type=int, default=8766,
                        help="Bridge WebSocket port (default: 8766)")
    parser.add_argument("--voice", action="store_true",
                        help="Start voice mode (listen for 'Cont' wake word)")
    parser.add_argument("--listen-once", action="store_true",
                        help="Listen for a single voice command")
    parser.add_argument("--whisper-model", type=str, default="base",
                        choices=["tiny", "base", "small", "medium", "large-v3"],
                        help="Whisper model size (default: base)")
    parser.add_argument("--voice-test", action="store_true",
                        help="Run voice pipeline diagnostic test")
    parser.add_argument("--setup-openai", metavar="KEY",
                        help="Save OpenAI API key to ~/.config/cont/openai_key")
    parser.add_argument("--watcher", choices=["start", "stop", "status"],
                        help="Control the context watcher daemon")
    # Self-improvement commands
    parser.add_argument("--self-report", action="store_true",
                        help="Show success rates by task type and top failures")
    parser.add_argument("--self-improve", action="store_true",
                        help="Analyze recent failures, suggest prompt patches")
    parser.add_argument("--self-apply", action="store_true",
                        help="Apply suggested prompt improvements")
    parser.add_argument("--self-reset", action="store_true",
                        help="Reset all learned improvements (fresh start)")
    # Self-improvement loop commands
    parser.add_argument("--self-improve-off", action="store_true",
                        help="Disable idle self-improvement loop")
    parser.add_argument("--self-improve-status", action="store_true",
                        help="Show self-improvement loop history and stats")
    parser.add_argument("--self-improve-log", action="store_true",
                        help="Show what the self-improvement loop fixed")
    # Learning system commands
    parser.add_argument("--show-recipes", action="store_true",
                        help="List all recipes and their stats")
    parser.add_argument("--show-patches", action="store_true",
                        help="List all file-based prompt patches")
    parser.add_argument("--show-vocabulary", action="store_true",
                        help="Show learned vocabulary stats and words")
    # Automation system commands
    parser.add_argument("--automations", action="store_true",
                        help="List all automations and their status")
    parser.add_argument("--run-automation", metavar="NAME",
                        help="Run a specific automation by name")
    parser.add_argument("--briefing", action="store_true",
                        help="Run morning briefing automation")
    # Triage
    parser.add_argument("--triage", nargs="?", const=50, type=int, metavar="N",
                        help="Scan last N runs (default 50), report top 5 failure patterns")
    # Claude Code CLI escalation commands
    parser.add_argument("--claude", action="store_true",
                        help="Force Claude Code escalation for next task")
    parser.add_argument("--claude-stats", action="store_true",
                        help="Show Claude Code CLI usage statistics")
    parser.add_argument("--claude-mode", choices=["general", "plan", "analyze", "edit"],
                        default="general", help="Claude Code mode (default: general)")
    parser.add_argument("--no-escalation", action="store_true",
                        help="Disable auto-escalation for this session")
    # Web UI
    parser.add_argument("--ui", action="store_true",
                        help="Start web UI at http://localhost:8550")
    # Security system commands
    parser.add_argument("--audit", action="store_true",
                        help="Show recent security audit log entries and exit")
    parser.add_argument("--backups", action="store_true",
                        help="List recent file backups and exit")
    parser.add_argument("--undo", metavar="BACKUP",
                        help="Restore a file from backup (use --backups to see list)")
    parser.add_argument("--ui-port", type=int, default=8550,
                        help="Web UI port (default: 8550)")

    # RPC — CC entegrasyonu
    parser.add_argument("--rpc", nargs="*", metavar="CMD",
                        help="RPC komut çalıştır (check-notebook-sync, check-type-consistency, verify-wheel-install, verify-before-publish, ews-pipeline-test)")

    # Daemon
    parser.add_argument("--daemon-start", action="store_true",
                        help="Start Cont daemon (background)")
    parser.add_argument("--daemon-stop", action="store_true",
                        help="Stop Cont daemon")
    parser.add_argument("--daemon-status", action="store_true",
                        help="Show daemon status (AWAKE/IDLE/SLEEP)")

    # Local LLM — fallback GGUF presets (LM Studio kapalıysa)
    parser.add_argument("--local-list", action="store_true",
                        help="List available local GGUF model presets")

    # Genesis — owner recognition
    parser.add_argument("--set-keyphrase", action="store_true",
                        help="Set owner keyphrase interactively (getpass, no echo)")
    parser.add_argument("--genesis", action="store_true",
                        help="Show genesis/owner recognition status")

    # Trace mode
    parser.add_argument("--trace", choices=["off", "compact", "story", "full"],
                        default=None,
                        help="Trace level: off (default), compact, story, full (env: CONT_TRACE)")
    parser.add_argument("--trace-file", metavar="PATH",
                        help="Write trace JSONL to file (in addition to stderr)")
    parser.add_argument("--trace-max-lines", type=int, default=4, metavar="N",
                        help="Max lines per section in FULL mode (default: 4)")
    parser.add_argument("--trace-max-chars", type=int, default=800, metavar="N",
                        help="Max chars per section in FULL mode (default: 800)")

    return parser
