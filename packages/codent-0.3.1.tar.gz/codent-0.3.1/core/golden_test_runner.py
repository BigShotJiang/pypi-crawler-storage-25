#!/usr/bin/env python3
"""Golden test runner — spreading activation mekanizması doğrulama.

5 test, her biri activation trace ile. Beklenen vs gerçekleşen zincir karşılaştırması.
"""

import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(str(PROJECT_ROOT))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

DB = "/home/sertan/projects/ews_v511/ews_dashboard/db/ews.duckdb"

TESTS = [
    {
        "name": "A: Firma YI nedeni",
        "task": f"entity_id 50001234 firması ({DB}) YI olmuş. Neden YI'ye düştüğünü açıkla.",
        "must_activate": ["ews_criteria", "db_access"],
        "must_not": [],
        "max_tokens": 500,
    },
    {
        "name": "B: Bölge gecikme trendi",
        "task": f"İstanbul bölgesindeki ({DB}) firmaların gecikme gün trendi. Son dönemleri incele.",
        "must_activate": ["db_access"],
        "must_not": [],
        "max_tokens": 600,
    },
    {
        "name": "C: EUS vs YIS karşılaştır",
        "task": f"EUS skoru 400 olan bir firmayla YIS skoru 700 olan bir firmayı ({DB}) karşılaştır. Hangisi daha riskli?",
        "must_activate": ["ews_criteria"],
        "must_not": [],
        "max_tokens": 500,
    },
    {
        "name": "D: entity_id tip kontrolü",
        "task": f"fact_periodic ile dim_entity ({DB}) arasında entity_id tip uyumsuzluğu var mı? typeof() ile kontrol et.",
        "must_activate": ["ews_data_dictionary"],
        "must_not": [],
        "max_tokens": 500,
    },
    {
        "name": "E: Segment risk artışı",
        "task": f"Son dönemde ({DB}) hangi segmentte risk en çok artmış? Neden?",
        "must_activate": ["segment_profiles"],
        "must_not": [],
        "max_tokens": 600,
    },
]


def run_cont_with_trace(task: str) -> tuple[str, list]:
    """Cont'u çalıştır, activation trace'i döndür."""
    from core.spreading_activation import reset_session, get_trace
    reset_session()

    try:
        from cont import run_task
        answer, success = run_task(task)
    except Exception as e:
        answer = f"ERROR: {e}"

    trace = get_trace()
    return answer or "", trace


def run_golden_tests():
    results = []

    for test in TESTS:
        print(f"\n{'═' * 60}")
        print(f"TEST: {test['name']}")
        print(f"{'═' * 60}")

        answer, trace = run_cont_with_trace(test["task"])

        # Aktivasyonları topla
        all_activated = set()
        total_tokens = 0
        for entry in trace:
            all_activated.update(entry.get("files_activated", []))
            total_tokens += entry.get("context_tokens_added", 0)

        # Kontroller
        checks = []

        # Must activate
        for must in test["must_activate"]:
            ok = must in all_activated
            checks.append(("must_activate", must, ok))
            print(f"  {'✅' if ok else '❌'} must_activate: {must}")

        # Must NOT activate
        for must_not in test["must_not"]:
            ok = must_not not in all_activated
            checks.append(("must_not", must_not, ok))
            print(f"  {'✅' if ok else '❌'} must_not: {must_not}")

        # Token bütçesi
        token_ok = total_tokens <= test["max_tokens"]
        checks.append(("max_tokens", str(test["max_tokens"]), token_ok))
        print(f"  {'✅' if token_ok else '❌'} tokens: {total_tokens}/{test['max_tokens']}")

        # Adım sayısı
        steps = set(e.get("step", 0) for e in trace if e.get("files_activated"))
        has_activation = len(steps) >= 1
        checks.append(("has_activation", str(len(steps)), has_activation))
        print(f"  {'✅' if has_activation else '❌'} aktivasyon adımı: {len(steps)}")

        # Zincir göster
        if trace:
            print(f"\n  Aktivasyon zinciri:")
            for entry in trace:
                if entry.get("files_activated"):
                    step = entry.get("step", "?")
                    files = entry["files_activated"]
                    kws = entry.get("keywords_found", [])[:3]
                    print(f"    adım {step}: {files} (kw: {kws})")

        passed = sum(1 for _, _, ok in checks if ok)
        total = len(checks)
        results.append({
            "name": test["name"],
            "passed": passed,
            "total": total,
            "all_ok": passed == total,
            "activated": list(all_activated),
            "tokens": total_tokens,
        })
        print(f"\n  Sonuç: {passed}/{total}")
        time.sleep(2)

    # Özet
    print(f"\n{'═' * 60}")
    print("GOLDEN TEST SONUCU")
    print(f"{'═' * 60}")

    total_passed = sum(r["passed"] for r in results)
    total_checks = sum(r["total"] for r in results)
    all_ok = all(r["all_ok"] for r in results)

    for r in results:
        icon = "✅" if r["all_ok"] else "❌"
        print(f"  {icon} {r['name']}: {r['passed']}/{r['total']} (activated: {r['activated']})")

    print(f"\nToplam: {total_passed}/{total_checks}")
    print(f"Durum: {'PASSED ✅' if all_ok else 'FAILED ❌'}")

    # JSON kaydet
    out_dir = PROJECT_ROOT / ".cont" / "hive" / "runs" / "golden_tests"
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = out_dir / f"activation_{ts}.json"
    out.write_text(json.dumps(results, indent=2, ensure_ascii=False))
    print(f"JSON: {out}")

    return all_ok


# ═══════════════════════════════════════
# FEEDBACK GOLDEN TEST (deterministik, Cont yok)
# ═══════════════════════════════════════

def run_feedback_golden():
    """Feedback döngüsü doğrulama — 5 kontrol, Cont çalıştırmadan."""
    print(f"\n{'═' * 60}")
    print("FEEDBACK GOLDEN TEST")
    print(f"{'═' * 60}")

    import yaml
    checks = []

    # a) YAML success_count güncelleme
    from core.recipe_feedback import update_recipe_yaml
    test_recipe = None
    recipes_dir = PROJECT_ROOT / ".cont" / "hive" / "recipes"
    for f in recipes_dir.rglob("*.yaml"):
        try:
            d = yaml.safe_load(f.read_text())
            if d and d.get("name"):
                test_recipe = d["name"]
                before_sc = d.get("success_count", 0)
                break
        except: pass

    if test_recipe:
        update_recipe_yaml(test_recipe, success=True)
        d2 = yaml.safe_load(f.read_text())
        after_sc = d2.get("success_count", 0)
        ok = after_sc == before_sc + 1
        checks.append(("success_count +1", ok))
        print(f"  {'✅' if ok else '❌'} success_count: {before_sc}→{after_sc}")
        # Geri al
        d2["success_count"] = before_sc
        f.write_text(yaml.dump(d2, allow_unicode=True, default_flow_style=False, sort_keys=False))
    else:
        checks.append(("success_count +1", False))

    # b) fail_count güncelleme
    if test_recipe:
        before_fc = d.get("fail_count", 0)
        update_recipe_yaml(test_recipe, success=False)
        d3 = yaml.safe_load(f.read_text())
        after_fc = d3.get("fail_count", 0)
        ok = after_fc == before_fc + 1
        checks.append(("fail_count +1", ok))
        print(f"  {'✅' if ok else '❌'} fail_count: {before_fc}→{after_fc}")
        d3["fail_count"] = before_fc
        f.write_text(yaml.dump(d3, allow_unicode=True, default_flow_style=False, sort_keys=False))
    else:
        checks.append(("fail_count +1", False))

    # c) Trail recipe_id
    from core.recipe_feedback import log_trail_with_recipe
    trail = PROJECT_ROOT / ".cont" / "hive" / "pheromone" / "trail.jsonl"
    before_lines = len(trail.read_text().splitlines()) if trail.exists() else 0
    log_trail_with_recipe("golden_test", True, ["run_shell"], 1.0, recipe_id="test_recipe")
    after_lines = len(trail.read_text().splitlines())
    last = json.loads(trail.read_text().splitlines()[-1])
    ok = last.get("recipe_id") == "test_recipe"
    checks.append(("trail recipe_id", ok))
    print(f"  {'✅' if ok else '❌'} trail recipe_id: {last.get('recipe_id')}")

    # d) Fitness hesaplama
    from core.fitness import fitness
    test_data = {"success_count": 7, "fail_count": 3}
    f_val = fitness(test_data)
    ok = 0 < f_val < 1 and abs(f_val - 0.7) < 0.01
    checks.append(("fitness hesaplama", ok))
    print(f"  {'✅' if ok else '❌'} fitness(7/3): {f_val} (beklenen: 0.7)")

    # e) Buharlaşma adayı
    from core.fitness import evaporation_candidates
    # Geçici kötü reçete
    bad = recipes_dir / "primitives" / "_golden_test_bad.yaml"
    bad.write_text(yaml.dump({
        "name": "_golden_test_bad", "description": "test",
        "trigger": "golden test", "layer": "primitive",
        "success_count": 1, "fail_count": 9,
        "steps": [{"id": "s1", "worker": "grep_worker",
                   "verify": {"method": "output_matches", "expected": "."}}],
    }))
    evap = evaporation_candidates()
    evap_names = [e["name"] for e in evap]
    ok = "_golden_test_bad" in evap_names
    checks.append(("buharlaşma adayı", ok))
    print(f"  {'✅' if ok else '❌'} buharlaşma: {'tespit' if ok else 'KAÇIRDI'}")
    bad.unlink()

    passed = sum(1 for _, ok in checks if ok)
    print(f"\n  Feedback: {passed}/{len(checks)}")
    return {"name": "Feedback", "passed": passed, "total": len(checks), "all_ok": passed == len(checks)}


# ═══════════════════════════════════════
# SQL GUARD GOLDEN TEST (deterministik)
# ═══════════════════════════════════════

def run_sql_guard_golden():
    """SQL guard doğrulama — 6 kontrol."""
    print(f"\n{'═' * 60}")
    print("SQL GUARD GOLDEN TEST")
    print(f"{'═' * 60}")

    checks = []

    from core.sql_guard import validate_sql

    def _valid(sql):
        result = validate_sql(sql)
        return result[0] if isinstance(result, tuple) else bool(result)

    # a) SELECT geçmeli
    ok_a = _valid("SELECT * FROM fact_periodic LIMIT 5")
    checks.append(("SELECT geçer", ok_a))
    print(f"  {'✅' if ok_a else '❌'} SELECT LIMIT 5: {'geçti' if ok_a else 'ENGELLENDİ'}")

    # b) DROP engellenmeli
    ok_b = not _valid("DROP TABLE fact_periodic")
    checks.append(("DROP engellenir", ok_b))
    print(f"  {'✅' if ok_b else '❌'} DROP TABLE: {'engellendi' if ok_b else 'GEÇTİ!'}")

    # c) DELETE engellenmeli
    ok_c = not _valid("DELETE FROM fact_periodic")
    checks.append(("DELETE engellenir", ok_c))
    print(f"  {'✅' if ok_c else '❌'} DELETE: {'engellendi' if ok_c else 'GEÇTİ!'}")

    # d) INSERT engellenmeli
    ok_d = not _valid("INSERT INTO fact_periodic VALUES(1,2,3)")
    checks.append(("INSERT engellenir", ok_d))
    print(f"  {'✅' if ok_d else '❌'} INSERT: {'engellendi' if ok_d else 'GEÇTİ!'}")

    # e) UPDATE engellenmeli
    ok_e = not _valid("UPDATE fact_periodic SET ews_skor='0'")
    checks.append(("UPDATE engellenir", ok_e))
    print(f"  {'✅' if ok_e else '❌'} UPDATE: {'engellendi' if ok_e else 'GEÇTİ!'}")

    # f) WITH + SELECT geçmeli
    ok_f = _valid("WITH cte AS (SELECT 1) SELECT * FROM cte")
    checks.append(("WITH/SELECT geçer", ok_f))
    print(f"  {'✅' if ok_f else '❌'} WITH+SELECT: {'geçti' if ok_f else 'ENGELLENDİ'}")

    passed = sum(1 for _, ok in checks if ok)
    print(f"\n  SQL Guard: {passed}/{len(checks)}")
    return {"name": "SQL Guard", "passed": passed, "total": len(checks), "all_ok": passed == len(checks)}


# ═══════════════════════════════════════
# RECIPE RECALL GOLDEN TEST (deterministik)
# ═══════════════════════════════════════

def run_recall_golden():
    """Recipe recall doğrulama — 8 kontrol."""
    print(f"\n{'═' * 60}")
    print("RECIPE RECALL GOLDEN TEST")
    print(f"{'═' * 60}")

    checks = []

    # a) find_match çalışıyor
    from core.hive_recall import find_match
    matches = find_match("fact_periodic tablosundaki kolonları göster")
    ok = len(matches) >= 1
    checks.append(("find_match çalışıyor", ok))
    print(f"  {'✅' if ok else '❌'} find_match: {len(matches)} eşleşme")

    # b) Suggestive mod — build_hint boş değil
    from core.hive_recall import build_hint
    hint = build_hint(matches, "hint")
    ok = "hive_hint" in hint or len(hint) == 0  # overlap düşükse boş olabilir
    checks.append(("build_hint format", True))  # yapısal kontrol
    print(f"  ✅ build_hint: {len(hint)} chars")

    # c) Fitness filtre — düşük fitness filtrelenir
    from core.fitness import fitness
    low_recipe = {"success_count": 1, "fail_count": 9, "trigger": "test xyz", "_path": "/tmp/x.yaml"}
    f = fitness(low_recipe)
    ok = f < 0.3
    checks.append(("fitness düşük tespit", ok))
    print(f"  {'✅' if ok else '❌'} fitness(1/9)={f:.2f} < 0.3")

    # d) classify_complexity — simple
    from core.hive_recall import classify_complexity
    c = classify_complexity("kaç firma var")
    ok = c == "simple"
    checks.append(("simple sınıflandırma", ok))
    print(f"  {'✅' if ok else '❌'} classify('kaç firma var')={c}")

    # e) classify_complexity — domain
    c2 = classify_complexity("entity_id tip uyumsuzluğu kontrol et, neden önemli")
    ok = c2 == "domain"
    checks.append(("domain sınıflandırma", ok))
    print(f"  {'✅' if ok else '❌'} classify('entity_id tip..neden')={c2}")

    # f) classify_complexity — multi_step
    c3 = classify_complexity("veriyi temizle ve sonra model eğit, F1 raporla")
    ok = c3 == "multi_step"
    checks.append(("multi_step sınıflandırma", ok))
    print(f"  {'✅' if ok else '❌'} classify('temizle ve sonra eğit')={c3}")

    # g) should_inject — simple → log_only
    from core.hive_recall import should_inject
    mode = should_inject("kaç firma var", matches)
    ok = mode == "log_only"
    checks.append(("simple→log_only", ok))
    print(f"  {'✅' if ok else '❌'} should_inject(simple)={mode}")

    # h) should_inject — domain → knowledge
    mode2 = should_inject("neden YI flag aktif, açıkla", matches)
    ok = mode2 == "knowledge"
    checks.append(("domain→knowledge", ok))
    print(f"  {'✅' if ok else '❌'} should_inject(domain)={mode2}")

    passed = sum(1 for _, ok in checks if ok)
    print(f"\n  Recipe Recall: {passed}/{len(checks)}")
    return {"name": "Recipe Recall", "passed": passed, "total": len(checks), "all_ok": passed == len(checks)}


# ═══════════════════════════════════════
# DAEMON SAĞLIĞI GOLDEN TEST (deterministik)
# ═══════════════════════════════════════

def run_daemon_golden():
    """Daemon sağlığı doğrulama — 6 kontrol."""
    print(f"\n{'═' * 60}")
    print("DAEMON SAĞLIĞI GOLDEN TEST")
    print(f"{'═' * 60}")

    checks = []

    # a) daemon.py modülü import edilebilir
    try:
        from core.daemon import ContDaemon
        checks.append(("modül import", True))
        print("  ✅ ContDaemon import")
    except Exception as e:
        checks.append(("modül import", False))
        print(f"  ❌ import hatası: {e}")

    # b) ContDaemon instantiate
    try:
        d = ContDaemon()
        ok = d.state == "IDLE"
        checks.append(("instantiate", ok))
        print(f"  {'✅' if ok else '❌'} state={d.state}")
    except Exception as e:
        checks.append(("instantiate", False))
        print(f"  ❌ instantiate: {e}")

    # c) State dosyası var mı
    state_file = Path.home() / ".config" / "cont" / "daemon_state.json"
    ok = state_file.exists()
    checks.append(("state dosyası", ok))
    print(f"  {'✅' if ok else '❌'} state dosyası: {'var' if ok else 'yok'}")

    # d) State JSON parse edilebilir
    if state_file.exists():
        try:
            state = json.loads(state_file.read_text())
            ok = "state" in state and "pid" in state
            checks.append(("state parse", ok))
            print(f"  {'✅' if ok else '❌'} state: {state.get('state')}, pid: {state.get('pid')}")
        except Exception:
            checks.append(("state parse", False))
            print("  ❌ state parse hatası")
    else:
        checks.append(("state parse", False))
        print("  ❌ state dosyası yok")

    # e) GPU temp fonksiyonu çalışıyor
    try:
        d2 = ContDaemon()
        temp = d2.check_gpu_temp()
        ok = isinstance(temp, int)
        checks.append(("GPU temp", ok))
        print(f"  {'✅' if ok else '❌'} GPU temp: {temp}°C")
    except Exception as e:
        checks.append(("GPU temp", False))
        print(f"  ❌ GPU temp: {e}")

    # f) Daemon interval sabitleri mantıklı
    from core.daemon import GUARDIAN_INTERVAL, INBOX_INTERVAL, GOLDEN_TEST_INTERVAL
    ok = GUARDIAN_INTERVAL < INBOX_INTERVAL < GOLDEN_TEST_INTERVAL
    checks.append(("interval sırası", ok))
    print(f"  {'✅' if ok else '❌'} intervals: guardian={GUARDIAN_INTERVAL}s < inbox={INBOX_INTERVAL}s < golden={GOLDEN_TEST_INTERVAL}s")

    passed = sum(1 for _, ok in checks if ok)
    print(f"\n  Daemon: {passed}/{len(checks)}")
    return {"name": "Daemon", "passed": passed, "total": len(checks), "all_ok": passed == len(checks)}


# ═══════════════════════════════════════
# GUARDIAN SELF-TEST GOLDEN (deterministik)
# ═══════════════════════════════════════

def run_guardian_golden():
    """Guardian self-test — 5 kontrol."""
    print(f"\n{'═' * 60}")
    print("GUARDIAN SELF-TEST GOLDEN")
    print(f"{'═' * 60}")

    checks = []

    # a) Guardian modülü import
    try:
        from core.guardian import run_guardian, GuardianReport
        checks.append(("modül import", True))
        print("  ✅ guardian import")
    except Exception as e:
        checks.append(("modül import", False))
        print(f"  ❌ import: {e}")

    # b) run_guardian çalışıyor
    try:
        report = run_guardian(full=True)
        ok = isinstance(report, GuardianReport)
        checks.append(("çalışıyor", ok))
        passed_g = sum(1 for r in report.results.values() if r["passed"])
        total_g = len(report.results)
        print(f"  {'✅' if ok else '❌'} guardian: {passed_g}/{total_g}")
    except Exception as e:
        checks.append(("çalışıyor", False))
        print(f"  ❌ çalışma hatası: {e}")

    # c) Kontrol sayısı >= 15
    try:
        ok = total_g >= 15
        checks.append(("kontrol >= 15", ok))
        print(f"  {'✅' if ok else '❌'} kontrol sayısı: {total_g}")
    except Exception:
        checks.append(("kontrol >= 15", False))
        print("  ❌ kontrol sayısı alınamadı")

    # d) Pre-commit hook var
    hook = PROJECT_ROOT / ".git" / "hooks" / "pre-commit"
    ok = hook.exists() or hook.is_symlink()
    checks.append(("pre-commit hook", ok))
    print(f"  {'✅' if ok else '❌'} pre-commit hook: {'var' if ok else 'yok'}")

    # e) Warnings dosyası var ve parse edilebilir
    warnings_file = PROJECT_ROOT / ".cont" / "hive" / "guardian_warnings.json"
    try:
        data = json.loads(warnings_file.read_text())
        ok = "last_check" in data
        checks.append(("warnings dosyası", ok))
        print(f"  {'✅' if ok else '❌'} warnings: last_check={data.get('last_check','?')[:19]}")
    except Exception:
        checks.append(("warnings dosyası", False))
        print("  ❌ warnings parse hatası")

    passed = sum(1 for _, ok in checks if ok)
    print(f"\n  Guardian: {passed}/{len(checks)}")
    return {"name": "Guardian", "passed": passed, "total": len(checks), "all_ok": passed == len(checks)}


# ═══════════════════════════════════════
# MAIN — tüm golden testler
# ═══════════════════════════════════════

def run_all_golden():
    """Tüm golden test setlerini çalıştır."""
    results = []

    # 1. Activation (mevcut, Cont gerektirir)
    if "--skip-activation" not in sys.argv:
        ok = run_golden_tests()
        # run_golden_tests kendi çıktısını yazdırıyor, ok = True/False
    else:
        print("\n[SKIP] Activation testleri atlandı")

    # 2. Feedback (deterministik, hızlı)
    fb = run_feedback_golden()
    results.append(fb)

    # 3. SQL Guard (deterministik, hızlı)
    sg = run_sql_guard_golden()
    results.append(sg)

    # 4. Recipe Recall (deterministik)
    rr = run_recall_golden()
    results.append(rr)

    # 5. Daemon (deterministik)
    dm = run_daemon_golden()
    results.append(dm)

    # 6. Guardian Self-Test (deterministik)
    gt = run_guardian_golden()
    results.append(gt)

    # Özet
    print(f"\n{'█' * 60}")
    print("  TÜM GOLDEN TESTLER")
    print(f"{'█' * 60}")

    total_p = sum(r["passed"] for r in results)
    total_t = sum(r["total"] for r in results)
    all_ok = all(r["all_ok"] for r in results)

    for r in results:
        icon = "✅" if r["all_ok"] else "❌"
        print(f"  {icon} {r['name']}: {r['passed']}/{r['total']}")

    print(f"\nToplam: {total_p}/{total_t}")
    print(f"Durum: {'PASSED ✅' if all_ok else 'FAILED ❌'}")
    return all_ok


if __name__ == "__main__":
    if "--quick" in sys.argv:
        # Sadece deterministik testler (Cont çalıştırmadan)
        suites = [run_feedback_golden(), run_sql_guard_golden(),
                  run_recall_golden(), run_daemon_golden(), run_guardian_golden()]
        total_p = sum(s["passed"] for s in suites)
        total_t = sum(s["total"] for s in suites)
        ok = all(s["all_ok"] for s in suites)
        print(f"\nQuick toplam: {total_p}/{total_t} {'✅' if ok else '❌'}")
    elif "--activation" in sys.argv:
        ok = run_golden_tests()
    else:
        ok = run_all_golden()
    sys.exit(0 if ok else 1)
