# core/task_utils.py
"""Task utilities — decomposition, feedback, learning, assessment.

Extracted from runtime.py.
"""

import re
import time
from pathlib import Path
from typing import Optional, Callable

def should_decompose(user_input: str, is_retry: bool = False) -> bool:
    """Skip decomposer for tasks that don't need it.

    NO decompose: short input (<12 words), retries, corrections, questions.
    YES decompose: long multi-step, URL+multi-action, multiple distinct verbs.
    """
    words = user_input.lower().split()
    word_count = len(words)
    text_lower = user_input.lower()

    # Retry/continuation — never decompose
    if is_retry:
        return False

    # Correction phrases — never decompose
    if any(p in text_lower for p in (
        'değil', 'degil', 'demek istedim', 'yanlış', 'yanlis',
    )):
        return False

    # Pure questions — never decompose
    stripped = text_lower.rstrip('? ')
    if stripped.endswith(('nedir', 'nerede', 'nasıl', 'nasil', 'kim', 'kaç', 'kac')):
        return False
    if word_count <= 4 and '?' in user_input:
        return False

    # Short input — almost never needs decomposing
    if word_count < 12:
        has_url = any('http' in w or '.gov' in w or '.com' in w for w in words)
        multi_action = sum(1 for kw in (
            'bul', 'indir', 'ara', 'özetle', 'ozetle', 'kaydet',
            'aç', 'ac', 'oku', 'yaz', 'göster', 'goster',
            'find', 'download', 'search', 'summarize', 'save', 'open',
        ) if kw in text_lower) >= 2
        if not (has_url and multi_action):
            return False

    return True  # Long or complex — decompose


# ═══════════════════════════════════════════════════════════════
# 2. Result Extraction Utilities
# ═══════════════════════════════════════════════════════════════


def extract_dir_from_results(all_results: list) -> str:
    """Extract a directory path from previous phase results.

    Searches both the FINAL answer text and any embedded tool result paths.
    Prioritizes the longest valid directory path found (most specific).
    """
    candidates = []
    for res, _ok in all_results:
        if not res:
            continue
        # Match /home/... paths that look like directories
        paths = re.findall(r'(/home/\S+)', res)
        for p in paths:
            p = p.rstrip('.,;:)"\'}]')
            if os.path.isdir(p):
                candidates.append(p)
        # Also try to parse JSON tool results (system_search output)
        json_paths = re.findall(r'"path"\s*:\s*"(/[^"]+)"', res)
        for p in json_paths:
            if os.path.isdir(p):
                candidates.append(p)
    if not candidates:
        return ""
    # Return longest path (most specific directory)
    return max(candidates, key=len)



def load_files_for_summary(file_paths: list, max_per_file: int = 500,
                           max_total: int = 5000) -> tuple[str, int]:
    """Load truncated file previews for summarization.
    Always lists ALL file names, even if only some are read.
    Returns (preview_text, files_read_count)."""
    previews = []
    total = 0
    read_count = 0
    for path in file_paths:
        if total >= max_total:
            break
        try:
            with open(path, 'r', errors='ignore') as f:
                content = f.read(max_per_file)
            basename = Path(path).name
            previews.append(f"--- {basename} ---\n{content}")
            total += len(content)
            read_count += 1
        except Exception:
            pass

    # Always list ALL file names at the top
    file_listing = "Dosyalar:\n" + "\n".join(
        f"  📄 {Path(p).name}" for p in file_paths
    )

    if previews:
        return file_listing + "\n\n" + "\n\n".join(previews), read_count
    return file_listing, 0


# ═══════════════════════════════════════════════════════════════
# 3. Hallucination Detection
# ═══════════════════════════════════════════════════════════════


def self_assess(task: str, answer: str, tool_calls_count: int,
                duration_ms: int, task_id: int) -> tuple[int, list[str]]:
    """Rule-based self-assessment after each task. No LLM call.
    Returns (score, notes). Score: 1-5.
    """
    if not task_id:
        return 3, []

    score = 3
    notes = []

    # Empty/short answer
    if not answer or len(answer.strip()) < 20:
        score = 1
        notes.append("Yanıt çok kısa veya boş")

    # Uncertainty phrases
    uncertainty = [
        'emin değilim', 'bilmiyorum', 'yapamıyorum', 'erişemiyorum',
        'not sure', "can't", "unable to", 'I cannot',
    ]
    if any(p in (answer or '').lower() for p in uncertainty):
        score = min(score, 2)
        notes.append("Belirsizlik ifadesi içeriyor")

    # Tool efficiency
    if tool_calls_count > 8:
        score = min(score, 2)
        notes.append(f"Çok fazla tool call: {tool_calls_count}")
    elif tool_calls_count == 0 and len((answer or '').strip()) < 100:
        score = min(score, 2)
        notes.append("Tool kullanmadan kısa yanıt")

    # Speed bonus
    if duration_ms < 5000 and score >= 3:
        score = min(score + 1, 5)
        notes.append("Hızlı yanıt (<5s)")

    # Long, detailed answer bonus
    if answer and len(answer.strip()) > 500 and score >= 3:
        score = min(score + 1, 5)
        notes.append("Detaylı yanıt")

    return score, notes


# ═══════════════════════════════════════════════════════════════
# 6. Feedback Handling
# ═══════════════════════════════════════════════════════════════


def save_feedback(task_id: int, source: str, rating: int, note: str = None):
    """Save feedback to task_feedback table."""
    if not task_id:
        return
    if not _memory_init_db_fn or not _db_connect_fn:
        return
    try:
        _memory_init_db_fn()
        db = _db_connect_fn()
        db.execute("""
            INSERT INTO task_feedback (task_outcome_id, source, rating, note)
            VALUES (?, ?, ?, ?)
        """, (task_id, source, rating, note))
        db.commit()
        db.close()
    except Exception as e:
        _debug_fn(f"Feedback save failed: {e}")



def process_feedback_for_learning(task_id: int):
    """Convert feedback into memory entries for learning."""
    if not _memory_init_db_fn or not _db_connect_fn or not _memory_remember_fn:
        return
    try:
        _memory_init_db_fn()
        db = _db_connect_fn()
        feedbacks = db.execute("""
            SELECT source, rating, note FROM task_feedback
            WHERE task_outcome_id = ? ORDER BY created_at
        """, (task_id,)).fetchall()

        user_fb = [f for f in feedbacks if f[0] == 'user']
        if not user_fb:
            db.close()
            return

        worst_rating = min(f[1] for f in user_fb if f[1] is not None)
        user_notes = [f[2] for f in user_fb if f[2]]

        task_row = db.execute(
            "SELECT task_text FROM task_outcome WHERE id = ?", (task_id,)
        ).fetchone()
        db.close()

        if not task_row:
            return

        task_text = task_row[0]

        if worst_rating <= 1:
            note_text = "; ".join(user_notes) if user_notes else "Kullanıcı memnun değildi"
            _memory_remember_fn(
                f"YAPMA: '{task_text[:100]}' görevinde hata: {note_text}",
                memory_type="feedback",
                source="user",
                importance=0.8,
            )
        elif worst_rating >= 3 and user_notes:
            _memory_remember_fn(
                f"İYİ: '{task_text[:100]}' görevinde başarılı. Not: {'; '.join(user_notes)}",
                memory_type="feedback",
                source="user",
                importance=0.6,
            )
    except Exception as e:
        _debug_fn(f"Feedback learning failed: {e}")



def learn_from_chain(session_tasks: list, feedback_rating: int,
                     feedback_note: str = None):
    """Learn from the entire task chain, not just the last task."""
    if not session_tasks:
        return

    # Single task — use simple learning
    if len(session_tasks) < 2:
        process_feedback_for_learning(session_tasks[-1]["task_id"])
        return

    chain = session_tasks[-5:]  # Last 5 tasks max
    failed_tasks = [t for t in chain[:-1] if not t["success"]]
    final_task = chain[-1]

    if feedback_rating >= 3 and failed_tasks and _memory_remember_fn:
        # User said "good" after failures = learning opportunity
        fail_texts = [t["task_text"] for t in failed_tasks]
        success_text = final_task["task_text"]

        lesson = (
            f"ÖĞREN - Görev zinciri ({len(failed_tasks)} başarısız → 1 başarılı):\n"
            f"  Başarısız denemeler: {'; '.join(t[:80] for t in fail_texts)}\n"
            f"  Başarılı olan: {success_text[:120]}\n"
            f"  Kullanılan araçlar: {', '.join(final_task.get('tools_used', []))}\n"
        )

        if feedback_note:
            lesson += f"  Kullanıcı notu: {feedback_note}\n"

        # Extract actionable rules from what changed
        path_kws = ['projects', 'home', 'klasör', 'altında', 'dizin',
                     'path', 'folder', 'directory', '~/', '/home']
        if any(kw in success_text.lower() for kw in path_kws):
            lesson += (
                "  KURAL: Dosya/klasör bulunamadığında otomatik olarak "
                "~/projects/ ve ~/ altında da ara. find_path tool'unu kullan."
            )

        if len(success_text) > len(fail_texts[0]) * 1.5:
            lesson += (
                "  KURAL: İlk aramada bulunamazsa, kullanıcıdan "
                "yardım beklemeden daha geniş kapsamda ara."
            )

        try:
            _memory_remember_fn(lesson, memory_type="chain_feedback", importance=0.9)
            _debug_fn(f"Chain lesson saved ({len(failed_tasks)} failures → success)")
        except Exception as e:
            _debug_fn(f"Chain lesson save failed: {e}")

    elif feedback_rating <= 1 and _memory_remember_fn:
        # User said "bad" — whole chain was bad
        all_texts = [t["task_text"] for t in chain]
        lesson = (
            f"YAPMA - Başarısız görev zinciri:\n"
            f"  Görevler: {'; '.join(t[:80] for t in all_texts)}\n"
            f"  Sorun: Kullanıcı memnun olmadı.\n"
        )
        if feedback_note:
            lesson += f"  Kullanıcı notu: {feedback_note}\n"

        try:
            _memory_remember_fn(lesson, memory_type="chain_feedback", importance=0.9)
        except Exception as e:
            _debug_fn(f"Chain lesson save failed: {e}")

    # Also save individual feedback for the last task
    process_feedback_for_learning(final_task["task_id"])


# ═══════════════════════════════════════════════════════════════
# 7. Conversation Context Builder
# ═══════════════════════════════════════════════════════════════


def handle_feedback_command(
    user_input: str,
    last_task_id: int,
    session_tasks: list = None,
    *,
    recipe_success_fn: Optional[Callable] = None,
    recipe_failure_fn: Optional[Callable] = None,
    episodic_feedback_fn: Optional[Callable] = None,
    last_recipe_id: Optional[str] = None,
    last_episode_id: Optional[int] = None,
    console_print_fn: Optional[Callable] = None,
    memory_remember_fn: Optional[Callable] = None,
    last_tools_used: Optional[list] = None,
    last_raw_input: Optional[str] = None,
) -> bool:
    """Handle feedback commands. Returns True if input was consumed.

    Args:
        recipe_success_fn: Called with recipe_id on positive feedback
        recipe_failure_fn: Called with recipe_id on negative feedback
        episodic_feedback_fn: Called with (episode_id, feedback_str)
        last_recipe_id: Current recipe ID (if any)
        last_episode_id: Current episode ID (if any)
        console_print_fn: Rich console.print function
    """
    cmd = user_input.strip()
    _print = console_print_fn or (lambda msg: None)

    # Unicode normalization — fix surrogate escapes and NFC normalize
    # Prevents "/iyi" → "/\udcc5iyi" mangling
    import unicodedata
    try:
        cmd = cmd.encode('utf-8', errors='surrogateescape').decode('utf-8', errors='replace')
    except (UnicodeDecodeError, UnicodeEncodeError):
        pass
    cmd = unicodedata.normalize('NFC', cmd)

    # Fix common Turkish encoding corruption (U+FFFD replacement)
    if '\ufffd' in cmd:
        _turkish_recovery = {
            'k\ufffdtü': 'kötü',
            'k\ufffd\ufffdtü': 'kötü',
            'i\ufffdyi': 'iyi',
            '\ufffdyi': 'iyi',
        }
        cmd_lower = cmd.lower()
        for broken, fixed in _turkish_recovery.items():
            if broken in cmd_lower:
                idx = cmd_lower.index(broken)
                cmd = cmd[:idx] + fixed + cmd[idx + len(broken):]
                break

    # Check if it's a feedback command first (even without last_task_id)
    cmd_clean = cmd.lstrip('/')

    # Detect /not anywhere in input (user may prefix with "çok", "kötü", etc.)
    _has_embedded_not = '/not ' in cmd or '/not"' in cmd
    _has_embedded_feedback = (
        _has_embedded_not
        or '/iyi' in cmd
        or '/kötü' in cmd
        or '/eh' in cmd
    )

    is_feedback_cmd = (
        cmd in ('/iyi', '+', '/kötü', '-', '/eh', '~')
        or cmd.startswith('/not ')
        or cmd_clean.startswith('not ')
        or cmd_clean.startswith('iyi')
        or cmd_clean.startswith('kötü')
        or cmd_clean == 'eh'
        or _has_embedded_feedback
    )
    if not is_feedback_cmd:
        return False

    if not last_task_id:
        _print("[dim]Henüz değerlendirilecek görev yok.[/dim]")
        return True

    if cmd in ('/iyi', '+') or cmd_clean == 'iyi' or ('/iyi' in cmd and not _has_embedded_not):
        save_feedback(last_task_id, 'user', 3)
        learn_from_chain(session_tasks, 3)
        if recipe_success_fn and last_recipe_id:
            try:
                recipe_success_fn(last_recipe_id)
            except Exception:
                pass
        if episodic_feedback_fn and last_episode_id:
            try:
                episodic_feedback_fn(last_episode_id, "iyi")
            except Exception:
                pass
        # v6: Save success strategy to memory
        if memory_remember_fn and last_tools_used and last_raw_input:
            try:
                _tools_chain = " → ".join(last_tools_used[:5])
                _strategy = (
                    f"BAŞARILI: '{last_raw_input[:60]}' görevi — "
                    f"Araçlar: {_tools_chain}"
                )
                # Extract domain from session_tasks if available
                if session_tasks:
                    _last_task = session_tasks[-1] if session_tasks else {}
                    _task_tools = _last_task.get("tools_used", [])
                    for _t in _task_tools:
                        if "browser" in _t or "web" in _t:
                            _domain = _extract_domain_from_args(
                                {"query": _last_task.get("task_text", "")}
                            )
                            if _domain:
                                _strategy += f" | Site: {_domain}"
                            break
                memory_remember_fn(
                    _strategy,
                    memory_type="fact",
                    source="success_strategy",
                    importance=0.5,
                )
            except Exception:
                pass  # Memory save failure is non-fatal
        _print("[green]✓ Teşekkürler![/green]")
        return True

    elif cmd in ('/kötü', '-') or cmd_clean == 'kötü' or ('/kötü' in cmd and not _has_embedded_not):
        save_feedback(last_task_id, 'user', 1)
        learn_from_chain(session_tasks, 1)
        if recipe_failure_fn and last_recipe_id:
            try:
                recipe_failure_fn(last_recipe_id)
            except Exception:
                pass
        if episodic_feedback_fn and last_episode_id:
            try:
                episodic_feedback_fn(last_episode_id, "kötü")
            except Exception:
                pass
        _print("[yellow]Kaydedildi. Gelişeceğim.[/yellow]")
        return True

    elif cmd in ('/eh', '~') or cmd_clean == 'eh' or ('/eh' in cmd and not _has_embedded_not and not '/iyi' in cmd and not '/kötü' in cmd):
        save_feedback(last_task_id, 'user', 2)
        _print("[dim]Kaydedildi.[/dim]")
        return True

    elif cmd.startswith('/not ') or cmd_clean.startswith('not ') or _has_embedded_not:
        # Find /not position for prefix extraction
        not_idx = cmd.find('/not')
        if not_idx >= 0:
            note = cmd[not_idx + 4:].strip().strip('"').strip("'")
            prefix = cmd[:not_idx].strip().lower()
        else:
            note_start = cmd_clean.find('not ') + 4
            note = cmd_clean[note_start:].strip().strip('"').strip("'")
            prefix = ""

        # Check negative words in both note AND prefix
        negative_words = [
            'kötü', 'yanlış', 'hata', 'saçma', 'berbat', 'anlamamış',
            'wrong', 'bad', 'useless'
        ]
        negative = (
            any(w in note.lower() for w in negative_words)
            or any(w in prefix for w in negative_words)
        )
        rating = 1 if negative else 2
        save_feedback(last_task_id, 'user', rating, note)
        learn_from_chain(session_tasks, rating, note)
        _print("[dim]Not kaydedildi.[/dim]")
        return True

    return False


# ═══════════════════════════════════════════════════════════════
# 9. Helper functions (moved from cont.py — use _ctx bridge)
# ═══════════════════════════════════════════════════════════════




# Self-improvement functions (extracted from runtime.py)
def _self_improve_reflect(task: str, output: str) -> str:
    """Quick reflection on failure - max 100 tokens, temp 0.1."""
    prompt = f"""Task: {task[:200]}
Result: FAILED
Output: {output[:300]}

Why did this fail? One sentence, be specific."""

    try:
        response = _ctx.client.chat.completions.create(
            model=_ctx.model,
            messages=[{"role": "user", "content": clean_surrogates(prompt)}],
            max_tokens=100,
            temperature=0.1,
        )
        return (response.choices[0].message.content or "")[:300]
    except Exception:
        return ""



def _self_improve_record(task: str, success: bool, output: str, failure_reason: str,
                         tool_calls_count: int, start_time: float) -> Optional[int]:
    """Record task outcome and trigger reflection on failure."""
    if not _ctx.self_improve_enabled:
        return None
    try:
        improver = _ctx.self_improver_cls(_ctx.db_connect_fn, _ctx.memory_init_db_fn)
        duration_ms = int((time.time() - start_time) * 1000)

        reflection = ""
        if not success:
            analysis = improver.analyze_failure(task, output)
            failure_reason = analysis.get("pattern", failure_reason)
            _ctx.debug_fn(f"Self-improve: failure pattern = {failure_reason}")

            task_type = _ctx.classify_task_fn(task)
            created = improver.auto_create_patch(failure_reason, task_type)
            if created:
                _ctx.console.print(f"[dim]Self-improve: new prompt patch created for '{failure_reason}'[/dim]")

            if improver.should_reflect(failure_reason):
                try:
                    reflection = _self_improve_reflect(task, output)
                    if reflection:
                        _ctx.memory_remember_fn(
                            f"[{task_type}] {reflection}",
                            memory_type="reflection",
                            source="self_improve",
                            importance=0.6,
                        )
                        _ctx.debug_fn(f"Self-improve reflection: {reflection[:100]}")
                except Exception as e:
                    _ctx.debug_fn(f"Self-improve reflection failed: {e}")

            if _ctx.escalation_enabled:
                try:
                    esc = _ctx.get_escalation_fn()
                    if esc.is_available:
                        fc = improver.get_failure_count(task_type, hours=24)
                        if fc >= 3:
                            _ctx.console.print(f"[yellow]Task type '{task_type}' has failed {fc} times in 24h. Consider: --claude or /claude <task>[/yellow]")
                except Exception as e_esc:
                    _ctx.debug_fn(f"Auto-escalation check failed: {e_esc}")

        task_outcome_id = improver.record_outcome(
            task=task, success=success, output=output[:300],
            failure_reason=failure_reason, reflection=reflection if not success else "",
            tool_calls_count=tool_calls_count, duration_ms=duration_ms,
            model=_ctx.model, prompt_tokens=0,
        )

        if _ctx.learning_enabled:
            try:
                recipe = _ctx.match_recipe_fn(task)
                if recipe:
                    _ctx.record_recipe_outcome_fn(recipe["name"], success, _ctx.db_connect_fn, _ctx.memory_init_db_fn)
                    _ctx.debug_fn(f"Recipe '{recipe['name']}' outcome: {'success' if success else 'fail'}")

                matched_patches = _ctx.match_patches_fn(task)
                for p in matched_patches:
                    _ctx.record_patch_outcome_fn(p.get("id", "?"), success, _ctx.db_connect_fn, _ctx.memory_init_db_fn)
            except Exception as e2:
                _ctx.debug_fn(f"Learning outcome tracking failed: {e2}")

        if _ctx.automation_enabled and _ctx.event_bus:
            try:
                event_type = "task.completed" if success else "task.failed"
                _ctx.event_bus.emit_async(event_type, {
                    "task": task[:200],
                    "success": success,
                    "duration_ms": duration_ms,
                    "tool_calls": tool_calls_count,
                    "task_type": _ctx.classify_task_fn(task) if _ctx.self_improve_enabled else "unknown",
                })
            except Exception as e3:
                _ctx.debug_fn(f"Event emission failed: {e3}")
        return task_outcome_id
    except Exception as e:
        _ctx.debug_fn(f"Self-improve record failed: {e}")
    return None



