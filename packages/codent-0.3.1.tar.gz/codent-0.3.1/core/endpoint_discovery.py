# core/endpoint_discovery.py
"""Auto-discover OpenAI-compatible server URL (LM Studio, etc.)."""

import os
import subprocess
from pathlib import Path
from typing import Optional

import requests

from core.utils import debug as _debug


def _get_wsl2_gateway_ip() -> Optional[str]:
    """Get the WSL2 Windows host IP (default gateway)."""
    try:
        result = subprocess.run(
            ["ip", "route"],
            capture_output=True,
            text=True,
            timeout=2
        )
        for line in result.stdout.splitlines():
            if line.startswith("default"):
                parts = line.split()
                if len(parts) >= 3:
                    return parts[2]
    except Exception:
        pass
    return None


def _get_nameserver_ip() -> Optional[str]:
    """Get the first nameserver from /etc/resolv.conf."""
    try:
        resolv = Path("/etc/resolv.conf")
        if resolv.exists():
            for line in resolv.read_text().splitlines():
                if line.strip().startswith("nameserver"):
                    parts = line.split()
                    if len(parts) >= 2:
                        return parts[1]
    except Exception:
        pass
    return None


def _check_openai_endpoint(base_url: str, timeout: float = 1.5) -> bool:
    """Check if an OpenAI-compatible endpoint is reachable via GET /models."""
    try:
        url = base_url.rstrip("/") + "/models"
        resp = requests.get(url, timeout=timeout)
        return resp.status_code == 200
    except Exception:
        return False


class EndpointNotFoundError(Exception):
    """Raised when no working OpenAI-compatible server is found."""
    def __init__(self, tried_urls: list):
        self.tried_urls = tried_urls
        super().__init__(f"No working endpoint found. Tried: {tried_urls}")


def _get_backend() -> str:
    """config.toml'dan backend oku (lm_studio | ollama)."""
    try:
        from pathlib import Path
        import tomllib
        config = Path(__file__).parent.parent / "config.toml"
        if config.exists():
            with open(config, "rb") as f:
                return tomllib.load(f).get("llm", {}).get("backend", "lm_studio")
    except Exception:
        pass
    return "lm_studio"


def discover_openai_base_url() -> tuple[str, list[str]]:
    """Auto-discover a working OpenAI-compatible server URL.

    Backend = "ollama"   → http://localhost:11434/v1 (WSL local)
    Backend = "lm_studio" → WSL2 gateway:1234 (Windows host)
    """
    candidates = []
    backend = _get_backend()

    # a) Current env OPENAI_BASE_URL (sadece backend uyumluysa)
    env_url = os.environ.get("OPENAI_BASE_URL")
    if env_url:
        if backend == "ollama" and "11434" in env_url:
            candidates.append(("env OPENAI_BASE_URL", env_url))
        elif backend != "ollama" and "11434" not in env_url:
            candidates.append(("env OPENAI_BASE_URL", env_url))

    if backend == "ollama":
        # Ollama: WSL içinde lokal
        candidates.append(("ollama localhost", "http://127.0.0.1:11434/v1"))
        candidates.append(("ollama loopback", "http://localhost:11434/v1"))
    else:
        # LM Studio: Windows host (WSL gateway)
        gw_ip = _get_wsl2_gateway_ip()
        if gw_ip:
            candidates.append(("WSL2 gateway", f"http://{gw_ip}:1234/v1"))
        ns_ip = _get_nameserver_ip()
        if ns_ip and ns_ip != gw_ip:
            candidates.append(("nameserver", f"http://{ns_ip}:1234/v1"))
        candidates.append(("localhost", "http://127.0.0.1:1234/v1"))

    tried = []
    for source, url in candidates:
        tried.append(url)
        _debug(f"Trying {source}: {url}")
        if _check_openai_endpoint(url):
            _debug(f"Success: using {url}")
            return url, tried
        _debug(f"Failed: {url}")

    raise EndpointNotFoundError(tried)
