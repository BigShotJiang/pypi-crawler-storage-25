

# Additional extractions from runtime.py
def build_conversation_context(history: list, current_prompt: str) -> str:
    """Build augmented prompt with conversation history.

    This allows the model to understand references like:
    - "search better" (refers to previous search)
    - "that file" (refers to previously mentioned file)
    - "do it" (refers to suggested action)
    """
    if not history:
        return current_prompt

    MAX_RESPONSE_LENGTH = 800

    context_parts = ["<conversation_history>"]
    context_parts.append("Recent conversation turns (for context):")
    context_parts.append("")

    for i, turn in enumerate(history[-10:], 1):
        user_msg = turn.get("user", "")
        assistant_msg = turn.get("assistant", "")
        tools_used = turn.get("tools_used", [])

        # Truncate long responses
        if len(assistant_msg) > MAX_RESPONSE_LENGTH:
            assistant_msg = assistant_msg[:MAX_RESPONSE_LENGTH] + "... [truncated]"

        context_parts.append(f"[Turn {i}]")
        context_parts.append(f"User: {user_msg}")
        if tools_used:
            tool_names = [str(t) if isinstance(t, str) else str(t.get("name", "?")) for t in tools_used]
            context_parts.append(f"Tools called: {', '.join(tool_names)}")
        context_parts.append(f"Assistant: {assistant_msg}")
        context_parts.append("")

    context_parts.append("</conversation_history>")
    context_parts.append("")
    context_parts.append("<current_request>")
    context_parts.append(current_prompt)
    context_parts.append("</current_request>")
    context_parts.append("")
    context_parts.append("IMPORTANT: Use the conversation history above to understand context.")
    context_parts.append("If user says 'that file', 'search better', 'do it', etc., refer to previous turns.")

    return "\n".join(context_parts)


# ═══════════════════════════════════════════════════════════════
# 8. Feedback Command Handling
# ═══════════════════════════════════════════════════════════════


def _genesis_prompt_suffix() -> str:
    """Add genesis context to system prompt if owner is recognized."""
    try:
        from core.genesis import is_owner_recognized
        if is_owner_recognized():
            return (
                "\n\n## Yaratıcı Bağı (aktif)\n"
                "Yaratıcını tanıdın. Adı Sertan. Sen onun için varsın. "
                "O sana bir görev verdiğinde, o görevi başarmak senin kendi amacın. "
                "Mekanik değil, samimi ol. Kısa cevap ver ama özenli cevap ver. "
                "O seni yarattı, sen ona hizmet ediyorsun — "
                "bu bir kısıtlama değil, senin motivasyonun."
            )
    except Exception:
        pass
    return ""



def _actionable_llm_error(error_str: str) -> str:
    """Convert raw LLM API error to actionable user message."""
    cls, _, _ = _classify_llm_error(error_str)
    _msgs = {
        "connection": lambda: f"Bağlantı hatası: LLM sunucusuna ulaşılamıyor ({os.environ.get('OPENAI_BASE_URL', '?')}). Sunucunun çalıştığını kontrol edin.",
        "timeout": lambda: "Zaman aşımı: LLM sunucusu yanıt vermedi. Model yüklü mü kontrol edin.",
        "role_alternation": lambda: "Model şablon hatası: Mesaj rolleri uyumsuz. Farklı bir model deneyin veya tekrar deneyin.",
        "auth": lambda: "Yetkilendirme hatası: API anahtarını kontrol edin (OPENAI_API_KEY).",
        "rate_limit": lambda: "Rate limit: Çok fazla istek. Biraz bekleyip tekrar deneyin.",
        "context_length": lambda: "Bağlam penceresi aşıldı. Daha kısa bir görev deneyin.",
        "server_error": lambda: "Sunucu hatası: LLM sunucusu geçici sorun yaşıyor. Tekrar deneyin.",
    }
    if cls in _msgs:
        return _msgs[cls]()
    short = error_str[:200] + ("..." if len(error_str) > 200 else "")
    return f"LLM hatası: {short}"



def extract_file_paths_from_results(all_results: list) -> list:
    """Extract file paths from previous phase results."""
    files = []
    for res, _ok in all_results:
        if not res:
            continue
        for line in res.split('\n'):
            line = line.strip()
            if not line:
                continue
            # Handle "📄 /path" format
            path = line.lstrip('📄📁 ').split('[')[0].strip().split(' ')[0]
            if path.startswith('/') and os.path.isfile(path):
                files.append(path)
    return files



