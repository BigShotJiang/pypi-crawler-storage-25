#!/usr/bin/env python3
"""SQL güvenlik kontrolü — deterministik, LLM yok.

Her üretilen SQL buradan geçmek ZORUNDA.
Read-only + keyword blacklist + tablo whitelist.
"""

import re

FORBIDDEN = {
    'INSERT', 'UPDATE', 'DELETE', 'DROP', 'ALTER', 'CREATE',
    'TRUNCATE', 'REPLACE', 'MERGE', 'GRANT', 'REVOKE',
    'EXEC', 'EXECUTE', 'INTO', 'COPY', 'ATTACH',
}


def validate_sql(sql: str, allowed_tables: set = None) -> tuple[bool, str]:
    """Validate SQL is safe to execute.

    Returns (is_safe, reason).
    """
    sql_clean = sql.strip()
    sql_upper = sql_clean.upper()

    if not sql_clean:
        return False, "Boş SQL"

    # 1. SELECT ile başlamalı (WITH CTE de kabul)
    if not (sql_upper.startswith('SELECT') or sql_upper.startswith('WITH')):
        return False, "SQL SELECT veya WITH ile başlamalı"

    # 2. Yasaklı keyword
    # Tokenize: kelime sınırlarında ara (kolon adlarıyla karışmasın)
    words = set(re.findall(r'\b([A-Z_]+)\b', sql_upper))
    found = words & FORBIDDEN
    if found:
        return False, f"Yasaklı keyword: {', '.join(sorted(found))}"

    # 3. Tablo whitelist (opsiyonel)
    if allowed_tables:
        # FROM/JOIN sonrası tablo adlarını çıkar
        table_refs = re.findall(r'\bFROM\s+(\w+)|\bJOIN\s+(\w+)', sql_upper)
        used_tables = {t for pair in table_refs for t in pair if t}
        unknown = used_tables - {t.upper() for t in allowed_tables}
        if unknown:
            return False, f"Bilinmeyen tablo: {', '.join(unknown)}"

    # 4. Noktalı virgül — birden fazla statement engelle
    if ';' in sql_clean[:-1]:  # sondaki ; kabul
        return False, "Birden fazla statement (;) yasak"

    return True, "OK"


def execute_readonly(sql: str, db_path: str, timeout: int = 30) -> dict:
    """Execute SQL on read-only DuckDB connection.

    Returns {success, data, columns, row_count, error}.
    """
    import duckdb

    # Double guard: validate first
    safe, reason = validate_sql(sql)
    if not safe:
        return {"success": False, "error": f"SQL reddedildi: {reason}"}

    try:
        con = duckdb.connect(db_path, read_only=True)
        result = con.execute(sql).df()
        con.close()

        return {
            "success": True,
            "columns": list(result.columns),
            "row_count": len(result),
            "data": result.head(100).to_dict('records'),  # Max 100 satır
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


if __name__ == "__main__":
    import sys, json
    if len(sys.argv) < 2:
        print("Usage: python3 core/sql_guard.py <sql> [db_path]")
        sys.exit(1)

    sql = sys.argv[1]
    safe, reason = validate_sql(sql)
    if safe:
        if len(sys.argv) > 2:
            result = execute_readonly(sql, sys.argv[2])
            # İnsan + model okunabilir çıktı
            if result["success"]:
                data = result["data"]
                cols = result["columns"]
                print(f"Sonuç ({result['row_count']} satır):")
                if result["row_count"] <= 20:
                    for row in data:
                        vals = [f"{k}={v}" for k, v in row.items()]
                        print(f"  {', '.join(vals)}")
                else:
                    for row in data[:10]:
                        vals = [f"{k}={v}" for k, v in row.items()]
                        print(f"  {', '.join(vals)}")
                    print(f"  ... ({result['row_count'] - 10} satır daha)")
            else:
                print(f"HATA: {result['error']}")
        else:
            print(f"OK: {sql[:80]}")
    else:
        print(f"REJECTED: {reason}")
        sys.exit(1)
