# core/cc_auditor.py
"""CC Auditor — Cont CC'nin işini denetler.

5 mekanizma (hepsi deterministik, bool döner):
1. commit_audit — son commit gerçeği yansıtıyor mu
2. claim_verifier — CC'nin sözlü iddialarını doğrula
3. integration_chain — fonksiyon yazıldı ama çağrılıyor mu
4. diff_anomaly — şüpheli değişiklikler
5. before_after — iddia edilen iyileşme gerçek mi
"""

import json
import re
import subprocess
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
HIVE_DIR = PROJECT_ROOT / ".cont" / "hive"
AUDIT_LOG = HIVE_DIR / "runs" / "cc_audits.jsonl"


def _git(args: list, cwd: Path = PROJECT_ROOT) -> str:
    try:
        r = subprocess.run(["git"] + args, cwd=cwd, capture_output=True, text=True, timeout=10)
        return r.stdout
    except Exception:
        return ""


# ═══════════════════════════════════════
# 1. COMMIT AUDIT
# ═══════════════════════════════════════

def commit_audit(commit_ref: str = "HEAD") -> dict:
    """Son commit'i denetle. Returns: {checks: [{name, passed, detail}], score}."""
    msg = _git(["log", "-1", "--pretty=%B", commit_ref]).strip()
    diff = _git(["diff", f"{commit_ref}~1", commit_ref])
    files = _git(["diff", f"{commit_ref}~1", commit_ref, "--name-only"]).strip().splitlines()

    checks = []

    # a) "eklendi" → dosya gerçekten var mı?
    if "eklen" in msg.lower() or "added" in msg.lower() or "create" in msg.lower():
        added_files = [l[2:] for l in _git(["diff", f"{commit_ref}~1", commit_ref, "--name-status"]).splitlines() if l.startswith("A\t")]
        all_exist = all((PROJECT_ROOT / f).exists() for f in added_files) if added_files else True
        checks.append({"name": "added_files_exist", "passed": all_exist,
                       "detail": f"{len(added_files)} dosya eklendi"})

    # b) "test geçti" → testi çalıştır
    if "test geçti" in msg.lower() or "test passed" in msg.lower() or "/" in msg:
        # Sayısal iddia var mı (örn 26/26, 46/46)
        claims = re.findall(r'(\d+)/(\d+)', msg)
        if claims:
            checks.append({"name": "numerical_claims_present", "passed": True,
                           "detail": f"İddialar: {claims[:3]}"})

    # c) Yeni fonksiyon kontrolü integration_chain'de yapılıyor — burada tekrarlama

    # d) Değişen dosyalar mevcut mu
    missing = [f for f in files if f and not (PROJECT_ROOT / f).exists() and "delete" not in msg.lower()]
    if missing:
        checks.append({"name": "files_exist", "passed": False, "detail": f"Eksik: {missing[:3]}"})

    score = sum(1 for c in checks if c["passed"])
    return {"checks": checks, "score": score, "total": len(checks),
            "commit": commit_ref, "msg": msg[:100]}


# ═══════════════════════════════════════
# 2. CLAIM VERIFIER
# ═══════════════════════════════════════

def claim_verifier(text: str) -> dict:
    """CC'nin sözlü iddialarını gerçek sonuçlarla karşılaştır."""
    checks = []

    # Guardian iddiası
    g_claim = re.search(r'[Gg]uardian[:\s]+(\d+)/(\d+)', text)
    if g_claim:
        claimed = (int(g_claim.group(1)), int(g_claim.group(2)))
        try:
            from core.guardian import run_guardian
            report = run_guardian(full=True)
            actual_pass = sum(1 for r in report.results.values() if r["passed"])
            actual_total = len(report.results)
            ok = claimed == (actual_pass, actual_total)
            checks.append({"name": "guardian_claim", "passed": ok,
                           "detail": f"İddia: {claimed[0]}/{claimed[1]}, Gerçek: {actual_pass}/{actual_total}"})
        except Exception as e:
            checks.append({"name": "guardian_claim", "passed": False, "detail": f"Doğrulanamadı: {e}"})

    # Golden test iddiası
    gt_claim = re.search(r'[Gg]olden[:\s]+(\d+)/(\d+)', text)
    if gt_claim:
        claimed = (int(gt_claim.group(1)), int(gt_claim.group(2)))
        # Sadece var olduğunu kontrol et (tam çalıştırma pahalı)
        checks.append({"name": "golden_claim_present", "passed": True,
                       "detail": f"İddia: {claimed[0]}/{claimed[1]} (manuel doğrulanmalı)"})

    score = sum(1 for c in checks if c["passed"])
    return {"checks": checks, "score": score, "total": len(checks)}


# ═══════════════════════════════════════
# 3. INTEGRATION CHAIN
# ═══════════════════════════════════════

def integration_chain(commit_ref: str = "HEAD") -> dict:
    """Yeni fonksiyon → çağrılıyor mu?"""
    diff = _git(["diff", f"{commit_ref}~1", commit_ref])
    new_funcs = re.findall(r'^\+def (\w+)\(', diff, re.MULTILINE)
    new_funcs = [f for f in new_funcs if not f.startswith("__")]

    checks = []
    orphans = []
    for fn in new_funcs[:10]:
        # grep hem def hem çağrı
        result = _git(["grep", "-rn", "--include=*.py", f"{fn}(", "core", "cont.py"])
        lines = [l for l in result.strip().splitlines() if l]
        def_lines = [l for l in lines if f"def {fn}(" in l]
        call_lines = [l for l in lines if f"{fn}(" in l and f"def {fn}(" not in l]
        if def_lines and not call_lines:
            orphans.append(fn)

    checks.append({
        "name": "no_orphan_functions",
        "passed": len(orphans) == 0,
        "detail": f"{len(new_funcs)} yeni fonksiyon, {len(orphans)} orphan: {orphans[:3]}"
    })

    return {"checks": checks, "score": sum(1 for c in checks if c["passed"]),
            "total": len(checks), "orphans": orphans}


# ═══════════════════════════════════════
# 4. DIFF ANOMALY
# ═══════════════════════════════════════

EXEMPT_FILES = {"core/cc_auditor.py", "core/guardian.py", ".claude/hooks/pre_write_check.py",
                "task_folder/", "tests/test_golden.py", ".cont/hive/runs/",
                ".cont/hive/inbox/", ".cont/hive/pheromone/"}


def _is_exempt(path: str) -> bool:
    return any(e in path for e in EXEMPT_FILES)


def diff_anomaly(commit_ref: str = "HEAD") -> dict:
    """Şüpheli değişiklikler. Exempt dosyalar atlanır."""
    diff = _git(["diff", f"{commit_ref}~1", commit_ref])

    # Exempt dosyaları diff'ten çıkar
    filtered_lines = []
    current_file = None
    skip_file = False
    for line in diff.splitlines():
        if line.startswith("diff --git"):
            m = re.match(r'diff --git a/(\S+) b/(\S+)', line)
            current_file = m.group(2) if m else None
            skip_file = current_file and _is_exempt(current_file)
        if not skip_file and line.startswith("+") and not line.startswith("+++"):
            filtered_lines.append(line[1:])
    added_lines = filtered_lines

    checks = []

    # except: pass
    bare_excepts = sum(1 for l in added_lines if re.search(r'except.*:\s*pass\s*$', l))
    checks.append({"name": "no_bare_except", "passed": bare_excepts == 0,
                   "detail": f"{bare_excepts} bare except:pass"})

    # TODO/FIXME/HACK
    todos = sum(1 for l in added_lines if re.search(r'\b(TODO|FIXME|HACK|XXX)\b', l))
    checks.append({"name": "no_todos", "passed": todos == 0,
                   "detail": f"{todos} TODO/FIXME/HACK"})

    # Hardcoded keyword listesi (5+ string)
    hardcoded = 0
    for line in added_lines:
        if re.search(r'(?:list|set|dict)\s*=\s*[\[\{]', line, re.IGNORECASE):
            hardcoded += 1
    checks.append({"name": "no_hardcoded_lists", "passed": hardcoded < 3,
                   "detail": f"{hardcoded} hardcoded list/dict (limit: 3)"})

    # Büyük dosya değişikliği (300+ satır eklendi)
    files_changed = _git(["diff", f"{commit_ref}~1", commit_ref, "--stat"]).splitlines()
    large_files = []
    for line in files_changed:
        m = re.search(r'(\S+\.py)\s+\|\s+(\d+)', line)
        if m and int(m.group(2)) > 300:
            large_files.append(f"{m.group(1)}({m.group(2)})")
    checks.append({"name": "no_huge_changes", "passed": len(large_files) == 0,
                   "detail": f"300+ satır değişen: {large_files}"})

    return {"checks": checks, "score": sum(1 for c in checks if c["passed"]),
            "total": len(checks)}


# ═══════════════════════════════════════
# 5. BEFORE/AFTER
# ═══════════════════════════════════════

def before_after(commit_ref: str = "HEAD") -> dict:
    """İddia edilen iyileşme gerçek mi?"""
    msg = _git(["log", "-1", "--pretty=%B", commit_ref])
    checks = []

    # "satır düştü/azaldı" iddiası
    if any(w in msg.lower() for w in ["satır", "düştü", "azaldı", "→", "lines"]):
        # Mesajda X→Y kalıbı var mı
        m = re.search(r'(\d+)\s*[→>-]+\s*(\d+)', msg)
        if m:
            before_n = int(m.group(1))
            after_n = int(m.group(2))
            # Sadece kalıbın varlığını doğrula (gerçek satır sayısı dosya bazlı)
            checks.append({
                "name": "before_after_pattern",
                "passed": True,
                "detail": f"{before_n}→{after_n} ({'düşüş' if after_n < before_n else 'artış'})"
            })

    # F1 iddiası
    if "f1" in msg.lower():
        checks.append({"name": "f1_claim_present", "passed": True,
                       "detail": "F1 iddiası var (manuel doğrulanmalı)"})

    return {"checks": checks, "score": sum(1 for c in checks if c["passed"]),
            "total": len(checks)}


# ═══════════════════════════════════════
# AUDIT LAST COMMIT (CLI)
# ═══════════════════════════════════════

def audit_last_commit() -> dict:
    """Tüm denetleyicileri çalıştır, rapor üret."""
    results = {
        "timestamp": datetime.now().isoformat(),
        "commit": _git(["rev-parse", "--short", "HEAD"]).strip(),
        "msg": _git(["log", "-1", "--pretty=%s"]).strip(),
        "audits": {},
    }

    # claim_verifier commit mesajından OKUNMAZ — sadece runtime çıktılardan
    # (commit mesajındaki sayılar açıklama, iddia değil)
    results["audits"]["commit_audit"] = commit_audit("HEAD")
    results["audits"]["claim_verifier"] = {"checks": [], "score": 0, "total": 0,
                                            "note": "Sadece runtime çıktılardan çalışır"}
    results["audits"]["integration_chain"] = integration_chain("HEAD")
    results["audits"]["diff_anomaly"] = diff_anomaly("HEAD")
    results["audits"]["before_after"] = before_after("HEAD")

    total_passed = sum(a["score"] for a in results["audits"].values())
    total = sum(a["total"] for a in results["audits"].values())
    results["total_score"] = f"{total_passed}/{total}"
    results["all_passed"] = all(a["score"] == a["total"] for a in results["audits"].values())

    # Log
    try:
        AUDIT_LOG.parent.mkdir(parents=True, exist_ok=True)
        with open(AUDIT_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(results, ensure_ascii=False) + "\n")
    except Exception:
        pass

    return results


def print_audit(results: dict):
    """Audit sonucunu yazdır."""
    print(f"\n{'═'*60}")
    print(f"  CC AUDIT — commit {results['commit']}")
    print(f"  {results['msg'][:70]}")
    print(f"{'═'*60}")

    for name, audit in results["audits"].items():
        icon = "✅" if audit["score"] == audit["total"] else "⚠️"
        print(f"\n  {icon} {name}: {audit['score']}/{audit['total']}")
        for c in audit.get("checks", []):
            ci = "✓" if c["passed"] else "✗"
            print(f"    {ci} {c['name']}: {c['detail'][:80]}")

    print(f"\n{'═'*60}")
    print(f"  TOPLAM: {results['total_score']} {'✅' if results['all_passed'] else '⚠️'}")
    print(f"{'═'*60}")


if __name__ == "__main__":
    import sys
    if "--audit-last-commit" in sys.argv or len(sys.argv) == 1:
        r = audit_last_commit()
        print_audit(r)
        sys.exit(0 if r["all_passed"] else 1)
