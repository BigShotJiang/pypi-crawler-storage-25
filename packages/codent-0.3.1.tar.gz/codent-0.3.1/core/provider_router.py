# core/provider_router.py
"""Detect available LLM provider at startup.

Priority: LM Studio → Ollama → llama-cpp (fallback of last resort).
Config: config.toml [llm] section.
Health check cached per session (@lru_cache).
"""

import logging
import tomllib
from functools import lru_cache
from pathlib import Path
from typing import Optional

import httpx
from openai import OpenAI

logger = logging.getLogger(__name__)

CONFIG_PATH = Path(__file__).parent.parent / "config.toml"

# Defaults (overridden by config.toml)
LM_STUDIO_BASE = "http://localhost:1234/v1"
OLLAMA_BASE = "http://localhost:11434/v1"
OLLAMA_PREFERRED_MODEL = "devstral"
HEALTH_TIMEOUT = 2.0


def _load_config() -> dict:
    """Load LLM config from config.toml."""
    if CONFIG_PATH.exists():
        try:
            with open(CONFIG_PATH, "rb") as f:
                cfg = tomllib.load(f)
            return cfg.get("llm", {})
        except Exception:
            pass
    return {}


class ProviderUnavailableError(RuntimeError):
    """Raised when no LLM provider is available."""
    pass


def _check_provider(base_url: str, api_key: str = "none") -> Optional[list[str]]:
    """Check if a provider is alive. Returns model names if reachable, else None."""
    try:
        url = base_url.rstrip("/") + "/models"
        resp = httpx.get(url, timeout=HEALTH_TIMEOUT)
        if resp.status_code != 200:
            return None
        data = resp.json()
        models = [m["id"] for m in data.get("data", [])]
        return models if models else None
    except Exception:
        return None


def _pick_ollama_model(models: list[str]) -> str:
    """Pick devstral if available, otherwise first model."""
    for m in models:
        if OLLAMA_PREFERRED_MODEL in m:
            return m
    return models[0]


@lru_cache(maxsize=1)
def get_provider(
    *,
    lmstudio_base: Optional[str] = None,
    ollama_base: Optional[str] = None,
    api_key: str = "lmstudio",
    timeout: float = 120.0,
) -> tuple[OpenAI, str, str]:
    """Detect available provider once, cache result.

    Returns (client, model_name, provider_name).
    Raises ProviderUnavailableError if none available.
    """
    cfg = _load_config()
    lm_url = lmstudio_base or cfg.get("primary", LM_STUDIO_BASE)
    ol_url = ollama_base or cfg.get("fallback", OLLAMA_BASE)
    preferred_model = cfg.get("model")
    api_timeout = cfg.get("timeouts", {}).get("api_timeout", timeout)
    connect_timeout = cfg.get("timeouts", {}).get("connect_timeout", 10.0)

    # 1. Try LM Studio
    models = _check_provider(lm_url)
    if models:
        model = preferred_model if preferred_model and preferred_model in models else models[0]
        # Check for preferred model with partial match
        if preferred_model and model != preferred_model:
            for m in models:
                if preferred_model in m:
                    model = m
                    break
        client = OpenAI(
            base_url=lm_url, api_key=api_key,
            timeout=httpx.Timeout(api_timeout, connect=connect_timeout),
        )
        logger.info("Provider: lmstudio | Model: %s", model)
        return client, model, "lmstudio"

    logger.warning("LM Studio unavailable, falling back to Ollama")

    # 2. Try Ollama
    models = _check_provider(ol_url)
    if models:
        model = _pick_ollama_model(models)
        client = OpenAI(
            base_url=ol_url, api_key="ollama",
            timeout=httpx.Timeout(api_timeout, connect=connect_timeout),
        )
        logger.info("Provider: ollama | Model: %s", model)
        return client, model, "ollama"

    # 3. Try llama-server (llama-cpp-python)
    llama_url = cfg.get("llama_server", "http://localhost:8080/v1")
    models = _check_provider(llama_url)
    if models:
        model = models[0]
        client = OpenAI(
            base_url=llama_url, api_key="local",
            timeout=httpx.Timeout(api_timeout, connect=connect_timeout),
        )
        logger.info("Provider: llama-server | Model: %s", model)
        return client, model, "llama-server"

    logger.error("No LLM provider available")
    raise ProviderUnavailableError(
        "No LLM provider available.\n"
        f"Tried: {lm_url}, {ol_url}, {llama_url}\n"
        "Hint: Start LM Studio (port 1234) or Ollama (port 11434).\n"
        "Config: config.toml [llm] section."
    )
