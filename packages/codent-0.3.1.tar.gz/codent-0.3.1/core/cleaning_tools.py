#!/usr/bin/env python3
"""Data cleaning tools — detect, fix, validate, log.

Usage: python3 core/cleaning_tools.py <command> <args...>

Commands:
  detect <path> [--table T]           Detect all data issues
  clean_nulls <path> [strategy]       Clean nulls (median|mean|mode|flag|drop)
  handle_outliers <path> [method]     Handle outliers (clip|winsorize|flag|remove)
  fix_skewness <path> [method]        Fix skewness (log1p|sqrt|yeo_johnson)
  drop_useless <path>                 Drop zero-var, duplicate, high-null cols
  validate_types <path>               Check type consistency
  target_analysis <path> <target>     Deep target variable analysis
  segment_analysis <path> <group>     Group-based analysis
  select_features <path> <target> [k] Feature selection (mutual_info)
"""

import json
import sys
from pathlib import Path
from datetime import datetime
import numpy as np


class _NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (np.integer,)): return int(obj)
        if isinstance(obj, (np.floating,)): return float(obj)
        if isinstance(obj, (np.bool_,)): return bool(obj)
        if isinstance(obj, np.ndarray): return obj.tolist()
        return super().default(obj)

def _dumps(obj, **kw):
    return json.dumps(obj, cls=_NpEncoder, **kw)

def _load(path, table=None):
    import pandas as pd
    p = Path(path)
    if p.suffix == ".duckdb":
        import duckdb
        con = duckdb.connect(str(p), read_only=True)
        df = con.execute(f"SELECT * FROM {table}").df()
        con.close()
        return df
    return pd.read_parquet(p) if p.suffix == ".parquet" else pd.read_csv(p)

def _save(df, path):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.suffix == ".parquet":
        df.to_parquet(p, index=False)
    else:
        df.to_csv(p, index=False)

def _log(data, category="cleaning"):
    log_dir = Path(".cont/hive/runs") / category
    log_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = log_dir / f"{category}_{ts}.json"
    path.write_text(_dumps(data, indent=2))
    return str(path)


# ── Detect ──

def cmd_detect(path, table=None):
    df = _load(path, table)
    issues = []

    for col in df.columns:
        s = df[col]
        # Null check
        null_count = int(s.isnull().sum())
        if null_count > 0:
            ratio = null_count / len(df)
            severity = "critical" if ratio > 0.5 else "high" if ratio > 0.2 else "medium" if ratio > 0.05 else "low"
            issues.append({"column": col, "issue": "null", "severity": severity,
                          "affected": null_count, "ratio": round(ratio, 4),
                          "action": "drop_column" if ratio > 0.95 else "impute" if ratio < 0.5 else "flag"})

        # Numeric checks
        import pandas as pd
        is_numeric = pd.api.types.is_numeric_dtype(s)
        if is_numeric:
            clean = s.dropna()
            if len(clean) == 0:
                continue

            # Constant
            if clean.nunique() <= 1:
                issues.append({"column": col, "issue": "constant", "severity": "high",
                              "affected": len(df), "ratio": 1.0, "action": "drop_column"})
                continue

            # Skewness
            skew = float(clean.skew())
            if abs(skew) > 2.0:
                issues.append({"column": col, "issue": "skewed", "severity": "medium",
                              "affected": len(clean), "ratio": 1.0, "skewness": round(skew, 4),
                              "action": "log1p" if skew > 0 and clean.min() >= 0 else "yeo_johnson"})

            # Outliers (IQR)
            q1, q3 = clean.quantile(0.25), clean.quantile(0.75)
            iqr = q3 - q1
            if iqr > 0:
                outliers = ((clean < q1 - 1.5*iqr) | (clean > q3 + 1.5*iqr)).sum()
                if outliers > 0:
                    ratio = int(outliers) / len(clean)
                    severity = "high" if ratio > 0.1 else "medium" if ratio > 0.02 else "low"
                    issues.append({"column": col, "issue": "outlier", "severity": severity,
                                  "affected": int(outliers), "ratio": round(ratio, 4),
                                  "action": "clip" if ratio < 0.05 else "winsorize"})

    # Duplicate columns (r > 0.95)
    numeric = df.select_dtypes(include=["number"])
    if numeric.shape[1] >= 2:
        corr = numeric.corr().abs()
        for i in range(len(corr.columns)):
            for j in range(i+1, len(corr.columns)):
                if corr.iloc[i,j] > 0.95:
                    issues.append({"column": corr.columns[j], "issue": "duplicate",
                                  "severity": "high", "affected": len(df), "ratio": 1.0,
                                  "pair": corr.columns[i], "correlation": round(float(corr.iloc[i,j]), 4),
                                  "action": "drop_one"})

    summary = {"total_issues": len(issues),
               "critical": sum(1 for i in issues if i["severity"] == "critical"),
               "high": sum(1 for i in issues if i["severity"] == "high"),
               "medium": sum(1 for i in issues if i["severity"] == "medium"),
               "low": sum(1 for i in issues if i["severity"] == "low")}

    result = {"summary": summary, "issues": issues}
    log_path = _log(result, "detect")
    result["log"] = log_path
    print(_dumps(result, indent=2))


# ── Clean nulls ──

def cmd_clean_nulls(path, strategy="median", table=None, out=None):
    import pandas as pd
    df = _load(path, table)
    report = []

    numeric = df.select_dtypes(include=["number"]).columns
    for col in numeric:
        null_count = int(df[col].isnull().sum())
        if null_count == 0:
            continue

        if strategy == "flag":
            df[f"{col}_is_null"] = df[col].isnull().astype(int)
            df[col] = df[col].fillna(df[col].median())
            report.append({"column": col, "nulls": null_count, "strategy": "flag+median"})
        elif strategy == "forward_fill":
            df[col] = df[col].ffill()
            report.append({"column": col, "nulls": null_count, "strategy": "forward_fill"})
        elif strategy == "drop":
            pass  # handled below
        else:
            fill_val = df[col].median() if strategy == "median" else df[col].mean() if strategy == "mean" else df[col].mode().iloc[0]
            df[col] = df[col].fillna(fill_val)
            report.append({"column": col, "nulls": null_count, "strategy": strategy, "fill_value": round(float(fill_val), 4)})

    if strategy == "drop":
        before = len(df)
        df = df.dropna()
        report.append({"action": "drop_rows", "before": before, "after": len(df), "dropped": before - len(df)})

    null_after = int(df.isnull().sum().sum())
    if out:
        _save(df, out)

    result = {"null_before": sum(r.get("nulls", 0) for r in report), "null_after": null_after, "report": report, "rows": len(df)}
    _log(result, "nulls")
    print(_dumps(result, indent=2))


# ── Handle outliers ──

def cmd_handle_outliers(path, method="clip", table=None, out=None):
    df = _load(path, table)
    report = []

    numeric = df.select_dtypes(include=["number"]).columns
    for col in numeric:
        s = df[col].dropna()
        if len(s) < 10:
            continue
        q1, q3 = s.quantile(0.25), s.quantile(0.75)
        iqr = q3 - q1
        if iqr == 0:
            continue
        lower, upper = q1 - 1.5*iqr, q3 + 1.5*iqr
        outlier_mask = (df[col] < lower) | (df[col] > upper)
        count = int(outlier_mask.sum())
        if count == 0:
            continue

        if method == "clip":
            df[col] = df[col].clip(lower=lower, upper=upper)
        elif method == "winsorize":
            df[col] = df[col].clip(lower=s.quantile(0.01), upper=s.quantile(0.99))
        elif method == "flag":
            df[f"{col}_outlier"] = outlier_mask.astype(int)
        elif method == "remove":
            df = df[~outlier_mask]

        report.append({"column": col, "outliers": count, "method": method,
                       "lower": round(float(lower), 4), "upper": round(float(upper), 4)})

    if out:
        _save(df, out)
    result = {"method": method, "columns_affected": len(report), "report": report, "rows": len(df)}
    _log(result, "outliers")
    print(_dumps(result, indent=2))


# ── Drop useless ──

def cmd_drop_useless(path, table=None, out=None):
    df = _load(path, table)
    dropped = []

    # Zero variance
    for col in df.select_dtypes(include=["number"]).columns:
        if df[col].nunique() <= 1:
            dropped.append({"column": col, "reason": "zero_variance"})
            df = df.drop(columns=[col])

    # High null (>95%)
    for col in df.columns:
        if df[col].isnull().sum() / len(df) > 0.95:
            dropped.append({"column": col, "reason": "high_null", "null_ratio": round(df[col].isnull().sum()/len(df), 4)})
            df = df.drop(columns=[col])

    # Duplicate (r>0.95)
    numeric = df.select_dtypes(include=["number"])
    if numeric.shape[1] >= 2:
        corr = numeric.corr().abs()
        to_drop = set()
        for i in range(len(corr.columns)):
            for j in range(i+1, len(corr.columns)):
                if corr.iloc[i,j] > 0.95 and corr.columns[j] not in to_drop:
                    to_drop.add(corr.columns[j])
                    dropped.append({"column": corr.columns[j], "reason": "duplicate",
                                   "pair": corr.columns[i], "corr": round(float(corr.iloc[i,j]), 4)})
        df = df.drop(columns=list(to_drop))

    if out:
        _save(df, out)
    result = {"dropped": dropped, "count": len(dropped), "remaining_cols": len(df.columns)}
    _log(result, "drop_useless")
    print(_dumps(result, indent=2))


# ── Target analysis ──

def cmd_target_analysis(path, target, table=None):
    from sklearn.feature_selection import mutual_info_classif
    df = _load(path, table)
    y = df[target]

    # Class distribution
    dist = y.value_counts().to_dict()

    # Point-biserial correlation
    numeric = df.select_dtypes(include=["number"]).drop(columns=[target], errors="ignore")
    correlations = {}
    for col in numeric.columns:
        clean = df[[col, target]].dropna()
        if len(clean) < 10:
            continue
        corr = float(clean[col].corr(clean[target]))
        correlations[col] = round(corr, 4)

    # Group means
    group_means = {}
    for col in list(numeric.columns)[:20]:
        g = df.groupby(target)[col].mean()
        group_means[col] = {str(k): round(float(v), 4) for k, v in g.items()}

    # Mutual information (top 10)
    X = numeric.fillna(0)
    try:
        mi = mutual_info_classif(X, y, random_state=42)
        mi_scores = dict(zip(numeric.columns, [round(float(m), 4) for m in mi]))
        top_features = sorted(mi_scores.items(), key=lambda x: -x[1])[:10]
    except Exception:
        top_features = sorted(correlations.items(), key=lambda x: -abs(x[1]))[:10]

    result = {"target": target, "distribution": {str(k): int(v) for k, v in dist.items()},
              "correlations": dict(sorted(correlations.items(), key=lambda x: -abs(x[1]))[:15]),
              "top_discriminating": top_features, "group_means_sample": dict(list(group_means.items())[:10])}
    print(_dumps(result, indent=2))


# ── Segment analysis ──

def cmd_segment_analysis(path, group_col, target="label", table=None):
    df = _load(path, table)

    groups = {}
    for name, g in df.groupby(group_col):
        target_rate = float(g[target].mean()) if target in g.columns else None
        groups[str(name)] = {
            "count": len(g), "ratio": round(len(g)/len(df), 4),
            "target_rate": round(target_rate, 4) if target_rate is not None else None
        }

    result = {"group_column": group_col, "groups": groups, "total_groups": len(groups)}
    print(_dumps(result, indent=2))


# ── Feature selection ──

def cmd_select_features(path, target, k=15, table=None):
    from sklearn.feature_selection import mutual_info_classif
    df = _load(path, table)
    y = df[target]
    X = df.select_dtypes(include=["number"]).drop(columns=[target], errors="ignore").fillna(0)

    mi = mutual_info_classif(X, y, random_state=42)
    scores = dict(zip(X.columns, [round(float(m), 4) for m in mi]))
    ranked = sorted(scores.items(), key=lambda x: -x[1])
    selected = [name for name, _ in ranked[:int(k)]]

    result = {"method": "mutual_info", "k": int(k), "selected": selected,
              "scores": dict(ranked[:int(k)]), "all_scores": dict(ranked)}
    print(_dumps(result, indent=2))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)

    cmd = sys.argv[1]
    table = out = None
    args = []
    i = 2
    while i < len(sys.argv):
        if sys.argv[i] == "--table" and i+1 < len(sys.argv): table = sys.argv[i+1]; i += 2
        elif sys.argv[i] == "--out" and i+1 < len(sys.argv): out = sys.argv[i+1]; i += 2
        else: args.append(sys.argv[i]); i += 1

    cmds = {
        "detect": lambda: cmd_detect(args[0], table),
        "clean_nulls": lambda: cmd_clean_nulls(args[0], args[1] if len(args)>1 else "median", table, out),
        "handle_outliers": lambda: cmd_handle_outliers(args[0], args[1] if len(args)>1 else "clip", table, out),
        "drop_useless": lambda: cmd_drop_useless(args[0], table, out),
        "target_analysis": lambda: cmd_target_analysis(args[0], args[1], table),
        "segment_analysis": lambda: cmd_segment_analysis(args[0], args[1], args[2] if len(args)>2 else "label", table),
        "select_features": lambda: cmd_select_features(args[0], args[1], args[2] if len(args)>2 else 15, table),
    }
    if cmd not in cmds: print(f"Unknown: {cmd}"); sys.exit(1)
    cmds[cmd]()
