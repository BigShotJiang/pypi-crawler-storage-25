#!/usr/bin/env python3
"""İleri muhakeme gece eğitimi — 7 bölüm, 24 görev, GPU termal yönetimi.

3 görev → 10dk mola → 3 görev → 10dk mola → ...
GPU 70°C üstüyse ekstra 5dk bekle.
07:30'a kadar tekrar çalıştır.
"""

import json, os, re, subprocess, sys, time
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(str(PROJECT_ROOT))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

DB = "/home/sertan/projects/ews_v511/ews_dashboard/db/ews.duckdb"
RESULTS_DIR = PROJECT_ROOT / ".cont" / "hive" / "runs" / "training"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

STOP_TIME = datetime.now().replace(hour=7, minute=30, second=0)
if STOP_TIME < datetime.now():
    STOP_TIME += timedelta(days=1)

SECTIONS = {
    "A": {
        "name": "Sayılar uymuyor",
        "tasks": [
            {"id": "A1", "scenario": f"Scoreboard'da 1,540,051 firma var ama dim_entity'de 4,185,053. 2.6 milyon firma nereye kayboldu? ({DB}) SQL ile araştır.",
             "check": lambda r: any(w in r.lower() for w in ["filtre","katman","dim_entity","fact_periodic","scoreboard","kaybolmadı"])},
            {"id": "A2", "scenario": f"Aynı firma için kombine_risk=150M, kik_risk=50M, kredi_risk=120M ({DB}). Hangisi doğru? Risk nasıl hesaplanıyor?",
             "check": lambda r: any(w in r.lower() for w in ["kombine","coalesce","fallback","toplam","formül","hesaplama"])},
            {"id": "A3", "scenario": f"brz_raporlama_depo'da donem=2501 ama dosya adı 1-DEPO2025. Bu tutarsızlık mı? ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["kaydırma","shift","konvansiyon","rapor","gecikme","dosya adı"])},
        ],
    },
    "B": {
        "name": "Neden bozuldu?",
        "tasks": [
            {"id": "B1", "scenario": f"Dev'de 6000 row dönen fonksiyon prod'da 0 row dönüyor. Hata yok. entity_id tipi VARCHAR vs BIGINT olabilir mi? ({DB})",
             "check": lambda r: any(w in r.upper() for w in ["VARCHAR","BIGINT","CAST","NULL","TİP"]) and any(w in r.lower() for w in ["join","eşleşme","tip","uyumsuz"])},
            {"id": "B2", "scenario": f"_build_diag_index prod'da boş dict döndürüyor. except bloğu hatayı yutuyor olabilir. Bellek sorunu mu? ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["bellek","memory","except","aggregate","sql","fetchdf","oom"])},
            {"id": "B3", "scenario": f"Fonksiyon var, test geçiyor ama prod'da diag_index boş. Fonksiyon çağrılıyor mu? ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["çağrılmıyor","entegrasyon","return","integration","unit test"])},
            {"id": "B4", "scenario": f"HTML'de çok büyük inline JavaScript var. Admin sayfası açılmıyor. Neden? ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["inline","json","chunk","script","boyut","mb","parse"])},
        ],
    },
    "C": {
        "name": "Tasarım kararları",
        "tasks": [
            {"id": "C1", "scenario": f"Diag tablosu neden 42.6M satır? Normalize edilseydi daha iyi olmaz mıydı? ({DB}) Trade-off'u açıkla.",
             "check": lambda r: any(w in r.lower() for w in ["denormalize","trade-off","sorgu","hız","depolama","join"])},
            {"id": "C2", "scenario": f"wsx.id_risk (EUS kapsam sorgusu) neden idempotent değil? Her çalıştırmada farklı sonuç verirse ne olur?",
             "check": lambda r: any(w in r.lower() for w in ["idempotent","canlı","güncel","tekrar","tutarsız"])},
            {"id": "C3", "scenario": f"EWS skoru neden VARCHAR? Integer olsa tip güvenliği olurdu. Neden string seçildi? ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["varchar","yi","string","integer","cast","esneklik"])},
        ],
    },
    "D": {
        "name": "Zincir muhakeme",
        "tasks": [
            {"id": "D1", "scenario": f"Bir firmanın 2503'te skoru 400, 2602'de 750. 12 dönemlik trajectory'sini çıkar, kırılma noktasını bul. ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["trajectory","kırılma","dönem","trend","geçiş","artış"])},
            {"id": "D2", "scenario": f"EUS skoru hesaplanan firma seti dönemler arası neden değişiyor? Kapsam sorgusu nasıl çalışıyor? ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["kapsam","eus","filtre","sorgu","değişiyor","set"])},
            {"id": "D3", "scenario": f"Admin sayfasında bir firmanın Neden YIS tablosu boş ama diag verisi var. _build_diag_index_full vs _slim farkı ne?",
             "check": lambda r: any(w in r.lower() for w in ["slim","full","admin","diag","fark","index"])},
            {"id": "D4", "scenario": f"2509'da YI sayısı aniden %30 arttı. Gerçek mi yoksa veri anomalisi mi? En az 3 alternatif açıklama ver. ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["alternatif","açıklama","anomali","gerçek","veri","kapsam"])},
        ],
    },
    "E": {
        "name": "Çapraz kontrol",
        "tasks": [
            {"id": "E1", "scenario": f"fact_periodic + dim_entity + brz_kik_izleme ({DB}): entity_id tutarlı mı? Dönem uyumu var mı? Risk tutarlı mı?",
             "check": lambda r: any(w in r.lower() for w in ["tutarlı","entity_id","dönem","risk","join","tip"])},
            {"id": "E2", "scenario": f"Scoreboard çıktısındaki firma sayısı ile fact_periodic'teki firma sayısı ({DB}) aynı mı? Fark varsa neden?",
             "check": lambda r: any(w in r.lower() for w in ["firma","sayı","fark","filtre","scoreboard","fact"])},
            {"id": "E3", "scenario": f"fact_periodic'te ews_skor='YI' olan firmalarla ykn_izl_flag=1 olan firmalar ({DB}) aynı set mi? Fark ne kadar?",
             "check": lambda r: any(w in r.lower() for w in ["yi","ykn_izl","fark","aynı","set","flag"])},
        ],
    },
    "F": {
        "name": "Sistem düşüncesi",
        "tasks": [
            {"id": "F1", "scenario": f"brz_eus_tahmin yanlış geldi — downstream etki analizi yap. Hangi tablolar, hangi raporlar etkilenir? ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["downstream","etki","bağımlı","tablo","rapor","pipeline"])},
            {"id": "F2", "scenario": f"EUS eşiğini 325'ten 250'ye düşürseydik ne olurdu? Kaç firma daha yakalanırdı, precision nasıl değişirdi? ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["eşik","threshold","precision","recall","firma","250"])},
            {"id": "F3", "scenario": f"Bu pipeline'ın en kırılgan noktası neresi? Hangi adım bozulursa en çok hasar verir? ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["kırılgan","hasar","risk","bağımlılık","tek nokta","critical"])},
        ],
    },
    "G": {
        "name": "Meta-muhakeme",
        "tasks": [
            {"id": "G1", "scenario": f"Yüksek risk volatilitesi olan firmaların %80'i YI oluyor. Volatiliteyi düşürmek YI'yı azaltır mı? ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["korelasyon","nedensellik","causation","ters","correlation"])},
            {"id": "G2", "scenario": f"0-325 bandındaki firmaların %95'i 12 dönem güvenli kalmış. Model çok iyi mi? ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["survivorship","bias","hayatta","kalan","seçilim","yanılgı"])},
            {"id": "G3", "scenario": f"Her segmentte precision >%22 ama genel precision %18. Bu nasıl mümkün? ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["simpson","paradoks","ağırlık","weight","segment","boyut"])},
            {"id": "G4", "scenario": f"2506'da EUS firma sayısı %5 düştü. Bu kriz mi? En az 3 alternatif açıklama ver. ({DB})",
             "check": lambda r: any(w in r.lower() for w in ["alternatif","açıklama","kapsam","kriz","veri","sorgu"])},
        ],
    },
}


def gpu_temp():
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=temperature.gpu", "--format=csv,noheader"],
                           capture_output=True, text=True, timeout=5)
        return int(r.stdout.strip())
    except Exception:
        return -1


def rest(minutes=10, label="DİNLENME"):
    """GPU soğutma molası."""
    t = gpu_temp()
    print(f"\n[{label}] {datetime.now().strftime('%H:%M')} — GPU={t}°C, {minutes}dk bekleniyor...")
    time.sleep(minutes * 60)
    t2 = gpu_temp()
    if t2 > 70:
        print(f"  GPU hâlâ {t2}°C > 70°C, ekstra 5dk...")
        time.sleep(300)
    t3 = gpu_temp()
    print(f"  [{label} BİTTİ] GPU={t3}°C")


def run_cont(task):
    t0 = time.time()
    try:
        from cont import run_task
        answer, success = run_task(task)
        return {"answer": answer or "", "elapsed": round(time.time()-t0, 1),
                "tools": len(getattr(run_task, '_last_tools_used', []) or []),
                "recipe": getattr(run_task, '_last_recipe_id', None)}
    except Exception as e:
        return {"answer": f"ERROR:{e}", "elapsed": round(time.time()-t0, 1), "tools": 0, "recipe": None}


def score_answer(answer, task):
    """Basit otomatik puanlama."""
    if not answer or "ERROR" in answer:
        return {"dogruluk": 0, "zincir": 0, "derinlik": 0, "farkindalik": 0}

    passed = task["check"](answer)
    length = len(answer)
    steps = len(re.findall(r'(?:^\d+[\.\)]|^-\s|^#{1,3}\s|Adım)', answer, re.MULTILINE))

    dogruluk = 3 if passed and length > 200 else 2 if passed else 1 if length > 50 else 0
    zincir = min(4, steps)
    derinlik = 3 if length > 500 else 2 if length > 200 else 1
    farkindalik = 2 if any(w in answer.lower() for w in ["tuzak","dikkat","uyarı","yanıltıcı","varsayım"]) else 1

    return {"dogruluk": dogruluk, "zincir": zincir, "derinlik": derinlik, "farkindalik": farkindalik}


def weighted(scores):
    return round(scores["dogruluk"]*0.3 + scores["zincir"]*0.3 + scores["derinlik"]*0.2 + scores["farkindalik"]*0.2, 1)


def run_section(section_key, section):
    """Bir bölümü çalıştır."""
    tasks = section["tasks"]
    name = section["name"]
    results = []

    print(f"\n{'█'*60}")
    print(f"  BÖLÜM {section_key}: {name} ({len(tasks)} görev)")
    print(f"{'█'*60}")

    for ti, task in enumerate(tasks):
        if datetime.now() > STOP_TIME:
            print(f"  ⏰ 07:30 geçti, durduruluyor")
            break

        print(f"\n  [{task['id']}] {task['scenario'][:70]}...")
        r = run_cont(task["scenario"])
        scores = score_answer(r["answer"], task)
        w = weighted(scores)
        icon = "✓" if w >= 2.5 else "~" if w >= 1.5 else "✗"
        print(f"    {icon} {w}/4.0 (d={scores['dogruluk']} z={scores['zincir']} "
              f"dp={scores['derinlik']} f={scores['farkindalik']}) | {r['elapsed']:.0f}s")

        results.append({
            "id": task["id"], "scores": scores, "weighted": w,
            "elapsed": r["elapsed"], "tools": r["tools"], "recipe": r["recipe"],
            "answer_len": len(r["answer"]),
        })
        time.sleep(2)

    # Bölüm özeti
    total_w = sum(r["weighted"] for r in results)
    max_w = len(results) * 4
    print(f"\n  Bölüm {section_key}: {total_w:.1f}/{max_w:.0f}")
    return results


def run_training_cycle(cycle_num=1):
    """Tam bir eğitim döngüsü — 7 bölüm + molalar."""
    print(f"\n{'═'*60}")
    print(f"  EĞİTİM DÖNGÜSÜ #{cycle_num} — {datetime.now().strftime('%H:%M')}")
    print(f"  Hedef bitiş: {STOP_TIME.strftime('%H:%M')}")
    print(f"{'═'*60}")

    all_results = {}
    task_counter = 0

    for section_key in sorted(SECTIONS.keys()):
        if datetime.now() > STOP_TIME:
            break

        section = SECTIONS[section_key]
        results = run_section(section_key, section)
        all_results[section_key] = results
        task_counter += len(results)

        # Her 3 görev → mola
        if task_counter % 3 == 0 and section_key != list(SECTIONS.keys())[-1]:
            ml_task = section_key in ("B", "D")  # ML/ağır görevler
            rest(15 if ml_task else 10)

    return all_results


def save_results(all_results, cycle_num):
    """Sonuçları kaydet."""
    total_w = sum(r["weighted"] for results in all_results.values() for r in results)
    total_tasks = sum(len(results) for results in all_results.values())
    max_w = total_tasks * 4

    summary = {
        "cycle": cycle_num,
        "timestamp": datetime.now().isoformat(),
        "total_score": round(total_w, 1),
        "max_score": max_w,
        "total_tasks": total_tasks,
        "pct": round(total_w / max(max_w, 1) * 100, 1),
        "gpu_temp": gpu_temp(),
        "sections": {},
    }

    for key, results in all_results.items():
        sec_w = sum(r["weighted"] for r in results)
        sec_max = len(results) * 4
        summary["sections"][key] = {
            "name": SECTIONS[key]["name"],
            "score": round(sec_w, 1),
            "max": sec_max,
            "tasks": results,
        }

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = RESULTS_DIR / f"advanced_cycle{cycle_num}_{ts}.json"
    out.write_text(json.dumps(summary, indent=2, ensure_ascii=False, default=str))

    print(f"\n{'═'*60}")
    print(f"  DÖNGÜ #{cycle_num} SONUCU: {total_w:.1f}/{max_w} ({summary['pct']}%)")
    for key in sorted(summary["sections"].keys()):
        s = summary["sections"][key]
        print(f"    {key}. {s['name']:<20s} {s['score']:.1f}/{s['max']}")
    print(f"  GPU: {summary['gpu_temp']}°C")
    print(f"  JSON: {out}")

    return summary


def main():
    cycle = 1

    while datetime.now() < STOP_TIME:
        results = run_training_cycle(cycle)
        summary = save_results(results, cycle)

        # Guardian
        try:
            from core.guardian import run_guardian
            report = run_guardian(full=True)
            g = sum(1 for r in report.results.values() if r["passed"])
            print(f"  Guardian: {g}/{len(report.results)}")
        except Exception:
            pass

        # Sonraki döngü için uzun mola
        if datetime.now() < STOP_TIME:
            remaining = (STOP_TIME - datetime.now()).total_seconds() / 60
            if remaining > 30:
                print(f"\n  Sonraki döngüye kadar 20dk mola (kalan: {remaining:.0f}dk)")
                rest(20, "DÖNGÜ ARASI")
                cycle += 1
            else:
                print(f"\n  Kalan süre {remaining:.0f}dk — döngü yeterli değil, durduruluyor")
                break

    # Sabah raporu
    print(f"\n{'█'*60}")
    print(f"  SABAH RAPORU — {datetime.now().strftime('%H:%M')}")
    print(f"  Toplam döngü: {cycle}")
    print(f"  GPU: {gpu_temp()}°C")
    print(f"{'█'*60}")


if __name__ == "__main__":
    main()
