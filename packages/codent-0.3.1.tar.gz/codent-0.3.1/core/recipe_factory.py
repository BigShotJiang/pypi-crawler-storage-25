# core/recipe_factory.py
"""Recipe Factory — standart reçete üretim modülü.

Kim üretirse üretsin, bu modülün create() fonksiyonunu çağırır.
7 adım: validate → normalize → dedup → quality gate → classify → register → activate.
"""

import json
import yaml
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path

from core.utils import debug as _debug

RECIPE_DIR = Path(__file__).parent.parent / ".cont" / "hive" / "recipes"
KNOWLEDGE_DIR = Path(__file__).parent.parent / ".cont" / "hive" / "knowledge"
ACTIVATION_MAP = KNOWLEDGE_DIR / "activation_map.yaml"
TRAIL_PATH = Path(__file__).parent.parent / ".cont" / "hive" / "pheromone" / "trail.jsonl"

REQUIRED_FIELDS = ["name", "description", "trigger", "layer", "steps"]
VALID_LAYERS = ["primitive", "composite", "project"]
STRONG_VERIFY = {"output_contains", "output_matches", "json_validate", "equals",
                 "assert_equal", "assert_range", "assert_count", "test_passes"}
WEAK_VERIFY = {"exit_code", "not_empty", "is_boolean"}


class RecipeFactory:

    def create(self, recipe_data: dict, source: str = "unknown",
               mode: str = "strict") -> dict:
        """Reçete oluştur. Returns: {status, path, reason, warnings}."""
        warnings = []

        # 1. VALIDATE
        v = self._validate(recipe_data, mode)
        if not v["valid"]:
            return {"status": "rejected", "reason": v["reason"], "warnings": v.get("warnings", [])}
        warnings.extend(v.get("warnings", []))

        # 2. NORMALIZE
        normalized = self._normalize(recipe_data, source)

        # 3. DEDUP
        dedup = self._dedup_check(normalized)
        if dedup["is_duplicate"]:
            if dedup.get("action") == "extend_trigger":
                self._extend_trigger(dedup["existing_path"], normalized["trigger"])
                return {"status": "duplicate", "reason": f"Trigger genişletildi: {dedup['existing_name']}", "warnings": warnings}
            return {"status": "duplicate", "reason": f"Zaten var: {dedup['existing_name']}", "warnings": warnings}

        # 4. QUALITY GATE
        q = self._quality_check(normalized, mode)
        warnings.extend(q.get("warnings", []))
        if mode == "strict" and not q["pass"]:
            return {"status": "rejected", "reason": q["reason"], "warnings": warnings}
        if mode == "draft" and not q["pass"]:
            normalized["status"] = "draft"

        # 5. CLASSIFY + REGISTER
        layer = normalized.get("layer", "primitive")
        target_dir = RECIPE_DIR / self._layer_dir(layer)
        target_dir.mkdir(parents=True, exist_ok=True)
        target_path = target_dir / f"{normalized['name']}.yaml"
        target_path.write_text(yaml.dump(normalized, allow_unicode=True,
                                          default_flow_style=False, sort_keys=False), encoding="utf-8")

        # 6. ACTIVATE
        self._update_activation_map(normalized)

        # 7. LOG
        self._log_creation(normalized, source, str(target_path))

        status = "draft" if normalized.get("status") == "draft" else "created"
        return {"status": status, "path": str(target_path), "reason": "Kaydedildi", "warnings": warnings}

    def _validate(self, data, mode):
        missing = [f for f in REQUIRED_FIELDS if f not in data]
        if missing:
            return {"valid": False, "reason": f"Zorunlu alan eksik: {missing}"}
        name = data.get("name", "")
        if not name or not name.replace("_", "").replace("-", "").isalnum():
            return {"valid": False, "reason": f"Geçersiz name: '{name}'"}
        if data.get("layer") not in VALID_LAYERS:
            return {"valid": False, "reason": f"Geçersiz layer: '{data.get('layer')}'"}
        steps = data.get("steps", [])
        if not steps:
            return {"valid": False, "reason": "steps boş"}
        warnings = []
        for i, step in enumerate(steps):
            if "verify" not in step and mode == "strict":
                return {"valid": False, "reason": f"Adım {step.get('id', i)}: verify yok"}
            if "verify" not in step:
                warnings.append(f"Adım {step.get('id', i)}: verify eksik")
        return {"valid": True, "warnings": warnings}

    def _normalize(self, data, source):
        n = dict(data)
        n.setdefault("success_count", 0)
        n.setdefault("fail_count", 0)
        n.setdefault("tested", False)
        n.setdefault("status", "active")
        n.setdefault("version", 1)
        n["created_by"] = source
        n["created_at"] = datetime.now().isoformat()
        trigger = n.get("trigger", "")
        if isinstance(trigger, list):
            trigger = ", ".join(trigger)
        n["trigger"] = trigger.lower().strip()
        for i, step in enumerate(n.get("steps", [])):
            step.setdefault("id", f"step_{i+1}")
            step.setdefault("llm_required", False)
            step.setdefault("output", f"result_{i+1}")
        return n

    def _dedup_check(self, recipe):
        for rfile in self._all_recipes():
            try:
                existing = yaml.safe_load(rfile.read_text(encoding="utf-8")) or {}
            except Exception:
                continue
            if existing.get("name") == recipe.get("name"):
                return {"is_duplicate": True, "existing_name": existing["name"],
                        "existing_path": str(rfile), "action": "exact_match"}
            t1 = recipe.get("trigger", "")
            t2 = existing.get("trigger", "")
            if not t1 or not t2:
                continue
            trigger_sim = SequenceMatcher(None, t1, t2).ratio()
            s1 = [s.get("worker", "") for s in recipe.get("steps", [])]
            s2 = [s.get("worker", "") for s in existing.get("steps", [])]
            step_sim = SequenceMatcher(None, s1, s2).ratio()
            combined = trigger_sim * 0.4 + step_sim * 0.6
            if combined > 0.7:
                action = "extend_trigger" if trigger_sim < 0.9 else "exact_match"
                return {"is_duplicate": True, "existing_name": existing.get("name", "?"),
                        "existing_path": str(rfile), "action": action, "similarity": combined}
        return {"is_duplicate": False}

    def _extend_trigger(self, existing_path, new_trigger):
        path = Path(existing_path)
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        old = set(k.strip() for k in data.get("trigger", "").split(",") if k.strip())
        new = set(k.strip() for k in new_trigger.split(",") if k.strip())
        data["trigger"] = ", ".join(sorted(old | new))
        path.write_text(yaml.dump(data, allow_unicode=True, default_flow_style=False, sort_keys=False), encoding="utf-8")

    def _quality_check(self, recipe, mode):
        warnings = []
        steps = recipe.get("steps", [])
        weak = sum(1 for s in steps if s.get("verify", {}).get("method", "") in WEAK_VERIFY)
        no_verify = sum(1 for s in steps if "verify" not in s)
        total = len(steps)
        if no_verify == total:
            return {"pass": False, "reason": "Hiçbir adımda verify yok", "warnings": warnings}
        ratio = (weak + no_verify) / max(total, 1)
        if mode == "strict" and ratio > 0.5:
            return {"pass": False, "reason": f"Verify kalitesi düşük: {weak} zayıf + {no_verify} eksik / {total}", "warnings": warnings}
        if weak > 0:
            warnings.append(f"{weak} adımda zayıf verify — Seviye 3+ önerilir")
        return {"pass": True, "warnings": warnings}

    def _update_activation_map(self, recipe):
        if not ACTIVATION_MAP.exists():
            return
        try:
            map_data = yaml.safe_load(ACTIVATION_MAP.read_text(encoding="utf-8")) or {}
            activation = map_data.get("activation", {})
            for kw in recipe.get("activation_hints", []):
                kw_lower = kw.lower()
                if kw_lower in activation and isinstance(activation[kw_lower], dict):
                    recipes_list = activation[kw_lower].get("recipes", [])
                    if recipe["name"] not in recipes_list:
                        recipes_list.append(recipe["name"])
                        activation[kw_lower]["recipes"] = recipes_list
            map_data["activation"] = activation
            ACTIVATION_MAP.write_text(yaml.dump(map_data, allow_unicode=True,
                                                 default_flow_style=False, sort_keys=False), encoding="utf-8")
        except Exception:
            pass

    def _layer_dir(self, layer):
        return {"primitive": "primitives", "composite": "composites", "project": "project"}.get(layer, "primitives")

    def _all_recipes(self):
        recipes = []
        for d in ("primitives", "composites", "project"):
            rdir = RECIPE_DIR / d
            if rdir.exists():
                recipes.extend(rdir.glob("*.yaml"))
        return recipes

    def _log_creation(self, recipe, source, path):
        try:
            entry = {"event": "recipe_created", "ts": datetime.now().isoformat(),
                     "recipe_name": recipe["name"], "source": source, "path": path,
                     "layer": recipe.get("layer"), "steps": len(recipe.get("steps", []))}
            TRAIL_PATH.parent.mkdir(parents=True, exist_ok=True)
            with open(TRAIL_PATH, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            pass


_factory = None

def get_factory():
    global _factory
    if _factory is None:
        _factory = RecipeFactory()
    return _factory

def create_recipe(recipe_data, source="unknown", mode="strict"):
    return get_factory().create(recipe_data, source, mode)
