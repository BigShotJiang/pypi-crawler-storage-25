# core/recipe_learner.py
"""Post-task recipe learning — otomatik reçete üretimi, dedup, recall feedback.

3 mekanizma:
1. post_task_recipe: başarılı görevden tool zincirini reçeteye çevir
2. dedup_recipe: mevcut reçetelerle benzerlik kontrolü
3. recall_feedback: recall eşleşmeme gap analizi + trigger genişletme
"""

import json
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import yaml

from core.utils import debug as _debug

HIVE_DIR = Path(__file__).parent.parent / ".cont" / "hive"
RECIPES_DIR = HIVE_DIR / "recipes"
INBOX_DIR = HIVE_DIR / "inbox"
TRAIL_PATH = HIVE_DIR / "pheromone" / "trail.jsonl"
FEEDBACK_LOG = HIVE_DIR / "runs" / "recall_feedback.jsonl"

# Minimum tool call to generate recipe (1-tool tasks too trivial)
MIN_TOOLS_FOR_RECIPE = 1


# ══════════════════════════════════════════════════════
# 1. POST-TASK RECIPE GENERATION
# ══════════════════════════════════════════════════════

def post_task_recipe(task: str, tools_used: list, success: bool,
                     elapsed_s: float, recipe_matched: str = None) -> Optional[str]:
    """Başarılı görevden ham reçete üret → inbox'a veya mevcut reçeteyi güncelle.

    Returns: inbox path if written, None otherwise.
    """
    if not success or not task or not tools_used:
        return None
    if len(tools_used) < MIN_TOOLS_FOR_RECIPE:
        return None

    # Task'tan keyword'ler çıkar
    task_keywords = _extract_keywords(task)
    if not task_keywords:
        return None

    # Tool zincirini steps'e çevir
    steps = _tools_to_steps(tools_used)
    if not steps:
        return None

    # Dedup kontrolü
    match = find_similar_recipe(task_keywords, tools_used)
    if match:
        similarity = match["similarity"]
        if similarity >= 0.70:
            # Mevcut reçetenin trigger'ını genişlet
            _expand_triggers(match["recipe_path"], task_keywords)
            _debug(f"[LEARNER] Dedup: {match['recipe_name']} trigger genişletildi ({similarity:.0%})")
            return None

    # Yeni reçete — inbox'a yaz
    recipe_name = _generate_recipe_name(task)
    recipe = {
        "name": recipe_name,
        "description": task[:120],
        "trigger": ", ".join(task_keywords[:10]),
        "learned_from": f"auto_{datetime.now().strftime('%Y-%m-%d')}",
        "layer": "primitive",
        "success_count": 1,
        "fail_count": 0,
        "steps": steps,
    }

    # Factory üzerinden oluştur (kalite kapısı + dedup + activation)
    try:
        from core.recipe_factory import create_recipe
        result = create_recipe(recipe, source="recipe_learner", mode="draft")
        if result["status"] in ("created", "draft"):
            _debug(f"[LEARNER] Factory: {result['status']} → {result.get('path','?')}")
            return result.get("path")
        elif result["status"] == "duplicate":
            _debug(f"[LEARNER] Factory dedup: {result['reason']}")
            return None
        else:
            _debug(f"[LEARNER] Factory rejected: {result['reason']}")
    except Exception as e:
        _debug(f"[LEARNER] Factory error, inbox fallback: {e}")

    # Fallback: inbox'a yaz
    INBOX_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    filename = f"{ts}_{recipe_name}.yaml"
    out_path = INBOX_DIR / filename
    out_path.write_text(yaml.dump(recipe, allow_unicode=True, default_flow_style=False, sort_keys=False))
    _debug(f"[LEARNER] Inbox fallback: {out_path.name}")
    return str(out_path)


def _extract_keywords(task: str) -> list[str]:
    """Task'tan anlamlı keyword'ler çıkar (stopword'ler hariç)."""
    stopwords = {
        "bir", "bu", "şu", "ve", "ile", "için", "olan", "var", "yok",
        "mi", "mı", "mu", "mü", "de", "da", "den", "dan", "ne", "nasıl",
        "the", "a", "an", "is", "are", "to", "for", "in", "of", "and",
        "bul", "yap", "et",  # çok genel fiiller
    }
    words = re.findall(r'[a-zA-ZçğıöşüÇĞİÖŞÜ]{3,}', task.lower())
    return [w for w in words if w not in stopwords][:15]


def _tools_to_steps(tools_used: list) -> list[dict]:
    """Tool listesini reçete step formatına çevir."""
    steps = []
    seen_tools = {}
    for i, tool in enumerate(tools_used):
        tool_name = tool if isinstance(tool, str) else tool.get("name", str(tool))
        # Aynı tool tekrar → skip (dedup within recipe)
        count = seen_tools.get(tool_name, 0)
        seen_tools[tool_name] = count + 1
        if count >= 3:  # aynı tool 3+ kez → skip
            continue

        worker = _tool_to_worker(tool_name)
        step = {
            "id": f"step_{i+1}",
            "worker": worker,
            "llm_required": worker in ("single_file_analyzer", "code_writer", "summarizer"),
            "params": {"tool": tool_name},
            "verify": {"method": "output_matches", "expected": ".+"},
            "output": f"result_{i+1}",
        }
        steps.append(step)
    return steps


def _tool_to_worker(tool_name: str) -> str:
    """Tool adını worker tipine çevir."""
    mapping = {
        "run_shell": "grep_worker",
        "read_file": "grep_worker",
        "list_dir": "file_lister",
        "search_files": "grep_worker",
        "find_path": "file_lister",
        "web_search": "grep_worker",
        "web_fetch": "grep_worker",
        "recall": "grep_worker",
        "remember": "formatter",
    }
    return mapping.get(tool_name, "grep_worker")


def _generate_recipe_name(task: str) -> str:
    """Task'tan snake_case reçete adı üret."""
    words = _extract_keywords(task)[:4]
    if not words:
        words = ["auto_task"]
    name = "_".join(words)
    # Sanitize
    name = re.sub(r'[^a-z0-9_]', '', name)
    return name[:50] or "auto_recipe"


# ══════════════════════════════════════════════════════
# 2. RECIPE DEDUP
# ══════════════════════════════════════════════════════

def find_similar_recipe(task_keywords: list[str], tools_used: list,
                        threshold: float = 0.70) -> Optional[dict]:
    """Mevcut reçetelerle benzerlik kontrolü.

    Returns: {"recipe_name", "recipe_path", "similarity"} or None.
    """
    if not RECIPES_DIR.exists():
        return None

    task_kw_set = set(task_keywords)
    tool_names = [t if isinstance(t, str) else t.get("name", "") for t in tools_used]

    best_match = None
    best_score = 0.0

    for layer in ("primitives", "composites", "project"):
        layer_dir = RECIPES_DIR / layer
        if not layer_dir.exists():
            continue
        for f in layer_dir.glob("*.yaml"):
            try:
                data = yaml.safe_load(f.read_text(encoding="utf-8"))
                if not data or not isinstance(data, dict):
                    continue

                # Trigger keyword overlap
                trigger = data.get("trigger", "")
                trigger_kws = set(re.findall(r'[a-zA-ZçğıöşüÇĞİÖŞÜ]{3,}', trigger.lower()))
                if not trigger_kws:
                    continue

                kw_overlap = len(task_kw_set & trigger_kws) / max(len(task_kw_set | trigger_kws), 1)

                # Tool sequence similarity
                recipe_tools = []
                for step in data.get("steps", []):
                    w = step.get("worker", "")
                    p = step.get("params", {})
                    recipe_tools.append(p.get("tool", w))

                tool_sim = _sequence_similarity(tool_names, recipe_tools)

                # Combined score (keyword 60%, tool 40%)
                combined = kw_overlap * 0.6 + tool_sim * 0.4

                if combined > best_score:
                    best_score = combined
                    best_match = {
                        "recipe_name": data.get("name", f.stem),
                        "recipe_path": str(f),
                        "similarity": combined,
                        "kw_overlap": kw_overlap,
                        "tool_sim": tool_sim,
                    }

            except Exception:
                continue

    if best_match and best_score >= threshold:
        return best_match
    return None


def _sequence_similarity(seq1: list, seq2: list) -> float:
    """İki tool sequence'ın benzerliği (Jaccard + order bonus)."""
    if not seq1 or not seq2:
        return 0.0
    set1, set2 = set(seq1), set(seq2)
    jaccard = len(set1 & set2) / max(len(set1 | set2), 1)

    # Order bonus: ilk N tool aynı sırada mı?
    min_len = min(len(seq1), len(seq2))
    order_matches = sum(1 for i in range(min_len) if seq1[i] == seq2[i])
    order_bonus = order_matches / max(min_len, 1) * 0.3

    return min(jaccard + order_bonus, 1.0)


def _expand_triggers(recipe_path: str, new_keywords: list[str]) -> bool:
    """Mevcut reçetenin trigger'ına yeni keyword'ler ekle."""
    try:
        path = Path(recipe_path)
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not data:
            return False

        existing_trigger = data.get("trigger", "")
        existing_kws = set(k.strip().lower() for k in existing_trigger.split(",") if k.strip())

        # Yeni keyword'leri ekle
        added = []
        for kw in new_keywords:
            if kw.lower() not in existing_kws and len(kw) >= 3:
                added.append(kw)

        if not added:
            return False

        # Trigger güncelle
        new_trigger = existing_trigger
        if added:
            new_trigger = existing_trigger + ", " + ", ".join(added[:5])
            data["trigger"] = new_trigger

        path.write_text(yaml.dump(data, allow_unicode=True, default_flow_style=False, sort_keys=False))
        _debug(f"[LEARNER] Trigger genişletildi: +{added[:5]} → {path.name}")
        return True
    except Exception as e:
        _debug(f"[LEARNER] Trigger genişletme hatası: {e}")
        return False


# ══════════════════════════════════════════════════════
# 3. RECALL FEEDBACK LOOP
# ══════════════════════════════════════════════════════

def recall_feedback(task: str, recipe_matched: str, tools_used: list) -> Optional[dict]:
    """Recall eşleşmeme gap analizi — neden eşleşmedi, trigger genişlet.

    Çağrılma koşulu: Cont reçetesiz çözdü (recipe_matched=None).
    """
    if recipe_matched:
        return None  # Zaten eşleşmiş, sorun yok

    if not tools_used:
        return None  # Tool kullanmadı, basit soru

    task_keywords = _extract_keywords(task)
    if not task_keywords:
        return None

    # En yakın reçeteyi bul (eşik altında kalmış olabilir)
    match = find_similar_recipe(task_keywords, tools_used, threshold=0.30)
    if not match:
        # Hiç benzer reçete yok — yeni alan
        gap = {
            "task": task[:200],
            "existing_recipe": None,
            "gap": "no_similar_recipe",
            "task_keywords": task_keywords[:10],
            "timestamp": datetime.now().isoformat(),
        }
        _log_feedback(gap)
        return gap

    # Benzer reçete var ama eşleşmedi — trigger eksikliği
    recipe_path = Path(match["recipe_path"])
    try:
        recipe_data = yaml.safe_load(recipe_path.read_text(encoding="utf-8"))
        recipe_triggers = set(k.strip().lower() for k in recipe_data.get("trigger", "").split(","))
    except Exception:
        recipe_triggers = set()

    task_kw_set = set(task_keywords)
    missing_in_trigger = task_kw_set - recipe_triggers
    gap = {
        "task": task[:200],
        "existing_recipe": match["recipe_name"],
        "recipe_triggers": sorted(recipe_triggers)[:10],
        "task_keywords": task_keywords[:10],
        "gap": f"trigger'da eksik: {sorted(missing_in_trigger)[:5]}",
        "similarity": round(match["similarity"], 2),
        "timestamp": datetime.now().isoformat(),
    }

    # Otomatik trigger genişletme (similarity >= 0.40 ise güvenli)
    if match["similarity"] >= 0.40:
        expanded = _expand_triggers(match["recipe_path"], list(missing_in_trigger))
        gap["auto_expanded"] = expanded
        if expanded:
            _debug(f"[LEARNER] Recall feedback: {match['recipe_name']} trigger genişletildi")

    _log_feedback(gap)
    return gap


def _log_feedback(entry: dict):
    """Feedback logunu yaz."""
    try:
        FEEDBACK_LOG.parent.mkdir(parents=True, exist_ok=True)
        with open(FEEDBACK_LOG, "a") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass


# ══════════════════════════════════════════════════════
# ENTEGRASYON: post-task hook
# ══════════════════════════════════════════════════════

def on_task_complete(task: str, success: bool, tools_used: list,
                     elapsed_s: float, recipe_matched: str = None):
    """Runtime'dan çağrılır — post-task learning pipeline.

    1. Recall feedback (eşleşmeme analizi)
    2. Recipe generation (başarılı görevden reçete üret)
    """
    try:
        # 1. Recall feedback
        recall_feedback(task, recipe_matched, tools_used)

        # 2. Recipe generation (başarılı + tool kullanan görevler)
        if success and tools_used:
            post_task_recipe(task, tools_used, success, elapsed_s, recipe_matched)
    except Exception as e:
        _debug(f"[LEARNER] on_task_complete error: {e}")
