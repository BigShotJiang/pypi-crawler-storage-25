# core/task_classifier.py
"""Task type classification for adaptive prompting and success tracking."""

import re
from pathlib import Path

# Loaded from .cont/hive/knowledge/task_classifier.yaml
_CLASSIFIER_CACHE: dict | None = None

def _load_classifier_knowledge() -> tuple[dict, dict]:
    global _CLASSIFIER_CACHE
    if _CLASSIFIER_CACHE is not None:
        return _CLASSIFIER_CACHE["task_types"], _CLASSIFIER_CACHE["strong_signals"]
    yaml_path = Path(__file__).parent.parent / ".cont" / "hive" / "knowledge" / "task_classifier.yaml"
    task_types: dict = {}
    strong_signals: dict = {}
    if yaml_path.exists():
        import yaml
        data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
        task_types = data.get("task_types", {})
        strong_signals = data.get("strong_signals", {})
    _CLASSIFIER_CACHE = {"task_types": task_types, "strong_signals": strong_signals}
    return task_types, strong_signals

TASK_TYPES, STRONG_SIGNALS = _load_classifier_knowledge()


def classify_task(task: str) -> str:
    """
    Return task type based on keyword matching.
    Returns the best-matching type or 'general' if no strong match.
    """
    if not task:
        return "general"

    task_lower = task.lower()

    # Check strong signals first (2x weight)
    scores = {}
    for task_type, keywords in STRONG_SIGNALS.items():
        for kw in keywords:
            if kw in task_lower:
                scores[task_type] = scores.get(task_type, 0) + 2

    # Check regular keywords
    for task_type, keywords in TASK_TYPES.items():
        for kw in keywords:
            if kw in task_lower:
                scores[task_type] = scores.get(task_type, 0) + 1

    if not scores:
        return "general"

    return max(scores, key=scores.get)


def is_turkish(task: str) -> bool:
    """Check if task contains Turkish characters or common Turkish words."""
    turkish_chars = set("çğıöşüÇĞİÖŞÜ")
    if any(c in turkish_chars for c in task):
        return True

    turkish_words = [
        "bir", "bu", "ve", "için", "ile", "olan", "var", "yok",
        "mı", "mi", "mu", "mü", "ne", "nasıl", "neden", "nerede",
        "dosya", "klasör", "proje", "kod", "hata", "çalış",
        "bul", "ara", "yaz", "oku", "aç", "kapat", "sil",
        "bana", "benim", "şu", "bu", "onu", "onun",
    ]
    task_lower = task.lower()
    return any(f" {w} " in f" {task_lower} " for w in turkish_words)


def get_task_intent(task: str) -> str:
    """
    Determine high-level intent: 'read', 'write', or 'mixed'.
    Used by write protection and prompt adaptation.
    """
    task_type = classify_task(task)

    read_types = {"file_read", "search", "explain"}
    write_types = {"file_write"}

    if task_type in read_types:
        return "read"
    elif task_type in write_types:
        return "write"
    else:
        return "mixed"
