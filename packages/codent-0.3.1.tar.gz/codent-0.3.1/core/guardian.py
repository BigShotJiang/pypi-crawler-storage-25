# core/guardian.py
"""pDNA Guardian — felsefe koruma mekanizması.

Cont Hive'ın mimari felsefesine uyumu denetler.
İnsan müdahalesi olmadan çalışır, ihlal tespit ederse
düzelene kadar her oturum başında uyarı verir.

Çalıştırma: python3 core/guardian.py
"""

import json
import os
import re
import subprocess
from datetime import datetime
from pathlib import Path

import yaml

HIVE_DIR = Path(__file__).parent.parent / ".cont" / "hive"
WARNINGS_FILE = HIVE_DIR / "guardian_warnings.json"
RECIPES_DIR = HIVE_DIR / "recipes"
SOUL_PATH = Path.home() / ".config" / "cont" / "SOUL.md"
ADAPTIVE_PROMPT_PATH = Path(__file__).parent / "adaptive_prompt.py"


# ── Kontrol 1: System prompt şişkinliği ──

def check_system_prompt_bloat() -> tuple[bool, list[str]]:
    """System prompt'un satır sayısını ve talimat fiillerini kontrol et."""
    violations = []

    # SOUL.md satır kontrolü
    if SOUL_PATH.exists():
        lines = SOUL_PATH.read_text(encoding="utf-8").splitlines()
        if len(lines) > 50:
            violations.append(
                f"SOUL.md {len(lines)} satır (limit: 50). "
                "Fazla içeriği reçeteye veya topic file'a taşı."
            )

    # Adaptive prompt'ta hardcoded strateji kontrolü
    if ADAPTIVE_PROMPT_PATH.exists():
        content = ADAPTIVE_PROMPT_PATH.read_text(encoding="utf-8")
        # Harita cümlelerini hariç tut (dosya yolları)
        strategy_patterns = [
            r'(?<!#)\b(?:kullan|tercih et|yapma|her zaman|asla)\b',
        ]
        # Sadece string literal'larda (prompt text) ara, Python kodunda değil
        in_string = False
        string_lines = []
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith('"""') or stripped.startswith("'''"):
                in_string = not in_string
                continue
            if in_string:
                string_lines.append(line)

        strategy_hits = []
        for line in string_lines:
            for pat in strategy_patterns:
                if re.search(pat, line, re.IGNORECASE):
                    clean = line.strip()[:80]
                    # Harita referansları kabul edilir
                    if any(p in clean for p in [".cont/", "CONT.md", "CLAUDE.md",
                                                 "recipes/", "DISCIPLINE"]):
                        continue
                    strategy_hits.append(clean)

        if len(strategy_hits) > 5:
            violations.append(
                f"System prompt'ta {len(strategy_hits)} talimat fiili bulundu. "
                "Bunlar reçeteye taşınmalı. Örnekler:\n"
                + "\n".join(f"  - {h}" for h in strategy_hits[:3])
            )

    return len(violations) == 0, violations


# ── Kontrol 2: Budget doping ──

def check_budget_changes() -> tuple[bool, list[str]]:
    """Son commit'te budget değişikliği varsa yanında reçete olmalı."""
    violations = []

    try:
        diff = subprocess.run(
            ["git", "diff", "HEAD~1", "--", "core/tools.py"],
            capture_output=True, text=True, timeout=5,
            cwd=str(Path(__file__).parent.parent),
        ).stdout

        # Sadece eklenen/çıkarılan satırlara bak (context satırları hariç)
        changed_lines = [
            line for line in diff.splitlines()
            if line.startswith("+") or line.startswith("-")
        ]
        changed_text = "\n".join(changed_lines)
        budget_changed = any(
            p in changed_text for p in ["PER_TOOL_CAPS", "TOOL_LIMITS"]
        )

        if budget_changed:
            # Aynı commit'te reçete dosyası da değişmiş mi?
            recipe_diff = subprocess.run(
                ["git", "diff", "HEAD~1", "--name-only", "--", ".cont/hive/recipes/"],
                capture_output=True, text=True, timeout=5,
                cwd=str(Path(__file__).parent.parent),
            ).stdout.strip()

            if not recipe_diff:
                violations.append(
                    "Budget değişti ama alternatif strateji reçetesi yazılmadı. "
                    "Budget artırmak yerine modele reçete ile strateji öğret."
                )
    except Exception:
        pass  # git yoksa veya hata olursa atla

    return len(violations) == 0, violations


# ── Kontrol 3: Reçete kalitesi ──

def check_recipe_quality() -> tuple[bool, list[str]]:
    """Tüm reçetelerde felsefe kontrolü."""
    violations = []

    if not RECIPES_DIR.exists():
        return True, []

    for yaml_file in RECIPES_DIR.rglob("*.yaml"):
        try:
            data = yaml.safe_load(yaml_file.read_text(encoding="utf-8"))
            if not data or not isinstance(data, dict):
                continue

            name = data.get("name", yaml_file.stem)
            steps = data.get("steps", [])

            if not steps:
                continue

            # Trigger kontrolü
            if not data.get("trigger"):
                violations.append(f"Reçete '{name}': trigger alanı boş")

            # LLM oranı kontrolü (sadece composite/project, primitifler muaf)
            layer = data.get("layer", "primitive")
            if layer in ("composite", "project"):
                llm_count = sum(1 for s in steps if s.get("llm_required"))
                ratio = llm_count / len(steps) if steps else 0
                if ratio > 0.3:
                    violations.append(
                        f"Reçete '{name}': LLM oranı %{ratio*100:.0f} (limit: %30). "
                        "Deterministik adımlara böl."
                    )

        except Exception:
            continue

    # Doğrulama tiyatrosu: Seviye 0 verify oranı
    try:
        from core.verify_minions import verify_level_report
        report = verify_level_report()
        debt = report.get("debt_ratio", 0)
        if debt > 0.15:
            violations.append(
                f"Doğrulama tiyatrosu: Seviye 0 verify {debt*100:.0f}% (limit: %15). "
                "exit_code/not_empty → output_contains/output_matches'e güçlendir."
            )
    except Exception:
        pass

    return len(violations) == 0, violations


# ── Kontrol 4: Bilgi yerleşimi ──

def check_knowledge_location() -> tuple[bool, list[str]]:
    """System prompt kodunda göreve özgü bilgi var mı?"""
    violations = []

    if not ADAPTIVE_PROMPT_PATH.exists():
        return True, []

    content = ADAPTIVE_PROMPT_PATH.read_text(encoding="utf-8")

    # Kabul edilmez pattern'ler (strateji/taktik)
    bad_patterns = [
        (r'"grep kullan', "strateji cümlesi"),
        (r'"read_file yerine', "strateji cümlesi"),
        (r'BIGINT\b', "göreve özgü taktik"),
        (r'"test çalıştırmadan', "göreve özgü talimat"),
    ]

    for pat, desc in bad_patterns:
        if re.search(pat, content, re.IGNORECASE):
            violations.append(
                f"System prompt'ta {desc} bulundu: {pat}. "
                "Bu bilgi reçetede veya DISCIPLINE.md'de yaşamalı."
            )

    return len(violations) == 0, violations


# ── Kontrol 5: Recall bypass ──

def check_recall_bypass() -> tuple[bool, list[str]]:
    """Son logda reçete eşleşmesine rağmen model kendi yolunu mu denemiş?"""
    violations = []

    log_dir = Path(__file__).parent.parent / "logs" / "cont_runs"
    if not log_dir.exists():
        return True, []

    # En son log dosyasını bul
    logs = sorted(log_dir.glob("*.jsonl"), key=lambda f: f.name, reverse=True)
    if not logs:
        return True, []

    latest = logs[0]
    try:
        events = []
        for line in latest.read_text(encoding="utf-8").splitlines():
            try:
                events.append(json.loads(line))
            except Exception:
                continue

        # Hive hint enjekte edilmiş mi?
        hive_injected = any(
            "hive_recipe" in str(e.get("data", "")).lower()
            for e in events
        )

        if hive_injected:
            # Model reçetedeki stratejiyi mi izledi?
            # Basit heuristic: ilk tool call run_shell+grep ise → izledi
            tool_calls = [
                e for e in events if e.get("type") == "tool_call"
            ]
            if tool_calls:
                first_tool = tool_calls[0].get("data", {}).get("name", "")
                # Eğer ilk tool read_file ise ve reçete grep öneriyorsa → bypass
                if first_tool == "read_file" and len(tool_calls) > 3:
                    final = [e for e in events if e.get("type") == "final"]
                    if final and not final[0].get("data", {}).get("success"):
                        violations.append(
                            "Eşleşen reçete vardı ama model reçetedeki stratejiyi "
                            "kullanmadı (read_file ile başladı). Görev başarısız oldu."
                        )
    except Exception:
        pass

    return len(violations) == 0, violations


# ══════════════════════════════════════════════════════════
# KOD YAPISI KONTROLLERI (6-10) — sadece --full modunda
# ══════════════════════════════════════════════════════════

CORE_DIR = Path(__file__).parent
PROJECT_ROOT = CORE_DIR.parent


def check_monolithic_llm_calls() -> tuple[bool, list[str]]:
    """Tek fonksiyonda büyük LLM çağrıları var mı?"""
    violations = []

    llm_call_patterns = re.compile(
        r"(chat\.completions\.create|llm_complete|_llm_complete_chat)"
    )

    for py_file in CORE_DIR.glob("*.py"):
        if py_file.name.startswith("test"):
            continue
        try:
            content = py_file.read_text(encoding="utf-8")
            lines = content.splitlines()

            # Fonksiyon sınırlarını ve LLM çağrılarını bul
            current_fn = None
            fn_start = 0
            for i, line in enumerate(lines):
                if re.match(r"^def \w+", line):
                    # Önceki fonksiyonu kontrol et
                    # init/setup/config fonksiyonları muaf (yapılandırma, LLM çağrısı değil)
                    init_names = {"init_", "setup_", "ensure_", "configure_", "_build_ctx"}
                    is_init = current_fn and any(current_fn.startswith(p) or current_fn in init_names for p in init_names)
                    if current_fn and (i - fn_start) > 80 and not is_init:
                        fn_body = "\n".join(lines[fn_start:i])
                        if llm_call_patterns.search(fn_body):
                            violations.append(
                                f"Monolitik LLM çağrısı: {py_file.name}:{fn_start+1} "
                                f"def {current_fn} ({i - fn_start} satır) — parçala"
                            )
                    current_fn = line.split("(")[0].replace("def ", "").strip()
                    fn_start = i
        except Exception:
            continue

    return len(violations) == 0, violations


def check_llm_doing_deterministic_work() -> tuple[bool, list[str]]:
    """LLM prompt şablonlarında deterministik araçlarla yapılabilecek iş var mı?"""
    violations = []

    deterministic_patterns = {
        "listele": "grep / find / ls",
        "say ": "wc -l",
        "karşılaştır": "diff",
        "dosyada ara": "grep",
    }

    for py_file in CORE_DIR.glob("*.py"):
        if py_file.name.startswith("test"):
            continue
        try:
            content = py_file.read_text(encoding="utf-8")
            # Sadece string literal'larda ara (prompt text)
            for match in re.finditer(r'"""(.*?)"""', content, re.DOTALL):
                text = match.group(1)
                for pattern, alt in deterministic_patterns.items():
                    if pattern in text.lower() and "llm" not in text.lower()[:50]:
                        # Prompt template'lerde beklenir, sadece aşırı kullanımı işaretle
                        pass  # Şimdilik pasif — false positive çok olabilir
        except Exception:
            continue

    return len(violations) == 0, violations


def check_hive_bypass() -> tuple[bool, list[str]]:
    """Son commit'te eklenen tool fonksiyonlarının reçetesi var mı?"""
    violations = []

    try:
        diff = subprocess.run(
            ["git", "diff", "HEAD~1", "--", "core/tools.py"],
            capture_output=True, text=True, timeout=5,
            cwd=str(PROJECT_ROOT),
        ).stdout

        # Yeni eklenen public fonksiyonlar
        new_fns = re.findall(r"^\+def ([a-z]\w+)\(", diff, re.MULTILINE)
        if not new_fns:
            return True, []

        # Reçete trigger'larını topla
        all_triggers = ""
        if RECIPES_DIR.exists():
            for f in RECIPES_DIR.rglob("*.yaml"):
                try:
                    data = yaml.safe_load(f.read_text(encoding="utf-8"))
                    all_triggers += " " + (data.get("trigger", "") if data else "")
                except Exception:
                    continue

        for fn in new_fns:
            # snake_case'i boşluklara çevir
            fn_words = fn.replace("_", " ")
            if fn_words not in all_triggers.lower() and fn not in all_triggers.lower():
                violations.append(
                    f"Yeni fonksiyon '{fn}' eklendi ama eşleşen reçete yok"
                )
    except Exception:
        pass

    return len(violations) == 0, violations


def check_hardcoded_knowledge() -> tuple[bool, list[str]]:
    """Kaynak kodda reçetede olması gereken hardcoded bilgi var mı?"""
    violations = []

    # Proje-spesifik terimler (config/hive yolları hariç)
    # NOT: "kosgeb" gibi alan adları Cont'un doğal bağlamı, ihlal değil.
    # Burada sadece başka projeden sızan hardcoded bilgi aranır.
    bad_terms = {
        "BIGINT": "proje-spesifik tip",
    }

    # Config yolları kabul edilir
    safe_contexts = [".cont/", "~/.config/cont/", "hive/", "recipes/",
                     "DISCIPLINE", "GENESIS", "SOUL", "test", "# "]

    # Guardian kendi dosyası ve schema tanımları muaf
    skip_files = {"guardian.py", "tool_schemas.py", "test_golden.py", "rpc.py",
                  "curriculum_runner.py", "overnight_training.py", "benchmark.py",
                  "yis_deep_training.py", "overfit_test.py", "quick_overfit_test.py",
                  "feedback_training.py", "advanced_overnight.py", "cc_auditor.py"}
    for py_file in list(CORE_DIR.glob("*.py")) + [PROJECT_ROOT / "cont.py"]:
        if py_file.name in skip_files or "test" in py_file.name:
            continue
        try:
            for i, line in enumerate(py_file.read_text(encoding="utf-8").splitlines(), 1):
                if any(ctx in line for ctx in safe_contexts):
                    continue
                # Sadece string literal'larda ara
                if '"' not in line and "'" not in line:
                    continue
                for term, desc in bad_terms.items():
                    if term.lower() in line.lower():
                        violations.append(
                            f"Hardcoded bilgi: {py_file.name}:{i} — "
                            f"'{term}' ({desc}), reçeteye taşı"
                        )
        except Exception:
            continue

    return len(violations) == 0, violations


def check_inbox_overflow() -> tuple[bool, list[str]]:
    """Inbox'ta 20+ ham reçete birikmiş mi?"""
    violations = []
    inbox = HIVE_DIR / "inbox"
    if inbox.exists():
        count = len(list(inbox.glob("*.yaml")))
        if count >= 20:
            violations.append(
                f"Inbox'ta {count} ham reçete birikmiş — gözden geçirme zamanı. "
                "Çalıştır: cont --review-inbox"
            )
    return len(violations) == 0, violations


def check_unverified_tool_calls() -> tuple[bool, list[str]]:
    """Tool çağrısı sonrası doğrulama eksik mi? (heuristic)"""
    violations = []

    # Runtime'da tool sonucu kullanılıp doğrulanmayan noktaları bul
    runtime_path = CORE_DIR / "runtime.py"
    if not runtime_path.exists():
        return True, []

    try:
        content = runtime_path.read_text(encoding="utf-8")
        # Tool result'ın mesaja eklendiği noktaları bul
        result_adds = re.findall(
            r"messages\.append\(\{.*?tool_call_id.*?\}\)", content
        )
        # Bu basit heuristic — gerçek doğrulama kodu zaten var
        # Sadece yeni eklenen tool entegrasyonlarını kontrol et
    except Exception:
        pass

    return len(violations) == 0, violations


def check_knowledge_bypass() -> tuple[bool, list[str]]:
    """Python dosyalarında knowledge'a taşınması gereken hardcoded string koleksiyonları var mı?

    5+ elemanlı string set/list/dict literal → muhtemelen knowledge dosyasında olmalı.

    Muaf kategoriler:
    - Import listeleri, config key'leri, test fixture'ları, ≤4 elemanlı sabitler
    - Güvenlik/altyapı sabitleri (FORBIDDEN, SAFE_, DANGEROUS_, LEAK_, HALLUCIN*, vb.)
    - Locale/format sabitleri (_AY, _GUN)
    - NLP stopword listeleri (model-bağımsız dilbilgisi)
    - REPL interaction pattern'leri (_FOLLOWUP_, _RETRY_, _CONTINUE_)
    - _load_ ile bilgi dosyasından yüklenenler

    Hedef: Görev yönlendirme / sınıflandırma bilgisini (task verbs, intent triggers,
    task types, decompose patterns) knowledge'a taşımak.
    """
    violations = []

    # Taranan dosyalar
    scan_files = list(CORE_DIR.glob("*.py")) + [PROJECT_ROOT / "cont.py"]

    # Muaf dosyalar
    skip_files = {"guardian.py", "tool_schemas.py", "test_golden.py",
                  "safety.py", "sql_guard.py"}

    # Muaf değişken adı pattern'leri — altyapı/güvenlik sabitleri
    safe_var_re = re.compile(
        r"^(?:"
        r"FORBIDDEN|SAFE_|DANGEROUS_|DESTRUCTIVE_|EXEMPT_|FINALIZE_|TIER_|ALLOWED_"  # güvenlik
        r"|LEAK_|HALLUCIN|CLAIM_|DENIAL_|_BLOCKED_|_UNSAFE_"                          # güvenlik/doğrulama
        r"|_GATEWAY_|NOISE_"                                                           # altyapı
        r"|_AY$|_GUN$|_MONTHS|_DAYS"                                                   # locale
        r"|_FOLLOWUP_|_RETRY_|_CONTINUE_"                                              # REPL
        r"|_STOPWORD|_STOP_WORD|stopword"                                              # NLP stopword
        r"|hint_parts|rebuilt"                                                          # scratchpad/format
        r")", re.IGNORECASE
    )

    # Baseline: bilinen mevcut ihlaller (yeni eklenen yakalanır, mevcut tolere edilir)
    baseline_path = HIVE_DIR / "knowledge_bypass_baseline.json"
    baseline_keys: set = set()
    if baseline_path.exists():
        try:
            baseline_keys = set(json.loads(baseline_path.read_text(encoding="utf-8")))
        except Exception:
            pass

    # Suspect değişken adı pattern'leri — yüksek olasılıkla externalize edilmeli
    suspect_var_re = re.compile(
        r"(?:TASK_VERBS|TASK_TYPES|ACTION_VERBS|OPEN_VERBS|WRITE_TRIGGERS|READ_TRIGGERS"
        r"|INTENT_KEYWORDS|INTENT_PATTERNS|DECOMPOSE_PATTERNS|TASK_PATTERNS"
        r"|STRONG_SIGNALS|ROOT_CAUSES|FAILURE_PATTERNS|SKIP_PATTERNS"
        r"|TOOL_NAME_ALIASES|DIR_LIST_BLOCKERS|DIR_KEYWORDS|FILE_CONTEXT_PATTERNS"
        r"|BROWSER_INTENT)",
        re.IGNORECASE,
    )

    for py_file in scan_files:
        if not py_file.exists():
            continue
        if py_file.name in skip_files or "test" in py_file.name:
            continue

        try:
            content = py_file.read_text(encoding="utf-8")
            lines = content.splitlines()
        except Exception:
            continue

        i = 0
        while i < len(lines):
            line = lines[i]
            stripped = line.strip()

            # Yorum veya boş satır → atla
            if not stripped or stripped.startswith("#"):
                i += 1
                continue

            # Değişken ataması bul: VAR = { veya VAR = [
            m = re.match(r"^(\s*)(\w+)\s*=\s*([\{\[])", stripped)
            if not m:
                i += 1
                continue

            var_name = m.group(2)
            opener = m.group(3)
            closer = "}" if opener == "{" else "]"

            # Altyapı/güvenlik muafiyeti
            if safe_var_re.search(var_name):
                i += 1
                continue

            # _load_ veya yaml ile yüklenen satırları atla
            if "_load_" in stripped or "yaml" in stripped.lower():
                i += 1
                continue

            # Çok satırlı literal'ı topla
            depth = 0
            start_line = i
            collected = []
            while i < len(lines):
                for ch in lines[i]:
                    if ch == opener:
                        depth += 1
                    elif ch == closer:
                        depth -= 1
                collected.append(lines[i])
                i += 1
                if depth <= 0:
                    break

            full_literal = "\n".join(collected)

            # String elemanlarını say
            string_elements = re.findall(r"""['\"]([^'\"]{2,})['\"]""", full_literal)

            # ≤4 eleman → küçük sabit, kabul
            if len(string_elements) <= 4:
                continue

            # Import listesi kontrolü
            if "import" in var_name.lower() or any(kw in full_literal for kw in ["import ", "from "]):
                continue

            # Dict ise ve value'ları callable/fonksiyon referansı → dispatcher, muaf
            if opener == "{" and re.search(r":\s*[a-zA-Z_]\w*\s*[,\}]", full_literal):
                # Tüm value'lar string DEĞİLSE → dispatcher
                values = re.findall(r":\s*(.+?)(?:,|\n|\})", full_literal)
                non_string_vals = sum(1 for v in values if not re.match(r"""\s*['\"]""", v))
                if non_string_vals > len(values) * 0.5:
                    continue

            # Suspect adı varsa → kesin ihlal (eleman sayısı yeterli)
            is_suspect = bool(suspect_var_re.search(var_name))

            rel_path = py_file.relative_to(PROJECT_ROOT) if py_file.is_relative_to(PROJECT_ROOT) else py_file.name

            if is_suspect:
                # Baseline key: dosya:değişken (satır numarası hariç, refactoring toleransı)
                bkey = f"{rel_path}:{var_name}"
                if bkey not in baseline_keys:
                    violations.append(
                        f"Knowledge bypass: {rel_path}:{start_line+1} — "
                        f"{var_name} ({len(string_elements)} string) "
                        f"knowledge dosyasına taşınmalı"
                    )

    return len(violations) == 0, violations


def check_recipe_fitness() -> tuple[bool, list[str]]:
    """Fitness < 0.5 olan reçeteler var mı? Tekrarlayan hatalar var mı?"""
    violations = []

    try:
        from core.fitness import all_fitness
        results = all_fitness()
        broken = [r for r in results if 0 < r["fitness"] < 0.5]
        if broken:
            names = ", ".join(r["name"] for r in broken[:5])
            violations.append(
                f"{len(broken)} reçete fitness < 0.5: {names}. "
                "Düzelt veya buharlaştır."
            )
    except Exception:
        pass

    # Tekrarlayan hata: trail'de aynı reçetenin 3+ ardışık fail'i
    trail_path = HIVE_DIR / "pheromone" / "trail.jsonl"
    if trail_path.exists():
        try:
            from collections import defaultdict
            consecutive = defaultdict(int)
            max_consecutive = defaultdict(int)
            for line in trail_path.read_text(encoding="utf-8").splitlines()[-200:]:
                try:
                    e = json.loads(line)
                    recipe = e.get("recipe_id", e.get("recipe", ""))
                    if not recipe:
                        continue
                    status = e.get("status", e.get("result", ""))
                    if status in ("fail", "failure", "error"):
                        consecutive[recipe] += 1
                        max_consecutive[recipe] = max(max_consecutive[recipe], consecutive[recipe])
                    else:
                        consecutive[recipe] = 0
                except Exception:
                    continue

            broken_recipes = {r: c for r, c in max_consecutive.items() if c >= 3}
            if broken_recipes:
                names = ", ".join(f"{r}({c}x)" for r, c in list(broken_recipes.items())[:3])
                violations.append(
                    f"Tekrarlayan hata: {names} — self_heal veya düzeltme gerekli"
                )
        except Exception:
            pass

    return len(violations) == 0, violations


def check_pheromone_anomaly() -> tuple[bool, list[str]]:
    """Feromon trail'de ani fail artışı var mı?"""
    violations = []

    trail_path = HIVE_DIR / "pheromone" / "trail.jsonl"
    if not trail_path.exists():
        return True, []

    try:
        from collections import Counter

        recent_fails = Counter()   # son 100 event'teki fail'ler
        older_fails = Counter()    # önceki 100 event'teki fail'ler

        lines = trail_path.read_text(encoding="utf-8").splitlines()
        recent_lines = lines[-100:] if len(lines) >= 100 else lines
        older_lines = lines[-200:-100] if len(lines) >= 200 else []

        for line in recent_lines:
            try:
                e = json.loads(line)
                if e.get("status", e.get("result", "")) in ("fail", "failure", "error"):
                    recipe = e.get("recipe_id", e.get("recipe", "unknown"))
                    recent_fails[recipe] += 1
            except Exception:
                continue

        for line in older_lines:
            try:
                e = json.loads(line)
                if e.get("status", e.get("result", "")) in ("fail", "failure", "error"):
                    recipe = e.get("recipe_id", e.get("recipe", "unknown"))
                    older_fails[recipe] += 1
            except Exception:
                continue

        # Anomali: son pencerede fail sayısı öncekinin 3x'inden fazla
        total_recent = sum(recent_fails.values())
        total_older = sum(older_fails.values())
        if total_older > 0 and total_recent > total_older * 3:
            violations.append(
                f"Feromon anomali: fail artışı {total_older}→{total_recent} (3x+). "
                "Sistematik sorun olabilir."
            )

        # Tek reçetede ani artış
        for recipe in recent_fails:
            r = recent_fails[recipe]
            o = older_fails.get(recipe, 0)
            if o > 0 and r > o * 3 and r >= 3:
                violations.append(
                    f"Feromon anomali: {recipe} fail artışı {o}→{r}. "
                    "Reçete bozulmuş olabilir."
                )

    except Exception:
        pass

    return len(violations) == 0, violations


def check_code_pollution() -> tuple[bool, list[str]]:
    """Kaynak kodda knowledge'a taşınması gereken hardcoded zeka pattern'leri var mı?

    Muaf: güvenlik pattern'leri, altyapı sabitleri, config değerleri.
    Hedef: model davranışını belirleyen strateji/zeka listeleri.
    """
    violations = []

    # Sadece bu dosyalardaki bu isimler kontrol edilir (false positive önleme)
    # Altyapı pattern'leri (DANGEROUS_PATTERNS, SAFE_READ_COMMANDS vb) muaf
    WATCH_LIST = {
        "postprocess.py": ["DENIAL_PATTERNS"],
        "adaptive_prompt.py": ["INTELLIGENCE_SIGNALS"],
    }

    for py_name, pattern_names in WATCH_LIST.items():
        py_file = CORE_DIR / py_name
        if not py_file.exists():
            continue
        content = py_file.read_text(encoding="utf-8")
        for pname in pattern_names:
            if pname in content and "_load_" not in content:
                violations.append(
                    f"Hardcoded zeka pattern: {py_name}:{pname} — "
                    ".cont/hive/knowledge/'a taşı veya _load_ ile yükle"
                )

    return len(violations) == 0, violations


# ── Kontrol 14: Feedback döngüsü sağlığı ──

def check_feedback_health() -> tuple[bool, list[str]]:
    """Feedback döngüsü çalışıyor mu? Trail recipe_id, YAML güncelleme, fitness."""
    violations = []

    # a) Trail'de recipe_id var mı (son 1000 satır)
    trail_path = HIVE_DIR / "pheromone" / "trail.jsonl"
    if trail_path.exists():
        recipe_id_count = 0
        for line in trail_path.read_text(encoding="utf-8").splitlines()[-1000:]:
            try:
                e = json.loads(line)
                if e.get("recipe_id"):
                    recipe_id_count += 1
            except Exception:
                continue
        if recipe_id_count == 0:
            violations.append(
                "Feedback döngüsü kopuk: trail'de recipe_id olan satır yok. "
                "recipe_feedback.py çalışıyor mu?"
            )

    # b) YAML güncelleme oranı
    total_recipes = 0
    updated_recipes = 0
    if RECIPES_DIR.exists():
        for f in RECIPES_DIR.rglob("*.yaml"):
            try:
                d = yaml.safe_load(f.read_text(encoding="utf-8"))
                if not d or not isinstance(d, dict):
                    continue
                total_recipes += 1
                sc = d.get("success_count", 0)
                fc = d.get("fail_count", 0)
                if (sc + fc) > 0:
                    updated_recipes += 1
            except Exception:
                continue

    if total_recipes > 0:
        update_ratio = updated_recipes / total_recipes
        if update_ratio < 0.20:
            violations.append(
                f"Reçetelerin {100-update_ratio*100:.0f}%'ı hiç çalıştırılmamış "
                f"({updated_recipes}/{total_recipes}). Recall eşleşme veya "
                "feedback kaydı eksik olabilir."
            )

    # c) Buharlaşma aday bilgisi (alarm değil, info)
    try:
        from core.fitness import evaporation_candidates
        evap = evaporation_candidates()
        if evap:
            # Sadece bilgi, ihlal değil — debug log
            pass
    except Exception:
        pass

    return len(violations) == 0, violations


# ── Kontrol 15: Evrimsel döngü sağlığı ──

def check_evolution_health() -> tuple[bool, list[str]]:
    """Reçete üretimi, trigger genişletme, genel başarı oranı."""
    violations = []

    # a) Son 10 commit'te yeni reçete yazıldı mı?
    try:
        diff = subprocess.run(
            ["git", "log", "--oneline", "-10", "--name-only", "--diff-filter=A",
             "--", ".cont/hive/recipes/"],
            capture_output=True, text=True, timeout=5,
            cwd=str(PROJECT_ROOT),
        ).stdout
        new_recipes = [l for l in diff.splitlines() if l.endswith(".yaml")]
        if not new_recipes:
            violations.append(
                "Son 10 commit'te yeni reçete yazılmamış. "
                "recipe_learner çalışıyor mu?"
            )
    except Exception:
        pass

    # b) Inbox boyutu
    inbox = HIVE_DIR / "inbox"
    if inbox.exists():
        count = len(list(inbox.glob("*.yaml")))
        if count >= 30:
            violations.append(
                f"Inbox'ta {count} ham reçete birikmiş — "
                "modülerleştirme gerekli"
            )

    # c) Genel başarı oranı
    total_success = 0
    total_fail = 0
    if RECIPES_DIR.exists():
        for f in RECIPES_DIR.rglob("*.yaml"):
            try:
                d = yaml.safe_load(f.read_text(encoding="utf-8"))
                if not d or not isinstance(d, dict):
                    continue
                total_success += d.get("success_count", 0)
                total_fail += d.get("fail_count", 0)
            except Exception:
                continue

    total_runs = total_success + total_fail
    if total_runs >= 10:
        success_rate = total_success / total_runs
        if success_rate < 0.50:
            violations.append(
                f"Reçete başarı oranı {success_rate*100:.0f}% "
                f"({total_success}/{total_runs}) — "
                "yarısından fazlası başarısız"
            )

    return len(violations) == 0, violations


# ── Kontrol 16: Hook override takibi ──

def check_hook_overrides() -> tuple[bool, list[str]]:
    """Son dönemde hook uyarıları kaç kez override edilmiş?"""
    violations = []
    override_dir = HIVE_DIR / "runs" / "hook_overrides"
    if not override_dir.exists():
        return True, []

    overrides = sorted(override_dir.glob("*.json"), reverse=True)
    recent = overrides[:20]  # son 20

    if len(recent) >= 3:
        files = set()
        for f in recent:
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
                files.add(d.get("file", "?"))
            except Exception:
                continue
        violations.append(
            f"Hook uyarıları override ediliyor: son {len(recent)} uyarı, "
            f"dosyalar: {', '.join(list(files)[:3])}. "
            "Koda talimat gömmek yerine knowledge/recipe kullan."
        )

    return len(violations) == 0, violations


# ── Kontrol 17: Activation map sağlığı ──

def check_activation_map() -> tuple[bool, list[str]]:
    """activation_map.yaml var mı, ölü referans var mı, summary eksik mi?"""
    violations = []

    try:
        from core.spreading_activation import get_activation_stats
        stats = get_activation_stats()

        # Ölü referanslar
        if stats["dead_refs"]:
            violations.append(
                f"Ölü referans: {stats['dead_refs']} — activation_map'te var ama dosya yok"
            )

        # Summary eksik (>%50)
        if stats["total_files"] > 0:
            missing_pct = len(stats["missing_summary"]) / stats["total_files"]
            if missing_pct > 0.50:
                violations.append(
                    f"Knowledge dosyalarının %{missing_pct*100:.0f}'ında summary yok: "
                    f"{stats['missing_summary'][:3]}"
                )

        # Erişilemeyen knowledge (info, ihlal değil ama logla)
        # Not: bu altyapı dosyaları olabilir, ihlal yapma
    except ImportError:
        violations.append("spreading_activation modülü import edilemiyor")
    except Exception as e:
        violations.append(f"Activation map kontrol hatası: {e}")

    return len(violations) == 0, violations


# ── Kontrol 18: Recipe-activation uyumu ──

def check_recipe_activation_coverage() -> tuple[bool, list[str]]:
    """Reçeteler çalışırken ilgili knowledge canlanıyor mu?"""
    violations = []

    # Trail'den kontrol: recipe_id + activation birlikte mi?
    trail = HIVE_DIR / "pheromone" / "trail.jsonl"
    if trail.exists():
        recipe_runs = 0
        recipe_with_activation = 0
        for line in trail.read_text(encoding="utf-8").splitlines()[-100:]:
            try:
                e = json.loads(line)
                if e.get("recipe_id"):
                    recipe_runs += 1
                    # Bu da activation trace'de mi?
                    # Basit kontrol: recipe_id olan run'larda tool kullanılmış mı
                    if e.get("tool_count", 0) > 0:
                        recipe_with_activation += 1
            except Exception:
                continue

    return len(violations) == 0, violations


# ── Kontrol 19: Activation öz-büyüme sağlığı ──

def check_activation_growth() -> tuple[bool, list[str]]:
    """auto_learned büyüyor mu, gap'ler loglanıyor mu?"""
    violations = []

    map_path = HIVE_DIR / "knowledge" / "activation_map.yaml"
    if map_path.exists():
        try:
            data = yaml.safe_load(map_path.read_text(encoding="utf-8"))
            auto = data.get("auto_learned", {})
            if isinstance(auto, dict) and len(auto) > 50:
                violations.append(
                    f"auto_learned'da {len(auto)} keyword — gürültü riski. "
                    "Cleanup çalışıyor mu?"
                )
        except Exception:
            pass

    return len(violations) == 0, violations


# ── Kontrol 20: SQL guard sağlığı ──

def check_sql_guard() -> tuple[bool, list[str]]:
    """SQL guard modülü var mı, güvenlik kontrolleri aktif mi?"""
    violations = []
    sql_guard = CORE_DIR / "sql_guard.py"
    if not sql_guard.exists():
        violations.append("sql_guard.py bulunamadı — SQL güvenlik katmanı eksik")
    else:
        content = sql_guard.read_text(encoding="utf-8")
        if "DROP" not in content and "DELETE" not in content:
            violations.append("sql_guard.py'de DROP/DELETE koruması bulunamadı")
        if "read_only" not in content.lower():
            violations.append("sql_guard.py'de read_only kontrolü yok")
    return len(violations) == 0, violations


# ── Kontrol 21: Daemon sağlığı ──

def check_daemon_health() -> tuple[bool, list[str]]:
    """Daemon çalışıyor mu, son heartbeat ne zaman?"""
    violations = []
    import os
    state_file = Path.home() / ".config" / "cont" / "daemon_state.json"
    pid_file = Path.home() / ".config" / "cont" / "daemon.pid"

    if pid_file.exists():
        try:
            pid = int(pid_file.read_text().strip())
            # Process hâlâ yaşıyor mu?
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                violations.append(
                    f"Daemon PID {pid} ölü — stale PID dosyası. "
                    "cont --daemon-start ile yeniden başlat."
                )
        except Exception:
            pass
    # PID yoksa uyarma — daemon opsiyonel

    return len(violations) == 0, violations


# ── Kontrol 22: Bütçe yönetimi sağlığı ──

def check_budget_management() -> tuple[bool, list[str]]:
    """Bütçe kurulu modülü var mı, trail'e karar loglanıyor mu?"""
    violations = []
    bc_path = CORE_DIR / "budget_committee.py"
    if not bc_path.exists():
        violations.append("budget_committee.py bulunamadı — bütçe yönetimi eksik")
    else:
        content = bc_path.read_text(encoding="utf-8")
        for decision in ["APPROVE", "DECOMPOSE", "REDIRECT", "LEARN"]:
            if decision not in content:
                violations.append(f"Bütçe kararı '{decision}' budget_committee.py'de yok")
    return len(violations) == 0, violations


# ── Kontrol 23: Öğrenme döngüsü sağlığı ──

def check_learning_loop() -> tuple[bool, list[str]]:
    """Öğrenme döngüsü modülü var mı?"""
    violations = []
    ll_path = CORE_DIR / "learning_loop.py"
    if not ll_path.exists():
        violations.append("learning_loop.py bulunamadı — öğrenme döngüsü eksik")
    else:
        content = ll_path.read_text(encoding="utf-8")
        for step in ["analyze_failure", "find_knowledge_gap", "acquire_knowledge", "create_recipe"]:
            if step not in content:
                violations.append(f"Öğrenme adımı '{step}' learning_loop.py'de yok")
    return len(violations) == 0, violations


# ── Kontrol 24: Recipe factory uyumu ──

def check_recipe_factory() -> tuple[bool, list[str]]:
    """recipe_factory.py var mı, temel fonksiyonlar mevcut mu?"""
    violations = []
    rf_path = CORE_DIR / "recipe_factory.py"
    if not rf_path.exists():
        violations.append("recipe_factory.py bulunamadı")
    else:
        content = rf_path.read_text(encoding="utf-8")
        for fn in ["_validate", "_normalize", "_dedup_check", "_quality_check"]:
            if fn not in content:
                violations.append(f"recipe_factory.py'de {fn} eksik")
    return len(violations) == 0, violations


# ── Kontrol 25: CC audit sağlığı ──

def check_cc_audit() -> tuple[bool, list[str]]:
    """Son audit sonuçları, CC güvenilirlik oranı."""
    violations = []
    audit_log = HIVE_DIR / "runs" / "cc_audits.jsonl"

    if not audit_log.exists():
        return True, []  # Henüz audit yok, ihlal değil

    try:
        lines = audit_log.read_text(encoding="utf-8").splitlines()
        recent = lines[-10:]
        if len(recent) < 3:
            return True, []

        passed = 0
        for line in recent:
            try:
                d = json.loads(line)
                if d.get("all_passed"):
                    passed += 1
            except Exception:
                continue

        rate = passed / len(recent)
        if rate < 0.5:
            violations.append(
                f"CC audit güvenilirlik düşük: {passed}/{len(recent)} (%{rate*100:.0f})"
            )
    except Exception:
        pass

    return len(violations) == 0, violations


# ── Kontrol 26: Ağ güvenliği ──

def check_network_safety() -> tuple[bool, list[str]]:
    """Banka ortamı için ağ güvenliği — yasak modül, offline destek."""
    violations = []
    try:
        from core.network_audit import audit_report
        r = audit_report()

        # CONT_OFFLINE desteği
        if not r["offline_supported"]:
            violations.append("CONT_OFFLINE flag desteği yok — banka modu eksik")

        # Yasak modüller koşullu mu?
        if r["forbidden_imports"] > 0:
            modules = r.get("forbidden_modules", [])
            # Koşullu (try/except) ise sorun yok — kontrol et
            for mod in modules:
                # memory_store gibi koşullu importlar exempt
                if mod == "sentence_transformers":
                    continue  # try/except içinde, kontrol edildi
                violations.append(f"Yasak modül: {mod}")

    except ImportError:
        violations.append("network_audit modülü import edilemiyor")
    except Exception as e:
        violations.append(f"Network audit hatası: {e}")

    return len(violations) == 0, violations


# ── Kontrol 27: Halüsinasyon guard ──

def check_hallucination_guard() -> tuple[bool, list[str]]:
    """Tablo/kolon iddiası yapan görevlerde SQL çalıştırılmış mı?

    Trail'in son N entry'sinde:
    - Görev "tablo yapısı", "kolon listesi", "kaç satır" iddiası içeriyorsa
    - VE tool_count == 0 veya hiç DESCRIBE/SELECT/PRAGMA yoksa
    → HALÜSİNASYON
    """
    violations = []
    trail_path = HIVE_DIR / "pheromone" / "trail.jsonl"
    if not trail_path.exists():
        return True, []

    SCHEMA_KEYWORDS = {"tablo", "kolon", "kolonları", "yapı", "şema", "schema",
                       "describe", "kaç satır", "satır sayısı", "column", "table"}
    SQL_INDICATORS = {"describe", "select", "pragma", "show columns",
                      "information_schema", "information_schema.columns"}

    suspicious = []
    try:
        lines = trail_path.read_text(encoding="utf-8").splitlines()[-50:]
        for line in lines:
            try:
                e = json.loads(line)
                task = (e.get("task") or "").lower()
                if not task:
                    continue
                tools = e.get("tools", [])
                tool_count = e.get("tool_count", 0)
                success = e.get("success", False)

                # Tablo/şema iddiası var mı?
                has_schema_claim = any(kw in task for kw in SCHEMA_KEYWORDS)
                if not has_schema_claim:
                    continue

                # SQL araç kullanımı var mı?
                tools_str = " ".join(str(t).lower() for t in (tools if isinstance(tools, list) else []))
                has_sql_tool = "run_shell" in tools_str or "sql" in tools_str

                # Halüsinasyon: schema iddiası + tool yok + başarılı görünüyor
                if success and tool_count == 0 and has_schema_claim:
                    suspicious.append(task[:60])
            except Exception:
                continue
    except Exception:
        pass

    if len(suspicious) >= 2:
        violations.append(
            f"Halüsinasyon riski: {len(suspicious)} görev SQL çalıştırmadan "
            f"tablo/kolon iddiası içerdi. Örnek: {suspicious[0]}"
        )

    return len(violations) == 0, violations


# ── Guardian raporu ──

class GuardianReport:
    def __init__(self):
        self.results: dict[str, dict] = {}

    def add_pass(self, check_name: str):
        self.results[check_name] = {"passed": True, "violations": []}

    def add_violation(self, check_name: str, message: str):
        if check_name not in self.results:
            self.results[check_name] = {"passed": False, "violations": []}
        self.results[check_name]["passed"] = False
        self.results[check_name]["violations"].append(message)

    def has_violations(self) -> bool:
        return any(not r["passed"] for r in self.results.values())

    def all_violations(self) -> list[tuple[str, str]]:
        out = []
        for name, r in self.results.items():
            for v in r["violations"]:
                out.append((name, v))
        return out


def write_warnings(report: GuardianReport):
    """Persistent uyarıları dosyaya yaz."""
    existing = load_warnings()
    existing_msgs = {w["message"] for w in existing if not w.get("resolved")}

    now = datetime.now().isoformat()

    for check_name, msg in report.all_violations():
        if msg not in existing_msgs:
            existing.append({
                "check": check_name,
                "message": msg,
                "fix": _suggest_fix(check_name),
                "first_seen": now,
                "resolved": False,
            })

    _save_warnings(existing, now)


def clear_warnings():
    """Tüm uyarıları çözülmüş olarak işaretle."""
    warnings = load_warnings()
    for w in warnings:
        w["resolved"] = True
    _save_warnings(warnings, datetime.now().isoformat())


def load_warnings() -> list[dict]:
    """Mevcut uyarıları oku."""
    if not WARNINGS_FILE.exists():
        return []
    try:
        data = json.loads(WARNINGS_FILE.read_text(encoding="utf-8"))
        return data.get("violations", [])
    except Exception:
        return []


def _save_warnings(violations: list[dict], timestamp: str):
    """Uyarıları dosyaya kaydet."""
    WARNINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "last_check": timestamp,
        "violations": violations,
    }
    WARNINGS_FILE.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def _suggest_fix(check_name: str) -> str:
    """İhlal türüne göre çözüm önerisi."""
    fixes = {
        "system_prompt_bloat": "Fazla satırları reçeteye veya topic file'a taşı",
        "budget_doping": "Budget artırmak yerine alternatif strateji reçetesi yaz",
        "recipe_quality": "Deterministik adımlara böl, verify ekle",
        "knowledge_location": "Bilgiyi reçeteye veya DISCIPLINE.md'ye taşı",
        "recall_bypass": "Model eğitimini güçlendir veya reçeteyi iyileştir",
        "monolithic_llm": "Fonksiyonu küçük parçalara böl, her parça tek iş yapsın",
        "llm_deterministic": "LLM yerine grep/diff/wc gibi deterministik araç kullan",
        "hive_bypass": "Yeni fonksiyon için eşleşen reçete yaz",
        "hardcoded_knowledge": "Proje-spesifik bilgiyi reçeteye veya config'e taşı",
        "unverified_tool": "Tool sonucuna exit_code/None/format doğrulaması ekle",
        "inbox_overflow": "Inbox'u gözden geçir: cont --review-inbox",
        "code_pollution": "Hardcoded listeyi .cont/hive/knowledge/'a taşı",
        "knowledge_bypass": "5+ elemanlı string koleksiyonunu .cont/hive/knowledge/ YAML'a taşı ve _load_ ile yükle",
        "recipe_fitness": "Düşük fitness reçeteyi düzelt veya buharlaştır, tekrarlayan hatalar için self_heal çalıştır",
        "pheromone_anomaly": "Ani fail artışını incele, broken reçeteleri düzelt veya buharlaştır",
        "feedback_health": "recipe_feedback.py entegrasyonunu kontrol et, trail'e recipe_id yazılmalı, YAML güncellenmeli",
        "evolution_health": "recipe_learner çalışmalı, inbox modülerleştirilmeli, başarı oranı izlenmeli",
        "hook_overrides": "Hook uyarılarını ciddiye al — koda talimat gömme, knowledge/recipe kullan",
        "activation_map": "activation_map.yaml kontrol et — ölü referansları kaldır, summary ekle",
        "recipe_activation_coverage": "Reçete çalışırken knowledge canlanmalı — trail'de kontrol et",
        "activation_growth": "auto_learned büyüyor mu, gürültü riski var mı",
        "sql_guard": "sql_guard.py kontrol et — DROP/DELETE koruması, read_only",
        "daemon_health": "Daemon PID stale kontrolü — ölü process varsa yeniden başlat",
        "budget_management": "budget_committee.py — 4 karar tipi (APPROVE/DECOMPOSE/REDIRECT/LEARN)",
        "learning_loop": "learning_loop.py — 5 adımlı öğrenme döngüsü",
        "recipe_factory": "recipe_factory.py — validate, normalize, dedup, quality gate",
        "cc_audit": "CC audit güvenilirlik — son 10 commit'in audit pas oranı",
        "network_safety": "Banka ortamı ağ güvenliği — CONT_OFFLINE + yasak modül kontrolü",
        "hallucination_guard": "Tablo/kolon iddiası varsa SQL çalıştırılmış olmalı — veriye dayanmayan iddia yasak",
    }
    return fixes.get(check_name, "ANTIPATTERNS.md'ye bak")


def show_guardian_warnings():
    """Cont başlangıcında çözülmemiş uyarıları göster."""
    warnings = load_warnings()
    unresolved = [w for w in warnings if not w.get("resolved")]
    if not unresolved:
        return

    print("=" * 60)
    print("[GUARDIAN] Çözülmemiş ihlaller:")
    for w in unresolved:
        print(f"  ⚠ {w['check']}: {w['message'][:120]}")
        print(f"    Çözüm: {w['fix']}")
    print("=" * 60)


def run_guardian(full: bool = False) -> GuardianReport:
    """Tüm kontrolleri çalıştır.

    full=False: operasyonel kontroller (1-5) — Cont başlangıcı
    full=True:  + kod yapısı kontrolleri (6-10) — CC commit öncesi
    """
    operational_checks = [
        ("system_prompt_bloat", check_system_prompt_bloat),
        ("budget_doping", check_budget_changes),
        ("recipe_quality", check_recipe_quality),
        ("knowledge_location", check_knowledge_location),
        ("recall_bypass", check_recall_bypass),
        ("recipe_fitness", check_recipe_fitness),
        ("pheromone_anomaly", check_pheromone_anomaly),
        ("feedback_health", check_feedback_health),
        ("evolution_health", check_evolution_health),
        ("hook_overrides", check_hook_overrides),
        ("activation_map", check_activation_map),
        ("recipe_activation_coverage", check_recipe_activation_coverage),
        ("activation_growth", check_activation_growth),
    ]

    code_checks = [
        ("monolithic_llm", check_monolithic_llm_calls),
        ("llm_deterministic", check_llm_doing_deterministic_work),
        ("hive_bypass", check_hive_bypass),
        ("hardcoded_knowledge", check_hardcoded_knowledge),
        ("unverified_tool", check_unverified_tool_calls),
        ("inbox_overflow", check_inbox_overflow),
        ("code_pollution", check_code_pollution),
        ("knowledge_bypass", check_knowledge_bypass),
        ("sql_guard", check_sql_guard),
        ("daemon_health", check_daemon_health),
        ("budget_management", check_budget_management),
        ("learning_loop", check_learning_loop),
        ("recipe_factory", check_recipe_factory),
        ("cc_audit", check_cc_audit),
        ("network_safety", check_network_safety),
        ("hallucination_guard", check_hallucination_guard),
    ]

    checks = operational_checks + (code_checks if full else [])

    report = GuardianReport()
    for name, check_fn in checks:
        try:
            passed, violations = check_fn()
            if not violations:
                report.add_pass(name)
            else:
                for v in violations:
                    report.add_violation(name, v)
        except Exception as e:
            report.add_violation(name, f"Kontrol hatası: {e}")

    # Mevcut uyarıları güncelle: yeni ihlalleri ekle, düzelenleri işaretle
    current_msgs = {msg for _, msg in report.all_violations()}
    existing = load_warnings()
    for w in existing:
        if w["message"] not in current_msgs:
            w["resolved"] = True
    _save_warnings(existing, datetime.now().isoformat())

    if report.has_violations():
        write_warnings(report)
    else:
        clear_warnings()

    return report


if __name__ == "__main__":
    import sys as _sys
    os.chdir(str(Path(__file__).parent.parent))

    full = "--full" in _sys.argv
    mode = "TAM (operasyonel + kod yapısı)" if full else "HIZLI (operasyonel)"
    print(f"[GUARDIAN] Mod: {mode}\n")

    report = run_guardian(full=full)

    passed = sum(1 for r in report.results.values() if r["passed"])
    total = len(report.results)

    if report.has_violations():
        print(f"[GUARDIAN] {passed}/{total} kontrol geçti. İhlaller:\n")
        for check, msg in report.all_violations():
            print(f"  ✗ {check}: {msg}\n")
    else:
        print(f"[GUARDIAN] ✓ {total}/{total} kontrol geçti.")
