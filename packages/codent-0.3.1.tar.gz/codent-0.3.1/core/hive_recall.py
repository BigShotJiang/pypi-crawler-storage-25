# core/hive_recall.py
"""Hive recall — 3 ayrı adım: MATCH → INJECT kararı → HINT oluştur.

Adım 1 (find_match): HER ZAMAN çalışır. Keyword eşleştirme.
Adım 2 (should_inject): Bağlama göre enjeksiyon kararı.
Adım 3 (build_hint): Suggestive hint oluştur.

Feedback ayrı — recipe_feedback.py'de, match sonucunu kullanır.
"""

import re
from pathlib import Path
from typing import Optional

import yaml

HIVE_RECIPES_DIR = Path(__file__).parent.parent / ".cont" / "hive" / "recipes"


# ═══════════════════════════════
# ADIM 1: MATCH (her zaman çalışır)
# ═══════════════════════════════

def _load_recipes() -> list[dict]:
    recipes = []
    if not HIVE_RECIPES_DIR.exists():
        return recipes
    for layer in ("primitives", "composites", "project"):
        layer_dir = HIVE_RECIPES_DIR / layer
        if not layer_dir.exists():
            continue
        for f in layer_dir.glob("*.yaml"):
            try:
                data = yaml.safe_load(f.read_text(encoding="utf-8"))
                if data and isinstance(data, dict) and "trigger" in data:
                    data["_layer"] = layer
                    data["_path"] = str(f)
                    recipes.append(data)
            except Exception:
                continue
    return recipes


def _score(task: str, recipe: dict) -> float:
    task_lower = task.lower()
    task_words = set(task_lower.split())
    trigger = recipe.get("trigger", "")
    trigger_keywords = [k.strip() for k in trigger.split(",")]

    score = 0.0
    for keyword in trigger_keywords:
        kw = keyword.lower().strip()
        if not kw:
            continue
        kw_parts = kw.split()
        if len(kw_parts) > 1:
            if all(p in task_lower for p in kw_parts):
                score += 2.0 * len(kw_parts)
                continue
        if kw in task_words:
            score += 2.0
        elif kw in task_lower:
            score += 1.0
    return score


def find_match(task: str, top_k: int = 2, min_score: float = 2.0) -> list[dict]:
    """ADIM 1: Keyword eşleştirme. HER ZAMAN çalışır, bypass YOK.

    Returns: eşleşen reçeteler (skor + overlap + fitness bilgisiyle).
    Boş liste = eşleşme yok.
    """
    recipes = _load_recipes()
    task_lower = task.lower()
    task_words = set(task_lower.split())
    scored = []

    for r in recipes:
        s = _score(task, r)
        if s >= min_score:
            trigger = r.get("trigger", "")
            trigger_kws = set(k.strip().lower() for k in trigger.split(",") if k.strip())
            task_kws = set(w for w in task_words if len(w) >= 3)
            overlap = len(task_kws & trigger_kws) / max(len(task_kws | trigger_kws), 1)
            r["_score"] = s
            r["_keyword_overlap"] = round(overlap, 2)
            scored.append((s, r))

    # Fitness sort + güvenilmez filtre
    try:
        from core.fitness import fitness
        filtered = []
        for s, r in scored:
            f = fitness(r)
            total_runs = r.get("success_count", 0) + r.get("fail_count", 0)
            if total_runs >= 5 and f < 0.3:
                continue
            r["_fitness"] = f
            filtered.append((s, r))
        filtered.sort(key=lambda x: (-x[0], -x[1].get("_fitness", 0.5)))
        scored = filtered
    except ImportError:
        scored.sort(key=lambda x: -x[0])

    return [r for _, r in scored[:top_k]]


# ═══════════════════════════════
# ADIM 2: ENJEKSIYON KARARI
# ═══════════════════════════════

_DOMAIN_SIGNALS_CACHE: set | None = None

def _load_domain_signals() -> set:
    """domain_task_signals.yaml'dan domain keyword'lerini yükle."""
    global _DOMAIN_SIGNALS_CACHE
    if _DOMAIN_SIGNALS_CACHE is not None:
        return _DOMAIN_SIGNALS_CACHE

    signals = set()
    yaml_path = Path(__file__).parent.parent / ".cont" / "hive" / "knowledge" / "domain_task_signals.yaml"
    if yaml_path.exists():
        data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
        for category_words in data.get("domain_signals", {}).values():
            if category_words:
                signals.update(w.lower() for w in category_words if w)
    _DOMAIN_SIGNALS_CACHE = signals
    return signals


def classify_complexity(task: str) -> str:
    """Görev karmaşıklığını sınıfla: 'simple', 'domain', 'multi_step'.

    Fiil bazlı DEĞİL, içerik bazlı:
    - simple: tek sorgu, direkt cevap ("kaç firma var", "listele")
    - domain: domain bilgisi gerektirir ("neden YI", "açıkla", SQL/DuckDB)
    - multi_step: çok adımlı ("temizle ve model eğit", "karşılaştır ve raporla")
    """
    task_lower = task.lower()
    word_count = len(task.split())

    # Multi-step sinyalleri
    multi_step_patterns = [
        r"\bve\s+(sonra|ardından)\b", r"\bthen\b", r"\band\s+then\b",
        r"\badım\b", r"\bpipeline\b", r"\bsırayla\b",
        r"(temizle|eğit|karşılaştır|analiz|raporla).+(temizle|eğit|karşılaştır|analiz|raporla)",
    ]
    for pat in multi_step_patterns:
        if re.search(pat, task_lower):
            return "multi_step"

    if word_count > 30:
        return "multi_step"

    # Domain sinyalleri — knowledge'dan yüklenir
    domain_keywords = _load_domain_signals()
    task_words = set(re.findall(r'[a-zA-ZçğıöşüÇĞİÖŞÜ_]{3,}', task_lower))
    # Exact match + substring match (Türkçe ekleri: tablosundaki→tablo)
    domain_hits = task_words & domain_keywords
    for kw in domain_keywords:
        if len(kw) >= 4 and kw in task_lower:
            domain_hits.add(kw)
    if len(domain_hits) >= 2:
        return "domain"

    # Açıklama/yorum sinyalleri
    domain_patterns = [
        r"\bneden\b", r"\bnasıl\b", r"\baçıkla\b", r"\byorum\b",
        r"\banlat\b", r"\banlamı\b", r"\bfark\b", r"\bilişki\b",
        r"\bwhy\b", r"\bhow\b", r"\bexplain\b", r"\binterpret\b",
    ]
    for pat in domain_patterns:
        if re.search(pat, task_lower):
            return "domain"

    if word_count > 15 and ("?" in task or any(w in task_lower for w in ["nasıl", "neden", "nedir"])):
        return "domain"

    return "simple"


def should_inject(task: str, matches: list[dict]) -> str:
    """ADIM 2: Enjeksiyon kararı. Returns: 'none', 'log_only', 'hint', 'knowledge'.

    - simple görev → 'log_only' (eşleşme var ama enjekte etme, sadece feedback için kaydet)
    - domain görev → 'knowledge' (knowledge dosyası varsa enjekte)
    - multi_step → 'hint' (suggestive reçete hint'i)
    - eşleşme yok → 'none'
    """
    if not matches:
        return "none"

    complexity = classify_complexity(task)

    if complexity == "simple":
        return "log_only"
    elif complexity == "domain":
        return "knowledge"
    else:  # multi_step
        return "hint"


# ═══════════════════════════════
# ADIM 3: HINT OLUŞTUR
# ═══════════════════════════════

def build_hint(matches: list[dict], mode: str = "hint") -> str:
    """ADIM 3: Suggestive hint oluştur.

    mode='hint' → reçete adımları suggestive olarak
    mode='knowledge' → sadece reçete adı + domain bilgisi işareti
    mode='log_only' → boş string (enjekte etme)
    mode='none' → boş string
    """
    if mode in ("none", "log_only") or not matches:
        return ""

    parts = []
    for r in matches:
        name = r.get("name", "?")
        desc = r.get("description", "")
        overlap = r.get("_keyword_overlap", 0)

        if overlap < 0.30:
            continue

        sc = r.get("success_count", 0)
        fc = r.get("fail_count", 0)
        total = sc + fc
        sr_str = f" ({round(sc/total*100)}% başarı)" if total > 0 else ""

        if mode == "knowledge":
            # Kısa: sadece ad + domain ipucu
            parts.append(
                f"<hive_hint type='knowledge'>\n"
                f"İlgili domain bilgisi: {name} — {desc}{sr_str}\n"
                f"Knowledge dosyalarına bak: .cont/hive/knowledge/\n"
                f"</hive_hint>"
            )
        elif mode == "hint" and overlap >= 0.50:
            # Tam suggestive hint
            steps_summary = []
            for step in r.get("steps", [])[:4]:
                params = step.get("params", {})
                cmd = params.get("command", params.get("pattern", ""))
                worker = step.get("worker", "?")
                if cmd:
                    first_line = cmd.strip().split("\n")[0][:80]
                    steps_summary.append(f"  - {first_line}")
                else:
                    steps_summary.append(f"  - {worker}")
            steps_str = "\n".join(steps_summary)
            parts.append(
                f"<hive_hint type='suggestive'>\n"
                f"Benzer görevlerde başarılı yaklaşım{sr_str}:\n"
                f"Reçete: {name} — {desc}\n"
                f"Adımlar:\n{steps_str}\n"
                f"Bu göreve uygunsa kullanabilirsin.\n"
                f"</hive_hint>"
            )

    return "\n".join(parts)


# ═══════════════════════════════
# CONVENIENCE: tek çağrı
# ═══════════════════════════════

def recall_and_hint(task: str) -> str:
    """Backward compat: match → karar → hint. Returns hint string."""
    matches = find_match(task)
    mode = should_inject(task, matches)
    return build_hint(matches, mode)


# Eski API uyumluluğu
def recall(task: str, top_k: int = 2, min_score: float = 2.0) -> list[dict]:
    """Eski API — find_match'e yönlendir."""
    return find_match(task, top_k, min_score)
