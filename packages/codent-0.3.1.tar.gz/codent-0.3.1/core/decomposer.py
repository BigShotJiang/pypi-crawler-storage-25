# core/decomposer.py
"""
Task decomposer for local LLMs.

7B-20B models fail on complex multi-step tasks. This module breaks them
into simple subtasks using regex-based pattern matching (no LLM calls).
Handles both Turkish and English conjunctions.
"""

import re
from pathlib import Path


# Loaded from .cont/hive/knowledge/action_verbs.yaml
def _load_action_verbs() -> set:
    yaml_path = Path(__file__).parent.parent / ".cont" / "hive" / "knowledge" / "action_verbs.yaml"
    if yaml_path.exists():
        import yaml
        data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
        return set(data.get("action_verbs", []))
    return set()

ACTION_VERBS = _load_action_verbs()

# Decomposition patterns: (regex, extractor function)
DECOMPOSE_PATTERNS = [
    # "compare X and/ile/with Y" → [read X, read Y, compare the two]
    (r"(?:compare|karşılaştır)\s+(.+?)\s+(?:and|ve|ile|with)\s+(.+)",
     lambda m: [f"read {m.group(1).strip()}", f"read {m.group(2).strip()}", "compare the two"]),

    # "fix all errors in X" → [find all issues in X, fix each issue]
    (r"(?:fix|düzelt)\s+(?:all|tüm|hepsi)\s+(.+)",
     lambda m: [f"find all issues in {m.group(1).strip()}", "fix each issue one by one"]),

    # "X and then Y" / "X ve sonra Y" (explicit sequencing)
    (r"(.+?)\s+(?:and\s+then|ve\s+sonra)\s+(.+)",
     lambda m: [m.group(1).strip(), m.group(2).strip()]),

    # "X then Y" / "X sonra Y"
    (r"(.+?)\s+(?:then|sonra)\s+(.+)",
     lambda m: [m.group(1).strip(), m.group(2).strip()]),

    # "X and Y" / "X ve Y" (only if both halves contain action verbs)
    (r"(.+?)\s+(?:and|ve)\s+(.+)",
     lambda m: _split_if_both_have_actions(m.group(1).strip(), m.group(2).strip())),
]


def _split_if_both_have_actions(part1: str, part2: str) -> list:
    """Only split on 'and/ve' if both halves contain action verbs."""
    words1 = set(part1.lower().split())
    words2 = set(part2.lower().split())
    if words1 & ACTION_VERBS and words2 & ACTION_VERBS:
        return [part1, part2]
    # No split - treat as single task
    return [f"{part1} and {part2}"]


def should_decompose(task: str) -> bool:
    """Check if task is complex enough to need decomposition."""
    words = task.split()

    # Word count heuristic: long tasks likely need decomposition
    if len(words) > 15:
        return True

    # Multiple action verbs suggest multi-step task
    action_count = sum(1 for w in task.lower().split() if w in ACTION_VERBS)
    if action_count >= 2:
        return True

    return False


def decompose(task: str) -> list:
    """
    Break a complex task into simple subtasks.

    Returns list of subtask strings. If no decomposition is needed,
    returns [task] (single-element list).
    """
    # Always try pattern matching first (compare, fix all, etc.)
    for pattern, extractor in DECOMPOSE_PATTERNS:
        match = re.search(pattern, task, re.IGNORECASE)
        if match:
            subtasks = extractor(match)
            # Filter out empty strings and single-element non-splits
            subtasks = [s for s in subtasks if s.strip()]
            if len(subtasks) > 1:
                return subtasks

    # No pattern matched despite heuristic saying it's complex
    return [task]


def format_decomposed_task(subtasks: list) -> str:
    """Format subtasks as a numbered instruction list for the LLM."""
    if len(subtasks) <= 1:
        return subtasks[0] if subtasks else ""

    lines = ["This task has multiple steps. Complete them in order:"]
    for i, st in enumerate(subtasks, 1):
        lines.append(f"  {i}. {st}")
    lines.append("Complete each step before moving to the next.")
    return "\n".join(lines)


# ── Compound task decomposition ──
# Uses general heuristics instead of hardcoded word lists:
# 1. Short tasks (<=3 words) are always simple
# 2. Must have location keyword + file type + action verb
# 3. Location word must look like a directory name (hyphens, underscores,
#    or exists in system_map) — not a common Turkish word

# Extension mapping for file type detection
_EXT_MAP = {
    'json': 'json', 'yaml': 'yaml', 'yml': 'yaml',
    'csv': 'csv', 'xml': 'xml', 'py': 'py',
    'txt': 'txt', 'pdf': 'pdf', 'log': 'log',
    'md': 'md', 'html': 'html', 'js': 'js', 'ts': 'ts',
    'toml': 'toml', 'ini': 'ini', 'cfg': 'cfg',
    'conf': 'conf', 'css': 'css',
}


def _looks_like_dirname(name: str) -> bool:
    """Check if a word looks like a directory/project name vs common word.

    Directory names typically contain hyphens, underscores, dots,
    or are long enough to be project names. Also checks system_map.
    """
    # Structural indicators: hyphens, underscores, dots
    if '-' in name or '_' in name or '.' in name:
        return True
    # Long words (>6 chars) are more likely project names than common words
    if len(name) > 6:
        return True
    # Check filesystem index
    try:
        from core.system_map import find_in_map
        results = find_in_map(name, entry_type="dir", limit=1)
        if results:
            return True
    except Exception:
        pass
    return False


def decompose_compound_task(task_text: str) -> list:
    """
    Only decompose tasks that match:
    '[specific-location] altındaki/içindeki [file-type] [multi-action]'

    Uses general heuristics — no hardcoded word lists.
    Returns empty list [] for simple tasks (no decomposition).
    Returns list of subtask dicts for compound tasks.
    """
    if not task_text:
        return []

    task = task_text.lower().strip()
    words = task.split()

    # ─── HEURISTIC 1: Short tasks are always simple ───
    if len(words) <= 3:
        return []

    # ─── HEURISTIC 2: MUST have location keyword ───
    location_match = re.search(
        r'([\w\-_.]{3,})\s+(altındaki|içindeki|klasöründeki|dizinindeki|klasörünün)',
        task
    )

    if not location_match:
        return []  # No location pattern = simple task

    target_name = location_match.group(1)

    # ─── HEURISTIC 3: Location must look like a directory name ───
    if not _looks_like_dirname(target_name):
        return []  # Common word, not a directory name

    # ─── HEURISTIC 4: MUST have file type ───
    file_type_match = re.search(
        r'\b(json|yaml|yml|csv|xml|py|txt|pdf|log|md|html|js|ts)'
        r'(?:ları|leri|lar|ler|dosyaları|dosyalarını|files?)?\b'
        r'|'
        r'\b(dosya|dosyalar|dosyaları|dosyalarını)\b',
        task
    )

    if not file_type_match:
        return []  # No file type mentioned = simple task

    # Extract the actual extension
    file_type_word = file_type_match.group(1) or file_type_match.group(2)
    file_ext = _EXT_MAP.get(file_type_word, None)

    # If user said "dosyaları" without extension, check if
    # extension is elsewhere in the text
    if not file_ext:
        for ext in _EXT_MAP:
            if ext in task:
                file_ext = _EXT_MAP[ext]
                break

    if not file_ext:
        file_ext = "*"  # All files

    # ─── HEURISTIC 5: MUST have action verb ───
    has_find = bool(re.search(r'\b(bul|ara|find|search)\b', task))
    has_list = bool(re.search(r'\b(listele|göster|list|show|yazdır)\b', task))
    has_summarize = bool(re.search(r'\b(özetle|summarize|oku|read|incele)\b', task))

    action_count = sum([has_find, has_list, has_summarize])

    # Location implies "find", so list/summarize alone counts as 2
    if has_summarize or has_list:
        action_count = max(action_count, 2)

    if action_count < 2:
        return []

    # ─── BUILD SUBTASKS ───
    subtasks = []

    subtasks.append({
        "task": f"{target_name} klasörünü bul",
        "type": "find_location",
        "target": target_name,
        "hint": f"system_search ile '{target_name}' klasörünü bul",
    })

    subtasks.append({
        "task": f".{file_ext} dosyalarını listele",
        "type": "find_files",
        "extension": file_ext,
        "hint": f"find komutuyla .{file_ext} dosyalarını bul",
    })

    if has_summarize:
        subtasks.append({
            "task": "dosyaları oku ve özetle",
            "type": "read_summarize",
            "hint": "Dosyaları oku ve özet çıkar",
        })

    return subtasks
