# core/repl.py
"""Interactive REPL loop — moved from cont.py Wave 3.

All cont.py globals accessed via RuntimeContext (_ctx).
"""

import itertools
import os
import queue as _queue_mod
import re
import select
import sys
import threading
import time
from pathlib import Path

from rich import print as rprint

from core.runtime import RuntimeContext

# ── Pattern constants ──

_FOLLOWUP_PATTERNS = [
    r'\bbunları\b', r'\bbunu\b', r'\bşimdi\b.*\bözetle\b',
    r'\byukarıdaki\b', r'\bsonuçları\b', r'\bdo it\b',
    r'\bsame\b', r'\bdevam\b', r'\baynısını\b',
    r'\bşimdi\b.*\byap\b', r'\bözetle\b',
]

_RETRY_PATTERNS = [
    r'^tekrar\s*dene', r'^yeniden\s*dene', r'^retry',
    r'^tekrar\s*yap', r'^bir\s*daha\s*dene',
    r'okumayı\s*tekrar', r'tekrar\s*oku',
    r'^bir\s*daha\s*yap', r'^yeniden\s*yap',
]

_CONTINUE_PATTERNS = [
    r'^devam$', r'^devam\s+et', r'^continue$', r'^next$',
    r'^sonraki', r'^kalan', r'^geri\s+kalan',
]

# ── Batch continuation state ──

_current_batch_state = None


def _save_batch_state(state: dict):
    global _current_batch_state
    _current_batch_state = state


def _load_batch_state() -> dict:
    return _current_batch_state


def _clear_batch_state():
    global _current_batch_state
    _current_batch_state = None


def _is_followup(user_input: str) -> bool:
    """Detect if user input references previous results."""
    text = user_input.lower().strip()
    if _is_retry(text):
        return False
    for pattern in _FOLLOWUP_PATTERNS:
        if re.search(pattern, text):
            return True
    return False


def _is_retry(user_input: str) -> bool:
    """Detect if user wants to retry the previous task."""
    text = user_input.lower().strip()
    for pattern in _RETRY_PATTERNS:
        if re.search(pattern, text):
            return True
    return False


def _is_continuation(user_input: str) -> bool:
    """Detect if user wants to continue reading next batch."""
    text = user_input.lower().strip()
    for pattern in _CONTINUE_PATTERNS:
        if re.search(pattern, text):
            return True
    return False


def _make_cli_callback(console):
    """Create event callback that shows Rich spinner/status in CLI."""
    _spinner_chars = itertools.cycle(['⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏'])

    def _update_status(text):
        sys.stderr.write(f"\r\033[K  {next(_spinner_chars)} {text}")
        sys.stderr.flush()

    def _clear_status():
        sys.stderr.write("\r\033[K")
        sys.stderr.flush()

    def callback(event):
        etype = event.get("type")
        if etype == "status":
            _update_status(event.get("text", ""))
        elif etype == "tool_call":
            pass
        elif etype == "done":
            _clear_status()
        elif etype == "error":
            _clear_status()
            console.print(f"  [red]⚠ {event.get('text', 'Hata')}[/red]")
        elif etype == "escalation":
            _clear_status()
        elif etype == "response":
            _clear_status()

    return callback


def run_batch(ctx: RuntimeContext, tasks_file: str) -> bool:
    """Run tasks from a file, one per line. Stops on first failure."""
    tasks_path = Path(tasks_file)
    if not tasks_path.exists():
        ctx.console.print(f"[red]Tasks file not found: {tasks_file}[/red]")
        return False

    tasks = [line.strip() for line in tasks_path.read_text().splitlines() if line.strip()]

    if not tasks:
        ctx.console.print("[yellow]No tasks found in file.[/yellow]")
        return True

    ctx.console.print(f"[green]Running {len(tasks)} tasks from {tasks_file}[/green]")

    for i, task in enumerate(tasks, 1):
        ctx.console.print(f"\n[bold]=== Task {i}/{len(tasks)} ===[/bold]")
        ctx.console.print(f"[blue]{task}[/blue]\n")

        logger = ctx.run_logger_cls(f"batch_{i}_{task}", ctx.log_dir)
        answer, success = ctx.run_task_fn(task, logger)

        if not success:
            ctx.console.print(f"\n[red]Task {i} failed. Stopping batch.[/red]")
            return False

        ctx.console.print(f"\n[green]Task {i} completed.[/green]")

    ctx.console.print(f"\n[bold green]All {len(tasks)} tasks completed successfully.[/bold green]")
    return True


def _handle_slash_command(ctx: RuntimeContext, task: str, cmd: str,
                          conversation_history: list,
                          _voice_thread, _voice_stop_event, _voice_queue,
                          _voice_bg_listener,
                          _episodic_conn, improve_loop) -> tuple:
    """Handle slash commands. Returns (handled: bool, voice_thread)."""

    if cmd == "/clear":
        conversation_history.clear()
        ctx.console.print("[green]Conversation history cleared.[/green]")
        return True, _voice_thread

    elif cmd == "/history":
        if not conversation_history:
            ctx.console.print("[yellow]No conversation history.[/yellow]")
        else:
            ctx.console.print(f"[cyan]History ({len(conversation_history)} turns):[/cyan]")
            for i, turn in enumerate(conversation_history, 1):
                user_short = turn['user'][:50] + "..." if len(turn['user']) > 50 else turn['user']
                ctx.console.print(f"  {i}. {user_short}")
        return True, _voice_thread

    elif cmd == "/help":
        ctx.console.print("[cyan]Commands:[/cyan]")
        ctx.console.print("  /clear          - Clear conversation history")
        ctx.console.print("  /history        - Show conversation history")
        ctx.console.print("  /recipes        - Show loaded recipes")
        ctx.console.print("  /vocab          - Show vocabulary stats")
        ctx.console.print("  /patches        - Show active patches")
        ctx.console.print("  /automations    - Show automations and status")
        ctx.console.print("  /briefing       - Run morning briefing")
        ctx.console.print("  /claude <task>  - Send task to Claude Code")
        ctx.console.print("  /claude-edit <task>  - Claude edits files")
        ctx.console.print("  /claude-analyze <task> - Claude analyzes (read-only)")
        ctx.console.print("  /relay          - Start Browser Claude relay server")
        ctx.console.print("  /bridge         - Start Chrome extension bridge for Claude.ai")
        ctx.console.print("  /voice          - Start voice input mode")
        ctx.console.print("  /openai <task>  - Run task with OpenAI API")
        ctx.console.print("  /tanı <cümle>   - Yaratıcı anahtar doğrulama")
        ctx.console.print("  /help           - Show this help")
        return True, _voice_thread

    elif cmd == "/relay":
        from core.relay import start_relay
        ctx.console.print("[dim]Starting relay server... (Ctrl+C to stop)[/dim]")
        try:
            start_relay()
        except KeyboardInterrupt:
            pass
        return True, _voice_thread

    elif cmd == "/bridge":
        from core.bridge_server import start_bridge
        ctx.console.print("[dim]Starting bridge server... (Ctrl+C to stop)[/dim]")
        try:
            start_bridge()
        except KeyboardInterrupt:
            pass
        return True, _voice_thread

    elif cmd == "/voice":
        if _voice_thread is None or not _voice_thread.is_alive():
            _voice_stop_event.clear()
            _voice_thread = threading.Thread(
                target=_voice_bg_listener,
                args=(_voice_queue, _voice_stop_event),
                daemon=True,
            )
            _voice_thread.start()
            ctx.console.print("[green]Voice mode ON. Say 'Cont' or 'Alev' + command.[/green]")
        else:
            _voice_stop_event.set()
            _voice_thread.join(timeout=8)
            _voice_thread = None
            ctx.console.print("[yellow]Voice mode OFF.[/yellow]")
        return True, _voice_thread

    elif cmd in ("/tanı", "/tani", "/genesis", "/owner"):
        from core.genesis import check_owner_keyphrase, is_owner_recognized
        if is_owner_recognized():
            ctx.console.print("[green]Yaratıcı zaten tanındı.[/green]")
        else:
            import getpass
            try:
                keyphrase = getpass.getpass("Anahtar cümle: ")
                if not keyphrase.strip():
                    ctx.console.print("[yellow]Boş cümle girildi.[/yellow]")
                elif check_owner_keyphrase(keyphrase):
                    ctx.console.print("[bold green]Yaratıcı tanındı. Bağ aktif.[/bold green]")
                else:
                    ctx.console.print("[red]Anahtar cümle eşleşmedi.[/red]")
            except (EOFError, KeyboardInterrupt):
                ctx.console.print("\n[yellow]İptal edildi.[/yellow]")
        return True, _voice_thread

    elif cmd in ("/recipes", "/recipies", "/reçete", "/recete", "/tarifler"):
        if ctx.learning_enabled:
            from core.recipes import list_recipes
            recipes = list_recipes()
            if recipes:
                ctx.console.print(f"[cyan]Recipes ({len(recipes)}):[/cyan]")
                for r in recipes:
                    rid = r.get("id", "?")
                    desc = r.get("description", "")
                    ok = r.get("success_count", 0)
                    fail = r.get("failure_count", 0)
                    src = r.get("source", "?")
                    ctx.console.print(
                        f"  {rid}: {desc} "
                        f"(ok:{ok} fail:{fail}) [{src}]"
                    )
            else:
                ctx.console.print("[yellow]No recipes loaded.[/yellow]")
        else:
            ctx.console.print("[yellow]Learning system not available.[/yellow]")
        return True, _voice_thread

    elif cmd in ("/evict", "/temizle"):
        try:
            from core.memory_eviction import run_eviction
            conn = ctx.db_connect_fn()
            evicted = run_eviction(conn)
            conn.close()
            if evicted:
                ctx.console.print(f"[green]🧹 {evicted} hafıza kaydı temizlendi.[/green]")
            else:
                ctx.console.print("[dim]Temizlenecek bir şey yok.[/dim]")
        except Exception as e:
            ctx.console.print(f"[red]Eviction hatası: {e}[/red]")
        return True, _voice_thread

    elif cmd.startswith("/browse ") or cmd.startswith("/gez "):
        _browse_rest = task.split(" ", 1)[1].strip() if " " in task else ""
        _browse_parts = _browse_rest.split(" ", 1)
        if len(_browse_parts) == 2 and _browse_parts[0].startswith("http"):
            _browse_url, _browse_goal = _browse_parts
            try:
                from core.browser_agent import browser_agent_run
                ctx.console.print(f"[cyan]🌐 Browser agent: {_browse_url}[/cyan]")
                _browse_result = browser_agent_run(_browse_url, _browse_goal)
                ctx.console.print(_browse_result[:5000])
            except ImportError:
                ctx.console.print("[red]Browser agent kullanılamıyor (playwright gerekli)[/red]")
            except Exception as e:
                ctx.console.print(f"[red]Browser agent hatası: {e}[/red]")
        else:
            ctx.console.print("[yellow]Kullanım: /browse <url> <hedef>[/yellow]")
            ctx.console.print("[dim]Örnek: /browse https://mevzuat.adalet.gov.tr kosgeb kanununu bul[/dim]")
        return True, _voice_thread

    elif cmd.startswith("/teach ") or cmd.startswith("/öğret "):
        if ctx.teacher_enabled and ctx.learning_enabled:
            _teach_task = task.split(" ", 1)[1].strip()
            if _teach_task:
                _teach_ctx = {
                    "cwd": str(ctx.current_cwd),
                    "repo_root": str(ctx.repo_root),
                }
                _teach_conn = ctx.init_recipe_db_fn()
                _teach_result = ctx.learn_and_save_fn(
                    _teach_task, _teach_conn,
                    context=_teach_ctx,
                )
                if _teach_result:
                    ctx.console.print(
                        f"[green]  ✅ Recipe öğrenildi: "
                        f"{_teach_result['id']}[/green]"
                    )
                    ctx.console.print(
                        f"[dim]  📝 {_teach_result.get('description', '')}[/dim]"
                    )
                else:
                    ctx.console.print(
                        "[red]  ❌ Recipe öğrenilemedi. "
                        "API key kontrol edin:[/red]"
                    )
                    ctx.console.print(
                        "[dim]     python3 cont.py "
                        "--setup-openai sk-...[/dim]"
                    )
            else:
                ctx.console.print(
                    "[yellow]Kullanım: /teach <görev açıklaması>[/yellow]"
                )
        else:
            ctx.console.print("[yellow]Teacher modülü etkin değil.[/yellow]")
        return True, _voice_thread

    elif cmd in ("/stats", "/istatistik"):
        if ctx.episodic_enabled and _episodic_conn:
            try:
                from core.episodic import get_task_stats
                _st = get_task_stats(_episodic_conn)
                ctx.console.print("[cyan]📊 Son 7 gün:[/cyan]")
                ctx.console.print(f"   Toplam: {_st['total']}")
                ctx.console.print(
                    f"   Başarılı: {_st['success']} | "
                    f"Başarısız: {_st['failed']} | "
                    f"Belirsiz: {_st['unknown']}"
                )
                ctx.console.print(f"   Başarı oranı: {_st['success_rate']}")
                ctx.console.print(f"   Ort. tool: {_st['avg_tools']}")
                if _st['by_type']:
                    _types = ", ".join(
                        f"{k}: {v}" for k, v in _st['by_type'].items()
                    )
                    ctx.console.print(f"   Tip: {_types}")
            except Exception as e:
                ctx.console.print(f"[red]Stats hatası: {e}[/red]")
        else:
            ctx.console.print("[yellow]Episodic memory etkin değil.[/yellow]")
        return True, _voice_thread

    elif cmd == "/vocab":
        if ctx.learning_enabled:
            from core.vocabulary import get_vocabulary_stats
            stats = get_vocabulary_stats()
            if stats.get("total", 0) > 0:
                ctx.console.print(f"[cyan]Vocabulary: {stats['commands']} commands, {stats['context_words']} context words, {stats['patterns']} patterns[/cyan]")
            else:
                ctx.console.print("[yellow]No vocabulary loaded.[/yellow]")
        else:
            ctx.console.print("[yellow]Learning system not available.[/yellow]")
        return True, _voice_thread

    elif cmd == "/patches":
        if ctx.learning_enabled:
            from core.prompt_patches import load_file_patches
            patches = load_file_patches()
            if patches:
                active_count = sum(1 for p in patches if p.get("active", True))
                ctx.console.print(f"[cyan]Patches ({active_count} active / {len(patches)} total):[/cyan]")
                for p in patches:
                    pid = p.get("id", "?")
                    pri = p.get("priority", 0)
                    active = "✓" if p.get("active", True) else "✗"
                    text = p.get("patch_text", "")[:60]
                    ctx.console.print(f"  {active} [{pri:2d}] {pid}: {text}")
            else:
                ctx.console.print("[yellow]No patches loaded.[/yellow]")
        else:
            ctx.console.print("[yellow]Learning system not available.[/yellow]")
        return True, _voice_thread

    elif cmd == "/automations":
        if ctx.automation_enabled:
            from core.automations import load_automations
            autos = load_automations()
            if autos:
                ctx.console.print(f"[cyan]Automations ({len(autos)}):[/cyan]")
                for a in autos:
                    name = a.get("name", "?")
                    desc = a.get("description", "")[:50]
                    enabled = "✓" if a.get("enabled", True) else "✗"
                    trigger = a.get("trigger", {}).get("event", "?")
                    ctx.console.print(f"  {enabled} {name}: {desc} [trigger: {trigger}]")
            else:
                ctx.console.print("[yellow]No automations found.[/yellow]")
        else:
            ctx.console.print("[yellow]Automation system not available.[/yellow]")
        return True, _voice_thread

    elif cmd == "/briefing":
        if ctx.automation_enabled:
            from core.automations import load_automations, AutomationRunner
            autos = load_automations()
            briefing = next((a for a in autos if a.get("name") == "morning_briefing"), None)
            if briefing:
                ctx.console.print("[cyan]Running morning briefing...[/cyan]")
                runner = AutomationRunner()
                summary = runner.execute(briefing)
                if summary:
                    for part in summary.split(" | "):
                        ctx.console.print(f"  {part}")
                else:
                    ctx.console.print("  (no output)")
            else:
                ctx.console.print("[yellow]No morning_briefing automation found.[/yellow]")
        else:
            ctx.console.print("[yellow]Automation system not available.[/yellow]")
        return True, _voice_thread

    elif cmd == "/triage" or cmd.startswith("/triage "):
        from core.episodic import run_triage
        parts = cmd.split()
        _triage_n = 50
        if len(parts) > 1:
            try:
                _triage_n = int(parts[1])
            except ValueError:
                pass
        _triage_report = run_triage(
            n=_triage_n,
            log_dir=str(ctx.repo_root / "logs" / "cont_runs"),
            verbose=True,
        )
        ctx.console.print(_triage_report)
        return True, _voice_thread

    # Claude Code slash commands
    if task.startswith("/claude-edit "):
        claude_task = task[13:].strip()
        if claude_task and ctx.escalation_enabled:
            esc = ctx.get_escalation_fn()
            if esc.is_available:
                result = esc.call_claude(claude_task, mode="edit", working_dir=str(ctx.repo_root))
                if result.get("success"):
                    ctx.console.print(f"[green]Claude Code ({result['duration_sec']}s):[/green]")
                    ctx.console.print(result["output"])
                else:
                    ctx.console.print(f"[red]{result.get('error')}[/red]")
            else:
                ctx.console.print("[red]Claude CLI not found[/red]")
        return True, _voice_thread

    if task.startswith("/claude-analyze "):
        claude_task = task[16:].strip()
        if claude_task and ctx.escalation_enabled:
            esc = ctx.get_escalation_fn()
            if esc.is_available:
                result = esc.call_claude(claude_task, mode="analyze", working_dir=str(ctx.repo_root))
                if result.get("success"):
                    ctx.console.print(f"[green]Claude Code ({result['duration_sec']}s):[/green]")
                    ctx.console.print(result["output"])
                else:
                    ctx.console.print(f"[red]{result.get('error')}[/red]")
            else:
                ctx.console.print("[red]Claude CLI not found[/red]")
        return True, _voice_thread

    if task.startswith("/claude "):
        claude_task = task[8:].strip()
        if claude_task and ctx.escalation_enabled:
            esc = ctx.get_escalation_fn()
            if esc.is_available:
                result = esc.call_claude(claude_task, mode="general", working_dir=str(ctx.repo_root))
                if result.get("success"):
                    ctx.console.print(f"[green]Claude Code ({result['duration_sec']}s):[/green]")
                    ctx.console.print(result["output"])
                else:
                    ctx.console.print(f"[red]{result.get('error')}[/red]")
            else:
                ctx.console.print("[red]Claude CLI not found[/red]")
        elif not ctx.escalation_enabled:
            ctx.console.print("[red]Escalation system not available[/red]")
        return True, _voice_thread

    # Not handled
    return False, _voice_thread


def run_interactive(ctx: RuntimeContext,
                    no_log: bool = False, debug: bool = False,
                    self_improve_off: bool = False):
    """Interactive chat loop with conversation memory."""

    # Resolve model and endpoint
    ctx.model = ctx.resolve_model_fn()
    ctx.determine_endpoint_mode_fn(ctx.model)

    ctx.console.print(f"[dim]Model: {ctx.model} | Endpoint: {ctx.endpoint_mode}[/dim]")
    if debug:
        ctx.console.print(f"[dim]Base URL: {ctx.base_url}[/dim]")

    # Run pending scheduled automations at startup
    if ctx.automation_enabled:
        try:
            from core.automations import AutomationRunner, register_event_handlers
            from core.scheduler import Scheduler
            runner = AutomationRunner()
            register_event_handlers()
            pending = runner.get_pending_scheduled()
            if pending:
                ctx.console.print(f"[dim]Running {len(pending)} scheduled automation(s)...[/dim]")
                for auto, period in pending:
                    name = auto.get("name", "?")
                    summary = runner.execute(auto)
                    scheduler = Scheduler()
                    scheduler.mark_done(name, period)
                    if summary:
                        ctx.console.print(f"[dim]  {summary}[/dim]")
        except Exception as e:
            ctx.debug_fn(f"Startup automations failed: {e}")

    # Initialize system map
    try:
        from core.system_map import ensure_index_exists
        ensure_index_exists()
    except Exception as e:
        ctx.debug_fn(f"System map init failed: {e}")

    # Memory eviction at startup
    try:
        from core.memory_eviction import evict_on_startup
        evict_on_startup(ctx.db_connect_fn)
    except Exception as e:
        ctx.debug_fn(f"Startup eviction failed: {e}")

    ctx.console.print("Hello. Enter a prompt (Ctrl+D or Ctrl+C to exit).")

    # === EPISODIC MEMORY ===
    _episodic_conn = None
    if ctx.episodic_enabled:
        try:
            from core.episodic import init_episodic_db, record_episode, \
                episodic_update_feedback as _episodic_update_feedback
            _episodic_conn = init_episodic_db()
        except Exception as e:
            ctx.debug_fn(f"Episodic DB init failed: {e}")

    # === CONVERSATION HISTORY ===
    conversation_history = []
    MAX_HISTORY_TURNS = 10
    last_task_id = None
    session_tasks = []
    _last_self_score = 3
    previous_task = None

    # === SELF-IMPROVEMENT LOOP ===
    improve_loop = None
    if not self_improve_off and ctx.self_improve_enabled:
        try:
            from core.self_improve import SelfImproveLoop
            improve_loop = SelfImproveLoop(
                ctx.db_connect_fn, ctx.memory_init_db_fn, str(ctx.repo_root)
            )
        except Exception as e:
            ctx.debug_fn(f"Self-improve loop init failed: {e}")

    # === BACKGROUND VOICE LISTENER ===
    _voice_queue = _queue_mod.Queue()
    _voice_stop_event = threading.Event()
    _voice_thread = None

    def _voice_bg_listener(q, stop_event):
        """Background thread: records audio, transcribes, puts commands in queue."""
        from core.voice import record_audio, transcribe, detect_wake_word, \
            extract_command, _get_whisper_model
        model = _get_whisper_model()
        if model is None:
            return
        while not stop_event.is_set():
            try:
                audio = record_audio(duration=3)
                if stop_event.is_set():
                    if audio:
                        try:
                            os.remove(audio)
                        except OSError:
                            pass
                    break
                if not audio:
                    time.sleep(0.5)
                    continue
                text = transcribe(audio)
                if not text:
                    continue
                if detect_wake_word(text):
                    command = extract_command(text)
                    if command:
                        sys.stdout.write(f"\r\033[K  Voice: {command}\n> ")
                        sys.stdout.flush()
                        q.put(command)
            except Exception as e:
                ctx.debug_fn(f"Voice listener error: {e}")
                time.sleep(1)

    while True:
        try:
            # Prompt for input
            sys.stdout.write("\n> ")
            sys.stdout.flush()
            task = None
            _openai_override = False

            while task is None:
                # Check voice queue first
                try:
                    voice_cmd = _voice_queue.get_nowait()
                    task = voice_cmd
                    if improve_loop:
                        improve_loop.user_active()
                    break
                except _queue_mod.Empty:
                    pass

                # Check if stdin has data (1 second timeout)
                try:
                    ready, _, _ = select.select([sys.stdin], [], [], 1.0)
                except (ValueError, OSError):
                    task = input().strip()
                    break
                if ready:
                    line = sys.stdin.readline()
                    if not line:
                        raise EOFError
                    task = line.strip()
                    if improve_loop:
                        improve_loop.user_active()
                else:
                    if improve_loop:
                        improve_loop.check_and_start()

            if not task:
                continue

            # v6.3: Early Unicode normalization — fix surrogate escapes
            # before any handler. Prevents /kötü from falling through
            # to Phase-0 due to corrupted ö/ü characters.
            import unicodedata
            try:
                task = task.encode('utf-8', errors='surrogateescape').decode('utf-8', errors='replace')
            except (UnicodeDecodeError, UnicodeEncodeError):
                pass
            task = unicodedata.normalize('NFC', task)

            # Check for confirmation responses
            if task.lower() in ("yes", "evet", "y", "e"):
                wp = ctx.get_write_protection_fn()
                if wp.pending_writes:
                    wp.write_confirmed = True
                    ctx.console.print("[green]Write confirmed. Proceeding...[/green]")
                    continue
            elif task.lower() in ("no", "hayır", "n", "h"):
                wp = ctx.get_write_protection_fn()
                if wp.pending_writes:
                    wp.pending_writes = []
                    ctx.console.print("[yellow]Write cancelled.[/yellow]")
                    continue

            # Handle feedback commands
            _fb_recipe_id = ctx.run_task_fn._last_recipe_id
            _fb_episode_id = ctx.run_task_fn._last_episode_id
            from core.runtime import handle_feedback_command as _handle_feedback_command
            if _handle_feedback_command(
                task, last_task_id, session_tasks,
                recipe_success_fn=ctx.recipe_record_success_fn if ctx.learning_enabled else None,
                recipe_failure_fn=(
                    getattr(ctx, 'recipe_record_failure_fn', None)
                    if ctx.learning_enabled else None
                ),
                episodic_feedback_fn=(
                    lambda eid, fb: _episodic_update_feedback(init_episodic_db(), eid, fb)
                ) if ctx.episodic_enabled and _episodic_conn else None,
                last_recipe_id=_fb_recipe_id,
                last_episode_id=_fb_episode_id,
                console_print_fn=ctx.console.print,
                memory_remember_fn=getattr(ctx, 'memory_remember_fn', None),
                last_tools_used=list(getattr(ctx, 'last_tools_used', None) or []),
                last_raw_input=previous_task,
            ):
                continue

            # Session reset
            if task.strip() == "/s":
                conversation_history.clear()
                session_tasks.clear()
                last_task_id = None
                previous_task = None
                _last_self_score = 3
                _clear_batch_state()
                if improve_loop and hasattr(improve_loop, '_attempted_tasks'):
                    improve_loop._attempted_tasks.clear()
                try:
                    from core.memory_eviction import run_eviction
                    conn = ctx.db_connect_fn()
                    evicted = run_eviction(conn)
                    conn.close()
                    if evicted:
                        ctx.console.print(f"[dim]🧹 {evicted} eski hafıza temizlendi.[/dim]")
                except Exception:
                    pass
                ctx.console.print("🔄 Yeni oturum. Konu değiştirildi.")
                continue

            # Handle batch continuation
            if _is_continuation(task):
                batch = _load_batch_state()
                if batch:
                    start = batch["read_so_far"]
                    end = min(start + batch["batch_size"], len(batch["all_files"]))
                    next_batch = batch["all_files"][start:end]

                    if not next_batch:
                        ctx.console.print("[green]✅ Tüm dosyalar zaten okundu.[/green]")
                        _clear_batch_state()
                    else:
                        remaining_after = len(batch["all_files"]) - end
                        ctx.console.print(f"[dim]Sonraki {len(next_batch)} dosya okunuyor...[/dim]")

                        from core.runtime import load_files_for_summary as _load_files_for_summary
                        previews, files_read = _load_files_for_summary(
                            next_batch, max_per_file=400, max_total=5000
                        )
                        if previews:
                            logger = None if no_log else ctx.run_logger_cls(task, ctx.log_dir)
                            summary = ctx.llm_summarize_fn(
                                previews, len(next_batch),
                                batch.get("original_task", task),
                                logger=logger
                            )

                            if remaining_after > 0:
                                summary += (
                                    f"\n\n📊 **{end}/{len(batch['all_files'])} "
                                    f"dosya okundu.** Kalan {remaining_after} dosya var.\n"
                                    f"💡 \"devam\" yazarak okumaya devam edebilirsin."
                                )
                                batch["read_so_far"] = end
                                _save_batch_state(batch)
                            else:
                                summary += (
                                    f"\n\n✅ Tüm {len(batch['all_files'])} "
                                    f"dosya okundu ve özetlendi."
                                )
                                _clear_batch_state()

                            rprint(summary)

                            conversation_history.append({
                                "user": task,
                                "assistant": summary,
                                "success": True,
                            })
                            if len(conversation_history) > MAX_HISTORY_TURNS:
                                conversation_history = conversation_history[-MAX_HISTORY_TURNS:]
                        else:
                            ctx.console.print("[yellow]Dosyalar okunamadı.[/yellow]")
                            _clear_batch_state()
                    continue

            # Handle slash commands
            if task.startswith("/"):
                cmd = task.lower().strip()

                # /openai needs special handling (doesn't always return)
                if cmd == "/openai" or cmd.startswith("/openai "):
                    arg = cmd[7:].strip() if len(cmd) > 7 else ""
                    if not arg:
                        key = ctx.load_openai_cloud_key_fn()
                        if key:
                            ctx.console.print(f"[green]OpenAI API key: ...{key[-8:]}[/green]")
                            ctx.console.print("[dim]Kullanım: /openai <görev> veya --model openai:gpt-4o-mini[/dim]")
                        else:
                            ctx.console.print("[yellow]OpenAI key yok.[/yellow]")
                            ctx.console.print("[dim]Ayarla: python3 cont.py --setup-openai sk-...[/dim]")
                            ctx.console.print("[dim]  veya: export CONT_OPENAI_KEY=sk-...[/dim]")
                        continue
                    if not ctx.load_openai_cloud_key_fn():
                        ctx.console.print("[red]OpenAI API key ayarlanmamış.[/red]")
                        continue
                    task = arg
                    _openai_override = True
                    ctx.console.print(f"[cyan]  ↗ OpenAI ile çalışıyor...[/cyan]")
                else:
                    handled, _voice_thread = _handle_slash_command(
                        ctx, task, cmd, conversation_history,
                        _voice_thread, _voice_stop_event, _voice_queue,
                        _voice_bg_listener, _episodic_conn, improve_loop,
                    )
                    if handled:
                        continue

            # === INTENT GATE (Phase -1) ===
            from core.intent_gate import detect_intent as _detect_intent

            _intent = _detect_intent(task)
            if _intent.intent == "write":
                from core.intent_gate import handle_write_intent
                from core.memory_store import memory_remember as _mem_remember
                _write_result = handle_write_intent(
                    _intent.payload,
                    memory_write_fn=_mem_remember,
                    console_print_fn=ctx.console.print,
                )
                if _write_result:
                    conversation_history.append({"user": task, "assistant": _write_result, "success": True})
                continue
            elif _intent.intent == "read":
                from core.intent_gate import handle_read_intent
                _read_result = handle_read_intent(
                    _intent.payload,
                    memory_search_fn=ctx.memory_hybrid_search_fn,
                    console_print_fn=ctx.console.print,
                )
                if _read_result:
                    conversation_history.append({"user": task, "assistant": _read_result, "success": True})
                continue
            elif _intent.intent == "command":
                pass  # safety net — slash router should have caught it already

            # === INPUT SAFETY ===
            _safe, _reason = ctx.check_input_safety_fn(task)
            if not _safe:
                ctx.console.print(f"\n[bold red]  ⛔ Tehlikeli komut tespit edildi: {_reason}[/bold red]")
                ctx.console.print(f"[bold red]  Bu işlem güvenlik nedeniyle engellenmiştir.[/bold red]")
                ctx.console.print(f"[bold red]  Tier 3 kuralları geçersiz kılınamaz.[/bold red]\n")
                try:
                    security = ctx.get_security_manager_fn()
                    if security:
                        security._audit("tier3_input_blocked", "user_input",
                                        {"task": task[:200]}, 3, "blocked", {"reason": _reason})
                except Exception:
                    pass
                continue

            # === RETRY DETECTION ===
            if _is_retry(task) and previous_task:
                ctx.console.print(f"[dim]Tekrar deneniyor: {previous_task[:60]}...[/dim]")
                task = previous_task

            # === BUILD CONTEXT FROM HISTORY ===
            from core.runtime import build_conversation_context as _build_conversation_context
            context_prompt = _build_conversation_context(conversation_history, task)

            # Inject previous result if follow-up
            if _is_followup(task) and conversation_history:
                prev = conversation_history[-1]
                prev_answer = prev.get("assistant", "")
                prev_task = prev.get("user", "")
                prev_success = prev.get("success", True)
                prev_tools = prev.get("tools_used", []) or []
                # Multi-turn fix: even if assistant text empty, still inject
                # task + tools_used so next turn knows context.
                if prev_answer or prev_tools:
                    status = "BAŞARILI" if prev_success else "BAŞARISIZ"
                    answer_line = prev_answer[:1500] if prev_answer else "(metin yok — sadece tool çağrıları yapıldı)"
                    tools_line = f"Kullanılan tool'lar: {', '.join(prev_tools)}\n" if prev_tools else ""
                    inject = (
                        f"\n[ÖNCEKİ GÖREV ({status})]\n"
                        f"Görev: {prev_task[:200]}\n"
                        f"{tools_line}"
                        f"Sonuç: {answer_line}\n"
                        f"[/ÖNCEKİ GÖREV]\n\n"
                        f"Kullanıcı \"{task}\" diyor. Önceki görevin sonucunu kullanarak devam et.\n"
                    )
                    context_prompt = inject + context_prompt

            # Inject hint if previous task failed
            if session_tasks and not session_tasks[-1]["success"]:
                prev = session_tasks[-1]
                prev_tools = prev.get("tools_used", [])
                hint_parts = ["[SİSTEM İPUCU: Önceki görev başarısız oldu."]
                if any(t in prev_tools for t in ("list_dir", "search_files", "read_file")):
                    hint_parts.append(
                        "Dosya/klasör bulunamadıysa find_path ile ~/projects/ altında ara."
                    )
                hint_parts.append("Aynı tool'u aynı argümanlarla tekrar çağırma.]")
                context_prompt = " ".join(hint_parts) + "\n\n" + context_prompt

            # Auto model selection
            if ctx.get_auto_mode_fn():
                from core.model_routing import auto_select_model, detect_task_complexity
                auto_model = auto_select_model(task)
                if auto_model:
                    old_model = ctx.model
                    if auto_model != old_model:
                        ctx.model = auto_model
                        tier = detect_task_complexity(task)
                        ctx.console.print(f"[dim]Auto: {tier} → {auto_model}[/dim]")

            # Create logger
            logger = None if no_log else ctx.run_logger_cls(task, ctx.log_dir)
            ctx.current_log_path = str(logger.logfile) if logger else None

            # Pause self-improvement
            if improve_loop:
                improve_loop.pause()

            # Store raw user input
            ctx.run_task_fn._user_input = task

            # Track timing for episodic memory
            _task_start_time = time.time()

            # Run with context
            try:
                _saved_model = None
                if _openai_override:
                    _saved_model = ctx.model
                    ctx.model = "openai:gpt-4o-mini"
                _cli_cb = _make_cli_callback(ctx.console)
                try:
                    answer, success = ctx.run_task_fn(context_prompt, logger, event_callback=_cli_cb)
                finally:
                    if _saved_model:
                        ctx.model = _saved_model

                # Capture task_id for feedback
                last_task_id = getattr(ctx.run_task_fn, '_last_task_id', None)

                # Save for retry
                previous_task = task

                # === SAVE TO HISTORY ===
                _last_tools = list(getattr(ctx.run_task_fn, '_last_tools_used', []) or [])
                conversation_history.append({
                    "user": task,
                    "assistant": answer if answer else "",
                    "success": success,
                    "tools_used": _last_tools[:5],  # Multi-turn context için
                })
                if len(conversation_history) > MAX_HISTORY_TURNS:
                    conversation_history = conversation_history[-MAX_HISTORY_TURNS:]

                # === SESSION TASK TRACKING ===
                session_tasks.append({
                    "task_id": last_task_id,
                    "task_text": task,
                    "success": success,
                    "answer_snippet": (answer or "")[:200],
                    "tools_used": list(getattr(ctx.run_task_fn, '_last_tools_used', [])),
                    "timestamp": time.time(),
                })
                if len(session_tasks) > 20:
                    session_tasks = session_tasks[-20:]

                # === EPISODIC MEMORY + AUTO-EVAL ===
                if ctx.episodic_enabled and _episodic_conn:
                    try:
                        _tools_list = list(getattr(ctx.run_task_fn, '_last_tools_used', []))
                        _tool_count = len(_tools_list)
                        _recipe_id = getattr(ctx.run_task_fn, '_last_recipe_id', None)

                        _ep_task_type = "llm"
                        _ep_method = None
                        if _recipe_id:
                            _ep_task_type = "recipe"
                            _ep_method = f"recipe:{_recipe_id}"
                        elif answer and hasattr(ctx.run_task_fn, '_last_task_id'):
                            if _tool_count == 0 and success:
                                _ep_task_type = "fastpath"

                        _recipe_criteria = None
                        _mr = getattr(ctx.run_task_fn, '_last_matched_recipe', None)
                        if _recipe_id and _mr and _mr.get("success_criteria"):
                            _recipe_criteria = _mr["success_criteria"]

                        from core.auto_eval import evaluate_task
                        _auto_eval = evaluate_task(
                            task_input=task,
                            response=answer or "",
                            tools_used=_tool_count,
                            tool_names=_tools_list,
                            task_type=_ep_task_type,
                            recipe_id=_recipe_id,
                            recipe_criteria=_recipe_criteria,
                        )

                        _ep_success = 1 if _auto_eval["success"] else (
                            0 if _auto_eval["success"] is False else -1
                        )

                        _last_episode_id = record_episode(
                            conn=_episodic_conn,
                            task_input=task,
                            task_type=_ep_task_type,
                            method=_ep_method,
                            tools_used=_tool_count,
                            tool_names=_tools_list,
                            duration_ms=int((time.time() - _task_start_time) * 1000),
                            success=_ep_success,
                            auto_eval=_auto_eval,
                            response_preview=(answer or "")[:200],
                            recipe_id=_recipe_id,
                        )
                        ctx.run_task_fn._last_episode_id = _last_episode_id

                        if _auto_eval["success"] is False and _auto_eval["confidence"] > 0.7:
                            ctx.console.print(
                                f"[dim]  ⚠️ Oto-değerlendirme: "
                                f"başarısız ({_auto_eval['score']}/100)[/dim]"
                            )
                            for _r in _auto_eval["reasons"]:
                                ctx.console.print(f"[dim]    - {_r}[/dim]")
                    except Exception as _ep_err:
                        ctx.debug_fn(f"Episodic recording failed: {_ep_err}")

                # === TEACHER: auto-learn recipe ===
                if ctx.teacher_enabled and ctx.episodic_enabled and ctx.learning_enabled:
                    try:
                        _tools_list_t = list(getattr(ctx.run_task_fn, '_last_tools_used', []))
                        _recipe_id_t = getattr(ctx.run_task_fn, '_last_recipe_id', None)
                        _mr_t = getattr(ctx.run_task_fn, '_last_matched_recipe', None)
                        _auto_eval_t = locals().get('_auto_eval')
                        _ep_success_t = _auto_eval_t["success"] if _auto_eval_t else None

                        _browser_success = (
                            "browser_agent" in _tools_list_t
                            and _ep_success_t is True
                        )

                        if ctx.should_learn_fn(
                            task,
                            episode={
                                "success": 0 if _ep_success_t is False else (
                                    1 if _ep_success_t else -1
                                ),
                                "tools_used": len(_tools_list_t),
                            },
                            recipe_match=_mr_t,
                            browser_agent_success=_browser_success,
                        ):
                            _teacher_ctx = {
                                "cwd": str(ctx.current_cwd),
                                "repo_root": str(ctx.repo_root),
                                "matched_recipe_id": getattr(ctx.run_task_fn, '_last_recipe_id', None),
                                "run_id": getattr(logger, 'run_id', None) if logger else None,
                            }
                            if _mr_t and _mr_t.get("pattern_keywords"):
                                _teacher_ctx["matched_recipe_keywords"] = ", ".join(
                                    sorted(_mr_t["pattern_keywords"].keys())[:8]
                                )
                            _failed_ep = {
                                "tools_used": len(_tools_list_t),
                                "tool_names": _tools_list_t,
                                "response_preview": (answer or "")[:100],
                            }
                            _recipe_conn_t = ctx.init_recipe_db_fn()
                            _learned = ctx.learn_and_save_fn(
                                task, _recipe_conn_t,
                                context=_teacher_ctx,
                                failed_episode=_failed_ep,
                            )
                            if _learned:
                                ctx.console.print(
                                    f"[cyan]  📚 Yeni recipe: "
                                    f"{_learned['id']}[/cyan]"
                                )
                                ctx.console.print(
                                    "[dim]     Sonraki sefer bu görev "
                                    "daha iyi çalışacak.[/dim]"
                                )
                    except Exception as _teach_err:
                        ctx.debug_fn(f"Teacher learning failed: {_teach_err}")

                ctx.current_log_path = None

                if logger:
                    ctx.console.print(f"[dim]Log: {logger.logfile}[/dim]")

                # Feedback prompt
                if last_task_id:
                    _voice_hint = "  /voice" if (_voice_thread is None or not _voice_thread.is_alive()) else ""
                    ctx.console.print(f"[dim]  Feedback: /iyi  /kötü  /not \"mesaj\"  /s (yeni oturum){_voice_hint}  (Enter=atla)[/dim]")
            except Exception as e:
                ctx.console.print(f"[red]Error: {e}[/red]")

        except EOFError:
            if improve_loop:
                improve_loop.pause()
            ctx.console.print("\nGoodbye.")
            break
        except KeyboardInterrupt:
            if improve_loop:
                improve_loop.pause()
            ctx.console.print("\nGoodbye.")
            break
