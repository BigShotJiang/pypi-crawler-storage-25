#!/usr/bin/env python3
"""Hızlı overfit test — 10 hafif görev, ham vs hive, 2x, < 10 dakika."""

import json, os, re, sys, time
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(str(PROJECT_ROOT))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

DB = "/home/sertan/projects/ews_v511/ews_dashboard/db/ews.duckdb"

TASKS = [
    {"id":"Q1","name":"Tablo sayısı",
     "task":f"DuckDB ({DB}): kaç tablo var?",
     "check":lambda r: any(c.isdigit() for c in r)},
    {"id":"Q2","name":"fact_periodic satır",
     "task":f"fact_periodic ({DB}) kaç satır?",
     "check":lambda r: any(c.isdigit() for c in r) and any(w in r.lower() for w in ["satır","row","562","fact"])},
    {"id":"Q3","name":"Dönem listesi",
     "task":f"fact_periodic ({DB}): hangi dönemler var? Listele.",
     "check":lambda r: any(w in r for w in ["250","260","donem","dönem"])},
    {"id":"Q4","name":"Segment sayıları",
     "task":f"dim_entity ({DB}): her segmentte kaç firma var?",
     "check":lambda r: any(w in r.lower() for w in ["kobi","mikro","kur-tic","eskk","segment"])},
    {"id":"Q5","name":"Max risk",
     "task":f"fact_periodic ({DB}): en yüksek kombine_risk değeri nedir?",
     "check":lambda r: any(c.isdigit() for c in r) and any(w in r.lower() for w in ["max","risk","en yüksek"])},
    {"id":"Q6","name":"YI firma sayısı",
     "task":f"fact_periodic ({DB}): son dönemde kaç firma YI (ews_skor='YI')?",
     "check":lambda r: any(c.isdigit() for c in r) and "yi" in r.lower()},
    {"id":"Q7","name":"Kolon tipleri",
     "task":f"fact_periodic ({DB}): entity_id ve ews_skor kolonlarının tipleri ne?",
     "check":lambda r: any(w in r.upper() for w in ["VARCHAR","BIGINT","INTEGER","DOUBLE"])},
    {"id":"Q8","name":"Bölge sayısı",
     "task":f"ref_sube_bolge ({DB}): kaç bölge var?",
     "check":lambda r: any(c.isdigit() for c in r)},
    {"id":"Q9","name":"EUS/YIS dağılımı",
     "task":f"fact_periodic ({DB}): son dönemde ews_kaynak='eus' ve 'yis' kaçar firma?",
     "check":lambda r: any(w in r.lower() for w in ["eus","yis"]) and any(c.isdigit() for c in r)},
    {"id":"Q10","name":"Diag tablo boyutu",
     "task":f"diag_eus_kapsam_diskalma ({DB}): kaç satır, kaç kolon?",
     "check":lambda r: any(c.isdigit() for c in r) and any(w in r.lower() for w in ["satır","row","kolon","column","diag"])},
]


def run_cont(task):
    t0 = time.time()
    try:
        from cont import run_task
        answer, success = run_task(task)
        return {"answer":answer or "","elapsed":round(time.time()-t0,1),
                "tools":len(getattr(run_task,'_last_tools_used',[]) or []),
                "recipe":getattr(run_task,'_last_recipe_id',None)}
    except Exception as e:
        return {"answer":f"ERROR:{e}","elapsed":round(time.time()-t0,1),"tools":0,"recipe":None}


def score(answer, check_fn):
    if not answer or "ERROR" in answer: return 0
    if not check_fn(answer): return 1
    has_num = len(re.findall(r'\d{2,}', answer)) >= 1
    return 4 if has_num and len(answer) > 100 else 3 if has_num else 2


def main():
    print(f"HIZLI OVERFİT TESTİ — 10 görev × 2 mod × 2 run")
    print(f"{'='*60}")

    all_results = []
    for run_idx in range(2):
        print(f"\n{'─'*60}")
        print(f"RUN {run_idx+1}/2")
        results = []
        for t in TASKS:
            # Ham
            ra = run_cont(t["task"])
            sa = score(ra["answer"], t["check"])
            time.sleep(1)
            # Hive
            rb = run_cont(t["task"])
            sb = score(rb["answer"], t["check"])
            delta = sb - sa
            icon = "✓" if delta >= 0 else "✗"
            print(f"  {t['id']:4s} Ham={sa} Hive={sb} Δ{'+' if delta>=0 else ''}{delta} {icon} recipe={rb['recipe']} ({ra['elapsed']:.0f}s/{rb['elapsed']:.0f}s)")
            results.append({"id":t["id"],"raw":sa,"hive":sb,"delta":delta,"recipe":rb["recipe"]})
            time.sleep(1)

        raw_t = sum(r["raw"] for r in results)
        hive_t = sum(r["hive"] for r in results)
        d = hive_t - raw_t
        print(f"\n  Run {run_idx+1}: Ham {raw_t}/40 vs Hive {hive_t}/40, Δ{'+' if d>=0 else ''}{d}")
        all_results.append({"run":run_idx+1,"raw":raw_t,"hive":hive_t,"delta":d,"tasks":results})

    # Özet
    avg_raw = sum(r["raw"] for r in all_results) / len(all_results)
    avg_hive = sum(r["hive"] for r in all_results) / len(all_results)
    avg_delta = avg_hive - avg_raw

    print(f"\n{'='*60}")
    print(f"SONUÇ (2 run ortalaması):")
    print(f"  Ham:  {avg_raw:.0f}/40")
    print(f"  Hive: {avg_hive:.0f}/40")
    print(f"  Δ:    {'+' if avg_delta>=0 else ''}{avg_delta:.0f}")

    if avg_delta >= 0:
        print(f"  ✓ Hive >= Ham — overfit düzeltildi")
    else:
        pct = avg_delta / max(avg_raw, 1) * 100
        if pct > -10:
            print(f"  ~ Hive hafif geride ({pct:.0f}%) — kabul edilebilir varyans")
        else:
            print(f"  ✗ Hive hâlâ geride ({pct:.0f}%) — overfit devam ediyor")

    # Zararlı recipe tespiti
    harm_count = sum(1 for r in all_results for t in r["tasks"] if t["delta"] < 0 and t["recipe"])
    total_recipe = sum(1 for r in all_results for t in r["tasks"] if t["recipe"])
    print(f"\n  Recipe enjeksiyon: {total_recipe}/20 görevde")
    print(f"  Zararlı recipe: {harm_count}/20 görevde (Hive < Ham + recipe var)")

    out = Path(".cont/hive/runs/training") / f"quick_overfit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    out.write_text(json.dumps(all_results, indent=2, ensure_ascii=False, default=str))
    print(f"\nJSON: {out}")


if __name__ == "__main__":
    main()
