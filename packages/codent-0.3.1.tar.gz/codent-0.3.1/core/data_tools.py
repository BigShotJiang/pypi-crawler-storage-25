#!/usr/bin/env python3
"""Deterministic data analysis tools for pDNA recipes.

Usage: python3 core/data_tools.py <command> <args...>

Commands:
  shape <path>                  Row count, column count, memory
  column_types <path>           Column names, types, null ratios
  class_balance <path> <col>    Class distribution for target column
  feature_stats <path>          Min, max, mean, std, median per numeric col
  null_analysis <path>          Null count/ratio per column
  correlation <path> [top_n]    Top correlated pairs
  outliers <path> <col> [method] Outlier detection (iqr|zscore)
  distribution <path> <col>     Skewness, kurtosis, normality test

Supports: .csv, .parquet, .duckdb (with --table)
"""

import json
import sys
from pathlib import Path


def _load(path: str, table: str = None):
    """Load data from CSV, parquet, or DuckDB."""
    import pandas as pd

    p = Path(path)
    if p.suffix == ".csv":
        return pd.read_csv(p)
    elif p.suffix == ".parquet":
        return pd.read_parquet(p)
    elif p.suffix == ".duckdb":
        import duckdb
        con = duckdb.connect(str(p), read_only=True)
        if not table:
            tables = [t[0] for t in con.execute("SHOW TABLES").fetchall()]
            con.close()
            return None, tables
        df = con.execute(f"SELECT * FROM {table}").df()
        con.close()
        return df
    else:
        raise ValueError(f"Unsupported format: {p.suffix}")


def cmd_shape(path: str, table: str = None):
    result = _load(path, table)
    if isinstance(result, tuple):
        _, tables = result
        print(json.dumps({"tables": tables}))
        return
    df = result
    print(json.dumps({
        "rows": len(df),
        "columns": len(df.columns),
        "memory_mb": round(df.memory_usage(deep=True).sum() / 1024 / 1024, 2),
        "column_names": list(df.columns),
    }))


def cmd_column_types(path: str, table: str = None):
    df = _load(path, table)
    result = []
    for col in df.columns:
        null_count = int(df[col].isnull().sum())
        result.append({
            "name": col,
            "dtype": str(df[col].dtype),
            "null_count": null_count,
            "null_ratio": round(null_count / len(df), 4) if len(df) > 0 else 0,
        })
    print(json.dumps(result, indent=2))


def cmd_class_balance(path: str, target: str, table: str = None):
    df = _load(path, table)
    counts = df[target].value_counts()
    total = len(df)
    result = {
        "target": target,
        "total": total,
        "classes": {},
    }
    for val, count in counts.items():
        result["classes"][str(val)] = {
            "count": int(count),
            "ratio": round(count / total, 4),
        }
    if len(counts) >= 2:
        result["imbalance_ratio"] = round(counts.max() / counts.min(), 2)
    print(json.dumps(result, indent=2))


def cmd_feature_stats(path: str, table: str = None):
    df = _load(path, table)
    numeric = df.select_dtypes(include=["number"])
    result = {}
    for col in numeric.columns:
        s = numeric[col].dropna()
        if len(s) == 0:
            continue
        result[col] = {
            "min": round(float(s.min()), 4),
            "max": round(float(s.max()), 4),
            "mean": round(float(s.mean()), 4),
            "std": round(float(s.std()), 4),
            "median": round(float(s.median()), 4),
            "count": int(len(s)),
        }
    print(json.dumps(result, indent=2))


def cmd_null_analysis(path: str, table: str = None):
    df = _load(path, table)
    total = len(df)
    result = []
    for col in df.columns:
        null_count = int(df[col].isnull().sum())
        result.append({
            "column": col,
            "null_count": null_count,
            "null_ratio": round(null_count / total, 4) if total > 0 else 0,
        })
    # Sort by null ratio descending
    result.sort(key=lambda x: -x["null_ratio"])
    empty_cols = [r["column"] for r in result if r["null_ratio"] == 1.0]
    print(json.dumps({
        "total_rows": total,
        "columns": result,
        "completely_empty": empty_cols,
    }, indent=2))


def cmd_correlation(path: str, top_n: int = 10, table: str = None):
    df = _load(path, table)
    numeric = df.select_dtypes(include=["number"])
    if numeric.shape[1] < 2:
        print(json.dumps({"pairs": [], "message": "Not enough numeric columns"}))
        return

    corr = numeric.corr()
    pairs = []
    for i, c1 in enumerate(corr.columns):
        for j, c2 in enumerate(corr.columns):
            if i < j:
                val = corr.iloc[i, j]
                if not (val != val):  # not NaN
                    pairs.append({
                        "col_a": c1,
                        "col_b": c2,
                        "correlation": round(float(val), 4),
                    })

    pairs.sort(key=lambda x: -abs(x["correlation"]))
    print(json.dumps({"top_pairs": pairs[:top_n]}, indent=2))


def cmd_outliers(path: str, column: str, method: str = "iqr", table: str = None):
    df = _load(path, table)
    s = df[column].dropna()

    if method == "iqr":
        q1, q3 = s.quantile(0.25), s.quantile(0.75)
        iqr = q3 - q1
        lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        outliers = s[(s < lower) | (s > upper)]
    elif method == "zscore":
        z = (s - s.mean()) / s.std()
        lower, upper = -3, 3
        outliers = s[z.abs() > 3]
    else:
        print(json.dumps({"error": f"Unknown method: {method}"}))
        return

    print(json.dumps({
        "column": column,
        "method": method,
        "total": int(len(s)),
        "outlier_count": int(len(outliers)),
        "outlier_ratio": round(len(outliers) / len(s), 4) if len(s) > 0 else 0,
        "lower_bound": round(float(lower), 4),
        "upper_bound": round(float(upper), 4),
    }, indent=2))


def cmd_distribution(path: str, column: str, table: str = None):
    from scipy import stats as sp_stats
    df = _load(path, table)
    s = df[column].dropna()

    skew = float(s.skew())
    kurt = float(s.kurtosis())
    # Shapiro-Wilk (sample if too large)
    sample = s.sample(min(5000, len(s)), random_state=42) if len(s) > 5000 else s
    stat, p_value = sp_stats.shapiro(sample)

    print(json.dumps({
        "column": column,
        "count": int(len(s)),
        "skewness": round(skew, 4),
        "kurtosis": round(kurt, 4),
        "shapiro_stat": round(float(stat), 4),
        "shapiro_p_value": round(float(p_value), 6),
        "normal": bool(p_value > 0.05),
    }, indent=2))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1]
    # Parse --table flag
    table = None
    args = []
    i = 2
    while i < len(sys.argv):
        if sys.argv[i] == "--table" and i + 1 < len(sys.argv):
            table = sys.argv[i + 1]
            i += 2
        else:
            args.append(sys.argv[i])
            i += 1

    commands = {
        "shape": lambda: cmd_shape(args[0], table),
        "column_types": lambda: cmd_column_types(args[0], table),
        "class_balance": lambda: cmd_class_balance(args[0], args[1], table),
        "feature_stats": lambda: cmd_feature_stats(args[0], table),
        "null_analysis": lambda: cmd_null_analysis(args[0], table),
        "correlation": lambda: cmd_correlation(args[0], int(args[1]) if len(args) > 1 else 10, table),
        "outliers": lambda: cmd_outliers(args[0], args[1], args[2] if len(args) > 2 else "iqr", table),
        "distribution": lambda: cmd_distribution(args[0], args[1], table),
    }

    if cmd not in commands:
        print(f"Unknown command: {cmd}")
        sys.exit(1)

    commands[cmd]()
