# core/self_improve.py
"""
Closed-loop self-improvement system for Cont.

Analyzes task failures, detects patterns, and generates prompt patches
that get automatically injected into future prompts for similar tasks.
"""

import os
import re
import json
import select
import sqlite3
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

try:
    from core.task_classifier import classify_task
except ImportError:
    def classify_task(t): return "general"


# =====================
# Failure Pattern Definitions (rule-based, no LLM needed)
# =====================

# Loaded from .cont/hive/knowledge/failure_patterns.yaml
def _load_failure_patterns() -> dict:
    from pathlib import Path
    yaml_path = Path(__file__).parent.parent / ".cont" / "hive" / "knowledge" / "failure_patterns.yaml"
    if yaml_path.exists():
        import yaml
        data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
        return data.get("failure_patterns", {})
    return {}

FAILURE_PATTERNS = _load_failure_patterns()


class SelfImprover:
    """Analyzes failures and generates prompt improvements."""

    def __init__(self, db_connect_fn, memory_init_fn):
        self._db_connect = db_connect_fn
        self._memory_init = memory_init_fn

    def analyze_failure(self, task: str, output: str, tool_calls_log: list = None) -> dict:
        """
        Analyze why a task failed using pattern matching (no LLM call).

        Returns:
            {
                "pattern": str,           # pattern key or "unknown"
                "description": str,       # human-readable description
                "detail": str,            # extracted detail (e.g., tool name)
                "fix_suggestion": str,    # suggested prompt patch
            }
        """
        combined = f"{task}\n{output}"
        if tool_calls_log:
            combined += "\n" + json.dumps(tool_calls_log, default=str)

        for pattern_key, pattern_def in FAILURE_PATTERNS.items():
            match = re.search(pattern_def["regex"], combined, re.IGNORECASE)
            if match:
                detail = match.group(1) if match.lastindex else ""
                return {
                    "pattern": pattern_key,
                    "description": pattern_def["description"],
                    "detail": detail,
                    "fix_suggestion": pattern_def["fix_template"].format(
                        detail=detail,
                        available_tools="list_dir, read_file, write_file, apply_patch, run_shell, search_files, web_fetch, web_search, repo_fetch, remember, recall, forget, list_memories"
                    ),
                }

        return {
            "pattern": "unknown",
            "description": "Unknown failure pattern",
            "detail": output[:200] if output else "",
            "fix_suggestion": "",
        }

    def record_outcome(self, task: str, success: bool, output: str = "",
                       failure_reason: str = "", reflection: str = "",
                       tool_calls_count: int = 0, duration_ms: int = 0,
                       model: str = "", prompt_tokens: int = 0) -> Optional[int]:
        """Record task outcome to DB. Returns task_outcome id or None."""
        try:
            self._memory_init()
            task_type = classify_task(task)
            conn = self._db_connect()
            try:
                cur = conn.execute("""
                    INSERT INTO task_outcome
                    (task_text, task_type, success, failure_reason, reflection,
                     tool_calls_count, duration_ms, model_used, prompt_tokens_approx, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    task[:500], task_type, 1 if success else 0,
                    failure_reason[:500] if failure_reason else None,
                    reflection[:500] if reflection else None,
                    tool_calls_count, duration_ms, model,
                    prompt_tokens, datetime.now().isoformat()
                ))
                conn.commit()
                return cur.lastrowid
            finally:
                conn.close()
        except Exception:
            pass  # Don't break main flow
        return None

    def get_failure_count(self, pattern: str, hours: int = 168) -> int:
        """Count how many times a failure pattern occurred in the last N hours."""
        try:
            self._memory_init()
            conn = self._db_connect()
            try:
                since = (datetime.now() - timedelta(hours=hours)).isoformat()
                cur = conn.execute("""
                    SELECT COUNT(*) FROM task_outcome
                    WHERE success = 0 AND failure_reason LIKE ?
                    AND created_at > ?
                """, (f"%{pattern}%", since))
                return cur.fetchone()[0]
            finally:
                conn.close()
        except Exception:
            return 0

    def should_reflect(self, pattern: str) -> bool:
        """Check if we should reflect on this failure (skip if recent duplicate)."""
        try:
            self._memory_init()
            conn = self._db_connect()
            try:
                since = (datetime.now() - timedelta(hours=24)).isoformat()
                cur = conn.execute("""
                    SELECT COUNT(*) FROM semantic_memory
                    WHERE memory_type = 'reflection'
                    AND content LIKE ?
                    AND created_at > ?
                """, (f"%{pattern}%", since))
                return cur.fetchone()[0] == 0
            finally:
                conn.close()
        except Exception:
            return True  # Reflect if we can't check

    def suggest_prompt_fix(self, failure_pattern: str, count: int) -> str:
        """
        After 3+ same failures, suggest a prompt modification.
        Returns a prompt patch string, or empty string if not enough data.
        """
        if count < 3:
            return ""

        pattern_def = FAILURE_PATTERNS.get(failure_pattern)
        if not pattern_def:
            return ""

        return pattern_def["fix_template"].format(
            detail="(recurring)",
            available_tools="list_dir, read_file, write_file, apply_patch, run_shell, search_files, web_fetch, web_search, repo_fetch, remember, recall, forget, list_memories"
        )

    def auto_create_patch(self, pattern: str, task_type: str) -> bool:
        """
        If pattern occurred 3+ times, auto-create a prompt patch.
        Returns True if a patch was created.
        """
        count = self.get_failure_count(pattern)
        if count < 3:
            return False

        fix = self.suggest_prompt_fix(pattern, count)
        if not fix:
            return False

        # Check if patch already exists
        try:
            conn = self._db_connect()
            try:
                cur = conn.execute("""
                    SELECT id FROM prompt_patch
                    WHERE task_type = ? AND trigger_pattern = ? AND active = 1
                """, (task_type, pattern))
                if cur.fetchone():
                    return False  # Already exists

                conn.execute("""
                    INSERT INTO prompt_patch
                    (task_type, patch_text, trigger_pattern, active, created_at)
                    VALUES (?, ?, ?, 1, ?)
                """, (task_type, fix, pattern, datetime.now().isoformat()))
                conn.commit()
                return True
            finally:
                conn.close()
        except Exception:
            return False

    def apply_learning(self, task_type: str) -> dict:
        """
        Track success rates by task type.
        Returns stats and flags for prompt improvement.
        """
        try:
            self._memory_init()
            conn = self._db_connect()
            try:
                cur = conn.execute("""
                    SELECT
                        COUNT(*) as total,
                        SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successes
                    FROM task_outcome
                    WHERE task_type = ?
                    AND created_at > datetime('now', '-7 days')
                """, (task_type,))
                row = cur.fetchone()
                total = row[0] or 0
                successes = row[1] or 0
                rate = successes / total if total > 0 else 0.0

                return {
                    "task_type": task_type,
                    "total": total,
                    "successes": successes,
                    "success_rate": round(rate, 2),
                    "needs_improvement": rate < 0.5 and total >= 3,
                }
            finally:
                conn.close()
        except Exception:
            return {"task_type": task_type, "total": 0, "success_rate": 0.0}

    def get_self_report(self) -> dict:
        """Generate a self-improvement report."""
        try:
            self._memory_init()
            conn = self._db_connect()
            try:
                # Success rates by task type
                cur = conn.execute("""
                    SELECT task_type,
                           COUNT(*) as total,
                           SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successes
                    FROM task_outcome
                    WHERE created_at > datetime('now', '-7 days')
                    GROUP BY task_type
                    ORDER BY total DESC
                """)
                by_type = []
                for row in cur.fetchall():
                    total, successes = row[1], row[2]
                    rate = successes / total if total > 0 else 0
                    by_type.append({
                        "type": row[0],
                        "total": total,
                        "successes": successes,
                        "rate": f"{rate:.0%}",
                    })

                # Top failure reasons
                cur = conn.execute("""
                    SELECT failure_reason, COUNT(*) as cnt
                    FROM task_outcome
                    WHERE success = 0 AND failure_reason IS NOT NULL
                    AND created_at > datetime('now', '-7 days')
                    GROUP BY failure_reason
                    ORDER BY cnt DESC
                    LIMIT 10
                """)
                top_failures = [{"reason": r[0], "count": r[1]} for r in cur.fetchall()]

                # Active patches
                cur = conn.execute("""
                    SELECT task_type, patch_text, trigger_pattern, success_delta
                    FROM prompt_patch WHERE active = 1
                """)
                patches = [{
                    "type": r[0], "patch": r[1],
                    "trigger": r[2], "delta": r[3]
                } for r in cur.fetchall()]

                # Overall stats
                cur = conn.execute("""
                    SELECT COUNT(*), SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END)
                    FROM task_outcome
                    WHERE created_at > datetime('now', '-7 days')
                """)
                row = cur.fetchone()
                total = row[0] or 0
                successes = row[1] or 0

                return {
                    "period": "last 7 days",
                    "total_tasks": total,
                    "overall_success_rate": f"{successes/total:.0%}" if total > 0 else "N/A",
                    "by_type": by_type,
                    "top_failures": top_failures,
                    "active_patches": patches,
                }
            finally:
                conn.close()
        except Exception as e:
            return {"error": str(e)}

    def suggest_improvements(self) -> list:
        """Analyze recent failures and suggest prompt patches."""
        suggestions = []
        try:
            self._memory_init()
            conn = self._db_connect()
            try:
                # Find recurring failure patterns
                cur = conn.execute("""
                    SELECT failure_reason, task_type, COUNT(*) as cnt
                    FROM task_outcome
                    WHERE success = 0 AND failure_reason IS NOT NULL
                    AND created_at > datetime('now', '-7 days')
                    GROUP BY failure_reason, task_type
                    HAVING cnt >= 3
                    ORDER BY cnt DESC
                """)
                for row in cur.fetchall():
                    reason, task_type, count = row
                    # Check if we already have a patch
                    cur2 = conn.execute("""
                        SELECT id FROM prompt_patch
                        WHERE task_type = ? AND trigger_pattern = ? AND active = 1
                    """, (task_type, reason))
                    if not cur2.fetchone():
                        fix = self.suggest_prompt_fix(reason, count)
                        if fix:
                            suggestions.append({
                                "task_type": task_type,
                                "pattern": reason,
                                "count": count,
                                "suggested_patch": fix,
                            })
            finally:
                conn.close()
        except Exception:
            pass
        return suggestions

    def reset_learning(self):
        """Reset all learned improvements (fresh start)."""
        try:
            self._memory_init()
            conn = self._db_connect()
            try:
                conn.execute("DELETE FROM prompt_patch")
                conn.execute("DELETE FROM task_outcome")
                conn.execute("DELETE FROM semantic_memory WHERE memory_type = 'reflection'")
                conn.commit()
                return True
            finally:
                conn.close()
        except Exception:
            return False


# =====================
# Idle Self-Improvement Loop
# =====================

class SelfImproveLoop:
    """
    Background self-improvement loop that runs when user is idle.

    Analyzes failed tasks, generates test cases, calls Claude Code CLI
    for fixes, and rolls back on failure. Pauses instantly when user
    provides input.
    """

    IDLE_TIMEOUT = 60        # seconds of silence before starting
    MAX_IMPROVEMENTS = 3     # per-session cap
    MAX_ISSUES_PER_IDLE = 2  # max issues to attempt per idle period

    def __init__(self, db_connect_fn, memory_init_fn, repo_root: str):
        self._db_connect = db_connect_fn
        self._memory_init = memory_init_fn
        self._repo_root = repo_root
        self.running = False
        self._stop_event = threading.Event()
        self._thread = None
        self._improvements_done = 0
        self._failed_attempts = 0
        self._last_user_input_time = time.time()
        self._attempted_tasks = set()  # task_text already tried this session
        self._cooldown_until = 0       # timestamp until which we don't run
        self._scan_count = 0           # how many times we've scanned
        self.MAX_SCANS = 3             # max scans per session
        self._ran_with_issues = False  # True once issues found — prevents re-run
        self._log = []  # list of dicts for --self-improve-log

    def user_active(self):
        """User provided input — reset idle timer and pause."""
        self._last_user_input_time = time.time()
        self.pause()

    def pause(self):
        """Stop improvement loop immediately."""
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)
        self.running = False

    def _has_partial_input(self) -> bool:
        """Check if user has typed something but not pressed Enter."""
        try:
            import fcntl
            import termios
            buf = fcntl.ioctl(sys.stdin.fileno(), termios.FIONREAD, b'\x00\x00\x00\x00')
            return int.from_bytes(buf, 'little') > 0
        except Exception:
            return False

    def check_and_start(self):
        """Called from interactive loop each second. Starts if idle enough."""
        if self._improvements_done >= self.MAX_IMPROVEMENTS:
            return  # Hard stop — session cap reached
        if self._scan_count >= self.MAX_SCANS:
            return  # Max scans reached, never run again this session
        if self._ran_with_issues:
            return  # Already found and processed issues this session
        if self._failed_attempts >= self.MAX_ISSUES_PER_IDLE * 2:
            return  # Tried enough unfixable issues, stop for this session
        if time.time() < self._cooldown_until:
            return  # In cooldown period
        if self.running:
            return

        idle_seconds = time.time() - self._last_user_input_time
        if idle_seconds < self.IDLE_TIMEOUT:
            return

        # Don't start if user is mid-typing (partial input in buffer)
        if self._has_partial_input():
            return

        self._scan_count += 1
        self.running = True
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._improve_loop,
            daemon=True
        )
        self._thread.start()

    def _print_background_status(self, message):
        """Print status without breaking input prompt."""
        sys.stdout.write(f"\r\033[K  {message}\n")
        sys.stdout.flush()

    def _should_stop(self) -> bool:
        """Check if we should stop (user active or stop requested)."""
        if self._stop_event.is_set():
            return True

        # Non-blocking stdin check
        try:
            if sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
                self._stop_event.set()
                self._print_background_status("⏸️  Input algılandı, duraklatıldı.")
                return True
        except Exception:
            pass  # select may fail in non-TTY environments

        return False

    def _improve_loop(self):
        """Main improvement loop. Runs in background thread.

        Stays SILENT unless it actually finds fixable issues.
        Only prints when starting a fix, never for "no issues found".
        """
        try:
            if self._should_stop():
                return

            # Silent analysis — no "Log analizi yapılıyor" message
            issues = self._analyze_recent_logs()
            if not issues:
                issues = self._analyze_logs()

            if not issues:
                # SILENT — no print, just cooldown
                self._cooldown_until = time.time() + 300
                return

            # Only print when we're actually going to fix something
            self._ran_with_issues = True  # Prevent re-run this session
            self._print_background_status(f"🔍 {len(issues)} sorun tespit edildi (/triage ile detay görebilirsiniz)")

            for issue in issues[:self.MAX_ISSUES_PER_IDLE]:
                if self._should_stop():
                    return

                self._attempted_tasks.add(issue["task_text"])

                # Step 1: Run test (silent)
                test_result = self._run_test(issue)

                if test_result["passed"]:
                    self._log_entry(issue, "skip", True, "Already passing")
                    continue

                if self._should_stop():
                    return

                # Step 2: Generate fix (silent)
                fix = self._generate_fix(issue, test_result)

                if not fix:
                    self._print_background_status(f"⚠️  Fix üretilemedi: {issue.get('test_input', '?')[:40]}")
                    self._log_entry(issue, "no_fix", False, "Could not generate fix")
                    self._failed_attempts += 1
                    continue

                if self._should_stop():
                    return

                # Step 3: Log suggestion (observe-only, no auto-fix)
                applied = self._apply_fix(fix)

                if not applied:
                    # Observe-only: log suggestion for /triage review
                    self._log_entry(issue, fix["type"], False,
                                    f"Suggestion: {fix['prompt'][:300]}")
                    self._failed_attempts += 1
                    continue

                if self._should_stop():
                    return

                # Step 4: Re-test
                retest = self._run_test(issue)

                if retest["passed"]:
                    self._print_background_status(f"✅ Fix başarılı: {issue['test_input'][:50]}")
                    self._improvements_done += 1
                    self._log_entry(issue, fix["type"], True, "Fix applied and tested")
                else:
                    self._rollback_fix(fix)
                    self._print_background_status(f"⚠️  Fix test geçemedi, geri alındı: {issue.get('test_input', '?')[:40]}")
                    self._log_entry(issue, fix["type"], False, "Fix failed re-test, rolled back")
                    self._failed_attempts += 1

            # After processing issues, cooldown 60 seconds
            self._cooldown_until = time.time() + 60

        except Exception:
            self._cooldown_until = time.time() + 300  # Error = long cooldown
        finally:
            self.running = False

    # -- JSONL Log Analysis --

    def _analyze_recent_logs(self) -> list:
        """
        Analyze JSONL log files directly instead of querying the DB.
        Returns issues in the same format as _analyze_logs().

        JSONL files are in ~/projects/cont/logs/cont_runs/ with format:
          20260214_185348_task_name_here.jsonl
        Each line is a JSON object with 'type' field:
          llm_request, llm_response, tool_call, tool_result, final
        """
        log_dir = Path(self._repo_root) / "logs" / "cont_runs"
        if not log_dir.exists():
            return []

        issues = []
        cutoff = datetime.now() - timedelta(hours=24)

        try:
            log_files = sorted(log_dir.glob("*.jsonl"), reverse=True)
        except Exception:
            return []

        for log_file in log_files[:10]:  # Check last 10 files (recent focus)
            # Extract timestamp from filename: 20260214_185348_task_name.jsonl
            fname = log_file.stem  # e.g. "20260214_185348_task_name_here"
            try:
                ts_str = fname[:15]  # "20260214_185348"
                file_time = datetime.strptime(ts_str, "%Y%m%d_%H%M%S")
                if file_time < cutoff:
                    break  # Files are sorted newest-first, so we can stop
            except (ValueError, IndexError):
                continue

            # Extract task name from filename (after timestamp)
            task_name = fname[16:].replace("_", " ").strip() if len(fname) > 16 else ""
            if not task_name or len(task_name) < 3:
                continue

            # Skip already attempted
            if task_name in self._attempted_tasks:
                continue

            # Parse JSONL entries
            tool_calls = 0
            blocked_calls = 0
            tool_names = []
            has_error = False
            has_final = False

            try:
                with open(log_file, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            entry = json.loads(line)
                        except json.JSONDecodeError:
                            continue

                        entry_type = entry.get("type", "")
                        data = entry.get("data", {})

                        if entry_type == "tool_call":
                            tool_calls += 1
                            tool_names.append(data.get("name", ""))

                        elif entry_type == "tool_result":
                            if data.get("error") == "budget_blocked":
                                blocked_calls += 1
                            elif data.get("error"):
                                has_error = True

                        elif entry_type == "final":
                            has_final = True

            except Exception:
                continue

            # Detect issues from parsed data

            # Issue: Wasteful tool usage (>=8 calls)
            if tool_calls >= 8:
                issues.append({
                    "type": "wasteful_tools",
                    "task_text": task_name,
                    "test_input": task_name,
                    "tool_count": tool_calls,
                    "stats": f"{tool_calls} tool calls",
                    "log_file": str(log_file),
                    "source": "jsonl",
                })

            # Issue: Duplicate/blocked calls (>=3 blocked)
            if blocked_calls >= 3:
                issues.append({
                    "type": "duplicate_calls",
                    "task_text": task_name,
                    "test_input": task_name,
                    "blocked_count": blocked_calls,
                    "stats": f"{blocked_calls} blocked calls out of {tool_calls} total",
                    "log_file": str(log_file),
                    "source": "jsonl",
                })

            # Issue: Same tool called repeatedly (anti-loop failure)
            if tool_names:
                from collections import Counter
                name_counts = Counter(tool_names)
                for name, count in name_counts.items():
                    if count >= 4 and name not in ("system_search",):
                        issues.append({
                            "type": "tool_loop",
                            "task_text": task_name,
                            "test_input": task_name,
                            "looped_tool": name,
                            "loop_count": count,
                            "stats": f"tool '{name}' called {count} times",
                            "log_file": str(log_file),
                            "source": "jsonl",
                        })
                        break  # One issue per log file

            # Issue: No final answer (task didn't complete)
            if not has_final and tool_calls > 0:
                issues.append({
                    "type": "incomplete_task",
                    "task_text": task_name,
                    "test_input": task_name,
                    "log_file": str(log_file),
                    "source": "jsonl",
                })

        # Deduplicate by task_text
        seen = set()
        unique = []
        for issue in issues:
            key = issue["task_text"]
            if key in seen or key in self._attempted_tasks:
                continue
            seen.add(key)
            unique.append(issue)

        return unique[:5]

    # -- DB Log Analysis --

    @staticmethod
    def _clean_task_text(text: str) -> str:
        """Remove XML tags and system context from task text."""
        if not text:
            return ""
        # Remove everything between XML tag pairs (conversation_history, etc.)
        clean = re.sub(r'<[^>]+>.*?</[^>]+>', '', text, flags=re.DOTALL)
        # Remove remaining standalone XML tags
        clean = re.sub(r'<[^>]+>', '', clean)
        # Truncate at system prompt fragments
        for prefix in ['IMPORTANT:', 'Recent conversation', 'ŞİMDİKİ GÖREV:',
                       'Önceki aşama', 'system_search', 'Tool budget:',
                       '[Turn', 'Assistant:', 'User:', 'tool_call',
                       'SİSTEM İPUCU', 'conversation history']:
            idx = clean.find(prefix)
            if idx >= 0:
                clean = clean[:idx]
        clean = clean.strip()
        # Skip if still looks like system text
        if clean.startswith("Recent") or clean.startswith("ŞİMDİKİ") or len(clean) < 5:
            return ""
        # Take first meaningful line
        for line in clean.split('\n'):
            line = line.strip()
            if len(line) >= 5 and not line.startswith('[') and not line.startswith('<'):
                return line[:200]
        return clean[:200]

    def _analyze_logs(self) -> list:
        """Find recent issues from DB logs using multiple detection methods."""
        issues = []
        try:
            self._memory_init()
            conn = self._db_connect()
            try:
                # Method 1: Bad feedback tasks
                rows = conn.execute("""
                    SELECT tf.task_outcome_id, tf.note, tf.rating,
                           t.task_text
                    FROM task_feedback tf
                    JOIN task_outcome t ON tf.task_outcome_id = t.id
                    WHERE tf.rating <= 1
                    ORDER BY tf.created_at DESC
                    LIMIT 5
                """).fetchall()
                for row in rows:
                    task_text = self._clean_task_text(row[3])
                    if len(task_text) < 5:
                        continue
                    issues.append({
                        "type": "bad_feedback",
                        "task_text": task_text,
                        "user_note": row[1],
                        "test_input": task_text,
                    })

                # Method 2: Wasteful tool usage (>6 calls in last 24h)
                rows = conn.execute("""
                    SELECT task_text, tool_calls_count, failure_reason
                    FROM task_outcome
                    WHERE tool_calls_count > 6
                      AND created_at > datetime('now', '-24 hours')
                    ORDER BY tool_calls_count DESC
                    LIMIT 5
                """).fetchall()
                for row in rows:
                    task_text = self._clean_task_text(row[0])
                    if len(task_text) < 5:
                        continue
                    issues.append({
                        "type": "wasteful_tools",
                        "task_text": task_text,
                        "test_input": task_text,
                        "tool_count": row[1],
                    })

                # Method 3: Budget exhausted tasks
                rows = conn.execute("""
                    SELECT task_text FROM task_outcome
                    WHERE failure_reason = 'budget_exhausted'
                      AND created_at > datetime('now', '-24 hours')
                    ORDER BY created_at DESC LIMIT 5
                """).fetchall()
                for row in rows:
                    task_text = self._clean_task_text(row[0])
                    if len(task_text) < 5:
                        continue
                    issues.append({
                        "type": "budget_exhausted",
                        "task_text": task_text,
                        "test_input": task_text,
                    })

                # Method 4: LLM API errors (context overflow etc.)
                rows = conn.execute("""
                    SELECT task_text, failure_reason FROM task_outcome
                    WHERE failure_reason = 'llm_api_error'
                      AND created_at > datetime('now', '-24 hours')
                    ORDER BY created_at DESC LIMIT 3
                """).fetchall()
                for row in rows:
                    task_text = self._clean_task_text(row[0])
                    if len(task_text) < 5:
                        continue
                    issues.append({
                        "type": "context_overflow",
                        "task_text": task_text,
                        "test_input": task_text,
                    })

                # Method 5: Hallucination warnings
                rows = conn.execute("""
                    SELECT task_text FROM task_outcome
                    WHERE (reflection LIKE '%hallucin%'
                       OR reflection LIKE '%UYARI%okunmadan%')
                      AND created_at > datetime('now', '-24 hours')
                    ORDER BY created_at DESC LIMIT 3
                """).fetchall()
                for row in rows:
                    task_text = self._clean_task_text(row[0])
                    if len(task_text) < 5:
                        continue
                    issues.append({
                        "type": "hallucination",
                        "task_text": task_text,
                        "test_input": task_text,
                    })

                # Method 6: Wrong decomposition
                rows = conn.execute("""
                    SELECT task_text FROM task_outcome
                    WHERE task_text NOT LIKE '%altındaki%'
                      AND task_text NOT LIKE '%içindeki%'
                      AND task_text NOT LIKE '%klasöründeki%'
                      AND reflection LIKE '%decompos%'
                      AND success = 0
                      AND created_at > datetime('now', '-24 hours')
                    ORDER BY created_at DESC LIMIT 3
                """).fetchall()
                for row in rows:
                    task_text = self._clean_task_text(row[0])
                    if len(task_text) < 5:
                        continue
                    issues.append({
                        "type": "wrong_decompose",
                        "task_text": task_text,
                        "test_input": task_text,
                    })

            finally:
                conn.close()
        except Exception:
            pass

        # Deduplicate by task_text and filter already attempted
        seen = set()
        unique = []
        for issue in issues:
            key = issue["task_text"]
            if key in seen or key in self._attempted_tasks:
                continue
            seen.add(key)
            unique.append(issue)

        # Defensive filter: skip entries that look like system content, not user input
        return self._filter_system_content(unique)[:5]

    @staticmethod
    def _filter_system_content(issues: list) -> list:
        """Remove issues whose task_text looks like system content, not user input."""
        _SKIP_PATTERNS = [
            'Turn 1', 'Turn 2', 'conversation history', 'conversation_history',
            'IMPORTANT:', 'ŞİMDİKİ GÖREV:', 'Önceki aşama',
            'system_search', 'Recent conversation', 'SİSTEM İPUCU',
            '<', '>', 'tool_call', 'function=', 'current_request',
            'Tool budget:', 'Assistant:', 'User:', 'tool_budget',
        ]
        filtered = []
        for issue in issues:
            txt = issue.get("task_text", "").strip()
            if len(txt) < 10:
                continue
            if txt.startswith("[") or txt.startswith("IMPORTANT"):
                continue
            if any(skip in txt for skip in _SKIP_PATTERNS):
                continue
            filtered.append(issue)
        return filtered

    # -- Test Runner --

    def _run_test(self, issue: dict) -> dict:
        """
        Test whether an issue is already fixed.

        For pre-fix: checks if the problem still exists.
        For post-fix (retest): checks if Claude Code's changes helped.
        """
        result = {"passed": False, "error": None, "details": ""}
        task_text = issue["test_input"]

        if issue["type"] == "wrong_decompose":
            try:
                from core.decomposer import decompose_compound_task
                subtasks = decompose_compound_task(task_text)
                result["passed"] = len(subtasks) == 0  # Should NOT decompose
                result["details"] = f"decomposed={len(subtasks) > 0}"
            except Exception as e:
                result["error"] = str(e)

        elif issue["type"] == "wasteful_tools":
            # Check if decomposer wrongly splits simple tasks
            try:
                from core.decomposer import decompose_compound_task
                subtasks = decompose_compound_task(task_text)
                # Simple tasks like "list dir", "cont log" should not decompose
                words = task_text.split()
                is_simple = len(words) <= 4
                if is_simple:
                    result["passed"] = len(subtasks) == 0
                    result["details"] = f"simple task, decomposed={len(subtasks) > 0}"
                else:
                    result["passed"] = True  # Complex task, can't fully test
                    result["details"] = "complex task, assumed OK"
            except Exception as e:
                result["error"] = str(e)

        elif issue["type"] == "duplicate_calls":
            # Check if prompt was strengthened (retest: check git diff)
            try:
                diff = subprocess.run(
                    ["git", "diff", "--stat"],
                    capture_output=True, text=True, timeout=10,
                    cwd=self._repo_root,
                )
                # If Claude Code made changes, consider it passed
                result["passed"] = len(diff.stdout.strip()) > 0
                result["details"] = diff.stdout.strip()[:200] if diff.stdout.strip() else "no changes"
            except Exception as e:
                result["error"] = str(e)

        elif issue["type"] == "context_overflow":
            # Check if truncation code exists in cont.py
            try:
                cont_path = os.path.join(self._repo_root, "cont.py")
                with open(cont_path, "r", encoding="utf-8") as f:
                    code = f.read()
                has_truncation = (
                    "_truncate_messages" in code
                    or "_ensure_context_fits" in code
                    or "ensure_context_fits" in code
                )
                result["passed"] = has_truncation
                result["details"] = "truncation function found" if has_truncation else "no truncation found"
            except Exception as e:
                result["error"] = str(e)

        elif issue["type"] == "hallucination":
            result["passed"] = False
            result["details"] = "hallucination requires LLM test"

        elif issue["type"] == "tool_loop":
            # Check if prompt was strengthened (retest: check git diff)
            try:
                diff = subprocess.run(
                    ["git", "diff", "--stat"],
                    capture_output=True, text=True, timeout=10,
                    cwd=self._repo_root,
                )
                result["passed"] = len(diff.stdout.strip()) > 0
                result["details"] = diff.stdout.strip()[:200] if diff.stdout.strip() else "no changes"
            except Exception as e:
                result["error"] = str(e)

        elif issue["type"] == "incomplete_task":
            result["passed"] = False
            result["details"] = "incomplete task requires LLM test"

        return result

    # -- Fix Generation --

    def _generate_fix(self, issue: dict, test_result: dict) -> dict:
        """Create a specific, actionable fix prompt for Claude Code."""

        if issue["type"] == "wrong_decompose":
            return {
                "type": "decomposer_fix",
                "prompt": (
                    f"Fix decompose_compound_task() in core/decomposer.py. "
                    f"Input: '{issue['task_text']}' "
                    f"Expected: No decomposition (simple task). "
                    f"Got: Decomposed into multiple phases. "
                    f"The regex is matching too broadly. "
                    f"Add this pattern to _NOT_LOCATION_TARGETS or fix the regex."
                ),
                "file": "core/decomposer.py",
            }

        elif issue["type"] == "duplicate_calls":
            return {
                "type": "duplicate_fix",
                "prompt": (
                    f"The task '{issue['task_text']}' caused "
                    f"{issue.get('stats', 'many')} duplicate blocked tool calls. "
                    f"The model keeps calling the same tool with same args "
                    f"even after getting blocked. "
                    f"\nRead cont.py and find the system prompt that tells "
                    f"the model not to repeat calls. Make it STRONGER. "
                    f"Add to the system prompt: "
                    f"'ASLA aynı tool+args tekrar çağırma. Blocked mesajı "
                    f"aldıysan FARKLI bir tool veya FARKLI parametreler kullan. "
                    f"3 kez blocked alırsan DUR ve cevap ver.'"
                ),
                "file": "cont.py",
            }

        elif issue["type"] == "wasteful_tools":
            return {
                "type": "wasteful_fix",
                "prompt": (
                    f"The task '{issue['task_text']}' used "
                    f"{issue.get('stats', 'too many')} tool calls. "
                    f"Simple tasks like 'list dir' or 'cont log' should "
                    f"need only 1-2 tool calls. "
                    f"\nRead the log file at {issue.get('log_file', '')} "
                    f"to see exactly which tools were called and why. "
                    f"Then fix the issue — it's usually one of: "
                    f"1. Decomposer wrongly splitting simple tasks "
                    f"2. System prompt not telling model to answer quickly "
                    f"3. Model searching when it already has the answer"
                ),
                "file": "cont.py",
            }

        elif issue["type"] == "context_overflow":
            return {
                "type": "overflow_fix",
                "prompt": (
                    f"The task '{issue['task_text']}' caused a context "
                    f"overflow error (model has 8192 token limit). "
                    f"\nFind ALL places in cont.py where messages are "
                    f"sent to the LLM. Before each API call, add "
                    f"truncation to keep total chars under 6000. "
                    f"Search for 'completions.create' or 'chat_completion'."
                ),
                "file": "cont.py",
            }

        elif issue["type"] == "hallucination":
            return {
                "type": "hallucination_fix",
                "prompt": (
                    f"Task '{issue['task_text']}' produced hallucinated content. "
                    f"Read cont.py and find _check_hallucination(). "
                    f"Strengthen it: if the model mentions file contents "
                    f"but read_file was never called for that file, flag it. "
                    f"Also add to the system prompt: "
                    f"'Dosya içeriği hakkında bilgi verme — önce read_file ile oku.'"
                ),
                "file": "cont.py",
            }

        elif issue["type"] == "tool_loop":
            looped = issue.get("looped_tool", "unknown")
            count = issue.get("loop_count", "many")
            return {
                "type": "tool_loop_fix",
                "prompt": (
                    f"Task '{issue['task_text']}' called tool '{looped}' {count} times. "
                    f"\nRead the log file at {issue.get('log_file', '')} "
                    f"to see why '{looped}' was called repeatedly. "
                    f"Then read cont.py and find the anti-loop guard. "
                    f"Fix: lower the repeat threshold for '{looped}' or "
                    f"add a stronger prompt rule: "
                    f"'Aynı tool 2 kez aynı args ile çağrıldıysa, "
                    f"sonuç değişmez. FARKLI bir yaklaşım dene.'"
                ),
                "file": "cont.py",
            }

        elif issue["type"] == "incomplete_task":
            return {
                "type": "incomplete_task_fix",
                "prompt": (
                    f"Task '{issue['task_text']}' started tool calls but never "
                    f"produced a final answer. "
                    f"\nRead the log file at {issue.get('log_file', '')} "
                    f"to see where the task got stuck. "
                    f"Then read cont.py run_task() and ensure the LLM "
                    f"response loop always produces a final text response, "
                    f"even when tools error out or budget is exhausted."
                ),
                "file": "cont.py",
            }

        return None

    # -- Fix Application --

    def _apply_fix(self, fix: dict) -> bool:
        """Observe-only: log suggestion, never apply.
        No Claude Code call, no recipe/episode, no task trigger.
        User must explicitly run /claude to apply fixes.
        """
        # Only in-memory — _log_entry in caller handles DB audit
        return False  # Never auto-apply

    def _rollback_fix(self, fix: dict):
        """Roll back failed fix with git checkout."""
        try:
            subprocess.run(
                ["git", "checkout", "--", "."],
                cwd=self._repo_root,
                capture_output=True,
                timeout=10,
            )
        except Exception:
            pass

    # -- Logging --

    def _log_entry(self, issue: dict, fix_type: str, success: bool, details: str):
        """Record an improvement attempt."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "issue_type": issue["type"],
            "task_text": issue["task_text"][:200],
            "fix_type": fix_type,
            "success": success,
            "details": details,
        }
        self._log.append(entry)

        # Also write to DB
        try:
            self._memory_init()
            conn = self._db_connect()
            try:
                conn.execute("""
                    INSERT INTO self_improve_log
                    (issue_type, task_text, fix_type, success, details_json)
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    issue["type"],
                    issue["task_text"][:200],
                    fix_type,
                    1 if success else 0,
                    json.dumps({"details": details}),
                ))
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass  # DB logging must never crash the loop

    def get_log(self) -> list:
        """Return session improvement log."""
        return list(self._log)

    def get_status(self) -> dict:
        """Return current loop status."""
        return {
            "running": self.running,
            "improvements_done": self._improvements_done,
            "max_improvements": self.MAX_IMPROVEMENTS,
            "log_entries": len(self._log),
        }
