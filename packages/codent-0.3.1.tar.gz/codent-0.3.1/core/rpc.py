#!/usr/bin/env python3
"""Cont RPC — CC'den gelen doğrulama çağrılarını işle.

Usage: cont --rpc <command> [--arg val ...]
Output: stdout'a JSON

Commands:
  check-notebook-sync   Notebook ↔ .py dosyası senkron mu
  check-type-consistency Cross-file tip uyumsuzluğu kontrolü
  verify-wheel-install  Wheel kurulabilirlik testi
  verify-before-publish PyPI yayın öncesi tam doğrulama
  ews-pipeline-test     EWS pipeline runtime testi
"""

import json
import os
import re
import subprocess
import sys
from pathlib import Path


def rpc_check_notebook_sync(project_dir: str = ".", py_file: str = None) -> dict:
    """Notebook ↔ .py dosyası senkron mu kontrol et."""
    project = Path(project_dir)
    issues = []

    # Tüm .py dosyaları veya tek dosya
    if py_file:
        py_files = [Path(py_file)]
    else:
        src = project / "src"
        py_files = list(src.rglob("*.py")) if src.exists() else list(project.rglob("*.py"))

    # Notebook'ları bul
    notebooks = {}
    for nb in project.rglob("*.ipynb"):
        if ".ipynb_checkpoints" in str(nb) or "_arsiv" in str(nb):
            continue
        notebooks[nb.stem] = nb

    for py in py_files:
        if py.name.startswith("_") or "test" in py.name:
            continue
        stem = py.stem

        # İlişkili notebook bul (nb_*_<stem>)
        related = [nb for name, nb in notebooks.items() if stem in name]
        if not related:
            continue

        for nb_path in related:
            py_mtime = py.stat().st_mtime
            nb_mtime = nb_path.stat().st_mtime

            if py_mtime > nb_mtime + 3600:  # .py 1 saatten yeni
                issues.append({
                    "py_file": str(py),
                    "notebook": str(nb_path),
                    "status": "warning",
                    "detail": f"{py.name} notebook'tan {(py_mtime-nb_mtime)/3600:.0f}h daha yeni",
                })

    return {"issues": issues, "count": len(issues), "status": "ok" if not issues else "warning"}


def rpc_check_type_consistency(project_dir: str = ".", symbol: str = "entity_id",
                                scope: str = "src/") -> dict:
    """Cross-file tip uyumsuzluğu kontrolü."""
    project = Path(project_dir) / scope
    conflicts = []

    # Sembolü tüm dosyalarda bul
    type_hints = {}  # file → detected_type
    try:
        result = subprocess.run(
            ["grep", "-rn", symbol, str(project), "--include=*.py", "--include=*.sql"],
            capture_output=True, text=True, timeout=10,
        )
        for line in result.stdout.splitlines():
            parts = line.split(":", 2)
            if len(parts) < 3:
                continue
            fpath, lineno, content = parts

            # Tip çıkarımı
            detected = None
            content_up = content.upper()
            if "BIGINT" in content_up:
                detected = "BIGINT"
            elif "VARCHAR" in content_up:
                detected = "VARCHAR"
            elif "INTEGER" in content_up or "INT" in content_up:
                detected = "INTEGER"
            elif ": str" in content or "-> str" in content:
                detected = "str"
            elif ": int" in content or "-> int" in content:
                detected = "int"
            elif "CAST" in content_up and "AS" in content_up:
                m = re.search(r"AS\s+(\w+)", content_up)
                if m:
                    detected = m.group(1)

            if detected:
                type_hints.setdefault(fpath, set()).add(detected)

    except Exception:
        pass

    # Tutarsızlık kontrolü
    all_types = set()
    for types in type_hints.values():
        all_types |= types

    if len(all_types) > 1:
        for fpath, types in type_hints.items():
            for t in types:
                conflicts.append({"file": fpath, "type": t})

    consistent = len(all_types) <= 1
    return {
        "symbol": symbol,
        "consistent": consistent,
        "types_found": list(all_types),
        "conflicts": conflicts[:20],
        "files_checked": len(type_hints),
    }


def rpc_verify_wheel_install(project_dir: str = ".", dist_dir: str = "dist/") -> dict:
    """Wheel kurulabilirlik ve içerik kontrolü."""
    dist = Path(project_dir) / dist_dir
    issues = []

    wheels = list(dist.glob("*.whl"))
    if not wheels:
        return {"passed": False, "issues": ["dist/ dizininde wheel bulunamadı"]}

    wheel = wheels[-1]  # En son wheel

    # Wheel içeriğini kontrol et
    import zipfile
    with zipfile.ZipFile(wheel) as zf:
        names = zf.namelist()

        # .so kontrolü
        so_files = [n for n in names if n.endswith(".so") or n.endswith(".pyd")]
        if so_files:
            issues.append(f".so dosyası wheel'da: {so_files[:3]}")

        # __pycache__ kontrolü
        cache_files = [n for n in names if "__pycache__" in n]
        if cache_files:
            issues.append(f"__pycache__ wheel'da: {len(cache_files)} dosya")

    # Kurulabilirlik testi
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", str(wheel), "--target", tmp, "--no-deps", "-q"],
            capture_output=True, text=True, timeout=30,
        )
        if r.returncode != 0:
            issues.append(f"Kurulum hatası: {r.stderr[:200]}")

    return {"passed": len(issues) == 0, "wheel": wheel.name, "issues": issues}


def rpc_verify_before_publish(project_dir: str = ".", dist_dir: str = "dist/",
                               src_dir: str = "src/") -> dict:
    """PyPI yayın öncesi tam doğrulama."""
    blockers = []
    warnings = []

    # 1. Wheel kontrolü
    wheel_result = rpc_verify_wheel_install(project_dir, dist_dir)
    if not wheel_result["passed"]:
        blockers.extend(wheel_result["issues"])

    # 2. Versiyon kontrolü
    project = Path(project_dir)
    pyproject = project / "pyproject.toml"
    if pyproject.exists():
        content = pyproject.read_text()
        m = re.search(r'version\s*=\s*"([^"]+)"', content)
        if m:
            version = m.group(1)
            # Git tag ile karşılaştır
            r = subprocess.run(["git", "tag", "-l", f"v{version}"], capture_output=True, text=True,
                               cwd=project_dir, timeout=5)
            if f"v{version}" not in r.stdout:
                warnings.append(f"Git tag v{version} yok — oluştur: git tag v{version}")

    # 3. README kontrolü
    if not (project / "README.md").exists():
        warnings.append("README.md yok")

    publish_ok = len(blockers) == 0
    return {"publish_ok": publish_ok, "blockers": blockers, "warnings": warnings}


def rpc_ews_pipeline_test(project_dir: str = ".", db_path: str = None) -> dict:
    """EWS pipeline runtime testi."""
    project = Path(project_dir)

    if not db_path:
        db_path = str(project / "db" / "ews.duckdb")

    if not Path(db_path).exists():
        return {"passed": False, "error": f"DB bulunamadı: {db_path}"}

    steps = []

    # Temel tablo kontrolleri
    import duckdb
    try:
        con = duckdb.connect(db_path, read_only=True)
        tables = [t[0] for t in con.execute("SHOW TABLES").fetchall()]

        required = ["fact_periodic", "dim_entity", "map_identity"]
        for t in required:
            if t in tables:
                count = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                ok = count > 0
                steps.append({"step": f"table_{t}", "passed": ok, "rows": count})
            else:
                steps.append({"step": f"table_{t}", "passed": False, "error": "tablo yok"})

        # Veri tutarlılık kontrolü
        if "fact_periodic" in tables and "dim_entity" in tables:
            orphans = con.execute("""
                SELECT COUNT(*) FROM fact_periodic f
                LEFT JOIN dim_entity d ON f.entity_id = d.entity_id
                WHERE d.entity_id IS NULL
            """).fetchone()[0]
            steps.append({"step": "fk_integrity", "passed": orphans == 0, "orphans": orphans})

        con.close()
    except Exception as e:
        steps.append({"step": "db_connect", "passed": False, "error": str(e)})

    all_passed = all(s["passed"] for s in steps)
    return {"passed": all_passed, "steps": steps, "total": len(steps)}


# ── CLI handler ──

def handle_rpc(args: list[str]) -> dict:
    """Parse RPC args and dispatch."""
    if not args:
        return {"status": "error", "message": "Komut gerekli. Kullanım: cont --rpc <command>"}

    command = args[0]
    kwargs = {}
    i = 1
    while i < len(args):
        if args[i].startswith("--") and i + 1 < len(args):
            key = args[i][2:].replace("-", "_")
            kwargs[key] = args[i + 1]
            i += 2
        else:
            i += 1

    handlers = {
        "check-notebook-sync": rpc_check_notebook_sync,
        "check-type-consistency": rpc_check_type_consistency,
        "verify-wheel-install": rpc_verify_wheel_install,
        "verify-before-publish": rpc_verify_before_publish,
        "ews-pipeline-test": rpc_ews_pipeline_test,
    }

    handler = handlers.get(command)
    if not handler:
        return {"status": "error", "message": f"Bilinmeyen komut: {command}",
                "available": list(handlers.keys())}

    return handler(**kwargs)


if __name__ == "__main__":
    result = handle_rpc(sys.argv[1:])
    print(json.dumps(result, indent=2, default=str))
