# core/lmstudio.py
"""LM Studio model management — probe, load, unload, eject-before-load guard."""

import time
from typing import Optional

import requests

from core.utils import debug as _debug


def _get_base(base_url: str) -> str:
    """OpenAI compat base_url'den LM Studio API base'i çıkar."""
    # http://host:1234/v1 → http://host:1234
    return base_url.rstrip("/").removesuffix("/v1")


def _lmstudio_get_loaded(base_url: str) -> list[str]:
    """Şu anda yüklü olan modellerin ID'lerini döndür."""
    try:
        base = _get_base(base_url)
        resp = requests.get(f"{base}/api/v0/models", timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            return [m["id"] for m in data.get("data", []) if m.get("state") == "loaded"]
    except Exception as e:
        _debug(f"LM Studio get_loaded error: {e}")
    return []


def _probe_lmstudio_unload(base_url: str) -> bool:
    """LM Studio API v0/v1 desteğini kontrol et."""
    try:
        base = _get_base(base_url)
        resp = requests.get(f"{base}/api/v0/models", timeout=5)
        return resp.status_code == 200
    except Exception:
        return False


def _lmstudio_eject_all(base_url: str) -> int:
    """Tüm yüklü modelleri eject et. Kaç model eject edildiğini döndür."""
    loaded = _lmstudio_get_loaded(base_url)
    ejected = 0
    for model_id in loaded:
        if _lmstudio_unload_model(base_url, model_id):
            ejected += 1
            time.sleep(1)
    return ejected


def _lmstudio_unload_model(base_url: str, model_id: str) -> bool:
    """Model'i LM Studio'dan kaldır (eject)."""
    try:
        base = _get_base(base_url)
        _debug(f"Unloading model: {model_id}")
        resp = requests.post(
            f"{base}/api/v1/models/unload",
            json={"instance_id": model_id},
            timeout=30,
        )
        if resp.status_code == 200:
            _debug(f"Model {model_id} unloaded")
            return True
        else:
            _debug(f"Unload failed: HTTP {resp.status_code} {resp.text[:100]}")
            return False
    except Exception as e:
        _debug(f"Unload error: {e}")
        return False


def _lmstudio_load_model(base_url: str, model_id: str,
                          context_length: int = 10000,
                          eject_others: bool = True) -> bool:
    """Model yükle. eject_others=True ise önce diğer modelleri kaldır (üst üste binme koruması)."""
    # Üst üste binme koruması — VRAM paylaşımını engelle
    if eject_others:
        loaded = _lmstudio_get_loaded(base_url)
        others = [m for m in loaded if m != model_id]
        if others:
            _debug(f"Eject-before-load guard: {others} kaldırılıyor")
            for other in others:
                _lmstudio_unload_model(base_url, other)
                time.sleep(2)

        # Zaten yüklüyse tekrar yüklemeye gerek yok
        if model_id in loaded:
            _debug(f"Model {model_id} zaten yüklü, skip")
            return True

    try:
        base = _get_base(base_url)
        _debug(f"Loading model: {model_id} (ctx={context_length})")
        resp = requests.post(
            f"{base}/api/v1/models/load",
            json={"model": model_id, "context_length": context_length},
            timeout=600,
        )
        if resp.status_code == 200:
            _debug(f"Model {model_id} loaded ({resp.json().get('load_time_seconds', '?')}s)")
            return True
        else:
            _debug(f"Load failed: HTTP {resp.status_code} {resp.text[:100]}")
            return False
    except Exception as e:
        _debug(f"Load error: {e}")
        return False


def _lmstudio_ensure_model(base_url: str, model_id: str,
                            context_length: int = 10000) -> bool:
    """Model'in yüklü olduğunu garanti et. Değilse yükle (önce diğerlerini eject et).

    Ollama backend'inde no-op (Ollama otomatik yükler).
    """
    # Ollama backend → no-op
    if "11434" in base_url:
        return True
    loaded = _lmstudio_get_loaded(base_url)
    if model_id in loaded:
        _debug(f"Model {model_id} zaten yüklü ✓")
        return True
    return _lmstudio_load_model(base_url, model_id, context_length, eject_others=True)
