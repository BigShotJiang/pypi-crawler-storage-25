#!/usr/bin/env python3
"""Feedback aktif eğitim — külliyat + R1 tekrar, feedback metrikleri."""

import json, os, re, sys, time
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(str(PROJECT_ROOT))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

DB = "/home/sertan/projects/ews_v511/ews_dashboard/db/ews.duckdb"
RESULTS_DIR = PROJECT_ROOT / ".cont" / "hive" / "runs" / "training"
TRAIL_PATH = PROJECT_ROOT / ".cont" / "hive" / "pheromone" / "trail.jsonl"


def run_cont(task):
    t0 = time.time()
    try:
        from cont import run_task
        answer, success = run_task(task)
        return {
            "answer": answer or "", "elapsed": round(time.time()-t0, 1),
            "tools": len(getattr(run_task, '_last_tools_used', []) or []),
            "recipe": getattr(run_task, '_last_recipe_id', None),
        }
    except Exception as e:
        return {"answer": f"ERROR:{e}", "elapsed": round(time.time()-t0, 1), "tools": 0, "recipe": None}


def score(answer, check_fn):
    if not answer or "ERROR" in answer: return 0
    if not check_fn(answer): return 1
    has_num = len(re.findall(r'\d{3,}', answer)) >= 2
    l = len(answer)
    if has_num and l > 300: return 5
    if has_num and l > 100: return 4
    if has_num: return 3
    return 2


def check_feedback():
    """Son trail satırında recipe_id var mı?"""
    try:
        last = TRAIL_PATH.read_text().splitlines()[-1]
        e = json.loads(last)
        has_rid = bool(e.get("recipe_id"))
        return {"recipe_id": e.get("recipe_id"), "has_recipe_id": has_rid}
    except Exception:
        return {"recipe_id": None, "has_recipe_id": False}


def count_yaml_updates():
    """YAML'da success+fail > 0 olan reçete sayısı."""
    import yaml
    recipes_dir = PROJECT_ROOT / ".cont" / "hive" / "recipes"
    total, updated = 0, 0
    for f in recipes_dir.rglob("*.yaml"):
        try:
            d = yaml.safe_load(f.read_text())
            if not d: continue
            total += 1
            if d.get("success_count", 0) + d.get("fail_count", 0) > 0:
                updated += 1
        except: pass
    return updated, total


def T(task): return task.replace("$DB", DB)


# ═══════════════════════════════
# KÜLLIYAT (from curriculum_runner)
# ═══════════════════════════════

from core.curriculum_runner import ALL_TASKS, LEVEL_NAMES


def run_curriculum_with_feedback():
    """33 görev, sadece Hive, feedback izleme."""
    print("█" * 60)
    print("  İŞ 1: KÜLLIYAT — FEEDBACK AKTİF")
    print("█" * 60)

    trail_before = len(TRAIL_PATH.read_text().splitlines()) if TRAIL_PATH.exists() else 0
    yaml_before, _ = count_yaml_updates()

    level_scores = {}
    all_results = []

    for level in sorted(ALL_TASKS.keys()):
        tasks = ALL_TASKS[level]
        name = LEVEL_NAMES[level]
        level_total = 0

        print(f"\n  Seviye {level}: {name}")
        for t in tasks:
            r = run_cont(t["task"])
            s = score(r["answer"], t["accept"])
            fb = check_feedback()
            level_total += s
            all_results.append({
                "id": t["id"], "level": level, "score": s,
                "recipe": r["recipe"], "feedback_ok": fb["has_recipe_id"],
            })
            rid_icon = "✓" if fb["has_recipe_id"] else "·"
            print(f"    {t['id']}: {s}/5 | recipe={r['recipe'] or '–':15s} | trail_rid={rid_icon} | {r['elapsed']:.0f}s")
            time.sleep(1)

        mx = len(tasks) * 5
        level_scores[level] = {"score": level_total, "max": mx, "name": name}

    # Feedback metrikleri
    trail_after = len(TRAIL_PATH.read_text().splitlines()) if TRAIL_PATH.exists() else 0
    yaml_after, yaml_total = count_yaml_updates()
    new_trail_entries = trail_after - trail_before
    new_yaml_updates = yaml_after - yaml_before

    # Recipe_id olan trail satırları (yeni eklenenler)
    recipe_id_count = 0
    if TRAIL_PATH.exists():
        for line in TRAIL_PATH.read_text().splitlines()[-new_trail_entries:]:
            try:
                if json.loads(line).get("recipe_id"):
                    recipe_id_count += 1
            except: pass

    total_score = sum(ls["score"] for ls in level_scores.values())
    total_max = sum(ls["max"] for ls in level_scores.values())

    print(f"\n{'═'*50}")
    print(f"KÜLLIYAT SONUCU: {total_score}/{total_max}")
    print(f"{'═'*50}")
    for level in sorted(level_scores.keys()):
        ls = level_scores[level]
        print(f"  {level}. {ls['name']:<17s} {ls['score']:>3d}/{ls['max']}")

    print(f"\nFeedback metrikleri:")
    print(f"  Trail yeni satır: {new_trail_entries}")
    print(f"  Trail recipe_id: {recipe_id_count}/{new_trail_entries}")
    print(f"  YAML güncellenen: {yaml_before}→{yaml_after} (+{new_yaml_updates})")

    return {
        "total": total_score, "max": total_max,
        "levels": level_scores, "results": all_results,
        "feedback": {
            "trail_new": new_trail_entries, "trail_recipe_id": recipe_id_count,
            "yaml_updated": yaml_after, "yaml_total": yaml_total,
        },
    }


# ═══════════════════════════════
# R1 TEKRAR (knowledge ile)
# ═══════════════════════════════

R1_TASKS = [
    {"q": T("fact_periodic ($DB): her kolonu açıkla — adı, tipi, ne işe yarıyor, NULL ise nedeni"),
     "check": lambda r: sum(1 for c in ["entity_id","donem","yis_skor","eus_skor","ews_skor","kombine_risk","ykn_izl_flag"] if c in r) >= 5},
    {"q": T("fact_periodic ($DB): hangi kolonlar kategorik (VARCHAR), hangileri sayısal? DESCRIBE kullan."),
     "check": lambda r: any(w in r.upper() for w in ["VARCHAR","INTEGER","DOUBLE","BIGINT"]) and any(w in r.lower() for w in ["kategorik","sayısal","numeric","categorical","varchar","string"])},
    {"q": T("fact_periodic ($DB): NULL oranı en yüksek 5 kolon hangisi? Her birinin NULL NEDENİ ne? (ör: yis_skor NULL → firma EUS havuzunda)"),
     "check": lambda r: any(w in r.lower() for w in ["null","%","oran"]) and any(w in r.lower() for w in ["neden","çünkü","because","havuz","kapsam"])},
    {"q": T("fact_periodic ve dim_entity ($DB): entity_id tipi ne? Neden önemli? JOIN'de ne olur?"),
     "check": lambda r: any(w in r.upper() for w in ["VARCHAR","BIGINT"]) and any(w in r.lower() for w in ["join","cast","uyumsuz","tip","önemli"])},
    {"q": T("fact_periodic ($DB): kaç dönem var, her dönemde kaç firma, MIN/MAX donem?"),
     "check": lambda r: any(w in r.lower() for w in ["dönem","donem"]) and any(c.isdigit() for c in r)},
]

R1_EXTRA = [
    {"q": T("entity_id VARCHAR mı BIGINT mı, neden önemli? ($DB)"),
     "check": lambda r: any(w in r.upper() for w in ["VARCHAR","BIGINT"]) and any(w in r.lower() for w in ["önemli","join","cast","silent","null"])},
    {"q": T("ews_kaynak='eus' olan firmalar hangi skor bandında yoğun? ($DB)"),
     "check": lambda r: any(w in r.lower() for w in ["eus","band","0-325","325-500","yoğun","dağılım"])},
    {"q": T("ykn_izl_flag ile ews_skor='YI' arasındaki fark ne? ($DB)"),
     "check": lambda r: any(w in r.lower() for w in ["flag","yi","fark","istisna","anomali","ilişki"])},
    {"q": T("kombine_risk negatif olabilir mi? ($DB) Kontrol et."),
     "check": lambda r: any(w in r.lower() for w in ["negatif","0","yok","olamaz","olmamalı","hata"])},
    {"q": T("Aynı firmada hem EUS hem YIS skoru olabilir mi? Aynı dönemde? ($DB)"),
     "check": lambda r: any(w in r.lower() for w in ["olamaz","hayır","bir","tek","aynı dönem","farklı dönem","geçiş"])},
]


def run_r1_with_knowledge():
    """R1 tekrar + ekstra sorular, knowledge aktif."""
    print("\n" + "█" * 60)
    print("  İŞ 2: R1 TEKRAR + EKSTRA (knowledge aktif)")
    print("█" * 60)

    # R1 orijinal
    print("\n  R1 Orijinal (5 görev):")
    r1_scores = []
    for i, t in enumerate(R1_TASKS):
        r = run_cont(t["q"])
        s = score(r["answer"], t["check"])
        fb = check_feedback()
        print(f"    R1.{i+1}: {s}/5 | {'✓' if t['check'](r['answer']) else '✗'} | {r['elapsed']:.0f}s")
        r1_scores.append(s)
        time.sleep(1)

    r1_total = sum(r1_scores)
    print(f"  R1 toplam: {r1_total}/25 (önceki: 15/25)")

    # R1 ekstra
    print("\n  R1 Ekstra (5 zor soru):")
    extra_scores = []
    for i, t in enumerate(R1_EXTRA):
        r = run_cont(t["q"])
        s = score(r["answer"], t["check"])
        print(f"    X{i+1}: {s}/5 | {'✓' if t['check'](r['answer']) else '✗'} | {r['elapsed']:.0f}s")
        extra_scores.append(s)
        time.sleep(1)

    extra_total = sum(extra_scores)
    print(f"  Ekstra toplam: {extra_total}/25")

    return {"r1": r1_total, "r1_max": 25, "extra": extra_total, "extra_max": 25}


# ═══════════════════════════════

def main():
    t0 = time.time()

    curriculum = run_curriculum_with_feedback()
    r1 = run_r1_with_knowledge()

    # Fitness dağılımı
    from core.fitness import all_fitness
    fit = all_fitness()
    high = sum(1 for f in fit if f["fitness"] >= 0.9 and f["success"]+f["fail"] > 0)
    mid = sum(1 for f in fit if 0.5 <= f["fitness"] < 0.9 and f["success"]+f["fail"] > 0)
    low = sum(1 for f in fit if f["fitness"] < 0.5 and f["success"]+f["fail"] > 0)
    untested = sum(1 for f in fit if f["success"]+f["fail"] == 0)
    from core.fitness import evaporation_candidates
    evap = evaporation_candidates()

    # Sabah raporu
    print("\n" + "█" * 60)
    print("  SABAH RAPORU")
    print("█" * 60)
    print(f"\n  Külliyat: {curriculum['total']}/{curriculum['max']} (önceki: 90/160)")
    delta = curriculum['total'] - 90
    print(f"  Δ: {'+' if delta>=0 else ''}{delta}")
    print(f"\n  R1: {r1['r1']}/25 (önceki: 15/25)")
    print(f"  R1 ekstra: {r1['extra']}/25")
    print(f"\n  Feedback metrikleri:")
    fb = curriculum['feedback']
    print(f"    Trail recipe_id: {fb['trail_recipe_id']}/{fb['trail_new']}")
    print(f"    YAML güncellenen: {fb['yaml_updated']}/{fb['yaml_total']}")
    print(f"\n  Fitness dağılımı:")
    print(f"    Güvenilir (≥0.9): {high}")
    print(f"    Orta (0.5-0.9): {mid}")
    print(f"    Düşük (<0.5): {low}")
    print(f"    Untested: {untested}")
    print(f"    Buharlaşma adayı: {len(evap)}")
    print(f"\n  Süre: {(time.time()-t0)/60:.0f} dakika")

    out = RESULTS_DIR / f"feedback_training_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    out.write_text(json.dumps({
        "curriculum": {k: v for k, v in curriculum.items() if k != "results"},
        "r1": r1,
        "fitness": {"high": high, "mid": mid, "low": low, "untested": untested, "evap": len(evap)},
    }, indent=2, ensure_ascii=False, default=str))
    print(f"  JSON: {out}")


if __name__ == "__main__":
    main()
