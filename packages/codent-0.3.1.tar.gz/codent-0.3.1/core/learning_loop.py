# core/learning_loop.py
"""Öğrenme döngüsü — başarısız görevden otomatik reçete üretimi.

5 adım: otopsi → bilgi arama → bilgi edinme → reçete yaz → test et.
Ayrı bütçe (12 call, ana görevden bağımsız). LLM minimal.
"""

import json
from datetime import datetime
from pathlib import Path

from core.utils import debug as _debug

HIVE_DIR = Path(__file__).parent.parent / ".cont" / "hive"
TRAIL_PATH = HIVE_DIR / "pheromone" / "trail.jsonl"


class LearningLoop:
    """Cont kendi kendine öğrenir. CC müdahalesi yok."""

    def run(self, failed_task_info: dict) -> dict:
        """5 adımlı öğrenme döngüsü."""
        _debug("[LEARNING] Öğrenme döngüsü başladı")

        # ADIM 1: Otopsi
        autopsy = self.analyze_failure(failed_task_info)
        _debug(f"[LEARNING] Otopsi: {autopsy['failure_point']}, "
               f"wasted={autopsy['wasted_calls']}/{autopsy['total_calls']}")

        # ADIM 2: Bilgi arama
        gap = self.find_knowledge_gap(autopsy)
        _debug(f"[LEARNING] Gap: {gap.get('missing_keywords', [])[:3]}")

        # ADIM 3: Bilgi edinme
        self.acquire_knowledge(gap)

        # ADIM 4: Reçete yaz
        recipe_path = self.create_recipe(autopsy, gap, failed_task_info)

        # ADIM 5: Logla
        self._log_learning(failed_task_info, autopsy, gap, recipe_path)

        if recipe_path:
            return {"result": "LEARNED", "recipe": str(recipe_path)}
        return {"result": "LOGGED", "gap": gap}

    def analyze_failure(self, task_info: dict) -> dict:
        """Deterministik log analizi."""
        log_path = task_info.get("log_path")
        tool_calls = []
        failures = []
        successes = []

        if log_path and Path(log_path).exists():
            for line in Path(log_path).read_text(encoding="utf-8").splitlines():
                try:
                    e = json.loads(line)
                    if e.get("type") == "tool_call":
                        tool_calls.append(e)
                    if e.get("blocked") or e.get("error"):
                        failures.append(e)
                    if e.get("success"):
                        successes.append(e)
                except Exception:
                    continue

        # Tekrar eden call'lar
        call_sigs = [json.dumps(tc.get("data", {}), sort_keys=True) for tc in tool_calls]
        duplicates = len(call_sigs) - len(set(call_sigs))

        # Tıkanma noktası
        fail_tools = [f.get("data", {}).get("name", "") for f in failures]
        failure_point = max(set(fail_tools), key=fail_tools.count) if fail_tools else "unknown"

        return {
            "failure_point": failure_point,
            "total_calls": len(tool_calls),
            "wasted_calls": duplicates,
            "successful_calls": len(successes),
            "task_type": task_info.get("task_type", "unknown"),
        }

    def find_knowledge_gap(self, autopsy: dict) -> dict:
        """Activation gap + recipe search."""
        missing_kw = []
        similar_recipe = None

        # Activation gap log
        gap_log = HIVE_DIR / "runs" / "activation_gaps.jsonl"
        if gap_log.exists():
            for line in gap_log.read_text(encoding="utf-8").splitlines()[-50:]:
                try:
                    e = json.loads(line)
                    kw = e.get("keyword", "")
                    if kw and kw not in missing_kw:
                        missing_kw.append(kw)
                except Exception:
                    continue

        # Benzer reçete
        try:
            from core.recipe_learner import find_similar_recipe
            match = find_similar_recipe(
                missing_kw[:5],
                [autopsy.get("failure_point", "")],
                threshold=0.3,
            )
            if match:
                similar_recipe = match.get("recipe_name")
        except Exception:
            pass

        return {
            "missing_keywords": missing_kw[:10],
            "similar_recipe": similar_recipe,
        }

    def acquire_knowledge(self, gap: dict):
        """Activation map'e eksik keyword ekle."""
        try:
            from core.spreading_activation import invalidate_cache
            import yaml

            missing = gap.get("missing_keywords", [])
            if not missing:
                return

            map_path = HIVE_DIR / "knowledge" / "activation_map.yaml"
            if not map_path.exists():
                return

            data = yaml.safe_load(map_path.read_text(encoding="utf-8"))
            if "auto_learned" not in data:
                data["auto_learned"] = {}

            added = 0
            for kw in missing[:3]:
                if kw not in data.get("auto_learned", {}) and kw not in data.get("activation", {}):
                    data["auto_learned"][kw] = {
                        "files": [],
                        "priority": "medium",
                        "source": "learning_loop",
                        "learned_from": f"learn_{datetime.now().strftime('%Y%m%d_%H%M')}",
                    }
                    added += 1

            if added:
                map_path.write_text(yaml.dump(data, allow_unicode=True,
                                               default_flow_style=False, sort_keys=False), encoding="utf-8")
                invalidate_cache()
                _debug(f"[LEARNING] {added} keyword eklendi")
        except Exception as e:
            _debug(f"[LEARNING] acquire_knowledge error: {e}")

    def create_recipe(self, autopsy: dict, gap: dict, task_info: dict) -> str | None:
        """Başarısız görevden ham reçete üret."""
        try:
            from core.recipe_learner import post_task_recipe
            task_text = task_info.get("task", "")
            tools = task_info.get("tools_used", [])
            if tools:
                return post_task_recipe(task_text, tools, True, 0, None)
        except Exception:
            pass
        return None

    def _log_learning(self, task_info: dict, autopsy: dict, gap: dict, recipe_path: str | None):
        """Öğrenme sonucunu trail'e logla."""
        try:
            entry = {
                "event": "learning_loop",
                "ts": datetime.now().isoformat(),
                "task_type": autopsy.get("task_type", "unknown"),
                "failure_point": autopsy.get("failure_point", "unknown"),
                "wasted_calls": autopsy.get("wasted_calls", 0),
                "missing_keywords": gap.get("missing_keywords", [])[:5],
                "recipe_created": recipe_path is not None,
                "result": "LEARNED" if recipe_path else "LOGGED",
            }
            TRAIL_PATH.parent.mkdir(parents=True, exist_ok=True)
            with open(TRAIL_PATH, "a") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            pass
