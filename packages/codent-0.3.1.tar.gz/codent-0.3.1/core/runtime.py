# core/runtime.py
"""
Runtime helpers for task execution.

Contains:
- Input preprocessing (decomposer gate, retry detection)
- Post-processing (hallucination check, denial detection)
- Result extraction utilities
- Self-assessment
- RuntimeContext bridge for run_task pipeline (moved from cont.py)

Helpers (sections 1-8): DI via init_runtime(). No direct cont.py imports.
run_task pipeline (sections 9+): DI via RuntimeContext (ctx bridge).
"""

import hashlib
import json
import os
import re
import select
import subprocess
import sys
import threading
import itertools
import time
from collections import deque
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from rich import print as rprint

from core.trace import (
    is_off as _trace_off, get_level as _trace_level, TraceLevel,
    trace_llm_request, trace_llm_response,
    trace_tool_call, trace_tool_result,
    trace_story_intent, trace_story_observed,
    trace_memory_recall,
)
try:
    from core.memory_gate import try_memory_gate
except ImportError:
    try_memory_gate = None  # type: ignore[assignment]

# ── Direct imports from core/ modules (unconditional, no circular deps) ──
from core.formatters import (
    FINALIZE_MARKER,
    build_bare_system_prompt, build_format_system_prompt,
    build_browser_format_system_prompt, build_browser_rescue_system_prompt,
    build_summarize_system_prompt, build_summarize_user_prompt,
    build_browser_user_prompt,
    is_greeting_response, sanitize_response as _sanitize_response,
    budget_nearly_exhausted_msg, budget_exhausted_msg,
    read_blocked_msg, tool_blocked_msg, tool_blocked_path_hint,
    tool_limit_reached_msg, tool_limit_system_inject_msg,
    phase_checkpoint_msg, all_phases_exhausted_msg,
    too_many_blocks_msg, task_reminder_msg,
    empty_response_msg, security_blocked_msg, unknown_tool_msg,
)
from core.tool_budget import DynamicToolBudget
from core.tools import normalize_tool_call, PER_TOOL_CAPS, _TOOL_ALTERNATIVES, _TOOL_NAME_ALIASES
from core.router import extract_raw_input, extract_url, extract_goal
from core.intent_detection import DESTRUCTIVE_TOOLS
from core.file_context import resolve_file_context
from core.utils import clean_surrogates


# ── Knowledge-based recipe guard verbs (anti-pattern #7 fix) ──
_RECIPE_GUARD_CACHE: dict | None = None

def _load_recipe_guard_verbs() -> tuple[set, set]:
    """Load task verbs and question markers from knowledge YAML.
    Falls back to empty sets if file missing (guardian will catch).
    """
    global _RECIPE_GUARD_CACHE
    if _RECIPE_GUARD_CACHE is not None:
        return _RECIPE_GUARD_CACHE["task_verbs"], _RECIPE_GUARD_CACHE["question_markers"]

    yaml_path = Path(__file__).parent.parent / ".cont" / "hive" / "knowledge" / "recipe_guard_verbs.yaml"
    task_verbs: set = set()
    question_markers: set = set()
    if yaml_path.exists():
        import yaml
        with open(yaml_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        task_verbs = set(data.get("task_verbs", []))
        question_markers = set(data.get("question_markers", []))
    _RECIPE_GUARD_CACHE = {"task_verbs": task_verbs, "question_markers": question_markers}
    return task_verbs, question_markers
from core.postprocess import check_hallucination, detect_false_success, postprocess_response, DENIAL_PATTERNS, _DENIAL_RE
from core.context_utils import build_conversation_context, _genesis_prompt_suffix, _actionable_llm_error, extract_file_paths_from_results
from core.tool_helpers import (
    _is_stopword_only_query,
    _classify_llm_error, _recover_tool_json, extract_fenced_tool_requests,
    extract_malformed_tool_calls, _extract_domain_from_args,
    check_tool_error_recovery, _sanitize_role_alternation,
    _build_allowed_vocab, _sanitize_tool_args,
    _llm_summarize, ask_claude_tool,
)
from core.task_utils import (
    should_decompose, extract_dir_from_results, load_files_for_summary,
    self_assess, save_feedback, process_feedback_for_learning,
    learn_from_chain, handle_feedback_command,
    _self_improve_reflect, _self_improve_record,
)


_debug_fn: Callable = lambda msg: None
_console: Any = None
_llm_complete_fn: Optional[Callable] = None
_model: str = ""
_memory_remember_fn: Optional[Callable] = None
_memory_init_db_fn: Optional[Callable] = None
_db_connect_fn: Optional[Callable] = None

def init_runtime(
    *,
    debug_fn: Callable = None,
    console: Any = None,
    llm_complete_fn: Callable = None,
    model: str = "",
    memory_remember_fn: Callable = None,
    memory_init_db_fn: Callable = None,
    db_connect_fn: Callable = None,
):
    """Initialize runtime helpers with dependencies from cont.py."""
    global _debug_fn, _console, _llm_complete_fn, _model
    global _memory_remember_fn, _memory_init_db_fn, _db_connect_fn

    if debug_fn:
        _debug_fn = debug_fn
    _console = console
    _llm_complete_fn = llm_complete_fn
    _model = model
    _memory_remember_fn = memory_remember_fn
    _memory_init_db_fn = memory_init_db_fn
    _db_connect_fn = db_connect_fn

# ═══════════════════════════════════════════════════════════════
# RuntimeContext — ctx bridge for run_task pipeline
# ═══════════════════════════════════════════════════════════════

class RuntimeContext:
    """Container for all cont.py globals needed by the run_task pipeline.

    Created by cont.py's _build_ctx() before each run_task call.
    All fields set dynamically via __init__(**kw).

    Expected fields (grouped by category):
      Core: console, debug_fn, model, client, repo_root
      LLM: llm_complete_fn, truncate_for_context_fn, endpoint_mode,
           context_limit, max_tokens, load_openai_cloud_key_fn,
           llm_complete_openai_fn, determine_endpoint_mode_fn,
           clean_messages_fn
      Tools: tools, tool_schemas, tool_budget, max_iterations
      Flags: verification_enabled, self_improve_enabled, learning_enabled,
             automation_enabled, escalation_enabled, safety_enabled,
             phase0_enabled, fastpath_enabled, teacher_enabled,
             episodic_enabled, browser_available
      Security: get_write_protection_fn, get_security_manager_fn,
                check_input_safety_fn, request_tier2_approval_fn
      Memory: memory_remember_fn, memory_hybrid_search_fn,
              memory_get_context_fn, memory_update_daily_summary_fn,
              memory_init_db_fn, db_connect_fn
      Self-improve: self_improver_cls, classify_task_fn,
                    build_adaptive_prompt_fn, estimate_tokens_fn
      Prompts: build_system_prompt_fn
      Recipes: match_recipe_fn, init_recipe_db_fn, seed_recipes_fn,
               cleanup_junk_recipes_fn, recipe_to_prompt_fn,
               recipe_record_success_fn, record_recipe_outcome_fn,
               match_patches_fn, record_patch_outcome_fn
      Decomposer: decompose_fn, decompose_compound_fn, format_decomposed_fn
      Events: event_bus
      Escalation: get_escalation_fn
      Phase-0: run_phase0_fn, system_executor_cls
      Evaluation: evaluate_task_fn, should_learn_fn, learn_and_save_fn
      Browser: browser_agent_cls, get_teacher_api_key_fn
      Batch: save_batch_state_fn, clear_batch_state_fn
      Other: remember_tool_fn, run_shell_fn, resolver_repo_root_fn
      State (in/out): user_input, in_decomposed, skip_escalation, dry_run,
                      last_task_id, last_recipe_id, last_matched_recipe,
                      last_episode_id, last_tools_used
    """

    def __init__(self, **kw):
        # Set defaults for output state
        self.last_task_id = None
        self.last_recipe_id = None
        self.last_matched_recipe = None
        self.last_episode_id = None
        self.last_tools_used = []
        # Apply all keyword args
        for k, v in kw.items():
            setattr(self, k, v)

# Module-level ctx — set before run_task, used by helper functions
_ctx: Optional[RuntimeContext] = None

def ensure_runtime_ctx(**kw) -> RuntimeContext:
    """Create RuntimeContext from cont.py globals and set as module-level _ctx.

    Called by cont.py's thin wrapper before each run_task invocation.
    Returns the ctx for callers that need it.
    """
    global _ctx
    _ctx = RuntimeContext(**kw)
    return _ctx

# ═══════════════════════════════════════════════════════════════
# 1. Decomposer Gate
# ═══════════════════════════════════════════════════════════════

RETRY_PHRASES = frozenset({
    'tekrar dene', 'tekrar', 'haydi yap', 'haydi', 'çalıştır',
    'dene', 'yap', 'devam', 'devam et', 'o zaman yap',
    'evet', 'tamam', 'olur', 'başla',
})

def is_retry_input(text: str) -> bool:
    """Check if input is a retry/continuation phrase."""
    return text.lower().strip() in RETRY_PHRASES

def _message_roles_sig(messages: list) -> str:
    """Compact role signature for messages: 's,u,a,t,u,...' (last 10)."""
    role_map = {"system": "s", "user": "u", "assistant": "a", "tool": "t"}
    roles = [role_map.get(m.get("role", "?"), "?") for m in messages[-10:]]
    return ",".join(roles)

def tool_call_signature(name: str, args: dict) -> str:
    """Create a hash signature for a tool call to detect repetition."""
    sig_str = f"{name}:{json.dumps(args, sort_keys=True)}"
    return hashlib.md5(sig_str.encode()).hexdigest()[:12]


def get_system_prompt(repo_root: str, tool_budget: int, task: str = "") -> str:
    """Get system prompt - uses adaptive prompt if available, falls back gracefully."""
    # Priority 1: Adaptive prompt (shortest, best for local LLMs)
    if _ctx.self_improve_enabled and task:
        try:
            prompt = _ctx.build_adaptive_prompt_fn(
                str(repo_root), tool_budget, task, strict_mode=True
            )
            tokens = _ctx.estimate_tokens_fn(prompt)
            _ctx.debug_fn(f"Adaptive prompt: ~{tokens} tokens (task type: {_ctx.classify_task_fn(task)})")
            return prompt + _genesis_prompt_suffix()
        except Exception as e:
            _ctx.debug_fn(f"Adaptive prompt failed, falling back: {e}")

    # Priority 2: Full verification prompt (original)
    if _ctx.verification_enabled and _ctx.build_system_prompt_fn:
        return _ctx.build_system_prompt_fn(str(repo_root), tool_budget, strict_mode=True) + _genesis_prompt_suffix()

    # Priority 3: Bare fallback
    return build_bare_system_prompt(str(repo_root), tool_budget) + _genesis_prompt_suffix()

def run_decomposed_task(task: str, subtasks: list, logger=None, event_callback=None) -> tuple:
    """Run a compound task as separate phased subtasks."""
    def emit(event_type, **kwargs):
        if event_callback:
            event_callback({"type": event_type, **kwargs})

    _ctx.console.print(f"\n  [bold cyan]📋 Görev {len(subtasks)} aşamaya bölündü:[/bold cyan]")
    for i, st in enumerate(subtasks, 1):
        _ctx.console.print(f"     [cyan]{i}. {st['task']}[/cyan]")
    emit("status", text=f"Görev {len(subtasks)} aşamaya bölündü")

    all_results = []

    for i, subtask in enumerate(subtasks):
        phase_num = i + 1
        _ctx.console.print(f"\n  [bold]═══ Aşama {phase_num}/{len(subtasks)}: {subtask['task']} ═══[/bold]")
        emit("status", text=f"Aşama {phase_num}/{len(subtasks)}: {subtask['task']}")

        # ── Fast path: find_location ──
        if subtask.get("type") == "find_location" and subtask.get("target"):
            target = subtask["target"]
            found_dir = ""
            try:
                from core.system_map import find_in_map as _map_find
                hits = _map_find(target, entry_type="dir", limit=5)
                for hit in hits:
                    p = hit.get("path", "") if isinstance(hit, dict) else str(hit)
                    if os.path.isdir(p) and target.lower() in os.path.basename(p).lower():
                        found_dir = p
                        break
                    if os.path.isdir(p) and target.lower() in p.lower():
                        found_dir = p
                        break
            except Exception as e:
                _ctx.debug_fn(f"find_location fast path failed: {e}")

            if found_dir:
                phase_result = f"Klasör bulundu: {found_dir}"
                all_results.append((phase_result, True))
                _ctx.console.print(f"  [green]→ {found_dir}[/green]")
                emit("tool_result", tool="system_search", result=f"found: {found_dir}")
                continue

        # ── Fast path: find_files ──
        if subtask.get("type") == "find_files" and all_results:
            ext = subtask.get("extension", "json")
            found_dir = extract_dir_from_results(all_results)

            if not found_dir:
                _ctx.debug_fn("find_files: extract_dir_from_results returned empty, trying system_map")
                try:
                    from core.system_map import find_in_map as _map_find
                    target_match = re.match(r'([\w-]+)', task)
                    if target_match:
                        target = target_match.group(1)
                        hits = _map_find(target, entry_type="dir", limit=5)
                        for hit in hits:
                            p = hit.get("path", "") if isinstance(hit, dict) else str(hit)
                            if os.path.isdir(p):
                                found_dir = p
                                _ctx.debug_fn(f"find_files: system_map fallback found: {found_dir}")
                                break
                except Exception as e:
                    _ctx.debug_fn(f"find_files: system_map fallback failed: {e}")

            if found_dir:
                try:
                    cmd = (
                        f'find "{found_dir}" -name "*.{ext}" -type f '
                        f'-not -path "*/.git/*" -not -path "*/.venv/*" '
                        f'-not -path "*/node_modules/*" -not -path "*/__pycache__/*" '
                        f'2>/dev/null'
                    )
                    proc = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
                    files = [f for f in proc.stdout.strip().split('\n') if f]
                    if files:
                        file_list = "\n".join(f"  📄 {f}" for f in files)
                        phase_result = (
                            f"{len(files)} adet .{ext} dosyası bulundu "
                            f"({found_dir}):\n{file_list}"
                        )
                        all_results.append((phase_result, True))
                        _ctx.console.print(f"  [green]→ {len(files)} .{ext} dosyası bulundu[/green]")
                        emit("tool_result", tool="find", result=f"{len(files)} files found")
                        continue
                except Exception as e:
                    _ctx.debug_fn(f"Fast find_files failed: {e}")

        # ── Fast path: read_summarize ──
        if subtask.get("type") == "read_summarize" and all_results:
            file_paths = extract_file_paths_from_results(all_results)
            if file_paths:
                previews, files_read = load_files_for_summary(file_paths, max_per_file=400, max_total=5000)
                if previews:
                    _ctx.console.print(f"  [dim]Sistem {files_read}/{len(file_paths)} dosyayı okudu, LLM özetliyor...[/dim]")
                    try:
                        summary = _llm_summarize(
                            previews, len(file_paths), task,
                            logger=logger, event_callback=event_callback
                        )

                        total_files_count = len(file_paths)
                        if total_files_count > files_read:
                            remaining = total_files_count - files_read
                            summary += (
                                f"\n\n📊 **{total_files_count} dosyadan {files_read} tanesi okundu.** "
                                f"Kalan {remaining} dosya context limiti nedeniyle okunamadı.\n"
                                f"💡 Devam etmek ister misin? \"devam\" yazarsan "
                                f"sonraki {min(remaining, files_read)} dosyayı da özetlerim."
                            )
                            _ctx.save_batch_state_fn({
                                "all_files": file_paths,
                                "read_so_far": files_read,
                                "batch_size": files_read,
                                "original_task": task,
                            })
                        else:
                            _ctx.clear_batch_state_fn()

                        all_results.append((summary, True))
                        rprint(summary)
                        emit("response", text=summary, via=None)
                        emit("done")
                        continue
                    except Exception as e:
                        _ctx.debug_fn(f"Fast read_summarize failed: {e}")

        # ── Normal path: build context and run LLM ──
        context_parts = []
        if all_results:
            context_parts.append("Önceki aşamaların sonuçları:")
            for j, (res, _ok) in enumerate(all_results):
                preview = res[:500] if res else "(boş)"
                if res and len(res) > 500:
                    preview += f"\n... ({len(res)} karakter, kırpıldı)"
                context_parts.append(f"  Aşama {j+1}: {preview}")

        hint = subtask.get("hint", "")
        subtask_prompt = ""
        if context_parts:
            subtask_prompt += "\n".join(context_parts) + "\n\n"
        subtask_prompt += f"ŞİMDİKİ GÖREV: {subtask['task']}\n"
        if hint:
            subtask_prompt += f"{hint}\n"
        subtask_prompt += (
            f"Orijinal kullanıcı isteği: {task}\n"
            f"Bu aşamayı tamamla ve sonuçları bildir."
        )

        _ctx.skip_escalation = True
        old_budget = _ctx.tool_budget
        if subtask.get("type") == "find_location":
            _ctx.tool_budget = 2
        try:
            result, success = run_task(subtask_prompt, logger=logger, event_callback=event_callback)
        finally:
            _ctx.skip_escalation = False
            _ctx.tool_budget = old_budget
        all_results.append((result, success))

        if not success:
            _ctx.console.print(f"  [yellow]⚠️  Aşama {phase_num} başarısız, devam ediliyor...[/yellow]")

    if all_results:
        return all_results[-1]
    return "Görev tamamlanamadı.", False

# ═══════════════════════════════════════════════════════════════
# 10. Main task execution (moved from cont.py)
# ═══════════════════════════════════════════════════════════════

def run_task(task: str, logger=None, event_callback=None) -> tuple:
    """Run a single task with verification. Returns (final_answer, success).

    Requires _ctx to be set via ensure_runtime_ctx() before calling.
    """

    _ctx.last_task_id = None
    _ctx.last_recipe_id = None
    _ctx.last_matched_recipe = None
    _ctx.last_episode_id = None
    _ctx.last_tools_used = []
    _blocked_read_files = []
    _files_actually_read = []
    _tool_results_log = []

    def emit(event_type, **kwargs):
        if event_callback:
            if event_type == "response" and "text" in kwargs:
                kwargs["text"] = _sanitize_response(kwargs["text"])
            event_callback({"type": event_type, **kwargs})

    # === INPUT-LEVEL SAFETY CHECK ===
    _raw_input = getattr(_ctx, 'user_input', None) or task
    _ctx.user_input = None  # Consume (one-shot)

    _raw_input = extract_raw_input(_raw_input)
    safe, reason = _ctx.check_input_safety_fn(_raw_input)
    if not safe:
        block_msg = (
            f"\n  ⛔ Tehlikeli komut tespit edildi: {reason}\n"
            f"  Bu işlem güvenlik nedeniyle engellenmiştir.\n"
            f"  Tier 3 kuralları geçersiz kılınamaz.\n"
        )
        _ctx.console.print(f"[bold red]{block_msg}[/bold red]")
        emit("response", text=block_msg)
        try:
            security = _ctx.get_security_manager_fn()
            if security:
                security._audit("tier3_input_blocked", "user_input", {"task": task[:200]}, 3, "blocked",
                                {"reason": reason})
        except Exception:
            pass
        return block_msg.strip(), False

    # Compound task decomposition
    _is_retry = _raw_input.lower().strip() in (
        'tekrar dene', 'tekrar', 'haydi yap', 'haydi', 'çalıştır',
        'dene', 'yap', 'devam', 'devam et', 'o zaman yap',
        'evet', 'tamam', 'olur', 'başla',
    )
    if _ctx.learning_enabled and not getattr(_ctx, 'in_decomposed', False):
        if should_decompose(_raw_input, is_retry=_is_retry):
            try:
                compound = _ctx.decompose_compound_fn(_raw_input)
                if len(compound) >= 2:
                    _ctx.debug_fn(f"Compound decomposition: {len(compound)} subtasks")
                    _ctx.in_decomposed = True
                    try:
                        return run_decomposed_task(_raw_input, compound, logger, event_callback)
                    finally:
                        _ctx.in_decomposed = False
            except Exception as e:
                _ctx.debug_fn(f"Compound decomposer failed: {e}")

    # Simple task decomposition
    if _ctx.learning_enabled and should_decompose(_raw_input, is_retry=_is_retry):
        try:
            subtasks = _ctx.decompose_fn(task)
            if len(subtasks) > 1:
                task = _ctx.format_decomposed_fn(subtasks)
                _ctx.debug_fn(f"Decomposed into {len(subtasks)} subtasks")
        except Exception as e:
            _ctx.debug_fn(f"Decomposer failed: {e}")

    # SYSTEM FASTPATH (Lane A)
    if _ctx.fastpath_enabled and not getattr(_ctx, 'skip_escalation', False):
        try:
            _sys_exec = _ctx.system_executor_cls()
            _sys_result = _sys_exec.try_execute(_raw_input)
            if _sys_result and _sys_result.get("handled"):
                _ctx.debug_fn(
                    f"[SYSTEM-EXEC] {_sys_result['intent']} "
                    f"(score: {_sys_result.get('intent_score', '?')})"
                )
                _ctx.console.print(f"[dim]⚡ Fastpath: {_sys_result['intent']}[/dim]")
                emit("status", text="Fastpath — formatlanıyor...")

                _fmt_messages = _sanitize_role_alternation([
                    {"role": "system", "content": build_format_system_prompt()},
                    {"role": "user", "content": _sys_result["format_prompt"]},
                ])
                _fmt_resp = _ctx.llm_complete_fn(
                    model=_ctx.model,
                    messages=_fmt_messages,
                    tools=None,
                    tool_choice="none",
                )
                _fmt_text = _fmt_resp.get("content", "")

                if _fmt_text:
                    _fmt_text = _sanitize_response(_fmt_text)
                    rprint(_fmt_text)
                    emit("response", text=_fmt_text, via="fastpath")
                    if logger:
                        logger.log_final(_fmt_text)

                    _task_start = time.time()
                    _fp_eval = _ctx.evaluate_task_fn(
                        task_input=_raw_input,
                        response=_fmt_text,
                        tools_used=0,
                        task_type="fastpath",
                    ) if _ctx.evaluate_task_fn else {"success": True}
                    _fp_success = _fp_eval["success"] is not False
                    _fp_id = _self_improve_record(
                        _raw_input, _fp_success, _fmt_text[:500], "",
                        0, _task_start,
                    )
                    _ctx.last_task_id = _fp_id

                    _fp_data = _sys_result.get("data", {})
                    if "path" in _fp_data:
                        try:
                            _ctx.remember_tool_fn(
                                f"{_sys_result['intent']}: {_fp_data['path']}",
                            )
                        except Exception:
                            pass

                    emit("done", task_id=_fp_id)
                    return _fmt_text, True
        except Exception as e:
            _ctx.debug_fn(f"Fastpath failed (non-fatal): {e}")

    # RECIPE MATCHING + EXECUTION (Lane A2)
    _matched_recipe = None
    _last_recipe_id = None
    _recipe_result = None
    _hive_matches = []
    _inject_mode = "none"
    if _ctx.learning_enabled:
        try:
            _recipe_conn = _ctx.init_recipe_db_fn()
            _ctx.seed_recipes_fn(_recipe_conn)
            _expired_junk = _ctx.cleanup_junk_recipes_fn(_recipe_conn, max_age_hours=24)
            if _expired_junk:
                _ctx.debug_fn(f"[RECIPE] Expired {len(_expired_junk)} junk recipes: {_expired_junk[:3]}")

            # ── RECALL: HER ZAMAN çalışır (bypass yok) ──
            # Adım 1: find_match — keyword eşleştirme
            from core.hive_recall import find_match, should_inject
            _hive_matches = find_match(_raw_input)
            # Adım 2: enjeksiyon kararı (bağlama göre)
            _inject_mode = should_inject(_raw_input, _hive_matches)
            if _hive_matches:
                _ctx.debug_fn(
                    f"[RECALL] Match: {_hive_matches[0].get('name','?')} "
                    f"(score={_hive_matches[0].get('_score','?')}, "
                    f"inject={_inject_mode})"
                )
                # Feedback için recipe_id'yi kaydet (inject olsun olmasın)
                _ctx.last_recipe_id = _hive_matches[0].get("name")

            # Recipe hijack guard: aktif görev varsa recipe execution atla
            _has_active_task = bool(getattr(_ctx, 'last_tools_used', None))
            if _has_active_task:
                _matched_recipe = None
            else:
                _matched_recipe = _ctx.match_recipe_fn(_raw_input, _recipe_conn)
            if _matched_recipe:
                _last_recipe_id = _matched_recipe["id"]
                _ctx.last_recipe_id = _last_recipe_id
                _ctx.last_matched_recipe = _matched_recipe
                _ctx.debug_fn(
                    f"[RECIPE] {_matched_recipe['id']} "
                    f"(score: {_matched_recipe.get('_score', '?')})"
                )
                if logger:
                    logger.log_decision("recipe_matched", f"Recipe '{_last_recipe_id}' matched", {
                        "recipe_id": _last_recipe_id,
                        "score": _matched_recipe.get("_score"),
                        "success_count": _matched_recipe.get("success_count", 0),
                        "failure_count": _matched_recipe.get("failure_count", 0),
                    })

                _recipe_exec = _ctx.system_executor_cls(
                    memory_fn=_ctx.memory_hybrid_search_fn,
                )
                _recipe_result = _recipe_exec.try_execute_recipe(
                    _raw_input, _matched_recipe
                )
                if _recipe_result and _recipe_result.get("handled"):
                    _ctx.debug_fn(f"[RECIPE-EXEC] {_matched_recipe['id']}")
                    _ctx.console.print(f"[dim]⚡ Recipe: {_matched_recipe['id']}[/dim]")
                    emit("status", text="Recipe — formatlanıyor...")

                    _r_messages = _sanitize_role_alternation([
                        {"role": "system", "content": build_format_system_prompt()},
                        {"role": "user", "content": _recipe_result["format_prompt"]},
                    ])
                    _r_resp = _ctx.llm_complete_fn(
                        model=_ctx.model,
                        messages=_r_messages,
                        tools=None,
                        tool_choice="none",
                    )
                    _r_text = _r_resp.get("content", "")

                    if _r_text:
                        _r_text = _sanitize_response(_r_text)
                        rprint(_r_text)
                        emit("response", text=_r_text, via="recipe")
                        if logger:
                            logger.log_final(_r_text)

                        _task_start = time.time()
                        _r_id = _self_improve_record(
                            _raw_input, True, _r_text[:500], "",
                            0, _task_start,
                        )
                        _ctx.last_task_id = _r_id

                        try:
                            _ctx.recipe_record_success_fn(_last_recipe_id)
                        except Exception:
                            pass

                        _r_data = _recipe_result.get("data", {})
                        if _r_data.get("file_path"):
                            try:
                                _ctx.remember_tool_fn(
                                    f"recipe:{_last_recipe_id}: {_r_data['file_path']}",
                                )
                            except Exception:
                                pass

                        emit("done", task_id=_r_id)
                        return _r_text, True
                else:
                    _ctx.console.print(f"[dim]Recipe: {_matched_recipe['id']}[/dim]")
        except Exception as e:
            _ctx.debug_fn(f"Recipe match failed (non-fatal): {e}")

    # AUTO BROWSER AGENT
    _ba_url = extract_url(_raw_input)
    _recipe_system_handled = _recipe_result and _recipe_result.get("handled")
    try:
        _recipe_allows_browser = not _matched_recipe or (
            _ctx.recipe_needs_browser_fn(_matched_recipe) and not _recipe_system_handled
        )
    except Exception:
        _recipe_allows_browser = not _matched_recipe
    if _ba_url and _recipe_allows_browser:
        try:
            _ba_agent_cls = _ctx.browser_agent_cls
            _ba_get_key = _ctx.get_teacher_api_key_fn

            if _ba_agent_cls and _ba_get_key and _ba_get_key():
                _ba_goal = extract_goal(_raw_input)

                _ctx.console.print(f"[cyan]  🌐 Browser agent: {_ba_url}[/cyan]")
                emit("status", text="Browser agent çalışıyor...")

                _ba_agent = _ba_agent_cls(max_steps=10)
                _ba_result = _ba_agent.run(_ba_url, _ba_goal)

                if _ba_result.get("success") and _ba_result.get("content"):
                    _ba_content = _ba_result["content"][:4000]

                    _ba_fmt_messages = _sanitize_role_alternation([
                        {"role": "system", "content": build_browser_format_system_prompt()},
                        {"role": "user", "content": build_browser_user_prompt(_raw_input, _ba_content)},
                    ])
                    _ba_fmt = _ctx.llm_complete_fn(
                        model=_ctx.model, messages=_ba_fmt_messages,
                        tools=None, tool_choice="none",
                    )
                    _ba_text = _ba_fmt.get("content", "")

                    if _ba_text:
                        _ba_text = _sanitize_response(_ba_text)
                        rprint(_ba_text)
                        emit("response", text=_ba_text, via="browser_agent")

                        if logger:
                            logger.log_decision("auto_browser_agent", f"URL detected: {_ba_url}", {
                                "goal": _ba_goal,
                                "success": True,
                            })
                            logger.log_final(_ba_text)

                        _ba_start = time.time()
                        _ba_id = _self_improve_record(
                            _raw_input, True, _ba_text[:500], "",
                            1, _ba_start,
                        )
                        _ctx.last_task_id = _ba_id

                        if _ctx.teacher_enabled and _ctx.learning_enabled:
                            try:
                                if _ctx.should_learn_fn(
                                    _raw_input,
                                    browser_agent_success=True,
                                ):
                                    _ba_teach_conn = _ctx.init_recipe_db_fn()
                                    _ba_ctx_data = {
                                        "cwd": str(Path.cwd()),
                                        "repo_root": str(_ctx.repo_root),
                                        "matched_recipe_id": _last_recipe_id,
                                        "run_id": getattr(logger, 'run_id', None) if logger else None,
                                    }
                                    if _matched_recipe:
                                        _ba_ctx_data["matched_recipe_keywords"] = ", ".join(
                                            sorted(_matched_recipe.get("pattern_keywords", {}).keys())[:8]
                                        )
                                    _ba_learned = _ctx.learn_and_save_fn(
                                        _raw_input, _ba_teach_conn,
                                        context=_ba_ctx_data,
                                    )
                                    if _ba_learned:
                                        _ctx.console.print(
                                            f"[cyan]  📚 Yeni recipe: {_ba_learned['id']}[/cyan]"
                                        )
                            except Exception:
                                pass

                        emit("done", task_id=_ba_id)
                        return _ba_text, True
                else:
                    _ctx.debug_fn(f"[AUTO-BROWSER] Agent failed: {_ba_result.get('error', 'unknown')}")
                    _ctx.console.print("[dim]  ⚠️ Browser agent başarısız, LLM'e düşülüyor...[/dim]")
        except ImportError:
            _ctx.debug_fn("[AUTO-BROWSER] playwright not available, skipping")
        except Exception as _ba_err:
            _ctx.debug_fn(f"[AUTO-BROWSER] Error: {_ba_err}")

    # Claude Code escalation check
    emit("status", text="Görev analiz ediliyor...")
    if _ctx.escalation_enabled and not getattr(_ctx, 'skip_escalation', False):
        try:
            esc = _ctx.get_escalation_fn()
            if esc.is_available:
                should_esc, reason = esc.should_escalate(task)
                if should_esc:
                    _ctx.console.print(f"[yellow]This task may benefit from Claude Code: {reason}[/yellow]")
                    if event_callback:
                        emit("escalation", reason=reason, task=task)
                        approved = getattr(event_callback, '_escalation_result', False)
                    elif esc.require_approval:
                        approved = esc.request_approval(task, reason)
                    else:
                        approved = True
                    if approved:
                        task_lower = task.lower()
                        if any(w in task_lower for w in ["analiz", "analyze", "incele", "review", "açıkla", "explain"]):
                            mode = "analyze"
                        elif any(w in task_lower for w in ["plan", "planla", "strateji", "adım"]):
                            mode = "plan"
                        elif any(w in task_lower for w in ["düzelt", "fix", "güncelle", "update", "ekle", "add", "değiştir", "edit"]):
                            mode = "edit"
                        else:
                            mode = "general"

                        emit("status", text="Claude Code çalışıyor...")
                        result = esc.call_claude(task=task, mode=mode, working_dir=str(_ctx.repo_root))
                        if result.get("success"):
                            _ctx.console.print(f"[green]Claude Code responded ({result['duration_sec']}s)[/green]")
                            _esc_task_id = _self_improve_record(_raw_input, True, result["output"][:500], "", 0, time.time())
                            _ctx.last_task_id = _esc_task_id
                            emit("response", text=result["output"], via="claude", duration=result.get("duration_sec"))
                            emit("done")
                            return result["output"], True
                        else:
                            error_msg = result.get('error', 'unknown error')
                            if result.get("silent_fallback"):
                                _ctx.debug_fn(f"Claude Code timed out, falling back silently")
                                emit("status", text="Yerel modele geçiliyor...")
                            else:
                                _ctx.console.print(f"[red]Claude Code error: {error_msg}[/red]")
                                _is_self_fix = bool(re.search(
                                    r'kendini.*(düzelt|tamir|fix)|self.?fix|fix.yourself',
                                    task.lower()
                                ))
                                if _is_self_fix:
                                    msg = (f"Claude Code hatası: {error_msg}. "
                                           "Daha spesifik bir görev verin, örn: "
                                           "'cont.py daki hataları bul ve düzelt'")
                                    _ctx.console.print(f"[yellow]{msg}[/yellow]")
                                    emit("response", text=msg, via=None)
                                    emit("done")
                                    _esc_fail_id = _self_improve_record(_raw_input, False, msg, "escalation_failed", 0, time.time())
                                    _ctx.last_task_id = _esc_fail_id
                                    return msg, False
                                _ctx.console.print("[dim]Falling back to local model...[/dim]")
                                emit("status", text="Yerel modele geçiliyor...")
        except Exception as e:
            _ctx.debug_fn(f"Escalation check failed: {e}")

    # Initialize write protection
    wp = _ctx.get_write_protection_fn()
    wp.set_task(task)

    if getattr(_ctx, 'dry_run', False):
        wp.dry_run = True
        _ctx.console.print("[yellow]DRY-RUN MODE: No files will be modified[/yellow]")

    # Initialize verifier if available
    verifier = None
    if _ctx.verification_enabled and _ctx.response_verifier_cls:
        verifier = _ctx.response_verifier_cls(strict_mode=True)

    correction_attempts = 0
    max_corrections = 2

    # Pre-read any files mentioned in the user's input
    _file_context_text, skipped_files, _loaded_count = resolve_file_context(_raw_input, repo_root=_ctx.repo_root)
    if _loaded_count > 0:
        _ctx.console.print(f"[dim]Loaded {_loaded_count} file(s) into context[/dim]")
        if skipped_files:
            _ctx.console.print(f"[dim]Skipped {len(skipped_files)} unreadable file(s)[/dim]")
    if _file_context_text != _raw_input:
        file_blocks = _file_context_text[: _file_context_text.rfind(_raw_input)]
        augmented_task = file_blocks + task
    else:
        augmented_task = task

    # PHASE-0 PRELUDE
    _phase0_result = None
    _prefetch_cache = None
    memory_context = ""

    if _ctx.phase0_enabled and _ctx.run_phase0_fn:
        try:
            emit("status", text="Phase-0 hazirlik...")
            _phase0_result = _ctx.run_phase0_fn(
                user_input=_raw_input,
                llm_complete_fn=_ctx.llm_complete_fn,
                model=_ctx.model,
                memory_search_fn=_ctx.memory_hybrid_search_fn,
                tool_fns={
                    "list_dir": _ctx.tools.get("list_dir"),
                    "run_shell": lambda command: _ctx.tools.get("run_shell", lambda **kw: "")(command=command),
                },
                timeout=2.0,
            )
            _prefetch_cache = _phase0_result.prefetch_cache
            _ctx.console.print(
                f"[dim]Phase-0: {_phase0_result.elapsed_ms:.0f}ms, "
                f"{len(_phase0_result.memories)} memories, "
                f"{len(_prefetch_cache._cache)} prefetch[/dim]"
            )
            if not _trace_off() and _phase0_result.memories:
                trace_memory_recall(
                    source="phase0",
                    entity_count=len(_phase0_result.memories),
                    result_count=len(_phase0_result.memories),
                    top_snippets=_phase0_result.memories[:2],
                )
        except Exception as e:
            _ctx.debug_fn(f"Phase-0 failed (non-fatal): {e}")

    # If Phase-0 returned HIGH actionable facts, bypass LLM entirely.
    if try_memory_gate and _phase0_result and _phase0_result.memories:
        from core.memory_gate import _is_high, _detect_action, _extract_content_words
        _gate_diag = {
            "user_input": _raw_input[:100],
            "memory_count": len(_phase0_result.memories),
            "high_count": sum(1 for m in _phase0_result.memories if _is_high(m)),
            "action": _detect_action(_raw_input),
            "content_words": list(_extract_content_words(_raw_input)),
        }
        _gate_result = try_memory_gate(_raw_input, _phase0_result.memories)
        if _gate_result:
            _ctx.console.print(
                f"[bold green]MEMORY GATE → {_gate_result['action']}: "
                f"{_gate_result['target']}[/bold green]"
            )
            if logger:
                logger.log_event("memory_gate_fired", _gate_result)

            # Execute tool directly
            _gate_output = None
            _gate_error = None
            try:
                if _gate_result["action"] == "open_path" and "open_in_explorer" in _ctx.tools:
                    _gate_output = _ctx.tools["open_in_explorer"](path=_gate_result["target"])
                elif _gate_result["action"] == "open_url" and "open_in_browser" in _ctx.tools:
                    _gate_output = _ctx.tools["open_in_browser"](url=_gate_result["target"])
            except Exception as e:
                _gate_error = str(e)

            if _gate_output and "Error" not in str(_gate_output):
                # Success — return without LLM
                _gate_answer = (
                    f"Açıldı: {_gate_result['target']}\n\n"
                    f"(Kaynak: hafıza — {_gate_result['source_memory'][:60]})"
                )
                _ctx.console.print(f"[green]Açıldı: {_gate_result['target']}[/green]")
                emit("final_answer", text=_gate_answer)

                # Record for feedback system (/iyi, /kötü)
                _gate_task_start = time.time()
                _gate_id = _self_improve_record(
                    _raw_input, True, _gate_answer[:500], "",
                    0, _gate_task_start,
                )
                _ctx.last_task_id = _gate_id
                emit("done", task_id=_gate_id)
                return _gate_answer, True

            # Gate tool failed — show error and log
            _ctx.console.print(f"[red]Açılamadı: {_gate_result['target']} ({_gate_error or 'bilinmeyen hata'})[/red]")
            # Gate tool failed → log structured event, fall through to LLM
            if logger:
                logger.log_event("memory_gate_failed", {
                    "action": _gate_result["action"],
                    "target": _gate_result["target"],
                    "error": _gate_error or str(_gate_output),
                })
            _ctx.debug_fn(f"Memory gate tool failed: {_gate_error or _gate_output}")
        else:
            # Gate did NOT fire — log why for debugging
            _gate_diag["fired"] = False
            if logger:
                logger.log_event("memory_gate_skipped", _gate_diag)
            _ctx.debug_fn(
                f"Memory gate skip: {_gate_diag['high_count']} HIGH, "
                f"action={_gate_diag['action']}, words={_gate_diag['content_words']}"
            )

    # Fallback: legacy memory injection
    if not _phase0_result:
        try:
            relevant_memories = _ctx.memory_get_context_fn(limit=3) if _ctx.memory_get_context_fn else None
            task_memories = []
            if _raw_input and len(_raw_input.split()) >= 2:
                try:
                    if _ctx.memory_hybrid_search_fn:
                        task_memories = _ctx.memory_hybrid_search_fn(
                            query=_raw_input, limit=3
                        )
                    if relevant_memories and task_memories:
                        generic_ids = {m.get('id') for m in relevant_memories if 'id' in m}
                        generic_contents = {m['content'][:80] for m in relevant_memories}
                        task_memories = [
                            m for m in task_memories
                            if m.get('id') not in generic_ids
                            and m['content'][:80] not in generic_contents
                        ]
                except Exception as e:
                    _ctx.debug_fn(f"Auto-recall failed: {e}")

            all_memories = (relevant_memories or []) + (task_memories or [])
            if all_memories:
                memory_context = "\n\n<relevant_memories>\n"
                seen = set()
                for mem in all_memories:
                    key = mem['content'][:100]
                    if key not in seen:
                        seen.add(key)
                        memory_context += f"[{mem['memory_type']}] {mem['content']}\n"
                memory_context += "</relevant_memories>\n"
                _ctx.debug_fn(f"Memory context: {len(relevant_memories or [])} generic + {len(task_memories or [])} task-specific")
        except Exception as e:
            _ctx.debug_fn(f"Memory context injection failed: {e}")

    # Initialize dynamic budget
    budget = DynamicToolBudget(budget_per_phase=_ctx.tool_budget)

    # Build messages
    system_prompt = get_system_prompt(str(_ctx.repo_root), _ctx.tool_budget, task=task)
    system_prompt += f"\n\n{budget.get_budget_for_prompt()}"

    if _phase0_result:
        phase0_section = _phase0_result.build_prompt_section()
        if phase0_section:
            system_prompt += f"\n\n{phase0_section}"
    elif memory_context:
        system_prompt += memory_context

    # Inject recipe steps
    if _matched_recipe:
        try:
            _recipe_context = {"cwd": os.getcwd()}
            try:
                if _ctx.resolver_repo_root_fn:
                    _recipe_context["repo_root"] = _ctx.resolver_repo_root_fn()
            except Exception:
                pass
            _recipe_prompt = _ctx.recipe_to_prompt_fn(
                _matched_recipe, _raw_input, _recipe_context
            )
            system_prompt += f"\n\n{_recipe_prompt}"
        except Exception as e:
            _ctx.debug_fn(f"Recipe prompt injection failed: {e}")

    _task_start_time = time.time()
    _browser_agent_success_content = None
    messages = [
        {"role": "system", "content": system_prompt},
    ]

    if _phase0_result:
        prefetch_msgs = _phase0_result.build_prefetch_messages()
        if prefetch_msgs:
            messages.extend(prefetch_msgs)

    # Hive hint injection — _inject_mode'a göre (recall bloğunda belirlendi)
    try:
        if _hive_matches and _inject_mode in ("hint", "knowledge"):
            from core.hive_recall import build_hint
            _hive_hint = build_hint(_hive_matches, _inject_mode)
            if _hive_hint:
                augmented_task += f"\n\n{_hive_hint}"
                _ctx.debug_fn(f"[HIVE] {_inject_mode} hint injected ({len(_hive_hint)} chars)")
        elif _hive_matches and _inject_mode == "log_only":
            _ctx.debug_fn(f"[HIVE] Match var ama simple görev — enjekte edilmedi, feedback kaydedilecek")
    except Exception as e:
        _ctx.debug_fn(f"[HIVE] Hint injection failed (non-fatal): {e}")

    # Spreading activation — görev başında keyword'lerden knowledge summary enjekte
    try:
        from core.spreading_activation import extract_keywords, micro_recall, reset_session
        reset_session()
        _sa_keywords = extract_keywords(_raw_input)
        _sa_hints = micro_recall(_sa_keywords)
        if _sa_hints:
            augmented_task += f"\n\n{_sa_hints}"
            _ctx.debug_fn(f"[ACTIVATION] Görev başı: {len(_sa_keywords)} keyword, {len(_sa_hints)} chars")
    except Exception as e:
        _ctx.debug_fn(f"[ACTIVATION] Görev başı failed (non-fatal): {e}")

    messages.append({"role": "user", "content": augmented_task})

    if logger:
        logger.log_llm_request(messages)

    tool_calls_count = 0
    recent_tool_sigs: deque = deque(maxlen=10)
    tool_specific_counts: dict = {}
    force_finalize = False
    consecutive_blocks = 0
    total_blocked = 0
    consecutive_tools = 0
    _force_llm_turn_msg = ""
    _force_no_tools = False  # v4: after brake, force tool_choice="none" for 1 turn
    # Structured logging counters
    _llm_calls_count = 0
    _tool_args_recovered_count = 0
    _tool_args_invalid_count = 0
    _tool_fingerprints: dict[str, int] = {}  # sig → repeat count
    _permanently_blocked: set[str] = set()  # tool+args keys that were blocked — never retry
    _fabricated_cooldown: set[str] = set()  # Guard B: fn+query keys for fabricated arg cooldown
    _prior_tool_results: list[str] = []  # Guard B: accumulate tool result snippets for allowed vocab
    _allowed_vocab: set[str] = _build_allowed_vocab(
        _raw_input,
        phase0_memories=_phase0_result.memories if _phase0_result else None,
        conversation_history=messages,  # v6.1: include system/user context
    )

    TOOL_LIMITS = dict(PER_TOOL_CAPS)

    # v6.1: Scratchpad — capture tool results for context rebuild
    from core.scratchpad import (
        init_scratchpad as _sp_init,
        append_scratchpad as _sp_append,
        maybe_rebuild_context as _sp_rebuild,
        cleanup_scratchpad as _sp_cleanup,
    )
    _sp_path = _sp_init(str(id(_raw_input)))
    _sp_step = 0

    for iteration in range(_ctx.max_iterations):
        # v6.1: Rebuild context from scratchpad if messages too long
        messages = _sp_rebuild(messages, _sp_path, _raw_input)
        # v6.2: Re-sanitize after rebuild (rebuild may change role order)
        messages = _sanitize_role_alternation(messages)

        # Inject deferred brake message from previous iteration
        if _force_llm_turn_msg:
            messages.append({"role": "system", "content": _force_llm_turn_msg})
            _force_llm_turn_msg = ""

        phase_remaining = budget.BUDGET_PER_PHASE - budget.phase_calls
        budget_exhausted = (
            force_finalize
            or (budget.total_calls >= budget.MAX_TOTAL_CALLS)
            or (budget.phase_calls >= budget.BUDGET_PER_PHASE
                and budget.current_phase >= budget.MAX_PHASES)
        )
        budget_nearly_exhausted = (phase_remaining == 1 and not budget_exhausted)

        if budget_nearly_exhausted:
            if messages[-1]["role"] != "user" or FINALIZE_MARKER not in messages[-1].get("content", ""):
                nudge = budget_nearly_exhausted_msg(budget.get_display())
                _ctx.console.print(f"[yellow]{nudge}[/yellow]")
                messages.append({"role": "user", "content": nudge})

        if budget_exhausted:
            # Bütçe kurulu — ek bütçe mi, öğrenme mi, bölme mi?
            try:
                from core.budget_committee import BudgetCommittee
                _bc = BudgetCommittee()
                _bc_decision = _bc.evaluate({
                    "calls_used": budget.total_calls,
                    "calls_blocked": sum(1 for _ in _tool_fingerprints.values() if _ > 1),
                    "estimated_remaining": 5,
                    "successful_tool_count": tool_calls_count - sum(1 for _ in _tool_fingerprints.values() if _ > 1),
                    "task_type": getattr(_ctx, '_task_type', 'unknown'),
                    "session_budget_requests": getattr(budget, '_extension_count', 0),
                })
                if _bc_decision["decision"] == "APPROVE" and _bc_decision["additional_budget"] > 0:
                    budget.total_calls -= _bc_decision["additional_budget"]
                    budget_exhausted = False
                    force_finalize = False
                    _ctx.debug_fn(f"[BUDGET] Kurul ONAY: +{_bc_decision['additional_budget']} call")
                    budget._extension_count = getattr(budget, '_extension_count', 0) + 1
                    messages.append({"role": "system", "content": f"[BÜTÇE] +{_bc_decision['additional_budget']} call eklendi. {_bc_decision['reason']}"})
                else:
                    _ctx.debug_fn(f"[BUDGET] Kurul: {_bc_decision['decision']} — {_bc_decision['reason']}")
            except Exception as e:
                _ctx.debug_fn(f"[BUDGET] Kurul hatası: {e}")

            if budget_exhausted:
                finalize_msg = budget_exhausted_msg(budget.get_display(), budget.total_calls)
                _ctx.console.print(f"[yellow]{finalize_msg}[/yellow]")
                messages.append({"role": "user", "content": finalize_msg})

        if logger and iteration > 0:
            logger.log_llm_request(messages)

        emit("status", text=f"Model çalışıyor... (adım {iteration + 1})")

        # Sanitize role alternation before LLM call (prevents Jinja crash)
        messages = _sanitize_role_alternation(messages)

        # ── TRACE: LLM Request (before spinner) ──
        if not _trace_off():
            trace_llm_request(
                model=_ctx.model,
                messages=messages,
                tools_enabled=bool(_ctx.tool_schemas and not budget_exhausted),
                tool_choice="none" if budget_exhausted else "auto",
                base_url=getattr(_ctx, "base_url", ""),
                iteration=iteration,
            )

        _spin_stop = threading.Event()
        _spin_start = time.time()
        def _llm_spin():
            chars = itertools.cycle(['⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏'])
            while not _spin_stop.is_set():
                elapsed = int(time.time() - _spin_start)
                sys.stderr.write(f"\r\033[K  {next(chars)} Model çalışıyor... ({elapsed}s)")
                sys.stderr.flush()
                _spin_stop.wait(0.1)
            sys.stderr.write("\r\033[K")
            sys.stderr.flush()
        _spin_t = threading.Thread(target=_llm_spin, daemon=True)
        _spin_t.start()
        try:
            try:
                if budget_exhausted or _force_no_tools:
                    if _force_no_tools:
                        _force_no_tools = False  # one-shot
                    result = _ctx.llm_complete_fn(
                        model=_ctx.model,
                        messages=messages,
                        tools=None,
                        tool_choice="none"
                    )
                else:
                    if _ctx.endpoint_mode == "chat":
                        result = _ctx.llm_complete_fn(
                            model=_ctx.model,
                            messages=messages,
                            tools=_ctx.tool_schemas,
                            tool_choice="auto"
                        )
                    else:
                        result = _ctx.llm_complete_fn(
                            model=_ctx.model,
                            messages=messages
                        )
            except Exception as e:
                error_str = str(e).lower()
                if any(kw in error_str for kw in ("context", "token", "8192", "maximum", "length exceeded", "too long", "n_keep", "n_ctx")):
                    # Clamp: if n_keep >= n_ctx error, use very aggressive limit
                    _trunc_limit = 8000 if "n_keep" in error_str or "n_ctx" in error_str else 12000
                    _ctx.debug_fn(f"Context overflow detected, retrying with truncation limit={_trunc_limit}: {e}")
                    try:
                        messages = _ctx.truncate_for_context_fn(messages, max_chars=_trunc_limit)
                        messages = _sanitize_role_alternation(messages)  # v4: re-sanitize after truncation
                        if budget_exhausted:
                            result = _ctx.llm_complete_fn(model=_ctx.model, messages=messages, tools=None, tool_choice="none")
                        elif _ctx.endpoint_mode == "chat":
                            result = _ctx.llm_complete_fn(model=_ctx.model, messages=messages, tools=_ctx.tool_schemas, tool_choice="auto")
                        else:
                            result = _ctx.llm_complete_fn(model=_ctx.model, messages=messages)
                    except Exception as e2:
                        if _ctx.load_openai_cloud_key_fn and _ctx.load_openai_cloud_key_fn():
                            try:
                                _ctx.console.print("[yellow]  ↗ OpenAI'ya geçiliyor...[/yellow]")
                                _fb_tools = None if budget_exhausted else _ctx.tool_schemas
                                _fb_tc = "none" if budget_exhausted else "auto"
                                result = _ctx.llm_complete_openai_fn("openai:gpt-4o-mini", messages, _fb_tools, _fb_tc)
                            except Exception as e3:
                                _ctx.console.print(f"[red]OpenAI fallback da başarısız: {e3}[/red]")
                                _self_improve_record(_raw_input, False, str(e2), "llm_api_error", tool_calls_count, _task_start_time)
                                emit("error", text=str(e2))
                                emit("done")
                                return "Hata: Bağlam penceresi aşıldı. Daha kısa bir görev deneyin.", False
                        else:
                            error_msg = f"LLM API error (retry failed): {e2}"
                            _ctx.console.print(f"[red]{error_msg}[/red]")
                            if logger:
                                logger.log("error", {"message": error_msg})
                            _self_improve_record(_raw_input, False, error_msg, "llm_api_error", tool_calls_count, _task_start_time)
                            emit("error", text=error_msg)
                            emit("done")
                            return "Hata: Bağlam penceresi aşıldı. Daha kısa bir görev deneyin.", False
                else:
                    if _ctx.load_openai_cloud_key_fn and _ctx.load_openai_cloud_key_fn():
                        try:
                            _ctx.console.print(f"[yellow]  ↗ Yerel model hatası, OpenAI'ya geçiliyor...[/yellow]")
                            _fb_tools = None if budget_exhausted else _ctx.tool_schemas
                            _fb_tc = "none" if budget_exhausted else "auto"
                            result = _ctx.llm_complete_openai_fn("openai:gpt-4o-mini", messages, _fb_tools, _fb_tc)
                        except Exception as e_cloud:
                            _ctx.console.print(f"[red]OpenAI fallback da başarısız: {e_cloud}[/red]")
                            _self_improve_record(_raw_input, False, str(e), "llm_api_error", tool_calls_count, _task_start_time)
                            emit("error", text=str(e))
                            emit("done")
                            return str(e), False
                    else:
                        user_msg = _actionable_llm_error(str(e))
                        _ctx.console.print(f"[red]{user_msg}[/red]")
                        if logger:
                            err_cls, http_st, action = _classify_llm_error(str(e))
                            logger.log("llm_api_error", {
                                "model": _ctx.model,
                                "error_class": err_cls,
                                "http_status": http_st,
                                "tools_enabled": bool(_ctx.tool_schemas and not budget_exhausted),
                                "message_roles_sig": _message_roles_sig(messages),
                                "action_hint": action,
                                "raw_error": str(e)[:300],
                            })
                        _self_improve_record(_raw_input, False, str(e), "llm_api_error", tool_calls_count, _task_start_time)
                        emit("error", text=str(e))
                        emit("done")
                        return user_msg, False
        finally:
            _spin_stop.set()
            _spin_t.join(timeout=1)

        _llm_calls_count += 1
        _llm_latency_ms = int((time.time() - _spin_start) * 1000)
        content = result["content"]
        tool_calls = result.get("tool_calls") if not budget_exhausted else None

        # Fenced tool_request fallback: some models emit tool calls as text blocks
        if not tool_calls and content and "tool_request" in (content or ""):
            _fenced = extract_fenced_tool_requests(content)
            if _fenced:
                from types import SimpleNamespace
                tool_calls = []
                for i, ft in enumerate(_fenced):
                    _tc_id = f"fenced_{i}_{hashlib.md5(ft['name'].encode()).hexdigest()[:8]}"
                    _func = SimpleNamespace(
                        name=ft["name"],
                        arguments=json.dumps(ft["args"], ensure_ascii=False),
                    )
                    tool_calls.append(SimpleNamespace(id=_tc_id, function=_func))
                _ctx.debug_fn(f"Parsed {len(tool_calls)} fenced tool_request block(s)")
                if logger:
                    logger.log("fenced_tool_request_parsed", {
                        "count": len(tool_calls),
                        "tools": [ft["name"] for ft in _fenced],
                    })

        # v6: [TOOL_CALLS] malformed pattern fallback (devstral under tool_choice pressure)
        if not tool_calls and content and "[TOOL_CALL" in (content or ""):
            _malformed = extract_malformed_tool_calls(content)
            if _malformed:
                from types import SimpleNamespace
                tool_calls = []
                for i, mt in enumerate(_malformed):
                    _tc_id = f"malformed_{i}_{hashlib.md5(mt['name'].encode()).hexdigest()[:8]}"
                    _func = SimpleNamespace(
                        name=mt["name"],
                        arguments=json.dumps(mt["args"], ensure_ascii=False),
                    )
                    tool_calls.append(SimpleNamespace(id=_tc_id, function=_func))
                _ctx.debug_fn(f"Recovered {len(tool_calls)} malformed [TOOL_CALLS] from text")
                if logger:
                    logger.log("malformed_tool_call_recovered", {
                        "count": len(tool_calls),
                        "tools": [mt["name"] for mt in _malformed],
                    })

        # ── TRACE: LLM Response (after spinner stopped) ──
        if not _trace_off():
            _tc_names = [tc.function.name for tc in tool_calls] if tool_calls else None
            trace_llm_response(
                content=content or "",
                tool_calls_count=len(tool_calls) if tool_calls else 0,
                finish_reason="tool_calls" if tool_calls else "stop",
                latency_ms=_llm_latency_ms,
                tool_names=_tc_names,
            )

        if logger:
            tc_data = None
            if tool_calls:
                tc_data = [{"id": tc.id, "name": tc.function.name, "args": tc.function.arguments} for tc in tool_calls]
            logger.log_llm_response(content, tc_data)

        if tool_calls:
            assistant_msg = {"role": "assistant", "content": content}
            assistant_msg["tool_calls"] = [
                {"id": tc.id, "type": "function", "function": {"name": tc.function.name, "arguments": tc.function.arguments}}
                for tc in tool_calls
            ]
            messages.append(assistant_msg)

            # ── TRACE: STORY Intent + per-call-id timing ──
            _tool_trace_t0: dict[str, float] = {}
            if _trace_level() >= TraceLevel.STORY:
                trace_story_intent(
                    content=content or "",
                    tool_names=[tc.function.name for tc in tool_calls],
                    tool_args_previews=[(tc.function.arguments or "")[:80] for tc in tool_calls],
                )

            for tc in tool_calls:
                fn_name = tc.function.name
                _raw_args = tc.function.arguments or "{}"
                try:
                    args = json.loads(_raw_args)
                except json.JSONDecodeError as _jde:
                    _t0 = time.time()
                    recovered, _method = _recover_tool_json(
                        _raw_args, fn_name, _ctx.debug_fn,
                    )
                    _fix_ms = round((time.time() - _t0) * 1000, 1)
                    _raw_hash = hashlib.md5(_raw_args.encode()).hexdigest()[:12]

                    if recovered is None:
                        # Total failure: refuse tool, ask LLM to regenerate
                        _tool_args_invalid_count += 1
                        refuse_msg = (
                            f"Tool '{fn_name}' çağrısı reddedildi: arguments geçerli JSON değil. "
                            f"Lütfen geçerli JSON ile tekrar dene."
                        )
                        messages.append({"role": "tool", "tool_call_id": tc.id, "content": refuse_msg})
                        if logger:
                            logger.log_tool_call(fn_name, {})
                            logger.log("tool_args_invalid", {
                                "tool_name": fn_name,
                                "model": _ctx.model,
                                "iteration": iteration,
                                "raw_len": len(_raw_args),
                                "raw_hash": _raw_hash,
                                "raw_preview": _raw_args[:120],
                                "error_type": str(_jde)[:80],
                                "refused": True,
                                "next_action": "ask_llm_retry_valid_json",
                            })
                        tool_calls_count += 1
                        continue

                    # Recovery succeeded
                    _tool_args_recovered_count += 1
                    _fixed_str = json.dumps(recovered, ensure_ascii=False)
                    if logger:
                        logger.log("tool_args_recovered", {
                            "tool_name": fn_name,
                            "model": _ctx.model,
                            "iteration": iteration,
                            "method": _method,
                            "raw_len": len(_raw_args),
                            "fixed_len": len(_fixed_str),
                            "raw_hash": _raw_hash,
                            "fixed_hash": hashlib.md5(_fixed_str.encode()).hexdigest()[:12],
                            "raw_preview": _raw_args[:120],
                            "success": True,
                            "latency_ms": _fix_ms,
                        })
                    args = recovered

                fn_name, args = normalize_tool_call(fn_name, args)

                # browser_open → open_in_browser rewrite for "aç" intent
                if fn_name == "browser_open" and _raw_input:
                    _input_lower = _raw_input.lower()
                    _open_verbs = {"aç", "açın", "açmak", "açalım", "git", "gidin", "gitmek", "gitmeli", "göster", "gösterin"}
                    _headless_verbs = {"ara", "bul", "analiz", "tara", "scrape", "tıkla"}
                    _input_words = set(_input_lower.split())
                    _has_open = bool(_input_words & _open_verbs)
                    _has_headless = bool(_input_words & _headless_verbs)
                    if _has_open and not _has_headless:
                        fn_name = "open_in_browser"

                # Guard B: sanitize fabricated query args
                args, _should_skip, _skip_reason = _sanitize_tool_args(
                    args, _raw_input, fn_name, _fabricated_cooldown,
                    allowed_vocab=_allowed_vocab,
                )
                if _should_skip:
                    messages.append({"role": "tool", "tool_call_id": tc.id, "content": _skip_reason})
                    if logger:
                        logger.log_warning("tool_arg_fabricated", {
                            "tool": fn_name,
                            "original_query": str(args.get("query", args.get("goal", args.get("pattern", "")))),
                            "user_input": _raw_input[:100],
                        })
                    continue

                # www prefix fix: strip www. from browser URLs when user didn't provide it
                if fn_name in ("browser_open", "open_in_browser", "browser_agent"):
                    _url_arg = args.get("url", "")
                    if _url_arg and "://www." in _url_arg and "www." not in _raw_input.lower():
                        args["url"] = _url_arg.replace("://www.", "://")

                # Tool call fingerprint — track repeats within this run
                _fp_sig = f"{fn_name}:{hashlib.md5(json.dumps(args, sort_keys=True).encode()).hexdigest()[:12]}"
                _tool_fingerprints[_fp_sig] = _tool_fingerprints.get(_fp_sig, 0) + 1

                # Permanent block: tool+args that were already blocked never get retried
                if _fp_sig in _permanently_blocked:
                    _perm_block_count = getattr(budget, '_perm_block_hits', 0) + 1
                    budget._perm_block_hits = _perm_block_count
                    _perm_msg = (
                        f"[KALICI ENGEL] {fn_name} aynı argümanlarla zaten engellendi. "
                        "Bu çağrıyı tekrar DENEME. "
                        "run_shell ile grep kullanarak dosyada arama yap "
                        "veya elindeki bilgiyle HEMEN cevap ver."
                    )
                    messages.append({"role": "tool", "tool_call_id": tc.id, "content": _perm_msg})
                    _ctx.console.print(f"[bold red]PERM-BLOCKED: {fn_name} (same args)[/bold red]")
                    if logger:
                        logger.log_warning("permanent_block_retry", {
                            "tool": fn_name, "sig": _fp_sig,
                        })
                    # After 2 permanent blocks, force finalization
                    if _perm_block_count >= 2:
                        force_finalize = True
                        _ctx.debug_fn(f"Force finalize after {_perm_block_count} permanent blocks")
                        break
                    continue

                allowed, budget_msg = budget.can_call(fn_name, args)
                if not allowed:
                    _permanently_blocked.add(_fp_sig)
                    consecutive_blocks += 1
                    total_blocked += 1
                    _ctx.console.print(f"[yellow]{budget_msg} (block {consecutive_blocks}/{total_blocked})[/yellow]")
                    if logger:
                        logger.log_warning(f"Tool blocked: {fn_name}", {
                            "tool": fn_name,
                            "reason": budget_msg,
                            "consecutive_blocks": consecutive_blocks,
                            "total_blocked": total_blocked,
                        })

                    if fn_name == "read_file" and "same args" in budget_msg:
                        blocked_path = args.get("path", "?")
                        _blocked_read_files.append(blocked_path)
                        messages.append({"role": "tool", "tool_call_id": tc.id,
                                         "content": f"[BLOCKED] read_file('{blocked_path}') engellendi."})
                        messages.append({"role": "system", "content": read_blocked_msg(blocked_path)})
                        if logger:
                            logger.log_tool_call(fn_name, args)
                            logger.log_tool_result(fn_name, "blocked_read", "repetition_blocked")
                        tool_calls_count += 1
                    else:
                        block_result = f"{budget_msg}{tool_blocked_path_hint(fn_name)}"
                        messages.append({"role": "tool", "tool_call_id": tc.id, "content": block_result})
                        messages.append({"role": "system", "content": tool_blocked_msg(fn_name, _TOOL_ALTERNATIVES.get(fn_name, ""))})
                        if logger:
                            logger.log_tool_call(fn_name, args)
                            logger.log_tool_result(fn_name, block_result, "budget_blocked")
                        tool_calls_count += 1

                    if consecutive_blocks >= 3:
                        if budget.force_new_phase():
                            consecutive_blocks = 0
                            previous_results = []
                            for m in messages:
                                if m.get("role") == "tool" and not m.get("content", "").startswith("[BLOCKED"):
                                    preview = m["content"][:300].replace("\n", " ")
                                    previous_results.append(f"  - {preview}")
                            results_summary = "\n".join(previous_results[-5:])

                            checkpoint_msg = phase_checkpoint_msg(
                                budget.BUDGET_PER_PHASE, budget.current_phase,
                                budget.MAX_PHASES, results_summary,
                            )
                            _ctx.console.print(f"[green]{checkpoint_msg}[/green]")
                            messages.append({"role": "system", "content": checkpoint_msg})
                            break
                        else:
                            stop_msg = all_phases_exhausted_msg(budget.total_calls)
                            _ctx.console.print(f"[bold red]{stop_msg}[/bold red]")
                            messages.append({"role": "system", "content": stop_msg})
                            force_finalize = True
                            break

                    if total_blocked >= 2:
                        stop_msg = too_many_blocks_msg(total_blocked)
                        _ctx.console.print(f"[bold red]{stop_msg}[/bold red]")
                        messages.append({"role": "system", "content": stop_msg})
                        force_finalize = True
                        break

                    continue

                consecutive_blocks = 0

                sig = tool_call_signature(fn_name, args)
                recent_tool_sigs.append(sig)

                if logger:
                    logger.log_tool_call(fn_name, args)

                # ── TRACE: Tool Call (per-call-id timing) ──
                if not _trace_off():
                    _tool_trace_t0[tc.id] = time.time()
                    trace_tool_call(tool_name=fn_name, args=args, call_id=tc.id)

                _ctx.console.print(f"  [cyan]⚡ {fn_name}[/cyan] [dim]({budget.get_display()})[/dim] {json.dumps(args)[:80]}")
                emit("tool_call", tool=fn_name, args=args)

                if fn_name not in _ctx.tools:
                    corrected = _TOOL_NAME_ALIASES.get(fn_name)
                    if corrected and corrected in _ctx.tools:
                        _ctx.console.print(f"[yellow]Auto-corrected: {fn_name} → {corrected}[/yellow]")
                        fn_name = corrected
                    else:
                        _ctx.console.print(f"[red]Unknown tool requested: {fn_name}[/red]")
                        result = unknown_tool_msg(fn_name, list(_ctx.tools.keys()))
                        error = result
                        force_finalize = True
                elif fn_name in TOOL_LIMITS and tool_specific_counts.get(fn_name, 0) >= TOOL_LIMITS[fn_name]:
                    consecutive_blocks += 1
                    total_blocked += 1
                    over_by = tool_specific_counts[fn_name] - TOOL_LIMITS[fn_name]
                    alts = _TOOL_ALTERNATIVES.get(fn_name, "farklı bir tool")
                    _ctx.console.print(f"[yellow]Tool limit reached for {fn_name} (block {consecutive_blocks}/{total_blocked})[/yellow]")
                    result = tool_limit_reached_msg(fn_name, TOOL_LIMITS[fn_name], alts)
                    error = "tool_limit_reached"
                    messages.append({"role": "tool", "tool_call_id": tc.id, "content": result})
                    messages.append({"role": "system", "content": tool_limit_system_inject_msg(fn_name, alts)})
                    if logger:
                        logger.log_tool_call(fn_name, args)
                        logger.log_tool_result(fn_name, result, error)
                    tool_calls_count += 1
                    if over_by >= 1 or total_blocked >= 2:
                        force_finalize = True
                        break
                    continue
                else:
                    tool_specific_counts[fn_name] = tool_specific_counts.get(fn_name, 0) + 1

                    _cache_hit_result = None
                    if _prefetch_cache is not None:
                        _cache_hit_result = _prefetch_cache.get(fn_name, args)

                    if _cache_hit_result is not None:
                        result = _cache_hit_result
                        if isinstance(result, (dict, list)):
                            result = json.dumps(result, indent=2)
                        error = None
                        tool_success = True
                        _ctx.console.print(f"  [green]CACHE HIT[/green] [dim]{fn_name}[/dim]")
                        if logger:
                            logger.log_tool_result(fn_name, result[:1000] if isinstance(result, str) else result, "prefetch_cache_hit")

                    if _cache_hit_result is None:
                        security = _ctx.get_security_manager_fn()
                    else:
                        security = None
                    wp = _ctx.get_write_protection_fn()
                    tier2_approved = False

                    if _cache_hit_result is not None:
                        from types import SimpleNamespace
                        perm = SimpleNamespace(allowed=False, tier=0, reason="cache_hit", details={})
                    elif security:
                        perm = security.check(fn_name, args)
                    else:
                        from types import SimpleNamespace
                        perm = SimpleNamespace(allowed=True, tier=0, reason="no_safety_module", details={})

                    if not perm.allowed:
                        if perm.reason == "needs_approval":
                            tier2_approved = _ctx.request_tier2_approval_fn(fn_name, args, perm)
                            if tier2_approved:
                                security.approve(fn_name, args)
                            else:
                                result = json.dumps({"status": "blocked", "reason": "user_denied",
                                                     "message": "User denied this action. Try a different approach."})
                                _ctx.console.print(f"[yellow]User denied {fn_name}[/yellow]")
                                tool_success = False
                                error = "user_denied"
                                if logger:
                                    logger.log("security_denied", {"tool": fn_name, "args": args})

                        elif perm.reason == "blocked":
                            result = json.dumps({"status": "blocked", "reason": "dangerous_command",
                                                 "message": f"BLOCKED (TIER 3): {perm.details.get('message', 'Dangerous command')}"})
                            _ctx.console.print(f"[bold red]BLOCKED (TIER 3): {fn_name}[/bold red]")
                            tool_success = False
                            error = "tier3_blocked"

                        elif perm.reason == "repeat_blocked":
                            result = json.dumps({"status": "blocked", "reason": "repeat_guard",
                                                 "message": "Same destructive call repeated too many times. Use a different approach."})
                            _ctx.console.print(f"[yellow]RepeatGuard: {fn_name} blocked[/yellow]")
                            tool_success = False
                            error = "repeat_blocked"

                    if perm.allowed or tier2_approved:
                        if wp.dry_run and fn_name in DESTRUCTIVE_TOOLS:
                            result = json.dumps({
                                "status": "dry_run",
                                "action": "SIMULATED",
                                "would_do": DESTRUCTIVE_TOOLS.get(fn_name, fn_name),
                                "target": args.get("path") or args.get("cmd"),
                                "message": f"DRY-RUN: Would {DESTRUCTIVE_TOOLS.get(fn_name, fn_name)} -> {args.get('path') or args.get('cmd')}. NO CHANGES MADE."
                            })
                            _ctx.console.print(f"[cyan]DRY-RUN: Would {fn_name}({args}) - NOT EXECUTED[/cyan]")
                            tool_success = True
                            error = None

                        elif not security and wp.user_intent in ("read", "ambiguous") and fn_name in DESTRUCTIVE_TOOLS and not wp.write_confirmed:
                            should_block, reason, details = wp.should_block_write(fn_name, args)
                            if should_block and reason == "intent_mismatch":
                                confirmation_msg = wp.request_confirmation(fn_name, args)
                                result = json.dumps({
                                    "status": "blocked", "reason": "write_protection",
                                    "message": confirmation_msg,
                                })
                                _ctx.console.print(f"[bold red]WRITE PROTECTION: {fn_name} blocked[/bold red]")
                                tool_success = False
                                error = "write_protection"
                            else:
                                should_block = False

                            if not should_block:
                                try:
                                    result = _ctx.tools[fn_name](**args)
                                    if isinstance(result, (dict, list)):
                                        result = json.dumps(result, indent=2)
                                    error = None
                                    tool_success = True
                                except Exception as e:
                                    result = f"Error: {type(e).__name__}: {e}"
                                    error = result
                                    tool_success = False
                                    _recovery = check_tool_error_recovery(str(e))
                                    if _recovery:
                                        result += f"\n[RECOVERY] {_recovery['msg']}"
                                        if _recovery["block"]:
                                            _permanently_blocked.add(_fp_sig)
                        else:
                            if fn_name in ("write_file", "apply_patch"):
                                target_path = args.get("path", "")
                                if target_path:
                                    try:
                                        from core.tools import safe_path
                                        full_path = safe_path(target_path)
                                        if full_path.exists():
                                            backup = (security.do_backup(str(full_path)) if security
                                                      else wp.create_backup(str(full_path)))
                                            if backup:
                                                _ctx.console.print(f"[dim]Backup: {backup}[/dim]")
                                    except Exception:
                                        pass

                            try:
                                result = _ctx.tools[fn_name](**args)
                                if fn_name == "browser_agent" and isinstance(result, dict):
                                    if result.get("success"):
                                        _browser_agent_success_content = result.get("content") or result.get("text", "")
                                    result = result.get("text", str(result))
                                elif isinstance(result, (dict, list)):
                                    result = json.dumps(result, indent=2)
                                error = None
                                tool_success = True
                            except Exception as e:
                                result = f"Error: {type(e).__name__}: {e}"
                                error = result
                                tool_success = False
                                _recovery = check_tool_error_recovery(str(e))
                                if _recovery:
                                    result += f"\n[RECOVERY] {_recovery['msg']}"
                                    if _recovery["block"]:
                                        _permanently_blocked.add(_fp_sig)

                    if verifier:
                        verifier.record_tool_call(fn_name, args, str(result)[:5000], tool_success)

                if fn_name == "read_file" and error is None:
                    read_path = args.get("path", "")
                    if read_path:
                        _files_actually_read.append(read_path)

                if error is None and result and len(str(result)) > 20:
                    _tool_results_log.append({
                        "name": fn_name,
                        "args": args,
                        "result": str(result)[:1500],
                    })

                if logger:
                    logger.log_tool_result(fn_name, result[:1000] if isinstance(result, str) else result, error)

                result_preview = str(result)[:300] if result else ""
                emit("tool_result", tool=fn_name, result=result_preview)

                # ── TRACE: Tool Result + STORY Observed ──
                if not _trace_off():
                    _t0 = _tool_trace_t0.pop(tc.id, time.time())
                    trace_tool_result(
                        tool_name=fn_name,
                        result_chars=len(result_preview),
                        result_preview=result_preview[:200],
                        error=error,
                        latency_ms=int((time.time() - _t0) * 1000),
                        call_id=tc.id,
                    )
                if _trace_level() >= TraceLevel.STORY:
                    trace_story_observed(
                        tool_name=fn_name,
                        result_preview=result_preview[:120],
                        success=error is None,
                    )

                if fn_name.startswith("browser_") and result:
                    _ctx.debug_fn(f"[browser] {fn_name} → {str(result)[:500]}")
                    _short = str(result)[:120].replace("\n", " ")
                    _ctx.console.print(f"  [dim]↳ {_short}{'…' if len(str(result)) > 120 else ''}[/dim]")

                tool_result_str = clean_surrogates(str(result))

                # Large result truncation — prevent context overflow
                _MAX_TOOL_RESULT_CHARS = 12000
                if len(tool_result_str) > _MAX_TOOL_RESULT_CHARS:
                    _orig_len = len(tool_result_str)
                    _head = tool_result_str[:8000]
                    _tail = tool_result_str[-3000:]
                    tool_result_str = (
                        f"{_head}\n\n"
                        f"...[{_orig_len} karakter, kırpıldı — tamamını görmek için "
                        f"run_shell ile grep kullan]...\n\n"
                        f"{_tail}"
                    )
                    _ctx.debug_fn(f"Tool result truncated: {_orig_len} → {len(tool_result_str)} chars")

                # v6.1: Capture to scratchpad
                _sp_step += 1
                _sp_append(_sp_path, _sp_step, fn_name, args, tool_result_str)

                if fn_name in ("search_files", "system_search") and not budget._bulk_reader.active:
                    file_lines = [
                        l.strip() for l in tool_result_str.split('\n')
                        if l.strip() and (l.strip().startswith('/') or l.strip().startswith('📄'))
                    ]
                    if len(file_lines) > 10:
                        file_paths = []
                        for fl in file_lines:
                            path_part = fl.lstrip('📄📁 ').split('[')[0].strip().split(' ')[0]
                            if path_part.startswith('/') and os.path.isfile(path_part):
                                file_paths.append(path_part)
                        if len(file_paths) > 10:
                            bulk_msg = budget.activate_bulk_read(file_paths)
                            tool_result_str += f"\n{bulk_msg}"
                            _ctx.console.print(f"[green]{bulk_msg}[/green]")

                messages.append({"role": "tool", "tool_call_id": tc.id, "content": tool_result_str})

                # Spreading activation — tool result'tan keyword çıkar + relevance check
                try:
                    from core.spreading_activation import extract_keywords, micro_recall, check_usage
                    _sa_kw = extract_keywords(tool_result_str[:500])
                    _sa_h = micro_recall(_sa_kw)
                    if _sa_h:
                        messages.append({"role": "system", "content": _sa_h})
                        _ctx.debug_fn(f"[ACTIVATION] Post-tool: {len(_sa_kw)} kw, {len(_sa_h)} chars")
                    # Hebb: model output + tool result → kullanım kontrolü
                    check_usage(tool_result_str[:300], str(args)[:200])
                except Exception:
                    pass

                # v6: Failure memory injection — search past experience when tool fails
                if error and _ctx.memory_hybrid_search_fn:
                    try:
                        _fail_domain = _extract_domain_from_args(args)
                        _fail_key = (
                            f"{fn_name} {_fail_domain} hata" if _fail_domain
                            else f"{fn_name} hata"
                        )
                        _fail_mems = _ctx.memory_hybrid_search_fn(_fail_key, limit=2)
                        if _fail_mems:
                            _fail_hints = [
                                f"[GEÇMİŞ TECRÜBESİ] {m.get('content', '')[:150]}"
                                for m in _fail_mems
                                if m.get("content")
                            ]
                            if _fail_hints:
                                _fail_hint_str = "\n".join(_fail_hints[:2])
                                messages.append({
                                    "role": "system",
                                    "content": _fail_hint_str,
                                })
                                _ctx.debug_fn(
                                    f"[FAILURE-MEM] {fn_name}: injected {len(_fail_hints)} hints"
                                )
                                if logger:
                                    logger.log("failure_memory_injected", {
                                        "tool": fn_name,
                                        "domain": _fail_domain,
                                        "hint_count": len(_fail_hints),
                                    })
                    except Exception:
                        pass  # Memory search failure is non-fatal

                # v6.1: Controlled vocab expansion — only URLs and short tokens
                # from successful tool results. Full text is NOT added (v4 laundering fix).
                if tool_result_str and not error:
                    _prior_tool_results.append(tool_result_str)
                    # Extract URLs and their domain parts
                    for _url in re.findall(r'https?://[\w./%\-?&=#+]+', tool_result_str):
                        for _part in _url.replace('/', ' ').replace('.', ' ').replace('-', ' ').split():
                            _part = _part.strip().lower()
                            if len(_part) >= 3:
                                _allowed_vocab.add(_part)

                if error and any(kw in str(error).lower() for kw in (
                    'blocked ip', 'ssrf', 'private ip', 'security',
                    'forbidden', '403', 'access denied',
                )):
                    messages.append({"role": "system", "content": security_blocked_msg(fn_name)})

                if budget_msg:
                    messages.append({"role": "system", "content": budget_msg})
                    _ctx.console.print(f"[yellow]{budget_msg}[/yellow]")

                tool_calls_count += 1
                if fn_name not in _ctx.last_tools_used:
                    _ctx.last_tools_used.append(fn_name)

                if tool_calls_count in (4, 8):
                    _reminder = task_reminder_msg(_raw_input)
                    messages.append({"role": "system", "content": _reminder})
                    if logger:
                        logger.log("task_reminder", {"at_tool_call": tool_calls_count, "task": _raw_input[:100]})
            # --- Consecutive tool brake ---
            consecutive_tools += 1
            if consecutive_tools >= 3:
                _brake_msg = (
                    "[SYSTEM] 3 ardışık tool çağrısı yaptın ama hiç gözlem/analiz yazmadın. "
                    "Şu ana kadar topladığın bilgiyi 1-2 cümle ile özetle. "
                    "Sonra ya cevap ver ya da bir tool daha çağır."
                )
                _force_llm_turn_msg = _brake_msg
                # v6: do NOT force tool_choice="none" — model may need tools
                # _force_no_tools was causing malformed [TOOL_CALLS] text output
                if logger:
                    logger.log("consecutive_tool_brake", {"consecutive_tools": consecutive_tools})
                consecutive_tools = 0
            continue

        if content and content.strip():
            consecutive_tools = 0
            if _browser_agent_success_content:
                _is_greeting = is_greeting_response(content)
                _is_too_short = len(content.split()) < 15
                if _is_greeting or _is_too_short:
                    _rescue_messages = [
                        {"role": "system", "content": build_browser_rescue_system_prompt()},
                        {"role": "user", "content": build_browser_user_prompt(
                            _raw_input, _browser_agent_success_content[:4000])},
                    ]
                    _rescue_resp = _ctx.llm_complete_fn(
                        model=_ctx.model, messages=_rescue_messages,
                        tools=None, tool_choice="none",
                    )
                    _rescue_text = _rescue_resp.get("content", "")
                    if _rescue_text and len(_rescue_text) > len(content):
                        if logger:
                            logger.log_warning("browser_agent_rescue", {
                                "original_preview": content[:100],
                                "reason": "greeting" if _is_greeting else "too_short",
                            })
                        content = _rescue_text

            if verifier and correction_attempts < max_corrections:
                is_valid, correction_prompt = verifier.verify_response(content)

                if not is_valid:
                    correction_attempts += 1
                    _ctx.console.print(f"[yellow]⚠ Doğrulama başarısız (deneme {correction_attempts}/{max_corrections}). Düzeltme yapılacak.[/yellow]")

                    if logger:
                        logger.log("verification_failed", {
                            "attempt": correction_attempts,
                            "correction_prompt": correction_prompt[:500] if correction_prompt else None
                        })

                    _correction_cancelled = False
                    _countdown_sec = 60
                    _ctx.console.print(f"[dim]  {_countdown_sec}sn içinde 'dur' yazarak iptal edebilirsin. (Enter = hemen devam)[/dim]")
                    try:
                        _start = time.time()
                        while time.time() - _start < _countdown_sec:
                            _remaining = int(_countdown_sec - (time.time() - _start))
                            sys.stdout.write(f"\r  [{'█' * (_remaining // 3)}{'░' * (20 - _remaining // 3)}] {_remaining:2d}s  ")
                            sys.stdout.flush()
                            rlist, _, _ = select.select([sys.stdin], [], [], 1.0)
                            if rlist:
                                _user_input = sys.stdin.readline().strip().lower()
                                if _user_input in ("dur", "stop", "cancel", "iptal", "hayır", "hayir"):
                                    _correction_cancelled = True
                                    break
                                elif _user_input == "":
                                    break
                        sys.stdout.write("\r" + " " * 40 + "\r")
                        sys.stdout.flush()
                    except Exception:
                        pass

                    if _correction_cancelled:
                        _ctx.console.print("[green]Düzeltme iptal edildi. Yanıt olduğu gibi gösteriliyor.[/green]")
                    else:
                        messages.append({"role": "assistant", "content": content})
                        messages.append({"role": "user", "content": correction_prompt})
                        continue
                else:
                    if logger:
                        logger.log("verification_passed", {"attempt": correction_attempts})

            if verifier and correction_attempts >= max_corrections:
                _ctx.console.print(f"[yellow]Warning: Response may contain unverified claims (max corrections reached)[/yellow]")

            try:
                content = check_hallucination(
                    content, _blocked_read_files, _files_actually_read,
                    tools_used=_ctx.last_tools_used, raw_input=_raw_input,
                )
                content = postprocess_response(content, _tool_results_log)
            except Exception as e:
                _ctx.debug_fn(f"Postprocess failed (non-fatal): {e}")

            rprint(content)
            emit("response", text=content, via=None)
            if logger:
                try:
                    _repeats = {k: v for k, v in _tool_fingerprints.items() if v > 1}
                    logger.log_final(content,
                        llm_calls_count=_llm_calls_count,
                        tool_args_recovered_count=_tool_args_recovered_count,
                        tool_args_invalid_count=_tool_args_invalid_count,
                        tool_repeat_signatures=_repeats if _repeats else None,
                    )
                except Exception as e:
                    _ctx.debug_fn(f"log_final failed (non-fatal): {e}")

            try:
                if task:
                    short_summary = task[:100] + "..." if len(task) > 100 else task
                    if _ctx.memory_update_daily_summary_fn:
                        _ctx.memory_update_daily_summary_fn(short_summary, task_count=1)
            except Exception as e:
                _ctx.debug_fn(f"Daily summary update failed: {e}")

            # False success detection + learning (non-critical, must not block return)
            _last_task_outcome_id = None
            try:
                _actual_success = True
                _false_reason = ""
                _is_false, _false_reason = detect_false_success(
                    _raw_input, content, tool_calls_count, _ctx.last_tools_used,
                )
                if _is_false:
                    _actual_success = False
                    if logger:
                        logger.log_warning("false_success_detected", {
                            "reason": _false_reason,
                            "tool_calls": tool_calls_count,
                            "task_preview": _raw_input[:100],
                        })

                _last_task_outcome_id = _self_improve_record(_raw_input, _actual_success, content, _false_reason, tool_calls_count, _task_start_time)
                _ctx.last_task_id = _last_task_outcome_id

                if _last_task_outcome_id:
                    self_assess(task, content, tool_calls_count, int((time.time() - _task_start_time) * 1000), _last_task_outcome_id)
            except Exception as e:
                _ctx.debug_fn(f"Post-task learning failed (non-fatal): {e}")

            # Recipe feedback — YAML güncelle + trail logla + record_failure
            try:
                from core.recipe_feedback import on_task_done
                _recipe_id = getattr(_ctx, 'last_recipe_id', None)
                on_task_done(
                    task=_raw_input,
                    success=_actual_success,
                    tools=_ctx.last_tools_used or [],
                    elapsed=time.time() - _task_start_time,
                    recipe_id=_recipe_id,
                )
                # record_failure (SQLite) — başarısız + recipe eşleşmişse
                if not _actual_success and _recipe_id and _ctx.recipe_record_failure_fn:
                    try:
                        _ctx.recipe_record_failure_fn(_recipe_id)
                    except Exception:
                        pass
            except Exception as e:
                _ctx.debug_fn(f"Recipe feedback failed (non-fatal): {e}")

            # Spreading activation — auto-learn + relevance feedback
            try:
                from core.spreading_activation import auto_learn, save_relevance_feedback
                auto_learn(_raw_input, _actual_success, _ctx.last_tools_used or [])
                save_relevance_feedback()
            except Exception as e:
                _ctx.debug_fn(f"Activation auto-learn failed (non-fatal): {e}")

            # Recipe learner — otomatik reçete üretimi + recall feedback
            try:
                from core.recipe_learner import on_task_complete
                on_task_complete(
                    task=_raw_input,
                    success=_actual_success,
                    tools_used=_ctx.last_tools_used or [],
                    elapsed_s=time.time() - _task_start_time,
                    recipe_matched=_recipe_id,
                )
            except Exception as e:
                _ctx.debug_fn(f"Recipe learner failed (non-fatal): {e}")

            emit("done", task_id=_last_task_outcome_id)
            return content, True
        else:
            if iteration < _ctx.max_iterations - 1:
                _ctx.console.print("[yellow]Empty response, requesting final answer...[/yellow]")
                messages.append({"role": "user", "content": empty_response_msg()})
                continue
            else:
                final_msg = "Agent returned empty response after all attempts."
                _ctx.console.print(f"[yellow]{final_msg}[/yellow]")
                if logger:
                    _repeats = {k: v for k, v in _tool_fingerprints.items() if v > 1}
                    logger.log_final(final_msg, success=False,
                        llm_calls_count=_llm_calls_count,
                        tool_args_recovered_count=_tool_args_recovered_count,
                        tool_args_invalid_count=_tool_args_invalid_count,
                        tool_repeat_signatures=_repeats if _repeats else None,
                    )
                _fail_id = _self_improve_record(_raw_input, False, final_msg, "empty_response", tool_calls_count, _task_start_time)
                _ctx.last_task_id = _fail_id
                if _fail_id:
                    self_assess(task, final_msg, tool_calls_count, int((time.time() - _task_start_time) * 1000), _fail_id)
                emit("error", text=final_msg)
                emit("done", task_id=_fail_id)
                return final_msg, False

    timeout_msg = f"Max iterations ({_ctx.max_iterations}) reached without final answer."
    _ctx.console.print(f"[yellow]{timeout_msg}[/yellow]")
    if logger:
        _repeats = {k: v for k, v in _tool_fingerprints.items() if v > 1}
        logger.log_final(timeout_msg, success=False,
            llm_calls_count=_llm_calls_count,
            tool_args_recovered_count=_tool_args_recovered_count,
            tool_args_invalid_count=_tool_args_invalid_count,
            tool_repeat_signatures=_repeats if _repeats else None,
        )
    _timeout_id = _self_improve_record(_raw_input, False, timeout_msg, "budget_exhausted", tool_calls_count, _task_start_time)
    _ctx.last_task_id = _timeout_id
    if _timeout_id:
        self_assess(task, timeout_msg, tool_calls_count, int((time.time() - _task_start_time) * 1000), _timeout_id)
    emit("error", text=timeout_msg)
    emit("done", task_id=_timeout_id)
    return timeout_msg, False