# core/network_audit.py
"""Ağ auditi — Cont'un dış bağlantı noktalarını bul ve raporla.

Banka ortamı için: SIFIR bulut, SIFIR sunucu, SIFIR online.
İstisnası yok. Sadece localhost (lokal LLM) izinli.
"""

import os
import re
import subprocess
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent

ALLOWED_HOSTS_OFFLINE = {"127.0.0.1", "localhost", "0.0.0.0", "::1"}

# Banka ortamında YASAK modüller
NETWORK_MODULES_FORBIDDEN = {
    "sentence_transformers",  # model download
    "huggingface_hub",         # model download
    "transformers",            # model download (sınırlı)
}

# Banka ortamında ŞARTLI modüller (sadece localhost'a izin)
NETWORK_MODULES_RESTRICTED = {
    "requests", "urllib", "httpx", "aiohttp", "openai", "anthropic",
}


def scan_source_files() -> dict:
    """Tüm .py dosyalarını tara, ağ bağlantı noktalarını bul."""
    findings = {
        "external_urls": [],       # localhost dışı URL'ler
        "network_imports": [],     # ağ kütüphanesi import'ları
        "subprocess_network": [],  # subprocess ile ağ
        "pip_install": [],         # pip install komutları
    }

    py_files = list((PROJECT_ROOT / "core").glob("*.py")) + [PROJECT_ROOT / "cont.py"]

    for f in py_files:
        if not f.exists():
            continue
        try:
            content = f.read_text(encoding="utf-8")
        except Exception:
            continue

        rel = str(f.relative_to(PROJECT_ROOT))

        # External URL'ler (localhost hariç)
        for ln, line in enumerate(content.splitlines(), 1):
            urls = re.findall(r'https?://[^\s\'"<>)]+', line)
            for url in urls:
                if not any(h in url for h in ALLOWED_HOSTS_OFFLINE):
                    findings["external_urls"].append({
                        "file": rel, "line": ln, "url": url[:80],
                        "is_doc": "description" in line.lower() or line.strip().startswith("#"),
                    })

        # Ağ import'ları
        for ln, line in enumerate(content.splitlines(), 1):
            if line.strip().startswith(("import ", "from ")):
                for mod in NETWORK_MODULES_FORBIDDEN | NETWORK_MODULES_RESTRICTED:
                    if re.search(rf'\b{re.escape(mod)}\b', line):
                        findings["network_imports"].append({
                            "file": rel, "line": ln, "module": mod,
                            "forbidden": mod in NETWORK_MODULES_FORBIDDEN,
                            "code": line.strip()[:100],
                        })

        # pip install
        for ln, line in enumerate(content.splitlines(), 1):
            if "pip install" in line or "pip.main" in line:
                findings["pip_install"].append({
                    "file": rel, "line": ln, "code": line.strip()[:100],
                })

    return findings


def check_offline_mode() -> dict:
    """CONT_OFFLINE flag kontrolü."""
    flag_set = os.environ.get("CONT_OFFLINE", "0") == "1"
    return {
        "env_flag": flag_set,
        "supported": _check_offline_support(),
    }


def _check_offline_support() -> bool:
    """Kod CONT_OFFLINE flag'i destekliyor mu?"""
    for f in (PROJECT_ROOT / "core").glob("*.py"):
        try:
            if "CONT_OFFLINE" in f.read_text(encoding="utf-8"):
                return True
        except Exception:
            continue
    return False


def is_offline_mode() -> bool:
    """Şu an offline mod aktif mi?"""
    return os.environ.get("CONT_OFFLINE", "0") == "1"


def is_host_allowed(host: str) -> bool:
    """Host offline modda izinli mi?"""
    if not is_offline_mode():
        return True
    return host in ALLOWED_HOSTS_OFFLINE


def audit_report() -> dict:
    """Tam audit raporu."""
    findings = scan_source_files()
    offline = check_offline_mode()

    # External URL'leri filtreleme: dokümantasyon/yorum hariç
    real_external = [u for u in findings["external_urls"] if not u["is_doc"]]

    # Ölü vs aktif import: sadece bilgi
    forbidden_imports = [i for i in findings["network_imports"] if i["forbidden"]]
    restricted_imports = [i for i in findings["network_imports"] if not i["forbidden"]]

    return {
        "external_url_count": len(real_external),
        "external_urls_top": real_external[:10],
        "forbidden_imports": len(forbidden_imports),
        "forbidden_modules": list(set(i["module"] for i in forbidden_imports)),
        "restricted_imports": len(restricted_imports),
        "pip_install_calls": len(findings["pip_install"]),
        "offline_flag_set": offline["env_flag"],
        "offline_supported": offline["supported"],
    }


def print_report():
    """Audit raporunu yazdır."""
    r = audit_report()
    print("\n" + "=" * 60)
    print("  AĞ AUDİT RAPORU")
    print("=" * 60)
    print(f"\n  External URL'ler (localhost hariç): {r['external_url_count']}")
    for u in r["external_urls_top"][:5]:
        print(f"    {u['file']}:{u['line']} → {u['url']}")
    print(f"\n  Yasak modül import'ları: {r['forbidden_imports']}")
    if r["forbidden_modules"]:
        print(f"    Modüller: {r['forbidden_modules']}")
    print(f"\n  Şartlı modüller (localhost izinli): {r['restricted_imports']}")
    print(f"\n  pip install çağrıları: {r['pip_install_calls']}")
    print(f"\n  CONT_OFFLINE flag: {'AKTİF' if r['offline_flag_set'] else 'pasif'}")
    print(f"  CONT_OFFLINE destek: {'✓' if r['offline_supported'] else '✗ EKSİK'}")
    print("=" * 60)


if __name__ == "__main__":
    import sys
    if "--report" in sys.argv or len(sys.argv) == 1:
        print_report()
