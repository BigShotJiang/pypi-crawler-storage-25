# core/postprocess.py
"""Extracted from runtime.py for modularity."""

import re

def check_hallucination(answer: str, blocked_reads: list,
                        files_read: list = None,
                        tools_used: list = None,
                        raw_input: str = "") -> str:
    """Warn if model claims file content it never successfully read,
    or claims to have opened a file/folder without calling open tools.

    Only triggers when:
    - Files were blocked from reading AND mentioned with code/content, OR
    - read_file was actually used but model describes MORE files than it read, OR
    - User intent is "aç" but no open_in_explorer/open_file was called
    Skips entirely for simple tasks (list dir, open file, etc.)
    """
    if not answer:
        return answer
    tools_used = tools_used or []

    # Check 0: "aç" intent hallucination
    # User asked to open, model claims success but never called open tool
    if raw_input:
        _input_lower = raw_input.lower()
        _has_ac_intent = any(kw in _input_lower for kw in ("aç", "açın", "explorer"))
        _open_tools = {"open_in_explorer", "open_file", "open_in_browser"}
        _called_open = bool(_open_tools & set(tools_used))
        _claims_opened = any(kw in answer.lower() for kw in (
            "açtım", "açıldı", "açılıyor", "explorer'da", "explorer'da açtım",
            "opened in explorer", "opened with",
        ))
        if _has_ac_intent and _claims_opened and not _called_open:
            answer += (
                "\n\n---\n⚠️ UYARI: 'Açtım' deniyor ancak open_in_explorer veya "
                "open_file tool'u çağrılmadı. Dosya/klasör gerçekten açılmamış olabilir."
            )

    # Skip remaining checks if no file reading was involved at all
    if not blocked_reads and not files_read:
        return answer

    # Check 1: Blocked files mentioned with content
    if blocked_reads:
        has_code = '```' in answer
        has_json_keys = any(k in answer for k in ['"name":', '"version":', '"description":',
                                                   '"dependencies":', '"scripts":'])
        blocked_mentioned = any(
            Path(f).name in answer for f in blocked_reads
        )
        if blocked_mentioned and (has_code or has_json_keys):
            answer += (
                "\n\n---\n⚠️ UYARI: Bazı dosya içerikleri okunamadan üretilmiş olabilir."
            )

    # Check 2: Answer describes more files than were actually read
    if files_read:
        mentioned = set(re.findall(
            r'[\w\-]+\.(?:json|yaml|yml|py|md|csv|txt|xml|toml|html|css|js|ts|log)',
            answer,
        ))
        read_basenames = set(Path(f).name for f in files_read)

        unread_mentioned = mentioned - read_basenames
        if len(unread_mentioned) > 3 and len(unread_mentioned) > len(read_basenames):
            read_list = ', '.join(sorted(read_basenames)) if read_basenames else 'hiçbiri'
            answer += (
                f"\n\n---\n⚠️ UYARI: Yukarıdaki özetlerin çoğu dosya içeriği "
                f"okunmadan oluşturulmuştur. Gerçekten okunan dosyalar: {read_list}. "
                f"Diğer {len(unread_mentioned)} dosya hakkındaki bilgiler "
                f"tahmine dayalıdır, doğru olmayabilir."
            )

    return answer


# ═══════════════════════════════════════════════════════════════
# 3b. False Success Detection
# ═══════════════════════════════════════════════════════════════

# Turkish action verbs that require tool execution
_ACTION_VERBS_TR = {
    "aç", "açın", "çek", "getir", "bul", "indir", "yükle", "kur",
    "sil", "yaz", "oluştur", "kaydet", "gönder", "ara", "tara",
    "çalıştır", "derle", "kopyala", "taşı",
}



def detect_false_success(
    raw_input: str,
    answer: str,
    tool_calls_count: int,
    tools_used: list,
) -> tuple[bool, str]:
    """Detect false success: user asked for action but no tool was called.

    Returns (is_false_success, reason).
    """
    if not raw_input or not answer:
        return False, ""
    if tool_calls_count > 0:
        return False, ""

    # Check if input contains action verbs
    input_lower = raw_input.lower()
    input_words = set(re.split(r'\s+', input_lower))
    has_action = bool(input_words & _ACTION_VERBS_TR)
    if not has_action:
        return False, ""

    # If model has action intent but used zero tools → false success
    return True, "no_action_taken"


# ═══════════════════════════════════════════════════════════════
# 4. Denial Detection
# ═══════════════════════════════════════════════════════════════

def _load_denial_patterns():
    """Load denial patterns from knowledge file, fallback to minimal hardcoded."""
    from pathlib import Path
    try:
        import yaml
        p = Path(__file__).parent.parent / ".cont" / "hive" / "knowledge" / "denial_patterns.yaml"
        if p.exists():
            data = yaml.safe_load(p.read_text())
            return data.get("turkish", []) + data.get("english", [])
    except Exception:
        pass
    # Minimal fallback — asla boş olmasın
    return [r'erişemiyorum', r'okuyamıyorum', r"I (?:can'?t|cannot) (?:read|access)"]

DENIAL_PATTERNS = _load_denial_patterns()
_DENIAL_RE = [re.compile(p, re.IGNORECASE) for p in DENIAL_PATTERNS]



def postprocess_response(answer: str, tool_results: list,
                         model: str = None) -> str:
    """Detect when model denies its own successful tool results.

    If the model says "I can't read files" but tool_results show successful
    read_file calls, re-call the LLM with results injected, or fall back
    to showing raw results.
    """
    if not answer or not tool_results:
        return answer

    # Check if answer contains any denial pattern
    has_denial = any(p.search(answer) for p in _DENIAL_RE)
    if not has_denial:
        return answer

    # Collect successful results that contradict the denial
    successful = []
    for tr in tool_results:
        name = tr.get("name", "")
        result = tr.get("result", "")
        if name in ("read_file", "list_dir", "search_files", "system_search") and result:
            args_str = ", ".join(f"{k}={v}" for k, v in tr.get("args", {}).items())
            successful.append(f"[{name}({args_str})] returned:\n{result[:500]}")

    if not successful:
        return answer  # Denial is about something else, not tool results

    _debug_fn(f"Denial detected in response. {len(successful)} successful tool results found.")

    # Strategy 1: Re-call LLM with injected results
    results_text = "\n\n".join(successful[:5])  # Max 5 results
    correction_prompt = (
        "DÜZELTME: Araç çağrıların başarılı oldu. İşte sonuçlar:\n\n"
        f"{results_text}\n\n"
        "Bu sonuçları kullanarak kullanıcının sorusunu CEVAPLA. "
        "'Erişemiyorum', 'okuyamıyorum' DEME — sonuçlar yukarıda."
    )

    if _llm_complete_fn:
        try:
            use_model = model or _model
            correction_messages = [
                {"role": "user", "content": correction_prompt},
            ]
            resp = _llm_complete_fn(use_model, correction_messages)
            new_content = resp.get("content", "").strip()
            if new_content and len(new_content) > 20:
                # Check the correction doesn't also contain denial
                still_denies = any(p.search(new_content) for p in _DENIAL_RE)
                if not still_denies:
                    _debug_fn("Denial corrected via re-call.")
                    return new_content
        except Exception as e:
            _debug_fn(f"Denial correction re-call failed: {e}")

    # Strategy 2: Fallback — append raw results to the answer
    _debug_fn("Denial correction failed, appending raw results.")
    fallback = "\n\n---\n📋 Araç sonuçları (model yanıtı hatalı olabilir):\n\n"
    for tr in tool_results[:5]:
        name = tr.get("name", "")
        result = tr.get("result", "")
        if name in ("read_file", "list_dir", "search_files", "system_search") and result:
            args_str = ", ".join(f"{k}={v}" for k, v in tr.get("args", {}).items())
            fallback += f"**{name}({args_str})**:\n```\n{result[:500]}\n```\n\n"

    return answer + fallback


# ═══════════════════════════════════════════════════════════════
# 5. Self-Assessment (rule-based, no LLM)
# ═══════════════════════════════════════════════════════════════


