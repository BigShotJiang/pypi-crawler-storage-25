#!/usr/bin/env python3
"""Reçete fitness hesaplama — evrimsel seçilim sinyali.

Güven skoru = success / (success + fail)
  > 0.9:  güvenilir
  > 0.7:  iyi
  > 0.5:  şüpheli
  < 0.5:  buharlaşma adayı
  = 0:    untested
"""

import yaml
from pathlib import Path

RECIPES_DIR = Path(__file__).parent.parent / ".cont" / "hive" / "recipes"


def fitness(recipe_data: dict) -> float:
    """Calculate fitness score for a recipe. Returns 0.0-1.0.
    Untested = 0.5 (nötr — ne iyi ne kötü).
    """
    sc = recipe_data.get("success_count", 0)
    fc = recipe_data.get("fail_count", 0)
    total = sc + fc
    if total == 0:
        return 0.5  # untested = nötr
    return round(sc / total, 4)


def fitness_label(score: float, total_runs: int = 0) -> str:
    """Human-readable fitness label."""
    if total_runs == 0:
        return "untested"
    if score >= 0.9:
        return "güvenilir"
    if score >= 0.7:
        return "iyi"
    if score >= 0.5:
        return "şüpheli"
    return "buharlaşma_adayı"


def all_fitness() -> list[dict]:
    """Calculate fitness for all recipes."""
    results = []
    for f in sorted(RECIPES_DIR.rglob("*.yaml")):
        try:
            d = yaml.safe_load(f.read_text())
            if not d:
                continue
            score = fitness(d)
            sc = d.get("success_count", 0)
            fc = d.get("fail_count", 0)
            results.append({
                "name": d.get("name", f.stem),
                "layer": d.get("layer", "?"),
                "fitness": score,
                "label": fitness_label(score, sc + fc),
                "success": sc,
                "fail": fc,
                "path": str(f),
            })
        except Exception:
            continue
    return results


def evaporation_candidates(min_runs: int = 5, max_fitness: float = 0.3) -> list[dict]:
    """Find recipes to archive: fitness < 0.3 and at least 5 runs."""
    return [
        r for r in all_fitness()
        if (r["success"] + r["fail"]) >= min_runs and r["fitness"] < max_fitness
    ]


def rank_by_fitness(matches: list[dict]) -> list[dict]:
    """Sort recipe matches by fitness — for hive_recall."""
    for m in matches:
        sc = m.get("success_count", 0)
        fc = m.get("fail_count", 0)
        m["_fitness"] = sc / (sc + fc) if (sc + fc) > 0 else 0.0
    return sorted(matches, key=lambda x: -x["_fitness"])


if __name__ == "__main__":
    results = all_fitness()
    print(f"{'Reçete':<30} {'Fitness':>8} {'Label':<18} {'S/F'}")
    print("-" * 70)
    for r in sorted(results, key=lambda x: x["fitness"]):
        print(f"{r['name']:<30} {r['fitness']:>8.2f} {r['label']:<18} {r['success']}/{r['fail']}")

    evap = evaporation_candidates()
    if evap:
        print(f"\nBuharlaşma adayları: {len(evap)}")
        for r in evap:
            print(f"  {r['name']}: fitness={r['fitness']}")
