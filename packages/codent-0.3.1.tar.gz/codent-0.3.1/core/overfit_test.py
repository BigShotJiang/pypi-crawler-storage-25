#!/usr/bin/env python3
"""Overfit kontrolü — 3 test: yeni görevler, regresyon, cross-validation."""

import json
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(str(PROJECT_ROOT))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

DB = "/home/sertan/projects/ews_v511/ews_dashboard/db/ews.duckdb"
RESULTS_DIR = PROJECT_ROOT / ".cont" / "hive" / "runs" / "training"


def run_cont(task: str) -> dict:
    t0 = time.time()
    try:
        from cont import run_task
        answer, success = run_task(task)
        return {
            "answer": answer or "", "success": success,
            "elapsed": round(time.time() - t0, 1),
            "tools": len(getattr(run_task, '_last_tools_used', []) or []),
            "recipe": getattr(run_task, '_last_recipe_id', None),
        }
    except Exception as e:
        return {"answer": f"ERROR:{e}", "success": False, "elapsed": round(time.time() - t0, 1), "tools": 0, "recipe": None}


def score(answer: str, check_fn) -> int:
    if not answer or "ERROR" in answer: return 0
    if not check_fn(answer): return 1
    has_num = len(re.findall(r'\d{3,}', answer)) >= 2
    l = len(answer)
    if has_num and l > 300: return 5
    if has_num and l > 100: return 4
    if has_num: return 3
    if l > 50: return 2
    return 1


# ══════════════════════════════════════
# TEST 1: TAMAMEN YENİ GÖREVLER
# ══════════════════════════════════════

NEW_TASKS = [
    {"id": "N1", "name": "3 dönem üst üste artış",
     "task": f"fact_periodic ({DB}): hangi firmaların ews skoru son 3 dönem üst üste artmış? Kaç firma? Segment dağılımı?",
     "check": lambda r: any(w in r.lower() for w in ["firma", "artış", "segment", "dönem", "üst üste"])},
    {"id": "N2", "name": "Segment YI geçiş matrisi",
     "task": f"fact_periodic ({DB}): segment bazında YI geçiş matrisi. Her segment için YI'ye giren ve çıkan firma sayısı (son 2 dönem).",
     "check": lambda r: any(w in r.lower() for w in ["segment", "yi", "geçiş", "giren", "çıkan", "matris"])},
    {"id": "N3", "name": "En kötü şube",
     "task": f"fact_periodic JOIN dim_entity ({DB}): risk/firma oranı en kötü (en yüksek) şube hangisi? Top 5 şube.",
     "check": lambda r: any(w in r.lower() for w in ["şube", "risk", "oran", "top", "en yüksek", "kötü"])},
    {"id": "N4", "name": "EUS-YIS korelasyon",
     "task": f"fact_periodic ({DB}): aynı firmada hem eus_skor hem yis_skor olan dönemlerde ikisi arasındaki korelasyonu ölç.",
     "check": lambda r: any(w in r.lower() for w in ["korelasyon", "correlation", "eus", "yis", "skor"])},
    {"id": "N5", "name": "Gecikme sıçrama",
     "task": f"fact_periodic ({DB}): gecikme günü bir dönemde 0'dan 30+'ya sıçrayan firmalar kimler? Kaç tane?",
     "check": lambda r: any(w in r.lower() for w in ["gecikme", "sıçra", "firma", "gün", "30"])},
    {"id": "N6", "name": "Bölge risk haritası",
     "task": f"fact_periodic JOIN ref_sube_bolge ({DB}): her bölgenin toplam riski, firma sayısı, YI oranı. En riskli 3 bölge.",
     "check": lambda r: any(w in r.lower() for w in ["bölge", "risk", "yi", "oran", "toplam"])},
    {"id": "N7", "name": "Skor stabilite endeksi",
     "task": f"fact_periodic ({DB}): her firmanın 12 dönemde skor varyasyon katsayısı (CV = std/mean). CV < 0.1 stabil, CV > 0.5 instabil. Dağılım?",
     "check": lambda r: any(w in r.lower() for w in ["stabil", "varyasyon", "cv", "std", "dağılım", "instabil"])},
    {"id": "N8", "name": "İlk kez YI olan firmalar",
     "task": f"fact_periodic ({DB}): son dönemde ilk kez YI olan firmalar (önceki dönemlerde hiç YI olmamış). Kaç tane? Segment?",
     "check": lambda r: any(w in r.lower() for w in ["ilk kez", "yeni", "yi", "firma", "segment", "önceki"])},
    {"id": "N9", "name": "Risk konsantrasyonu Gini",
     "task": f"fact_periodic ({DB}): son dönemde risk Gini katsayısını hesapla. Segment bazında Gini farkı var mı?",
     "check": lambda r: any(w in r.lower() for w in ["gini", "konsantrasyon", "eşitsizlik", "segment", "risk"])},
    {"id": "N10", "name": "Kaynak değişim hızı",
     "task": f"fact_periodic ({DB}): ews_kaynak (eus/yis) değişim sıklığı. 12 dönemde kaç kez kaynak değiştiren firma var? 0,1,2,3+ dağılımı.",
     "check": lambda r: any(w in r.lower() for w in ["kaynak", "değişim", "sıklık", "eus", "yis", "dağılım"])},
]


def test1_new_tasks():
    """Tamamen yeni görevler — ham vs hive."""
    print("█" * 70)
    print("  TEST 1: TAMAMEN YENİ GÖREVLER (10 adet)")
    print("█" * 70)

    results = []
    for t in NEW_TASKS:
        print(f"\n  {t['id']}: {t['name']}")

        # Ham
        ra = run_cont(t["task"])
        sa = score(ra["answer"], t["check"])
        print(f"    Ham:  {ra['elapsed']:.0f}s | {sa}/5 | {'✓' if t['check'](ra['answer']) else '✗'}")
        time.sleep(2)

        # Hive
        rb = run_cont(t["task"])
        sb = score(rb["answer"], t["check"])
        delta = sb - sa
        print(f"    Hive: {rb['elapsed']:.0f}s | {sb}/5 | {'✓' if t['check'](rb['answer']) else '✗'} | recipe={rb['recipe']}")
        print(f"    Δ: {'+' if delta >= 0 else ''}{delta}")

        results.append({"id": t["id"], "name": t["name"], "raw": sa, "hive": sb, "delta": delta})
        time.sleep(1)

    raw_total = sum(r["raw"] for r in results)
    hive_total = sum(r["hive"] for r in results)
    delta = hive_total - raw_total
    pct = delta / max(raw_total, 1) * 100

    print(f"\n{'═' * 50}")
    print(f"TEST 1 SONUÇ: Ham {raw_total}/50 vs Hive {hive_total}/50, Δ{'+' if delta >= 0 else ''}{delta} ({pct:+.0f}%)")
    print(f"Overfit kontrolü: {'PASS — fark tutarlı' if pct >= 15 else 'WARN — fark azaldı' if pct >= 0 else 'FAIL — overfit olabilir'}")
    return {"test": "new_tasks", "raw": raw_total, "hive": hive_total, "delta": delta, "pct": round(pct, 1), "results": results}


# ══════════════════════════════════════
# TEST 2: HAM MODEL REGRESYON
# ══════════════════════════════════════

def test2_regression():
    """Aynı görevleri ham modda tekrar çalıştır — 69 mu 85 mi?"""
    print("\n" + "█" * 70)
    print("  TEST 2: HAM MODEL REGRESYON (8 seviye, sadece ham)")
    print("█" * 70)

    from core.curriculum_runner import ALL_TASKS, LEVEL_NAMES

    level_scores = {}
    total = 0
    for level in sorted(ALL_TASKS.keys()):
        tasks = ALL_TASKS[level]
        level_raw = 0
        for t in tasks:
            ra = run_cont(t["task"])
            sa = score(ra["answer"], t["accept"])
            level_raw += sa
            time.sleep(1)
        level_scores[level] = level_raw
        mx = len(tasks) * 5
        total += level_raw
        print(f"  Seviye {level} ({LEVEL_NAMES[level]}): {level_raw}/{mx}")

    print(f"\n{'═' * 50}")
    print(f"TEST 2 SONUÇ: Ham toplam = {total}/160")
    print(f"Önceki referans: ilk run 85/160, retest 69/160")
    if total >= 80:
        print(f"Regresyon: YOK — smart recall ham modeli bozmamış")
    elif total >= 65:
        print(f"Regresyon: KÜÇÜK — varyans aralığında ({total} vs 69-85)")
    else:
        print(f"Regresyon: VAR — ham model performansı düşmüş!")
    return {"test": "regression", "total": total, "level_scores": level_scores}


# ══════════════════════════════════════
# TEST 3: CROSS-VALIDATION
# ══════════════════════════════════════

def test3_crossval():
    """3-fold cross-validation — Hive avantajı tutarlı mı?"""
    print("\n" + "█" * 70)
    print("  TEST 3: 3-FOLD CROSS-VALIDATION")
    print("█" * 70)

    from core.curriculum_runner import ALL_TASKS

    # Tüm görevleri düzleştir
    all_tasks = []
    for level in sorted(ALL_TASKS.keys()):
        for t in ALL_TASKS[level]:
            all_tasks.append(t)

    # 3 gruba böl (11+11+11)
    folds = [all_tasks[i::3] for i in range(3)]
    fold_results = []

    for fold_idx in range(3):
        test_fold = folds[fold_idx]
        print(f"\n  FOLD {fold_idx + 1}: {len(test_fold)} test görevi")

        fold_raw, fold_hive = 0, 0
        for t in test_fold:
            # Ham
            ra = run_cont(t["task"])
            sa = score(ra["answer"], t["accept"])
            fold_raw += sa
            time.sleep(1)

            # Hive
            rb = run_cont(t["task"])
            sb = score(rb["answer"], t["accept"])
            fold_hive += sb
            time.sleep(1)

        mx = len(test_fold) * 5
        delta = fold_hive - fold_raw
        print(f"    Ham: {fold_raw}/{mx} | Hive: {fold_hive}/{mx} | Δ{'+' if delta >= 0 else ''}{delta}")
        fold_results.append({"fold": fold_idx + 1, "raw": fold_raw, "hive": fold_hive, "max": mx, "delta": delta})

    # Tutarlılık
    deltas = [f["delta"] for f in fold_results]
    all_positive = all(d >= 0 for d in deltas)
    avg_delta = sum(deltas) / len(deltas)

    print(f"\n{'═' * 50}")
    print(f"TEST 3 SONUÇ:")
    for f in fold_results:
        print(f"  Fold {f['fold']}: Ham {f['raw']}/{f['max']} vs Hive {f['hive']}/{f['max']}, Δ{'+' if f['delta'] >= 0 else ''}{f['delta']}")
    print(f"  Ortalama Δ: {avg_delta:+.1f}")
    if all_positive:
        print(f"  Tutarlılık: PASS — 3/3 fold'da Hive >= Ham")
    else:
        neg = sum(1 for d in deltas if d < 0)
        print(f"  Tutarlılık: WARN — {neg}/3 fold'da Ham > Hive")
    return {"test": "crossval", "folds": fold_results, "avg_delta": round(avg_delta, 1), "all_positive": all_positive}


# ══════════════════════════════════════
# MAIN
# ══════════════════════════════════════

def run_all():
    t0 = time.time()
    results = {}

    results["test1"] = test1_new_tasks()
    results["test2"] = test2_regression()
    results["test3"] = test3_crossval()

    # Final rapor
    print("\n" + "█" * 70)
    print("  OVERFİT KONTROL RAPORU")
    print("█" * 70)

    t1 = results["test1"]
    t2 = results["test2"]
    t3 = results["test3"]

    print(f"\n1. Yeni görevler:   Ham {t1['raw']}/50 vs Hive {t1['hive']}/50, Δ{t1['delta']:+d} ({t1['pct']:+.0f}%)")
    print(f"2. Ham regresyon:   {t2['total']}/160 (ref: 69-85)")
    print(f"3. Cross-val:       Ort Δ={t3['avg_delta']:+.1f}, tutarlı={'✓' if t3['all_positive'] else '✗'}")

    overfit = False
    if t1["pct"] < 0:
        print("\n⚠ OVERFIT İŞARETİ: Yeni görevlerde Hive geride")
        overfit = True
    if t2["total"] < 60:
        print("\n⚠ REGRESYON: Ham model performansı düşmüş")
    if not t3["all_positive"]:
        print("\n⚠ TUTARSIZLIK: Cross-val'de Hive her fold'da kazanmadı")

    if not overfit and t3["all_positive"]:
        print("\n✓ OVERFİT YOK — Hive avantajı genelleşiyor")
    elif not overfit:
        print("\n~ SINIRDA — Hive avantajı var ama tutarsız")
    else:
        print("\n✗ OVERFİT RİSKİ — reçeteler genelleşmiyor olabilir")

    elapsed = (time.time() - t0) / 3600
    print(f"\nSüre: {elapsed:.1f}h")

    out = RESULTS_DIR / f"overfit_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    out.write_text(json.dumps(results, indent=2, ensure_ascii=False, default=str))
    print(f"JSON: {out}")
    return results


if __name__ == "__main__":
    if "--test1" in sys.argv:
        test1_new_tasks()
    elif "--test2" in sys.argv:
        test2_regression()
    elif "--test3" in sys.argv:
        test3_crossval()
    else:
        run_all()
