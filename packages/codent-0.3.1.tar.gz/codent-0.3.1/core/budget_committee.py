# core/budget_committee.py
"""Bütçe kurulu — deterministik karar mekanizması.

4 karar: APPROVE, DECOMPOSE, REDIRECT, LEARN.
Ceza YOK. Her karar yapıcı.
LLM çağrısı YOK — tamamen deterministik.
"""

import json
from datetime import datetime, timedelta
from pathlib import Path

from core.utils import debug as _debug

TRAIL_PATH = Path(__file__).parent.parent / ".cont" / "hive" / "pheromone" / "trail.jsonl"


class BudgetCommittee:
    MAX_EXTENSION = 15
    MAX_TOTAL = 30
    MAX_BLOCKED_RATIO = 0.3

    def evaluate(self, request: dict) -> dict:
        """Bütçe talebi değerlendir. Deterministik."""
        investigation = self._investigate(request)

        # Aynı görev tipi sürekli talep → öğren
        if investigation["same_type_requests"] >= 3:
            return {
                "decision": "LEARN",
                "additional_budget": 0,
                "reason": f"Bu görev tipi {investigation['same_type_requests']} kez bütçe aştı",
                "action": "learning_loop",
            }

        # Aynı session'da 3. talep → böl
        if investigation["session_requests"] >= 3:
            return {
                "decision": "DECOMPOSE",
                "additional_budget": 0,
                "reason": f"Aynı görevde {investigation['session_requests']}. talep",
                "action": "decompose_task",
            }

        # Tekrar oranı yüksek → strateji değiştir
        used = request.get("calls_used", 0)
        blocked = request.get("calls_blocked", 0)
        if used > 0 and blocked / max(used, 1) > self.MAX_BLOCKED_RATIO:
            return {
                "decision": "REDIRECT",
                "additional_budget": 0,
                "reason": f"Tekrar oranı {blocked}/{used} ({blocked/max(used,1):.0%})",
                "advice": "Farklı araçlar veya argümanlar dene.",
            }

        # İlerleme yoksa → küçük ek + uyarı
        if not investigation["progress_detected"]:
            return {
                "decision": "APPROVE",
                "additional_budget": 3,
                "reason": f"{used} call'da ilerleme az — son şans +3",
            }

        # Toplam bütçe aşımı → böl
        total = used + request.get("estimated_remaining", 5)
        if total > self.MAX_TOTAL:
            return {
                "decision": "DECOMPOSE",
                "additional_budget": 0,
                "reason": f"Toplam {total} > {self.MAX_TOTAL}",
            }

        # Normal onay
        ref = investigation.get("similar_task_avg", 0)
        grant = min(request.get("estimated_remaining", 5) + 2, self.MAX_EXTENSION)
        if ref > 0:
            grant = min(int(ref * 0.5), grant)

        return {
            "decision": "APPROVE",
            "additional_budget": grant,
            "reason": f"İlerleme var. +{grant} call.",
        }

    def _investigate(self, request: dict) -> dict:
        task_type = request.get("task_type", "unknown")
        session_requests = request.get("session_budget_requests", 0) + 1
        progress = request.get("successful_tool_count", 0) >= 2

        # Trail'den geçmiş talepleri oku
        same_type_count = 0
        similar_avg = 0
        if TRAIL_PATH.exists():
            try:
                cutoff = (datetime.now() - timedelta(days=7)).isoformat()
                budget_entries = []
                success_entries = []
                for line in TRAIL_PATH.read_text(encoding="utf-8").splitlines()[-500:]:
                    try:
                        e = json.loads(line)
                        ts = e.get("ts", "")
                        if ts >= cutoff:
                            if e.get("event") == "budget_decision" and e.get("task_type") == task_type:
                                budget_entries.append(e)
                            if e.get("success") and e.get("task_type") == task_type:
                                tc = e.get("tool_count", 0)
                                if tc > 0:
                                    success_entries.append(tc)
                    except Exception:
                        continue
                same_type_count = len(budget_entries)
                if success_entries:
                    similar_avg = sum(success_entries) / len(success_entries)
            except Exception:
                pass

        return {
            "same_type_requests": same_type_count,
            "similar_task_avg": similar_avg,
            "session_requests": session_requests,
            "progress_detected": progress,
        }
