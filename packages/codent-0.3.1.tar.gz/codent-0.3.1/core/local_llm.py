#!/usr/bin/env python3
"""Local LLM inference — doğrudan GGUF model yükleme, LM Studio bypass.

RTX 5090 24GB VRAM için optimize edilmiş.
llama-cpp-python CUDA backend kullanır.

Usage:
  from core.local_llm import LocalLLM
  llm = LocalLLM("/path/to/model.gguf")
  response = llm.chat([{"role": "user", "content": "merhaba"}])

Veya OpenAI-compatible API olarak:
  python3 core/local_llm.py --serve --model /path/to/model.gguf --port 8080
"""

import json
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Model presets — 24GB VRAM budgeting
MODEL_PRESETS = {
    "qwen3-coder-next-iq1m": {
        "path": "/mnt/c/Users/Sertan/.lmstudio/models/unsloth/Qwen3-Coder-Next-GGUF/Qwen3-Coder-Next-UD-IQ1_M.gguf",
        "n_gpu_layers": -1,  # All layers on GPU
        "n_ctx": 32768,
        "size_gb": 21,
        "description": "Qwen3-Coder-Next ultra-low quant, tam GPU",
    },
    "qwen3-coder-30b-a3b": {
        "path": "/mnt/c/Users/Sertan/.lmstudio/models/lmstudio-community/Qwen3-Coder-30B-A3B-Instruct-GGUF/Qwen3-Coder-30B-A3B-Instruct-Q4_K_M.gguf",
        "n_gpu_layers": -1,
        "n_ctx": 32768,
        "size_gb": 18,
        "description": "Qwen3-Coder-30B MoE (3B active), Q4_K_M",
    },
    "qwen3-coder-next-q4km": {
        "path": "/mnt/c/Users/Sertan/.lmstudio/models/lmstudio-community/Qwen3-Coder-Next-GGUF/Qwen3-Coder-Next-Q4_K_M.gguf",
        "n_gpu_layers": 40,  # Partial offload — 46GB model, 24GB VRAM
        "n_ctx": 16384,
        "size_gb": 46,
        "description": "Qwen3-Coder-Next Q4_K_M, partial GPU offload",
    },
}


class LocalLLM:
    """Direct GGUF model inference via llama-cpp-python."""

    def __init__(
        self,
        model_path: Optional[str] = None,
        preset: Optional[str] = None,
        n_gpu_layers: int = -1,
        n_ctx: int = 32768,
        n_batch: int = 512,
        verbose: bool = False,
    ):
        from llama_cpp import Llama

        if preset and preset in MODEL_PRESETS:
            cfg = MODEL_PRESETS[preset]
            model_path = cfg["path"]
            n_gpu_layers = cfg.get("n_gpu_layers", n_gpu_layers)
            n_ctx = cfg.get("n_ctx", n_ctx)
            logger.info("Preset: %s — %s", preset, cfg["description"])

        if not model_path or not Path(model_path).exists():
            raise FileNotFoundError(f"Model not found: {model_path}")

        logger.info("Loading %s (n_gpu_layers=%d, n_ctx=%d)...",
                     Path(model_path).name, n_gpu_layers, n_ctx)

        self.model = Llama(
            model_path=str(model_path),
            n_gpu_layers=n_gpu_layers,
            n_ctx=n_ctx,
            n_batch=n_batch,
            verbose=verbose,
            chat_format="chatml",
        )
        self.model_path = model_path
        logger.info("Model loaded: %s", Path(model_path).name)

    def chat(
        self,
        messages: list[dict],
        max_tokens: int = 2048,
        temperature: float = 0.7,
        top_p: float = 0.9,
        stop: list[str] = None,
        tools: list[dict] = None,
        tool_choice: str = "auto",
    ) -> dict:
        """Chat completion — returns OpenAI-compatible response dict."""

        # Tool calling support via system prompt injection
        if tools and tool_choice != "none":
            tool_prompt = self._build_tool_prompt(tools)
            # Inject into system message
            if messages and messages[0]["role"] == "system":
                messages[0]["content"] += "\n\n" + tool_prompt
            else:
                messages.insert(0, {"role": "system", "content": tool_prompt})

        response = self.model.create_chat_completion(
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            stop=stop or [],
        )

        result = response["choices"][0]["message"]

        # Parse tool calls from response if tools were provided
        if tools and tool_choice != "none":
            parsed_tools = self._parse_tool_calls(result.get("content", ""))
            if parsed_tools:
                result["tool_calls"] = parsed_tools
                result["content"] = ""

        return {
            "content": result.get("content", ""),
            "tool_calls": result.get("tool_calls"),
            "usage": response.get("usage", {}),
        }

    def _build_tool_prompt(self, tools: list[dict]) -> str:
        """Build tool description for system prompt injection."""
        lines = ["Available tools (call with JSON):"]
        for tool in tools:
            if tool.get("type") == "function":
                fn = tool["function"]
                params = fn.get("parameters", {}).get("properties", {})
                param_str = ", ".join(f"{k}: {v.get('type', '?')}" for k, v in params.items())
                lines.append(f"  - {fn['name']}({param_str}): {fn.get('description', '')}")
        lines.append("\nTo call a tool, respond with JSON: {\"name\": \"tool_name\", \"arguments\": {...}}")
        return "\n".join(lines)

    def _parse_tool_calls(self, content: str) -> list:
        """Parse tool calls from model output."""
        if not content:
            return []

        import re
        # Look for JSON tool call pattern
        pattern = r'\{[^{}]*"name"\s*:\s*"(\w+)"[^{}]*"arguments"\s*:\s*(\{[^{}]*\})[^{}]*\}'
        matches = re.findall(pattern, content, re.DOTALL)

        tool_calls = []
        for name, args_str in matches:
            try:
                args = json.loads(args_str)
                tool_calls.append({
                    "type": "function",
                    "id": f"call_{len(tool_calls)}",
                    "function": {"name": name, "arguments": json.dumps(args)},
                })
            except json.JSONDecodeError:
                continue

        return tool_calls

    def complete(self, prompt: str, max_tokens: int = 512, **kwargs) -> str:
        """Simple text completion."""
        response = self.model(prompt, max_tokens=max_tokens, **kwargs)
        return response["choices"][0]["text"]


def create_openai_compatible_wrapper(llm: LocalLLM):
    """Wrap LocalLLM as OpenAI-compatible client for Cont integration."""

    class _ChatCompletions:
        def create(self, model=None, messages=None, tools=None,
                   tool_choice="auto", max_tokens=2048, temperature=0.7, **kwargs):
            result = llm.chat(
                messages=messages or [],
                max_tokens=max_tokens,
                temperature=temperature,
                tools=tools,
                tool_choice=tool_choice or "auto",
            )

            # Build OpenAI-like response object
            from types import SimpleNamespace
            choice = SimpleNamespace()
            msg = SimpleNamespace()
            msg.content = result.get("content", "")
            msg.tool_calls = None

            if result.get("tool_calls"):
                tc_list = []
                for tc in result["tool_calls"]:
                    tc_obj = SimpleNamespace()
                    tc_obj.type = "function"
                    tc_obj.id = tc["id"]
                    fn = SimpleNamespace()
                    fn.name = tc["function"]["name"]
                    fn.arguments = tc["function"]["arguments"]
                    tc_obj.function = fn
                    tc_list.append(tc_obj)
                msg.tool_calls = tc_list

            choice.message = msg
            choice.finish_reason = "tool_calls" if msg.tool_calls else "stop"

            resp = SimpleNamespace()
            resp.choices = [choice]
            resp.usage = SimpleNamespace(**result.get("usage", {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}))
            return resp

    class _Chat:
        def __init__(self):
            self.completions = _ChatCompletions()

    class _Client:
        def __init__(self):
            self.chat = _Chat()

    return _Client()


def list_presets():
    """List available model presets."""
    for name, cfg in MODEL_PRESETS.items():
        exists = "✓" if Path(cfg["path"]).exists() else "✗"
        print(f"  {exists} {name}: {cfg['description']} ({cfg['size_gb']}GB)")


if __name__ == "__main__":
    import sys

    if "--list" in sys.argv:
        print("Available presets:")
        list_presets()
    elif "--serve" in sys.argv:
        # Simple OpenAI-compatible server
        preset = None
        model_path = None
        port = 8080

        for i, arg in enumerate(sys.argv):
            if arg == "--preset" and i + 1 < len(sys.argv):
                preset = sys.argv[i + 1]
            elif arg == "--model" and i + 1 < len(sys.argv):
                model_path = sys.argv[i + 1]
            elif arg == "--port" and i + 1 < len(sys.argv):
                port = int(sys.argv[i + 1])

        llm = LocalLLM(model_path=model_path, preset=preset)
        print(f"Model loaded. Serving on port {port}")
        # Use llama_cpp built-in server
        from llama_cpp.server.app import create_app
        import uvicorn
        app = create_app(model=llm.model)
        uvicorn.run(app, host="0.0.0.0", port=port)
    else:
        print(__doc__)
        print("\nPresets:")
        list_presets()
