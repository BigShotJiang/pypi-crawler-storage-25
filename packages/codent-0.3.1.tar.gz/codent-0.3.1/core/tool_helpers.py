# core/tool_helpers.py
"""Extracted from runtime.py for modularity."""

import json
import re
from typing import Optional

def _classify_llm_error(error_str: str) -> tuple[str, str | None, str]:
    """Classify LLM error into (error_class, http_status, action_hint)."""
    e = error_str.lower()
    # Extract HTTP status if present
    import re as _re
    http_match = _re.search(r'\b(4\d{2}|5\d{2})\b', error_str)
    http_status = http_match.group(1) if http_match else None

    if "connection" in e or "connect" in e or "refused" in e:
        return "connection", http_status, "check_endpoint_alive"
    if "timeout" in e or "timed out" in e:
        return "timeout", http_status, "check_model_loaded"
    if "roles must alternate" in e or "jinja" in e:
        return "role_alternation", http_status or "400", "check_roles_alternation"
    if "401" in e or "unauthorized" in e or "api key" in e:
        return "auth", http_status or "401", "check_api_key"
    if "429" in e or "rate limit" in e:
        return "rate_limit", http_status or "429", "wait_and_retry"
    if "context" in e or "token" in e or "8192" in e or "length exceeded" in e:
        return "context_length", http_status, "reduce_context"
    if "500" in e or "502" in e or "503" in e:
        return "server_error", http_status, "retry_later"
    return "unknown", http_status, "check_logs"



def _recover_tool_json(raw: str, tool_name: str, debug_fn=None):
    """Layer 2: Conservative JSON recovery — safety net after adapter.

    Uses canonical fixup_json (same fixups as Layer 1).
    Returns (parsed_dict, method) on success, (None, None) on failure.
    Caller is responsible for logging with full context (iteration, model, etc.)
    """
    from core.utils import fixup_json
    _dbg = debug_fn or (lambda m: None)

    fixed, method = fixup_json(raw)
    if method:
        _dbg(f"JSON recovery ({method}) for {tool_name}")
        try:
            result = json.loads(fixed)
            if isinstance(result, dict):
                return result, method
        except json.JSONDecodeError:
            pass

    _dbg(f"JSON recovery FAILED for {tool_name}: {raw[:200]}")
    return None, None



def extract_fenced_tool_requests(text: str) -> list:
    """Parse tool_request fenced blocks + bare JSON tool calls from model text.

    Some models emit tool calls as:
      a) ```tool_request\\n{...}\\n```  (Gemma3 style)
      b) <tool_call>{...}</tool_call>   (Qwen style)
      c) Bare JSON: {"name": "X", "arguments": {...}}  (Ollama Qwen3 fallback)
    """
    if not text:
        return []

    tool_calls = []

    # a) Fenced tool_request blocks
    if "tool_request" in text:
        for match in re.findall(r'```tool_request\s*\n(.*?)\n```', text, re.DOTALL):
            try:
                parsed = json.loads(match.strip())
                if isinstance(parsed, dict) and "name" in parsed:
                    tool_calls.append({
                        "name": parsed["name"],
                        "args": parsed.get("arguments", parsed.get("args", {})),
                    })
            except json.JSONDecodeError:
                pass

    # b) <tool_call> XML tags (Qwen)
    if "<tool_call>" in text:
        for match in re.findall(r'<tool_call>\s*(\{.*?\})\s*</tool_call>', text, re.DOTALL):
            try:
                parsed = json.loads(match.strip())
                if isinstance(parsed, dict) and "name" in parsed:
                    tool_calls.append({
                        "name": parsed["name"],
                        "args": parsed.get("arguments", parsed.get("args", {})),
                    })
            except json.JSONDecodeError:
                pass

    # b2) <tools>...</tools> wrapper (Qwen3-Coder bare emit) — may contain
    # one or more JSON objects, possibly without closing </tools> tag.
    if "<tools>" in text:
        # Capture from <tools> until </tools> OR end of string
        wrapper_match = re.search(r'<tools>\s*(.*?)(?:</tools>|$)', text, re.DOTALL)
        if wrapper_match:
            inner = wrapper_match.group(1).strip()
            # Try parse as single dict, list, or multiple concatenated dicts
            try:
                parsed = json.loads(inner)
                items = parsed if isinstance(parsed, list) else [parsed]
                for item in items:
                    if isinstance(item, dict) and "name" in item:
                        tool_calls.append({
                            "name": item["name"],
                            "args": item.get("arguments", item.get("args", {})),
                        })
            except json.JSONDecodeError:
                # Fallback: extract individual {...} JSON objects via decoder
                decoder = json.JSONDecoder()
                idx = 0
                while idx < len(inner):
                    # Skip to next '{'
                    brace = inner.find("{", idx)
                    if brace == -1:
                        break
                    try:
                        obj, end = decoder.raw_decode(inner, brace)
                        if isinstance(obj, dict) and "name" in obj:
                            tool_calls.append({
                                "name": obj["name"],
                                "args": obj.get("arguments", obj.get("args", {})),
                            })
                        idx = end
                    except json.JSONDecodeError:
                        idx = brace + 1

    # c) Bare JSON tool call (Ollama Qwen3 fallback)
    # Pattern: yanıt bir tool call JSON ile başlıyor veya tek satır
    if not tool_calls and text.strip().startswith(("{", "[")):
        stripped = text.strip()
        # Tek dict
        try:
            parsed = json.loads(stripped)
            if isinstance(parsed, dict) and "name" in parsed and ("arguments" in parsed or "args" in parsed):
                tool_calls.append({
                    "name": parsed["name"],
                    "args": parsed.get("arguments", parsed.get("args", {})),
                })
            elif isinstance(parsed, list):
                # Tool call listesi
                for item in parsed:
                    if isinstance(item, dict) and "name" in item:
                        tool_calls.append({
                            "name": item["name"],
                            "args": item.get("arguments", item.get("args", {})),
                        })
        except json.JSONDecodeError:
            pass

    return tool_calls


# v6: [TOOL_CALLS] pattern — devstral emits tool calls as text under tool_choice pressure
_TOOL_CALL_IN_TEXT_RE = re.compile(
    r'\[TOOL_CALLS?\](\w+)\[ARGS?\](.*)',
    re.DOTALL,
)



def extract_malformed_tool_calls(text: str) -> list:
    """Parse [TOOL_CALLS]tool_name[ARGS]{...} from text responses.

    Some models (devstral) emit tool calls as text when under tool_choice
    pressure (e.g. after consecutive tool brake forces tool_choice=none).
    """
    if not text or "[TOOL_CALL" not in text:
        return []
    match = _TOOL_CALL_IN_TEXT_RE.search(text)
    if not match:
        return []
    tool_name = match.group(1)
    args_str = match.group(2).strip()
    try:
        args = json.loads(args_str) if args_str else {}
    except json.JSONDecodeError:
        return []
    return [{"name": tool_name, "args": args}]



def _extract_domain_from_args(args: dict) -> str:
    """Extract domain from tool args (url, goal, query fields)."""
    for key in ("url", "goal", "query", "search_query"):
        val = str(args.get(key, ""))
        match = re.search(r'https?://([^/\s]+)', val)
        if match:
            return match.group(1)
    return ""


TOOL_ERROR_RECOVERY = {
    "Content type not allowed": {
        "msg": "PDF/binary dosya. browser_open veya browser_agent kullan.",
        "block": True,
    },
    "Too many redirects": {
        "msg": "Redirect döngüsü. Farklı URL veya web_search dene.",
        "block": True,
    },
    "TimeoutExpired": {
        "msg": "/mnt/c altında arama YAPMA. Linux path kullan.",
        "block": True,
    },
    "blocked IP": {
        "msg": "URL engellendi. web_search ile alternatif bul.",
        "block": True,
    },
    "Connection refused": {
        "msg": "Sunucu yanıt vermiyor. Farklı URL veya web_search dene.",
        "block": False,
    },
}



def check_tool_error_recovery(error_str: str) -> dict | None:
    """Check if a tool error matches a known recovery pattern.

    Returns the recovery dict (msg, block) if matched, else None.
    """
    for pattern, recovery in TOOL_ERROR_RECOVERY.items():
        if pattern in error_str:
            return recovery
    return None


_TURKISH_STOPWORDS = {
    "ve", "ile", "de", "da", "den", "dan", "bir", "bu", "şu",
    "mi", "mı", "mu", "mü", "ne", "ya", "ki", "ama", "için",
    "gibi", "daha", "en", "çok", "her", "kadar", "sonra", "önce",
    "var", "yok", "o", "ben", "sen",
    # Pronouns / particles (v3 extension)
    "benim", "senin", "onun", "bizim", "sizin",
    "onu", "bunu", "şunu", "bana", "sana", "ona",
    "şey", "olan", "olarak",
    "lütfen", "tamam", "evet", "hayır",
    "fakat", "ancak", "ise", "tüm", "hep",
    # v4: navigation container words (from memory_gate)
    "dosyasını", "dosyayı", "klasörü", "klasörünü",
    "sitesini", "sitesi", "sayfasını",
    "nasıl", "nerede", "nereye",
    # v4: discourse markers (missing from all sets)
    "çünkü", "zira", "hem", "peki", "acaba",
    "böyle", "şöyle", "hangisi", "hangi",
}



def _sanitize_role_alternation(messages: list[dict]) -> list[dict]:
    """Sanitize message roles for strict-alternation APIs (Devstral/Mistral).

    Rules enforced:
    1. First system message preserved as-is.
    2. Mid-conversation system messages converted to user role
       (Devstral only accepts system at position 0).
    3. Consecutive same-role messages merged.
    4. After tool results, if next non-system is user, insert a minimal
       assistant bridge to maintain tool→assistant→user alternation.
    """
    if not messages:
        return messages

    # Pass 1: Convert mid-conversation system messages to user role
    normalized = []
    for i, msg in enumerate(messages):
        if msg["role"] == "system" and i > 0:
            # Mid-conversation system → user (Devstral rejects mid-system)
            normalized.append({"role": "user", "content": msg.get("content") or ""})
        else:
            normalized.append(msg)

    # Pass 2: Merge consecutive same-role messages
    result = []
    for msg in normalized:
        if result and result[-1]["role"] == msg["role"]:
            result[-1] = dict(result[-1])  # shallow copy to avoid mutation
            prev_content = result[-1].get("content") or ""
            new_content = msg.get("content") or ""
            result[-1]["content"] = prev_content + "\n\n" + new_content
        else:
            result.append(msg)

    return result


_MAX_ALLOWED_VOCAB = 300  # Cap to prevent unbounded growth



def _build_allowed_vocab(
    user_input: str,
    phase0_memories: list[dict] | None = None,
    conversation_history: list[dict] | None = None,
) -> set[str]:
    """Build allowed vocabulary from all pipeline-known sources.

    Words from these sources are NOT fabricated — the model learned them
    from the pipeline, not hallucination.
    Capped at _MAX_ALLOWED_VOCAB to prevent unbounded growth.
    """
    allowed = set()

    # 1. User input tokens (always)
    for w in user_input.lower().split():
        w = w.strip(".,!?:;\"'()[]")
        if len(w) >= 2:
            allowed.add(w)

    # 2. Phase-0 HIGH memory fact tokens
    if phase0_memories:
        from core.memory_gate import _is_high
        for mem in phase0_memories:
            if _is_high(mem):
                content = mem.get("content", "")
                for w in content.lower().split():
                    w = w.strip(".,!?:;\"'()[]=/")
                    if len(w) >= 2:
                        allowed.add(w)

    # 3. v6.1: Conversation history tokens (user + assistant content)
    if conversation_history:
        for msg in conversation_history:
            text = msg.get("content", "")
            if text and msg.get("role") in ("user", "assistant"):
                for w in text[:500].lower().split():
                    w = w.strip(".,!?:;\"'()[]<>/")
                    if len(w) >= 3:
                        allowed.add(w)

    # Cap: keep longest (most meaningful) tokens if over limit
    if len(allowed) > _MAX_ALLOWED_VOCAB:
        allowed = set(sorted(allowed, key=len, reverse=True)[:_MAX_ALLOWED_VOCAB])

    return allowed





def _is_stopword_only_query(query: str) -> bool:
    """True if query contains only Turkish stopwords or single-char tokens."""
    words = [w.strip(".,!?:;") for w in query.split()]
    meaningful = [w for w in words if w.lower() not in _TURKISH_STOPWORDS and len(w) > 1]
    return len(meaningful) == 0

def _sanitize_tool_args(
    args: dict,
    user_input: str,
    fn_name: str = "",
    cooldown: set | None = None,
    allowed_vocab: set[str] | None = None,
) -> tuple[dict, bool, str]:
    """Sanitize query-type tool arguments against known vocabulary.

    Returns: (cleaned_args, should_skip, skip_reason)
    - should_skip=True → tool call should be SKIPPED entirely (all fabricated)
    - Partial fabrication → keep only valid words
    - Cooldown set tracks fn+query pairs to prevent anti-loop
    - allowed_vocab: expanded vocabulary from phase0 memories + tool results
    """
    if not user_input:
        return args, False, ""

    # Selector preservation: browser tool args must never be tokenized/truncated
    _BROWSER_SELECTOR_TOOLS = {
        "browser_click", "browser_type", "browser_select", "browser_check",
        "browser_agent", "open_in_browser",
    }
    _SELECTOR_KEYS = {"selector", "css_selector", "goal", "url"}
    _preserved_selectors = {}
    if fn_name in _BROWSER_SELECTOR_TOOLS:
        for sk in _SELECTOR_KEYS:
            if sk in args:
                _preserved_selectors[sk] = args[sk]

    # Use expanded vocab if provided, otherwise fall back to user input only
    if allowed_vocab is None:
        allowed_vocab = set()
        for w in user_input.lower().split():
            w = w.strip(".,!?:;\"'()[]")
            if len(w) >= 2:
                allowed_vocab.add(w)
    input_lower = user_input.strip().lower()

    for key in ("query", "goal", "pattern", "search_query", "keywords"):
        if key not in args:
            continue
        value = str(args[key])
        words = value.split()
        if not words:
            continue

        # Stopword-only guard: block meaningless queries
        if _is_stopword_only_query(value):
            _cooldown_key = f"{fn_name}:{value}"
            if cooldown is not None:
                cooldown.add(_cooldown_key)
            return args, True, (
                f"[SYSTEM] Tool query anlamsız (stopword-only: '{value}'); "
                "call atlandı. Daha spesifik kelimelerle dene."
            )

        # Check against expanded vocab (user input + phase0 + tool results)
        valid = [w for w in words if w.lower() in allowed_vocab or w.lower() in input_lower]

        # Cooldown check: same fn+query already fabricated this turn?
        _cooldown_key = f"{fn_name}:{value}"
        if cooldown is not None and _cooldown_key in cooldown:
            return args, True, (
                f"[SYSTEM] Aynı fabricated query tekrar denendi ({fn_name}). "
                "Tool atlandı."
            )

        if len(valid) == len(words):
            continue  # All words valid, no change

        if len(valid) > 0:
            # Partial fabrication — keep valid words
            args[key] = " ".join(valid)
        else:
            # ALL fabricated — SKIP tool call
            if cooldown is not None:
                cooldown.add(_cooldown_key)
            # Restore preserved selectors before returning
            for sk, sv in _preserved_selectors.items():
                args[sk] = sv
            return args, True, (
                "[SYSTEM] Tool query fabricated (pipeline'da geçmeyen) kelimeler "
                "içeriyordu ve temizlenemedi; tool call atlandı. "
                "Farklı kelimelerle dene veya doğrudan cevap ver."
            )
    # Restore preserved selectors (never tokenized/truncated)
    for sk, sv in _preserved_selectors.items():
        args[sk] = sv
    return args, False, ""





# Additional extractions from runtime.py
def _llm_summarize(file_previews: str, total_files: int, original_task: str,
                   logger=None, event_callback=None) -> str:
    """Call LLM for pure text summarization — no tools, just text generation."""
    messages = [
        {"role": "system", "content": build_summarize_system_prompt()},
        {"role": "user", "content": build_summarize_user_prompt(total_files, original_task, file_previews)},
    ]

    available_tokens = (_ctx.context_limit or 8192) - 500
    context_limit = int(available_tokens * 2.5)
    messages = _ctx.truncate_for_context_fn(messages, max_chars=context_limit)

    if logger:
        logger.log_llm_request(messages)

    result = _ctx.llm_complete_fn(
        model=_ctx.model,
        messages=messages,
        tools=None,
        tool_choice="none"
    )

    content = result.get("content", "") or ""

    if logger:
        logger.log_llm_response(content, None)
        logger.log_final(content)

    return content



def ask_claude_tool(task: str, context: str = "", mode: str = "general",
                    working_dir: str = "") -> str:
    """Send task to Claude Code CLI. Requires user approval."""
    if not _ctx.escalation_enabled:
        return json.dumps({"ok": False, "error": "Escalation system not available"})
    try:
        esc = _ctx.get_escalation_fn()
        if not esc.is_available:
            return json.dumps({"ok": False, "error": "Claude Code CLI not found. Install: npm install -g @anthropic-ai/claude-code"})

        if esc.require_approval:
            if not esc.request_approval(task, f"Tool call: ask_claude (mode={mode})"):
                return json.dumps({"ok": False, "error": "User declined escalation"})

        result = esc.call_claude(
            task=task, context=context, mode=mode,
            working_dir=working_dir or str(Path.cwd()),
        )

        if result.get("success"):
            _ctx.console.print(f"[green]Claude Code responded ({result['duration_sec']}s)[/green]")
            return json.dumps({
                "ok": True,
                "mode": result.get("mode"),
                "output": result.get("output", ""),
                "duration_sec": result.get("duration_sec"),
            }, ensure_ascii=False)
        else:
            return json.dumps({"ok": False, "error": result.get("error", "Unknown error")})
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)})



