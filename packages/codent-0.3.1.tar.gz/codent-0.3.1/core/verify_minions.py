#!/usr/bin/env python3
"""Doğrulama minionları — seviye bazlı, tek işli, ucuz doğrulayıcılar.

Seviye 5: matematiksel kesinlik (assert_*)
Seviye 3: çıktı eşleştirme (pattern_*, json_*, contains_*)
Seviye 2: istatistiksel (metric_*)
"""

import json
import re


# ═══ Seviye 5: Matematiksel kesinlik ═══

def assert_equal(a, b) -> tuple[bool, str]:
    ok = a == b
    return ok, f"{a} == {b}" if ok else f"{a} != {b}"


def assert_range(value, min_val, max_val) -> tuple[bool, str]:
    ok = min_val <= value <= max_val
    return ok, f"{min_val} <= {value} <= {max_val}" if ok else f"{value} dışında [{min_val}, {max_val}]"


def assert_count(items, expected: int) -> tuple[bool, str]:
    actual = len(items) if hasattr(items, '__len__') else items
    ok = actual == expected
    return ok, f"count={actual}" if ok else f"count={actual}, beklenen={expected}"


def assert_positive(value) -> tuple[bool, str]:
    ok = value > 0
    return ok, f"{value} > 0" if ok else f"{value} <= 0"


def assert_ratio(value) -> tuple[bool, str]:
    ok = 0 <= value <= 1
    return ok, f"0 <= {value} <= 1" if ok else f"{value} [0,1] dışında"


# ═══ Seviye 3: Çıktı eşleştirme ═══

def contains_check(output: str, expected: str) -> tuple[bool, str]:
    ok = expected in output
    return ok, f"'{expected}' bulundu" if ok else f"'{expected}' bulunamadı"


def pattern_match(output: str, regex: str) -> tuple[bool, str]:
    ok = bool(re.search(regex, output))
    return ok, f"pattern eşleşti" if ok else f"'{regex}' eşleşmedi"


def json_validate(output: str) -> tuple[bool, str]:
    try:
        json.loads(output)
        return True, "geçerli JSON"
    except (json.JSONDecodeError, TypeError) as e:
        return False, f"JSON hatası: {e}"


def json_has_keys(output: str, keys: list[str]) -> tuple[bool, str]:
    try:
        d = json.loads(output)
        missing = [k for k in keys if k not in d]
        if missing:
            return False, f"eksik anahtarlar: {missing}"
        return True, f"tüm anahtarlar var: {keys}"
    except Exception as e:
        return False, f"JSON parse hatası: {e}"


def csv_structure(output: str, expected_cols: int = None, has_header: bool = True) -> tuple[bool, str]:
    lines = output.strip().splitlines()
    if not lines:
        return False, "boş çıktı"
    if has_header and expected_cols:
        cols = len(lines[0].split(","))
        ok = cols == expected_cols
        return ok, f"{cols} kolon" if ok else f"{cols} kolon, beklenen={expected_cols}"
    return True, f"{len(lines)} satır"


# ═══ Seviye 2: İstatistiksel ═══

def metric_threshold(value: float, min_val: float = None, max_val: float = None) -> tuple[bool, str]:
    if min_val is not None and value < min_val:
        return False, f"{value} < {min_val} (minimum)"
    if max_val is not None and value > max_val:
        return False, f"{value} > {max_val} (maximum)"
    return True, f"{value} aralıkta"


# ═══ Seviye sınıflandırma ═══

VERIFY_LEVELS = {
    "equals": 5, "assert_equal": 5, "assert_range": 5, "assert_count": 5,
    "test_passes": 4,
    "output_contains": 3, "output_matches": 3, "json_validate": 3,
    "metric_threshold": 2,
    "exit_code": 0, "not_empty": 0, "is_boolean": 0,
}


def classify_verify(method: str) -> int:
    """Return verification level (0-5)."""
    return VERIFY_LEVELS.get(method, 0)


def verify_level_report(recipes_dir: str = ".cont/hive/recipes") -> dict:
    """Count verify methods by level across all recipes."""
    from pathlib import Path
    import yaml

    levels = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    total = 0

    for f in Path(recipes_dir).rglob("*.yaml"):
        try:
            d = yaml.safe_load(f.read_text())
            if not d:
                continue
            for s in d.get("steps", []):
                v = s.get("verify", {})
                if isinstance(v, dict):
                    total += 1
                    lvl = classify_verify(v.get("method", ""))
                    levels[lvl] += 1
        except Exception:
            continue

    return {
        "total": total,
        "levels": levels,
        "debt_ratio": round(levels[0] / total, 4) if total else 0,
        "strong_ratio": round((levels[3] + levels[4] + levels[5]) / total, 4) if total else 0,
    }


if __name__ == "__main__":
    report = verify_level_report()
    print("=== Verify Seviye Raporu ===")
    for lvl in range(5, -1, -1):
        count = report["levels"][lvl]
        pct = count / report["total"] * 100 if report["total"] else 0
        bar = "█" * int(pct / 2)
        print(f"  Seviye {lvl}: {count:3d} ({pct:5.1f}%) {bar}")
    print(f"\n  Borç (Seviye 0): {report['debt_ratio']*100:.1f}%")
    print(f"  Güçlü (Seviye 3+): {report['strong_ratio']*100:.1f}%")
