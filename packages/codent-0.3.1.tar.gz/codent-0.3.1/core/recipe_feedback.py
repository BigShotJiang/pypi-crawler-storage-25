# core/recipe_feedback.py
"""Feedback döngüsü — reçete YAML güncelleme, trail recipe_id, fitness sync.

Düzeltme 1: record_failure çağrısı (runtime'dan)
Düzeltme 2: YAML success_count/fail_count güncelleme
Düzeltme 3: trail'e recipe_id yazma
"""

import json
from datetime import datetime
from pathlib import Path

import yaml

from core.utils import debug as _debug

HIVE_DIR = Path(__file__).parent.parent / ".cont" / "hive"
RECIPES_DIR = HIVE_DIR / "recipes"
TRAIL_PATH = HIVE_DIR / "pheromone" / "trail.jsonl"


def update_recipe_yaml(recipe_id: str, success: bool) -> bool:
    """Reçete YAML'ında success_count veya fail_count'u +1 artır.

    recipe_id: reçete adı (YAML dosya adı veya name alanı)
    """
    # Tüm YAML'larda ara
    for layer in ("primitives", "composites", "project"):
        layer_dir = RECIPES_DIR / layer
        if not layer_dir.exists():
            continue
        for f in layer_dir.glob("*.yaml"):
            try:
                data = yaml.safe_load(f.read_text(encoding="utf-8"))
                if not data or not isinstance(data, dict):
                    continue
                name = data.get("name", f.stem)
                if name == recipe_id or f.stem == recipe_id:
                    key = "success_count" if success else "fail_count"
                    data[key] = data.get(key, 0) + 1
                    f.write_text(yaml.dump(data, allow_unicode=True,
                                           default_flow_style=False, sort_keys=False),
                                 encoding="utf-8")
                    _debug(f"[FEEDBACK] {name}: {key} → {data[key]}")
                    return True
            except Exception:
                continue
    return False


def log_trail_with_recipe(task: str, success: bool, tools: list,
                           elapsed: float, recipe_id: str = None):
    """trail.jsonl'e recipe_id bilgisiyle log yaz."""
    entry = {
        "ts": datetime.now().isoformat(),
        "task": task[:200] if task else "",
        "success": success,
        "tools": [t if isinstance(t, str) else str(t) for t in (tools or [])],
        "tool_count": len(tools or []),
        "elapsed": round(elapsed, 1),
    }
    if recipe_id:
        entry["recipe_id"] = recipe_id
        entry["recipe_matched"] = True

    try:
        TRAIL_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(TRAIL_PATH, "a") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception as e:
        _debug(f"[FEEDBACK] Trail log error: {e}")


def on_task_done(task: str, success: bool, tools: list,
                  elapsed: float, recipe_id: str = None):
    """Görev tamamlandığında çağrılır — YAML güncelle + trail logla.

    Bu fonksiyon runtime.py'den çağrılır, her görev sonunda.
    """
    # 1. YAML güncelle (recipe eşleşmişse)
    if recipe_id:
        update_recipe_yaml(recipe_id, success)

    # 2. Trail'e recipe_id ile logla
    log_trail_with_recipe(task, success, tools, elapsed, recipe_id)
