#!/usr/bin/env python3
"""Deterministic ML preprocessing and training tools for pDNA recipes.

Usage: python3 core/ml_tools.py <command> <args...>

Preprocessing:
  drop_correlated <path> [threshold]      Drop highly correlated features
  log_transform <path> [skew_threshold]   Log1p transform skewed columns
  handle_imbalance <path> <target> <method>  Fix class imbalance
  impute_nulls <path> [strategy]          Fill/drop nulls
  split <path> <target> [test_ratio]      Stratified train/test split

Training:
  train <path> <target> <model_type> [params_json]  Train model
  evaluate <model_path> <test_path> <target>        Evaluate model
  compare <results_dir>                             Compare models

Supports: .csv, .parquet, .duckdb (with --table)
"""

import json
import os
import sys
from pathlib import Path


def _load(path: str, table: str = None):
    """Load data from CSV, parquet, or DuckDB."""
    import pandas as pd
    p = Path(path)
    if p.suffix == ".csv":
        return pd.read_csv(p)
    elif p.suffix == ".parquet":
        return pd.read_parquet(p)
    elif p.suffix == ".duckdb":
        import duckdb
        con = duckdb.connect(str(p), read_only=True)
        df = con.execute(f"SELECT * FROM {table}").df()
        con.close()
        return df
    else:
        raise ValueError(f"Unsupported: {p.suffix}")


def _save(df, path: str):
    """Save dataframe."""
    import pandas as pd
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.suffix == ".parquet":
        df.to_parquet(p, index=False)
    else:
        df.to_csv(p, index=False)


# ── Preprocessing ──

def cmd_drop_correlated(path, threshold=0.95, table=None, out=None):
    import pandas as pd
    df = _load(path, table)
    numeric = df.select_dtypes(include=["number"])
    corr = numeric.corr().abs()

    upper = corr.where(lambda x: x.values != 1.0)
    to_drop = set()
    for col in upper.columns:
        high = upper.index[upper[col] > threshold].tolist()
        for h in high:
            if h not in to_drop and col not in to_drop:
                # Drop the one with more nulls
                null_col = df[col].isnull().sum()
                null_h = df[h].isnull().sum()
                to_drop.add(col if null_col >= null_h else h)

    df_clean = df.drop(columns=list(to_drop))
    if out:
        _save(df_clean, out)
    print(json.dumps({
        "original_cols": len(df.columns),
        "dropped": list(to_drop),
        "remaining_cols": len(df_clean.columns),
        "output": out or "stdout",
    }, indent=2))


def cmd_log_transform(path, skew_threshold=2.0, table=None, out=None):
    import numpy as np
    df = _load(path, table)
    numeric_cols = df.select_dtypes(include=["number"]).columns
    transformed = []

    # Never transform binary/target columns
    skip_cols = {c for c in numeric_cols if df[c].nunique() <= 2}
    for col in numeric_cols:
        if col in skip_cols:
            continue
        skew = float(df[col].dropna().skew())
        if abs(skew) > skew_threshold and df[col].min() >= 0:
            df[col] = np.log1p(df[col])
            new_skew = float(df[col].dropna().skew())
            transformed.append({"column": col, "old_skew": round(skew, 4), "new_skew": round(new_skew, 4)})

    if out:
        _save(df, out)
    print(json.dumps({
        "threshold": skew_threshold,
        "transformed": transformed,
        "count": len(transformed),
        "output": out or "stdout",
    }, indent=2))


def cmd_handle_imbalance(path, target, method="class_weight", table=None, out=None):
    df = _load(path, table)
    y = df[target]
    X = df.drop(columns=[target])

    old_counts = y.value_counts().to_dict()
    old_ratio = max(old_counts.values()) / min(old_counts.values()) if len(old_counts) >= 2 else 1

    if method == "smote":
        from imblearn.over_sampling import SMOTE
        sm = SMOTE(random_state=42)
        X_res, y_res = sm.fit_resample(X, y)
    elif method == "adasyn":
        from imblearn.over_sampling import ADASYN
        ada = ADASYN(random_state=42)
        X_res, y_res = ada.fit_resample(X, y)
    elif method == "undersample":
        from imblearn.under_sampling import RandomUnderSampler
        rus = RandomUnderSampler(random_state=42)
        X_res, y_res = rus.fit_resample(X, y)
    elif method == "class_weight":
        # No resampling — return original, weight handled at model level
        X_res, y_res = X, y
    else:
        print(json.dumps({"error": f"Unknown method: {method}"}))
        return

    import pandas as pd
    df_res = pd.concat([X_res, y_res], axis=1)
    new_counts = y_res.value_counts().to_dict()
    new_ratio = max(new_counts.values()) / min(new_counts.values()) if len(new_counts) >= 2 else 1

    if out:
        _save(df_res, out)
    print(json.dumps({
        "method": method,
        "old_counts": {str(k): int(v) for k, v in old_counts.items()},
        "new_counts": {str(k): int(v) for k, v in new_counts.items()},
        "old_ratio": round(old_ratio, 2),
        "new_ratio": round(new_ratio, 2),
        "output": out or "stdout",
    }, indent=2))


def cmd_impute_nulls(path, strategy="median", table=None, out=None):
    import pandas as pd
    df = _load(path, table)
    null_before = int(df.isnull().sum().sum())

    if strategy == "drop":
        df = df.dropna()
    else:
        numeric = df.select_dtypes(include=["number"]).columns
        for col in numeric:
            if df[col].isnull().any():
                if strategy == "median":
                    df[col] = df[col].fillna(df[col].median())
                elif strategy == "mean":
                    df[col] = df[col].fillna(df[col].mean())
                elif strategy == "mode":
                    df[col] = df[col].fillna(df[col].mode().iloc[0] if not df[col].mode().empty else 0)

    null_after = int(df.isnull().sum().sum())
    if out:
        _save(df, out)
    print(json.dumps({
        "strategy": strategy,
        "null_before": null_before,
        "null_after": null_after,
        "rows": len(df),
        "output": out or "stdout",
    }, indent=2))


def cmd_split(path, target, test_ratio=0.2, table=None, out_dir=None):
    from sklearn.model_selection import train_test_split
    df = _load(path, table)

    train, test = train_test_split(df, test_size=float(test_ratio),
                                    stratify=df[target], random_state=42)

    if out_dir:
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        _save(train, f"{out_dir}/train.parquet")
        _save(test, f"{out_dir}/test.parquet")

    train_dist = train[target].value_counts().to_dict()
    test_dist = test[target].value_counts().to_dict()
    print(json.dumps({
        "total": len(df),
        "train_rows": len(train),
        "test_rows": len(test),
        "test_ratio_actual": round(len(test) / len(df), 4),
        "train_distribution": {str(k): int(v) for k, v in train_dist.items()},
        "test_distribution": {str(k): int(v) for k, v in test_dist.items()},
        "output_dir": out_dir or "stdout",
    }, indent=2))


# ── Training ──

def cmd_train(path, target, model_type="lightgbm", params_json=None, table=None, out=None):
    import numpy as np
    df = _load(path, table)
    y = df[target]
    X = df.drop(columns=[target]).select_dtypes(include=["number"])

    params = json.loads(params_json) if params_json else {}

    if model_type == "lightgbm":
        import lightgbm as lgb
        default_params = {
            "n_estimators": 200, "learning_rate": 0.05, "max_depth": 6,
            "num_leaves": 31, "min_child_samples": 20,
            "class_weight": "balanced", "random_state": 42, "verbose": -1,
        }
        default_params.update(params)
        model = lgb.LGBMClassifier(**default_params)
        model.fit(X, y)

    elif model_type == "xgboost":
        import xgboost as xgb
        # Calculate scale_pos_weight
        neg = (y == 0).sum()
        pos = (y == 1).sum()
        spw = neg / pos if pos > 0 else 1
        default_params = {
            "n_estimators": 200, "learning_rate": 0.05, "max_depth": 6,
            "scale_pos_weight": spw, "random_state": 42,
            "eval_metric": "logloss", "verbosity": 0,
        }
        default_params.update(params)
        model = xgb.XGBClassifier(**default_params)
        model.fit(X, y)

    else:
        print(json.dumps({"error": f"Unknown model: {model_type}"}))
        return

    if out:
        import joblib
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({"model": model, "features": list(X.columns), "target": target}, out)

    print(json.dumps({
        "model_type": model_type,
        "features": len(X.columns),
        "train_rows": len(X),
        "params": {k: str(v) for k, v in (default_params if model_type != "tabnet" else params).items()},
        "output": out or "in_memory",
    }, indent=2))


def cmd_evaluate(model_path, test_path, target, table=None):
    import joblib
    import numpy as np
    from sklearn.metrics import f1_score, precision_score, recall_score, confusion_matrix, classification_report

    data = joblib.load(model_path)
    model = data["model"]
    features = data["features"]

    df = _load(test_path, table)
    y_true = df[target]
    X = df[features]

    y_pred = model.predict(X)

    f1 = round(float(f1_score(y_true, y_pred, zero_division=0)), 4)
    prec = round(float(precision_score(y_true, y_pred, zero_division=0)), 4)
    rec = round(float(recall_score(y_true, y_pred, zero_division=0)), 4)
    cm = confusion_matrix(y_true, y_pred).tolist()

    print(json.dumps({
        "model_path": model_path,
        "test_rows": len(df),
        "f1": f1,
        "precision": prec,
        "recall": rec,
        "confusion_matrix": cm,
    }, indent=2))


def cmd_compare(results_dir):
    results = []
    for f in sorted(Path(results_dir).glob("*.json")):
        try:
            data = json.loads(f.read_text())
            results.append({"name": f.stem, **data})
        except Exception:
            continue

    results.sort(key=lambda x: -x.get("f1", 0))
    print(json.dumps({
        "experiments": len(results),
        "ranking": [{"name": r["name"], "f1": r.get("f1"), "precision": r.get("precision"), "recall": r.get("recall")} for r in results],
        "best": results[0]["name"] if results else None,
    }, indent=2))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1]
    table = None
    out = None
    args = []
    i = 2
    while i < len(sys.argv):
        if sys.argv[i] == "--table" and i + 1 < len(sys.argv):
            table = sys.argv[i + 1]; i += 2
        elif sys.argv[i] == "--out" and i + 1 < len(sys.argv):
            out = sys.argv[i + 1]; i += 2
        else:
            args.append(sys.argv[i]); i += 1

    commands = {
        "drop_correlated": lambda: cmd_drop_correlated(args[0], float(args[1]) if len(args) > 1 else 0.95, table, out),
        "log_transform": lambda: cmd_log_transform(args[0], float(args[1]) if len(args) > 1 else 2.0, table, out),
        "handle_imbalance": lambda: cmd_handle_imbalance(args[0], args[1], args[2] if len(args) > 2 else "class_weight", table, out),
        "impute_nulls": lambda: cmd_impute_nulls(args[0], args[1] if len(args) > 1 else "median", table, out),
        "split": lambda: cmd_split(args[0], args[1], args[2] if len(args) > 2 else 0.2, table, out),
        "train": lambda: cmd_train(args[0], args[1], args[2] if len(args) > 2 else "lightgbm", args[3] if len(args) > 3 else None, table, out),
        "evaluate": lambda: cmd_evaluate(args[0], args[1], args[2], table),
        "compare": lambda: cmd_compare(args[0]),
    }

    if cmd not in commands:
        print(f"Unknown command: {cmd}"); sys.exit(1)
    commands[cmd]()
