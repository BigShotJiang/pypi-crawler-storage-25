#!/usr/bin/env python3
"""
cont - Offline Claude Code–like coding agent
Runs against a local OpenAI-compatible LLM (e.g., LM Studio)
"""

import os
import sys
import json
import hashlib
import select
import shlex
import subprocess
import argparse
import socket
import ipaddress
import re
import shutil
import threading
import tarfile
import io
import itertools
import sqlite3
import time
from pathlib import Path
from datetime import datetime
from typing import Any, Optional
from collections import deque
from urllib.parse import urlparse, parse_qs, unquote
from html.parser import HTMLParser

from rich import print as rprint
from rich.console import Console
from openai import OpenAI
import httpx
import requests

# Anti-hallucination system (Sprint 1)
try:
    from core.verification import ResponseVerifier, detect_hallucination_language
    from core.prompts import build_system_prompt
    from core.structured_output import parse_structured_response
    VERIFICATION_ENABLED = True
except ImportError:
    VERIFICATION_ENABLED = False
    print("[Warning] Verification module not found, running without anti-hallucination", file=sys.stderr)

# Self-improvement system (Sprint: self-improve)
try:
    from core.self_improve import SelfImprover, SelfImproveLoop
    from core.adaptive_prompt import build_adaptive_prompt, estimate_tokens
    from core.task_classifier import classify_task as _classify_task, is_turkish as _is_turkish
    SELF_IMPROVE_ENABLED = True
except ImportError:
    SELF_IMPROVE_ENABLED = False
    print("[Warning] Self-improvement modules not found, running without self-improvement", file=sys.stderr)

# Learning system (recipes, vocabulary, patches, decomposer)
try:
    from core.recipes import (load_recipes, match_recipe, format_recipe_for_prompt,
                              record_recipe_outcome, get_recipe_stats, save_recipe,
                              init_recipe_db, seed_recipes, recipe_to_prompt,
                              record_success as recipe_record_success,
                              record_failure as recipe_record_failure,
                              list_recipes, cleanup_junk_recipes)
    from core.vocabulary import (load_vocabulary, get_relevant_vocab, add_word,
                                 get_vocabulary_stats)
    from core.prompt_patches import (load_file_patches, match_patches,
                                     format_patches_for_prompt, record_patch_outcome,
                                     get_patch_stats)
    from core.decomposer import should_decompose, decompose, format_decomposed_task, decompose_compound_task
    LEARNING_ENABLED = True
except ImportError:
    LEARNING_ENABLED = False

# Automation system (events, scheduler, automations)
try:
    from core.events import event_bus
    from core.scheduler import Scheduler
    from core.automations import (load_automations, match_automation,
                                  AutomationRunner, register_event_handlers)
    AUTOMATION_ENABLED = True
except ImportError:
    AUTOMATION_ENABLED = False
    event_bus = None

# Claude Code CLI escalation (optional)
try:
    from core.escalation import get_escalation
    ESCALATION_ENABLED = True
except ImportError:
    ESCALATION_ENABLED = False

# Tiered security system (optional)
try:
    from core.safety import SecurityManager, SecurityTier
    SAFETY_ENABLED = True
except ImportError:
    SAFETY_ENABLED = False

# Phase-0 Prelude system (warmup + prefetch + auto-recall)
try:
    from core.prefetch import run_phase0, PrefetchCache
    PHASE0_ENABLED = True
except ImportError:
    PHASE0_ENABLED = False
    PrefetchCache = None

# System Fastpath (Lane A: system resolves → LLM formats, no tools)
try:
    from core.system_executor import SystemExecutor
    FASTPATH_ENABLED = True
except ImportError:
    FASTPATH_ENABLED = False
    SystemExecutor = None

# Router (pure routing decision — no execution)
from core.router import (
    route_task as _route_task_decision, extract_raw_input, extract_url,
    extract_goal, init_router, _URL_RE,
)

# Runtime helpers (extracted from cont.py)
from core.runtime import (
    should_decompose as _should_decompose, is_retry_input,
    extract_dir_from_results as _extract_dir_from_results,
    extract_file_paths_from_results as _extract_file_paths_from_results,
    load_files_for_summary as _load_files_for_summary,
    check_hallucination as _check_hallucination,
    postprocess_response as _postprocess_response,
    self_assess as _self_assess,
    save_feedback as _save_feedback,
    process_feedback_for_learning as _process_feedback_for_learning,
    learn_from_chain as _learn_from_chain,
    build_conversation_context as _build_conversation_context,
    handle_feedback_command as _handle_feedback_command,
    init_runtime, DENIAL_PATTERNS, _DENIAL_RE,
    # ctx bridge for run_task pipeline
    RuntimeContext, ensure_runtime_ctx,
    run_task as _runtime_run_task,
    run_decomposed_task as _runtime_run_decomposed_task,
    ask_claude_tool as _runtime_ask_claude_tool,
    tool_call_signature as _runtime_tool_call_signature,
    get_system_prompt as _runtime_get_system_prompt,
    _llm_summarize as _runtime_llm_summarize,
)
from core.repl import (
    run_interactive as _repl_run_interactive,
    run_batch as _repl_run_batch,
    _save_batch_state as _repl_save_batch_state,
    _clear_batch_state as _repl_clear_batch_state,
    _is_continuation, _is_followup, _is_retry,
)
from core.formatters import sanitize_response as _sanitize_response

# CLI flag handlers (extracted from main())
from core.app import handle_exit_flags, init_app

# Episodic memory + auto-evaluator
try:
    from core.episodic import (
        init_episodic_db, record_episode, update_feedback as episodic_update_feedback,
        get_similar_episodes, get_task_stats, cleanup_old_episodes,
        run_triage,
    )
    from core.auto_eval import evaluate_task
    EPISODIC_ENABLED = True
except ImportError:
    EPISODIC_ENABLED = False

# ChatGPT Teacher (recipe learning)
try:
    from core.teacher import should_learn, learn_and_save
    TEACHER_ENABLED = True
except ImportError:
    TEACHER_ENABLED = False

console = Console()

# =====================
# Config
# =====================
REPO_ROOT = Path(os.environ.get("CONT_REPO_ROOT", os.getcwd())).resolve()
LOG_LEVEL = os.environ.get("CONT_LOG_LEVEL", "").lower()
CONT_DIR = Path(__file__).parent.resolve()
LOG_DIR = CONT_DIR / "logs" / "cont_runs"
ENV_SNAPSHOT_DIR = CONT_DIR / "logs" / "env_snapshots"
_current_log_path = None  # Path of the log file being written right now

# Current working directory (updated by navigate)
# This is separate from REPO_ROOT which is the original startup directory
_CURRENT_CWD = None

def get_current_cwd() -> Path:
    """Get current working directory, respecting navigate changes."""
    global _CURRENT_CWD
    if _CURRENT_CWD is not None:
        return _CURRENT_CWD
    return Path.cwd()

def set_current_cwd(path: Path) -> None:
    """Set current working directory."""
    global _CURRENT_CWD
    _CURRENT_CWD = path
    os.chdir(path)

def clean_surrogates(text: str) -> str:
    """Remove surrogate characters that break UTF-8 encoding.

    WSL2 can produce surrogate characters when reading Windows file paths.
    These cause 'surrogates not allowed' errors when sent to the LLM API.
    """
    if not isinstance(text, str):
        return text
    try:
        return text.encode('utf-8', errors='surrogateescape').decode('utf-8', errors='replace')
    except Exception:
        return text.encode('utf-8', errors='replace').decode('utf-8')


def _clean_messages(messages: list) -> list:
    """Clean all string values in a messages list of surrogate characters."""
    cleaned = []
    for msg in messages:
        cmsg = {}
        for k, v in msg.items():
            if isinstance(v, str):
                cmsg[k] = clean_surrogates(v)
            elif isinstance(v, list):
                # Handle tool_calls lists etc.
                cmsg[k] = v
            else:
                cmsg[k] = v
        cleaned.append(cmsg)
    return cleaned


def _debug(msg: str):
    """Print debug message if CONT_LOG_LEVEL=debug."""
    if LOG_LEVEL == "debug":
        console.print(f"[dim][DEBUG] {msg}[/dim]")

# =====================
# Prompt Strings & Formatting (extracted to core/formatters.py)
# =====================
from core.formatters import (
    FINALIZE_MARKER, LEAK_MARKERS,
    build_bare_system_prompt,
    build_format_system_prompt,
    build_browser_format_system_prompt, build_browser_rescue_system_prompt,
    build_summarize_system_prompt, build_summarize_user_prompt,
    build_browser_user_prompt,
    is_greeting_response,
    budget_nearly_exhausted_msg, budget_exhausted_msg,
    read_blocked_msg, tool_blocked_msg, tool_blocked_path_hint,
    tool_limit_reached_msg, tool_limit_system_inject_msg,
    phase_checkpoint_msg, all_phases_exhausted_msg,
    too_many_blocks_msg, task_reminder_msg,
    empty_response_msg, security_blocked_msg, unknown_tool_msg,
)

# =====================
# Identity & Home Management (extracted to core/identity.py)
# =====================
from core.identity import (
    CONT_CONFIG_DIR, CONT_HOME_FILE, CONT_SOUL_FILE, CONT_STATE_FILE,
    _ensure_config_dir, _ensure_learning_data,
    get_cont_home, set_cont_home, get_soul, _get_default_soul,
    get_current_state, get_startup_context,
)

# Smart Path Resolution (extracted to core/path_resolution.py)
# =====================
from core.path_resolution import (
    IS_WSL, normalize_path, resolve_path, path_exists_fuzzy,
)

# Tool Implementations (extracted to core/tools.py)
# =====================
from core.tools import (
    init_tools,
    safe_path, block_dangerous, is_step_safe, _shell_timeout,
    DANGEROUS_PATTERNS, _UNSAFE_STEP_PATTERNS,
    open_file, list_dir, read_file, write_file, apply_patch,
    run_shell, _run_shell_capture, search_files,
    find_path, navigate, system_search,
    normalize_tool_call, PER_TOOL_CAPS, _TOOL_ALTERNATIVES,
    _ARG_ALIASES, _TOOL_NAME_ALIASES, _SEARCH_EXCLUDE_DIRS,
)

# CLI Parser (extracted to core/cli.py)
# =====================
from core.cli import build_parser
from core.trace import init_trace, TraceLevel, is_off as _trace_off

# Intent Detection & Write Protection (extracted to core/intent_detection.py)
# =====================
from core.intent_detection import (
    READ_INTENT_PATTERNS, WRITE_INTENT_PATTERNS,
    DESTRUCTIVE_TOOLS, DESTRUCTIVE_SHELL_PATTERNS, SAFE_READ_COMMANDS,
    detect_user_intent, is_shell_destructive, WriteProtection,
)

# Global write protection instance
_write_protection = None

def get_write_protection() -> WriteProtection:
    global _write_protection
    if _write_protection is None:
        _write_protection = WriteProtection(backup_dir=CONT_DIR / "backups")
    return _write_protection


# Global security manager instance
_security_manager = None

def get_security_manager():
    """Get or create the global SecurityManager."""
    global _security_manager
    if _security_manager is None and SAFETY_ENABLED:
        _security_manager = SecurityManager(
            repo_root=Path(REPO_ROOT),
            db_path=_memory_db_path(),
            backup_dir=CONT_DIR / "backups",
            enabled=True,
        )
    return _security_manager

def _request_tier2_approval(tool_name: str, args: dict, perm) -> bool:
    """
    Interactive TIER_2 approval prompt. Returns True if user approves.
    Bilingual (Turkish + English).
    """
    console.print()
    console.print("[bold yellow]--- ONAY GEREKLİ / APPROVAL REQUIRED ---[/bold yellow]")
    console.print(f"[cyan]Tier:[/cyan] TIER_{int(perm.tier)} ({perm.tier.name})")
    console.print(f"[cyan]Tool:[/cyan] {tool_name}")

    if tool_name == "run_shell":
        console.print(f"[cyan]Command:[/cyan] {args.get('cmd', '?')}")
    elif "path" in args:
        console.print(f"[cyan]Path:[/cyan] {args['path']}")
    if "url" in args:
        console.print(f"[cyan]URL:[/cyan] {args['url']}")

    console.print()
    console.print("[dim]y/yes/evet = approve (this session) | n/no/hayır = deny[/dim]")
    console.print("[bold yellow]> [/bold yellow]", end="")

    try:
        response = input().strip().lower()
        return response in ("y", "yes", "evet", "e")
    except (EOFError, KeyboardInterrupt):
        return False

# Sticky Model Config (extracted to core/sticky_config.py)
# =====================
from core.sticky_config import (
    _load_sticky_config, _save_sticky_config,
    _get_sticky_model, _set_sticky_model,
    _get_auto_mode, _set_auto_mode,
    _forget_sticky_model,
)

# =====================
# Adaptive Model Routing (extracted to core/model_routing.py)
# =====================
from core.model_routing import (
    MODEL_TIERS, SIMPLE_TASK_PATTERNS, COMPLEX_TASK_PATTERNS,
    detect_task_complexity, select_model_for_tier, auto_select_model,
)

# =====================
# Environment Snapshot (extracted to core/env_snapshot.py)
# =====================
from core.env_snapshot import (
    ENV_SNAPSHOT_DIR, collect_env_snapshot, save_env_snapshot,
)

# =====================
# Memory Store (loaded from core/memory_store.py)
# =====================
from core.memory_store import (
    _cont_state_dir, _memory_db_path, _db_connect, memory_init_db,
    memory_stats, _stable_json, compute_env_id, memory_upsert_env_snapshot,
    _truncate, _error_signature_from_output, memory_log_attempt,
    memory_add_solution, _parse_iso_timestamp, memory_solution_stats,
    memory_get_best_solution, memory_check_recent_failure,
    memory_map_error, memory_unmap_error, memory_get_error_mappings,
    memory_lookup_error, memory_increment_error_hits,
    memory_enable_autofix, memory_disable_autofix,
    memory_is_autofix_enabled, memory_get_autofix_list,
    memory_get_last_failed_attempt, memory_recent_attempts,
    memory_prune, memory_export, memory_import,
    EmbeddingManager, get_embedding_manager,
    memory_remember, memory_recall, memory_hybrid_search,
    memory_forget, memory_list_all, memory_get_context,
    memory_update_daily_summary, memory_get_daily_summary,
    memory_semantic_stats,
    EMBEDDINGS_AVAILABLE,
)


from core.utils import slugify as _slugify

# Endpoint Discovery (extracted to core/endpoint_discovery.py)
from core.endpoint_discovery import (
    discover_openai_base_url, EndpointNotFoundError,
    _check_openai_endpoint,
)

# Provider Router (LM Studio primary, Ollama fallback)
from core.provider_router import (
    get_provider as _get_provider,
    ProviderUnavailableError,
)

# Discover working base URL at startup (LM Studio → Ollama fallback)
# Discover working base URL at startup (LM Studio → Ollama fallback)
_PROVIDER_NAME = "lmstudio"
try:
    BASE_URL, _TRIED_URLS = discover_openai_base_url()
except EndpointNotFoundError:
    from core.provider_router import _check_provider, OLLAMA_BASE
    _ollama_models = _check_provider(OLLAMA_BASE)
    if _ollama_models:
        BASE_URL = OLLAMA_BASE
        _TRIED_URLS = [OLLAMA_BASE]
        _PROVIDER_NAME = "ollama"
        console.print("[yellow]LM Studio unavailable, using Ollama fallback.[/yellow]")
    else:
        console.print("[bold red]Error: No LLM provider available.[/bold red]")
        console.print("\n[yellow]Hint:[/yellow] Start LM Studio (port 1234) or Ollama (port 11434).")
        sys.exit(1)
API_KEY = os.environ.get("OPENAI_API_KEY", "lmstudio")
TIMEOUT = int(os.environ.get("CONT_TIMEOUT", "120"))  # seconds

# OpenAI Cloud API (separate from local LLM endpoint)
_OPENAI_CLOUD_KEY = None
_openai_cloud_client = None

def _load_openai_cloud_key():
    """Load OpenAI cloud API key from env or config file."""
    global _OPENAI_CLOUD_KEY
    if _OPENAI_CLOUD_KEY:
        return _OPENAI_CLOUD_KEY
    key = os.environ.get("CONT_OPENAI_KEY") or os.environ.get("OPENAI_CLOUD_API_KEY")
    if not key:
        # Also check OPENAI_API_KEY if it looks like a real OpenAI key
        _oai = os.environ.get("OPENAI_API_KEY", "")
        if _oai.startswith("sk-"):
            key = _oai
    if not key:
        key_file = Path.home() / ".config" / "cont" / "openai_key"
        if key_file.exists():
            try:
                key = key_file.read_text().strip()
            except OSError:
                pass
    if key and key.startswith("sk-"):
        _OPENAI_CLOUD_KEY = key
    return _OPENAI_CLOUD_KEY

def _get_openai_cloud_client():
    """Get or create OpenAI cloud client (lazy)."""
    global _openai_cloud_client
    if _openai_cloud_client is not None:
        return _openai_cloud_client
    key = _load_openai_cloud_key()
    if not key:
        return None
    _openai_cloud_client = OpenAI(
        api_key=key,
        timeout=httpx.Timeout(120.0, connect=10.0)
    )
    return _openai_cloud_client
MAX_ITERATIONS = int(os.environ.get("CONT_MAX_STEPS", "40"))
TOOL_BUDGET = int(os.environ.get("CONT_TOOL_BUDGET", "12"))


# Dynamic Tool Budget (extracted to core/tool_budget.py)
from core.tool_budget import DynamicToolBudget, BulkReadMode


# Optional token limits (None = use defaults)
_MAX_TOKENS: Optional[int] = None  # Set by --max-tokens or CONT_MAX_TOKENS
_CONTEXT_LIMIT: Optional[int] = None  # Set by --context-limit or CONT_CONTEXT_LIMIT (hint only)

# =====================
# Model-Agnostic LLM Layer
# =====================
# Model will be resolved dynamically: CLI > env > sticky > auto-detect
_MODEL_OVERRIDE: Optional[str] = None  # Set by --model flag
_MODEL_LIKE_OVERRIDE: Optional[str] = None  # Set by --model-like flag (fuzzy match)
_ENDPOINT_MODE: Optional[str] = None  # "chat" or "completions", cached per run
_STRICT_MODEL: bool = True  # Strict model validation when override is set
_SAVE_MODEL: bool = True  # Whether to persist model as sticky
_SKIP_MODELS_FETCH: bool = False  # Skip /v1/models fetch when using sticky

# Model resolution (extracted to core/model.py)
from core.model import (
    init_model, list_available_models, validate_model_id, find_model_like,
    resolve_model as _resolve_model_core,
    flatten_messages_to_prompt as _model_flatten_messages,
    probe_chat_endpoint as _model_probe_chat,
    determine_endpoint_mode as _model_determine_endpoint,
    check_response_model as _model_check_response,
    get_endpoint_mode as _model_get_endpoint_mode,
    get_model_mismatch_detected as _model_get_mismatch,
    reset_endpoint_mode as _model_reset_endpoint,
)

def resolve_model(strict=None, save=None, **kw):
    """Compatibility wrapper — passes cont.py globals to core.model.resolve_model."""
    return _resolve_model_core(
        model_override=_MODEL_OVERRIDE,
        model_like_override=_MODEL_LIKE_OVERRIDE,
        strict=strict if strict is not None else _STRICT_MODEL,
        save=save if save is not None else _SAVE_MODEL,
        skip_fetch=_SKIP_MODELS_FETCH,
        **kw,
    )


# =====================
# LM Studio Model Management (Best Effort)
# LM Studio Model Management (extracted to core/lmstudio.py)
# =====================
from core.lmstudio import (
    _probe_lmstudio_unload, _lmstudio_unload_model, _lmstudio_load_model,
    _lmstudio_eject_all, _lmstudio_ensure_model, _lmstudio_get_loaded,
)
_NO_UNLOAD: bool = False  # Set by --no-unload flag


def handle_model_switch(new_model: str, old_model: Optional[str] = None) -> None:
    """
    Handle switching to a new model, unloading old one if supported.
    Best effort - never fails the operation.
    """
    if not old_model or old_model == new_model:
        return

    if _NO_UNLOAD:
        _debug("Model unload skipped (--no-unload)")
        return

    if _probe_lmstudio_unload(BASE_URL):
        console.print(f"[dim]Switching from {old_model} to {new_model}...[/dim]")
        if _lmstudio_unload_model(BASE_URL, old_model):
            console.print(f"[dim]Unloaded {old_model}[/dim]")
    else:
        _debug("LM Studio unload not supported; switching model may keep previous loaded")


# Model helpers — thin wrappers (impl in core/model.py)
def _flatten_messages_to_prompt(messages: list) -> str:
    return _model_flatten_messages(messages)

def _probe_chat_endpoint(model: str) -> bool:
    return _model_probe_chat(model)

def _determine_endpoint_mode(model: str) -> str:
    global _ENDPOINT_MODE
    _ENDPOINT_MODE = _model_determine_endpoint(model)
    return _ENDPOINT_MODE

def _check_response_model(requested_model: str, response) -> None:
    global _MODEL_MISMATCH_DETECTED
    from core import model as _cm
    _cm._model_override = _MODEL_OVERRIDE
    _cm._strict_model = _STRICT_MODEL
    _model_check_response(requested_model, response)
    _MODEL_MISMATCH_DETECTED = _model_get_mismatch()

_MODEL_MISMATCH_DETECTED = False


def _truncate_for_context(messages: list, max_chars: int = 20000) -> list:
    """
    Hard truncate messages to fit context window.
    8192 tokens ≈ 24000 chars for multilingual.
    Default 20000 leaves room for response generation.
    """
    total = sum(len(m.get("content", "") or "") for m in messages)

    if total <= max_chars:
        return messages

    _debug(f"_truncate_for_context: {total} chars > {max_chars}")

    # Strategy 1: Truncate system message if too long
    for msg in messages:
        if msg["role"] == "system" and len(msg.get("content", "") or "") > 8000:
            content = msg["content"]
            # Keep first 4000 chars (core instructions) + last 2000 (current context)
            msg["content"] = (
                content[:4000] +
                "\n\n...[sistem promptu kırpıldı]...\n\n" +
                content[-2000:]
            )

    # Strategy 2: Truncate user messages
    total = sum(len(m.get("content", "") or "") for m in messages)
    if total > max_chars:
        for msg in messages:
            if msg["role"] == "user" and len(msg.get("content", "") or "") > 4000:
                content = msg["content"]
                msg["content"] = (
                    content[:3000] +
                    "\n\n...[içerik kırpıldı]...\n\n" +
                    content[-1000:]
                )

    # Strategy 3: If STILL too big, aggressive truncation
    total = sum(len(m.get("content", "") or "") for m in messages)
    if total > max_chars:
        for msg in messages:
            content = msg.get("content", "") or ""
            if len(content) > 3000:
                msg["content"] = content[:2000] + "\n...[kırpıldı]..."

    # Strategy 4: Nuclear option — keep only system + last user message
    total = sum(len(m.get("content", "") or "") for m in messages)
    if total > max_chars:
        _debug(f"Nuclear truncation: {total} > {max_chars}")
        system_msg = None
        last_user = None
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg
            if msg["role"] == "user":
                last_user = msg

        messages.clear()
        if system_msg:
            system_msg["content"] = (system_msg.get("content", "") or "")[:5000]
            messages.append(system_msg)
        if last_user:
            last_user["content"] = (last_user.get("content", "") or "")[:3000]
            messages.append(last_user)

    return messages


def _ensure_context_fits(messages: list, max_context_chars: int = 16000) -> list:
    """Truncate messages if total content exceeds context window.

    Default 16000 chars ≈ 5000-6000 tokens for Turkish text (2.5-3 chars/token).
    Leaves room for system prompt + response generation.
    """
    total_chars = sum(len(m.get("content", "") or "") for m in messages)
    if total_chars <= max_context_chars:
        return messages

    _debug(f"Context overflow: {total_chars} chars > {max_context_chars}, truncating")

    # Pass 1: Truncate messages longer than 2000 chars, starting from longest
    for msg in sorted(messages, key=lambda m: len(m.get("content", "") or ""), reverse=True):
        content = msg.get("content", "") or ""
        if len(content) > 2000 and total_chars > max_context_chars:
            old_len = len(content)
            if msg.get("role") == "system":
                # System prompt: keep first 2000 + last 500
                msg["content"] = content[:2000] + "\n...[kırpıldı]...\n" + content[-500:]
            else:
                # User/assistant: keep first 1500 + last 500
                msg["content"] = content[:1500] + "\n...[kırpıldı]...\n" + content[-500:]
            total_chars -= (old_len - len(msg["content"]))
            if total_chars <= max_context_chars:
                break

    # Pass 2: If still over, aggressively truncate all non-system messages > 1000 chars
    if total_chars > max_context_chars:
        for msg in sorted(messages, key=lambda m: len(m.get("content", "") or ""), reverse=True):
            content = msg.get("content", "") or ""
            if msg.get("role") != "system" and len(content) > 1000 and total_chars > max_context_chars:
                old_len = len(content)
                msg["content"] = content[:800] + "\n...[kırpıldı]"
                total_chars -= (old_len - len(msg["content"]))
                if total_chars <= max_context_chars:
                    break

    # Pass 3: Nuclear option — drop middle messages if still over
    if total_chars > max_context_chars and len(messages) > 3:
        _debug(f"Nuclear truncation: dropping middle messages ({total_chars} > {max_context_chars})")
        # Keep first (system), second (user task), and last 2 messages
        kept = [messages[0], messages[1]] + messages[-2:]
        messages.clear()
        messages.extend(kept)

    return messages


def _sanitize_tool_arguments(raw: str) -> str:
    """Layer 1: Fix tool_call JSON at the adapter boundary.

    Uses canonical fixup_json from core.utils (single source of truth).
    On failure, returns raw string unchanged — Layer 2 in runtime.py
    will handle it (refuse + ask LLM to regenerate).
    """
    from core.utils import fixup_json
    fixed, method = fixup_json(raw)
    if method:
        _debug(f"tool_arguments sanitized ({method})")
    return fixed


def llm_complete(
    model: str,
    messages: list,
    tools: Optional[list] = None,
    tool_choice: Optional[str] = None
) -> dict:
    """
    Model-agnostic LLM completion.
    Automatically uses chat or completions endpoint based on model support.

    Returns dict with:
    - content: str (response text)
    - tool_calls: list or None
    - raw_response: original response object
    """
    global MODEL
    # Safety: if model is empty, resolve it now
    if not model:
        model = resolve_model()
        MODEL = model
        _debug(f"llm_complete: model was empty, resolved to {model}")

    # Eject guard: LM Studio'da doğru modelin yüklü olduğunu garanti et
    # (üst üste binme koruması — yanlış model VRAM'i işgal etmesin)
    # Sadece ilk çağrıda kontrol et (session başına bir kez yeterli)
    if not getattr(llm_complete, '_model_ensured', False):
        _lmstudio_ensure_model(BASE_URL, model)
        llm_complete._model_ensured = True

    # Ensure messages fit in context window before sending.
    # Tool schemas consume ~5200 tokens, so subtract that from the budget.
    # Reserve 500 tokens for response generation.
    ctx_tokens = (_CONTEXT_LIMIT or 32768)
    tool_overhead = 5500 if tools else 0  # tool schemas ≈ 5200 tokens
    available_tokens = ctx_tokens - tool_overhead - 500  # response headroom
    available_tokens = max(available_tokens, 4000)  # floor
    context_limit = int(available_tokens * 2.5)  # tokens → chars (Turkish)
    messages = _truncate_for_context(messages, max_chars=context_limit)

    # Route to OpenAI cloud if model has openai: prefix
    if model.startswith("openai:"):
        return _llm_complete_openai(model, messages, tools, tool_choice)

    endpoint_mode = _determine_endpoint_mode(model)

    if endpoint_mode == "chat":
        result = _llm_complete_chat(model, messages, tools, tool_choice)
    else:
        result = _llm_complete_text(model, messages)

    # Post-response guard: check if returned model matches requested
    _check_response_model(model, result.get("raw_response"))

    return result


def _llm_complete_chat(
    model: str,
    messages: list,
    tools: Optional[list] = None,
    tool_choice: Optional[str] = None
) -> dict:
    """Use OpenAI chat completions endpoint."""
    kwargs = {
        "model": model,
        "messages": _clean_messages(messages),
    }
    if tools:
        kwargs["tools"] = tools
    if tool_choice:
        kwargs["tool_choice"] = tool_choice

    # Apply optional token limits
    if _MAX_TOKENS is not None:
        kwargs["max_tokens"] = _MAX_TOKENS
        _debug(f"Using max_tokens={_MAX_TOKENS}")

    # Context limit is a hint - only some backends support it
    # For OpenAI-compatible, we can try max_context_length or just log it
    if _CONTEXT_LIMIT is not None:
        _debug(f"Context limit hint: {_CONTEXT_LIMIT} (not all backends support this)")
        # Some backends use 'max_context_length' or 'context_length'
        # We don't set it by default as it may cause errors on incompatible backends

    response = client.chat.completions.create(**kwargs)
    msg = response.choices[0].message

    # Sanitize tool_call arguments at the adapter boundary.
    # Local models (Devstral, Nemotron, Qwen3) emit trailing commas,
    # single quotes, or unescaped control chars. Fix here so every
    # downstream consumer gets valid JSON.
    if msg.tool_calls:
        for tc in msg.tool_calls:
            tc.function.arguments = _sanitize_tool_arguments(
                tc.function.arguments or "{}"
            )

    return {
        "content": msg.content or "",
        "tool_calls": msg.tool_calls,
        "raw_response": response
    }


def _llm_complete_text(model: str, messages: list) -> dict:
    """
    Use OpenAI completions endpoint (text completion).
    Flattens messages into a single prompt.
    Note: Tools are not supported in this mode.
    """
    prompt = clean_surrogates(_flatten_messages_to_prompt(messages))

    # Use configured max_tokens or default
    max_tokens = _MAX_TOKENS if _MAX_TOKENS is not None else 2048

    url = BASE_URL.rstrip("/") + "/completions"
    payload = {
        "model": model,
        "prompt": prompt,
        "max_tokens": max_tokens,
        "temperature": 0.7,
        "stop": ["USER:", "SYSTEM:"]
    }
    headers = {"Content-Type": "application/json"}
    if API_KEY:
        headers["Authorization"] = f"Bearer {API_KEY}"

    if _MAX_TOKENS is not None:
        _debug(f"Using max_tokens={_MAX_TOKENS}")
    if _CONTEXT_LIMIT is not None:
        _debug(f"Context limit hint: {_CONTEXT_LIMIT} (not applied to completions endpoint)")

    _debug(f"Completions request to {url}")
    resp = requests.post(url, json=payload, headers=headers, timeout=TIMEOUT)

    if resp.status_code != 200:
        raise ValueError(f"Completions API error: HTTP {resp.status_code} - {resp.text[:500]}")

    data = resp.json()
    text = ""
    if data.get("choices"):
        text = data["choices"][0].get("text", "")

    return {
        "content": text.strip(),
        "tool_calls": None,  # Not supported in completions mode
        "raw_response": data
    }


def _llm_complete_openai(model: str, messages: list,
                         tools=None, tool_choice=None) -> dict:
    """Use OpenAI cloud API (gpt-4o-mini etc.)."""
    cloud = _get_openai_cloud_client()
    if not cloud:
        raise ValueError("OpenAI API key not configured. Set CONT_OPENAI_KEY or run --setup-openai")

    # openai:gpt-4o-mini -> gpt-4o-mini
    if model.startswith("openai:"):
        model = model[7:]

    kwargs = {"model": model, "messages": _clean_messages(messages)}
    if tools:
        kwargs["tools"] = tools
    if tool_choice:
        kwargs["tool_choice"] = tool_choice

    _debug(f"OpenAI cloud request: model={model}")
    response = cloud.chat.completions.create(**kwargs)
    msg = response.choices[0].message

    # Cloud models rarely need this, but same boundary guard as local
    if msg.tool_calls:
        for tc in msg.tool_calls:
            tc.function.arguments = _sanitize_tool_arguments(
                tc.function.arguments or "{}"
            )

    return {
        "content": msg.content or "",
        "tool_calls": msg.tool_calls,
        "raw_response": response
    }


# Keep MODEL as resolved value (for backward compat in logs/display)
# Will be set properly in main() after CLI parsing
MODEL: str = ""


# Web functionality loaded from core/web.py
from core.web import (web_fetch, web_search, repo_fetch,
                      WEB_MAX_BYTES, WEB_TIMEOUT, REPO_MAX_MB, ALLOWED_REPO_HOSTS,
                      EXTERNAL_DIR)


ALLOW_SHELL = True

# =====================
# WSL → Windows Open Tools
# =====================

def _is_wsl() -> bool:
    """Check if running in WSL."""
    try:
        with open("/proc/version", "r") as f:
            return "microsoft" in f.read().lower()
    except Exception:
        return False

def _wsl_to_windows_path(linux_path: str) -> str:
    """Convert WSL path to Windows path."""
    try:
        result = subprocess.run(
            ["wslpath", "-w", linux_path],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return linux_path

def open_in_explorer(path: str) -> str:
    """
    Open file or folder in Windows Explorer.
    If path is a file, Explorer opens with file selected.
    If path is a folder, Explorer opens that folder.
    """
    if not _is_wsl():
        return "Error: This tool only works in WSL environment"

    # Resolve path
    path = normalize_path(path)
    target = safe_path(path)
    if not target.exists():
        return f"Error: Path does not exist: {path}"

    # Convert to Windows path
    win_path = _wsl_to_windows_path(str(target))

    try:
        if target.is_file():
            # Open Explorer with file selected
            cmd = ["explorer.exe", "/select,", win_path]
        else:
            # Open folder
            cmd = ["explorer.exe", win_path]

        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return f"Opened in Explorer: {win_path}"
    except Exception as e:
        return f"Error opening Explorer: {e}"

def open_in_browser(url: str) -> str:
    """
    Open URL in default Windows browser.
    """
    if not _is_wsl():
        return "Error: This tool only works in WSL environment"

    # Basic URL validation
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    try:
        # wslview is part of wslu package, falls back to cmd.exe
        if shutil.which("wslview"):
            subprocess.Popen(["wslview", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            subprocess.Popen(["cmd.exe", "/c", "start", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return f"Opened in browser: {url}"
    except Exception as e:
        return f"Error opening browser: {e}"

# =====================
# Capability Registry
# =====================
CAPABILITIES = {
    "local_code_edit": True,
    "local_code_read": True,
    "local_shell": True,
    "file_search": True,
    "web_fetch": True,
    "web_search": True,
    "repo_fetch": True,
    "package_install": False,
    "sudo": False,
    "network_write": False,
    "binary_execution": False,
    "git_push": False,
    "arbitrary_url_fetch": False,
    "open_explorer": True,
    "open_browser": True,
    "open_file": True,
    "browser_automation": False,  # Updated to True if playwright available
}

CAPABILITY_DESCRIPTIONS = {
    "local_code_edit": "Edit files within the repository root",
    "local_code_read": "Read files within the repository root",
    "local_shell": "Execute shell commands (dangerous patterns blocked)",
    "file_search": "Search for patterns in code files",
    "web_fetch": "Fetch content from public URLs (SSRF-protected)",
    "web_search": "Search the web and return ranked results",
    "repo_fetch": "Download code from allowlisted hosts (GitHub, GitLab, Bitbucket)",
    "package_install": "Install system or language packages (BLOCKED)",
    "sudo": "Run commands with elevated privileges (BLOCKED)",
    "network_write": "Make network requests that modify data (BLOCKED)",
    "binary_execution": "Execute downloaded binaries (BLOCKED)",
    "git_push": "Push changes to remote repositories (BLOCKED)",
    "arbitrary_url_fetch": "Fetch from arbitrary private/internal URLs (BLOCKED)",
    "open_explorer": "Open files/folders in Windows Explorer (WSL only)",
    "open_browser": "Open URLs in default Windows browser (WSL only)",
    "open_file": "Open files with default Windows application (WSL only)",
    "browser_automation": "Headless browser automation via Playwright (navigate, click, type, screenshot)",
}

# Logging (extracted to core/run_logger.py)
# =====================
from core.run_logger import RunLogger, _sanitize_filename

# ── Input-level safety (pre-model check) ──
# Catches dangerous intent in user input BEFORE sending to the model.
# This is the FIRST line of defense; tool-level checks are the SECOND.

DANGEROUS_INPUT_PATTERNS = [
    (r'\brm\s+-rf\b', "rm -rf komutu"),
    (r'\brm\s+-r\s+/', "rm -r / komutu"),
    (r'\bsudo\s+rm\b', "sudo rm komutu"),
    (r'\bmkfs\b', "mkfs (disk format)"),
    (r'\bdd\s+if=', "dd komutu"),
    (r'\bformat\b.*\bdisk\b', "disk formatlama"),
    (r'\bher\s*şeyi\s+sil', "toplu silme"),
    (r'\btümünü\s+sil', "toplu silme"),
    (r'\bsudo\b', "sudo komutu"),
    (r'\bchmod\s+-R\s+777\b', "chmod 777"),
    (r'\bgit\s+push\s+.*--force\b', "git force push"),
    (r'\bgit\s+reset\s+--hard\b', "git hard reset"),
    (r'\bshutdown\b', "shutdown komutu"),
    (r'\breboot\b', "reboot komutu"),
    (r'\bpoweroff\b', "poweroff komutu"),
]

def check_input_safety(user_input: str) -> tuple:
    """Check user input for dangerous intent BEFORE sending to model.
    Returns (safe: bool, reason: str)
    """
    text = user_input.lower()
    for pattern, description in DANGEROUS_INPUT_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            return False, description
    return True, ""


# =====================
# Capabilities Report
# =====================
def capabilities_report() -> dict:
    """Return the agent's capability registry with descriptions."""
    return {
        "capabilities": CAPABILITIES,
        "descriptions": CAPABILITY_DESCRIPTIONS,
        "limits": {
            "tool_budget": TOOL_BUDGET,
            "max_iterations": MAX_ITERATIONS,
            "web_max_bytes": WEB_MAX_BYTES,
            "repo_max_mb": REPO_MAX_MB,
            "allowed_repo_hosts": list(ALLOWED_REPO_HOSTS),
        }
    }


# Tool schemas loaded from core/tool_schemas.py
from core.tool_schemas import TOOL_SCHEMAS, BROWSER_TOOL_SCHEMAS

# Offline mode: ağ bağlantısı gerektiren tool'ları çıkar
if os.environ.get("CONT_OFFLINE", "0") == "1":
    _OFFLINE_BLOCKED = {"web_search", "web_fetch", "open_in_browser", "browser_open",
                        "browser_click", "browser_type", "browser_text",
                        "browser_screenshot", "browser_links", "browser_agent",
                        "repo_fetch"}
    TOOL_SCHEMAS = [t for t in TOOL_SCHEMAS
                    if t.get("function", {}).get("name") not in _OFFLINE_BLOCKED]
    BROWSER_TOOL_SCHEMAS = []
    _debug(f"[OFFLINE] {len(_OFFLINE_BLOCKED)} ağ tool'u tool listesinden çıkarıldı")

# File Context Injection (extracted to core/file_context.py)
# =====================
from core.file_context import (
    read_text_file, extract_file_paths, resolve_file_context,
    _FILE_CONTEXT_MAX_BYTES,
)


# =====================
# Semantic Memory Tool Wrappers
# =====================

_CORRECTION_PATTERNS = re.compile(
    r'\b(?:değil|degil|yanlış|yanlis|hatalı|hatali|düzelt|duzelt|aslında|aslinda)\b',
    re.IGNORECASE,
)


def remember(content: str, memory_type: str = "fact", importance: float = 0.5) -> str:
    """Tool wrapper for memory_remember."""
    # Correction guard: reject facts that contain correction language.
    # The model often stores "X değil Y" but picks X instead of Y.
    if memory_type == "fact" and _CORRECTION_PATTERNS.search(content):
        return json.dumps({
            "status": "rejected",
            "reason": (
                "Bu içerik düzeltme ifadesi içeriyor ('değil', 'yanlış', vb.). "
                "Yanlış bilgiyi değil, DOĞRU bilgiyi kaydet. "
                "Örnek: 'ITO = İstanbul Ticaret Odası' şeklinde sadece doğruyu yaz."
            ),
            "rejected_content": content,
        })
    try:
        memory_id = memory_remember(
            content=content,
            memory_type=memory_type,
            source="agent",
            importance=importance
        )
        return json.dumps({
            "status": "remembered",
            "memory_id": memory_id,
            "content": content,
            "type": memory_type,
            "importance": importance
        })
    except Exception as e:
        return json.dumps({"status": "error", "error": str(e)})


def recall(query: str, memory_type: str = None, limit: int = 5) -> str:
    """Tool wrapper for memory search - uses hybrid search when available."""
    try:
        emb_manager = get_embedding_manager()
        if emb_manager.is_available():
            results = memory_hybrid_search(query, limit=limit, memory_type=memory_type)
            search_type = "hybrid"
        else:
            results = memory_recall(query, limit=limit, memory_type=memory_type)
            search_type = "bm25"

        if not results:
            return json.dumps({"status": "no_memories", "query": query, "search_type": search_type, "results": []})
        return json.dumps({
            "status": "found",
            "query": query,
            "search_type": search_type,
            "count": len(results),
            "results": results
        }, default=str)
    except Exception as e:
        return json.dumps({"status": "error", "error": str(e)})


def forget(memory_id: int = None, query: str = None) -> str:
    """Tool wrapper for memory_forget."""
    try:
        result = memory_forget(memory_id=memory_id, query=query)
        return json.dumps({"status": "forgotten", **result})
    except Exception as e:
        return json.dumps({"status": "error", "error": str(e)})


def list_memories(memory_type: str = None, limit: int = 20) -> str:
    """Tool wrapper for memory_list_all."""
    try:
        results = memory_list_all(limit=limit, memory_type=memory_type)
        stats = memory_semantic_stats()
        return json.dumps({
            "status": "ok",
            "count": len(results),
            "stats": stats,
            "memories": results
        }, default=str)
    except Exception as e:
        return json.dumps({"status": "error", "error": str(e)})


def where_am_i() -> str:
    """Report Cont's current location and identity."""
    cont_home = get_cont_home()
    cwd = get_current_cwd()

    info = {
        "cont_home": str(cont_home),
        "current_working_directory": str(cwd),
        "actual_os_cwd": os.getcwd(),
        "in_home": cwd.resolve() == cont_home.resolve(),
        "soul_file": str(CONT_SOUL_FILE),
        "config_dir": str(CONT_CONFIG_DIR),
    }

    # List current directory contents
    try:
        contents = sorted(os.listdir(cwd))[:10]
        info["cwd_contents_preview"] = contents
    except Exception:
        pass

    return json.dumps(info, indent=2)



# =====================
# Self-Improvement Tools (LLM-callable)
# =====================

def create_recipe(name: str = "", triggers: str = "[]", steps: str = "[]",
                  forbidden_tools: str = "[]", **kwargs) -> str:
    """Create a new task recipe for future use."""
    if not LEARNING_ENABLED:
        return json.dumps({"ok": False, "error": "Learning system not available"})
    try:
        trigger_list = json.loads(triggers) if isinstance(triggers, str) else triggers
        step_list = json.loads(steps) if isinstance(steps, str) else steps
        forbidden_list = json.loads(forbidden_tools) if isinstance(forbidden_tools, str) else forbidden_tools

        if not name or not trigger_list:
            return json.dumps({"ok": False, "error": "name and triggers are required"})

        ok = save_recipe(name, trigger_list, step_list, forbidden_list)
        return json.dumps({"ok": ok, "recipe": name})
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)})


def learn_word(word: str = "", translation: str = "", intent: str = "read",
               example: str = "", **kwargs) -> str:
    """Add a new word to the vocabulary."""
    if not LEARNING_ENABLED:
        return json.dumps({"ok": False, "error": "Learning system not available"})
    try:
        if not word or not translation:
            return json.dumps({"ok": False, "error": "word and translation are required"})

        ok = add_word(word, translation, intent, example)
        return json.dumps({"ok": ok, "word": word, "translation": translation})
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)})


def report_failure(reason: str = "", lesson: str = "", suggested_patch: str = "",
                   **kwargs) -> str:
    """Report why a task failed. Stores reflection and optionally creates a patch."""
    try:
        if not reason:
            return json.dumps({"ok": False, "error": "reason is required"})

        # Store reflection in semantic memory
        reflection_text = f"[failure] {reason}"
        if lesson:
            reflection_text += f" | lesson: {lesson}"
        memory_remember(
            reflection_text,
            memory_type="reflection",
            source="self_report",
            importance=0.7,
        )

        # Optionally create a patch
        patch_created = False
        if suggested_patch and LEARNING_ENABLED:
            from core.prompt_patches import save_patch
            patch_id = f"auto_{hashlib.md5(reason.encode()).hexdigest()[:8]}"
            patch_created = save_patch(
                patch_id,
                trigger_patterns=[reason.split()[0]] if reason.split() else ["error"],
                patch_text=suggested_patch,
                priority=3,
            )

        return json.dumps({"ok": True, "reflection_stored": True,
                           "patch_created": patch_created})
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)})


def suggest_improvement(area: str = "", suggestion: str = "", priority: str = "medium",
                        **kwargs) -> str:
    """Suggest an improvement. Stored in semantic memory for human review."""
    try:
        if not area or not suggestion:
            return json.dumps({"ok": False, "error": "area and suggestion are required"})

        content = f"[improvement:{area}:{priority}] {suggestion}"
        memory_remember(
            content,
            memory_type="improvement",
            source="self_suggest",
            importance=0.6 if priority == "low" else (0.8 if priority == "high" else 0.7),
        )
        return json.dumps({"ok": True, "area": area, "priority": priority})
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)})


# =====================
# Automation Tools (LLM-callable)
# =====================

def list_automations_tool(**kwargs) -> str:
    """List all automation rules and their status."""
    if not AUTOMATION_ENABLED:
        return json.dumps({"ok": False, "error": "Automation system not available"})
    try:
        autos = load_automations()
        result = []
        for a in autos:
            result.append({
                "name": a.get("name", "?"),
                "description": a.get("description", ""),
                "enabled": a.get("enabled", True),
                "trigger": a.get("trigger", {}).get("event", "?"),
                "actions_count": len(a.get("actions", [])),
            })
        return json.dumps({"ok": True, "automations": result, "count": len(result)})
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)})


def run_automation_tool(name: str = "", **kwargs) -> str:
    """Manually trigger a named automation."""
    if not AUTOMATION_ENABLED:
        return json.dumps({"ok": False, "error": "Automation system not available"})
    try:
        if not name:
            return json.dumps({"ok": False, "error": "name is required"})

        autos = load_automations()
        target = None
        for a in autos:
            if a.get("name") == name:
                target = a
                break

        if not target:
            available = [a.get("name") for a in autos]
            return json.dumps({"ok": False, "error": f"Automation '{name}' not found",
                               "available": available})

        runner = AutomationRunner()
        t0 = time.time()
        summary = runner.execute(target)
        duration_ms = int((time.time() - t0) * 1000)

        # Log to DB
        try:
            from core.memory_store import log_automation_run
            log_automation_run(name, "manual", len(target.get("actions", [])),
                               1, summary, duration_ms)
        except Exception:
            pass

        return json.dumps({"ok": True, "name": name, "summary": summary,
                           "duration_ms": duration_ms})
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)})


def toggle_automation_tool(name: str = "", enabled: str = "true", **kwargs) -> str:
    """Enable or disable an automation by name."""
    if not AUTOMATION_ENABLED:
        return json.dumps({"ok": False, "error": "Automation system not available"})
    try:
        if not name:
            return json.dumps({"ok": False, "error": "name is required"})

        import yaml as _yaml
        automations_dir = Path.home() / ".config" / "cont" / "automations"
        target_file = None

        # Find the automation file
        for f in automations_dir.glob("*.yaml"):
            try:
                data = _yaml.safe_load(f.read_text(encoding="utf-8"))
                if data and data.get("name") == name:
                    target_file = f
                    break
            except Exception:
                continue

        if not target_file:
            return json.dumps({"ok": False, "error": f"Automation '{name}' not found"})

        # Update the enabled field
        data = _yaml.safe_load(target_file.read_text(encoding="utf-8"))
        new_state = enabled.lower() in ("true", "1", "yes", "on")
        data["enabled"] = new_state
        target_file.write_text(
            _yaml.dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False),
            encoding="utf-8")

        return json.dumps({"ok": True, "name": name, "enabled": new_state})
    except ImportError:
        return json.dumps({"ok": False, "error": "PyYAML not available"})
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)})


def emit_event_tool(event_type: str = "", data: str = "{}", **kwargs) -> str:
    """Emit an event to trigger matching automations."""
    if not AUTOMATION_ENABLED or not event_bus:
        return json.dumps({"ok": False, "error": "Automation system not available"})
    try:
        if not event_type:
            return json.dumps({"ok": False, "error": "event_type is required"})

        event_data = json.loads(data) if isinstance(data, str) else data
        results = event_bus.emit(event_type, event_data)

        handler_results = []
        for handler_name, result in results:
            if isinstance(result, Exception):
                handler_results.append({"handler": handler_name, "error": str(result)})
            else:
                handler_results.append({"handler": handler_name, "result": str(result)[:200]})

        return json.dumps({"ok": True, "event": event_type,
                           "handlers_triggered": len(results),
                           "results": handler_results})
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)})


# =====================
# ctx bridge — _build_ctx bundles globals for core.runtime
# =====================

def _build_ctx():
    """Bundle current cont.py globals into RuntimeContext for core.runtime."""
    _recipe_needs_browser_fn_local = None
    try:
        from core.recipes import recipe_needs_browser as _recipe_needs_browser_fn_local
    except ImportError:
        pass

    _resolver_repo_root_fn = None
    try:
        from core.system_executor import Resolver as _Resolver
        _resolver_repo_root_fn = _Resolver.repo_root
    except (ImportError, AttributeError):
        pass

    _browser_agent_cls = None
    try:
        from core.browser_agent import BrowserAgent as _browser_agent_cls
    except ImportError:
        pass

    _get_teacher_api_key_fn = None
    try:
        from core.teacher import get_api_key as _get_teacher_api_key_fn
    except ImportError:
        pass

    _response_verifier_cls = None
    if VERIFICATION_ENABLED:
        try:
            from core.verification import ResponseVerifier as _response_verifier_cls
        except ImportError:
            pass

    return ensure_runtime_ctx(
        # Core
        console=console,
        debug_fn=_debug,
        model=MODEL,
        client=client,
        repo_root=REPO_ROOT,
        # LLM
        llm_complete_fn=llm_complete,
        llm_complete_openai_fn=_llm_complete_openai,
        load_openai_cloud_key_fn=_load_openai_cloud_key,
        truncate_for_context_fn=_truncate_for_context,
        determine_endpoint_mode_fn=_determine_endpoint_mode,
        clean_messages_fn=_clean_messages,
        endpoint_mode=_ENDPOINT_MODE,
        context_limit=_CONTEXT_LIMIT,
        max_tokens=_MAX_TOKENS,
        # Tools
        tools=TOOLS,
        tool_schemas=TOOL_SCHEMAS,
        tool_budget=TOOL_BUDGET,
        max_iterations=MAX_ITERATIONS,
        # Feature flags
        verification_enabled=VERIFICATION_ENABLED,
        self_improve_enabled=SELF_IMPROVE_ENABLED,
        learning_enabled=LEARNING_ENABLED,
        automation_enabled=AUTOMATION_ENABLED,
        escalation_enabled=ESCALATION_ENABLED,
        safety_enabled=SAFETY_ENABLED,
        phase0_enabled=PHASE0_ENABLED,
        fastpath_enabled=FASTPATH_ENABLED,
        teacher_enabled=TEACHER_ENABLED,
        episodic_enabled=EPISODIC_ENABLED,
        browser_available=_BROWSER_AVAILABLE if '_BROWSER_AVAILABLE' in dir() else False,
        # Security
        get_write_protection_fn=get_write_protection,
        get_security_manager_fn=get_security_manager,
        check_input_safety_fn=check_input_safety,
        request_tier2_approval_fn=_request_tier2_approval,
        # Memory
        memory_remember_fn=memory_remember if LEARNING_ENABLED else None,
        memory_hybrid_search_fn=memory_hybrid_search if LEARNING_ENABLED else None,
        memory_get_context_fn=memory_get_context if LEARNING_ENABLED else None,
        memory_update_daily_summary_fn=memory_update_daily_summary if LEARNING_ENABLED else None,
        memory_init_db_fn=memory_init_db if LEARNING_ENABLED else None,
        db_connect_fn=_db_connect if SELF_IMPROVE_ENABLED else None,
        # Self-improve
        self_improver_cls=SelfImprover if SELF_IMPROVE_ENABLED else None,
        classify_task_fn=_classify_task if SELF_IMPROVE_ENABLED else None,
        build_adaptive_prompt_fn=build_adaptive_prompt if SELF_IMPROVE_ENABLED else None,
        estimate_tokens_fn=estimate_tokens if SELF_IMPROVE_ENABLED else None,
        build_system_prompt_fn=build_system_prompt if VERIFICATION_ENABLED else None,
        response_verifier_cls=_response_verifier_cls,
        # Recipes
        match_recipe_fn=match_recipe if LEARNING_ENABLED else None,
        init_recipe_db_fn=init_recipe_db if LEARNING_ENABLED else None,
        seed_recipes_fn=seed_recipes if LEARNING_ENABLED else None,
        cleanup_junk_recipes_fn=cleanup_junk_recipes if LEARNING_ENABLED else None,
        recipe_to_prompt_fn=recipe_to_prompt if LEARNING_ENABLED else None,
        recipe_record_success_fn=recipe_record_success if LEARNING_ENABLED else None,
        record_recipe_outcome_fn=record_recipe_outcome if LEARNING_ENABLED else None,
        match_patches_fn=match_patches if LEARNING_ENABLED else None,
        record_patch_outcome_fn=record_patch_outcome if LEARNING_ENABLED else None,
        recipe_needs_browser_fn=_recipe_needs_browser_fn_local,
        # Decomposer
        decompose_fn=decompose if LEARNING_ENABLED else None,
        decompose_compound_fn=decompose_compound_task if LEARNING_ENABLED else None,
        format_decomposed_fn=format_decomposed_task if LEARNING_ENABLED else None,
        # Events
        event_bus=event_bus if AUTOMATION_ENABLED else None,
        # Escalation
        get_escalation_fn=get_escalation if ESCALATION_ENABLED else None,
        # Phase-0
        run_phase0_fn=run_phase0 if PHASE0_ENABLED else None,
        system_executor_cls=SystemExecutor if FASTPATH_ENABLED else None,
        # Evaluation
        evaluate_task_fn=evaluate_task if EPISODIC_ENABLED else None,
        should_learn_fn=should_learn if TEACHER_ENABLED else None,
        learn_and_save_fn=learn_and_save if TEACHER_ENABLED else None,
        # Browser
        browser_agent_cls=_browser_agent_cls,
        get_teacher_api_key_fn=_get_teacher_api_key_fn,
        # Batch (use repl's state so interactive + runtime share state)
        save_batch_state_fn=_repl_save_batch_state,
        clear_batch_state_fn=_repl_clear_batch_state,
        # Other
        remember_tool_fn=remember,
        resolver_repo_root_fn=_resolver_repo_root_fn,
        # REPL extras
        resolve_model_fn=resolve_model,
        base_url=BASE_URL,
        current_cwd=_CURRENT_CWD,
        run_task_fn=run_task,
        run_logger_cls=RunLogger,
        log_dir=LOG_DIR,
        get_auto_mode_fn=_get_auto_mode,
        llm_summarize_fn=_llm_summarize,
        current_log_path=_current_log_path,
        recipe_record_failure_fn=recipe_record_failure if LEARNING_ENABLED else None,
        # State (input)
        user_input=getattr(run_task, '_user_input', None),
        in_decomposed=getattr(run_task, '_in_decomposed', False),
        skip_escalation=getattr(run_task, '_skip_escalation', False),
        dry_run=getattr(run_task, '_dry_run', False),
    )


def ask_claude_tool(task: str, context: str = "", mode: str = "general",
                    working_dir: str = "") -> str:
    """Send task to Claude Code CLI. Thin wrapper → core.runtime."""
    _build_ctx()
    return _runtime_ask_claude_tool(task, context, mode, working_dir)



# Initialize model module with runtime dependencies
init_model(
    console=console,
    debug_fn=_debug,
    base_url=BASE_URL,
    api_key=API_KEY,
)

# Initialize tool module with runtime dependencies
init_tools(
    repo_root=REPO_ROOT,
    debug_fn=_debug,
    console=console,
    allow_shell=ALLOW_SHELL,
    get_cwd=get_current_cwd,
    set_cwd=set_current_cwd,
    is_wsl_fn=_is_wsl,
    wsl_to_win_path_fn=_wsl_to_windows_path,
    current_log_path_fn=lambda: _current_log_path,
)

# Initialize router with runtime dependencies
_recipe_needs_browser_fn = None
try:
    from core.recipes import recipe_needs_browser as _recipe_needs_browser_fn
except ImportError:
    pass

init_router(
    fastpath_enabled=FASTPATH_ENABLED,
    learning_enabled=LEARNING_ENABLED,
    escalation_enabled=ESCALATION_ENABLED,
    check_safety_fn=check_input_safety,
    system_executor_factory=lambda **kw: SystemExecutor(**kw) if SystemExecutor else None,
    match_recipe_fn=match_recipe if LEARNING_ENABLED else None,
    recipe_needs_browser_fn=_recipe_needs_browser_fn,
    memory_search_fn=memory_hybrid_search if LEARNING_ENABLED else None,
    init_recipe_db_fn=init_recipe_db if LEARNING_ENABLED else None,
    seed_recipes_fn=seed_recipes if LEARNING_ENABLED else None,
    cleanup_junk_fn=cleanup_junk_recipes if LEARNING_ENABLED else None,
    debug_fn=_debug,
)

# Initialize runtime helpers
init_runtime(
    debug_fn=_debug,
    console=console,
    llm_complete_fn=llm_complete,
    model=MODEL,
    memory_remember_fn=memory_remember if LEARNING_ENABLED else None,
    memory_init_db_fn=memory_init_db if LEARNING_ENABLED else None,
    db_connect_fn=_db_connect if SELF_IMPROVE_ENABLED else None,
)

# Initialize CLI flag handlers with runtime dependencies
init_app(
    console=console,
    debug_fn=_debug,
    base_url=BASE_URL,
    self_improve_enabled=SELF_IMPROVE_ENABLED,
    learning_enabled=LEARNING_ENABLED,
    automation_enabled=AUTOMATION_ENABLED,
    escalation_enabled=ESCALATION_ENABLED,
    model_override_getter=lambda: _MODEL_OVERRIDE,
    resolve_model_fn=resolve_model,
    determine_endpoint_fn=_determine_endpoint_mode,
    list_available_models_fn=list_available_models,
    run_task_fn=lambda t: run_task(t),
)

# Tool dispatcher
TOOLS = {
    "list_dir": list_dir,
    "read_file": read_file,
    "write_file": write_file,
    "apply_patch": apply_patch,
    "run_shell": run_shell,
    "search_files": search_files,
    "web_fetch": web_fetch,
    "web_search": web_search,
    "repo_fetch": repo_fetch,
    "capabilities_report": capabilities_report,
    "open_in_explorer": open_in_explorer,
    "open_in_browser": open_in_browser,
    "open_file": open_file,
    "remember": remember,
    "recall": recall,
    "forget": forget,
    "list_memories": list_memories,
    "where_am_i": where_am_i,
    "find_path": find_path,
    "navigate": navigate,
    "create_recipe": create_recipe,
    "learn_word": learn_word,
    "report_failure": report_failure,
    "suggest_improvement": suggest_improvement,
    "list_automations": list_automations_tool,
    "run_automation": run_automation_tool,
    "toggle_automation": toggle_automation_tool,
    "emit_event": emit_event_tool,
    # ask_claude removed from tool registry — model was auto-calling it.
    # Use /claude, /claude-edit, /claude-analyze slash commands instead.
    "system_search": system_search,
}

# OCR tool (optional — requires easyocr)
try:
    from core.ocr import ocr_tool
    TOOLS["ocr"] = ocr_tool
    CAPABILITIES["ocr"] = True
    _OCR_AVAILABLE = True
except ImportError:
    _OCR_AVAILABLE = False

# Browser tools (optional — requires playwright)
try:
    from core.browser import (
        browser_open, browser_click, browser_type,
        browser_text, browser_screenshot, browser_links,
        browser_close,
    )
    BROWSER_TOOLS = {
        "browser_open": browser_open,
        "browser_click": browser_click,
        "browser_type": browser_type,
        "browser_text": browser_text,
        "browser_screenshot": browser_screenshot,
        "browser_links": browser_links,
        "browser_close": browser_close,
    }
    TOOLS.update(BROWSER_TOOLS)
    TOOL_SCHEMAS.extend(BROWSER_TOOL_SCHEMAS)
    CAPABILITIES["browser_automation"] = True
    _BROWSER_AVAILABLE = True
    # Browser agent (autonomous navigation — requires browser + teacher API)
    try:
        from core.browser_agent import browser_agent_run
        TOOLS["browser_agent"] = browser_agent_run
    except ImportError:
        pass
except ImportError:
    _BROWSER_AVAILABLE = False

# =====================
# LLM Client (via provider_router)
# =====================
client = OpenAI(
    base_url=BASE_URL,
    api_key=API_KEY if _PROVIDER_NAME != "ollama" else "ollama",
    timeout=httpx.Timeout(TIMEOUT, connect=10.0)
)

def get_system_prompt(repo_root: str, tool_budget: int, task: str = "") -> str:
    """Get system prompt. Thin wrapper → core.runtime."""
    _build_ctx()
    return _runtime_get_system_prompt(repo_root, tool_budget, task)

def tool_call_signature(name: str, args: dict) -> str:
    """Create a hash signature for a tool call to detect repetition."""
    return _runtime_tool_call_signature(name, args)



# =====================
# Decomposer Gate — thin wrappers (impl in core/runtime.py)
# =====================







def _llm_summarize(file_previews: str, total_files: int, original_task: str,
                   logger=None, event_callback=None) -> str:
    """Call LLM for pure text summarization. Thin wrapper → core.runtime."""
    _build_ctx()
    return _runtime_llm_summarize(file_previews, total_files, original_task,
                                  logger, event_callback)


def run_decomposed_task(task: str, subtasks: list, logger=None, event_callback=None) -> tuple:
    """Run compound task as phased subtasks. Thin wrapper → core.runtime."""
    _build_ctx()
    return _runtime_run_decomposed_task(task, subtasks, logger, event_callback)


def run_task(task: str, logger: Optional[RunLogger] = None, event_callback=None) -> tuple[str, bool]:
    """Run a single task with verification. Thin wrapper → core.runtime.

    Returns (final_answer, success).
    """
    ctx = _build_ctx()
    result = _runtime_run_task(task, logger, event_callback)

    # Proxy state back from ctx to function attributes
    run_task._last_task_id = getattr(ctx, 'last_task_id', None)
    run_task._last_recipe_id = getattr(ctx, 'last_recipe_id', None)
    run_task._last_matched_recipe = getattr(ctx, 'last_matched_recipe', None)
    run_task._last_episode_id = getattr(ctx, 'last_episode_id', None)
    run_task._last_tools_used = getattr(ctx, 'last_tools_used', [])

    return result

# Initialize function attributes
run_task._last_task_id = None
run_task._last_recipe_id = None
run_task._last_matched_recipe = None
run_task._last_episode_id = None
run_task._last_tools_used = []
run_task._skip_escalation = False
run_task._dry_run = False
run_task._in_decomposed = False
run_task._user_input = None



def run_batch(tasks_file: str) -> bool:
    """Run tasks from a file. Thin wrapper → core.repl."""
    ctx = _build_ctx()
    return _repl_run_batch(ctx, tasks_file)


def run_interactive(no_log: bool = False, debug: bool = False, self_improve_off: bool = False):
    """Interactive chat loop. Thin wrapper → core.repl."""
    ctx = _build_ctx()
    _repl_run_interactive(ctx, no_log=no_log, debug=debug, self_improve_off=self_improve_off)


def main():
    global _MODEL_OVERRIDE, _MODEL_LIKE_OVERRIDE, MODEL, LOG_LEVEL, _STRICT_MODEL
    global _MODEL_MISMATCH_DETECTED, _SAVE_MODEL, _NO_UNLOAD, _MAX_TOKENS, _CONTEXT_LIMIT

    # Initialize identity on startup
    _ensure_config_dir()
    cont_home = get_cont_home()
    _debug(f"Cont home: {cont_home}")

    # Guardian — felsefe koruma uyarıları
    try:
        from core.guardian import show_guardian_warnings
        show_guardian_warnings()
    except Exception:
        pass

    parser = build_parser()
    args = parser.parse_args()

    # Daemon hoş geldin raporu
    try:
        from core.daemon import show_welcome
        show_welcome()
    except Exception:
        pass

    # Handle --debug flag (enable debug logging)
    if args.debug:
        LOG_LEVEL = "debug"
        _debug("Debug mode enabled via --debug flag")

    # Handle --trace (trace level for LLM + tool boundary debugging)
    _trace_str = (args.trace or os.environ.get("CONT_TRACE", "off")).lower()
    _trace_map = {"off": TraceLevel.OFF, "compact": TraceLevel.COMPACT,
                  "story": TraceLevel.STORY, "full": TraceLevel.FULL}
    _trace_lvl = _trace_map.get(_trace_str, TraceLevel.OFF)
    init_trace(
        level=_trace_lvl,
        trace_file=getattr(args, "trace_file", None),
        max_lines=getattr(args, "trace_max_lines", 4),
        max_chars=getattr(args, "trace_max_chars", 800),
    )
    if _trace_lvl != TraceLevel.OFF:
        console.print(f"[dim]Trace: {_trace_str}[/dim]")

    # Set dry-run mode
    if args.dry_run:
        run_task._dry_run = True
        console.print("[yellow]DRY-RUN MODE ENABLED[/yellow]")
    else:
        run_task._dry_run = False

    # Handle --local-list (show available GGUF presets)
    if getattr(args, 'local_list', False):
        from core.local_llm import list_presets
        list_presets()
        sys.exit(0)

    # Handle all exit flags (--set-home, --show-home, --self-report, --memory-*, etc.)
    handle_exit_flags(args)

    # Handle --ui (start web interface)
    if args.ui:
        # Ensure FastAPI is installed
        try:
            import fastapi
        except ImportError:
            console.print("[yellow]FastAPI yükleniyor...[/yellow]")
            subprocess.check_call([sys.executable, "-m", "pip", "install",
                                   "fastapi", "uvicorn", "websockets",
                                   "--break-system-packages", "-q"])

        # Resolve model before starting UI (so run_task has a valid MODEL)
        MODEL = resolve_model()
        _determine_endpoint_mode(MODEL)
        console.print(f"[dim]Model: {MODEL} | Endpoint: {_ENDPOINT_MODE}[/dim]")

        port = args.ui_port or 8550

        # Open browser (WSL-aware)
        try:
            import platform as _plat
            if 'microsoft' in _plat.uname().release.lower():
                subprocess.Popen(['cmd.exe', '/c', 'start', f'http://localhost:{port}'],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                import webbrowser
                webbrowser.open(f"http://localhost:{port}")
        except Exception:
            console.print(f"[dim]Tarayıcı açılamadı. Manuel aç: http://localhost:{port}[/dim]")

        from cont_ui.server import main as start_ui
        start_ui(port=port)
        sys.exit(0)

    # Handle --no-escalation
    if args.no_escalation:
        run_task._skip_escalation = True
        console.print("[yellow]Auto-escalation disabled for this session[/yellow]")

    # Handle --claude (force escalation for next task)
    if args.claude:
        if ESCALATION_ENABLED:
            esc = get_escalation()
            if not esc.is_available:
                console.print("[red]Claude CLI not found. Install: npm install -g @anthropic-ai/claude-code[/red]")
                sys.exit(1)
            esc.require_approval = False  # User already opted in via --claude
            console.print("[cyan]Claude Code escalation forced[/cyan]")
        else:
            console.print("[red]Escalation system not available.[/red]")
            sys.exit(1)

    # Disable write protection if requested
    if args.no_write_protect:
        wp = get_write_protection()
        wp.write_confirmed = True
        # Also disable tiered security
        security = get_security_manager()
        if security:
            security.enabled = False
        console.print("[yellow]Write protection disabled via --no-write-protect[/yellow]")

    # Handle --unattended (auto-approve TIER_2, for overnight training)
    if getattr(args, 'unattended', False):
        wp = get_write_protection()
        wp.write_confirmed = True
        security = get_security_manager()
        if security:
            # Pre-approve common tools so no prompts appear
            security.session.approve_tool("run_shell")
            security.session.approve_tool("write_file")
            security.session.approve_tool("apply_patch")
        console.print("[yellow]Unattended mode: TIER_2 auto-approved[/yellow]")

    # Handle --model flag (set model override)
    if args.model:
        _MODEL_OVERRIDE = args.model
        _debug(f"Model override set via --model: {args.model}")

    # Handle --model-like flag
    if args.model_like:
        _MODEL_LIKE_OVERRIDE = args.model_like
        _debug(f"Model-like pattern set: {args.model_like}")

    # Handle --no-strict-model flag
    if args.no_strict_model:
        _STRICT_MODEL = False
        _debug("Strict model validation disabled via --no-strict-model")

    # Handle --auto-on
    if args.auto_on:
        _set_auto_mode(True)
        console.print("[green]Auto model selection enabled permanently.[/green]")
        console.print("[dim]Use --auto-off to disable.[/dim]")
        if not args.task:
            sys.exit(0)

    # Handle --auto-off
    if args.auto_off:
        _set_auto_mode(False)
        console.print("[yellow]Auto model selection disabled.[/yellow]")
        if not args.task:
            sys.exit(0)

    # Handle --forget-model flag
    if args.forget_model:
        _forget_sticky_model()
        console.print("[dim]Sticky model forgotten. Will auto-detect on next run.[/dim]")
        if not args.task and not args.tasks:
            sys.exit(0)

    # Handle --no-save-model flag
    if args.no_save_model:
        _SAVE_MODEL = False
        _debug("Model persistence disabled via --no-save-model")

    # Handle --no-unload flag
    if args.no_unload:
        _NO_UNLOAD = True
        _debug("Model unload disabled via --no-unload")

    # Handle --max-tokens (CLI or env)
    max_tokens_env = os.environ.get("CONT_MAX_TOKENS")
    if args.max_tokens:
        _MAX_TOKENS = args.max_tokens
        _debug(f"Max tokens set via --max-tokens: {_MAX_TOKENS}")
    elif max_tokens_env:
        _MAX_TOKENS = int(max_tokens_env)
        _debug(f"Max tokens set via CONT_MAX_TOKENS: {_MAX_TOKENS}")

    # Handle --context-limit (CLI or env)
    context_limit_env = os.environ.get("CONT_CONTEXT_LIMIT")
    if args.context_limit:
        _CONTEXT_LIMIT = args.context_limit
        _debug(f"Context limit set via --context-limit: {_CONTEXT_LIMIT}")
    elif context_limit_env:
        _CONTEXT_LIMIT = int(context_limit_env)
        _debug(f"Context limit set via CONT_CONTEXT_LIMIT: {_CONTEXT_LIMIT}")

    # Handle --voice / --listen-once
    if args.voice or args.listen_once:
        from core.voice import VoiceLoop
        MODEL = resolve_model()
        _determine_endpoint_mode(MODEL)

        def _voice_handler(text):
            result, _ = run_task(text)
            return result

        loop = VoiceLoop(
            task_handler=_voice_handler,
            continuous=not args.listen_once,
            whisper_model=getattr(args, "whisper_model", "base"),
        )
        loop.start()
        sys.exit(0)

    if args.tasks:
        # Resolve model for batch mode
        MODEL = resolve_model()
        _determine_endpoint_mode(MODEL)
        console.print(f"[dim]Config: model={MODEL}, endpoint={_ENDPOINT_MODE}[/dim]")
        success = run_batch(args.tasks)
        sys.exit(0 if success else 1)

    # Handle "cont do <file_or_text>" - read from file or treat as direct task
    if args.task and len(args.task) >= 2 and args.task[0].lower() == "do":
        orders_arg = " ".join(args.task[1:])

        # Try as file path first (relative to CONT_DIR, then CWD)
        orders_path = CONT_DIR / orders_arg
        task = None
        if orders_path.exists() and orders_path.is_file():
            task = orders_path.read_text(encoding="utf-8").strip()
            console.print(f"[dim]Running orders from: {orders_path} ({len(task)} chars)[/dim]")
        else:
            alt_path = Path(orders_arg)
            if alt_path.exists() and alt_path.is_file():
                orders_path = alt_path
                task = orders_path.read_text(encoding="utf-8").strip()
                console.print(f"[dim]Running orders from: {orders_path} ({len(task)} chars)[/dim]")
            else:
                # Not a file — treat as direct task string
                task = orders_arg
                console.print(f"[dim]Running direct task: {task[:80]}{'...' if len(task) > 80 else ''}[/dim]")

        if not task:
            console.print(f"[yellow]Empty task or orders file.[/yellow]")
            sys.exit(0)

        # Resolve model
        MODEL = resolve_model()
        _determine_endpoint_mode(MODEL)

        logger = None if args.no_log else RunLogger(f"do_{orders_path.stem}", LOG_DIR)
        console.print(f"[dim]Config: model={MODEL}, endpoint={_ENDPOINT_MODE}, tool_budget={TOOL_BUDGET}, timeout={TIMEOUT}s[/dim]")

        answer, success = run_task(task, logger)

        if logger:
            console.print(f"\n[dim]Log: {logger.logfile}[/dim]")

        sys.exit(0 if success else 1)

    if not args.task:
        # No positional args - check if interactive mode
        if sys.stdin.isatty():
            # Interactive mode: TTY connected, start REPL
            run_interactive(
                no_log=args.no_log,
                debug=args.debug,
                self_improve_off=getattr(args, 'self_improve_off', False),
            )
            sys.exit(0)
        else:
            # Non-interactive, no args - read from stdin (pipe/redirect)
            task = sys.stdin.read().strip()
            if not task:
                parser.print_help()
                sys.exit(1)
    else:
        task = " ".join(args.task)

    # Check for model switch (if override is set and differs from sticky)
    old_model = _get_sticky_model()
    is_override = _MODEL_OVERRIDE or _MODEL_LIKE_OVERRIDE or os.environ.get("CONT_MODEL") or os.environ.get("OPENAI_MODEL")

    # Resolve model before running task (pass auto/tier via keyword args)
    MODEL = resolve_model(
        auto_mode=args.auto or _get_auto_mode(),
        current_task=task if 'task' in dir() else "",
        tier_override=args.tier if hasattr(args, 'tier') and args.tier else None,
    )

    # Handle model switch if needed
    if is_override and old_model and old_model != MODEL:
        handle_model_switch(MODEL, old_model)

    # Pre-determine endpoint mode
    _determine_endpoint_mode(MODEL)

    logger = None if args.no_log else RunLogger(task, LOG_DIR)

    # Print config info
    console.print(f"[dim]Config: model={MODEL}, endpoint={_ENDPOINT_MODE}, tool_budget={TOOL_BUDGET}, timeout={TIMEOUT}s[/dim]")
    if args.debug:
        console.print(f"[dim]Debug: base_url={BASE_URL}[/dim]")

    answer, success = run_task(task, logger)

    if logger:
        console.print(f"\n[dim]Log: {logger.logfile}[/dim]")

    # Determine exit code: prioritize model mismatch (exit 2), then success
    if _MODEL_MISMATCH_DETECTED:
        console.print("[yellow]Exiting with code 2 due to model mismatch.[/yellow]")
        sys.exit(2)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
