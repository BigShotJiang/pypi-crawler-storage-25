"""
Agent Manager CLI — daemon, login, and node agent.

Modes:
1. daemon — bridges Claude Code CLI to the backend via bidirectional WebSocket
2. login  — authenticate with the server and save token locally
3. connect — run as a persistent node agent: scan sessions, receive attach commands

Usage:
    am login --host agent-manager.space --email user@mail.com
    am connect
    am daemon --token <TOKEN> -- claude -p "task" --output-format stream-json
"""

from __future__ import annotations

import argparse
import asyncio
import getpass
import json
import os
import subprocess
import sys
from pathlib import Path

import websockets

# ---------------------------------------------------------------------------
# Config file management (~/.agentmanager/config.json)
# ---------------------------------------------------------------------------

CONFIG_DIR = Path.home() / ".agentmanager"
CONFIG_FILE = CONFIG_DIR / "config.json"


def load_config() -> dict:
    """Load config from ~/.agentmanager/config.json."""
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def save_config(data: dict) -> None:
    """Save config to ~/.agentmanager/config.json with restricted permissions."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_DIR.chmod(0o700)
    CONFIG_FILE.write_text(json.dumps(data, indent=2))
    CONFIG_FILE.chmod(0o600)


# ---------------------------------------------------------------------------
# Stream event mapping (daemon mode)
# ---------------------------------------------------------------------------


def map_stream_event(line: str) -> list[dict]:
    """Map a Claude Code stream-json line to our StreamEvent format(s).

    Returns a list of event dicts (may be empty).
    """
    try:
        msg = json.loads(line)
    except json.JSONDecodeError:
        return []

    msg_type = msg.get("type")

    if msg_type == "system":
        if msg.get("subtype") == "init":
            return [
                {
                    "event_type": "status",
                    "data": {
                        "status": "running",
                        "message": "Session started",
                        "session_id": msg.get("session_id", ""),
                    },
                }
            ]
        return []

    if msg_type == "assistant":
        message = msg.get("message", {})
        content_blocks = message.get("content", [])
        events = []
        for block in content_blocks:
            block_type = block.get("type")
            if block_type == "thinking":
                events.append(
                    {
                        "event_type": "thinking",
                        "data": {"text": block.get("thinking", "")},
                    }
                )
            elif block_type == "text":
                events.append(
                    {
                        "event_type": "text",
                        "data": {"text": block.get("text", "")},
                    }
                )
            elif block_type == "tool_use":
                events.append(
                    {
                        "event_type": "tool_use",
                        "data": {
                            "tool": block.get("name", ""),
                            "input": block.get("input", {}),
                            "tool_use_id": block.get("id", ""),
                        },
                    }
                )
        # Emit token usage delta if present in this assistant message.
        usage = message.get("usage") or {}
        if usage:
            events.append(
                {
                    "event_type": "usage",
                    "data": {
                        "input_tokens": usage.get("input_tokens", 0),
                        "output_tokens": usage.get("output_tokens", 0),
                        "cache_creation_input_tokens": usage.get("cache_creation_input_tokens", 0),
                        "cache_read_input_tokens": usage.get("cache_read_input_tokens", 0),
                    },
                }
            )
        return events

    if msg_type == "user":
        content_blocks = msg.get("message", {}).get("content", [])
        for block in content_blocks:
            if block.get("type") == "tool_result":
                content = block.get("content", "")
                if isinstance(content, list):
                    content = "\n".join(
                        b.get("text", "") for b in content if b.get("type") == "text"
                    )
                return [
                    {
                        "event_type": "tool_result",
                        "data": {
                            "tool_use_id": block.get("tool_use_id", ""),
                            "content": str(content)[:2000],
                            "is_error": block.get("is_error", False),
                        },
                    }
                ]
        return []

    if msg_type == "result":
        subtype = msg.get("subtype", "")
        if subtype == "success":
            return [
                {
                    "event_type": "status",
                    "data": {
                        "status": "completed",
                        "message": "Task completed",
                        "cost_usd": msg.get("total_cost_usd", 0),
                        "duration_ms": msg.get("duration_ms", 0),
                        "num_turns": msg.get("num_turns", 0),
                        "session_id": msg.get("session_id", ""),
                    },
                }
            ]
        return [
            {
                "event_type": "error",
                "data": {
                    "message": f"Task ended: {subtype}",
                    "cost_usd": msg.get("total_cost_usd", 0),
                },
            }
        ]

    if msg_type == "stream_event":
        delta = msg.get("event", {}).get("delta", {})
        delta_type = delta.get("type")
        if delta_type == "text_delta":
            return [
                {
                    "event_type": "text",
                    "data": {"text": delta.get("text", ""), "partial": True},
                }
            ]
        if delta_type == "thinking_delta":
            return [
                {
                    "event_type": "thinking",
                    "data": {"text": delta.get("thinking", ""), "partial": True},
                }
            ]

    if msg_type == "input_request":
        request_type = msg.get("request_type", "text")
        event_data: dict = {"request_type": request_type}

        if request_type == "permission":
            event_data["tool_name"] = msg.get("tool_name", "")
            event_data["tool_input"] = msg.get("tool_input", {})
        elif request_type == "question":
            event_data["questions"] = msg.get("questions", [])

        return [
            {
                "event_type": "input_request",
                "data": event_data,
            }
        ]

    return []


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def read_lines(stream) -> asyncio.Queue:
    """Read lines from a sync stream in a thread, put them into an async queue."""
    queue: asyncio.Queue[str | None] = asyncio.Queue()
    loop = asyncio.get_event_loop()

    def _reader():
        try:
            for line in stream:
                loop.call_soon_threadsafe(queue.put_nowait, line.strip())
        finally:
            loop.call_soon_threadsafe(queue.put_nowait, None)

    loop.run_in_executor(None, _reader)
    return queue


def format_user_message_for_stdin(text: str) -> str:
    """Format a user message as stream-json for Claude CLI stdin."""
    return json.dumps(
        {
            "type": "user",
            "message": {
                "role": "user",
                "content": [{"type": "text", "text": text}],
            },
        }
    )


def format_permission_response_for_stdin(allow: bool) -> str:
    """Legacy — kept for compatibility. See format_control_response_for_stdin."""
    return json.dumps(
        {
            "type": "permission_response",
            "permission": "allow" if allow else "deny",
        }
    )


def format_control_response_for_stdin(
    request_id: str,
    allow: bool,
    original_input: dict | None = None,
    deny_message: str = "Denied by user",
    destination: str | None = None,
) -> str:
    """Build a stream-json control_response for Claude's can_use_tool prompt.

    Claude Code emits `{type:"control_request", subtype:"can_use_tool", ...}`
    on stdout when it wants explicit permission to call a tool. The expected
    reply on stdin is a matching `control_response` with behavior allow/deny.

    When allowing, we must echo back the input unchanged in `updatedInput`
    (Claude uses that to build the actual tool invocation).

    `destination` (optional) supports "sticky" allow — Claude will remember
    the decision for the rest of the session (`"session"`) or persist it
    to local settings (`"localSettings"`).
    """
    if allow:
        response_body: dict = {
            "behavior": "allow",
            "updatedInput": original_input or {},
        }
        if destination in ("session", "localSettings"):
            response_body["destination"] = destination
    else:
        response_body = {
            "behavior": "deny",
            "message": deny_message,
        }
    return json.dumps(
        {
            "type": "control_response",
            "response": {
                "subtype": "success",
                "request_id": request_id,
                "response": response_body,
            },
        }
    )


def format_control_request_for_stdin(subtype: str, **fields) -> str:
    """Build a client→claude control_request with the given subtype and
    payload fields. Handles `interrupt`, `set_model`, `set_permission_mode`,
    and other control subtypes Claude supports over stream-json stdin."""
    import uuid as _u

    return json.dumps(
        {
            "type": "control_request",
            "request_id": f"{subtype}-{_u.uuid4()}",
            "request": {"subtype": subtype, **fields},
        }
    )


def _log(prefix: str, msg: str) -> None:
    print(f"[{prefix}] {msg}", file=sys.stderr)


def _safe_urlopen(url, **kwargs):
    """urlopen wrapper that only allows http/https schemes."""
    import urllib.request

    check = url.full_url if isinstance(url, urllib.request.Request) else url
    if not check.startswith(("http://", "https://")):
        raise ValueError(f"Unsafe URL scheme: {check}")
    return urllib.request.urlopen(url, **kwargs)  # nosec B310 — scheme validated above


# Allowed CLI executables for subprocess calls
_ALLOWED_EXECUTABLES = frozenset({"claude", "codex", "gemini"})


# Permission modes accepted by Claude Code (`--permission-mode` flag and
# `set_permission_mode` control_request). Listed in the same order that the
# TUI cycles through on Shift+Tab. `bypassPermissions` is excluded from the
# rotation because it's a "dangerous" mode that should be opt-in explicitly.
CLAUDE_PERMISSION_MODES = ("default", "acceptEdits", "plan")
CLAUDE_PERMISSION_MODES_ALL = (
    "default",
    "acceptEdits",
    "plan",
    "bypassPermissions",
    "dontAsk",
    "auto",
)


def _build_claude_hook_settings() -> str:
    """Inline JSON payload for `claude --settings` that registers our
    PreToolUse hook. The hook is `am permission-hook` — a subcommand of
    this very CLI that forwards each permission request to the backend
    and routes the user's answer back to Claude."""
    # Quote sys.executable properly in case of spaces in path.
    import shlex

    cmd_str = f"{shlex.quote(sys.executable)} -m am permission-hook"
    return json.dumps(
        {
            "hooks": {
                "PreToolUse": [
                    {
                        "matcher": "*",
                        "hooks": [
                            {
                                "type": "command",
                                "command": cmd_str,
                            }
                        ],
                    }
                ]
            }
        }
    )


def _build_cli_command(
    cli: str,
    session_id: str,
    permission_mode: str | None = None,
    with_permission_hook: bool = True,
) -> list[str]:
    """Build CLI-specific resume command.

    Only allows known CLI executables to prevent arbitrary command execution.
    """
    if cli not in _ALLOWED_EXECUTABLES:
        allowed = ", ".join(sorted(_ALLOWED_EXECUTABLES))
        raise ValueError(f"Unsupported CLI: {cli!r} (allowed: {allowed})")
    if cli == "claude":
        cmd = [
            "claude",
            "--continue",
            "--resume",
            session_id,
            "--output-format",
            "stream-json",
            "--input-format",
            "stream-json",
            "--verbose",
        ]
        if permission_mode and permission_mode in CLAUDE_PERMISSION_MODES_ALL:
            cmd.extend(["--permission-mode", permission_mode])
        if with_permission_hook:
            cmd.extend(["--settings", _build_claude_hook_settings()])
        return cmd
    if cli == "codex":
        return ["codex", "resume", session_id, "--json"]
    # gemini
    return ["gemini", "--resume"]


def _build_continue_command(
    original_cmd: list[str],
    session_id: str,
    prompt: str,
) -> list[str]:
    """Build a --continue --resume command from the original command."""
    exe = original_cmd[0]
    return [
        exe,
        "-p",
        prompt,
        "--continue",
        "--resume",
        session_id,
        "--output-format",
        "stream-json",
        "--input-format",
        "stream-json",
        "--verbose",
    ]


# ---------------------------------------------------------------------------
# Daemon mode
# ---------------------------------------------------------------------------


def _log_event(etype: str, data: dict) -> None:
    """Log a mapped event to stderr."""
    if etype == "text":
        _log(etype, data.get("text", "")[:80])
    elif etype == "tool_use":
        _log(etype, data.get("tool", ""))
    elif etype == "tool_result":
        _log(etype, data.get("content", "")[:60])
    elif etype in ("status", "error"):
        _log(etype, data.get("message", ""))
    elif etype == "thinking":
        _log(etype, "...")
    elif etype == "input_request":
        _log(etype, data.get("request_type", ""))


async def run_daemon_bidirectional(ws_url: str, ws_token: str, command: list[str]):
    """Run Claude CLI with bidirectional pipes and forward via WebSocket."""
    _log("daemon", f"Running: {' '.join(command)}")
    proc = subprocess.Popen(
        command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=sys.stderr,
        text=True,
    )

    session_id = None

    async with websockets.connect(ws_url, ping_interval=20, ping_timeout=10) as ws:
        await ws.send(json.dumps({"token": ws_token}))
        _log("daemon", "Connected (bidirectional mode)")

        # Send initial status so dashboard shows the agent immediately
        await ws.send(
            json.dumps(
                {
                    "event_type": "status",
                    "data": {
                        "status": "running",
                        "message": "Daemon connected, waiting for CLI output",
                    },
                }
            )
        )

        stdout_queue = await read_lines(proc.stdout)
        sent_count = 0

        # Maps Claude's control_request_id → original tool input. Populated
        # when we forward a `can_use_tool` request to the backend; consumed
        # when the user's permission response comes back and we need to
        # echo the input in `updatedInput`.
        pending_tool_requests: dict[str, dict] = {}

        async def _read_stdout():
            nonlocal sent_count, session_id
            line_num = 0
            while True:
                line = await stdout_queue.get()
                if line is None:
                    break
                if not line:
                    continue
                line_num += 1

                try:
                    raw = json.loads(line)
                    raw_type = raw.get("type", "?")
                    _log("raw", f"#{line_num} type={raw_type}")
                    if raw_type == "system" and raw.get("subtype") == "init":
                        session_id = raw.get("session_id")
                    elif raw_type == "result":
                        sid = raw.get("session_id")
                        if sid:
                            session_id = sid
                    elif raw_type == "control_request":
                        # Claude is asking us for permission to call a tool.
                        req = raw.get("request", {}) or {}
                        if req.get("subtype") == "can_use_tool":
                            request_id = raw.get("request_id") or ""
                            tool_input = req.get("input") or {}
                            pending_tool_requests[request_id] = tool_input
                            permission_event = {
                                "event_type": "input_request",
                                "data": {
                                    "request_type": "permission",
                                    "request_id": request_id,
                                    "tool_name": req.get("tool_name"),
                                    "display_name": req.get("display_name"),
                                    "tool_input": tool_input,
                                    "tool_use_id": req.get("tool_use_id"),
                                    "description": req.get("description"),
                                    "permission_suggestions": req.get("permission_suggestions"),
                                },
                            }
                            try:
                                await ws.send(json.dumps(permission_event))
                                sent_count += 1
                                _log(
                                    "permission",
                                    f"request {req.get('tool_name')} "
                                    f"id={request_id[-8:] if request_id else '?'}",
                                )
                            except Exception as e:
                                _log("send error", str(e))
                            # control_request is a conversation-level message,
                            # not a stream event — don't run it through the
                            # event mapper.
                            continue
                except (json.JSONDecodeError, KeyError):
                    _log("raw", f"#{line_num} (not json) {line[:80]}")

                events = map_stream_event(line)
                if not events:
                    continue

                for event in events:
                    try:
                        await ws.send(json.dumps(event))
                        sent_count += 1
                    except Exception as e:
                        _log("send error", str(e))
                        continue
                    _log_event(event["event_type"], event.get("data", {}))

            _log("daemon", f"stdout closed. Sent {sent_count} events.")

        async def _read_ws():
            try:
                async for raw_msg in ws:
                    try:
                        msg = json.loads(raw_msg)
                    except json.JSONDecodeError:
                        continue

                    msg_type = msg.get("type", "")
                    if msg_type == "user_input":
                        text = msg.get("data", {}).get("text", "")
                        if text and proc.stdin and not proc.stdin.closed:
                            proc.stdin.write(format_user_message_for_stdin(text) + "\n")
                            proc.stdin.flush()
                            _log("stdin", f"user_input: {text[:60]}")
                    elif msg_type == "permission_response":
                        data = msg.get("data", {}) or {}
                        allow = bool(data.get("allow", False))
                        destination = data.get("destination")
                        request_id = msg.get("request_id") or data.get("request_id")
                        if not request_id:
                            _log(
                                "stdin",
                                "permission_response: missing request_id, ignoring",
                            )
                        elif proc.stdin and not proc.stdin.closed:
                            original_input = pending_tool_requests.pop(request_id, None)
                            ctrl = format_control_response_for_stdin(
                                request_id=request_id,
                                allow=allow,
                                original_input=original_input,
                                destination=destination,
                            )
                            proc.stdin.write(ctrl + "\n")
                            proc.stdin.flush()
                            sticky = f" sticky={destination}" if destination else ""
                            _log(
                                "stdin",
                                f"permission: {'allow' if allow else 'deny'}"
                                f" id={request_id[-8:]}{sticky}",
                            )
                    elif msg_type == "interrupt":
                        # Cancel whatever Claude is currently doing without
                        # killing the process. Equivalent to pressing Esc in
                        # the TUI. Claude stops the in-flight tool and
                        # returns control.
                        if proc.stdin and not proc.stdin.closed:
                            ctrl = format_control_request_for_stdin("interrupt")
                            proc.stdin.write(ctrl + "\n")
                            proc.stdin.flush()
                            _log("stdin", "interrupt")
                    elif msg_type == "set_model":
                        model = msg.get("data", {}).get("model")
                        if not model:
                            _log("stdin", "set_model: missing model, ignoring")
                        elif proc.stdin and not proc.stdin.closed:
                            ctrl = format_control_request_for_stdin(
                                "set_model",
                                model=model,
                            )
                            proc.stdin.write(ctrl + "\n")
                            proc.stdin.flush()
                            _log("stdin", f"set_model: {model}")
                    elif msg_type == "set_permission_mode":
                        # Shift+Tab equivalent — send a control_request to
                        # Claude CLI so it updates its session permission
                        # state without needing a restart.
                        mode = msg.get("data", {}).get("mode", "default")
                        if mode not in CLAUDE_PERMISSION_MODES_ALL:
                            _log("stdin", f"set_permission_mode: ignoring unknown mode {mode!r}")
                        elif proc.stdin and not proc.stdin.closed:
                            ctrl = format_control_request_for_stdin(
                                "set_permission_mode",
                                mode=mode,
                            )
                            proc.stdin.write(ctrl + "\n")
                            proc.stdin.flush()
                            _log("stdin", f"set_permission_mode: {mode}")
                    elif msg_type == "stop":
                        _log("daemon", "Stop received — terminating Claude CLI")
                        try:
                            proc.terminate()
                        except ProcessLookupError:
                            pass
                        break
            except websockets.exceptions.ConnectionClosed:
                pass

        stdout_task = asyncio.create_task(_read_stdout())
        ws_task = asyncio.create_task(_read_ws())
        await stdout_task
        ws_task.cancel()

    proc.wait()
    _log("daemon", f"Process exited with code {proc.returncode}")
    return proc.returncode, session_id


async def run_daemon_pipe(ws_url: str, ws_token: str, input_stream):
    """Forward mapped events from stdin (pipe mode, read-only)."""
    async with websockets.connect(ws_url, ping_interval=20, ping_timeout=10) as ws:
        await ws.send(json.dumps({"token": ws_token}))
        _log("daemon", "Connected (pipe mode)")

        await ws.send(
            json.dumps(
                {
                    "event_type": "status",
                    "data": {
                        "status": "running",
                        "message": "Daemon connected, reading stdin",
                    },
                }
            )
        )

        queue = await read_lines(input_stream)
        sent_count = 0

        while True:
            line = await queue.get()
            if line is None:
                break
            if not line:
                continue

            events = map_stream_event(line)
            for event in events:
                try:
                    await ws.send(json.dumps(event))
                    sent_count += 1
                except Exception as e:
                    _log("send error", str(e))
                    continue
                _log_event(event["event_type"], event.get("data", {}))

        _log("daemon", f"Done. Sent {sent_count} events.")


async def run_with_followup(ws_url: str, ws_token: str, command: list[str]):
    """Run Claude CLI, then listen for follow-up messages and restart."""
    returncode, session_id = await run_daemon_bidirectional(ws_url, ws_token, command)

    if returncode != 0 or not session_id:
        return returncode

    _log("daemon", f"Task completed (session: {session_id}). Listening for follow-ups...")

    async with websockets.connect(ws_url, ping_interval=20, ping_timeout=10) as ws:
        await ws.send(json.dumps({"token": ws_token}))
        await ws.send(
            json.dumps(
                {
                    "event_type": "status",
                    "data": {
                        "status": "waiting_followup",
                        "message": "Ready for follow-up",
                        "session_id": session_id,
                    },
                }
            )
        )

        try:
            async for raw_msg in ws:
                try:
                    msg = json.loads(raw_msg)
                except json.JSONDecodeError:
                    continue

                if msg.get("type") == "user_input":
                    text = msg.get("data", {}).get("text", "")
                    if not text:
                        continue
                    _log("daemon", f"Follow-up: {text[:60]}")
                    continue_cmd = _build_continue_command(command, session_id, text)
                    break
                elif msg.get("type") == "stop":
                    _log("daemon", "Stop received.")
                    return 0
            else:
                return 0
        except websockets.exceptions.ConnectionClosed:
            return 0

    return await run_with_followup(ws_url, ws_token, continue_cmd)


# ---------------------------------------------------------------------------
# Login command
# ---------------------------------------------------------------------------


def cmd_login(args: argparse.Namespace) -> None:
    """Authenticate with the server and save tokens locally."""
    import urllib.error
    import urllib.request

    host = args.host
    email = args.email or input("Email: ")
    password = args.password or getpass.getpass("Password: ")

    # Default to secure for production host
    secure = args.secure or not host.startswith("localhost")
    proto = "https" if secure else "http"
    url = f"{proto}://{host}/api/auth/login"

    payload = json.dumps({"email": email, "password": password}).encode()
    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with _safe_urlopen(req) as resp:
            data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        _log("login", f"Error {e.code}: {body}")
        sys.exit(1)
    except urllib.error.URLError as e:
        _log("login", f"Connection error: {e.reason}")
        sys.exit(1)

    config = load_config()
    config["host"] = host
    config["secure"] = secure
    config["access_token"] = data["access_token"]
    config["refresh_token"] = data["refresh_token"]
    save_config(config)

    _log("login", f"Logged in as {email}")
    _log("login", f"Config saved to {CONFIG_FILE}")


# ---------------------------------------------------------------------------
# Connect command (Node Agent)
# ---------------------------------------------------------------------------


def _refresh_token(host: str, secure: bool, refresh_token: str) -> dict | None:
    """Try to refresh the access token. Returns new tokens or None."""
    import urllib.request

    proto = "https" if secure else "http"
    url = f"{proto}://{host}/api/auth/refresh"
    payload = json.dumps({"refresh_token": refresh_token}).encode()
    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with _safe_urlopen(req) as resp:
            return json.loads(resp.read())
    except Exception:
        return None


async def _run_node_agent(
    host: str,
    secure: bool,
    access_token: str,
    daemon_procs: dict[str, asyncio.subprocess.Process],
) -> None:
    """Run the node agent: connect, scan sessions, handle attach commands.

    `daemon_procs` is owned by the caller (cmd_connect) so it survives ws
    reconnects — daemon subprocesses have their own daemon_token and ws
    connection, they don't die just because the node's ws hiccuped.
    """
    from am.scanners import scan_all_sessions

    ws_proto = "wss" if secure else "ws"
    ws_url = f"{ws_proto}://{host}/ws/node"

    _log("node", f"Connecting to {ws_url}...")

    # Reap any already-exited daemons on reconnect so we don't spawn
    # duplicates for the same agent.
    dead = [aid for aid, p in daemon_procs.items() if p.returncode is not None]
    for aid in dead:
        daemon_procs.pop(aid, None)

    async with websockets.connect(ws_url, ping_interval=20, ping_timeout=10) as ws:
        await ws.send(json.dumps({"token": access_token}))

        raw = await ws.recv()
        msg = json.loads(raw)
        if msg.get("type") != "connected":
            _log("node", f"Unexpected response: {msg}")
            return
        _log("node", f"Connected as user {msg.get('user_id', '?')[:8]}...")

        async def _scan_and_send():
            while True:
                try:
                    loop = asyncio.get_event_loop()
                    sessions = await loop.run_in_executor(None, scan_all_sessions)
                    sessions_data = [s.model_dump(mode="json") for s in sessions]
                    await ws.send(
                        json.dumps(
                            {
                                "type": "sessions",
                                "data": sessions_data,
                            }
                        )
                    )
                    _log("node", f"Sent {len(sessions)} sessions")
                except websockets.exceptions.ConnectionClosed as e:
                    _log("node", f"scan: connection closed ({e.code} {e.reason or '-'})")
                    break
                except Exception as e:
                    _log("node", f"Scan error: {e}")
                await asyncio.sleep(30)

        async def _heartbeat():
            while True:
                await asyncio.sleep(25)
                try:
                    await ws.send(json.dumps({"type": "heartbeat"}))
                except websockets.exceptions.ConnectionClosed as e:
                    _log("node", f"heartbeat: connection closed ({e.code} {e.reason or '-'})")
                    break

        async def _listen_commands():
            try:
                async for raw_msg in ws:
                    try:
                        cmd = json.loads(raw_msg)
                    except json.JSONDecodeError:
                        continue

                    if cmd.get("type") == "attach":
                        await _handle_attach(cmd, host, secure, daemon_procs)
            except websockets.exceptions.ConnectionClosed as e:
                _log("node", f"listen: connection closed ({e.code} {e.reason or '-'})")

        scan_task = asyncio.create_task(_scan_and_send())
        hb_task = asyncio.create_task(_heartbeat())
        cmd_task = asyncio.create_task(_listen_commands())

        try:
            await asyncio.wait(
                [scan_task, hb_task, cmd_task],
                return_when=asyncio.FIRST_COMPLETED,
            )
        finally:
            scan_task.cancel()
            hb_task.cancel()
            cmd_task.cancel()
            # NB: do NOT terminate daemon_procs here. Each daemon has its
            # own WS connection + daemon_token and can survive node agent
            # reconnects (e.g. when the backend reloads during dev).
            # Killing them here would blow away user's long-running tasks
            # on every transient ws blip.
            alive = sum(1 for p in daemon_procs.values() if p.returncode is None)
            if alive:
                _log("node", f"Keeping {alive} daemon(s) alive across reconnect")


async def _handle_attach(
    cmd: dict,
    host: str,
    secure: bool,
    daemon_procs: dict[str, asyncio.subprocess.Process],
) -> None:
    """Handle an attach command from the server."""
    agent_id = cmd["agent_id"]
    session_id = cmd["session_id"]
    cli = cmd.get("cli", "claude")
    project_path = cmd.get("project_path", "")
    daemon_token = cmd["daemon_token"]
    permission_mode = cmd.get("permission_mode")

    # De-dupe: if we already have a live daemon for this agent, don't
    # spawn another one. Re-attach commands can arrive multiple times
    # during transient disconnects or if the backend re-fires by mistake.
    existing = daemon_procs.get(agent_id)
    if existing and existing.returncode is None:
        _log(
            "node",
            f"Attach ignored: agent {agent_id[:8]}... already has live daemon PID {existing.pid}",
        )
        return

    _log(
        "node",
        f"Attach: {cli} session {session_id[:8]}... agent {agent_id[:8]}..."
        + (f" [mode={permission_mode}]" if permission_mode else ""),
    )

    cli_cmd = _build_cli_command(cli, session_id, permission_mode)
    daemon_cmd = [
        sys.executable,
        "-m",
        "am",
        "daemon",
        "--token",
        daemon_token,
        "--host",
        host,
        *(["--secure"] if secure else []),
        "--",
        *cli_cmd,
    ]

    # Propagate backend connection info + daemon token to the child
    # subprocess tree. Claude CLI will spawn PreToolUse hooks (via
    # `am permission-hook`) that need to contact the backend, so these
    # env vars must reach the grandchild process.
    env = dict(os.environ)
    env["AM_DAEMON_TOKEN"] = daemon_token
    env["AM_BACKEND_HOST"] = host
    env["AM_BACKEND_SECURE"] = "1" if secure else "0"

    proc = await asyncio.create_subprocess_exec(
        *daemon_cmd,
        cwd=project_path or None,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.PIPE,
        env=env,
    )
    daemon_procs[agent_id] = proc
    _log("node", f"Spawned daemon PID {proc.pid} for agent {agent_id[:8]}...")

    asyncio.create_task(_log_daemon_stderr(agent_id, proc, daemon_procs))


async def _log_daemon_stderr(
    agent_id: str,
    proc: asyncio.subprocess.Process,
    daemon_procs: dict[str, asyncio.subprocess.Process],
) -> None:
    """Read daemon stderr and log it."""
    try:
        while True:
            line = await proc.stderr.readline()
            if not line:
                break
            print(f"  [daemon:{agent_id[:8]}] {line.decode().rstrip()}", file=sys.stderr)
    except Exception:
        pass
    await proc.wait()
    _log("node", f"Daemon {agent_id[:8]}... exited with code {proc.returncode}")
    daemon_procs.pop(agent_id, None)


def cmd_connect(args: argparse.Namespace) -> None:
    """Run the node agent."""
    config = load_config()

    host = args.host or config.get("host")
    secure = args.secure or config.get("secure", False)
    access_token = config.get("access_token")
    refresh_token = config.get("refresh_token")

    if not host:
        _log("connect", "No host configured. Run `am login` first.")
        sys.exit(1)
    if not access_token:
        _log("connect", "No access token. Run `am login` first.")
        sys.exit(1)

    # Refresh token before connecting
    if refresh_token:
        tokens = _refresh_token(host, secure, refresh_token)
        if tokens:
            access_token = tokens["access_token"]
            config["access_token"] = tokens["access_token"]
            config["refresh_token"] = tokens["refresh_token"]
            save_config(config)
            _log("connect", "Token refreshed.")

    # Reconnect loop with exponential backoff. On clean disconnect (network
    # blip, backend restart, proxy timeout) we retry automatically. Auth
    # errors (401/403) bail out immediately — the user must re-login.
    #
    # daemon_procs is owned here so it persists across ws reconnects — we
    # don't want to kill long-running Claude sessions just because the
    # backend hiccuped or reloaded.
    import time as _time

    daemon_procs: dict[str, asyncio.subprocess.Process] = {}
    backoff = 1
    try:
        while True:
            try:
                asyncio.run(_run_node_agent(host, secure, access_token, daemon_procs))
                # _run_node_agent returned normally → ws was closed by server
                # or one of the tasks finished. Reconnect after a short delay.
                _log("connect", f"Disconnected. Reconnecting in {backoff}s...")
            except KeyboardInterrupt:
                raise
            except websockets.exceptions.InvalidStatusCode as e:
                if e.status_code in (401, 403):
                    _log("connect", f"Auth failed ({e.status_code}). Run `am login` again.")
                    sys.exit(1)
                _log("connect", f"WebSocket error: {e}, retrying in {backoff}s...")
            except OSError as e:
                # DNS / connect refused / network unreachable — keep trying.
                _log("connect", f"Network error: {e}, retrying in {backoff}s...")
            except Exception as e:
                _log("connect", f"Error: {e} ({type(e).__name__}), retrying in {backoff}s...")

            _time.sleep(backoff)
            backoff = min(backoff * 2, 30)  # cap at 30 seconds

            # After a reconnect attempt, try to refresh the token again in case
            # it expired while we were disconnected for a long period.
            if refresh_token:
                tokens = _refresh_token(host, secure, refresh_token)
                if tokens:
                    access_token = tokens["access_token"]
                    refresh_token = tokens["refresh_token"]
                    config["access_token"] = access_token
                    config["refresh_token"] = refresh_token
                    save_config(config)
    except KeyboardInterrupt:
        print("\n[connect] Stopped.", file=sys.stderr)
        # On explicit shutdown only — terminate all live daemon subprocesses.
        for aid, proc in daemon_procs.items():
            if proc.returncode is None:
                try:
                    proc.terminate()
                    _log("connect", f"Terminated daemon for agent {aid[:8]}...")
                except ProcessLookupError:
                    pass
        return


# ---------------------------------------------------------------------------
# Daemon subcommand
# ---------------------------------------------------------------------------


def cmd_daemon(args: argparse.Namespace) -> None:
    """Run daemon for a CLI session."""
    proto = "wss" if args.secure else "ws"
    ws_url = f"{proto}://{args.host}/ws/daemon"

    if args.cli_command:
        if args.no_followup:
            returncode, _ = asyncio.run(
                run_daemon_bidirectional(ws_url, args.token, args.cli_command)
            )
        else:
            returncode = asyncio.run(run_with_followup(ws_url, args.token, args.cli_command))
        sys.exit(returncode or 0)
    else:
        _log("daemon", "Reading from stdin (pipe mode)...")
        asyncio.run(run_daemon_pipe(ws_url, args.token, sys.stdin))


# ---------------------------------------------------------------------------
# PreToolUse permission hook — spawned by Claude CLI for every tool call.
# ---------------------------------------------------------------------------


def cmd_permission_hook(args: argparse.Namespace) -> None:  # noqa: ARG001
    """Handle a single Claude Code PreToolUse hook invocation.

    Claude spawns this subprocess per tool call with a JSON payload on
    stdin describing the tool use. We forward it to the backend, wait
    for the user's decision (long-poll HTTP), and write Claude's
    expected response shape to stdout.

    Environment (populated by the parent am daemon subprocess):
        AM_DAEMON_TOKEN   — daemon JWT (identifies user+agent)
        AM_BACKEND_HOST   — "host:port"
        AM_BACKEND_SECURE — "1" for https/wss, "0" for plain

    Fail-safe: on any error (network, missing token, timeout) we default
    to `ask` with a reason. This causes Claude to use its normal
    permission-mode flow instead of silently allowing or blocking.
    """
    import urllib.error
    import urllib.request

    def _emit(decision: str, reason: str = "") -> None:
        """Write the PreToolUse hook response and exit cleanly."""
        out = {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": decision,
                "permissionDecisionReason": reason,
            }
        }
        sys.stdout.write(json.dumps(out))
        sys.stdout.flush()
        sys.exit(0)

    try:
        raw_input_payload = sys.stdin.read()
    except Exception as e:
        _emit("ask", f"Hook: failed to read stdin: {e}")
        return

    try:
        hook_input = json.loads(raw_input_payload) if raw_input_payload.strip() else {}
    except json.JSONDecodeError as e:
        _emit("ask", f"Hook: bad JSON on stdin: {e}")
        return

    token = os.environ.get("AM_DAEMON_TOKEN")
    host = os.environ.get("AM_BACKEND_HOST", "localhost:8000")
    secure = os.environ.get("AM_BACKEND_SECURE") == "1"
    if not token:
        _emit("ask", "Hook: AM_DAEMON_TOKEN is not set")
        return

    proto = "https" if secure else "http"
    url = f"{proto}://{host}/api/hooks/permission/ask"

    body = {
        "tool_name": hook_input.get("tool_name"),
        "tool_input": hook_input.get("tool_input"),
        "hook_event_name": hook_input.get("hook_event_name"),
        "session_id": hook_input.get("session_id"),
        "transcript_path": hook_input.get("transcript_path"),
    }

    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode(),
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        # Long-poll: backend blocks until user answers or 5-min timeout.
        # Give urllib a slightly longer ceiling to avoid races.
        with _safe_urlopen(req, timeout=310) as resp:
            payload = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        _emit("ask", f"Hook: backend HTTP {e.code}")
        return
    except Exception as e:
        _emit("ask", f"Hook: backend error: {e}")
        return

    decision = payload.get("decision", "ask")
    reason = payload.get("reason", "")
    if decision not in ("allow", "deny", "ask"):
        decision = "ask"
    _emit(decision, reason)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def _read_version() -> str:
    """Return installed package version. Falls back gracefully if the
    package isn't installed (e.g. running straight from source tree)."""
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version("agent-manager-cli")
    except PackageNotFoundError:
        return "unknown"
    except Exception:
        return "unknown"


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="am",
        description="Agent Manager — daemon, login, and node agent",
    )
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"%(prog)s {_read_version()}",
    )
    subparsers = parser.add_subparsers(dest="command")

    # --- login ---
    login_p = subparsers.add_parser("login", help="Authenticate with the server")
    login_p.add_argument(
        "--host",
        default="agent-manager.space",
        help="Server host (default: agent-manager.space)",
    )
    login_p.add_argument("--email", help="Email (will prompt if not provided)")
    login_p.add_argument("--password", help="Password (will prompt if not provided)")
    login_p.add_argument("--secure", action="store_true", help="Use HTTPS/WSS")

    # --- connect ---
    connect_p = subparsers.add_parser("connect", help="Run node agent")
    connect_p.add_argument("--host", help="Override saved host")
    connect_p.add_argument("--secure", action="store_true", help="Use HTTPS/WSS")

    # --- daemon ---
    daemon_p = subparsers.add_parser("daemon", help="Run daemon for a CLI session")
    daemon_p.add_argument("--token", required=True, help="Daemon JWT token")
    daemon_p.add_argument("--host", default="localhost:8000", help="Backend host:port")
    daemon_p.add_argument("--secure", action="store_true", help="Use WSS")
    daemon_p.add_argument("--no-followup", action="store_true", help="Disable follow-up mode")
    daemon_p.add_argument("cli_command", nargs="*", help="CLI command to run")

    # --- permission-hook (spawned by Claude CLI as PreToolUse hook) ---
    subparsers.add_parser(
        "permission-hook",
        help="Internal: Claude Code PreToolUse hook handler",
    )

    args = parser.parse_args()

    if args.command == "login":
        cmd_login(args)
    elif args.command == "connect":
        cmd_connect(args)
    elif args.command == "daemon":
        cmd_daemon(args)
    elif args.command == "permission-hook":
        cmd_permission_hook(args)
    else:
        parser.print_help()
        sys.exit(1)
