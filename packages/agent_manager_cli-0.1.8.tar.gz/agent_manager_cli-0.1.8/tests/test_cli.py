"""Tests for CLI config management and helpers."""

import json
import subprocess
import sys

from am.cli import (
    _build_claude_hook_settings,
    _build_cli_command,
    _build_continue_command,
    format_control_request_for_stdin,
    format_control_response_for_stdin,
    format_permission_response_for_stdin,
    format_user_message_for_stdin,
    load_config,
    save_config,
)


class TestConfig:
    def test_load_config_missing(self, tmp_path, monkeypatch):
        monkeypatch.setattr("am.cli.CONFIG_FILE", tmp_path / "missing.json")
        assert load_config() == {}

    def test_save_and_load(self, tmp_path, monkeypatch):
        config_file = tmp_path / "sub" / "config.json"
        monkeypatch.setattr("am.cli.CONFIG_FILE", config_file)
        monkeypatch.setattr("am.cli.CONFIG_DIR", tmp_path / "sub")

        save_config({"host": "example.com", "secure": True})
        result = load_config()
        assert result["host"] == "example.com"
        assert result["secure"] is True


class TestFormatMessages:
    def test_user_message(self):
        result = json.loads(format_user_message_for_stdin("hello"))
        assert result["type"] == "user"
        assert result["message"]["role"] == "user"
        content = result["message"]["content"]
        assert len(content) == 1
        assert content[0]["type"] == "text"
        assert content[0]["text"] == "hello"

    def test_permission_allow(self):
        result = json.loads(format_permission_response_for_stdin(True))
        assert result["type"] == "permission_response"
        assert result["permission"] == "allow"

    def test_permission_deny(self):
        result = json.loads(format_permission_response_for_stdin(False))
        assert result["permission"] == "deny"


class TestBuildCommands:
    def test_claude_command(self):
        cmd = _build_cli_command("claude", "sess-123")
        assert cmd[0] == "claude"
        assert "--continue" in cmd
        assert "--resume" in cmd
        assert "sess-123" in cmd
        assert "--output-format" in cmd
        assert "stream-json" in cmd
        # No permission mode → flag should NOT be present
        assert "--permission-mode" not in cmd
        # Permission hook is enabled by default for claude
        assert "--settings" in cmd
        # The inline settings JSON must declare a PreToolUse hook pointing
        # to `am permission-hook` so Claude calls our bridge on every tool.
        idx = cmd.index("--settings")
        settings = json.loads(cmd[idx + 1])
        assert "hooks" in settings
        assert "PreToolUse" in settings["hooks"]
        hook_cmd = settings["hooks"]["PreToolUse"][0]["hooks"][0]["command"]
        assert "am permission-hook" in hook_cmd

    def test_claude_command_without_hook(self):
        cmd = _build_cli_command("claude", "sess-123", with_permission_hook=False)
        assert "--settings" not in cmd

    def test_claude_command_with_permission_mode(self):
        cmd = _build_cli_command("claude", "sess-123", permission_mode="acceptEdits")
        assert "--permission-mode" in cmd
        idx = cmd.index("--permission-mode")
        assert cmd[idx + 1] == "acceptEdits"

    def test_claude_command_rejects_unknown_permission_mode(self):
        # Unknown modes are silently dropped (we don't want to break
        # spawn just because the UI sent a garbage value).
        cmd = _build_cli_command("claude", "sess-123", permission_mode="nonsense")
        assert "--permission-mode" not in cmd

    def test_codex_command(self):
        cmd = _build_cli_command("codex", "rollout-abc")
        assert cmd == ["codex", "resume", "rollout-abc", "--json"]

    def test_gemini_command(self):
        cmd = _build_cli_command("gemini", "anything")
        assert cmd == ["gemini", "--resume"]

    def test_unsupported_cli(self):
        try:
            _build_cli_command("unknown", "x")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "unknown" in str(e)

    def test_continue_command(self):
        original = ["claude", "-p", "do stuff", "--output-format", "stream-json"]
        cmd = _build_continue_command(original, "sess-1", "next task")
        assert cmd[0] == "claude"
        assert "-p" in cmd
        assert "next task" in cmd
        assert "--continue" in cmd
        assert "--resume" in cmd
        assert "sess-1" in cmd


class TestControlProtocol:
    """Tests for Claude Code's stream-json control_request/response helpers."""

    def test_control_request_shape(self):
        raw = format_control_request_for_stdin("set_permission_mode", mode="plan")
        msg = json.loads(raw)
        assert msg["type"] == "control_request"
        assert msg["request_id"].startswith("set_permission_mode-")
        assert msg["request"] == {"subtype": "set_permission_mode", "mode": "plan"}

    def test_control_request_empty_payload(self):
        raw = format_control_request_for_stdin("interrupt")
        msg = json.loads(raw)
        assert msg["request"]["subtype"] == "interrupt"
        assert len(msg["request"]) == 1  # only subtype

    def test_control_response_allow(self):
        raw = format_control_response_for_stdin(
            request_id="req-1",
            allow=True,
            original_input={"command": "ls"},
        )
        msg = json.loads(raw)
        assert msg["type"] == "control_response"
        assert msg["response"]["subtype"] == "success"
        assert msg["response"]["request_id"] == "req-1"
        assert msg["response"]["response"]["behavior"] == "allow"
        assert msg["response"]["response"]["updatedInput"] == {"command": "ls"}
        assert "destination" not in msg["response"]["response"]

    def test_control_response_allow_sticky(self):
        raw = format_control_response_for_stdin(
            request_id="req-2",
            allow=True,
            original_input={"x": 1},
            destination="session",
        )
        msg = json.loads(raw)
        assert msg["response"]["response"]["destination"] == "session"

    def test_control_response_deny(self):
        raw = format_control_response_for_stdin(
            request_id="req-3",
            allow=False,
            deny_message="nope",
        )
        msg = json.loads(raw)
        assert msg["response"]["response"]["behavior"] == "deny"
        assert msg["response"]["response"]["message"] == "nope"
        assert "updatedInput" not in msg["response"]["response"]


class TestHookSettings:
    def test_build_claude_hook_settings(self):
        raw = _build_claude_hook_settings()
        settings = json.loads(raw)
        # Registers exactly one PreToolUse hook matching all tools.
        assert list(settings.keys()) == ["hooks"]
        assert list(settings["hooks"].keys()) == ["PreToolUse"]
        group = settings["hooks"]["PreToolUse"][0]
        assert group["matcher"] == "*"
        hooks = group["hooks"]
        assert len(hooks) == 1
        assert hooks[0]["type"] == "command"
        # Points at `sys.executable -m am permission-hook`
        assert "am permission-hook" in hooks[0]["command"]


class TestCLIEntryPoint:
    def test_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "am", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "login" in result.stdout
        assert "connect" in result.stdout
        assert "daemon" in result.stdout

    def test_login_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "am", "login", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "--host" in result.stdout
        assert "--email" in result.stdout

    def test_connect_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "am", "connect", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "--host" in result.stdout

    def test_daemon_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "am", "daemon", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "--token" in result.stdout

    def test_no_command_shows_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "am"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 1


class TestPermissionHook:
    """Tests for `am permission-hook` subcommand.

    The hook reads a Claude-style JSON payload on stdin, POSTs to the
    backend, waits for the user, and writes the hookSpecificOutput shape
    to stdout. We mock the backend via a monkey-patched urlopen.
    """

    def _run_hook(self, stdin_json, env, monkeypatch, mock_response):
        """Invoke cmd_permission_hook() inline, capturing stdout/exit."""
        import contextlib
        import io

        from am import cli as cli_mod

        class _FakeResponse:
            def __init__(self, body):
                self._body = json.dumps(body).encode()

            def read(self):
                return self._body

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

        def _fake_urlopen(req, *args, **kwargs):
            # Exceptions (e.g. HTTPError) can be injected by passing them
            # in as `mock_response`.
            if isinstance(mock_response, Exception):
                raise mock_response
            return _FakeResponse(mock_response)

        monkeypatch.setattr(cli_mod, "_safe_urlopen", _fake_urlopen)
        for k, v in env.items():
            monkeypatch.setenv(k, v)
        monkeypatch.setattr("sys.stdin", io.StringIO(json.dumps(stdin_json)))

        buf = io.StringIO()
        exit_code = None
        try:
            with contextlib.redirect_stdout(buf):
                cli_mod.cmd_permission_hook(type("A", (), {"command": "permission-hook"})())
        except SystemExit as e:
            exit_code = e.code
        return exit_code, buf.getvalue()

    def test_allow_decision(self, monkeypatch):
        code, out = self._run_hook(
            stdin_json={
                "tool_name": "Bash",
                "tool_input": {"command": "ls"},
                "hook_event_name": "PreToolUse",
                "session_id": "s1",
            },
            env={
                "AM_DAEMON_TOKEN": "fake-token",
                "AM_BACKEND_HOST": "localhost:8000",
                "AM_BACKEND_SECURE": "0",
            },
            monkeypatch=monkeypatch,
            mock_response={"decision": "allow", "reason": "user approved"},
        )
        assert code == 0
        parsed = json.loads(out)
        assert parsed["hookSpecificOutput"]["hookEventName"] == "PreToolUse"
        assert parsed["hookSpecificOutput"]["permissionDecision"] == "allow"
        assert parsed["hookSpecificOutput"]["permissionDecisionReason"] == "user approved"

    def test_deny_decision(self, monkeypatch):
        code, out = self._run_hook(
            stdin_json={"tool_name": "Bash", "tool_input": {"command": "rm -rf /"}},
            env={
                "AM_DAEMON_TOKEN": "fake",
                "AM_BACKEND_HOST": "localhost:8000",
            },
            monkeypatch=monkeypatch,
            mock_response={"decision": "deny", "reason": "nope"},
        )
        assert code == 0
        parsed = json.loads(out)
        assert parsed["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_missing_token_defaults_to_ask(self, monkeypatch):
        # Without AM_DAEMON_TOKEN the hook can't talk to the backend, so
        # it must emit "ask" so Claude falls back to permission-mode logic.
        monkeypatch.delenv("AM_DAEMON_TOKEN", raising=False)
        code, out = self._run_hook(
            stdin_json={"tool_name": "Bash"},
            env={},  # no token
            monkeypatch=monkeypatch,
            mock_response={"decision": "allow"},  # never called
        )
        assert code == 0
        parsed = json.loads(out)
        assert parsed["hookSpecificOutput"]["permissionDecision"] == "ask"
        assert "AM_DAEMON_TOKEN" in parsed["hookSpecificOutput"]["permissionDecisionReason"]

    def test_backend_error_defaults_to_ask(self, monkeypatch):
        code, out = self._run_hook(
            stdin_json={"tool_name": "Bash"},
            env={"AM_DAEMON_TOKEN": "fake"},
            monkeypatch=monkeypatch,
            mock_response=ConnectionRefusedError("backend down"),
        )
        assert code == 0
        parsed = json.loads(out)
        assert parsed["hookSpecificOutput"]["permissionDecision"] == "ask"
        assert "backend error" in parsed["hookSpecificOutput"]["permissionDecisionReason"]

    def test_garbage_decision_coerced_to_ask(self, monkeypatch):
        code, out = self._run_hook(
            stdin_json={"tool_name": "Bash"},
            env={"AM_DAEMON_TOKEN": "fake"},
            monkeypatch=monkeypatch,
            mock_response={"decision": "something-weird"},
        )
        assert code == 0
        parsed = json.loads(out)
        assert parsed["hookSpecificOutput"]["permissionDecision"] == "ask"

    def test_bad_stdin_json_defaults_to_ask(self, monkeypatch):
        import contextlib
        import io

        from am import cli as cli_mod

        monkeypatch.setenv("AM_DAEMON_TOKEN", "fake")
        monkeypatch.setattr("sys.stdin", io.StringIO("not json {{"))
        buf = io.StringIO()
        code = None
        try:
            with contextlib.redirect_stdout(buf):
                cli_mod.cmd_permission_hook(type("A", (), {"command": "permission-hook"})())
        except SystemExit as e:
            code = e.code
        assert code == 0
        parsed = json.loads(buf.getvalue())
        assert parsed["hookSpecificOutput"]["permissionDecision"] == "ask"
        assert "bad JSON" in parsed["hookSpecificOutput"]["permissionDecisionReason"]

    def test_cli_registers_subcommand(self):
        result = subprocess.run(
            [sys.executable, "-m", "am", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "permission-hook" in result.stdout
