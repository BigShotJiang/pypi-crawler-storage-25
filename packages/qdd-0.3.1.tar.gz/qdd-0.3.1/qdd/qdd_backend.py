from collections import Counter
import dataclasses
import math
import os
import sys
import time
import traceback
from typing import Any, Dict, List, Union
import uuid
from warnings import warn

from qiskit.circuit import QuantumCircuit as QiskitCircuit
from qiskit.circuit import Barrier, Clbit, ClassicalRegister, IfElseOp, Measure, Qubit, Reset
import qiskit.circuit.library as qiskit_gates
from qiskit.circuit.library import Initialize
from qiskit.providers import BackendV2, JobV1,Options
from qiskit.result import Result
from qiskit.transpiler import Target

from qdd import __version__ as qdd_version
from qdd import pyQDD
from qdd.qdd_failed_job import QddFailedJob
from qdd.qdd_job import QddJob
from qdd.qdd_gate import QDDGate
from .circuit_property import CircuitProperty


_qiskit_gates_1q_0param: Dict = {
    qiskit_gates.HGate: "H",
    qiskit_gates.IGate: "I",
    qiskit_gates.SdgGate: "Sdag",
    qiskit_gates.SGate: "S",
    qiskit_gates.SXdgGate: "SXdag",
    qiskit_gates.SXGate: "SX",
    qiskit_gates.TdgGate: "Tdag",
    qiskit_gates.TGate: "T",
    qiskit_gates.XGate: "X",
    qiskit_gates.YGate: "Y",
    qiskit_gates.ZGate: "Z",
    qiskit_gates.CXGate: "X",
    qiskit_gates.CYGate: "Y",
    qiskit_gates.CZGate: "Z",
    qiskit_gates.CSXGate: "SX",
    qiskit_gates.CCXGate: "X",
    qiskit_gates.C3XGate: "X",
    qiskit_gates.C4XGate: "X",
    qiskit_gates.MCXGate: "X",
}

_qiskit_gates_1q_1param: Dict = {
    qiskit_gates.RXGate: pyQDD.rxmat,
    qiskit_gates.RYGate: pyQDD.rymat,
    qiskit_gates.RZGate: pyQDD.rzmat,
    qiskit_gates.PhaseGate: pyQDD.p,
    qiskit_gates.CPhaseGate: pyQDD.p,
    qiskit_gates.MCPhaseGate: pyQDD.p,
    qiskit_gates.CU1Gate: pyQDD.u1,
    qiskit_gates.CRXGate: pyQDD.rxmat,
    qiskit_gates.CRYGate: pyQDD.rymat,
    qiskit_gates.CRZGate: pyQDD.rzmat,
}

_qiskit_gates_1q_2param: Dict = {
    qiskit_gates.RGate: pyQDD.r,
}

_qiskit_gates_1q_3param: Dict = {
    qiskit_gates.UGate: pyQDD.u3,
    qiskit_gates.CU3Gate: pyQDD.u3,
}

_qiskit_gates_1q_4param: Dict = {
    qiskit_gates.CUGate: pyQDD.u,
}

_qiskit_gates_1q: Dict = {
    **_qiskit_gates_1q_0param,
    **_qiskit_gates_1q_1param,
    **_qiskit_gates_1q_2param,
    **_qiskit_gates_1q_3param,
    **_qiskit_gates_1q_4param,
}

_qiskit_gates_2q_0param: Dict = {
    qiskit_gates.SwapGate: pyQDD.swapmat,
    qiskit_gates.iSwapGate: pyQDD.iswapmat,
    qiskit_gates.CSwapGate: pyQDD.swapmat,
}

_qiskit_gates_2q_1param: Dict = {
    qiskit_gates.RXXGate: pyQDD.rxxmat,
    qiskit_gates.RYYGate: pyQDD.ryymat,
    qiskit_gates.RZZGate: pyQDD.rzzmat,
    qiskit_gates.RZXGate: pyQDD.rzxmat,
}


_qiskit_gates_2q: Dict = {
    **_qiskit_gates_2q_0param,
    **_qiskit_gates_2q_1param,
}

_qiskit_gates_unitary: Dict = {
    qiskit_gates.UnitaryGate: pyQDD.unitary,
}

_qdd_gate: Dict = {
    QDDGate: None,
}

_supported_qiskit_gates: Dict = {
    **_qiskit_gates_1q,
    **_qiskit_gates_2q,
    **_qiskit_gates_unitary,
    **_qdd_gate,
}


@dataclasses.dataclass
class QddExperiments:
    circs: List[QiskitCircuit]
    circuit_props: List[CircuitProperty]
    options: dict


class QddBackend(BackendV2):
    """A backend used for evaluating circuits with QDD simulator."""

    _save_SV = False
    _basis_gates: List[str] = [
        "ccx",
        "cp",
        "crx",
        "cry",
        "crz",
        "cswap",
        "csx",
        "cu",
        "cu1",
        "cu3",
        "cx",
        "cy",
        "cz",
        "h",
        "id",
        "if_else",
        "iswap",
        "mcx",
        "measure",
        "p",
        "r",
        "reset",
        "rx",
        "rxx",
        "ry",
        "ryy",
        "rz",
        "rzx",
        "rzz",
        "s",
        "sdg",
        "swap",
        "sx",
        "sxdg",
        "t",
        "tdg",
        "u",
        "unitary",
        "x",
        "y",
        "z",
    ]

    _NUM_QUBITS = 100

    _MAX_SHOTS = int(1e6)

    _DEFAULT_SHOTS = 1024

    # If user specify runtime options that are not included in the default option list, the runtime options are ignored
    # and ignorance warnings will be emitted.
    # This dict is used for suppressing the ignorance warnings.
    _OPTIONS_IGNORED_WITHOUT_WARN = {
        # Entries of "the option key": "whether the option value can be ignored without warning"
        # 'parameter_binds' is a very exceptional option. The option is always not ignored even though it is not in the
        # default option list; so, ignorance warning should not be emitted.
        "parameter_binds": lambda _: True,
        "max_credits": lambda _: True,  # it is obvious to users that max_credits has no meaning in the Qdd simulator
    }

    def __init__(self, provider, name="qasm_simulator"):
        super().__init__(
            provider=provider,
            name=name,
            description="Backend for QDD",
            backend_version=qdd_version,
        )

    @property
    def target(self):
        target = Target.from_configuration(
            basis_gates=self._basis_gates,
            num_qubits=self._NUM_QUBITS,
            custom_name_mapping={
                "if_else": IfElseOp,
                "mcx": qiskit_gates.MCXGate,
                "unitary": qiskit_gates.UnitaryGate,
            },
        )
        return target

    @property
    def max_circuits(self):
        return None

    @classmethod
    def _default_options(cls):
        return Options(
            shots=cls._DEFAULT_SHOTS,
            memory=False,
            seed_simulator=None,
            use_mpi=False,
            show_progress=False,
            show_progress_frequency=10000,
        )

    @staticmethod
    def _create_experiment_header(qiskit_circ: QiskitCircuit) -> dict:
        clbit_labels = []
        creg_sizes = []
        memory_slots = 0
        for creg in qiskit_circ.cregs:
            for i in range(creg.size):
                clbit_labels.append([creg.name, i])
            creg_sizes.append([creg.name, creg.size])
            memory_slots += creg.size

        qubit_labels = []
        qreg_sizes = []
        num_qubits = 0
        for qreg in qiskit_circ.qregs:  # 'qregs' includes ancilla registers
            for i in range(qreg.size):
                qubit_labels.append([qreg.name, i])
            qreg_sizes.append([qreg.name, qreg.size])
            num_qubits += qreg.size

        header = {
            "clbit_labels": clbit_labels,
            "creg_sizes": creg_sizes,
            "global_phase": float(qiskit_circ.global_phase),
            "memory_slots": memory_slots,
            "metadata": qiskit_circ.metadata,
            "n_qubits": num_qubits,
            "name": qiskit_circ.name,
            "qreg_sizes": qreg_sizes,
            "qubit_labels": qubit_labels,
        }

        return header

    def run(
        self, circuits: Union[QiskitCircuit, List[QiskitCircuit]], **run_options
    ) -> JobV1:
        qiskit_circs: List[QiskitCircuit] = []

        try:
            # convert the given 'circuits' argument into a list of QiskitCircuit
            if isinstance(circuits, QiskitCircuit):
                qiskit_circs = [circuits]
            elif isinstance(circuits, list) and all(
                isinstance(circ, QiskitCircuit) for circ in circuits
            ):
                qiskit_circs = circuits
            else:
                # the argument type is invalid; abort circuit evaluation.
                if isinstance(circuits, list):
                    arg_circ_type = str(list(map(type, circuits)))
                else:
                    arg_circ_type = str(type(circuits))
                raise RuntimeError(
                    f"{self.name}.run(...) accepts one or more"
                    f" qiskit.{QiskitCircuit.__qualname__} objects only,"
                    f" but the following arguments were specified.{os.linesep}"
                    f"    type={arg_circ_type},{os.linesep}"
                    f"    value={circuits}"
                )

            # evaluate the given circuits
            return self._run_internal(qiskit_circs, **run_options)

        except Exception as e:
            # print the stack trace and error messages so that the user can notice the circuit evaluation has failed.
            traceback.print_exc()
            circ_names = [circ.name for circ in qiskit_circs]

            print(
                f"Failed to evaluate the given circuits. {circ_names}."
                f"{os.linesep}Please see error messages.",
                file=sys.stderr,
            )

            job_id = "N/A"
            result = Result.from_dict(
                {
                    "results": [],
                    "backend_name": self.name,
                    "backend_version": self.backend_version,
                    "job_id": job_id,
                    "qobj_id": "N/A",
                    "success": False,
                    "status": str(e),
                }
            )
            return QddFailedJob(self, job_id, result)

    def _run_internal(self, qiskit_circs: List[QiskitCircuit], **run_options) -> JobV1:
        self._validate_run_options(run_options)
        actual_options = {
            "shots": run_options.get("shots", self.options.shots),
            "memory": run_options.get("memory", self.options.memory),
            "seed_simulator": run_options.get(
                "seed_simulator", self.options.seed_simulator
            ),
            "use_mpi": run_options.get("use_mpi", self.options.use_mpi),
            "show_progress": run_options.get("show_progress", self.options.show_progress),
            "show_progress_frequency": run_options.get("show_progress_frequency", self.options.show_progress_frequency),
        }

        if ("parameter_binds" in run_options) and (
            run_options["parameter_binds"] is not None
        ):
            param_bound_qiskit_circs = []
            for qiskit_circ, binds in zip(qiskit_circs, run_options["parameter_binds"]):
                param_bound_qiskit_circs.append(qiskit_circ.assign_parameters(binds))
        else:
            # no parameter bindings are specified
            param_bound_qiskit_circs = qiskit_circs

        circ_props = QddBackend._validate_and_get_circuit_properties(
            param_bound_qiskit_circs, self._save_SV == False
        )
        experiments = QddExperiments(
            circs=param_bound_qiskit_circs,
            circuit_props=circ_props,
            options=actual_options,
        )

        # run circuits via issuing a job
        job_id = str(uuid.uuid4())
        job = QddJob(
            backend=self,
            job_id=job_id,
            run_exp_fn=self._run_experiment,
            qobj=experiments,
        )
        job.submit()

        return job

    def _run_experiment(self, experiments, job_id) -> Result:
        """Runs the given experiments"""
        results = [
            self._evaluate_circuit(circ, circ_prop, experiments.options)
            for circ, circ_prop in zip(experiments.circs, experiments.circuit_props)
        ]

        result = Result.from_dict(
            {
                "results": results,
                "backend_name": self.name,
                "backend_version": self.backend_version,
                "job_id": job_id,
                "qobj_id": "N/A",
                "success": True,
            }
        )

        return result

    def _create_qubitmap(self, circ: QiskitCircuit):
        qubits = circ.qubits
        mapdata = {}
        id = 0
        for qubit in qubits:
            mapdata[qubit] = id
            id += 1
        self.qubitmap = mapdata

    def get_qID(self, qubit):
        return self.qubitmap[qubit]

    def _create_cbitmap(self, circ: QiskitCircuit):
        cbits = circ.clbits
        mapdata = {}
        id = 0
        for cbit in cbits:
            mapdata[cbit] = id
            id += 1
        self.cbitmap = mapdata

    def get_cID(self, cbit):
        return self.cbitmap[cbit]

    def merge_circuit(self, circ: QiskitCircuit, gc_freq=20):
        n_qubit = circ.num_qubits
        n_cbit = circ.num_clbits
        self._create_qubitmap(circ)
        self._create_cbitmap(circ)

        current = pyQDD.makeGate(n_qubit, "I", 0)
        count = 0
        for ci in circ.data:
            i, qargs, cargs = ci.operation, ci.qubits, ci.clbits
            qiskit_gate_type = i.base_class
            # filter out special cases first
            if qiskit_gate_type == Barrier:
                continue
            if qiskit_gate_type == Measure:
                continue
            assert len(cargs) == 0

            if qiskit_gate_type in _supported_qiskit_gates:
                if qiskit_gate_type in _qiskit_gates_1q:
                    controls = []
                    for j in range(len(qargs) - 1):
                        controls.append(self.get_qID(qargs[j]))
                    if qiskit_gate_type in _qiskit_gates_1q_0param:
                        matrix = _qiskit_gates_1q_0param[qiskit_gate_type]
                    elif qiskit_gate_type in _qiskit_gates_1q_1param:
                        matrix = _qiskit_gates_1q_1param[qiskit_gate_type](i.params[0])
                    elif qiskit_gate_type in _qiskit_gates_1q_2param:
                        matrix = _qiskit_gates_1q_2param[qiskit_gate_type](
                            i.params[0], i.params[1]
                        )
                    elif qiskit_gate_type in _qiskit_gates_1q_3param:
                        matrix = _qiskit_gates_1q_3param[qiskit_gate_type](
                            i.params[0], i.params[1], i.params[2]
                        )
                    elif qiskit_gate_type in _qiskit_gates_1q_4param:
                        matrix = _qiskit_gates_1q_4param[qiskit_gate_type](
                            i.params[0], i.params[1], i.params[2], i.params[3]
                        )
                    gate = pyQDD.makeGate(
                        n_qubit, matrix, self.get_qID(qargs[-1]), controls
                    )
                    current = pyQDD.mm_multiply(gate, current)
                elif qiskit_gate_type in _qiskit_gates_2q:
                    controls = []
                    for j in range(len(qargs) - 2):
                        controls.append(self.get_qID(qargs[j]))
                    if qiskit_gate_type in _qiskit_gates_2q_0param:
                        matrix = _qiskit_gates_2q_0param[qiskit_gate_type]()
                    elif qiskit_gate_type in _qiskit_gates_2q_1param:
                        matrix = _qiskit_gates_2q_1param[qiskit_gate_type](i.params[0])
                    gate = pyQDD.makeTwoQubitGate(
                        n_qubit,
                        matrix,
                        self.get_qID(qargs[-1]),
                        self.get_qID(qargs[-2]),
                        controls,
                    )
                    current = pyQDD.mm_multiply(gate, current)
                elif qiskit_gate_type in _qiskit_gates_unitary:
                    matrix = i.to_matrix()
                    targets = [self.get_qID(q) for q in qargs]
                    gate = pyQDD.unitary(n_qubit, matrix, targets)
                    current = pyQDD.mm_multiply(gate, current)
                elif qiskit_gate_type in _qdd_gate:
                    gate = i.params[0]
                    current = pyQDD.mm_multiply(gate, current)
                else:
                    raise RuntimeError(
                        f"Unsupported gate or instruction:"
                        f" type={qiskit_gate_type.__name__}, name={i.name}."
                        f" It needs to transpile the circuit before evaluating it."
                    )

            count += 1
            if self.options.show_progress and count % self.options.show_progress_frequency == 0:
                print(count,"/",len(circ.data))
            if count%gc_freq==0:
                current = pyQDD.gc_mat(current, False)
            # pyQDD.clear_cache(False)
        current = pyQDD.applyGlobal(current, circ.global_phase)
        return current

    def _execute_instructions(
        self,
        instructions,
        current,
        val_cbit,
        prob_cbit,
        circ,
        circ_prop,
        options,
        n_qubit,
    ):
        use_mpi = options["use_mpi"]
        if use_mpi:
            from mpi4py import MPI

        for ci in instructions:
            i, qargs, cargs = ci.operation, ci.qubits, ci.clbits

            if isinstance(i, IfElseOp):
                classical, val = i.condition

                # Determine if the condition is met
                execute_true_body = False
                if isinstance(classical, ClassicalRegister):
                    current_val = 0
                    # The bits in a register are ordered from LSB to MSB for the value
                    for bit_idx, bit in enumerate(classical):
                        if val_cbit[self.get_cID(bit)] == '1':
                            current_val |= (1 << bit_idx)
                    if current_val == val:
                        execute_true_body = True
                elif isinstance(classical, Clbit):
                    # For a single clbit, the value is just 0 or 1
                    if int(val_cbit[self.get_cID(classical)]) == val:
                        execute_true_body = True
                
                body = None
                if execute_true_body:
                    body = i.blocks[0]
                elif len(i.blocks) > 1:
                    body = i.blocks[1]

                if body:
                    (
                        current, val_cbit, prob_cbit
                    ) = self._execute_instructions(
                        body.data, current, val_cbit, prob_cbit, circ, circ_prop, options, n_qubit,
                    )
                continue

            skip = False
            if hasattr(i, "condition") and i.condition is not None:
                classical, val = i.condition
                if isinstance(classical, Clbit):
                    if val_cbit[self.get_cID(classical)] != str(int(val)):
                        skip = True
                else:
                    for clbit in classical:
                        idx = self.get_cID(clbit)
                        if val_cbit[idx] != str((val >> idx) & 1):
                            skip = True
                            break
            if skip:
                continue
            qiskit_gate_type = i.base_class
            # print("#", MPI.COMM_WORLD.Get_rank(), "#", qiskit_gate_type, qargs)

            # filter out special cases first
            if qiskit_gate_type == Barrier:
                continue
            if qiskit_gate_type == Measure and circ_prop.stable_final_state == True:
                continue
            if circ_prop.stable_final_state == True:
                assert len(cargs) == 0

            if qiskit_gate_type in _supported_qiskit_gates:
                if qiskit_gate_type in _qiskit_gates_1q:
                    controls = []
                    for j in range(len(qargs) - 1):
                        controls.append(self.get_qID(qargs[j]))
                    if qiskit_gate_type in _qiskit_gates_1q_0param:
                        matrix = _qiskit_gates_1q_0param[qiskit_gate_type]
                    elif qiskit_gate_type in _qiskit_gates_1q_1param:
                        matrix = _qiskit_gates_1q_1param[qiskit_gate_type](
                            i.params[0]
                        )
                    elif qiskit_gate_type in _qiskit_gates_1q_2param:
                        matrix = _qiskit_gates_1q_2param[qiskit_gate_type](
                            i.params[0], i.params[1]
                        )
                    elif qiskit_gate_type in _qiskit_gates_1q_3param:
                        matrix = _qiskit_gates_1q_3param[qiskit_gate_type](
                            i.params[0], i.params[1], i.params[2]
                        )
                    elif qiskit_gate_type in _qiskit_gates_1q_4param:
                        matrix = _qiskit_gates_1q_4param[qiskit_gate_type](
                            i.params[0], i.params[1], i.params[2], i.params[3]
                        )
                    gate = pyQDD.makeGate(
                        n_qubit,
                        matrix,
                        self.get_qID(qargs[-1]),
                        controls,
                    )
                    current = (
                        pyQDD.mv_multiply(gate, current)
                        if use_mpi == False
                        else pyQDD.mv_multiply_MPI(
                                gate,
                                current,
                                n_qubit,
                                max(
                                    [self.get_qID(i) for i in qargs]
                                ),
                            )
                    )
                elif qiskit_gate_type in _qiskit_gates_2q:
                    controls = []
                    for j in range(len(qargs) - 2):
                        controls.append(self.get_qID(qargs[j]))
                    if qiskit_gate_type in _qiskit_gates_2q_0param:
                        matrix = _qiskit_gates_2q_0param[qiskit_gate_type]()
                    elif qiskit_gate_type in _qiskit_gates_2q_1param:
                        matrix = _qiskit_gates_2q_1param[qiskit_gate_type](
                            i.params[0]
                        )
                    gate = pyQDD.makeTwoQubitGate(
                        n_qubit,
                        matrix,
                        self.get_qID(qargs[-1]),
                        self.get_qID(qargs[-2]),
                        controls,
                    )
                    current = (
                        pyQDD.mv_multiply(gate, current)
                        if use_mpi == False
                        else (
                            pyQDD.mv_multiply_MPI(
                                gate,
                                current,
                                n_qubit,
                                max(
                                    [self.get_qID(i) for i in qargs]
                                ),
                            )
                        )
                    )
                elif qiskit_gate_type in _qiskit_gates_unitary:
                    matrix = i.to_matrix()
                    targets = [self.get_qID(q) for q in qargs]
                    gate = pyQDD.unitary(n_qubit, matrix, targets)
                    current = (
                        pyQDD.mv_multiply(gate, current)
                        if use_mpi == False
                        else (
                            pyQDD.mv_multiply_MPI(
                                gate,
                                current,
                                n_qubit,
                                max(
                                    [self.get_qID(i) for i in qargs]
                                ),
                            )
                        )
                    )
                elif qiskit_gate_type in _qdd_gate:
                    if use_mpi:
                        raise RuntimeError(
                            f"Unsupported gate or instruction:"
                            f" type={qiskit_gate_type.__name__}, name={i.name}."
                            f" QDDGate is not supported with MPI now."
                        )
                    gate = i.params[0]
                    current = (pyQDD.mv_multiply(gate, current) if use_mpi == False
                         else pyQDD.mv_multiply_MPI(gate, current, n_qubit, max([self.get_qID(i) for i in qargs]),) )
                else:
                    raise RuntimeError(
                        f"Unsupported gate or instruction:"
                        f" type={qiskit_gate_type.__name__}, name={i.name}."
                        f" It needs to transpile the circuit before evaluating it."
                    )
            else:
                if (
                    qiskit_gate_type == Measure
                    and circ_prop.stable_final_state == False
                ):
                    if options["shots"]:
                        current, val_cbit[self.get_cID(cargs[0])] = (
                            pyQDD.measureOneCollapsing(
                                current, self.get_qID(qargs[0])
                            )
                            if use_mpi == False
                            else pyQDD.measureOneCollapsingMPI(
                                current,
                                self.get_qID(qargs[0]),
                                n_qubit,
                            )
                        )
                    else:
                        current, prob_cbit[self.get_cID(cargs[0])] = (
                            pyQDD.measureOne(
                                current, self.get_qID(qargs[0])
                            )
                            if use_mpi == False
                            else pyQDD.measureOneMPI(
                                current,
                                self.get_qID(qargs[0]),
                                n_qubit,
                            )
                        )
                elif (
                    qiskit_gate_type == Reset
                    and circ_prop.stable_final_state == False
                ):
                    current, _meas_result = (
                        pyQDD.measureOneCollapsing(
                            current, self.get_qID(qargs[0])
                        )
                        if use_mpi == False
                        else pyQDD.measureOneCollapsingMPI(
                            current, self.get_qID(qargs[0]), n_qubit
                        )
                    )
                    if _meas_result == "1":
                        gate = pyQDD.makeGate(
                            n_qubit, "X", self.get_qID(qargs[0])
                        )
                        current = (
                            pyQDD.mv_multiply(gate, current)
                            if use_mpi == False
                            else pyQDD.mv_multiply_MPI(
                                gate,
                                current,
                                n_qubit,
                                max(
                                    [self.get_qID(i) for i in qargs]
                                ),
                            )
                        )
                else:
                    # We assume the given Qiskit circuit has already been transpiled into a circuit of basis gates only.
                    raise RuntimeError(
                        f"Unsupported gate or instruction:"
                        f" type={qiskit_gate_type.__name__}, name={i.name}."
                        f" It needs to transpile the circuit before evaluating it."
                    )
            current = pyQDD.gc(current, False)

        return current, val_cbit, prob_cbit

    def _evaluate_circuit(
        self, circ: QiskitCircuit, circ_prop: CircuitProperty, options: dict
    ):
        use_mpi = options["use_mpi"]
        size_global = 0
        if use_mpi:
            from mpi4py import MPI

            circ = MPI.COMM_WORLD.bcast(circ, root=0)
            circ_prop = MPI.COMM_WORLD.bcast(circ_prop, root=0)
            if pow(2, circ.num_qubits) <= MPI.COMM_WORLD.Get_size():
                print("ERROR: Too many nodes for MPI")
                assert pow(2, circ.num_qubits) > MPI.COMM_WORLD.Get_size()
            size_global = int(math.log2(MPI.COMM_WORLD.Get_size()))

        n_qubit = circ.num_qubits
        n_cbit = circ.num_clbits
        self._create_qubitmap(circ)
        self._create_cbitmap(circ)
        if options["shots"]:
            sampled_values = [None] * options["shots"]
        #        print(len(circ.data), " gates")

        if options["shots"] is None:
            has_classical_condition = False
            for ci in circ.data:
                i, qargs, cargs = ci.operation, ci.qubits, ci.clbits
                if getattr(i, "condition", None):
                    has_classical_condition = True
                    break
            if has_classical_condition:
                raise RuntimeError(
                    "ERROR: Classical condition is not supported when shots=None"
                )

        reps = 1
        if circ_prop.stable_final_state == False and isinstance(options["shots"], int):
            reps = options["shots"]

        prob_cbit = [0] * n_cbit
        for shot in range(reps):
            val_cbit = ["0"] * n_cbit
            current = (
                pyQDD.makeZeroState(n_qubit)
                if use_mpi == False
                else pyQDD.makeZeroStateMPI(n_qubit)
            )

            (
                current, val_cbit, prob_cbit,
            ) = self._execute_instructions(
                circ.data, current, val_cbit, prob_cbit, circ, circ_prop, options, n_qubit,
            )

            # print(shot, val_cbit)
            if options["shots"] and circ_prop.stable_final_state == False:
                sampled_values[shot] = "".join(reversed(val_cbit))

        current = pyQDD.applyGlobal(current, circ.global_phase)

        if options["shots"] and circ_prop.stable_final_state == True:
            for i in range(options["shots"]):
                _, result_tmp = (
                    pyQDD.measureAll(current, False)
                    if use_mpi == False
                    else pyQDD.measureAllMPI(current, False)
                )
                result_final_tmp = ["0"] * n_cbit
                mapping: Dict[Clbit, Qubit] = circ_prop.clbit_final_values
                for cbit in mapping:
                    result_final_tmp[self.get_cID(cbit)] = result_tmp[
                        len(result_tmp)
                        - 1
                        - self.get_qID(mapping[cbit])
                    ]  # TODO: need check
                sampled_values[i] = "".join(reversed(result_final_tmp))

        if options["shots"]:
            hex_sampled_counts = Counter(sampled_values)
            result_data: Dict[str, Any] = {"counts": hex_sampled_counts}
            if options["memory"]:
                result_data["memory"] = sampled_values
            if self._save_SV:
                result_data["statevector"] = (
                    pyQDD.getVector(current)
                    if use_mpi == False
                    else pyQDD.getVectorMPI(current, n_qubit, MPI.COMM_WORLD.Get_size())
                )

        else:
            if circ_prop.stable_final_state:
                prob = (
                    pyQDD.probabilities(current)
                    if use_mpi == False
                    else pyQDD.probabilitiesMPI(current)
                )
            else:
                prob = [1] * (2**n_cbit)
                for i in range(2**n_cbit):
                    for j in range(n_cbit):
                        if i & (1 << j):
                            prob[i] *= 1 - prob_cbit[j]
                        else:
                            prob[i] *= prob_cbit[j]
            probabilities = {}
            for i, p in enumerate(prob):
                probabilities[i] = p
            result_data: Dict[str, Any] = {"probabilities": probabilities}
            if self._save_SV:
                result_data["statevector"] = (
                    pyQDD.getVector(current)
                    if use_mpi == False
                    else pyQDD.getVectorMPI(current, n_qubit, MPI.COMM_WORLD.Get_size())
                )
        header = QddBackend._create_experiment_header(circ)
        result = {
            "success": True,
            "shots": options["shots"],
            "data": result_data,
            # Note: header information is used by several Qiskit functions; it must be contained in every result object.
            # E.g., header['memory_slots'] is used in Result#get_counts() for formatting sampled counts.
            "header": header,
            "edge": current,
        }

        #        print("nQubit", n_qubit, "nGates", len(circ.data), "nNodes", pyQDD.get_nNodes(current))
        return result

    @staticmethod
    def _validate_and_get_circuit_properties(
        qiskit_circs: List[QiskitCircuit], require_measurement=True
    ) -> List[CircuitProperty]:
        circ_props = [
            QddBackend._validate_and_get_circuit_property(circ, require_measurement)
            for circ in qiskit_circs
        ]
        return circ_props

    @staticmethod
    def _validate_and_get_circuit_property(
        circ: QiskitCircuit, require_measurement=True
    ) -> CircuitProperty:
        """Checks whether the given circuit is valid to run (e.g., #qubits <= #max-qubits),
        and, if valid, returns a CircuitProperty instance that will be used for simulation.
        """

        # #qubit must be lower than #max-qubits
        max_qubits: int = QddBackend._NUM_QUBITS
        if circ.num_qubits > max_qubits:  # num_qubits includes ancilla registers
            raise RuntimeError(
                f'Circuit "{circ.name}" has {circ.num_qubits} qubits,'
                f" but #qubits must be <= {max_qubits}."
            )

        # Check whether the final state computed by evaluating the circuit is stable over shots,
        # which affects the simulation strategy (see QddBackend._evaluate_circuit(...) for the details).
        # If either of the followings holds, the final state is regarded as unstable.
        # - There are conditional gates.
        # - For the same qubit, there are instructions (except for measurements) after a measurement.
        # - There are probabilistic instructions (e.g., reset, kraus).
        #   Note: Reset is decomposed to two operations: Measure(q, c) and circuit.x(q).c_if(c, 1);
        #         so, Reset is regarded as a stochastic operation.
        # - There are 'initialize' instructions that are not located at the first step in the circuit
        #   and do not operate on all qubits (i.e., non-full-width initialization at or after the second step).
        #   Note: 'Initialize' performs reset instructions at first, thereby regarded as stochastic.
        #         Exceptions are full-width initializations and an initialization at the first step,
        #         which is deterministic.
        #
        # Note: consecutive measurements for the same qubit do not result in an unstable final state
        # because they are equal to a single measurement for the qubit.
        # Note: a measure gate with broadcast parameters, e.g., Measure(0, [0, 1]), is decomposed into
        # two measure gates: Measure(0, 0) and Measure(0, 1).
        # Note: all the quantum channel instructions (e.g., Choi, SuperOp, Kraus, ...) have the name of 'kraus'.
        stable_final_state: bool = True
        measured_qubits = set()
        clbit_final_values: Dict[Clbit, Qubit] = (
            {}
        )  # for each clbit, this holds the qubit last assigned to the clbit.
        for i, ci in enumerate(circ.data):
            inst, qargs, cargs = ci.operation, ci.qubits, ci.clbits
            if inst.base_class == Measure:
                # For a Measure instruction, both qargs and cargs always have a size of 1.
                # (Multi-target measurements (Measure([...], [...]) is decomposed to single-target measurement gates.)
                clbit_final_values[cargs[0]] = qargs[0]
                measured_qubits |= set(qargs)
            elif (
                hasattr(inst, "condition") and inst.condition is not None
                or any(qubit in measured_qubits for qubit in qargs)
                or inst.base_class == Reset
                or inst.name == "kraus"
                or inst.name == "superop"
            ):
                # Note: the condition value of 'superop' might have no meaning because SuperOp instances have
                # the name of 'kraus'; however, the implementation of the Qiskit aer simulator explicitly tests
                # the name against 'superop' to check whether the circuit has probabilistic instructions.
                # https://github.com/Qiskit/qiskit-aer/blob/0.9.1/src/controllers/aer_controller.hpp#L1621
                # So, we do the same check here just in case.
                stable_final_state = False
            elif inst.base_class == Initialize:
                if i != 0 and len(qargs) < circ.num_qubits:
                    stable_final_state = False

            # if all the properties this loop try to detect have already been identified,
            # there's no need to check further
            if not stable_final_state and len(measured_qubits) > 0:
                break

        # Notice: here, 'measured_qubits' may not contain all measured qubits due to 'break' above

        # The circuit must have measurement gates
        if not measured_qubits:
            if require_measurement:
                raise RuntimeError(
                    f'Circuit "{circ.name}" has no measurement gates.'
                    f" Every circuit must have measurement gates when using {QddBackend.__name__}."
                )

        return CircuitProperty(
            stable_final_state=stable_final_state, clbit_final_values=clbit_final_values
        )

    def _validate_run_options(self, run_options):
        """Checks whether the given options are valid to run with (e.g., shots < max_shots)."""

        # Check if invalid options (i.e., causing errors) are specified
        if "shots" in run_options:
            shots = run_options["shots"]
            if shots is not None:
                max_shots = QddBackend._MAX_SHOTS
                if not (0 < shots <= max_shots):
                    raise RuntimeError(
                        f"Shots={shots} is specified, but #shots must be positive and <= {max_shots}"
                        f" when using {QddBackend.__name__}."
                    )

        # Warn if unsupported options are specified
        # Note: we cannot raise an error here because some Qiskit functions (e.g., execute(...)) adds some options to
        # the user-specified options (i.e., user-unspecified options sometimes comes to here).
        for run_opt in run_options:
            # if the runtime option is not contained in the default option list, output a warning.
            if not hasattr(self.options, run_opt):
                # some options can be ignored without warnings (e.g., an option value of no effect)
                can_ignore = (
                    run_opt in QddBackend._OPTIONS_IGNORED_WITHOUT_WARN
                    and QddBackend._OPTIONS_IGNORED_WITHOUT_WARN[run_opt](
                        run_options[run_opt]
                    )
                )
                if not can_ignore:
                    warn(
                        f"Option {run_opt}={run_options[run_opt]} is not used by {QddBackend.__name__}.",
                        UserWarning,
                        stacklevel=2,
                    )
