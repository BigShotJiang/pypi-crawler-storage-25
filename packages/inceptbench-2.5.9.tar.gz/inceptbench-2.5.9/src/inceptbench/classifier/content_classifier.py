"""
Content classifier for educational materials.

This module provides a classifier that uses LLM to determine the type of
educational content (question, quiz, reading passage, etc.).
"""

import logging
import time
from pathlib import Path
from typing import Optional

from pydantic import BaseModel

from inceptbench.llm import LLMFactory, LLMMessage
from inceptbench.models import ContentType
from inceptbench.core.input_models import RequestMetadata
from inceptbench.observability import observe

logger = logging.getLogger(__name__)

# Mapping from request_metadata.type values to ContentType enum
# Keys not present here will fall back to LLM classification
REQUEST_TYPE_TO_CONTENT_TYPE: dict[str, ContentType] = {
    "mcq": ContentType.QUESTION,
    "fill-in": ContentType.QUESTION,
    "msq": ContentType.QUESTION,
    "match": ContentType.QUESTION,
    "sequence": ContentType.QUESTION,
    # Essay/open-response question types
    "saq": ContentType.QUESTION,
    "leq": ContentType.QUESTION,
    "dbq": ContentType.QUESTION,
    # MCQ set → dedicated evaluator (uniform difficulty expected, unlike quizzes)
    "mcq_set": ContentType.MCQ_SET,

    "article": ContentType.ARTICLE,
    "nonfiction_reading": ContentType.NONFICTION_READING,
    "fiction_reading": ContentType.FICTION_READING,
}


class ContentClassificationResult(BaseModel):
    """Result from content classification."""
    content_type: ContentType
    confidence: str  # high, medium, low
    explanation: str


class ContentClassifier:
    """
    Classifies educational content into predefined types.
    
    Uses LLM with structured output to classify content as question, quiz,
    fiction reading, nonfiction reading, or other.
    """
    
    def __init__(self):
        """Initialize the content classifier."""
        self.llm = LLMFactory.create("classifier")
        self.base_system_prompt = self._load_prompt()
        
    def _load_prompt(self) -> str:
        """Load the classifier prompt from file."""
        prompt_path = Path(__file__).parent.parent / "prompts" / "classifier.txt"
        try:
            with open(prompt_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            logger.error(f"Error loading classifier prompt: {e}")
            raise RuntimeError(f"Could not load classifier prompt: {e}")
    
    @observe(name="classify_content")
    async def classify(
        self, 
        content: str,
        request_metadata: Optional[RequestMetadata] = None
    ) -> ContentType:
        """
        Classify the content type.
        
        Args:
            content: The educational content to classify
            request_metadata: Optional metadata about the content generation request
            
        Returns:
            ContentType enum value indicating the classified type
            
        Raises:
            RuntimeError: If classification fails
        """
        start_time = time.time()
        
        if request_metadata and request_metadata.type:
            # Normalize user-provided type so values like "Article" or " article "
            # reliably hit deterministic routing rather than LLM fallback.
            normalized_type = request_metadata.type.strip().lower()
            content_type = REQUEST_TYPE_TO_CONTENT_TYPE.get(normalized_type)
            if content_type is not None:
                logger.info(
                    f"User specified type '{request_metadata.type}' "
                    f"(normalized: '{normalized_type}'), "
                    f"mapped to {content_type.value}, skipping LLM classification"
                )
                return content_type
            else:
                logger.info(
                    f"User specified type '{request_metadata.type}' "
                    f"(normalized: '{normalized_type}') has no mapping, "
                    f"falling back to LLM classification"
                )
        
        logger.info("Classifying content type with LLM...")
        
        try:
            from baml_client import b as _baml
            baml_result = await _baml.ClassifyContent(
                system_prompt=self.base_system_prompt,
                content=content,
            )
            # Map BAML result to ContentClassificationResult with ContentType enum
            raw_type = getattr(baml_result, 'content_type', 'other').lower()
            try:
                ct = ContentType(raw_type)
            except ValueError:
                ct = ContentType.OTHER
            result = ContentClassificationResult(
                content_type=ct,
                confidence=getattr(baml_result, 'confidence', 'medium'),
                explanation=getattr(baml_result, 'explanation', ''),
            )
            
            logger.info(
                f"Classification completed in {time.time() - start_time:.2f}s: "
                f"{result.content_type.value} (confidence: {result.confidence})"
            )
            logger.debug(f"Classification explanation: {result.explanation}")
            return result.content_type
            
        except Exception as e:
            logger.error(f"Error classifying content: {str(e)}")
            from ..utils.failure_tracker import FailureTracker
            FailureTracker.record_exhausted(
                component="classifier",
                error_message=str(e),
                context={"defaulted_to": "OTHER"}
            )
            logger.info(
                f"Classification failed after {time.time() - start_time:.2f}s, "
                f"defaulting to OTHER"
            )
            return ContentType.OTHER
