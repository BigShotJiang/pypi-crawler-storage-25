"""
Main evaluation service for educational content.

This module provides the primary service that orchestrates the complete
evaluation flow: transcript fetching → classification → decomposition → evaluation.

For video/audio content:
1. Transcripts are for DECOMPOSITION only (understanding structure)
2. Evaluators receive media URLs/bytes, NOT transcripts (they watch/listen)
3. The extracted_text is tracked for debugging/review purposes
"""

import logging
import re
import time
from typing import Dict, Any, Optional

from .classifier.content_classifier import ContentClassifier
from .decomposer.content_decomposer import ContentDecomposer
from .orchestrator.evaluation_orchestrator import EvaluationOrchestrator
from .models.base import BaseEvaluationResult
from .models.video import VideoTranscriptSummary
from .models.audio import AudioTranscriptSummary
from .core.input_models import RequestMetadata
from .config.settings import settings
from .observability import observe, propagate_attributes
from .tools.video_utils import has_video_content
from .tools.audio_utils import has_audio_content
from .tools.transcript_fetcher import TranscriptFetcher
from .tools.audio_transcriber import AudioTranscriber
from .models.content_tree import ContentNode
from .utils.failure_tracker import FailureTracker

logger = logging.getLogger(__name__)

# Patterns to match transcript markers (for stripping before evaluation)
VIDEO_TRANSCRIPT_MARKER_PATTERN = re.compile(
    r'\[TRANSCRIPT START\].*?\[TRANSCRIPT END\]',
    re.DOTALL
)
AUDIO_TRANSCRIPT_MARKER_PATTERN = re.compile(
    r'\[AUDIO_TRANSCRIPT START\].*?\[AUDIO_TRANSCRIPT END\]',
    re.DOTALL
)

# Patterns to match SOURCE markers (for converting to media URLs)
VIDEO_SOURCE_PATTERN = re.compile(r'\[VIDEO_SOURCE:\s*([^\]]+)\]')
AUDIO_SOURCE_PATTERN = re.compile(r'\[AUDIO_SOURCE:\s*([^\]]+)\]')


class EvaluationService:
    """
    Main service for evaluating educational content.
    
    Provides comprehensive hierarchical evaluation:
    1. Fetches video transcripts / transcribes audio (for understanding structure)
    2. Classifies content type using LLM (uses transcript for media)
    3. Decomposes into nested structure (e.g., quiz → questions, reading passage → quiz → questions)
    4. Evaluates bottom-up with context propagation:
       - Children evaluated first (in parallel where possible)
       - Parents evaluated with knowledge of child results
       - All nodes receive root content as context
       - Evaluators receive media URLs and watch/listen themselves
    5. Returns nested evaluation results with child evaluations
    
    IMPORTANT: Transcripts are for decomposition only. Evaluators receive
    the original media URLs and must watch/listen themselves.
    
    This is the primary interface that external systems (CLI, API) should use.
    """
    
    def __init__(self):
        """Initialize the evaluation service with all components."""
        settings.validate_api_keys()
        
        self.transcript_fetcher = TranscriptFetcher()
        self.audio_transcriber = AudioTranscriber()
        self.classifier = ContentClassifier()
        self.decomposer = ContentDecomposer()
        self.orchestrator = EvaluationOrchestrator()
        
        self._last_transcript_summary: Optional[VideoTranscriptSummary] = None
        self._last_audio_transcript_summary: Optional[AudioTranscriptSummary] = None
        
        logger.info("Evaluation service initialized (with video + audio media support)")
    
    @observe(name="evaluation_pipeline")
    async def evaluate(
        self,
        content: str,
        curriculum: Optional[str] = None,
        generation_prompt: Optional[str] = None,
        request_metadata: Optional[RequestMetadata] = None,
        curriculum_version: Optional[str] = None
    ) -> BaseEvaluationResult:
        """
        Evaluate educational content with hierarchical decomposition.
        
        This method provides comprehensive evaluation of nested content:
        1. Fetches transcripts for any videos (for understanding structure)
        2. Classifies top-level content type
        3. Decomposes into hierarchical structure (e.g., quiz → questions)
        4. Evaluates bottom-up:
           - Children evaluated first (in parallel where possible)
           - Parents evaluated with knowledge of child results
           - All nodes receive root content as context
           - Evaluators watch actual videos (no transcript crib)
        5. Returns nested evaluation results
        
        Use this method for all evaluations. The method automatically handles:
        - Simple content (single question, no nesting)
        - Complex content (quizzes with questions, reading passages with quizzes)
        - Video content (transcripts for decomposition, videos for evaluation)
        
        Args:
            content: The educational content to evaluate (may contain video/image URLs)
            curriculum: Curriculum to use (defaults to settings.DEFAULT_CURRICULUM)
            generation_prompt: Optional prompt used to generate the content (deprecated, use request_metadata)
            request_metadata: Optional structured metadata about the content generation request
            curriculum_version: Optional curriculum version (e.g., "1.2"). If not specified,
                               the API defaults to the latest version.
            
        Returns:
            BaseEvaluationResult (Pydantic model) with evaluation results and nested subcontent_evaluations
            
        Raises:
            ValueError: If content is invalid or curriculum not supported
            RuntimeError: If evaluation fails
        """
        if not content or not content.strip():
            raise ValueError("Content cannot be empty")
        
        # Initialize failure tracker for this request context
        # This ensures each concurrent request has isolated failure logs
        FailureTracker.init_context()
        
        curriculum = curriculum or settings.DEFAULT_CURRICULUM
        
        # Handle metadata/prompt consolidation
        # If request_metadata is provided, it's the source of truth
        # If only generation_prompt is provided, wrap it in metadata for consistency
        if request_metadata is None and generation_prompt:
            request_metadata = RequestMetadata(instructions=generation_prompt)
        
        start_time = time.time()
        version_info = f", version: {curriculum_version}" if curriculum_version else " (latest)"
        logger.info(f"Starting evaluation with curriculum: {curriculum}{version_info}")
        
        # Build Langfuse trace attributes from request context
        trace_tags = [f"curriculum:{curriculum}"]
        trace_metadata = {"curriculum": curriculum}
        if curriculum_version:
            trace_tags.append(f"version:{curriculum_version}")
            trace_metadata["curriculum_version"] = curriculum_version
        if request_metadata:
            if getattr(request_metadata, "type", None):
                trace_tags.append(f"type:{request_metadata.type}")
            if getattr(request_metadata, "subject", None):
                trace_tags.append(f"subject:{request_metadata.subject}")
            if getattr(request_metadata, "grade", None):
                trace_tags.append(f"grade:{request_metadata.grade}")
        
        with propagate_attributes(
            tags=trace_tags,
            metadata=trace_metadata,
        ):
            try:
                # Reset transcript summaries for this evaluation
                self._last_transcript_summary = None
                self._last_audio_transcript_summary = None

                # Step 0: Fetch/generate transcripts for media (if any)
                # Transcripts are used for classification/decomposition only.
                # Evaluators receive original media URLs and watch/listen themselves.
                decomposition_content = content  # Default to original

                if has_video_content(content):
                    logger.info("Step 0a: Fetching video transcripts for decomposition...")
                    transcripts = await self.transcript_fetcher.fetch_all_transcripts(content)

                    self._last_transcript_summary = VideoTranscriptSummary()
                    for url, transcript in transcripts.items():
                        self._last_transcript_summary.add_transcript(
                            video_url=url,
                            extracted_text=transcript.extracted_text,
                            available=transcript.available,
                            language=transcript.language,
                            error_message=transcript.error_message
                        )

                    decomposition_content = self.transcript_fetcher.create_decomposition_content(
                        content, transcripts
                    )

                    available = sum(1 for t in transcripts.values() if t.available)
                    logger.info(
                        f"Video transcript fetch complete. "
                        f"{available}/{len(transcripts)} transcripts available."
                    )

                if has_audio_content(content):
                    logger.info("Step 0b: Transcribing audio for decomposition...")
                    audio_transcripts = await self.audio_transcriber.transcribe_all(content)

                    self._last_audio_transcript_summary = AudioTranscriptSummary()
                    for url, transcript in audio_transcripts.items():
                        self._last_audio_transcript_summary.add_transcript(
                            audio_url=url,
                            extracted_text=transcript.extracted_text,
                            available=transcript.available,
                            language=transcript.language,
                            error_message=transcript.error_message
                        )

                    decomposition_content = self.audio_transcriber.create_decomposition_content(
                        decomposition_content, audio_transcripts
                    )

                    available = sum(1 for t in audio_transcripts.values() if t.available)
                    logger.info(
                        f"Audio transcription complete. "
                        f"{available}/{len(audio_transcripts)} transcripts available."
                    )

                # Step 1: Classify top-level content (using transcript for videos)
                # Classifier fast-path handles known types (mcq, saq, leq, dbq, mcq_set, etc.)
                logger.info("Step 1: Classifying content...")
                content_type = await self.classifier.classify(decomposition_content, request_metadata)
                logger.info(f"Content classified as: {content_type.value}")
                
                # Step 2: Decompose into hierarchical structure (using transcript for videos)
                logger.info("Step 2: Decomposing content into hierarchical structure...")
                content_tree = await self.decomposer.decompose(
                    decomposition_content, content_type, request_metadata
                )

                # Prepare tree for evaluation:
                # - Replace root_content with original (has video URLs, no transcript text)
                # - Strip transcript markers from all nodes
                # This ensures evaluators watch videos, not read transcripts
                content_tree.root_content = content
                self._prepare_tree_for_evaluation(content_tree.root_node)

                logger.info(
                    f"Decomposition complete. "
                    f"Depth: {content_tree.get_depth()}, "
                    f"Total nodes: {content_tree.count_nodes()}"
                )
                
                # Step 3: Evaluate hierarchically (bottom-up)
                # Evaluators receive video URLs and watch videos themselves
                logger.info("Step 3: Evaluating hierarchically (bottom-up)...")
                result = await self.orchestrator.evaluate_hierarchical(
                    content_tree, 
                    curriculum, 
                    request_metadata=request_metadata,
                    curriculum_version=curriculum_version
                )
                
                logger.info(
                    f"Evaluation complete. "
                    f"Type: {content_type.value}, "
                    f"Overall: {result.overall.score:.2f}, "
                    f"Subcontent evaluations: {len(result.subcontent_evaluations) if result.subcontent_evaluations else 0}"
                )
                logger.info(f"Evaluation completed in {time.time() - start_time:.2f} seconds")
                return result
                
            except Exception as e:
                logger.error(f"Evaluation failed after {time.time() - start_time:.2f} seconds: {e}")
                raise RuntimeError(f"Evaluation failed: {e}")
    
    async def evaluate_json(
        self,
        content: str,
        curriculum: Optional[str] = None,
        generation_prompt: Optional[str] = None,
        request_metadata: Optional[RequestMetadata] = None,
        curriculum_version: Optional[str] = None
    ) -> str:
        """
        Evaluate content and return JSON string.
        
        Convenience method that wraps evaluate() and returns JSON format.
        Useful for REST APIs, CLIs, and other scenarios where JSON serialization is needed.
        
        Args:
            content: The educational content to evaluate
            curriculum: Curriculum to use (defaults to settings.DEFAULT_CURRICULUM)
            generation_prompt: Optional prompt used to generate the content
            request_metadata: Optional structured metadata about the content generation request
            curriculum_version: Optional curriculum version (e.g., "1.2"). If not specified,
                               the API defaults to the latest version.
            
        Returns:
            JSON string with evaluation results (clean, no internal debug info)
            
        Raises:
            ValueError: If content is invalid or curriculum not supported
            RuntimeError: If evaluation fails
        """
        result = await self.evaluate(content, curriculum, generation_prompt, request_metadata, curriculum_version)
        return result.to_json()
    
    def get_failure_summary(self) -> Optional[Dict[str, Any]]:
        """
        Get a summary of soft failures that occurred during the last evaluation.
        
        Soft failures are non-fatal errors like API timeouts after all retries.
        These are useful for debugging but should not be part of the main evaluation output.
        
        Returns:
            None if no failures, otherwise a dict with failure count and details
        """
        return FailureTracker.get_summary()
    
    def has_failures(self) -> bool:
        """Check if any soft failures occurred during the last evaluation."""
        return FailureTracker.has_failures()

    def get_transcript_summary(self) -> Optional[VideoTranscriptSummary]:
        """
        Get the video transcript summary from the last evaluation.

        Contains the extracted_text for each video, useful for
        debugging and reviewing what text was used for decomposition.

        Returns:
            VideoTranscriptSummary if videos were processed, None otherwise
        """
        return self._last_transcript_summary

    def get_audio_transcript_summary(self) -> Optional[AudioTranscriptSummary]:
        """
        Get the audio transcript summary from the last evaluation.

        Contains the extracted_text for each audio file, useful for
        debugging and reviewing what text was used for decomposition.

        Returns:
            AudioTranscriptSummary if audio was processed, None otherwise
        """
        return self._last_audio_transcript_summary

    def _prepare_tree_for_evaluation(self, node: ContentNode) -> None:
        """
        Prepare a content tree node for evaluation.

        Strips transcript markers from extracted_content and converts
        SOURCE markers to actual media URLs. Evaluators see media URLs
        but NOT transcript text — they must watch/listen themselves.

        Args:
            node: The content node to process (modifies in place)
        """
        # Strip video and audio transcript text
        node.extracted_content = VIDEO_TRANSCRIPT_MARKER_PATTERN.sub('', node.extracted_content)
        node.extracted_content = AUDIO_TRANSCRIPT_MARKER_PATTERN.sub('', node.extracted_content)

        def replace_video_source(match: re.Match) -> str:
            return match.group(1).strip()

        def replace_audio_source(match: re.Match) -> str:
            return match.group(1).strip()

        node.extracted_content = VIDEO_SOURCE_PATTERN.sub(
            replace_video_source,
            node.extracted_content
        )
        node.extracted_content = AUDIO_SOURCE_PATTERN.sub(
            replace_audio_source,
            node.extracted_content
        )

        node.extracted_content = re.sub(r'\n{3,}', '\n\n', node.extracted_content).strip()

        for child in node.children:
            self._prepare_tree_for_evaluation(child)
