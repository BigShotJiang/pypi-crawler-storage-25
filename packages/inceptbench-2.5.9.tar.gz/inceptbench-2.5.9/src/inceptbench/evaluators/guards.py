"""
Shared deterministic guards for evaluators.

Pure functions that inspect evaluation results and content, overriding
non-deterministic LLM scores when high-confidence programmatic checks
disagree with the model.

Each guard takes a result object and returns a (possibly mutated) result.
All overrides are logged with before/after scores.
"""

import logging
import re
from typing import Optional

from inceptbench.config.tier_scoring import calculate_weighted_score
from inceptbench.models.base import BaseEvaluationResult, MetricResult
from inceptbench.tools.image_utils import get_all_image_urls_for_analysis
from inceptbench.tools.stimulus_reference_detector import has_markdown_table_stimulus
from inceptbench.tools.unified_image_analyzer import analyze_images
from inceptbench.tools.visual_spec import extract_visual_spec
from inceptbench.tools.visual_verifier import verify_visual_constraints

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Stimulus quality guard
# ---------------------------------------------------------------------------

def guard_stimulus_quality(
    result: BaseEvaluationResult,
    content: str,
    full_context: Optional[str] = None,
) -> BaseEvaluationResult:
    """
    If the LLM scored stimulus_quality < 0.5 but the content contains inline
    markdown tables, images (![...](...)), or SVG tags, override to 1.0.

    Args:
        result: The evaluation result to inspect/mutate.
        content: The article/question content string.
        full_context: Optional broader context (ignored for this guard).

    Returns:
        The result object (mutated in place if override applied).
    """
    stimulus = getattr(result, "stimulus_quality", None)
    if stimulus is None or stimulus.score >= 0.5:
        return result

    has_table = has_markdown_table_stimulus(content)
    has_inline_image = bool(re.search(r"!\[[^\]]*\]\([^)]+\)", content))
    has_svg = bool(re.search(r"<svg[\s>]", content, re.IGNORECASE))

    if has_table or has_inline_image or has_svg:
        logger.info(
            "Deterministic stimulus_quality override: LLM scored %.2f "
            "but programmatic check found inline stimulus "
            "(table=%s, image=%s, svg=%s) — overriding to 1.0",
            stimulus.score, has_table, has_inline_image, has_svg,
        )
        stimulus.score = 1.0
        stimulus.reasoning = (
            "[DeterministicGuard/stimulus_quality] The LLM reported missing stimulus "
            "but programmatic inspection found valid inline stimulus "
            "(table/image/SVG) in the content."
        )
        stimulus.suggested_improvements = None
    return result


# ---------------------------------------------------------------------------
# Math factual-accuracy guard
# ---------------------------------------------------------------------------

def guard_math_factual_accuracy(
    result: BaseEvaluationResult,
    content: str,
    math_context: str,
    request_metadata: Optional[object] = None,
) -> BaseEvaluationResult:
    """
    If the LLM scored factual_accuracy low (< 0.3) and its reasoning explicitly
    cites mathematical errors, but precomputed SymPy verification says CORRECT,
    override factual_accuracy to 1.0.

    Non-mathematical factual errors (history, biology, etc.) are NEVER silenced
    by a passing arithmetic check.

    Args:
        result: The evaluation result to inspect/mutate.
        content: The content string (unused but kept for API symmetry).
        math_context: The deterministic math-verification context string from
            ``extract_and_verify_math``. Must contain
            ``"**Verification result: CORRECT**"`` to trigger an override.
        request_metadata: Optional request metadata (unused).

    Returns:
        The result object (mutated in place if override applied).
    """
    del content, request_metadata  # API symmetry

    factual = getattr(result, "factual_accuracy", None)
    if factual is None or factual.score >= 0.3:
        return result

    factual_audit = getattr(result, "factual_audit", None)
    audit_score = getattr(factual_audit, "score", None)
    audit_skipped = bool(getattr(factual_audit, "skipped", False))
    if factual_audit is not None and not audit_skipped and audit_score is not None and audit_score < 0.3:
        logger.info(
            "Skipping factual_accuracy math override: factual audit already "
            "downgraded the metric to %.2f.",
            audit_score,
        )
        return result

    # Collect LLM rationale for the low score.
    llm_rationale = " ".join(
        filter(None, [
            getattr(factual, "reasoning", ""),
            getattr(factual, "suggested_improvements", ""),
            getattr(factual, "internal_reasoning", ""),
        ])
    ).lower()

    # Only proceed if the LLM itself flagged math-related concerns.
    math_keywords = (
        "math", "mathematical", "arithmetic", "calculation", "equation",
        "formula", "numerical", "compute", "solved incorrectly",
        "math error", "incorrect calculation",
    )
    llm_concern_is_math = any(
        re.search(rf"\b{re.escape(kw)}\b", llm_rationale)
        for kw in math_keywords
    )

    if not llm_concern_is_math:
        logger.info(
            "Skipping factual_accuracy override: LLM scored %.2f but "
            "rationale does not mention mathematical errors "
            "(rationale snippet: %.80s). Not overriding.",
            factual.score, llm_rationale[:80],
        )
        return result

    if math_context and "**Verification result: CORRECT**" in math_context:
        logger.info(
            "Deterministic factual_accuracy override: LLM scored %.2f "
            "and cited mathematical errors, but SymPy verification says "
            "CORRECT — overriding to 1.0",
            factual.score,
        )
        factual.score = 1.0
        factual.reasoning = (
            "[DeterministicGuard/math_factual_accuracy] The LLM reported mathematical "
            "errors, but SymPy-based verification confirmed all "
            "mathematical content is CORRECT. The factual_accuracy score "
            "is overridden to 1.0 for the mathematical claims only."
        )
        factual.suggested_improvements = None

    return result


# ---------------------------------------------------------------------------
# Visual option-key consistency guard
# ---------------------------------------------------------------------------

async def guard_visual_option_key_consistency(
    result: BaseEvaluationResult,
    content: str,
    full_context: Optional[str] = None,
    request_metadata: Optional[object] = None,
) -> BaseEvaluationResult:
    """
    Minimal deterministic safety net for factual_accuracy.

    When images show 2-option questions and visual label extraction
    confirms high-confidence option-key consistency, un-fail
    factual_accuracy (0.0 → 1.0).

    Contradictions remain advisory because visual label extraction is
    not allowed to overrule the evaluator's direct reasoning after the
    fact.

    Args:
        result: The evaluation result to inspect/mutate.
        content: The question content string.
        full_context: Optional broader context (also searched for images).
        request_metadata: Optional request metadata for spec extraction.

    Returns:
        The result object (mutated in place if override applied).
    """
    candidates = [content]
    if full_context and full_context != content:
        candidates.append(full_context)

    selected_spec = None
    selected_urls: list[str] = []
    for txt in candidates:
        spec = extract_visual_spec(txt, request_metadata)
        urls = get_all_image_urls_for_analysis(txt)
        if urls and len(spec.answer_option_labels) == 2:
            selected_spec = spec
            selected_urls = urls
            break
    if selected_spec is None or not selected_urls:
        return result

    try:
        analysis = await analyze_images(selected_urls)
    except Exception:
        return result
    if not analysis.success or not analysis.image_analyses:
        return result

    verification = verify_visual_constraints(analysis.image_analyses[0], selected_spec)
    key_pass = any(
        c.check_name == "option_key_consistency"
        and c.status == "pass"
        and c.confidence == "high"
        for c in verification.checks
    )
    key_fail = any(
        c.check_name == "option_key_consistency"
        and c.status == "fail"
        and c.confidence == "high"
        for c in verification.checks
    )

    if not (key_pass and not key_fail and result.factual_accuracy.score == 0.0):
        return result

    # Any deterministic guard that has already downgraded factual_accuracy
    # (e.g. ``guard_ela_double_determiner``, ELA detector enforcement, or any
    # future ``[DeterministicGuard/*]`` marker) must not be silently
    # cancelled by the image-consistency check.
    prior_reasoning = result.factual_accuracy.reasoning or ""
    if (
        "[CONCLUSION_DOMAIN_LEAK enforced]" in prior_reasoning
        or "[DeterministicGuard/" in prior_reasoning
    ):
        return result

    new_factual = MetricResult(
        score=1.0,
        reasoning=(
            "[DeterministicConsistencyGuard] High-confidence deterministic "
            "option-key consistency pass supports factual accuracy. "
            + (result.factual_accuracy.reasoning or "")
        ),
        suggested_improvements=None,
    )

    patched = result.model_copy(update={"factual_accuracy": new_factual})
    scores = patched._get_metric_scores()
    weighted = calculate_weighted_score(scores) or 0.0
    new_overall = patched.overall.model_copy(
        update={
            "score": round(float(weighted), 4),
            "reasoning": (patched.overall.reasoning or "")
            + " (Overall recomputed after deterministic factual safety net.)",
        }
    )
    return patched.model_copy(update={"overall": new_overall})


# ---------------------------------------------------------------------------
# ELA double-determiner guard
# ---------------------------------------------------------------------------

def guard_ela_double_determiner(
    result: BaseEvaluationResult,
    content: str,
    request_metadata: Optional[object] = None,
) -> BaseEvaluationResult:
    """
    Detect ungrammatical double-determiner patterns in ELA fill-in-the-blank
    questions (e.g. ``a(n) an adverb``) and override factual_accuracy.

    Trigger: the question stem contains ``a(n)`` immediately before a blank,
    and an accepted answer begins with ``a `` or ``an `` without a matching
    bare-answer variant in the same answer group.

    When triggered, factual_accuracy is forced to 0.0 and the overall score
    is recomputed so the item lands in the INFERIOR bucket.
    """
    import json

    # Only act if the evaluator was lenient (factual_accuracy high or missing).
    factual = getattr(result, "factual_accuracy", None)
    if factual is not None and factual.score == 0.0:
        return result  # evaluator already caught it

    # Parse JSON content to extract question stem and answers.
    try:
        data = json.loads(content) if content.strip().startswith("{") else {}
    except Exception:
        return result

    question = str(data.get("question") or "").strip()
    if not question:
        return result

    # Detect "a(n) _____" or "a(n) ____" pattern near a blank.
    has_double_determiner_prompt = bool(
        re.search(r"a\(n\)\s*[_–—-]{2,}", question, re.IGNORECASE)
    )
    if not has_double_determiner_prompt:
        return result

    # Collect accepted answers from either top-level or nested structure.
    accepted_groups: list[list[str]] = []
    raw_answer = data.get("answer")
    if isinstance(raw_answer, list):
        for ans in raw_answer:
            if isinstance(ans, dict):
                group = [str(a) for a in (ans.get("accepted_answers") or [])]
                if group:
                    accepted_groups.append(group)
            elif isinstance(ans, str):
                accepted_groups.append([ans])
    elif isinstance(raw_answer, str):
        accepted_groups.append([raw_answer])

    # Check if an answer group has an article-bearing accepted answer without
    # the corresponding bare answer. Accepting both "adverb" and "an adverb"
    # is a harmless grading variant; accepting only "an adverb" makes the
    # rendered blank read as "a(n) an adverb".
    def _strip_leading_article(answer: str) -> str:
        return re.sub(r"^(?:a|an)\s+", "", answer.strip().lower())

    bad_answer = False
    article_answers_for_log: list[str] = []
    for group in accepted_groups:
        normalized = {a.strip().lower() for a in group if str(a).strip()}
        article_answers = [
            a for a in normalized
            if a.startswith("a ") or a.startswith("an ")
        ]
        missing_bare_answers = [
            a for a in article_answers
            if _strip_leading_article(a) not in normalized
        ]
        if missing_bare_answers:
            bad_answer = True
            article_answers_for_log.extend(missing_bare_answers)
            break

    if not bad_answer:
        return result

    # Override factual_accuracy and recompute overall.
    new_factual = MetricResult(
        score=0.0,
        reasoning=(
            "[DeterministicGuard/ela_double_determiner] Programmatic inspection "
            "found a double-determiner error: the blank is preceded by 'a(n)' "
            "and the accepted answer begins with 'a' or 'an', producing "
            "ungrammatical constructions like 'a(n) an adverb'."
        ),
        suggested_improvements=(
            "Remove the article from the accepted answer or rephrase the blank "
            "to avoid the double determiner (e.g. change 'a(n) _____' to '_____')."
        ),
    )

    patched = result.model_copy(update={"factual_accuracy": new_factual})
    scores = patched._get_metric_scores()
    weighted = calculate_weighted_score(scores) or 0.0
    new_overall = patched.overall.model_copy(
        update={
            "score": round(float(weighted), 4),
            "reasoning": (
                (patched.overall.reasoning or "")
                + " (Overall recomputed after deterministic double-determiner guard.)"
            ),
        }
    )
    logger.info(
        "Deterministic ELA double-determiner override: accepted answers=%s — "
        "factual_accuracy 0.0, overall %.4f",
        article_answers_for_log,
        new_overall.score,
    )
    return patched.model_copy(update={"overall": new_overall})


# ---------------------------------------------------------------------------
# Math image-reveals-answer guard
# ---------------------------------------------------------------------------

def guard_math_image_reveals_answer(
    result: BaseEvaluationResult,
    content: str,
    request_metadata: Optional[object] = None,
) -> BaseEvaluationResult:
    """
    Detect math fill-in questions where the image (e.g. protractor, number line)
    directly reveals the numeric answer, making the intended calculation
    unnecessary. Overrides educational_accuracy to 0.0 when the answer
    explanation fails to reference the image.

    Trigger (all must hold — guards against decorative-image false positives):
    - Math subject (grade K-8)
    - Fill-in type
    - SVG or image URL present
    - Accepted answer is a pure number
    - The question text itself signals an image-reading task
      (e.g. "shown below", "in the diagram", "measure the angle"). Plain
      arithmetic prompts that happen to ship with a decorative illustration
      do NOT trip the guard.
    - No answer explanation references the image (no visual keywords)
    """
    import json

    # Only act if evaluator was lenient.
    educational = getattr(result, "educational_accuracy", None)
    if educational is not None and educational.score == 0.0:
        return result  # evaluator already caught it

    # Parse content.
    try:
        data = json.loads(content) if content.strip().startswith("{") else {}
    except Exception:
        return result

    # Must be math and fill-in.
    meta = data.get("metadata") or {}
    if isinstance(request_metadata, dict):
        meta = request_metadata
    # Prefer the Pydantic RequestMetadata object (production case) over the
    # embedded JSON "metadata" key, which may be absent.
    if request_metadata is not None and not isinstance(request_metadata, dict):
        subject = str(getattr(request_metadata, "subject", None) or meta.get("subject") or "").lower()
        q_type = str(
            getattr(request_metadata, "type", None)
            or getattr(request_metadata, "question_type", None)
            or meta.get("type")
            or meta.get("question_type")
            or ""
        ).lower()
    else:
        subject = str(meta.get("subject") or "").lower()
        q_type = str(meta.get("type") or meta.get("question_type") or "").lower()
    if subject != "math" or q_type not in ("fill-in", "fill_in", "fillin"):
        return result

    # Must have image.
    has_image = bool(
        data.get("image_url")
        or data.get("image_urls")
        or re.search(r"<svg[\s>]", str(data.get("question") or ""), re.IGNORECASE)
    )
    if not has_image:
        return result

    # The question text must itself signal an image-reading task. Decorative
    # illustrations (e.g. an SVG star next to "2+3 = ___") never include
    # language like "shown below" or "measure the angle in the diagram", so
    # this check is what separates real reveals-answer questions from
    # plain-arithmetic prompts that happen to ship with a graphic.
    question_text = str(data.get("question") or "").lower()
    image_task_phrases = (
        "shown", "depicted", "in the diagram", "in the figure", "in the image",
        "in the picture", "in the chart", "in the graph",
        "from the diagram", "from the figure", "from the image",
        "use the diagram", "use the figure", "use the image",
        "the angle below", "the angle above", "the angle shown",
        "measure the angle", "read the number line", "on the number line",
        "the protractor", "look at the diagram", "look at the figure",
    )
    if not any(p in question_text for p in image_task_phrases):
        return result  # decorative-image case — never flag

    # Must have numeric accepted answer.
    accepted: list[str] = []
    raw_answer = data.get("answer")
    if isinstance(raw_answer, list):
        for ans in raw_answer:
            if isinstance(ans, dict):
                accepted.extend(ans.get("accepted_answers") or [])
            elif isinstance(ans, str):
                accepted.append(ans)
    elif isinstance(raw_answer, str):
        accepted.append(raw_answer)

    if not all(re.match(r"^\d+(\.\d+)?$", a.strip()) for a in accepted if a.strip()):
        return result  # not purely numeric

    # Check if answer explanations reference the image.
    explanations: list[str] = []
    if isinstance(raw_answer, list):
        for ans in raw_answer:
            if isinstance(ans, dict):
                exp = ans.get("answer_explanation") or ""
                if exp:
                    explanations.append(str(exp))
    top_exp = data.get("answer_explanation") or data.get("explanation") or ""
    if top_exp:
        explanations.append(str(top_exp))

    combined_exp = " ".join(explanations).lower()
    visual_keywords = (
        "image", "diagram", "figure", "chart", "graph", "picture",
        "illustration", "shown", "depicted", "visual", "protractor",
        "angle", "line", "shape", "polygon", "circle", "radius",
    )
    has_visual_ref = any(kw in combined_exp for kw in visual_keywords)
    if has_visual_ref:
        return result  # explanation references image

    # Override educational_accuracy.
    new_educational = MetricResult(
        score=0.0,
        reasoning=(
            "[DeterministicGuard/math_image_reveals_answer] The question "
            "includes an image that directly displays the answer (" + ", ".join(accepted) +
            "), yet the answer explanation does not reference the image or "
            "describe how to derive the answer from it. Students can simply "
            "read the value off the image instead of performing the intended "
            "mathematical reasoning, making the question educationally ineffective."
        ),
        suggested_improvements=(
            "Either remove the image so students must calculate the answer, or "
            "rewrite the explanation to explicitly describe how the image is used "
            "in the solution process."
        ),
    )

    patched = result.model_copy(update={"educational_accuracy": new_educational})
    scores = patched._get_metric_scores()
    weighted = calculate_weighted_score(scores) or 0.0
    new_overall = patched.overall.model_copy(
        update={
            "score": round(float(weighted), 4),
            "reasoning": (
                (patched.overall.reasoning or "")
                + " (Overall recomputed after deterministic image-reveals-answer guard.)"
            ),
        }
    )
    logger.info(
        "Deterministic math image-reveals-answer override: answer=%s — "
        "educational_accuracy 0.0, overall %.4f",
        accepted,
        new_overall.score,
    )
    return patched.model_copy(update={"overall": new_overall})
