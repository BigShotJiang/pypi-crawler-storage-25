"""
Base evaluator class for educational content evaluation.

This module defines the abstract base class that all content-type-specific
evaluators must extend.
"""

import asyncio
import json
import logging
import re
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List, Optional

from inceptbench.config.constants import AP_CURRICULUMS, AP_CURRICULUM_TO_COURSE
from inceptbench.curricula.ap.repository import JSONFileCurriculumRepository
from inceptbench.llm import LLMFactory, LLMImage, LLMMessage
from inceptbench.llm.config import LLMConfig, get_llm_config
from inceptbench.models import BaseEvaluationResult, with_required_interest_relevance
from inceptbench.core.input_models import RequestMetadata
from inceptbench.tools.curriculum_client import CurriculumAPIError
from inceptbench.tools.curriculum_search import get_curriculum_context
from inceptbench.tools.image_utils import (
    download_and_encode_image,
    ImagePreparationError,
    extract_image_urls,
    get_all_image_urls_for_analysis,
    prepare_svgs_for_analysis,
    extract_svg_content,
    remove_svg_from_content,
)
from inceptbench.tools.video_utils import extract_video_urls, prepare_video_for_gemini, VideoInputMethod
from inceptbench.tools.audio_utils import extract_audio_urls, prepare_audio_for_gemini
from inceptbench.observability import observe
from inceptbench.tools.unified_image_analyzer import (
    analyze_images,
    format_evidence_for_prompt,
)
from inceptbench.tools.visual_spec import extract_visual_spec
from inceptbench.tools.visual_verifier import (
    VerificationResult,
    verify_visual_constraints,
)
from inceptbench.utils.failure_tracker import AttemptError, FailureTracker

logger = logging.getLogger(__name__)

# Module-level singleton: avoids re-loading the 400k-line JSON on every evaluation call.
# JSONFileCurriculumRepository is read-only after init, so sharing is safe.
_ap_curriculum_repo: Optional[JSONFileCurriculumRepository] = None


def _get_ap_curriculum_repo() -> JSONFileCurriculumRepository:
    """Return the cached AP curriculum repository singleton."""
    global _ap_curriculum_repo
    if _ap_curriculum_repo is None:
        _ap_curriculum_repo = JSONFileCurriculumRepository()
    return _ap_curriculum_repo


# ---------------------------------------------------------------------------
# interest_relevance — deterministic literal-mention check
# ---------------------------------------------------------------------------

# Stopwords skipped by the per-token interest matcher.  They appear inside
# multi-word interests ("the Colosseum in Rome", "Diary of a Wimpy Kid")
# but should never trigger a match on their own.
_INTEREST_STOPWORDS = frozenset({
    "the", "a", "an", "in", "of", "and", "or", "to", "for", "with",
    "from", "on", "at", "by", "is", "as", "be", "into", "out", "over",
    "off", "up", "down",
})


def _normalize_interests_to_list(student_interests) -> List[str]:
    """Best-effort coerce to list[str] for matching.

    Accepts the canonical list-of-strings shape, plus dict (values used) and
    string (split on common separators) for backwards compatibility.
    """
    if isinstance(student_interests, list):
        return [str(x).strip() for x in student_interests if str(x).strip()]
    if isinstance(student_interests, dict):
        out: List[str] = []
        for v in student_interests.values():
            if isinstance(v, (list, dict)):
                out.extend(_normalize_interests_to_list(v))
            elif v is not None and str(v).strip():
                out.append(str(v).strip())
        return out
    if isinstance(student_interests, str):
        parts = re.split(r"[,;\n]+", student_interests)
        return [p.strip() for p in parts if p.strip()]
    return []


def _interest_token_candidates(token: str) -> set:
    """Token + simple inflectional stems used for the literal-mention check.

    The ``-es`` rule only fires when the resulting stem ends in one of the
    phonetic contexts where English actually adds ``-es`` to form the plural
    (``s``, ``x``, ``z``, ``ch``, ``sh``).  Otherwise the regular ``-s`` rule
    is the right answer — e.g. ``games`` → ``game``, NOT ``gam``.
    """
    candidates = {token}
    if token.endswith("ies") and len(token) > 4:
        candidates.add(token[:-3] + "y")
    if token.endswith("es") and len(token) > 3:
        stem = token[:-2]
        if stem.endswith(("s", "x", "z", "ch", "sh")):
            candidates.add(stem)
    if token.endswith("s") and len(token) > 2:
        candidates.add(token[:-1])
    if token.endswith("ing") and len(token) > 4:
        candidates.add(token[:-3])
    return candidates


def _extract_student_facing_text_for_interests(content: str) -> str:
    """Concatenate student-facing fields from JSON-encoded content.

    Pulls only what the student actually sees (question stem, options) — never
    metadata such as ``request.skills.lesson_title`` or ``answer_explanation``.
    Falls back to the raw string when the content is not JSON.
    """
    try:
        parsed = json.loads(content)
    except (json.JSONDecodeError, TypeError):
        return content if isinstance(content, str) else ""

    STUDENT_FACING_KEYS = {
        "question", "stem", "prompt", "text", "passage", "scenario",
        "title", "instruction", "instructions", "body",
        "options", "answer_options", "choices",
    }
    METADATA_KEYS = {
        "answer", "answer_information", "answer_key", "answer_explanation",
        "explanation", "solution", "teacher_notes", "rubric", "feedback",
        "insight", "hint", "help", "rationale", "internal_reasoning",
        "reasoning", "metadata", "additional_details",
        "skills", "lesson_title", "substandard_id",
        "substandard_description", "subject", "curriculum",
    }

    chunks: List[str] = []

    def walk(obj, parent_key: Optional[str] = None) -> None:
        if isinstance(obj, dict):
            for k, v in obj.items():
                kl = str(k).strip().lower()
                if kl in METADATA_KEYS:
                    continue
                if kl in STUDENT_FACING_KEYS:
                    walk(v, kl)
                    continue
                if isinstance(v, (dict, list)):
                    walk(v, kl)
        elif isinstance(obj, list):
            for item in obj:
                walk(item, parent_key)
        elif isinstance(obj, str) and parent_key in STUDENT_FACING_KEYS:
            if obj.strip():
                chunks.append(obj)

    walk(parsed)
    return "\n".join(chunks)


def _resolve_prompt_placeholders(
    system_prompt: str, request_metadata: Optional[RequestMetadata]
) -> str:
    """Substitute prompt placeholders that the LLM is not meant to see.

    The question prompts contain ``{request.subject}`` (and the
    backtick-only ``request.subject``) placeholders inside the
    subject-knowledge counterfactual probe instructions.  ``_load_prompt``
    is a plain ``f.read()`` — there is no template engine — so without
    explicit substitution the LLM literally sees the placeholder string,
    which makes the probe instructions read as broken templates.

    Falls back to ``"subject-area"`` when the request has no subject so
    the surrounding prose still reads naturally.
    """
    raw_subject = (
        getattr(request_metadata, "subject", None) if request_metadata else None
    )
    subject = (str(raw_subject).strip().lower() if raw_subject else "") or "subject-area"
    return (
        system_prompt
        .replace("{request.subject}", subject)
        .replace("`request.subject`", f"`{subject}`")
    )


def _match_interests_in_content(content: str, interests: List[str]) -> List[str]:
    """Return the subset of ``interests`` literally referenced in ``content``.

    "Literally referenced" means: the full interest phrase appears, OR at
    least one non-stopword token from the interest appears (with simple
    s/es/ies/ing stemming), case-insensitively, with a word-boundary anchor
    so prefixes don't false-match (e.g., "art" doesn't match "started").
    """
    if not content or not interests:
        return []
    text = _extract_student_facing_text_for_interests(content).lower()
    if not text:
        return []
    matched: List[str] = []
    for interest in interests:
        norm = interest.lower().strip()
        if not norm:
            continue
        # 1. Whole phrase match — anchored to word boundaries so a short
        # interest like "art" doesn't match inside "started".
        if re.search(rf"\b{re.escape(norm)}\b", text):
            matched.append(interest)
            continue
        # 2. Per-token check with simple stemming.
        for token in re.findall(r"[a-z]+", norm):
            if token in _INTEREST_STOPWORDS:
                continue
            if any(
                re.search(rf"\b{re.escape(c)}\b", text)
                for c in _interest_token_candidates(token)
            ):
                matched.append(interest)
                break
    return matched


class BaseEvaluator(ABC):
    """
    Abstract base class for all content evaluators.
    
    Provides common functionality for:
    - Loading prompts from files
    - Getting curriculum context
    - Getting object count context for images
    - Structuring evaluation calls
    
    Subclasses must implement:
    - _load_prompt(): Load evaluator-specific prompt
    - evaluate(): Perform the evaluation
    - _get_result_model(): Return the Pydantic model for results
    """
    
    def __init__(self, model: Optional[str] = None):
        """
        Initialize the evaluator.

        Args:
            model: Optional model override. If provided, overrides the model
                   from the task registry while keeping the same provider.
        """
        if model:
            base_config = get_llm_config("evaluator")
            config_override = LLMConfig(
                provider=base_config.provider,
                model=model,
                timeout=base_config.timeout,
            )
            self.llm = LLMFactory.create("evaluator", config_override=config_override)
        else:
            self.llm = LLMFactory.create("evaluator")
        self.prompt_template = self._load_prompt()
        
    @abstractmethod
    def _load_prompt(self) -> str:
        """
        Load the evaluator-specific prompt from file.
        
        Returns:
            Prompt template string
            
        Raises:
            RuntimeError: If prompt file cannot be loaded
        """
        pass
    
    @observe(name="evaluate_content")
    async def evaluate(
        self,
        content: str,
        curriculum: str = "common_core",
        full_context: Optional[str] = None,
        subcontent_results: Optional[List[BaseEvaluationResult]] = None,
        request_metadata: Optional[RequestMetadata] = None,
        analyzed_image_urls: Optional[set] = None,
        curriculum_version: Optional[str] = None,
        prompt_override: Optional[str] = None
    ) -> BaseEvaluationResult:
        """
        Evaluate the content and return structured results.
        
        This is the default implementation that handles the common evaluation flow:
        1. Get programmatic analysis context (if any)
        2. Get curriculum context
        3. Get object count context (skipping already-analyzed images)
        4. Get generation_prompt context from request_metadata (for AI-generated content)
        5. Add full_context if provided (for hierarchical content)
        6. Add subcontent_results if provided (for parent content)
        7. Build system prompt with all contexts
        8. Call LLM evaluator
        9. Return results
        
        Subclasses can override this method for custom behavior, or just override
        _get_programmatic_context() to add custom analyses.
        
        Args:
            content: The educational content to evaluate (specific node content)
            curriculum: Curriculum to use for evaluation (default: "common_core")
            full_context: Complete root content for contextual evaluation (optional)
            subcontent_results: Results from evaluating nested content (optional)
            request_metadata: Optional structured metadata about the content generation request
            analyzed_image_urls: Set of image URLs already analyzed in subcontent (optional)
            curriculum_version: Optional curriculum version (e.g., "1.2"). If not specified,
                               the API defaults to the latest version.

        Returns:
            Evaluation results specific to the content type
            
        Raises:
            RuntimeError: If evaluation fails
        """
        start_time = time.time()
        content_type_name = self._get_result_model().__name__.replace("EvaluationResult", "").lower()
        logger.info(f"Evaluating {content_type_name}...")
        
        # Track which images to skip (already analyzed in subcontent)
        skip_images = analyzed_image_urls or set()
        if skip_images:
            logger.info(f"Skipping {len(skip_images)} image(s) already analyzed in subcontent")
        
        try:
            # Gather context in parallel (no dependencies between these calls)
            (
                programmatic_context,
                curriculum_context,
                image_analysis_context
            ) = await asyncio.gather(
                self._get_programmatic_context(content, curriculum, request_metadata, full_context),
                self._get_curriculum_context(content, curriculum, request_metadata, curriculum_version),
                self._get_unified_image_analysis_context(content, skip_images=skip_images, request_metadata=request_metadata)
            )

            # Get generation prompt context if provided (sync, no IO)
            # We derive this from request_metadata
            generation_prompt_context = ""
            student_interests_context = ""
            if request_metadata:
                prompt_text = request_metadata.to_generation_prompt()
                generation_prompt_context = self._format_generation_prompt_context(prompt_text)
                student_interests_context = self._format_student_interests_context(
                    request_metadata.student_interests,
                    content=content,
                )
            
            # Build complete system prompt (contexts are prepended to prompt template)
            system_prompt = prompt_override or self.prompt_template
            
            # Add hierarchical context (if provided)
            # Remove SVG code from full_context to save tokens (SVGs are analyzed separately)
            if full_context and full_context != content:
                cleaned_full_context = remove_svg_from_content(full_context)
                context_note = (
                    "\n\n## FULL CONTEXT\n\n"
                    "This content is part of a larger educational resource. "
                    "The complete context is provided below for reference:\n\n"
                    f"{cleaned_full_context}\n\n"
                    "---\n\n"
                    "You are evaluating the SPECIFIC content provided in the user message, "
                    "but you should consider how it relates to and fits within the full context above."
                )
                system_prompt = context_note + "\n\n" + system_prompt
            
            # Add subcontent evaluation results (if provided)
            if subcontent_results:
                subcontent_context = self._format_subcontent_results(subcontent_results)
                system_prompt = subcontent_context + "\n\n" + system_prompt
            
            # Add standard contexts
            if programmatic_context:
                system_prompt = programmatic_context + "\n\n" + system_prompt
            if image_analysis_context:
                system_prompt = image_analysis_context + "\n\n" + system_prompt
            if curriculum_context:
                system_prompt = curriculum_context + "\n\n" + system_prompt
            if generation_prompt_context:
                system_prompt = generation_prompt_context + "\n\n" + system_prompt
            if student_interests_context:
                system_prompt = student_interests_context + "\n\n" + system_prompt
            
            # Resolve placeholders that the LLM is not meant to see literally
            # (e.g. ``{request.subject}`` in the counterfactual probe).
            system_prompt = _resolve_prompt_placeholders(system_prompt, request_metadata)

            # Call LLM evaluator
            result_model = self._get_result_model()
            if student_interests_context:
                result_model = with_required_interest_relevance(result_model)
            result = await self._call_llm_evaluator(
                content=content,
                system_prompt=system_prompt,
                result_model=result_model
            )
            result.overall.score = result.constrained_overall_score()
            
            logger.info(
                f"{content_type_name.capitalize()} evaluation complete in {time.time() - start_time:.2f}s. "
                f"Overall: {result.overall.score:.2f}"
            )
            return result
            
        except Exception as e:
            logger.error(f"Error evaluating {content_type_name}: {e}")
            raise RuntimeError(f"{content_type_name.capitalize()} evaluation failed: {e}")
    
    @abstractmethod
    def _get_result_model(self) -> type[BaseEvaluationResult]:
        """
        Return the Pydantic model class for this evaluator's results.
        
        Returns:
            Pydantic model class (e.g., QuestionEvaluationResult)
        """
        pass
    
    async def _get_programmatic_context(
        self,
        content: str,
        curriculum: str = "",
        request_metadata: Optional[RequestMetadata] = None,
        full_context: Optional[str] = None,
    ) -> str:
        """
        Hook for subclasses to add programmatic analysis context.
        
        Override this method to perform programmatic analyses (e.g., chi-square
        test for answer balance in quizzes, AP curriculum lookups) and return
        formatted context to prepend to the system prompt.

        Args:
            content: The educational content
            curriculum: Curriculum name (e.g., "common_core", "ap_us_history")
            request_metadata: Optional metadata about the content generation request

        Returns:
            Formatted programmatic analysis context string (empty by default)
        """
        return ""
    
    def _compute_child_aggregation_stats(
        self, 
        subcontent_results: List[BaseEvaluationResult]
    ) -> Dict:
        """
        Compute aggregation statistics from child evaluation results.
        
        These statistics are used by parent evaluators as authoritative data
        for metrics that depend on child outcomes.
        
        Args:
            subcontent_results: List of evaluation results from subcontent
            
        Returns:
            Dictionary containing:
            - n_children: Total number of children
            - mean_child: Mean of child overall scores
            - min_child: Minimum of child overall scores
            - max_child: Maximum of child overall scores
            - factual_accuracy_failures: Count of children with factual_accuracy = 0.0
            - educational_accuracy_failures: Count of children with educational_accuracy = 0.0
            - educational_accuracy_failure_pct: Percentage of children failing educational_accuracy
            - metric_pass_rates: Dict mapping metric names to pass rates (proportion with score 1.0)
        """
        if not subcontent_results:
            return {}
        
        n = len(subcontent_results)
        overall_scores = [r.overall.score for r in subcontent_results]
        
        # Core statistics
        stats = {
            "n_children": n,
            "mean_child": sum(overall_scores) / n,
            "min_child": min(overall_scores),
            "max_child": max(overall_scores),
        }
        
        # Critical metric failures
        factual_failures = sum(1 for r in subcontent_results if r.factual_accuracy.score == 0.0)
        educational_failures = sum(1 for r in subcontent_results if r.educational_accuracy.score == 0.0)
        
        stats["factual_accuracy_failures"] = factual_failures
        stats["educational_accuracy_failures"] = educational_failures
        stats["educational_accuracy_failure_pct"] = (educational_failures / n) * 100
        
        # Compute pass rates for common metrics across all children
        # We check which metrics exist on the results and compute pass rates
        metric_pass_rates = {}
        
        # Metrics that might be shared between parent and child evaluations
        potential_shared_metrics = [
            "factual_accuracy",
            "educational_accuracy", 
            "localization_quality",
            "stimulus_quality",
        ]
        
        for metric_name in potential_shared_metrics:
            scores = []
            for r in subcontent_results:
                metric_result = getattr(r, metric_name, None)
                if metric_result is not None and hasattr(metric_result, 'score'):
                    scores.append(metric_result.score)
            
            if scores:
                pass_count = sum(1 for s in scores if s == 1.0)
                metric_pass_rates[metric_name] = {
                    "pass_count": pass_count,
                    "total": len(scores),
                    "pass_rate": pass_count / len(scores)
                }
        
        stats["metric_pass_rates"] = metric_pass_rates
        
        return stats
    
    def _format_subcontent_results(self, subcontent_results: List[BaseEvaluationResult]) -> str:
        """
        Format subcontent evaluation results for inclusion in parent evaluation prompt.
        
        This provides the parent evaluator with context about how its nested
        components were evaluated, including computed aggregation statistics
        that should be used as authoritative data.
        
        Args:
            subcontent_results: List of evaluation results from subcontent
            
        Returns:
            Formatted string describing subcontent evaluations
        """
        if not subcontent_results:
            return ""
        
        # Compute aggregation statistics
        stats = self._compute_child_aggregation_stats(subcontent_results)
        
        lines = [
            "\n\n## NESTED CONTENT EVALUATIONS\n",
            f"This content contains {stats['n_children']} nested component(s) that have been evaluated.",
        ]
        
        # Add computed statistics section (AUTHORITATIVE)
        lines.append("\n### COMPUTED AGGREGATION STATISTICS (AUTHORITATIVE - USE THESE EXACTLY)")
        lines.append("")
        lines.append("The following statistics have been pre-computed from child evaluations.")
        lines.append("**You MUST use these values exactly** when applying aggregation rules.")
        lines.append("")
        lines.append(f"- **mean_child**: {stats['mean_child']:.3f}")
        lines.append(f"- **min_child**: {stats['min_child']:.3f}")
        lines.append(f"- **max_child**: {stats['max_child']:.3f}")
        lines.append("")
        lines.append(f"- **factual_accuracy failures**: {stats['factual_accuracy_failures']} of {stats['n_children']} children")
        lines.append(f"- **educational_accuracy failures**: {stats['educational_accuracy_failures']} of {stats['n_children']} children ({stats['educational_accuracy_failure_pct']:.1f}%)")
        
        # Add metric pass rates
        if stats.get("metric_pass_rates"):
            lines.append("")
            lines.append("**Metric pass rates across children:**")
            for metric_name, rate_info in stats["metric_pass_rates"].items():
                pct = rate_info["pass_rate"] * 100
                passes_threshold = "✓ passes 80%" if rate_info["pass_rate"] >= 0.80 else "✗ below 80%"
                lines.append(f"- {metric_name}: {rate_info['pass_count']}/{rate_info['total']} passing ({pct:.0f}%) {passes_threshold}")
        
        # Add individual component details
        lines.append("\n### Individual Component Scores\n")
        
        for i, subcontent_result in enumerate(subcontent_results, 1):
            content_type = subcontent_result.content_type
            overall_score = subcontent_result.overall.score
            
            lines.append(f"**Component {i}: {content_type}**")
            lines.append(f"- Overall Score: {overall_score:.2f}")
            lines.append(f"- Factual Accuracy: {subcontent_result.factual_accuracy.score:.1f}")
            lines.append(f"- Educational Accuracy: {subcontent_result.educational_accuracy.score:.1f}")
            
            # Add key insights from overall reasoning (first sentence)
            reasoning_preview = subcontent_result.overall.reasoning.split('.')[0] + "."
            lines.append(f"- Summary: {reasoning_preview}")
            lines.append("")
        
        lines.append(
            "**Use the computed statistics above** when determining parent-level metric scores. "
            "Do NOT recalculate these values - use them as provided."
        )
        
        return "\n".join(lines)
    
    async def _get_curriculum_context(
        self,
        content: str,
        curriculum: str,
        request_metadata: Optional[RequestMetadata] = None,
        curriculum_version: Optional[str] = None
    ) -> str:
        """
        Get curriculum context for the content.

        Routes to AP-specific local lookup for AP curriculums,
        or to the standard curriculum search API otherwise.

        Args:
            content: The educational content
            curriculum: Curriculum name
            request_metadata: Optional metadata about the request (prioritized for search)
            curriculum_version: Optional curriculum version (e.g., "1.2")

        Returns:
            Formatted curriculum context string (may be empty)
        """
        if (curriculum or "").lower() in AP_CURRICULUMS:
            return await self._get_ap_curriculum_context(content, curriculum, request_metadata)

        try:
            return await get_curriculum_context(content, curriculum, request_metadata, curriculum_version)
        except CurriculumAPIError:
            # Curriculum API errors must fail the evaluation loudly so the
            # caller sees the upstream message (wrong curriculum / subject /
            # course / etc.) rather than a silently empty context.
            raise
        except Exception as e:
            logger.warning(f"Error getting curriculum context: {e}")
            return ""

    def _extract_ap_standard_id(self, skills: object) -> Optional[str]:
        """
        Extract AP standard/substandard ID from request metadata skills.

        Supports dict and JSON-serialized string formats.
        """
        if skills is None:
            return None

        parsed = skills
        if isinstance(skills, str):
            stripped = skills.strip()
            if not stripped:
                return None
            try:
                parsed = json.loads(stripped)
            except json.JSONDecodeError:
                # Treat plain string skills as an ID/code
                return stripped

        candidate_keys = ("standard_id", "standardId", "id", "code", "standard_code")

        if isinstance(parsed, dict):
            for key in candidate_keys:
                value = parsed.get(key)
                if value:
                    return str(value).strip() or None
            return None

        if isinstance(parsed, list):
            for entry in parsed:
                if isinstance(entry, dict):
                    for key in candidate_keys:
                        value = entry.get(key)
                        if value:
                            return str(value).strip() or None
                elif isinstance(entry, str) and entry.strip():
                    return entry.strip()
            return None

        return None

    async def _get_ap_curriculum_context(
        self,
        content: str,
        curriculum: str,
        request_metadata: Optional[RequestMetadata] = None,
    ) -> str:
        """
        Build AP curriculum context from local JSON facts only (fail-closed).

        Behavior:
        - Exact standard ID match only (from request_metadata.skills)
        - No text search fallback
        - No random fallback
        - Course guard enforced to prevent cross-course ID collisions
        """
        del content  # AP context is substandard-driven only.

        course = AP_CURRICULUM_TO_COURSE.get((curriculum or "").lower())
        # Fallback: generic "ap" curriculum — derive course from subject (e.g. "apush" → "APUSH")
        if not course and curriculum and curriculum.lower() == "ap" and request_metadata and request_metadata.subject:
            subject = request_metadata.subject.strip().upper()
            if subject in AP_CURRICULUM_TO_COURSE.values():
                course = subject
        if not course:
            logger.info("AP_CONTEXT_MODE=NO_MATCH_FAIL_CLOSED reason=unknown_curriculum")
            return ""

        skills = request_metadata.skills if request_metadata else None
        standard_id = self._extract_ap_standard_id(skills)
        if not standard_id:
            logger.info("AP_CONTEXT_MODE=NO_SKILLS_FAIL_CLOSED")
            return ""

        try:
            repo = _get_ap_curriculum_repo()
            standard = repo.get_standard_by_id(standard_id, course=course)
            if not standard:
                cross_course = repo.get_standard_by_id(standard_id)
                if cross_course:
                    logger.info(
                        "AP_CONTEXT_MODE=COURSE_MISMATCH_FAIL_CLOSED requested_course=%s "
                        "matched_course=%s standard_id=%s",
                        course,
                        cross_course.get("course", ""),
                        standard_id,
                    )
                else:
                    logger.info(
                        "AP_CONTEXT_MODE=NO_MATCH_FAIL_CLOSED course=%s standard_id=%s",
                        course,
                        standard_id,
                    )
                return ""

            logger.info(
                "AP_CONTEXT_MODE=EXACT_ID_MATCH course=%s standard_id=%s",
                course,
                standard_id,
            )

            lines = [
                "## AP CURRICULUM STANDARDS",
                "",
                "The following AP curriculum standard was matched exactly from provided skills.",
                "Use this to assess curriculum alignment and factual accuracy:",
                "",
                "**Standard 1:**",
            ]
            if standard.get("course"):
                lines.append(f"- Course: {standard['course']}")
            if standard.get("unit"):
                lines.append(f"- Unit: {standard['unit']}")
            lines.append(f"- Standard ID: {standard_id}")
            if standard.get("topic"):
                lines.append(f"- Topic: {standard['topic']}")
            if standard.get("learning_objective"):
                lines.append(f"- Learning Objective: {standard['learning_objective']}")
            if standard.get("curriculum_fact"):
                lines.append(f"- Key Fact: {standard['curriculum_fact']}")
            if standard.get("time_period"):
                lines.append(f"- Time Period: {standard['time_period']}")
            lines.append("")
            return "\n".join(lines)
        except Exception as e:
            logger.warning("AP_CONTEXT_MODE=NO_MATCH_FAIL_CLOSED error=%s", e)
            return ""
    
    async def _get_unified_image_analysis_context(
        self,
        content: str,
        skip_images: set = None,
        request_metadata: Optional[RequestMetadata] = None,
    ) -> str:
        """
        Get comprehensive image analysis context using the evidence-first pipeline.

        Pipeline:
        1. analyze_images()  — LLM call, returns structured evidence
        2. extract_visual_spec()  — non-LLM, rule-based from content/metadata
        3. verify_visual_constraints()  — non-LLM, deterministic checks
        4. format_evidence_for_prompt()  — formats everything for the evaluator

        Args:
            content: The educational content
            skip_images: Set of image URLs to skip (already analyzed in subcontent)
            request_metadata: Optional metadata for spec extraction

        Returns:
            Formatted image analysis context string (may be empty)
        """
        def _merge_verification_results(
            analyses: List,
            spec
        ) -> Optional[VerificationResult]:
            if not analyses:
                return None
            merged: Optional[VerificationResult] = None
            for evidence in analyses:
                current = verify_visual_constraints(evidence, spec)
                if merged is None:
                    merged = current
                    continue
                merged.checks.extend(current.checks)
                merged.passed_count += current.passed_count
                merged.failed_count += current.failed_count
                merged.uncertain_count += current.uncertain_count
                merged.auto_reject = merged.auto_reject or current.auto_reject
            return merged

        try:
            all_image_urls = get_all_image_urls_for_analysis(content)

            if not all_image_urls:
                logger.debug("No images (URLs or SVGs) found in content")
                return ""

            if skip_images:
                original_count = len(all_image_urls)
                all_image_urls = [
                    url for url in all_image_urls
                    if url.startswith("data:") or url not in skip_images
                ]
                filtered_count = original_count - len(all_image_urls)
                if filtered_count > 0:
                    logger.info(
                        f"Filtered {filtered_count} image(s) already analyzed in subcontent"
                    )

            if not all_image_urls:
                logger.info("All images already analyzed in subcontent, skipping image analysis")
                return ""

            svg_count = sum(1 for url in all_image_urls if url.startswith("data:"))
            url_count = len(all_image_urls) - svg_count

            logger.info(
                f"Found {len(all_image_urls)} image(s) in content "
                f"({url_count} URL(s), {svg_count} SVG(s)), analyzing with unified analyzer..."
            )

            # Step 1: LLM analysis (returns structured evidence)
            analysis_result = await analyze_images(all_image_urls)

            # Step 2: Non-LLM spec extraction from content text
            spec = extract_visual_spec(content, request_metadata)

            # Step 3: Non-LLM deterministic verification across all images
            verification = None
            if analysis_result.success and analysis_result.image_analyses:
                verification = _merge_verification_results(
                    analysis_result.image_analyses,
                    spec,
                )

            # Step 4: Evidence-aware formatting
            image_analysis_context = format_evidence_for_prompt(
                analysis_result, verification
            )
            if image_analysis_context:
                image_analysis_context += (
                    "\n- When SVG programmatic coordinate data is included in the analysis context, "
                    "treat it as ground truth over visual estimation"
                )
            logger.info("Evidence-first image analysis context generated")
            return image_analysis_context

        except ImportError as e:
            if "cairosvg" in str(e):
                logger.warning(
                    "cairosvg not available for SVG conversion. "
                    "SVG images will be skipped. Install with: pip install cairosvg"
                )
                try:
                    image_urls = extract_image_urls(content)
                    if image_urls and skip_images:
                        image_urls = [url for url in image_urls if url not in skip_images]
                    if image_urls:
                        logger.info(f"Analyzing {len(image_urls)} URL image(s) only (SVGs skipped)")
                        analysis_result = await analyze_images(image_urls)
                        spec = extract_visual_spec(content, request_metadata)
                        verification = None
                        if analysis_result.success and analysis_result.image_analyses:
                            verification = _merge_verification_results(
                                analysis_result.image_analyses,
                                spec,
                            )
                        return format_evidence_for_prompt(analysis_result, verification)
                except Exception as fallback_e:
                    logger.warning(f"Fallback image analysis also failed: {fallback_e}")
            return ""

        except Exception as e:
            logger.warning(f"Error getting unified image analysis context: {e}")
            return ""
    
    def _format_generation_prompt_context(self, generation_prompt: Optional[str]) -> str:
        """
        Format the generation prompt context for inclusion in the system prompt.
        
        The generation prompt represents the instructions used to create AI-generated
        content. When present, it helps the evaluator understand the intended purpose
        and goals of the content, which is especially relevant for metrics like
        educational_accuracy and curriculum_alignment.
        
        Args:
            generation_prompt: The prompt used to generate the content (optional)
            
        Returns:
            Formatted generation prompt context string (empty if no prompt provided)
        """
        if not generation_prompt or not generation_prompt.strip():
            return ""
        
        return (
            "## GENERATION PROMPT\n\n"
            "The content you are evaluating was AI-generated using the following prompt. "
            "Use this prompt as an expression of the intended purpose, goals, and requirements "
            "for the content. When assessing metrics such as educational_accuracy, "
            "curriculum_alignment, or any other metrics where understanding the intended "
            "purpose is relevant, consider whether the content successfully fulfills the "
            "requirements expressed in this generation prompt:\n\n"
            f"{generation_prompt.strip()}\n\n"
            "---"
        )

    def _format_student_interests_context(
        self,
        student_interests,
        content: Optional[str] = None,
    ) -> str:
        """
        Format student interest data and the interest_relevance metric definition.

        Runs a deterministic literal-mention check against the student-facing
        text. If at least one listed interest does NOT appear literally in
        the question / options, the metric is force-failed with an
        authoritative directive — the LLM cannot pass it via inferred
        thematic similarity. When at least one interest is literally named,
        the LLM still judges whether the reference is meaningful or
        shoehorned.

        Only injected when student_interests are provided. When absent, the
        LLM never sees this metric and Pydantic defaults the field to None.

        Args:
            student_interests: Student interest data (list, dict, str, or None)
            content: The full evaluation content (JSON-encoded or raw string).
                Used for the deterministic literal-mention check.  If omitted,
                the deterministic veto is skipped and only the prompt rule
                governs the LLM's score.

        Returns:
            Formatted context string (empty if no interests provided)
        """
        if not student_interests:
            return ""

        if isinstance(student_interests, (list, dict)):
            interests_str = json.dumps(student_interests, indent=2)
        else:
            interests_str = str(student_interests)

        # Normalize the interest list to a flat list[str] for the matcher.
        interest_list = _normalize_interests_to_list(student_interests)

        # The matcher returns ``[]`` both when no listed interest appears AND
        # when the student-facing text was empty / unextractable.  Only the
        # first case is a real "no mention" signal that warrants the
        # authoritative force-fail directive.
        student_facing_text = (
            _extract_student_facing_text_for_interests(content) if content else ""
        )
        matched: List[str] = []
        if student_facing_text and interest_list:
            matched = _match_interests_in_content(content, interest_list)

        forced_fail = bool(student_facing_text) and bool(interest_list) and not matched

        if forced_fail:
            return (
                "## STUDENT INTERESTS & INTEREST RELEVANCE METRIC (AUTHORITATIVE)\n\n"
                "The caller provided these student interests:\n\n"
                f"{interests_str}\n\n"
                "A programmatic check has scanned the student-facing text "
                "(question stem and answer options) and confirmed that NONE of "
                "the listed interests appear literally in the content (neither "
                "the exact phrase nor any inflectional form like singular/plural "
                "of a notable token).\n\n"
                "Inferred thematic connections (e.g., \"hammer and nail\" for "
                "\"building birdhouses\") DO NOT count — those are inference, "
                "not reference.\n\n"
                "You MUST score `interest_relevance = 0.0` for this content. "
                "Cite which interests were checked and confirm none appear.\n\n"
                "Do NOT let this directive influence any other metric "
                "(factual_accuracy, educational_accuracy, clarity_precision, "
                "etc.) — those judge correctness, not engagement.\n\n"
                "---"
            )

        return (
            "## STUDENT INTERESTS & INTEREST RELEVANCE METRIC\n\n"
            "The caller has provided a list of student interests (shown below). "
            "You MUST evaluate the `interest_relevance` metric described here.\n\n"
            "### Student Interests\n\n"
            f"{interests_str}\n\n"
            "### interest_relevance (Binary: 0.0 or 1.0)\n\n"
            "**Rule:** the content must reference AT LEAST ONE of the listed "
            "interests by literally naming it. A single genuine reference is "
            "enough — the question does not need to reference all of them.\n\n"
            "- **1.0 (Pass)**: At least one listed interest is **literally "
            "named** in the student-facing text (question stem or answer "
            "options) — the exact term or a simple inflectional form. "
            "Examples: \"birdhouse\" passes for the interest \"building "
            "birdhouses\"; \"motorcycle\" passes for \"motorcycles\"; \"Rome\" "
            "passes for \"the Colosseum in Rome\".\n"
            "- **0.0 (Fail)**: No listed interest is literally named. Inferred "
            "or thematic connections DO NOT pass — for example, \"hammer and "
            "nail\" is NOT a reference to \"building birdhouses\"; \"guitar\" "
            "is NOT a reference to \"jazz\". Those are inference, not "
            "reference.\n\n"
            "**Guidelines:**\n"
            "- This is an engagement/relevance measure, not a correctness "
            "measure.\n"
            "- Do NOT let this metric influence any other metric "
            "(factual_accuracy, educational_accuracy, clarity_precision, "
            "etc.) — those judge correctness, not engagement.\n"
            "- A literal mention can still fail (score 0.0) if it is "
            "shoehorned in a way that makes the question incoherent or "
            "doesn't actually engage the interest meaningfully.\n\n"
            "---"
        )
    
    def _load_prompt_from_file(self, prompt_file_path: Path) -> str:
        """
        Helper method to load prompt from a file path.
        
        Args:
            prompt_file_path: Path to the prompt file
            
        Returns:
            Prompt content as string
            
        Raises:
            RuntimeError: If file cannot be loaded
        """
        try:
            with open(prompt_file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            logger.error(f"Error loading prompt from {prompt_file_path}: {e}")
            raise RuntimeError(f"Could not load prompt: {e}")
    
    @observe(name="llm_evaluator_call")
    async def _call_llm_evaluator(
        self,
        content: str,
        system_prompt: str,
        result_model: type[BaseEvaluationResult],
        max_retries: int = 3
    ) -> BaseEvaluationResult:
        """
        Helper method to call LLM for evaluation with structured output.

        Uses the LLMFactory-created instance (self.llm) which respects the
        task registry configuration for provider, model, and timeout.

        When video content is detected, automatically routes to Gemini for
        evaluation (since Gemini has native video understanding).

        The adapter handles transient error retries (timeouts, rate limits).
        This method adds an outer retry loop for non-transient intermittent
        failures (e.g., model returns unparseable output).

        Args:
            content: The content to evaluate
            system_prompt: The complete system prompt (including context)
            result_model: Pydantic model for structured output
            max_retries: Maximum number of retry attempts (default: 3)

        Returns:
            Evaluation result

        Raises:
            RuntimeError: If LLM call fails after all retries
        """
        # Check for media content (video/audio) — if present, route to Gemini
        video_urls = extract_video_urls(content)
        audio_urls = extract_audio_urls(content)
        if video_urls or audio_urls:
            media_type = "video+audio" if (video_urls and audio_urls) else ("video" if video_urls else "audio")
            logger.info(f"Media detected in content ({media_type}), routing to Gemini for evaluation")
            return await self._call_gemini_evaluator_with_media(
                content=content,
                system_prompt=system_prompt,
                result_model=result_model,
                video_urls=video_urls,
                audio_urls=audio_urls,
                max_retries=max_retries,
            )

        # BAML native path: route all known result types through BAML, including
        # content with images and SVGs (passed as baml_py.Image objects natively).
        model_name = result_model.__name__
        baml_dispatch = {
            "QuestionEvaluationResult": "call_baml_question",
            "QuizEvaluationResult": "call_baml_quiz",
            "McqSetEvaluationResult": "call_baml_mcqset",
            "ReadingEvaluationResult": "call_baml_reading",
            "OtherEvaluationResult": "call_baml_other",
        }
        if model_name in baml_dispatch:
            import baml_py
            import re as _re
            baml_images: List[baml_py.Image] = []

            # Collect URL images as baml_py.Image objects — extract_image_urls
            # applies clean_image_url internally, so returned URLs may differ from
            # raw markdown URLs (trailing punctuation stripped, etc.).
            # Build maps keyed on cleaned URLs so lookups match, but retain the raw
            # URL string for use in re.sub patterns (the pattern must match the
            # literal content text, which still contains the original raw URL).
            image_urls = extract_image_urls(content)
            _raw_alt_pairs = _re.findall(r"!\[([^\]]*)\]\(([^)]+)\)", content)
            from inceptbench.tools.image_utils import clean_image_url as _clean_img_url
            _alt_map: dict = {}   # cleaned_url -> alt_text
            _raw_url_map: dict = {}  # cleaned_url -> raw_url (for re.sub pattern)
            for alt, raw_url in _raw_alt_pairs:
                cleaned = _clean_img_url(raw_url.strip())
                if cleaned:
                    _alt_map[cleaned] = alt.strip()
                    _raw_url_map[cleaned] = raw_url.strip()
            _fetch_failed: list = []  # list of (cleaned_url, raw_url, alt_text)
            for url in image_urls:
                try:
                    encoded = download_and_encode_image(url)
                    if encoded.startswith("data:"):
                        header, b64 = encoded.split(";base64,", 1)
                        media_type = header.split(":", 1)[1]
                        baml_images.append(baml_py.Image.from_base64(media_type, b64))
                    else:
                        # download_and_encode_image returned the URL unchanged — the download
                        # failed and fell back to the raw URL. In the BAML path we cannot pass
                        # a URL that BAML will try to re-fetch (it may be inaccessible and will
                        # crash the entire evaluation). Treat this as a fetch failure instead.
                        logger.warning(
                            "Skipping URL image for BAML (download returned raw URL fallback): %s",
                            url,
                        )
                        _fetch_failed.append((url, _raw_url_map.get(url, url), _alt_map.get(url, "")))
                except ImagePreparationError as e:
                    logger.warning("Skipping URL image for BAML: %s", e)
                    _fetch_failed.append((url, _raw_url_map.get(url, url), _alt_map.get(url, "")))

            # Propagate fetch failures into content so the LLM knows not to hallucinate.
            # Also replace the markdown image syntax for failed URLs with plain text so
            # BAML's client library does not attempt to fetch them again and hard-fail.
            if _fetch_failed:
                for _failed_url, _raw_url, _alt in _fetch_failed:
                    _alt_display = f'"{_alt}"' if _alt else "(no alt text)"
                    _replacement = f"[IMAGE UNAVAILABLE: {_alt_display}]"
                    # Pattern uses the raw URL string as it appears in content
                    # (not the cleaned URL) so the substitution reliably matches
                    # the original markdown syntax even when cleaning strips chars.
                    # Lambda avoids re.sub misinterpreting backslashes in alt text.
                    content = _re.sub(
                        r"!\[[^\]]*\]\(" + _re.escape(_raw_url) + r"\)",
                        lambda _m, _r=_replacement: _r,
                        content,
                    )
                _failure_lines = [
                    "\n\n## IMAGE FETCH FAILURES\n\n"
                    "The following images could not be downloaded. You have ONLY their alt text "
                    "-- you have NOT seen the actual image pixels. "
                    "DO NOT describe specific visual details for these images. "
                    "For stimulus_quality, base your assessment solely on whether the alt text "
                    "suggests the image is appropriate or harmful.\n"
                ]
                for _failed_url, _raw_url, _alt in _fetch_failed:
                    _alt_display = f'"{_alt}"' if _alt else "(no alt text)"
                    _failure_lines.append(
                        f"- Image alt text {_alt_display}: fetch failed -- "
                        "visual content NOT verifiable from this evaluation"
                    )
                content = content + "\n".join(_failure_lines)

            # Convert SVGs to PNG and add as baml_py.Image objects
            svgs = extract_svg_content(content)
            if svgs:
                svg_prepared = prepare_svgs_for_analysis(svgs)
                for item in svg_prepared:
                    img_url = item.get("image_url", "")
                    match = _re.match(r"data:([^;]+);base64,(.+)", img_url, _re.DOTALL)
                    if match:
                        baml_images.append(
                            baml_py.Image.from_base64(match.group(1), match.group(2))
                        )

            from inceptbench.llm import baml_native_evaluator as _baml
            baml_fn = getattr(_baml, baml_dispatch[model_name])
            logger.info(
                "BAML native path: evaluating %s with %d image(s)",
                model_name, len(baml_images),
            )
            return await baml_fn(system_prompt, content, max_retries, images=baml_images or None)

        # FALLBACK: reached for result_model types intentionally routed outside BAML
        # (e.g. ArticleEvaluationResult, which uses GeminiAdapter for direct task
        # configuration and article consensus control) OR for truly new types that
        # lack a BAML function. Only the latter is a warning-worthy condition.
        intentionally_fallback = {"ArticleEvaluationResult"}
        if model_name not in intentionally_fallback:
            logger.warning(
                "BAML dispatch not found for result_model=%s — falling back to generate_structured/"
                "generate_with_vision. Add this type to baml_dispatch in _call_llm_evaluator.",
                model_name,
            )
        else:
            logger.info(
                "Intentional fallback for result_model=%s — using generate_structured/"
                "generate_with_vision for temperature control.",
                model_name,
            )

        import random

        # Remove SVG code from content to save tokens (SVGs are analyzed separately as images)
        cleaned_content = remove_svg_from_content(content)

        messages = [
            LLMMessage(role="system", content=system_prompt),
            LLMMessage(role="user", content=f"Please evaluate this content:\n\n{cleaned_content}"),
        ]

        # Extract images from original content (not cleaned) for vision input
        image_urls = extract_image_urls(content)
        images = None
        image_unavailable_notes: List[str] = []
        user_content = None
        if image_urls:
            logger.info(f"Adding {len(image_urls)} image(s) to evaluation")
            images = []
            for i, url in enumerate(image_urls, start=1):
                try:
                    encoded = download_and_encode_image(url)
                except ImagePreparationError as e:
                    logger.warning("Skipping image %d due to preparation failure: %s", i, e)
                    image_unavailable_notes.append(
                        f"Image {i} unavailable: preparation failed ({e})"
                    )
                    continue
                if encoded.startswith("data:"):
                    # Parse the data URL into base64_data + media_type for the LLM
                    header, b64 = encoded.split(";base64,", 1)
                    media_type = header.split(":", 1)[1]
                    images.append(LLMImage(base64_data=b64, media_type=media_type))
                else:
                    # Download failed — fall back to passing URL directly
                    images.append(LLMImage(url=encoded))
            if not images:
                images = None
            if image_unavailable_notes:
                user_msg = messages[1].content
                user_msg += (
                    "\n\n## IMAGE AVAILABILITY NOTES\n"
                    + "\n".join(f"- {note}" for note in image_unavailable_notes)
                    + "\nTreat unavailable image evidence as uncertain. "
                      "Do not assign hard factual penalties based only on missing image access."
                )
                messages[1] = LLMMessage(role="user", content=user_msg)

        # Add SVG-rendered PNGs so the evaluator LLM can see the diagrams
        svgs = extract_svg_content(content)
        if svgs:
            svg_images = prepare_svgs_for_analysis(svgs)
            if svg_images:
                logger.info(f"Adding {len(svg_images)} SVG image(s) to evaluation")
                if user_content is None:
                    user_content = list(svg_images)
                else:
                    user_content.extend(svg_images)
        last_error = None
        attempt_errors: List[AttemptError] = []

        # Convert user_content dicts → LLMImage objects for generate_with_vision
        llm_images: Optional[List[LLMImage]] = None
        if user_content:
            llm_images = []
            for item in user_content:
                img_url = item.get("image_url", "")
                if img_url.startswith("data:"):
                    # data:image/png;base64,<data>
                    match = re.match(r"data:([^;]+);base64,(.+)", img_url, re.DOTALL)
                    if match:
                        llm_images.append(LLMImage(
                            base64_data=match.group(2),
                            media_type=match.group(1)
                        ))
                elif img_url:
                    llm_images.append(LLMImage(url=img_url))

        for attempt in range(max_retries + 1):
            try:
                if llm_images:
                    result = await self.llm.generate_with_vision(
                        messages, llm_images, response_schema=result_model
                    )
                else:
                    result = await self.llm.generate_structured(messages, result_model)

                if attempt > 0:
                    FailureTracker.record_recovered(
                        component="evaluator._call_llm_evaluator",
                        message=f"Succeeded on attempt {attempt + 1}/{max_retries + 1}",
                        context={"model": self.llm.model},
                        attempt_errors=attempt_errors if attempt_errors else None
                    )
                    logger.info(f"Successfully got response on attempt {attempt + 1}")
                return result

            except Exception as e:
                logger.warning(f"LLM call failed (attempt {attempt + 1}/{max_retries + 1}): {e}")
                last_error = e
                attempt_errors.append(AttemptError(
                    attempt=attempt + 1,
                    error_message=str(e)
                ))

            # Retry with exponential backoff (4s base delay) if not the last attempt
            if attempt < max_retries:
                delay = 4.0 * (2 ** attempt) + random.uniform(0, 1)
                logger.info(f"Retrying in {delay:.1f}s...")
                await asyncio.sleep(delay)

        # All retries exhausted - record as EXHAUSTED
        FailureTracker.record_exhausted(
            component="evaluator._call_llm_evaluator",
            error_message=str(last_error) if last_error else "Unknown error",
            context={"model": self.llm.model, "result_model": result_model.__name__, "attempts": max_retries + 1},
            attempt_errors=attempt_errors
        )
        logger.error(f"Failed to get valid LLM response after {max_retries + 1} attempts")
        raise RuntimeError(f"Evaluation failed after {max_retries + 1} attempts: {last_error}")

    async def _call_gemini_evaluator_with_media(
        self,
        content: str,
        system_prompt: str,
        result_model: type[BaseEvaluationResult],
        video_urls: Optional[List[str]] = None,
        audio_urls: Optional[List[str]] = None,
        max_retries: int = 3,
    ) -> BaseEvaluationResult:
        """
        Call Gemini for evaluation when video or audio content is present.

        Uses Gemini's native multimodal understanding. Per Gemini best practices,
        only one media file per request for optimal results.

        Args:
            content: The content to evaluate
            system_prompt: The complete system prompt
            result_model: Pydantic model for structured output
            video_urls: List of video URLs found in content
            audio_urls: List of audio URLs found in content
            max_retries: Maximum number of retry attempts

        Returns:
            Evaluation result

        Raises:
            RuntimeError: If media evaluation fails
        """
        gemini = LLMFactory.create("media_evaluator")

        media_url_for_tracking = None
        media_kind = None

        try:
            media_url = None
            media_bytes = None
            media_mime_type = "video/mp4"
            extra_media = []

            if video_urls:
                media_url_for_tracking = video_urls[0]
                media_kind = "video" if not audio_urls else "video+audio"
                prepared_videos = await asyncio.gather(
                    *[prepare_video_for_gemini(url) for url in video_urls]
                )
                primary = prepared_videos[0]
                if primary.input_method == VideoInputMethod.YOUTUBE_URL:
                    media_url = primary.url
                else:
                    media_bytes = primary.video_bytes
                media_mime_type = primary.mime_type
                for extra in prepared_videos[1:]:
                    if extra.video_bytes:
                        extra_media.append((extra.video_bytes, extra.mime_type))
                if len(video_urls) > 1:
                    logger.info(f"Prepared {len(video_urls)} video files for evaluation")

            if audio_urls:
                if not video_urls:
                    media_url_for_tracking = audio_urls[0]
                    media_kind = "audio"
                prepared_audios = await asyncio.gather(
                    *[prepare_audio_for_gemini(url) for url in audio_urls]
                )
                if not video_urls:
                    media_bytes = prepared_audios[0].audio_bytes
                    media_mime_type = prepared_audios[0].mime_type
                    extra_media.extend(
                        (p.audio_bytes, p.mime_type) for p in prepared_audios[1:]
                    )
                else:
                    extra_media.extend(
                        (p.audio_bytes, p.mime_type) for p in prepared_audios
                    )
                if len(audio_urls) > 1:
                    logger.info(f"Prepared {len(audio_urls)} audio files for evaluation")

            image_urls = extract_image_urls(content)
            images = []
            for img_url in image_urls:
                images.append(LLMImage(url=img_url))

            messages = [
                LLMMessage(role="system", content=system_prompt),
                LLMMessage(role="user", content=f"Please evaluate this content:\n\n{content}")
            ]

            logger.info(f"Calling Gemini with {media_kind} media (mime: {media_mime_type})")

            result = await gemini.generate_with_media(
                messages=messages,
                media_url=media_url,
                media_bytes=media_bytes,
                media_mime_type=media_mime_type,
                images=images if images else None,
                response_schema=result_model,
                additional_media=extra_media if extra_media else None,
            )

            logger.info(f"Gemini {media_kind} evaluation completed successfully")
            return result

        except Exception as e:
            logger.error(f"Gemini {media_kind} evaluation failed: {e}")
            FailureTracker.record_exhausted(
                component="evaluator._call_gemini_evaluator_with_media",
                error_message=str(e),
                context={"media_url": media_url_for_tracking, "media_kind": media_kind, "task": "media_evaluator"}
            )
            raise RuntimeError(f"Media evaluation failed ({media_kind}): {e}")
