"""
Question evaluator for educational content.

This module provides an evaluator for single questions, assessing them across
multiple quality dimensions including curriculum alignment, clarity, misconception
detection, and more.

Uses a layered prompt architecture:
- _base_evaluation.txt: General evaluation framework (scoring, checklists, curriculum handling)
- Type-specific overlays: Metric definitions for each question type
- Optional subject overlays: Subject-wide rules for supported curriculum-subject pairs
- Optional curriculum-subject overlays: Narrow rules for a specific curriculum + subject

Supported question types:
- Closed-ended (MCQ, fill-in, MSQ): closed_ended_evaluation.txt
- Match (categories + items schema): match_evaluation.txt
- Sequence/ordering (sequence): sequence_evaluation.txt
- SAQ (Short Answer Questions): saq_evaluation.txt
- LEQ (Long Essay Questions): leq_evaluation.txt
- DBQ (Document-Based Questions): dbq_evaluation.txt

Prompt authoring rule: put each instruction at the broadest layer where it is
useful and true.
"""

import asyncio
import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

from inceptbench.config.constants import AP_CURRICULUMS
from inceptbench.config.tier_scoring import calculate_weighted_score
from inceptbench.evaluators.base import BaseEvaluator
from inceptbench.models import BaseEvaluationResult, MetricResult, QuestionEvaluationResult
from inceptbench.core.input_models import RequestMetadata
from inceptbench.tools.stimulus_reference_detector import (
    detect_stimulus_reference_mismatch,
)

logger = logging.getLogger(__name__)

PROMPTS_DIR = Path(__file__).parent.parent / "prompts" / "question"

_WIKI_CONTEXT_CACHE_DIR = Path(__file__).resolve().parent.parent.parent / ".wiki_context_cache"


def _wiki_context_disk_path(cache_key: str) -> Path:
    return _WIKI_CONTEXT_CACHE_DIR / f"{cache_key}.txt"


def _save_wiki_context_disk(cache_key: str, text: str) -> None:
    try:
        _WIKI_CONTEXT_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        _wiki_context_disk_path(cache_key).write_text(text, encoding="utf-8")
    except Exception as e:
        logger.debug("Failed to save wiki context cache: %s", e)

# Maps question type → overlay file. Types sharing evaluation logic point to the same file.
# Types not listed here fall back to DEFAULT_OVERLAY.
TYPE_PROMPT_MAP: Dict[str, str] = {
    # Closed-ended types — share the same answer_options-based evaluation framework
    "mcq": "closed_ended_evaluation.txt",
    "fill-in": "closed_ended_evaluation.txt",
    "msq": "closed_ended_evaluation.txt",
    # Match uses a dedicated overlay — categories + items schema differs structurally
    # from answer_options-based types (no answer_options field; uses categories/items instead)
    "match": "match_evaluation.txt",
    # Ordering/sequence type — dedicated overlay with ordering-specific metrics
    "sequence": "sequence_evaluation.txt",
    # Open-ended types — each has unique metric interpretations
    "saq": "saq_evaluation.txt",
    "leq": "leq_evaluation.txt",
    "dbq": "dbq_evaluation.txt",
}

DEFAULT_OVERLAY = "closed_ended_evaluation.txt"

# Optional broad subject prompts. Add a file only when it contains existing
# rules moved from a broader prompt and those rules are useful across the whole
# subject.
SUBJECT_PROMPT_MAP: Dict[str, str] = {
    "ela":  "ela_evaluation.txt",
    "math": "math_evaluation.txt",
}

# Maps (curriculum, subject) -> optional curriculum-subject overlay file.
# These files contain rules useful only for a specific supported pair, such as
# SAT Math or SAT Reading and Writing.
CURRICULUM_SUBJECT_PROMPT_MAP: Dict[tuple, str] = {
    ("sat", "math"):                "sat_math_evaluation.txt",
    ("sat", "ela"):                 "sat_rw_evaluation.txt",
}


@dataclass(frozen=True)
class PromptLayerSelection:
    """Resolved prompt layers for question evaluation."""

    question_type: Optional[str]
    type_overlay: str
    curriculum_key: Optional[str] = None
    subject_key: Optional[str] = None
    subject_overlay: Optional[str] = None
    curriculum_subject_key: Optional[tuple] = None
    curriculum_subject_overlay: Optional[str] = None


def _normalise_prompt_key(text: Optional[str]) -> str:
    return (text or "").strip().lower().replace("-", " ").replace("_", " ")


def _normalise_curriculum_key(curriculum: Optional[str]) -> str:
    text = (curriculum or "").strip().lower().replace("-", "_").replace(" ", "_")
    if text in {"cc", "common_core", "commoncore"}:
        return "common_core"
    if text == "teks":
        return "teks"
    if text == "sat":
        return "sat"
    if text in {"ap", "college_board"} or text in AP_CURRICULUMS:
        return "ap"
    return text


def _normalise_subject_key(subject: Optional[str]) -> Optional[str]:
    text = _normalise_prompt_key(subject)
    if not text:
        return None
    if text in {"math", "mathematics"}:
        return "math"
    if text in {
        "ela",
        "english",
        "english language arts",
        "language arts",
        "language",
        "reading",
        "writing",
        "reading and writing",
    }:
        return "ela"
    if text in {"science", "biology", "chemistry", "physics", "earth science"}:
        return "science"
    if text in {
        "ss",
        "social studies",
        "social science",
        "history",
        "american history",
        "us history",
        "u s history",
        "world history",
        "geography",
        "human geography",
        "government",
        "civics",
        "economics",
    }:
        return "social_studies"
    return None


SUPPORTED_SUBJECTS_BY_CURRICULUM: Dict[str, frozenset[str]] = {
    "common_core": frozenset({"ela", "math", "science", "social_studies"}),
    "teks": frozenset({"math"}),
    "sat": frozenset({"ela", "math"}),
    "ap": frozenset({"social_studies"}),
}


class QuestionEvaluator(BaseEvaluator):
    """
    Evaluator for single educational questions.

    Assesses questions across 11 metrics using layered prompt composition.
    The base prompt provides the general evaluation framework (scoring table,
    checklists, curriculum handling, borderline rules). Type overlays provide
    format-specific metric definitions. Optional subject and curriculum-subject
    layers add narrower guidance when available.
    """

    # Cache for prompt overlays (loaded once, reused across requests)
    _overlay_cache: Dict[str, str] = {}

    def _load_prompt(self) -> str:
        """Load the base evaluation prompt (general framework, no metric definitions)."""
        return self._load_prompt_from_file(PROMPTS_DIR / "_base_evaluation.txt")

    def _get_result_model(self) -> type[BaseEvaluationResult]:
        """Return the QuestionEvaluationResult model."""
        return QuestionEvaluationResult

    def _load_overlay(self, filename: str) -> Optional[str]:
        """
        Load a question prompt overlay, cached after first load.

        Returns None if the overlay file doesn't exist.
        """
        if filename not in self._overlay_cache:
            path = PROMPTS_DIR / filename
            if path.exists():
                self._overlay_cache[filename] = self._load_prompt_from_file(path)
            else:
                logger.warning("Question prompt overlay not found: %s", path)
                return None
        return self._overlay_cache.get(filename)

    def _detect_subject(
        self,
        request_metadata: Optional[RequestMetadata],
        curriculum: str = "",
    ) -> Optional[str]:
        """Detect the supported broad subject key for selecting a subject overlay."""
        curriculum_text = _normalise_curriculum_key(
            (request_metadata.curriculum if request_metadata else None) or curriculum
        )
        subject_text = _normalise_subject_key(
            request_metadata.subject if request_metadata else None
        )
        if not curriculum_text or not subject_text:
            return None
        if subject_text in SUPPORTED_SUBJECTS_BY_CURRICULUM.get(curriculum_text, frozenset()):
            return subject_text
        return None

    def _detect_curriculum_subject(
        self,
        request_metadata: Optional[RequestMetadata],
        curriculum: str = "",
    ) -> Optional[tuple]:
        """Detect (curriculum, subject) key for selecting a narrow overlay."""
        curriculum_text = _normalise_curriculum_key(
            (request_metadata.curriculum if request_metadata else None) or curriculum
        )
        subject_text = self._detect_subject(request_metadata, curriculum)
        key = (curriculum_text, subject_text)
        if key in CURRICULUM_SUBJECT_PROMPT_MAP:
            return key
        return None

    def _resolve_prompt_layers(
        self,
        question_type: Optional[str],
        request_metadata: Optional[RequestMetadata] = None,
        curriculum: str = "",
    ) -> PromptLayerSelection:
        """Resolve all prompt layer filenames for a question evaluation."""
        qtype = question_type.lower() if question_type else None
        type_overlay = TYPE_PROMPT_MAP.get(qtype, DEFAULT_OVERLAY) if qtype else DEFAULT_OVERLAY
        curriculum_key = _normalise_curriculum_key(
            (request_metadata.curriculum if request_metadata else None) or curriculum
        )
        subject_key = self._detect_subject(request_metadata, curriculum)
        subject_overlay = SUBJECT_PROMPT_MAP.get(subject_key) if subject_key else None
        curriculum_subject_key = self._detect_curriculum_subject(request_metadata, curriculum)
        curriculum_subject_overlay = (
            CURRICULUM_SUBJECT_PROMPT_MAP.get(curriculum_subject_key)
            if curriculum_subject_key
            else None
        )

        return PromptLayerSelection(
            question_type=qtype,
            type_overlay=type_overlay,
            curriculum_key=curriculum_key or None,
            subject_key=subject_key,
            subject_overlay=subject_overlay,
            curriculum_subject_key=curriculum_subject_key,
            curriculum_subject_overlay=curriculum_subject_overlay,
        )

    def _get_combined_prompt(
        self,
        question_type: Optional[str],
        subject_key: Optional[str] = None,
        curriculum_subject_key: Optional[tuple] = None,
    ) -> str:
        """
        Build the complete prompt by appending resolved layers.

        Assembly order is base + type + optional subject + optional
        curriculum-subject. This is composition order only; prompt authors
        should still put each rule at the broadest layer where it is useful
        and true.
        """
        if isinstance(subject_key, tuple) and curriculum_subject_key is None:
            curriculum_subject_key = subject_key
            subject_key = None

        overlay_filename = (
            TYPE_PROMPT_MAP.get(question_type, DEFAULT_OVERLAY)
            if question_type
            else DEFAULT_OVERLAY
        )
        overlay = self._load_overlay(overlay_filename)
        prompt_parts = [self.prompt_template]

        if overlay:
            prompt_parts.append(overlay)
        else:
            logger.warning(
                f"Could not load overlay for type '{question_type}', using base prompt only"
            )

        if subject_key:
            subject_overlay_filename = SUBJECT_PROMPT_MAP.get(subject_key)
            if subject_overlay_filename:
                subject_overlay = self._load_overlay(subject_overlay_filename)
                if subject_overlay:
                    prompt_parts.append(subject_overlay)
                else:
                    logger.warning(
                        "Subject overlay file %s not found, skipping subject layer",
                        subject_overlay_filename,
                    )

        if curriculum_subject_key:
            curriculum_overlay_filename = CURRICULUM_SUBJECT_PROMPT_MAP.get(
                curriculum_subject_key
            )
            if curriculum_overlay_filename:
                curriculum_overlay = self._load_overlay(curriculum_overlay_filename)
                if curriculum_overlay:
                    prompt_parts.append(curriculum_overlay)
                else:
                    logger.warning(
                        "Curriculum overlay file %s not found, skipping curriculum-subject layer",
                        curriculum_overlay_filename,
                    )

        return "\n\n".join(prompt_parts)

    async def evaluate(
        self,
        content: str,
        curriculum: str = "common_core",
        full_context: Optional[str] = None,
        subcontent_results=None,
        request_metadata: Optional[RequestMetadata] = None,
        analyzed_image_urls: Optional[set] = None,
        curriculum_version: Optional[str] = None,
        prompt_override: Optional[str] = None
    ) -> BaseEvaluationResult:
        """
        Evaluate a question, selecting the appropriate prompt based on type.

        Detects question type from request_metadata.type and builds a combined
        prompt (base + type overlay). Falls back to closed-ended overlay for
        unknown types.
        """
        # Detect question type and build combined prompt
        qtype = None
        if request_metadata and request_metadata.type:
            qtype = request_metadata.type.lower()

        layer_selection = self._resolve_prompt_layers(qtype, request_metadata, curriculum)

        if not prompt_override:
            prompt_override = self._get_combined_prompt(
                qtype,
                layer_selection.subject_key,
                layer_selection.curriculum_subject_key,
            )
            layer_names = ["_base_evaluation.txt", layer_selection.type_overlay]
            if layer_selection.subject_overlay:
                layer_names.append(layer_selection.subject_overlay)
            if layer_selection.curriculum_subject_overlay:
                layer_names.append(layer_selection.curriculum_subject_overlay)
            logger.info(
                "Using question prompt layers %s for type=%r curriculum=%r subject=%r",
                " + ".join(layer_names),
                qtype,
                layer_selection.curriculum_key,
                layer_selection.subject_key,
            )
        elif layer_selection.subject_key or layer_selection.curriculum_subject_key:
            # prompt_override was supplied by the caller; optional overlays are skipped.
            logger.debug(
                "prompt_override provided; skipping optional question prompt layers "
                "(subject=%s, curriculum_subject=%s)",
                layer_selection.subject_key,
                layer_selection.curriculum_subject_key,
            )

        from inceptbench.tools.factual_accuracy_audit import (
            apply_factual_audit_to_question_result,
            run_consensus_factual_accuracy_audit,
            should_run_audit,
        )

        if not should_run_audit(request_metadata):
            result = await super().evaluate(
                content=content,
                curriculum=curriculum,
                full_context=full_context,
                subcontent_results=subcontent_results,
                request_metadata=request_metadata,
                analyzed_image_urls=analyzed_image_urls,
                curriculum_version=curriculum_version,
                prompt_override=prompt_override,
            )
            if isinstance(result, QuestionEvaluationResult):
                return await self._apply_deterministic_consistency_guard(
                    result, content, full_context, request_metadata
                )
            return result

        result, factual_audit = await asyncio.gather(
            super().evaluate(
                content=content,
                curriculum=curriculum,
                full_context=full_context,
                subcontent_results=subcontent_results,
                request_metadata=request_metadata,
                analyzed_image_urls=analyzed_image_urls,
                curriculum_version=curriculum_version,
                prompt_override=prompt_override,
            ),
            run_consensus_factual_accuracy_audit(
                self,
                content=content,
                curriculum=curriculum,
                full_context=full_context,
                subcontent_results=subcontent_results,
                request_metadata=request_metadata,
                analyzed_image_urls=analyzed_image_urls,
                curriculum_version=curriculum_version,
            ),
        )

        if isinstance(result, QuestionEvaluationResult):
            audited = apply_factual_audit_to_question_result(result, factual_audit)
            return await self._apply_deterministic_consistency_guard(
                audited, content, full_context, request_metadata
            )
        return result

    async def _apply_deterministic_consistency_guard(
        self,
        result: QuestionEvaluationResult,
        content: str,
        full_context: Optional[str],
        request_metadata: Optional[RequestMetadata],
    ) -> QuestionEvaluationResult:
        """
        Minimal deterministic safety net for factual_accuracy only.

        Advisory remains the default, but high-confidence deterministic
        option-key consistency can un-fail factual_accuracy (0.0 -> 1.0)
        on a clear pass. Contradictions remain advisory because visual label
        extraction is not allowed to overrule the evaluator's direct reasoning
        after the fact.
        """
        # ELA standard-specific enforcement: when a deterministic detector
        # fired into the programmatic context AND the LLM still passed the
        # corresponding metric, flip it to 0.0. The signal block in the prompt
        # asked the LLM to do this; if the LLM ignored it, we enforce the
        # narrow override-or-penalize contract from outside.
        result = self._apply_ela_detector_enforcement(result, content, request_metadata)

        # Deterministic guards for specific content patterns.
        from .guards import (
            guard_ela_double_determiner,
            guard_math_image_reveals_answer,
            guard_visual_option_key_consistency,
        )
        result = guard_ela_double_determiner(result, content, request_metadata)
        result = guard_math_image_reveals_answer(result, content, request_metadata)

        # Delegate visual option-key consistency check to shared guard.
        return await guard_visual_option_key_consistency(
            result, content, full_context, request_metadata
        )

    def _apply_ela_detector_enforcement(
        self,
        result: QuestionEvaluationResult,
        content: str,
        request_metadata: Optional[RequestMetadata],
    ) -> QuestionEvaluationResult:
        """
        When an ELA standard-specific detector fired, the prompt context asked
        the LLM to score the affected metric 0.0. If the LLM ignored that
        directive, this guard enforces the contract deterministically.

        Override clause is honored: if the LLM's own reasoning quotes a
        valid override per the signal block (i.e., its reasoning includes
        explicit visual-derivation evidence or stylistic-synonym mapping),
        the existing score stands. Without such quoting, we flip to 0.0.
        """
        if not isinstance(result, QuestionEvaluationResult):
            return result

        updates: dict = {}

        integration_fired = bool(
            self._detect_integration_decorative_image(content, request_metadata)
        )
        if integration_fired and result.curriculum_alignment.score == 1.0:
            reasoning = (result.curriculum_alignment.reasoning or "") + " " + (
                result.curriculum_alignment.internal_reasoning or ""
            )
            # Override requires the LLM to quote a substring from the actual
            # answer_explanation / question stem that names a visual element.
            # Generic uses of "visual" in the LLM's reasoning don't count.
            data = self._unwrap_content(content) or {}
            student_text = (data.get("question") or "") + " " + (
                data.get("answer_explanation") or ""
            )
            override_ok = False
            for sentence in re.split(r"(?<=[.!?])\s+", student_text):
                if (
                    self._VISUAL_REFERENCE_TOKENS.search(sentence)
                    and sentence.strip()[:80] in reasoning
                ):
                    override_ok = True
                    break
            if not override_ok:
                updates["curriculum_alignment"] = result.curriculum_alignment.model_copy(
                    update={
                        "score": 0.0,
                        "reasoning": (
                            "[INTEGRATION_DECORATIVE_IMAGE enforced] The targeted "
                            "integration-of-formats standard requires every stimulus to "
                            "be load-bearing. A deterministic check found an image was "
                            "provided but never referenced in the answer explanation, and "
                            "the evaluator's reasoning did not quote any sentence using "
                            "image-derived facts to discriminate among options. "
                            + (result.curriculum_alignment.reasoning or "")
                        ),
                        "suggested_improvements": (
                            "Either remove the decorative image, or rewrite the item so "
                            "the correct answer cannot be reached from the text/data "
                            "alone — the image must carry a discriminating fact."
                        ),
                    }
                )

        conclusion_fired = bool(
            self._detect_conclusion_domain_leak(content, request_metadata)
        )
        if conclusion_fired and result.factual_accuracy.score == 1.0:
            reasoning = (result.factual_accuracy.reasoning or "") + " " + (
                result.factual_accuracy.internal_reasoning or ""
            )
            # Heuristic: accept LLM override only if the reasoning explicitly
            # quotes a synonym mapping (uses "synonym" / "paraphrase" /
            # "same concept as" / shows both quoted phrases with ↔ or ->).
            override_ok = any(
                marker in reasoning.lower()
                for marker in ("synonym", "paraphrase", "same concept", "stylistic")
            )
            if not override_ok:
                updates["factual_accuracy"] = result.factual_accuracy.model_copy(
                    update={
                        "score": 0.0,
                        "reasoning": (
                            "[CONCLUSION_DOMAIN_LEAK enforced] A correct option "
                            "introduces a domain/claim that the passage never argues. "
                            + (result.factual_accuracy.reasoning or "")
                        ),
                        "suggested_improvements": (
                            "Remove the unsupported domain word from the correct option, "
                            "or revise the passage to actually argue that domain."
                        ),
                    }
                )

        if not updates:
            return result

        patched = result.model_copy(update=updates)
        scores = patched._get_metric_scores()
        weighted = calculate_weighted_score(scores) or 0.0
        new_overall = patched.overall.model_copy(
            update={
                "score": round(float(weighted), 4),
                "reasoning": (patched.overall.reasoning or "")
                + " (Overall recomputed after ELA detector enforcement.)",
            }
        )
        return patched.model_copy(update={"overall": new_overall})

    _STEM_PASSAGE_SIGNALS = re.compile(
        r"read the (?:following )?(?:passage|paragraph|excerpt|poem|text)|"
        r"excerpt from|adapted from|according to the (?:passage|author|narrator|speaker|poem|text)|"
        r"in the (?:poem|text|excerpt|passage)|"
        r"line \d+[:\.]|^\(\d+\)\s",
        re.IGNORECASE | re.MULTILINE,
    )
    _STEM_LONG_QUOTE = re.compile(r'["“”].{120,}["“”]', re.DOTALL)
    _STEM_BLOCKQUOTE = re.compile(r"^>[ \t].+", re.MULTILINE)
    _STEM_PUNCT = re.compile(r"[^\w\s]")
    _STEM_WS = re.compile(r"\s+")

    @staticmethod
    def _normalize_for_redundancy(text: str) -> str:
        """Lowercase, replace punctuation with spaces, collapse whitespace."""
        cleaned = QuestionEvaluator._STEM_PUNCT.sub(" ", text.lower())
        return QuestionEvaluator._STEM_WS.sub(" ", cleaned).strip()

    @staticmethod
    def _detect_stem_redundancy(content: str) -> str:
        """
        Detect when answer-option text appears verbatim inside the question stem.

        Match definition: after lowercasing, replacing punctuation with spaces, and
        collapsing whitespace, the option's full text appears as a contiguous substring
        of the stem. Order-preserving — rejects coincidental bag-of-words overlap.
        Options shorter than 20 characters or 5 normalized words are skipped.

        Returns a verify-cue context block (NOT an authoritative override) when at
        least 2 options match. The block asks the LLM to re-read stem + options and
        only penalize if the duplication is real. Returns empty string when no signal.
        """
        try:
            data = json.loads(content)
        except Exception:
            return ""

        if isinstance(data, dict) and "generated_content" in data:
            items = data["generated_content"]
            if isinstance(items, list) and items:
                data = items[0]
            elif isinstance(items, dict):
                data = items
            else:
                return ""
        if isinstance(data, dict) and isinstance(data.get("content"), dict):
            data = data["content"]

        if not isinstance(data, dict):
            return ""

        question: str = data.get("question", "") or ""
        answer_options = data.get("answer_options", [])

        if not question or not isinstance(answer_options, list) or len(answer_options) < 2:
            return ""

        option_texts: list[str] = []
        for opt in answer_options:
            if isinstance(opt, dict):
                option_texts.append((opt.get("text") or "").strip())
            elif isinstance(opt, str):
                option_texts.append(opt.strip())

        if not option_texts:
            return ""

        # Reading-comprehension passage guard: options legitimately quote stem content.
        if (
            QuestionEvaluator._STEM_PASSAGE_SIGNALS.search(question)
            or QuestionEvaluator._STEM_LONG_QUOTE.search(question)
            or QuestionEvaluator._STEM_BLOCKQUOTE.search(question)
        ):
            return ""

        norm_question = QuestionEvaluator._normalize_for_redundancy(question)

        matches = 0
        matched_options: list[str] = []
        for opt_text in option_texts:
            if len(opt_text) < 20:
                continue
            norm_opt = QuestionEvaluator._normalize_for_redundancy(opt_text)
            if len(norm_opt.split()) < 5:
                continue
            if norm_opt and norm_opt in norm_question:
                matches += 1
                matched_options.append(opt_text[:80])
                logger.debug(
                    "Stem redundancy match: opt=%r found verbatim in stem",
                    opt_text[:60],
                )

        logger.info(
            "Stem redundancy check: %d/%d options matched verbatim in stem",
            matches, len(option_texts),
        )

        if matches < 2:
            return ""

        # Truncate the raw stem so it doesn't blow up the prompt for very long passages.
        # If truncated, the LLM still sees the full set of matched-option excerpts above.
        stem_for_display = question if len(question) <= 2000 else question[:2000] + "\n…[truncated]"

        lines = [
            "## STEM REDUNDANCY SIGNAL — VERIFY AND PENALIZE IF CONFIRMED",
            "",
            f"A deterministic check found that {matches} of {len(option_texts)} answer-option "
            "texts appear as a contiguous substring (after lowercasing + punctuation/whitespace "
            "normalization) inside the question stem. Coincidental contiguous verbatim matches of "
            "full multi-word answer options are extremely rare, so the default reading of this "
            "signal is that the redundancy is real.",
            "",
            "### What stem redundancy is",
            "",
            "The full answer-choice list is embedded TWICE: once written into the question stem "
            "(typically as `A. <text> B. <text> C. <text> D. <text>` or a similar inline list), "
            "and once again as the structured `answer_options` field that the rendering layer "
            "presents to the student. The student therefore sees the same set of options listed "
            "twice. This is a structural authoring defect, not a stylistic choice — properly "
            "authored MCQs put the answer choices in `answer_options` only.",
            "",
            "### Raw question stem (verbatim — read this carefully)",
            "",
            "```",
            stem_for_display,
            "```",
            "",
            "### Option texts that the heuristic matched inside the stem above:",
        ]
        for opt in matched_options:
            lines.append(f'  - "{opt}..."')
        lines.extend([
            "",
            "### What you must verify",
            "",
            "Read the raw question stem. Confirm whether the matched option texts appear inside "
            "the stem as an inline answer-choice list. The signal is CONFIRMED if both of the "
            "following are true:",
            "1. The stem contains 2 or more of the answer-option texts verbatim (allowing for "
            "casing/punctuation differences).",
            "2. Those texts are presented as choices for the student to pick from — typically "
            "with `A.`/`B.`/`C.`/`D.` labels, bullets, numbered lines, or line-separated stanzas "
            "structured as a selectable list.",
            "",
            "If both are true, the signal is CONFIRMED and you must penalize.",
            "",
            "### Narrow false-positive cases — when to ignore the signal",
            "",
            "Only ignore the signal if ONE of these is true and you can quote the stem text that "
            "demonstrates it:",
            "- **Passage being analyzed**: the matched text is part of an extended passage, "
            "excerpt, poem, or quotation that the student is asked to analyze, and the options "
            "legitimately quote sentences from it. (The deterministic guards already filter many "
            "of these, but you should still check.)",
            "- **Worked example**: the matched text is a worked example or model that the stem "
            "walks through before posing a *different* question.",
            "- **Partial / not presented as choices**: the matched substring appears in the stem "
            "but is NOT presented as an answer-choice list (e.g., it is woven into a single "
            "natural sentence, not labeled or formatted as options).",
            "",
            "### Reasons that DO NOT justify overriding the signal",
            "",
            "The following rationalizations are NOT valid grounds to ignore this signal. If your "
            "reasoning matches any of these, you must penalize, not override:",
            "- *\"This is a common formatting style.\"* — It is not standard MCQ authoring; it is "
            "a defect.",
            "- *\"The student still has to evaluate and select.\"* — True but irrelevant; the "
            "options being listed twice is the defect, regardless of student cognitive load.",
            "- *\"The redundancy is harmless / does not affect correctness.\"* — Structural "
            "defects are scored even when the underlying educational core is sound.",
            "- *\"The stem contains additional framing text, so it's fine.\"* — Framing text "
            "around a duplicated option list does not eliminate the duplication.",
            "- *\"The stem text does not contain the options.\"* — Read the FULL raw stem above. "
            "Do not crop to the first sentence and conclude based on that. If you claim the "
            "options are absent, you must have read past every `A.`/`B.`/`C.`/`D.` label in the "
            "raw stem block above.",
            "",
            "### Action",
            "",
            "If the signal is CONFIRMED (the default outcome given the deterministic match):",
            "- Record `STEM REDUNDANCY` in your Step 2 issue list, citing which option texts are "
            "duplicated.",
            "- Score `specification_compliance = 0.0`.",
            "- Score `educational_accuracy = 0.0`.",
            "",
            "If you override the signal, you MUST in your `internal_reasoning` for these two "
            "metrics: (a) cite which of the three narrow false-positive cases above applies, and "
            "(b) quote the specific stem text that demonstrates it. An override without both is "
            "invalid — fall back to penalizing.",
        ])
        return "\n".join(lines)

    _INTEGRATION_STANDARD_DESC = re.compile(
        r"\bintegrat\w+\b.{0,80}\b(?:formats?|media|visually|quantitatively|diagrams?|charts?|tables?)\b",
        re.IGNORECASE,
    )
    _CONCLUSION_STANDARD_DESC = re.compile(
        r"\bconclud\w+\b.{0,80}\b(?:argument|claim|follow|presented)\b|"
        r"\bfollows?\s+from\b.{0,60}\bargument\b",
        re.IGNORECASE,
    )
    _NARRATIVE_EVAL_STANDARD_DESC = re.compile(
        r"\b(?:engage|orient)\w*\b.{0,80}\breader\b|"
        r"\bevent\s+sequence\b|"
        r"\bnarrator\b.{0,40}\bcharacter\b|"
        r"\bestablish\w*\b.{0,40}\bcontext\b",
        re.IGNORECASE,
    )
    _VISUAL_REFERENCE_TOKENS = re.compile(
        # Match phrases that genuinely refer to an attached visual stimulus.
        # Bare "figure" / "figures" are intentionally excluded because they
        # collide with content phrases like "figure-eight" (#371 bee dance).
        r"\b(?:image|images|diagram|diagrams|visual|visuals|picture|pictures|"
        r"illustration|illustrations|infographic|chart|charts|graph|graphs|"
        r"shown|depicted|depict|as\s+seen|in\s+the\s+(?:image|diagram|figure|chart|graph|picture|illustration)|"
        r"see\s+the\s+(?:image|diagram|figure|chart|graph|picture|illustration)|"
        r"figure\s+\d+|figure\s+(?:above|below|on the right|on the left))\b",
        re.IGNORECASE,
    )
    _STOPWORDS = frozenset({
        "the","a","an","and","or","but","if","then","of","to","in","on","at","by","for","with",
        "from","into","onto","as","is","are","was","were","be","been","being","this","that",
        "these","those","it","its","their","there","here","not","no","yes","do","does","did",
        "have","has","had","can","could","would","should","may","might","will","shall","more",
        "most","also","such","than","both","all","any","each","every","one","two","very",
        "many","much","some","few","several","other","another","also","only","just","very",
        "while","because","since","though","although","when","where","what","which","who","whom",
        "whose","why","how","over","under","up","down","out","off","about","against","through",
        "between","among","new","old","first","second","big","small","good","bad","best","worst",
        "many","main","part","parts","like","make","makes","made","take","takes","took","get",
        "gets","got","go","goes","went","gone","day","year","years","time","times","way","ways",
        "thing","things","provide","provides","providing","provided","ultimately","conclusion",
        "in conclusion","based on","passage","argument","author","conclude","concluding","statement",
        "section","follows","follow","argued","argues","arguing"
    })

    @staticmethod
    def _tokens(text: str) -> set[str]:
        """Lowercase word tokens >= 4 chars, stripped of plurals/-ing/-ed, non-stopwords."""
        out: set[str] = set()
        for raw in re.findall(r"[A-Za-z][A-Za-z\-]+", text or ""):
            w = raw.lower()
            if w in QuestionEvaluator._STOPWORDS or len(w) < 4:
                continue
            # crude stem: trim common suffixes
            if w.endswith("ies") and len(w) - 3 >= 4:
                w = w[:-3] + "y"
            elif w.endswith("ing") and len(w) - 3 >= 4:
                w = w[:-3]
            elif w.endswith("ied") and len(w) - 3 >= 4:
                w = w[:-3] + "y"
            elif w.endswith("ed") and len(w) - 2 >= 4:
                w = w[:-2]
            elif w.endswith("es") and len(w) - 2 >= 4:
                w = w[:-2]
            elif w.endswith("s") and len(w) - 1 >= 4:
                w = w[:-1]
            if w in QuestionEvaluator._STOPWORDS or len(w) < 4:
                continue
            out.add(w)
        return out

    @staticmethod
    def _unwrap_content(content: str) -> Optional[dict]:
        try:
            data = json.loads(content)
        except Exception:
            return None
        if isinstance(data, dict) and "generated_content" in data:
            items = data["generated_content"]
            if isinstance(items, list) and items:
                data = items[0]
            elif isinstance(items, dict):
                data = items
            else:
                return None
        if isinstance(data, dict) and isinstance(data.get("content"), dict):
            data = data["content"]
        return data if isinstance(data, dict) else None

    @staticmethod
    def _standard_description(
        request_metadata: Optional[RequestMetadata], content: Optional[str] = None
    ) -> str:
        """Pull the substandard description out of request metadata; fall back to
        the `request.skills` embedded in the wrapped content payload when the
        orchestrator did not thread RequestMetadata through (folder/batch mode).
        """
        skills = None
        if request_metadata is not None:
            skills = getattr(request_metadata, "skills", None)
        if not skills and content:
            try:
                wrapper = json.loads(content)
            except Exception:
                wrapper = None
            if isinstance(wrapper, dict):
                items = wrapper.get("generated_content")
                if isinstance(items, list) and items:
                    first = items[0]
                    if isinstance(first, dict):
                        req = first.get("request") or {}
                        if isinstance(req, dict):
                            skills = req.get("skills")
        if not skills:
            return ""
        if isinstance(skills, str):
            try:
                skills = json.loads(skills)
            except Exception:
                return skills
        if isinstance(skills, dict):
            return str(skills.get("substandard_description") or skills.get("description") or "")
        return ""

    @staticmethod
    def _detect_integration_decorative_image(
        content: str, request_metadata: Optional[RequestMetadata]
    ) -> str:
        """
        For integration-of-formats standards (description names integrating
        information across media/formats/visually/quantitatively): if the item
        carries an image_url but the answer_explanation never references any
        visual element, the image is decorative and the item fails the
        integration demand.

        Emits a verify-cue signal block. CONFIRMED-by-default; LLM may only
        override with quoted evidence that the image is actually load-bearing.
        """
        desc = QuestionEvaluator._standard_description(request_metadata, content)
        if not desc or not QuestionEvaluator._INTEGRATION_STANDARD_DESC.search(desc):
            return ""

        data = QuestionEvaluator._unwrap_content(content)
        if not data:
            return ""

        image_urls = data.get("image_url") or data.get("image_urls") or []
        if isinstance(image_urls, str):
            image_urls = [image_urls]
        image_urls = [u for u in image_urls if isinstance(u, str) and u.strip()]
        if not image_urls:
            return ""

        explanation = (data.get("answer_explanation") or "").strip()
        question_stem = (data.get("question") or "").strip()
        combined_text = (question_stem + " " + explanation).strip()
        if combined_text and QuestionEvaluator._VISUAL_REFERENCE_TOKENS.search(combined_text):
            return ""

        return "\n".join([
            "## INTEGRATION-STANDARD DECORATIVE-IMAGE SIGNAL (AUTHORITATIVE)",
            "",
            "This signal OVERRIDES the global \"default to PASS\" stance for "
            "`curriculum_alignment` on this item. The deterministic check below is "
            "treated as ground truth unless you can satisfy the narrow override clause.",
            "",
            f"The targeted standard requires *integrating* information across formats "
            f"(description excerpt: \"{desc[:200].strip()}\"), and the item ships "
            f"{len(image_urls)} image(s). A deterministic scan of `question` and "
            "`answer_explanation` found NO references to any visual element — no `image`, `diagram`, "
            "`visual`, `chart`, `graph`, `picture`, `illustration`, `shown`, `depicted`, "
            "or `figure N` / `in the figure` construction. Under an integration standard, "
            "an image whose content is not used to discriminate among answers is "
            "decorative. A decorative stimulus on an integration-of-formats item "
            "violates the standard's integration demand.",
            "",
            "### Mandatory action",
            "- Record `INTEGRATION_DECORATIVE_IMAGE` in your Step 2 issue list.",
            "- Score `curriculum_alignment = 0.0`.",
            "- The `overall` reasoning must mention the decorative-image violation.",
            "",
            "### Narrow override clause",
            "You may set `curriculum_alignment = 1.0` ONLY IF, in your "
            "`internal_reasoning` for `curriculum_alignment`, you quote a specific "
            "sentence from the student-facing content (the `question` stem or "
            "`answer_explanation`) that uses a fact *derived from the image* to "
            "discriminate among the answer options. Examples of valid overrides:",
            "- \"The image shows 5 segments which is why option C is correct.\"",
            "- \"The diagram's arrow points up, eliminating option B.\"",
            "",
            "Invalid overrides (you must penalize if you find yourself writing these):",
            "- \"The image illustrates the topic.\"",
            "- \"The image is engaging / thematic / scaffolding.\"",
            "- \"The image supports comprehension.\"",
            "- \"The standard is about integration so the image counts.\" (circular)",
            "",
            "If you cannot produce a load-bearing quote, you MUST penalize. The "
            "global PASS stance does not apply to this signal.",
        ])

    @staticmethod
    def _detect_conclusion_domain_leak(
        content: str, request_metadata: Optional[RequestMetadata]
    ) -> str:
        """
        For argument-conclusion standards (description names providing a
        concluding statement that follows from the argument): each correct
        option's content nouns/adjectives must trace back to the passage.
        Any correct-option token not found (literal or trivial morphological
        variant) in the passage is a candidate "new domain" introduction.

        Emits a verify-cue signal listing the missing tokens.
        """
        desc = QuestionEvaluator._standard_description(request_metadata, content)
        if not desc or not QuestionEvaluator._CONCLUSION_STANDARD_DESC.search(desc):
            return ""

        data = QuestionEvaluator._unwrap_content(content)
        if not data:
            return ""

        question = data.get("question") or ""
        options = data.get("answer_options") or []
        answer = data.get("answer")

        # Build the set of correct option indices/keys
        correct_keys: set = set()
        if isinstance(answer, list):
            correct_keys = {str(a).strip().upper() for a in answer if a}
        elif isinstance(answer, str):
            correct_keys = {answer.strip().upper()}

        if not options or not correct_keys:
            return ""

        passage_tokens = QuestionEvaluator._tokens(question)

        # Domain words very commonly added as unsupported synthesis. Used only
        # to elevate certainty when found; absence does not suppress the check.
        elevation_terms = {"econom", "tourism", "tourist", "beauty", "safety",
                           "political", "religious", "spiritual"}

        leaks: list[tuple[str, list[str]]] = []
        for opt in options:
            key = ""
            text = ""
            if isinstance(opt, dict):
                key = str(opt.get("key", "")).strip().upper()
                text = opt.get("text") or ""
            elif isinstance(opt, str):
                # Plain-string options don't carry keys; skip.
                continue
            if key not in correct_keys:
                continue
            opt_tokens = QuestionEvaluator._tokens(text)
            missing = sorted(opt_tokens - passage_tokens)
            # Filter to tokens that look domain-y: keep tokens that are
            # nouns/adjectives (we don't have POS, so use length + the elevation
            # heuristic) and drop short or generic fragments.
            domain_missing = [t for t in missing if len(t) >= 5]
            if not domain_missing:
                continue
            # Only flag if at least one missing word looks like a new domain
            # (elevation hit) OR more than 2 missing tokens overall.
            has_elevation = any(any(t.startswith(e) for e in elevation_terms) for t in domain_missing)
            if has_elevation or len(domain_missing) >= 3:
                leaks.append((key, domain_missing[:8]))

        if not leaks:
            return ""

        lines = [
            "## CONCLUSION-STANDARD DOMAIN-LEAK SIGNAL (AUTHORITATIVE)",
            "",
            "This signal OVERRIDES the global \"default to PASS\" stance for "
            "`factual_accuracy` on this item. Treat the deterministic finding below as "
            "ground truth unless the narrow override clause applies.",
            "",
            "The targeted standard requires that concluding statements *follow from* the "
            f"argument actually presented (description excerpt: \"{desc[:200].strip()}\"). "
            "A deterministic scan compared content tokens in each correct option against "
            "tokens in the passage and found correct options that introduce domain words "
            "the passage never argues:",
            "",
        ]
        for key, words in leaks:
            lines.append(f"- Option **{key}** introduces: {', '.join(words)}")
        lines.extend([
            "",
            "### Mandatory action",
            "If any listed token names a benefit / cause / effect / domain the passage "
            "never literally argues:",
            "- Record `CONCLUSION_DOMAIN_LEAK` in your Step 2 issue list.",
            "- Score `factual_accuracy = 0.0`.",
            "- The `overall` reasoning must mention the unsupported-domain violation.",
            "",
            "### Narrow override clause",
            "You may keep `factual_accuracy = 1.0` ONLY when the missing token is a "
            "stylistic synonym (e.g., \"residents\" ↔ \"people\") of a concept the "
            "passage explicitly names. In your `internal_reasoning` you must quote both "
            "(a) the option phrase containing the missing token and (b) the passage "
            "phrase you are mapping it to.",
            "",
            "These are NOT valid overrides (penalize if you write them):",
            "- \"Could be inferred from the passage.\"",
            "- \"Implied by the discussion of X.\"",
            "- \"Reasonable abstraction / synthesis for a hard item.\"",
            "- \"Cheaper veg implies economic impact.\" (this invents the claim)",
        ])
        return "\n".join(lines)

    @staticmethod
    def _detect_narrative_eval_borderline_risk(
        content: str, request_metadata: Optional[RequestMetadata]
    ) -> str:
        """
        Narrative-writing-evaluation items (standards naming engage/orient
        reader, event sequence, establish context with characters) that ask
        the student to pick the BEST among multiple long parallel options
        (drafts/passages of 40+ words each) carry a high risk of containing
        distractors that a reasonable student could defensibly pick. This
        signal asks the LLM to strictly apply the borderline-correct test.
        """
        desc = QuestionEvaluator._standard_description(request_metadata, content)
        if not desc or not QuestionEvaluator._NARRATIVE_EVAL_STANDARD_DESC.search(desc):
            return ""

        data = QuestionEvaluator._unwrap_content(content)
        if not data:
            return ""

        options = data.get("answer_options") or []
        long_opts = 0
        # Treat options as "long parallel narratives" if the OPTION TEXTS are
        # long, OR if the question stem itself embeds long labeled drafts
        # (e.g., "Draft A: ...", "Story B: ...").
        for opt in options:
            text = opt.get("text") if isinstance(opt, dict) else opt
            if isinstance(text, str) and len(text.split()) >= 40:
                long_opts += 1

        stem = data.get("question") or ""
        embedded_drafts = len(re.findall(
            r"\b(?:Draft|Passage|Story|Excerpt|Sample|Example|Version)\s+[A-Z]\b[:\.]",
            stem,
        ))

        if long_opts < 3 and embedded_drafts < 3:
            return ""

        return "\n".join([
            "## NARRATIVE-EVALUATION BORDERLINE-DISTRACTOR SIGNAL (AUTHORITATIVE)",
            "",
            "This signal OVERRIDES the global \"default to PASS\" stance for "
            "`distractor_quality` on this item. Treat the deterministic finding below "
            "as ground truth unless the narrow override clause applies.",
            "",
            "The targeted standard names criteria for narrative writing (engage/orient "
            "the reader, establish context, introduce characters, organize an event "
            "sequence) and the item presents multiple long parallel narratives as "
            "options or embedded drafts. Such items have a high failure rate on the "
            "*borderline distractor* check: distractors that a reasonable student "
            "could defensibly argue satisfy the named criteria are improperly marked "
            "incorrect.",
            "",
            "### Mandatory action",
            "For each distractor (option marked incorrect), produce a one-sentence "
            "argument *defending* it under the stem's criteria. If you can produce a "
            "defensible argument — meaning a reasonable student could read the stem "
            "and the distractor and conclude it satisfies the criteria — that "
            "distractor is borderline-correct and the item fails:",
            "- Record `BORDERLINE_DISTRACTOR_DEFENSIBLE` in your Step 2 issue list.",
            "- Score `distractor_quality = 0.0`.",
            "",
            "### Narrow override clause",
            "Override (keep `distractor_quality = 1.0`) only when for EVERY distractor "
            "you can quote the specific clause/sentence in the distractor that "
            "demonstrably violates a *named* criterion from the standard (not a "
            "general \"weakness\"). \"Less effective\" or \"clunky\" is NOT a "
            "criterion violation; \"contains a temporal jump with no transition\" or "
            "\"opens without naming any character\" IS.",
        ])

    async def _get_programmatic_context(
        self,
        content: str,
        curriculum: str = "",
        request_metadata: Optional[RequestMetadata] = None,
        full_context: Optional[str] = None,
    ) -> str:
        """Compute deterministic contexts (math + stimulus mismatch + stem redundancy + inline SVG analysis + optional Wikipedia).

        ``full_context`` is the parent (root) content. The stimulus-reference
        check uses it as a fallback so a recursively decomposed child whose
        anchor slice missed a sibling-region stimulus is not falsely flagged
        when the parent article actually carries that image.
        """
        import os
        from inceptbench.tools.image_utils import (
            cross_reference_box_whisker,
            extract_svg_box_whisker,
            extract_svg_box_whisker_values,
            extract_svg_clock_time,
            extract_svg_content,
            extract_svg_fraction_model_analysis,
            extract_svg_grid_area,
            extract_svg_math_coordinates,
            extract_svg_protractor_angle,
            extract_svg_tick_intervals,
        )
        from inceptbench.tools.math_verifier import extract_and_verify_math

        del curriculum

        question_type = getattr(request_metadata, "type", None) if request_metadata else None
        skip_stimulus_check = question_type and question_type.lower() == "sequence"
        use_wiki = os.environ.get("EVALUATOR_USE_WIKIPEDIA", "").strip().lower() in (
            "1", "true", "yes",
        )

        coros: list = [extract_and_verify_math(content)]
        if not skip_stimulus_check:
            coros.append(
                detect_stimulus_reference_mismatch(content, fallback_context=full_context)
            )
        if use_wiki:
            coros.append(self._fetch_wiki_for_evaluator(content, request_metadata))

        results = await asyncio.gather(*coros)

        contexts: list[str] = []
        idx = 0

        math_context = results[idx]; idx += 1
        if math_context:
            contexts.append(math_context)

        # Deterministic stem redundancy check — runs for MCQ/MSQ (or unknown type)
        _qtype_lower = (question_type or "").lower()
        if _qtype_lower in ("mcq", "msq", ""):
            stem_redundancy_context = self._detect_stem_redundancy(content)
            if stem_redundancy_context:
                contexts.append(stem_redundancy_context)

        # ELA standard-specific deterministic checks. Both are gated by the
        # standard description, so they no-op outside the relevant standards.
        integration_signal = self._detect_integration_decorative_image(content, request_metadata)
        if integration_signal:
            contexts.append(integration_signal)
        conclusion_signal = self._detect_conclusion_domain_leak(content, request_metadata)
        if conclusion_signal:
            contexts.append(conclusion_signal)
        narrative_signal = self._detect_narrative_eval_borderline_risk(content, request_metadata)
        if narrative_signal:
            contexts.append(narrative_signal)

        if not skip_stimulus_check:
            stimulus_check = results[idx]; idx += 1
            if stimulus_check.is_mismatch:
                lines = [
                    "## PROGRAMMATIC STIMULUS REFERENCE CHECK (AUTHORITATIVE)",
                    "",
                    "The question PROMISES the student will consult the following "
                    "stimuli, but the content does not actually carry them in the "
                    "required medium:",
                    "",
                ]
                for promise in stimulus_check.unsatisfied_promises[:8]:
                    phrase = promise.exact_phrase or promise.kind
                    lines.append(
                        f"- **{promise.kind}** "
                        f"(medium: {promise.medium_required}) — \"{phrase}\""
                    )
                    lines.append(f"    Reason: {promise.reason}")
                lines.extend([
                    "",
                    "A prose description of an absent visual/audio/video artifact "
                    "is NOT a valid substitute. This is a CONFIRMED mismatch — the "
                    "question fabricates artifacts the student is told to consult.",
                    "",
                    "You MUST score stimulus_quality = 0.0 for this content.",
                ])
                contexts.append("\n".join(lines))

        if use_wiki:
            wiki_context = results[idx]; idx += 1
            if wiki_context:
                contexts.append(wiki_context)

        # Extract deterministic context from inline SVGs (box plots, etc.)
        # These SVGs get converted to PNG for vision analysis, so their
        # structural data is lost unless we extract it here from the raw text.
        for svg_item in extract_svg_content(content):
            svg_text = svg_item.get("content", "")
            if not svg_text:
                continue
            box_ctx = extract_svg_box_whisker(svg_text)
            if box_ctx:
                contexts.append(box_ctx)
                box_vals = extract_svg_box_whisker_values(svg_text)
                if box_vals:
                    contradiction = cross_reference_box_whisker(box_vals, content)
                    if contradiction:
                        contexts.append(contradiction)
            svg_context = (
                extract_svg_clock_time(svg_text)
                or extract_svg_math_coordinates(svg_text)
                or extract_svg_tick_intervals(svg_text)
                or extract_svg_fraction_model_analysis(svg_text)
                or extract_svg_protractor_angle(svg_text)
                or extract_svg_grid_area(svg_text)
            )
            if svg_context:
                contexts.append(svg_context)

        return "\n\n".join(contexts)

    _wiki_context_cache: dict[str, str] = {}

    async def _fetch_wiki_for_evaluator(
        self,
        content: str,
        request_metadata: Optional["RequestMetadata"] = None,
    ) -> str:
        """Fetch Wikipedia passages and format as reference material for the evaluator.

        Uses a content-hash cache: first evaluation pays the LLM + Wikipedia cost,
        all subsequent evaluations of the same question are instant.
        """
        import hashlib

        cache_key = hashlib.sha256(content.encode()).hexdigest()[:16]
        if cache_key in self._wiki_context_cache:
            return self._wiki_context_cache[cache_key]

        disk_path = _wiki_context_disk_path(cache_key)
        if disk_path.exists():
            try:
                cached = disk_path.read_text(encoding="utf-8")
                self._wiki_context_cache[cache_key] = cached
                return cached
            except Exception:
                pass

        from inceptbench.tools.wiki_retriever import (
            _select_wiki_variant,
            extract_multiple_search_terms,
            fetch_wikipedia_passages,
        )

        try:
            grade = getattr(request_metadata, "grade", None) if request_metadata else None
            wiki_variant = _select_wiki_variant(str(grade) if grade is not None else None)
            search_terms = await extract_multiple_search_terms(content)
            if not search_terms:
                result = ""
                self._wiki_context_cache[cache_key] = result
                _save_wiki_context_disk(cache_key, result)
                return result

            per_query_budget = 3000 // max(len(search_terms), 1)
            fetches = [
                fetch_wikipedia_passages(term, variant=wiki_variant, max_tokens=per_query_budget)
                for term in search_terms[:3]
            ]
            results = await asyncio.gather(*fetches, return_exceptions=True)
            passages = [r for r in results if isinstance(r, str) and r]
            if not passages:
                result = ""
                self._wiki_context_cache[cache_key] = result
                _save_wiki_context_disk(cache_key, result)
                return result

            combined = "\n\n---\n\n".join(passages)
            result = (
                "## WIKIPEDIA REFERENCE MATERIAL (for factual cross-check)\n\n"
                "The following Wikipedia passages are provided as factual reference. "
                "Use them to verify claims in the question content:\n"
                "- If a passage **directly contradicts** a factual claim in the correct "
                "answer or its explanation, score `factual_accuracy = 0.0`.\n"
                "- If passages do not address a claim, rely on your own knowledge.\n"
                "- Do NOT penalize correct content just because Wikipedia doesn't mention it.\n\n"
                f"[WIKIPEDIA PASSAGES]\n{combined}\n[/WIKIPEDIA PASSAGES]"
            )
            self._wiki_context_cache[cache_key] = result
            _save_wiki_context_disk(cache_key, result)
            return result
        except Exception as e:
            logger.warning("Wikipedia fetch for evaluator failed: %s", e)
            return ""
