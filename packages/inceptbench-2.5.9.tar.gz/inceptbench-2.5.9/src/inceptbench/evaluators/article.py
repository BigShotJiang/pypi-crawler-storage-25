"""
Article evaluator.

This module evaluates educational articles using a base + subject-overlay
prompt architecture. The base prompt contains common evaluation rules and
shared metrics. Subject overlays define additional metrics and scoring rules.

Evaluation path:
  All articles route through ``BaseEvaluator._call_llm_evaluator`` →
  ``GeminiAdapter.generate_structured`` (BAML's native ``EvaluateArticle``
  function is intentionally bypassed for articles — the structured-output
  Gemini path gives us direct adapter control, and the N-run consensus loop
  applies sampling diversity plus metric voting.
  SVG content: rendered to PNG and passed as image bytes.
  URL images: downloaded, base64-encoded, passed as image bytes.
  Video/audio: routes to Gemini media path (generate_with_media) — BAML does
  not support media.

The evaluator then:
- Runs ``ARTICLE_EVALUATOR_CONSENSUS_RUNS`` (default 3) sequential calls and
  majority-votes every binary metric using an 80% supermajority threshold.
- Applies the shared deterministic guards (``guard_stimulus_quality`` and
  ``guard_math_factual_accuracy``) to each raw run before merging, so a
  programmatically-resolvable metric (e.g. inline-image stimulus) is
  unanimously stable across consensus runs.
- Merges a parallel factual-accuracy audit (Wikipedia RAG, when subject-
  gated on) and stores the advisory on the article result for diagnostics.
- Sets ``overall.score`` deterministically to the ceiling of the metric
  pattern's band (``overall_score_bounds()[1]``) so two consensus passes
  with the same voted metrics produce identical verdicts.
"""

import asyncio
import contextvars
import logging
import os
from collections import OrderedDict
from pathlib import Path
from typing import Dict, List, Optional

from inceptbench.core.input_models import RequestMetadata
from inceptbench.models.article import ArticleEvaluationResult
from inceptbench.models.base import BaseEvaluationResult, MetricResult

from .base import BaseEvaluator

logger = logging.getLogger(__name__)

PROMPTS_DIR = Path(__file__).parent.parent / "prompts" / "article"

# Per-request math verification cache.
#
# ``ArticleEvaluator`` is instantiated once in ``EvaluationOrchestrator`` and
# reused for all requests (singleton lifetime). Using an instance attribute to
# cache the math-verification context between ``_get_programmatic_context`` and
# the post-evaluation guard is racy under concurrent load — one request can
# overwrite another request's cache between the write and the read, silently
# substituting the wrong article's math verification result.
#
# A ``ContextVar`` solves this because asyncio creates a per-task copy of the
# context at task creation. Each top-level request runs in its own asyncio
# task, so ``set()`` calls in one request are invisible to others. Within a
# single request, child tasks spawned via ``asyncio.gather`` inside
# ``BaseEvaluator.evaluate()`` inherit a snapshot of the parent's context, so
# the value written by ``_get_programmatic_context`` is visible to the parent
# task after the gather completes.
_math_context_var: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "inceptbench_article_math_context", default=None
)

_wiki_context_var: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "inceptbench_article_wiki_context", default=None
)

# Set to True by the factual audit before calling _get_programmatic_context
# so the wiki passages it carries via its own RAG preamble are not duplicated
# inside the audit's system prompt.
_suppress_wiki_in_programmatic_context: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "inceptbench_article_suppress_wiki_in_programmatic_context", default=False
)

def _wiki_context_cache_dir() -> Path:
    """Return the on-disk wiki cache directory.

    Honours ``INCEPTBENCH_WIKI_CACHE_DIR`` when set; otherwise uses the XDG
    cache home (``$XDG_CACHE_HOME`` or ``~/.cache``) so we never pollute the
    source tree at runtime.
    """
    override = os.environ.get("INCEPTBENCH_WIKI_CACHE_DIR", "").strip()
    if override:
        return Path(override).expanduser()
    xdg = os.environ.get("XDG_CACHE_HOME", "").strip()
    base = Path(xdg).expanduser() if xdg else Path.home() / ".cache"
    return base / "inceptbench" / "wiki_context"


def _wiki_context_disk_path(cache_key: str) -> Path:
    """Return the on-disk cache path for a wiki context entry."""
    return _wiki_context_cache_dir() / f"{cache_key}.txt"

def _save_wiki_context_disk(cache_key: str, text: str) -> None:
    """Persist wiki context to disk cache (best-effort)."""
    try:
        path = _wiki_context_disk_path(cache_key)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    except Exception as e:
        logger.debug("Failed to save wiki context cache: %s", e)


SUBJECT_PROMPT_MAP: Dict[str, str] = {
    "social studies": "social_studies_evaluation.txt",
    "history": "social_studies_evaluation.txt",
    "geography": "social_studies_evaluation.txt",
    "economics": "social_studies_evaluation.txt",
    "civics": "social_studies_evaluation.txt",
}

DEFAULT_OVERLAY = "di_evaluation.txt"


class ArticleEvaluator(BaseEvaluator):
    """
    Evaluator for educational articles.

    Uses a base prompt plus subject-specific overlays:
    - Default overlay for general direct-instruction article evaluation
    - Social Studies overlay for history/geography/economics/civics content

    Supports optional consensus evaluation (``ARTICLE_EVALUATOR_CONSENSUS_RUNS``)
    to reduce LLM non-determinism on binary metrics. When N>1, the evaluator
    runs N times and majority-votes each metric, dramatically lowering flip
    rates on borderline content.
    """

    _overlay_cache: Dict[str, str] = {}
    _WIKI_CONTEXT_CACHE_MAX_ENTRIES = 256
    _wiki_context_cache: OrderedDict[str, str] = OrderedDict()

    @classmethod
    def _get_wiki_context_from_memory(cls, cache_key: str) -> Optional[str]:
        """Return an in-memory wiki context and mark it recently used."""
        if cache_key not in cls._wiki_context_cache:
            return None
        value = cls._wiki_context_cache[cache_key]
        cls._wiki_context_cache.move_to_end(cache_key)
        return value

    @classmethod
    def _remember_wiki_context(cls, cache_key: str, context: str) -> None:
        """Store wiki context in a bounded process-local cache."""
        cls._wiki_context_cache[cache_key] = context
        cls._wiki_context_cache.move_to_end(cache_key)
        while len(cls._wiki_context_cache) > cls._WIKI_CONTEXT_CACHE_MAX_ENTRIES:
            cls._wiki_context_cache.popitem(last=False)

    # ------------------------------------------------------------------
    # Consensus helpers
    # ------------------------------------------------------------------

    # Default consensus run count for production deployments. The golden
    # quality gate in `.github/workflows/quality-gates.yml` runs at the same
    # value so CI validation matches what users experience by default.
    _DEFAULT_CONSENSUS_RUNS = 3

    @staticmethod
    def _get_consensus_runs() -> int:
        """Return the number of consensus runs from ARTICLE_EVALUATOR_CONSENSUS_RUNS.

        When N>1, the evaluator runs N times and majority-votes each binary
        metric. This filters out noisy false-positives while preserving
        consistently-detected real issues.

        Defaults to ``_DEFAULT_CONSENSUS_RUNS`` (currently 3) when the env var
        is unset or invalid, so production behavior matches the configuration
        validated by the golden CI gate. Override with
        ``ARTICLE_EVALUATOR_CONSENSUS_RUNS=1`` to opt out (e.g. for fast
        local debugging).
        """
        raw = os.environ.get("ARTICLE_EVALUATOR_CONSENSUS_RUNS", "").strip()
        if raw:
            try:
                n = int(raw)
                if n >= 1:
                    return n
            except ValueError:
                pass
        return ArticleEvaluator._DEFAULT_CONSENSUS_RUNS

    @staticmethod
    def _merge_consensus_results(
        results: List[ArticleEvaluationResult],
    ) -> ArticleEvaluationResult:
        """Merge N article evaluation results via supermajority voting.

        All binary metrics — critical and non-critical — use the same
        ``>= 80%`` fail threshold. With N=3 that means a failure must be
        unanimous before it flips a metric to 0.0, which prevents a single
        noisy LLM run from flipping the verdict on borderline content.

        The overall score is set deterministically to
        ``overall_score_bounds()[1]`` (the band ceiling for the merged
        metric pattern) so it is identical across consensus passes with the
        same voted metric outcomes — no LLM-generated ``overall.score``
        noise leaks into the final verdict.
        """
        if not results:
            raise ValueError("Cannot merge empty results list")
        if len(results) == 1:
            return results[0]

        n = len(results)
        base = results[0]
        majority_metrics: dict[str, MetricResult] = {}

        for field_name in ArticleEvaluationResult.model_fields:
            if field_name in (
                "content_type",
                "overall",
                "subcontent_evaluations",
                "overall_rating",
                "weighted_score",
                "factual_audit",
            ):
                continue

            votes: list[float] = []
            candidates: list[MetricResult] = []
            for r in results:
                metric = getattr(r, field_name, None)
                if isinstance(metric, MetricResult):
                    votes.append(metric.score)
                    candidates.append(metric)

            if not votes:
                continue

            fail_count = sum(1 for v in votes if v == 0.0)
            fail_ratio = fail_count / n

            # All binary metrics use the same supermajority (>=80% fail)
            # threshold. The previous 50% rule for `factual_accuracy` /
            # `educational_accuracy` allowed a single LLM disagreement to
            # flip the verdict across consecutive consensus passes, which
            # violated the cross-run stability target. Real factual errors
            # are still caught by the dedicated factual_audit consensus
            # path (`run_consensus_factual_accuracy_audit`), which requires
            # unanimous agreement before downgrading factual_accuracy.
            chosen_score = 0.0 if fail_ratio >= 0.8 else 1.0

            # Pick the candidate whose score matches the consensus.
            for metric in candidates:
                if metric.score == chosen_score:
                    majority_metrics[field_name] = metric
                    break
            else:
                # No candidate has exactly chosen_score (e.g. LLM returned 0.5).
                # Synthesise a MetricResult so the merged value reflects the
                # consensus decision rather than silently reusing results[0].
                majority_metrics[field_name] = MetricResult(
                    score=chosen_score,
                    reasoning=(
                        f"[Consensus] No candidate matched {chosen_score:.1f}; "
                        "synthetic metric from majority vote."
                    ),
                )

        # Deep-copy so mutating merged.overall.score below does not corrupt
        # results[0].overall.score (Pydantic v2's default model_copy is shallow,
        # which would otherwise alias the same MetricResult object).
        merged = base.model_copy(update=majority_metrics, deep=True)
        # Drive the overall score deterministically from the merged metric
        # pattern: use the ceiling of the band that pattern warrants.
        # `constrained_overall_score()` clamps the LLM-generated overall
        # score, but that LLM score is itself non-deterministic across
        # consensus passes, so identical metric patterns could yield
        # different final overall scores (e.g. 0.96 vs 0.99 → ACCEPTABLE
        # vs SUPERIOR) — the cross-run verdict instability the issue #392
        # flip target is trying to catch. The ceiling is uniquely
        # determined by the metric pattern, so the final score is stable
        # across runs whenever the consensus-voted metrics are stable.
        _floor, ceiling = merged.overall_score_bounds()
        merged.overall.score = ceiling
        return merged

    async def _run_consensus_evaluation(
        self,
        content: str,
        n: int,
        **kwargs,
    ) -> ArticleEvaluationResult:
        """Run the article evaluator N times sequentially and merge via majority vote.

        Sequential execution avoids exhausting the caller's concurrency budget
        (each consensus run is a full LLM evaluation).  For a stability script
        with MAX_CONCURRENT=10, sequential inner runs keep throughput at
        ~10 items in parallel instead of ~3.
        """
        merged, _ = await self._run_consensus_with_detail(content, n, **kwargs)
        return merged

    async def _run_consensus_with_detail(
        self,
        content: str,
        n: int,
        **kwargs,
    ) -> tuple[ArticleEvaluationResult, list[ArticleEvaluationResult]]:
        """Run consensus N times and return both merged result + raw per-run results.

        Applies the deterministic post-LLM guards (stimulus_quality,
        math factual_accuracy) to EACH raw run before merging, so that
        cross-run output is stable when programmatic checks are unanimous —
        e.g. a content with inline images gets stimulus_quality=1.0 every
        raw run, eliminating noise that would otherwise propagate through
        consensus voting.

        Returns both the merged consensus and the raw guarded per-run
        results, so stability analyses see what consensus actually voted
        on rather than the unfiltered LLM output.
        """
        from .guards import guard_math_factual_accuracy, guard_stimulus_quality

        math_context = _math_context_var.get() or ""

        logger.info("Running article evaluation consensus: %d sequential runs", n)
        results: list[ArticleEvaluationResult] = []
        for i in range(n):
            logger.debug("Consensus run %d/%d", i + 1, n)
            raw = await super().evaluate(content, **kwargs)
            raw = guard_stimulus_quality(raw, content)
            raw = guard_math_factual_accuracy(raw, content, math_context)
            results.append(raw)
        merged = self._merge_consensus_results(results)
        return merged, results

    def _load_prompt(self) -> str:
        """Load the base article evaluation prompt."""
        return self._load_prompt_from_file(PROMPTS_DIR / "_base_evaluation.txt")

    def _load_overlay(self, filename: str) -> Optional[str]:
        """Load and cache a subject overlay prompt."""
        if filename not in self._overlay_cache:
            path = PROMPTS_DIR / filename
            if path.exists():
                self._overlay_cache[filename] = self._load_prompt_from_file(path)
            else:
                logger.warning(f"Article subject overlay not found: {path}")
                return None
        return self._overlay_cache.get(filename)

    def _detect_subject(
        self,
        request_metadata: Optional[RequestMetadata],
        curriculum: str = "",
    ) -> Optional[str]:
        """Detect subject key for selecting an overlay."""
        subject_text = (request_metadata.subject or "").strip().lower() if request_metadata else ""
        # Normalize common separators so values like "social-studies" route correctly.
        normalized_subject_text = subject_text.replace("-", " ").replace("_", " ")
        curriculum_text = (curriculum or "").strip().lower()

        for subject_key in SUBJECT_PROMPT_MAP:
            if subject_key in normalized_subject_text or subject_key in curriculum_text:
                return subject_key
        return None

    def _get_combined_prompt(self, subject_key: Optional[str]) -> str:
        """Build base + subject overlay prompt."""
        overlay_filename = (
            SUBJECT_PROMPT_MAP.get(subject_key, DEFAULT_OVERLAY)
            if subject_key
            else DEFAULT_OVERLAY
        )
        overlay = self._load_overlay(overlay_filename)
        if overlay:
            return self.prompt_template + "\n\n" + overlay
        logger.warning(
            f"Could not load article overlay for subject '{subject_key}', using base prompt only"
        )
        return self.prompt_template

    async def _fetch_wiki_for_evaluator(
        self,
        content: str,
        request_metadata: Optional[RequestMetadata] = None,
    ) -> str:
        """Fetch Wikipedia passages and format as reference material for the evaluator.

        Uses a content-hash cache: first evaluation pays the LLM + Wikipedia cost,
        all subsequent evaluations of the same article are instant.
        """
        import hashlib
        import os

        cache_key = hashlib.sha256(content.encode()).hexdigest()[:16]
        cached_context = self._get_wiki_context_from_memory(cache_key)
        if cached_context is not None:
            return cached_context

        try:
            disk_path = _wiki_context_disk_path(cache_key)
            if disk_path.exists():
                cached = disk_path.read_text(encoding="utf-8")
                self._remember_wiki_context(cache_key, cached)
                return cached
        except Exception as e:
            logger.debug("Failed to read wiki context cache: %s", e)

        from inceptbench.tools.wiki_retriever import (
            _select_wiki_variant,
            extract_multiple_search_terms,
            fetch_wikipedia_passages,
        )

        try:
            grade = getattr(request_metadata, "grade", None) if request_metadata else None
            wiki_variant = _select_wiki_variant(str(grade) if grade is not None else None)
            search_terms = await extract_multiple_search_terms(content)
            if not search_terms:
                result = ""
                self._remember_wiki_context(cache_key, result)
                _save_wiki_context_disk(cache_key, result)
                return result

            per_query_budget = 3000 // max(len(search_terms), 1)
            fetches = [
                fetch_wikipedia_passages(term, variant=wiki_variant, max_tokens=per_query_budget)
                for term in search_terms[:3]
            ]
            results = await asyncio.gather(*fetches, return_exceptions=True)
            passages = [r for r in results if isinstance(r, str) and r]
            if not passages:
                result = ""
                self._remember_wiki_context(cache_key, result)
                _save_wiki_context_disk(cache_key, result)
                return result

            combined = "\n\n---\n\n".join(passages)
            result = (
                "## WIKIPEDIA REFERENCE MATERIAL (for factual cross-check)\n\n"
                "The following Wikipedia passages are provided as factual reference. "
                "Use them to verify claims in the article content:\n"
                "- If a passage **directly contradicts** a factual claim, "
                "score `factual_accuracy = 0.0`.\n"
                "- If passages do not address a claim, rely on your own knowledge.\n"
                "- Do NOT penalize correct content just because Wikipedia doesn't mention it.\n\n"
                f"[WIKIPEDIA PASSAGES]\n{combined}\n[/WIKIPEDIA PASSAGES]"
            )
            self._remember_wiki_context(cache_key, result)
            _save_wiki_context_disk(cache_key, result)
            return result
        except Exception as e:
            logger.warning("Wikipedia fetch for article evaluator failed: %s", e)
            return ""

    # Metrics that are only valid for DI (non-SS) articles
    _DI_ONLY_METRICS = ("follows_direct_instruction", "worked_examples", "practice_problems")
    # Derived automatically from SUBJECT_PROMPT_MAP: any overlay that is NOT the
    # DEFAULT_OVERLAY is considered a non-DI (e.g. social-studies) overlay, and
    # articles using it will have DI-only metrics nulled in post-processing.
    # No manual sync required — adding a new entry to SUBJECT_PROMPT_MAP is sufficient.
    _SS_OVERLAY_FILENAMES: frozenset = frozenset(
        v for v in SUBJECT_PROMPT_MAP.values() if v != DEFAULT_OVERLAY
    )

    async def evaluate(self, content: str, **kwargs) -> ArticleEvaluationResult:
        """
        Evaluate an educational article.

        Selects the prompt overlay based on detected subject metadata.
        For social-studies subjects, DI-specific metrics are nulled out in
        post-processing so they do not appear in evaluation results.

        Runs the evaluator with optional N-run consensus voting. Single-run
        evaluations apply shared deterministic guards after the LLM call;
        consensus evaluations apply them to each raw run before voting.
        """
        request_metadata = kwargs.get("request_metadata")
        curriculum = kwargs.get("curriculum", "")
        prompt_override = kwargs.get("prompt_override")

        # Always detect subject so DI-metric nulling works even when prompt_override
        # is pre-supplied by the caller.  When a prompt_override is provided we skip
        # building the combined prompt (that work is already done) but we still need
        # subject_key to decide whether to clear DI metrics in post-processing.
        subject_key: Optional[str] = self._detect_subject(request_metadata, curriculum)
        if not prompt_override:
            prompt_override = self._get_combined_prompt(subject_key)
            kwargs["prompt_override"] = prompt_override

            if subject_key:
                overlay_file = SUBJECT_PROMPT_MAP.get(subject_key, DEFAULT_OVERLAY)
                logger.info(f"Using article base + {overlay_file} for subject: {subject_key}")
            else:
                logger.info(f"Using article base + {DEFAULT_OVERLAY} (default overlay)")

        # Precompute math verification context ONCE per request and store in a
        # per-task ContextVar so it can be shared with _get_programmatic_context
        # (inherited by gathered child tasks) and the post-evaluation guard below
        # without a second SymPy round-trip and without any singleton-instance race.
        # Skip math verification for non-math subjects — social-studies articles
        # contain no verifiable math and the BAML extraction call is expensive
        # and occasionally hangs on non-mathematical content.
        is_math_subject = False
        if request_metadata and getattr(request_metadata, "subject", None):
            is_math_subject = "math" in (request_metadata.subject or "").lower()

        use_wiki = os.environ.get("EVALUATOR_USE_WIKIPEDIA", "").strip().lower() in ("1", "true", "yes")
        is_social_studies = subject_key is not None and (
            SUBJECT_PROMPT_MAP.get(subject_key, DEFAULT_OVERLAY) in self._SS_OVERLAY_FILENAMES
        )

        from inceptbench.tools.math_verifier import extract_and_verify_math

        # Wikipedia enrichment is scoped to social-studies subjects only — math
        # and DI articles have their own factual paths and don't benefit from
        # Wikipedia passages.
        want_wiki = use_wiki and is_social_studies
        if is_math_subject and want_wiki:
            math_context, wiki_context = await asyncio.gather(
                extract_and_verify_math(content),
                self._fetch_wiki_for_evaluator(content, request_metadata),
            )
        elif is_math_subject:
            math_context = await extract_and_verify_math(content)
            wiki_context = ""
        elif want_wiki:
            math_context = ""
            wiki_context = await self._fetch_wiki_for_evaluator(content, request_metadata)
        else:
            math_context = ""
            wiki_context = ""

        ctx_token = _math_context_var.set(math_context)
        wiki_ctx_token = _wiki_context_var.set(wiki_context)

        from inceptbench.tools.factual_accuracy_audit import (
            apply_factual_audit_to_article_result,
            run_consensus_factual_accuracy_audit_for_article,
            should_run_audit,
        )

        try:
            n = self._get_consensus_runs()
            guards_already_applied = n > 1
            if n <= 1:
                if not should_run_audit(request_metadata):
                    result: ArticleEvaluationResult = await super().evaluate(content, **kwargs)
                else:
                    result, factual_audit = await asyncio.gather(
                        super().evaluate(content, **kwargs),
                        run_consensus_factual_accuracy_audit_for_article(
                            self,
                            content=content,
                            curriculum=curriculum,
                            full_context=kwargs.get("full_context"),
                            subcontent_results=kwargs.get("subcontent_results"),
                            request_metadata=request_metadata,
                            analyzed_image_urls=kwargs.get("analyzed_image_urls"),
                            curriculum_version=kwargs.get("curriculum_version"),
                        ),
                    )
                    result = apply_factual_audit_to_article_result(result, factual_audit)
            else:
                # Consensus mode: run the full evaluator N times and majority-vote.
                if not should_run_audit(request_metadata):
                    result = await self._run_consensus_evaluation(content, n, **kwargs)
                else:
                    result, factual_audit = await asyncio.gather(
                        self._run_consensus_evaluation(content, n, **kwargs),
                        run_consensus_factual_accuracy_audit_for_article(
                            self,
                            content=content,
                            curriculum=curriculum,
                            full_context=kwargs.get("full_context"),
                            subcontent_results=kwargs.get("subcontent_results"),
                            request_metadata=request_metadata,
                            analyzed_image_urls=kwargs.get("analyzed_image_urls"),
                            curriculum_version=kwargs.get("curriculum_version"),
                        ),
                    )
                    result = apply_factual_audit_to_article_result(result, factual_audit)
        finally:
            _math_context_var.reset(ctx_token)
            _wiki_context_var.reset(wiki_ctx_token)

        # For social-studies articles, null out DI-only metrics.
        # The SS overlay's output schema does not include these fields, but the BAML
        # model still accepts them if the LLM outputs them.  Clearing them here
        # ensures callers never see spurious DI scores on SS content.
        if subject_key is not None and (
            SUBJECT_PROMPT_MAP.get(subject_key, DEFAULT_OVERLAY) in self._SS_OVERLAY_FILENAMES
        ):
            for metric_name in self._DI_ONLY_METRICS:
                if getattr(result, metric_name, None) is not None:
                    setattr(result, metric_name, None)
                    logger.debug(
                        "Cleared DI-only metric '%s' for SS article (subject=%s)",
                        metric_name,
                        subject_key,
                    )

        if not guards_already_applied:
            # Apply shared deterministic guards for the single-run path.
            # Consensus mode applies these to every raw run before voting.
            from .guards import guard_math_factual_accuracy, guard_stimulus_quality

            result = guard_stimulus_quality(result, content)
            result = guard_math_factual_accuracy(result, content, math_context)

        # Recompute overall after any deterministic overrides — use the
        # band ceiling for the merged metric pattern so the final score is
        # deterministic and identical across consensus passes with the
        # same metric outcomes.
        _floor, _ceiling = result.overall_score_bounds()
        result.overall.score = _ceiling

        return result

    def _get_result_model(self) -> type[BaseEvaluationResult]:
        """Return the article evaluation result model."""
        return ArticleEvaluationResult

    async def _get_programmatic_context(
        self,
        content: str,
        curriculum: str = "",
        request_metadata=None,
        full_context=None,
    ) -> str:
        """Return deterministic context (math + optional Wikipedia) for the system prompt.

        Both math verification and Wikipedia passages are precomputed once at the
        top of ``evaluate()`` and stored in per-task ``ContextVar``s so they can
        be reused for the system prompt without redundant LLM / SymPy round-trips
        and without singleton-instance race conditions under concurrent load.

        Falls back to direct calls when the ContextVars are unset (e.g. callers
        that invoke ``BaseEvaluator.evaluate()`` directly without going through
        ``ArticleEvaluator.evaluate()``).
        """
        del curriculum, full_context

        parts: list[str] = []

        math_cached = _math_context_var.get()
        if math_cached is not None:
            parts.append(math_cached)
        else:
            # Fallback: only run math verification if subject looks like math.
            is_math = False
            if request_metadata and getattr(request_metadata, "subject", None):
                is_math = "math" in (request_metadata.subject or "").lower()
            if is_math:
                from inceptbench.tools.math_verifier import extract_and_verify_math
                parts.append(await extract_and_verify_math(content))
            else:
                parts.append("")

        # Skip wiki when called from the factual audit — its RAG preamble
        # carries its own Wikipedia passages, so appending here would double
        # the passages in the audit's system prompt.
        if _suppress_wiki_in_programmatic_context.get():
            return "\n\n".join(parts)

        wiki_cached = _wiki_context_var.get()
        if wiki_cached is not None:
            if wiki_cached:
                parts.append(wiki_cached)
        elif request_metadata is not None:
            # Fallback: compute directly if ContextVar was not set (e.g. direct
            # BaseEvaluator.evaluate() callers). Only runs when the env flag is
            # explicitly enabled to avoid unexpected LLM / network overhead.
            use_wiki = os.environ.get("EVALUATOR_USE_WIKIPEDIA", "").strip().lower() in (
                "1", "true", "yes",
            )
            if use_wiki:
                subject_text = (request_metadata.subject or "").strip().lower()
                is_ss = any(sk in subject_text for sk in SUBJECT_PROMPT_MAP)
                if is_ss:
                    wiki_ctx = await self._fetch_wiki_for_evaluator(content, request_metadata)
                    if wiki_ctx:
                        parts.append(wiki_ctx)

        return "\n\n".join(parts)
