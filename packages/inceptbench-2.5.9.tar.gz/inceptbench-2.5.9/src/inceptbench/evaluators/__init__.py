"""
Evaluators package for educational content evaluation.

This package provides evaluators for different content types:
- Questions (MCQ, SAQ, LEQ, DBQ, fill-in, etc.)
- Quizzes (collections of questions, including MCQ sets)
- Reading passages (fiction and non-fiction)
- Articles
- Other educational content
"""

from .base import BaseEvaluator
from .question import QuestionEvaluator
from .quiz import QuizEvaluator
from .fiction_reading import FictionReadingEvaluator
from .nonfiction_reading import NonfictionReadingEvaluator
from .article import ArticleEvaluator
from .other import OtherEvaluator

__all__ = [
    "BaseEvaluator",
    "QuestionEvaluator",
    "QuizEvaluator",
    "FictionReadingEvaluator",
    "NonfictionReadingEvaluator",
    "ArticleEvaluator",
    "OtherEvaluator",
]
