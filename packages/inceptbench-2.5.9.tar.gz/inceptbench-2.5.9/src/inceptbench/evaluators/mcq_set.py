"""
MCQ set evaluator for educational content.

This module provides an evaluator for MCQ sets (stimulus-based question sets
with 3-5 questions sharing a single stimulus).

Unlike quizzes, MCQ sets expect UNIFORM difficulty - all questions should be
at the same appropriate difficulty level.
"""

import asyncio
import logging
from pathlib import Path

from scipy.stats import chisquare

from inceptbench.evaluators.base import BaseEvaluator
# LLMFactory and LLMMessage no longer needed — answer_balance uses BAML (ExtractAnswerBalance)
from inceptbench.models import BaseEvaluationResult, MetricResult, McqSetEvaluationResult
from inceptbench.observability import observe

logger = logging.getLogger(__name__)


class McqSetEvaluator(BaseEvaluator):
    """
    Evaluator for MCQ sets (stimulus-based question sets).

    MCQ sets are small question sets (3-5 questions) sharing a single stimulus.
    Unlike quizzes, MCQ sets expect UNIFORM difficulty.

    Uses the same metrics as quizzes, but the evaluation prompt interprets them
    differently (e.g., uniform difficulty is acceptable for MCQ sets):
    - overall (continuous [0.0, 1.0])
    - factual_accuracy (binary)
    - educational_accuracy (binary)
    - stimulus_quality (binary) - all questions must require the stimulus
    - concept_coverage (binary)
    - difficulty_distribution (binary) - uniform difficulty is acceptable
    - non_repetitiveness (binary)
    - test_preparedness (binary)
    - answer_balance (binary) - computed programmatically
    - integrity_check (binary)
    """

    def _load_prompt(self) -> str:
        """Load the MCQ set evaluation prompt from file."""
        prompt_path = Path(__file__).parent.parent / "prompts" / "mcq_set" / "evaluation.txt"
        return self._load_prompt_from_file(prompt_path)

    def _get_result_model(self) -> type[BaseEvaluationResult]:
        """Return the McqSetEvaluationResult model."""
        return McqSetEvaluationResult

    @observe(name="calculate_answer_balance_mcq_set")
    async def _calculate_answer_balance(self, content: str) -> MetricResult:
        """
        Calculate answer balance using chi-square goodness of fit test.

        Args:
            content: The MCQ set content

        Returns:
            MetricResult with binary score (1.0 if balanced, 0.0 if not)
        """
        try:
            # Extract answer choices via BAML (structured, no raw text parsing)
            from baml_client import b as _baml
            system_prompt = "Extract the correct answer key for each question. Return structured data."
            baml_result = await _baml.ExtractAnswerBalance(system_prompt, content)

            # Convert BAML result to answer_data format:
            # list of dicts like {"A": "incorrect", "B": "correct", ...}
            answer_data = [
                {k: ("correct" if k == choice.correct_key else "incorrect") for k in choice.all_keys}
                for choice in baml_result.choices
            ]

            if not answer_data:
                return MetricResult(
                    score=1.0,
                    reasoning="Could not extract answer choices for balance analysis. Defaulting to pass."
                )

            # Find correct answer positions
            correct_positions = []
            for q in answer_data:
                if not isinstance(q, dict):
                    continue
                for i, (key, value) in enumerate(q.items()):
                    if isinstance(value, str) and value.lower() == "correct":
                        correct_positions.append(i)
                        break

            if not correct_positions:
                return MetricResult(
                    score=1.0,
                    reasoning="No valid correct answers found. Defaulting to pass."
                )

            # Group by number of choices
            choice_groups = {}
            for q, pos in zip(answer_data, correct_positions):
                n_choices = len(q)
                if n_choices not in choice_groups:
                    choice_groups[n_choices] = []
                choice_groups[n_choices].append(pos)

            # Calculate chi-square
            p_values = []
            observed_distributions = {}

            for n_choices, positions in choice_groups.items():
                observed = [positions.count(i) for i in range(n_choices)]
                expected = [len(positions) / n_choices] * n_choices

                try:
                    stat, p_value = chisquare(observed, expected)
                    p_values.append(p_value)
                    observed_distributions[n_choices] = {
                        'positions': observed,
                        'p_value': p_value
                    }
                except Exception as e:
                    logger.warning(f"Chi-square calculation failed: {e}")

            p_value = min(p_values) if p_values else 1.0
            score = 1.0 if p_value >= 0.60 else 0.0

            # Build explanation
            distributions = []
            for n_choices, data in observed_distributions.items():
                dist_str = (
                    f"Questions with {n_choices} choices: "
                    f"correct answer distribution {data['positions']}, "
                    f"probability random: {data['p_value']*100:.1f}%"
                )
                distributions.append(dist_str)

            reasoning = (
                "Answer distribution:\n" +
                "\n".join(distributions) +
                f"\n\nOverall probability distribution is random: {p_value*100:.1f}%. "
            )

            if score == 1.0:
                reasoning += "Distribution is well-balanced."
            else:
                reasoning += "Distribution shows exploitable patterns."

            suggested_improvements = None if score == 1.0 else (
                "Redistribute correct answers across positions A, B, C, D."
            )

            return MetricResult(
                score=score,
                reasoning=reasoning,
                suggested_improvements=suggested_improvements
            )

        except Exception as e:
            logger.error(f"Error calculating answer balance: {e}")
            return MetricResult(
                score=1.0,
                reasoning=f"Error calculating answer balance: {str(e)}. Defaulting to pass."
            )

    async def _get_programmatic_context(self, content: str, curriculum: str = "", request_metadata=None, full_context=None) -> str:
        """
        Provide answer balance analysis for MCQ sets.

        Args:
            content: The MCQ set content

        Returns:
            Formatted answer balance analysis context
        """
        answer_balance_result = await self._calculate_answer_balance(content)

        return f"""

Answer Balance Analysis (Pre-computed via chi-squared statistical analysis):
Score: {answer_balance_result.score}
{answer_balance_result.reasoning}

Use this answer balance data for the Answer Balance metric. You MUST use the
provided score ({answer_balance_result.score}) exactly.
"""
