"""
Anchor-based content slicing for the decomposer.

Why this exists
---------------
When the decomposer LLM is asked to "extract verbatim text" of a child node,
it routinely paraphrases rich stimuli — `<img src="...">` becomes
"[Image: ...]", `<svg>` blocks become text descriptions, `<table>` becomes a
bulleted list. The downstream evaluator then runs a programmatic stimulus
check on the paraphrased text, finds no real image, and scores
`stimulus_quality = 0.0` even though the source had the image inline.

Solution
--------
The decomposer LLM returns short verbatim `start_anchor` / `end_anchor`
substrings instead. This module slices the ORIGINAL source buffer between
those anchors — so every byte (image URLs of any format, inline SVG, tables,
LaTeX, markdown, base64 data URIs, …) is preserved untouched.

Design choices
~~~~~~~~~~~~~~
- Whitespace-tolerant matching: the LLM tends to normalize ``\\r\\n`` →
  ``\\n`` and collapse whitespace. We match against a normalized projection
  of the source while keeping an offset map back to the original buffer.
- Occurrence index disambiguates duplicate anchors (e.g., "Is this shape a
  rhombus?" appears in both the example and practice sections).
- Failure is non-fatal: if anchors don't match, the caller falls back to the
  LLM's free-text `extracted_content`. Each failure is logged so we can
  monitor decomposer drift.
"""

from __future__ import annotations

import logging
import re
import unicodedata
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)

# Anchors shorter than this are rejected outright. The decomposition prompt
# and BAML schema instruct the LLM to pick anchors of 40–120 chars; we keep a
# small safety margin below that floor (rather than the full 40) so that
# legitimate slightly-trimmed anchors still match, but not so low that short
# headings like "Practice Section" can produce silently-wrong slices on
# longer articles where they appear multiple times.
MIN_ANCHOR_LEN = 30

# Minimum length of the prefix/suffix used by the soft-anchor fallback path.
# Lower than ``MIN_ANCHOR_LEN`` because we only use this when both the exact
# and whitespace-normalized paths have failed — we want some chance of
# recovering a sensible slice instead of dropping straight to the LLM's
# (often paraphrased) ``extracted_content`` field. Keep it just above the
# floor where headings start to recur ambiguously.
_SOFT_ANCHOR_PREFIX_LEN = 24

_WS_RE = re.compile(r"\s+")


def _unicode_fold(text: str) -> str:
    """Map common LLM-normalised character variants back to ASCII-ish forms.

    The decomposer LLM frequently substitutes:
    - smart quotes / typographic apostrophes → ASCII quotes
    - en-/em-dashes (and minus signs) → ASCII hyphen-minus
    - non-breaking spaces → regular space

    Normalising both the source and the anchors lets the whitespace-normalised
    matcher succeed in cases where it would otherwise drop through to the
    paraphrased fallback text.
    """
    if not text:
        return text
    # NFKC handles many compatibility forms (e.g. full-width / ligatures).
    folded = unicodedata.normalize("NFKC", text)
    # Quotes — straight & curly, double & single, and the prime variants.
    folded = folded.translate(
        {
            0x2018: ord("'"),
            0x2019: ord("'"),
            0x201A: ord("'"),
            0x201B: ord("'"),
            0x2032: ord("'"),
            0x201C: ord('"'),
            0x201D: ord('"'),
            0x201E: ord('"'),
            0x201F: ord('"'),
            0x2033: ord('"'),
            # Dashes — en-, em-, minus, hyphen-minus variants.
            0x2010: ord("-"),
            0x2011: ord("-"),
            0x2012: ord("-"),
            0x2013: ord("-"),
            0x2014: ord("-"),
            0x2015: ord("-"),
            0x2212: ord("-"),
            # Spaces — NBSP / narrow NBSP / zero-width.
            0x00A0: ord(" "),
            0x202F: ord(" "),
            0x200B: 0x20,
            0xFEFF: 0x20,
        }
    )
    return folded


@dataclass(frozen=True)
class AnchorSliceResult:
    sliced_content: str
    # "exact" | "whitespace_normalized" | "unicode_folded" | "soft_prefix"
    method: str
    start_offset: int
    end_offset: int


def _normalize_with_offset_map(text: str) -> tuple[str, list[int]]:
    """Collapse whitespace, returning the normalized string plus a map from
    each normalized index to the original index."""
    norm_chars: list[str] = []
    offset_map: list[int] = []
    in_ws = False
    for i, ch in enumerate(text):
        if ch.isspace():
            if not in_ws and norm_chars:
                norm_chars.append(" ")
                offset_map.append(i)
            in_ws = True
        else:
            norm_chars.append(ch)
            offset_map.append(i)
            in_ws = False
    return "".join(norm_chars), offset_map


def _find_nth(haystack: str, needle: str, occurrence: int) -> int:
    """Return the start index of the Nth (1-indexed) occurrence, or -1."""
    if occurrence < 1:
        occurrence = 1
    pos = -1
    for _ in range(occurrence):
        pos = haystack.find(needle, pos + 1)
        if pos == -1:
            return -1
    return pos


def slice_by_anchors(
    source: str,
    start_anchor: Optional[str],
    end_anchor: Optional[str],
    occurrence: Optional[int] = 1,
) -> Optional[AnchorSliceResult]:
    """Slice ``source`` between the two anchors and return the byte-exact
    substring, or ``None`` if either anchor cannot be located.

    The returned slice is ``source[start_anchor_start : end_anchor_end]`` —
    inclusive of both anchors, so any stimulus inside the bracketed region
    (images, SVG, tables, etc.) is preserved verbatim.

    Known limitation (whitespace-normalized path only): when an LLM-supplied
    anchor ends at a non-whitespace character but the original source has
    trailing whitespace immediately after that character (e.g., source
    ``"</div>  \\n"`` with ``end_anchor="</div>"``), the slice ends at the
    last non-whitespace character. The trailing source whitespace is not
    included in the returned slice. This is fine for stimulus-preservation
    because every byte BETWEEN the anchors is preserved; only bytes strictly
    AFTER the end anchor are excluded.
    """
    if not source or not start_anchor or not end_anchor:
        return None

    if (
        len(start_anchor.strip()) < MIN_ANCHOR_LEN
        or len(end_anchor.strip()) < MIN_ANCHOR_LEN
    ):
        return None

    occ = occurrence if occurrence and occurrence > 0 else 1

    # 1) Exact match against the raw source — fastest path.
    exact_start_idx = _find_nth(source, start_anchor, occ)
    if exact_start_idx != -1:
        end_search_from = exact_start_idx + len(start_anchor)
        end_idx = source.find(end_anchor, end_search_from)
        if end_idx != -1:
            end_offset = end_idx + len(end_anchor)
            return AnchorSliceResult(
                sliced_content=source[exact_start_idx:end_offset],
                method="exact",
                start_offset=exact_start_idx,
                end_offset=end_offset,
            )

    # 2) Whitespace-tolerant match — the LLM may have normalized \r\n / runs
    #    of spaces. Search in the normalized projection, then map both ends
    #    back to original-source offsets so the slice still includes the raw
    #    HTML / markdown bytes between them.
    norm_source, offset_map = _normalize_with_offset_map(source)
    norm_start = _WS_RE.sub(" ", start_anchor).strip()
    norm_end = _WS_RE.sub(" ", end_anchor).strip()
    if not norm_start or not norm_end:
        return None

    ws_result = _try_match(
        source,
        norm_source,
        offset_map,
        norm_start,
        norm_end,
        occ,
        exact_start_idx,
        method="whitespace_normalized",
    )
    if ws_result is not None:
        return ws_result

    # 3) Unicode-folded match — recover when the LLM substituted curly quotes,
    #    em-/en-dashes, NBSP, etc. in its anchor strings. We fold BOTH the
    #    source and the anchors, then reuse the whitespace-normalised matcher.
    #
    #    NFKC is NOT length-preserving in general (e.g. ``"½"`` expands to
    #    ``"1⁄2"``). When folding changes the source length, the offset map
    #    built against the folded buffer cannot be used to slice the raw
    #    source — every offset past the expansion is shifted. To stay safe
    #    without inventing a folded→raw offset projection, we only activate
    #    this tier when folding preserves length, which is the common case
    #    for the typographic substitutions the LLM actually performs
    #    (curly quotes, en/em/minus dashes, NBSP).
    folded_source = _unicode_fold(source)
    norm_folded_start = _WS_RE.sub(" ", _unicode_fold(start_anchor)).strip()
    norm_folded_end = _WS_RE.sub(" ", _unicode_fold(end_anchor)).strip()
    # Activate when folding preserved length AND folding changed either the
    # source or an anchor — the folded_source != source requirement was overly
    # restrictive for ASCII-clean sources with typographic LLM anchors.
    _anchor_folding_changed = (
        norm_folded_start != norm_start or norm_folded_end != norm_end
    )
    if len(folded_source) == len(source) and (
        folded_source != source or _anchor_folding_changed
    ):
        norm_folded_source, folded_offset_map = _normalize_with_offset_map(folded_source)
        if norm_folded_start and norm_folded_end:
            uf_result = _try_match(
                source,
                norm_folded_source,
                folded_offset_map,
                norm_folded_start,
                norm_folded_end,
                occ,
                exact_start_idx,
                method="unicode_folded",
            )
            if uf_result is not None:
                return uf_result

    # 4) Soft-prefix fallback — the LLM's full anchor strings did not match
    #    even under whitespace/unicode normalisation, but a shorter unique
    #    prefix may still locate the region reliably. We keep this last so
    #    only genuinely-broken anchors hit it; legitimate slices still go
    #    through the exact-match fast path above. BOTH the start and end
    #    soft anchors must be unique in the normalised source so we never
    #    silently truncate the region when an end-anchor suffix recurs
    #    (e.g. repeated "the answer key for Problem N" lines).
    soft_start = norm_start[:_SOFT_ANCHOR_PREFIX_LEN]
    soft_end = norm_end[-_SOFT_ANCHOR_PREFIX_LEN:]
    if (
        len(soft_start) >= _SOFT_ANCHOR_PREFIX_LEN
        and len(soft_end) >= _SOFT_ANCHOR_PREFIX_LEN
        and norm_source.count(soft_start) == 1
        and norm_source.count(soft_end) == 1
    ):
        soft_result = _try_match(
            source,
            norm_source,
            offset_map,
            soft_start,
            soft_end,
            occ=1,
            exact_start_idx=-1,
            method="soft_prefix",
        )
        if soft_result is not None:
            logger.info(
                "Anchor slicer recovered via soft-prefix fallback "
                "(start='%s...', end='...%s'). The LLM-supplied anchors did "
                "not match exactly; verify decomposer prompt fidelity.",
                soft_start, soft_end,
            )
            return soft_result

    return None


def _try_match(
    source: str,
    norm_source: str,
    offset_map: list[int],
    norm_start: str,
    norm_end: str,
    occ: int,
    exact_start_idx: int,
    *,
    method: str,
) -> Optional[AnchorSliceResult]:
    """Shared body of the ws-normalised / unicode-folded / soft-prefix paths."""
    n_start = _find_nth(norm_source, norm_start, occ)
    if n_start == -1:
        return None
    n_end = norm_source.find(norm_end, n_start + len(norm_start))
    if n_end == -1:
        return None
    n_end_inclusive = n_end + len(norm_end) - 1

    if n_start >= len(offset_map) or n_end_inclusive >= len(offset_map):
        return None

    # If the start anchor matched exactly upstream but only the end fell back
    # to a normalised path, prefer the confirmed exact start offset so we do
    # not silently trim leading whitespace that the LLM included verbatim in
    # ``start_anchor`` (offset_map maps to the first non-whitespace char).
    if exact_start_idx != -1:
        raw_start = exact_start_idx
    else:
        raw_start = offset_map[n_start]
    raw_end_inclusive = offset_map[n_end_inclusive]
    raw_end = raw_end_inclusive + 1
    if raw_end <= raw_start:
        return None

    return AnchorSliceResult(
        sliced_content=source[raw_start:raw_end],
        method=method,
        start_offset=raw_start,
        end_offset=raw_end,
    )
