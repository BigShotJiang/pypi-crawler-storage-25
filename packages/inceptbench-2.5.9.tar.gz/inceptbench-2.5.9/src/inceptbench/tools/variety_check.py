"""
Standalone variety check utilities.

This module ports the benchmark worker's variety-check behavior with minimal
adaptation for Python usage in inceptbench.
"""

from __future__ import annotations

import asyncio
import re
import time
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Dict, Optional

import httpx

# Variety check configuration (parity with benchmark worker)
REQUESTS_PER_SUBSTANDARD = 10
DEFAULT_CONCURRENCY = 20

# Generator retry configuration (parity with benchmark worker)
MAX_RETRIES = 3
INITIAL_RETRY_DELAY_MS = 1000
REQUEST_TIMEOUT_SECONDS = 10 * 60

GeneratorCallResult = Dict[str, Any]
GeneratorCaller = Callable[[Dict[str, Any], Dict[str, Any], Dict[str, Any]], Awaitable[GeneratorCallResult]]


def extract_text_content(generated_content: Dict[str, Any], content_type: str) -> str:
    """Extract comparable text content from one generator response."""
    try:
        items = generated_content.get("generated_content")
        if not isinstance(items, list) or not items:
            return ""

        content = items[0].get("content") if isinstance(items[0], dict) else None
        if not isinstance(content, dict):
            return ""

        parts = []

        if content_type in ("mcq", "msq"):
            if content.get("question"):
                parts.append(content["question"])
            answer_options = content.get("answer_options")
            if isinstance(answer_options, list):
                for option in answer_options:
                    if isinstance(option, dict) and option.get("text"):
                        parts.append(option["text"])
            if content.get("answer_explanation"):
                parts.append(content["answer_explanation"])
        elif content_type == "fill-in":
            if content.get("question"):
                parts.append(content["question"])
            answers = content.get("answer")
            if isinstance(answers, list):
                for answer in answers:
                    if not isinstance(answer, dict):
                        continue
                    accepted_answers = answer.get("accepted_answers")
                    if isinstance(accepted_answers, list):
                        parts.append(" ".join(str(item) for item in accepted_answers))
                    if answer.get("answer_explanation"):
                        parts.append(answer["answer_explanation"])
        elif content_type == "match":
            if content.get("question"):
                parts.append(content["question"])
            column_a = content.get("column_a")
            if isinstance(column_a, list):
                for item in column_a:
                    if isinstance(item, dict) and item.get("content"):
                        parts.append(item["content"])
            column_b = content.get("column_b")
            if isinstance(column_b, list):
                for item in column_b:
                    if isinstance(item, dict) and item.get("content"):
                        parts.append(item["content"])
            if content.get("answer_explanation"):
                parts.append(content["answer_explanation"])
        elif content_type == "sequence":
            if content.get("question"):
                parts.append(content["question"])
            items_field = content.get("items")
            if isinstance(items_field, list):
                for item in items_field:
                    if isinstance(item, dict) and item.get("content"):
                        parts.append(item["content"])
            if content.get("answer_explanation"):
                parts.append(content["answer_explanation"])
        elif content_type == "article":
            if content.get("content"):
                parts.append(content["content"])
        else:
            if content.get("question"):
                parts.append(content["question"])
            if content.get("content"):
                parts.append(content["content"])
            if content.get("answer_explanation"):
                parts.append(content["answer_explanation"])

        return " ||| ".join(str(part) for part in parts)
    except Exception:
        return ""


def normalize_text(text: str) -> str:
    """Normalize text before trigram comparisons."""
    if not isinstance(text, str) or not text:
        return ""
    normalized = text.lower()
    normalized = re.sub(r"[^\w\s'-]", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized)
    return normalized.strip()


def get_word_trigrams(text: str) -> set[str]:
    """Create word-level trigrams from normalized text."""
    words = [word for word in text.split(" ") if word]
    trigrams: set[str] = set()
    if len(words) < 3:
        if words:
            trigrams.add(" ".join(words))
        return trigrams

    for index in range(0, len(words) - 2):
        trigrams.add(f"{words[index]} {words[index + 1]} {words[index + 2]}")
    return trigrams


def jaccard_distance(set_a: set[str], set_b: set[str]) -> float:
    """Calculate Jaccard distance between two trigram sets."""
    if not set_a and not set_b:
        return 0.0

    smaller, larger = (set_a, set_b) if len(set_a) <= len(set_b) else (set_b, set_a)
    intersection_size = sum(1 for item in smaller if item in larger)
    union_size = len(set_a) + len(set_b) - intersection_size
    if union_size == 0:
        return 0.0
    return 1 - (intersection_size / union_size)


def compute_variety_score(responses: list[Dict[str, Any]], content_type: str) -> Dict[str, Any]:
    """Compute variety score from repeated responses to the same prompt."""
    if not responses or len(responses) <= 1:
        return {"score": 0.0, "uniqueResponses": len(responses) if responses else 0}

    texts = [normalize_text(extract_text_content(response, content_type)) for response in responses]
    unique_texts = set(texts)
    unique_responses = len(unique_texts)

    if all(not text for text in texts):
        return {"score": None, "uniqueResponses": 0}

    trigram_sets = [get_word_trigrams(text) for text in texts]
    total_distance = 0.0
    pair_count = 0
    for i in range(len(trigram_sets)):
        for j in range(i + 1, len(trigram_sets)):
            total_distance += jaccard_distance(trigram_sets[i], trigram_sets[j])
            pair_count += 1

    score = (total_distance / pair_count) if pair_count > 0 else 0.0
    return {"score": round(score, 4), "uniqueResponses": unique_responses}


def compute_variety_score_detailed(responses: list[Dict[str, Any]], content_type: str) -> Dict[str, Any]:
    """
    Compute variety score and return detailed pairwise debug artifacts.

    Includes extracted/normalized texts, trigram sets, and all C(N,2) pair distances.
    """
    if not responses or len(responses) <= 1:
        return {
            "score": 0.0,
            "uniqueResponses": len(responses) if responses else 0,
            "debug": {
                "extracted_texts": [extract_text_content(response, content_type) for response in (responses or [])],
                "normalized_texts": [
                    normalize_text(extract_text_content(response, content_type))
                    for response in (responses or [])
                ],
                "trigrams": [],
                "pairwise_distances": [],
            },
        }

    extracted_texts = [extract_text_content(response, content_type) for response in responses]
    texts = [normalize_text(text) for text in extracted_texts]
    unique_texts = set(texts)
    unique_responses = len(unique_texts)

    if all(not text for text in texts):
        return {
            "score": None,
            "uniqueResponses": 0,
            "debug": {
                "extracted_texts": extracted_texts,
                "normalized_texts": texts,
                "trigrams": [sorted(list(get_word_trigrams(text))) for text in texts],
                "pairwise_distances": [],
            },
        }

    trigram_sets = [get_word_trigrams(text) for text in texts]
    pairwise_distances = []
    total_distance = 0.0
    pair_count = 0
    for i in range(len(trigram_sets)):
        for j in range(i + 1, len(trigram_sets)):
            distance = jaccard_distance(trigram_sets[i], trigram_sets[j])
            pairwise_distances.append(
                {
                    "i": i,
                    "j": j,
                    "distance": round(distance, 4),
                }
            )
            total_distance += distance
            pair_count += 1

    score = (total_distance / pair_count) if pair_count > 0 else 0.0
    return {
        "score": round(score, 4),
        "uniqueResponses": unique_responses,
        "debug": {
            "extracted_texts": extracted_texts,
            "normalized_texts": texts,
            "trigrams": [sorted(list(trigram_set)) for trigram_set in trigram_sets],
            "pairwise_distances": pairwise_distances,
        },
    }


async def call_generator(
    generator_config: Dict[str, Any],
    request_body: Dict[str, Any],
    options: Optional[Dict[str, Any]] = None,
    client: Optional[httpx.AsyncClient] = None,
) -> GeneratorCallResult:
    """Call a generator endpoint with benchmark-parity retry behavior."""
    endpoint_url = generator_config.get("endpoint_url")
    auth_type = generator_config.get("auth_type")
    auth_credential = generator_config.get("auth_credential")

    if not endpoint_url:
        raise ValueError("generator_config.endpoint_url is required")

    headers = {"Content-Type": "application/json"}
    if auth_type == "bearer":
        headers["Authorization"] = f"Bearer {auth_credential}"
    elif auth_type == "x-api-key":
        headers["x-api-key"] = auth_credential

    last_error: Optional[Exception] = None
    for attempt in range(MAX_RETRIES + 1):
        attempt_start = time.perf_counter()
        try:
            if client is None:
                async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT_SECONDS) as owned_client:
                    response = await owned_client.post(
                        endpoint_url, headers=headers, json=request_body
                    )
            else:
                response = await client.post(endpoint_url, headers=headers, json=request_body)

            if response.status_code >= 400:
                error = RuntimeError(
                    f"Generator returned {response.status_code}: {response.text[:200]}"
                )
                setattr(error, "status_code", response.status_code)
                if 500 <= response.status_code < 600 and attempt < MAX_RETRIES:
                    last_error = error
                    await asyncio.sleep((INITIAL_RETRY_DELAY_MS * (2 ** attempt)) / 1000)
                    continue
                raise error

            time_taken = round(time.perf_counter() - attempt_start, 2)
            return {"result": response.json(), "timeTaken": time_taken}
        except httpx.RequestError as exc:
            if attempt < MAX_RETRIES:
                last_error = exc
                await asyncio.sleep((INITIAL_RETRY_DELAY_MS * (2 ** attempt)) / 1000)
                continue
            raise
        except Exception:
            raise

    raise last_error or RuntimeError("Generator request failed after all retries")


class VarietyChecker:
    """Run benchmark-parity variety checks for a set of raw requests."""

    def __init__(
        self,
        generator_config: Dict[str, Any],
        threshold: float = 0.45,
        generator_caller: Optional[GeneratorCaller] = None,
    ) -> None:
        self.generator_config = generator_config
        self.threshold = threshold
        self.generator_caller = generator_caller or call_generator
        configured = int(generator_config.get("concurrency_limit", DEFAULT_CONCURRENCY))
        if configured <= 0:
            raise ValueError("generator_config.concurrency_limit must be > 0")
        self.concurrency = configured

    def collect_requests(self, raw_requests: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """Collect valid requests exactly as provided."""
        request_map: Dict[str, Dict[str, Any]] = {}
        for request_id, request in raw_requests.items():
            if not isinstance(request, dict):
                continue
            skills = request.get("skills")
            substandard_id = skills.get("substandard_id") if isinstance(skills, dict) else None
            request_map[request_id] = {
                "requestId": request_id,
                "request": request,
                "contentType": request.get("type") or "mcq",
                "substandardId": substandard_id,
            }
        return request_map

    async def generate_multiple(
        self,
        request: Dict[str, Any],
        count: int,
        request_id: str,
        client: Optional[httpx.AsyncClient] = None,
    ) -> list[Optional[Dict[str, Any]]]:
        """Call generator repeatedly with batched concurrency and null-on-failure behavior."""
        responses: list[Optional[Dict[str, Any]]] = []
        request_body = {key: value for key, value in request.items() if key != "_metadata"}

        for start in range(0, count, self.concurrency):
            batch_size = min(self.concurrency, count - start)
            batch_tasks = []
            for index in range(batch_size):
                attempt_idx = start + index
                req_id = f"{request_id}-variety-{attempt_idx}"
                batch_tasks.append(
                    self._call_generator_safely(
                        request_body,
                        {"requestId": req_id},
                        client=client,
                    )
                )

            batch_results = await asyncio.gather(*batch_tasks)
            responses.extend(batch_results)
        return responses

    async def _call_generator_safely(
        self,
        request_body: Dict[str, Any],
        options: Dict[str, Any],
        client: Optional[httpx.AsyncClient] = None,
    ) -> Optional[Dict[str, Any]]:
        try:
            if self.generator_caller is call_generator:
                result = await call_generator(
                    self.generator_config,
                    request_body,
                    options,
                    client=client,
                )
            else:
                result = await self.generator_caller(self.generator_config, request_body, options)
            return result["result"]
        except Exception:
            return None

    async def check(
        self,
        raw_requests: Dict[str, Dict[str, Any]],
        on_progress: Optional[Callable[[Dict[str, Any]], Any]] = None,
        include_debug: bool = False,
    ) -> Dict[str, Any]:
        """Run the complete variety check pipeline."""
        request_map = self.collect_requests(raw_requests)
        request_ids = list(request_map.keys())

        if not request_ids:
            return {
                "varietyScore": None,
                "isStatic": None,
                "varietyDetails": {
                    "error": "No valid requests found",
                    "substandards_sampled": 0,
                },
            }

        per_substandard: Dict[str, Any] = {}
        scores: list[float] = []

        # The client is threaded as a local through generate_multiple and
        # _call_generator_safely instead of being stored on self so that
        # concurrent check() calls on the same VarietyChecker instance do
        # not stomp on each other's client and silently close in-flight
        # requests.
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT_SECONDS) as shared_client:
            for request_id_key in request_ids:
                item = request_map[request_id_key]
                request_id = item["requestId"]
                request = item["request"]
                content_type = item["contentType"]
                substandard_id = item["substandardId"]

                try:
                    responses = await self.generate_multiple(
                        request,
                        REQUESTS_PER_SUBSTANDARD,
                        request_id,
                        client=shared_client,
                    )
                    successful_responses = [response for response in responses if response is not None]
                    failures = len(responses) - len(successful_responses)

                    if len(successful_responses) < 2:
                        per_substandard[request_id] = {
                            "score": None,
                            "unique_responses": len(successful_responses),
                            "content_type": content_type,
                            "substandard_id": substandard_id,
                            "sample_request_id": request_id,
                            "generation_failures": failures,
                            "error": "Not enough successful responses",
                        }
                        if include_debug:
                            debug_result = compute_variety_score_detailed(
                                successful_responses, content_type
                            )
                            per_substandard[request_id]["debug"] = {
                                "generated_responses": successful_responses,
                                "extracted_texts": debug_result["debug"]["extracted_texts"],
                                "normalized_texts": debug_result["debug"]["normalized_texts"],
                                "trigrams": debug_result["debug"]["trigrams"],
                                "pairwise_distances": debug_result["debug"]["pairwise_distances"],
                            }
                    else:
                        score_result = (
                            compute_variety_score_detailed(successful_responses, content_type)
                            if include_debug
                            else compute_variety_score(successful_responses, content_type)
                        )
                        per_substandard[request_id] = {
                            "score": score_result["score"],
                            "unique_responses": score_result["uniqueResponses"],
                            "content_type": content_type,
                            "substandard_id": substandard_id,
                            "sample_request_id": request_id,
                            "generation_failures": failures,
                        }
                        if include_debug:
                            per_substandard[request_id]["debug"] = {
                                "generated_responses": successful_responses,
                                "extracted_texts": score_result["debug"]["extracted_texts"],
                                "normalized_texts": score_result["debug"]["normalized_texts"],
                                "trigrams": score_result["debug"]["trigrams"],
                                "pairwise_distances": score_result["debug"]["pairwise_distances"],
                            }
                        if score_result["score"] is not None:
                            scores.append(score_result["score"])
                        else:
                            # score=None with >=2 successes means every response
                            # extracted to an empty string (unexpected content
                            # schema). Surface that explicitly so callers can
                            # distinguish it from the <2-successes branch.
                            per_substandard[request_id]["error"] = (
                                "All extracted texts were empty"
                            )
                except Exception as exc:
                    per_substandard[request_id] = {
                        "score": None,
                        "unique_responses": 0,
                        "content_type": content_type,
                        "substandard_id": substandard_id,
                        "sample_request_id": request_id,
                        "generation_failures": REQUESTS_PER_SUBSTANDARD,
                        "error": str(exc),
                    }

                if on_progress:
                    try:
                        progress_payload = {
                            "completed": len(per_substandard),
                            "total": len(request_ids),
                            "perSubstandard": per_substandard,
                        }
                        progress_result = on_progress(progress_payload)
                        if asyncio.iscoroutine(progress_result):
                            await progress_result
                    except Exception:
                        pass

        variety_score = round(sum(scores) / len(scores), 4) if scores else None
        is_static = (variety_score < self.threshold) if variety_score is not None else None

        variety_details = {
            "threshold": self.threshold,
            "substandards_sampled": len(request_ids),
            "requests_per_substandard": REQUESTS_PER_SUBSTANDARD,
            "total_generation_calls": len(request_ids) * REQUESTS_PER_SUBSTANDARD,
            "computed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "per_substandard": per_substandard,
        }

        return {
            "varietyScore": variety_score,
            "isStatic": is_static,
            "varietyDetails": variety_details,
        }


# JS-parity aliases for users who prefer benchmark naming.
extractTextContent = extract_text_content
normalizeText = normalize_text
getWordTrigrams = get_word_trigrams
jaccardDistance = jaccard_distance
computeVarietyScore = compute_variety_score
