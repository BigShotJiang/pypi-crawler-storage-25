"""
Wikipedia retriever for RAG-based factual accuracy auditing.

Fetches Wikipedia passages for a given query and grade level.
- Grades ≤8: Simple English Wikipedia (curriculum-level language)
- Grades 9+: Full English Wikipedia
- Fallback: if Simple English returns nothing, try full English

Two-layer cache: in-memory dict + persistent JSON disk cache.
Rate limit: 0.1s + jitter delay, semaphore of 20 concurrent calls, 5-retry backoff on 429.
"""

from __future__ import annotations

import asyncio
import json as _json_mod
import logging
import os
import re
from pathlib import Path
from typing import Optional

import requests as _requests

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Two-layer cache: in-memory + persistent disk
# ---------------------------------------------------------------------------
_WIKI_CACHE: dict[tuple[str, str], str] = {}

_DISK_CACHE_DIR = Path(os.environ.get(
    "WIKI_CACHE_DIR",
    Path(__file__).resolve().parent.parent.parent / ".wiki_cache",
))


def _disk_cache_path(query: str, variant: str) -> Path:
    safe = re.sub(r'[^a-zA-Z0-9_-]', '_', f"{query}_{variant}")[:120]
    return _DISK_CACHE_DIR / f"{safe}.json"


def _load_disk_cache(query: str, variant: str) -> Optional[str]:
    p = _disk_cache_path(query, variant)
    if p.exists():
        try:
            data = _json_mod.loads(p.read_text(encoding="utf-8"))
            return data.get("passages", "")
        except Exception:
            return None
    return None


def _save_disk_cache(query: str, variant: str, passages: str) -> None:
    try:
        _DISK_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        _disk_cache_path(query, variant).write_text(
            _json_mod.dumps({"query": query, "variant": variant, "passages": passages}),
            encoding="utf-8",
        )
    except Exception as exc:
        logger.debug("Failed to write wiki disk cache: %s", exc)


_WIKI_BASES = {
    "simple": "https://simple.wikipedia.org",
    "en": "https://en.wikipedia.org",
}

_RATE_LIMIT_DELAY = 0.1  # seconds between cache-miss API calls

# Global semaphore: max concurrent Wikipedia HTTP calls across all eval workers.
# Wikimedia Action API allows up to 200 req/s with a proper User-Agent.
_WIKI_SEMAPHORE = asyncio.Semaphore(20)


# ---------------------------------------------------------------------------
# Grade → Wikipedia variant
# ---------------------------------------------------------------------------

def _select_wiki_variant(grade: str | None) -> str:
    """Grades ≤8 → Simple English Wikipedia; 9+ → full English Wikipedia."""
    if grade is None:
        return "en"
    try:
        return "simple" if int(grade) <= 8 else "en"
    except (ValueError, TypeError):
        return "en"


# ---------------------------------------------------------------------------
# Search term extraction via LLM (small call — cheap model)
# ---------------------------------------------------------------------------

async def extract_search_terms(content: str) -> str:
    """
    Extract Wikipedia search terms from question content using a small LLM call.

    Returns a short query string suitable for Wikipedia search,
    or a plain-text fallback if the LLM call fails.
    """
    terms_list = await extract_multiple_search_terms(content)
    return terms_list[0] if terms_list else ""


async def extract_multiple_search_terms(content: str) -> list[str]:
    """
    Extract 2–3 Wikipedia search queries from full question content.

    Analyzes question stem, answer options, AND explanation to cover
    all factual claims that need verification. Returns a list of
    distinct search queries.
    """
    import json as _json

    text = content
    try:
        obj = _json.loads(content)
        if isinstance(obj, dict):
            parts = []
            if "question" in obj:
                parts.append(f"Question: {obj['question']}")
            if "answer_explanation" in obj:
                parts.append(f"Explanation: {str(obj['answer_explanation'])[:300]}")
            if "answer_options" in obj and isinstance(obj["answer_options"], list):
                opts = "; ".join(
                    str(o.get("text", o)) if isinstance(o, dict) else str(o)
                    for o in obj["answer_options"][:4]
                )
                parts.append(f"Options: {opts[:300]}")
            if "items" in obj and isinstance(obj["items"], list):
                items_text = "; ".join(
                    str(it.get("content", it)) if isinstance(it, dict) else str(it)
                    for it in obj["items"][:6]
                )
                parts.append(f"Items: {items_text[:300]}")
            if parts:
                text = "\n".join(parts)
    except (ValueError, TypeError):
        pass

    text = text[:1200]

    try:
        from inceptbench.llm.factory import LLMFactory
        from inceptbench.llm.base import LLMMessage

        llm = LLMFactory.create("wiki_search")
        messages = [
            LLMMessage(
                role="user",
                content=(
                    "List 2–3 Wikipedia article titles to look up to fact-check ALL claims in this "
                    "educational question (including its answer explanation and options).\n"
                    "Reply with one article title per line (2–5 words each). No numbering, no explanation.\n\n"
                    f"{text}"
                ),
            )
        ]
        result = await llm.generate_text(messages)
        raw_lines = [
            ln.strip().strip("*_`\"'-·•0123456789.)")
            for ln in result.strip().split("\n")
            if ln.strip()
        ]
        terms = [t for t in raw_lines if 2 <= len(t.split()) <= 8 and len(t) > 3]
        if terms:
            logger.debug("LLM search terms for %r: %r", text[:60], terms[:3])
            return terms[:3]
    except Exception as exc:
        logger.debug("LLM term extraction failed (%s), falling back to regex", exc)

    _STOPWORDS = frozenset({
        "a", "an", "the", "in", "on", "at", "to", "for", "of", "and", "or",
        "but", "with", "from", "by", "as", "is", "was", "are", "were", "be",
        "been", "being", "have", "has", "had", "do", "does", "did", "will",
        "would", "could", "should", "may", "might", "shall", "can", "which",
        "that", "this", "these", "those", "it", "its", "they", "their",
        "what", "when", "where", "who", "how", "why", "during", "after",
        "before", "between", "through", "about", "into", "against",
        "select", "all", "following", "apply", "based", "according",
        "describe", "best", "most", "least", "each", "both", "only", "also",
    })
    words = re.findall(r'\b[a-zA-Z]{3,}\b', text)
    content_words = [w for w in words if w.lower() not in _STOPWORDS]
    return [" ".join(content_words[:6])] if content_words else []


# ---------------------------------------------------------------------------
# Wikipedia API fetch
# ---------------------------------------------------------------------------

async def fetch_wikipedia_passages(
    query: str,
    variant: str = "en",
    max_tokens: int = 2000,
    timeout: float = 8.0,
) -> str:
    """
    Fetch relevant Wikipedia passages for a query.

    Returns plain-text passages (intro + most relevant section), or empty
    string if nothing found or any error occurs. Callers treat empty string
    as fail-open → skip audit.

    Args:
        query:      Search terms (from extract_search_terms or manual)
        variant:    "simple" or "en"
        max_tokens: Approximate token budget (1 token ≈ 4 chars)
        timeout:    HTTP timeout in seconds
    """
    cache_key = (query.strip().lower(), variant)
    if cache_key in _WIKI_CACHE:
        logger.debug("Wiki cache hit (memory): %r (%s)", query, variant)
        return _WIKI_CACHE[cache_key]

    disk_hit = _load_disk_cache(query, variant)
    if disk_hit is not None:
        _WIKI_CACHE[cache_key] = disk_hit
        logger.debug("Wiki cache hit (disk): %r (%s), %d chars", query, variant, len(disk_hit))
        return disk_hit

    import random
    async with _WIKI_SEMAPHORE:
        await asyncio.sleep(_RATE_LIMIT_DELAY + random.uniform(0, 0.3))
        return await _fetch_wikipedia_passages_inner(query, variant, max_tokens, timeout, cache_key)


async def _fetch_wikipedia_passages_inner(
    query: str,
    variant: str,
    max_tokens: int,
    timeout: float,
    cache_key: tuple[str, str],
) -> str:
    """Inner fetch — called while holding _WIKI_SEMAPHORE."""
    base = _WIKI_BASES.get(variant, _WIKI_BASES["en"])
    api = f"{base}/w/api.php"

    def _fetch_sync() -> dict | None:
        """Synchronous Wikipedia fetch — runs in a thread pool."""
        import time as _time

        session = _requests.Session()
        session.headers.update({
            "User-Agent": "InceptBench-FactualAudit/1.0 (educational factual auditor; contact: dev@inceptbench)",
            "Accept": "application/json",
        })
        # Bypass proxy env vars
        session.proxies = {"http": None, "https": None}  # type: ignore[assignment]

        def _parse_retry_after(header: str) -> int:
            """Parse Retry-After which may be integer seconds or an HTTP-date string."""
            try:
                return int(header)
            except ValueError:
                from email.utils import parsedate_to_datetime
                import datetime as _dt
                try:
                    delta = parsedate_to_datetime(header) - _dt.datetime.now(_dt.timezone.utc)
                    return max(0, int(delta.total_seconds()))
                except Exception:
                    return 60

        def _get_with_retry(url: str, params: dict) -> _requests.Response:
            """GET with up to 5 retries on 429, respecting Retry-After header."""
            for attempt in range(5):
                resp = session.get(url, params=params, timeout=timeout)
                if resp.status_code == 429:
                    retry_after = resp.headers.get("Retry-After")
                    if retry_after and _parse_retry_after(retry_after) > 120:
                        logger.warning(
                            "Wikipedia 429 with Retry-After=%ss for %r — giving up (block too long)",
                            retry_after, query,
                        )
                        raise _requests.HTTPError(f"429 with Retry-After={retry_after}s", response=resp)
                    wait = min(_parse_retry_after(retry_after), 60) if retry_after else (2 ** attempt + 1)
                    wait = max(wait, 2)
                    logger.debug("Wikipedia 429 for %r, waiting %ds (attempt %d/5)", query, wait, attempt + 1)
                    _time.sleep(wait)
                    continue
                resp.raise_for_status()
                return resp
            resp.raise_for_status()
            return resp  # unreachable but satisfies type checker

        try:
            # Step 1: Search for candidate articles
            search_resp = _get_with_retry(api, {
                "action": "query",
                "list": "search",
                "srsearch": query,
                "format": "json",
                "srlimit": 3,
                "srnamespace": 0,
            })
            hits = search_resp.json().get("query", {}).get("search", [])

            if not hits:
                return {"hits": [], "pages": {}}

            # Step 2: Fetch plain-text extracts for top candidates
            titles = "|".join(h["title"] for h in hits[:3])
            extract_resp = _get_with_retry(api, {
                "action": "query",
                "prop": "extracts",
                "titles": titles,
                "format": "json",
                "explaintext": 1,
                "exsectionformat": "plain",
            })
            pages = extract_resp.json().get("query", {}).get("pages", {})
            return {"hits": hits, "pages": pages}

        except Exception as exc:
            logger.warning("Wikipedia API error for %r: %s", query, exc)
            return None

    try:
        result = await asyncio.to_thread(_fetch_sync)
    except Exception as exc:
        logger.warning("Wikipedia thread error for %r: %s", query, exc)
        _WIKI_CACHE[cache_key] = ""
        return ""

    if result is None:
        _WIKI_CACHE[cache_key] = ""
        return ""

    hits = result["hits"]
    pages = result["pages"]

    if not hits:
        # If Simple English returned nothing, try full English as fallback.
        # Check both cache layers before making a network call (semaphore is already held).
        if variant == "simple":
            logger.debug("No Simple Wikipedia results for %r, trying en", query)
            en_cache_key = (query.strip().lower(), "en")
            if en_cache_key in _WIKI_CACHE:
                en_result = _WIKI_CACHE[en_cache_key]
            else:
                disk_hit = _load_disk_cache(query, "en")
                if disk_hit is not None:
                    _WIKI_CACHE[en_cache_key] = disk_hit
                    en_result = disk_hit
                else:
                    en_result = await _fetch_wikipedia_passages_inner(query, "en", max_tokens, timeout, en_cache_key)
            _WIKI_CACHE[cache_key] = en_result
            return en_result
        logger.debug("No Wikipedia results for %r", query)
        _WIKI_CACHE[cache_key] = ""
        return ""

    passages = _select_passages(pages, query, max_tokens)
    _WIKI_CACHE[cache_key] = passages
    _save_disk_cache(query, variant, passages)

    if passages:
        logger.debug("Wikipedia retrieved %d chars for %r (%s)", len(passages), query, variant)
    else:
        logger.debug("Wikipedia: empty passages for %r (%s)", query, variant)

    return passages


# ---------------------------------------------------------------------------
# Passage selection
# ---------------------------------------------------------------------------

def _select_passages(pages: dict, query: str, max_tokens: int) -> str:
    """
    From Wikipedia API page extracts, select intro + most relevant section.

    Token budget: max_tokens * 4 chars (rough estimate).
    Priority: intro sections first, then sections ranked by keyword overlap with query.
    """
    char_budget = max_tokens * 4
    query_words = set(re.findall(r'\b[a-z]{3,}\b', query.lower()))

    intro_sections: list[str] = []
    scored_sections: list[tuple[float, str, str]] = []  # (score, title, text)

    for page in pages.values():
        extract = page.get("extract", "")
        if not extract:
            continue

        sections = _split_into_sections(extract)
        for i, (sec_title, sec_text) in enumerate(sections):
            if not sec_text.strip():
                continue
            is_intro = i == 0 or sec_title.lower() in ("", "introduction")
            if is_intro:
                intro_sections.append(sec_text.strip())
            else:
                sec_words = set(re.findall(r'\b[a-z]{3,}\b', sec_text.lower()))
                overlap = len(query_words & sec_words)
                scored_sections.append((overlap, sec_title, sec_text.strip()))

    scored_sections.sort(key=lambda x: -x[0])

    result_parts: list[str] = []
    used_chars = 0

    for intro_text in intro_sections:
        if used_chars >= char_budget:
            break
        chunk = intro_text[:char_budget - used_chars]
        result_parts.append(chunk)
        used_chars += len(chunk)

    for _, sec_title, sec_text in scored_sections:
        if used_chars >= char_budget:
            break
        remaining = char_budget - used_chars
        chunk = sec_text[:remaining]
        header = f"\n\n[{sec_title}]\n" if sec_title else "\n\n"
        result_parts.append(header + chunk)
        used_chars += len(chunk)

    return "\n\n".join(result_parts).strip()


def _split_into_sections(extract: str) -> list[tuple[str, str]]:
    """
    Split a Wikipedia plain-text extract (from explaintext=1) into
    (section_title, section_text) pairs. First element is always the intro
    with an empty title.
    """
    # With explaintext=1, section headers appear as lines like:
    #   == Overview ==
    #   === Subsection ===
    section_re = re.compile(r'^={2,}\s*(.+?)\s*={2,}\s*$', re.MULTILINE)
    parts = section_re.split(extract)

    sections: list[tuple[str, str]] = []
    # parts[0] = intro text; then alternating title, text
    if parts[0].strip():
        sections.append(("", parts[0].strip()))
    i = 1
    while i + 1 < len(parts):
        sections.append((parts[i].strip(), parts[i + 1].strip()))
        i += 2

    return sections


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def clear_cache() -> None:
    """Clear the in-memory Wikipedia cache (for testing)."""
    _WIKI_CACHE.clear()
