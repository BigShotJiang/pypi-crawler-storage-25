"""
Audio utility functions for educational content evaluation.

This module provides utilities for detecting audio URLs in content,
downloading audio files, and preparing them for Gemini API consumption.

Follows the same patterns as video_utils.py. Gemini handles audio
through the same Part-based API as video:
- Audio <20MB can be passed inline as bytes
- Audio >20MB needs File API upload (then delete after)

Supported formats per Gemini documentation:
WAV, MP3, AIFF, AAC, OGG Vorbis, FLAC

Reference: https://ai.google.dev/gemini-api/docs/audio
"""

import logging
import re
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional, Tuple

import aiohttp

logger = logging.getLogger(__name__)


class AudioInputMethod(Enum):
    """How to provide audio to Gemini API."""
    INLINE_BYTES = "inline_bytes"  # Pass as base64 bytes (<20MB)
    FILE_API = "file_api"  # Upload via File API (>20MB)


# Supported audio MIME types per Gemini documentation
SUPPORTED_AUDIO_MIMES = {
    "audio/wav",
    "audio/mp3",
    "audio/mpeg",
    "audio/aiff",
    "audio/aac",
    "audio/ogg",
    "audio/flac",
}

# Common audio MIME types we'll accept and map to Gemini-supported ones
ACCEPTED_AUDIO_MIMES = SUPPORTED_AUDIO_MIMES | {
    "audio/x-wav",
    "audio/x-aiff",
    "audio/mp4",       # .m4a containers
    "audio/x-m4a",
    "audio/opus",
    "audio/webm",
    "audio/x-ms-wma",
}

# File extension to MIME type mapping
EXTENSION_TO_MIME = {
    ".mp3": "audio/mp3",
    ".wav": "audio/wav",
    ".aiff": "audio/aiff",
    ".aif": "audio/aiff",
    ".aac": "audio/aac",
    ".ogg": "audio/ogg",
    ".oga": "audio/ogg",
    ".flac": "audio/flac",
    ".m4a": "audio/mp4",
    ".wma": "audio/x-ms-wma",
    ".opus": "audio/opus",
    ".webm": "audio/webm",
}

# Maximum size for inline audio (20MB per Gemini docs)
MAX_INLINE_SIZE = 20 * 1024 * 1024

# Maximum audio size we'll attempt to download (200MB — generous for long recordings)
MAX_DOWNLOAD_SIZE = 200 * 1024 * 1024


@dataclass
class AudioInfo:
    """Information about an audio URL."""
    url: str
    input_method: AudioInputMethod
    mime_type: str


@dataclass
class PreparedAudio:
    """Audio prepared for Gemini API consumption."""
    input_method: AudioInputMethod
    mime_type: str
    audio_bytes: Optional[bytes] = None
    file_uri: Optional[str] = None  # For File API uploads


def is_audio_url(url: str) -> bool:
    """Check if URL points to an audio file."""
    url_lower = url.lower().split('?')[0]  # Remove query params
    for ext in EXTENSION_TO_MIME:
        if url_lower.endswith(ext):
            return True
    return False


def get_mime_type_from_url(url: str) -> str:
    """Infer MIME type from audio URL."""
    url_lower = url.lower().split('?')[0]
    for ext, mime in EXTENSION_TO_MIME.items():
        if url_lower.endswith(ext):
            return mime
    return "audio/mp3"  # Default


def _normalize_mime_type(mime: str) -> str:
    """Normalize a MIME type to one Gemini supports."""
    if mime in SUPPORTED_AUDIO_MIMES:
        return mime
    mapping = {
        "audio/x-wav": "audio/wav",
        "audio/x-aiff": "audio/aiff",
        "audio/mp4": "audio/aac",
        "audio/x-m4a": "audio/aac",
        "audio/x-ms-wma": "audio/mp3",
    }
    return mapping.get(mime, mime)


def extract_audio_urls(content: str) -> List[str]:
    """
    Extract audio URLs from content.

    Detects both direct audio file URLs and embedded audio data URIs.

    Args:
        content: The content to extract URLs from

    Returns:
        List of unique audio URLs found in the content
    """
    urls = []

    audio_extensions = '|'.join(ext.lstrip('.') for ext in EXTENSION_TO_MIME)
    audio_url_pattern = rf'https?://[^\s<>"]+\.(?:{audio_extensions})(?:\?[^\s<>"]*)?'
    urls.extend(re.findall(audio_url_pattern, content, re.IGNORECASE))

    # Remove duplicates while preserving order
    seen = set()
    unique_urls = []
    for url in urls:
        url = url.strip().rstrip('.,;:)>')
        if url not in seen:
            seen.add(url)
            unique_urls.append(url)

    logger.debug(f"Extracted {len(unique_urls)} audio URL(s) from content")
    return unique_urls


def extract_audio_data_uris(content: str) -> List[str]:
    """Extract base64-encoded audio data URIs from content."""
    pattern = r'data:audio/[^;]+;base64,[A-Za-z0-9+/=]+'
    return re.findall(pattern, content)


def get_audio_info(url: str) -> AudioInfo:
    """Get information about an audio URL without downloading."""
    mime_type = get_mime_type_from_url(url)
    return AudioInfo(
        url=url,
        input_method=AudioInputMethod.INLINE_BYTES,
        mime_type=mime_type
    )


async def download_audio(url: str, timeout: int = 120) -> Tuple[bytes, str]:
    """
    Download an audio file from URL.

    Args:
        url: Audio URL to download
        timeout: Request timeout in seconds

    Returns:
        Tuple of (audio bytes, mime type)

    Raises:
        ValueError: If audio is too large or download fails
    """
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=timeout)) as response:
                response.raise_for_status()

                content_length = response.headers.get('Content-Length')
                if content_length and int(content_length) > MAX_DOWNLOAD_SIZE:
                    raise ValueError(
                        f"Audio too large: {int(content_length) / (1024*1024):.1f}MB "
                        f"(max: {MAX_DOWNLOAD_SIZE / (1024*1024):.0f}MB)"
                    )

                chunks = []
                total_size = 0
                async for chunk in response.content.iter_chunked(1024 * 1024):
                    total_size += len(chunk)
                    if total_size > MAX_DOWNLOAD_SIZE:
                        raise ValueError(
                            f"Audio too large: >{MAX_DOWNLOAD_SIZE / (1024*1024):.0f}MB"
                        )
                    chunks.append(chunk)

                audio_bytes = b''.join(chunks)

                content_type = response.headers.get('Content-Type', '').split(';')[0].strip()
                if content_type and content_type in ACCEPTED_AUDIO_MIMES:
                    mime_type = _normalize_mime_type(content_type)
                else:
                    mime_type = get_mime_type_from_url(url)

                logger.info(f"Downloaded audio: {len(audio_bytes) / (1024*1024):.1f}MB, type: {mime_type}")
                return audio_bytes, mime_type

    except aiohttp.ClientError as e:
        logger.error(f"Failed to download audio from {url}: {e}")
        raise ValueError(f"Failed to download audio: {e}")


async def prepare_audio_for_gemini(url: str) -> PreparedAudio:
    """
    Prepare audio for Gemini API consumption.

    Follows Gemini documentation guidance:
    - Audio <20MB: pass as inline bytes
    - Audio >20MB: needs File API upload (returns info for caller to handle)

    Args:
        url: Audio URL

    Returns:
        PreparedAudio with appropriate format

    Raises:
        ValueError: If audio cannot be prepared
    """
    audio_bytes, mime_type = await download_audio(url)

    if len(audio_bytes) <= MAX_INLINE_SIZE:
        logger.info(f"Audio is {len(audio_bytes) / (1024*1024):.1f}MB, using inline bytes")
        return PreparedAudio(
            input_method=AudioInputMethod.INLINE_BYTES,
            mime_type=mime_type,
            audio_bytes=audio_bytes
        )
    else:
        logger.info(f"Audio is {len(audio_bytes) / (1024*1024):.1f}MB, needs File API upload")
        return PreparedAudio(
            input_method=AudioInputMethod.FILE_API,
            mime_type=mime_type,
            audio_bytes=audio_bytes
        )


def has_audio_content(content: str) -> bool:
    """Quick check if content contains any audio URLs or data URIs."""
    return len(extract_audio_urls(content)) > 0 or len(extract_audio_data_uris(content)) > 0
