"""
Audio transcription for content decomposition.

This module provides utilities for transcribing audio content using Gemini,
primarily for classification and decomposition of audio-based educational content.

Unlike video transcription (which uses YouTube's transcript API), audio
transcription requires sending the audio to Gemini since there's no external
transcript service for arbitrary audio files.

Key design principles (same as video):
1. Transcripts are for DECOMPOSITION only (understanding structure)
2. Evaluators receive audio URLs/bytes, not transcripts (they listen to audio)
3. The extracted text is stored for debugging/review purposes
4. Transcripts are cached to avoid duplicate fetches
"""

import asyncio
import base64
import logging
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from inceptbench.tools.audio_utils import (
    download_audio,
    extract_audio_urls,
    extract_audio_data_uris,
    is_audio_url,
)

logger = logging.getLogger(__name__)


@dataclass
class AudioTranscriptSegment:
    """A segment of audio transcript with timing information."""
    text: str
    start: float  # Start time in seconds
    duration: float  # Duration in seconds

    @property
    def end(self) -> float:
        return self.start + self.duration

    @property
    def start_timestamp(self) -> str:
        return _format_timestamp(self.start)

    @property
    def end_timestamp(self) -> str:
        return _format_timestamp(self.end)


@dataclass
class AudioTranscript:
    """
    Transcript extracted from audio content.

    Contains the full text for decomposition purposes,
    plus metadata about the transcription.
    """
    audio_url: str
    extracted_text: str
    available: bool
    language: Optional[str] = None
    segments: List[AudioTranscriptSegment] = field(default_factory=list)
    error_message: Optional[str] = None


def _format_timestamp(seconds: float) -> str:
    """Format seconds as MM:SS or HH:MM:SS."""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)

    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


TRANSCRIPTION_PROMPT = (
    "Transcribe the speech in this audio file. "
    "Provide the full transcript as plain text. "
    "If there are distinct segments or speakers, separate them with paragraph breaks. "
    "Focus on accuracy and completeness. "
    "If the audio contains music or non-speech sounds, briefly note them in brackets "
    "like [music] or [applause]."
)


class AudioTranscriber:
    """
    Transcribes and caches audio content using Gemini.

    Transcripts are used for content classification and decomposition.
    The cache ensures each audio URL is transcribed only once, providing
    consistency across the evaluation pipeline.

    IMPORTANT: Transcripts are for decomposition only. Evaluators
    receive the original audio and listen to it themselves.
    """

    def __init__(self):
        self._cache: Dict[str, AudioTranscript] = {}

    def get_cached(self, audio_url: str) -> Optional[AudioTranscript]:
        """Get a cached transcript if available."""
        return self._cache.get(audio_url)

    def get_all_transcripts(self) -> Dict[str, AudioTranscript]:
        """Get all cached transcripts."""
        return self._cache.copy()

    async def transcribe(self, audio_url: str) -> AudioTranscript:
        """
        Transcribe audio from a URL using Gemini.

        Returns cached result if available.

        Args:
            audio_url: The audio URL to transcribe

        Returns:
            AudioTranscript with extracted text (may be empty if unavailable)
        """
        if audio_url in self._cache:
            logger.debug(f"Using cached audio transcript for: {audio_url[:50]}...")
            return self._cache[audio_url]

        transcript = await self._transcribe_with_gemini(audio_url)
        self._cache[audio_url] = transcript
        return transcript

    async def transcribe_all(self, content: str) -> Dict[str, AudioTranscript]:
        """
        Transcribe all audio in content.

        Args:
            content: Content potentially containing audio URLs

        Returns:
            Dict mapping audio URLs to their transcripts
        """
        audio_urls = extract_audio_urls(content)

        if not audio_urls:
            return {}

        logger.info(f"Transcribing {len(audio_urls)} audio file(s)...")

        for url in audio_urls:
            await self.transcribe(url)

        return self.get_all_transcripts()

    async def _transcribe_with_gemini(self, audio_url: str) -> AudioTranscript:
        """
        Transcribe audio using Gemini's audio understanding.

        Downloads the audio and sends it to Gemini for transcription.
        Uses the media_transcriber LLM config (Flash model for cost efficiency).
        """
        try:
            audio_bytes, mime_type = await download_audio(audio_url)

            from inceptbench.llm import LLMFactory, LLMMessage

            llm = LLMFactory.create("media_transcriber")

            result = await llm.generate_with_media(
                messages=[
                    LLMMessage(role="user", content=TRANSCRIPTION_PROMPT),
                ],
                media_bytes=audio_bytes,
                media_mime_type=mime_type,
            )

            transcript_text = result if isinstance(result, str) else str(result)

            logger.info(
                f"Transcribed audio {audio_url[:50]}...: "
                f"{len(transcript_text)} chars"
            )

            return AudioTranscript(
                audio_url=audio_url,
                extracted_text=transcript_text,
                available=True,
                language="en",
            )

        except Exception as e:
            logger.error(f"Error transcribing audio {audio_url[:50]}...: {e}")
            return AudioTranscript(
                audio_url=audio_url,
                extracted_text="",
                available=False,
                error_message=str(e)
            )

    def create_decomposition_content(
        self,
        original_content: str,
        transcripts: Optional[Dict[str, AudioTranscript]] = None
    ) -> str:
        """
        Create content view for decomposition by substituting audio transcripts.

        For each audio URL in the content, if a transcript is available,
        the URL is augmented with the transcript text. This allows the
        classifier and decomposer to understand audio structure.

        Uses [AUDIO_SOURCE: url] markers that survive decomposition,
        ensuring child nodes retain the audio source information.

        Args:
            original_content: The original content with audio URLs
            transcripts: Optional dict of transcripts (uses cache if not provided)

        Returns:
            Content with audio URLs augmented by transcripts
        """
        if transcripts is None:
            transcripts = self._cache

        if not transcripts:
            return original_content

        result = original_content

        for audio_url, transcript in transcripts.items():
            if transcript.available and transcript.extracted_text:
                replacement = (
                    f"[AUDIO_SOURCE: {audio_url}]\n"
                    f"[AUDIO_TRANSCRIPT START]\n"
                    f"{transcript.extracted_text}\n"
                    f"[AUDIO_TRANSCRIPT END]"
                )
                result = result.replace(audio_url, replacement)
            else:
                replacement = f"[AUDIO_SOURCE: {audio_url}]"
                result = result.replace(audio_url, replacement)

        return result

    def create_evaluation_content(
        self,
        node_content: str,
        scope_description: Optional[str] = None
    ) -> str:
        """
        Create content view for evaluation (strips transcripts).

        Evaluators should hear the audio, NOT read the transcript.

        Args:
            node_content: The node's content (may contain transcript markers)
            scope_description: Unused, kept for API compatibility

        Returns:
            Clean content with audio URL, no transcript
        """
        result = re.sub(
            r'\[AUDIO_TRANSCRIPT START\].*?\[AUDIO_TRANSCRIPT END\]',
            '',
            node_content,
            flags=re.DOTALL
        )

        result = re.sub(r'\n{3,}', '\n\n', result).strip()

        return result

    def clear_cache(self) -> None:
        """Clear the transcript cache."""
        self._cache.clear()
