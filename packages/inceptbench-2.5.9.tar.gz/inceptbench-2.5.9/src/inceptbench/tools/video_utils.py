"""
Video utility functions for educational content evaluation.

This module provides utilities for detecting video URLs in content,
downloading videos, and preparing them for Gemini API consumption.

Follows Gemini documentation guidance:
- YouTube URLs can be passed directly
- Videos <20MB can be passed inline as bytes
- Videos >20MB need File API upload (then delete after)

Reference: https://ai.google.dev/gemini-api/docs/video-understanding
"""

import logging
import re
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional, Tuple

import aiohttp

logger = logging.getLogger(__name__)


class VideoInputMethod(Enum):
    """How to provide video to Gemini API."""
    YOUTUBE_URL = "youtube_url"  # Pass URL directly
    INLINE_BYTES = "inline_bytes"  # Pass as base64 bytes (<20MB)
    FILE_API = "file_api"  # Upload via File API (>20MB)


# Supported video MIME types per Gemini documentation
SUPPORTED_VIDEO_MIMES = {
    "video/mp4",
    "video/mpeg",
    "video/mov",
    "video/avi",
    "video/x-flv",
    "video/mpg",
    "video/webm",
    "video/wmv",
    "video/3gpp",
}

# File extension to MIME type mapping
EXTENSION_TO_MIME = {
    ".mp4": "video/mp4",
    ".mpeg": "video/mpeg",
    ".mpg": "video/mpg",
    ".mov": "video/mov",
    ".avi": "video/avi",
    ".flv": "video/x-flv",
    ".webm": "video/webm",
    ".wmv": "video/wmv",
    ".3gp": "video/3gpp",
    ".3gpp": "video/3gpp",
}

# Maximum size for inline video (20MB per Gemini docs)
MAX_INLINE_SIZE = 20 * 1024 * 1024

# Maximum video size we'll attempt to download (500MB)
MAX_DOWNLOAD_SIZE = 500 * 1024 * 1024


@dataclass
class VideoInfo:
    """Information about a video URL."""
    url: str
    input_method: VideoInputMethod
    mime_type: str
    is_youtube: bool


@dataclass
class PreparedVideo:
    """Video prepared for Gemini API consumption."""
    input_method: VideoInputMethod
    mime_type: str
    url: Optional[str] = None  # For YouTube URLs
    video_bytes: Optional[bytes] = None  # For inline or File API
    file_uri: Optional[str] = None  # For File API uploads


def is_youtube_url(url: str) -> bool:
    """
    Check if URL is a YouTube video URL.
    
    Args:
        url: URL to check
        
    Returns:
        True if URL is a YouTube video URL
    """
    youtube_patterns = [
        r'(?:https?://)?(?:www\.)?youtube\.com/watch\?v=[\w-]+',
        r'(?:https?://)?(?:www\.)?youtube\.com/embed/[\w-]+',
        r'(?:https?://)?youtu\.be/[\w-]+',
        r'(?:https?://)?(?:www\.)?youtube\.com/v/[\w-]+',
        r'(?:https?://)?(?:www\.)?youtube\.com/shorts/[\w-]+',
    ]
    
    for pattern in youtube_patterns:
        if re.match(pattern, url, re.IGNORECASE):
            return True
    return False


def is_video_url(url: str) -> bool:
    """
    Check if URL points to a video file.
    
    Args:
        url: URL to check
        
    Returns:
        True if URL appears to be a video
    """
    if is_youtube_url(url):
        return True
    
    # Check for video file extensions
    url_lower = url.lower().split('?')[0]  # Remove query params
    for ext in EXTENSION_TO_MIME.keys():
        if url_lower.endswith(ext):
            return True
    
    return False


def get_mime_type_from_url(url: str) -> str:
    """
    Infer MIME type from video URL.
    
    Args:
        url: Video URL
        
    Returns:
        MIME type string
    """
    if is_youtube_url(url):
        return "video/*"  # YouTube URLs use wildcard MIME
    
    url_lower = url.lower().split('?')[0]
    for ext, mime in EXTENSION_TO_MIME.items():
        if url_lower.endswith(ext):
            return mime
    
    return "video/mp4"  # Default


def extract_video_urls(content: str) -> List[str]:
    """
    Extract video URLs from content.
    
    Args:
        content: The content to extract URLs from
        
    Returns:
        List of unique video URLs found in the content
    """
    urls = []
    
    # YouTube URLs
    youtube_patterns = [
        r'https?://(?:www\.)?youtube\.com/watch\?v=[\w-]+(?:&[\w=&-]*)?',
        r'https?://(?:www\.)?youtube\.com/embed/[\w-]+',
        r'https?://youtu\.be/[\w-]+',
        r'https?://(?:www\.)?youtube\.com/v/[\w-]+',
        r'https?://(?:www\.)?youtube\.com/shorts/[\w-]+',
    ]
    
    for pattern in youtube_patterns:
        urls.extend(re.findall(pattern, content, re.IGNORECASE))
    
    # Direct video file URLs
    video_extensions = '|'.join(ext.lstrip('.') for ext in EXTENSION_TO_MIME.keys())
    video_url_pattern = rf'https?://[^\s<>"]+\.(?:{video_extensions})(?:\?[^\s<>"]*)?'
    urls.extend(re.findall(video_url_pattern, content, re.IGNORECASE))
    
    # Remove duplicates while preserving order
    seen = set()
    unique_urls = []
    for url in urls:
        # Clean URL
        url = url.strip().rstrip('.,;:)>')
        if url not in seen:
            seen.add(url)
            unique_urls.append(url)
    
    logger.debug(f"Extracted {len(unique_urls)} video URL(s) from content")
    return unique_urls


def get_video_info(url: str) -> VideoInfo:
    """
    Get information about a video URL without downloading.
    
    Args:
        url: Video URL
        
    Returns:
        VideoInfo with details about the video
    """
    is_yt = is_youtube_url(url)
    mime_type = get_mime_type_from_url(url)
    
    if is_yt:
        # YouTube URLs can always be passed directly
        input_method = VideoInputMethod.YOUTUBE_URL
    else:
        # For non-YouTube, we'll determine method after checking size
        # Default to inline for now, will be updated when preparing
        input_method = VideoInputMethod.INLINE_BYTES
    
    return VideoInfo(
        url=url,
        input_method=input_method,
        mime_type=mime_type,
        is_youtube=is_yt
    )


async def download_video(url: str, timeout: int = 120) -> Tuple[bytes, str]:
    """
    Download a video from URL.
    
    Args:
        url: Video URL to download
        timeout: Request timeout in seconds
        
    Returns:
        Tuple of (video bytes, mime type)
        
    Raises:
        ValueError: If video is too large or download fails
    """
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=timeout)) as response:
                response.raise_for_status()
                
                # Check content length if available
                content_length = response.headers.get('Content-Length')
                if content_length and int(content_length) > MAX_DOWNLOAD_SIZE:
                    raise ValueError(
                        f"Video too large: {int(content_length) / (1024*1024):.1f}MB "
                        f"(max: {MAX_DOWNLOAD_SIZE / (1024*1024):.0f}MB)"
                    )
                
                # Download with size limit
                chunks = []
                total_size = 0
                async for chunk in response.content.iter_chunked(1024 * 1024):  # 1MB chunks
                    total_size += len(chunk)
                    if total_size > MAX_DOWNLOAD_SIZE:
                        raise ValueError(
                            f"Video too large: >{MAX_DOWNLOAD_SIZE / (1024*1024):.0f}MB"
                        )
                    chunks.append(chunk)
                
                video_bytes = b''.join(chunks)
                
                # Determine MIME type
                content_type = response.headers.get('Content-Type', '')
                if content_type and content_type in SUPPORTED_VIDEO_MIMES:
                    mime_type = content_type
                else:
                    mime_type = get_mime_type_from_url(url)
                
                logger.info(f"Downloaded video: {len(video_bytes) / (1024*1024):.1f}MB, type: {mime_type}")
                return video_bytes, mime_type
                
    except aiohttp.ClientError as e:
        logger.error(f"Failed to download video from {url}: {e}")
        raise ValueError(f"Failed to download video: {e}")


async def prepare_video_for_gemini(url: str) -> PreparedVideo:
    """
    Prepare a video for Gemini API consumption.
    
    Follows Gemini documentation guidance:
    - YouTube URLs: pass directly
    - Videos <20MB: pass as inline bytes
    - Videos >20MB: would need File API (returns info for caller to handle)
    
    Args:
        url: Video URL
        
    Returns:
        PreparedVideo with appropriate format for the video
        
    Raises:
        ValueError: If video cannot be prepared
    """
    info = get_video_info(url)
    
    if info.is_youtube:
        logger.info(f"Video is YouTube URL, will pass directly: {url}")
        return PreparedVideo(
            input_method=VideoInputMethod.YOUTUBE_URL,
            mime_type=info.mime_type,
            url=url
        )
    
    # Non-YouTube: need to download to determine size
    video_bytes, mime_type = await download_video(url)
    
    if len(video_bytes) <= MAX_INLINE_SIZE:
        logger.info(f"Video is {len(video_bytes) / (1024*1024):.1f}MB, using inline bytes")
        return PreparedVideo(
            input_method=VideoInputMethod.INLINE_BYTES,
            mime_type=mime_type,
            video_bytes=video_bytes
        )
    else:
        logger.info(f"Video is {len(video_bytes) / (1024*1024):.1f}MB, needs File API upload")
        return PreparedVideo(
            input_method=VideoInputMethod.FILE_API,
            mime_type=mime_type,
            video_bytes=video_bytes
        )


def has_video_content(content: str) -> bool:
    """
    Quick check if content contains any video URLs.
    
    Args:
        content: Content to check
        
    Returns:
        True if content contains video URLs
    """
    return len(extract_video_urls(content)) > 0
