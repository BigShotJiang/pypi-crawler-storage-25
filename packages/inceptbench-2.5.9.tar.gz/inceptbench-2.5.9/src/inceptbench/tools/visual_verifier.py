"""
Non-LLM deterministic verification of visual evidence against expected spec.

Compares structured evidence extracted by the image analyzer against
constraints from the visual spec. Every check is pure Python -- no LLM call.
"""

import logging
import re
from typing import TYPE_CHECKING, List, Optional

from pydantic import BaseModel, Field

from inceptbench.tools.visual_spec import ExpectedVisualSpec

if TYPE_CHECKING:
    from inceptbench.tools.unified_image_analyzer import ImageAnalysisData

logger = logging.getLogger(__name__)
_SUPPORTED_DIAGRAM_CONSTRAINTS = {
    "axis_labels_required",
    "legend_if_multiple_series",
    "no_overlap",
    "adequate_spacing",
}


# =============================================================================
# Models
# =============================================================================

class CheckResult(BaseModel):
    """Outcome of a single deterministic check."""
    check_name: str = Field(description="e.g., 'count_match', 'answer_leakage'")
    status: str = Field(description="'pass', 'fail', or 'uncertain'")
    expected: Optional[str] = None
    observed: Optional[str] = None
    confidence: str = Field(default="high", description="'high', 'medium', or 'low'")
    detail: str = Field(default="")


class VerificationResult(BaseModel):
    """Aggregated verification outcome across all checks."""
    checks: List[CheckResult] = Field(default_factory=list)
    passed_count: int = 0
    failed_count: int = 0
    uncertain_count: int = 0
    auto_reject: bool = Field(
        default=False,
        description="True if any hard-fail gate triggered with high confidence",
    )


# =============================================================================
# Individual check functions
# =============================================================================

def _check_answer_leakage(
    evidence: "ImageAnalysisData",
    spec: ExpectedVisualSpec,
) -> List[CheckResult]:
    """Check whether the image reveals answer values."""
    results: List[CheckResult] = []
    for rule in spec.text_rules:
        if rule.rule != "no_answer_leakage":
            continue
        if not rule.forbidden_values:
            results.append(CheckResult(
                check_name="answer_leakage",
                status="uncertain",
                detail="No specific answer values to check against",
                confidence="low",
            ))
            continue

        ocr_text = [t.lower().strip() for t in evidence.ocr_text_found if t]
        detected_numbers = [n.strip().lower() for n in evidence.detected_numbers if n is not None]

        if not ocr_text and not detected_numbers:
            results.append(CheckResult(
                check_name="answer_leakage",
                status="uncertain",
                expected="none of: " + ", ".join(rule.forbidden_values),
                observed="no OCR data available",
                confidence="low",
                detail="Cannot verify — no text/number evidence was extracted from the image",
            ))
            continue

        observed_chunks = set(ocr_text) | set(detected_numbers)
        observed_token_set = set()
        for chunk in observed_chunks:
            observed_token_set.update(re.findall(r"[a-z0-9./]+", chunk))

        leaked = []
        for raw_val in rule.forbidden_values:
            val = raw_val.lower().strip()
            if not val:
                continue

            # Exact token/number match.
            if val in observed_chunks or val in observed_token_set:
                leaked.append(raw_val)
                continue

            # OCR fragments often include the answer inside a longer sentence.
            if any(val in chunk for chunk in ocr_text):
                leaked.append(raw_val)
                continue

        if leaked:
            results.append(CheckResult(
                check_name="answer_leakage",
                status="fail",
                expected="none of: " + ", ".join(rule.forbidden_values),
                observed="found: " + ", ".join(leaked),
                confidence="high",
                detail="Image contains answer-revealing values",
            ))
        else:
            results.append(CheckResult(
                check_name="answer_leakage",
                status="pass",
                expected="none of: " + ", ".join(rule.forbidden_values),
                observed="none found in OCR/numbers",
                confidence="medium",
            ))
    return results


def _check_unsupported_constraints(spec: ExpectedVisualSpec) -> List[CheckResult]:
    """Surface constraints that are not deterministically implemented yet."""
    results: List[CheckResult] = []
    unsupported = [
        c for c in spec.diagram_constraints
        if c not in _SUPPORTED_DIAGRAM_CONSTRAINTS
    ]
    if unsupported:
        results.append(CheckResult(
            check_name="unsupported_constraints",
            status="uncertain",
            confidence="low",
            detail="No deterministic verifier implemented for: " + ", ".join(sorted(set(unsupported))),
        ))
    return results


def _check_count_match(
    evidence: "ImageAnalysisData",
    spec: ExpectedVisualSpec,
) -> List[CheckResult]:
    """Compare observed object counts against expected counts."""
    results: List[CheckResult] = []
    if not spec.expected_object_counts:
        return results

    evidence_counts = {
        oc.object_type.lower(): oc.total_count for oc in evidence.object_counts
    }

    for expected in spec.expected_object_counts:
        exp_key = expected.object_type.lower()
        best_match = None
        for obs_key, obs_val in evidence_counts.items():
            if exp_key in obs_key or obs_key in exp_key:
                best_match = (obs_key, obs_val)
                break

        if best_match is None:
            results.append(CheckResult(
                check_name="count_match",
                status="uncertain",
                expected=f"{expected.count} {expected.object_type}",
                observed="no matching object type found in evidence",
                confidence="low",
                detail="The analyzer did not report a count for this object type",
            ))
        else:
            obs_key, obs_val = best_match
            tolerance = max(1.0, expected.count * 0.1)
            if abs(obs_val - expected.count) <= tolerance:
                results.append(CheckResult(
                    check_name="count_match",
                    status="pass",
                    expected=f"{expected.count} {expected.object_type}",
                    observed=f"{obs_val} {obs_key}",
                    confidence="medium",
                ))
            else:
                results.append(CheckResult(
                    check_name="count_match",
                    status="uncertain",
                    expected=f"{expected.count} {expected.object_type}",
                    observed=f"{obs_val} {obs_key}",
                    confidence="low",
                    detail=(
                        f"Analyzer count disagrees by {abs(obs_val - expected.count)} "
                        f"(tolerance {tolerance}). Observed counts come from LLM vision output "
                        "and may be incorrect; verify directly from the image before penalizing."
                    ),
                ))
    return results


def _check_overlap(evidence: "ImageAnalysisData") -> List[CheckResult]:
    """Check if objects overlap."""
    if evidence.layout_info is None:
        return []
    if evidence.layout_info.overlap_detected is None:
        return [CheckResult(
            check_name="overlap",
            status="uncertain",
            confidence="low",
            detail="Overlap status was not determined",
        )]
    if evidence.layout_info.overlap_detected:
        return [CheckResult(
            check_name="overlap",
            status="fail",
            observed="overlap detected",
            confidence="medium",
            detail="Objects overlap, which may hurt clarity",
        )]
    return [CheckResult(
        check_name="overlap",
        status="pass",
        observed="no overlap",
        confidence="medium",
    )]


def _check_spacing(evidence: "ImageAnalysisData") -> List[CheckResult]:
    """Check if spacing is adequate."""
    if evidence.layout_info is None:
        return []
    if evidence.layout_info.spacing_adequate is None:
        return []
    if not evidence.layout_info.spacing_adequate:
        return [CheckResult(
            check_name="spacing",
            status="fail",
            observed="inadequate spacing",
            confidence="medium",
        )]
    return [CheckResult(
        check_name="spacing",
        status="pass",
        observed="adequate spacing",
        confidence="medium",
    )]


def _check_chart_features(
    evidence: "ImageAnalysisData",
    spec: ExpectedVisualSpec,
) -> List[CheckResult]:
    """Check chart-specific requirements (axes, legend)."""
    results: List[CheckResult] = []
    if evidence.chart_features is None:
        if "axis_labels_required" in spec.diagram_constraints:
            results.append(CheckResult(
                check_name="axis_labels",
                status="uncertain",
                confidence="low",
                detail="No chart feature data available",
            ))
        return results

    cf = evidence.chart_features

    if "axis_labels_required" in spec.diagram_constraints:
        if cf.has_x_axis_label and cf.has_y_axis_label:
            results.append(CheckResult(
                check_name="axis_labels",
                status="pass",
                observed="both axes labeled",
                confidence="medium",
            ))
        else:
            missing = []
            if not cf.has_x_axis_label:
                missing.append("x-axis")
            if not cf.has_y_axis_label:
                missing.append("y-axis")
            results.append(CheckResult(
                check_name="axis_labels",
                status="fail",
                expected="both axes labeled",
                observed=f"missing: {', '.join(missing)}",
                confidence="medium",
            ))

    if "legend_if_multiple_series" in spec.diagram_constraints:
        if cf.has_legend is None:
            results.append(CheckResult(
                check_name="legend_present",
                status="uncertain",
                confidence="low",
            ))
        elif cf.has_legend:
            results.append(CheckResult(
                check_name="legend_present",
                status="pass",
                confidence="medium",
            ))
        else:
            results.append(CheckResult(
                check_name="legend_present",
                status="fail",
                observed="no legend found",
                confidence="medium",
            ))
    return results


def _check_text_policy(
    evidence: "ImageAnalysisData",
    spec: ExpectedVisualSpec,
) -> List[CheckResult]:
    """Check text-presence rules (e.g., standalone images should have minimal text)."""
    results: List[CheckResult] = []
    for rule in spec.text_rules:
        if rule.rule != "no_descriptive_text":
            continue
        ocr_text = evidence.ocr_text_found
        if not ocr_text:
            results.append(CheckResult(
                check_name="text_policy",
                status="uncertain",
                confidence="low",
                detail="No OCR data to evaluate text policy",
            ))
        elif len(ocr_text) > 5:
            results.append(CheckResult(
                check_name="text_policy",
                status="fail",
                observed=f"{len(ocr_text)} text fragments found",
                confidence="medium",
                detail="Standalone image contains excessive text",
            ))
        else:
            results.append(CheckResult(
                check_name="text_policy",
                status="pass",
                observed=f"{len(ocr_text)} text fragments (acceptable)",
                confidence="medium",
            ))
    return results


def _check_option_key_consistency(
    evidence: "ImageAnalysisData",
    spec: ExpectedVisualSpec,
) -> List[CheckResult]:
    """
    Verify answer-key option labels against deterministic SVG equal-pair evidence.

    Activates only when:
    - deterministic equal-pair line exists in quality notes, and
    - answer_option_labels contains exactly two labels
    """
    if len(spec.answer_option_labels) != 2:
        return []
    parsed_pairs = set()

    # Preferred: structured deterministic property from analyzer.
    for prop in evidence.visual_properties:
        if prop.property_name != "deterministic_equal_area_pairs":
            continue
        for token in prop.value.split(","):
            token = token.strip().upper()
            pm = re.search(r"\b([A-Z])\s*-\s*([A-Z])\b", token)
            if pm:
                parsed_pairs.add("-".join(sorted((pm.group(1), pm.group(2)))))

    # Backward-compatible fallback: parse from notes if structured property missing.
    if not parsed_pairs:
        notes = evidence.quality_notes or ""
        m = re.search(
            r"Equal-area pairs from exact SVG line geometry:\s*(.+)",
            notes,
            flags=re.IGNORECASE,
        )
        if m:
            for token in m.group(1).split(","):
                pm = re.search(r"\b([A-Z])\s*-\s*([A-Z])\b", token.strip(), flags=re.IGNORECASE)
                if not pm:
                    continue
                a, b = pm.group(1).upper(), pm.group(2).upper()
                parsed_pairs.add("-".join(sorted((a, b))))

    # Additional structured fallback: derive equal-pairs from deterministic shape areas.
    if not parsed_pairs:
        for prop in evidence.visual_properties:
            if prop.property_name != "deterministic_shape_areas":
                continue
            area_map = {}
            for token in prop.value.split(","):
                token = token.strip()
                if "=" not in token:
                    continue
                label, area = token.split("=", 1)
                label = label.strip().upper()
                area = area.strip()
                if not re.match(r"^[A-Z]$", label):
                    continue
                if not re.match(r"^\d+$", area):
                    continue
                area_map[label] = int(area)
            labels = sorted(area_map.keys())
            for i in range(len(labels)):
                for j in range(i + 1, len(labels)):
                    if area_map[labels[i]] == area_map[labels[j]]:
                        parsed_pairs.add("-".join((labels[i], labels[j])))

    if not parsed_pairs:
        return []

    expected_pair = "-".join(sorted(spec.answer_option_labels))
    observed_pairs = ", ".join(sorted(parsed_pairs))
    if expected_pair in parsed_pairs:
        return [CheckResult(
            check_name="option_key_consistency",
            status="pass",
            expected=expected_pair,
            observed=observed_pairs,
            confidence="high",
            detail="Deterministic SVG geometry confirms keyed equal-area pair.",
        )]
    return [CheckResult(
        check_name="option_key_consistency",
        status="fail",
        expected=expected_pair,
        observed=observed_pairs,
        confidence="high",
        detail="Deterministic SVG geometry contradicts keyed equal-area pair.",
    )]


# =============================================================================
# Main verification function
# =============================================================================

def verify_visual_constraints(
    evidence: "ImageAnalysisData",
    spec: ExpectedVisualSpec,
) -> VerificationResult:
    """
    Run all deterministic checks comparing evidence against spec.

    This is entirely non-LLM.  Each check returns a CheckResult with status
    (pass / fail / uncertain) and a confidence level.  If confidence is low
    (evidence was missing or ambiguous), status is set to 'uncertain' so the
    final LLM evaluator can investigate.

    Parameters
    ----------
    evidence : ImageAnalysisData
        Structured evidence from the image analyzer.
    spec : ExpectedVisualSpec
        Expected constraints from content parsing.

    Returns
    -------
    VerificationResult
    """
    all_checks: List[CheckResult] = []

    all_checks.extend(_check_answer_leakage(evidence, spec))
    all_checks.extend(_check_count_match(evidence, spec))
    all_checks.extend(_check_overlap(evidence))
    all_checks.extend(_check_spacing(evidence))
    all_checks.extend(_check_chart_features(evidence, spec))
    all_checks.extend(_check_text_policy(evidence, spec))
    all_checks.extend(_check_option_key_consistency(evidence, spec))
    all_checks.extend(_check_unsupported_constraints(spec))

    passed = sum(1 for c in all_checks if c.status == "pass")
    failed = sum(1 for c in all_checks if c.status == "fail")
    uncertain = sum(1 for c in all_checks if c.status == "uncertain")

    # Option-key consistency is high-signal, but it depends on upstream visual
    # label extraction. Keep it advisory so it cannot force a hard rejection by
    # itself when geometry and labels disagree.
    hard_fail_checks = {"answer_leakage", "count_match"}
    auto_reject = any(
        c.status == "fail" and c.confidence == "high" and c.check_name in hard_fail_checks
        for c in all_checks
    )

    result = VerificationResult(
        checks=all_checks,
        passed_count=passed,
        failed_count=failed,
        uncertain_count=uncertain,
        auto_reject=auto_reject,
    )

    logger.info(
        "Visual verification: %d passed, %d failed, %d uncertain, auto_reject=%s",
        passed, failed, uncertain, auto_reject,
    )
    return result
